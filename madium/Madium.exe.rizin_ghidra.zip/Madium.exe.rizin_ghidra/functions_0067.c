// Chunk 67 - 50 functions

// ============================================================
// Function: FUN_14004c470
// Address: 0x14004c470
// Size: 55 bytes
// ============================================================
undefined8 fcn.14004c470(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004c2a7;
}

// ============================================================
// Function: FUN_14004c4b0
// Address: 0x14004c4b0
// Size: 25 bytes
// ============================================================
void fcn.14004c4b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004c4d0
// Address: 0x14004c4d0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004c4d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004c327;
}

// ============================================================
// Function: FUN_14004c510
// Address: 0x14004c510
// Size: 25 bytes
// ============================================================
void fcn.14004c510(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004c530
// Address: 0x14004c530
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004c530(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004c327;
}

// ============================================================
// Function: FUN_14004c570
// Address: 0x14004c570
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.14004c570(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004c5c0
// Address: 0x14004c5c0
// Size: 552 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1050h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1058h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1048h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1838h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1830h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1820h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1828h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2200h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1840h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_540h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_528h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1170h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1168h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1aa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1aa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4df8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4de0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4dc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4dd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4dc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4de8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1118h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1160h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1940h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1100h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_d08h
// WARNING: [rz-ghidra] Removing arg arg_4e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1128h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_d10h
// WARNING: [rz-ghidra] Removing arg arg_550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1688h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1680h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1690h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2947f26eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1960h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_580h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_568h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1948h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1130h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1598h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1818h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1810h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_6c8h
// WARNING: [rz-ghidra] Removing arg arg_dd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_de0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_de8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1038h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_860h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ca8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4610h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1060h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_600h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_608h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_610h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_6c1h
// WARNING: [rz-ghidra] Detected overlap for variable var_6d0h
// WARNING: [rz-ghidra] Removing arg arg_2a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcbf271h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1068h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1070h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ef8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3438h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_e99h
// WARNING: [rz-ghidra] Removing arg arg_2a18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1808h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_e91h
// WARNING: [rz-ghidra] Removing arg arg_4f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_800h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2118h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_6d1h
// WARNING: [rz-ghidra] Removing arg arg_12d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1860h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_6b9h
// WARNING: [rz-ghidra] Removing arg arg_948h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_e86h
// WARNING: [rz-ghidra] Removing arg arg_2af0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2b00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2b08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1138h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_940h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2947f26fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2af8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ae8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ae0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2b10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a28h because it doesn't fit into ProtoModel

void fcn.14004c5c0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_88h, int64_t arg_98h,
                  int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h,
                  int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_e8h, int64_t arg_f0h, int64_t arg_f8h,
                  int64_t arg_100h, int64_t arg_140h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h,
                  int64_t arg_160h, int64_t arg_170h, int64_t arg_178h, int64_t arg_180h, int64_t arg_188h)
{
    uint8_t uVar1;
    int64_t var_20h;
    int64_t var_76b80d98h;
    int64_t var_1678h;
    int64_t var_1620h;
    int64_t var_15cah;
    int64_t var_1520h;
    int64_t var_11f8h;
    int64_t var_11e0h;
    int64_t var_1038h;
    int64_t var_fd8h;
    int64_t var_ee8h;
    int64_t var_ee0h;
    int64_t var_ec8h;
    int64_t var_ec0h;
    int64_t var_eb8h;
    int64_t var_ea8h;
    int64_t var_ea0h;
    int64_t var_e98h;
    int64_t var_e90h;
    int64_t var_e88h;
    int64_t var_e80h;
    int64_t var_e78h;
    int64_t var_e70h;
    int64_t var_e68h;
    int64_t var_e48h;
    int64_t var_e40h;
    int64_t var_e38h;
    int64_t var_e30h;
    int64_t var_e28h;
    int64_t var_e20h;
    int64_t var_e18h;
    int64_t var_dd2h;
    int64_t var_dcah;
    int64_t var_d68h;
    int64_t var_d60h;
    int64_t var_d58h;
    int64_t var_d48h;
    int64_t var_d40h;
    int64_t var_d38h;
    int64_t var_d30h;
    int64_t var_d28h;
    int64_t var_d20h;
    int64_t var_d18h;
    int64_t var_d09h;
    int64_t var_d00h;
    int64_t var_cf8h;
    int64_t var_cd8h;
    int64_t var_cd0h;
    int64_t var_cc8h;
    int64_t var_cc0h;
    int64_t var_b40h;
    int64_t var_b30h;
    int64_t var_b28h;
    int64_t var_b20h;
    int64_t var_b18h;
    int64_t var_b10h;
    int64_t var_b08h;
    int64_t var_b00h;
    int64_t var_780h;
    int64_t var_778h;
    int64_t var_770h;
    int64_t var_768h;
    int64_t var_748h;
    int64_t var_730h;
    int64_t var_728h;
    int64_t var_720h;
    int64_t var_718h;
    int64_t var_710h;
    int64_t var_708h;
    int64_t var_700h;
    int64_t var_6f8h;
    int64_t var_6f0h;
    int64_t var_6e8h;
    int64_t var_6e0h;
    int64_t var_6d8h;
    int64_t var_6c9h;
    int64_t var_6c0h;
    int64_t var_6b8h;
    int64_t var_6b0h;
    int64_t var_4c8h;
    int64_t var_4c0h;
    int64_t var_4b8h;
    int64_t var_4b0h;
    int64_t var_4a8h;
    int64_t var_4a0h;
    int64_t var_468h;
    int64_t var_460h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_370h;
    int64_t var_368h;
    int64_t var_360h;
    int64_t var_358h;
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_310h;
    int64_t var_2e8h;
    int64_t var_2e0h;
    int64_t var_2c8h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t var_288h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014004c5f6. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (18 cases) at 0x14097adc4
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097adc4) + 0x14097adc4))();
    return;
}

// ============================================================
// Function: FUN_14004c7f0
// Address: 0x14004c7f0
// Size: 37 bytes
// ============================================================
void fcn.14004c7f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004c820
// Address: 0x14004c820
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_6a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004c820(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x728) = 2;
    fcn.14011d8b0(*(undefined8 *)(arg2 + 0xe70), arg2 + 0x728);
    return;
}

// ============================================================
// Function: FUN_14004c860
// Address: 0x14004c860
// Size: 25 bytes
// ============================================================
void fcn.14004c860(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004c880
// Address: 0x14004c880
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_de8h because it doesn't fit into ProtoModel

undefined8 fcn.14004c880(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xe88));
    *(undefined8 *)(arg2 + 0xe58) = uVar1;
    *(int64_t *)(arg2 + 0xe68) = iVar2;
    return 0x14004c71d;
}

// ============================================================
// Function: FUN_14004c8c0
// Address: 0x14004c8c0
// Size: 25 bytes
// ============================================================
void fcn.14004c8c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004c8e0
// Address: 0x14004c8e0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_dd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_de8h because it doesn't fit into ProtoModel

undefined8 fcn.14004c8e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xe58) = uVar1;
    *(int64_t *)(arg2 + 0xe68) = iVar2;
    return 0x14004c71d;
}

// ============================================================
// Function: FUN_14004c920
// Address: 0x14004c920
// Size: 25 bytes
// ============================================================
void fcn.14004c920(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004c940
// Address: 0x14004c940
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_de8h because it doesn't fit into ProtoModel

undefined8 fcn.14004c940(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xe80));
    *(undefined8 *)(arg2 + 0xe70) = uVar1;
    *(int64_t *)(arg2 + 0xe68) = iVar2;
    return 0x14004c79d;
}

// ============================================================
// Function: FUN_14004c980
// Address: 0x14004c980
// Size: 25 bytes
// ============================================================
void fcn.14004c980(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004c9a0
// Address: 0x14004c9a0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_de8h because it doesn't fit into ProtoModel

undefined8 fcn.14004c9a0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xe70) = uVar1;
    *(int64_t *)(arg2 + 0xe68) = iVar2;
    return 0x14004c79d;
}

// ============================================================
// Function: FUN_14004c9e0
// Address: 0x14004c9e0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_de8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_df0h because it doesn't fit into ProtoModel

void fcn.14004c9e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xe68) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xe70), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xe68) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004ca30
// Address: 0x14004ca30
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.14004ca30(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004ca3d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004ca5b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004ca6c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097ade4) + 0x14097ade4))();
    return;
}

// ============================================================
// Function: FUN_14004cc30
// Address: 0x14004cc30
// Size: 37 bytes
// ============================================================
void fcn.14004cc30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004cc60
// Address: 0x14004cc60
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004cc60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011da20(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_14004cca0
// Address: 0x14004cca0
// Size: 25 bytes
// ============================================================
void fcn.14004cca0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004ccc0
// Address: 0x14004ccc0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004ccc0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004cb57;
}

// ============================================================
// Function: FUN_14004cd00
// Address: 0x14004cd00
// Size: 25 bytes
// ============================================================
void fcn.14004cd00(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004cd20
// Address: 0x14004cd20
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004cd20(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004cb57;
}

// ============================================================
// Function: FUN_14004cd60
// Address: 0x14004cd60
// Size: 25 bytes
// ============================================================
void fcn.14004cd60(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004cd80
// Address: 0x14004cd80
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004cd80(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004cbd7;
}

// ============================================================
// Function: FUN_14004cdc0
// Address: 0x14004cdc0
// Size: 25 bytes
// ============================================================
void fcn.14004cdc0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004cde0
// Address: 0x14004cde0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004cde0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004cbd7;
}

// ============================================================
// Function: FUN_14004ce20
// Address: 0x14004ce20
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.14004ce20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004ce70
// Address: 0x14004ce70
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.14004ce70(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004ce7d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004ce9b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004ceac. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097ae04) + 0x14097ae04))();
    return;
}

// ============================================================
// Function: FUN_14004d070
// Address: 0x14004d070
// Size: 37 bytes
// ============================================================
void fcn.14004d070(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004d0a0
// Address: 0x14004d0a0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004d0a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011da20(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_14004d0e0
// Address: 0x14004d0e0
// Size: 25 bytes
// ============================================================
void fcn.14004d0e0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004d100
// Address: 0x14004d100
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004d100(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004cf97;
}

// ============================================================
// Function: FUN_14004d140
// Address: 0x14004d140
// Size: 25 bytes
// ============================================================
void fcn.14004d140(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004d160
// Address: 0x14004d160
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004d160(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004cf97;
}

// ============================================================
// Function: FUN_14004d1a0
// Address: 0x14004d1a0
// Size: 25 bytes
// ============================================================
void fcn.14004d1a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004d1c0
// Address: 0x14004d1c0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004d1c0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004d017;
}

// ============================================================
// Function: FUN_14004d200
// Address: 0x14004d200
// Size: 25 bytes
// ============================================================
void fcn.14004d200(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004d220
// Address: 0x14004d220
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004d220(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004d017;
}

// ============================================================
// Function: FUN_14004d260
// Address: 0x14004d260
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.14004d260(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004d2b0
// Address: 0x14004d2b0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1fb0h because it doesn't fit into ProtoModel

void fcn.14004d2b0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004d2bd;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00001fb0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004d2db;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004d2ec. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097ae24) + 0x14097ae24))();
    return;
}

// ============================================================
// Function: FUN_14004d4b0
// Address: 0x14004d4b0
// Size: 37 bytes
// ============================================================
void fcn.14004d4b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004d4e0
// Address: 0x14004d4e0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004d4e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xfe8) = 2;
    fcn.14011e680(*(undefined8 *)(arg2 + 0x1fc0), arg2 + 0xfe8);
    return;
}

// ============================================================
// Function: FUN_14004d520
// Address: 0x14004d520
// Size: 25 bytes
// ============================================================
void fcn.14004d520(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004d540
// Address: 0x14004d540
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.14004d540(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1fd8));
    *(undefined8 *)(arg2 + 0x1fa8) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x14004d3d7;
}

// ============================================================
// Function: FUN_14004d580
// Address: 0x14004d580
// Size: 25 bytes
// ============================================================
void fcn.14004d580(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004d5a0
// Address: 0x14004d5a0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.14004d5a0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1fa8) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x14004d3d7;
}

// ============================================================
// Function: FUN_14004d5e0
// Address: 0x14004d5e0
// Size: 25 bytes
// ============================================================
void fcn.14004d5e0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

