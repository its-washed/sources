// Chunk 63 - 50 functions

// ============================================================
// Function: FUN_140047cc0
// Address: 0x140047cc0
// Size: 65 bytes
// ============================================================
void fcn.140047cc0(undefined8 placeholder_0, int64_t arg2, int64_t arg_108h, int64_t arg_110h)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x188) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 400), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x188) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140047d10
// Address: 0x140047d10
// Size: 24 bytes
// ============================================================
void fcn.140047d10(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140047d30
// Address: 0x140047d30
// Size: 552 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1830h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1838h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1828h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1820h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1840h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2200h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_540h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcbf268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1170h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1168h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_528h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1100h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1118h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1130h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1aa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4df8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4dc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4de8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4dd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4dd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4dc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1160h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_43f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_d08h
// WARNING: [rz-ghidra] Removing arg arg_4e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1818h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1680h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4de0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2148h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1948h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_568h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1940h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_d11h
// WARNING: [rz-ghidra] Removing arg arg_3490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1960h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_30d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1aa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1050h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1058h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1060h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_d10h
// WARNING: [rz-ghidra] Removing arg arg_1858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_6d0h
// WARNING: [rz-ghidra] Removing arg arg_1040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1048h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_800h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_808h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4630h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4600h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4610h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_810h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_eb9h
// WARNING: [rz-ghidra] Removing arg arg_2ca8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1038h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_de0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_de8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_868h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4618h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_820h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1068h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_6e9h
// WARNING: [rz-ghidra] Removing arg arg_2a00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_600h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_608h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1070h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_6c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_6c1h
// WARNING: [rz-ghidra] Removing arg arg_1810h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_6c0h
// WARNING: [rz-ghidra] Removing arg arg_2938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1138h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_e91h
// WARNING: [rz-ghidra] Removing arg arg_610h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_618h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1860h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1128h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_940h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2947f267h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2af0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2af8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2b00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ae8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_948h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2b08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488ff24ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_dd8h
// WARNING: [rz-ghidra] Removing arg arg_2b10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ae0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_580h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcbf272h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ad8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1898h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1890h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_990h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_988h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1888h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1968h because it doesn't fit into ProtoModel

void fcn.140047d30(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
                  int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_e8h,
                  int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_138h, int64_t arg_140h,
                  int64_t arg_148h, int64_t arg_150h, int64_t arg_158h, int64_t arg_160h, int64_t arg_170h,
                  int64_t arg_178h, int64_t arg_180h, int64_t arg_188h)
{
    uint8_t uVar1;
    int64_t var_20h;
    int64_t var_3bd6c628h;
    int64_t var_1cd0h;
    int64_t var_1688h;
    int64_t var_1678h;
    int64_t var_1670h;
    int64_t var_1668h;
    int64_t var_1660h;
    int64_t var_1630h;
    int64_t var_1618h;
    int64_t var_15c2h;
    int64_t var_1520h;
    int64_t var_1510h;
    int64_t var_1508h;
    int64_t var_14c8h;
    int64_t var_1310h;
    int64_t var_1308h;
    int64_t var_11f0h;
    int64_t var_11d8h;
    int64_t var_1038h;
    int64_t var_ff0h;
    int64_t var_fe0h;
    int64_t var_f18h;
    int64_t var_f10h;
    int64_t var_f08h;
    int64_t var_ef8h;
    int64_t var_ef0h;
    int64_t var_ee8h;
    int64_t var_ed8h;
    int64_t var_ed0h;
    int64_t var_ec8h;
    int64_t var_ec0h;
    int64_t var_eb8h;
    int64_t var_ea8h;
    int64_t var_ea0h;
    int64_t var_e98h;
    int64_t var_e90h;
    int64_t var_e88h;
    int64_t var_e80h;
    int64_t var_e78h;
    int64_t var_e70h;
    int64_t var_e68h;
    int64_t var_e58h;
    int64_t var_e48h;
    int64_t var_e40h;
    int64_t var_e38h;
    int64_t var_e30h;
    int64_t var_e28h;
    int64_t var_e20h;
    int64_t var_e18h;
    int64_t var_e10h;
    int64_t var_df0h;
    int64_t var_de8h;
    int64_t var_de0h;
    int64_t var_dd2h;
    int64_t var_dcah;
    int64_t var_d68h;
    int64_t var_d60h;
    int64_t var_d58h;
    int64_t var_d50h;
    int64_t var_d48h;
    int64_t var_d40h;
    int64_t var_d38h;
    int64_t var_d30h;
    int64_t var_d28h;
    int64_t var_d20h;
    int64_t var_d18h;
    int64_t var_d09h;
    int64_t var_d00h;
    int64_t var_cf8h;
    int64_t var_cd8h;
    int64_t var_cd0h;
    int64_t var_cc8h;
    int64_t var_cc0h;
    int64_t var_c50h;
    int64_t var_b38h;
    int64_t var_b28h;
    int64_t var_b20h;
    int64_t var_b18h;
    int64_t var_b10h;
    int64_t var_b08h;
    int64_t var_af8h;
    int64_t var_780h;
    int64_t var_778h;
    int64_t var_770h;
    int64_t var_768h;
    int64_t var_740h;
    int64_t var_728h;
    int64_t var_720h;
    int64_t var_718h;
    int64_t var_708h;
    int64_t var_700h;
    int64_t var_6f8h;
    int64_t var_6f0h;
    int64_t var_6e8h;
    int64_t var_6e0h;
    int64_t var_6d8h;
    int64_t var_6c9h;
    int64_t var_6b8h;
    int64_t var_6b0h;
    int64_t var_4c8h;
    int64_t var_4c0h;
    int64_t var_4b8h;
    int64_t var_4b0h;
    int64_t var_4a8h;
    int64_t var_4a0h;
    int64_t var_460h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_440h;
    int64_t var_370h;
    int64_t var_368h;
    int64_t var_360h;
    int64_t var_358h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_310h;
    int64_t var_308h;
    int64_t var_2c8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t var_228h;
    int64_t var_218h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x000140047d66. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (3 cases) at 0x14097aba4
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097aba4) + 0x14097aba4))();
    return;
}

// ============================================================
// Function: FUN_140047f60
// Address: 0x140047f60
// Size: 37 bytes
// ============================================================
void fcn.140047f60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140047f90
// Address: 0x140047f90
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_6a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140047f90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x728) = 2;
    fcn.14011d8b0(*(undefined8 *)(arg2 + 0xe70), arg2 + 0x728);
    return;
}

// ============================================================
// Function: FUN_140047fd0
// Address: 0x140047fd0
// Size: 25 bytes
// ============================================================
void fcn.140047fd0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140047ff0
// Address: 0x140047ff0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_de8h because it doesn't fit into ProtoModel

undefined8 fcn.140047ff0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xe88));
    *(undefined8 *)(arg2 + 0xe58) = uVar1;
    *(int64_t *)(arg2 + 0xe68) = iVar2;
    return 0x140047e8d;
}

// ============================================================
// Function: FUN_140048030
// Address: 0x140048030
// Size: 25 bytes
// ============================================================
void fcn.140048030(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140048050
// Address: 0x140048050
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_dd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_de8h because it doesn't fit into ProtoModel

undefined8 fcn.140048050(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xe58) = uVar1;
    *(int64_t *)(arg2 + 0xe68) = iVar2;
    return 0x140047e8d;
}

// ============================================================
// Function: FUN_140048090
// Address: 0x140048090
// Size: 25 bytes
// ============================================================
void fcn.140048090(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400480b0
// Address: 0x1400480b0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_de8h because it doesn't fit into ProtoModel

undefined8 fcn.1400480b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xe80));
    *(undefined8 *)(arg2 + 0xe70) = uVar1;
    *(int64_t *)(arg2 + 0xe68) = iVar2;
    return 0x140047f0d;
}

// ============================================================
// Function: FUN_1400480f0
// Address: 0x1400480f0
// Size: 25 bytes
// ============================================================
void fcn.1400480f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140048110
// Address: 0x140048110
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_de8h because it doesn't fit into ProtoModel

undefined8 fcn.140048110(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xe70) = uVar1;
    *(int64_t *)(arg2 + 0xe68) = iVar2;
    return 0x140047f0d;
}

// ============================================================
// Function: FUN_140048150
// Address: 0x140048150
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_de8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_df0h because it doesn't fit into ProtoModel

void fcn.140048150(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xe68) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xe70), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xe68) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400481a0
// Address: 0x1400481a0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.1400481a0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400481ad;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x1400481cb;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x0001400481dc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097abc4) + 0x14097abc4))();
    return;
}

// ============================================================
// Function: FUN_1400483a0
// Address: 0x1400483a0
// Size: 37 bytes
// ============================================================
void fcn.1400483a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1400483d0
// Address: 0x1400483d0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400483d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011da20(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140048410
// Address: 0x140048410
// Size: 25 bytes
// ============================================================
void fcn.140048410(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140048430
// Address: 0x140048430
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140048430(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400482c7;
}

// ============================================================
// Function: FUN_140048470
// Address: 0x140048470
// Size: 25 bytes
// ============================================================
void fcn.140048470(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140048490
// Address: 0x140048490
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140048490(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400482c7;
}

// ============================================================
// Function: FUN_1400484d0
// Address: 0x1400484d0
// Size: 25 bytes
// ============================================================
void fcn.1400484d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400484f0
// Address: 0x1400484f0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400484f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140048347;
}

// ============================================================
// Function: FUN_140048530
// Address: 0x140048530
// Size: 25 bytes
// ============================================================
void fcn.140048530(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140048550
// Address: 0x140048550
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140048550(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140048347;
}

// ============================================================
// Function: FUN_140048590
// Address: 0x140048590
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140048590(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400485e0
// Address: 0x1400485e0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.1400485e0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400485ed;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004860b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004861c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097abe4) + 0x14097abe4))();
    return;
}

// ============================================================
// Function: FUN_1400487e0
// Address: 0x1400487e0
// Size: 37 bytes
// ============================================================
void fcn.1400487e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140048810
// Address: 0x140048810
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140048810(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140048850
// Address: 0x140048850
// Size: 25 bytes
// ============================================================
void fcn.140048850(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140048870
// Address: 0x140048870
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140048870(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140048707;
}

// ============================================================
// Function: FUN_1400488b0
// Address: 0x1400488b0
// Size: 25 bytes
// ============================================================
void fcn.1400488b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400488d0
// Address: 0x1400488d0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400488d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140048707;
}

// ============================================================
// Function: FUN_140048910
// Address: 0x140048910
// Size: 25 bytes
// ============================================================
void fcn.140048910(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140048930
// Address: 0x140048930
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140048930(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140048787;
}

// ============================================================
// Function: FUN_140048970
// Address: 0x140048970
// Size: 25 bytes
// ============================================================
void fcn.140048970(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140048990
// Address: 0x140048990
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140048990(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140048787;
}

// ============================================================
// Function: FUN_1400489d0
// Address: 0x1400489d0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.1400489d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140048a20
// Address: 0x140048a20
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel

void fcn.140048a20(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140048a2d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00001e90 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140048a4b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140048a5c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097ac04) + 0x14097ac04))();
    return;
}

// ============================================================
// Function: FUN_140048c20
// Address: 0x140048c20
// Size: 37 bytes
// ============================================================
void fcn.140048c20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140048c50
// Address: 0x140048c50
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140048c50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xf58) = 2;
    fcn.14011f650(*(undefined8 *)(arg2 + 0x1ea0), arg2 + 0xf58);
    return;
}

// ============================================================
// Function: FUN_140048c90
// Address: 0x140048c90
// Size: 25 bytes
// ============================================================
void fcn.140048c90(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140048cb0
// Address: 0x140048cb0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140048cb0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1eb8));
    *(undefined8 *)(arg2 + 0x1e88) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140048b47;
}

// ============================================================
// Function: FUN_140048cf0
// Address: 0x140048cf0
// Size: 25 bytes
// ============================================================
void fcn.140048cf0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140048d10
// Address: 0x140048d10
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140048d10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1e88) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140048b47;
}

// ============================================================
// Function: FUN_140048d50
// Address: 0x140048d50
// Size: 25 bytes
// ============================================================
void fcn.140048d50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140048d70
// Address: 0x140048d70
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140048d70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1eb0));
    *(undefined8 *)(arg2 + 0x1ea0) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140048bc7;
}

// ============================================================
// Function: FUN_140048db0
// Address: 0x140048db0
// Size: 25 bytes
// ============================================================
void fcn.140048db0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140048dd0
// Address: 0x140048dd0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140048dd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1ea0) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140048bc7;
}

// ============================================================
// Function: FUN_140048e10
// Address: 0x140048e10
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

void fcn.140048e10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1e98) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1ea0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1e98) + 0x10));
    }
    return;
}

