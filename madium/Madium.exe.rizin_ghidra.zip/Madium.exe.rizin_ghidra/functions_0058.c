// Chunk 58 - 50 functions

// ============================================================
// Function: FUN_140042540
// Address: 0x140042540
// Size: 37 bytes
// ============================================================
void fcn.140042540(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140042570
// Address: 0x140042570
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140042570(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_1400425b0
// Address: 0x1400425b0
// Size: 25 bytes
// ============================================================
void fcn.1400425b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400425d0
// Address: 0x1400425d0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400425d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140042467;
}

// ============================================================
// Function: FUN_140042610
// Address: 0x140042610
// Size: 25 bytes
// ============================================================
void fcn.140042610(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140042630
// Address: 0x140042630
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140042630(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140042467;
}

// ============================================================
// Function: FUN_140042670
// Address: 0x140042670
// Size: 25 bytes
// ============================================================
void fcn.140042670(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140042690
// Address: 0x140042690
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140042690(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400424e7;
}

// ============================================================
// Function: FUN_1400426d0
// Address: 0x1400426d0
// Size: 25 bytes
// ============================================================
void fcn.1400426d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400426f0
// Address: 0x1400426f0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400426f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400424e7;
}

// ============================================================
// Function: FUN_140042730
// Address: 0x140042730
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140042730(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140042780
// Address: 0x140042780
// Size: 552 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ce0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ce8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_10f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1130h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1138h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1128h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_276h
// WARNING: [rz-ghidra] Removing arg arg_2440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_10f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1100h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2740h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2750h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2758h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1140h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1160h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1168h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2748h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2528h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_10e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1148h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2438h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1da0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_da0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_da8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_270h
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2bd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2bc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_59e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_59f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_59e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1da8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1200h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1db0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Removing arg arg_2bc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4090h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_40a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2588h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2590h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1208h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5870h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5868h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5860h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5828h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_59f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2d78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_40a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4098h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4060h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2568h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1210h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2947fe86h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4088h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4068h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4070h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2580h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_40b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3cf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2088h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_40b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_540h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_557h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_528h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_19f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_19f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_40c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1af8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_988h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1438h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4808h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1af0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ae8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3640h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3528h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_10d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_cb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_53fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3628h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3638h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ad8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1960h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2680h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2690h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3540h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_55fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_567h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2688h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4078h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_cf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3630h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ad0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1948h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_279h
// WARNING: [rz-ghidra] Detected overlap for variable var_271h
// WARNING: [rz-ghidra] Removing arg arg_1ea0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1420h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1410h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_54fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_980h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3730h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3700h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3728h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3718h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1118h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2947fe8fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1680h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1688h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1568h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26eh
// WARNING: [rz-ghidra] Removing arg arg_cc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1540h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_748h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_19d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4050h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4058h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4048h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_36f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_10e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2430h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3708h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ba0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ba8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b8h
// WARNING: [rz-ghidra] Removing arg arg_fcbfe92h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Removing arg arg_40c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1b0h
// WARNING: [rz-ghidra] Removing arg arg_24b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ae0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1898h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1038h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1430h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1058h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488ffcb4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_608h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2130h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2128h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_2a1h
// WARNING: [rz-ghidra] Removing arg arg_2310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_aa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1940h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_370h
// WARNING: [rz-ghidra] Detected overlap for variable var_388h
// WARNING: [rz-ghidra] Removing arg arg_3380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c00h because it doesn't fit into ProtoModel

void fcn.140042780(int64_t arg1, int64_t arg_80h, int64_t arg_88h, int64_t arg_e0h, int64_t arg_e8h, int64_t arg_f0h,
                  int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h, int64_t arg_110h, int64_t arg_118h,
                  int64_t arg_120h)
{
    uint8_t uVar1;
    int64_t var_10b0h;
    int64_t var_fa8h;
    int64_t var_fa0h;
    int64_t var_f88h;
    int64_t var_a58h;
    int64_t var_a00h;
    int64_t var_8b0h;
    int64_t var_6f8h;
    int64_t var_6f0h;
    int64_t var_5d0h;
    int64_t var_5b8h;
    int64_t var_588h;
    int64_t var_470h;
    int64_t var_438h;
    int64_t var_430h;
    int64_t var_428h;
    int64_t var_418h;
    int64_t var_410h;
    int64_t var_408h;
    int64_t var_400h;
    int64_t var_3f0h;
    int64_t var_3d0h;
    int64_t var_3c0h;
    int64_t var_38fh;
    int64_t var_380h;
    int64_t var_378h;
    int64_t var_36ah;
    int64_t var_300h;
    int64_t var_2f8h;
    int64_t var_2f0h;
    int64_t var_2e8h;
    int64_t var_2e0h;
    int64_t var_2d8h;
    int64_t var_2d0h;
    int64_t var_2c8h;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_238h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1bah;
    int64_t var_1b2h;
    int64_t var_1aah;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e9h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x0001400427b6. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (33 cases) at 0x14097a924
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a924) + 0x14097a924))();
    return;
}

// ============================================================
// Function: FUN_1400429b0
// Address: 0x1400429b0
// Size: 37 bytes
// ============================================================
void fcn.1400429b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1400429e0
// Address: 0x1400429e0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400429e0(undefined8 placeholder_0, int64_t arg2, int64_t arg_98h, int64_t arg_1d0h)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x118) = 2;
    fcn.14011ec40(*(undefined8 *)(arg2 + 0x250), arg2 + 0x118);
    return;
}

// ============================================================
// Function: FUN_140042a20
// Address: 0x140042a20
// Size: 25 bytes
// ============================================================
void fcn.140042a20(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140042a40
// Address: 0x140042a40
// Size: 60 bytes
// ============================================================
undefined8 fcn.140042a40(undefined8 placeholder_0, int64_t arg2, int64_t arg_1b8h, int64_t arg_1c8h, int64_t arg_1e8h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x268));
    *(undefined8 *)(arg2 + 0x238) = uVar1;
    *(int64_t *)(arg2 + 0x248) = iVar2;
    return 0x1400428dd;
}

// ============================================================
// Function: FUN_140042a80
// Address: 0x140042a80
// Size: 25 bytes
// ============================================================
void fcn.140042a80(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140042aa0
// Address: 0x140042aa0
// Size: 55 bytes
// ============================================================
undefined8 fcn.140042aa0(undefined8 placeholder_0, int64_t arg2, int64_t arg_1b8h, int64_t arg_1c8h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x238) = uVar1;
    *(int64_t *)(arg2 + 0x248) = iVar2;
    return 0x1400428dd;
}

// ============================================================
// Function: FUN_140042ae0
// Address: 0x140042ae0
// Size: 25 bytes
// ============================================================
void fcn.140042ae0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140042b00
// Address: 0x140042b00
// Size: 60 bytes
// ============================================================
undefined8 fcn.140042b00(undefined8 placeholder_0, int64_t arg2, int64_t arg_1c8h, int64_t arg_1d0h, int64_t arg_1e0h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x260));
    *(undefined8 *)(arg2 + 0x250) = uVar1;
    *(int64_t *)(arg2 + 0x248) = iVar2;
    return 0x14004295d;
}

// ============================================================
// Function: FUN_140042b40
// Address: 0x140042b40
// Size: 25 bytes
// ============================================================
void fcn.140042b40(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140042b60
// Address: 0x140042b60
// Size: 55 bytes
// ============================================================
undefined8 fcn.140042b60(undefined8 placeholder_0, int64_t arg2, int64_t arg_1c8h, int64_t arg_1d0h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x250) = uVar1;
    *(int64_t *)(arg2 + 0x248) = iVar2;
    return 0x14004295d;
}

// ============================================================
// Function: FUN_140042ba0
// Address: 0x140042ba0
// Size: 67 bytes
// ============================================================
void fcn.140042ba0(undefined8 placeholder_0, int64_t arg2, int64_t arg_1c8h, int64_t arg_1d0h)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x248) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x250), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x248) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140042bf0
// Address: 0x140042bf0
// Size: 499 bytes
// ============================================================
void fcn.140042bf0(int64_t arg1)
{
    uint8_t uVar1;
    int64_t var_348h;
    int64_t var_30h;
    
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140042c26. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a944) + 0x14097a944))();
    return;
}

// ============================================================
// Function: FUN_140042df0
// Address: 0x140042df0
// Size: 37 bytes
// ============================================================
void fcn.140042df0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140042e20
// Address: 0x140042e20
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140042e20(undefined8 placeholder_0, int64_t arg2, int64_t arg_150h)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1d0) = 2;
    fcn.140120700(*(undefined8 *)(arg2 + 0x390), arg2 + 0x1d0);
    return;
}

// ============================================================
// Function: FUN_140042e60
// Address: 0x140042e60
// Size: 25 bytes
// ============================================================
void fcn.140042e60(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140042e80
// Address: 0x140042e80
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_308h because it doesn't fit into ProtoModel

undefined8 fcn.140042e80(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x3a8));
    *(undefined8 *)(arg2 + 0x378) = uVar1;
    *(int64_t *)(arg2 + 0x388) = iVar2;
    return 0x140042d11;
}

// ============================================================
// Function: FUN_140042ec0
// Address: 0x140042ec0
// Size: 25 bytes
// ============================================================
void fcn.140042ec0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140042ee0
// Address: 0x140042ee0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_308h because it doesn't fit into ProtoModel

undefined8 fcn.140042ee0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x378) = uVar1;
    *(int64_t *)(arg2 + 0x388) = iVar2;
    return 0x140042d11;
}

// ============================================================
// Function: FUN_140042f20
// Address: 0x140042f20
// Size: 25 bytes
// ============================================================
void fcn.140042f20(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140042f40
// Address: 0x140042f40
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_308h because it doesn't fit into ProtoModel

undefined8 fcn.140042f40(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x3a0));
    *(undefined8 *)(arg2 + 0x390) = uVar1;
    *(int64_t *)(arg2 + 0x388) = iVar2;
    return 0x140042d91;
}

// ============================================================
// Function: FUN_140042f80
// Address: 0x140042f80
// Size: 25 bytes
// ============================================================
void fcn.140042f80(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140042fa0
// Address: 0x140042fa0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_308h because it doesn't fit into ProtoModel

undefined8 fcn.140042fa0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x390) = uVar1;
    *(int64_t *)(arg2 + 0x388) = iVar2;
    return 0x140042d91;
}

// ============================================================
// Function: FUN_140042fe0
// Address: 0x140042fe0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_310h because it doesn't fit into ProtoModel

void fcn.140042fe0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x388) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x390), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x388) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140043030
// Address: 0x140043030
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.140043030(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004303d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004305b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004306c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a964) + 0x14097a964))();
    return;
}

// ============================================================
// Function: FUN_140043230
// Address: 0x140043230
// Size: 37 bytes
// ============================================================
void fcn.140043230(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140043260
// Address: 0x140043260
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140043260(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_1400432a0
// Address: 0x1400432a0
// Size: 25 bytes
// ============================================================
void fcn.1400432a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400432c0
// Address: 0x1400432c0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400432c0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140043157;
}

// ============================================================
// Function: FUN_140043300
// Address: 0x140043300
// Size: 25 bytes
// ============================================================
void fcn.140043300(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140043320
// Address: 0x140043320
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140043320(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140043157;
}

// ============================================================
// Function: FUN_140043360
// Address: 0x140043360
// Size: 25 bytes
// ============================================================
void fcn.140043360(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140043380
// Address: 0x140043380
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140043380(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400431d7;
}

// ============================================================
// Function: FUN_1400433c0
// Address: 0x1400433c0
// Size: 25 bytes
// ============================================================
void fcn.1400433c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400433e0
// Address: 0x1400433e0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400433e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400431d7;
}

// ============================================================
// Function: FUN_140043420
// Address: 0x140043420
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140043420(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140043470
// Address: 0x140043470
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel

void fcn.140043470(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004347d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00001e90 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004349b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x0001400434ac. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a984) + 0x14097a984))();
    return;
}

// ============================================================
// Function: FUN_140043670
// Address: 0x140043670
// Size: 37 bytes
// ============================================================
void fcn.140043670(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1400436a0
// Address: 0x1400436a0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400436a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xf58) = 2;
    fcn.14011d460(*(undefined8 *)(arg2 + 0x1ea0), arg2 + 0xf58);
    return;
}

