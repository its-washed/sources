// Chunk 34 - 50 functions

// ============================================================
// Function: FUN_140028100
// Address: 0x140028100
// Size: 53 bytes
// ============================================================
undefined8 fcn.140028100(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1c80) = uVar1;
    *(int64_t *)(arg2 + 0x1c88) = iVar2;
    return 0x14002803a;
}

// ============================================================
// Function: FUN_140028140
// Address: 0x140028140
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c00h because it doesn't fit into ProtoModel

void fcn.140028140(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1c88) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1c80), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1c88) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140028190
// Address: 0x140028190
// Size: 24 bytes
// ============================================================
void fcn.140028190(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400281b0
// Address: 0x1400281b0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1387h because it doesn't fit into ProtoModel

void fcn.1400281b0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1400281bc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001388 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001368 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400281de;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001387)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028204;
        func_0x00014011d740(*(int64_t *)(&stack0x00001368 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001387)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028224;
        func_0x000140796b10(*(int64_t *)(&stack0x00001368 + iVar4) + 0x1380, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001368 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028233;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002823f;
        func_0x0001400158f0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_1400282b0
// Address: 0x1400282b0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel

undefined8 fcn.1400282b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13a0));
    *(undefined8 *)(arg2 + 0x1380) = uVar1;
    *(int64_t *)(arg2 + 5000) = iVar2;
    return 0x14002824a;
}

// ============================================================
// Function: FUN_1400282f0
// Address: 0x1400282f0
// Size: 24 bytes
// ============================================================
void fcn.1400282f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140028310
// Address: 0x140028310
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel

undefined8 fcn.140028310(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1380) = uVar1;
    *(int64_t *)(arg2 + 5000) = iVar2;
    return 0x14002824a;
}

// ============================================================
// Function: FUN_140028350
// Address: 0x140028350
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel

void fcn.140028350(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 5000) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1380), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 5000) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400283a0
// Address: 0x1400283a0
// Size: 24 bytes
// ============================================================
void fcn.1400283a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400283c0
// Address: 0x1400283c0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1387h because it doesn't fit into ProtoModel

void fcn.1400283c0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1400283cc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001388 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001368 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400283ee;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001387)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028414;
        func_0x00014011db90(*(int64_t *)(&stack0x00001368 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001387)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028434;
        func_0x000140796b10(*(int64_t *)(&stack0x00001368 + iVar4) + 0x1380, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001368 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028443;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002844f;
        func_0x00014001a540(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_1400284c0
// Address: 0x1400284c0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel

undefined8 fcn.1400284c0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13a0));
    *(undefined8 *)(arg2 + 0x1380) = uVar1;
    *(int64_t *)(arg2 + 5000) = iVar2;
    return 0x14002845a;
}

// ============================================================
// Function: FUN_140028500
// Address: 0x140028500
// Size: 24 bytes
// ============================================================
void fcn.140028500(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140028520
// Address: 0x140028520
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel

undefined8 fcn.140028520(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1380) = uVar1;
    *(int64_t *)(arg2 + 5000) = iVar2;
    return 0x14002845a;
}

// ============================================================
// Function: FUN_140028560
// Address: 0x140028560
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel

void fcn.140028560(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 5000) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1380), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 5000) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400285b0
// Address: 0x1400285b0
// Size: 24 bytes
// ============================================================
void fcn.1400285b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400285d0
// Address: 0x1400285d0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1417h because it doesn't fit into ProtoModel

void fcn.1400285d0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1400285dc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001418 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x000013f8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400285fe;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001417)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028624;
        func_0x00014011ef20(*(int64_t *)(&stack0x000013f8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001417)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028644;
        func_0x000140796b10(*(int64_t *)(&stack0x000013f8 + iVar4) + 0x1410, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x000013f8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028653;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002865f;
        func_0x0001400156e0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_1400286d0
// Address: 0x1400286d0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel

undefined8 fcn.1400286d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1430));
    *(undefined8 *)(arg2 + 0x1410) = uVar1;
    *(int64_t *)(arg2 + 0x1418) = iVar2;
    return 0x14002866a;
}

// ============================================================
// Function: FUN_140028710
// Address: 0x140028710
// Size: 24 bytes
// ============================================================
void fcn.140028710(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140028730
// Address: 0x140028730
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel

undefined8 fcn.140028730(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1410) = uVar1;
    *(int64_t *)(arg2 + 0x1418) = iVar2;
    return 0x14002866a;
}

// ============================================================
// Function: FUN_140028770
// Address: 0x140028770
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel

void fcn.140028770(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1418) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1410), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1418) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400287c0
// Address: 0x1400287c0
// Size: 24 bytes
// ============================================================
void fcn.1400287c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400287e0
// Address: 0x1400287e0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1387h because it doesn't fit into ProtoModel

void fcn.1400287e0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1400287ec;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001388 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001368 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002880e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001387)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028834;
        func_0x00014011db90(*(int64_t *)(&stack0x00001368 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001387)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028854;
        func_0x000140796b10(*(int64_t *)(&stack0x00001368 + iVar4) + 0x1380, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001368 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028863;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002886f;
        func_0x000140016550(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_1400288e0
// Address: 0x1400288e0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel

undefined8 fcn.1400288e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13a0));
    *(undefined8 *)(arg2 + 0x1380) = uVar1;
    *(int64_t *)(arg2 + 5000) = iVar2;
    return 0x14002887a;
}

// ============================================================
// Function: FUN_140028920
// Address: 0x140028920
// Size: 24 bytes
// ============================================================
void fcn.140028920(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140028940
// Address: 0x140028940
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel

undefined8 fcn.140028940(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1380) = uVar1;
    *(int64_t *)(arg2 + 5000) = iVar2;
    return 0x14002887a;
}

// ============================================================
// Function: FUN_140028980
// Address: 0x140028980
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel

void fcn.140028980(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 5000) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1380), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 5000) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400289d0
// Address: 0x1400289d0
// Size: 24 bytes
// ============================================================
void fcn.1400289d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400289f0
// Address: 0x1400289f0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff7h because it doesn't fit into ProtoModel

void fcn.1400289f0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1400289fc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00000ff8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00000fd8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028a1e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00000ff7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028a44;
        func_0x00014011edb0(*(int64_t *)(&stack0x00000fd8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00000ff7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028a64;
        func_0x000140796b10(*(int64_t *)(&stack0x00000fd8 + iVar4) + 0xff0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00000fd8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028a73;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028a7f;
        func_0x00014001ab70(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140028af0
// Address: 0x140028af0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel

undefined8 fcn.140028af0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1010));
    *(undefined8 *)(arg2 + 0xff0) = uVar1;
    *(int64_t *)(arg2 + 0xff8) = iVar2;
    return 0x140028a8a;
}

// ============================================================
// Function: FUN_140028b30
// Address: 0x140028b30
// Size: 24 bytes
// ============================================================
void fcn.140028b30(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140028b50
// Address: 0x140028b50
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel

undefined8 fcn.140028b50(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xff0) = uVar1;
    *(int64_t *)(arg2 + 0xff8) = iVar2;
    return 0x140028a8a;
}

// ============================================================
// Function: FUN_140028b90
// Address: 0x140028b90
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel

void fcn.140028b90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xff8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xff0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xff8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140028be0
// Address: 0x140028be0
// Size: 24 bytes
// ============================================================
void fcn.140028be0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140028c00
// Address: 0x140028c00
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2197h because it doesn't fit into ProtoModel

void fcn.140028c00(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x140028c0c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00002198 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00002178 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028c2e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00002197)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028c54;
        func_0x00014011d180(*(int64_t *)(&stack0x00002178 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00002197)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028c74;
        func_0x000140796b10(*(int64_t *)(&stack0x00002178 + iVar4) + 0x2190, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00002178 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028c83;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028c8f;
        func_0x000140013780(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140028d00
// Address: 0x140028d00
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2130h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2118h because it doesn't fit into ProtoModel

undefined8 fcn.140028d00(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x21b0));
    *(undefined8 *)(arg2 + 0x2190) = uVar1;
    *(int64_t *)(arg2 + 0x2198) = iVar2;
    return 0x140028c9a;
}

// ============================================================
// Function: FUN_140028d40
// Address: 0x140028d40
// Size: 24 bytes
// ============================================================
void fcn.140028d40(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140028d60
// Address: 0x140028d60
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2118h because it doesn't fit into ProtoModel

undefined8 fcn.140028d60(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2190) = uVar1;
    *(int64_t *)(arg2 + 0x2198) = iVar2;
    return 0x140028c9a;
}

// ============================================================
// Function: FUN_140028da0
// Address: 0x140028da0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2118h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel

void fcn.140028da0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x2198) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x2190), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x2198) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140028df0
// Address: 0x140028df0
// Size: 24 bytes
// ============================================================
void fcn.140028df0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140028e10
// Address: 0x140028e10
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff7h because it doesn't fit into ProtoModel

void fcn.140028e10(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x140028e1c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00000ff8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00000fd8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028e3e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00000ff7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028e64;
        func_0x00014011edb0(*(int64_t *)(&stack0x00000fd8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00000ff7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028e84;
        func_0x000140796b10(*(int64_t *)(&stack0x00000fd8 + iVar4) + 0xff0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00000fd8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028e93;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028e9f;
        func_0x0001400173c0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140028f10
// Address: 0x140028f10
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel

undefined8 fcn.140028f10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1010));
    *(undefined8 *)(arg2 + 0xff0) = uVar1;
    *(int64_t *)(arg2 + 0xff8) = iVar2;
    return 0x140028eaa;
}

// ============================================================
// Function: FUN_140028f50
// Address: 0x140028f50
// Size: 24 bytes
// ============================================================
void fcn.140028f50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140028f70
// Address: 0x140028f70
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel

undefined8 fcn.140028f70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xff0) = uVar1;
    *(int64_t *)(arg2 + 0xff8) = iVar2;
    return 0x140028eaa;
}

// ============================================================
// Function: FUN_140028fb0
// Address: 0x140028fb0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel

void fcn.140028fb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xff8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xff0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xff8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140029000
// Address: 0x140029000
// Size: 24 bytes
// ============================================================
void fcn.140029000(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029020
// Address: 0x140029020
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_14a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a7h because it doesn't fit into ProtoModel

void fcn.140029020(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002902c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x000014a8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001488 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002904e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x000014a7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029074;
        func_0x00014011f200(*(int64_t *)(&stack0x00001488 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x000014a7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029094;
        func_0x000140796b10(*(int64_t *)(&stack0x00001488 + iVar4) + 0x14a0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001488 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400290a3;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400290af;
        func_0x00014001a330(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140029120
// Address: 0x140029120
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1420h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1428h because it doesn't fit into ProtoModel

undefined8 fcn.140029120(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x14c0));
    *(undefined8 *)(arg2 + 0x14a0) = uVar1;
    *(int64_t *)(arg2 + 0x14a8) = iVar2;
    return 0x1400290ba;
}

// ============================================================
// Function: FUN_140029160
// Address: 0x140029160
// Size: 24 bytes
// ============================================================
void fcn.140029160(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029180
// Address: 0x140029180
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1420h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1428h because it doesn't fit into ProtoModel

undefined8 fcn.140029180(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x14a0) = uVar1;
    *(int64_t *)(arg2 + 0x14a8) = iVar2;
    return 0x1400290ba;
}

// ============================================================
// Function: FUN_1400291c0
// Address: 0x1400291c0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1420h because it doesn't fit into ProtoModel

void fcn.1400291c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x14a8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x14a0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x14a8) + 0x10));
    }
    return;
}

