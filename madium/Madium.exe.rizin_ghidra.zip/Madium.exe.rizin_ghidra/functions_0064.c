// Chunk 64 - 50 functions

// ============================================================
// Function: FUN_140048e60
// Address: 0x140048e60
// Size: 505 bytes
// ============================================================
void fcn.140048e60(int64_t var_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_a8h, int64_t arg_128h,
                  int64_t arg_130h, int64_t arg_138h, int64_t arg_140h, int64_t arg_148h, int64_t arg_150h,
                  int64_t arg_158h, int64_t arg_160h, int64_t arg_168h, int64_t arg_170h, int64_t arg_178h,
                  int64_t arg_180h, int64_t arg_190h, int64_t arg_198h, int64_t arg_1b0h, int64_t arg_1b8h,
                  int64_t arg_1c0h, int64_t arg_1c8h, int64_t arg_1d0h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t var_7h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_49f0ff24h;
    int64_t var_3bd6b798h;
    int64_t var_e40h;
    int64_t var_7e8h;
    int64_t var_7e0h;
    int64_t var_790h;
    int64_t var_788h;
    int64_t var_480h;
    int64_t var_3a0h;
    int64_t var_360h;
    int64_t var_348h;
    int64_t var_1a8h;
    int64_t var_160h;
    int64_t var_150h;
    int64_t var_48h;
    int64_t var_30h;
    undefined8 uStack_20;
    int64_t var_8h;
    
    uStack_20 = 0x140048e6d;
    iVar2 = func_0x00014094c690();
    *(undefined8 *)(&stack0x000027f0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140048e8b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x000140048e9c. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (512 cases) at 0x14097ac24
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097ac24) + 0x14097ac24))();
    return;
}

// ============================================================
// Function: FUN_140049060
// Address: 0x140049060
// Size: 37 bytes
// ============================================================
void fcn.140049060(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140049090
// Address: 0x140049090
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140049090(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1408) = 2;
    fcn.14011ef20(*(undefined8 *)(arg2 + 0x2800), arg2 + 0x1408);
    return;
}

// ============================================================
// Function: FUN_1400490d0
// Address: 0x1400490d0
// Size: 25 bytes
// ============================================================
void fcn.1400490d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400490f0
// Address: 0x1400490f0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.1400490f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2818));
    *(undefined8 *)(arg2 + 0x27e8) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x140048f87;
}

// ============================================================
// Function: FUN_140049130
// Address: 0x140049130
// Size: 25 bytes
// ============================================================
void fcn.140049130(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140049150
// Address: 0x140049150
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.140049150(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x27e8) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x140048f87;
}

// ============================================================
// Function: FUN_140049190
// Address: 0x140049190
// Size: 25 bytes
// ============================================================
void fcn.140049190(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400491b0
// Address: 0x1400491b0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.1400491b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2810));
    *(undefined8 *)(arg2 + 0x2800) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x140049007;
}

// ============================================================
// Function: FUN_1400491f0
// Address: 0x1400491f0
// Size: 25 bytes
// ============================================================
void fcn.1400491f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140049210
// Address: 0x140049210
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.140049210(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2800) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x140049007;
}

// ============================================================
// Function: FUN_140049250
// Address: 0x140049250
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel

void fcn.140049250(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x27f8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x2800), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x27f8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400492a0
// Address: 0x1400492a0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3090h because it doesn't fit into ProtoModel

void fcn.1400492a0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400492ad;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00003090 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x1400492cb;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x0001400492dc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097ac44) + 0x14097ac44))();
    return;
}

// ============================================================
// Function: FUN_1400494a0
// Address: 0x1400494a0
// Size: 37 bytes
// ============================================================
void fcn.1400494a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1400494d0
// Address: 0x1400494d0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_17d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400494d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1858) = 2;
    fcn.140120420(*(undefined8 *)(arg2 + 0x30a0), arg2 + 0x1858);
    return;
}

// ============================================================
// Function: FUN_140049510
// Address: 0x140049510
// Size: 25 bytes
// ============================================================
void fcn.140049510(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140049530
// Address: 0x140049530
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3038h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3018h because it doesn't fit into ProtoModel

undefined8 fcn.140049530(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x30b8));
    *(undefined8 *)(arg2 + 0x3088) = uVar1;
    *(int64_t *)(arg2 + 0x3098) = iVar2;
    return 0x1400493c7;
}

// ============================================================
// Function: FUN_140049570
// Address: 0x140049570
// Size: 25 bytes
// ============================================================
void fcn.140049570(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140049590
// Address: 0x140049590
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3018h because it doesn't fit into ProtoModel

undefined8 fcn.140049590(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x3088) = uVar1;
    *(int64_t *)(arg2 + 0x3098) = iVar2;
    return 0x1400493c7;
}

// ============================================================
// Function: FUN_1400495d0
// Address: 0x1400495d0
// Size: 25 bytes
// ============================================================
void fcn.1400495d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400495f0
// Address: 0x1400495f0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3018h because it doesn't fit into ProtoModel

undefined8 fcn.1400495f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x30b0));
    *(undefined8 *)(arg2 + 0x30a0) = uVar1;
    *(int64_t *)(arg2 + 0x3098) = iVar2;
    return 0x140049447;
}

// ============================================================
// Function: FUN_140049630
// Address: 0x140049630
// Size: 25 bytes
// ============================================================
void fcn.140049630(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140049650
// Address: 0x140049650
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3018h because it doesn't fit into ProtoModel

undefined8 fcn.140049650(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x30a0) = uVar1;
    *(int64_t *)(arg2 + 0x3098) = iVar2;
    return 0x140049447;
}

// ============================================================
// Function: FUN_140049690
// Address: 0x140049690
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3020h because it doesn't fit into ProtoModel

void fcn.140049690(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x3098) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30a0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x3098) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400496e0
// Address: 0x1400496e0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.1400496e0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400496ed;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004970b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004971c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097ac64) + 0x14097ac64))();
    return;
}

// ============================================================
// Function: FUN_1400498e0
// Address: 0x1400498e0
// Size: 37 bytes
// ============================================================
void fcn.1400498e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140049910
// Address: 0x140049910
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140049910(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011da20(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140049950
// Address: 0x140049950
// Size: 25 bytes
// ============================================================
void fcn.140049950(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140049970
// Address: 0x140049970
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140049970(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140049807;
}

// ============================================================
// Function: FUN_1400499b0
// Address: 0x1400499b0
// Size: 25 bytes
// ============================================================
void fcn.1400499b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400499d0
// Address: 0x1400499d0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400499d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140049807;
}

// ============================================================
// Function: FUN_140049a10
// Address: 0x140049a10
// Size: 25 bytes
// ============================================================
void fcn.140049a10(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140049a30
// Address: 0x140049a30
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140049a30(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140049887;
}

// ============================================================
// Function: FUN_140049a70
// Address: 0x140049a70
// Size: 25 bytes
// ============================================================
void fcn.140049a70(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140049a90
// Address: 0x140049a90
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140049a90(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140049887;
}

// ============================================================
// Function: FUN_140049ad0
// Address: 0x140049ad0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140049ad0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140049b20
// Address: 0x140049b20
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2790h because it doesn't fit into ProtoModel

void fcn.140049b20(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140049b2d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00002790 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140049b4b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140049b5c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097ac84) + 0x14097ac84))();
    return;
}

// ============================================================
// Function: FUN_140049d20
// Address: 0x140049d20
// Size: 37 bytes
// ============================================================
void fcn.140049d20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140049d50
// Address: 0x140049d50
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140049d50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x13d8) = 2;
    fcn.14011f7c0(*(undefined8 *)(arg2 + 0x27a0), arg2 + 0x13d8);
    return;
}

// ============================================================
// Function: FUN_140049d90
// Address: 0x140049d90
// Size: 25 bytes
// ============================================================
void fcn.140049d90(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140049db0
// Address: 0x140049db0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2738h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2708h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2718h because it doesn't fit into ProtoModel

undefined8 fcn.140049db0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x27b8));
    *(undefined8 *)(arg2 + 0x2788) = uVar1;
    *(int64_t *)(arg2 + 0x2798) = iVar2;
    return 0x140049c47;
}

// ============================================================
// Function: FUN_140049df0
// Address: 0x140049df0
// Size: 25 bytes
// ============================================================
void fcn.140049df0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140049e10
// Address: 0x140049e10
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2708h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2718h because it doesn't fit into ProtoModel

undefined8 fcn.140049e10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2788) = uVar1;
    *(int64_t *)(arg2 + 0x2798) = iVar2;
    return 0x140049c47;
}

// ============================================================
// Function: FUN_140049e50
// Address: 0x140049e50
// Size: 25 bytes
// ============================================================
void fcn.140049e50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140049e70
// Address: 0x140049e70
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2730h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2718h because it doesn't fit into ProtoModel

undefined8 fcn.140049e70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x27b0));
    *(undefined8 *)(arg2 + 0x27a0) = uVar1;
    *(int64_t *)(arg2 + 0x2798) = iVar2;
    return 0x140049cc7;
}

// ============================================================
// Function: FUN_140049eb0
// Address: 0x140049eb0
// Size: 25 bytes
// ============================================================
void fcn.140049eb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140049ed0
// Address: 0x140049ed0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2718h because it doesn't fit into ProtoModel

undefined8 fcn.140049ed0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x27a0) = uVar1;
    *(int64_t *)(arg2 + 0x2798) = iVar2;
    return 0x140049cc7;
}

// ============================================================
// Function: FUN_140049f10
// Address: 0x140049f10
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2718h because it doesn't fit into ProtoModel

void fcn.140049f10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x2798) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x27a0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x2798) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140049f60
// Address: 0x140049f60
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2730h because it doesn't fit into ProtoModel

void fcn.140049f60(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140049f6d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00002730 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140049f8b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140049f9c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097aca4) + 0x14097aca4))();
    return;
}

// ============================================================
// Function: FUN_14004a160
// Address: 0x14004a160
// Size: 37 bytes
// ============================================================
void fcn.14004a160(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

