// Chunk 17 - 50 functions

// ============================================================
// Function: FUN_140014800
// Address: 0x140014800
// Size: 245 bytes
// ============================================================
void fcn.140014800(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t unaff_RBP;
    int64_t *piVar5;
    undefined8 unaff_RSI;
    int64_t iVar6;
    code *pcVar7;
    undefined8 auStack_50 [3];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    code **ppcStack_20;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar5 = &var_8h;
    var_10h = -2;
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    var_18h = arg1;
    var_8h = unaff_RBP;
    if (*piVar1 == 0) {
        auStack_50[0] = 0x14001482d;
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(var_18h + 0x30) == 1) {
        if ((*(int64_t *)(var_18h + 0x38) != 0) && (var_28h = *(int64_t *)(var_18h + 0x40), var_28h != 0)) {
            ppcStack_20 = *(code ***)(var_18h + 0x48);
            if (*ppcStack_20 != (code *)0x0) {
                auStack_50[0] = 0x14001487e;
                (**ppcStack_20)(var_28h);
            }
            pcVar4 = ppcStack_20[1];
            if (pcVar4 != (code *)0x0) {
                pcVar7 = ppcStack_20[2];
                *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
                auStack_50[0] = 0x140014898;
                iVar3 = var_28h;
                goto code_r0x0001404d3c50;
            }
        }
    } else if (*(int32_t *)(var_18h + 0x30) == 0) {
        auStack_50[0] = 0x14001484a;
        func_0x00014000da50(var_18h + 0x38);
    }
    if (*(int64_t *)(var_18h + 0x1870) != 0) {
        auStack_50[0] = 0x1400148b6;
        (**(code **)(*(int64_t *)(var_18h + 0x1870) + 0x18))(*(undefined8 *)(var_18h + 0x1878));
    }
    piVar1 = *(int64_t **)(var_18h + 0x1880);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            auStack_50[0] = 0x1400148dc;
            func_0x00014045efb0(var_18h + 0x1880);
        }
    }
    pcVar4 = (code *)0x1900;
    pcVar7 = (code *)0x80;
    iVar3 = var_18h;
    piVar5 = (int64_t *)var_8h;
code_r0x0001404d3c50:
    *(int64_t **)((int64_t)*(undefined **)0x20 + -8) = piVar5;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
    iVar6 = iVar3;
    if ((code *)0x10 < pcVar7) {
        iVar6 = *(int64_t *)(iVar3 + -8);
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140901d3e;
    uVar2 = (*(code *)0xe5f2d8)(iVar3, pcVar4);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, iVar6);
    return;
}

// ============================================================
// Function: FUN_140014900
// Address: 0x140014900
// Size: 51 bytes
// ============================================================
void fcn.140014900(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140014940
// Address: 0x140014940
// Size: 37 bytes
// ============================================================
void fcn.140014940(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1860);
    return;
}

// ============================================================
// Function: FUN_140014970
// Address: 0x140014970
// Size: 58 bytes
// ============================================================
void fcn.140014970(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1880);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1880);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1400149b0
// Address: 0x1400149b0
// Size: 41 bytes
// ============================================================
void fcn.1400149b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1900, 0x80);
    return;
}

// ============================================================
// Function: FUN_1400149e0
// Address: 0x1400149e0
// Size: 34 bytes
// ============================================================
void fcn.1400149e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012130(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140014a10
// Address: 0x140014a10
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140014a10(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000dcb0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x13c0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x13c0) + 0x18))(*(undefined8 *)(arg1 + 0x13c8));
    }
    piVar1 = *(int64_t **)(arg1 + 0x13d0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x13d0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1400);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140014b10
// Address: 0x140014b10
// Size: 51 bytes
// ============================================================
void fcn.140014b10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140014b50
// Address: 0x140014b50
// Size: 37 bytes
// ============================================================
void fcn.140014b50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x13b0);
    return;
}

// ============================================================
// Function: FUN_140014b80
// Address: 0x140014b80
// Size: 58 bytes
// ============================================================
void fcn.140014b80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x13d0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x13d0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140014bc0
// Address: 0x140014bc0
// Size: 41 bytes
// ============================================================
void fcn.140014bc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1400, 0x80);
    return;
}

// ============================================================
// Function: FUN_140014bf0
// Address: 0x140014bf0
// Size: 34 bytes
// ============================================================
void fcn.140014bf0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012070(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140014c20
// Address: 0x140014c20
// Size: 150 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140014c20(int64_t arg1)
{
    int64_t iVar1;
    code **ppcVar2;
    undefined8 uVar3;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 in_R9;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x58);
    if (iVar1 != 0) {
        ppcVar2 = *(code ***)(arg1 + 0x60);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar1);
        }
        if (ppcVar2[1] != (code *)0x0) {
            fcn.1404d3c50(iVar1, ppcVar2[1], ppcVar2[2]);
        }
    }
    if (*(int64_t *)arg1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 8), *(int64_t *)arg1, 1);
    }
    uVar3 = (*(code *)0xe5f2d8)(arg1, 0x70, 8, in_R9, 0xfffffffffffffffe, unaff_RSI, unaff_RBP);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, arg1);
    return;
}

// ============================================================
// Function: FUN_140014cc0
// Address: 0x140014cc0
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140014cc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    if ((**(uint64_t **)(arg2 + 0x38) & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x38) + 8), **(uint64_t **)(arg2 + 0x38), 1);
    }
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x38), 0x70, 8);
    return;
}

// ============================================================
// Function: FUN_140014d30
// Address: 0x140014d30
// Size: 101 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140014d30(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    func_0x00014001eac0();
    piVar1 = *(int64_t **)(arg1 + 0x88);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x0001406c6890(arg1 + 0x88);
    }
    piVar1 = *(int64_t **)(arg1 + 0x90);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 != 0) {
        return;
    }
    iVar2 = *(int64_t *)(arg1 + 0x90);
    if (iVar2 != -1) {
        LOCK();
        piVar1 = (int64_t *)(iVar2 + 8);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            uVar3 = (*(code *)0xe5f2d8)(iVar2, 0x20);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar3, 0, iVar2);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_140014da0
// Address: 0x140014da0
// Size: 53 bytes
// ============================================================
void fcn.140014da0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x88);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c6890(iVar1 + 0x88);
    }
    return;
}

// ============================================================
// Function: FUN_140014de0
// Address: 0x140014de0
// Size: 53 bytes
// ============================================================
void fcn.140014de0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x90);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.140682a80(iVar1 + 0x90);
    }
    return;
}

// ============================================================
// Function: FUN_140014e50
// Address: 0x140014e50
// Size: 285 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140014e50(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x148) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x150), *(int64_t *)(arg1 + 0x148), 1);
    }
    func_0x00014001eac0(arg1);
    if (*(int32_t *)(arg1 + 0x90) != 3) {
        if (*(int64_t *)(arg1 + 0x128) != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 0x130), *(int64_t *)(arg1 + 0x128), 1);
        }
        piVar1 = *(int64_t **)(arg1 + 0x118);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x00014045ec00(arg1 + 0x118);
        }
        func_0x00014001eac0(arg1 + 0x90);
    }
    piVar1 = *(int64_t **)(arg1 + 0x200);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.1406c6890(arg1 + 0x200);
    }
    fcn.140014d30(arg1 + 0x168);
    piVar1 = *(int64_t **)(arg1 + 0x208);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x0001406c66e0(arg1 + 0x208);
    }
    piVar1 = *(int64_t **)(arg1 + 0x210);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 != 0) {
        return;
    }
    iVar2 = *(int64_t *)(arg1 + 0x210);
    func_0x0001406da7b0(iVar2 + 0x18);
    if (iVar2 != -1) {
        LOCK();
        piVar1 = (int64_t *)(iVar2 + 8);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            uVar3 = (*(code *)0xe5f2d8)(iVar2, 0x30);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar3, 0, iVar2);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_140014f70
// Address: 0x140014f70
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140014f70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x28) + 0x90) != 3) {
        fcn.140003460(*(int64_t *)(arg2 + 0x28) + 0x90);
    }
    return;
}

// ============================================================
// Function: FUN_140014fa0
// Address: 0x140014fa0
// Size: 32 bytes
// ============================================================
void fcn.140014fa0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001eac0(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_140014fc0
// Address: 0x140014fc0
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140014fc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    piVar2 = *(int64_t **)(iVar1 + 0x200);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c6890(iVar1 + 0x200);
    }
    return;
}

// ============================================================
// Function: FUN_140015000
// Address: 0x140015000
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140015000(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140014d30(*(int64_t *)(arg2 + 0x28) + 0x168);
    return;
}

// ============================================================
// Function: FUN_140015030
// Address: 0x140015030
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140015030(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    piVar2 = *(int64_t **)(iVar1 + 0x208);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c66e0(iVar1 + 0x208);
    }
    return;
}

// ============================================================
// Function: FUN_140015070
// Address: 0x140015070
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140015070(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    piVar2 = *(int64_t **)(iVar1 + 0x210);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c6650(iVar1 + 0x210);
    }
    return;
}

// ============================================================
// Function: FUN_1400150b0
// Address: 0x1400150b0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1400150b0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000e3d0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1c90) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1c90) + 0x18))(*(undefined8 *)(arg1 + 0x1c98));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1ca0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1ca0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1d00);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_1400151b0
// Address: 0x1400151b0
// Size: 51 bytes
// ============================================================
void fcn.1400151b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400151f0
// Address: 0x1400151f0
// Size: 37 bytes
// ============================================================
void fcn.1400151f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1c80);
    return;
}

// ============================================================
// Function: FUN_140015220
// Address: 0x140015220
// Size: 58 bytes
// ============================================================
void fcn.140015220(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1ca0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1ca0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140015260
// Address: 0x140015260
// Size: 41 bytes
// ============================================================
void fcn.140015260(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1d00, 0x80);
    return;
}

// ============================================================
// Function: FUN_140015290
// Address: 0x140015290
// Size: 34 bytes
// ============================================================
void fcn.140015290(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400121f0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_1400152c0
// Address: 0x1400152c0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1400152c0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000e170(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1c00) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1c00) + 0x18))(*(undefined8 *)(arg1 + 0x1c08));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1c10);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1c10);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1c80);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_1400153c0
// Address: 0x1400153c0
// Size: 51 bytes
// ============================================================
void fcn.1400153c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140015400
// Address: 0x140015400
// Size: 37 bytes
// ============================================================
void fcn.140015400(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1bf0);
    return;
}

// ============================================================
// Function: FUN_140015430
// Address: 0x140015430
// Size: 58 bytes
// ============================================================
void fcn.140015430(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1c10);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1c10);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140015470
// Address: 0x140015470
// Size: 41 bytes
// ============================================================
void fcn.140015470(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1c80, 0x80);
    return;
}

// ============================================================
// Function: FUN_1400154a0
// Address: 0x1400154a0
// Size: 34 bytes
// ============================================================
void fcn.1400154a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012370(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_1400154d0
// Address: 0x1400154d0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1400154d0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000df10(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xee0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xee0) + 0x18))(*(undefined8 *)(arg1 + 0xee8));
    }
    piVar1 = *(int64_t **)(arg1 + 0xef0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xef0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0xf00);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_1400155d0
// Address: 0x1400155d0
// Size: 51 bytes
// ============================================================
void fcn.1400155d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140015610
// Address: 0x140015610
// Size: 37 bytes
// ============================================================
void fcn.140015610(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xed0);
    return;
}

// ============================================================
// Function: FUN_140015640
// Address: 0x140015640
// Size: 58 bytes
// ============================================================
void fcn.140015640(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xef0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xef0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140015680
// Address: 0x140015680
// Size: 41 bytes
// ============================================================
void fcn.140015680(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0xf00, 0x80);
    return;
}

// ============================================================
// Function: FUN_1400156b0
// Address: 0x1400156b0
// Size: 34 bytes
// ============================================================
void fcn.1400156b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400122b0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_1400156e0
// Address: 0x1400156e0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1400156e0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000f6d0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1420) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1420) + 0x18))(*(undefined8 *)(arg1 + 0x1428));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1430);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1430);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1480);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_1400157e0
// Address: 0x1400157e0
// Size: 51 bytes
// ============================================================
void fcn.1400157e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140015820
// Address: 0x140015820
// Size: 37 bytes
// ============================================================
void fcn.140015820(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1410);
    return;
}

// ============================================================
// Function: FUN_140015850
// Address: 0x140015850
// Size: 58 bytes
// ============================================================
void fcn.140015850(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1430);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1430);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140015890
// Address: 0x140015890
// Size: 41 bytes
// ============================================================
void fcn.140015890(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1480, 0x80);
    return;
}

// ============================================================
// Function: FUN_1400158c0
// Address: 0x1400158c0
// Size: 34 bytes
// ============================================================
void fcn.1400158c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400128b0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_1400158f0
// Address: 0x1400158f0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1400158f0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000e630(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1390) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1390) + 0x18))(*(undefined8 *)(arg1 + 0x1398));
    }
    piVar1 = *(int64_t **)(arg1 + 0x13a0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x13a0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1400);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_1400159f0
// Address: 0x1400159f0
// Size: 51 bytes
// ============================================================
void fcn.1400159f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

