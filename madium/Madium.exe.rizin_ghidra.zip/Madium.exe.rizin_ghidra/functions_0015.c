// Chunk 15 - 50 functions

// ============================================================
// Function: FUN_140012430
// Address: 0x140012430
// Size: 123 bytes
// ============================================================
void fcn.140012430(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x1348) == '\0') {
            func_0x000140005a40(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x1348) != '\x03') {
                return;
            }
            func_0x000140005a40(arg1 + 0xa68);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_1400124b0
// Address: 0x1400124b0
// Size: 51 bytes
// ============================================================
void fcn.1400124b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400124f0
// Address: 0x1400124f0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400124f0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x1ca8) == '\0') {
            func_0x0001400089a0(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x1ca8) != '\x03') {
                return;
            }
            func_0x0001400089a0(arg1 + 0xf18);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012570
// Address: 0x140012570
// Size: 51 bytes
// ============================================================
void fcn.140012570(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400125b0
// Address: 0x1400125b0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400125b0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x1468) == '\0') {
            func_0x000140008590(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x1468) != '\x03') {
                return;
            }
            func_0x000140008590(arg1 + 0xaf8);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012630
// Address: 0x140012630
// Size: 51 bytes
// ============================================================
void fcn.140012630(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012670
// Address: 0x140012670
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012670(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x14c8) == '\0') {
            func_0x000140006bc0(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x14c8) != '\x03') {
                return;
            }
            func_0x000140006bc0(arg1 + 0xb28);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_1400126f0
// Address: 0x1400126f0
// Size: 51 bytes
// ============================================================
void fcn.1400126f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012730
// Address: 0x140012730
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012730(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x13a8) == '\0') {
            func_0x000140008130(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x13a8) != '\x03') {
                return;
            }
            func_0x000140008130(arg1 + 0xa98);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_1400127b0
// Address: 0x1400127b0
// Size: 51 bytes
// ============================================================
void fcn.1400127b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400127f0
// Address: 0x1400127f0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400127f0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x1348) == '\0') {
            func_0x000140005ea0(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x1348) != '\x03') {
                return;
            }
            func_0x000140005ea0(arg1 + 0xa68);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012870
// Address: 0x140012870
// Size: 51 bytes
// ============================================================
void fcn.140012870(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400128b0
// Address: 0x1400128b0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400128b0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x13d8) == '\0') {
            func_0x000140006300(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x13d8) != '\x03') {
                return;
            }
            func_0x000140006300(arg1 + 0xab0);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012930
// Address: 0x140012930
// Size: 51 bytes
// ============================================================
void fcn.140012930(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012970
// Address: 0x140012970
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012970(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x13d8) == '\0') {
            func_0x000140006760(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x13d8) != '\x03') {
                return;
            }
            func_0x000140006760(arg1 + 0xab0);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_1400129f0
// Address: 0x1400129f0
// Size: 51 bytes
// ============================================================
void fcn.1400129f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012a30
// Address: 0x140012a30
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012a30(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x13a8) == '\0') {
            func_0x000140007cd0(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x13a8) != '\x03') {
                return;
            }
            func_0x000140007cd0(arg1 + 0xa98);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012ab0
// Address: 0x140012ab0
// Size: 51 bytes
// ============================================================
void fcn.140012ab0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012af0
// Address: 0x140012af0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012af0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x1348) == '\0') {
            func_0x000140007870(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x1348) != '\x03') {
                return;
            }
            func_0x000140007870(arg1 + 0xa68);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012b70
// Address: 0x140012b70
// Size: 51 bytes
// ============================================================
void fcn.140012b70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012bb0
// Address: 0x140012bb0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012bb0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x1ca8) == '\0') {
            func_0x000140007410(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x1ca8) != '\x03') {
                return;
            }
            func_0x000140007410(arg1 + 0xf18);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012c30
// Address: 0x140012c30
// Size: 51 bytes
// ============================================================
void fcn.140012c30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012c70
// Address: 0x140012c70
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012c70(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x18b8) == '\0') {
            func_0x000140007020(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x18b8) != '\x03') {
                return;
            }
            func_0x000140007020(arg1 + 0xd20);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012cf0
// Address: 0x140012cf0
// Size: 51 bytes
// ============================================================
void fcn.140012cf0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012d30
// Address: 0x140012d30
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012d30(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0xf28) == '\0') {
            func_0x000140009670(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0xf28) != '\x03') {
                return;
            }
            func_0x000140009670(arg1 + 0x858);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012db0
// Address: 0x140012db0
// Size: 51 bytes
// ============================================================
void fcn.140012db0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012df0
// Address: 0x140012df0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012df0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0xf28) == '\0') {
            func_0x00014000a390(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0xf28) != '\x03') {
                return;
            }
            func_0x00014000a390(arg1 + 0x858);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012e70
// Address: 0x140012e70
// Size: 51 bytes
// ============================================================
void fcn.140012e70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012eb0
// Address: 0x140012eb0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140012eb0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x198) == '\0') {
            func_0x00014001be30();
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x198) != '\x03') {
                return;
            }
            func_0x00014001be30();
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012f30
// Address: 0x140012f30
// Size: 51 bytes
// ============================================================
void fcn.140012f30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012f70
// Address: 0x140012f70
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012f70(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0xfb8) == '\0') {
            func_0x000140008e00(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0xfb8) != '\x03') {
                return;
            }
            func_0x000140008e00(arg1 + 0x8a0);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012ff0
// Address: 0x140012ff0
// Size: 51 bytes
// ============================================================
void fcn.140012ff0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140013030
// Address: 0x140013030
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140013030(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0xf58) == '\0') {
            func_0x000140009f30(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0xf58) != '\x03') {
                return;
            }
            func_0x000140009f30(arg1 + 0x870);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_1400130b0
// Address: 0x1400130b0
// Size: 51 bytes
// ============================================================
void fcn.1400130b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400130f0
// Address: 0x1400130f0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400130f0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0xf28) == '\0') {
            func_0x000140009ad0(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0xf28) != '\x03') {
                return;
            }
            func_0x000140009ad0(arg1 + 0x858);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140013170
// Address: 0x140013170
// Size: 51 bytes
// ============================================================
void fcn.140013170(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400131b0
// Address: 0x1400131b0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400131b0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0xfb8) == '\0') {
            func_0x000140009260(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0xfb8) != '\x03') {
                return;
            }
            func_0x000140009260(arg1 + 0x8a0);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140013230
// Address: 0x140013230
// Size: 51 bytes
// ============================================================
void fcn.140013230(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140013270
// Address: 0x140013270
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140013270(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0xfe8) == '\0') {
            func_0x00014000b050(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0xfe8) != '\x03') {
                return;
            }
            func_0x00014000b050(arg1 + 0x8b8);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_1400132f0
// Address: 0x1400132f0
// Size: 51 bytes
// ============================================================
void fcn.1400132f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140013330
// Address: 0x140013330
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140013330(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0xb08) == '\0') {
            func_0x00014000a7f0(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0xb08) != '\x03') {
                return;
            }
            func_0x00014000a7f0(arg1 + 0x648);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_1400133b0
// Address: 0x1400133b0
// Size: 51 bytes
// ============================================================
void fcn.1400133b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400133f0
// Address: 0x1400133f0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400133f0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0xf28) == '\0') {
            func_0x00014000b450(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0xf28) != '\x03') {
                return;
            }
            func_0x00014000b450(arg1 + 0x858);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140013470
// Address: 0x140013470
// Size: 51 bytes
// ============================================================
void fcn.140013470(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400134b0
// Address: 0x1400134b0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400134b0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0xbc8) == '\0') {
            func_0x00014000ac00(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0xbc8) != '\x03') {
                return;
            }
            func_0x00014000ac00(arg1 + 0x6a8);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140013530
// Address: 0x140013530
// Size: 51 bytes
// ============================================================
void fcn.140013530(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140013570
// Address: 0x140013570
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140013570(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000bd40(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x2e60) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x2e60) + 0x18))(*(undefined8 *)(arg1 + 0x2e68));
    }
    piVar1 = *(int64_t **)(arg1 + 0x2e70);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x00014045efb0(arg1 + 0x2e70);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x2e80);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140013670
// Address: 0x140013670
// Size: 51 bytes
// ============================================================
void fcn.140013670(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400136b0
// Address: 0x1400136b0
// Size: 37 bytes
// ============================================================
void fcn.1400136b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x2e50);
    return;
}

// ============================================================
// Function: FUN_1400136e0
// Address: 0x1400136e0
// Size: 58 bytes
// ============================================================
void fcn.1400136e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x2e70);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x2e70);
        }
    }
    return;
}

