// Chunk 74 - 50 functions

// ============================================================
// Function: FUN_140054070
// Address: 0x140054070
// Size: 60 bytes
// ============================================================
undefined8 fcn.140054070(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140053ec7;
}

// ============================================================
// Function: FUN_1400540b0
// Address: 0x1400540b0
// Size: 25 bytes
// ============================================================
void fcn.1400540b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400540d0
// Address: 0x1400540d0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400540d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140053ec7;
}

// ============================================================
// Function: FUN_140054110
// Address: 0x140054110
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140054110(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140054160
// Address: 0x140054160
// Size: 505 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_187h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3088h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3078h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1840h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3090h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_beh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcc00f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1638h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1640h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1630h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5cb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_7h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Removing arg arg_4318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2170h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2800h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800f6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ad8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ae0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ad0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ab8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ac0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5aa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5aa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1208h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_50c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2430h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4aa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4a70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4a80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_30d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7cfh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Removing arg arg_b68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel

void fcn.140054160(int64_t var_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_128h, int64_t arg_130h,
                  int64_t arg_138h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h, int64_t arg_160h,
                  int64_t arg_168h, int64_t arg_170h, int64_t arg_178h, int64_t arg_190h, int64_t arg_198h,
                  int64_t arg_1b0h, int64_t arg_1b8h, int64_t arg_1c0h, int64_t arg_1c8h, int64_t arg_1d0h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_3bd6b798h;
    int64_t var_7e8h;
    int64_t var_7e0h;
    int64_t var_790h;
    int64_t var_690h;
    int64_t var_688h;
    int64_t var_680h;
    int64_t var_368h;
    int64_t var_350h;
    int64_t var_348h;
    int64_t var_1a8h;
    int64_t var_150h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    undefined8 uStack_20;
    int64_t var_8h;
    
    uStack_20 = 0x14005416d;
    iVar2 = func_0x00014094c690();
    *(undefined8 *)(&stack0x00001e90 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14005418b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014005419c. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (18 cases) at 0x14097b164
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b164) + 0x14097b164))();
    return;
}

// ============================================================
// Function: FUN_140054360
// Address: 0x140054360
// Size: 37 bytes
// ============================================================
void fcn.140054360(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140054390
// Address: 0x140054390
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140054390(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xf58) = 2;
    fcn.14011d460(*(undefined8 *)(arg2 + 0x1ea0), arg2 + 0xf58);
    return;
}

// ============================================================
// Function: FUN_1400543d0
// Address: 0x1400543d0
// Size: 25 bytes
// ============================================================
void fcn.1400543d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400543f0
// Address: 0x1400543f0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.1400543f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1eb8));
    *(undefined8 *)(arg2 + 0x1e88) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140054287;
}

// ============================================================
// Function: FUN_140054430
// Address: 0x140054430
// Size: 25 bytes
// ============================================================
void fcn.140054430(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140054450
// Address: 0x140054450
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140054450(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1e88) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140054287;
}

// ============================================================
// Function: FUN_140054490
// Address: 0x140054490
// Size: 25 bytes
// ============================================================
void fcn.140054490(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400544b0
// Address: 0x1400544b0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.1400544b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1eb0));
    *(undefined8 *)(arg2 + 0x1ea0) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140054307;
}

// ============================================================
// Function: FUN_1400544f0
// Address: 0x1400544f0
// Size: 25 bytes
// ============================================================
void fcn.1400544f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140054510
// Address: 0x140054510
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140054510(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1ea0) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140054307;
}

// ============================================================
// Function: FUN_140054550
// Address: 0x140054550
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel

void fcn.140054550(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1e98) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1ea0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1e98) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400545a0
// Address: 0x1400545a0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.1400545a0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400545ad;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x1400545cb;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x0001400545dc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b184) + 0x14097b184))();
    return;
}

// ============================================================
// Function: FUN_1400547a0
// Address: 0x1400547a0
// Size: 37 bytes
// ============================================================
void fcn.1400547a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1400547d0
// Address: 0x1400547d0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400547d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140054810
// Address: 0x140054810
// Size: 25 bytes
// ============================================================
void fcn.140054810(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140054830
// Address: 0x140054830
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140054830(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400546c7;
}

// ============================================================
// Function: FUN_140054870
// Address: 0x140054870
// Size: 25 bytes
// ============================================================
void fcn.140054870(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140054890
// Address: 0x140054890
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140054890(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400546c7;
}

// ============================================================
// Function: FUN_1400548d0
// Address: 0x1400548d0
// Size: 25 bytes
// ============================================================
void fcn.1400548d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400548f0
// Address: 0x1400548f0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400548f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140054747;
}

// ============================================================
// Function: FUN_140054930
// Address: 0x140054930
// Size: 25 bytes
// ============================================================
void fcn.140054930(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140054950
// Address: 0x140054950
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140054950(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140054747;
}

// ============================================================
// Function: FUN_140054990
// Address: 0x140054990
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140054990(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400549e0
// Address: 0x1400549e0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.1400549e0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400549ed;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140054a0b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140054a1c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b1a4) + 0x14097b1a4))();
    return;
}

// ============================================================
// Function: FUN_140054be0
// Address: 0x140054be0
// Size: 37 bytes
// ============================================================
void fcn.140054be0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140054c10
// Address: 0x140054c10
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140054c10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011da20(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140054c50
// Address: 0x140054c50
// Size: 25 bytes
// ============================================================
void fcn.140054c50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140054c70
// Address: 0x140054c70
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140054c70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140054b07;
}

// ============================================================
// Function: FUN_140054cb0
// Address: 0x140054cb0
// Size: 25 bytes
// ============================================================
void fcn.140054cb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140054cd0
// Address: 0x140054cd0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140054cd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140054b07;
}

// ============================================================
// Function: FUN_140054d10
// Address: 0x140054d10
// Size: 25 bytes
// ============================================================
void fcn.140054d10(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140054d30
// Address: 0x140054d30
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140054d30(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140054b87;
}

// ============================================================
// Function: FUN_140054d70
// Address: 0x140054d70
// Size: 25 bytes
// ============================================================
void fcn.140054d70(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140054d90
// Address: 0x140054d90
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140054d90(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140054b87;
}

// ============================================================
// Function: FUN_140054dd0
// Address: 0x140054dd0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140054dd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140054e20
// Address: 0x140054e20
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.140054e20(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140054e2d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140054e4b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140054e5c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b1c4) + 0x14097b1c4))();
    return;
}

// ============================================================
// Function: FUN_140055020
// Address: 0x140055020
// Size: 37 bytes
// ============================================================
void fcn.140055020(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140055050
// Address: 0x140055050
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140055050(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140055090
// Address: 0x140055090
// Size: 25 bytes
// ============================================================
void fcn.140055090(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400550b0
// Address: 0x1400550b0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400550b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140054f47;
}

// ============================================================
// Function: FUN_1400550f0
// Address: 0x1400550f0
// Size: 25 bytes
// ============================================================
void fcn.1400550f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140055110
// Address: 0x140055110
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140055110(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140054f47;
}

// ============================================================
// Function: FUN_140055150
// Address: 0x140055150
// Size: 25 bytes
// ============================================================
void fcn.140055150(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140055170
// Address: 0x140055170
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140055170(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140054fc7;
}

// ============================================================
// Function: FUN_1400551b0
// Address: 0x1400551b0
// Size: 25 bytes
// ============================================================
void fcn.1400551b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

