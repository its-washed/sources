// Chunk 2 - 50 functions

// ============================================================
// Function: FUN_140002690
// Address: 0x140002690
// Size: 65 bytes
// ============================================================
void fcn.140002690(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x48) + 0x98);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0xa0), iVar1 << 2, 4);
    }
    return;
}

// ============================================================
// Function: FUN_1400026e0
// Address: 0x1400026e0
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400026e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    if (*(int64_t *)(iVar1 + 0xb8) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0xc0), *(int64_t *)(iVar1 + 0xb8) << 2, 4);
    }
    *(undefined *)(iVar1 + 0xd2) = 0;
    if (*(char *)(iVar1 + 0xd1) != '\0') {
        func_0x000140014d30(iVar1 + 0xd8);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_140002750
// Address: 0x140002750
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140002750(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    *(undefined *)(*(int64_t *)(arg2 + 0x48) + 0xd1) = 0;
    return;
}

// ============================================================
// Function: FUN_140002780
// Address: 0x140002780
// Size: 43 bytes
// ============================================================
void fcn.140002780(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400027b0
// Address: 0x1400027b0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400027b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140002800
// Address: 0x140002800
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.140002800(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140002850
// Address: 0x140002850
// Size: 54 bytes
// ============================================================
void fcn.140002850(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x40);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140002890
// Address: 0x140002890
// Size: 43 bytes
// ============================================================
void fcn.140002890(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400028c0
// Address: 0x1400028c0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400028c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140002910
// Address: 0x140002910
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.140002910(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140002960
// Address: 0x140002960
// Size: 607 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140002960(int64_t arg1)
{
    undefined8 uVar1;
    char cVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0xfd8) == '\0') {
        fcn.14001c990();
        iVar5 = *(int64_t *)(arg1 + 0x218);
        var_30h = 0;
        iVar4 = *(int64_t *)(arg1 + 0x210);
        while (iVar5 != var_30h) {
            var_30h = var_30h + 1;
            func_0x0001402727a0(iVar4);
            iVar4 = iVar4 + 0x60;
        }
        goto code_r0x000140002abf;
    }
    if (*(char *)(arg1 + 0xfd8) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0xfd0) == '\x03') {
        var_30h = arg1 + 0xb40;
        cVar2 = *(char *)(arg1 + 0xb98);
        if (cVar2 != '\x04') goto code_r0x0001400029b9;
code_r0x000140002b0f:
        if (*(char *)(var_30h + 0x488) == '\x03') {
            if (*(char *)(var_30h + 0x480) == '\x03') {
                func_0x00014001f080((int64_t *)(var_30h + 0x298));
                func_0x00014001d690((int64_t *)(var_30h + 0x238));
                *(undefined *)(var_30h + 0x481) = 0;
            } else if (*(char *)(var_30h + 0x480) == '\0') {
                func_0x00014001d7a0((int64_t *)(var_30h + 0xf8));
            }
        } else if (*(char *)(var_30h + 0x488) == '\0') {
            func_0x00014001d7a0((int64_t *)(var_30h + 0x60));
        }
code_r0x000140002b3f:
        *(undefined *)(var_30h + 0x59) = 0;
        if (*(int64_t *)(var_30h + 0x40) != 0) {
            fcn.1404d3c50(*(undefined8 *)(var_30h + 0x48), *(int64_t *)(var_30h + 0x40), 1);
        }
        var_30h = var_30h + 0x28;
        iVar5 = *(int64_t *)var_30h;
        if (iVar5 != 0) {
code_r0x0001400029ce:
            fcn.1404d3c50(*(int64_t *)(var_30h + 8), iVar5, 1);
        }
    } else if (*(char *)(arg1 + 0xfd0) == '\0') {
        var_30h = arg1 + 0x6b0;
        cVar2 = *(char *)(arg1 + 0x708);
        if (cVar2 == '\x04') goto code_r0x000140002b0f;
code_r0x0001400029b9:
        if (cVar2 == '\x03') {
            func_0x00014001d230((int64_t *)(var_30h + 0x60));
            goto code_r0x000140002b3f;
        }
        if ((cVar2 != '\0') || (iVar5 = *(int64_t *)var_30h, iVar5 == 0)) goto code_r0x0001400029e3;
        goto code_r0x0001400029ce;
    }
code_r0x0001400029e3:
    fcn.14001c990(arg1);
    iVar5 = *(int64_t *)(arg1 + 0x218);
    var_30h = 0;
    iVar4 = *(int64_t *)(arg1 + 0x210);
    while (iVar5 != var_30h) {
        var_30h = var_30h + 1;
        func_0x0001402727a0(iVar4);
        iVar4 = iVar4 + 0x60;
    }
code_r0x000140002abf:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140002bc0
// Address: 0x140002bc0
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140002bc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001d690(iVar1 + 0x238);
    *(undefined *)(iVar1 + 0x481) = 0;
    return;
}

// ============================================================
// Function: FUN_140002c00
// Address: 0x140002c00
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140002c00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    *(undefined *)(iVar1 + 0x59) = 0;
    if (*(int64_t *)(iVar1 + 0x40) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x48), *(int64_t *)(iVar1 + 0x40), 1);
    }
    if (*(int64_t *)(iVar1 + 0x28) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x30), *(int64_t *)(iVar1 + 0x28), 1);
    }
    iVar1 = *(int64_t *)(arg2 + 0x40);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140002c80
// Address: 0x140002c80
// Size: 43 bytes
// ============================================================
void fcn.140002c80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140002cb0
// Address: 0x140002cb0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140002cb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140002d00
// Address: 0x140002d00
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.140002d00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140002d50
// Address: 0x140002d50
// Size: 43 bytes
// ============================================================
void fcn.140002d50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140002d80
// Address: 0x140002d80
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140002d80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140002dd0
// Address: 0x140002dd0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.140002dd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140002e20
// Address: 0x140002e20
// Size: 64 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140002e20(int64_t arg1)
{
    undefined8 uVar1;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (arg1 == 0) {
        return;
    }
    func_0x00014001cb00();
    uVar1 = (*(code *)0xe5f2d8)(arg1, 0x70);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar1, 0, arg1);
    return;
}

// ============================================================
// Function: FUN_140002e60
// Address: 0x140002e60
// Size: 41 bytes
// ============================================================
void fcn.140002e60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), 0x70, 8);
    return;
}

// ============================================================
// Function: FUN_140002e90
// Address: 0x140002e90
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140002e90(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 != 0) {
        if (((*(int32_t *)arg1 == 1) && (*(int64_t *)(arg1 + 8) != 0)) &&
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 != 0)) {
            ppcVar2 = *(code ***)(arg1 + 0x18);
            if (*ppcVar2 != (code *)0x0) {
                (**ppcVar2)(iVar4);
            }
            if (ppcVar2[1] != (code *)0x0) {
                if ((code *)0x10 < ppcVar2[2]) {
                    iVar4 = *(int64_t *)(iVar4 + -8);
                }
                uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
                (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
                return;
            }
        }
        return;
    }
    // [00] -r-x section size 9928704 named .text
    // switch table (6 cases) at 0x14097a0a8
    switch(*(undefined *)(arg1 + 0x80)) {
    case 0:
        func_0x000140416640();
        piVar1 = *(int64_t **)(arg1 + 0x48);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x00014045f950();
        }
        func_0x0001402d8080();
        piVar1 = *(int64_t **)(arg1 + 0x50);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x00014045f100();
        }
        piVar1 = *(int64_t **)(arg1 + 0x40);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x00014045faf0(arg1 + 0x40);
        }
        goto code_r0x0001400011d4;
    default:
        goto code_r0x0001400011ed;
    case 3:
        if (*(char *)(arg1 + 0xd8) == '\x03') {
            func_0x0001402d7f10(arg1 + 0xa8);
            if (*(int64_t *)(arg1 + 0xb0) != 0) {
                (**(code **)(*(int64_t *)(arg1 + 0xb0) + 0x18))(*(undefined8 *)(arg1 + 0xb8));
            }
        }
        break;
    case 4:
        if ((*(int64_t *)(arg1 + 0xa0) != 6) &&
           (((int32_t)*(int64_t *)(arg1 + 0xa0) != 4 || (*(int16_t *)(arg1 + 200) != 0x12)))) {
            (**(code **)(*(int64_t *)(arg1 + 0xa8) + 0x20))
                      (arg1 + 0xc0, *(undefined8 *)(arg1 + 0xb0), *(undefined8 *)(arg1 + 0xb8));
        }
        break;
    case 5:
        if ((*(int64_t *)(arg1 + 0xa0) != 6) &&
           (((int32_t)*(int64_t *)(arg1 + 0xa0) != 4 || (*(int16_t *)(arg1 + 200) != 0x12)))) {
            (**(code **)(*(int64_t *)(arg1 + 0xa8) + 0x20))
                      (arg1 + 0xc0, *(undefined8 *)(arg1 + 0xb0), *(undefined8 *)(arg1 + 0xb8));
        }
    }
    func_0x000140416640();
    piVar1 = *(int64_t **)(arg1 + 0x48);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x00014045f950();
    }
    func_0x0001402d8080();
    piVar1 = *(int64_t **)(arg1 + 0x50);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x00014045f100();
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x00014045faf0(arg1 + 0x40);
    }
code_r0x0001400011d4:
    if ((*(int64_t *)(arg1 + 8) != 6) && (((int32_t)*(int64_t *)(arg1 + 8) != 4 || (*(int16_t *)(arg1 + 0x30) != 0x12)))
       ) {
    // WARNING: Could not recover jumptable at 0x00014000120e. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)(arg1 + 0x10) + 0x20))
                  (arg1 + 0x28, *(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20));
        return;
    }
code_r0x0001400011ed:
    return;
}

// ============================================================
// Function: FUN_140002f10
// Address: 0x140002f10
// Size: 51 bytes
// ============================================================
void fcn.140002f10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140002f50
// Address: 0x140002f50
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140002f50(int64_t arg1)
{
    code **ppcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t iVar6;
    code *pcVar7;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 != 0) {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar1 = *(code ***)(arg1 + 0x18);
        if (*ppcVar1 != (code *)0x0) {
            (**ppcVar1)(iVar4);
        }
        pcVar5 = ppcVar1[1];
        if (pcVar5 == (code *)0x0) {
            return;
        }
        pcVar7 = ppcVar1[2];
        goto code_r0x0001404d3c50;
    }
    iVar4 = arg1 + 8;
    if (*(char *)(arg1 + 0x75c) != '\x03') {
        if (*(char *)(arg1 + 0x75c) != '\0') {
            return;
        }
        goto code_r0x000140014d30;
    }
    // switch table (11 cases) at 0x14097a0c0
    switch(*(undefined *)(arg1 + 0x4c8)) {
    case 0:
        iVar4 = arg1 + 0xb0;
        goto code_r0x000140014d30;
    default:
        return;
    case 3:
        func_0x00014001d230(arg1 + 0x4d0);
        goto code_r0x0001400016f3;
    case 4:
        if (*(char *)(arg1 + 0x750) == '\x03') {
            func_0x00014001f080(arg1 + 0x568);
        } else if (*(char *)(arg1 + 0x750) == '\0') {
            func_0x00014001d7a0(arg1 + 0x4d0);
        }
        if (*(int32_t *)(arg1 + 0x228) == 3) {
            func_0x000140014c20(*(undefined8 *)(arg1 + 0x230));
        }
        goto code_r0x0001400016f3;
    case 5:
        func_0x00014001d230(arg1 + 0x4d0);
        goto code_r0x000140001644;
    case 6:
        if (*(char *)(arg1 + 0x750) == '\x03') {
            func_0x00014001f080(arg1 + 0x568);
        } else if (*(char *)(arg1 + 0x750) == '\0') {
            func_0x00014001d7a0(arg1 + 0x4d0);
        }
        if (*(int32_t *)(arg1 + 0x2c0) == 3) {
            func_0x000140014c20(*(undefined8 *)(arg1 + 0x2c8));
        }
code_r0x000140001644:
        if (*(int64_t *)(arg1 + 0x210) != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 0x218), *(int64_t *)(arg1 + 0x210), 1);
        }
        goto code_r0x0001400016f3;
    case 7:
        func_0x00014001d230(arg1 + 0x4d0);
        break;
    case 8:
        if (*(char *)(arg1 + 0x750) == '\x03') {
            func_0x00014001f080(arg1 + 0x568);
        } else if (*(char *)(arg1 + 0x750) == '\0') {
            func_0x00014001d7a0(arg1 + 0x4d0);
        }
        if (*(int32_t *)(arg1 + 0x388) == 3) {
            func_0x000140014c20(*(undefined8 *)(arg1 + 0x390));
        }
        break;
    case 9:
        func_0x00014001d230(arg1 + 0x4d0);
        break;
    case 10:
        if (*(char *)(arg1 + 0x750) == '\x03') {
            func_0x00014001f080(arg1 + 0x568);
        } else if (*(char *)(arg1 + 0x750) == '\0') {
            func_0x00014001d7a0(arg1 + 0x4d0);
        }
        if (*(int32_t *)(arg1 + 0x428) == 3) {
            func_0x000140014c20(*(undefined8 *)(arg1 + 0x430));
        }
    }
    if (*(int64_t *)(arg1 + 0x370) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x378), *(int64_t *)(arg1 + 0x370), 1);
    }
    *(undefined *)(arg1 + 0x4c9) = 0;
    if (*(int64_t *)(arg1 + 0x358) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x360), *(int64_t *)(arg1 + 0x358), 1);
    }
    *(undefined2 *)(arg1 + 0x4ca) = 0;
    *(undefined *)(arg1 + 0x4cc) = 0;
code_r0x0001400016f3:
    iVar4 = arg1 + 0x158;
code_r0x000140014d30:
    func_0x00014001eac0();
    piVar2 = *(int64_t **)(iVar4 + 0x88);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        func_0x0001406c6890(iVar4 + 0x88);
    }
    piVar2 = *(int64_t **)(iVar4 + 0x90);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 != 0) {
        return;
    }
    iVar4 = *(int64_t *)(iVar4 + 0x90);
    if (iVar4 != -1) {
        LOCK();
        piVar2 = (int64_t *)(iVar4 + 8);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            pcVar5 = (code *)0x20;
            pcVar7 = (code *)0x8;
code_r0x0001404d3c50:
            iVar6 = iVar4;
            if ((code *)0x10 < pcVar7) {
                iVar6 = *(int64_t *)(iVar4 + -8);
            }
            uVar3 = (*(code *)0xe5f2d8)(iVar4, pcVar5);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar3, 0, iVar6);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_140002fd0
// Address: 0x140002fd0
// Size: 51 bytes
// ============================================================
void fcn.140002fd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140003010
// Address: 0x140003010
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140003010(int64_t arg1)
{
    code **ppcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t iVar6;
    code *pcVar7;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x114) == '\x03') {
            func_0x00014001cb00(arg1 + 0xa0);
        } else if (*(char *)(arg1 + 0x114) != '\0') {
            return;
        }
        func_0x00014001eac0();
        piVar2 = *(int64_t **)(arg1 + 0x90);
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            func_0x0001406c6890(arg1 + 0x90);
        }
        piVar2 = *(int64_t **)(arg1 + 0x98);
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 != 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x98);
        if (iVar4 != -1) {
            LOCK();
            piVar2 = (int64_t *)(iVar4 + 8);
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (*piVar2 == 0) {
                pcVar5 = (code *)0x20;
                pcVar7 = (code *)0x8;
                goto code_r0x0001404d3c50;
            }
        }
        return;
    }
    if (((*(int32_t *)arg1 == 1) && (*(int64_t *)(arg1 + 8) != 0)) && (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 != 0)) {
        ppcVar1 = *(code ***)(arg1 + 0x18);
        if (*ppcVar1 != (code *)0x0) {
            (**ppcVar1)(iVar4);
        }
        pcVar5 = ppcVar1[1];
        if (pcVar5 != (code *)0x0) {
            pcVar7 = ppcVar1[2];
code_r0x0001404d3c50:
            iVar6 = iVar4;
            if ((code *)0x10 < pcVar7) {
                iVar6 = *(int64_t *)(iVar4 + -8);
            }
            uVar3 = (*(code *)0xe5f2d8)(iVar4, pcVar5);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar3, 0, iVar6);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1400030b0
// Address: 0x1400030b0
// Size: 30 bytes
// ============================================================
void fcn.1400030b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140014d30(*(undefined8 *)(arg2 + 0x30));
    return;
}

// ============================================================
// Function: FUN_1400030d0
// Address: 0x1400030d0
// Size: 51 bytes
// ============================================================
void fcn.1400030d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140003110
// Address: 0x140003110
// Size: 321 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140003110(int64_t arg1)
{
    char cVar1;
    code **ppcVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 in_R9;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    cVar1 = *(char *)(arg1 + 0x4c);
    if (cVar1 == '\0') {
        func_0x000140416820();
        piVar4 = *(int64_t **)(arg1 + 0x10);
        LOCK();
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (*piVar4 == 0) {
            func_0x000140682ab0();
        }
        piVar4 = *(int64_t **)(arg1 + 0x18);
        LOCK();
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (*piVar4 == 0) {
            func_0x00014045ead0(arg1 + 0x18);
        }
        goto code_r0x00014000322c;
    }
    if (cVar1 != '\x03') {
        if (cVar1 != '\x04') {
            return;
        }
        uVar6 = *(undefined8 *)(arg1 + 0x78);
        ppcVar2 = *(code ***)(arg1 + 0x80);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(uVar6);
        }
        if (ppcVar2[1] != (code *)0x0) {
            fcn.1404d3c50(uVar6, ppcVar2[1], ppcVar2[2]);
        }
        iVar5 = 0x10;
        if (*(uint32_t *)(arg1 + 0x50) < 2) {
code_r0x000140003192:
            iVar3 = *(int64_t *)(arg1 + 0x50 + iVar5);
            if (iVar3 != 0) {
                fcn.1404d3c50(*(undefined8 *)(arg1 + 0x58 + iVar5), iVar3, 1);
            }
        } else if (*(uint32_t *)(arg1 + 0x50) == 2) {
            iVar5 = 8;
            goto code_r0x000140003192;
        }
        *(undefined *)(arg1 + 0x4d) = 0;
    }
    func_0x000140416820();
    piVar4 = *(int64_t **)(arg1 + 0x10);
    LOCK();
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (*piVar4 == 0) {
        func_0x000140682ab0();
    }
    piVar4 = *(int64_t **)(arg1 + 0x18);
    LOCK();
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (*piVar4 == 0) {
        func_0x00014045ead0(arg1 + 0x18);
    }
code_r0x00014000322c:
    piVar4 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (*piVar4 != 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    func_0x0001406e9970(iVar5 + 0x10);
    uVar6 = *(undefined8 *)(iVar5 + 0x10);
    ppcVar2 = *(code ***)(iVar5 + 0x18);
    if (*ppcVar2 != (code *)0x0) {
        (**ppcVar2)(uVar6);
    }
    if (ppcVar2[1] != (code *)0x0) {
        fcn.1404d3c50(uVar6, ppcVar2[1], ppcVar2[2]);
    }
    iVar3 = *(int64_t *)(iVar5 + 0x20);
    if (iVar3 != 0) {
        ppcVar2 = *(code ***)(iVar5 + 0x28);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar3);
        }
        if (ppcVar2[1] != (code *)0x0) {
            fcn.1404d3c50(iVar3, ppcVar2[1], ppcVar2[2]);
        }
    }
    if (iVar5 != -1) {
        LOCK();
        piVar4 = (int64_t *)(iVar5 + 8);
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (*piVar4 == 0) {
            uVar6 = (*(code *)0xe5f2d8)(iVar5, 0x38, 8, in_R9, 0xfffffffffffffffe, unaff_RSI, unaff_RBP);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar6, 0, iVar5);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_140003260
// Address: 0x140003260
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003260(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    iVar1 = *(int64_t *)(arg2 + 0x38);
    func_0x00014001dc30(iVar1 + 0x50);
    *(undefined *)(iVar1 + 0x4d) = 0;
    func_0x0001400018f0(iVar1 + 0x10);
    piVar2 = *(int64_t **)(iVar1 + 0x18);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        func_0x00014045ead0(*(int64_t *)(arg2 + 0x38) + 0x18);
        piVar2 = *(int64_t **)(*(int64_t *)(arg2 + 0x38) + 0x20);
        LOCK();
        *piVar2 = *piVar2 + -1;
        iVar1 = *piVar2;
        UNLOCK();
    } else {
        piVar2 = *(int64_t **)(*(int64_t *)(arg2 + 0x38) + 0x20);
        LOCK();
        *piVar2 = *piVar2 + -1;
        iVar1 = *piVar2;
        UNLOCK();
    }
    if (iVar1 == 0) {
        func_0x00014045f450(*(int64_t *)(arg2 + 0x38) + 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_140003300
// Address: 0x140003300
// Size: 45 bytes
// ============================================================
void fcn.140003300(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x30);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.140682ab0(*(undefined8 *)(arg2 + 0x30));
    }
    return;
}

// ============================================================
// Function: FUN_140003330
// Address: 0x140003330
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003330(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg2 + 0x38) + 0x18);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045ead0(*(int64_t *)(arg2 + 0x38) + 0x18);
    }
    return;
}

// ============================================================
// Function: FUN_140003370
// Address: 0x140003370
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003370(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg2 + 0x38) + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f450(*(int64_t *)(arg2 + 0x38) + 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_1400033b0
// Address: 0x1400033b0
// Size: 45 bytes
// ============================================================
void fcn.1400033b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x30);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.140682ab0(*(undefined8 *)(arg2 + 0x30));
    }
    return;
}

// ============================================================
// Function: FUN_1400033e0
// Address: 0x1400033e0
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400033e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg2 + 0x38) + 0x18);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045ead0(*(int64_t *)(arg2 + 0x38) + 0x18);
    }
    return;
}

// ============================================================
// Function: FUN_140003420
// Address: 0x140003420
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003420(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg2 + 0x38) + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f450(*(int64_t *)(arg2 + 0x38) + 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_140003460
// Address: 0x140003460
// Size: 100 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001400034b0: Changing call to branch
// WARNING: Possible PIC construction at 0x00014001eb34: Changing call to branch
// WARNING: Possible PIC construction at 0x00014001eb6a: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140003460(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t iVar7;
    undefined8 auStack_50 [2];
    undefined8 auStack_40 [4];
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    int64_t *piVar6;
    
    piVar1 = &var_18h;
    var_18h = -2;
    var_10h = unaff_RSI;
    var_8h = unaff_RBP;
    if (*(int64_t *)(arg1 + 0x98) != 0) {
        auStack_50[0] = 0x140003494;
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0xa0), *(int64_t *)(arg1 + 0x98), 1);
    }
    iVar7 = var_10h;
    piVar4 = *(int64_t **)(arg1 + 0x88);
    LOCK();
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    var_20h = arg1;
    if (*piVar4 == 0) {
        piVar4 = (int64_t *)(arg1 + 0x88);
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
        auStack_50[0] = 0x1400034b5;
        var_8h = (int64_t)piVar1;
        iVar7 = arg1;
    } else {
        piVar5 = &var_8h;
        piVar6 = &var_8h;
        var_10h = -2;
        piVar1 = *(int64_t **)(arg1 + 0x18);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        var_18h = arg1;
        if (*piVar1 == 0) {
            auStack_40[0] = 0x14001eaed;
            func_0x0001406c6790(arg1 + 0x18);
        }
        auStack_40[0] = 0x14001eaf6;
        func_0x0001402c5910(var_18h);
        auStack_40[0] = 0x14001eb03;
        func_0x00014001f200(var_18h + 0x28);
        piVar1 = *(int64_t **)(var_18h + 0x58);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            auStack_40[0] = 0x14001eb1e;
            func_0x0001406c7890(var_18h + 0x58);
        }
        piVar1 = *(int64_t **)(var_18h + 0x60);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            piVar4 = (int64_t *)(var_18h + 0x60);
            *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_40;
            auStack_40[0] = 0x14001eb39;
            var_8h = (int64_t)piVar5;
        } else {
            piVar1 = *(int64_t **)(var_18h + 0x68);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                auStack_40[0] = 0x14001eb54;
                func_0x00014045ec00(var_18h + 0x68);
            }
            piVar1 = *(int64_t **)(var_18h + 0x70);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                piVar4 = (int64_t *)(var_18h + 0x70);
                *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_40;
                auStack_40[0] = 0x14001eb6f;
                var_8h = (int64_t)piVar6;
            } else {
                piVar1 = *(int64_t **)(var_18h + 0x78);
                LOCK();
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (*piVar1 != 0) {
                    return;
                }
                piVar4 = (int64_t *)(var_18h + 0x78);
            }
        }
    }
    iVar2 = *piVar4;
    if (iVar2 != -1) {
        LOCK();
        piVar1 = (int64_t *)(iVar2 + 8);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            *(int64_t *)((int64_t)*(undefined **)0x20 + -8) = var_8h;
            *(int64_t *)((int64_t)*(undefined **)0x20 + -0x10) = iVar7;
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140901d3e;
            uVar3 = (*(code *)0xe5f2d8)(iVar2, 0x18);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar3, 0, iVar2);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1400034d0
// Address: 0x1400034d0
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400034d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001eac0(*(undefined8 *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_1400034f0
// Address: 0x1400034f0
// Size: 229 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.1400034f0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t var_30h;
    int64_t var_28h;
    
    func_0x000140231300();
    func_0x00014001edb0(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20));
    func_0x00014001dc60(arg1);
    piVar1 = *(int64_t **)(arg1 + 0x28);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x00014045e760(arg1 + 0x28);
    }
    piVar1 = *(int64_t **)(arg1 + 0x30);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x00014045e760(arg1 + 0x30);
    }
    iVar2 = *(int64_t *)(arg1 + 0x38);
    uVar4 = iVar2 >> 0x3f & iVar2 + 0x8000000000000001U;
    if (uVar4 == 0) {
        iVar6 = 0x1000;
        iVar7 = 0x20;
        if (iVar2 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 0x40), iVar2, 1);
        }
code_r0x0001400035ba:
        uVar3 = *(undefined8 *)(arg1 + 0x38 + iVar7);
        uVar5 = (*(code *)0xe5f2d8)(uVar3, iVar6);
    // WARNING: Treating indirect jump as call
        (*(code *)0xe5f2ea)(uVar5, 0, uVar3);
        return;
    }
    if (uVar4 == 1) {
        iVar6 = *(int64_t *)(arg1 + 0x40);
        iVar7 = 0x10;
        if (iVar6 != 0) goto code_r0x0001400035ba;
    }
    return;
}

// ============================================================
// Function: FUN_1400035e0
// Address: 0x1400035e0
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400035e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    piVar2 = *(int64_t **)(iVar1 + 0x28);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.14045e760(iVar1 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140003620
// Address: 0x140003620
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003620(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    piVar2 = *(int64_t **)(iVar1 + 0x30);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.14045e760(iVar1 + 0x30);
    }
    return;
}

// ============================================================
// Function: FUN_140003660
// Address: 0x140003660
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003660(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001dd20(*(int64_t *)(arg2 + 0x28) + 0x38);
    return;
}

// ============================================================
// Function: FUN_140003690
// Address: 0x140003690
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003690(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001edb0(*(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x18), *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x20));
    return;
}

// ============================================================
// Function: FUN_1400036c0
// Address: 0x1400036c0
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400036c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001dc60(*(undefined8 *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_1400036f0
// Address: 0x1400036f0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1400036f0(int64_t arg1)
{
    char cVar1;
    int64_t *piVar2;
    code **ppcVar3;
    int64_t iVar4;
    undefined8 uVar5;
    code *pcVar6;
    int64_t iVar7;
    code *pcVar8;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 != 0) {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar3 = *(code ***)(arg1 + 0x18);
        if (*ppcVar3 != (code *)0x0) {
            (**ppcVar3)(iVar4);
        }
        pcVar6 = ppcVar3[1];
        if (pcVar6 == (code *)0x0) {
            return;
        }
        pcVar8 = ppcVar3[2];
        goto code_r0x0001404d3c50;
    }
    cVar1 = *(char *)(arg1 + 0x54);
    if (cVar1 == '\0') {
        func_0x000140416820();
        piVar2 = *(int64_t **)(arg1 + 0x18);
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.140682ab0();
        }
        piVar2 = *(int64_t **)(arg1 + 0x20);
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045ead0(arg1 + 0x20);
        }
    } else {
        if (cVar1 != '\x03') {
            if (cVar1 != '\x04') {
                return;
            }
            uVar5 = *(undefined8 *)(arg1 + 0x80);
            ppcVar3 = *(code ***)(arg1 + 0x88);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(uVar5);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(uVar5, ppcVar3[1], ppcVar3[2]);
            }
            iVar4 = 0x10;
            if (*(uint32_t *)(arg1 + 0x58) < 2) {
code_r0x000140003192:
                iVar7 = *(int64_t *)(arg1 + 0x58 + iVar4);
                if (iVar7 != 0) {
                    fcn.1404d3c50(*(undefined8 *)(arg1 + 0x60 + iVar4), iVar7, 1);
                }
            } else if (*(uint32_t *)(arg1 + 0x58) == 2) {
                iVar4 = 8;
                goto code_r0x000140003192;
            }
            *(undefined *)(arg1 + 0x55) = 0;
        }
        func_0x000140416820();
        piVar2 = *(int64_t **)(arg1 + 0x18);
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.140682ab0();
        }
        piVar2 = *(int64_t **)(arg1 + 0x20);
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045ead0(arg1 + 0x20);
        }
    }
    piVar2 = *(int64_t **)(arg1 + 0x28);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 != 0) {
        return;
    }
    iVar4 = *(int64_t *)(arg1 + 0x28);
    func_0x0001406e9970(iVar4 + 0x10);
    uVar5 = *(undefined8 *)(iVar4 + 0x10);
    ppcVar3 = *(code ***)(iVar4 + 0x18);
    if (*ppcVar3 != (code *)0x0) {
        (**ppcVar3)(uVar5);
    }
    if (ppcVar3[1] != (code *)0x0) {
        fcn.1404d3c50(uVar5, ppcVar3[1], ppcVar3[2]);
    }
    iVar7 = *(int64_t *)(iVar4 + 0x20);
    if (iVar7 != 0) {
        ppcVar3 = *(code ***)(iVar4 + 0x28);
        if (*ppcVar3 != (code *)0x0) {
            (**ppcVar3)(iVar7);
        }
        if (ppcVar3[1] != (code *)0x0) {
            fcn.1404d3c50(iVar7, ppcVar3[1], ppcVar3[2]);
        }
    }
    if (iVar4 != -1) {
        LOCK();
        piVar2 = (int64_t *)(iVar4 + 8);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            pcVar6 = (code *)0x38;
            pcVar8 = (code *)0x8;
code_r0x0001404d3c50:
            iVar7 = iVar4;
            if ((code *)0x10 < pcVar8) {
                iVar7 = *(int64_t *)(iVar4 + -8);
            }
            uVar5 = (*(code *)0xe5f2d8)(iVar4, pcVar6);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar5, 0, iVar7);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_140003770
// Address: 0x140003770
// Size: 51 bytes
// ============================================================
void fcn.140003770(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400037b0
// Address: 0x1400037b0
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400037b0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x38);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x00014045faf0(arg1 + 0x38);
    }
    if ((*(int64_t *)arg1 != 6) && (((int32_t)*(int64_t *)arg1 != 4 || (*(int16_t *)(arg1 + 0x28) != 0x12)))) {
    // WARNING: Could not recover jumptable at 0x000140003815. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)(arg1 + 8) + 0x20))
                  (arg1 + 0x20, *(undefined8 *)(arg1 + 0x10), *(undefined8 *)(arg1 + 0x18));
        return;
    }
    return;
}

// ============================================================
// Function: FUN_140003820
// Address: 0x140003820
// Size: 30 bytes
// ============================================================
void fcn.140003820(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001f030(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_140003840
// Address: 0x140003840
// Size: 395 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140003840(int64_t arg1)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x408) == '\0') {
        fcn.14001c990();
        iVar3 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar4 = *(int64_t *)(arg1 + 0x210);
        while (iVar3 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar4);
            iVar4 = iVar4 + 0x60;
        }
        goto code_r0x00014000398f;
    }
    if (*(char *)(arg1 + 0x408) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x400) == '\0') {
        if (*(char *)(arg1 + 0x359) == '\0') {
            iVar3 = arg1 + 0x2c0;
            goto code_r0x000140003927;
        }
    } else if ((*(char *)(arg1 + 0x400) == '\x03') && (*(char *)(arg1 + 0x3f9) == '\0')) {
        iVar3 = arg1 + 0x360;
code_r0x000140003927:
        fcn.140014d30(iVar3);
    }
    fcn.14001c990(arg1);
    iVar3 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar4 = *(int64_t *)(arg1 + 0x210);
    while (iVar3 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar4);
        iVar4 = iVar4 + 0x60;
    }
code_r0x00014000398f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar2 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_1400039d0
// Address: 0x1400039d0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400039d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

