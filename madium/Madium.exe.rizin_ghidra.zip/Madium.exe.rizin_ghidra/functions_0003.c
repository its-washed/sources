// Chunk 3 - 50 functions

// ============================================================
// Function: FUN_140003a00
// Address: 0x140003a00
// Size: 67 bytes
// ============================================================
void fcn.140003a00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140003a50
// Address: 0x140003a50
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003a50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140003aa0
// Address: 0x140003aa0
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003aa0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140003ae0
// Address: 0x140003ae0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003ae0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140003b10
// Address: 0x140003b10
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140003b10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140003b60
// Address: 0x140003b60
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003b60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140003bb0
// Address: 0x140003bb0
// Size: 395 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140003bb0(int64_t arg1)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x408) == '\0') {
        fcn.14001c990();
        iVar3 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar4 = *(int64_t *)(arg1 + 0x210);
        while (iVar3 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar4);
            iVar4 = iVar4 + 0x60;
        }
        goto code_r0x000140003cff;
    }
    if (*(char *)(arg1 + 0x408) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x400) == '\0') {
        if (*(char *)(arg1 + 0x358) == '\0') {
            iVar3 = arg1 + 0x2c0;
            goto code_r0x000140003c97;
        }
    } else if ((*(char *)(arg1 + 0x400) == '\x03') && (*(char *)(arg1 + 0x3f8) == '\0')) {
        iVar3 = arg1 + 0x360;
code_r0x000140003c97:
        func_0x000140014d30(iVar3);
    }
    fcn.14001c990(arg1);
    iVar3 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar4 = *(int64_t *)(arg1 + 0x210);
    while (iVar3 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar4);
        iVar4 = iVar4 + 0x60;
    }
code_r0x000140003cff:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar2 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140003d40
// Address: 0x140003d40
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003d40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140003d70
// Address: 0x140003d70
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140003d70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140003dc0
// Address: 0x140003dc0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003dc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140003e10
// Address: 0x140003e10
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003e10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140003e50
// Address: 0x140003e50
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003e50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140003e80
// Address: 0x140003e80
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140003e80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140003ed0
// Address: 0x140003ed0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140003ed0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140003f20
// Address: 0x140003f20
// Size: 395 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140003f20(int64_t arg1)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x438) == '\0') {
        fcn.14001c990();
        iVar3 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar4 = *(int64_t *)(arg1 + 0x210);
        while (iVar3 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar4);
            iVar4 = iVar4 + 0x60;
        }
        goto code_r0x00014000406f;
    }
    if (*(char *)(arg1 + 0x438) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x430) == '\0') {
        if (*(char *)(arg1 + 0x378) == '\0') {
            iVar3 = arg1 + 0x2d0;
            goto code_r0x000140004007;
        }
    } else if ((*(char *)(arg1 + 0x430) == '\x03') && (*(char *)(arg1 + 0x428) == '\0')) {
        iVar3 = arg1 + 0x380;
code_r0x000140004007:
        func_0x000140014d30(iVar3);
    }
    fcn.14001c990(arg1);
    iVar3 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar4 = *(int64_t *)(arg1 + 0x210);
    while (iVar3 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar4);
        iVar4 = iVar4 + 0x60;
    }
code_r0x00014000406f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar2 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_1400040b0
// Address: 0x1400040b0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400040b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400040e0
// Address: 0x1400040e0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400040e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140004130
// Address: 0x140004130
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004130(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140004180
// Address: 0x140004180
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004180(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400041c0
// Address: 0x1400041c0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400041c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400041f0
// Address: 0x1400041f0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400041f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140004240
// Address: 0x140004240
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004240(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140004290
// Address: 0x140004290
// Size: 427 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140004290(int64_t arg1)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x8e8) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar3 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar3);
            iVar3 = iVar3 + 0x60;
        }
        goto code_r0x0001400043ff;
    }
    if (*(char *)(arg1 + 0x8e8) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x8e0) == '\0') {
        if (*(char *)(arg1 + 0x698) == '\0') {
            iVar4 = 0x678;
            func_0x000140014e50(arg1 + 0x460);
            goto code_r0x00014000437d;
        }
    } else if ((*(char *)(arg1 + 0x8e0) == '\x03') && (*(char *)(arg1 + 0x8d8) == '\0')) {
        iVar4 = 0x8b8;
        func_0x000140014e50(arg1 + 0x6a0);
code_r0x00014000437d:
        if (*(int64_t *)(arg1 + iVar4) != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar4), *(int64_t *)(arg1 + iVar4), 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar3 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar3);
        iVar3 = iVar3 + 0x60;
    }
code_r0x0001400043ff:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar2 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140004440
// Address: 0x140004440
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004440(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x48) + 0x678);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x680), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140004490
// Address: 0x140004490
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004490(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x48) + 0x8b8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x8c0), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_1400044e0
// Address: 0x1400044e0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400044e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140004510
// Address: 0x140004510
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140004510(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140004560
// Address: 0x140004560
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004560(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_1400045b0
// Address: 0x1400045b0
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400045b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400045f0
// Address: 0x1400045f0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400045f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140004620
// Address: 0x140004620
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140004620(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140004670
// Address: 0x140004670
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004670(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_1400046c0
// Address: 0x1400046c0
// Size: 955 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.1400046c0(int64_t arg1)
{
    char cVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t **ppiVar7;
    undefined8 *puVar8;
    undefined8 uVar9;
    bool bVar10;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0xb40) == '\0') {
        fcn.14001c990();
        iVar3 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar6 = *(int64_t *)(arg1 + 0x210);
        while (iVar3 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar6);
            iVar6 = iVar6 + 0x60;
        }
        goto code_r0x000140004a3f;
    }
    if (*(char *)(arg1 + 0xb40) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0xb38) == '\x03') {
        iVar3 = arg1 + 0x830;
        cVar1 = *(char *)(arg1 + 0xb30);
joined_r0x0001400047a1:
        if (cVar1 == '\0') {
            func_0x000140014e50();
            if (*(int64_t *)(iVar3 + 0x238) != 0) {
                fcn.1404d3c50(*(undefined8 *)(iVar3 + 0x240), *(int64_t *)(iVar3 + 0x238), 1);
            }
            if (*(int64_t *)(iVar3 + 0x218) != 0) {
                if ((int32_t)*(int64_t *)(iVar3 + 0x218) == 1) {
                    iVar6 = *(int64_t *)(iVar3 + 0x220);
                    if (iVar6 != 0) {
                        uVar4 = *(undefined8 *)(iVar3 + 0x228);
                        uVar9 = 1;
code_r0x000140004863:
                        fcn.1404d3c50(uVar4, iVar6, uVar9);
                    }
                } else {
                    iVar6 = *(int64_t *)(iVar3 + 0x230);
                    if (iVar6 != 0) {
                        puVar8 = (undefined8 *)(*(int64_t *)(iVar3 + 0x228) + 8);
                        do {
                            if (puVar8[-1] != 0) {
                                fcn.1404d3c50(*puVar8, puVar8[-1], 1);
                            }
                            puVar8 = puVar8 + 3;
                            iVar6 = iVar6 + -1;
                        } while (iVar6 != 0);
                    }
                    if (*(int64_t *)(iVar3 + 0x220) != 0) {
                        uVar4 = *(undefined8 *)(iVar3 + 0x228);
                        iVar6 = *(int64_t *)(iVar3 + 0x220) * 0x18;
                        uVar9 = 8;
                        goto code_r0x000140004863;
                    }
                }
            }
            func_0x00014001db70(iVar3 + 0x280);
            iVar6 = *(int64_t *)(iVar3 + 0x260);
            if (iVar6 != 0) {
                ppiVar7 = *(int64_t ***)(iVar3 + 600);
                iVar5 = 1;
                do {
                    piVar2 = *ppiVar7;
                    LOCK();
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (*piVar2 == 0) {
                        func_0x00014045f3c0(ppiVar7);
                    }
                    ppiVar7 = ppiVar7 + 1;
                    bVar10 = iVar5 != iVar6;
                    iVar5 = iVar5 + 1;
                } while (bVar10);
            }
            if (*(int64_t *)(iVar3 + 0x250) != 0) {
                fcn.1404d3c50(*(undefined8 *)(iVar3 + 600), *(int64_t *)(iVar3 + 0x250) << 3, 8);
            }
            iVar6 = *(int64_t *)(iVar3 + 0x278);
            if (iVar6 != 0) {
                ppiVar7 = *(int64_t ***)(iVar3 + 0x270);
                iVar5 = 1;
                do {
                    piVar2 = *ppiVar7;
                    LOCK();
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (*piVar2 == 0) {
                        func_0x00014045f3c0(ppiVar7);
                    }
                    ppiVar7 = ppiVar7 + 1;
                    bVar10 = iVar5 != iVar6;
                    iVar5 = iVar5 + 1;
                } while (bVar10);
            }
            if (*(int64_t *)(iVar3 + 0x268) != 0) {
                fcn.1404d3c50(*(undefined8 *)(iVar3 + 0x270), *(int64_t *)(iVar3 + 0x268) << 3, 8);
            }
            piVar2 = *(int64_t **)(iVar3 + 0x2f0);
            LOCK();
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (*piVar2 == 0) {
                func_0x00014045e930(iVar3 + 0x2f0);
            }
            piVar2 = *(int64_t **)(iVar3 + 0x2f8);
            LOCK();
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (*piVar2 == 0) {
                func_0x00014045e930(iVar3 + 0x2f8);
            }
        }
    } else if (*(char *)(arg1 + 0xb38) == '\0') {
        iVar3 = arg1 + 0x528;
        cVar1 = *(char *)(arg1 + 0x828);
        goto joined_r0x0001400047a1;
    }
    fcn.14001c990(arg1);
    iVar3 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar6 = *(int64_t *)(arg1 + 0x210);
    while (iVar3 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar6);
        iVar6 = iVar6 + 0x60;
    }
code_r0x000140004a3f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar4 = *(undefined8 *)(arg1 + 0x210);
    uVar9 = (*(code *)0xe5f2d8)(uVar4, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar9, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140004a80
// Address: 0x140004a80
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004a80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x48) + 0x238);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x240), iVar1, 1);
    }
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001d6f0(iVar1 + 0x218);
    fcn.14001db70(iVar1 + 0x280);
    return;
}

// ============================================================
// Function: FUN_140004ae0
// Address: 0x140004ae0
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.140004ae0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar4 = *(int64_t *)(arg2 + 0x40); iVar4 != iVar1; iVar4 = iVar4 + 1) {
        piVar3 = *(int64_t **)(iVar2 + iVar4 * 8);
        LOCK();
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (*piVar3 == 0) {
            fcn.14045f3c0(iVar2 + iVar4 * 8);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140004b30
// Address: 0x140004b30
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004b30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x48) + 0x250);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 600), iVar1 << 3, 8);
    }
    fcn.140001da0(*(int64_t *)(arg2 + 0x48) + 0x268);
    return;
}

// ============================================================
// Function: FUN_140004b90
// Address: 0x140004b90
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.140004b90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar4 = *(int64_t *)(arg2 + 0x40); iVar4 != iVar1; iVar4 = iVar4 + 1) {
        piVar3 = *(int64_t **)(iVar2 + iVar4 * 8);
        LOCK();
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (*piVar3 == 0) {
            fcn.14045f3c0(iVar2 + iVar4 * 8);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140004be0
// Address: 0x140004be0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004be0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x48) + 0x268);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x270), iVar1 << 3, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140004c30
// Address: 0x140004c30
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004c30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001960(*(int64_t *)(arg2 + 0x48) + 0x2f0);
    return;
}

// ============================================================
// Function: FUN_140004c60
// Address: 0x140004c60
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004c60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg2 + 0x48) + 0x2f8);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045e930(*(int64_t *)(arg2 + 0x48) + 0x2f8);
    }
    return;
}

// ============================================================
// Function: FUN_140004ca0
// Address: 0x140004ca0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140004ca0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_18h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x38) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140004cd0
// Address: 0x140004cd0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004cd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140004d20
// Address: 0x140004d20
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140004d20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x38) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140004d70
// Address: 0x140004d70
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140004d70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140004db0
// Address: 0x140004db0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140004db0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_18h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x38) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140004de0
// Address: 0x140004de0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004de0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140004e30
// Address: 0x140004e30
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140004e30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x38) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140004e80
// Address: 0x140004e80
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140004e80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.1400019e0(*(int64_t *)(arg2 + 0x48) + 0x250);
    return;
}

// ============================================================
// Function: FUN_140004eb0
// Address: 0x140004eb0
// Size: 459 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140004eb0(int64_t arg1)
{
    int64_t iVar1;
    char cVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0xd08) == '\0') {
        fcn.14001c990();
        iVar1 = *(int64_t *)(arg1 + 0x218);
        var_30h = 0;
        iVar5 = *(int64_t *)(arg1 + 0x210);
        while (iVar1 != var_30h) {
            var_30h = var_30h + 1;
            func_0x0001402727a0(iVar5);
            iVar5 = iVar5 + 0x60;
        }
        goto code_r0x00014000503f;
    }
    if (*(char *)(arg1 + 0xd08) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0xd00) == '\x03') {
        iVar1 = arg1 + 0x960;
        cVar2 = *(char *)(arg1 + 0xcfc);
joined_r0x000140004f91:
        if (cVar2 == '\0') {
            func_0x00014001be30(iVar1);
            func_0x000140014e50(iVar1 + 0x168);
            if (*(int64_t *)(iVar1 + 0x380) != 0) {
                fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x388), *(int64_t *)(iVar1 + 0x380), 1);
            }
        }
    } else if (*(char *)(arg1 + 0xd00) == '\0') {
        iVar1 = arg1 + 0x5c0;
        cVar2 = *(char *)(arg1 + 0x95c);
        goto joined_r0x000140004f91;
    }
    fcn.14001c990(arg1);
    iVar1 = *(int64_t *)(arg1 + 0x218);
    var_30h = 0;
    iVar5 = *(int64_t *)(arg1 + 0x210);
    while (iVar1 != var_30h) {
        var_30h = var_30h + 1;
        func_0x0001402727a0(iVar5);
        iVar5 = iVar5 + 0x60;
    }
code_r0x00014000503f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar3 = *(undefined8 *)(arg1 + 0x210);
    uVar4 = (*(code *)0xe5f2d8)(uVar3, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar4, 0, uVar3);
    return;
}

// ============================================================
// Function: FUN_140005080
// Address: 0x140005080
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005080(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140014e50(*(int64_t *)(arg2 + 0x48) + 0x168);
    return;
}

