// Chunk 35 - 50 functions

// ============================================================
// Function: FUN_140029210
// Address: 0x140029210
// Size: 24 bytes
// ============================================================
void fcn.140029210(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029230
// Address: 0x140029230
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.140029230(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_f70h;
    int64_t var_f18h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_f70h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011e960(var_40h + 0x20, &var_f70h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xf60, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x0001400175d0(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140029320
// Address: 0x140029320
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.140029320(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xf80));
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x1400292c4;
}

// ============================================================
// Function: FUN_140029360
// Address: 0x140029360
// Size: 24 bytes
// ============================================================
void fcn.140029360(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029380
// Address: 0x140029380
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.140029380(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x1400292c4;
}

// ============================================================
// Function: FUN_1400293c0
// Address: 0x1400293c0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel

void fcn.1400293c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xf68) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf60), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xf68) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140029410
// Address: 0x140029410
// Size: 24 bytes
// ============================================================
void fcn.140029410(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029430
// Address: 0x140029430
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e7h because it doesn't fit into ProtoModel

void fcn.140029430(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002943c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x000013e8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x000013c8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002945e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x000013e7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029484;
        func_0x00014011e7f0(*(int64_t *)(&stack0x000013c8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x000013e7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400294a4;
        func_0x000140796b10(*(int64_t *)(&stack0x000013c8 + iVar4) + 0x13e0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x000013c8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400294b3;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400294bf;
        func_0x000140019af0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140029530
// Address: 0x140029530
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel

undefined8 fcn.140029530(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1400));
    *(undefined8 *)(arg2 + 0x13e0) = uVar1;
    *(int64_t *)(arg2 + 0x13e8) = iVar2;
    return 0x1400294ca;
}

// ============================================================
// Function: FUN_140029570
// Address: 0x140029570
// Size: 24 bytes
// ============================================================
void fcn.140029570(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029590
// Address: 0x140029590
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel

undefined8 fcn.140029590(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x13e0) = uVar1;
    *(int64_t *)(arg2 + 0x13e8) = iVar2;
    return 0x1400294ca;
}

// ============================================================
// Function: FUN_1400295d0
// Address: 0x1400295d0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel

void fcn.1400295d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x13e8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x13e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x13e8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140029620
// Address: 0x140029620
// Size: 24 bytes
// ============================================================
void fcn.140029620(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029640
// Address: 0x140029640
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.140029640(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_a00h;
    int64_t var_9a8h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_a00h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011dd00(var_40h + 0x20, &var_a00h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0x9f0, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x0001400141d0(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140029730
// Address: 0x140029730
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_990h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel

undefined8 fcn.140029730(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xa10));
    *(undefined8 *)(arg2 + 0x9f0) = uVar1;
    *(int64_t *)(arg2 + 0x9f8) = iVar2;
    return 0x1400296d4;
}

// ============================================================
// Function: FUN_140029770
// Address: 0x140029770
// Size: 24 bytes
// ============================================================
void fcn.140029770(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029790
// Address: 0x140029790
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel

undefined8 fcn.140029790(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x9f0) = uVar1;
    *(int64_t *)(arg2 + 0x9f8) = iVar2;
    return 0x1400296d4;
}

// ============================================================
// Function: FUN_1400297d0
// Address: 0x1400297d0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel

void fcn.1400297d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x9f8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x9f0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x9f8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140029820
// Address: 0x140029820
// Size: 24 bytes
// ============================================================
void fcn.140029820(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029840
// Address: 0x140029840
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff7h because it doesn't fit into ProtoModel

void fcn.140029840(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002984c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00000ff8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00000fd8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002986e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00000ff7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029894;
        func_0x00014011e680(*(int64_t *)(&stack0x00000fd8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00000ff7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400298b4;
        func_0x000140796b10(*(int64_t *)(&stack0x00000fd8 + iVar4) + 0xff0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00000fd8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400298c3;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400298cf;
        func_0x00014001b1a0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140029940
// Address: 0x140029940
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel

undefined8 fcn.140029940(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1010));
    *(undefined8 *)(arg2 + 0xff0) = uVar1;
    *(int64_t *)(arg2 + 0xff8) = iVar2;
    return 0x1400298da;
}

// ============================================================
// Function: FUN_140029980
// Address: 0x140029980
// Size: 24 bytes
// ============================================================
void fcn.140029980(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400299a0
// Address: 0x1400299a0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel

undefined8 fcn.1400299a0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xff0) = uVar1;
    *(int64_t *)(arg2 + 0xff8) = iVar2;
    return 0x1400298da;
}

// ============================================================
// Function: FUN_1400299e0
// Address: 0x1400299e0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel

void fcn.1400299e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xff8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xff0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xff8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140029a30
// Address: 0x140029a30
// Size: 24 bytes
// ============================================================
void fcn.140029a30(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029a50
// Address: 0x140029a50
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e7h because it doesn't fit into ProtoModel

void fcn.140029a50(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x140029a5c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x000013e8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x000013c8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029a7e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x000013e7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029aa4;
        func_0x00014011f7c0(*(int64_t *)(&stack0x000013c8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x000013e7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029ac4;
        func_0x000140796b10(*(int64_t *)(&stack0x000013c8 + iVar4) + 0x13e0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x000013c8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029ad3;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029adf;
        func_0x000140016970(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140029b50
// Address: 0x140029b50
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel

undefined8 fcn.140029b50(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1400));
    *(undefined8 *)(arg2 + 0x13e0) = uVar1;
    *(int64_t *)(arg2 + 0x13e8) = iVar2;
    return 0x140029aea;
}

// ============================================================
// Function: FUN_140029b90
// Address: 0x140029b90
// Size: 24 bytes
// ============================================================
void fcn.140029b90(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029bb0
// Address: 0x140029bb0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel

undefined8 fcn.140029bb0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x13e0) = uVar1;
    *(int64_t *)(arg2 + 0x13e8) = iVar2;
    return 0x140029aea;
}

// ============================================================
// Function: FUN_140029bf0
// Address: 0x140029bf0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel

void fcn.140029bf0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x13e8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x13e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x13e8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140029c40
// Address: 0x140029c40
// Size: 24 bytes
// ============================================================
void fcn.140029c40(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029c60
// Address: 0x140029c60
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_18f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f7h because it doesn't fit into ProtoModel

void fcn.140029c60(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x140029c6c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x000018f8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x000018d8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029c8e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x000018f7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029cb4;
        func_0x00014011ead0(*(int64_t *)(&stack0x000018d8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x000018f7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029cd4;
        func_0x000140796b10(*(int64_t *)(&stack0x000018d8 + iVar4) + 0x18f0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x000018d8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029ce3;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029cef;
        func_0x000140019d00(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140029d60
// Address: 0x140029d60
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1890h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1870h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1878h because it doesn't fit into ProtoModel

undefined8 fcn.140029d60(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1910));
    *(undefined8 *)(arg2 + 0x18f0) = uVar1;
    *(int64_t *)(arg2 + 0x18f8) = iVar2;
    return 0x140029cfa;
}

// ============================================================
// Function: FUN_140029da0
// Address: 0x140029da0
// Size: 24 bytes
// ============================================================
void fcn.140029da0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029dc0
// Address: 0x140029dc0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1870h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1878h because it doesn't fit into ProtoModel

undefined8 fcn.140029dc0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x18f0) = uVar1;
    *(int64_t *)(arg2 + 0x18f8) = iVar2;
    return 0x140029cfa;
}

// ============================================================
// Function: FUN_140029e00
// Address: 0x140029e00
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1878h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1870h because it doesn't fit into ProtoModel

void fcn.140029e00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x18f8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x18f0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x18f8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140029e50
// Address: 0x140029e50
// Size: 24 bytes
// ============================================================
void fcn.140029e50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029e70
// Address: 0x140029e70
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1868h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1867h because it doesn't fit into ProtoModel

void fcn.140029e70(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x140029e7c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001868 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001848 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029e9e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001867)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029ec4;
        func_0x000140120420(*(int64_t *)(&stack0x00001848 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001867)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029ee4;
        func_0x000140796b10(*(int64_t *)(&stack0x00001848 + iVar4) + 0x1860, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001848 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029ef3;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140029eff;
        func_0x000140018440(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140029f70
// Address: 0x140029f70
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1800h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e8h because it doesn't fit into ProtoModel

undefined8 fcn.140029f70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1880));
    *(undefined8 *)(arg2 + 0x1860) = uVar1;
    *(int64_t *)(arg2 + 0x1868) = iVar2;
    return 0x140029f0a;
}

// ============================================================
// Function: FUN_140029fb0
// Address: 0x140029fb0
// Size: 24 bytes
// ============================================================
void fcn.140029fb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140029fd0
// Address: 0x140029fd0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e8h because it doesn't fit into ProtoModel

undefined8 fcn.140029fd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1860) = uVar1;
    *(int64_t *)(arg2 + 0x1868) = iVar2;
    return 0x140029f0a;
}

// ============================================================
// Function: FUN_14002a010
// Address: 0x14002a010
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_17e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel

void fcn.14002a010(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1868) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1860), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1868) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002a060
// Address: 0x14002a060
// Size: 24 bytes
// ============================================================
void fcn.14002a060(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002a080
// Address: 0x14002a080
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002a080(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_a00h;
    int64_t var_9a8h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_a00h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011e3a0(var_40h + 0x20, &var_a00h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0x9f0, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x000140018230(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002a170
// Address: 0x14002a170
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_990h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel

undefined8 fcn.14002a170(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xa10));
    *(undefined8 *)(arg2 + 0x9f0) = uVar1;
    *(int64_t *)(arg2 + 0x9f8) = iVar2;
    return 0x14002a114;
}

// ============================================================
// Function: FUN_14002a1b0
// Address: 0x14002a1b0
// Size: 24 bytes
// ============================================================
void fcn.14002a1b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002a1d0
// Address: 0x14002a1d0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel

undefined8 fcn.14002a1d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x9f0) = uVar1;
    *(int64_t *)(arg2 + 0x9f8) = iVar2;
    return 0x14002a114;
}

// ============================================================
// Function: FUN_14002a210
// Address: 0x14002a210
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel

void fcn.14002a210(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x9f8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x9f0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x9f8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002a260
// Address: 0x14002a260
// Size: 24 bytes
// ============================================================
void fcn.14002a260(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002a280
// Address: 0x14002a280
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1417h because it doesn't fit into ProtoModel

void fcn.14002a280(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002a28c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001418 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x000013f8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a2ae;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001417)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a2d4;
        func_0x00014011fc10(*(int64_t *)(&stack0x000013f8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001417)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a2f4;
        func_0x000140796b10(*(int64_t *)(&stack0x000013f8 + iVar4) + 0x1410, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x000013f8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a303;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a30f;
        func_0x000140016760(uVar1);
    }
    return;
}

