// Chunk 25 - 50 functions

// ============================================================
// Function: FUN_14001d540
// Address: 0x14001d540
// Size: 47 bytes
// ============================================================
void fcn.14001d540(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x38), 0x70, 8);
    return;
}

// ============================================================
// Function: FUN_14001d570
// Address: 0x14001d570
// Size: 167 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001d570(int64_t arg1)
{
    code **ppcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int64_t *)arg1 != 0) {
    // WARNING: Could not recover jumptable at 0x00014001d5a2. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)arg1 + 0x20))(arg1 + 0x18, *(undefined8 *)(arg1 + 8), *(undefined8 *)(arg1 + 0x10));
        return;
    }
    uVar3 = *(undefined8 *)(arg1 + 8);
    ppcVar1 = *(code ***)(arg1 + 0x10);
    if (*ppcVar1 != (code *)0x0) {
        (**ppcVar1)(uVar3);
    }
    if (ppcVar1[1] != (code *)0x0) {
        fcn.1404d3c50(uVar3, ppcVar1[1], ppcVar1[2]);
    }
    iVar2 = *(int64_t *)(arg1 + 0x18);
    if (iVar2 == 0) {
        return;
    }
    func_0x00014001cb00();
    uVar3 = (*(code *)0xe5f2d8)(iVar2, 0x70);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar2);
    return;
}

// ============================================================
// Function: FUN_14001d620
// Address: 0x14001d620
// Size: 64 bytes
// ============================================================
void fcn.14001d620(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    fcn.140002e20(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18));
    return;
}

// ============================================================
// Function: FUN_14001d660
// Address: 0x14001d660
// Size: 41 bytes
// ============================================================
void fcn.14001d660(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x70, 8);
    return;
}

// ============================================================
// Function: FUN_14001d690
// Address: 0x14001d690
// Size: 91 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.14001d690(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    
    if (*(int32_t *)arg1 != 2) {
        if ((*(char *)(arg1 + 0x30) != '\0') && (*(int64_t *)(arg1 + 0x38) != 0)) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 0x40), *(int64_t *)(arg1 + 0x38), 1);
        }
        iVar1 = *(int64_t *)(arg1 + 0x10);
        if ((-1 < iVar1) && (iVar1 != 0)) {
            uVar2 = *(undefined8 *)(arg1 + 0x18);
            uVar3 = (*(code *)0xe5f2d8)(uVar2, iVar1 << 5);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001d6f0
// Address: 0x14001d6f0
// Size: 165 bytes
// ============================================================
void fcn.14001d6f0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 *puVar6;
    
    if (*(int64_t *)arg1 == 0) {
        return;
    }
    if ((int32_t)*(int64_t *)arg1 == 1) {
        iVar3 = *(int64_t *)(arg1 + 8);
        if (iVar3 == 0) {
            return;
        }
        iVar2 = *(int64_t *)(arg1 + 0x10);
        uVar5 = 1;
    } else {
        iVar2 = *(int64_t *)(arg1 + 0x10);
        iVar3 = *(int64_t *)(arg1 + 0x18);
        if (iVar3 != 0) {
            puVar6 = (undefined8 *)(iVar2 + 8);
            do {
                if (puVar6[-1] != 0) {
                    fcn.1404d3c50(*puVar6, puVar6[-1], 1);
                }
                puVar6 = puVar6 + 3;
                iVar3 = iVar3 + -1;
            } while (iVar3 != 0);
        }
        if (*(int64_t *)(arg1 + 8) == 0) {
            return;
        }
        iVar3 = *(int64_t *)(arg1 + 8) * 0x18;
        uVar5 = 8;
    }
    iVar4 = iVar2;
    if (0x10 < uVar5) {
        iVar4 = *(int64_t *)(iVar2 + -8);
    }
    uVar1 = (*(code *)0xe5f2d8)(iVar2, iVar3);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar1, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_14001d7a0
// Address: 0x14001d7a0
// Size: 142 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001d7a0(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 in_R9;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    func_0x00014001cc40();
    iVar1 = *(int64_t *)(arg1 + 0x60);
    if (iVar1 != 0) {
        func_0x0001404403b0();
        fcn.1404d3c50(iVar1, 0x20, 8);
    }
    fcn.14001d570(arg1 + 0x70);
    piVar2 = *(int64_t **)(arg1 + 0x90);
    if (*piVar2 != 0) {
        fcn.1404d3c50(piVar2[1], *piVar2, 1);
    }
    uVar3 = (*(code *)0xe5f2d8)(piVar2, 0x58, 8, in_R9, 0xfffffffffffffffe, unaff_RSI, unaff_RBP);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, piVar2);
    return;
}

// ============================================================
// Function: FUN_14001d830
// Address: 0x14001d830
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001d830(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001cbd0(*(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x60));
    return;
}

// ============================================================
// Function: FUN_14001d860
// Address: 0x14001d860
// Size: 43 bytes
// ============================================================
void fcn.14001d860(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), 0x20, 8);
    return;
}

// ============================================================
// Function: FUN_14001d890
// Address: 0x14001d890
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001d890(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001d570(*(int64_t *)(arg2 + 0x28) + 0x70);
    return;
}

// ============================================================
// Function: FUN_14001d8c0
// Address: 0x14001d8c0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001d8c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001cf90(*(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x90));
    return;
}

// ============================================================
// Function: FUN_14001d8f0
// Address: 0x14001d8f0
// Size: 136 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.14001d8f0(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    iVar3 = *(int64_t *)(arg1 + 0x10);
    if (iVar3 != 0) {
        puVar4 = (undefined8 *)(iVar1 + 0x20);
        do {
            if (puVar4[-4] != 0) {
                fcn.1404d3c50(puVar4[-3], puVar4[-4], 1);
            }
            if (puVar4[-1] != 0) {
                fcn.1404d3c50(*puVar4, puVar4[-1], 1);
            }
            puVar4 = puVar4 + 7;
            iVar3 = iVar3 + -1;
        } while (iVar3 != 0);
    }
    if (*(int64_t *)arg1 == 0) {
        return;
    }
    uVar2 = (*(code *)0xe5f2d8)(iVar1, *(int64_t *)arg1 * 0x38);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, iVar1);
    return;
}

// ============================================================
// Function: FUN_14001d980
// Address: 0x14001d980
// Size: 240 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00014001da57: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00014001da5c)
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001d980(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t *unaff_RBP;
    int64_t unaff_RSI;
    undefined8 *puVar4;
    undefined8 auStack_60 [6];
    int64_t iStack_30;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = &var_28h;
    var_28h = -2;
    if (*(char *)(arg1 + 0x5d0) != '\0') {
        if (*(char *)(arg1 + 0x5d0) != '\x03') {
            return;
        }
        auStack_60[0] = 0x14001d9b9;
        iStack_30 = arg1;
        func_0x00014001e850(arg1 + 0x158);
        arg1 = iStack_30;
        unaff_RSI = *(int64_t *)(iStack_30 + 0x150);
        if (unaff_RSI != 0) {
            puVar4 = (undefined8 *)(*(int64_t *)(iStack_30 + 0x148) + 0x20);
            do {
                if (puVar4[-4] != 0) {
                    auStack_60[0] = 0x14001da01;
                    fcn.1404d3c50(puVar4[-3], puVar4[-4], 1);
                }
                if (puVar4[-1] != 0) {
                    auStack_60[0] = 0x14001da18;
                    fcn.1404d3c50(*puVar4, puVar4[-1], 1);
                }
                puVar4 = puVar4 + 7;
                unaff_RSI = unaff_RSI + -1;
            } while (unaff_RSI != 0);
        }
        if (*(int64_t *)(arg1 + 0x140) != 0) {
            auStack_60[0] = 0x14001da49;
            fcn.1404d3c50(*(undefined8 *)(arg1 + 0x148), *(int64_t *)(arg1 + 0x140) * 0x38, 8);
        }
        *(undefined *)(arg1 + 0x5d1) = 0;
        arg1 = arg1 + 0xa0;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_60;
        auStack_60[0] = 0x14001da5c;
        unaff_RBP = piVar1;
    }
    *(int64_t **)((int64_t)*(undefined **)0x20 + -8) = unaff_RBP;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) = 0xfffffffffffffffe;
    *(int64_t *)((int64_t)*(undefined **)0x20 + -0x18) = arg1;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140014d4b;
    func_0x00014001eac0();
    piVar1 = *(int64_t **)(*(int64_t *)((int64_t)*(undefined **)0x20 + -0x18) + 0x88);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140014d6c;
        func_0x0001406c6890(*(int64_t *)((int64_t)*(undefined **)0x20 + -0x18) + 0x88);
    }
    iVar2 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x18);
    piVar1 = *(int64_t **)(iVar2 + 0x90);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        uVar3 = *(undefined8 *)((int64_t)*(undefined **)0x20 + -8);
        iVar2 = *(int64_t *)(iVar2 + 0x90);
        if (iVar2 != -1) {
            LOCK();
            piVar1 = (int64_t *)(iVar2 + 8);
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = uVar3;
                *(int64_t *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140901d3e;
                uVar3 = (*(code *)0xe5f2d8)(iVar2, 0x20);
    // WARNING: Treating indirect jump as call
                (*(code *)0xe5f2ea)(uVar3, 0, iVar2);
                return;
            }
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_14001da70
// Address: 0x14001da70
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001da70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    fcn.14001d8f0(iVar1 + 0x140);
    *(undefined *)(iVar1 + 0x5d1) = 0;
    fcn.140014d30(iVar1 + 0xa0);
    return;
}

// ============================================================
// Function: FUN_14001dab0
// Address: 0x14001dab0
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001dab0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    *(undefined *)(*(int64_t *)(arg2 + 0x28) + 0x5d2) = 0;
    return;
}

// ============================================================
// Function: FUN_14001dae0
// Address: 0x14001dae0
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001dae0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(code **)arg2 != (code *)0x0) {
        (**(code **)arg2)(arg1);
    }
    if (*(int64_t *)(arg2 + 8) != 0) {
        if (0x10 < *(uint64_t *)(arg2 + 0x10)) {
            arg1 = *(int64_t *)(arg1 + -8);
        }
        uVar1 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
        (*(code *)0xe5f2ea)(uVar1, 0, arg1);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_14001db30
// Address: 0x14001db30
// Size: 51 bytes
// ============================================================
void fcn.14001db30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001db70
// Address: 0x14001db70
// Size: 124 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

int64_t fcn.14001db70(int64_t arg1)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(int64_t *)arg1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 8), *(int64_t *)arg1, 1);
    }
    if (*(int64_t *)(arg1 + 0x38) != 0) {
        func_0x000140440530(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x20) == 0) {
        return -*(int64_t *)(arg1 + 0x20);
    }
    uVar1 = *(undefined8 *)(arg1 + 0x28);
    uVar2 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    iVar3 = (*(code *)0xe5f2ea)(uVar2, 0, uVar1);
    return iVar3;
}

// ============================================================
// Function: FUN_14001dbf0
// Address: 0x14001dbf0
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001dbf0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x28) + 0x20);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x28), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14001dc60
// Address: 0x14001dc60
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001dc60(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    func_0x000140798190();
    if (*(char *)arg1 == '\0') {
        piVar1 = *(int64_t **)(arg1 + 8);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x000140795240();
        }
    } else {
        piVar1 = *(int64_t **)(arg1 + 8);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x000140794980();
        }
    }
    piVar1 = *(int64_t **)(arg1 + 0x10);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 != 0) {
        return;
    }
    iVar2 = *(int64_t *)(arg1 + 0x10);
    func_0x0001407a9f90(iVar2 + 0x80, 0x2f);
    if (*(int64_t *)(iVar2 + 0xb0) != 0) {
        (**(code **)(*(int64_t *)(iVar2 + 0xb0) + 0x18))(*(undefined8 *)(iVar2 + 0xb8));
    }
    if (*(int64_t *)(iVar2 + 0xc0) != 0) {
        (**(code **)(*(int64_t *)(iVar2 + 0xc0) + 0x18))(*(undefined8 *)(iVar2 + 200));
    }
    if (iVar2 != -1) {
        LOCK();
        piVar1 = (int64_t *)(iVar2 + 8);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            uVar3 = *(undefined8 *)(iVar2 + -8);
            uVar4 = (*(code *)0xe5f2d8)(iVar2, 0x100);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar4, 0, uVar3);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001dcd0
// Address: 0x14001dcd0
// Size: 48 bytes
// ============================================================
void fcn.14001dcd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg2 + 0x20) + 0x10);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.140794f40(*(int64_t *)(arg2 + 0x20) + 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_14001dd00
// Address: 0x14001dd00
// Size: 30 bytes
// ============================================================
void fcn.14001dd00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d160(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14001dd20
// Address: 0x14001dd20
// Size: 127 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.14001dd20(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uVar2;
    uint64_t uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    
    iVar1 = *(int64_t *)arg1;
    uVar3 = iVar1 >> 0x3f & iVar1 + 0x8000000000000001U;
    if (uVar3 == 0) {
        iVar5 = 0x1000;
        iVar6 = 0x20;
        if (iVar1 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8), iVar1, 1);
        }
code_r0x00014001dd86:
        uVar2 = *(undefined8 *)(arg1 + iVar6);
        uVar4 = (*(code *)0xe5f2d8)(uVar2, iVar5);
    // WARNING: Treating indirect jump as call
        (*(code *)0xe5f2ea)(uVar4, 0, uVar2);
        return;
    }
    if (uVar3 == 1) {
        iVar5 = *(int64_t *)(arg1 + 8);
        iVar6 = 0x10;
        if (iVar5 != 0) goto code_r0x00014001dd86;
    }
    return;
}

// ============================================================
// Function: FUN_14001dda0
// Address: 0x14001dda0
// Size: 1226 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00014001e1d0: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001dda0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char cVar5;
    uint32_t uVar6;
    int64_t *piVar7;
    undefined8 uVar8;
    undefined8 unaff_RBX;
    undefined *unaff_RBP;
    int64_t *piVar9;
    int64_t unaff_RSI;
    int64_t iVar10;
    int64_t unaff_RDI;
    undefined8 unaff_R14;
    undefined8 *puVar11;
    undefined8 unaff_R15;
    int64_t iVar12;
    bool bVar13;
    undefined8 auStack_60 [4];
    undefined8 uStack_40;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar9 = &var_18h;
    var_20h = -2;
    cVar5 = *(char *)(arg1 + 0x18c);
    var_28h = arg1;
    var_18h = unaff_RDI;
    if (cVar5 == '\0') {
        auStack_60[0] = 0x14001dea8;
        func_0x000140231300();
        auStack_60[0] = 0x14001deb9;
        func_0x00014001edb0(*(undefined8 *)(var_28h + 0x18), *(undefined8 *)(var_28h + 0x20));
        auStack_60[0] = 0x14001dec2;
        fcn.14001dc60(var_28h);
        auStack_60[0] = 0x14001decf;
        fcn.140014d30(var_28h + 0x28);
        piVar1 = *(int64_t **)(var_28h + 0xc0);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        iVar10 = unaff_RSI;
        piVar9 = (int64_t *)unaff_RBP;
        if (*piVar1 == 0) {
            auStack_60[0] = 0x14001def0;
            func_0x00014045e220(var_28h + 0xc0);
            iVar10 = unaff_RSI;
            piVar9 = (int64_t *)unaff_RBP;
        }
        piVar1 = *(int64_t **)(var_28h + 200);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            auStack_60[0] = 0x14001df11;
            func_0x00014045f1b0(var_28h + 200);
        }
        iVar2 = *(int64_t *)(var_28h + 0xd0);
        var_28h = var_28h + 0xd0;
        LOCK();
        piVar1 = (int64_t *)(iVar2 + 0x58);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            LOCK();
            bVar13 = *(char *)(iVar2 + 0x28) == '\0';
            if (bVar13) {
                *(char *)(iVar2 + 0x28) = '\x01';
            }
            UNLOCK();
            if (!bVar13) {
                auStack_60[0] = 0x14001e254;
                func_0x0001409766f0(iVar2 + 0x28);
            }
            if ((**(uint64_t **)0x140e64720 & 0x7fffffffffffffff) == 0) {
                uVar6 = 0;
            } else {
                auStack_60[0] = 0x14001e25e;
                uVar6 = func_0x000140977200();
                uVar6 = uVar6 ^ 1;
            }
            *(undefined *)(iVar2 + 0x50) = 1;
            auStack_60[0] = 0x14001df70;
            func_0x0001402d0210(iVar2 + 0x10, iVar2 + 0x28, uVar6);
        }
        piVar1 = *(int64_t **)var_28h;
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        piVar7 = (int64_t *)var_28h;
        unaff_RDI = var_18h;
        if (*piVar1 != 0) {
            return;
        }
    } else {
        if (cVar5 == '\x03') {
            if (*(char *)(arg1 + 0x6f0) == '\x03') {
                if (*(char *)(arg1 + 0x6e8) == '\x03') {
                    if (*(char *)(arg1 + 0x6e0) == '\x03') {
                        cVar5 = *(char *)(arg1 + 0x310);
                        if (cVar5 == '\x04') {
                            if (*(int32_t *)(arg1 + 0x5a0) != 2) {
                                iVar10 = arg1 + 0x5a0;
                                if (*(int32_t *)(arg1 + 0x650) != 3) {
                                    auStack_60[0] = 0x14001e0f9;
                                    var_30h = iVar10;
                                    func_0x00014001cc40(arg1 + 0x650);
                                    if (*(int64_t *)(var_28h + 0x6b0) != 0) {
                                        auStack_60[0] = 0x14001e112;
                                        var_38h = *(int64_t *)(var_28h + 0x6b0);
                                        func_0x0001404403b0();
                                        auStack_60[0] = 0x14001e126;
                                        fcn.1404d3c50(var_38h, 0x20, 8);
                                    }
                                    iVar10 = var_30h;
                                    if (*(int64_t *)(var_28h + 0x6c0) != 0) {
                                        auStack_60[0] = 0x14001e154;
                                        fcn.1404d3c50(*(undefined8 *)(var_28h + 0x6c8), *(int64_t *)(var_28h + 0x6c0), 1
                                                     );
                                        unaff_RDI = iVar10;
                                    }
                                }
                                auStack_60[0] = 0x14001e15c;
                                func_0x0001400034f0(iVar10);
                            }
                        } else if (cVar5 == '\x03') {
                            if (*(int32_t *)(arg1 + 0x318) != 2) {
                                var_30h = arg1 + 0x318;
                                auStack_60[0] = 0x14001e0a3;
                                func_0x000140231300();
                                auStack_60[0] = 0x14001e0ba;
                                func_0x00014001edb0(*(undefined8 *)(var_28h + 0x330), *(undefined8 *)(var_28h + 0x338));
                                auStack_60[0] = 0x14001e0c3;
                                fcn.14001dc60(var_30h);
                            }
                        } else if (cVar5 == '\0') {
                            var_30h = arg1 + 0x2a0;
                            auStack_60[0] = 0x14001e05d;
                            func_0x000140231300();
                            auStack_60[0] = 0x14001e074;
                            func_0x00014001edb0(*(undefined8 *)(var_28h + 0x2b8), *(undefined8 *)(var_28h + 0x2c0));
                            auStack_60[0] = 0x14001e07d;
                            fcn.14001dc60(var_30h);
                        }
                    } else if (*(char *)(arg1 + 0x6e0) == '\0') {
                        var_30h = arg1 + 0x230;
                        auStack_60[0] = 0x14001e007;
                        func_0x000140231300();
                        auStack_60[0] = 0x14001e01e;
                        func_0x00014001edb0(*(undefined8 *)(var_28h + 0x248), *(undefined8 *)(var_28h + 0x250));
                        auStack_60[0] = 0x14001e027;
                        fcn.14001dc60(var_30h);
                    }
                } else if (*(char *)(arg1 + 0x6e8) == '\0') {
                    var_30h = arg1 + 0x1c0;
                    auStack_60[0] = 0x14001dfba;
                    func_0x000140231300();
                    auStack_60[0] = 0x14001dfd1;
                    func_0x00014001edb0(*(undefined8 *)(var_28h + 0x1d8), *(undefined8 *)(var_28h + 0x1e0));
                    auStack_60[0] = 0x14001dfda;
                    fcn.14001dc60(var_30h);
                }
            } else if (*(char *)(arg1 + 0x6f0) == '\0') {
                var_30h = arg1 + 400;
                auStack_60[0] = 0x14001de7e;
                func_0x000140231300();
                auStack_60[0] = 0x14001de95;
                func_0x00014001edb0(*(undefined8 *)(var_28h + 0x1a8), *(undefined8 *)(var_28h + 0x1b0));
                auStack_60[0] = 0x14001de9e;
                fcn.14001dc60(var_30h);
            }
        } else {
            if (cVar5 != '\x04') {
                return;
            }
            uVar8 = *(undefined8 *)(arg1 + 0x1a0);
            auStack_60[0] = 0x14001dde8;
            cVar5 = func_0x000140797af0(uVar8);
            if (cVar5 != '\0') {
                auStack_60[0] = 0x14001ddf4;
                func_0x000140798840(uVar8);
            }
            *(undefined *)(var_28h + 0x18d) = 0;
            var_30h = var_28h + 0x198;
            auStack_60[0] = 0x14001de0f;
            func_0x000140416ae0();
            piVar1 = *(int64_t **)var_30h;
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                auStack_60[0] = 0x14001de21;
                func_0x00014045f950();
            }
            piVar1 = *(int64_t **)(var_28h + 400);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                auStack_60[0] = 0x14001de42;
                func_0x00014045faf0(var_28h + 400);
            }
            *(undefined *)(var_28h + 0x18e) = 0;
        }
        *(undefined *)(var_28h + 399) = 0;
        var_30h = var_28h + 0x180;
        iVar10 = *(int64_t *)(var_28h + 0x180);
        LOCK();
        piVar1 = (int64_t *)(iVar10 + 0x58);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            unaff_RDI = iVar10 + 0x28;
            LOCK();
            bVar13 = *(char *)(iVar10 + 0x28) == '\0';
            if (bVar13) {
                *(char *)(iVar10 + 0x28) = '\x01';
            }
            UNLOCK();
            if (!bVar13) {
                auStack_60[0] = 0x14001e236;
                func_0x0001409766f0(unaff_RDI);
            }
            if ((**(uint64_t **)0x140e64720 & 0x7fffffffffffffff) == 0) {
                uVar6 = 0;
            } else {
                auStack_60[0] = 0x14001e240;
                uVar6 = func_0x000140977200();
                uVar6 = uVar6 ^ 1;
            }
            *(undefined *)(iVar10 + 0x50) = 1;
            iVar10 = iVar10 + 0x10;
            auStack_60[0] = 0x14001e1c3;
            func_0x0001402d0210(iVar10, unaff_RDI, uVar6);
        }
        piVar1 = *(int64_t **)var_30h;
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 != 0) {
            piVar1 = *(int64_t **)(var_28h + 0x178);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            piVar9 = (int64_t *)unaff_RBP;
            if (*piVar1 == 0) {
                auStack_60[0] = 0x14001e1f6;
                func_0x00014045f1b0(var_28h + 0x178);
                piVar9 = (int64_t *)unaff_RBP;
            }
            piVar1 = *(int64_t **)(var_28h + 0x170);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                auStack_60[0] = 0x14001e217;
                func_0x00014045e220(var_28h + 0x170);
            }
            var_18h = var_28h + 0xd8;
            uStack_40 = 0x140014d4b;
            func_0x00014001eac0();
            piVar1 = *(int64_t **)(var_18h + 0x88);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                uStack_40 = 0x140014d6c;
                func_0x0001406c6890(var_18h + 0x88);
            }
            piVar1 = *(int64_t **)(var_18h + 0x90);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 != 0) {
                return;
            }
            iVar10 = *(int64_t *)(var_18h + 0x90);
            if (iVar10 == -1) {
                return;
            }
            LOCK();
            piVar1 = (int64_t *)(iVar10 + 8);
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 != 0) {
                return;
            }
            uVar8 = 0x20;
            goto code_r0x0001404d3c50;
        }
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_60;
        auStack_60[0] = 0x14001e1d5;
        piVar7 = (int64_t *)var_30h;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_R15;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_R14;
    *(int64_t *)((int64_t)*(undefined **)0x20 + -0x18) = iVar10;
    *(int64_t *)((int64_t)*(undefined **)0x20 + -0x20) = unaff_RDI;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x28) = unaff_RBX;
    iVar10 = *piVar7;
    iVar2 = *(int64_t *)(iVar10 + 0x18);
    if (iVar2 != 0) {
        iVar3 = *(int64_t *)(iVar10 + 0x10);
        puVar11 = (undefined8 *)(iVar3 + 0x10);
        iVar12 = iVar2;
        do {
            iVar4 = puVar11[-1];
            if (iVar4 != 0) {
                uVar8 = *puVar11;
                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x50) = 0x14045f155;
                fcn.1404d3c50(uVar8, iVar4, 1);
            }
            puVar11 = puVar11 + 6;
            iVar12 = iVar12 + -1;
        } while (iVar12 != 0);
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x50) = 0x14045f16d;
        fcn.1404d3c50(iVar3, iVar2 * 0x30, 8);
    }
    if (iVar10 != -1) {
        LOCK();
        piVar1 = (int64_t *)(iVar10 + 8);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            uVar8 = 0x88;
            unaff_RSI = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x18);
code_r0x0001404d3c50:
            *(int64_t **)((int64_t)*(undefined **)0x20 + -8) = piVar9;
            *(int64_t *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140901d3e;
            uVar8 = (*(code *)0xe5f2d8)(iVar10, uVar8);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar8, 0, iVar10);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001e270
// Address: 0x14001e270
// Size: 42 bytes
// ============================================================
void fcn.14001e270(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001edb0(*(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x18), *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x20));
    return;
}

// ============================================================
// Function: FUN_14001e2a0
// Address: 0x14001e2a0
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001e2a0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x30) + 0x6c0);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x6c8), uVar1, 1);
    }
    fcn.1400034f0(*(undefined8 *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_14001e2f0
// Address: 0x14001e2f0
// Size: 38 bytes
// ============================================================
void fcn.14001e2f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140014d30(*(int64_t *)(arg2 + 0x30) + 0x28);
    return;
}

// ============================================================
// Function: FUN_14001e320
// Address: 0x14001e320
// Size: 58 bytes
// ============================================================
void fcn.14001e320(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg2 + 0x30) + 0xc0);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045e220(*(int64_t *)(arg2 + 0x30) + 0xc0);
    }
    return;
}

// ============================================================
// Function: FUN_14001e360
// Address: 0x14001e360
// Size: 58 bytes
// ============================================================
void fcn.14001e360(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg2 + 0x30) + 200);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f1b0(*(int64_t *)(arg2 + 0x30) + 200);
    }
    return;
}

// ============================================================
// Function: FUN_14001e3a0
// Address: 0x14001e3a0
// Size: 41 bytes
// ============================================================
void fcn.14001e3a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001ece0(*(int64_t *)(arg2 + 0x30) + 0xd0);
    return;
}

// ============================================================
// Function: FUN_14001e3d0
// Address: 0x14001e3d0
// Size: 47 bytes
// ============================================================
void fcn.14001e3d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x30);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f100(*(undefined8 *)(arg2 + 0x30));
    }
    return;
}

// ============================================================
// Function: FUN_14001e400
// Address: 0x14001e400
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001e400(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x28);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f100(*(undefined8 *)(arg2 + 0x28));
    }
    return;
}

// ============================================================
// Function: FUN_14001e430
// Address: 0x14001e430
// Size: 48 bytes
// ============================================================
void fcn.14001e430(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    *(undefined *)(iVar1 + 399) = 0;
    fcn.14001ece0(iVar1 + 0x180);
    return;
}

// ============================================================
// Function: FUN_14001e460
// Address: 0x14001e460
// Size: 48 bytes
// ============================================================
void fcn.14001e460(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    *(undefined *)(iVar1 + 0x18d) = 0;
    fcn.14001ef50(iVar1 + 0x198);
    return;
}

// ============================================================
// Function: FUN_14001e490
// Address: 0x14001e490
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001e490(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x28);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f950(*(undefined8 *)(arg2 + 0x28));
    }
    return;
}

// ============================================================
// Function: FUN_14001e4c0
// Address: 0x14001e4c0
// Size: 58 bytes
// ============================================================
void fcn.14001e4c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg2 + 0x30) + 400);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045faf0(*(int64_t *)(arg2 + 0x30) + 400);
    }
    return;
}

// ============================================================
// Function: FUN_14001e500
// Address: 0x14001e500
// Size: 35 bytes
// ============================================================
void fcn.14001e500(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined *)(*(int64_t *)(arg2 + 0x30) + 0x18e) = 0;
    return;
}

// ============================================================
// Function: FUN_14001e530
// Address: 0x14001e530
// Size: 58 bytes
// ============================================================
void fcn.14001e530(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg2 + 0x30) + 0x178);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f1b0(*(int64_t *)(arg2 + 0x30) + 0x178);
    }
    return;
}

// ============================================================
// Function: FUN_14001e570
// Address: 0x14001e570
// Size: 58 bytes
// ============================================================
void fcn.14001e570(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg2 + 0x30) + 0x170);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045e220(*(int64_t *)(arg2 + 0x30) + 0x170);
    }
    return;
}

// ============================================================
// Function: FUN_14001e5b0
// Address: 0x14001e5b0
// Size: 41 bytes
// ============================================================
void fcn.14001e5b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140014d30(*(int64_t *)(arg2 + 0x30) + 0xd8);
    return;
}

// ============================================================
// Function: FUN_14001e5e0
// Address: 0x14001e5e0
// Size: 34 bytes
// ============================================================
void fcn.14001e5e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001dc60(*(int64_t *)(arg2 + 0x30));
    return;
}

// ============================================================
// Function: FUN_14001e610
// Address: 0x14001e610
// Size: 48 bytes
// ============================================================
void fcn.14001e610(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001edb0(*(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x1a8), *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x1b0)
                 );
    return;
}

// ============================================================
// Function: FUN_14001e640
// Address: 0x14001e640
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001e640(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_18h;
    
    fcn.14001dc60(*(int64_t *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_14001e670
// Address: 0x14001e670
// Size: 48 bytes
// ============================================================
void fcn.14001e670(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001edb0(*(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x1d8), *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x1e0)
                 );
    return;
}

// ============================================================
// Function: FUN_14001e6a0
// Address: 0x14001e6a0
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001e6a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_18h;
    
    fcn.14001dc60(*(int64_t *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_14001e6d0
// Address: 0x14001e6d0
// Size: 48 bytes
// ============================================================
void fcn.14001e6d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001edb0(*(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x248), *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x250)
                 );
    return;
}

// ============================================================
// Function: FUN_14001e700
// Address: 0x14001e700
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001e700(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_18h;
    
    fcn.14001dc60(*(int64_t *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_14001e730
// Address: 0x14001e730
// Size: 48 bytes
// ============================================================
void fcn.14001e730(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001edb0(*(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x2b8), *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x2c0)
                 );
    return;
}

// ============================================================
// Function: FUN_14001e760
// Address: 0x14001e760
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001e760(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_18h;
    
    fcn.14001dc60(*(int64_t *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_14001e790
// Address: 0x14001e790
// Size: 48 bytes
// ============================================================
void fcn.14001e790(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001edb0(*(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x330), *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x338)
                 );
    return;
}

