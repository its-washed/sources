// Chunk 4 - 50 functions

// ============================================================
// Function: FUN_1400050b0
// Address: 0x1400050b0
// Size: 99 bytes
// ============================================================
void fcn.1400050b0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x380);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x388), uVar1, 1);
    }
    iVar2 = *(int64_t *)(arg2 + 0x40);
    fcn.14001c990(iVar2);
    fcn.140001ed0(iVar2 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140005120
// Address: 0x140005120
// Size: 43 bytes
// ============================================================
void fcn.140005120(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140005150
// Address: 0x140005150
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140005150(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1400051a0
// Address: 0x1400051a0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1400051a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_1400051f0
// Address: 0x1400051f0
// Size: 43 bytes
// ============================================================
void fcn.1400051f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140005220
// Address: 0x140005220
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140005220(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140005270
// Address: 0x140005270
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.140005270(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_1400052c0
// Address: 0x1400052c0
// Size: 395 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.1400052c0(int64_t arg1)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x678) == '\0') {
        fcn.14001c990();
        iVar3 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar4 = *(int64_t *)(arg1 + 0x210);
        while (iVar3 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar4);
            iVar4 = iVar4 + 0x60;
        }
        goto code_r0x00014000540f;
    }
    if (*(char *)(arg1 + 0x678) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x670) == '\0') {
        if (*(char *)(arg1 + 0x4fc) == '\0') {
            iVar3 = arg1 + 0x390;
            goto code_r0x0001400053a7;
        }
    } else if ((*(char *)(arg1 + 0x670) == '\x03') && (*(char *)(arg1 + 0x66c) == '\0')) {
        iVar3 = arg1 + 0x500;
code_r0x0001400053a7:
        func_0x00014001be30(iVar3);
    }
    fcn.14001c990(arg1);
    iVar3 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar4 = *(int64_t *)(arg1 + 0x210);
    while (iVar3 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar4);
        iVar4 = iVar4 + 0x60;
    }
code_r0x00014000540f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar2 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140005450
// Address: 0x140005450
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005450(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140005480
// Address: 0x140005480
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140005480(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1400054d0
// Address: 0x1400054d0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400054d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140005520
// Address: 0x140005520
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005520(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140005560
// Address: 0x140005560
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005560(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140005590
// Address: 0x140005590
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140005590(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1400055e0
// Address: 0x1400055e0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400055e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140005630
// Address: 0x140005630
// Size: 459 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140005630(int64_t arg1)
{
    int64_t iVar1;
    char cVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0xd50) == '\0') {
        fcn.14001c990();
        iVar1 = *(int64_t *)(arg1 + 0x218);
        var_30h = 0;
        iVar5 = *(int64_t *)(arg1 + 0x210);
        while (iVar1 != var_30h) {
            var_30h = var_30h + 1;
            func_0x0001402727a0(iVar5);
            iVar5 = iVar5 + 0x60;
        }
        goto code_r0x0001400057bf;
    }
    if (*(char *)(arg1 + 0xd50) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0xd48) == '\x03') {
        iVar1 = arg1 + 0x990;
        cVar2 = *(char *)(arg1 + 0xd44);
joined_r0x000140005711:
        if (cVar2 == '\0') {
            func_0x00014001be30(iVar1);
            func_0x000140014e50(iVar1 + 0x168);
            if (*(int64_t *)(iVar1 + 0x380) != 0) {
                fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x388), *(int64_t *)(iVar1 + 0x380), 1);
            }
        }
    } else if (*(char *)(arg1 + 0xd48) == '\0') {
        iVar1 = arg1 + 0x5d8;
        cVar2 = *(char *)(arg1 + 0x98c);
        goto joined_r0x000140005711;
    }
    fcn.14001c990(arg1);
    iVar1 = *(int64_t *)(arg1 + 0x218);
    var_30h = 0;
    iVar5 = *(int64_t *)(arg1 + 0x210);
    while (iVar1 != var_30h) {
        var_30h = var_30h + 1;
        func_0x0001402727a0(iVar5);
        iVar5 = iVar5 + 0x60;
    }
code_r0x0001400057bf:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar3 = *(undefined8 *)(arg1 + 0x210);
    uVar4 = (*(code *)0xe5f2d8)(uVar3, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar4, 0, uVar3);
    return;
}

// ============================================================
// Function: FUN_140005800
// Address: 0x140005800
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005800(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140014e50(*(int64_t *)(arg2 + 0x48) + 0x168);
    return;
}

// ============================================================
// Function: FUN_140005830
// Address: 0x140005830
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005830(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x380);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x388), uVar1, 1);
    }
    iVar2 = *(int64_t *)(arg2 + 0x40);
    fcn.14001c990(iVar2);
    fcn.140001ed0(iVar2 + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400058a0
// Address: 0x1400058a0
// Size: 43 bytes
// ============================================================
void fcn.1400058a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400058d0
// Address: 0x1400058d0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400058d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140005920
// Address: 0x140005920
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.140005920(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140005970
// Address: 0x140005970
// Size: 43 bytes
// ============================================================
void fcn.140005970(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400059a0
// Address: 0x1400059a0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400059a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1400059f0
// Address: 0x1400059f0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1400059f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140005a40
// Address: 0x140005a40
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140005a40(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x8d0) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x000140005bdf;
    }
    if (*(char *)(arg1 + 0x8d0) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x8c8) == '\0') {
        if (*(char *)(arg1 + 0x688) == '\0') {
            fcn.140014e50(arg1 + 0x458);
            iVar4 = *(int64_t *)(arg1 + 0x670);
            iVar2 = 0x670;
            goto code_r0x000140005b48;
        }
    } else if ((*(char *)(arg1 + 0x8c8) == '\x03') && (*(char *)(arg1 + 0x8c0) == '\0')) {
        fcn.140014e50(arg1 + 0x690);
        iVar4 = *(int64_t *)(arg1 + 0x8a8);
        iVar2 = 0x8a8;
code_r0x000140005b48:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x000140005bdf:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140005c20
// Address: 0x140005c20
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005c20(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x670);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x678), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140005c70
// Address: 0x140005c70
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005c70(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x8a8);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x8b0), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140005cc0
// Address: 0x140005cc0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005cc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140005cf0
// Address: 0x140005cf0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140005cf0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140005d40
// Address: 0x140005d40
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005d40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140005d90
// Address: 0x140005d90
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005d90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140005dd0
// Address: 0x140005dd0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005dd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140005e00
// Address: 0x140005e00
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140005e00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140005e50
// Address: 0x140005e50
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140005e50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140005ea0
// Address: 0x140005ea0
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140005ea0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x8d0) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x00014000603f;
    }
    if (*(char *)(arg1 + 0x8d0) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x8c8) == '\0') {
        if (*(char *)(arg1 + 0x689) == '\0') {
            fcn.140014e50(arg1 + 0x458);
            iVar4 = *(int64_t *)(arg1 + 0x670);
            iVar2 = 0x670;
            goto code_r0x000140005fa8;
        }
    } else if ((*(char *)(arg1 + 0x8c8) == '\x03') && (*(char *)(arg1 + 0x8c1) == '\0')) {
        fcn.140014e50(arg1 + 0x690);
        iVar4 = *(int64_t *)(arg1 + 0x8a8);
        iVar2 = 0x8a8;
code_r0x000140005fa8:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x00014000603f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140006080
// Address: 0x140006080
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006080(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x670);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x678), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_1400060d0
// Address: 0x1400060d0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400060d0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x8a8);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x8b0), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140006120
// Address: 0x140006120
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006120(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140006150
// Address: 0x140006150
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140006150(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1400061a0
// Address: 0x1400061a0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400061a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_1400061f0
// Address: 0x1400061f0
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400061f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140006230
// Address: 0x140006230
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006230(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140006260
// Address: 0x140006260
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140006260(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1400062b0
// Address: 0x1400062b0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400062b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140006300
// Address: 0x140006300
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140006300(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x918) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x00014000649f;
    }
    if (*(char *)(arg1 + 0x918) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x910) == '\0') {
        if (*(char *)(arg1 + 0x6b8) == '\0') {
            fcn.140014e50(arg1 + 0x470);
            iVar4 = *(int64_t *)(arg1 + 0x688);
            iVar2 = 0x688;
            goto code_r0x000140006408;
        }
    } else if ((*(char *)(arg1 + 0x910) == '\x03') && (*(char *)(arg1 + 0x908) == '\0')) {
        fcn.140014e50(arg1 + 0x6c0);
        iVar4 = *(int64_t *)(arg1 + 0x8d8);
        iVar2 = 0x8d8;
code_r0x000140006408:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x00014000649f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_1400064e0
// Address: 0x1400064e0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400064e0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x688);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x690), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140006530
// Address: 0x140006530
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006530(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x8d8);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x8e0), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140006580
// Address: 0x140006580
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006580(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400065b0
// Address: 0x1400065b0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400065b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140006600
// Address: 0x140006600
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006600(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

