// Chunk 70 - 50 functions

// ============================================================
// Function: FUN_14004f920
// Address: 0x14004f920
// Size: 505 bytes
// ============================================================
void fcn.14004f920(int64_t var_28h, int64_t var_30h, int64_t var_38h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_138h, int64_t arg_140h
                  , int64_t arg_148h, int64_t arg_158h, int64_t arg_160h, int64_t arg_168h, int64_t arg_170h,
                  int64_t arg_178h, int64_t arg_180h, int64_t arg_198h, int64_t arg_1b8h, int64_t arg_1c0h,
                  int64_t arg_1c8h, int64_t arg_1d0h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t var_7h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_3bd6b790h;
    int64_t var_7e0h;
    int64_t var_7d8h;
    int64_t var_788h;
    int64_t var_690h;
    int64_t var_680h;
    int64_t var_678h;
    int64_t var_360h;
    int64_t var_348h;
    int64_t var_1a8h;
    int64_t var_150h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_20;
    int64_t var_8h;
    
    uStack_20 = 0x14004f92d;
    iVar2 = func_0x00014094c690();
    *(undefined8 *)(&stack0x000031b0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004f94b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014004f95c. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (512 cases) at 0x14097af44
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097af44) + 0x14097af44))();
    return;
}

// ============================================================
// Function: FUN_14004fb20
// Address: 0x14004fb20
// Size: 37 bytes
// ============================================================
void fcn.14004fb20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004fb50
// Address: 0x14004fb50
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1868h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3140h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004fb50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x18e8) = 2;
    fcn.14011ead0(*(undefined8 *)(arg2 + 0x31c0), arg2 + 0x18e8);
    return;
}

// ============================================================
// Function: FUN_14004fb90
// Address: 0x14004fb90
// Size: 25 bytes
// ============================================================
void fcn.14004fb90(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004fbb0
// Address: 0x14004fbb0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3128h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3138h because it doesn't fit into ProtoModel

undefined8 fcn.14004fbb0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x31d8));
    *(undefined8 *)(arg2 + 0x31a8) = uVar1;
    *(int64_t *)(arg2 + 0x31b8) = iVar2;
    return 0x14004fa47;
}

// ============================================================
// Function: FUN_14004fbf0
// Address: 0x14004fbf0
// Size: 25 bytes
// ============================================================
void fcn.14004fbf0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004fc10
// Address: 0x14004fc10
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3128h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3138h because it doesn't fit into ProtoModel

undefined8 fcn.14004fc10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x31a8) = uVar1;
    *(int64_t *)(arg2 + 0x31b8) = iVar2;
    return 0x14004fa47;
}

// ============================================================
// Function: FUN_14004fc50
// Address: 0x14004fc50
// Size: 25 bytes
// ============================================================
void fcn.14004fc50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004fc70
// Address: 0x14004fc70
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3140h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3138h because it doesn't fit into ProtoModel

undefined8 fcn.14004fc70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x31d0));
    *(undefined8 *)(arg2 + 0x31c0) = uVar1;
    *(int64_t *)(arg2 + 0x31b8) = iVar2;
    return 0x14004fac7;
}

// ============================================================
// Function: FUN_14004fcb0
// Address: 0x14004fcb0
// Size: 25 bytes
// ============================================================
void fcn.14004fcb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004fcd0
// Address: 0x14004fcd0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3140h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3138h because it doesn't fit into ProtoModel

undefined8 fcn.14004fcd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x31c0) = uVar1;
    *(int64_t *)(arg2 + 0x31b8) = iVar2;
    return 0x14004fac7;
}

// ============================================================
// Function: FUN_14004fd10
// Address: 0x14004fd10
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3138h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3140h because it doesn't fit into ProtoModel

void fcn.14004fd10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x31b8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x31c0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x31b8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004fd60
// Address: 0x14004fd60
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.14004fd60(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004fd6d;
    iVar2 = func_0x00014094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004fd8b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014004fd9c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097af64) + 0x14097af64))();
    return;
}

// ============================================================
// Function: FUN_14004ff60
// Address: 0x14004ff60
// Size: 37 bytes
// ============================================================
void fcn.14004ff60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004ff90
// Address: 0x14004ff90
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004ff90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_14004ffd0
// Address: 0x14004ffd0
// Size: 25 bytes
// ============================================================
void fcn.14004ffd0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004fff0
// Address: 0x14004fff0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004fff0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004fe87;
}

// ============================================================
// Function: FUN_140050030
// Address: 0x140050030
// Size: 25 bytes
// ============================================================
void fcn.140050030(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140050050
// Address: 0x140050050
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140050050(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004fe87;
}

// ============================================================
// Function: FUN_140050090
// Address: 0x140050090
// Size: 25 bytes
// ============================================================
void fcn.140050090(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400500b0
// Address: 0x1400500b0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400500b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004ff07;
}

// ============================================================
// Function: FUN_1400500f0
// Address: 0x1400500f0
// Size: 25 bytes
// ============================================================
void fcn.1400500f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140050110
// Address: 0x140050110
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140050110(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004ff07;
}

// ============================================================
// Function: FUN_140050150
// Address: 0x140050150
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140050150(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400501a0
// Address: 0x1400501a0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel

void fcn.1400501a0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400501ad;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000013b0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x1400501cb;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x0001400501dc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097af84) + 0x14097af84))();
    return;
}

// ============================================================
// Function: FUN_1400503a0
// Address: 0x1400503a0
// Size: 37 bytes
// ============================================================
void fcn.1400503a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1400503d0
// Address: 0x1400503d0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400503d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x9e8) = 2;
    fcn.14011dd00(*(undefined8 *)(arg2 + 0x13c0), arg2 + 0x9e8);
    return;
}

// ============================================================
// Function: FUN_140050410
// Address: 0x140050410
// Size: 25 bytes
// ============================================================
void fcn.140050410(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140050430
// Address: 0x140050430
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.140050430(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13d8));
    *(undefined8 *)(arg2 + 0x13a8) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x1400502c7;
}

// ============================================================
// Function: FUN_140050470
// Address: 0x140050470
// Size: 25 bytes
// ============================================================
void fcn.140050470(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140050490
// Address: 0x140050490
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.140050490(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x13a8) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x1400502c7;
}

// ============================================================
// Function: FUN_1400504d0
// Address: 0x1400504d0
// Size: 25 bytes
// ============================================================
void fcn.1400504d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400504f0
// Address: 0x1400504f0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.1400504f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13d0));
    *(undefined8 *)(arg2 + 0x13c0) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x140050347;
}

// ============================================================
// Function: FUN_140050530
// Address: 0x140050530
// Size: 25 bytes
// ============================================================
void fcn.140050530(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140050550
// Address: 0x140050550
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.140050550(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x13c0) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x140050347;
}

// ============================================================
// Function: FUN_140050590
// Address: 0x140050590
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1340h because it doesn't fit into ProtoModel

void fcn.140050590(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x13b8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x13c0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x13b8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400505e0
// Address: 0x1400505e0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.1400505e0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400505ed;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14005060b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014005061c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097afa4) + 0x14097afa4))();
    return;
}

// ============================================================
// Function: FUN_1400507e0
// Address: 0x1400507e0
// Size: 37 bytes
// ============================================================
void fcn.1400507e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140050810
// Address: 0x140050810
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140050810(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140050850
// Address: 0x140050850
// Size: 25 bytes
// ============================================================
void fcn.140050850(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140050870
// Address: 0x140050870
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140050870(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140050707;
}

// ============================================================
// Function: FUN_1400508b0
// Address: 0x1400508b0
// Size: 25 bytes
// ============================================================
void fcn.1400508b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400508d0
// Address: 0x1400508d0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400508d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140050707;
}

// ============================================================
// Function: FUN_140050910
// Address: 0x140050910
// Size: 25 bytes
// ============================================================
void fcn.140050910(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140050930
// Address: 0x140050930
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140050930(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140050787;
}

// ============================================================
// Function: FUN_140050970
// Address: 0x140050970
// Size: 25 bytes
// ============================================================
void fcn.140050970(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140050990
// Address: 0x140050990
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140050990(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140050787;
}

// ============================================================
// Function: FUN_1400509d0
// Address: 0x1400509d0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

void fcn.1400509d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140050a20
// Address: 0x140050a20
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel

void fcn.140050a20(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140050a2d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000013b0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140050a4b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x000140050a5c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097afc4) + 0x14097afc4))();
    return;
}

// ============================================================
// Function: FUN_140050c20
// Address: 0x140050c20
// Size: 37 bytes
// ============================================================
void fcn.140050c20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

