// Chunk 85 - 50 functions

// ============================================================
// Function: FUN_140060450
// Address: 0x140060450
// Size: 60 bytes
// ============================================================
undefined8 fcn.140060450(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x52a8));
    *(undefined8 *)(arg2 + 0x5278) = uVar1;
    *(int64_t *)(arg2 + 0x5288) = iVar2;
    return 0x1400602f3;
}

// ============================================================
// Function: FUN_140060490
// Address: 0x140060490
// Size: 25 bytes
// ============================================================
void fcn.140060490(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400604b0
// Address: 0x1400604b0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_51f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5208h because it doesn't fit into ProtoModel

undefined8 fcn.1400604b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x5278) = uVar1;
    *(int64_t *)(arg2 + 0x5288) = iVar2;
    return 0x1400602f3;
}

// ============================================================
// Function: FUN_1400604f0
// Address: 0x1400604f0
// Size: 25 bytes
// ============================================================
void fcn.1400604f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140060510
// Address: 0x140060510
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_5220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5210h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5208h because it doesn't fit into ProtoModel

undefined8 fcn.140060510(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x52a0));
    *(undefined8 *)(arg2 + 0x5290) = uVar1;
    *(int64_t *)(arg2 + 0x5288) = iVar2;
    return 0x140060373;
}

// ============================================================
// Function: FUN_140060550
// Address: 0x140060550
// Size: 25 bytes
// ============================================================
void fcn.140060550(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140060570
// Address: 0x140060570
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_5210h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5208h because it doesn't fit into ProtoModel

undefined8 fcn.140060570(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x5290) = uVar1;
    *(int64_t *)(arg2 + 0x5288) = iVar2;
    return 0x140060373;
}

// ============================================================
// Function: FUN_1400605b0
// Address: 0x1400605b0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_5208h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5210h because it doesn't fit into ProtoModel

void fcn.1400605b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x5288) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x5290), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x5288) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140060600
// Address: 0x140060600
// Size: 505 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcc00f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3088h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1840h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3078h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3090h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_beh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1640h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1638h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5cb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_187h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1630h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_818h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ab8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ac0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ae0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5aa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5aa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ad0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1208h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2170h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800f6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2430h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2300h because it doesn't fit into ProtoModel

void fcn.140060600(int64_t var_28h, int64_t arg_50h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_128h
                  , int64_t arg_130h, int64_t arg_138h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h,
                  int64_t arg_160h, int64_t arg_168h, int64_t arg_170h, int64_t arg_178h, int64_t arg_1b8h,
                  int64_t arg_1c0h, int64_t arg_1c8h, int64_t arg_1d0h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_360h;
    int64_t var_348h;
    int64_t var_1a8h;
    int64_t var_150h;
    int64_t var_48h;
    int64_t var_30h;
    undefined8 uStack_20;
    int64_t var_8h;
    
    uStack_20 = 0x14006060d;
    iVar2 = func_0x00014094c690();
    *(undefined8 *)(&stack0x00001e90 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14006062b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014006063c. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (18 cases) at 0x14097b724
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b724) + 0x14097b724))();
    return;
}

// ============================================================
// Function: FUN_140060800
// Address: 0x140060800
// Size: 37 bytes
// ============================================================
void fcn.140060800(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140060830
// Address: 0x140060830
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140060830(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xf58) = 2;
    fcn.14011d460(*(undefined8 *)(arg2 + 0x1ea0), arg2 + 0xf58);
    return;
}

// ============================================================
// Function: FUN_140060870
// Address: 0x140060870
// Size: 25 bytes
// ============================================================
void fcn.140060870(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140060890
// Address: 0x140060890
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140060890(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1eb8));
    *(undefined8 *)(arg2 + 0x1e88) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140060727;
}

// ============================================================
// Function: FUN_1400608d0
// Address: 0x1400608d0
// Size: 25 bytes
// ============================================================
void fcn.1400608d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400608f0
// Address: 0x1400608f0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.1400608f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1e88) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140060727;
}

// ============================================================
// Function: FUN_140060930
// Address: 0x140060930
// Size: 25 bytes
// ============================================================
void fcn.140060930(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140060950
// Address: 0x140060950
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140060950(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1eb0));
    *(undefined8 *)(arg2 + 0x1ea0) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x1400607a7;
}

// ============================================================
// Function: FUN_140060990
// Address: 0x140060990
// Size: 25 bytes
// ============================================================
void fcn.140060990(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400609b0
// Address: 0x1400609b0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.1400609b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1ea0) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x1400607a7;
}

// ============================================================
// Function: FUN_1400609f0
// Address: 0x1400609f0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel

void fcn.1400609f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1e98) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1ea0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1e98) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140060a40
// Address: 0x140060a40
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.140060a40(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140060a4d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140060a6b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140060a7c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b744) + 0x14097b744))();
    return;
}

// ============================================================
// Function: FUN_140060c40
// Address: 0x140060c40
// Size: 37 bytes
// ============================================================
void fcn.140060c40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140060c70
// Address: 0x140060c70
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140060c70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140060cb0
// Address: 0x140060cb0
// Size: 25 bytes
// ============================================================
void fcn.140060cb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140060cd0
// Address: 0x140060cd0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140060cd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140060b67;
}

// ============================================================
// Function: FUN_140060d10
// Address: 0x140060d10
// Size: 25 bytes
// ============================================================
void fcn.140060d10(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140060d30
// Address: 0x140060d30
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140060d30(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140060b67;
}

// ============================================================
// Function: FUN_140060d70
// Address: 0x140060d70
// Size: 25 bytes
// ============================================================
void fcn.140060d70(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140060d90
// Address: 0x140060d90
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140060d90(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140060be7;
}

// ============================================================
// Function: FUN_140060dd0
// Address: 0x140060dd0
// Size: 25 bytes
// ============================================================
void fcn.140060dd0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140060df0
// Address: 0x140060df0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140060df0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140060be7;
}

// ============================================================
// Function: FUN_140060e30
// Address: 0x140060e30
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140060e30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140060e80
// Address: 0x140060e80
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_27f0h because it doesn't fit into ProtoModel

void fcn.140060e80(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140060e8d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000027f0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140060eab;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140060ebc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b764) + 0x14097b764))();
    return;
}

// ============================================================
// Function: FUN_140061080
// Address: 0x140061080
// Size: 37 bytes
// ============================================================
void fcn.140061080(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1400610b0
// Address: 0x1400610b0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400610b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1408) = 2;
    fcn.14011ef20(*(undefined8 *)(arg2 + 0x2800), arg2 + 0x1408);
    return;
}

// ============================================================
// Function: FUN_1400610f0
// Address: 0x1400610f0
// Size: 25 bytes
// ============================================================
void fcn.1400610f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140061110
// Address: 0x140061110
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.140061110(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2818));
    *(undefined8 *)(arg2 + 0x27e8) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x140060fa7;
}

// ============================================================
// Function: FUN_140061150
// Address: 0x140061150
// Size: 25 bytes
// ============================================================
void fcn.140061150(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140061170
// Address: 0x140061170
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.140061170(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x27e8) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x140060fa7;
}

// ============================================================
// Function: FUN_1400611b0
// Address: 0x1400611b0
// Size: 25 bytes
// ============================================================
void fcn.1400611b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400611d0
// Address: 0x1400611d0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.1400611d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2810));
    *(undefined8 *)(arg2 + 0x2800) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x140061027;
}

// ============================================================
// Function: FUN_140061210
// Address: 0x140061210
// Size: 25 bytes
// ============================================================
void fcn.140061210(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140061230
// Address: 0x140061230
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.140061230(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2800) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x140061027;
}

// ============================================================
// Function: FUN_140061270
// Address: 0x140061270
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel

void fcn.140061270(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x27f8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x2800), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x27f8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400612c0
// Address: 0x1400612c0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.1400612c0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400612cd;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x1400612eb;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x0001400612fc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b784) + 0x14097b784))();
    return;
}

// ============================================================
// Function: FUN_1400614c0
// Address: 0x1400614c0
// Size: 37 bytes
// ============================================================
void fcn.1400614c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1400614f0
// Address: 0x1400614f0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400614f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140061530
// Address: 0x140061530
// Size: 25 bytes
// ============================================================
void fcn.140061530(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140061550
// Address: 0x140061550
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140061550(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400613e7;
}

// ============================================================
// Function: FUN_140061590
// Address: 0x140061590
// Size: 25 bytes
// ============================================================
void fcn.140061590(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

