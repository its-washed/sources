// Chunk 1 - 50 functions

// ============================================================
// Function: FUN_140001000
// Address: 0x140001000
// Size: 529 bytes
// ============================================================
void fcn.140001000(int64_t arg1)
{
    int64_t *piVar1;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    // [00] -r-x section size 9928704 named .text
    // switch table (6 cases) at 0x14097a0a8
    switch(*(undefined *)(arg1 + 0x78)) {
    case 0:
        func_0x000140416640();
        piVar1 = *(int64_t **)(arg1 + 0x40);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x00014045f950();
        }
        func_0x0001402d8080();
        piVar1 = *(int64_t **)(arg1 + 0x48);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x00014045f100();
        }
        piVar1 = *(int64_t **)(arg1 + 0x38);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x00014045faf0(arg1 + 0x38);
        }
        goto code_r0x0001400011d4;
    default:
        goto code_r0x0001400011ed;
    case 3:
        if (*(char *)(arg1 + 0xd0) == '\x03') {
            func_0x0001402d7f10(arg1 + 0xa0);
            if (*(int64_t *)(arg1 + 0xa8) != 0) {
                (**(code **)(*(int64_t *)(arg1 + 0xa8) + 0x18))(*(undefined8 *)(arg1 + 0xb0));
            }
        }
        break;
    case 4:
        if ((*(int64_t *)(arg1 + 0x98) != 6) &&
           (((int32_t)*(int64_t *)(arg1 + 0x98) != 4 || (*(int16_t *)(arg1 + 0xc0) != 0x12)))) {
            (**(code **)(*(int64_t *)(arg1 + 0xa0) + 0x20))
                      (arg1 + 0xb8, *(undefined8 *)(arg1 + 0xa8), *(undefined8 *)(arg1 + 0xb0));
        }
        break;
    case 5:
        if ((*(int64_t *)(arg1 + 0x98) != 6) &&
           (((int32_t)*(int64_t *)(arg1 + 0x98) != 4 || (*(int16_t *)(arg1 + 0xc0) != 0x12)))) {
            (**(code **)(*(int64_t *)(arg1 + 0xa0) + 0x20))
                      (arg1 + 0xb8, *(undefined8 *)(arg1 + 0xa8), *(undefined8 *)(arg1 + 0xb0));
        }
    }
    func_0x000140416640();
    piVar1 = *(int64_t **)(arg1 + 0x40);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x00014045f950();
    }
    func_0x0001402d8080();
    piVar1 = *(int64_t **)(arg1 + 0x48);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x00014045f100();
    }
    piVar1 = *(int64_t **)(arg1 + 0x38);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x00014045faf0(arg1 + 0x38);
    }
code_r0x0001400011d4:
    if ((*(int64_t *)arg1 != 6) && (((int32_t)*(int64_t *)arg1 != 4 || (*(int16_t *)(arg1 + 0x28) != 0x12)))) {
    // WARNING: Could not recover jumptable at 0x00014000120e. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)(arg1 + 8) + 0x20))
                  (arg1 + 0x20, *(undefined8 *)(arg1 + 0x10), *(undefined8 *)(arg1 + 0x18));
        return;
    }
code_r0x0001400011ed:
    return;
}

// ============================================================
// Function: FUN_140001220
// Address: 0x140001220
// Size: 45 bytes
// ============================================================
void fcn.140001220(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f950(*(undefined8 *)(arg2 + 0x20));
    }
    return;
}

// ============================================================
// Function: FUN_140001250
// Address: 0x140001250
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001250(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 0xa8);
    if (iVar1 != 0) {
        (**(code **)(iVar1 + 0x18))(*(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0xb0));
    }
    return;
}

// ============================================================
// Function: FUN_140001290
// Address: 0x140001290
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001290(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001eee0(*(int64_t *)(arg2 + 0x28) + 0x48);
    return;
}

// ============================================================
// Function: FUN_1400012c0
// Address: 0x1400012c0
// Size: 45 bytes
// ============================================================
void fcn.1400012c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f100(*(undefined8 *)(arg2 + 0x20));
    }
    return;
}

// ============================================================
// Function: FUN_1400012f0
// Address: 0x1400012f0
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400012f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.1400037b0(*(undefined8 *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_140001310
// Address: 0x140001310
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001310(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001f030(*(undefined8 *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_140001330
// Address: 0x140001330
// Size: 45 bytes
// ============================================================
void fcn.140001330(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f950(*(undefined8 *)(arg2 + 0x20));
    }
    return;
}

// ============================================================
// Function: FUN_140001360
// Address: 0x140001360
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001360(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    fcn.14001efc0(iVar1 + 0x40);
    fcn.14001eee0(iVar1 + 0x48);
    fcn.1400037b0(iVar1);
    return;
}

// ============================================================
// Function: FUN_1400013a0
// Address: 0x1400013a0
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400013a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001eee0(*(int64_t *)(arg2 + 0x28) + 0x48);
    return;
}

// ============================================================
// Function: FUN_1400013d0
// Address: 0x1400013d0
// Size: 45 bytes
// ============================================================
void fcn.1400013d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f100(*(undefined8 *)(arg2 + 0x20));
    }
    return;
}

// ============================================================
// Function: FUN_140001400
// Address: 0x140001400
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001400(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.1400037b0(*(undefined8 *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_140001420
// Address: 0x140001420
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001420(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001f030(*(undefined8 *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_140001440
// Address: 0x140001440
// Size: 713 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001400016b9: Changing call to branch
// WARNING: Possible PIC construction at 0x000140001669: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00014000166e)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140001440(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t unaff_RBP;
    int64_t *piVar4;
    int64_t unaff_RSI;
    int64_t iVar5;
    uint64_t uVar6;
    undefined8 auStack_50 [2];
    undefined8 uStack_40;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar4 = &var_18h;
    var_18h = -2;
    var_8h = unaff_RBP;
    if (*(char *)(arg1 + 0x754) != '\x03') {
        if (*(char *)(arg1 + 0x754) != '\0') {
            return;
        }
        goto code_r0x000140014d30;
    }
    var_10h = unaff_RSI;
    // switch table (11 cases) at 0x14097a0c0
    switch(*(undefined *)(arg1 + 0x4c0)) {
    case 0:
        arg1 = arg1 + 0xa8;
        goto code_r0x000140014d30;
    default:
        return;
    case 3:
        auStack_50[0] = 0x1400014f5;
        var_20h = arg1;
        func_0x00014001d230(arg1 + 0x4c8);
        goto code_r0x0001400016f3;
    case 4:
        if (*(char *)(arg1 + 0x748) == '\x03') {
            auStack_50[0] = 0x1400015c3;
            var_20h = arg1;
            func_0x00014001f080(arg1 + 0x560);
        } else {
            var_20h = arg1;
            if (*(char *)(arg1 + 0x748) == '\0') {
                auStack_50[0] = 0x1400014cb;
                func_0x00014001d7a0(arg1 + 0x4c8);
            }
        }
        if (*(int32_t *)(var_20h + 0x220) == 3) {
            auStack_50[0] = 0x1400015e4;
            func_0x000140014c20(*(undefined8 *)(var_20h + 0x228));
        }
        goto code_r0x0001400016f3;
    case 5:
        auStack_50[0] = 0x140001550;
        var_20h = arg1;
        func_0x00014001d230(arg1 + 0x4c8);
        goto code_r0x000140001644;
    case 6:
        if (*(char *)(arg1 + 0x748) == '\x03') {
            auStack_50[0] = 0x140001627;
            var_20h = arg1;
            func_0x00014001f080(arg1 + 0x560);
        } else {
            var_20h = arg1;
            if (*(char *)(arg1 + 0x748) == '\0') {
                auStack_50[0] = 0x140001581;
                func_0x00014001d7a0(arg1 + 0x4c8);
            }
        }
        if (*(int32_t *)(var_20h + 0x2b8) == 3) {
            auStack_50[0] = 0x140001644;
            func_0x000140014c20(*(undefined8 *)(var_20h + 0x2c0));
        }
code_r0x000140001644:
        iVar3 = *(int64_t *)(var_20h + 0x208);
        if (iVar3 != 0) {
            iVar2 = *(int64_t *)(var_20h + 0x210);
            uVar6 = 1;
            *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
            auStack_50[0] = 0x14000166e;
            goto code_r0x0001404d3c50;
        }
        goto code_r0x0001400016f3;
    case 7:
        auStack_50[0] = 0x1400014e0;
        var_20h = arg1;
        func_0x00014001d230(arg1 + 0x4c8);
        break;
    case 8:
        if (*(char *)(arg1 + 0x748) == '\x03') {
            auStack_50[0] = 0x1400015f5;
            var_20h = arg1;
            func_0x00014001f080(arg1 + 0x560);
        } else {
            var_20h = arg1;
            if (*(char *)(arg1 + 0x748) == '\0') {
                auStack_50[0] = 0x140001526;
                func_0x00014001d7a0(arg1 + 0x4c8);
            }
        }
        if (*(int32_t *)(var_20h + 0x380) == 3) {
            auStack_50[0] = 0x140001616;
            func_0x000140014c20(*(undefined8 *)(var_20h + 0x388));
        }
        break;
    case 9:
        auStack_50[0] = 0x14000153b;
        var_20h = arg1;
        func_0x00014001d230(arg1 + 0x4c8);
        break;
    case 10:
        if (*(char *)(arg1 + 0x748) == '\x03') {
            auStack_50[0] = 0x14000167f;
            var_20h = arg1;
            func_0x00014001f080(arg1 + 0x560);
        } else {
            var_20h = arg1;
            if (*(char *)(arg1 + 0x748) == '\0') {
                auStack_50[0] = 0x1400015b2;
                func_0x00014001d7a0(arg1 + 0x4c8);
            }
        }
        if (*(int32_t *)(var_20h + 0x420) == 3) {
            auStack_50[0] = 0x14000169c;
            func_0x000140014c20(*(undefined8 *)(var_20h + 0x428));
        }
    }
    iVar2 = var_20h;
    iVar3 = *(int64_t *)(var_20h + 0x368);
    if (iVar3 == 0) {
        *(undefined *)(var_20h + 0x4c1) = 0;
        if (*(int64_t *)(var_20h + 0x350) != 0) {
            auStack_50[0] = 0x1400016e3;
            func_0x0001404d3c50(*(undefined8 *)(var_20h + 0x358), *(int64_t *)(var_20h + 0x350), 1);
        }
        *(undefined2 *)(iVar2 + 0x4c2) = 0;
        *(undefined *)(iVar2 + 0x4c4) = 0;
code_r0x0001400016f3:
        arg1 = var_20h + 0x150;
        unaff_RSI = var_10h;
code_r0x000140014d30:
        var_10h = -2;
        uStack_40 = 0x140014d4b;
        var_18h = arg1;
        func_0x00014001eac0();
        piVar4 = *(int64_t **)(var_18h + 0x88);
        LOCK();
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (*piVar4 == 0) {
            uStack_40 = 0x140014d6c;
            func_0x0001406c6890(var_18h + 0x88);
        }
        piVar4 = *(int64_t **)(var_18h + 0x90);
        LOCK();
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (*piVar4 != 0) {
            return;
        }
        iVar2 = *(int64_t *)(var_18h + 0x90);
        if (iVar2 != -1) {
            LOCK();
            piVar4 = (int64_t *)(iVar2 + 8);
            *piVar4 = *piVar4 + -1;
            UNLOCK();
            if (*piVar4 == 0) {
                iVar3 = 0x20;
                uVar6 = 8;
                piVar4 = (int64_t *)var_8h;
                goto code_r0x0001404d3c50;
            }
        }
        return;
    }
    iVar2 = *(int64_t *)(var_20h + 0x370);
    uVar6 = 1;
    *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
    auStack_50[0] = 0x1400016be;
    unaff_RSI = var_20h;
code_r0x0001404d3c50:
    *(int64_t **)((int64_t)*(undefined **)0x20 + -8) = piVar4;
    *(int64_t *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
    iVar5 = iVar2;
    if (0x10 < uVar6) {
        iVar5 = *(int64_t *)(iVar2 + -8);
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140901d3e;
    uVar1 = (*(code *)0xe5f2d8)(iVar2, iVar3);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar1, 0, iVar5);
    return;
}

// ============================================================
// Function: FUN_140001710
// Address: 0x140001710
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001710(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x28) + 0x420) == 3) {
        fcn.140001c40(*(int64_t *)(arg2 + 0x28) + 0x420);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_140001750
// Address: 0x140001750
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001750(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x28) + 0x2b8) == 3) {
        fcn.140001c40(*(int64_t *)(arg2 + 0x28) + 0x2b8);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_140001790
// Address: 0x140001790
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001790(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x28) + 0x380) == 3) {
        fcn.140001c40(*(int64_t *)(arg2 + 0x28) + 0x380);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_1400017d0
// Address: 0x1400017d0
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400017d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x28) + 0x220) == 3) {
        fcn.140001c40(*(int64_t *)(arg2 + 0x28) + 0x220);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_140001810
// Address: 0x140001810
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001810(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 0x208);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x210), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140001850
// Address: 0x140001850
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001850(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    if (*(int64_t *)(iVar1 + 0x368) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x370), *(int64_t *)(iVar1 + 0x368), 1);
    }
    *(undefined *)(iVar1 + 0x4c1) = 0;
    if (*(int64_t *)(iVar1 + 0x350) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x358), *(int64_t *)(iVar1 + 0x350), 1);
    }
    *(undefined2 *)(iVar1 + 0x4c2) = 0;
    *(undefined *)(iVar1 + 0x4c4) = 0;
    return;
}

// ============================================================
// Function: FUN_1400018c0
// Address: 0x1400018c0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400018c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140014d30(*(int64_t *)(arg2 + 0x28) + 0x150);
    return;
}

// ============================================================
// Function: FUN_1400018f0
// Address: 0x1400018f0
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400018f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    var_40h = 0x14000190b;
    func_0x000140416820();
    piVar2 = *(int64_t **)arg1;
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 != 0) {
        return;
    }
    var_28h = -2;
    var_30h = *(int64_t *)arg1;
    iVar1 = var_30h + 0x80;
    iVar6 = var_30h + 0x1a0;
    func_0x000140693790(&var_50h, iVar6, iVar1);
    if (((uint32_t)var_50h & 0xfffffffe) != 4) {
        do {
            if (((uint32_t)var_50h != 3) && (var_48h != 0)) {
                fcn.1404d3c50(var_40h, var_48h, 1);
            }
            func_0x000140693790(&var_50h, iVar6, iVar1);
        } while (((uint32_t)var_50h & 0xfffffffe) != 4);
    }
    iVar1 = var_30h;
    iVar6 = *(int64_t *)(var_30h + 0x1a8);
    do {
        iVar3 = *(int64_t *)(iVar6 + 0x408);
        fcn.1404d3c50(iVar6, 0x420, 8);
        iVar6 = iVar3;
    } while (iVar3 != 0);
    if (*(int64_t *)(iVar1 + 0x100) != 0) {
        (**(code **)(*(int64_t *)(iVar1 + 0x100) + 0x18))(*(undefined8 *)(var_30h + 0x108));
    }
    if (var_30h != -1) {
        LOCK();
        piVar2 = (int64_t *)(var_30h + 8);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            uVar4 = *(undefined8 *)(var_30h + -8);
            var_40h = 0x140901d3e;
            uVar5 = (*(code *)0xe5f2d8)(var_30h, 0x200);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_140001930
// Address: 0x140001930
// Size: 43 bytes
// ============================================================
void fcn.140001930(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.140682ab0(*(undefined8 *)(arg2 + 0x20));
    }
    return;
}

// ============================================================
// Function: FUN_140001960
// Address: 0x140001960
// Size: 79 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000140001983: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001960(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    int64_t *piVar5;
    int64_t *unaff_RBP;
    undefined8 unaff_RSI;
    int64_t **ppiVar6;
    undefined8 unaff_RDI;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar5 = &var_8h;
    var_10h = -2;
    var_18h = arg1;
    piVar1 = *(int64_t **)arg1;
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        *(int64_t **)0x20 = (BADSPACEBASE *)&var_40h;
        var_40h = 0x140001988;
        unaff_RBP = piVar5;
    } else {
        piVar1 = *(int64_t **)(arg1 + 8);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 != 0) {
            return;
        }
        arg1 = arg1 + 8;
    }
    *(int64_t **)((int64_t)*(undefined **)0x20 + -8) = unaff_RBP;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x18) = unaff_RDI;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x20) = unaff_RBX;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x28) = 0xfffffffffffffffe;
    arg1 = *(int64_t *)arg1;
    *(int64_t *)((int64_t)*(undefined **)0x20 + -0x30) = arg1;
    iVar2 = *(int64_t *)(arg1 + 0x20);
    *(int64_t *)((int64_t)*(undefined **)0x20 + -0x38) = iVar2;
    if (iVar2 != 0) {
        ppiVar6 = *(int64_t ***)(*(int64_t *)((int64_t)*(undefined **)0x20 + -0x30) + 0x18);
        iVar2 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x38);
        iVar4 = 1;
        *(int64_t ***)((int64_t)*(undefined **)0x20 + -0x48) = ppiVar6;
        do {
            *(int64_t *)((int64_t)*(undefined **)0x20 + -0x40) = iVar4;
            piVar1 = *ppiVar6;
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x70) = 0x14045e9ad;
                func_0x00014045f3c0(ppiVar6);
            }
            iVar4 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x40) + 1;
            ppiVar6 = ppiVar6 + 1;
        } while (*(int64_t *)((int64_t)*(undefined **)0x20 + -0x40) != iVar2);
    }
    iVar2 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x30);
    iVar4 = *(int64_t *)(iVar2 + 0x10);
    if (iVar4 != 0) {
        uVar3 = *(undefined8 *)(iVar2 + 0x18);
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x70) = 0x14045e9cf;
        fcn.1404d3c50(uVar3, iVar4 << 3, 8);
    }
    if (iVar2 != -1) {
        LOCK();
        piVar1 = (int64_t *)(iVar2 + 8);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = *(undefined8 *)((int64_t)*(undefined **)0x20 + -8);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) =
                 *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140901d3e;
            uVar3 = (*(code *)0xe5f2d8)(iVar2, 0x28);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar3, 0, iVar2);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1400019b0
// Address: 0x1400019b0
// Size: 48 bytes
// ============================================================
void fcn.1400019b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg2 + 0x20) + 8);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045e930(*(int64_t *)(arg2 + 0x20) + 8);
    }
    return;
}

// ============================================================
// Function: FUN_1400019e0
// Address: 0x1400019e0
// Size: 289 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.1400019e0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t **ppiVar6;
    bool bVar7;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 8);
    iVar2 = *(int64_t *)(arg1 + 0x10);
    if (iVar2 != 0) {
        iVar5 = 1;
        ppiVar6 = ppiVar1;
        do {
            piVar3 = *ppiVar6;
            LOCK();
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (*piVar3 == 0) {
                func_0x00014045f3c0(ppiVar6);
            }
            ppiVar6 = ppiVar6 + 1;
            bVar7 = iVar5 != iVar2;
            iVar5 = iVar5 + 1;
        } while (bVar7);
    }
    if (*(int64_t *)arg1 != 0) {
        fcn.1404d3c50(ppiVar1, *(int64_t *)arg1 << 3, 8);
    }
    ppiVar1 = *(int64_t ***)(arg1 + 0x20);
    iVar2 = *(int64_t *)(arg1 + 0x28);
    if (iVar2 != 0) {
        iVar5 = 1;
        ppiVar6 = ppiVar1;
        do {
            piVar3 = *ppiVar6;
            LOCK();
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (*piVar3 == 0) {
                func_0x00014045f3c0(ppiVar6);
            }
            ppiVar6 = ppiVar6 + 1;
            bVar7 = iVar5 != iVar2;
            iVar5 = iVar5 + 1;
        } while (bVar7);
    }
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        return;
    }
    uVar4 = (*(code *)0xe5f2d8)(ppiVar1, *(int64_t *)(arg1 + 0x18) << 3);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar4, 0, ppiVar1);
    return;
}

// ============================================================
// Function: FUN_140001b10
// Address: 0x140001b10
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140001b10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    iVar2 = *(int64_t *)(arg2 + 0x38);
    for (iVar4 = *(int64_t *)(arg2 + 0x20); iVar4 != iVar1; iVar4 = iVar4 + 1) {
        piVar3 = *(int64_t **)(iVar2 + iVar4 * 8);
        LOCK();
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (*piVar3 == 0) {
            fcn.14045f3c0(iVar2 + iVar4 * 8);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140001b60
// Address: 0x140001b60
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001b60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x38), **(int64_t **)(arg2 + 0x30) << 3, 8);
    }
    fcn.140001da0(*(int64_t *)(arg2 + 0x30) + 0x18);
    return;
}

// ============================================================
// Function: FUN_140001bb0
// Address: 0x140001bb0
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140001bb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    iVar2 = *(int64_t *)(arg2 + 0x38);
    for (iVar4 = *(int64_t *)(arg2 + 0x20); iVar4 != iVar1; iVar4 = iVar4 + 1) {
        piVar3 = *(int64_t **)(iVar2 + iVar4 * 8);
        LOCK();
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (*piVar3 == 0) {
            fcn.14045f3c0(iVar2 + iVar4 * 8);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140001c00
// Address: 0x140001c00
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001c00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 0x18);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x38), iVar1 << 3, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140001c60
// Address: 0x140001c60
// Size: 158 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140001c60(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    iVar2 = *(int64_t *)(arg1 + 0x10);
    var_38h = 0;
    iVar4 = iVar1 + 0x38;
    while (iVar2 != var_38h) {
        var_38h = var_38h + 1;
        (**(code **)(*(int64_t *)(iVar4 + -0x18) + 0x20))
                  (iVar4, *(undefined8 *)(iVar4 + -0x10), *(undefined8 *)(iVar4 + -8));
        iVar4 = iVar4 + 0x48;
    }
    if (*(int64_t *)arg1 == 0) {
        return;
    }
    uVar3 = (*(code *)0xe5f2d8)(iVar1, *(int64_t *)arg1 * 0x48);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar1);
    return;
}

// ============================================================
// Function: FUN_140001d00
// Address: 0x140001d00
// Size: 96 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001d00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    iVar2 = *(int64_t *)(arg2 + 0x38);
    for (iVar3 = *(int64_t *)(arg2 + 0x30); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        (**(code **)(*(int64_t *)(iVar2 + 0x20 + iVar3 * 0x48) + 0x20))
                  (iVar2 + iVar3 * 0x48 + 0x38, *(undefined8 *)(iVar2 + 0x28 + iVar3 * 0x48), 
                   *(undefined8 *)(iVar2 + 0x30 + iVar3 * 0x48));
    }
    return;
}

// ============================================================
// Function: FUN_140001d60
// Address: 0x140001d60
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140001d60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x28) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x38), **(int64_t **)(arg2 + 0x28) * 0x48, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140001da0
// Address: 0x140001da0
// Size: 160 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140001da0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t **ppiVar6;
    bool bVar7;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 8);
    iVar2 = *(int64_t *)(arg1 + 0x10);
    if (iVar2 != 0) {
        iVar5 = 1;
        ppiVar6 = ppiVar1;
        do {
            piVar3 = *ppiVar6;
            LOCK();
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (*piVar3 == 0) {
                fcn.14045f3c0(ppiVar6);
            }
            ppiVar6 = ppiVar6 + 1;
            bVar7 = iVar5 != iVar2;
            iVar5 = iVar5 + 1;
        } while (bVar7);
    }
    if (*(int64_t *)arg1 == 0) {
        return;
    }
    uVar4 = (*(code *)0xe5f2d8)(ppiVar1, *(int64_t *)arg1 << 3);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar4, 0, ppiVar1);
    return;
}

// ============================================================
// Function: FUN_140001e40
// Address: 0x140001e40
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001e40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    iVar2 = *(int64_t *)(arg2 + 0x38);
    for (iVar4 = *(int64_t *)(arg2 + 0x20); iVar4 != iVar1; iVar4 = iVar4 + 1) {
        piVar3 = *(int64_t **)(iVar2 + iVar4 * 8);
        LOCK();
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (*piVar3 == 0) {
            fcn.14045f3c0(iVar2 + iVar4 * 8);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140001e90
// Address: 0x140001e90
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140001e90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x28) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x38), **(int64_t **)(arg2 + 0x28) << 3, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140001ed0
// Address: 0x140001ed0
// Size: 145 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

undefined8 fcn.140001ed0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar1 = *(int64_t *)arg1;
    iVar2 = *(int64_t *)(arg1 + 8);
    iVar3 = *(int64_t *)(arg1 + 0x10);
    var_40h = 0;
    iVar5 = iVar2;
    while (iVar3 != var_40h) {
        var_40h = var_40h + 1;
        func_0x0001402727a0(iVar5);
        iVar5 = iVar5 + 0x60;
    }
    if (iVar1 == 0) {
        return 0;
    }
    uVar4 = (*(code *)0xe5f2d8)(iVar2, iVar1 * 0x60);
    // WARNING: Treating indirect jump as call
    uVar4 = (*(code *)0xe5f2ea)(uVar4, 0, iVar2);
    return uVar4;
}

// ============================================================
// Function: FUN_140001f70
// Address: 0x140001f70
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140001f70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    iVar2 = *(int64_t *)(arg2 + 0x38);
    for (iVar3 = *(int64_t *)(arg2 + 0x28); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140001fd0
// Address: 0x140001fd0
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140001fd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int64_t *)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x38), *(int64_t *)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140002010
// Address: 0x140002010
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140002010(int64_t arg1)
{
    code **ppcVar1;
    int64_t iVar2;
    int64_t iVar3;
    char cVar4;
    uint32_t uVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    code *pcVar8;
    int64_t *piVar9;
    code *pcVar10;
    undefined8 *puVar11;
    int64_t iVar12;
    bool bVar13;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 != 0) {
        if (((*(int32_t *)arg1 == 1) && (*(int64_t *)(arg1 + 8) != 0)) &&
           (piVar7 = *(int64_t **)(arg1 + 0x10), piVar7 != (int64_t *)0x0)) {
            ppcVar1 = *(code ***)(arg1 + 0x18);
            if (*ppcVar1 != (code *)0x0) {
                (**ppcVar1)(piVar7);
            }
            pcVar8 = ppcVar1[1];
            if (pcVar8 != (code *)0x0) {
                pcVar10 = ppcVar1[2];
                goto code_r0x0001404d3c50;
            }
        }
        return;
    }
    cVar4 = *(char *)(arg1 + 0x194);
    if (cVar4 != '\0') {
        if (cVar4 == '\x03') {
            if (*(char *)(arg1 + 0x6f8) == '\x03') {
                if (*(char *)(arg1 + 0x6f0) == '\x03') {
                    if (*(char *)(arg1 + 0x6e8) == '\x03') {
                        cVar4 = *(char *)(arg1 + 0x318);
                        if (cVar4 == '\x04') {
                            if (*(int32_t *)(arg1 + 0x5a8) != 2) {
                                if (*(int32_t *)(arg1 + 0x658) != 3) {
                                    func_0x00014001cc40(arg1 + 0x658);
                                    iVar2 = *(int64_t *)(arg1 + 0x6b8);
                                    if (iVar2 != 0) {
                                        func_0x0001404403b0();
                                        fcn.1404d3c50(iVar2, 0x20, 8);
                                    }
                                    if (*(int64_t *)(arg1 + 0x6c8) != 0) {
                                        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x6d0), *(int64_t *)(arg1 + 0x6c8), 1);
                                    }
                                }
                                func_0x0001400034f0(arg1 + 0x5a8);
                            }
                        } else if (cVar4 == '\x03') {
                            if (*(int32_t *)(arg1 + 800) != 2) {
                                func_0x000140231300();
                                func_0x00014001edb0(*(undefined8 *)(arg1 + 0x338), *(undefined8 *)(arg1 + 0x340));
                                func_0x00014001dc60(arg1 + 800);
                            }
                        } else if (cVar4 == '\0') {
                            func_0x000140231300();
                            func_0x00014001edb0(*(undefined8 *)(arg1 + 0x2c0), *(undefined8 *)(arg1 + 0x2c8));
                            func_0x00014001dc60(arg1 + 0x2a8);
                        }
                    } else if (*(char *)(arg1 + 0x6e8) == '\0') {
                        func_0x000140231300();
                        func_0x00014001edb0(*(undefined8 *)(arg1 + 0x250), *(undefined8 *)(arg1 + 600));
                        func_0x00014001dc60(arg1 + 0x238);
                    }
                } else if (*(char *)(arg1 + 0x6f0) == '\0') {
                    func_0x000140231300();
                    func_0x00014001edb0(*(undefined8 *)(arg1 + 0x1e0), *(undefined8 *)(arg1 + 0x1e8));
                    func_0x00014001dc60(arg1 + 0x1c8);
                }
            } else if (*(char *)(arg1 + 0x6f8) == '\0') {
                func_0x000140231300();
                func_0x00014001edb0(*(undefined8 *)(arg1 + 0x1b0), *(undefined8 *)(arg1 + 0x1b8));
                func_0x00014001dc60(arg1 + 0x198);
            }
        } else {
            if (cVar4 != '\x04') {
                return;
            }
            uVar6 = *(undefined8 *)(arg1 + 0x1a8);
            cVar4 = func_0x000140797af0(uVar6);
            if (cVar4 != '\0') {
                func_0x000140798840(uVar6);
            }
            *(undefined *)(arg1 + 0x195) = 0;
            func_0x000140416ae0();
            piVar7 = *(int64_t **)(arg1 + 0x1a0);
            LOCK();
            *piVar7 = *piVar7 + -1;
            UNLOCK();
            if (*piVar7 == 0) {
                fcn.14045f950();
            }
            piVar7 = *(int64_t **)(arg1 + 0x198);
            LOCK();
            *piVar7 = *piVar7 + -1;
            UNLOCK();
            if (*piVar7 == 0) {
                func_0x00014045faf0(arg1 + 0x198);
            }
            *(undefined *)(arg1 + 0x196) = 0;
        }
        *(undefined *)(arg1 + 0x197) = 0;
        iVar2 = *(int64_t *)(arg1 + 0x188);
        LOCK();
        piVar7 = (int64_t *)(iVar2 + 0x58);
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (*piVar7 == 0) {
            LOCK();
            bVar13 = *(char *)(iVar2 + 0x28) == '\0';
            if (bVar13) {
                *(char *)(iVar2 + 0x28) = '\x01';
            }
            UNLOCK();
            if (!bVar13) {
                func_0x0001409766f0(iVar2 + 0x28);
            }
            if ((**(uint64_t **)0x140e64720 & 0x7fffffffffffffff) == 0) {
                uVar5 = 0;
            } else {
                uVar5 = func_0x000140977200();
                uVar5 = uVar5 ^ 1;
            }
            *(undefined *)(iVar2 + 0x50) = 1;
            func_0x0001402d0210(iVar2 + 0x10, iVar2 + 0x28, uVar5);
        }
        piVar7 = *(int64_t **)(arg1 + 0x188);
        LOCK();
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (*piVar7 == 0) {
            fcn.14045f100();
        }
        piVar7 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (*piVar7 == 0) {
            func_0x00014045f1b0(arg1 + 0x180);
        }
        piVar7 = *(int64_t **)(arg1 + 0x178);
        LOCK();
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (*piVar7 == 0) {
            func_0x00014045e220(arg1 + 0x178);
        }
        func_0x00014001eac0();
        piVar7 = *(int64_t **)(arg1 + 0x168);
        LOCK();
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (*piVar7 == 0) {
            func_0x0001406c6890(arg1 + 0x168);
        }
        piVar7 = *(int64_t **)(arg1 + 0x170);
        LOCK();
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (*piVar7 != 0) {
            return;
        }
        piVar7 = *(int64_t **)(arg1 + 0x170);
        if (piVar7 != (int64_t *)0xffffffffffffffff) {
            LOCK();
            piVar9 = piVar7 + 1;
            *piVar9 = *piVar9 + -1;
            UNLOCK();
            if (*piVar9 == 0) {
                pcVar8 = (code *)0x20;
                pcVar10 = (code *)0x8;
code_r0x0001404d3c50:
                piVar9 = piVar7;
                if ((code *)0x10 < pcVar10) {
                    piVar9 = (int64_t *)piVar7[-1];
                }
                uVar6 = (*(code *)0xe5f2d8)(piVar7, pcVar8);
    // WARNING: Treating indirect jump as call
                (*(code *)0xe5f2ea)(uVar6, 0, piVar9);
                return;
            }
        }
        return;
    }
    func_0x000140231300();
    func_0x00014001edb0(*(undefined8 *)(arg1 + 0x20), *(undefined8 *)(arg1 + 0x28));
    func_0x00014001dc60(arg1 + 8);
    fcn.140014d30(arg1 + 0x30);
    piVar7 = *(int64_t **)(arg1 + 200);
    LOCK();
    *piVar7 = *piVar7 + -1;
    UNLOCK();
    if (*piVar7 == 0) {
        func_0x00014045e220(arg1 + 200);
    }
    piVar7 = *(int64_t **)(arg1 + 0xd0);
    LOCK();
    *piVar7 = *piVar7 + -1;
    UNLOCK();
    if (*piVar7 == 0) {
        func_0x00014045f1b0(arg1 + 0xd0);
    }
    iVar2 = *(int64_t *)(arg1 + 0xd8);
    LOCK();
    piVar7 = (int64_t *)(iVar2 + 0x58);
    *piVar7 = *piVar7 + -1;
    UNLOCK();
    if (*piVar7 == 0) {
        LOCK();
        bVar13 = *(char *)(iVar2 + 0x28) == '\0';
        if (bVar13) {
            *(char *)(iVar2 + 0x28) = '\x01';
        }
        UNLOCK();
        if (!bVar13) {
            func_0x0001409766f0(iVar2 + 0x28);
        }
        if ((**(uint64_t **)0x140e64720 & 0x7fffffffffffffff) == 0) {
            uVar5 = 0;
        } else {
            uVar5 = func_0x000140977200();
            uVar5 = uVar5 ^ 1;
        }
        *(undefined *)(iVar2 + 0x50) = 1;
        func_0x0001402d0210(iVar2 + 0x10, iVar2 + 0x28, uVar5);
    }
    piVar7 = *(int64_t **)(arg1 + 0xd8);
    LOCK();
    *piVar7 = *piVar7 + -1;
    UNLOCK();
    if (*piVar7 != 0) {
        return;
    }
    piVar7 = *(int64_t **)(arg1 + 0xd8);
    iVar2 = piVar7[3];
    if (iVar2 != 0) {
        iVar3 = piVar7[2];
        puVar11 = (undefined8 *)(iVar3 + 0x10);
        iVar12 = iVar2;
        do {
            if (puVar11[-1] != 0) {
                fcn.1404d3c50(*puVar11, puVar11[-1], 1);
            }
            puVar11 = puVar11 + 6;
            iVar12 = iVar12 + -1;
        } while (iVar12 != 0);
        fcn.1404d3c50(iVar3, iVar2 * 0x30, 8);
    }
    if (piVar7 != (int64_t *)0xffffffffffffffff) {
        LOCK();
        piVar9 = piVar7 + 1;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (*piVar9 == 0) {
            pcVar8 = (code *)0x88;
            pcVar10 = (code *)0x8;
            goto code_r0x0001404d3c50;
        }
    }
    return;
}

// ============================================================
// Function: FUN_140002090
// Address: 0x140002090
// Size: 51 bytes
// ============================================================
void fcn.140002090(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400020d0
// Address: 0x1400020d0
// Size: 379 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.1400020d0(int64_t arg1)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x13b0) == '\0') {
        func_0x00014001c990();
        iVar3 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar4 = *(int64_t *)(arg1 + 0x210);
        while (iVar3 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar4);
            iVar4 = iVar4 + 0x60;
        }
        goto code_r0x00014000220f;
    }
    if (*(char *)(arg1 + 0x13b0) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x13a8) == '\x03') {
        iVar3 = arg1 + 0xdd0;
code_r0x00014000219a:
        func_0x00014001d980(iVar3);
    } else if (*(char *)(arg1 + 0x13a8) == '\0') {
        iVar3 = arg1 + 0x7f8;
        goto code_r0x00014000219a;
    }
    func_0x00014001c990(arg1);
    iVar3 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar4 = *(int64_t *)(arg1 + 0x210);
    while (iVar3 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar4);
        iVar4 = iVar4 + 0x60;
    }
code_r0x00014000220f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar2 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140002250
// Address: 0x140002250
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140002250(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140002280
// Address: 0x140002280
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140002280(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1400022d0
// Address: 0x1400022d0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400022d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140002320
// Address: 0x140002320
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140002320(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140002360
// Address: 0x140002360
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140002360(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140002390
// Address: 0x140002390
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140002390(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1400023e0
// Address: 0x1400023e0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400023e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140002430
// Address: 0x140002430
// Size: 603 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140002430(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uVar2;
    char cVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x1638) == '\0') {
        fcn.14001c990();
        iVar1 = *(int64_t *)(arg1 + 0x218);
        var_30h = 0;
        iVar5 = *(int64_t *)(arg1 + 0x210);
        while (iVar1 != var_30h) {
            var_30h = var_30h + 1;
            func_0x0001402727a0(iVar5);
            iVar5 = iVar5 + 0x60;
        }
        goto code_r0x00014000264f;
    }
    if (*(char *)(arg1 + 0x1638) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x1630) == '\x03') {
        var_30h = arg1 + 0xf80;
        cVar3 = *(char *)(arg1 + 0x1050);
        if (cVar3 != '\x04') goto code_r0x000140002490;
code_r0x00014000256a:
        func_0x00014001e850(var_30h + 0x178);
code_r0x00014000258c:
        if (*(int64_t *)(var_30h + 0xb8) != 0) {
            fcn.1404d3c50(*(undefined8 *)(var_30h + 0xc0), *(int64_t *)(var_30h + 0xb8) << 2, 4);
        }
        *(undefined *)(var_30h + 0xd2) = 0;
        if (*(char *)(var_30h + 0xd1) != '\0') {
            fcn.140014d30(var_30h + 0xd8);
        }
        *(undefined *)(var_30h + 0xd1) = 0;
    } else if (*(char *)(arg1 + 0x1630) == '\0') {
        var_30h = arg1 + 0x8d0;
        cVar3 = *(char *)(arg1 + 0x9a0);
        if (cVar3 == '\x04') goto code_r0x00014000256a;
code_r0x000140002490:
        if (cVar3 == '\x03') {
            func_0x00014001d980(var_30h + 0xd8);
            goto code_r0x00014000258c;
        }
        if (cVar3 == '\0') {
            fcn.140014d30(var_30h);
            if (*(int64_t *)(var_30h + 0x98) != 0) {
                fcn.1404d3c50(*(undefined8 *)(var_30h + 0xa0), *(int64_t *)(var_30h + 0x98) << 2, 4);
            }
        }
    }
    fcn.14001c990(arg1);
    iVar1 = *(int64_t *)(arg1 + 0x218);
    var_30h = 0;
    iVar5 = *(int64_t *)(arg1 + 0x210);
    while (iVar1 != var_30h) {
        var_30h = var_30h + 1;
        func_0x0001402727a0(iVar5);
        iVar5 = iVar5 + 0x60;
    }
code_r0x00014000264f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x210);
    uVar4 = (*(code *)0xe5f2d8)(uVar2, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar4, 0, uVar2);
    return;
}

