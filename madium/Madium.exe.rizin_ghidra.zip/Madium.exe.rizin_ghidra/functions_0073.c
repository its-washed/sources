// Chunk 73 - 50 functions

// ============================================================
// Function: FUN_140052f10
// Address: 0x140052f10
// Size: 55 bytes
// ============================================================
undefined8 fcn.140052f10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140052d47;
}

// ============================================================
// Function: FUN_140052f50
// Address: 0x140052f50
// Size: 25 bytes
// ============================================================
void fcn.140052f50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140052f70
// Address: 0x140052f70
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140052f70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140052dc7;
}

// ============================================================
// Function: FUN_140052fb0
// Address: 0x140052fb0
// Size: 25 bytes
// ============================================================
void fcn.140052fb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140052fd0
// Address: 0x140052fd0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140052fd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140052dc7;
}

// ============================================================
// Function: FUN_140053010
// Address: 0x140053010
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140053010(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140053060
// Address: 0x140053060
// Size: 505 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3088h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3078h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1840h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3090h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_beh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1640h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcc00f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1630h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1638h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2758h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_187h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_aeh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5cb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ab8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ac0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ae0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5aa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5aa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ad0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1208h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2170h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800f6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2430h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5258h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2800h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_30d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_30c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ba8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ba0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1688h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcc00f9h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7afh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3898h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7cfh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Removing arg arg_1d40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1690h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2100h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1680h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_748h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be0h because it doesn't fit into ProtoModel

void fcn.140053060(int64_t var_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_128h, int64_t arg_130h,
                  int64_t arg_138h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h, int64_t arg_160h,
                  int64_t arg_168h, int64_t arg_170h, int64_t arg_178h, int64_t arg_198h, int64_t arg_1b8h,
                  int64_t arg_1c0h, int64_t arg_1c8h, int64_t arg_1d0h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_3bd6b798h;
    int64_t var_7e8h;
    int64_t var_7e0h;
    int64_t var_790h;
    int64_t var_698h;
    int64_t var_688h;
    int64_t var_680h;
    int64_t var_360h;
    int64_t var_348h;
    int64_t var_1a8h;
    int64_t var_150h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_8h;
    
    var_20h = 0x14005306d;
    iVar2 = func_0x00014094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&var_20h + -iVar2) = 0x14005308b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014005309c. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (18 cases) at 0x14097b0e4
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b0e4) + 0x14097b0e4))();
    return;
}

// ============================================================
// Function: FUN_140053260
// Address: 0x140053260
// Size: 37 bytes
// ============================================================
void fcn.140053260(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140053290
// Address: 0x140053290
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140053290(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011da20(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_1400532d0
// Address: 0x1400532d0
// Size: 25 bytes
// ============================================================
void fcn.1400532d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400532f0
// Address: 0x1400532f0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400532f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140053187;
}

// ============================================================
// Function: FUN_140053330
// Address: 0x140053330
// Size: 25 bytes
// ============================================================
void fcn.140053330(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140053350
// Address: 0x140053350
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140053350(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140053187;
}

// ============================================================
// Function: FUN_140053390
// Address: 0x140053390
// Size: 25 bytes
// ============================================================
void fcn.140053390(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400533b0
// Address: 0x1400533b0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400533b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140053207;
}

// ============================================================
// Function: FUN_1400533f0
// Address: 0x1400533f0
// Size: 25 bytes
// ============================================================
void fcn.1400533f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140053410
// Address: 0x140053410
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140053410(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140053207;
}

// ============================================================
// Function: FUN_140053450
// Address: 0x140053450
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140053450(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400534a0
// Address: 0x1400534a0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel

void fcn.1400534a0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400534ad;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000013b0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x1400534cb;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x0001400534dc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b104) + 0x14097b104))();
    return;
}

// ============================================================
// Function: FUN_1400536a0
// Address: 0x1400536a0
// Size: 37 bytes
// ============================================================
void fcn.1400536a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1400536d0
// Address: 0x1400536d0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400536d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x9e8) = 2;
    fcn.14011e3a0(*(undefined8 *)(arg2 + 0x13c0), arg2 + 0x9e8);
    return;
}

// ============================================================
// Function: FUN_140053710
// Address: 0x140053710
// Size: 25 bytes
// ============================================================
void fcn.140053710(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140053730
// Address: 0x140053730
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.140053730(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13d8));
    *(undefined8 *)(arg2 + 0x13a8) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x1400535c7;
}

// ============================================================
// Function: FUN_140053770
// Address: 0x140053770
// Size: 25 bytes
// ============================================================
void fcn.140053770(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140053790
// Address: 0x140053790
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.140053790(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x13a8) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x1400535c7;
}

// ============================================================
// Function: FUN_1400537d0
// Address: 0x1400537d0
// Size: 25 bytes
// ============================================================
void fcn.1400537d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400537f0
// Address: 0x1400537f0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.1400537f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13d0));
    *(undefined8 *)(arg2 + 0x13c0) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x140053647;
}

// ============================================================
// Function: FUN_140053830
// Address: 0x140053830
// Size: 25 bytes
// ============================================================
void fcn.140053830(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140053850
// Address: 0x140053850
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.140053850(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x13c0) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x140053647;
}

// ============================================================
// Function: FUN_140053890
// Address: 0x140053890
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1340h because it doesn't fit into ProtoModel

void fcn.140053890(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x13b8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x13c0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x13b8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400538e0
// Address: 0x1400538e0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_17d0h because it doesn't fit into ProtoModel

void fcn.1400538e0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400538ed;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000017d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14005390b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014005391c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b124) + 0x14097b124))();
    return;
}

// ============================================================
// Function: FUN_140053ae0
// Address: 0x140053ae0
// Size: 37 bytes
// ============================================================
void fcn.140053ae0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140053b10
// Address: 0x140053b10
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_b78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140053b10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xbf8) = 2;
    fcn.14011f4e0(*(undefined8 *)(arg2 + 0x17e0), arg2 + 0xbf8);
    return;
}

// ============================================================
// Function: FUN_140053b50
// Address: 0x140053b50
// Size: 25 bytes
// ============================================================
void fcn.140053b50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140053b70
// Address: 0x140053b70
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1748h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1758h because it doesn't fit into ProtoModel

undefined8 fcn.140053b70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x17f8));
    *(undefined8 *)(arg2 + 0x17c8) = uVar1;
    *(int64_t *)(arg2 + 0x17d8) = iVar2;
    return 0x140053a07;
}

// ============================================================
// Function: FUN_140053bb0
// Address: 0x140053bb0
// Size: 25 bytes
// ============================================================
void fcn.140053bb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140053bd0
// Address: 0x140053bd0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1748h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1758h because it doesn't fit into ProtoModel

undefined8 fcn.140053bd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x17c8) = uVar1;
    *(int64_t *)(arg2 + 0x17d8) = iVar2;
    return 0x140053a07;
}

// ============================================================
// Function: FUN_140053c10
// Address: 0x140053c10
// Size: 25 bytes
// ============================================================
void fcn.140053c10(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140053c30
// Address: 0x140053c30
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1758h because it doesn't fit into ProtoModel

undefined8 fcn.140053c30(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x17f0));
    *(undefined8 *)(arg2 + 0x17e0) = uVar1;
    *(int64_t *)(arg2 + 0x17d8) = iVar2;
    return 0x140053a87;
}

// ============================================================
// Function: FUN_140053c70
// Address: 0x140053c70
// Size: 25 bytes
// ============================================================
void fcn.140053c70(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140053c90
// Address: 0x140053c90
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1758h because it doesn't fit into ProtoModel

undefined8 fcn.140053c90(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x17e0) = uVar1;
    *(int64_t *)(arg2 + 0x17d8) = iVar2;
    return 0x140053a87;
}

// ============================================================
// Function: FUN_140053cd0
// Address: 0x140053cd0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1758h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1760h because it doesn't fit into ProtoModel

void fcn.140053cd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x17d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x17e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x17d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140053d20
// Address: 0x140053d20
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.140053d20(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140053d2d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140053d4b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140053d5c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b144) + 0x14097b144))();
    return;
}

// ============================================================
// Function: FUN_140053f20
// Address: 0x140053f20
// Size: 37 bytes
// ============================================================
void fcn.140053f20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140053f50
// Address: 0x140053f50
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140053f50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140053f90
// Address: 0x140053f90
// Size: 25 bytes
// ============================================================
void fcn.140053f90(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140053fb0
// Address: 0x140053fb0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140053fb0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140053e47;
}

// ============================================================
// Function: FUN_140053ff0
// Address: 0x140053ff0
// Size: 25 bytes
// ============================================================
void fcn.140053ff0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140054010
// Address: 0x140054010
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140054010(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140053e47;
}

// ============================================================
// Function: FUN_140054050
// Address: 0x140054050
// Size: 25 bytes
// ============================================================
void fcn.140054050(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

