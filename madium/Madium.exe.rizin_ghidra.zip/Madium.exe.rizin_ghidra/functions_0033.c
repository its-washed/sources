// Chunk 33 - 50 functions

// ============================================================
// Function: FUN_140026f10
// Address: 0x140026f10
// Size: 44 bytes
// ============================================================
void fcn.140026f10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.1400124f0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140026f40
// Address: 0x140026f40
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel

void fcn.140026f40(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1cd8);
    puVar2 = *(undefined8 **)(arg2 + 0x1d08);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1d10) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1d00), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1d10) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1cf0);
    uVar4 = *(undefined4 *)(arg2 + 0x1ce4);
    uVar5 = *(undefined4 *)(arg2 + 0x1ce8);
    uVar6 = *(undefined4 *)(arg2 + 0x1cec);
    *puVar1 = *(undefined4 *)(arg2 + 0x1ce0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140026fb0
// Address: 0x140026fb0
// Size: 255 bytes
// ============================================================
void fcn.140026fb0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_f0h;
    int64_t var_98h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0xc0);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_f0h, arg1 + 0x30, 0x90);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_f0h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_1400270b0
// Address: 0x1400270b0
// Size: 44 bytes
// ============================================================
void fcn.1400270b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.1400036f0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_1400270e0
// Address: 0x1400270e0
// Size: 87 bytes
// ============================================================
void fcn.1400270e0(undefined8 placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h,
                  int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0xb8);
    puVar2 = *(undefined8 **)(arg2 + 0xe8);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0xf0) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xe0), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0xf0) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0xd0);
    uVar4 = *(undefined4 *)(arg2 + 0xc4);
    uVar5 = *(undefined4 *)(arg2 + 200);
    uVar6 = *(undefined4 *)(arg2 + 0xcc);
    *puVar1 = *(undefined4 *)(arg2 + 0xc0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140027140
// Address: 0x140027140
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1387h because it doesn't fit into ProtoModel

void fcn.140027140(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002714c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001388 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001368 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002716e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001387)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027194;
        func_0x00014011da20(*(int64_t *)(&stack0x00001368 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001387)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400271b4;
        func_0x000140796b10(*(int64_t *)(&stack0x00001368 + iVar4) + 0x1380, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001368 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400271c3;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400271cf;
        func_0x0001400192b0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140027240
// Address: 0x140027240
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel

undefined8 fcn.140027240(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13a0));
    *(undefined8 *)(arg2 + 0x1380) = uVar1;
    *(int64_t *)(arg2 + 5000) = iVar2;
    return 0x1400271da;
}

// ============================================================
// Function: FUN_140027280
// Address: 0x140027280
// Size: 24 bytes
// ============================================================
void fcn.140027280(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400272a0
// Address: 0x1400272a0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel

undefined8 fcn.1400272a0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1380) = uVar1;
    *(int64_t *)(arg2 + 5000) = iVar2;
    return 0x1400271da;
}

// ============================================================
// Function: FUN_1400272e0
// Address: 0x1400272e0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel

void fcn.1400272e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 5000) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1380), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 5000) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140027330
// Address: 0x140027330
// Size: 24 bytes
// ============================================================
void fcn.140027330(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140027350
// Address: 0x140027350
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2948h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2947h because it doesn't fit into ProtoModel

void fcn.140027350(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002735c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00002948 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00002928 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002737e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00002947)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400273a4;
        func_0x00014011de70(*(int64_t *)(&stack0x00002928 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00002947)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400273c4;
        func_0x000140796b10(*(int64_t *)(&stack0x00002928 + iVar4) + 0x2940, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00002928 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400273d3;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400273df;
        func_0x000140013fc0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140027450
// Address: 0x140027450
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_28e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28c8h because it doesn't fit into ProtoModel

undefined8 fcn.140027450(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2960));
    *(undefined8 *)(arg2 + 0x2940) = uVar1;
    *(int64_t *)(arg2 + 0x2948) = iVar2;
    return 0x1400273ea;
}

// ============================================================
// Function: FUN_140027490
// Address: 0x140027490
// Size: 24 bytes
// ============================================================
void fcn.140027490(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400274b0
// Address: 0x1400274b0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_28c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28c8h because it doesn't fit into ProtoModel

undefined8 fcn.1400274b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2940) = uVar1;
    *(int64_t *)(arg2 + 0x2948) = iVar2;
    return 0x1400273ea;
}

// ============================================================
// Function: FUN_1400274f0
// Address: 0x1400274f0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_28c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28c0h because it doesn't fit into ProtoModel

void fcn.1400274f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x2948) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x2940), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x2948) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140027540
// Address: 0x140027540
// Size: 24 bytes
// ============================================================
void fcn.140027540(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140027560
// Address: 0x140027560
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff7h because it doesn't fit into ProtoModel

void fcn.140027560(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002756c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00000ff8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00000fd8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002758e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00000ff7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400275b4;
        func_0x00014011e680(*(int64_t *)(&stack0x00000fd8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00000ff7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400275d4;
        func_0x000140796b10(*(int64_t *)(&stack0x00000fd8 + iVar4) + 0xff0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00000fd8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400275e3;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400275ef;
        func_0x0001400177e0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140027660
// Address: 0x140027660
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel

undefined8 fcn.140027660(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1010));
    *(undefined8 *)(arg2 + 0xff0) = uVar1;
    *(int64_t *)(arg2 + 0xff8) = iVar2;
    return 0x1400275fa;
}

// ============================================================
// Function: FUN_1400276a0
// Address: 0x1400276a0
// Size: 24 bytes
// ============================================================
void fcn.1400276a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400276c0
// Address: 0x1400276c0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel

undefined8 fcn.1400276c0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xff0) = uVar1;
    *(int64_t *)(arg2 + 0xff8) = iVar2;
    return 0x1400275fa;
}

// ============================================================
// Function: FUN_140027700
// Address: 0x140027700
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel

void fcn.140027700(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xff8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xff0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xff8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140027750
// Address: 0x140027750
// Size: 24 bytes
// ============================================================
void fcn.140027750(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140027770
// Address: 0x140027770
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.140027770(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_f70h;
    int64_t var_f18h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_f70h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011d460(var_40h + 0x20, &var_f70h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xf60, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x000140016fa0(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140027860
// Address: 0x140027860
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.140027860(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xf80));
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x140027804;
}

// ============================================================
// Function: FUN_1400278a0
// Address: 0x1400278a0
// Size: 24 bytes
// ============================================================
void fcn.1400278a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400278c0
// Address: 0x1400278c0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.1400278c0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x140027804;
}

// ============================================================
// Function: FUN_140027900
// Address: 0x140027900
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel

void fcn.140027900(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xf68) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf60), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xf68) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140027950
// Address: 0x140027950
// Size: 24 bytes
// ============================================================
void fcn.140027950(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140027970
// Address: 0x140027970
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1507h because it doesn't fit into ProtoModel

void fcn.140027970(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002797c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001508 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x000014e8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002799e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001507)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400279c4;
        func_0x00014011f930(*(int64_t *)(&stack0x000014e8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001507)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400279e4;
        func_0x000140796b10(*(int64_t *)(&stack0x000014e8 + iVar4) + 0x1500, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x000014e8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400279f3;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1400279ff;
        func_0x000140019f10(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140027a70
// Address: 0x140027a70
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_14a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel

undefined8 fcn.140027a70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1520));
    *(undefined8 *)(arg2 + 0x1500) = uVar1;
    *(int64_t *)(arg2 + 0x1508) = iVar2;
    return 0x140027a0a;
}

// ============================================================
// Function: FUN_140027ab0
// Address: 0x140027ab0
// Size: 24 bytes
// ============================================================
void fcn.140027ab0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140027ad0
// Address: 0x140027ad0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel

undefined8 fcn.140027ad0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1500) = uVar1;
    *(int64_t *)(arg2 + 0x1508) = iVar2;
    return 0x140027a0a;
}

// ============================================================
// Function: FUN_140027b10
// Address: 0x140027b10
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel

void fcn.140027b10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1508) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1500), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1508) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140027b60
// Address: 0x140027b60
// Size: 24 bytes
// ============================================================
void fcn.140027b60(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140027b80
// Address: 0x140027b80
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1387h because it doesn't fit into ProtoModel

void fcn.140027b80(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x140027b8c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001388 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001368 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027bae;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001387)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027bd4;
        func_0x00014011d740(*(int64_t *)(&stack0x00001368 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001387)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027bf4;
        func_0x000140796b10(*(int64_t *)(&stack0x00001368 + iVar4) + 0x1380, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001368 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027c03;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027c0f;
        func_0x0001400190a0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140027c80
// Address: 0x140027c80
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel

undefined8 fcn.140027c80(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13a0));
    *(undefined8 *)(arg2 + 0x1380) = uVar1;
    *(int64_t *)(arg2 + 5000) = iVar2;
    return 0x140027c1a;
}

// ============================================================
// Function: FUN_140027cc0
// Address: 0x140027cc0
// Size: 24 bytes
// ============================================================
void fcn.140027cc0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140027ce0
// Address: 0x140027ce0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel

undefined8 fcn.140027ce0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1380) = uVar1;
    *(int64_t *)(arg2 + 5000) = iVar2;
    return 0x140027c1a;
}

// ============================================================
// Function: FUN_140027d20
// Address: 0x140027d20
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel

void fcn.140027d20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 5000) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1380), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 5000) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140027d70
// Address: 0x140027d70
// Size: 24 bytes
// ============================================================
void fcn.140027d70(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140027d90
// Address: 0x140027d90
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1387h because it doesn't fit into ProtoModel

void fcn.140027d90(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x140027d9c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001388 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001368 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027dbe;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001387)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027de4;
        func_0x00014011da20(*(int64_t *)(&stack0x00001368 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001387)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027e04;
        func_0x000140796b10(*(int64_t *)(&stack0x00001368 + iVar4) + 0x1380, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001368 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027e13;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027e1f;
        func_0x000140016340(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_140027e90
// Address: 0x140027e90
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel

undefined8 fcn.140027e90(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13a0));
    *(undefined8 *)(arg2 + 0x1380) = uVar1;
    *(int64_t *)(arg2 + 5000) = iVar2;
    return 0x140027e2a;
}

// ============================================================
// Function: FUN_140027ed0
// Address: 0x140027ed0
// Size: 24 bytes
// ============================================================
void fcn.140027ed0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140027ef0
// Address: 0x140027ef0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel

undefined8 fcn.140027ef0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1380) = uVar1;
    *(int64_t *)(arg2 + 5000) = iVar2;
    return 0x140027e2a;
}

// ============================================================
// Function: FUN_140027f30
// Address: 0x140027f30
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel

void fcn.140027f30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 5000) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1380), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 5000) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140027f80
// Address: 0x140027f80
// Size: 24 bytes
// ============================================================
void fcn.140027f80(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140027fa0
// Address: 0x140027fa0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c87h because it doesn't fit into ProtoModel

void fcn.140027fa0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x140027fac;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001c88 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001c68 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027fce;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001c87)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140027ff4;
        func_0x00014011faa0(*(int64_t *)(&stack0x00001c68 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001c87)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028014;
        func_0x000140796b10(*(int64_t *)(&stack0x00001c68 + iVar4) + 0x1c80, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001c68 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140028023;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002802f;
        func_0x0001400150b0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_1400280a0
// Address: 0x1400280a0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c08h because it doesn't fit into ProtoModel

undefined8 fcn.1400280a0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1ca0));
    *(undefined8 *)(arg2 + 0x1c80) = uVar1;
    *(int64_t *)(arg2 + 0x1c88) = iVar2;
    return 0x14002803a;
}

// ============================================================
// Function: FUN_1400280e0
// Address: 0x1400280e0
// Size: 24 bytes
// ============================================================
void fcn.1400280e0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

