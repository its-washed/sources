// Chunk 41 - 50 functions

// ============================================================
// Function: FUN_14002f820
// Address: 0x14002f820
// Size: 53 bytes
// ============================================================
undefined8 fcn.14002f820(undefined8 placeholder_0, int64_t arg2, int64_t arg_150h, int64_t arg_158h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1d0) = uVar1;
    *(int64_t *)(arg2 + 0x1d8) = iVar2;
    return 0x14002f764;
}

// ============================================================
// Function: FUN_14002f860
// Address: 0x14002f860
// Size: 65 bytes
// ============================================================
void fcn.14002f860(undefined8 placeholder_0, int64_t arg2, int64_t arg_150h, int64_t arg_158h)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1d0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002f8b0
// Address: 0x14002f8b0
// Size: 24 bytes
// ============================================================
void fcn.14002f8b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002f8d0
// Address: 0x14002f8d0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002f8d0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_ee0h;
    int64_t var_e88h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_ee0h._0_4_ = 2;
        var_21h = uVar2;
        func_0x000140120140(var_40h + 0x20, &var_ee0h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xed0, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x000140018a70(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002f9c0
// Address: 0x14002f9c0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e58h because it doesn't fit into ProtoModel

undefined8 fcn.14002f9c0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xef0));
    *(undefined8 *)(arg2 + 0xed0) = uVar1;
    *(int64_t *)(arg2 + 0xed8) = iVar2;
    return 0x14002f964;
}

// ============================================================
// Function: FUN_14002fa00
// Address: 0x14002fa00
// Size: 24 bytes
// ============================================================
void fcn.14002fa00(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002fa20
// Address: 0x14002fa20
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e58h because it doesn't fit into ProtoModel

undefined8 fcn.14002fa20(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xed0) = uVar1;
    *(int64_t *)(arg2 + 0xed8) = iVar2;
    return 0x14002f964;
}

// ============================================================
// Function: FUN_14002fa60
// Address: 0x14002fa60
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel

void fcn.14002fa60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xed8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xed0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xed8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002fab0
// Address: 0x14002fab0
// Size: 24 bytes
// ============================================================
void fcn.14002fab0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002fad0
// Address: 0x14002fad0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bf7h because it doesn't fit into ProtoModel

void fcn.14002fad0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002fadc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001bf8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001bd8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002fafe;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001bf7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002fb24;
        func_0x0001401202b0(*(int64_t *)(&stack0x00001bd8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001bf7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002fb44;
        func_0x000140796b10(*(int64_t *)(&stack0x00001bd8 + iVar4) + 0x1bf0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001bd8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002fb53;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002fb5f;
        func_0x0001400152c0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002fbd0
// Address: 0x14002fbd0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1b90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b78h because it doesn't fit into ProtoModel

undefined8 fcn.14002fbd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1c10));
    *(undefined8 *)(arg2 + 0x1bf0) = uVar1;
    *(int64_t *)(arg2 + 0x1bf8) = iVar2;
    return 0x14002fb6a;
}

// ============================================================
// Function: FUN_14002fc10
// Address: 0x14002fc10
// Size: 24 bytes
// ============================================================
void fcn.14002fc10(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002fc30
// Address: 0x14002fc30
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1b70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b78h because it doesn't fit into ProtoModel

undefined8 fcn.14002fc30(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1bf0) = uVar1;
    *(int64_t *)(arg2 + 0x1bf8) = iVar2;
    return 0x14002fb6a;
}

// ============================================================
// Function: FUN_14002fc70
// Address: 0x14002fc70
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1b78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b70h because it doesn't fit into ProtoModel

void fcn.14002fc70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1bf8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1bf0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1bf8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002fcc0
// Address: 0x14002fcc0
// Size: 24 bytes
// ============================================================
void fcn.14002fcc0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002fce0
// Address: 0x14002fce0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002fce0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_a60h;
    int64_t var_a08h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_a60h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011d5d0(var_40h + 0x20, &var_a60h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xa50, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x000140018020(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002fdd0
// Address: 0x14002fdd0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_9f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel

undefined8 fcn.14002fdd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xa70));
    *(undefined8 *)(arg2 + 0xa50) = uVar1;
    *(int64_t *)(arg2 + 0xa58) = iVar2;
    return 0x14002fd74;
}

// ============================================================
// Function: FUN_14002fe10
// Address: 0x14002fe10
// Size: 24 bytes
// ============================================================
void fcn.14002fe10(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002fe30
// Address: 0x14002fe30
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel

undefined8 fcn.14002fe30(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xa50) = uVar1;
    *(int64_t *)(arg2 + 0xa58) = iVar2;
    return 0x14002fd74;
}

// ============================================================
// Function: FUN_14002fe70
// Address: 0x14002fe70
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel

void fcn.14002fe70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xa58) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xa50), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xa58) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002fec0
// Address: 0x14002fec0
// Size: 24 bytes
// ============================================================
void fcn.14002fec0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002fee0
// Address: 0x14002fee0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002fee0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_f70h;
    int64_t var_f18h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_f70h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011e960(var_40h + 0x20, &var_f70h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xf60, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014001a960(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002ffd0
// Address: 0x14002ffd0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.14002ffd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xf80));
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x14002ff74;
}

// ============================================================
// Function: FUN_140030010
// Address: 0x140030010
// Size: 24 bytes
// ============================================================
void fcn.140030010(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140030030
// Address: 0x140030030
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.140030030(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x14002ff74;
}

// ============================================================
// Function: FUN_140030070
// Address: 0x140030070
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel

void fcn.140030070(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xf68) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf60), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xf68) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400300c0
// Address: 0x1400300c0
// Size: 24 bytes
// ============================================================
void fcn.1400300c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400300e0
// Address: 0x1400300e0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.1400300e0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_ee0h;
    int64_t var_e88h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_ee0h._0_4_ = 2;
        var_21h = uVar2;
        func_0x000140120140(var_40h + 0x20, &var_ee0h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xed0, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x0001400154d0(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_1400301d0
// Address: 0x1400301d0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e58h because it doesn't fit into ProtoModel

undefined8 fcn.1400301d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xef0));
    *(undefined8 *)(arg2 + 0xed0) = uVar1;
    *(int64_t *)(arg2 + 0xed8) = iVar2;
    return 0x140030174;
}

// ============================================================
// Function: FUN_140030210
// Address: 0x140030210
// Size: 24 bytes
// ============================================================
void fcn.140030210(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140030230
// Address: 0x140030230
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e58h because it doesn't fit into ProtoModel

undefined8 fcn.140030230(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xed0) = uVar1;
    *(int64_t *)(arg2 + 0xed8) = iVar2;
    return 0x140030174;
}

// ============================================================
// Function: FUN_140030270
// Address: 0x140030270
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel

void fcn.140030270(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xed8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xed0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xed8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400302c0
// Address: 0x1400302c0
// Size: 24 bytes
// ============================================================
void fcn.1400302c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400302e0
// Address: 0x1400302e0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.1400302e0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_a00h;
    int64_t var_9a8h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_a00h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011dd00(var_40h + 0x20, &var_a00h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0x9f0, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x000140017e10(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_1400303d0
// Address: 0x1400303d0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_990h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel

undefined8 fcn.1400303d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xa10));
    *(undefined8 *)(arg2 + 0x9f0) = uVar1;
    *(int64_t *)(arg2 + 0x9f8) = iVar2;
    return 0x140030374;
}

// ============================================================
// Function: FUN_140030410
// Address: 0x140030410
// Size: 24 bytes
// ============================================================
void fcn.140030410(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140030430
// Address: 0x140030430
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel

undefined8 fcn.140030430(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x9f0) = uVar1;
    *(int64_t *)(arg2 + 0x9f8) = iVar2;
    return 0x140030374;
}

// ============================================================
// Function: FUN_140030470
// Address: 0x140030470
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel

void fcn.140030470(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x9f8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x9f0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x9f8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400304c0
// Address: 0x1400304c0
// Size: 24 bytes
// ============================================================
void fcn.1400304c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400304e0
// Address: 0x1400304e0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1507h because it doesn't fit into ProtoModel

void fcn.1400304e0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1400304ec;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001508 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x000014e8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14003050e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001507)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140030534;
        func_0x00014011f930(*(int64_t *)(&stack0x000014e8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001507)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140030554;
        func_0x000140796b10(*(int64_t *)(&stack0x000014e8 + iVar4) + 0x1500, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x000014e8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140030563;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14003056f;
        func_0x000140015b00(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_1400305e0
// Address: 0x1400305e0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_14a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel

undefined8 fcn.1400305e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1520));
    *(undefined8 *)(arg2 + 0x1500) = uVar1;
    *(int64_t *)(arg2 + 0x1508) = iVar2;
    return 0x14003057a;
}

// ============================================================
// Function: FUN_140030620
// Address: 0x140030620
// Size: 24 bytes
// ============================================================
void fcn.140030620(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140030640
// Address: 0x140030640
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel

undefined8 fcn.140030640(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1500) = uVar1;
    *(int64_t *)(arg2 + 0x1508) = iVar2;
    return 0x14003057a;
}

// ============================================================
// Function: FUN_140030680
// Address: 0x140030680
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel

void fcn.140030680(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1508) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1500), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1508) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400306d0
// Address: 0x1400306d0
// Size: 24 bytes
// ============================================================
void fcn.1400306d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400306f0
// Address: 0x1400306f0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1ce8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce7h because it doesn't fit into ProtoModel

void fcn.1400306f0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1400306fc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001ce8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001cc8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14003071e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001ce7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140030744;
        func_0x00014011e230(*(int64_t *)(&stack0x00001cc8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001ce7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140030764;
        func_0x000140796b10(*(int64_t *)(&stack0x00001cc8 + iVar4) + 0x1ce0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001cc8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x140030773;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14003077f;
        func_0x000140016d90(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_1400307f0
// Address: 0x1400307f0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel

undefined8 fcn.1400307f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1d00));
    *(undefined8 *)(arg2 + 0x1ce0) = uVar1;
    *(int64_t *)(arg2 + 0x1ce8) = iVar2;
    return 0x14003078a;
}

// ============================================================
// Function: FUN_140030830
// Address: 0x140030830
// Size: 24 bytes
// ============================================================
void fcn.140030830(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140030850
// Address: 0x140030850
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel

undefined8 fcn.140030850(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1ce0) = uVar1;
    *(int64_t *)(arg2 + 0x1ce8) = iVar2;
    return 0x14003078a;
}

// ============================================================
// Function: FUN_140030890
// Address: 0x140030890
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel

void fcn.140030890(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1ce8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1ce0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1ce8) + 0x10));
    }
    return;
}

