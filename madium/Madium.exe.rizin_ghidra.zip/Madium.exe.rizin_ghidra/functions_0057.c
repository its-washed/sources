// Chunk 57 - 50 functions

// ============================================================
// Function: FUN_1400411f0
// Address: 0x1400411f0
// Size: 67 bytes
// ============================================================
void fcn.1400411f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140041240
// Address: 0x140041240
// Size: 505 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3980h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3988h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_39a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_beh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2170h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3070h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1840h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1838h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3088h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3078h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1630h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1640h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1638h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5258h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ae0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_818h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_7h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Removing arg arg_1fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2160h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2168h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1620h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2690h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2410h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7bfh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2800h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ba8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ba0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7afh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3898h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7cfh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Removing arg arg_1ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800f7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3990h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_718h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_728h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcc00fah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1410h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_39a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1820h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1818h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2718h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2728h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2738h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3090h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2730h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_10f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1100h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1830h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1808h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1de8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2528h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2580h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2568h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_878h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Removing arg arg_1bb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ba8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ba0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_cf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_99h
// WARNING: [rz-ghidra] Detected overlap for variable arg_187h
// WARNING: [rz-ghidra] Removing arg arg_2710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3098h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2630h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2620h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1208h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_30a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1828h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3068h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2318h because it doesn't fit into ProtoModel

void fcn.140041240(int64_t var_28h, int64_t var_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_100h, int64_t arg_108h,
                  int64_t arg_110h, int64_t arg_118h, int64_t arg_128h, int64_t arg_130h, int64_t arg_138h,
                  int64_t arg_140h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h, int64_t arg_160h,
                  int64_t arg_168h, int64_t arg_170h, int64_t arg_178h, int64_t arg_198h, int64_t arg_1b0h,
                  int64_t arg_1b8h, int64_t arg_1c0h, int64_t arg_1c8h, int64_t arg_1d0h, int64_t arg_1f0h,
                  int64_t arg_1f8h, int64_t arg_200h, int64_t arg_210h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_76b7ff08h;
    int64_t var_3bd6b7a0h;
    int64_t var_eb8h;
    int64_t var_eb0h;
    int64_t var_e98h;
    int64_t var_e40h;
    int64_t var_d38h;
    int64_t var_d30h;
    int64_t var_d18h;
    int64_t var_7e8h;
    int64_t var_798h;
    int64_t var_790h;
    int64_t var_370h;
    int64_t var_350h;
    int64_t var_348h;
    int64_t var_1f8h;
    int64_t var_1c0h;
    int64_t var_1b8h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_160h;
    int64_t var_150h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined8 uStack_20;
    int64_t var_18h;
    int64_t var_8h;
    
    uStack_20 = 0x14004124d;
    iVar2 = func_0x00014094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004126b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014004127c. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (18 cases) at 0x14097a884
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a884) + 0x14097a884))();
    return;
}

// ============================================================
// Function: FUN_140041440
// Address: 0x140041440
// Size: 37 bytes
// ============================================================
void fcn.140041440(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140041470
// Address: 0x140041470
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140041470(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_1400414b0
// Address: 0x1400414b0
// Size: 25 bytes
// ============================================================
void fcn.1400414b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400414d0
// Address: 0x1400414d0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400414d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140041367;
}

// ============================================================
// Function: FUN_140041510
// Address: 0x140041510
// Size: 25 bytes
// ============================================================
void fcn.140041510(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140041530
// Address: 0x140041530
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140041530(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140041367;
}

// ============================================================
// Function: FUN_140041570
// Address: 0x140041570
// Size: 25 bytes
// ============================================================
void fcn.140041570(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140041590
// Address: 0x140041590
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140041590(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400413e7;
}

// ============================================================
// Function: FUN_1400415d0
// Address: 0x1400415d0
// Size: 25 bytes
// ============================================================
void fcn.1400415d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400415f0
// Address: 0x1400415f0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400415f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400413e7;
}

// ============================================================
// Function: FUN_140041630
// Address: 0x140041630
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140041630(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140041680
// Address: 0x140041680
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3990h because it doesn't fit into ProtoModel

void fcn.140041680(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004168d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00003990 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x1400416ab;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x0001400416bc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a8a4) + 0x14097a8a4))();
    return;
}

// ============================================================
// Function: FUN_140041880
// Address: 0x140041880
// Size: 37 bytes
// ============================================================
void fcn.140041880(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1400418b0
// Address: 0x1400418b0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400418b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1cd8) = 2;
    fcn.14011e230(*(undefined8 *)(arg2 + 0x39a0), arg2 + 0x1cd8);
    return;
}

// ============================================================
// Function: FUN_1400418f0
// Address: 0x1400418f0
// Size: 25 bytes
// ============================================================
void fcn.1400418f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140041910
// Address: 0x140041910
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3918h because it doesn't fit into ProtoModel

undefined8 fcn.140041910(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x39b8));
    *(undefined8 *)(arg2 + 0x3988) = uVar1;
    *(int64_t *)(arg2 + 0x3998) = iVar2;
    return 0x1400417a7;
}

// ============================================================
// Function: FUN_140041950
// Address: 0x140041950
// Size: 25 bytes
// ============================================================
void fcn.140041950(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140041970
// Address: 0x140041970
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3918h because it doesn't fit into ProtoModel

undefined8 fcn.140041970(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x3988) = uVar1;
    *(int64_t *)(arg2 + 0x3998) = iVar2;
    return 0x1400417a7;
}

// ============================================================
// Function: FUN_1400419b0
// Address: 0x1400419b0
// Size: 25 bytes
// ============================================================
void fcn.1400419b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400419d0
// Address: 0x1400419d0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3918h because it doesn't fit into ProtoModel

undefined8 fcn.1400419d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x39b0));
    *(undefined8 *)(arg2 + 0x39a0) = uVar1;
    *(int64_t *)(arg2 + 0x3998) = iVar2;
    return 0x140041827;
}

// ============================================================
// Function: FUN_140041a10
// Address: 0x140041a10
// Size: 25 bytes
// ============================================================
void fcn.140041a10(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140041a30
// Address: 0x140041a30
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3918h because it doesn't fit into ProtoModel

undefined8 fcn.140041a30(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x39a0) = uVar1;
    *(int64_t *)(arg2 + 0x3998) = iVar2;
    return 0x140041827;
}

// ============================================================
// Function: FUN_140041a70
// Address: 0x140041a70
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3920h because it doesn't fit into ProtoModel

void fcn.140041a70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x3998) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x39a0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x3998) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140041ac0
// Address: 0x140041ac0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1650h because it doesn't fit into ProtoModel

void fcn.140041ac0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140041acd;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00001650 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140041aeb;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140041afc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a8c4) + 0x14097a8c4))();
    return;
}

// ============================================================
// Function: FUN_140041cc0
// Address: 0x140041cc0
// Size: 37 bytes
// ============================================================
void fcn.140041cc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140041cf0
// Address: 0x140041cf0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ab8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140041cf0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xb38) = 2;
    fcn.14011e510(*(undefined8 *)(arg2 + 0x1660), arg2 + 0xb38);
    return;
}

// ============================================================
// Function: FUN_140041d30
// Address: 0x140041d30
// Size: 25 bytes
// ============================================================
void fcn.140041d30(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140041d50
// Address: 0x140041d50
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_15f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15d8h because it doesn't fit into ProtoModel

undefined8 fcn.140041d50(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1678));
    *(undefined8 *)(arg2 + 0x1648) = uVar1;
    *(int64_t *)(arg2 + 0x1658) = iVar2;
    return 0x140041be7;
}

// ============================================================
// Function: FUN_140041d90
// Address: 0x140041d90
// Size: 25 bytes
// ============================================================
void fcn.140041d90(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140041db0
// Address: 0x140041db0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_15c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15d8h because it doesn't fit into ProtoModel

undefined8 fcn.140041db0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1648) = uVar1;
    *(int64_t *)(arg2 + 0x1658) = iVar2;
    return 0x140041be7;
}

// ============================================================
// Function: FUN_140041df0
// Address: 0x140041df0
// Size: 25 bytes
// ============================================================
void fcn.140041df0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140041e10
// Address: 0x140041e10
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_15f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15d8h because it doesn't fit into ProtoModel

undefined8 fcn.140041e10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1670));
    *(undefined8 *)(arg2 + 0x1660) = uVar1;
    *(int64_t *)(arg2 + 0x1658) = iVar2;
    return 0x140041c67;
}

// ============================================================
// Function: FUN_140041e50
// Address: 0x140041e50
// Size: 25 bytes
// ============================================================
void fcn.140041e50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140041e70
// Address: 0x140041e70
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15d8h because it doesn't fit into ProtoModel

undefined8 fcn.140041e70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1660) = uVar1;
    *(int64_t *)(arg2 + 0x1658) = iVar2;
    return 0x140041c67;
}

// ============================================================
// Function: FUN_140041eb0
// Address: 0x140041eb0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_15d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel

void fcn.140041eb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1658) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1660), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1658) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140041f00
// Address: 0x140041f00
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.140041f00(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140041f0d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140041f2b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140041f3c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a8e4) + 0x14097a8e4))();
    return;
}

// ============================================================
// Function: FUN_140042100
// Address: 0x140042100
// Size: 37 bytes
// ============================================================
void fcn.140042100(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140042130
// Address: 0x140042130
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140042130(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140042170
// Address: 0x140042170
// Size: 25 bytes
// ============================================================
void fcn.140042170(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140042190
// Address: 0x140042190
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140042190(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140042027;
}

// ============================================================
// Function: FUN_1400421d0
// Address: 0x1400421d0
// Size: 25 bytes
// ============================================================
void fcn.1400421d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400421f0
// Address: 0x1400421f0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400421f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140042027;
}

// ============================================================
// Function: FUN_140042230
// Address: 0x140042230
// Size: 25 bytes
// ============================================================
void fcn.140042230(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140042250
// Address: 0x140042250
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140042250(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400420a7;
}

// ============================================================
// Function: FUN_140042290
// Address: 0x140042290
// Size: 25 bytes
// ============================================================
void fcn.140042290(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400422b0
// Address: 0x1400422b0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400422b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400420a7;
}

// ============================================================
// Function: FUN_1400422f0
// Address: 0x1400422f0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

void fcn.1400422f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140042340
// Address: 0x140042340
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.140042340(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004234d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004236b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004237c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a904) + 0x14097a904))();
    return;
}

