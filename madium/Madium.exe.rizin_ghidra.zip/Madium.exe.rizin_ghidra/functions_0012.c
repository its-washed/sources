// Chunk 12 - 50 functions

// ============================================================
// Function: FUN_14000f0f0
// Address: 0x14000f0f0
// Size: 59 bytes
// ============================================================
void fcn.14000f0f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000f130
// Address: 0x14000f130
// Size: 95 bytes
// ============================================================
void fcn.14000f130(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    func_0x00014001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        func_0x0001406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000f190
// Address: 0x14000f190
// Size: 57 bytes
// ============================================================
void fcn.14000f190(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000f1d0
// Address: 0x14000f1d0
// Size: 59 bytes
// ============================================================
void fcn.14000f1d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000f210
// Address: 0x14000f210
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000f210(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x1ca0) == '\0') {
        func_0x0001400089a0(arg1 + 0x188);
        func_0x00014001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x1ca0) != '\x03') {
            return;
        }
        func_0x0001400089a0(arg1 + 0xf10);
        func_0x00014001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000f2e0
// Address: 0x14000f2e0
// Size: 34 bytes
// ============================================================
void fcn.14000f2e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000f310
// Address: 0x14000f310
// Size: 57 bytes
// ============================================================
void fcn.14000f310(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000f350
// Address: 0x14000f350
// Size: 59 bytes
// ============================================================
void fcn.14000f350(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000f390
// Address: 0x14000f390
// Size: 95 bytes
// ============================================================
void fcn.14000f390(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000f3f0
// Address: 0x14000f3f0
// Size: 57 bytes
// ============================================================
void fcn.14000f3f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000f430
// Address: 0x14000f430
// Size: 59 bytes
// ============================================================
void fcn.14000f430(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000f470
// Address: 0x14000f470
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000f470(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x13a0) == '\0') {
        func_0x000140008130(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x13a0) != '\x03') {
            return;
        }
        func_0x000140008130(arg1 + 0xa90);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000f540
// Address: 0x14000f540
// Size: 34 bytes
// ============================================================
void fcn.14000f540(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000f570
// Address: 0x14000f570
// Size: 57 bytes
// ============================================================
void fcn.14000f570(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000f5b0
// Address: 0x14000f5b0
// Size: 59 bytes
// ============================================================
void fcn.14000f5b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000f5f0
// Address: 0x14000f5f0
// Size: 95 bytes
// ============================================================
void fcn.14000f5f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000f650
// Address: 0x14000f650
// Size: 57 bytes
// ============================================================
void fcn.14000f650(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000f690
// Address: 0x14000f690
// Size: 59 bytes
// ============================================================
void fcn.14000f690(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000f6d0
// Address: 0x14000f6d0
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000f6d0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x13d0) == '\0') {
        func_0x000140006300(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x13d0) != '\x03') {
            return;
        }
        func_0x000140006300(arg1 + 0xaa8);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000f7a0
// Address: 0x14000f7a0
// Size: 34 bytes
// ============================================================
void fcn.14000f7a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000f7d0
// Address: 0x14000f7d0
// Size: 57 bytes
// ============================================================
void fcn.14000f7d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000f810
// Address: 0x14000f810
// Size: 59 bytes
// ============================================================
void fcn.14000f810(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000f850
// Address: 0x14000f850
// Size: 95 bytes
// ============================================================
void fcn.14000f850(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000f8b0
// Address: 0x14000f8b0
// Size: 57 bytes
// ============================================================
void fcn.14000f8b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000f8f0
// Address: 0x14000f8f0
// Size: 59 bytes
// ============================================================
void fcn.14000f8f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000f930
// Address: 0x14000f930
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000f930(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x1340) == '\0') {
        func_0x000140007870(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x1340) != '\x03') {
            return;
        }
        func_0x000140007870(arg1 + 0xa60);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000fa00
// Address: 0x14000fa00
// Size: 34 bytes
// ============================================================
void fcn.14000fa00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000fa30
// Address: 0x14000fa30
// Size: 57 bytes
// ============================================================
void fcn.14000fa30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000fa70
// Address: 0x14000fa70
// Size: 59 bytes
// ============================================================
void fcn.14000fa70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000fab0
// Address: 0x14000fab0
// Size: 95 bytes
// ============================================================
void fcn.14000fab0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000fb10
// Address: 0x14000fb10
// Size: 57 bytes
// ============================================================
void fcn.14000fb10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000fb50
// Address: 0x14000fb50
// Size: 59 bytes
// ============================================================
void fcn.14000fb50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000fb90
// Address: 0x14000fb90
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000fb90(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x1ca0) == '\0') {
        func_0x000140007410(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x1ca0) != '\x03') {
            return;
        }
        func_0x000140007410(arg1 + 0xf10);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000fc60
// Address: 0x14000fc60
// Size: 34 bytes
// ============================================================
void fcn.14000fc60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000fc90
// Address: 0x14000fc90
// Size: 57 bytes
// ============================================================
void fcn.14000fc90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000fcd0
// Address: 0x14000fcd0
// Size: 59 bytes
// ============================================================
void fcn.14000fcd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000fd10
// Address: 0x14000fd10
// Size: 95 bytes
// ============================================================
void fcn.14000fd10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000fd70
// Address: 0x14000fd70
// Size: 57 bytes
// ============================================================
void fcn.14000fd70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000fdb0
// Address: 0x14000fdb0
// Size: 59 bytes
// ============================================================
void fcn.14000fdb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000fdf0
// Address: 0x14000fdf0
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000fdf0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x1460) == '\0') {
        func_0x000140008590(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x1460) != '\x03') {
            return;
        }
        func_0x000140008590(arg1 + 0xaf0);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000fec0
// Address: 0x14000fec0
// Size: 34 bytes
// ============================================================
void fcn.14000fec0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000fef0
// Address: 0x14000fef0
// Size: 57 bytes
// ============================================================
void fcn.14000fef0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000ff30
// Address: 0x14000ff30
// Size: 59 bytes
// ============================================================
void fcn.14000ff30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000ff70
// Address: 0x14000ff70
// Size: 95 bytes
// ============================================================
void fcn.14000ff70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000ffd0
// Address: 0x14000ffd0
// Size: 57 bytes
// ============================================================
void fcn.14000ffd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_140010010
// Address: 0x140010010
// Size: 59 bytes
// ============================================================
void fcn.140010010(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140010050
// Address: 0x140010050
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140010050(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x14c0) == '\0') {
        func_0x000140006bc0(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x14c0) != '\x03') {
            return;
        }
        func_0x000140006bc0(arg1 + 0xb20);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_140010120
// Address: 0x140010120
// Size: 34 bytes
// ============================================================
void fcn.140010120(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_140010150
// Address: 0x140010150
// Size: 57 bytes
// ============================================================
void fcn.140010150(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_140010190
// Address: 0x140010190
// Size: 59 bytes
// ============================================================
void fcn.140010190(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

