// Chunk 69 - 50 functions

// ============================================================
// Function: FUN_14004e760
// Address: 0x14004e760
// Size: 55 bytes
// ============================================================
undefined8 fcn.14004e760(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x39a0) = uVar1;
    *(int64_t *)(arg2 + 0x3998) = iVar2;
    return 0x14004e557;
}

// ============================================================
// Function: FUN_14004e7a0
// Address: 0x14004e7a0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3920h because it doesn't fit into ProtoModel

void fcn.14004e7a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x3998) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x39a0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x3998) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004e7f0
// Address: 0x14004e7f0
// Size: 505 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3090h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1860h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3088h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3098h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1eb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1638h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1640h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5258h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2940h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_197h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5cb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_18fh
// WARNING: [rz-ghidra] Removing arg arg_2028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2168h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5cc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2528h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_52a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2df8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1af8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ac8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ad8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1db8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1dc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1dc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1db0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ac0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1410h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800feh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2438h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_187h
// WARNING: [rz-ghidra] Removing arg arg_388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5cb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7cfh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2800h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2808h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7afh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3898h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2170h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_beh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Removing arg arg_17b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800f7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3980h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3988h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_39a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3990h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be0h because it doesn't fit into ProtoModel

void fcn.14004e7f0(int64_t var_28h, int64_t var_30h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_130h, int64_t arg_138h,
                  int64_t arg_140h, int64_t arg_150h, int64_t arg_158h, int64_t arg_160h, int64_t arg_168h,
                  int64_t arg_170h, int64_t arg_178h, int64_t arg_180h, int64_t arg_188h, int64_t arg_1a0h,
                  int64_t arg_1b0h, int64_t arg_1b8h, int64_t arg_1c0h, int64_t arg_1c8h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_3bd6b790h;
    int64_t var_7e0h;
    int64_t var_788h;
    int64_t var_3b0h;
    int64_t var_398h;
    int64_t var_358h;
    int64_t var_340h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_1a0h;
    int64_t var_140h;
    int64_t var_40h;
    undefined8 uStack_20;
    int64_t var_8h;
    
    uStack_20 = 0x14004e7fd;
    iVar2 = func_0x00014094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004e81b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014004e82c. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (18 cases) at 0x14097aec4
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097aec4) + 0x14097aec4))();
    return;
}

// ============================================================
// Function: FUN_14004e9f0
// Address: 0x14004e9f0
// Size: 37 bytes
// ============================================================
void fcn.14004e9f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004ea20
// Address: 0x14004ea20
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004ea20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011da20(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_14004ea60
// Address: 0x14004ea60
// Size: 25 bytes
// ============================================================
void fcn.14004ea60(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004ea80
// Address: 0x14004ea80
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004ea80(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004e917;
}

// ============================================================
// Function: FUN_14004eac0
// Address: 0x14004eac0
// Size: 25 bytes
// ============================================================
void fcn.14004eac0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004eae0
// Address: 0x14004eae0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004eae0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004e917;
}

// ============================================================
// Function: FUN_14004eb20
// Address: 0x14004eb20
// Size: 25 bytes
// ============================================================
void fcn.14004eb20(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004eb40
// Address: 0x14004eb40
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004eb40(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004e997;
}

// ============================================================
// Function: FUN_14004eb80
// Address: 0x14004eb80
// Size: 25 bytes
// ============================================================
void fcn.14004eb80(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004eba0
// Address: 0x14004eba0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004eba0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004e997;
}

// ============================================================
// Function: FUN_14004ebe0
// Address: 0x14004ebe0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.14004ebe0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004ec30
// Address: 0x14004ec30
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel

void fcn.14004ec30(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004ec3d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00001e90 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004ec5b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004ec6c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097aee4) + 0x14097aee4))();
    return;
}

// ============================================================
// Function: FUN_14004ee30
// Address: 0x14004ee30
// Size: 37 bytes
// ============================================================
void fcn.14004ee30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004ee60
// Address: 0x14004ee60
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004ee60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xf58) = 2;
    fcn.14011f650(*(undefined8 *)(arg2 + 0x1ea0), arg2 + 0xf58);
    return;
}

// ============================================================
// Function: FUN_14004eea0
// Address: 0x14004eea0
// Size: 25 bytes
// ============================================================
void fcn.14004eea0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004eec0
// Address: 0x14004eec0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.14004eec0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1eb8));
    *(undefined8 *)(arg2 + 0x1e88) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x14004ed57;
}

// ============================================================
// Function: FUN_14004ef00
// Address: 0x14004ef00
// Size: 25 bytes
// ============================================================
void fcn.14004ef00(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004ef20
// Address: 0x14004ef20
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.14004ef20(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1e88) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x14004ed57;
}

// ============================================================
// Function: FUN_14004ef60
// Address: 0x14004ef60
// Size: 25 bytes
// ============================================================
void fcn.14004ef60(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004ef80
// Address: 0x14004ef80
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.14004ef80(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1eb0));
    *(undefined8 *)(arg2 + 0x1ea0) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x14004edd7;
}

// ============================================================
// Function: FUN_14004efc0
// Address: 0x14004efc0
// Size: 25 bytes
// ============================================================
void fcn.14004efc0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004efe0
// Address: 0x14004efe0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.14004efe0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1ea0) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x14004edd7;
}

// ============================================================
// Function: FUN_14004f020
// Address: 0x14004f020
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel

void fcn.14004f020(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1e98) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1ea0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1e98) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004f070
// Address: 0x14004f070
// Size: 558 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_4320h because it doesn't fit into ProtoModel

void fcn.14004f070(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004f07d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00004320 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004f09b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004f0ac. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097af04) + 0x14097af04))();
    return;
}

// ============================================================
// Function: FUN_14004f2a0
// Address: 0x14004f2a0
// Size: 37 bytes
// ============================================================
void fcn.14004f2a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004f2d0
// Address: 0x14004f2d0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004f2d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x2188) = 2;
    fcn.14011d180(*(undefined8 *)(arg2 + 0x4330), arg2 + 0x2188);
    return;
}

// ============================================================
// Function: FUN_14004f310
// Address: 0x14004f310
// Size: 25 bytes
// ============================================================
void fcn.14004f310(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004f330
// Address: 0x14004f330
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_42c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42a8h because it doesn't fit into ProtoModel

undefined8 fcn.14004f330(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x4348));
    *(undefined8 *)(arg2 + 0x4318) = uVar1;
    *(int64_t *)(arg2 + 0x4328) = iVar2;
    return 0x14004f1d3;
}

// ============================================================
// Function: FUN_14004f370
// Address: 0x14004f370
// Size: 25 bytes
// ============================================================
void fcn.14004f370(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004f390
// Address: 0x14004f390
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_4298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42a8h because it doesn't fit into ProtoModel

undefined8 fcn.14004f390(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x4318) = uVar1;
    *(int64_t *)(arg2 + 0x4328) = iVar2;
    return 0x14004f1d3;
}

// ============================================================
// Function: FUN_14004f3d0
// Address: 0x14004f3d0
// Size: 25 bytes
// ============================================================
void fcn.14004f3d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004f3f0
// Address: 0x14004f3f0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_42c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42a8h because it doesn't fit into ProtoModel

undefined8 fcn.14004f3f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x4340));
    *(undefined8 *)(arg2 + 0x4330) = uVar1;
    *(int64_t *)(arg2 + 0x4328) = iVar2;
    return 0x14004f253;
}

// ============================================================
// Function: FUN_14004f430
// Address: 0x14004f430
// Size: 25 bytes
// ============================================================
void fcn.14004f430(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004f450
// Address: 0x14004f450
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_42b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42a8h because it doesn't fit into ProtoModel

undefined8 fcn.14004f450(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x4330) = uVar1;
    *(int64_t *)(arg2 + 0x4328) = iVar2;
    return 0x14004f253;
}

// ============================================================
// Function: FUN_14004f490
// Address: 0x14004f490
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_42a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42b0h because it doesn't fit into ProtoModel

void fcn.14004f490(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x4328) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x4330), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x4328) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004f4e0
// Address: 0x14004f4e0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_17d0h because it doesn't fit into ProtoModel

void fcn.14004f4e0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004f4ed;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000017d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004f50b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004f51c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097af24) + 0x14097af24))();
    return;
}

// ============================================================
// Function: FUN_14004f6e0
// Address: 0x14004f6e0
// Size: 37 bytes
// ============================================================
void fcn.14004f6e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004f710
// Address: 0x14004f710
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_b78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004f710(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xbf8) = 2;
    fcn.14011f4e0(*(undefined8 *)(arg2 + 0x17e0), arg2 + 0xbf8);
    return;
}

// ============================================================
// Function: FUN_14004f750
// Address: 0x14004f750
// Size: 25 bytes
// ============================================================
void fcn.14004f750(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004f770
// Address: 0x14004f770
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1748h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1758h because it doesn't fit into ProtoModel

undefined8 fcn.14004f770(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x17f8));
    *(undefined8 *)(arg2 + 0x17c8) = uVar1;
    *(int64_t *)(arg2 + 0x17d8) = iVar2;
    return 0x14004f607;
}

// ============================================================
// Function: FUN_14004f7b0
// Address: 0x14004f7b0
// Size: 25 bytes
// ============================================================
void fcn.14004f7b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004f7d0
// Address: 0x14004f7d0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1748h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1758h because it doesn't fit into ProtoModel

undefined8 fcn.14004f7d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x17c8) = uVar1;
    *(int64_t *)(arg2 + 0x17d8) = iVar2;
    return 0x14004f607;
}

// ============================================================
// Function: FUN_14004f810
// Address: 0x14004f810
// Size: 25 bytes
// ============================================================
void fcn.14004f810(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004f830
// Address: 0x14004f830
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1758h because it doesn't fit into ProtoModel

undefined8 fcn.14004f830(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x17f0));
    *(undefined8 *)(arg2 + 0x17e0) = uVar1;
    *(int64_t *)(arg2 + 0x17d8) = iVar2;
    return 0x14004f687;
}

// ============================================================
// Function: FUN_14004f870
// Address: 0x14004f870
// Size: 25 bytes
// ============================================================
void fcn.14004f870(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004f890
// Address: 0x14004f890
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1758h because it doesn't fit into ProtoModel

undefined8 fcn.14004f890(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x17e0) = uVar1;
    *(int64_t *)(arg2 + 0x17d8) = iVar2;
    return 0x14004f687;
}

// ============================================================
// Function: FUN_14004f8d0
// Address: 0x14004f8d0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1758h because it doesn't fit into ProtoModel

void fcn.14004f8d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x17d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x17e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x17d8) + 0x10));
    }
    return;
}

