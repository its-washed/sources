// Chunk 31 - 50 functions

// ============================================================
// Function: FUN_1400230d0
// Address: 0x1400230d0
// Size: 304 bytes
// ============================================================
void fcn.1400230d0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_f90h;
    int64_t var_f38h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0xf60);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_f90h, arg1 + 0x30, 0xf30);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_f90h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_140023200
// Address: 0x140023200
// Size: 44 bytes
// ============================================================
void fcn.140023200(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012d30(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140023230
// Address: 0x140023230
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f00h because it doesn't fit into ProtoModel

void fcn.140023230(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0xf58);
    puVar2 = *(undefined8 **)(arg2 + 0xf88);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0xf90) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf80), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0xf90) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0xf70);
    uVar4 = *(undefined4 *)(arg2 + 0xf64);
    uVar5 = *(undefined4 *)(arg2 + 0xf68);
    uVar6 = *(undefined4 *)(arg2 + 0xf6c);
    *puVar1 = *(undefined4 *)(arg2 + 0xf60);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_1400232a0
// Address: 0x1400232a0
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel

void fcn.1400232a0(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400232ad;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x000013a0 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400232d5;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x1380);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400232ec;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x1350);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400233d4;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00001378 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00001368 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x0000136c + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00001370 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00001374 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00001388 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001398 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001390 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00001360 + iVar9) = *(int64_t *)(&stack0x00001390 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002338c;
                (*pcVar3)(*(undefined8 *)(&stack0x00001388 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001398 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001390 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001398 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400233b7;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00001388 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x0000136c + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00001370 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00001374 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00001368 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00001378 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_1400233e0
// Address: 0x1400233e0
// Size: 44 bytes
// ============================================================
void fcn.1400233e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.1400127f0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140023410
// Address: 0x140023410
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1320h because it doesn't fit into ProtoModel

void fcn.140023410(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1378);
    puVar2 = *(undefined8 **)(arg2 + 0x13a8);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x13b0) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x13a0), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x13b0) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1390);
    uVar4 = *(undefined4 *)(arg2 + 0x1384);
    uVar5 = *(undefined4 *)(arg2 + 5000);
    uVar6 = *(undefined4 *)(arg2 + 0x138c);
    *puVar1 = *(undefined4 *)(arg2 + 0x1380);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140023480
// Address: 0x140023480
// Size: 304 bytes
// ============================================================
void fcn.140023480(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_a20h;
    int64_t var_9c8h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0x9f0);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_a20h, arg1 + 0x30, 0x9c0);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_a20h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_1400235b0
// Address: 0x1400235b0
// Size: 44 bytes
// ============================================================
void fcn.1400235b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140011fb0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_1400235e0
// Address: 0x1400235e0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_980h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_990h because it doesn't fit into ProtoModel

void fcn.1400235e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x9e8);
    puVar2 = *(undefined8 **)(arg2 + 0xa18);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0xa20) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xa10), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0xa20) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0xa00);
    uVar4 = *(undefined4 *)(arg2 + 0x9f4);
    uVar5 = *(undefined4 *)(arg2 + 0x9f8);
    uVar6 = *(undefined4 *)(arg2 + 0x9fc);
    *puVar1 = *(undefined4 *)(arg2 + 0x9f0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140023650
// Address: 0x140023650
// Size: 304 bytes
// ============================================================
void fcn.140023650(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_a80h;
    int64_t var_a28h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0xa50);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_a80h, arg1 + 0x30, 0xa20);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_a80h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_140023780
// Address: 0x140023780
// Size: 44 bytes
// ============================================================
void fcn.140023780(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140011ef0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_1400237b0
// Address: 0x1400237b0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_9c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f0h because it doesn't fit into ProtoModel

void fcn.1400237b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0xa48);
    puVar2 = *(undefined8 **)(arg2 + 0xa78);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0xa80) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xa70), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0xa80) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0xa60);
    uVar4 = *(undefined4 *)(arg2 + 0xa54);
    uVar5 = *(undefined4 *)(arg2 + 0xa58);
    uVar6 = *(undefined4 *)(arg2 + 0xa5c);
    *puVar1 = *(undefined4 *)(arg2 + 0xa50);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140023820
// Address: 0x140023820
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel

void fcn.140023820(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x14002382d;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001400 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023855;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x13e0);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002386c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x13b0);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023954;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x000013d8 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x000013c8 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x000013cc + iVar9) = uVar5;
        *(undefined4 *)(&stack0x000013d0 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x000013d4 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x000013e8 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x000013f8 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x000013f0 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x000013c0 + iVar9) = *(int64_t *)(&stack0x000013f0 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002390c;
                (*pcVar3)(*(undefined8 *)(&stack0x000013e8 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x000013f8 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x000013f0 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x000013f8 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023937;
                fcn.1404d3c50(*(undefined8 *)(&stack0x000013e8 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x000013cc + iVar9);
        uVar6 = *(undefined4 *)(&stack0x000013d0 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x000013d4 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x000013c8 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x000013d8 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140023960
// Address: 0x140023960
// Size: 44 bytes
// ============================================================
void fcn.140023960(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012730(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140023990
// Address: 0x140023990
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel

void fcn.140023990(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x13d8);
    puVar2 = *(undefined8 **)(arg2 + 0x1408);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1410) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1400), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1410) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x13f0);
    uVar4 = *(undefined4 *)(arg2 + 0x13e4);
    uVar5 = *(undefined4 *)(arg2 + 0x13e8);
    uVar6 = *(undefined4 *)(arg2 + 0x13ec);
    *puVar1 = *(undefined4 *)(arg2 + 0x13e0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140023a00
// Address: 0x140023a00
// Size: 304 bytes
// ============================================================
void fcn.140023a00(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_208h;
    int64_t var_1a8h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0x1d8);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_208h, arg1 + 0x30, 0x1a8);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_208h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_140023b30
// Address: 0x140023b30
// Size: 44 bytes
// ============================================================
void fcn.140023b30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_60h;
    
    if (*(int32_t *)(arg2 + 0x20) != 1) {
        fcn.140012eb0(arg2 + 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_140023b60
// Address: 0x140023b60
// Size: 108 bytes
// ============================================================
void fcn.140023b60(undefined8 placeholder_0, int64_t arg2, int64_t arg_148h, int64_t arg_150h, int64_t arg_160h,
                  int64_t arg_170h, int64_t arg_178h, int64_t arg_180h)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1c8);
    puVar2 = *(undefined8 **)(arg2 + 0x1f8);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x200) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1f0), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x200) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1e0);
    uVar4 = *(undefined4 *)(arg2 + 0x1d4);
    uVar5 = *(undefined4 *)(arg2 + 0x1d8);
    uVar6 = *(undefined4 *)(arg2 + 0x1dc);
    *puVar1 = *(undefined4 *)(arg2 + 0x1d0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140023bd0
// Address: 0x140023bd0
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_14c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel

void fcn.140023bd0(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x140023bdd;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x000014c0 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023c05;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x14a0);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023c1c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x1470);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023d04;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00001498 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00001488 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x0000148c + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00001490 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00001494 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x000014a8 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x000014b8 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x000014b0 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00001480 + iVar9) = *(int64_t *)(&stack0x000014b0 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023cbc;
                (*pcVar3)(*(undefined8 *)(&stack0x000014a8 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x000014b8 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x000014b0 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x000014b8 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023ce7;
                fcn.1404d3c50(*(undefined8 *)(&stack0x000014a8 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x0000148c + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00001490 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00001494 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00001488 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00001498 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140023d10
// Address: 0x140023d10
// Size: 44 bytes
// ============================================================
void fcn.140023d10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.1400125b0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140023d40
// Address: 0x140023d40
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1430h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1420h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1440h because it doesn't fit into ProtoModel

void fcn.140023d40(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1498);
    puVar2 = *(undefined8 **)(arg2 + 0x14c8);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x14d0) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x14c0), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x14d0) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x14b0);
    uVar4 = *(undefined4 *)(arg2 + 0x14a4);
    uVar5 = *(undefined4 *)(arg2 + 0x14a8);
    uVar6 = *(undefined4 *)(arg2 + 0x14ac);
    *puVar1 = *(undefined4 *)(arg2 + 0x14a0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140023db0
// Address: 0x140023db0
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_21b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2170h because it doesn't fit into ProtoModel

void fcn.140023db0(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x140023dbd;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x000021b0 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023de5;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x2190);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023dfc;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x2160);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023ee4;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00002188 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00002178 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x0000217c + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00002180 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00002184 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00002198 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x000021a8 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x000021a0 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00002170 + iVar9) = *(int64_t *)(&stack0x000021a0 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023e9c;
                (*pcVar3)(*(undefined8 *)(&stack0x00002198 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x000021a8 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x000021a0 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x000021a8 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023ec7;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00002198 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x0000217c + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00002180 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00002184 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00002178 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00002188 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140023ef0
// Address: 0x140023ef0
// Size: 44 bytes
// ============================================================
void fcn.140023ef0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.14000cfa0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140023f20
// Address: 0x140023f20
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2138h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2140h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2130h because it doesn't fit into ProtoModel

void fcn.140023f20(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x2188);
    puVar2 = *(undefined8 **)(arg2 + 0x21b8);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x21c0) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x21b0), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x21c0) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x21a0);
    uVar4 = *(undefined4 *)(arg2 + 0x2194);
    uVar5 = *(undefined4 *)(arg2 + 0x2198);
    uVar6 = *(undefined4 *)(arg2 + 0x219c);
    *puVar1 = *(undefined4 *)(arg2 + 0x2190);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140023f90
// Address: 0x140023f90
// Size: 304 bytes
// ============================================================
void fcn.140023f90(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_b70h;
    int64_t var_b18h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0xb40);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_b70h, arg1 + 0x30, 0xb10);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_b70h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_1400240c0
// Address: 0x1400240c0
// Size: 44 bytes
// ============================================================
void fcn.1400240c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140013330(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_1400240f0
// Address: 0x1400240f0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ab8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ae8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_af0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ad0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ac0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ae0h because it doesn't fit into ProtoModel

void fcn.1400240f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0xb38);
    puVar2 = *(undefined8 **)(arg2 + 0xb68);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0xb70) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xb60), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0xb70) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0xb50);
    uVar4 = *(undefined4 *)(arg2 + 0xb44);
    uVar5 = *(undefined4 *)(arg2 + 0xb48);
    uVar6 = *(undefined4 *)(arg2 + 0xb4c);
    *puVar1 = *(undefined4 *)(arg2 + 0xb40);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140024160
// Address: 0x140024160
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel

void fcn.140024160(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x14002416d;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001ca0 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140024195;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x1c80);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400241ac;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x1c50);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140024294;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00001c78 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00001c68 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x00001c6c + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00001c70 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00001c74 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00001c88 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001c98 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001c90 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00001c60 + iVar9) = *(int64_t *)(&stack0x00001c90 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002424c;
                (*pcVar3)(*(undefined8 *)(&stack0x00001c88 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001c98 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001c90 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001c98 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140024277;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00001c88 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x00001c6c + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00001c70 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00001c74 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00001c68 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00001c78 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_1400242a0
// Address: 0x1400242a0
// Size: 44 bytes
// ============================================================
void fcn.1400242a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.1400121f0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_1400242d0
// Address: 0x1400242d0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c20h because it doesn't fit into ProtoModel

void fcn.1400242d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1c78);
    puVar2 = *(undefined8 **)(arg2 + 0x1ca8);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1cb0) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1ca0), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1cb0) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1c90);
    uVar4 = *(undefined4 *)(arg2 + 0x1c84);
    uVar5 = *(undefined4 *)(arg2 + 0x1c88);
    uVar6 = *(undefined4 *)(arg2 + 0x1c8c);
    *puVar1 = *(undefined4 *)(arg2 + 0x1c80);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140024340
// Address: 0x140024340
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2960h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2948h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2920h because it doesn't fit into ProtoModel

void fcn.140024340(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x14002434d;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00002960 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140024375;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x2940);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002438c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x2910);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140024474;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00002938 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00002928 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x0000292c + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00002930 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00002934 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00002948 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00002958 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00002950 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00002920 + iVar9) = *(int64_t *)(&stack0x00002950 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002442c;
                (*pcVar3)(*(undefined8 *)(&stack0x00002948 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00002958 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00002950 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00002958 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140024457;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00002948 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x0000292c + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00002930 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00002934 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00002928 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00002938 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140024480
// Address: 0x140024480
// Size: 44 bytes
// ============================================================
void fcn.140024480(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.14000d060(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_1400244b0
// Address: 0x1400244b0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_28b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28e0h because it doesn't fit into ProtoModel

void fcn.1400244b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x2938);
    puVar2 = *(undefined8 **)(arg2 + 0x2968);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x2970) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x2960), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x2970) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x2950);
    uVar4 = *(undefined4 *)(arg2 + 0x2944);
    uVar5 = *(undefined4 *)(arg2 + 0x2948);
    uVar6 = *(undefined4 *)(arg2 + 0x294c);
    *puVar1 = *(undefined4 *)(arg2 + 0x2940);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140024520
// Address: 0x140024520
// Size: 304 bytes
// ============================================================
void fcn.140024520(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_f90h;
    int64_t var_f38h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0xf60);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_f90h, arg1 + 0x30, 0xf30);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_f90h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_140024650
// Address: 0x140024650
// Size: 44 bytes
// ============================================================
void fcn.140024650(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.1400130f0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140024680
// Address: 0x140024680
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f00h because it doesn't fit into ProtoModel

void fcn.140024680(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0xf58);
    puVar2 = *(undefined8 **)(arg2 + 0xf88);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0xf90) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf80), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0xf90) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0xf70);
    uVar4 = *(undefined4 *)(arg2 + 0xf64);
    uVar5 = *(undefined4 *)(arg2 + 0xf68);
    uVar6 = *(undefined4 *)(arg2 + 0xf6c);
    *puVar1 = *(undefined4 *)(arg2 + 0xf60);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_1400246f0
// Address: 0x1400246f0
// Size: 304 bytes
// ============================================================
void fcn.1400246f0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_f90h;
    int64_t var_f38h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0xf60);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_f90h, arg1 + 0x30, 0xf30);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_f90h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_140024820
// Address: 0x140024820
// Size: 44 bytes
// ============================================================
void fcn.140024820(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012df0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140024850
// Address: 0x140024850
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f00h because it doesn't fit into ProtoModel

void fcn.140024850(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0xf58);
    puVar2 = *(undefined8 **)(arg2 + 0xf88);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0xf90) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf80), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0xf90) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0xf70);
    uVar4 = *(undefined4 *)(arg2 + 0xf64);
    uVar5 = *(undefined4 *)(arg2 + 0xf68);
    uVar6 = *(undefined4 *)(arg2 + 0xf6c);
    *puVar1 = *(undefined4 *)(arg2 + 0xf60);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_1400248c0
// Address: 0x1400248c0
// Size: 304 bytes
// ============================================================
void fcn.1400248c0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_150h;
    int64_t var_f8h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0x120);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_150h, arg1 + 0x30, 0xf0);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_150h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_1400249f0
// Address: 0x1400249f0
// Size: 44 bytes
// ============================================================
void fcn.1400249f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140002e90(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140024a20
// Address: 0x140024a20
// Size: 108 bytes
// ============================================================
void fcn.140024a20(undefined8 placeholder_0, int64_t arg2, int64_t arg_98h, int64_t arg_a0h, int64_t arg_b0h,
                  int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x118);
    puVar2 = *(undefined8 **)(arg2 + 0x148);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x150) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x140), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x150) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x130);
    uVar4 = *(undefined4 *)(arg2 + 0x124);
    uVar5 = *(undefined4 *)(arg2 + 0x128);
    uVar6 = *(undefined4 *)(arg2 + 300);
    *puVar1 = *(undefined4 *)(arg2 + 0x120);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140024a90
// Address: 0x140024a90
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1038h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel

void fcn.140024a90(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x140024a9d;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001040 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140024ac5;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x1020);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140024adc;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0xff0);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140024bc4;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00001018 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00001008 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x0000100c + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00001010 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00001014 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00001028 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001038 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001030 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00001000 + iVar9) = *(int64_t *)(&stack0x00001030 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140024b7c;
                (*pcVar3)(*(undefined8 *)(&stack0x00001028 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001038 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001030 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001038 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140024ba7;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00001028 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x0000100c + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00001010 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00001014 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00001008 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00001018 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140024bd0
// Address: 0x140024bd0
// Size: 44 bytes
// ============================================================
void fcn.140024bd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140013270(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140024c00
// Address: 0x140024c00
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fc0h because it doesn't fit into ProtoModel

void fcn.140024c00(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1018);
    puVar2 = *(undefined8 **)(arg2 + 0x1048);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1050) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1040), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1050) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1030);
    uVar4 = *(undefined4 *)(arg2 + 0x1024);
    uVar5 = *(undefined4 *)(arg2 + 0x1028);
    uVar6 = *(undefined4 *)(arg2 + 0x102c);
    *puVar1 = *(undefined4 *)(arg2 + 0x1020);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140024c70
// Address: 0x140024c70
// Size: 304 bytes
// ============================================================
void fcn.140024c70(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_a20h;
    int64_t var_9c8h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0x9f0);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_a20h, arg1 + 0x30, 0x9c0);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_a20h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_140024da0
// Address: 0x140024da0
// Size: 44 bytes
// ============================================================
void fcn.140024da0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140011e30(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140024dd0
// Address: 0x140024dd0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_980h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_990h because it doesn't fit into ProtoModel

void fcn.140024dd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x9e8);
    puVar2 = *(undefined8 **)(arg2 + 0xa18);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0xa20) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xa10), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0xa20) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0xa00);
    uVar4 = *(undefined4 *)(arg2 + 0x9f4);
    uVar5 = *(undefined4 *)(arg2 + 0x9f8);
    uVar6 = *(undefined4 *)(arg2 + 0x9fc);
    *puVar1 = *(undefined4 *)(arg2 + 0x9f0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140024e40
// Address: 0x140024e40
// Size: 304 bytes
// ============================================================
void fcn.140024e40(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_c30h;
    int64_t var_bd8h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0xc00);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_c30h, arg1 + 0x30, 0xbd0);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_c30h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_140024f70
// Address: 0x140024f70
// Size: 44 bytes
// ============================================================
void fcn.140024f70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.1400134b0(arg2 + 0x28);
    }
    return;
}

