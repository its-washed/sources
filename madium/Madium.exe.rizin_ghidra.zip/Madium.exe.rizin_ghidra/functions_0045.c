// Chunk 45 - 50 functions

// ============================================================
// Function: FUN_140033d10
// Address: 0x140033d10
// Size: 67 bytes
// ============================================================
void fcn.140033d10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x27f8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x2800), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x27f8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140033d60
// Address: 0x140033d60
// Size: 505 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_27f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_beh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3088h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3078h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1840h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3090h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1640h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1638h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1630h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_187h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5cb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ab8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ac0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ae0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5aa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5aa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ad0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4160h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1208h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_50c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ad8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2170h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800f6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2800h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ba0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ba8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1688h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1690h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_30d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_30c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2128h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7cfh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Removing arg arg_eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2160h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800ffh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3990h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3980h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3988h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_eh
// WARNING: [rz-ghidra] Removing arg arg_17b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2700h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_728h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_730h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_718h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2808h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2718h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2728h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2730h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_30a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1860h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcc0102h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_39a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1820h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1818h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_489000dch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_708h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_99h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2738h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2740h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3070h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ba8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2528h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_cb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3068h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1828h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1c0h
// WARNING: [rz-ghidra] Removing arg arg_1040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2438h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_19b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1838h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6347f26bh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1830h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1940h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_36f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_36f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1628h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcc00fbh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2568h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_10f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1100h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_10f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_b1h
// WARNING: [rz-ghidra] Variable var_7h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Removing arg arg_2810h because it doesn't fit into ProtoModel

void fcn.140033d60(int64_t var_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                  int64_t arg_100h, int64_t arg_108h, int64_t arg_110h, int64_t arg_118h, int64_t arg_120h,
                  int64_t arg_128h, int64_t arg_130h, int64_t arg_138h, int64_t arg_140h, int64_t arg_148h,
                  int64_t arg_150h, int64_t arg_158h, int64_t arg_160h, int64_t arg_168h, int64_t arg_170h,
                  int64_t arg_190h, int64_t arg_198h, int64_t arg_1b8h, int64_t arg_1c0h, int64_t arg_1c8h,
                  int64_t arg_1d0h, int64_t arg_1f0h, int64_t arg_1f8h, int64_t arg_200h, int64_t arg_210h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t var_2h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_e80h;
    int64_t var_e40h;
    int64_t var_df0h;
    int64_t var_d38h;
    int64_t var_d30h;
    int64_t var_d18h;
    int64_t var_c60h;
    int64_t var_c58h;
    int64_t var_b20h;
    int64_t var_7e8h;
    int64_t var_790h;
    int64_t var_73ah;
    int64_t var_3a0h;
    int64_t var_360h;
    int64_t var_348h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_260h;
    int64_t var_250h;
    int64_t var_240h;
    int64_t var_220h;
    int64_t var_1bfh;
    int64_t var_1a8h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_160h;
    int64_t var_150h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    undefined8 uStack_20;
    int64_t var_8h;
    
    uStack_20 = 0x140033d6d;
    iVar2 = func_0x00014094c690();
    *(undefined8 *)(&stack0x000027f0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140033d8b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x000140033d9c. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (18 cases) at 0x14097a244
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a244) + 0x14097a244))();
    return;
}

// ============================================================
// Function: FUN_140033f60
// Address: 0x140033f60
// Size: 37 bytes
// ============================================================
void fcn.140033f60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140033f90
// Address: 0x140033f90
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140033f90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1408) = 2;
    fcn.14011ef20(*(undefined8 *)(arg2 + 0x2800), arg2 + 0x1408);
    return;
}

// ============================================================
// Function: FUN_140033fd0
// Address: 0x140033fd0
// Size: 25 bytes
// ============================================================
void fcn.140033fd0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140033ff0
// Address: 0x140033ff0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.140033ff0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2818));
    *(undefined8 *)(arg2 + 0x27e8) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x140033e87;
}

// ============================================================
// Function: FUN_140034030
// Address: 0x140034030
// Size: 25 bytes
// ============================================================
void fcn.140034030(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140034050
// Address: 0x140034050
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.140034050(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x27e8) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x140033e87;
}

// ============================================================
// Function: FUN_140034090
// Address: 0x140034090
// Size: 25 bytes
// ============================================================
void fcn.140034090(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400340b0
// Address: 0x1400340b0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.1400340b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2810));
    *(undefined8 *)(arg2 + 0x2800) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x140033f07;
}

// ============================================================
// Function: FUN_1400340f0
// Address: 0x1400340f0
// Size: 25 bytes
// ============================================================
void fcn.1400340f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140034110
// Address: 0x140034110
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.140034110(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2800) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x140033f07;
}

// ============================================================
// Function: FUN_140034150
// Address: 0x140034150
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel

void fcn.140034150(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x27f8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x2800), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x27f8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400341a0
// Address: 0x1400341a0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.1400341a0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400341ad;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x1400341cb;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x0001400341dc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a264) + 0x14097a264))();
    return;
}

// ============================================================
// Function: FUN_1400343a0
// Address: 0x1400343a0
// Size: 37 bytes
// ============================================================
void fcn.1400343a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1400343d0
// Address: 0x1400343d0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400343d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140034410
// Address: 0x140034410
// Size: 25 bytes
// ============================================================
void fcn.140034410(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140034430
// Address: 0x140034430
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140034430(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400342c7;
}

// ============================================================
// Function: FUN_140034470
// Address: 0x140034470
// Size: 25 bytes
// ============================================================
void fcn.140034470(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140034490
// Address: 0x140034490
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140034490(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400342c7;
}

// ============================================================
// Function: FUN_1400344d0
// Address: 0x1400344d0
// Size: 25 bytes
// ============================================================
void fcn.1400344d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400344f0
// Address: 0x1400344f0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400344f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140034347;
}

// ============================================================
// Function: FUN_140034530
// Address: 0x140034530
// Size: 25 bytes
// ============================================================
void fcn.140034530(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140034550
// Address: 0x140034550
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140034550(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140034347;
}

// ============================================================
// Function: FUN_140034590
// Address: 0x140034590
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140034590(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400345e0
// Address: 0x1400345e0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.1400345e0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400345ed;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14003460b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014003461c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a284) + 0x14097a284))();
    return;
}

// ============================================================
// Function: FUN_1400347e0
// Address: 0x1400347e0
// Size: 37 bytes
// ============================================================
void fcn.1400347e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140034810
// Address: 0x140034810
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140034810(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011da20(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140034850
// Address: 0x140034850
// Size: 25 bytes
// ============================================================
void fcn.140034850(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140034870
// Address: 0x140034870
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140034870(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140034707;
}

// ============================================================
// Function: FUN_1400348b0
// Address: 0x1400348b0
// Size: 25 bytes
// ============================================================
void fcn.1400348b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400348d0
// Address: 0x1400348d0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400348d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140034707;
}

// ============================================================
// Function: FUN_140034910
// Address: 0x140034910
// Size: 25 bytes
// ============================================================
void fcn.140034910(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140034930
// Address: 0x140034930
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140034930(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140034787;
}

// ============================================================
// Function: FUN_140034970
// Address: 0x140034970
// Size: 25 bytes
// ============================================================
void fcn.140034970(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140034990
// Address: 0x140034990
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140034990(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140034787;
}

// ============================================================
// Function: FUN_1400349d0
// Address: 0x1400349d0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.1400349d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140034a20
// Address: 0x140034a20
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.140034a20(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140034a2d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140034a4b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140034a5c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a2a4) + 0x14097a2a4))();
    return;
}

// ============================================================
// Function: FUN_140034c20
// Address: 0x140034c20
// Size: 37 bytes
// ============================================================
void fcn.140034c20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140034c50
// Address: 0x140034c50
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140034c50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140034c90
// Address: 0x140034c90
// Size: 25 bytes
// ============================================================
void fcn.140034c90(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140034cb0
// Address: 0x140034cb0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140034cb0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140034b47;
}

// ============================================================
// Function: FUN_140034cf0
// Address: 0x140034cf0
// Size: 25 bytes
// ============================================================
void fcn.140034cf0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140034d10
// Address: 0x140034d10
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140034d10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140034b47;
}

// ============================================================
// Function: FUN_140034d50
// Address: 0x140034d50
// Size: 25 bytes
// ============================================================
void fcn.140034d50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140034d70
// Address: 0x140034d70
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140034d70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140034bc7;
}

// ============================================================
// Function: FUN_140034db0
// Address: 0x140034db0
// Size: 25 bytes
// ============================================================
void fcn.140034db0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140034dd0
// Address: 0x140034dd0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140034dd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140034bc7;
}

// ============================================================
// Function: FUN_140034e10
// Address: 0x140034e10
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

void fcn.140034e10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140034e60
// Address: 0x140034e60
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.140034e60(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140034e6d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140034e8b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140034e9c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a2c4) + 0x14097a2c4))();
    return;
}

