// Chunk 20 - 50 functions

// ============================================================
// Function: FUN_140017c00
// Address: 0x140017c00
// Size: 245 bytes
// ============================================================
void fcn.140017c00(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t unaff_RBP;
    int64_t *piVar5;
    undefined8 unaff_RSI;
    int64_t iVar6;
    code *pcVar7;
    undefined8 auStack_50 [3];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    code **ppcStack_20;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar5 = &var_8h;
    var_10h = -2;
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    var_18h = arg1;
    var_8h = unaff_RBP;
    if (*piVar1 == 0) {
        auStack_50[0] = 0x140017c2d;
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(var_18h + 0x30) == 1) {
        if ((*(int64_t *)(var_18h + 0x38) != 0) && (var_28h = *(int64_t *)(var_18h + 0x40), var_28h != 0)) {
            ppcStack_20 = *(code ***)(var_18h + 0x48);
            if (*ppcStack_20 != (code *)0x0) {
                auStack_50[0] = 0x140017c7e;
                (**ppcStack_20)(var_28h);
            }
            pcVar4 = ppcStack_20[1];
            if (pcVar4 != (code *)0x0) {
                pcVar7 = ppcStack_20[2];
                *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
                auStack_50[0] = 0x140017c98;
                iVar3 = var_28h;
                goto code_r0x0001404d3c50;
            }
        }
    } else if (*(int32_t *)(var_18h + 0x30) == 0) {
        auStack_50[0] = 0x140017c4a;
        func_0x000140011040(var_18h + 0x38);
    }
    if (*(int64_t *)(var_18h + 4000) != 0) {
        auStack_50[0] = 0x140017cb6;
        (**(code **)(*(int64_t *)(var_18h + 4000) + 0x18))(*(undefined8 *)(var_18h + 0xfa8));
    }
    piVar1 = *(int64_t **)(var_18h + 0xfb0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            auStack_50[0] = 0x140017cdc;
            func_0x00014045efb0(var_18h + 0xfb0);
        }
    }
    pcVar4 = (code *)0x1000;
    pcVar7 = (code *)0x80;
    iVar3 = var_18h;
    piVar5 = (int64_t *)var_8h;
code_r0x0001404d3c50:
    *(int64_t **)((int64_t)*(undefined **)0x20 + -8) = piVar5;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
    iVar6 = iVar3;
    if ((code *)0x10 < pcVar7) {
        iVar6 = *(int64_t *)(iVar3 + -8);
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140901d3e;
    uVar2 = (*(code *)0xe5f2d8)(iVar3, pcVar4);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, iVar6);
    return;
}

// ============================================================
// Function: FUN_140017d00
// Address: 0x140017d00
// Size: 51 bytes
// ============================================================
void fcn.140017d00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140017d40
// Address: 0x140017d40
// Size: 37 bytes
// ============================================================
void fcn.140017d40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xf90);
    return;
}

// ============================================================
// Function: FUN_140017d70
// Address: 0x140017d70
// Size: 58 bytes
// ============================================================
void fcn.140017d70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xfb0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xfb0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140017db0
// Address: 0x140017db0
// Size: 41 bytes
// ============================================================
void fcn.140017db0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1000, 0x80);
    return;
}

// ============================================================
// Function: FUN_140017de0
// Address: 0x140017de0
// Size: 34 bytes
// ============================================================
void fcn.140017de0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140013030(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140017e10
// Address: 0x140017e10
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140017e10(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000d330(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xa00) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xa00) + 0x18))(*(undefined8 *)(arg1 + 0xa08));
    }
    piVar1 = *(int64_t **)(arg1 + 0xa10);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xa10);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0xa80);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140017f10
// Address: 0x140017f10
// Size: 51 bytes
// ============================================================
void fcn.140017f10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140017f50
// Address: 0x140017f50
// Size: 37 bytes
// ============================================================
void fcn.140017f50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x9f0);
    return;
}

// ============================================================
// Function: FUN_140017f80
// Address: 0x140017f80
// Size: 58 bytes
// ============================================================
void fcn.140017f80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xa10);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xa10);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140017fc0
// Address: 0x140017fc0
// Size: 41 bytes
// ============================================================
void fcn.140017fc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0xa80, 0x80);
    return;
}

// ============================================================
// Function: FUN_140017ff0
// Address: 0x140017ff0
// Size: 34 bytes
// ============================================================
void fcn.140017ff0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140011fb0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140018020
// Address: 0x140018020
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140018020(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000d590(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xa60) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xa60) + 0x18))(*(undefined8 *)(arg1 + 0xa68));
    }
    piVar1 = *(int64_t **)(arg1 + 0xa70);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xa70);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0xa80);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140018120
// Address: 0x140018120
// Size: 51 bytes
// ============================================================
void fcn.140018120(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140018160
// Address: 0x140018160
// Size: 37 bytes
// ============================================================
void fcn.140018160(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xa50);
    return;
}

// ============================================================
// Function: FUN_140018190
// Address: 0x140018190
// Size: 58 bytes
// ============================================================
void fcn.140018190(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xa70);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xa70);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1400181d0
// Address: 0x1400181d0
// Size: 41 bytes
// ============================================================
void fcn.1400181d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0xa80, 0x80);
    return;
}

// ============================================================
// Function: FUN_140018200
// Address: 0x140018200
// Size: 34 bytes
// ============================================================
void fcn.140018200(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140011ef0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140018230
// Address: 0x140018230
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140018230(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000d7f0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xa00) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xa00) + 0x18))(*(undefined8 *)(arg1 + 0xa08));
    }
    piVar1 = *(int64_t **)(arg1 + 0xa10);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xa10);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0xa80);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140018330
// Address: 0x140018330
// Size: 51 bytes
// ============================================================
void fcn.140018330(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140018370
// Address: 0x140018370
// Size: 37 bytes
// ============================================================
void fcn.140018370(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x9f0);
    return;
}

// ============================================================
// Function: FUN_1400183a0
// Address: 0x1400183a0
// Size: 58 bytes
// ============================================================
void fcn.1400183a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xa10);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xa10);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1400183e0
// Address: 0x1400183e0
// Size: 41 bytes
// ============================================================
void fcn.1400183e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0xa80, 0x80);
    return;
}

// ============================================================
// Function: FUN_140018410
// Address: 0x140018410
// Size: 34 bytes
// ============================================================
void fcn.140018410(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140011e30(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140018440
// Address: 0x140018440
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140018440(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000da50(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1870) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1870) + 0x18))(*(undefined8 *)(arg1 + 0x1878));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1880);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1880);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1900);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140018540
// Address: 0x140018540
// Size: 51 bytes
// ============================================================
void fcn.140018540(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140018580
// Address: 0x140018580
// Size: 37 bytes
// ============================================================
void fcn.140018580(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1860);
    return;
}

// ============================================================
// Function: FUN_1400185b0
// Address: 0x1400185b0
// Size: 58 bytes
// ============================================================
void fcn.1400185b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1880);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1880);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1400185f0
// Address: 0x1400185f0
// Size: 41 bytes
// ============================================================
void fcn.1400185f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1900, 0x80);
    return;
}

// ============================================================
// Function: FUN_140018620
// Address: 0x140018620
// Size: 34 bytes
// ============================================================
void fcn.140018620(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012130(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140018650
// Address: 0x140018650
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140018650(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000dcb0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x13c0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x13c0) + 0x18))(*(undefined8 *)(arg1 + 0x13c8));
    }
    piVar1 = *(int64_t **)(arg1 + 0x13d0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x13d0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1400);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140018750
// Address: 0x140018750
// Size: 51 bytes
// ============================================================
void fcn.140018750(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140018790
// Address: 0x140018790
// Size: 37 bytes
// ============================================================
void fcn.140018790(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x13b0);
    return;
}

// ============================================================
// Function: FUN_1400187c0
// Address: 0x1400187c0
// Size: 58 bytes
// ============================================================
void fcn.1400187c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x13d0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x13d0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140018800
// Address: 0x140018800
// Size: 41 bytes
// ============================================================
void fcn.140018800(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1400, 0x80);
    return;
}

// ============================================================
// Function: FUN_140018830
// Address: 0x140018830
// Size: 34 bytes
// ============================================================
void fcn.140018830(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012070(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140018860
// Address: 0x140018860
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140018860(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000e170(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1c00) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1c00) + 0x18))(*(undefined8 *)(arg1 + 0x1c08));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1c10);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1c10);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1c80);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140018960
// Address: 0x140018960
// Size: 51 bytes
// ============================================================
void fcn.140018960(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400189a0
// Address: 0x1400189a0
// Size: 37 bytes
// ============================================================
void fcn.1400189a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1bf0);
    return;
}

// ============================================================
// Function: FUN_1400189d0
// Address: 0x1400189d0
// Size: 58 bytes
// ============================================================
void fcn.1400189d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1c10);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1c10);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140018a10
// Address: 0x140018a10
// Size: 41 bytes
// ============================================================
void fcn.140018a10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1c80, 0x80);
    return;
}

// ============================================================
// Function: FUN_140018a40
// Address: 0x140018a40
// Size: 34 bytes
// ============================================================
void fcn.140018a40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012370(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140018a70
// Address: 0x140018a70
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140018a70(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000df10(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xee0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xee0) + 0x18))(*(undefined8 *)(arg1 + 0xee8));
    }
    piVar1 = *(int64_t **)(arg1 + 0xef0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xef0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0xf00);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140018b70
// Address: 0x140018b70
// Size: 51 bytes
// ============================================================
void fcn.140018b70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140018bb0
// Address: 0x140018bb0
// Size: 37 bytes
// ============================================================
void fcn.140018bb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xed0);
    return;
}

// ============================================================
// Function: FUN_140018be0
// Address: 0x140018be0
// Size: 58 bytes
// ============================================================
void fcn.140018be0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xef0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xef0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140018c20
// Address: 0x140018c20
// Size: 41 bytes
// ============================================================
void fcn.140018c20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0xf00, 0x80);
    return;
}

// ============================================================
// Function: FUN_140018c50
// Address: 0x140018c50
// Size: 34 bytes
// ============================================================
void fcn.140018c50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400122b0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140018c80
// Address: 0x140018c80
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140018c80(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000e3d0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1c90) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1c90) + 0x18))(*(undefined8 *)(arg1 + 0x1c98));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1ca0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1ca0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1d00);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140018d80
// Address: 0x140018d80
// Size: 51 bytes
// ============================================================
void fcn.140018d80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

