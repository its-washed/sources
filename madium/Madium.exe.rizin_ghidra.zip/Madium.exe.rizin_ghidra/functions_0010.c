// Chunk 10 - 50 functions

// ============================================================
// Function: FUN_14000ceb0
// Address: 0x14000ceb0
// Size: 37 bytes
// ============================================================
void fcn.14000ceb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x20) + 0x148);
    return;
}

// ============================================================
// Function: FUN_14000cee0
// Address: 0x14000cee0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000cee0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x2e18) == '\0') {
            func_0x000140002430(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x2e18) != '\x03') {
                return;
            }
            func_0x000140002430(arg1 + 0x17d0);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_14000cf60
// Address: 0x14000cf60
// Size: 51 bytes
// ============================================================
void fcn.14000cf60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14000cfa0
// Address: 0x14000cfa0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000cfa0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x2158) == '\0') {
            func_0x000140002960(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x2158) != '\x03') {
                return;
            }
            func_0x000140002960(arg1 + 0x1170);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_14000d020
// Address: 0x14000d020
// Size: 51 bytes
// ============================================================
void fcn.14000d020(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14000d060
// Address: 0x14000d060
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000d060(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x2908) == '\0') {
            func_0x0001400020d0(arg1 + 400);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x2908) != '\x03') {
                return;
            }
            func_0x0001400020d0(arg1 + 0x1548);
            func_0x00014001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_14000d0e0
// Address: 0x14000d0e0
// Size: 51 bytes
// ============================================================
void fcn.14000d0e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14000d120
// Address: 0x14000d120
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14000d120(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140003110(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xd0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xd0) + 0x18))(*(undefined8 *)(arg1 + 0xd8));
    }
    piVar1 = *(int64_t **)(arg1 + 0xe0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x00014045efb0(arg1 + 0xe0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x100);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14000d220
// Address: 0x14000d220
// Size: 51 bytes
// ============================================================
void fcn.14000d220(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14000d260
// Address: 0x14000d260
// Size: 37 bytes
// ============================================================
void fcn.14000d260(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xc0);
    return;
}

// ============================================================
// Function: FUN_14000d290
// Address: 0x14000d290
// Size: 58 bytes
// ============================================================
void fcn.14000d290(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xe0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xe0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14000d2d0
// Address: 0x14000d2d0
// Size: 41 bytes
// ============================================================
void fcn.14000d2d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x100, 0x80);
    return;
}

// ============================================================
// Function: FUN_14000d300
// Address: 0x14000d300
// Size: 34 bytes
// ============================================================
void fcn.14000d300(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400036f0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14000d330
// Address: 0x14000d330
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000d330(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x9b0) == '\0') {
        func_0x000140003840(arg1 + 0x188);
        func_0x00014001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x0001406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x9b0) != '\x03') {
            return;
        }
        func_0x000140003840(arg1 + 0x598);
        func_0x00014001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x0001406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000d400
// Address: 0x14000d400
// Size: 34 bytes
// ============================================================
void fcn.14000d400(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000d430
// Address: 0x14000d430
// Size: 57 bytes
// ============================================================
void fcn.14000d430(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000d470
// Address: 0x14000d470
// Size: 59 bytes
// ============================================================
void fcn.14000d470(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000d4b0
// Address: 0x14000d4b0
// Size: 95 bytes
// ============================================================
void fcn.14000d4b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000d510
// Address: 0x14000d510
// Size: 57 bytes
// ============================================================
void fcn.14000d510(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000d550
// Address: 0x14000d550
// Size: 59 bytes
// ============================================================
void fcn.14000d550(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000d590
// Address: 0x14000d590
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000d590(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0xa10) == '\0') {
        func_0x000140003f20(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0xa10) != '\x03') {
            return;
        }
        func_0x000140003f20(arg1 + 0x5c8);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000d660
// Address: 0x14000d660
// Size: 34 bytes
// ============================================================
void fcn.14000d660(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000d690
// Address: 0x14000d690
// Size: 57 bytes
// ============================================================
void fcn.14000d690(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000d6d0
// Address: 0x14000d6d0
// Size: 59 bytes
// ============================================================
void fcn.14000d6d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000d710
// Address: 0x14000d710
// Size: 95 bytes
// ============================================================
void fcn.14000d710(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000d770
// Address: 0x14000d770
// Size: 57 bytes
// ============================================================
void fcn.14000d770(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000d7b0
// Address: 0x14000d7b0
// Size: 59 bytes
// ============================================================
void fcn.14000d7b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000d7f0
// Address: 0x14000d7f0
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000d7f0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x9b0) == '\0') {
        func_0x000140003bb0(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x9b0) != '\x03') {
            return;
        }
        func_0x000140003bb0(arg1 + 0x598);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000d8c0
// Address: 0x14000d8c0
// Size: 34 bytes
// ============================================================
void fcn.14000d8c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000d8f0
// Address: 0x14000d8f0
// Size: 57 bytes
// ============================================================
void fcn.14000d8f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000d930
// Address: 0x14000d930
// Size: 59 bytes
// ============================================================
void fcn.14000d930(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000d970
// Address: 0x14000d970
// Size: 95 bytes
// ============================================================
void fcn.14000d970(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000d9d0
// Address: 0x14000d9d0
// Size: 57 bytes
// ============================================================
void fcn.14000d9d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000da10
// Address: 0x14000da10
// Size: 59 bytes
// ============================================================
void fcn.14000da10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000da50
// Address: 0x14000da50
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000da50(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x1820) == '\0') {
        func_0x0001400046c0(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x1820) != '\x03') {
            return;
        }
        func_0x0001400046c0(arg1 + 0xcd0);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000db20
// Address: 0x14000db20
// Size: 34 bytes
// ============================================================
void fcn.14000db20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000db50
// Address: 0x14000db50
// Size: 57 bytes
// ============================================================
void fcn.14000db50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000db90
// Address: 0x14000db90
// Size: 59 bytes
// ============================================================
void fcn.14000db90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000dbd0
// Address: 0x14000dbd0
// Size: 95 bytes
// ============================================================
void fcn.14000dbd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000dc30
// Address: 0x14000dc30
// Size: 57 bytes
// ============================================================
void fcn.14000dc30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000dc70
// Address: 0x14000dc70
// Size: 59 bytes
// ============================================================
void fcn.14000dc70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000dcb0
// Address: 0x14000dcb0
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000dcb0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x1370) == '\0') {
        func_0x000140004290(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x1370) != '\x03') {
            return;
        }
        func_0x000140004290(arg1 + 0xa78);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000dd80
// Address: 0x14000dd80
// Size: 34 bytes
// ============================================================
void fcn.14000dd80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000ddb0
// Address: 0x14000ddb0
// Size: 57 bytes
// ============================================================
void fcn.14000ddb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000ddf0
// Address: 0x14000ddf0
// Size: 59 bytes
// ============================================================
void fcn.14000ddf0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000de30
// Address: 0x14000de30
// Size: 95 bytes
// ============================================================
void fcn.14000de30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000de90
// Address: 0x14000de90
// Size: 57 bytes
// ============================================================
void fcn.14000de90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000ded0
// Address: 0x14000ded0
// Size: 59 bytes
// ============================================================
void fcn.14000ded0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000df10
// Address: 0x14000df10
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000df10(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0xe90) == '\0') {
        func_0x0001400052c0(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0xe90) != '\x03') {
            return;
        }
        func_0x0001400052c0(arg1 + 0x808);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000dfe0
// Address: 0x14000dfe0
// Size: 34 bytes
// ============================================================
void fcn.14000dfe0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

