// Chunk 18 - 50 functions

// ============================================================
// Function: FUN_140015a30
// Address: 0x140015a30
// Size: 37 bytes
// ============================================================
void fcn.140015a30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1380);
    return;
}

// ============================================================
// Function: FUN_140015a60
// Address: 0x140015a60
// Size: 58 bytes
// ============================================================
void fcn.140015a60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x13a0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x13a0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140015aa0
// Address: 0x140015aa0
// Size: 41 bytes
// ============================================================
void fcn.140015aa0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1400, 0x80);
    return;
}

// ============================================================
// Function: FUN_140015ad0
// Address: 0x140015ad0
// Size: 34 bytes
// ============================================================
void fcn.140015ad0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012430(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140015b00
// Address: 0x140015b00
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140015b00(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140010050(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1510) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1510) + 0x18))(*(undefined8 *)(arg1 + 0x1518));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1520);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1520);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1580);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140015c00
// Address: 0x140015c00
// Size: 51 bytes
// ============================================================
void fcn.140015c00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140015c40
// Address: 0x140015c40
// Size: 37 bytes
// ============================================================
void fcn.140015c40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1500);
    return;
}

// ============================================================
// Function: FUN_140015c70
// Address: 0x140015c70
// Size: 58 bytes
// ============================================================
void fcn.140015c70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1520);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1520);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140015cb0
// Address: 0x140015cb0
// Size: 41 bytes
// ============================================================
void fcn.140015cb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1580, 0x80);
    return;
}

// ============================================================
// Function: FUN_140015ce0
// Address: 0x140015ce0
// Size: 34 bytes
// ============================================================
void fcn.140015ce0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012670(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140015d10
// Address: 0x140015d10
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140015d10(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000e890(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x13f0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x13f0) + 0x18))(*(undefined8 *)(arg1 + 0x13f8));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1400);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1400);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1480);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140015e10
// Address: 0x140015e10
// Size: 51 bytes
// ============================================================
void fcn.140015e10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140015e50
// Address: 0x140015e50
// Size: 37 bytes
// ============================================================
void fcn.140015e50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x13e0);
    return;
}

// ============================================================
// Function: FUN_140015e80
// Address: 0x140015e80
// Size: 58 bytes
// ============================================================
void fcn.140015e80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1400);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1400);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140015ec0
// Address: 0x140015ec0
// Size: 41 bytes
// ============================================================
void fcn.140015ec0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1480, 0x80);
    return;
}

// ============================================================
// Function: FUN_140015ef0
// Address: 0x140015ef0
// Size: 34 bytes
// ============================================================
void fcn.140015ef0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012a30(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140015f20
// Address: 0x140015f20
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140015f20(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000fdf0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x14b0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x14b0) + 0x18))(*(undefined8 *)(arg1 + 0x14b8));
    }
    piVar1 = *(int64_t **)(arg1 + 0x14c0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x14c0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1500);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140016020
// Address: 0x140016020
// Size: 51 bytes
// ============================================================
void fcn.140016020(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140016060
// Address: 0x140016060
// Size: 37 bytes
// ============================================================
void fcn.140016060(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x14a0);
    return;
}

// ============================================================
// Function: FUN_140016090
// Address: 0x140016090
// Size: 58 bytes
// ============================================================
void fcn.140016090(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x14c0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x14c0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1400160d0
// Address: 0x1400160d0
// Size: 41 bytes
// ============================================================
void fcn.1400160d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1500, 0x80);
    return;
}

// ============================================================
// Function: FUN_140016100
// Address: 0x140016100
// Size: 34 bytes
// ============================================================
void fcn.140016100(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400125b0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140016130
// Address: 0x140016130
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140016130(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000efb0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1900) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1900) + 0x18))(*(undefined8 *)(arg1 + 0x1908));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1910);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1910);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1980);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140016230
// Address: 0x140016230
// Size: 51 bytes
// ============================================================
void fcn.140016230(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140016270
// Address: 0x140016270
// Size: 37 bytes
// ============================================================
void fcn.140016270(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x18f0);
    return;
}

// ============================================================
// Function: FUN_1400162a0
// Address: 0x1400162a0
// Size: 58 bytes
// ============================================================
void fcn.1400162a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1910);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1910);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1400162e0
// Address: 0x1400162e0
// Size: 41 bytes
// ============================================================
void fcn.1400162e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1980, 0x80);
    return;
}

// ============================================================
// Function: FUN_140016310
// Address: 0x140016310
// Size: 34 bytes
// ============================================================
void fcn.140016310(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012c70(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140016340
// Address: 0x140016340
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140016340(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000eaf0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1390) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1390) + 0x18))(*(undefined8 *)(arg1 + 0x1398));
    }
    piVar1 = *(int64_t **)(arg1 + 0x13a0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x13a0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1400);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140016440
// Address: 0x140016440
// Size: 51 bytes
// ============================================================
void fcn.140016440(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140016480
// Address: 0x140016480
// Size: 37 bytes
// ============================================================
void fcn.140016480(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1380);
    return;
}

// ============================================================
// Function: FUN_1400164b0
// Address: 0x1400164b0
// Size: 58 bytes
// ============================================================
void fcn.1400164b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x13a0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x13a0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1400164f0
// Address: 0x1400164f0
// Size: 41 bytes
// ============================================================
void fcn.1400164f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1400, 0x80);
    return;
}

// ============================================================
// Function: FUN_140016520
// Address: 0x140016520
// Size: 34 bytes
// ============================================================
void fcn.140016520(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400127f0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140016550
// Address: 0x140016550
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140016550(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000f930(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1390) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1390) + 0x18))(*(undefined8 *)(arg1 + 0x1398));
    }
    piVar1 = *(int64_t **)(arg1 + 0x13a0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x13a0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1400);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140016650
// Address: 0x140016650
// Size: 51 bytes
// ============================================================
void fcn.140016650(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140016690
// Address: 0x140016690
// Size: 37 bytes
// ============================================================
void fcn.140016690(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1380);
    return;
}

// ============================================================
// Function: FUN_1400166c0
// Address: 0x1400166c0
// Size: 58 bytes
// ============================================================
void fcn.1400166c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x13a0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x13a0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140016700
// Address: 0x140016700
// Size: 41 bytes
// ============================================================
void fcn.140016700(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1400, 0x80);
    return;
}

// ============================================================
// Function: FUN_140016730
// Address: 0x140016730
// Size: 34 bytes
// ============================================================
void fcn.140016730(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012af0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140016760
// Address: 0x140016760
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140016760(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000ed50(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1420) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1420) + 0x18))(*(undefined8 *)(arg1 + 0x1428));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1430);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1430);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1480);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140016860
// Address: 0x140016860
// Size: 51 bytes
// ============================================================
void fcn.140016860(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400168a0
// Address: 0x1400168a0
// Size: 37 bytes
// ============================================================
void fcn.1400168a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1410);
    return;
}

// ============================================================
// Function: FUN_1400168d0
// Address: 0x1400168d0
// Size: 58 bytes
// ============================================================
void fcn.1400168d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1430);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1430);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140016910
// Address: 0x140016910
// Size: 41 bytes
// ============================================================
void fcn.140016910(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1480, 0x80);
    return;
}

// ============================================================
// Function: FUN_140016940
// Address: 0x140016940
// Size: 34 bytes
// ============================================================
void fcn.140016940(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012970(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140016970
// Address: 0x140016970
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140016970(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000f470(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x13f0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x13f0) + 0x18))(*(undefined8 *)(arg1 + 0x13f8));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1400);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1400);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1480);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140016a70
// Address: 0x140016a70
// Size: 51 bytes
// ============================================================
void fcn.140016a70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140016ab0
// Address: 0x140016ab0
// Size: 37 bytes
// ============================================================
void fcn.140016ab0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x13e0);
    return;
}

// ============================================================
// Function: FUN_140016ae0
// Address: 0x140016ae0
// Size: 58 bytes
// ============================================================
void fcn.140016ae0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1400);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1400);
        }
    }
    return;
}

