// Chunk 27 - 50 functions

// ============================================================
// Function: FUN_14001f7e0
// Address: 0x14001f7e0
// Size: 53 bytes
// ============================================================
undefined8 fcn.14001f7e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xf08) = uVar1;
    *(int64_t *)(arg2 + 0xef8) = iVar2;
    return 0x14001f6ba;
}

// ============================================================
// Function: FUN_14001f820
// Address: 0x14001f820
// Size: 24 bytes
// ============================================================
void fcn.14001f820(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001f840
// Address: 0x14001f840
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ea0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e78h because it doesn't fit into ProtoModel

undefined8 fcn.14001f840(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xf20));
    *(undefined8 *)(arg2 + 0xf08) = uVar1;
    *(int64_t *)(arg2 + 0xef8) = iVar2;
    return 0x14001f6ba;
}

// ============================================================
// Function: FUN_14001f880
// Address: 0x14001f880
// Size: 24 bytes
// ============================================================
void fcn.14001f880(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001f8a0
// Address: 0x14001f8a0
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14001f8a0(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14001f8ab;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00001e98 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00001e80 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001f8d8;
    fcn.14011d460();
    *(undefined8 *)(&stack0x00000f58 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00001e80 + iVar1) + 8);
    *(undefined8 *)(&stack0x00000f60 + iVar1) = 0;
    *(undefined8 *)(&stack0x00000f68 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00000f50 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001f910;
    fcn.14011d460(*(int64_t *)(&stack0x00001e80 + iVar1), &stack0x00000f50 + iVar1);
    return;
}

// ============================================================
// Function: FUN_14001f930
// Address: 0x14001f930
// Size: 23 bytes
// ============================================================
void fcn.14001f930(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001f950
// Address: 0x14001f950
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.14001f950(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1ea8));
    *(undefined8 *)(arg2 + 0x1e90) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x14001f91a;
}

// ============================================================
// Function: FUN_14001f990
// Address: 0x14001f990
// Size: 23 bytes
// ============================================================
void fcn.14001f990(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001f9b0
// Address: 0x14001f9b0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.14001f9b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1e90) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x14001f91a;
}

// ============================================================
// Function: FUN_14001f9f0
// Address: 0x14001f9f0
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_27f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1410h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14001f9f0(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14001f9fb;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000027f8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000027e0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001fa28;
    fcn.14011ef20();
    *(undefined8 *)(&stack0x00001408 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000027e0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00001410 + iVar1) = 0;
    *(undefined8 *)(&stack0x00001418 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00001400 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001fa60;
    fcn.14011ef20(*(int64_t *)(&stack0x000027e0 + iVar1), &stack0x00001400 + iVar1);
    return;
}

// ============================================================
// Function: FUN_14001fa80
// Address: 0x14001fa80
// Size: 23 bytes
// ============================================================
void fcn.14001fa80(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001faa0
// Address: 0x14001faa0
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.14001faa0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2808));
    *(undefined8 *)(arg2 + 0x27f0) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x14001fa6a;
}

// ============================================================
// Function: FUN_14001fae0
// Address: 0x14001fae0
// Size: 23 bytes
// ============================================================
void fcn.14001fae0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001fb00
// Address: 0x14001fb00
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.14001fb00(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x27f0) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x14001fa6a;
}

// ============================================================
// Function: FUN_14001fb40
// Address: 0x14001fb40
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3980h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14001fb40(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14001fb4b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00003998 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00003980 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001fb78;
    fcn.14011f370();
    *(undefined8 *)(&stack0x00001cd8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00003980 + iVar1) + 8);
    *(undefined8 *)(&stack0x00001ce0 + iVar1) = 0;
    *(undefined8 *)(&stack0x00001ce8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00001cd0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001fbb0;
    fcn.14011f370(*(int64_t *)(&stack0x00003980 + iVar1), &stack0x00001cd0 + iVar1);
    return;
}

// ============================================================
// Function: FUN_14001fbd0
// Address: 0x14001fbd0
// Size: 23 bytes
// ============================================================
void fcn.14001fbd0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001fbf0
// Address: 0x14001fbf0
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3918h because it doesn't fit into ProtoModel

undefined8 fcn.14001fbf0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x39a8));
    *(undefined8 *)(arg2 + 0x3990) = uVar1;
    *(int64_t *)(arg2 + 0x3998) = iVar2;
    return 0x14001fbba;
}

// ============================================================
// Function: FUN_14001fc30
// Address: 0x14001fc30
// Size: 23 bytes
// ============================================================
void fcn.14001fc30(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001fc50
// Address: 0x14001fc50
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3918h because it doesn't fit into ProtoModel

undefined8 fcn.14001fc50(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x3990) = uVar1;
    *(int64_t *)(arg2 + 0x3998) = iVar2;
    return 0x14001fbba;
}

// ============================================================
// Function: FUN_14001fc90
// Address: 0x14001fc90
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14001fc90(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14001fc9b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000013b8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000013a0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001fcc8;
    fcn.14011e3a0();
    *(undefined8 *)(&stack0x000009e8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000013a0 + iVar1) + 8);
    *(undefined8 *)(&stack0x000009f0 + iVar1) = 0;
    *(undefined8 *)(&stack0x000009f8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x000009e0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001fd00;
    fcn.14011e3a0(*(int64_t *)(&stack0x000013a0 + iVar1), &stack0x000009e0 + iVar1);
    return;
}

// ============================================================
// Function: FUN_14001fd20
// Address: 0x14001fd20
// Size: 23 bytes
// ============================================================
void fcn.14001fd20(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001fd40
// Address: 0x14001fd40
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.14001fd40(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13c8));
    *(undefined8 *)(arg2 + 0x13b0) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x14001fd0a;
}

// ============================================================
// Function: FUN_14001fd80
// Address: 0x14001fd80
// Size: 23 bytes
// ============================================================
void fcn.14001fd80(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001fda0
// Address: 0x14001fda0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.14001fda0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x13b0) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x14001fd0a;
}

// ============================================================
// Function: FUN_14001fde0
// Address: 0x14001fde0
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14001fde0(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14001fdeb;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00001e98 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00001e80 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001fe18;
    fcn.14011e960();
    *(undefined8 *)(&stack0x00000f58 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00001e80 + iVar1) + 8);
    *(undefined8 *)(&stack0x00000f60 + iVar1) = 0;
    *(undefined8 *)(&stack0x00000f68 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00000f50 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001fe50;
    fcn.14011e960(*(int64_t *)(&stack0x00001e80 + iVar1), &stack0x00000f50 + iVar1);
    return;
}

// ============================================================
// Function: FUN_14001fe70
// Address: 0x14001fe70
// Size: 23 bytes
// ============================================================
void fcn.14001fe70(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001fe90
// Address: 0x14001fe90
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.14001fe90(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1ea8));
    *(undefined8 *)(arg2 + 0x1e90) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x14001fe5a;
}

// ============================================================
// Function: FUN_14001fed0
// Address: 0x14001fed0
// Size: 23 bytes
// ============================================================
void fcn.14001fed0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001fef0
// Address: 0x14001fef0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.14001fef0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1e90) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x14001fe5a;
}

// ============================================================
// Function: FUN_14001ff30
// Address: 0x14001ff30
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_5c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14001ff30(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14001ff3b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00005c78 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00005c60 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001ff68;
    fcn.14011d2f0();
    *(undefined8 *)(&stack0x00002e48 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00005c60 + iVar1) + 8);
    *(undefined8 *)(&stack0x00002e50 + iVar1) = 0;
    *(undefined8 *)(&stack0x00002e58 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00002e40 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001ffa0;
    fcn.14011d2f0(*(int64_t *)(&stack0x00005c60 + iVar1), &stack0x00002e40 + iVar1);
    return;
}

// ============================================================
// Function: FUN_14001ffc0
// Address: 0x14001ffc0
// Size: 23 bytes
// ============================================================
void fcn.14001ffc0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001ffe0
// Address: 0x14001ffe0
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_5c08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5bf8h because it doesn't fit into ProtoModel

undefined8 fcn.14001ffe0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x5c88));
    *(undefined8 *)(arg2 + 0x5c70) = uVar1;
    *(int64_t *)(arg2 + 0x5c78) = iVar2;
    return 0x14001ffaa;
}

// ============================================================
// Function: FUN_140020020
// Address: 0x140020020
// Size: 23 bytes
// ============================================================
void fcn.140020020(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020040
// Address: 0x140020040
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_5bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5bf8h because it doesn't fit into ProtoModel

undefined8 fcn.140020040(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x5c70) = uVar1;
    *(int64_t *)(arg2 + 0x5c78) = iVar2;
    return 0x14001ffaa;
}

// ============================================================
// Function: FUN_140020080
// Address: 0x140020080
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140020080(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002008b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00001e98 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00001e80 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400200b8;
    fcn.14011f650();
    *(undefined8 *)(&stack0x00000f58 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00001e80 + iVar1) + 8);
    *(undefined8 *)(&stack0x00000f60 + iVar1) = 0;
    *(undefined8 *)(&stack0x00000f68 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00000f50 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400200f0;
    fcn.14011f650(*(int64_t *)(&stack0x00001e80 + iVar1), &stack0x00000f50 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140020110
// Address: 0x140020110
// Size: 23 bytes
// ============================================================
void fcn.140020110(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020130
// Address: 0x140020130
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140020130(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1ea8));
    *(undefined8 *)(arg2 + 0x1e90) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x1400200fa;
}

// ============================================================
// Function: FUN_140020170
// Address: 0x140020170
// Size: 23 bytes
// ============================================================
void fcn.140020170(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020190
// Address: 0x140020190
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140020190(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1e90) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x1400200fa;
}

// ============================================================
// Function: FUN_1400201d0
// Address: 0x1400201d0
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1ef8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400201d0(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1400201db;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00001ef8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00001ee0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020208;
    fcn.14011ffd0();
    *(undefined8 *)(&stack0x00000f88 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00001ee0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00000f90 + iVar1) = 0;
    *(undefined8 *)(&stack0x00000f98 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00000f80 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020240;
    fcn.14011ffd0(*(int64_t *)(&stack0x00001ee0 + iVar1), &stack0x00000f80 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140020260
// Address: 0x140020260
// Size: 23 bytes
// ============================================================
void fcn.140020260(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020280
// Address: 0x140020280
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e78h because it doesn't fit into ProtoModel

undefined8 fcn.140020280(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1f08));
    *(undefined8 *)(arg2 + 0x1ef0) = uVar1;
    *(int64_t *)(arg2 + 0x1ef8) = iVar2;
    return 0x14002024a;
}

// ============================================================
// Function: FUN_1400202c0
// Address: 0x1400202c0
// Size: 23 bytes
// ============================================================
void fcn.1400202c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400202e0
// Address: 0x1400202e0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e78h because it doesn't fit into ProtoModel

undefined8 fcn.1400202e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1ef0) = uVar1;
    *(int64_t *)(arg2 + 0x1ef8) = iVar2;
    return 0x14002024a;
}

// ============================================================
// Function: FUN_140020320
// Address: 0x140020320
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1640h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140020320(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002032b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00001658 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00001640 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020358;
    fcn.14011e510();
    *(undefined8 *)(&stack0x00000b38 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00001640 + iVar1) + 8);
    *(undefined8 *)(&stack0x00000b40 + iVar1) = 0;
    *(undefined8 *)(&stack0x00000b48 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00000b30 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020390;
    fcn.14011e510(*(int64_t *)(&stack0x00001640 + iVar1), &stack0x00000b30 + iVar1);
    return;
}

// ============================================================
// Function: FUN_1400203b0
// Address: 0x1400203b0
// Size: 23 bytes
// ============================================================
void fcn.1400203b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400203d0
// Address: 0x1400203d0
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_15e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15d8h because it doesn't fit into ProtoModel

undefined8 fcn.1400203d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1668));
    *(undefined8 *)(arg2 + 0x1650) = uVar1;
    *(int64_t *)(arg2 + 0x1658) = iVar2;
    return 0x14002039a;
}

// ============================================================
// Function: FUN_140020410
// Address: 0x140020410
// Size: 23 bytes
// ============================================================
void fcn.140020410(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020430
// Address: 0x140020430
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_15d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15d8h because it doesn't fit into ProtoModel

undefined8 fcn.140020430(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1650) = uVar1;
    *(int64_t *)(arg2 + 0x1658) = iVar2;
    return 0x14002039a;
}

// ============================================================
// Function: FUN_140020470
// Address: 0x140020470
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2738h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140020470(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002047b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00002738 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00002720 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400204a8;
    fcn.14011f090();
    *(undefined8 *)(&stack0x000013a8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00002720 + iVar1) + 8);
    *(undefined8 *)(&stack0x000013b0 + iVar1) = 0;
    *(undefined8 *)(&stack0x000013b8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x000013a0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400204e0;
    fcn.14011f090(*(int64_t *)(&stack0x00002720 + iVar1), &stack0x000013a0 + iVar1);
    return;
}

