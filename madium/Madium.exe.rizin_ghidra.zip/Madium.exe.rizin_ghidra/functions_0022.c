// Chunk 22 - 50 functions

// ============================================================
// Function: FUN_140019eb0
// Address: 0x140019eb0
// Size: 41 bytes
// ============================================================
void fcn.140019eb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1980, 0x80);
    return;
}

// ============================================================
// Function: FUN_140019ee0
// Address: 0x140019ee0
// Size: 34 bytes
// ============================================================
void fcn.140019ee0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012c70(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140019f10
// Address: 0x140019f10
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140019f10(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140010050(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1510) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1510) + 0x18))(*(undefined8 *)(arg1 + 0x1518));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1520);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x00014045efb0(arg1 + 0x1520);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1580);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001a010
// Address: 0x14001a010
// Size: 51 bytes
// ============================================================
void fcn.14001a010(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001a050
// Address: 0x14001a050
// Size: 37 bytes
// ============================================================
void fcn.14001a050(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1500);
    return;
}

// ============================================================
// Function: FUN_14001a080
// Address: 0x14001a080
// Size: 58 bytes
// ============================================================
void fcn.14001a080(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1520);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1520);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001a0c0
// Address: 0x14001a0c0
// Size: 41 bytes
// ============================================================
void fcn.14001a0c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1580, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001a0f0
// Address: 0x14001a0f0
// Size: 34 bytes
// ============================================================
void fcn.14001a0f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012670(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001a120
// Address: 0x14001a120
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001a120(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000f210(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1cf0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1cf0) + 0x18))(*(undefined8 *)(arg1 + 0x1cf8));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1d00);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1d00);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1d80);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001a220
// Address: 0x14001a220
// Size: 51 bytes
// ============================================================
void fcn.14001a220(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001a260
// Address: 0x14001a260
// Size: 37 bytes
// ============================================================
void fcn.14001a260(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1ce0);
    return;
}

// ============================================================
// Function: FUN_14001a290
// Address: 0x14001a290
// Size: 58 bytes
// ============================================================
void fcn.14001a290(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1d00);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1d00);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001a2d0
// Address: 0x14001a2d0
// Size: 41 bytes
// ============================================================
void fcn.14001a2d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1d80, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001a300
// Address: 0x14001a300
// Size: 34 bytes
// ============================================================
void fcn.14001a300(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400124f0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001a330
// Address: 0x14001a330
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001a330(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000fdf0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x14b0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x14b0) + 0x18))(*(undefined8 *)(arg1 + 0x14b8));
    }
    piVar1 = *(int64_t **)(arg1 + 0x14c0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x14c0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1500);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001a430
// Address: 0x14001a430
// Size: 51 bytes
// ============================================================
void fcn.14001a430(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001a470
// Address: 0x14001a470
// Size: 37 bytes
// ============================================================
void fcn.14001a470(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x14a0);
    return;
}

// ============================================================
// Function: FUN_14001a4a0
// Address: 0x14001a4a0
// Size: 58 bytes
// ============================================================
void fcn.14001a4a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x14c0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x14c0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001a4e0
// Address: 0x14001a4e0
// Size: 41 bytes
// ============================================================
void fcn.14001a4e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1500, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001a510
// Address: 0x14001a510
// Size: 34 bytes
// ============================================================
void fcn.14001a510(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400125b0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001a540
// Address: 0x14001a540
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001a540(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000f930(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1390) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1390) + 0x18))(*(undefined8 *)(arg1 + 0x1398));
    }
    piVar1 = *(int64_t **)(arg1 + 0x13a0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x13a0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1400);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001a640
// Address: 0x14001a640
// Size: 51 bytes
// ============================================================
void fcn.14001a640(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001a680
// Address: 0x14001a680
// Size: 37 bytes
// ============================================================
void fcn.14001a680(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1380);
    return;
}

// ============================================================
// Function: FUN_14001a6b0
// Address: 0x14001a6b0
// Size: 58 bytes
// ============================================================
void fcn.14001a6b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x13a0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x13a0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001a6f0
// Address: 0x14001a6f0
// Size: 41 bytes
// ============================================================
void fcn.14001a6f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1400, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001a720
// Address: 0x14001a720
// Size: 34 bytes
// ============================================================
void fcn.14001a720(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012af0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001a750
// Address: 0x14001a750
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001a750(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x0001400102b0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xf70) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xf70) + 0x18))(*(undefined8 *)(arg1 + 0xf78));
    }
    piVar1 = *(int64_t **)(arg1 + 0xf80);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xf80);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1000);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001a850
// Address: 0x14001a850
// Size: 51 bytes
// ============================================================
void fcn.14001a850(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001a890
// Address: 0x14001a890
// Size: 37 bytes
// ============================================================
void fcn.14001a890(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xf60);
    return;
}

// ============================================================
// Function: FUN_14001a8c0
// Address: 0x14001a8c0
// Size: 58 bytes
// ============================================================
void fcn.14001a8c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xf80);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xf80);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001a900
// Address: 0x14001a900
// Size: 41 bytes
// ============================================================
void fcn.14001a900(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1000, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001a930
// Address: 0x14001a930
// Size: 34 bytes
// ============================================================
void fcn.14001a930(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012d30(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001a960
// Address: 0x14001a960
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001a960(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140010770(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xf70) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xf70) + 0x18))(*(undefined8 *)(arg1 + 0xf78));
    }
    piVar1 = *(int64_t **)(arg1 + 0xf80);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xf80);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1000);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001aa60
// Address: 0x14001aa60
// Size: 51 bytes
// ============================================================
void fcn.14001aa60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001aaa0
// Address: 0x14001aaa0
// Size: 37 bytes
// ============================================================
void fcn.14001aaa0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xf60);
    return;
}

// ============================================================
// Function: FUN_14001aad0
// Address: 0x14001aad0
// Size: 58 bytes
// ============================================================
void fcn.14001aad0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xf80);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xf80);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001ab10
// Address: 0x14001ab10
// Size: 41 bytes
// ============================================================
void fcn.14001ab10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1000, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001ab40
// Address: 0x14001ab40
// Size: 34 bytes
// ============================================================
void fcn.14001ab40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012df0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001ab70
// Address: 0x14001ab70
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001ab70(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140010b80(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1000) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1000) + 0x18))(*(undefined8 *)(arg1 + 0x1008));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1010);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1010);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1080);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001ac70
// Address: 0x14001ac70
// Size: 51 bytes
// ============================================================
void fcn.14001ac70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001acb0
// Address: 0x14001acb0
// Size: 37 bytes
// ============================================================
void fcn.14001acb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xff0);
    return;
}

// ============================================================
// Function: FUN_14001ace0
// Address: 0x14001ace0
// Size: 58 bytes
// ============================================================
void fcn.14001ace0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1010);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1010);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001ad20
// Address: 0x14001ad20
// Size: 41 bytes
// ============================================================
void fcn.14001ad20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1080, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001ad50
// Address: 0x14001ad50
// Size: 34 bytes
// ============================================================
void fcn.14001ad50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400131b0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001ad80
// Address: 0x14001ad80
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001ad80(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140010de0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xf70) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xf70) + 0x18))(*(undefined8 *)(arg1 + 0xf78));
    }
    piVar1 = *(int64_t **)(arg1 + 0xf80);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xf80);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1000);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001ae80
// Address: 0x14001ae80
// Size: 51 bytes
// ============================================================
void fcn.14001ae80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001aec0
// Address: 0x14001aec0
// Size: 37 bytes
// ============================================================
void fcn.14001aec0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xf60);
    return;
}

// ============================================================
// Function: FUN_14001aef0
// Address: 0x14001aef0
// Size: 58 bytes
// ============================================================
void fcn.14001aef0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xf80);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xf80);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001af30
// Address: 0x14001af30
// Size: 41 bytes
// ============================================================
void fcn.14001af30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1000, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001af60
// Address: 0x14001af60
// Size: 34 bytes
// ============================================================
void fcn.14001af60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400130f0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

