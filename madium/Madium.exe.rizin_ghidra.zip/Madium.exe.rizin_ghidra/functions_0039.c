// Chunk 39 - 50 functions

// ============================================================
// Function: FUN_14002d630
// Address: 0x14002d630
// Size: 47 bytes
// ============================================================
undefined8 fcn.14002d630(undefined8 placeholder_0, int64_t arg2, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xc0) = uVar1;
    *(int64_t *)(arg2 + 200) = iVar2;
    return 0x14002d58f;
}

// ============================================================
// Function: FUN_14002d660
// Address: 0x14002d660
// Size: 56 bytes
// ============================================================
void fcn.14002d660(undefined8 placeholder_0, int64_t arg2, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 200) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xc0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 200) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002d6a0
// Address: 0x14002d6a0
// Size: 24 bytes
// ============================================================
void fcn.14002d6a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002d6c0
// Address: 0x14002d6c0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002d6c0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_130h;
    int64_t var_d8h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_130h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011ec40(var_40h + 0x20, &var_130h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0x120, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014000c950(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002d7b0
// Address: 0x14002d7b0
// Size: 58 bytes
// ============================================================
undefined8 fcn.14002d7b0(undefined8 placeholder_0, int64_t arg2, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_c0h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x140));
    *(undefined8 *)(arg2 + 0x120) = uVar1;
    *(int64_t *)(arg2 + 0x128) = iVar2;
    return 0x14002d754;
}

// ============================================================
// Function: FUN_14002d7f0
// Address: 0x14002d7f0
// Size: 24 bytes
// ============================================================
void fcn.14002d7f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002d810
// Address: 0x14002d810
// Size: 53 bytes
// ============================================================
undefined8 fcn.14002d810(undefined8 placeholder_0, int64_t arg2, int64_t arg_a0h, int64_t arg_a8h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x120) = uVar1;
    *(int64_t *)(arg2 + 0x128) = iVar2;
    return 0x14002d754;
}

// ============================================================
// Function: FUN_14002d850
// Address: 0x14002d850
// Size: 65 bytes
// ============================================================
void fcn.14002d850(undefined8 placeholder_0, int64_t arg2, int64_t arg_a0h, int64_t arg_a8h)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x128) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x120), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x128) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002d8a0
// Address: 0x14002d8a0
// Size: 24 bytes
// ============================================================
void fcn.14002d8a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002d8c0
// Address: 0x14002d8c0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002d8c0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_b50h;
    int64_t var_af8h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_b50h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011e510(var_40h + 0x20, &var_b50h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xb40, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014001b800(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002d9b0
// Address: 0x14002d9b0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ae0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ac0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ac8h because it doesn't fit into ProtoModel

undefined8 fcn.14002d9b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xb60));
    *(undefined8 *)(arg2 + 0xb40) = uVar1;
    *(int64_t *)(arg2 + 0xb48) = iVar2;
    return 0x14002d954;
}

// ============================================================
// Function: FUN_14002d9f0
// Address: 0x14002d9f0
// Size: 24 bytes
// ============================================================
void fcn.14002d9f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002da10
// Address: 0x14002da10
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ac0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ac8h because it doesn't fit into ProtoModel

undefined8 fcn.14002da10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xb40) = uVar1;
    *(int64_t *)(arg2 + 0xb48) = iVar2;
    return 0x14002d954;
}

// ============================================================
// Function: FUN_14002da50
// Address: 0x14002da50
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ac8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ac0h because it doesn't fit into ProtoModel

void fcn.14002da50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xb48) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xb40), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xb48) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002daa0
// Address: 0x14002daa0
// Size: 24 bytes
// ============================================================
void fcn.14002daa0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002dac0
// Address: 0x14002dac0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e7h because it doesn't fit into ProtoModel

void fcn.14002dac0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002dacc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x000013e8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x000013c8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002daee;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x000013e7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002db14;
        func_0x00014011e7f0(*(int64_t *)(&stack0x000013c8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x000013e7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002db34;
        func_0x000140796b10(*(int64_t *)(&stack0x000013c8 + iVar4) + 0x13e0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x000013c8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002db43;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002db4f;
        func_0x000140015d10(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002dbc0
// Address: 0x14002dbc0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel

undefined8 fcn.14002dbc0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1400));
    *(undefined8 *)(arg2 + 0x13e0) = uVar1;
    *(int64_t *)(arg2 + 0x13e8) = iVar2;
    return 0x14002db5a;
}

// ============================================================
// Function: FUN_14002dc00
// Address: 0x14002dc00
// Size: 24 bytes
// ============================================================
void fcn.14002dc00(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002dc20
// Address: 0x14002dc20
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel

undefined8 fcn.14002dc20(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x13e0) = uVar1;
    *(int64_t *)(arg2 + 0x13e8) = iVar2;
    return 0x14002db5a;
}

// ============================================================
// Function: FUN_14002dc60
// Address: 0x14002dc60
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel

void fcn.14002dc60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x13e8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x13e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x13e8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002dcb0
// Address: 0x14002dcb0
// Size: 24 bytes
// ============================================================
void fcn.14002dcb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002dcd0
// Address: 0x14002dcd0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002dcd0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_c10h;
    int64_t var_bb8h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_c10h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011f4e0(var_40h + 0x20, &var_c10h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xc00, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014001b5f0(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002ddc0
// Address: 0x14002ddc0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ba0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b88h because it doesn't fit into ProtoModel

undefined8 fcn.14002ddc0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xc20));
    *(undefined8 *)(arg2 + 0xc00) = uVar1;
    *(int64_t *)(arg2 + 0xc08) = iVar2;
    return 0x14002dd64;
}

// ============================================================
// Function: FUN_14002de00
// Address: 0x14002de00
// Size: 24 bytes
// ============================================================
void fcn.14002de00(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002de20
// Address: 0x14002de20
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b88h because it doesn't fit into ProtoModel

undefined8 fcn.14002de20(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xc00) = uVar1;
    *(int64_t *)(arg2 + 0xc08) = iVar2;
    return 0x14002dd64;
}

// ============================================================
// Function: FUN_14002de60
// Address: 0x14002de60
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_b88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b80h because it doesn't fit into ProtoModel

void fcn.14002de60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xc08) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xc00), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xc08) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002deb0
// Address: 0x14002deb0
// Size: 24 bytes
// ============================================================
void fcn.14002deb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002ded0
// Address: 0x14002ded0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002ded0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_130h;
    int64_t var_d8h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_130h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011ec40(var_40h + 0x20, &var_130h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0x120, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014000c530(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002dfc0
// Address: 0x14002dfc0
// Size: 58 bytes
// ============================================================
undefined8 fcn.14002dfc0(undefined8 placeholder_0, int64_t arg2, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_c0h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x140));
    *(undefined8 *)(arg2 + 0x120) = uVar1;
    *(int64_t *)(arg2 + 0x128) = iVar2;
    return 0x14002df64;
}

// ============================================================
// Function: FUN_14002e000
// Address: 0x14002e000
// Size: 24 bytes
// ============================================================
void fcn.14002e000(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002e020
// Address: 0x14002e020
// Size: 53 bytes
// ============================================================
undefined8 fcn.14002e020(undefined8 placeholder_0, int64_t arg2, int64_t arg_a0h, int64_t arg_a8h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x120) = uVar1;
    *(int64_t *)(arg2 + 0x128) = iVar2;
    return 0x14002df64;
}

// ============================================================
// Function: FUN_14002e060
// Address: 0x14002e060
// Size: 65 bytes
// ============================================================
void fcn.14002e060(undefined8 placeholder_0, int64_t arg2, int64_t arg_a0h, int64_t arg_a8h)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x128) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x120), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x128) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002e0b0
// Address: 0x14002e0b0
// Size: 24 bytes
// ============================================================
void fcn.14002e0b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002e0d0
// Address: 0x14002e0d0
// Size: 323 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ah

void fcn.14002e0d0(int64_t arg1)
{
    uint8_t uVar1;
    char cVar2;
    uint64_t in_RDX;
    int64_t var_168h;
    int64_t var_108h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    undefined var_2ah;
    uint8_t var_29h;
    int64_t var_28h;
    
    var_28h = -2;
    uVar1 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_168h._0_4_ = 2;
        var_2ah = 1;
        var_48h = arg1;
        var_29h = uVar1;
        var_50h = func_0x000140796790(*(undefined8 *)(arg1 + 0x28));
        var_38h = var_48h + 0x30;
        func_0x000140003010();
        func_0x000140951cf0(var_38h, &var_168h, 0x118);
        var_2ah = 0;
        func_0x000140796f10(&var_50h);
        arg1 = var_48h;
        uVar1 = var_29h;
    }
    if ((uVar1 & 1) != 0) {
        func_0x000140796b10(arg1 + 0x148, 0);
    }
    cVar2 = func_0x000140797e30(arg1);
    if (cVar2 != '\0') {
        func_0x00014000c3c0(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_14002e220
// Address: 0x14002e220
// Size: 46 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_deh because it doesn't fit into ProtoModel

void fcn.14002e220(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_60h;
    
    if (*(char *)(arg2 + 0x15e) != '\0') {
        fcn.140003010(arg2 + 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_14002e250
// Address: 0x14002e250
// Size: 25 bytes
// ============================================================
void fcn.14002e250(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002e270
// Address: 0x14002e270
// Size: 60 bytes
// ============================================================
undefined8 fcn.14002e270(undefined8 placeholder_0, int64_t arg2, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_e8h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x168));
    *(undefined8 *)(arg2 + 0x150) = uVar1;
    *(int64_t *)(arg2 + 0x148) = iVar2;
    return 0x14002e1a5;
}

// ============================================================
// Function: FUN_14002e2b0
// Address: 0x14002e2b0
// Size: 25 bytes
// ============================================================
void fcn.14002e2b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002e2d0
// Address: 0x14002e2d0
// Size: 55 bytes
// ============================================================
undefined8 fcn.14002e2d0(undefined8 placeholder_0, int64_t arg2, int64_t arg_c8h, int64_t arg_d0h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x150) = uVar1;
    *(int64_t *)(arg2 + 0x148) = iVar2;
    return 0x14002e1a5;
}

// ============================================================
// Function: FUN_14002e310
// Address: 0x14002e310
// Size: 67 bytes
// ============================================================
void fcn.14002e310(undefined8 placeholder_0, int64_t arg2, int64_t arg_c8h, int64_t arg_d0h)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x148) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x150), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x148) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002e360
// Address: 0x14002e360
// Size: 68 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_deh because it doesn't fit into ProtoModel

void fcn.14002e360(undefined8 placeholder_0, int64_t arg2, int64_t arg_b8h, int64_t arg_d0h)
{
    int64_t var_10h;
    int64_t var_60h;
    
    fcn.140951cf0(*(undefined8 *)(arg2 + 0x150), arg2 + 0x20, 0x118);
    fcn.140796f10(arg2 + 0x138);
    *(undefined *)(arg2 + 0x15e) = 0;
    return;
}

// ============================================================
// Function: FUN_14002e3b0
// Address: 0x14002e3b0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002e3b0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_f70h;
    int64_t var_f18h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_f70h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011fe60(var_40h + 0x20, &var_f70h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xf60, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014001ad80(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002e4a0
// Address: 0x14002e4a0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.14002e4a0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xf80));
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x14002e444;
}

// ============================================================
// Function: FUN_14002e4e0
// Address: 0x14002e4e0
// Size: 24 bytes
// ============================================================
void fcn.14002e4e0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002e500
// Address: 0x14002e500
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.14002e500(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x14002e444;
}

// ============================================================
// Function: FUN_14002e540
// Address: 0x14002e540
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel

void fcn.14002e540(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xf68) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf60), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xf68) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002e590
// Address: 0x14002e590
// Size: 24 bytes
// ============================================================
void fcn.14002e590(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002e5b0
// Address: 0x14002e5b0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1417h because it doesn't fit into ProtoModel

void fcn.14002e5b0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002e5bc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001418 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x000013f8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002e5de;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001417)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002e604;
        func_0x00014011fc10(*(int64_t *)(&stack0x000013f8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001417)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002e624;
        func_0x000140796b10(*(int64_t *)(&stack0x000013f8 + iVar4) + 0x1410, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x000013f8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002e633;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002e63f;
        func_0x000140018e90(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002e6b0
// Address: 0x14002e6b0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel

undefined8 fcn.14002e6b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1430));
    *(undefined8 *)(arg2 + 0x1410) = uVar1;
    *(int64_t *)(arg2 + 0x1418) = iVar2;
    return 0x14002e64a;
}

// ============================================================
// Function: FUN_14002e6f0
// Address: 0x14002e6f0
// Size: 24 bytes
// ============================================================
void fcn.14002e6f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

