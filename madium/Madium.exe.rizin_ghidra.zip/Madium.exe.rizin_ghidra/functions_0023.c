// Chunk 23 - 50 functions

// ============================================================
// Function: FUN_14001af90
// Address: 0x14001af90
// Size: 245 bytes
// ============================================================
void fcn.14001af90(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t unaff_RBP;
    int64_t *piVar5;
    undefined8 unaff_RSI;
    int64_t iVar6;
    code *pcVar7;
    undefined8 auStack_50 [3];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    code **ppcStack_20;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar5 = &var_8h;
    var_10h = -2;
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    var_18h = arg1;
    var_8h = unaff_RBP;
    if (*piVar1 == 0) {
        auStack_50[0] = 0x14001afbd;
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(var_18h + 0x30) == 1) {
        if ((*(int64_t *)(var_18h + 0x38) != 0) && (var_28h = *(int64_t *)(var_18h + 0x40), var_28h != 0)) {
            ppcStack_20 = *(code ***)(var_18h + 0x48);
            if (*ppcStack_20 != (code *)0x0) {
                auStack_50[0] = 0x14001b00e;
                (**ppcStack_20)(var_28h);
            }
            pcVar4 = ppcStack_20[1];
            if (pcVar4 != (code *)0x0) {
                pcVar7 = ppcStack_20[2];
                *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
                auStack_50[0] = 0x14001b028;
                iVar3 = var_28h;
                goto code_r0x0001404d3c50;
            }
        }
    } else if (*(int32_t *)(var_18h + 0x30) == 0) {
        auStack_50[0] = 0x14001afda;
        func_0x000140011040(var_18h + 0x38);
    }
    if (*(int64_t *)(var_18h + 4000) != 0) {
        auStack_50[0] = 0x14001b046;
        (**(code **)(*(int64_t *)(var_18h + 4000) + 0x18))(*(undefined8 *)(var_18h + 0xfa8));
    }
    piVar1 = *(int64_t **)(var_18h + 0xfb0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            auStack_50[0] = 0x14001b06c;
            func_0x00014045efb0(var_18h + 0xfb0);
        }
    }
    pcVar4 = (code *)0x1000;
    pcVar7 = (code *)0x80;
    iVar3 = var_18h;
    piVar5 = (int64_t *)var_8h;
code_r0x0001404d3c50:
    *(int64_t **)((int64_t)*(undefined **)0x20 + -8) = piVar5;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
    iVar6 = iVar3;
    if ((code *)0x10 < pcVar7) {
        iVar6 = *(int64_t *)(iVar3 + -8);
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140901d3e;
    uVar2 = (*(code *)0xe5f2d8)(iVar3, pcVar4);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, iVar6);
    return;
}

// ============================================================
// Function: FUN_14001b090
// Address: 0x14001b090
// Size: 51 bytes
// ============================================================
void fcn.14001b090(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001b0d0
// Address: 0x14001b0d0
// Size: 37 bytes
// ============================================================
void fcn.14001b0d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xf90);
    return;
}

// ============================================================
// Function: FUN_14001b100
// Address: 0x14001b100
// Size: 58 bytes
// ============================================================
void fcn.14001b100(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xfb0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xfb0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001b140
// Address: 0x14001b140
// Size: 41 bytes
// ============================================================
void fcn.14001b140(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1000, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001b170
// Address: 0x14001b170
// Size: 34 bytes
// ============================================================
void fcn.14001b170(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140013030(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001b1a0
// Address: 0x14001b1a0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001b1a0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140010510(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1000) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1000) + 0x18))(*(undefined8 *)(arg1 + 0x1008));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1010);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1010);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1080);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001b2a0
// Address: 0x14001b2a0
// Size: 51 bytes
// ============================================================
void fcn.14001b2a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001b2e0
// Address: 0x14001b2e0
// Size: 37 bytes
// ============================================================
void fcn.14001b2e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xff0);
    return;
}

// ============================================================
// Function: FUN_14001b310
// Address: 0x14001b310
// Size: 58 bytes
// ============================================================
void fcn.14001b310(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1010);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1010);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001b350
// Address: 0x14001b350
// Size: 41 bytes
// ============================================================
void fcn.14001b350(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1080, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001b380
// Address: 0x14001b380
// Size: 34 bytes
// ============================================================
void fcn.14001b380(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012f70(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001b3b0
// Address: 0x14001b3b0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001b3b0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x0001400109d0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1e8) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1e8) + 0x18))(*(undefined8 *)(arg1 + 0x1f0));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1f8);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1f8);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x280);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001b4b0
// Address: 0x14001b4b0
// Size: 51 bytes
// ============================================================
void fcn.14001b4b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001b4f0
// Address: 0x14001b4f0
// Size: 37 bytes
// ============================================================
void fcn.14001b4f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1d8);
    return;
}

// ============================================================
// Function: FUN_14001b520
// Address: 0x14001b520
// Size: 58 bytes
// ============================================================
void fcn.14001b520(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1f8);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1f8);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001b560
// Address: 0x14001b560
// Size: 41 bytes
// ============================================================
void fcn.14001b560(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x280, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001b590
// Address: 0x14001b590
// Size: 34 bytes
// ============================================================
void fcn.14001b590(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012eb0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001b5f0
// Address: 0x14001b5f0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001b5f0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x0001400114b0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xc10) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xc10) + 0x18))(*(undefined8 *)(arg1 + 0xc18));
    }
    piVar1 = *(int64_t **)(arg1 + 0xc20);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xc20);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0xc80);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001b6f0
// Address: 0x14001b6f0
// Size: 51 bytes
// ============================================================
void fcn.14001b6f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001b730
// Address: 0x14001b730
// Size: 37 bytes
// ============================================================
void fcn.14001b730(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xc00);
    return;
}

// ============================================================
// Function: FUN_14001b760
// Address: 0x14001b760
// Size: 58 bytes
// ============================================================
void fcn.14001b760(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xc20);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xc20);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001b7a0
// Address: 0x14001b7a0
// Size: 41 bytes
// ============================================================
void fcn.14001b7a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0xc80, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001b7d0
// Address: 0x14001b7d0
// Size: 34 bytes
// ============================================================
void fcn.14001b7d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400134b0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001b800
// Address: 0x14001b800
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001b800(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140011970(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xb50) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xb50) + 0x18))(*(undefined8 *)(arg1 + 0xb58));
    }
    piVar1 = *(int64_t **)(arg1 + 0xb60);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xb60);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0xb80);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001b900
// Address: 0x14001b900
// Size: 51 bytes
// ============================================================
void fcn.14001b900(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001b940
// Address: 0x14001b940
// Size: 37 bytes
// ============================================================
void fcn.14001b940(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xb40);
    return;
}

// ============================================================
// Function: FUN_14001b970
// Address: 0x14001b970
// Size: 58 bytes
// ============================================================
void fcn.14001b970(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xb60);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xb60);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001b9b0
// Address: 0x14001b9b0
// Size: 41 bytes
// ============================================================
void fcn.14001b9b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0xb80, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001b9e0
// Address: 0x14001b9e0
// Size: 34 bytes
// ============================================================
void fcn.14001b9e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140013330(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001ba10
// Address: 0x14001ba10
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001ba10(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140011bd0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xf70) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xf70) + 0x18))(*(undefined8 *)(arg1 + 0xf78));
    }
    piVar1 = *(int64_t **)(arg1 + 0xf80);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xf80);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1000);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001bb10
// Address: 0x14001bb10
// Size: 51 bytes
// ============================================================
void fcn.14001bb10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001bb50
// Address: 0x14001bb50
// Size: 37 bytes
// ============================================================
void fcn.14001bb50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xf60);
    return;
}

// ============================================================
// Function: FUN_14001bb80
// Address: 0x14001bb80
// Size: 58 bytes
// ============================================================
void fcn.14001bb80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xf80);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xf80);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001bbc0
// Address: 0x14001bbc0
// Size: 41 bytes
// ============================================================
void fcn.14001bbc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1000, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001bbf0
// Address: 0x14001bbf0
// Size: 34 bytes
// ============================================================
void fcn.14001bbf0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400133f0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001bc20
// Address: 0x14001bc20
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001bc20(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140011710(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1030) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1030) + 0x18))(*(undefined8 *)(arg1 + 0x1038));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1040);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1040);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1080);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001bd20
// Address: 0x14001bd20
// Size: 51 bytes
// ============================================================
void fcn.14001bd20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001bd60
// Address: 0x14001bd60
// Size: 37 bytes
// ============================================================
void fcn.14001bd60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1020);
    return;
}

// ============================================================
// Function: FUN_14001bd90
// Address: 0x14001bd90
// Size: 58 bytes
// ============================================================
void fcn.14001bd90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1040);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1040);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001bdd0
// Address: 0x14001bdd0
// Size: 41 bytes
// ============================================================
void fcn.14001bdd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1080, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001be00
// Address: 0x14001be00
// Size: 34 bytes
// ============================================================
void fcn.14001be00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140013270(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001be30
// Address: 0x14001be30
// Size: 216 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001be30(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x148);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x0001406c7970(arg1 + 0x148);
    }
    if (*(int64_t *)(arg1 + 0x98) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0xa0), *(int64_t *)(arg1 + 0x98), 1);
    }
    piVar1 = *(int64_t **)(arg1 + 0x88);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x00014045ec00(arg1 + 0x88);
    }
    func_0x00014001eac0(arg1);
    piVar1 = *(int64_t **)(arg1 + 0x150);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x0001406c6890(arg1 + 0x150);
    }
    func_0x000140014d30(arg1 + 0xb0);
    piVar1 = *(int64_t **)(arg1 + 0x158);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 != 0) {
        return;
    }
    iVar2 = *(int64_t *)(arg1 + 0x158);
    func_0x0001406da7b0(iVar2 + 0x18);
    if (iVar2 != -1) {
        LOCK();
        piVar1 = (int64_t *)(iVar2 + 8);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            uVar3 = (*(code *)0xe5f2d8)(iVar2, 0x30);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar3, 0, iVar2);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001bf10
// Address: 0x14001bf10
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001bf10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    piVar2 = *(int64_t **)(iVar1 + 0x150);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c6890(iVar1 + 0x150);
    }
    return;
}

// ============================================================
// Function: FUN_14001bf50
// Address: 0x14001bf50
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001bf50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140014d30(*(int64_t *)(arg2 + 0x28) + 0xb0);
    return;
}

// ============================================================
// Function: FUN_14001bf80
// Address: 0x14001bf80
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001bf80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    piVar2 = *(int64_t **)(iVar1 + 0x158);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c6650(iVar1 + 0x158);
    }
    return;
}

// ============================================================
// Function: FUN_14001bfc0
// Address: 0x14001bfc0
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001bfc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140003460(*(undefined8 *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_14001bfe0
// Address: 0x14001bfe0
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001bfe0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001eac0(*(undefined8 *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_14001c000
// Address: 0x14001c000
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001c000(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140011710(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1030) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1030) + 0x18))(*(undefined8 *)(arg1 + 0x1038));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1040);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1040);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1080);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001c100
// Address: 0x14001c100
// Size: 51 bytes
// ============================================================
void fcn.14001c100(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

