// Chunk 8 - 50 functions

// ============================================================
// Function: FUN_14000aa20
// Address: 0x14000aa20
// Size: 43 bytes
// ============================================================
void fcn.14000aa20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000aa50
// Address: 0x14000aa50
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000aa50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14000aaa0
// Address: 0x14000aaa0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.14000aaa0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14000aaf0
// Address: 0x14000aaf0
// Size: 54 bytes
// ============================================================
void fcn.14000aaf0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x40);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000ab30
// Address: 0x14000ab30
// Size: 43 bytes
// ============================================================
void fcn.14000ab30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000ab60
// Address: 0x14000ab60
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000ab60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14000abb0
// Address: 0x14000abb0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.14000abb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14000ac00
// Address: 0x14000ac00
// Size: 507 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.14000ac00(int64_t arg1)
{
    char cVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x510) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_30h = 0;
        iVar5 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_30h) {
            var_30h = var_30h + 1;
            func_0x0001402727a0(iVar5);
            iVar5 = iVar5 + 0x60;
        }
        goto code_r0x00014000adbf;
    }
    if (*(char *)(arg1 + 0x510) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x508) == '\x03') {
        iVar4 = arg1 + 0x410;
        cVar1 = *(char *)(arg1 + 0x500);
joined_r0x00014000ace1:
        if (cVar1 == '\0') {
            func_0x000140014d30();
            if (((*(uint8_t *)(iVar4 + 0x98) & 5) != 0) && (*(int64_t *)(iVar4 + 0xa0) != 0)) {
                fcn.1404d3c50(*(undefined8 *)(iVar4 + 0xa8), *(int64_t *)(iVar4 + 0xa0), 1);
            }
            if (*(int64_t *)(iVar4 + 0xb8) != 0) {
                fcn.1404d3c50(*(undefined8 *)(iVar4 + 0xc0), *(int64_t *)(iVar4 + 0xb8), 1);
            }
            if (*(char *)(iVar4 + 0xd0) != '\x06') {
                func_0x00014001c840(iVar4 + 0xd0);
            }
        }
    } else if (*(char *)(arg1 + 0x508) == '\0') {
        iVar4 = arg1 + 0x318;
        cVar1 = *(char *)(arg1 + 0x408);
        goto joined_r0x00014000ace1;
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_30h = 0;
    iVar5 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_30h) {
        var_30h = var_30h + 1;
        func_0x0001402727a0(iVar5);
        iVar5 = iVar5 + 0x60;
    }
code_r0x00014000adbf:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar2, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000ae00
// Address: 0x14000ae00
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000ae00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    func_0x00014001c970(iVar1 + 0x98);
    iVar1 = *(int64_t *)(iVar1 + 0xb8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0xc0), iVar1, 1);
    }
    if (*(char *)(*(int64_t *)(arg2 + 0x48) + 0xd0) != '\x06') {
        func_0x00014001c840(*(int64_t *)(arg2 + 0x48) + 0xd0);
    }
    return;
}

// ============================================================
// Function: FUN_14000ae70
// Address: 0x14000ae70
// Size: 43 bytes
// ============================================================
void fcn.14000ae70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000aea0
// Address: 0x14000aea0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000aea0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14000aef0
// Address: 0x14000aef0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.14000aef0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14000af40
// Address: 0x14000af40
// Size: 54 bytes
// ============================================================
void fcn.14000af40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x40);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000af80
// Address: 0x14000af80
// Size: 43 bytes
// ============================================================
void fcn.14000af80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000afb0
// Address: 0x14000afb0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000afb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14000b000
// Address: 0x14000b000
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.14000b000(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14000b050
// Address: 0x14000b050
// Size: 491 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.14000b050(int64_t arg1)
{
    int64_t iVar1;
    char cVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x720) == '\0') {
        fcn.14001c990();
        iVar1 = *(int64_t *)(arg1 + 0x218);
        var_30h = 0;
        iVar5 = *(int64_t *)(arg1 + 0x210);
        while (iVar1 != var_30h) {
            var_30h = var_30h + 1;
            func_0x0001402727a0(iVar5);
            iVar5 = iVar5 + 0x60;
        }
        goto code_r0x00014000b1ff;
    }
    if (*(char *)(arg1 + 0x720) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x718) == '\x03') {
        iVar1 = arg1 + 0x570;
        cVar2 = *(char *)(arg1 + 0x714);
joined_r0x00014000b131:
        if (cVar2 == '\0') {
            func_0x00014001be30(iVar1);
            if (*(int64_t *)(iVar1 + 0x188) != 0) {
                fcn.1404d3c50(*(undefined8 *)(iVar1 + 400), *(int64_t *)(iVar1 + 0x188), 1);
            }
            if (((*(uint8_t *)(iVar1 + 0x168) & 5) != 0) && (*(int64_t *)(iVar1 + 0x170) != 0)) {
                fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x178), *(int64_t *)(iVar1 + 0x170), 1);
            }
        }
    } else if (*(char *)(arg1 + 0x718) == '\0') {
        iVar1 = arg1 + 0x3c8;
        cVar2 = *(char *)(arg1 + 0x56c);
        goto joined_r0x00014000b131;
    }
    fcn.14001c990(arg1);
    iVar1 = *(int64_t *)(arg1 + 0x218);
    var_30h = 0;
    iVar5 = *(int64_t *)(arg1 + 0x210);
    while (iVar1 != var_30h) {
        var_30h = var_30h + 1;
        func_0x0001402727a0(iVar5);
        iVar5 = iVar5 + 0x60;
    }
code_r0x00014000b1ff:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar3 = *(undefined8 *)(arg1 + 0x210);
    uVar4 = (*(code *)0xe5f2d8)(uVar3, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar4, 0, uVar3);
    return;
}

// ============================================================
// Function: FUN_14000b240
// Address: 0x14000b240
// Size: 108 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000b240(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x48) + 0x188);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 400), iVar1, 1);
    }
    fcn.14001c970(*(int64_t *)(arg2 + 0x48) + 0x168);
    iVar1 = *(int64_t *)(arg2 + 0x40);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000b2b0
// Address: 0x14000b2b0
// Size: 43 bytes
// ============================================================
void fcn.14000b2b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000b2e0
// Address: 0x14000b2e0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000b2e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14000b330
// Address: 0x14000b330
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.14000b330(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14000b380
// Address: 0x14000b380
// Size: 43 bytes
// ============================================================
void fcn.14000b380(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000b3b0
// Address: 0x14000b3b0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000b3b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14000b400
// Address: 0x14000b400
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.14000b400(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14000b450
// Address: 0x14000b450
// Size: 427 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.14000b450(int64_t arg1)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x6c0) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar3 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar3);
            iVar3 = iVar3 + 0x60;
        }
        goto code_r0x00014000b5bf;
    }
    if (*(char *)(arg1 + 0x6c0) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x6b8) == '\0') {
        if (*(char *)(arg1 + 0x52c) == '\0') {
            iVar4 = 0x510;
            func_0x00014001be30(arg1 + 0x3a8);
            goto code_r0x00014000b53d;
        }
    } else if ((*(char *)(arg1 + 0x6b8) == '\x03') && (*(char *)(arg1 + 0x6b4) == '\0')) {
        iVar4 = 0x698;
        func_0x00014001be30(arg1 + 0x530);
code_r0x00014000b53d:
        if (*(int64_t *)(arg1 + iVar4) != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar4), *(int64_t *)(arg1 + iVar4), 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar3 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar3);
        iVar3 = iVar3 + 0x60;
    }
code_r0x00014000b5bf:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar2 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_14000b600
// Address: 0x14000b600
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000b600(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x48) + 0x510);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x518), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000b650
// Address: 0x14000b650
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000b650(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x48) + 0x698);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x6a0), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000b6a0
// Address: 0x14000b6a0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000b6a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000b6d0
// Address: 0x14000b6d0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000b6d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14000b720
// Address: 0x14000b720
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000b720(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14000b770
// Address: 0x14000b770
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000b770(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000b7b0
// Address: 0x14000b7b0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000b7b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000b7e0
// Address: 0x14000b7e0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000b7e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14000b830
// Address: 0x14000b830
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000b830(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14000b880
// Address: 0x14000b880
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000b880(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x2900) == '\0') {
        func_0x0001400020d0(arg1 + 0x188);
        func_0x00014001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x0001406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x2900) != '\x03') {
            return;
        }
        func_0x0001400020d0(arg1 + 0x1540);
        func_0x00014001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x0001406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000b950
// Address: 0x14000b950
// Size: 34 bytes
// ============================================================
void fcn.14000b950(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000b980
// Address: 0x14000b980
// Size: 57 bytes
// ============================================================
void fcn.14000b980(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000b9c0
// Address: 0x14000b9c0
// Size: 59 bytes
// ============================================================
void fcn.14000b9c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000ba00
// Address: 0x14000ba00
// Size: 95 bytes
// ============================================================
void fcn.14000ba00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000ba60
// Address: 0x14000ba60
// Size: 57 bytes
// ============================================================
void fcn.14000ba60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000baa0
// Address: 0x14000baa0
// Size: 59 bytes
// ============================================================
void fcn.14000baa0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000bae0
// Address: 0x14000bae0
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000bae0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x2150) == '\0') {
        func_0x000140002960(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x2150) != '\x03') {
            return;
        }
        func_0x000140002960(arg1 + 0x1168);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000bbb0
// Address: 0x14000bbb0
// Size: 34 bytes
// ============================================================
void fcn.14000bbb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14000bbe0
// Address: 0x14000bbe0
// Size: 57 bytes
// ============================================================
void fcn.14000bbe0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000bc20
// Address: 0x14000bc20
// Size: 59 bytes
// ============================================================
void fcn.14000bc20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000bc60
// Address: 0x14000bc60
// Size: 95 bytes
// ============================================================
void fcn.14000bc60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000bcc0
// Address: 0x14000bcc0
// Size: 57 bytes
// ============================================================
void fcn.14000bcc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000bd00
// Address: 0x14000bd00
// Size: 59 bytes
// ============================================================
void fcn.14000bd00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000bd40
// Address: 0x14000bd40
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000bd40(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x2e10) == '\0') {
        func_0x000140002430(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0x2e10) != '\x03') {
            return;
        }
        func_0x000140002430(arg1 + 0x17c8);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000be10
// Address: 0x14000be10
// Size: 34 bytes
// ============================================================
void fcn.14000be10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

