// Chunk 5 - 50 functions

// ============================================================
// Function: FUN_140006650
// Address: 0x140006650
// Size: 54 bytes
// ============================================================
void fcn.140006650(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140006690
// Address: 0x140006690
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006690(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400066c0
// Address: 0x1400066c0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400066c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140006710
// Address: 0x140006710
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006710(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140006760
// Address: 0x140006760
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140006760(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x918) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x0001400068ff;
    }
    if (*(char *)(arg1 + 0x918) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x910) == '\0') {
        if (*(char *)(arg1 + 0x6b8) == '\0') {
            func_0x000140014e50(arg1 + 0x488);
            iVar4 = *(int64_t *)(arg1 + 0x6a0);
            iVar2 = 0x6a0;
            goto code_r0x000140006868;
        }
    } else if ((*(char *)(arg1 + 0x910) == '\x03') && (*(char *)(arg1 + 0x908) == '\0')) {
        func_0x000140014e50(arg1 + 0x6d8);
        iVar4 = *(int64_t *)(arg1 + 0x8f0);
        iVar2 = 0x8f0;
code_r0x000140006868:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x0001400068ff:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140006940
// Address: 0x140006940
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006940(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x6a0);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x6a8), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140006990
// Address: 0x140006990
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006990(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x8f0);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x8f8), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_1400069e0
// Address: 0x1400069e0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400069e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140006a10
// Address: 0x140006a10
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140006a10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140006a60
// Address: 0x140006a60
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006a60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140006ab0
// Address: 0x140006ab0
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006ab0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140006af0
// Address: 0x140006af0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006af0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140006b20
// Address: 0x140006b20
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140006b20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140006b70
// Address: 0x140006b70
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006b70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140006bc0
// Address: 0x140006bc0
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140006bc0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x990) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x000140006d5f;
    }
    if (*(char *)(arg1 + 0x990) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x988) == '\0') {
        if (*(char *)(arg1 + 0x708) == '\0') {
            func_0x000140014e50(arg1 + 0x498);
            iVar4 = *(int64_t *)(arg1 + 0x6b0);
            iVar2 = 0x6b0;
            goto code_r0x000140006cc8;
        }
    } else if ((*(char *)(arg1 + 0x988) == '\x03') && (*(char *)(arg1 + 0x980) == '\0')) {
        func_0x000140014e50(arg1 + 0x710);
        iVar4 = *(int64_t *)(arg1 + 0x928);
        iVar2 = 0x928;
code_r0x000140006cc8:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x000140006d5f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140006da0
// Address: 0x140006da0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006da0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x6b0);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x6b8), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140006df0
// Address: 0x140006df0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006df0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x928);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x930), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140006e40
// Address: 0x140006e40
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006e40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140006e70
// Address: 0x140006e70
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140006e70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140006ec0
// Address: 0x140006ec0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006ec0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140006f10
// Address: 0x140006f10
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006f10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140006f50
// Address: 0x140006f50
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006f50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140006f80
// Address: 0x140006f80
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140006f80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140006fd0
// Address: 0x140006fd0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140006fd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140007020
// Address: 0x140007020
// Size: 427 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140007020(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0xb88) == '\0') {
        fcn.14001c990();
        iVar1 = *(int64_t *)(arg1 + 0x218);
        var_30h = 0;
        iVar4 = *(int64_t *)(arg1 + 0x210);
        while (iVar1 != var_30h) {
            var_30h = var_30h + 1;
            func_0x0001402727a0(iVar4);
            iVar4 = iVar4 + 0x60;
        }
        goto code_r0x00014000718f;
    }
    if (*(char *)(arg1 + 0xb88) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0xb80) == '\0') {
        if (*(char *)(arg1 + 0x858) == '\0') {
            var_30h = arg1 + 0x540;
            func_0x000140014d30(arg1 + 0x7c0);
            goto code_r0x000140007123;
        }
    } else if ((*(char *)(arg1 + 0xb80) == '\x03') && (*(char *)(arg1 + 0xb78) == '\0')) {
        var_30h = arg1 + 0x860;
        func_0x000140014d30(arg1 + 0xae0);
code_r0x000140007123:
        func_0x00014001cfd0(var_30h);
    }
    fcn.14001c990(arg1);
    iVar1 = *(int64_t *)(arg1 + 0x218);
    var_30h = 0;
    iVar4 = *(int64_t *)(arg1 + 0x210);
    while (iVar1 != var_30h) {
        var_30h = var_30h + 1;
        func_0x0001402727a0(iVar4);
        iVar4 = iVar4 + 0x60;
    }
code_r0x00014000718f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar2, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_1400071d0
// Address: 0x1400071d0
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400071d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001cfd0(*(undefined8 *)(arg2 + 0x48));
    return;
}

// ============================================================
// Function: FUN_140007200
// Address: 0x140007200
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007200(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001cfd0(*(undefined8 *)(arg2 + 0x48));
    return;
}

// ============================================================
// Function: FUN_140007230
// Address: 0x140007230
// Size: 43 bytes
// ============================================================
void fcn.140007230(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140007260
// Address: 0x140007260
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140007260(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1400072b0
// Address: 0x1400072b0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1400072b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140007300
// Address: 0x140007300
// Size: 54 bytes
// ============================================================
void fcn.140007300(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x40);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140007340
// Address: 0x140007340
// Size: 43 bytes
// ============================================================
void fcn.140007340(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140007370
// Address: 0x140007370
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140007370(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1400073c0
// Address: 0x1400073c0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1400073c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140007410
// Address: 0x140007410
// Size: 523 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140007410(int64_t arg1)
{
    int64_t iVar1;
    char cVar2;
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0xd80) == '\0') {
        fcn.14001c990(arg1);
        iVar1 = *(int64_t *)(arg1 + 0x218);
        var_30h = 0;
        iVar6 = *(int64_t *)(arg1 + 0x210);
        while (iVar1 != var_30h) {
            var_30h = var_30h + 1;
            func_0x0001402727a0(iVar6);
            iVar6 = iVar6 + 0x60;
        }
        goto code_r0x0001400075df;
    }
    if (*(char *)(arg1 + 0xd80) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0xd78) == '\x03') {
        iVar1 = arg1 + 0x9b0;
        cVar2 = *(char *)(arg1 + 0xd70);
joined_r0x0001400074f1:
        if (cVar2 == '\0') {
            func_0x00014001be30();
            func_0x000140014e50(iVar1 + 0x168);
            if (*(int64_t *)(iVar1 + 0x380) != 0) {
                fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x388), *(int64_t *)(iVar1 + 0x380), 1);
            }
            uVar3 = *(uint32_t *)(iVar1 + 0x398);
            if (uVar3 != 4) {
                if (uVar3 < 2) {
                    iVar6 = 8;
                } else {
                    iVar6 = 0x10;
                    if (uVar3 == 2) goto code_r0x000140007579;
                }
                iVar4 = *(int64_t *)(iVar1 + 0x398 + iVar6);
                if (iVar4 != 0) {
                    fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x3a0 + iVar6), iVar4, 1);
                }
            }
        }
    } else if (*(char *)(arg1 + 0xd78) == '\0') {
        iVar1 = arg1 + 0x5e8;
        cVar2 = *(char *)(arg1 + 0x9a8);
        goto joined_r0x0001400074f1;
    }
code_r0x000140007579:
    fcn.14001c990(arg1);
    iVar1 = *(int64_t *)(arg1 + 0x218);
    var_30h = 0;
    iVar6 = *(int64_t *)(arg1 + 0x210);
    while (iVar1 != var_30h) {
        var_30h = var_30h + 1;
        func_0x0001402727a0(iVar6);
        iVar6 = iVar6 + 0x60;
    }
code_r0x0001400075df:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar5 = *(undefined8 *)(arg1 + 0x210);
    uVar7 = (*(code *)0xe5f2d8)(uVar5, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar7, 0, uVar5);
    return;
}

// ============================================================
// Function: FUN_140007620
// Address: 0x140007620
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007620(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140014e50(*(int64_t *)(arg2 + 0x48) + 0x168);
    return;
}

// ============================================================
// Function: FUN_140007650
// Address: 0x140007650
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007650(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    if ((*(uint64_t *)(iVar1 + 0x380) & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x388), *(uint64_t *)(iVar1 + 0x380), 1);
    }
    if (*(int32_t *)(iVar1 + 0x398) != 4) {
        func_0x000140014e20(iVar1 + 0x398);
    }
    iVar1 = *(int64_t *)(arg2 + 0x40);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400076d0
// Address: 0x1400076d0
// Size: 43 bytes
// ============================================================
void fcn.1400076d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140007700
// Address: 0x140007700
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140007700(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140007750
// Address: 0x140007750
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.140007750(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_1400077a0
// Address: 0x1400077a0
// Size: 43 bytes
// ============================================================
void fcn.1400077a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400077d0
// Address: 0x1400077d0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400077d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140007820
// Address: 0x140007820
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.140007820(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140007870
// Address: 0x140007870
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140007870(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x8d0) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x000140007a0f;
    }
    if (*(char *)(arg1 + 0x8d0) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x8c8) == '\0') {
        if (*(char *)(arg1 + 0x68d) == '\0') {
            fcn.140014e50(arg1 + 0x458);
            iVar4 = *(int64_t *)(arg1 + 0x670);
            iVar2 = 0x670;
            goto code_r0x000140007978;
        }
    } else if ((*(char *)(arg1 + 0x8c8) == '\x03') && (*(char *)(arg1 + 0x8c5) == '\0')) {
        fcn.140014e50(arg1 + 0x690);
        iVar4 = *(int64_t *)(arg1 + 0x8a8);
        iVar2 = 0x8a8;
code_r0x000140007978:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x000140007a0f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140007a50
// Address: 0x140007a50
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007a50(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x670);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x678), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140007aa0
// Address: 0x140007aa0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007aa0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x8a8);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x8b0), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140007af0
// Address: 0x140007af0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007af0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140007b20
// Address: 0x140007b20
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140007b20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140007b70
// Address: 0x140007b70
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007b70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140007bc0
// Address: 0x140007bc0
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007bc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

