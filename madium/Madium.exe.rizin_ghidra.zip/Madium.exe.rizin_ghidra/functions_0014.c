// Chunk 14 - 50 functions

// ============================================================
// Function: FUN_1400112a0
// Address: 0x1400112a0
// Size: 245 bytes
// ============================================================
void fcn.1400112a0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t unaff_RBP;
    int64_t *piVar5;
    undefined8 unaff_RSI;
    int64_t iVar6;
    code *pcVar7;
    undefined8 auStack_50 [3];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    code **ppcStack_20;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar5 = &var_8h;
    var_10h = -2;
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    var_18h = arg1;
    var_8h = unaff_RBP;
    if (*piVar1 == 0) {
        auStack_50[0] = 0x1400112cd;
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(var_18h + 0x30) == 1) {
        if ((*(int64_t *)(var_18h + 0x38) != 0) && (var_28h = *(int64_t *)(var_18h + 0x40), var_28h != 0)) {
            ppcStack_20 = *(code ***)(var_18h + 0x48);
            if (*ppcStack_20 != (code *)0x0) {
                auStack_50[0] = 0x14001131e;
                (**ppcStack_20)(var_28h);
            }
            pcVar4 = ppcStack_20[1];
            if (pcVar4 != (code *)0x0) {
                pcVar7 = ppcStack_20[2];
                *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
                auStack_50[0] = 0x140011338;
                iVar3 = var_28h;
                goto code_r0x0001404d3c50;
            }
        }
    } else if (*(int32_t *)(var_18h + 0x30) == 0) {
        auStack_50[0] = 0x1400112ea;
        func_0x000140003110(var_18h + 0x38);
    }
    if (*(int64_t *)(var_18h + 0xd0) != 0) {
        auStack_50[0] = 0x140011356;
        (**(code **)(*(int64_t *)(var_18h + 0xd0) + 0x18))(*(undefined8 *)(var_18h + 0xd8));
    }
    piVar1 = *(int64_t **)(var_18h + 0xe0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            auStack_50[0] = 0x14001137c;
            func_0x00014045efb0(var_18h + 0xe0);
        }
    }
    pcVar4 = (code *)0x100;
    pcVar7 = (code *)0x80;
    iVar3 = var_18h;
    piVar5 = (int64_t *)var_8h;
code_r0x0001404d3c50:
    *(int64_t **)((int64_t)*(undefined **)0x20 + -8) = piVar5;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
    iVar6 = iVar3;
    if ((code *)0x10 < pcVar7) {
        iVar6 = *(int64_t *)(iVar3 + -8);
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140901d3e;
    uVar2 = (*(code *)0xe5f2d8)(iVar3, pcVar4);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, iVar6);
    return;
}

// ============================================================
// Function: FUN_1400113a0
// Address: 0x1400113a0
// Size: 51 bytes
// ============================================================
void fcn.1400113a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400113e0
// Address: 0x1400113e0
// Size: 37 bytes
// ============================================================
void fcn.1400113e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xc0);
    return;
}

// ============================================================
// Function: FUN_140011410
// Address: 0x140011410
// Size: 58 bytes
// ============================================================
void fcn.140011410(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xe0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xe0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140011450
// Address: 0x140011450
// Size: 41 bytes
// ============================================================
void fcn.140011450(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x100, 0x80);
    return;
}

// ============================================================
// Function: FUN_140011480
// Address: 0x140011480
// Size: 34 bytes
// ============================================================
void fcn.140011480(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400036f0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_1400114b0
// Address: 0x1400114b0
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400114b0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0xbc0) == '\0') {
        func_0x00014000ac00(arg1 + 0x188);
        func_0x00014001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x0001406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0xbc0) != '\x03') {
            return;
        }
        func_0x00014000ac00(arg1 + 0x6a0);
        func_0x00014001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x0001406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_140011580
// Address: 0x140011580
// Size: 34 bytes
// ============================================================
void fcn.140011580(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_1400115b0
// Address: 0x1400115b0
// Size: 57 bytes
// ============================================================
void fcn.1400115b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_1400115f0
// Address: 0x1400115f0
// Size: 59 bytes
// ============================================================
void fcn.1400115f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140011630
// Address: 0x140011630
// Size: 95 bytes
// ============================================================
void fcn.140011630(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_140011690
// Address: 0x140011690
// Size: 57 bytes
// ============================================================
void fcn.140011690(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_1400116d0
// Address: 0x1400116d0
// Size: 59 bytes
// ============================================================
void fcn.1400116d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140011710
// Address: 0x140011710
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140011710(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0xfe0) == '\0') {
        func_0x00014000b050(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0xfe0) != '\x03') {
            return;
        }
        func_0x00014000b050(arg1 + 0x8b0);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_1400117e0
// Address: 0x1400117e0
// Size: 34 bytes
// ============================================================
void fcn.1400117e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_140011810
// Address: 0x140011810
// Size: 57 bytes
// ============================================================
void fcn.140011810(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_140011850
// Address: 0x140011850
// Size: 59 bytes
// ============================================================
void fcn.140011850(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140011890
// Address: 0x140011890
// Size: 95 bytes
// ============================================================
void fcn.140011890(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_1400118f0
// Address: 0x1400118f0
// Size: 57 bytes
// ============================================================
void fcn.1400118f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_140011930
// Address: 0x140011930
// Size: 59 bytes
// ============================================================
void fcn.140011930(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140011970
// Address: 0x140011970
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140011970(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0xb00) == '\0') {
        func_0x00014000a7f0(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0xb00) != '\x03') {
            return;
        }
        func_0x00014000a7f0(arg1 + 0x640);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_140011a40
// Address: 0x140011a40
// Size: 34 bytes
// ============================================================
void fcn.140011a40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_140011a70
// Address: 0x140011a70
// Size: 57 bytes
// ============================================================
void fcn.140011a70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_140011ab0
// Address: 0x140011ab0
// Size: 59 bytes
// ============================================================
void fcn.140011ab0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140011af0
// Address: 0x140011af0
// Size: 95 bytes
// ============================================================
void fcn.140011af0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_140011b50
// Address: 0x140011b50
// Size: 57 bytes
// ============================================================
void fcn.140011b50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_140011b90
// Address: 0x140011b90
// Size: 59 bytes
// ============================================================
void fcn.140011b90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140011bd0
// Address: 0x140011bd0
// Size: 208 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140011bd0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0xf20) == '\0') {
        func_0x00014000b450(arg1 + 0x188);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    } else {
        if (*(char *)(arg1 + 0xf20) != '\x03') {
            return;
        }
        func_0x00014000b450(arg1 + 0x850);
        fcn.14001be30(arg1);
        piVar1 = *(int64_t **)(arg1 + 0x180);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.1406c7d50(arg1 + 0x180);
        }
    }
    if (*(int64_t *)(arg1 + 0x168) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x170);
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_140011ca0
// Address: 0x140011ca0
// Size: 34 bytes
// ============================================================
void fcn.140011ca0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001be30(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_140011cd0
// Address: 0x140011cd0
// Size: 57 bytes
// ============================================================
void fcn.140011cd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_140011d10
// Address: 0x140011d10
// Size: 59 bytes
// ============================================================
void fcn.140011d10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140011d50
// Address: 0x140011d50
// Size: 95 bytes
// ============================================================
void fcn.140011d50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    fcn.14001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_140011db0
// Address: 0x140011db0
// Size: 57 bytes
// ============================================================
void fcn.140011db0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_140011df0
// Address: 0x140011df0
// Size: 59 bytes
// ============================================================
void fcn.140011df0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140011e30
// Address: 0x140011e30
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140011e30(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x9b8) == '\0') {
            func_0x000140003bb0(arg1 + 400);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x9b8) != '\x03') {
                return;
            }
            func_0x000140003bb0(arg1 + 0x5a0);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140011eb0
// Address: 0x140011eb0
// Size: 51 bytes
// ============================================================
void fcn.140011eb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140011ef0
// Address: 0x140011ef0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140011ef0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0xa18) == '\0') {
            func_0x000140003f20(arg1 + 400);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0xa18) != '\x03') {
                return;
            }
            func_0x000140003f20(arg1 + 0x5d0);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140011f70
// Address: 0x140011f70
// Size: 51 bytes
// ============================================================
void fcn.140011f70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140011fb0
// Address: 0x140011fb0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140011fb0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x9b8) == '\0') {
            func_0x000140003840(arg1 + 400);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x9b8) != '\x03') {
                return;
            }
            func_0x000140003840(arg1 + 0x5a0);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012030
// Address: 0x140012030
// Size: 51 bytes
// ============================================================
void fcn.140012030(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012070
// Address: 0x140012070
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012070(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x1378) == '\0') {
            func_0x000140004290(arg1 + 400);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x1378) != '\x03') {
                return;
            }
            func_0x000140004290(arg1 + 0xa80);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_1400120f0
// Address: 0x1400120f0
// Size: 51 bytes
// ============================================================
void fcn.1400120f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012130
// Address: 0x140012130
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012130(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x1828) == '\0') {
            func_0x0001400046c0(arg1 + 400);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x1828) != '\x03') {
                return;
            }
            func_0x0001400046c0(arg1 + 0xcd8);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_1400121b0
// Address: 0x1400121b0
// Size: 51 bytes
// ============================================================
void fcn.1400121b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400121f0
// Address: 0x1400121f0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400121f0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x1c48) == '\0') {
            func_0x000140005630(arg1 + 400);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x1c48) != '\x03') {
                return;
            }
            func_0x000140005630(arg1 + 0xee8);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012270
// Address: 0x140012270
// Size: 51 bytes
// ============================================================
void fcn.140012270(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400122b0
// Address: 0x1400122b0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400122b0(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0xe98) == '\0') {
            func_0x0001400052c0(arg1 + 400);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0xe98) != '\x03') {
                return;
            }
            func_0x0001400052c0(arg1 + 0x810);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_140012330
// Address: 0x140012330
// Size: 51 bytes
// ============================================================
void fcn.140012330(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140012370
// Address: 0x140012370
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140012370(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int32_t *)arg1 == 0) {
        if (*(char *)(arg1 + 0x1bb8) == '\0') {
            func_0x000140004eb0(arg1 + 400);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        } else {
            if (*(char *)(arg1 + 0x1bb8) != '\x03') {
                return;
            }
            func_0x000140004eb0(arg1 + 0xea0);
            fcn.14001be30(arg1 + 8);
            piVar1 = *(int64_t **)(arg1 + 0x188);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                fcn.1406c7d50(arg1 + 0x188);
            }
        }
        if (*(int64_t *)(arg1 + 0x170) == 0) {
            return;
        }
        iVar4 = *(int64_t *)(arg1 + 0x178);
        pcVar5 = (code *)0x1;
    } else {
        if (((*(int32_t *)arg1 != 1) || (*(int64_t *)(arg1 + 8) == 0)) ||
           (iVar4 = *(int64_t *)(arg1 + 0x10), iVar4 == 0)) {
            return;
        }
        ppcVar2 = *(code ***)(arg1 + 0x18);
        if (*ppcVar2 != (code *)0x0) {
            (**ppcVar2)(iVar4);
        }
        if (ppcVar2[1] == (code *)0x0) {
            return;
        }
        pcVar5 = ppcVar2[2];
    }
    if ((code *)0x10 < pcVar5) {
        iVar4 = *(int64_t *)(iVar4 + -8);
    }
    uVar3 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, iVar4);
    return;
}

// ============================================================
// Function: FUN_1400123f0
// Address: 0x1400123f0
// Size: 51 bytes
// ============================================================
void fcn.1400123f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

