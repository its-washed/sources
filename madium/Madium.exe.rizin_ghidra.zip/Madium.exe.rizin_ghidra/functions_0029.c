// Chunk 29 - 50 functions

// ============================================================
// Function: FUN_140021210
// Address: 0x140021210
// Size: 23 bytes
// ============================================================
void fcn.140021210(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021230
// Address: 0x140021230
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.140021230(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1fc8));
    *(undefined8 *)(arg2 + 0x1fb0) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x1400211fa;
}

// ============================================================
// Function: FUN_140021270
// Address: 0x140021270
// Size: 23 bytes
// ============================================================
void fcn.140021270(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021290
// Address: 0x140021290
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.140021290(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1fb0) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x1400211fa;
}

// ============================================================
// Function: FUN_1400212d0
// Address: 0x1400212d0
// Size: 132 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400212d0(int64_t arg1)
{
    int64_t var_e30h;
    int64_t var_dd8h;
    int64_t var_730h;
    int64_t var_728h;
    int64_t var_720h;
    int64_t var_718h;
    int64_t var_30h;
    int64_t var_18h;
    
    var_18h = -2;
    var_30h = arg1;
    fcn.14011d8b0();
    var_728h = *(int64_t *)(var_30h + 8);
    var_720h = 0;
    var_730h._0_4_ = 1;
    fcn.14011d8b0(var_30h, &var_730h);
    return;
}

// ============================================================
// Function: FUN_140021360
// Address: 0x140021360
// Size: 23 bytes
// ============================================================
void fcn.140021360(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021380
// Address: 0x140021380
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_dc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_db0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_db8h because it doesn't fit into ProtoModel

undefined8 fcn.140021380(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xe48));
    *(undefined8 *)(arg2 + 0xe30) = uVar1;
    *(int64_t *)(arg2 + 0xe38) = iVar2;
    return 0x140021344;
}

// ============================================================
// Function: FUN_1400213c0
// Address: 0x1400213c0
// Size: 23 bytes
// ============================================================
void fcn.1400213c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400213e0
// Address: 0x1400213e0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_db0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_db8h because it doesn't fit into ProtoModel

undefined8 fcn.1400213e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xe30) = uVar1;
    *(int64_t *)(arg2 + 0xe38) = iVar2;
    return 0x140021344;
}

// ============================================================
// Function: FUN_140021420
// Address: 0x140021420
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_42f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140021420(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002142b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000042f8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000042e0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140021458;
    fcn.14011d180();
    *(undefined8 *)(&stack0x00002188 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000042e0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00002190 + iVar1) = 0;
    *(undefined8 *)(&stack0x00002198 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00002180 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140021490;
    fcn.14011d180(*(int64_t *)(&stack0x000042e0 + iVar1), &stack0x00002180 + iVar1);
    return;
}

// ============================================================
// Function: FUN_1400214b0
// Address: 0x1400214b0
// Size: 23 bytes
// ============================================================
void fcn.1400214b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400214d0
// Address: 0x1400214d0
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_4288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4278h because it doesn't fit into ProtoModel

undefined8 fcn.1400214d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x4308));
    *(undefined8 *)(arg2 + 0x42f0) = uVar1;
    *(int64_t *)(arg2 + 0x42f8) = iVar2;
    return 0x14002149a;
}

// ============================================================
// Function: FUN_140021510
// Address: 0x140021510
// Size: 23 bytes
// ============================================================
void fcn.140021510(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021530
// Address: 0x140021530
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_4270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4278h because it doesn't fit into ProtoModel

undefined8 fcn.140021530(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x42f0) = uVar1;
    *(int64_t *)(arg2 + 0x42f8) = iVar2;
    return 0x14002149a;
}

// ============================================================
// Function: FUN_140021570
// Address: 0x140021570
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140021570(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002157b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00002918 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00002900 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400215a8;
    fcn.14011f200();
    *(undefined8 *)(&stack0x00001498 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00002900 + iVar1) + 8);
    *(undefined8 *)(&stack0x000014a0 + iVar1) = 0;
    *(undefined8 *)(&stack0x000014a8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00001490 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400215e0;
    fcn.14011f200(*(int64_t *)(&stack0x00002900 + iVar1), &stack0x00001490 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140021600
// Address: 0x140021600
// Size: 23 bytes
// ============================================================
void fcn.140021600(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021620
// Address: 0x140021620
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_28a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2890h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2898h because it doesn't fit into ProtoModel

undefined8 fcn.140021620(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2928));
    *(undefined8 *)(arg2 + 0x2910) = uVar1;
    *(int64_t *)(arg2 + 0x2918) = iVar2;
    return 0x1400215ea;
}

// ============================================================
// Function: FUN_140021660
// Address: 0x140021660
// Size: 23 bytes
// ============================================================
void fcn.140021660(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021680
// Address: 0x140021680
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2890h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2898h because it doesn't fit into ProtoModel

undefined8 fcn.140021680(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2910) = uVar1;
    *(int64_t *)(arg2 + 0x2918) = iVar2;
    return 0x1400215ea;
}

// ============================================================
// Function: FUN_1400216c0
// Address: 0x1400216c0
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400216c0(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1400216cb;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00001478 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00001460 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400216f8;
    fcn.14011d5d0();
    *(undefined8 *)(&stack0x00000a48 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00001460 + iVar1) + 8);
    *(undefined8 *)(&stack0x00000a50 + iVar1) = 0;
    *(undefined8 *)(&stack0x00000a58 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00000a40 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140021730;
    fcn.14011d5d0(*(int64_t *)(&stack0x00001460 + iVar1), &stack0x00000a40 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140021750
// Address: 0x140021750
// Size: 23 bytes
// ============================================================
void fcn.140021750(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021770
// Address: 0x140021770
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel

undefined8 fcn.140021770(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1488));
    *(undefined8 *)(arg2 + 0x1470) = uVar1;
    *(int64_t *)(arg2 + 0x1478) = iVar2;
    return 0x14002173a;
}

// ============================================================
// Function: FUN_1400217b0
// Address: 0x1400217b0
// Size: 23 bytes
// ============================================================
void fcn.1400217b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400217d0
// Address: 0x1400217d0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel

undefined8 fcn.1400217d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1470) = uVar1;
    *(int64_t *)(arg2 + 0x1478) = iVar2;
    return 0x14002173a;
}

// ============================================================
// Function: FUN_140021810
// Address: 0x140021810
// Size: 132 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140021810(int64_t arg1)
{
    int64_t var_210h;
    int64_t var_1b8h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_30h;
    int64_t var_18h;
    
    var_18h = -2;
    var_30h = arg1;
    fcn.14011ec40();
    var_118h = *(int64_t *)(var_30h + 8);
    var_110h = 0;
    var_120h._0_4_ = 1;
    fcn.14011ec40(var_30h, &var_120h);
    return;
}

// ============================================================
// Function: FUN_1400218a0
// Address: 0x1400218a0
// Size: 23 bytes
// ============================================================
void fcn.1400218a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400218c0
// Address: 0x1400218c0
// Size: 56 bytes
// ============================================================
undefined8 fcn.1400218c0(undefined8 placeholder_0, int64_t arg2, int64_t arg_190h, int64_t arg_198h, int64_t arg_1a8h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x228));
    *(undefined8 *)(arg2 + 0x210) = uVar1;
    *(int64_t *)(arg2 + 0x218) = iVar2;
    return 0x140021884;
}

// ============================================================
// Function: FUN_140021900
// Address: 0x140021900
// Size: 23 bytes
// ============================================================
void fcn.140021900(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021920
// Address: 0x140021920
// Size: 51 bytes
// ============================================================
undefined8 fcn.140021920(undefined8 placeholder_0, int64_t arg2, int64_t arg_190h, int64_t arg_198h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x210) = uVar1;
    *(int64_t *)(arg2 + 0x218) = iVar2;
    return 0x140021884;
}

// ============================================================
// Function: FUN_140021960
// Address: 0x140021960
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_37b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140021960(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002196b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000037b8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000037a0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140021998;
    fcn.1401202b0();
    *(undefined8 *)(&stack0x00001be8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000037a0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00001bf0 + iVar1) = 0;
    *(undefined8 *)(&stack0x00001bf8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00001be0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400219d0;
    fcn.1401202b0(*(int64_t *)(&stack0x000037a0 + iVar1), &stack0x00001be0 + iVar1);
    return;
}

// ============================================================
// Function: FUN_1400219f0
// Address: 0x1400219f0
// Size: 23 bytes
// ============================================================
void fcn.1400219f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021a10
// Address: 0x140021a10
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3748h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3730h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3738h because it doesn't fit into ProtoModel

undefined8 fcn.140021a10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x37c8));
    *(undefined8 *)(arg2 + 0x37b0) = uVar1;
    *(int64_t *)(arg2 + 0x37b8) = iVar2;
    return 0x1400219da;
}

// ============================================================
// Function: FUN_140021a50
// Address: 0x140021a50
// Size: 23 bytes
// ============================================================
void fcn.140021a50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021a70
// Address: 0x140021a70
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3730h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3738h because it doesn't fit into ProtoModel

undefined8 fcn.140021a70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x37b0) = uVar1;
    *(int64_t *)(arg2 + 0x37b8) = iVar2;
    return 0x1400219da;
}

// ============================================================
// Function: FUN_140021ab0
// Address: 0x140021ab0
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_29d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140021ab0(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x140021abb;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000029d8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000029c0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140021ae8;
    fcn.14011f930();
    *(undefined8 *)(&stack0x000014f8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000029c0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00001500 + iVar1) = 0;
    *(undefined8 *)(&stack0x00001508 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x000014f0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140021b20;
    fcn.14011f930(*(int64_t *)(&stack0x000029c0 + iVar1), &stack0x000014f0 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140021b40
// Address: 0x140021b40
// Size: 23 bytes
// ============================================================
void fcn.140021b40(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021b60
// Address: 0x140021b60
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel

undefined8 fcn.140021b60(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x29e8));
    *(undefined8 *)(arg2 + 0x29d0) = uVar1;
    *(int64_t *)(arg2 + 0x29d8) = iVar2;
    return 0x140021b2a;
}

// ============================================================
// Function: FUN_140021ba0
// Address: 0x140021ba0
// Size: 23 bytes
// ============================================================
void fcn.140021ba0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021bc0
// Address: 0x140021bc0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel

undefined8 fcn.140021bc0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x29d0) = uVar1;
    *(int64_t *)(arg2 + 0x29d8) = iVar2;
    return 0x140021b2a;
}

// ============================================================
// Function: FUN_140021c00
// Address: 0x140021c00
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140021c00(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x140021c0b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00001fb8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00001fa0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140021c38;
    fcn.14011edb0();
    *(undefined8 *)(&stack0x00000fe8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00001fa0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00000ff0 + iVar1) = 0;
    *(undefined8 *)(&stack0x00000ff8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00000fe0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140021c70;
    fcn.14011edb0(*(int64_t *)(&stack0x00001fa0 + iVar1), &stack0x00000fe0 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140021c90
// Address: 0x140021c90
// Size: 23 bytes
// ============================================================
void fcn.140021c90(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021cb0
// Address: 0x140021cb0
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.140021cb0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1fc8));
    *(undefined8 *)(arg2 + 0x1fb0) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x140021c7a;
}

// ============================================================
// Function: FUN_140021cf0
// Address: 0x140021cf0
// Size: 23 bytes
// ============================================================
void fcn.140021cf0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021d10
// Address: 0x140021d10
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.140021d10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1fb0) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x140021c7a;
}

// ============================================================
// Function: FUN_140021d50
// Address: 0x140021d50
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140021d50(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x140021d5b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00001e98 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00001e80 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140021d88;
    fcn.14011fe60();
    *(undefined8 *)(&stack0x00000f58 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00001e80 + iVar1) + 8);
    *(undefined8 *)(&stack0x00000f60 + iVar1) = 0;
    *(undefined8 *)(&stack0x00000f68 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00000f50 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140021dc0;
    fcn.14011fe60(*(int64_t *)(&stack0x00001e80 + iVar1), &stack0x00000f50 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140021de0
// Address: 0x140021de0
// Size: 23 bytes
// ============================================================
void fcn.140021de0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021e00
// Address: 0x140021e00
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140021e00(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1ea8));
    *(undefined8 *)(arg2 + 0x1e90) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140021dca;
}

// ============================================================
// Function: FUN_140021e40
// Address: 0x140021e40
// Size: 23 bytes
// ============================================================
void fcn.140021e40(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021e60
// Address: 0x140021e60
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140021e60(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1e90) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140021dca;
}

// ============================================================
// Function: FUN_140021ea0
// Address: 0x140021ea0
// Size: 285 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

void fcn.140021ea0(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_280h;
    int64_t var_228h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    undefined var_22h;
    undefined var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_280h._0_4_ = 2;
    var_21h = 1;
    var_38h = arg1;
    var_48h = fcn.140796790(*(undefined8 *)(arg1 + 8));
    var_30h = var_38h + 0x10;
    fcn.140003010();
    piVar2 = &var_280h;
    fcn.140951cf0(var_30h, piVar2, 0x118);
    var_21h = 0;
    fcn.140796f10(&var_48h);
    iVar1 = var_38h;
    var_160h = *(int64_t *)(var_38h + 8);
    var_158h = 0;
    var_168h._0_4_ = 1;
    var_22h = 1;
    var_150h = (int64_t)piVar2;
    var_50h = fcn.140796790();
    var_38h = iVar1 + 0x10;
    fcn.140003010(var_38h);
    fcn.140951cf0(var_38h, &var_168h, 0x118);
    var_22h = 0;
    fcn.140796f10(&var_50h);
    return;
}

