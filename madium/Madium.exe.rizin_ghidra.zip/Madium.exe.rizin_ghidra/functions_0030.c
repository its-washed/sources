// Chunk 30 - 50 functions

// ============================================================
// Function: FUN_140021fc0
// Address: 0x140021fc0
// Size: 69 bytes
// ============================================================
void fcn.140021fc0(undefined8 placeholder_0, int64_t arg2, int64_t arg_c0h, int64_t arg_1d8h, int64_t arg_1f0h)
{
    int64_t var_10h;
    
    fcn.140951cf0(*(undefined8 *)(arg2 + 0x270), arg2 + 0x140, 0x118);
    fcn.140796f10(arg2 + 600);
    *(undefined *)(arg2 + 0x286) = 0;
    return;
}

// ============================================================
// Function: FUN_140022010
// Address: 0x140022010
// Size: 66 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_207h because it doesn't fit into ProtoModel

void fcn.140022010(undefined8 placeholder_0, int64_t arg2, int64_t arg_1e0h, int64_t arg_1f8h)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140951cf0(*(undefined8 *)(arg2 + 0x278), arg2 + 0x28, 0x118);
    fcn.140796f10(arg2 + 0x260);
    *(undefined *)(arg2 + 0x287) = 0;
    return;
}

// ============================================================
// Function: FUN_140022060
// Address: 0x140022060
// Size: 54 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_206h because it doesn't fit into ProtoModel

void fcn.140022060(undefined8 placeholder_0, int64_t arg2, int64_t arg_c0h)
{
    int64_t var_10h;
    
    if (*(char *)(arg2 + 0x286) == '\0') {
        return;
    }
    fcn.140003010(arg2 + 0x140);
    return;
}

// ============================================================
// Function: FUN_1400220a0
// Address: 0x1400220a0
// Size: 44 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_207h because it doesn't fit into ProtoModel

void fcn.1400220a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(char *)(arg2 + 0x287) != '\0') {
        fcn.140003010(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_1400220d0
// Address: 0x1400220d0
// Size: 53 bytes
// ============================================================
undefined8 fcn.1400220d0(undefined8 placeholder_0, int64_t arg2, int64_t arg_1e8h, int64_t arg_1f8h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x278) = uVar1;
    *(int64_t *)(arg2 + 0x268) = iVar2;
    return 0x140021faa;
}

// ============================================================
// Function: FUN_140022110
// Address: 0x140022110
// Size: 24 bytes
// ============================================================
void fcn.140022110(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140022130
// Address: 0x140022130
// Size: 58 bytes
// ============================================================
undefined8 fcn.140022130(undefined8 placeholder_0, int64_t arg2, int64_t arg_1e8h, int64_t arg_1f8h, int64_t arg_210h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x290));
    *(undefined8 *)(arg2 + 0x278) = uVar1;
    *(int64_t *)(arg2 + 0x268) = iVar2;
    return 0x140021faa;
}

// ============================================================
// Function: FUN_140022170
// Address: 0x140022170
// Size: 24 bytes
// ============================================================
void fcn.140022170(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140022190
// Address: 0x140022190
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140022190(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002219b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00002798 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00002780 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400221c8;
    fcn.14011f7c0();
    *(undefined8 *)(&stack0x000013d8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00002780 + iVar1) + 8);
    *(undefined8 *)(&stack0x000013e0 + iVar1) = 0;
    *(undefined8 *)(&stack0x000013e8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x000013d0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140022200;
    fcn.14011f7c0(*(int64_t *)(&stack0x00002780 + iVar1), &stack0x000013d0 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140022220
// Address: 0x140022220
// Size: 23 bytes
// ============================================================
void fcn.140022220(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140022240
// Address: 0x140022240
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2728h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2718h because it doesn't fit into ProtoModel

undefined8 fcn.140022240(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x27a8));
    *(undefined8 *)(arg2 + 0x2790) = uVar1;
    *(int64_t *)(arg2 + 0x2798) = iVar2;
    return 0x14002220a;
}

// ============================================================
// Function: FUN_140022280
// Address: 0x140022280
// Size: 23 bytes
// ============================================================
void fcn.140022280(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400222a0
// Address: 0x1400222a0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2718h because it doesn't fit into ProtoModel

undefined8 fcn.1400222a0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2790) = uVar1;
    *(int64_t *)(arg2 + 0x2798) = iVar2;
    return 0x14002220a;
}

// ============================================================
// Function: FUN_1400222e0
// Address: 0x1400222e0
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400222e0(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1400222eb;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00002018 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00002000 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140022318;
    fcn.140120590();
    *(undefined8 *)(&stack0x00001018 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00002000 + iVar1) + 8);
    *(undefined8 *)(&stack0x00001020 + iVar1) = 0;
    *(undefined8 *)(&stack0x00001028 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00001010 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140022350;
    fcn.140120590(*(int64_t *)(&stack0x00002000 + iVar1), &stack0x00001010 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140022370
// Address: 0x140022370
// Size: 23 bytes
// ============================================================
void fcn.140022370(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140022390
// Address: 0x140022390
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f98h because it doesn't fit into ProtoModel

undefined8 fcn.140022390(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2028));
    *(undefined8 *)(arg2 + 0x2010) = uVar1;
    *(int64_t *)(arg2 + 0x2018) = iVar2;
    return 0x14002235a;
}

// ============================================================
// Function: FUN_1400223d0
// Address: 0x1400223d0
// Size: 23 bytes
// ============================================================
void fcn.1400223d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400223f0
// Address: 0x1400223f0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f98h because it doesn't fit into ProtoModel

undefined8 fcn.1400223f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2010) = uVar1;
    *(int64_t *)(arg2 + 0x2018) = iVar2;
    return 0x14002235a;
}

// ============================================================
// Function: FUN_140022430
// Address: 0x140022430
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_27f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1410h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140022430(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002243b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000027f8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000027e0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140022468;
    fcn.14011fc10();
    *(undefined8 *)(&stack0x00001408 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000027e0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00001410 + iVar1) = 0;
    *(undefined8 *)(&stack0x00001418 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00001400 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400224a0;
    fcn.14011fc10(*(int64_t *)(&stack0x000027e0 + iVar1), &stack0x00001400 + iVar1);
    return;
}

// ============================================================
// Function: FUN_1400224c0
// Address: 0x1400224c0
// Size: 23 bytes
// ============================================================
void fcn.1400224c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400224e0
// Address: 0x1400224e0
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.1400224e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2808));
    *(undefined8 *)(arg2 + 0x27f0) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x1400224aa;
}

// ============================================================
// Function: FUN_140022520
// Address: 0x140022520
// Size: 23 bytes
// ============================================================
void fcn.140022520(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140022540
// Address: 0x140022540
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel

undefined8 fcn.140022540(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x27f0) = uVar1;
    *(int64_t *)(arg2 + 0x27f8) = iVar2;
    return 0x1400224aa;
}

// ============================================================
// Function: FUN_140022580
// Address: 0x140022580
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_5258h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2940h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2948h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140022580(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002258b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00005258 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00005240 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400225b8;
    fcn.14011de70();
    *(undefined8 *)(&stack0x00002938 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00005240 + iVar1) + 8);
    *(undefined8 *)(&stack0x00002940 + iVar1) = 0;
    *(undefined8 *)(&stack0x00002948 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00002930 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400225f0;
    fcn.14011de70(*(int64_t *)(&stack0x00005240 + iVar1), &stack0x00002930 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140022610
// Address: 0x140022610
// Size: 23 bytes
// ============================================================
void fcn.140022610(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140022630
// Address: 0x140022630
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_51e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_51d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_51d8h because it doesn't fit into ProtoModel

undefined8 fcn.140022630(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x5268));
    *(undefined8 *)(arg2 + 0x5250) = uVar1;
    *(int64_t *)(arg2 + 0x5258) = iVar2;
    return 0x1400225fa;
}

// ============================================================
// Function: FUN_140022670
// Address: 0x140022670
// Size: 23 bytes
// ============================================================
void fcn.140022670(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140022690
// Address: 0x140022690
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_51d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_51d8h because it doesn't fit into ProtoModel

undefined8 fcn.140022690(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x5250) = uVar1;
    *(int64_t *)(arg2 + 0x5258) = iVar2;
    return 0x1400225fa;
}

// ============================================================
// Function: FUN_1400226d0
// Address: 0x1400226d0
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3098h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1860h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1868h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400226d0(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1400226db;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00003098 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00003080 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140022708;
    fcn.140120420();
    *(undefined8 *)(&stack0x00001858 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00003080 + iVar1) + 8);
    *(undefined8 *)(&stack0x00001860 + iVar1) = 0;
    *(undefined8 *)(&stack0x00001868 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00001850 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140022740;
    fcn.140120420(*(int64_t *)(&stack0x00003080 + iVar1), &stack0x00001850 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140022760
// Address: 0x140022760
// Size: 23 bytes
// ============================================================
void fcn.140022760(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140022780
// Address: 0x140022780
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3018h because it doesn't fit into ProtoModel

undefined8 fcn.140022780(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x30a8));
    *(undefined8 *)(arg2 + 0x3090) = uVar1;
    *(int64_t *)(arg2 + 0x3098) = iVar2;
    return 0x14002274a;
}

// ============================================================
// Function: FUN_1400227c0
// Address: 0x1400227c0
// Size: 23 bytes
// ============================================================
void fcn.1400227c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400227e0
// Address: 0x1400227e0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3018h because it doesn't fit into ProtoModel

undefined8 fcn.1400227e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x3090) = uVar1;
    *(int64_t *)(arg2 + 0x3098) = iVar2;
    return 0x14002274a;
}

// ============================================================
// Function: FUN_140022820
// Address: 0x140022820
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1d78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140022820(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002282b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00001d78 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00001d60 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140022858;
    fcn.140120140();
    *(undefined8 *)(&stack0x00000ec8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00001d60 + iVar1) + 8);
    *(undefined8 *)(&stack0x00000ed0 + iVar1) = 0;
    *(undefined8 *)(&stack0x00000ed8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00000ec0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140022890;
    fcn.140120140(*(int64_t *)(&stack0x00001d60 + iVar1), &stack0x00000ec0 + iVar1);
    return;
}

// ============================================================
// Function: FUN_1400228b0
// Address: 0x1400228b0
// Size: 23 bytes
// ============================================================
void fcn.1400228b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400228d0
// Address: 0x1400228d0
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1d08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cf8h because it doesn't fit into ProtoModel

undefined8 fcn.1400228d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1d88));
    *(undefined8 *)(arg2 + 0x1d70) = uVar1;
    *(int64_t *)(arg2 + 0x1d78) = iVar2;
    return 0x14002289a;
}

// ============================================================
// Function: FUN_140022910
// Address: 0x140022910
// Size: 23 bytes
// ============================================================
void fcn.140022910(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140022930
// Address: 0x140022930
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1cf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cf8h because it doesn't fit into ProtoModel

undefined8 fcn.140022930(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1d70) = uVar1;
    *(int64_t *)(arg2 + 0x1d78) = iVar2;
    return 0x14002289a;
}

// ============================================================
// Function: FUN_140022970
// Address: 0x140022970
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel

void fcn.140022970(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x14002297d;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x000013a0 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400229a5;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x1380);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400229bc;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x1350);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140022aa4;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00001378 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00001368 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x0000136c + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00001370 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00001374 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00001388 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001398 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001390 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00001360 + iVar9) = *(int64_t *)(&stack0x00001390 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140022a5c;
                (*pcVar3)(*(undefined8 *)(&stack0x00001388 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001398 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001390 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001398 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140022a87;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00001388 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x0000136c + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00001370 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00001374 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00001368 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00001378 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140022ab0
// Address: 0x140022ab0
// Size: 44 bytes
// ============================================================
void fcn.140022ab0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012430(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140022ae0
// Address: 0x140022ae0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1320h because it doesn't fit into ProtoModel

void fcn.140022ae0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1378);
    puVar2 = *(undefined8 **)(arg2 + 0x13a8);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x13b0) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x13a0), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x13b0) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1390);
    uVar4 = *(undefined4 *)(arg2 + 0x1384);
    uVar5 = *(undefined4 *)(arg2 + 5000);
    uVar6 = *(undefined4 *)(arg2 + 0x138c);
    *puVar1 = *(undefined4 *)(arg2 + 0x1380);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140022b50
// Address: 0x140022b50
// Size: 304 bytes
// ============================================================
void fcn.140022b50(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_f90h;
    int64_t var_f38h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0xf60);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_f90h, arg1 + 0x30, 0xf30);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_f90h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_140022c80
// Address: 0x140022c80
// Size: 44 bytes
// ============================================================
void fcn.140022c80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.1400133f0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140022cb0
// Address: 0x140022cb0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f00h because it doesn't fit into ProtoModel

void fcn.140022cb0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0xf58);
    puVar2 = *(undefined8 **)(arg2 + 0xf88);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0xf90) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf80), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0xf90) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0xf70);
    uVar4 = *(undefined4 *)(arg2 + 0xf64);
    uVar5 = *(undefined4 *)(arg2 + 0xf68);
    uVar6 = *(undefined4 *)(arg2 + 0xf6c);
    *puVar1 = *(undefined4 *)(arg2 + 0xf60);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140022d20
// Address: 0x140022d20
// Size: 304 bytes
// ============================================================
void fcn.140022d20(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_178h;
    int64_t var_118h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0x148);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_178h, arg1 + 0x30, 0x118);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_178h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_140022e50
// Address: 0x140022e50
// Size: 44 bytes
// ============================================================
void fcn.140022e50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_60h;
    
    if (*(int32_t *)(arg2 + 0x20) != 1) {
        fcn.140003010(arg2 + 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_140022e80
// Address: 0x140022e80
// Size: 108 bytes
// ============================================================
void fcn.140022e80(undefined8 placeholder_0, int64_t arg2, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_d0h,
                  int64_t arg_e0h, int64_t arg_e8h, int64_t arg_f0h)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x138);
    puVar2 = *(undefined8 **)(arg2 + 0x168);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x170) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x160), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x170) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x150);
    uVar4 = *(undefined4 *)(arg2 + 0x144);
    uVar5 = *(undefined4 *)(arg2 + 0x148);
    uVar6 = *(undefined4 *)(arg2 + 0x14c);
    *puVar1 = *(undefined4 *)(arg2 + 0x140);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140022ef0
// Address: 0x140022ef0
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1430h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1420h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel

void fcn.140022ef0(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x140022efd;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001430 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140022f25;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x1410);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140022f3c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x13e0);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023024;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00001408 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x000013f8 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x000013fc + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00001400 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00001404 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00001418 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001428 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001420 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x000013f0 + iVar9) = *(int64_t *)(&stack0x00001420 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140022fdc;
                (*pcVar3)(*(undefined8 *)(&stack0x00001418 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001428 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001420 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001428 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140023007;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00001418 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x000013fc + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00001400 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00001404 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x000013f8 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00001408 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140023030
// Address: 0x140023030
// Size: 44 bytes
// ============================================================
void fcn.140023030(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.1400128b0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140023060
// Address: 0x140023060
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel

void fcn.140023060(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1408);
    puVar2 = *(undefined8 **)(arg2 + 0x1438);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1440) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1430), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1440) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1420);
    uVar4 = *(undefined4 *)(arg2 + 0x1414);
    uVar5 = *(undefined4 *)(arg2 + 0x1418);
    uVar6 = *(undefined4 *)(arg2 + 0x141c);
    *puVar1 = *(undefined4 *)(arg2 + 0x1410);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

