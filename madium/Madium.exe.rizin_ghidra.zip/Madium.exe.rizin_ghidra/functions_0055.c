// Chunk 55 - 50 functions

// ============================================================
// Function: FUN_14003ef30
// Address: 0x14003ef30
// Size: 25 bytes
// ============================================================
void fcn.14003ef30(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003ef50
// Address: 0x14003ef50
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003ef50(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003eda7;
}

// ============================================================
// Function: FUN_14003ef90
// Address: 0x14003ef90
// Size: 25 bytes
// ============================================================
void fcn.14003ef90(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003efb0
// Address: 0x14003efb0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003efb0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003eda7;
}

// ============================================================
// Function: FUN_14003eff0
// Address: 0x14003eff0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.14003eff0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14003f040
// Address: 0x14003f040
// Size: 505 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3088h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3078h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1840h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3090h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3070h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcc00f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_beh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1638h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5cb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1640h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1630h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_187h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ae0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ad8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ad0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4160h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1718h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2528h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2170h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800f6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2430h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2438h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_58e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ad8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcc00f9h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2800h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1568h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2638h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_54a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1688h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7cfh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7afh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3898h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Removing arg arg_b88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2160h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800f7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3980h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3988h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3990h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_6h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Removing arg arg_c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2808h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_39a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_718h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_728h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcc0102h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2728h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2718h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2730h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_489000dch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_17fh
// WARNING: [rz-ghidra] Removing arg arg_ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_708h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_99h
// WARNING: [rz-ghidra] Removing arg arg_2710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3098h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_30a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1828h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3068h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1830h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1820h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1838h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_36f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_36f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1660h because it doesn't fit into ProtoModel

void fcn.14003f040(int64_t var_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_98h,
                  int64_t arg_a0h, int64_t arg_a8h, int64_t arg_100h, int64_t arg_108h, int64_t arg_110h,
                  int64_t arg_118h, int64_t arg_120h, int64_t arg_128h, int64_t arg_130h, int64_t arg_138h,
                  int64_t arg_140h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h, int64_t arg_160h,
                  int64_t arg_168h, int64_t arg_170h, int64_t arg_178h, int64_t arg_188h, int64_t arg_198h,
                  int64_t arg_1b0h, int64_t arg_1b8h, int64_t arg_1c0h, int64_t arg_1c8h, int64_t arg_1d0h,
                  int64_t arg_1f0h, int64_t arg_1f8h, int64_t arg_200h, int64_t arg_210h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t var_7h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_3bd6b798h;
    int64_t var_e80h;
    int64_t var_e40h;
    int64_t var_7e8h;
    int64_t var_7e0h;
    int64_t var_790h;
    int64_t var_788h;
    int64_t var_640h;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_3a0h;
    int64_t var_360h;
    int64_t var_348h;
    int64_t var_220h;
    int64_t var_1a8h;
    int64_t var_160h;
    int64_t var_150h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    undefined8 uStack_20;
    int64_t var_8h;
    
    uStack_20 = 0x14003f04d;
    iVar2 = func_0x00014094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14003f06b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014003f07c. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (18 cases) at 0x14097a784
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a784) + 0x14097a784))();
    return;
}

// ============================================================
// Function: FUN_14003f240
// Address: 0x14003f240
// Size: 37 bytes
// ============================================================
void fcn.14003f240(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14003f270
// Address: 0x14003f270
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14003f270(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_14003f2b0
// Address: 0x14003f2b0
// Size: 25 bytes
// ============================================================
void fcn.14003f2b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003f2d0
// Address: 0x14003f2d0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003f2d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003f167;
}

// ============================================================
// Function: FUN_14003f310
// Address: 0x14003f310
// Size: 25 bytes
// ============================================================
void fcn.14003f310(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003f330
// Address: 0x14003f330
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003f330(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003f167;
}

// ============================================================
// Function: FUN_14003f370
// Address: 0x14003f370
// Size: 25 bytes
// ============================================================
void fcn.14003f370(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003f390
// Address: 0x14003f390
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003f390(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003f1e7;
}

// ============================================================
// Function: FUN_14003f3d0
// Address: 0x14003f3d0
// Size: 25 bytes
// ============================================================
void fcn.14003f3d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003f3f0
// Address: 0x14003f3f0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003f3f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003f1e7;
}

// ============================================================
// Function: FUN_14003f430
// Address: 0x14003f430
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.14003f430(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14003f480
// Address: 0x14003f480
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.14003f480(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14003f48d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14003f4ab;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014003f4bc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a7a4) + 0x14097a7a4))();
    return;
}

// ============================================================
// Function: FUN_14003f680
// Address: 0x14003f680
// Size: 37 bytes
// ============================================================
void fcn.14003f680(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14003f6b0
// Address: 0x14003f6b0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14003f6b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_14003f6f0
// Address: 0x14003f6f0
// Size: 25 bytes
// ============================================================
void fcn.14003f6f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003f710
// Address: 0x14003f710
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003f710(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003f5a7;
}

// ============================================================
// Function: FUN_14003f750
// Address: 0x14003f750
// Size: 25 bytes
// ============================================================
void fcn.14003f750(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003f770
// Address: 0x14003f770
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003f770(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003f5a7;
}

// ============================================================
// Function: FUN_14003f7b0
// Address: 0x14003f7b0
// Size: 25 bytes
// ============================================================
void fcn.14003f7b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003f7d0
// Address: 0x14003f7d0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003f7d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003f627;
}

// ============================================================
// Function: FUN_14003f810
// Address: 0x14003f810
// Size: 25 bytes
// ============================================================
void fcn.14003f810(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003f830
// Address: 0x14003f830
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003f830(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003f627;
}

// ============================================================
// Function: FUN_14003f870
// Address: 0x14003f870
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.14003f870(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14003f8c0
// Address: 0x14003f8c0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.14003f8c0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14003f8cd;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14003f8eb;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014003f8fc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a7c4) + 0x14097a7c4))();
    return;
}

// ============================================================
// Function: FUN_14003fac0
// Address: 0x14003fac0
// Size: 37 bytes
// ============================================================
void fcn.14003fac0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14003faf0
// Address: 0x14003faf0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14003faf0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_14003fb30
// Address: 0x14003fb30
// Size: 25 bytes
// ============================================================
void fcn.14003fb30(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003fb50
// Address: 0x14003fb50
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003fb50(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003f9e7;
}

// ============================================================
// Function: FUN_14003fb90
// Address: 0x14003fb90
// Size: 25 bytes
// ============================================================
void fcn.14003fb90(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003fbb0
// Address: 0x14003fbb0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003fbb0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003f9e7;
}

// ============================================================
// Function: FUN_14003fbf0
// Address: 0x14003fbf0
// Size: 25 bytes
// ============================================================
void fcn.14003fbf0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003fc10
// Address: 0x14003fc10
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003fc10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003fa67;
}

// ============================================================
// Function: FUN_14003fc50
// Address: 0x14003fc50
// Size: 25 bytes
// ============================================================
void fcn.14003fc50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003fc70
// Address: 0x14003fc70
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003fc70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003fa67;
}

// ============================================================
// Function: FUN_14003fcb0
// Address: 0x14003fcb0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.14003fcb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14003fd00
// Address: 0x14003fd00
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.14003fd00(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14003fd0d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14003fd2b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014003fd3c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a7e4) + 0x14097a7e4))();
    return;
}

// ============================================================
// Function: FUN_14003ff00
// Address: 0x14003ff00
// Size: 37 bytes
// ============================================================
void fcn.14003ff00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14003ff30
// Address: 0x14003ff30
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14003ff30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_14003ff70
// Address: 0x14003ff70
// Size: 25 bytes
// ============================================================
void fcn.14003ff70(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003ff90
// Address: 0x14003ff90
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003ff90(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003fe27;
}

// ============================================================
// Function: FUN_14003ffd0
// Address: 0x14003ffd0
// Size: 25 bytes
// ============================================================
void fcn.14003ffd0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003fff0
// Address: 0x14003fff0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003fff0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003fe27;
}

// ============================================================
// Function: FUN_140040030
// Address: 0x140040030
// Size: 25 bytes
// ============================================================
void fcn.140040030(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140040050
// Address: 0x140040050
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140040050(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003fea7;
}

