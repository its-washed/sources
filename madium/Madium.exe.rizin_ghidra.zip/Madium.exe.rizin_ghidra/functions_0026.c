// Chunk 26 - 50 functions

// ============================================================
// Function: FUN_14001e7c0
// Address: 0x14001e7c0
// Size: 34 bytes
// ============================================================
void fcn.14001e7c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_18h;
    
    fcn.14001dc60(*(undefined8 *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_14001e7f0
// Address: 0x14001e7f0
// Size: 41 bytes
// ============================================================
void fcn.14001e7f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001cbd0(*(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x6b0));
    return;
}

// ============================================================
// Function: FUN_14001e820
// Address: 0x14001e820
// Size: 45 bytes
// ============================================================
void fcn.14001e820(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), 0x20, 8);
    return;
}

// ============================================================
// Function: FUN_14001e850
// Address: 0x14001e850
// Size: 356 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.14001e850(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x45) == '\x03') {
        if (*(char *)(arg1 + 0x1a9) == '\x03') {
            func_0x00014001d230(arg1 + 0x70);
            piVar1 = *(int64_t **)(arg1 + 0x68);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001404da6a0(arg1 + 0x68);
            }
            *(undefined *)(arg1 + 0x1a8) = 0;
        }
    } else {
        if (*(char *)(arg1 + 0x45) != '\x04') {
            return;
        }
        if (*(char *)(arg1 + 0x470) == '\x03') {
            if (*(char *)(arg1 + 0x468) == '\x03') {
                func_0x00014001f080(arg1 + 0x280);
                if (*(int32_t *)(arg1 + 0x220) != 2) {
                    if ((*(char *)(arg1 + 0x250) != '\0') && (*(int64_t *)(arg1 + 600) != 0)) {
                        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x260), *(int64_t *)(arg1 + 600), 1);
                    }
                    iVar3 = *(int64_t *)(arg1 + 0x230);
                    if ((-1 < iVar3) && (iVar3 != 0)) {
                        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x238), iVar3 << 5, 8);
                    }
                }
                *(undefined *)(arg1 + 0x469) = 0;
            } else if (*(char *)(arg1 + 0x468) == '\0') {
                func_0x00014001d7a0(arg1 + 0xe0);
            }
        } else if (*(char *)(arg1 + 0x470) == '\0') {
            func_0x00014001d7a0(arg1 + 0x48);
        }
    }
    *(undefined *)(arg1 + 0x44) = 0;
    if (*(int64_t *)(arg1 + 0x20) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x28), *(int64_t *)(arg1 + 0x20), 1);
    }
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x10);
    uVar4 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar4, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14001e9c0
// Address: 0x14001e9c0
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001e9c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    piVar2 = *(int64_t **)(iVar1 + 0x68);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1404da6a0(iVar1 + 0x68);
    }
    return;
}

// ============================================================
// Function: FUN_14001ea00
// Address: 0x14001ea00
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001ea00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    *(undefined *)(*(int64_t *)(arg2 + 0x28) + 0x1a8) = 0;
    return;
}

// ============================================================
// Function: FUN_14001ea30
// Address: 0x14001ea30
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001ea30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    fcn.14001d690(iVar1 + 0x220);
    *(undefined *)(iVar1 + 0x469) = 0;
    return;
}

// ============================================================
// Function: FUN_14001ea60
// Address: 0x14001ea60
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001ea60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    *(undefined *)(iVar1 + 0x44) = 0;
    if (*(int64_t *)(iVar1 + 0x20) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x28), *(int64_t *)(iVar1 + 0x20), 1);
    }
    if (*(int64_t *)(iVar1 + 8) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x10), *(int64_t *)(iVar1 + 8), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14001eac0
// Address: 0x14001eac0
// Size: 210 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00014001eb34: Changing call to branch
// WARNING: Possible PIC construction at 0x00014001eb6a: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001eac0(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    int64_t unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 auStack_40 [5];
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    int64_t *piVar5;
    
    piVar4 = &var_8h;
    piVar5 = &var_8h;
    var_10h = -2;
    piVar3 = *(int64_t **)(arg1 + 0x18);
    LOCK();
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    var_18h = arg1;
    var_8h = unaff_RBP;
    if (*piVar3 == 0) {
        auStack_40[0] = 0x14001eaed;
        func_0x0001406c6790(arg1 + 0x18);
    }
    auStack_40[0] = 0x14001eaf6;
    func_0x0001402c5910(var_18h);
    auStack_40[0] = 0x14001eb03;
    func_0x00014001f200(var_18h + 0x28);
    piVar3 = *(int64_t **)(var_18h + 0x58);
    LOCK();
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (*piVar3 == 0) {
        auStack_40[0] = 0x14001eb1e;
        func_0x0001406c7890(var_18h + 0x58);
    }
    piVar3 = *(int64_t **)(var_18h + 0x60);
    LOCK();
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (*piVar3 == 0) {
        piVar3 = (int64_t *)(var_18h + 0x60);
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_40;
        auStack_40[0] = 0x14001eb39;
        var_8h = (int64_t)piVar4;
    } else {
        piVar3 = *(int64_t **)(var_18h + 0x68);
        LOCK();
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (*piVar3 == 0) {
            auStack_40[0] = 0x14001eb54;
            func_0x00014045ec00(var_18h + 0x68);
        }
        piVar3 = *(int64_t **)(var_18h + 0x70);
        LOCK();
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (*piVar3 == 0) {
            piVar3 = (int64_t *)(var_18h + 0x70);
            *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_40;
            auStack_40[0] = 0x14001eb6f;
            var_8h = (int64_t)piVar5;
        } else {
            piVar3 = *(int64_t **)(var_18h + 0x78);
            LOCK();
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (*piVar3 != 0) {
                return;
            }
            piVar3 = (int64_t *)(var_18h + 0x78);
        }
    }
    iVar1 = *piVar3;
    if (iVar1 != -1) {
        LOCK();
        piVar3 = (int64_t *)(iVar1 + 8);
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (*piVar3 == 0) {
            *(int64_t *)((int64_t)*(undefined **)0x20 + -8) = var_8h;
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140901d3e;
            uVar2 = (*(code *)0xe5f2d8)(iVar1, 0x18);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar2, 0, iVar1);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001eba0
// Address: 0x14001eba0
// Size: 47 bytes
// ============================================================
void fcn.14001eba0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x58);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7890(iVar1 + 0x58);
    }
    return;
}

// ============================================================
// Function: FUN_14001ebd0
// Address: 0x14001ebd0
// Size: 47 bytes
// ============================================================
void fcn.14001ebd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x60);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.14045ec00(iVar1 + 0x60);
    }
    return;
}

// ============================================================
// Function: FUN_14001ec00
// Address: 0x14001ec00
// Size: 47 bytes
// ============================================================
void fcn.14001ec00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x68);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.14045ec00(iVar1 + 0x68);
    }
    return;
}

// ============================================================
// Function: FUN_14001ec30
// Address: 0x14001ec30
// Size: 47 bytes
// ============================================================
void fcn.14001ec30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x70);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.14045ec00(iVar1 + 0x70);
    }
    return;
}

// ============================================================
// Function: FUN_14001ec60
// Address: 0x14001ec60
// Size: 47 bytes
// ============================================================
void fcn.14001ec60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x78);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.14045ec00(iVar1 + 0x78);
    }
    return;
}

// ============================================================
// Function: FUN_14001ec90
// Address: 0x14001ec90
// Size: 30 bytes
// ============================================================
void fcn.14001ec90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1402c5910(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14001ecb0
// Address: 0x14001ecb0
// Size: 34 bytes
// ============================================================
void fcn.14001ecb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001f200(*(int64_t *)(arg2 + 0x20) + 0x28);
    return;
}

// ============================================================
// Function: FUN_14001ece0
// Address: 0x14001ece0
// Size: 151 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001ece0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    undefined8 uVar5;
    undefined8 in_R9;
    undefined8 *puVar6;
    int64_t iVar7;
    bool bVar8;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)arg1;
    LOCK();
    piVar1 = (int64_t *)(iVar2 + 0x58);
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        LOCK();
        bVar8 = *(char *)(iVar2 + 0x28) == '\0';
        if (bVar8) {
            *(char *)(iVar2 + 0x28) = '\x01';
        }
        UNLOCK();
        if (!bVar8) {
            func_0x0001409766f0(iVar2 + 0x28);
        }
        if ((**(uint64_t **)0x140e64720 & 0x7fffffffffffffff) == 0) {
            uVar4 = 0;
        } else {
            uVar4 = func_0x000140977200();
            uVar4 = uVar4 ^ 1;
        }
        *(undefined *)(iVar2 + 0x50) = 1;
        func_0x0001402d0210(iVar2 + 0x10, iVar2 + 0x28, uVar4, in_R9, arg1, 0xfffffffffffffffe);
    }
    piVar1 = *(int64_t **)arg1;
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        arg1 = *(int64_t *)arg1;
        iVar2 = *(int64_t *)(arg1 + 0x18);
        if (iVar2 != 0) {
            iVar3 = *(int64_t *)(arg1 + 0x10);
            puVar6 = (undefined8 *)(iVar3 + 0x10);
            iVar7 = iVar2;
            do {
                if (puVar6[-1] != 0) {
                    fcn.1404d3c50(*puVar6, puVar6[-1], 1);
                }
                puVar6 = puVar6 + 6;
                iVar7 = iVar7 + -1;
            } while (iVar7 != 0);
            fcn.1404d3c50(iVar3, iVar2 * 0x30, 8);
        }
        if (arg1 != -1) {
            LOCK();
            piVar1 = (int64_t *)(arg1 + 8);
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                uVar5 = (*(code *)0xe5f2d8)(arg1, 0x88);
    // WARNING: Treating indirect jump as call
                (*(code *)0xe5f2ea)(uVar5, 0, arg1);
                return;
            }
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_14001ed80
// Address: 0x14001ed80
// Size: 47 bytes
// ============================================================
void fcn.14001ed80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f100(*(undefined8 *)(arg2 + 0x20));
    }
    return;
}

// ============================================================
// Function: FUN_14001edb0
// Address: 0x14001edb0
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001edb0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (arg1 != -1) {
        if (arg2 != 0) {
            func_0x0001407b8380(arg2);
            piVar1 = *(int64_t **)arg2;
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001407b8e20(arg2);
            }
            piVar1 = *(int64_t **)(arg2 + 8);
            LOCK();
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
                func_0x0001407b9000(arg2 + 8);
            }
            fcn.1404d3c50(arg2, 0x20, 8);
        }
    // WARNING: Treating indirect jump as call
        (*(code *)0xe5f428)(arg1);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_14001ee40
// Address: 0x14001ee40
// Size: 42 bytes
// ============================================================
void fcn.14001ee40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    ppiVar1 = *(int64_t ***)(arg2 + 0x30);
    piVar2 = *ppiVar1;
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1407b8e20(ppiVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14001ee70
// Address: 0x14001ee70
// Size: 47 bytes
// ============================================================
void fcn.14001ee70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 8);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1407b9000(iVar1 + 8);
    }
    return;
}

// ============================================================
// Function: FUN_14001eea0
// Address: 0x14001eea0
// Size: 51 bytes
// ============================================================
void fcn.14001eea0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_18h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x20, 8);
    (*(code *)0xe5f428)(*(undefined8 *)(arg2 + 0x28));
    return;
}

// ============================================================
// Function: FUN_14001eee0
// Address: 0x14001eee0
// Size: 57 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001eee0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    func_0x0001402d8080();
    piVar1 = *(int64_t **)arg1;
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 != 0) {
        return;
    }
    arg1 = *(int64_t *)arg1;
    iVar2 = *(int64_t *)(arg1 + 0x18);
    if (iVar2 != 0) {
        iVar3 = *(int64_t *)(arg1 + 0x10);
        puVar5 = (undefined8 *)(iVar3 + 0x10);
        iVar6 = iVar2;
        do {
            if (puVar5[-1] != 0) {
                fcn.1404d3c50(*puVar5, puVar5[-1], 1);
            }
            puVar5 = puVar5 + 6;
            iVar6 = iVar6 + -1;
        } while (iVar6 != 0);
        fcn.1404d3c50(iVar3, iVar2 * 0x30, 8);
    }
    if (arg1 != -1) {
        LOCK();
        piVar1 = (int64_t *)(arg1 + 8);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            uVar4 = (*(code *)0xe5f2d8)(arg1, 0x88);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar4, 0, arg1);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001ef20
// Address: 0x14001ef20
// Size: 43 bytes
// ============================================================
void fcn.14001ef20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f100(*(undefined8 *)(arg2 + 0x20));
    }
    return;
}

// ============================================================
// Function: FUN_14001ef50
// Address: 0x14001ef50
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001ef50(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_40 = 0x14001ef6b;
    func_0x000140416ae0();
    piVar2 = *(int64_t **)arg1;
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 != 0) {
        return;
    }
    var_30h = -2;
    var_38h = *(int64_t *)arg1;
    iVar1 = var_38h + 0x80;
    iVar6 = var_38h + 0x1a0;
    func_0x0001404114b0(&var_50h, iVar6, iVar1);
    if (-0x7fffffffffffffff < var_50h) {
        do {
            if (var_50h != 0) {
                fcn.1404d3c50(var_48h, var_50h, 1);
            }
            func_0x0001404114b0(&var_50h, iVar6, iVar1);
        } while (-0x7fffffffffffffff < var_50h);
    }
    iVar1 = var_38h;
    iVar6 = *(int64_t *)(var_38h + 0x1a8);
    do {
        iVar3 = *(int64_t *)(iVar6 + 0x308);
        fcn.1404d3c50(iVar6, 800, 8);
        iVar6 = iVar3;
    } while (iVar3 != 0);
    if (*(int64_t *)(iVar1 + 0x100) != 0) {
        (**(code **)(*(int64_t *)(iVar1 + 0x100) + 0x18))(*(undefined8 *)(var_38h + 0x108));
    }
    if (var_38h != -1) {
        LOCK();
        piVar2 = (int64_t *)(var_38h + 8);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            uVar4 = *(undefined8 *)(var_38h + -8);
            uStack_40 = 0x140901d3e;
            uVar5 = (*(code *)0xe5f2d8)(var_38h, 0x200);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001ef90
// Address: 0x14001ef90
// Size: 43 bytes
// ============================================================
void fcn.14001ef90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f950(*(undefined8 *)(arg2 + 0x20));
    }
    return;
}

// ============================================================
// Function: FUN_14001efc0
// Address: 0x14001efc0
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001efc0(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iStack_50;
    undefined8 uStack_48;
    undefined8 uStack_40;
    int64_t iStack_38;
    undefined8 uStack_30;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_40 = 0x14001efdb;
    func_0x000140416640();
    piVar2 = *(int64_t **)arg1;
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 != 0) {
        return;
    }
    uStack_30 = 0xfffffffffffffffe;
    iStack_38 = *(int64_t *)arg1;
    iVar1 = iStack_38 + 0x80;
    iVar6 = iStack_38 + 0x1a0;
    func_0x0001404114b0(&iStack_50, iVar6, iVar1);
    if (-0x7fffffffffffffff < iStack_50) {
        do {
            if (iStack_50 != 0) {
                fcn.1404d3c50(uStack_48, iStack_50, 1);
            }
            func_0x0001404114b0(&iStack_50, iVar6, iVar1);
        } while (-0x7fffffffffffffff < iStack_50);
    }
    iVar1 = iStack_38;
    iVar6 = *(int64_t *)(iStack_38 + 0x1a8);
    do {
        iVar3 = *(int64_t *)(iVar6 + 0x308);
        fcn.1404d3c50(iVar6, 800, 8);
        iVar6 = iVar3;
    } while (iVar3 != 0);
    if (*(int64_t *)(iVar1 + 0x100) != 0) {
        (**(code **)(*(int64_t *)(iVar1 + 0x100) + 0x18))(*(undefined8 *)(iStack_38 + 0x108));
    }
    if (iStack_38 != -1) {
        LOCK();
        piVar2 = (int64_t *)(iStack_38 + 8);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            uVar4 = *(undefined8 *)(iStack_38 + -8);
            uStack_40 = 0x140901d3e;
            uVar5 = (*(code *)0xe5f2d8)(iStack_38, 0x200);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001f000
// Address: 0x14001f000
// Size: 43 bytes
// ============================================================
void fcn.14001f000(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_10h;
    
    piVar1 = **(int64_t ***)(arg2 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        fcn.14045f950(*(undefined8 *)(arg2 + 0x20));
    }
    return;
}

// ============================================================
// Function: FUN_14001f080
// Address: 0x14001f080
// Size: 285 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001f080(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t *piVar3;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 in_R9;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(char *)(arg1 + 0x1e0) == '\0') {
        func_0x00014001cc40();
        iVar2 = *(int64_t *)(arg1 + 0x60);
        if (iVar2 != 0) {
            func_0x0001404403b0();
            fcn.1404d3c50(iVar2, 0x20, 8);
        }
        func_0x00014001d570(arg1 + 0x70);
        piVar3 = *(int64_t **)(arg1 + 0x90);
        if (*piVar3 != 0) {
            fcn.1404d3c50(piVar3[1], *piVar3, 1);
        }
        goto code_r0x0001404d3c50;
    }
    if (*(char *)(arg1 + 0x1e0) != '\x03') {
        return;
    }
    // switch table (6 cases) at 0x14097a0ec
    switch(*(undefined *)(arg1 + 0x19b)) {
    case 0:
        iVar2 = arg1 + 0x130;
        break;
    default:
        goto code_r0x00014001f162;
    case 5:
        if (*(int64_t *)(arg1 + 0x1a0) != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 0x1a8), *(int64_t *)(arg1 + 0x1a0), 1);
        }
        *(undefined *)(arg1 + 0x199) = 0;
    case 4:
        *(undefined *)(arg1 + 0x19a) = 0;
        if (*(char *)(arg1 + 0x198) == '\x01') {
            (**(code **)(*(int64_t *)(arg1 + 0x170) + 0x20))
                      (arg1 + 0x188, *(undefined8 *)(arg1 + 0x178), *(undefined8 *)(arg1 + 0x180));
        }
    case 3:
        *(undefined *)(arg1 + 0x198) = 0;
        iVar2 = arg1 + 0x150;
    }
    func_0x00014001d570(iVar2);
code_r0x00014001f162:
    piVar3 = *(int64_t **)(arg1 + 0x128);
    if (*piVar3 != 0) {
        fcn.1404d3c50(piVar3[1], *piVar3, 1);
    }
code_r0x0001404d3c50:
    uVar1 = (*(code *)0xe5f2d8)(piVar3, 0x58, 8, in_R9, 0xfffffffffffffffe, unaff_RSI, unaff_RBP);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar1, 0, piVar3);
    return;
}

// ============================================================
// Function: FUN_14001f1a0
// Address: 0x14001f1a0
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001f1a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    *(undefined *)(iVar1 + 0x198) = 0;
    fcn.14001d570(iVar1 + 0x150);
    return;
}

// ============================================================
// Function: FUN_14001f1d0
// Address: 0x14001f1d0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001f1d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001cf90(*(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x128));
    return;
}

// ============================================================
// Function: FUN_14001f200
// Address: 0x14001f200
// Size: 128 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001f200(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    var_10h = -2;
    piVar1 = *(int64_t **)arg1;
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    var_18h = arg1;
    if (*piVar1 == 0) {
        var_40h = 0x14001f228;
        fcn.14045ec00(arg1);
    }
    piVar1 = *(int64_t **)(var_18h + 8);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
        var_40h = 0x14001f242;
        func_0x0001406cdea0(var_18h + 8);
    }
    piVar1 = *(int64_t **)(var_18h + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        var_40h = 0x14001f25d;
        func_0x000140740680(var_18h + 0x20);
    }
    piVar1 = *(int64_t **)(var_18h + 0x28);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 != 0) {
        return;
    }
    var_20h = -2;
    var_28h = *(int64_t *)(var_18h + 0x28);
    iVar2 = *(int64_t *)(var_28h + 0x18);
    if (iVar2 == 0) {
        var_48h = 0;
    } else {
        var_70h = *(int64_t *)(var_28h + 0x20);
        var_48h = *(int64_t *)(var_28h + 0x28);
        var_80h = 0;
        var_60h = 0;
        var_78h = iVar2;
        var_58h = iVar2;
        var_50h = var_70h;
    }
    var_88h = (int64_t)(iVar2 != 0);
    var_68h = var_88h;
    func_0x000140743900(&var_40h, &var_88h);
    if (var_40h != 0) {
        do {
            func_0x000140743cd0(var_40h, var_30h);
            func_0x000140743900(&var_40h, &var_88h);
        } while (var_40h != 0);
    }
    iVar2 = var_28h;
    if (var_28h != -1) {
        LOCK();
        piVar1 = (int64_t *)(var_28h + 8);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            var_40h = 0x140901d3e;
            uVar3 = (*(code *)0xe5f2d8)(var_28h, 0x30);
    // WARNING: Treating indirect jump as call
            (*(code *)0xe5f2ea)(uVar3, 0, iVar2);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001f280
// Address: 0x14001f280
// Size: 46 bytes
// ============================================================
void fcn.14001f280(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 8);
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
        fcn.1406cdea0(iVar1 + 8);
    }
    return;
}

// ============================================================
// Function: FUN_14001f2b0
// Address: 0x14001f2b0
// Size: 47 bytes
// ============================================================
void fcn.14001f2b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x20);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.140740680(iVar1 + 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_14001f2e0
// Address: 0x14001f2e0
// Size: 47 bytes
// ============================================================
void fcn.14001f2e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x28);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.140740510(iVar1 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_14001f310
// Address: 0x14001f310
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14001f310(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14001f31b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000026d8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000026c0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001f348;
    fcn.14011d740();
    *(undefined8 *)(&stack0x00001378 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000026c0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00001380 + iVar1) = 0;
    *(undefined8 *)(&stack0x00001388 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00001370 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001f380;
    fcn.14011d740(*(int64_t *)(&stack0x000026c0 + iVar1), &stack0x00001370 + iVar1);
    return;
}

// ============================================================
// Function: FUN_14001f3a0
// Address: 0x14001f3a0
// Size: 23 bytes
// ============================================================
void fcn.14001f3a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001f3c0
// Address: 0x14001f3c0
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14001f3c0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26e8));
    *(undefined8 *)(arg2 + 0x26d0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14001f38a;
}

// ============================================================
// Function: FUN_14001f400
// Address: 0x14001f400
// Size: 23 bytes
// ============================================================
void fcn.14001f400(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001f420
// Address: 0x14001f420
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14001f420(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26d0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14001f38a;
}

// ============================================================
// Function: FUN_14001f460
// Address: 0x14001f460
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14001f460(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14001f46b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000026d8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000026c0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001f498;
    fcn.14011da20();
    *(undefined8 *)(&stack0x00001378 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000026c0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00001380 + iVar1) = 0;
    *(undefined8 *)(&stack0x00001388 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00001370 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x14001f4d0;
    fcn.14011da20(*(int64_t *)(&stack0x000026c0 + iVar1), &stack0x00001370 + iVar1);
    return;
}

// ============================================================
// Function: FUN_14001f4f0
// Address: 0x14001f4f0
// Size: 23 bytes
// ============================================================
void fcn.14001f4f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001f510
// Address: 0x14001f510
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14001f510(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26e8));
    *(undefined8 *)(arg2 + 0x26d0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14001f4da;
}

// ============================================================
// Function: FUN_14001f550
// Address: 0x14001f550
// Size: 23 bytes
// ============================================================
void fcn.14001f550(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14001f570
// Address: 0x14001f570
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14001f570(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26d0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14001f4da;
}

// ============================================================
// Function: FUN_14001f5b0
// Address: 0x14001f5b0
// Size: 285 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

void fcn.14001f5b0(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_f10h;
    int64_t var_eb8h;
    int64_t var_7b0h;
    int64_t var_7a8h;
    int64_t var_7a0h;
    int64_t var_798h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    undefined var_22h;
    undefined var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_f10h._0_4_ = 2;
    var_21h = 1;
    var_38h = arg1;
    var_48h = fcn.140796790(*(undefined8 *)(arg1 + 8));
    var_30h = var_38h + 0x10;
    fcn.14007b410();
    piVar2 = &var_f10h;
    fcn.140951cf0(var_30h, piVar2, 0x760);
    var_21h = 0;
    fcn.140796f10(&var_48h);
    iVar1 = var_38h;
    var_7a8h = *(int64_t *)(var_38h + 8);
    var_7a0h = 0;
    var_7b0h._0_4_ = 1;
    var_22h = 1;
    var_798h = (int64_t)piVar2;
    var_50h = fcn.140796790();
    var_38h = iVar1 + 0x10;
    fcn.14007b410(var_38h);
    fcn.140951cf0(var_38h, &var_7b0h, 0x760);
    var_22h = 0;
    fcn.140796f10(&var_50h);
    return;
}

// ============================================================
// Function: FUN_14001f6d0
// Address: 0x14001f6d0
// Size: 69 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_708h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e96h because it doesn't fit into ProtoModel

void fcn.14001f6d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140951cf0(*(undefined8 *)(arg2 + 0xf00), arg2 + 0x788, 0x760);
    fcn.140796f10(arg2 + 0xee8);
    *(undefined *)(arg2 + 0xf16) = 0;
    return;
}

// ============================================================
// Function: FUN_14001f720
// Address: 0x14001f720
// Size: 66 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e97h because it doesn't fit into ProtoModel

void fcn.14001f720(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140951cf0(*(undefined8 *)(arg2 + 0xf08), arg2 + 0x28, 0x760);
    fcn.140796f10(arg2 + 0xef0);
    *(undefined *)(arg2 + 0xf17) = 0;
    return;
}

// ============================================================
// Function: FUN_14001f770
// Address: 0x14001f770
// Size: 54 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e96h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_708h because it doesn't fit into ProtoModel

void fcn.14001f770(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    if (*(char *)(arg2 + 0xf16) == '\0') {
        return;
    }
    fcn.14007b410(arg2 + 0x788);
    return;
}

// ============================================================
// Function: FUN_14001f7b0
// Address: 0x14001f7b0
// Size: 44 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e97h because it doesn't fit into ProtoModel

void fcn.14001f7b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(char *)(arg2 + 0xf17) != '\0') {
        fcn.14007b410(arg2 + 0x28);
    }
    return;
}

