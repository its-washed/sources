// Chunk 36 - 50 functions

// ============================================================
// Function: FUN_14002a380
// Address: 0x14002a380
// Size: 58 bytes
// ============================================================
undefined8 fcn.14002a380(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1430));
    *(undefined8 *)(arg2 + 0x1410) = uVar1;
    *(int64_t *)(arg2 + 0x1418) = iVar2;
    return 0x14002a31a;
}

// ============================================================
// Function: FUN_14002a3c0
// Address: 0x14002a3c0
// Size: 24 bytes
// ============================================================
void fcn.14002a3c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002a3e0
// Address: 0x14002a3e0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel

undefined8 fcn.14002a3e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1410) = uVar1;
    *(int64_t *)(arg2 + 0x1418) = iVar2;
    return 0x14002a31a;
}

// ============================================================
// Function: FUN_14002a420
// Address: 0x14002a420
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel

void fcn.14002a420(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1418) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1410), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1418) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002a470
// Address: 0x14002a470
// Size: 24 bytes
// ============================================================
void fcn.14002a470(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002a490
// Address: 0x14002a490
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e57h because it doesn't fit into ProtoModel

void fcn.14002a490(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002a49c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00002e58 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00002e38 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a4be;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00002e57)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a4e4;
        func_0x00014011d2f0(*(int64_t *)(&stack0x00002e38 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00002e57)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a504;
        func_0x000140796b10(*(int64_t *)(&stack0x00002e38 + iVar4) + 0x2e50, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00002e38 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a513;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a51f;
        func_0x000140013ba0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002a590
// Address: 0x14002a590
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2dd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2dd8h because it doesn't fit into ProtoModel

undefined8 fcn.14002a590(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2e70));
    *(undefined8 *)(arg2 + 0x2e50) = uVar1;
    *(int64_t *)(arg2 + 0x2e58) = iVar2;
    return 0x14002a52a;
}

// ============================================================
// Function: FUN_14002a5d0
// Address: 0x14002a5d0
// Size: 24 bytes
// ============================================================
void fcn.14002a5d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002a5f0
// Address: 0x14002a5f0
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2dd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2dd8h because it doesn't fit into ProtoModel

undefined8 fcn.14002a5f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2e50) = uVar1;
    *(int64_t *)(arg2 + 0x2e58) = iVar2;
    return 0x14002a52a;
}

// ============================================================
// Function: FUN_14002a630
// Address: 0x14002a630
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2dd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2dd0h because it doesn't fit into ProtoModel

void fcn.14002a630(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x2e58) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x2e50), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x2e58) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002a680
// Address: 0x14002a680
// Size: 24 bytes
// ============================================================
void fcn.14002a680(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002a6a0
// Address: 0x14002a6a0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2197h because it doesn't fit into ProtoModel

void fcn.14002a6a0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002a6ac;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00002198 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00002178 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a6ce;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00002197)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a6f4;
        func_0x00014011d180(*(int64_t *)(&stack0x00002178 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00002197)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a714;
        func_0x000140796b10(*(int64_t *)(&stack0x00002178 + iVar4) + 0x2190, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00002178 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a723;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a72f;
        func_0x000140013db0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002a7a0
// Address: 0x14002a7a0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2130h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2118h because it doesn't fit into ProtoModel

undefined8 fcn.14002a7a0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x21b0));
    *(undefined8 *)(arg2 + 0x2190) = uVar1;
    *(int64_t *)(arg2 + 0x2198) = iVar2;
    return 0x14002a73a;
}

// ============================================================
// Function: FUN_14002a7e0
// Address: 0x14002a7e0
// Size: 24 bytes
// ============================================================
void fcn.14002a7e0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002a800
// Address: 0x14002a800
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2118h because it doesn't fit into ProtoModel

undefined8 fcn.14002a800(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2190) = uVar1;
    *(int64_t *)(arg2 + 0x2198) = iVar2;
    return 0x14002a73a;
}

// ============================================================
// Function: FUN_14002a840
// Address: 0x14002a840
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2118h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel

void fcn.14002a840(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x2198) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x2190), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x2198) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002a890
// Address: 0x14002a890
// Size: 24 bytes
// ============================================================
void fcn.14002a890(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002a8b0
// Address: 0x14002a8b0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1027h because it doesn't fit into ProtoModel

void fcn.14002a8b0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002a8bc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001028 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001008 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a8de;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001027)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a904;
        func_0x000140120590(*(int64_t *)(&stack0x00001008 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001027)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a924;
        func_0x000140796b10(*(int64_t *)(&stack0x00001008 + iVar4) + 0x1020, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001008 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a933;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002a93f;
        func_0x00014001bc20(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002a9b0
// Address: 0x14002a9b0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa8h because it doesn't fit into ProtoModel

undefined8 fcn.14002a9b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1040));
    *(undefined8 *)(arg2 + 0x1020) = uVar1;
    *(int64_t *)(arg2 + 0x1028) = iVar2;
    return 0x14002a94a;
}

// ============================================================
// Function: FUN_14002a9f0
// Address: 0x14002a9f0
// Size: 24 bytes
// ============================================================
void fcn.14002a9f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002aa10
// Address: 0x14002aa10
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa8h because it doesn't fit into ProtoModel

undefined8 fcn.14002aa10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1020) = uVar1;
    *(int64_t *)(arg2 + 0x1028) = iVar2;
    return 0x14002a94a;
}

// ============================================================
// Function: FUN_14002aa50
// Address: 0x14002aa50
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa0h because it doesn't fit into ProtoModel

void fcn.14002aa50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1028) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1020), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1028) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002aaa0
// Address: 0x14002aaa0
// Size: 24 bytes
// ============================================================
void fcn.14002aaa0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002aac0
// Address: 0x14002aac0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2948h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2947h because it doesn't fit into ProtoModel

void fcn.14002aac0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002aacc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00002948 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00002928 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002aaee;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00002947)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ab14;
        func_0x00014011de70(*(int64_t *)(&stack0x00002928 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00002947)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ab34;
        func_0x000140796b10(*(int64_t *)(&stack0x00002928 + iVar4) + 0x2940, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00002928 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ab43;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ab4f;
        func_0x000140013990(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002abc0
// Address: 0x14002abc0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_28e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28c8h because it doesn't fit into ProtoModel

undefined8 fcn.14002abc0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2960));
    *(undefined8 *)(arg2 + 0x2940) = uVar1;
    *(int64_t *)(arg2 + 0x2948) = iVar2;
    return 0x14002ab5a;
}

// ============================================================
// Function: FUN_14002ac00
// Address: 0x14002ac00
// Size: 24 bytes
// ============================================================
void fcn.14002ac00(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002ac20
// Address: 0x14002ac20
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_28c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28c8h because it doesn't fit into ProtoModel

undefined8 fcn.14002ac20(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2940) = uVar1;
    *(int64_t *)(arg2 + 0x2948) = iVar2;
    return 0x14002ab5a;
}

// ============================================================
// Function: FUN_14002ac60
// Address: 0x14002ac60
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_28c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28c0h because it doesn't fit into ProtoModel

void fcn.14002ac60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x2948) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x2940), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x2948) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002acb0
// Address: 0x14002acb0
// Size: 24 bytes
// ============================================================
void fcn.14002acb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002acd0
// Address: 0x14002acd0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002acd0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_740h;
    int64_t var_6e8h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_740h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011d8b0(var_40h + 0x20, &var_740h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0x730, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014000bfa0(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002adc0
// Address: 0x14002adc0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_6d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6b8h because it doesn't fit into ProtoModel

undefined8 fcn.14002adc0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x750));
    *(undefined8 *)(arg2 + 0x730) = uVar1;
    *(int64_t *)(arg2 + 0x738) = iVar2;
    return 0x14002ad64;
}

// ============================================================
// Function: FUN_14002ae00
// Address: 0x14002ae00
// Size: 24 bytes
// ============================================================
void fcn.14002ae00(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002ae20
// Address: 0x14002ae20
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_6b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6b8h because it doesn't fit into ProtoModel

undefined8 fcn.14002ae20(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x730) = uVar1;
    *(int64_t *)(arg2 + 0x738) = iVar2;
    return 0x14002ad64;
}

// ============================================================
// Function: FUN_14002ae60
// Address: 0x14002ae60
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_6b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6b0h because it doesn't fit into ProtoModel

void fcn.14002ae60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x738) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x730), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x738) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002aeb0
// Address: 0x14002aeb0
// Size: 24 bytes
// ============================================================
void fcn.14002aeb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002aed0
// Address: 0x14002aed0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1417h because it doesn't fit into ProtoModel

void fcn.14002aed0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002aedc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001418 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x000013f8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002aefe;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001417)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002af24;
        func_0x00014011ef20(*(int64_t *)(&stack0x000013f8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001417)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002af44;
        func_0x000140796b10(*(int64_t *)(&stack0x000013f8 + iVar4) + 0x1410, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x000013f8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002af53;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002af5f;
        func_0x0001400196d0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002afd0
// Address: 0x14002afd0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel

undefined8 fcn.14002afd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1430));
    *(undefined8 *)(arg2 + 0x1410) = uVar1;
    *(int64_t *)(arg2 + 0x1418) = iVar2;
    return 0x14002af6a;
}

// ============================================================
// Function: FUN_14002b010
// Address: 0x14002b010
// Size: 24 bytes
// ============================================================
void fcn.14002b010(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002b030
// Address: 0x14002b030
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel

undefined8 fcn.14002b030(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1410) = uVar1;
    *(int64_t *)(arg2 + 0x1418) = iVar2;
    return 0x14002af6a;
}

// ============================================================
// Function: FUN_14002b070
// Address: 0x14002b070
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel

void fcn.14002b070(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1418) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1410), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1418) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002b0c0
// Address: 0x14002b0c0
// Size: 24 bytes
// ============================================================
void fcn.14002b0c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002b0e0
// Address: 0x14002b0e0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_18f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f7h because it doesn't fit into ProtoModel

void fcn.14002b0e0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002b0ec;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x000018f8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x000018d8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002b10e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x000018f7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002b134;
        func_0x00014011ead0(*(int64_t *)(&stack0x000018d8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x000018f7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002b154;
        func_0x000140796b10(*(int64_t *)(&stack0x000018d8 + iVar4) + 0x18f0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x000018d8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002b163;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002b16f;
        func_0x000140016130(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002b1e0
// Address: 0x14002b1e0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1890h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1870h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1878h because it doesn't fit into ProtoModel

undefined8 fcn.14002b1e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1910));
    *(undefined8 *)(arg2 + 0x18f0) = uVar1;
    *(int64_t *)(arg2 + 0x18f8) = iVar2;
    return 0x14002b17a;
}

// ============================================================
// Function: FUN_14002b220
// Address: 0x14002b220
// Size: 24 bytes
// ============================================================
void fcn.14002b220(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002b240
// Address: 0x14002b240
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1870h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1878h because it doesn't fit into ProtoModel

undefined8 fcn.14002b240(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x18f0) = uVar1;
    *(int64_t *)(arg2 + 0x18f8) = iVar2;
    return 0x14002b17a;
}

// ============================================================
// Function: FUN_14002b280
// Address: 0x14002b280
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1878h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1870h because it doesn't fit into ProtoModel

void fcn.14002b280(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x18f8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x18f0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x18f8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002b2d0
// Address: 0x14002b2d0
// Size: 24 bytes
// ============================================================
void fcn.14002b2d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002b2f0
// Address: 0x14002b2f0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002b2f0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_fa0h;
    int64_t var_f48h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_fa0h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011ffd0(var_40h + 0x20, &var_fa0h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xf90, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x000140017c00(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002b3e0
// Address: 0x14002b3e0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f18h because it doesn't fit into ProtoModel

undefined8 fcn.14002b3e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xfb0));
    *(undefined8 *)(arg2 + 0xf90) = uVar1;
    *(int64_t *)(arg2 + 0xf98) = iVar2;
    return 0x14002b384;
}

// ============================================================
// Function: FUN_14002b420
// Address: 0x14002b420
// Size: 24 bytes
// ============================================================
void fcn.14002b420(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

