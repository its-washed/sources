// Chunk 21 - 50 functions

// ============================================================
// Function: FUN_140018dc0
// Address: 0x140018dc0
// Size: 37 bytes
// ============================================================
void fcn.140018dc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1c80);
    return;
}

// ============================================================
// Function: FUN_140018df0
// Address: 0x140018df0
// Size: 58 bytes
// ============================================================
void fcn.140018df0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1ca0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1ca0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140018e30
// Address: 0x140018e30
// Size: 41 bytes
// ============================================================
void fcn.140018e30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1d00, 0x80);
    return;
}

// ============================================================
// Function: FUN_140018e60
// Address: 0x140018e60
// Size: 34 bytes
// ============================================================
void fcn.140018e60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400121f0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140018e90
// Address: 0x140018e90
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140018e90(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000ed50(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1420) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1420) + 0x18))(*(undefined8 *)(arg1 + 0x1428));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1430);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1430);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1480);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140018f90
// Address: 0x140018f90
// Size: 51 bytes
// ============================================================
void fcn.140018f90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140018fd0
// Address: 0x140018fd0
// Size: 37 bytes
// ============================================================
void fcn.140018fd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1410);
    return;
}

// ============================================================
// Function: FUN_140019000
// Address: 0x140019000
// Size: 58 bytes
// ============================================================
void fcn.140019000(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1430);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1430);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140019040
// Address: 0x140019040
// Size: 41 bytes
// ============================================================
void fcn.140019040(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1480, 0x80);
    return;
}

// ============================================================
// Function: FUN_140019070
// Address: 0x140019070
// Size: 34 bytes
// ============================================================
void fcn.140019070(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012970(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_1400190a0
// Address: 0x1400190a0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1400190a0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000e630(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1390) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1390) + 0x18))(*(undefined8 *)(arg1 + 0x1398));
    }
    piVar1 = *(int64_t **)(arg1 + 0x13a0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x13a0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1400);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_1400191a0
// Address: 0x1400191a0
// Size: 51 bytes
// ============================================================
void fcn.1400191a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400191e0
// Address: 0x1400191e0
// Size: 37 bytes
// ============================================================
void fcn.1400191e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1380);
    return;
}

// ============================================================
// Function: FUN_140019210
// Address: 0x140019210
// Size: 58 bytes
// ============================================================
void fcn.140019210(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x13a0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x13a0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140019250
// Address: 0x140019250
// Size: 41 bytes
// ============================================================
void fcn.140019250(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1400, 0x80);
    return;
}

// ============================================================
// Function: FUN_140019280
// Address: 0x140019280
// Size: 34 bytes
// ============================================================
void fcn.140019280(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012430(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_1400192b0
// Address: 0x1400192b0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1400192b0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000eaf0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1390) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1390) + 0x18))(*(undefined8 *)(arg1 + 0x1398));
    }
    piVar1 = *(int64_t **)(arg1 + 0x13a0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x13a0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1400);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_1400193b0
// Address: 0x1400193b0
// Size: 51 bytes
// ============================================================
void fcn.1400193b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400193f0
// Address: 0x1400193f0
// Size: 37 bytes
// ============================================================
void fcn.1400193f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1380);
    return;
}

// ============================================================
// Function: FUN_140019420
// Address: 0x140019420
// Size: 58 bytes
// ============================================================
void fcn.140019420(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x13a0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x13a0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140019460
// Address: 0x140019460
// Size: 41 bytes
// ============================================================
void fcn.140019460(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1400, 0x80);
    return;
}

// ============================================================
// Function: FUN_140019490
// Address: 0x140019490
// Size: 34 bytes
// ============================================================
void fcn.140019490(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400127f0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_1400194c0
// Address: 0x1400194c0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1400194c0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000fb90(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1cf0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1cf0) + 0x18))(*(undefined8 *)(arg1 + 0x1cf8));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1d00);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1d00);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1d80);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_1400195c0
// Address: 0x1400195c0
// Size: 51 bytes
// ============================================================
void fcn.1400195c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140019600
// Address: 0x140019600
// Size: 37 bytes
// ============================================================
void fcn.140019600(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1ce0);
    return;
}

// ============================================================
// Function: FUN_140019630
// Address: 0x140019630
// Size: 58 bytes
// ============================================================
void fcn.140019630(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1d00);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1d00);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140019670
// Address: 0x140019670
// Size: 41 bytes
// ============================================================
void fcn.140019670(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1d80, 0x80);
    return;
}

// ============================================================
// Function: FUN_1400196a0
// Address: 0x1400196a0
// Size: 34 bytes
// ============================================================
void fcn.1400196a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012bb0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_1400196d0
// Address: 0x1400196d0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1400196d0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000f6d0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1420) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1420) + 0x18))(*(undefined8 *)(arg1 + 0x1428));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1430);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1430);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1480);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_1400197d0
// Address: 0x1400197d0
// Size: 51 bytes
// ============================================================
void fcn.1400197d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140019810
// Address: 0x140019810
// Size: 37 bytes
// ============================================================
void fcn.140019810(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1410);
    return;
}

// ============================================================
// Function: FUN_140019840
// Address: 0x140019840
// Size: 58 bytes
// ============================================================
void fcn.140019840(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1430);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1430);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140019880
// Address: 0x140019880
// Size: 41 bytes
// ============================================================
void fcn.140019880(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1480, 0x80);
    return;
}

// ============================================================
// Function: FUN_1400198b0
// Address: 0x1400198b0
// Size: 34 bytes
// ============================================================
void fcn.1400198b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400128b0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_1400198e0
// Address: 0x1400198e0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1400198e0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000f470(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x13f0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x13f0) + 0x18))(*(undefined8 *)(arg1 + 0x13f8));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1400);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1400);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1480);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_1400199e0
// Address: 0x1400199e0
// Size: 51 bytes
// ============================================================
void fcn.1400199e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140019a20
// Address: 0x140019a20
// Size: 37 bytes
// ============================================================
void fcn.140019a20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x13e0);
    return;
}

// ============================================================
// Function: FUN_140019a50
// Address: 0x140019a50
// Size: 58 bytes
// ============================================================
void fcn.140019a50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1400);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1400);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140019a90
// Address: 0x140019a90
// Size: 41 bytes
// ============================================================
void fcn.140019a90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1480, 0x80);
    return;
}

// ============================================================
// Function: FUN_140019ac0
// Address: 0x140019ac0
// Size: 34 bytes
// ============================================================
void fcn.140019ac0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012730(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140019af0
// Address: 0x140019af0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140019af0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000e890(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x13f0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x13f0) + 0x18))(*(undefined8 *)(arg1 + 0x13f8));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1400);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1400);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1480);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140019bf0
// Address: 0x140019bf0
// Size: 51 bytes
// ============================================================
void fcn.140019bf0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140019c30
// Address: 0x140019c30
// Size: 37 bytes
// ============================================================
void fcn.140019c30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x13e0);
    return;
}

// ============================================================
// Function: FUN_140019c60
// Address: 0x140019c60
// Size: 58 bytes
// ============================================================
void fcn.140019c60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1400);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1400);
        }
    }
    return;
}

// ============================================================
// Function: FUN_140019ca0
// Address: 0x140019ca0
// Size: 41 bytes
// ============================================================
void fcn.140019ca0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1480, 0x80);
    return;
}

// ============================================================
// Function: FUN_140019cd0
// Address: 0x140019cd0
// Size: 34 bytes
// ============================================================
void fcn.140019cd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140012a30(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_140019d00
// Address: 0x140019d00
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.140019d00(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014000efb0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x1900) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x1900) + 0x18))(*(undefined8 *)(arg1 + 0x1908));
    }
    piVar1 = *(int64_t **)(arg1 + 0x1910);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x1910);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1980);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140019e00
// Address: 0x140019e00
// Size: 51 bytes
// ============================================================
void fcn.140019e00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140019e40
// Address: 0x140019e40
// Size: 37 bytes
// ============================================================
void fcn.140019e40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x18f0);
    return;
}

// ============================================================
// Function: FUN_140019e70
// Address: 0x140019e70
// Size: 58 bytes
// ============================================================
void fcn.140019e70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1910);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1910);
        }
    }
    return;
}

