// Chunk 37 - 50 functions

// ============================================================
// Function: FUN_14002b440
// Address: 0x14002b440
// Size: 53 bytes
// ============================================================
undefined8 fcn.14002b440(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xf90) = uVar1;
    *(int64_t *)(arg2 + 0xf98) = iVar2;
    return 0x14002b384;
}

// ============================================================
// Function: FUN_14002b480
// Address: 0x14002b480
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f10h because it doesn't fit into ProtoModel

void fcn.14002b480(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xf98) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf90), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xf98) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002b4d0
// Address: 0x14002b4d0
// Size: 24 bytes
// ============================================================
void fcn.14002b4d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002b4f0
// Address: 0x14002b4f0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002b4f0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_c10h;
    int64_t var_bb8h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_c10h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011f4e0(var_40h + 0x20, &var_c10h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xc00, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014001c420(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002b5e0
// Address: 0x14002b5e0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ba0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b88h because it doesn't fit into ProtoModel

undefined8 fcn.14002b5e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xc20));
    *(undefined8 *)(arg2 + 0xc00) = uVar1;
    *(int64_t *)(arg2 + 0xc08) = iVar2;
    return 0x14002b584;
}

// ============================================================
// Function: FUN_14002b620
// Address: 0x14002b620
// Size: 24 bytes
// ============================================================
void fcn.14002b620(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002b640
// Address: 0x14002b640
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b88h because it doesn't fit into ProtoModel

undefined8 fcn.14002b640(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xc00) = uVar1;
    *(int64_t *)(arg2 + 0xc08) = iVar2;
    return 0x14002b584;
}

// ============================================================
// Function: FUN_14002b680
// Address: 0x14002b680
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_b88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b80h because it doesn't fit into ProtoModel

void fcn.14002b680(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xc08) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xc00), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xc08) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002b6d0
// Address: 0x14002b6d0
// Size: 24 bytes
// ============================================================
void fcn.14002b6d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002b6f0
// Address: 0x14002b6f0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_14a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a7h because it doesn't fit into ProtoModel

void fcn.14002b6f0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002b6fc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x000014a8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001488 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002b71e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x000014a7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002b744;
        func_0x00014011f200(*(int64_t *)(&stack0x00001488 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x000014a7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002b764;
        func_0x000140796b10(*(int64_t *)(&stack0x00001488 + iVar4) + 0x14a0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001488 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002b773;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002b77f;
        func_0x000140015f20(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002b7f0
// Address: 0x14002b7f0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1420h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1428h because it doesn't fit into ProtoModel

undefined8 fcn.14002b7f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x14c0));
    *(undefined8 *)(arg2 + 0x14a0) = uVar1;
    *(int64_t *)(arg2 + 0x14a8) = iVar2;
    return 0x14002b78a;
}

// ============================================================
// Function: FUN_14002b830
// Address: 0x14002b830
// Size: 24 bytes
// ============================================================
void fcn.14002b830(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002b850
// Address: 0x14002b850
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1420h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1428h because it doesn't fit into ProtoModel

undefined8 fcn.14002b850(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x14a0) = uVar1;
    *(int64_t *)(arg2 + 0x14a8) = iVar2;
    return 0x14002b78a;
}

// ============================================================
// Function: FUN_14002b890
// Address: 0x14002b890
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1420h because it doesn't fit into ProtoModel

void fcn.14002b890(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x14a8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x14a0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x14a8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002b8e0
// Address: 0x14002b8e0
// Size: 24 bytes
// ============================================================
void fcn.14002b8e0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002b900
// Address: 0x14002b900
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002b900(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_f70h;
    int64_t var_f18h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_f70h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011fe60(var_40h + 0x20, &var_f70h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xf60, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x0001400179f0(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002b9f0
// Address: 0x14002b9f0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.14002b9f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xf80));
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x14002b994;
}

// ============================================================
// Function: FUN_14002ba30
// Address: 0x14002ba30
// Size: 24 bytes
// ============================================================
void fcn.14002ba30(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002ba50
// Address: 0x14002ba50
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.14002ba50(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x14002b994;
}

// ============================================================
// Function: FUN_14002ba90
// Address: 0x14002ba90
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel

void fcn.14002ba90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xf68) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf60), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xf68) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002bae0
// Address: 0x14002bae0
// Size: 24 bytes
// ============================================================
void fcn.14002bae0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002bb00
// Address: 0x14002bb00
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1868h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1867h because it doesn't fit into ProtoModel

void fcn.14002bb00(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002bb0c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001868 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001848 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002bb2e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001867)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002bb54;
        func_0x000140120420(*(int64_t *)(&stack0x00001848 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001867)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002bb74;
        func_0x000140796b10(*(int64_t *)(&stack0x00001848 + iVar4) + 0x1860, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001848 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002bb83;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002bb8f;
        func_0x000140014800(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002bc00
// Address: 0x14002bc00
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1800h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e8h because it doesn't fit into ProtoModel

undefined8 fcn.14002bc00(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1880));
    *(undefined8 *)(arg2 + 0x1860) = uVar1;
    *(int64_t *)(arg2 + 0x1868) = iVar2;
    return 0x14002bb9a;
}

// ============================================================
// Function: FUN_14002bc40
// Address: 0x14002bc40
// Size: 24 bytes
// ============================================================
void fcn.14002bc40(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002bc60
// Address: 0x14002bc60
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e8h because it doesn't fit into ProtoModel

undefined8 fcn.14002bc60(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1860) = uVar1;
    *(int64_t *)(arg2 + 0x1868) = iVar2;
    return 0x14002bb9a;
}

// ============================================================
// Function: FUN_14002bca0
// Address: 0x14002bca0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_17e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel

void fcn.14002bca0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1868) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1860), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1868) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002bcf0
// Address: 0x14002bcf0
// Size: 24 bytes
// ============================================================
void fcn.14002bcf0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002bd10
// Address: 0x14002bd10
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002bd10(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_b50h;
    int64_t var_af8h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_b50h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011e510(var_40h + 0x20, &var_b50h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xb40, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014001c210(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002be00
// Address: 0x14002be00
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ae0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ac0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ac8h because it doesn't fit into ProtoModel

undefined8 fcn.14002be00(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xb60));
    *(undefined8 *)(arg2 + 0xb40) = uVar1;
    *(int64_t *)(arg2 + 0xb48) = iVar2;
    return 0x14002bda4;
}

// ============================================================
// Function: FUN_14002be40
// Address: 0x14002be40
// Size: 24 bytes
// ============================================================
void fcn.14002be40(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002be60
// Address: 0x14002be60
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ac0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ac8h because it doesn't fit into ProtoModel

undefined8 fcn.14002be60(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xb40) = uVar1;
    *(int64_t *)(arg2 + 0xb48) = iVar2;
    return 0x14002bda4;
}

// ============================================================
// Function: FUN_14002bea0
// Address: 0x14002bea0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ac8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ac0h because it doesn't fit into ProtoModel

void fcn.14002bea0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xb48) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xb40), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xb48) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002bef0
// Address: 0x14002bef0
// Size: 24 bytes
// ============================================================
void fcn.14002bef0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002bf10
// Address: 0x14002bf10
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002bf10(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_f70h;
    int64_t var_f18h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_f70h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011f650(var_40h + 0x20, &var_f70h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xf60, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014001c630(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002c000
// Address: 0x14002c000
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.14002c000(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xf80));
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x14002bfa4;
}

// ============================================================
// Function: FUN_14002c040
// Address: 0x14002c040
// Size: 24 bytes
// ============================================================
void fcn.14002c040(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002c060
// Address: 0x14002c060
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.14002c060(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x14002bfa4;
}

// ============================================================
// Function: FUN_14002c0a0
// Address: 0x14002c0a0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel

void fcn.14002c0a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xf68) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf60), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xf68) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002c0f0
// Address: 0x14002c0f0
// Size: 24 bytes
// ============================================================
void fcn.14002c0f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002c110
// Address: 0x14002c110
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1027h because it doesn't fit into ProtoModel

void fcn.14002c110(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002c11c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001028 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001008 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002c13e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001027)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002c164;
        func_0x000140120590(*(int64_t *)(&stack0x00001008 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001027)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002c184;
        func_0x000140796b10(*(int64_t *)(&stack0x00001008 + iVar4) + 0x1020, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001008 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002c193;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002c19f;
        func_0x00014001c000(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002c210
// Address: 0x14002c210
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa8h because it doesn't fit into ProtoModel

undefined8 fcn.14002c210(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1040));
    *(undefined8 *)(arg2 + 0x1020) = uVar1;
    *(int64_t *)(arg2 + 0x1028) = iVar2;
    return 0x14002c1aa;
}

// ============================================================
// Function: FUN_14002c250
// Address: 0x14002c250
// Size: 24 bytes
// ============================================================
void fcn.14002c250(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002c270
// Address: 0x14002c270
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa8h because it doesn't fit into ProtoModel

undefined8 fcn.14002c270(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1020) = uVar1;
    *(int64_t *)(arg2 + 0x1028) = iVar2;
    return 0x14002c1aa;
}

// ============================================================
// Function: FUN_14002c2b0
// Address: 0x14002c2b0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa0h because it doesn't fit into ProtoModel

void fcn.14002c2b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1028) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1020), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1028) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002c300
// Address: 0x14002c300
// Size: 24 bytes
// ============================================================
void fcn.14002c300(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002c320
// Address: 0x14002c320
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002c320(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_f70h;
    int64_t var_f18h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_f70h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011d460(var_40h + 0x20, &var_f70h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xf60, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014001a750(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002c410
// Address: 0x14002c410
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.14002c410(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xf80));
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x14002c3b4;
}

// ============================================================
// Function: FUN_14002c450
// Address: 0x14002c450
// Size: 24 bytes
// ============================================================
void fcn.14002c450(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002c470
// Address: 0x14002c470
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.14002c470(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x14002c3b4;
}

// ============================================================
// Function: FUN_14002c4b0
// Address: 0x14002c4b0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel

void fcn.14002c4b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xf68) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf60), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xf68) + 0x10));
    }
    return;
}

