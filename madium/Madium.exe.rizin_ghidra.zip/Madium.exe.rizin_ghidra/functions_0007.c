// Chunk 7 - 50 functions

// ============================================================
// Function: FUN_140009260
// Address: 0x140009260
// Size: 475 bytes
// ============================================================
void fcn.140009260(int64_t arg1)
{
    char cVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *unaff_RBP;
    int64_t *piVar5;
    int64_t unaff_RSI;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 auStack_80 [6];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar5 = &var_28h;
    var_28h = -2;
    var_30h = arg1;
    if (*(char *)(arg1 + 0x708) == '\0') {
        auStack_80[0] = 0x1400092cd;
        func_0x00014001c990(arg1);
        var_48h = var_30h + 0x208;
        var_50h = *(int64_t *)(var_30h + 0x210);
        var_40h = *(int64_t *)(var_30h + 0x218);
        var_38h = 0;
        iVar3 = var_50h;
        arg1 = unaff_RSI;
        piVar5 = unaff_RBP;
        while (var_40h != var_38h) {
            var_38h = var_38h + 1;
            auStack_80[0] = 0x14000932e;
            func_0x0001402727a0(iVar3);
            iVar3 = iVar3 + 0x60;
        }
    } else {
        if (*(char *)(arg1 + 0x708) != '\x03') {
            return;
        }
        iVar3 = arg1;
        if (*(char *)(arg1 + 0x700) == '\x03') {
            iVar4 = arg1 + 0x560;
            cVar1 = *(char *)(arg1 + 0x6f8);
joined_r0x000140009341:
            if (cVar1 == '\0') {
                auStack_80[0] = 0x14000934c;
                var_38h = iVar4;
                func_0x00014001be30();
                iVar3 = var_30h;
                iVar4 = *(int64_t *)(var_38h + 0x180);
                if (iVar4 != 0) {
                    iVar3 = *(int64_t *)(var_38h + 0x188);
                    uVar7 = 1;
                    *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_80;
                    auStack_80[0] = 0x140009373;
                    goto code_r0x0001404d3c50;
                }
                if (*(int64_t *)(var_38h + 0x168) != 0) {
                    auStack_80[0] = 0x140009395;
                    func_0x0001404d3c50(*(undefined8 *)(var_38h + 0x170), *(int64_t *)(var_38h + 0x168), 1);
                }
            }
        } else if (*(char *)(arg1 + 0x700) == '\0') {
            iVar4 = arg1 + 0x3c0;
            cVar1 = *(char *)(arg1 + 0x558);
            goto joined_r0x000140009341;
        }
        auStack_80[0] = 0x14000939d;
        func_0x00014001c990(iVar3);
        var_48h = var_30h + 0x208;
        var_50h = *(int64_t *)(var_30h + 0x210);
        var_40h = *(int64_t *)(var_30h + 0x218);
        var_38h = 0;
        iVar3 = var_50h;
        while (arg1 = unaff_RSI, piVar5 = unaff_RBP, var_40h != var_38h) {
            var_38h = var_38h + 1;
            auStack_80[0] = 0x1400093fa;
            func_0x0001402727a0(iVar3);
            iVar3 = iVar3 + 0x60;
        }
    }
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    iVar3 = *(int64_t *)(var_30h + 0x210);
    iVar4 = *(int64_t *)var_48h * 0x60;
    uVar7 = 8;
code_r0x0001404d3c50:
    *(int64_t **)((int64_t)*(undefined **)0x20 + -8) = piVar5;
    *(int64_t *)((int64_t)*(undefined **)0x20 + -0x10) = arg1;
    iVar6 = iVar3;
    if (0x10 < uVar7) {
        iVar6 = *(int64_t *)(iVar3 + -8);
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x140901d3e;
    uVar2 = (*(code *)0xe5f2d8)(iVar3, iVar4);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, iVar6);
    return;
}

// ============================================================
// Function: FUN_140009440
// Address: 0x140009440
// Size: 129 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009440(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x40);
    if ((*(uint64_t *)(iVar1 + 0x180) & 0x7fffffffffffffff) != 0) {
        func_0x0001404d3c50(*(undefined8 *)(iVar1 + 0x188), *(uint64_t *)(iVar1 + 0x180), 1);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        func_0x0001404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    iVar1 = *(int64_t *)(arg2 + 0x48);
    func_0x00014001c990(iVar1);
    func_0x000140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400094d0
// Address: 0x1400094d0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400094d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140009500
// Address: 0x140009500
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140009500(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140009550
// Address: 0x140009550
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009550(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_1400095a0
// Address: 0x1400095a0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400095a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400095d0
// Address: 0x1400095d0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400095d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140009620
// Address: 0x140009620
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009620(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140009670
// Address: 0x140009670
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140009670(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x6c0) == '\0') {
        func_0x00014001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x00014000980f;
    }
    if (*(char *)(arg1 + 0x6c0) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x6b8) == '\0') {
        if (*(char *)(arg1 + 0x528) == '\0') {
            func_0x00014001be30(arg1 + 0x3a8);
            iVar4 = *(int64_t *)(arg1 + 0x510);
            iVar2 = 0x510;
            goto code_r0x000140009778;
        }
    } else if ((*(char *)(arg1 + 0x6b8) == '\x03') && (*(char *)(arg1 + 0x6b0) == '\0')) {
        func_0x00014001be30(arg1 + 0x530);
        iVar4 = *(int64_t *)(arg1 + 0x698);
        iVar2 = 0x698;
code_r0x000140009778:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    func_0x00014001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x00014000980f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140009850
// Address: 0x140009850
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009850(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x510);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x518), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_1400098a0
// Address: 0x1400098a0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400098a0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x698);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x6a0), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_1400098f0
// Address: 0x1400098f0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400098f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140009920
// Address: 0x140009920
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140009920(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140009970
// Address: 0x140009970
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009970(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_1400099c0
// Address: 0x1400099c0
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400099c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140009a00
// Address: 0x140009a00
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009a00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140009a30
// Address: 0x140009a30
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140009a30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140009a80
// Address: 0x140009a80
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009a80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140009ad0
// Address: 0x140009ad0
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140009ad0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x6c0) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x000140009c6f;
    }
    if (*(char *)(arg1 + 0x6c0) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x6b8) == '\0') {
        if (*(char *)(arg1 + 0x52d) == '\0') {
            func_0x00014001be30(arg1 + 0x3a8);
            iVar4 = *(int64_t *)(arg1 + 0x510);
            iVar2 = 0x510;
            goto code_r0x000140009bd8;
        }
    } else if ((*(char *)(arg1 + 0x6b8) == '\x03') && (*(char *)(arg1 + 0x6b5) == '\0')) {
        func_0x00014001be30(arg1 + 0x530);
        iVar4 = *(int64_t *)(arg1 + 0x698);
        iVar2 = 0x698;
code_r0x000140009bd8:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x000140009c6f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140009cb0
// Address: 0x140009cb0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009cb0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x510);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x518), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140009d00
// Address: 0x140009d00
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009d00(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x698);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x6a0), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140009d50
// Address: 0x140009d50
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009d50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140009d80
// Address: 0x140009d80
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140009d80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140009dd0
// Address: 0x140009dd0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009dd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140009e20
// Address: 0x140009e20
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009e20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140009e60
// Address: 0x140009e60
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009e60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140009e90
// Address: 0x140009e90
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140009e90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140009ee0
// Address: 0x140009ee0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009ee0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140009f30
// Address: 0x140009f30
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140009f30(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x6d8) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x00014000a0cf;
    }
    if (*(char *)(arg1 + 0x6d8) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x6d0) == '\0') {
        if (*(char *)(arg1 + 0x538) == '\0') {
            func_0x00014001be30(arg1 + 0x3b0);
            iVar4 = *(int64_t *)(arg1 + 0x518);
            iVar2 = 0x518;
            goto code_r0x00014000a038;
        }
    } else if ((*(char *)(arg1 + 0x6d0) == '\x03') && (*(char *)(arg1 + 0x6c8) == '\0')) {
        func_0x00014001be30(arg1 + 0x540);
        iVar4 = *(int64_t *)(arg1 + 0x6a8);
        iVar2 = 0x6a8;
code_r0x00014000a038:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x00014000a0cf:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_14000a110
// Address: 0x14000a110
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a110(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x518);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x520), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000a160
// Address: 0x14000a160
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a160(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x6a8);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x6b0), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000a1b0
// Address: 0x14000a1b0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a1b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000a1e0
// Address: 0x14000a1e0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000a1e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14000a230
// Address: 0x14000a230
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a230(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14000a280
// Address: 0x14000a280
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a280(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000a2c0
// Address: 0x14000a2c0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a2c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000a2f0
// Address: 0x14000a2f0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000a2f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14000a340
// Address: 0x14000a340
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a340(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14000a390
// Address: 0x14000a390
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.14000a390(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x6c0) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x00014000a52f;
    }
    if (*(char *)(arg1 + 0x6c0) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x6b8) == '\0') {
        if (*(char *)(arg1 + 0x529) == '\0') {
            func_0x00014001be30(arg1 + 0x3a8);
            iVar4 = *(int64_t *)(arg1 + 0x510);
            iVar2 = 0x510;
            goto code_r0x00014000a498;
        }
    } else if ((*(char *)(arg1 + 0x6b8) == '\x03') && (*(char *)(arg1 + 0x6b1) == '\0')) {
        func_0x00014001be30(arg1 + 0x530);
        iVar4 = *(int64_t *)(arg1 + 0x698);
        iVar2 = 0x698;
code_r0x00014000a498:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x00014000a52f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_14000a570
// Address: 0x14000a570
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a570(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x510);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x518), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000a5c0
// Address: 0x14000a5c0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a5c0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x698);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x6a0), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000a610
// Address: 0x14000a610
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a610(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000a640
// Address: 0x14000a640
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000a640(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14000a690
// Address: 0x14000a690
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a690(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14000a6e0
// Address: 0x14000a6e0
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a6e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000a720
// Address: 0x14000a720
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a720(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_14000a750
// Address: 0x14000a750
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14000a750(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14000a7a0
// Address: 0x14000a7a0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a7a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14000a7f0
// Address: 0x14000a7f0
// Size: 459 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.14000a7f0(int64_t arg1)
{
    char cVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x4b0) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_30h = 0;
        iVar5 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_30h) {
            var_30h = var_30h + 1;
            func_0x0001402727a0(iVar5);
            iVar5 = iVar5 + 0x60;
        }
        goto code_r0x00014000a97f;
    }
    if (*(char *)(arg1 + 0x4b0) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x4a8) == '\x03') {
        iVar4 = arg1 + 0x3d0;
        cVar1 = *(char *)(arg1 + 0x4a0);
joined_r0x00014000a8d1:
        if (cVar1 == '\0') {
            func_0x000140014d30();
            if (*(int64_t *)(iVar4 + 0x98) != 0) {
                fcn.1404d3c50(*(undefined8 *)(iVar4 + 0xa0), *(int64_t *)(iVar4 + 0x98), 1);
            }
            if (*(char *)(iVar4 + 0xb0) != '\x06') {
                func_0x00014001c840(iVar4 + 0xb0);
            }
        }
    } else if (*(char *)(arg1 + 0x4a8) == '\0') {
        iVar4 = arg1 + 0x2f8;
        cVar1 = *(char *)(arg1 + 0x3c8);
        goto joined_r0x00014000a8d1;
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_30h = 0;
    iVar5 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_30h) {
        var_30h = var_30h + 1;
        func_0x0001402727a0(iVar5);
        iVar5 = iVar5 + 0x60;
    }
code_r0x00014000a97f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar2 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar2, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000a9c0
// Address: 0x14000a9c0
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14000a9c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x48) + 0x98);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0xa0), iVar1, 1);
    }
    if (*(char *)(*(int64_t *)(arg2 + 0x48) + 0xb0) != '\x06') {
        func_0x00014001c840(*(int64_t *)(arg2 + 0x48) + 0xb0);
    }
    return;
}

