// Chunk 66 - 50 functions

// ============================================================
// Function: FUN_14004b310
// Address: 0x14004b310
// Size: 60 bytes
// ============================================================
undefined8 fcn.14004b310(undefined8 placeholder_0, int64_t arg2, int64_t arg_f8h, int64_t arg_108h, int64_t arg_128h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1a8));
    *(undefined8 *)(arg2 + 0x178) = uVar1;
    *(int64_t *)(arg2 + 0x188) = iVar2;
    return 0x14004b1bd;
}

// ============================================================
// Function: FUN_14004b350
// Address: 0x14004b350
// Size: 25 bytes
// ============================================================
void fcn.14004b350(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004b370
// Address: 0x14004b370
// Size: 55 bytes
// ============================================================
undefined8 fcn.14004b370(undefined8 placeholder_0, int64_t arg2, int64_t arg_f8h, int64_t arg_108h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x178) = uVar1;
    *(int64_t *)(arg2 + 0x188) = iVar2;
    return 0x14004b1bd;
}

// ============================================================
// Function: FUN_14004b3b0
// Address: 0x14004b3b0
// Size: 25 bytes
// ============================================================
void fcn.14004b3b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004b3d0
// Address: 0x14004b3d0
// Size: 60 bytes
// ============================================================
undefined8 fcn.14004b3d0(undefined8 placeholder_0, int64_t arg2, int64_t arg_108h, int64_t arg_110h, int64_t arg_120h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1a0));
    *(undefined8 *)(arg2 + 400) = uVar1;
    *(int64_t *)(arg2 + 0x188) = iVar2;
    return 0x14004b22e;
}

// ============================================================
// Function: FUN_14004b410
// Address: 0x14004b410
// Size: 25 bytes
// ============================================================
void fcn.14004b410(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004b430
// Address: 0x14004b430
// Size: 55 bytes
// ============================================================
undefined8 fcn.14004b430(undefined8 placeholder_0, int64_t arg2, int64_t arg_108h, int64_t arg_110h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 400) = uVar1;
    *(int64_t *)(arg2 + 0x188) = iVar2;
    return 0x14004b22e;
}

// ============================================================
// Function: FUN_14004b470
// Address: 0x14004b470
// Size: 67 bytes
// ============================================================
void fcn.14004b470(undefined8 placeholder_0, int64_t arg2, int64_t arg_108h, int64_t arg_110h)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x188) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 400), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x188) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004b4c0
// Address: 0x14004b4c0
// Size: 505 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_1fb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3088h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3078h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1840h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3090h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_beh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcc00f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1640h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1638h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_187h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1630h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5258h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5cb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ad8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ad0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ac8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_25b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1de0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2170h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2168h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800eeh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_17fh
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_58e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ad0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_27f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_788h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_eb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ec8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ec0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1688h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2638h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_54a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3790h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_28f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_42e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Removing arg arg_1ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7bfh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_39a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3980h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3988h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_294800ffh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7cfh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d7h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3990h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_718h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_728h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2800h because it doesn't fit into ProtoModel

void fcn.14004b4c0(int64_t var_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_70h, int64_t arg_78h, int64_t arg_128h, int64_t arg_130h, int64_t arg_138h,
                  int64_t arg_148h, int64_t arg_150h, int64_t arg_158h, int64_t arg_160h, int64_t arg_168h,
                  int64_t arg_170h, int64_t arg_178h, int64_t arg_190h, int64_t arg_198h, int64_t arg_1a8h,
                  int64_t arg_1b0h, int64_t arg_1b8h, int64_t arg_1c0h, int64_t arg_1c8h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_7e8h;
    int64_t var_790h;
    int64_t var_73ah;
    int64_t var_690h;
    int64_t var_368h;
    int64_t var_350h;
    int64_t var_1b0h;
    int64_t var_158h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    undefined8 uStack_20;
    int64_t var_8h;
    
    uStack_20 = 0x14004b4cd;
    iVar2 = func_0x00014094c690();
    *(undefined8 *)(&stack0x00001fb0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004b4eb;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014004b4fc. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (18 cases) at 0x14097ad44
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097ad44) + 0x14097ad44))();
    return;
}

// ============================================================
// Function: FUN_14004b6c0
// Address: 0x14004b6c0
// Size: 37 bytes
// ============================================================
void fcn.14004b6c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004b6f0
// Address: 0x14004b6f0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004b6f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xfe8) = 2;
    fcn.14011e680(*(undefined8 *)(arg2 + 0x1fc0), arg2 + 0xfe8);
    return;
}

// ============================================================
// Function: FUN_14004b730
// Address: 0x14004b730
// Size: 25 bytes
// ============================================================
void fcn.14004b730(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004b750
// Address: 0x14004b750
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.14004b750(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1fd8));
    *(undefined8 *)(arg2 + 0x1fa8) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x14004b5e7;
}

// ============================================================
// Function: FUN_14004b790
// Address: 0x14004b790
// Size: 25 bytes
// ============================================================
void fcn.14004b790(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004b7b0
// Address: 0x14004b7b0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.14004b7b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1fa8) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x14004b5e7;
}

// ============================================================
// Function: FUN_14004b7f0
// Address: 0x14004b7f0
// Size: 25 bytes
// ============================================================
void fcn.14004b7f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004b810
// Address: 0x14004b810
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.14004b810(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1fd0));
    *(undefined8 *)(arg2 + 0x1fc0) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x14004b667;
}

// ============================================================
// Function: FUN_14004b850
// Address: 0x14004b850
// Size: 25 bytes
// ============================================================
void fcn.14004b850(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004b870
// Address: 0x14004b870
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.14004b870(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1fc0) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x14004b667;
}

// ============================================================
// Function: FUN_14004b8b0
// Address: 0x14004b8b0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f40h because it doesn't fit into ProtoModel

void fcn.14004b8b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1fb8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1fc0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1fb8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004b900
// Address: 0x14004b900
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.14004b900(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004b90d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004b92b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004b93c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097ad64) + 0x14097ad64))();
    return;
}

// ============================================================
// Function: FUN_14004bb00
// Address: 0x14004bb00
// Size: 37 bytes
// ============================================================
void fcn.14004bb00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004bb30
// Address: 0x14004bb30
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004bb30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_14004bb70
// Address: 0x14004bb70
// Size: 25 bytes
// ============================================================
void fcn.14004bb70(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004bb90
// Address: 0x14004bb90
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004bb90(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004ba27;
}

// ============================================================
// Function: FUN_14004bbd0
// Address: 0x14004bbd0
// Size: 25 bytes
// ============================================================
void fcn.14004bbd0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004bbf0
// Address: 0x14004bbf0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004bbf0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004ba27;
}

// ============================================================
// Function: FUN_14004bc30
// Address: 0x14004bc30
// Size: 25 bytes
// ============================================================
void fcn.14004bc30(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004bc50
// Address: 0x14004bc50
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004bc50(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004baa7;
}

// ============================================================
// Function: FUN_14004bc90
// Address: 0x14004bc90
// Size: 25 bytes
// ============================================================
void fcn.14004bc90(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004bcb0
// Address: 0x14004bcb0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004bcb0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004baa7;
}

// ============================================================
// Function: FUN_14004bcf0
// Address: 0x14004bcf0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.14004bcf0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004bd40
// Address: 0x14004bd40
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.14004bd40(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004bd4d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004bd6b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004bd7c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097ad84) + 0x14097ad84))();
    return;
}

// ============================================================
// Function: FUN_14004bf40
// Address: 0x14004bf40
// Size: 37 bytes
// ============================================================
void fcn.14004bf40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004bf70
// Address: 0x14004bf70
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004bf70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011db90(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_14004bfb0
// Address: 0x14004bfb0
// Size: 25 bytes
// ============================================================
void fcn.14004bfb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004bfd0
// Address: 0x14004bfd0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004bfd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004be67;
}

// ============================================================
// Function: FUN_14004c010
// Address: 0x14004c010
// Size: 25 bytes
// ============================================================
void fcn.14004c010(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004c030
// Address: 0x14004c030
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004c030(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004be67;
}

// ============================================================
// Function: FUN_14004c070
// Address: 0x14004c070
// Size: 25 bytes
// ============================================================
void fcn.14004c070(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004c090
// Address: 0x14004c090
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004c090(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004bee7;
}

// ============================================================
// Function: FUN_14004c0d0
// Address: 0x14004c0d0
// Size: 25 bytes
// ============================================================
void fcn.14004c0d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004c0f0
// Address: 0x14004c0f0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004c0f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004bee7;
}

// ============================================================
// Function: FUN_14004c130
// Address: 0x14004c130
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.14004c130(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14004c180
// Address: 0x14004c180
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.14004c180(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14004c18d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14004c1ab;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014004c1bc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097ada4) + 0x14097ada4))();
    return;
}

// ============================================================
// Function: FUN_14004c380
// Address: 0x14004c380
// Size: 37 bytes
// ============================================================
void fcn.14004c380(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14004c3b0
// Address: 0x14004c3b0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14004c3b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011da20(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_14004c3f0
// Address: 0x14004c3f0
// Size: 25 bytes
// ============================================================
void fcn.14004c3f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14004c410
// Address: 0x14004c410
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14004c410(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14004c2a7;
}

// ============================================================
// Function: FUN_14004c450
// Address: 0x14004c450
// Size: 25 bytes
// ============================================================
void fcn.14004c450(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

