// Chunk 38 - 50 functions

// ============================================================
// Function: FUN_14002c500
// Address: 0x14002c500
// Size: 24 bytes
// ============================================================
void fcn.14002c500(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002c520
// Address: 0x14002c520
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b7h because it doesn't fit into ProtoModel

void fcn.14002c520(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002c52c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x000013b8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001398 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002c54e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x000013b7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002c574;
        func_0x00014011f090(*(int64_t *)(&stack0x00001398 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x000013b7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002c594;
        func_0x000140796b10(*(int64_t *)(&stack0x00001398 + iVar4) + 0x13b0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001398 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002c5a3;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002c5af;
        func_0x000140018650(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002c620
// Address: 0x14002c620
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.14002c620(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13d0));
    *(undefined8 *)(arg2 + 0x13b0) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x14002c5ba;
}

// ============================================================
// Function: FUN_14002c660
// Address: 0x14002c660
// Size: 24 bytes
// ============================================================
void fcn.14002c660(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002c680
// Address: 0x14002c680
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.14002c680(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x13b0) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x14002c5ba;
}

// ============================================================
// Function: FUN_14002c6c0
// Address: 0x14002c6c0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel

void fcn.14002c6c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x13b8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x13b0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x13b8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002c710
// Address: 0x14002c710
// Size: 24 bytes
// ============================================================
void fcn.14002c710(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002c730
// Address: 0x14002c730
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002c730(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_f70h;
    int64_t var_f18h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_f70h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011f650(var_40h + 0x20, &var_f70h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xf60, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014001ba10(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002c820
// Address: 0x14002c820
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.14002c820(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xf80));
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x14002c7c4;
}

// ============================================================
// Function: FUN_14002c860
// Address: 0x14002c860
// Size: 24 bytes
// ============================================================
void fcn.14002c860(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002c880
// Address: 0x14002c880
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel

undefined8 fcn.14002c880(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xf60) = uVar1;
    *(int64_t *)(arg2 + 0xf68) = iVar2;
    return 0x14002c7c4;
}

// ============================================================
// Function: FUN_14002c8c0
// Address: 0x14002c8c0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel

void fcn.14002c8c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xf68) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf60), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xf68) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002c910
// Address: 0x14002c910
// Size: 24 bytes
// ============================================================
void fcn.14002c910(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002c930
// Address: 0x14002c930
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002c930(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_a00h;
    int64_t var_9a8h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_a00h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011e3a0(var_40h + 0x20, &var_a00h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0x9f0, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x0001400143e0(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002ca20
// Address: 0x14002ca20
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_990h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel

undefined8 fcn.14002ca20(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xa10));
    *(undefined8 *)(arg2 + 0x9f0) = uVar1;
    *(int64_t *)(arg2 + 0x9f8) = iVar2;
    return 0x14002c9c4;
}

// ============================================================
// Function: FUN_14002ca60
// Address: 0x14002ca60
// Size: 24 bytes
// ============================================================
void fcn.14002ca60(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002ca80
// Address: 0x14002ca80
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel

undefined8 fcn.14002ca80(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x9f0) = uVar1;
    *(int64_t *)(arg2 + 0x9f8) = iVar2;
    return 0x14002c9c4;
}

// ============================================================
// Function: FUN_14002cac0
// Address: 0x14002cac0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel

void fcn.14002cac0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x9f8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x9f0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x9f8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002cb10
// Address: 0x14002cb10
// Size: 24 bytes
// ============================================================
void fcn.14002cb10(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002cb30
// Address: 0x14002cb30
// Size: 323 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ah

void fcn.14002cb30(int64_t arg1)
{
    uint8_t uVar1;
    char cVar2;
    uint64_t in_RDX;
    int64_t var_7b0h;
    int64_t var_758h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    undefined var_2ah;
    uint8_t var_29h;
    int64_t var_28h;
    
    var_28h = -2;
    uVar1 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_7b0h._0_4_ = 2;
        var_2ah = 1;
        var_48h = arg1;
        var_29h = uVar1;
        var_50h = func_0x000140796790(*(undefined8 *)(arg1 + 0x28));
        var_38h = var_48h + 0x30;
        func_0x00014007b410();
        func_0x000140951cf0(var_38h, &var_7b0h, 0x760);
        var_2ah = 0;
        func_0x000140796f10(&var_50h);
        arg1 = var_48h;
        uVar1 = var_29h;
    }
    if ((uVar1 & 1) != 0) {
        func_0x000140796b10(arg1 + 0x790, 0);
    }
    cVar2 = func_0x000140797e30(arg1);
    if (cVar2 != '\0') {
        func_0x00014000cb60(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_14002cc80
// Address: 0x14002cc80
// Size: 46 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_72eh because it doesn't fit into ProtoModel

void fcn.14002cc80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(char *)(arg2 + 0x7ae) != '\0') {
        fcn.14007b410(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_14002ccb0
// Address: 0x14002ccb0
// Size: 25 bytes
// ============================================================
void fcn.14002ccb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002ccd0
// Address: 0x14002ccd0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_738h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_718h because it doesn't fit into ProtoModel

undefined8 fcn.14002ccd0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x7b8));
    *(undefined8 *)(arg2 + 0x7a0) = uVar1;
    *(int64_t *)(arg2 + 0x798) = iVar2;
    return 0x14002cc05;
}

// ============================================================
// Function: FUN_14002cd10
// Address: 0x14002cd10
// Size: 25 bytes
// ============================================================
void fcn.14002cd10(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002cd30
// Address: 0x14002cd30
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_718h because it doesn't fit into ProtoModel

undefined8 fcn.14002cd30(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x7a0) = uVar1;
    *(int64_t *)(arg2 + 0x798) = iVar2;
    return 0x14002cc05;
}

// ============================================================
// Function: FUN_14002cd70
// Address: 0x14002cd70
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_718h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel

void fcn.14002cd70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x798) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x7a0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x798) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002cdc0
// Address: 0x14002cdc0
// Size: 68 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_708h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_72eh because it doesn't fit into ProtoModel

void fcn.14002cdc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140951cf0(*(undefined8 *)(arg2 + 0x7a0), arg2 + 0x28, 0x760);
    fcn.140796f10(arg2 + 0x788);
    *(undefined *)(arg2 + 0x7ae) = 0;
    return;
}

// ============================================================
// Function: FUN_14002ce10
// Address: 0x14002ce10
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1ce8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce7h because it doesn't fit into ProtoModel

void fcn.14002ce10(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002ce1c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001ce8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001cc8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ce3e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001ce7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ce64;
        func_0x00014011e230(*(int64_t *)(&stack0x00001cc8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001ce7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ce84;
        func_0x000140796b10(*(int64_t *)(&stack0x00001cc8 + iVar4) + 0x1ce0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001cc8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ce93;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ce9f;
        func_0x00014001a120(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002cf10
// Address: 0x14002cf10
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel

undefined8 fcn.14002cf10(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1d00));
    *(undefined8 *)(arg2 + 0x1ce0) = uVar1;
    *(int64_t *)(arg2 + 0x1ce8) = iVar2;
    return 0x14002ceaa;
}

// ============================================================
// Function: FUN_14002cf50
// Address: 0x14002cf50
// Size: 24 bytes
// ============================================================
void fcn.14002cf50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002cf70
// Address: 0x14002cf70
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel

undefined8 fcn.14002cf70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1ce0) = uVar1;
    *(int64_t *)(arg2 + 0x1ce8) = iVar2;
    return 0x14002ceaa;
}

// ============================================================
// Function: FUN_14002cfb0
// Address: 0x14002cfb0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel

void fcn.14002cfb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1ce8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1ce0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1ce8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002d000
// Address: 0x14002d000
// Size: 24 bytes
// ============================================================
void fcn.14002d000(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002d020
// Address: 0x14002d020
// Size: 323 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ah

void fcn.14002d020(int64_t arg1)
{
    uint8_t uVar1;
    char cVar2;
    uint64_t in_RDX;
    int64_t var_168h;
    int64_t var_108h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    undefined var_2ah;
    uint8_t var_29h;
    int64_t var_28h;
    
    var_28h = -2;
    uVar1 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_168h._0_4_ = 2;
        var_2ah = 1;
        var_48h = arg1;
        var_29h = uVar1;
        var_50h = func_0x000140796790(*(undefined8 *)(arg1 + 0x28));
        var_38h = var_48h + 0x30;
        func_0x000140003010();
        fcn.140951cf0(var_38h, &var_168h, 0x118);
        var_2ah = 0;
        fcn.140796f10(&var_50h);
        arg1 = var_48h;
        uVar1 = var_29h;
    }
    if ((uVar1 & 1) != 0) {
        func_0x000140796b10(arg1 + 0x148, 0);
    }
    cVar2 = func_0x000140797e30(arg1);
    if (cVar2 != '\0') {
        func_0x00014000cd70(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_14002d170
// Address: 0x14002d170
// Size: 46 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_deh because it doesn't fit into ProtoModel

void fcn.14002d170(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_60h;
    
    if (*(char *)(arg2 + 0x15e) != '\0') {
        fcn.140003010(arg2 + 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_14002d1a0
// Address: 0x14002d1a0
// Size: 25 bytes
// ============================================================
void fcn.14002d1a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002d1c0
// Address: 0x14002d1c0
// Size: 60 bytes
// ============================================================
undefined8 fcn.14002d1c0(undefined8 placeholder_0, int64_t arg2, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_e8h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x168));
    *(undefined8 *)(arg2 + 0x150) = uVar1;
    *(int64_t *)(arg2 + 0x148) = iVar2;
    return 0x14002d0f5;
}

// ============================================================
// Function: FUN_14002d200
// Address: 0x14002d200
// Size: 25 bytes
// ============================================================
void fcn.14002d200(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002d220
// Address: 0x14002d220
// Size: 55 bytes
// ============================================================
undefined8 fcn.14002d220(undefined8 placeholder_0, int64_t arg2, int64_t arg_c8h, int64_t arg_d0h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x150) = uVar1;
    *(int64_t *)(arg2 + 0x148) = iVar2;
    return 0x14002d0f5;
}

// ============================================================
// Function: FUN_14002d260
// Address: 0x14002d260
// Size: 67 bytes
// ============================================================
void fcn.14002d260(undefined8 placeholder_0, int64_t arg2, int64_t arg_c8h, int64_t arg_d0h)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x148) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x150), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x148) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002d2b0
// Address: 0x14002d2b0
// Size: 68 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_deh because it doesn't fit into ProtoModel

void fcn.14002d2b0(undefined8 placeholder_0, int64_t arg2, int64_t arg_b8h, int64_t arg_d0h)
{
    int64_t var_10h;
    int64_t var_60h;
    
    fcn.140951cf0(*(undefined8 *)(arg2 + 0x150), arg2 + 0x20, 0x118);
    fcn.140796f10(arg2 + 0x138);
    *(undefined *)(arg2 + 0x15e) = 0;
    return;
}

// ============================================================
// Function: FUN_14002d300
// Address: 0x14002d300
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e7h because it doesn't fit into ProtoModel

void fcn.14002d300(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002d30c;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x000013e8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x000013c8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002d32e;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x000013e7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002d354;
        func_0x00014011f7c0(*(int64_t *)(&stack0x000013c8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x000013e7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002d374;
        func_0x000140796b10(*(int64_t *)(&stack0x000013c8 + iVar4) + 0x13e0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x000013c8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002d383;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002d38f;
        func_0x0001400198e0(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002d400
// Address: 0x14002d400
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel

undefined8 fcn.14002d400(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1400));
    *(undefined8 *)(arg2 + 0x13e0) = uVar1;
    *(int64_t *)(arg2 + 0x13e8) = iVar2;
    return 0x14002d39a;
}

// ============================================================
// Function: FUN_14002d440
// Address: 0x14002d440
// Size: 24 bytes
// ============================================================
void fcn.14002d440(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002d460
// Address: 0x14002d460
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel

undefined8 fcn.14002d460(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x13e0) = uVar1;
    *(int64_t *)(arg2 + 0x13e8) = iVar2;
    return 0x14002d39a;
}

// ============================================================
// Function: FUN_14002d4a0
// Address: 0x14002d4a0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel

void fcn.14002d4a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x13e8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x13e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x13e8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002d4f0
// Address: 0x14002d4f0
// Size: 24 bytes
// ============================================================
void fcn.14002d4f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002d510
// Address: 0x14002d510
// Size: 192 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002d510(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_d0h;
    int64_t var_78h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_d0h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011dfe0(var_40h + 0x20, &var_d0h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xc0, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014000d120(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002d5d0
// Address: 0x14002d5d0
// Size: 49 bytes
// ============================================================
undefined8 fcn.14002d5d0(undefined8 placeholder_0, int64_t arg2, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xe0));
    *(undefined8 *)(arg2 + 0xc0) = uVar1;
    *(int64_t *)(arg2 + 200) = iVar2;
    return 0x14002d58f;
}

// ============================================================
// Function: FUN_14002d610
// Address: 0x14002d610
// Size: 24 bytes
// ============================================================
void fcn.14002d610(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

