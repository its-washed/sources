// Chunk 9 - 50 functions

// ============================================================
// Function: FUN_14000be40
// Address: 0x14000be40
// Size: 57 bytes
// ============================================================
void fcn.14000be40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000be80
// Address: 0x14000be80
// Size: 59 bytes
// ============================================================
void fcn.14000be80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000bec0
// Address: 0x14000bec0
// Size: 95 bytes
// ============================================================
void fcn.14000bec0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    func_0x00014001be30(iVar1);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    if (*(int64_t *)(iVar1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x170), *(int64_t *)(iVar1 + 0x168), 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000bf20
// Address: 0x14000bf20
// Size: 57 bytes
// ============================================================
void fcn.14000bf20(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x180);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c7d50(iVar1 + 0x180);
    }
    return;
}

// ============================================================
// Function: FUN_14000bf60
// Address: 0x14000bf60
// Size: 59 bytes
// ============================================================
void fcn.14000bf60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x168);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x170), iVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_14000bfa0
// Address: 0x14000bfa0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14000bfa0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014001dda0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x740) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x740) + 0x18))(*(undefined8 *)(arg1 + 0x748));
    }
    piVar1 = *(int64_t **)(arg1 + 0x750);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x00014045efb0(arg1 + 0x750);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x780);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14000c0a0
// Address: 0x14000c0a0
// Size: 51 bytes
// ============================================================
void fcn.14000c0a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14000c0e0
// Address: 0x14000c0e0
// Size: 37 bytes
// ============================================================
void fcn.14000c0e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x730);
    return;
}

// ============================================================
// Function: FUN_14000c110
// Address: 0x14000c110
// Size: 58 bytes
// ============================================================
void fcn.14000c110(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x750);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x750);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14000c150
// Address: 0x14000c150
// Size: 41 bytes
// ============================================================
void fcn.14000c150(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x780, 0x80);
    return;
}

// ============================================================
// Function: FUN_14000c180
// Address: 0x14000c180
// Size: 34 bytes
// ============================================================
void fcn.14000c180(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140002010(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14000c1b0
// Address: 0x14000c1b0
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14000c1b0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x00014001dda0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x740) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x740) + 0x18))(*(undefined8 *)(arg1 + 0x748));
    }
    piVar1 = *(int64_t **)(arg1 + 0x750);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x750);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x780);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14000c2b0
// Address: 0x14000c2b0
// Size: 51 bytes
// ============================================================
void fcn.14000c2b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14000c2f0
// Address: 0x14000c2f0
// Size: 37 bytes
// ============================================================
void fcn.14000c2f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x730);
    return;
}

// ============================================================
// Function: FUN_14000c320
// Address: 0x14000c320
// Size: 58 bytes
// ============================================================
void fcn.14000c320(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x750);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x750);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14000c360
// Address: 0x14000c360
// Size: 41 bytes
// ============================================================
void fcn.14000c360(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x780, 0x80);
    return;
}

// ============================================================
// Function: FUN_14000c390
// Address: 0x14000c390
// Size: 34 bytes
// ============================================================
void fcn.14000c390(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140002010(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14000c3c0
// Address: 0x14000c3c0
// Size: 151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14000c3c0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    func_0x000140003010(arg1 + 0x30);
    if (*(int64_t *)(arg1 + 0x158) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x158) + 0x18))(*(undefined8 *)(arg1 + 0x160));
    }
    piVar1 = *(int64_t **)(arg1 + 0x168);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x168);
        }
    }
    uVar2 = *(undefined8 *)(arg1 + -8);
    uVar3 = (*(code *)0xe5f2d8)(arg1, 0x180);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000c460
// Address: 0x14000c460
// Size: 58 bytes
// ============================================================
void fcn.14000c460(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x168);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x168);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14000c4a0
// Address: 0x14000c4a0
// Size: 41 bytes
// ============================================================
void fcn.14000c4a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), 0x180, 0x80);
    return;
}

// ============================================================
// Function: FUN_14000c4d0
// Address: 0x14000c4d0
// Size: 34 bytes
// ============================================================
void fcn.14000c4d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140003010(*(int64_t *)(arg2 + 0x20) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14000c500
// Address: 0x14000c500
// Size: 37 bytes
// ============================================================
void fcn.14000c500(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x20) + 0x148);
    return;
}

// ============================================================
// Function: FUN_14000c530
// Address: 0x14000c530
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14000c530(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140001000(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x130) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x130) + 0x18))(*(undefined8 *)(arg1 + 0x138));
    }
    piVar1 = *(int64_t **)(arg1 + 0x140);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x140);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x180);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14000c630
// Address: 0x14000c630
// Size: 51 bytes
// ============================================================
void fcn.14000c630(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14000c670
// Address: 0x14000c670
// Size: 37 bytes
// ============================================================
void fcn.14000c670(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x120);
    return;
}

// ============================================================
// Function: FUN_14000c6a0
// Address: 0x14000c6a0
// Size: 58 bytes
// ============================================================
void fcn.14000c6a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x140);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x140);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14000c6e0
// Address: 0x14000c6e0
// Size: 41 bytes
// ============================================================
void fcn.14000c6e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x180, 0x80);
    return;
}

// ============================================================
// Function: FUN_14000c710
// Address: 0x14000c710
// Size: 34 bytes
// ============================================================
void fcn.14000c710(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140002e90(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14000c740
// Address: 0x14000c740
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14000c740(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140795240(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140001440(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x7a0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x7a0) + 0x18))(*(undefined8 *)(arg1 + 0x7a8));
    }
    piVar1 = *(int64_t **)(arg1 + 0x7b0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x7b0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x800);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14000c840
// Address: 0x14000c840
// Size: 51 bytes
// ============================================================
void fcn.14000c840(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14000c880
// Address: 0x14000c880
// Size: 37 bytes
// ============================================================
void fcn.14000c880(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x790);
    return;
}

// ============================================================
// Function: FUN_14000c8b0
// Address: 0x14000c8b0
// Size: 58 bytes
// ============================================================
void fcn.14000c8b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x7b0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x7b0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14000c8f0
// Address: 0x14000c8f0
// Size: 41 bytes
// ============================================================
void fcn.14000c8f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x800, 0x80);
    return;
}

// ============================================================
// Function: FUN_14000c920
// Address: 0x14000c920
// Size: 34 bytes
// ============================================================
void fcn.14000c920(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140002f50(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14000c950
// Address: 0x14000c950
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14000c950(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140001000(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x130) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x130) + 0x18))(*(undefined8 *)(arg1 + 0x138));
    }
    piVar1 = *(int64_t **)(arg1 + 0x140);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x140);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x180);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14000ca50
// Address: 0x14000ca50
// Size: 51 bytes
// ============================================================
void fcn.14000ca50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14000ca90
// Address: 0x14000ca90
// Size: 37 bytes
// ============================================================
void fcn.14000ca90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x120);
    return;
}

// ============================================================
// Function: FUN_14000cac0
// Address: 0x14000cac0
// Size: 58 bytes
// ============================================================
void fcn.14000cac0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x140);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x140);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14000cb00
// Address: 0x14000cb00
// Size: 41 bytes
// ============================================================
void fcn.14000cb00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x180, 0x80);
    return;
}

// ============================================================
// Function: FUN_14000cb30
// Address: 0x14000cb30
// Size: 34 bytes
// ============================================================
void fcn.14000cb30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140002e90(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14000cb60
// Address: 0x14000cb60
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14000cb60(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140001440(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0x7a0) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x7a0) + 0x18))(*(undefined8 *)(arg1 + 0x7a8));
    }
    piVar1 = *(int64_t **)(arg1 + 0x7b0);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x7b0);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x800);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14000cc60
// Address: 0x14000cc60
// Size: 51 bytes
// ============================================================
void fcn.14000cc60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14000cca0
// Address: 0x14000cca0
// Size: 37 bytes
// ============================================================
void fcn.14000cca0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x790);
    return;
}

// ============================================================
// Function: FUN_14000ccd0
// Address: 0x14000ccd0
// Size: 58 bytes
// ============================================================
void fcn.14000ccd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x7b0);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x7b0);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14000cd10
// Address: 0x14000cd10
// Size: 41 bytes
// ============================================================
void fcn.14000cd10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x800, 0x80);
    return;
}

// ============================================================
// Function: FUN_14000cd40
// Address: 0x14000cd40
// Size: 34 bytes
// ============================================================
void fcn.14000cd40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140002f50(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14000cd70
// Address: 0x14000cd70
// Size: 151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14000cd70(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    fcn.140003010(arg1 + 0x30);
    if (*(int64_t *)(arg1 + 0x158) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x158) + 0x18))(*(undefined8 *)(arg1 + 0x160));
    }
    piVar1 = *(int64_t **)(arg1 + 0x168);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0x168);
        }
    }
    uVar2 = *(undefined8 *)(arg1 + -8);
    uVar3 = (*(code *)0xe5f2d8)(arg1, 0x180);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar2);
    return;
}

// ============================================================
// Function: FUN_14000ce10
// Address: 0x14000ce10
// Size: 58 bytes
// ============================================================
void fcn.14000ce10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x168);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x168);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14000ce50
// Address: 0x14000ce50
// Size: 41 bytes
// ============================================================
void fcn.14000ce50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), 0x180, 0x80);
    return;
}

// ============================================================
// Function: FUN_14000ce80
// Address: 0x14000ce80
// Size: 34 bytes
// ============================================================
void fcn.14000ce80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140003010(*(int64_t *)(arg2 + 0x20) + 0x30);
    return;
}

