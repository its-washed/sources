// Chunk 6 - 50 functions

// ============================================================
// Function: FUN_140007c00
// Address: 0x140007c00
// Size: 43 bytes
// ============================================================
void fcn.140007c00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140007c30
// Address: 0x140007c30
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140007c30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140007c80
// Address: 0x140007c80
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007c80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140007cd0
// Address: 0x140007cd0
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140007cd0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x900) == '\0') {
        func_0x00014001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x000140007e6f;
    }
    if (*(char *)(arg1 + 0x900) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x8f8) == '\0') {
        if (*(char *)(arg1 + 0x6a8) == '\0') {
            func_0x000140014e50(arg1 + 0x468);
            iVar4 = *(int64_t *)(arg1 + 0x680);
            iVar2 = 0x680;
            goto code_r0x000140007dd8;
        }
    } else if ((*(char *)(arg1 + 0x8f8) == '\x03') && (*(char *)(arg1 + 0x8f0) == '\0')) {
        func_0x000140014e50(arg1 + 0x6b0);
        iVar4 = *(int64_t *)(arg1 + 0x8c8);
        iVar2 = 0x8c8;
code_r0x000140007dd8:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    func_0x00014001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x000140007e6f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140007eb0
// Address: 0x140007eb0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007eb0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x680);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x688), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140007f00
// Address: 0x140007f00
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007f00(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x8c8);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x8d0), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140007f50
// Address: 0x140007f50
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007f50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140007f80
// Address: 0x140007f80
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140007f80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140007fd0
// Address: 0x140007fd0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140007fd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140008020
// Address: 0x140008020
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008020(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140008060
// Address: 0x140008060
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008060(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140008090
// Address: 0x140008090
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140008090(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1400080e0
// Address: 0x1400080e0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400080e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140008130
// Address: 0x140008130
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140008130(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x900) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x0001400082cf;
    }
    if (*(char *)(arg1 + 0x900) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x8f8) == '\0') {
        if (*(char *)(arg1 + 0x6a8) == '\0') {
            func_0x000140014e50(arg1 + 0x478);
            iVar4 = *(int64_t *)(arg1 + 0x690);
            iVar2 = 0x690;
            goto code_r0x000140008238;
        }
    } else if ((*(char *)(arg1 + 0x8f8) == '\x03') && (*(char *)(arg1 + 0x8f0) == '\0')) {
        func_0x000140014e50(arg1 + 0x6c0);
        iVar4 = *(int64_t *)(arg1 + 0x8d8);
        iVar2 = 0x8d8;
code_r0x000140008238:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x0001400082cf:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140008310
// Address: 0x140008310
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008310(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x690);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x698), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140008360
// Address: 0x140008360
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008360(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x8d8);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x8e0), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_1400083b0
// Address: 0x1400083b0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400083b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400083e0
// Address: 0x1400083e0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400083e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140008430
// Address: 0x140008430
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008430(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140008480
// Address: 0x140008480
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008480(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400084c0
// Address: 0x1400084c0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400084c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400084f0
// Address: 0x1400084f0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400084f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140008540
// Address: 0x140008540
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008540(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140008590
// Address: 0x140008590
// Size: 491 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140008590(int64_t arg1)
{
    int64_t iVar1;
    char cVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x960) == '\0') {
        fcn.14001c990();
        iVar1 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar5 = *(int64_t *)(arg1 + 0x210);
        while (iVar1 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar5);
            iVar5 = iVar5 + 0x60;
        }
        goto code_r0x00014000873f;
    }
    if (*(char *)(arg1 + 0x960) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x958) == '\x03') {
        iVar1 = arg1 + 0x6f0;
        cVar2 = *(char *)(arg1 + 0x950);
joined_r0x000140008671:
        if (cVar2 == '\0') {
            func_0x000140014e50(iVar1);
            if (*(int64_t *)(iVar1 + 0x248) != 0) {
                fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x250), *(int64_t *)(iVar1 + 0x248), 1);
            }
            if ((*(int32_t *)(iVar1 + 0x218) != 2) && (*(int64_t *)(iVar1 + 0x228) != 0)) {
                fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x230), *(int64_t *)(iVar1 + 0x228), 1);
            }
        }
    } else if (*(char *)(arg1 + 0x958) == '\0') {
        iVar1 = arg1 + 0x488;
        cVar2 = *(char *)(arg1 + 0x6e8);
        goto joined_r0x000140008671;
    }
    fcn.14001c990(arg1);
    iVar1 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar5 = *(int64_t *)(arg1 + 0x210);
    while (iVar1 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar5);
        iVar5 = iVar5 + 0x60;
    }
code_r0x00014000873f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar3 = *(undefined8 *)(arg1 + 0x210);
    uVar4 = (*(code *)0xe5f2d8)(uVar3, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar4, 0, uVar3);
    return;
}

// ============================================================
// Function: FUN_140008780
// Address: 0x140008780
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008780(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x40);
    if ((*(uint64_t *)(iVar1 + 0x248) & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x250), *(uint64_t *)(iVar1 + 0x248), 1);
    }
    fcn.14001f060(iVar1 + 0x218);
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140008800
// Address: 0x140008800
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008800(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140008830
// Address: 0x140008830
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140008830(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140008880
// Address: 0x140008880
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008880(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_1400088d0
// Address: 0x1400088d0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1400088d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140008900
// Address: 0x140008900
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140008900(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140008950
// Address: 0x140008950
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008950(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_1400089a0
// Address: 0x1400089a0
// Size: 523 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.1400089a0(int64_t arg1)
{
    int64_t iVar1;
    char cVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0xd80) == '\0') {
        fcn.14001c990();
        iVar1 = *(int64_t *)(arg1 + 0x218);
        var_30h = 0;
        iVar5 = *(int64_t *)(arg1 + 0x210);
        while (iVar1 != var_30h) {
            var_30h = var_30h + 1;
            func_0x0001402727a0(iVar5);
            iVar5 = iVar5 + 0x60;
        }
        goto code_r0x000140008b6f;
    }
    if (*(char *)(arg1 + 0xd80) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0xd78) == '\x03') {
        iVar1 = arg1 + 0x9b0;
        cVar2 = *(char *)(arg1 + 0xd70);
joined_r0x000140008a81:
        if (cVar2 == '\0') {
            func_0x00014001be30(iVar1);
            func_0x000140014e50(iVar1 + 0x168);
            if (*(int64_t *)(iVar1 + 0x380) != 0) {
                fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x388), *(int64_t *)(iVar1 + 0x380), 1);
            }
            if (*(uint32_t *)(iVar1 + 0x398) < 2) {
                iVar5 = 8;
            } else {
                iVar5 = 0x10;
                if (*(uint32_t *)(iVar1 + 0x398) == 2) goto code_r0x000140008b0b;
            }
            iVar3 = *(int64_t *)(iVar1 + 0x398 + iVar5);
            if (iVar3 != 0) {
                fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x3a0 + iVar5), iVar3, 1);
            }
        }
    } else if (*(char *)(arg1 + 0xd78) == '\0') {
        iVar1 = arg1 + 0x5e8;
        cVar2 = *(char *)(arg1 + 0x9a8);
        goto joined_r0x000140008a81;
    }
code_r0x000140008b0b:
    fcn.14001c990(arg1);
    iVar1 = *(int64_t *)(arg1 + 0x218);
    var_30h = 0;
    iVar5 = *(int64_t *)(arg1 + 0x210);
    while (iVar1 != var_30h) {
        var_30h = var_30h + 1;
        func_0x0001402727a0(iVar5);
        iVar5 = iVar5 + 0x60;
    }
code_r0x000140008b6f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar4 = *(undefined8 *)(arg1 + 0x210);
    uVar6 = (*(code *)0xe5f2d8)(uVar4, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar6, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_140008bb0
// Address: 0x140008bb0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008bb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140014e50(*(int64_t *)(arg2 + 0x48) + 0x168);
    return;
}

// ============================================================
// Function: FUN_140008be0
// Address: 0x140008be0
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008be0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    if ((*(uint64_t *)(iVar1 + 0x380) & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x388), *(uint64_t *)(iVar1 + 0x380), 1);
    }
    fcn.140014e20(iVar1 + 0x398);
    iVar1 = *(int64_t *)(arg2 + 0x40);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140008c60
// Address: 0x140008c60
// Size: 43 bytes
// ============================================================
void fcn.140008c60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140008c90
// Address: 0x140008c90
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140008c90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140008ce0
// Address: 0x140008ce0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.140008ce0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140008d30
// Address: 0x140008d30
// Size: 43 bytes
// ============================================================
void fcn.140008d30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x40) + 0x208);
    return;
}

// ============================================================
// Function: FUN_140008d60
// Address: 0x140008d60
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.140008d60(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140008db0
// Address: 0x140008db0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.140008db0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x40) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140008e00
// Address: 0x140008e00
// Size: 475 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.140008e00(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(char *)(arg1 + 0x708) == '\0') {
        fcn.14001c990();
        iVar4 = *(int64_t *)(arg1 + 0x218);
        var_38h = 0;
        iVar2 = *(int64_t *)(arg1 + 0x210);
        while (iVar4 != var_38h) {
            var_38h = var_38h + 1;
            func_0x0001402727a0(iVar2);
            iVar2 = iVar2 + 0x60;
        }
        goto code_r0x000140008f9f;
    }
    if (*(char *)(arg1 + 0x708) != '\x03') {
        return;
    }
    if (*(char *)(arg1 + 0x700) == '\0') {
        if (*(char *)(arg1 + 0x558) == '\0') {
            func_0x00014001be30(arg1 + 0x3c0);
            iVar4 = *(int64_t *)(arg1 + 0x528);
            iVar2 = 0x528;
            goto code_r0x000140008f08;
        }
    } else if ((*(char *)(arg1 + 0x700) == '\x03') && (*(char *)(arg1 + 0x6f8) == '\0')) {
        func_0x00014001be30(arg1 + 0x560);
        iVar4 = *(int64_t *)(arg1 + 0x6c8);
        iVar2 = 0x6c8;
code_r0x000140008f08:
        if (iVar4 != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 8 + iVar2), iVar4, 1);
        }
    }
    fcn.14001c990(arg1);
    iVar4 = *(int64_t *)(arg1 + 0x218);
    var_38h = 0;
    iVar2 = *(int64_t *)(arg1 + 0x210);
    while (iVar4 != var_38h) {
        var_38h = var_38h + 1;
        func_0x0001402727a0(iVar2);
        iVar2 = iVar2 + 0x60;
    }
code_r0x000140008f9f:
    var_48h = arg1 + 0x208;
    if (*(int64_t *)var_48h == 0) {
        return;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar3 = (*(code *)0xe5f2d8)(uVar1, *(int64_t *)var_48h * 0x60);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar3, 0, uVar1);
    return;
}

// ============================================================
// Function: FUN_140008fe0
// Address: 0x140008fe0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140008fe0(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x528);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x530), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140009030
// Address: 0x140009030
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009030(undefined8 placeholder_0, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(*(int64_t *)(arg2 + 0x48) + 0x6c8);
    if ((uVar1 & 0x7fffffffffffffff) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x6d0), uVar1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_140009080
// Address: 0x140009080
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009080(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400090b0
// Address: 0x1400090b0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400090b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140009100
// Address: 0x140009100
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009100(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

// ============================================================
// Function: FUN_140009150
// Address: 0x140009150
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009150(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    fcn.14001c990(iVar1);
    fcn.140001ed0(iVar1 + 0x208);
    return;
}

// ============================================================
// Function: FUN_140009190
// Address: 0x140009190
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009190(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140001ed0(*(int64_t *)(arg2 + 0x48) + 0x208);
    return;
}

// ============================================================
// Function: FUN_1400091c0
// Address: 0x1400091c0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1400091c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x40); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        func_0x0001402727a0(iVar3 * 0x60 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_140009210
// Address: 0x140009210
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.140009210(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_8h;
    
    if (**(int64_t **)(arg2 + 0x30) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x48) + 0x210), **(int64_t **)(arg2 + 0x30) * 0x60, 8);
    }
    return;
}

