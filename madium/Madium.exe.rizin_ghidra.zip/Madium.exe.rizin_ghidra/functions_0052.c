// Chunk 52 - 50 functions

// ============================================================
// Function: FUN_14003bad0
// Address: 0x14003bad0
// Size: 37 bytes
// ============================================================
void fcn.14003bad0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14003bb00
// Address: 0x14003bb00
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14003bb00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011d740(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_14003bb40
// Address: 0x14003bb40
// Size: 25 bytes
// ============================================================
void fcn.14003bb40(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003bb60
// Address: 0x14003bb60
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003bb60(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003b9f7;
}

// ============================================================
// Function: FUN_14003bba0
// Address: 0x14003bba0
// Size: 25 bytes
// ============================================================
void fcn.14003bba0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003bbc0
// Address: 0x14003bbc0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003bbc0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003b9f7;
}

// ============================================================
// Function: FUN_14003bc00
// Address: 0x14003bc00
// Size: 25 bytes
// ============================================================
void fcn.14003bc00(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003bc20
// Address: 0x14003bc20
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003bc20(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003ba77;
}

// ============================================================
// Function: FUN_14003bc60
// Address: 0x14003bc60
// Size: 25 bytes
// ============================================================
void fcn.14003bc60(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003bc80
// Address: 0x14003bc80
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.14003bc80(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x14003ba77;
}

// ============================================================
// Function: FUN_14003bcc0
// Address: 0x14003bcc0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.14003bcc0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14003bd10
// Address: 0x14003bd10
// Size: 552 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1d90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_da0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_da8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2458h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_10f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1138h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1128h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1af0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1af8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ae8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ae0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_19f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_19f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2750h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2758h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1148h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1130h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2748h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_10f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1100h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ce0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ce8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1160h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1168h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2468h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2740h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_758h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2760h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_778h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1140h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_10e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2528h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1da0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2770h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2bc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2bd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2bc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_59e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1680h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_59f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_59f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_cf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1da8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1200h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1db0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_40a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_40a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_40b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4090h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5018h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Removing arg arg_2360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5880h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_299h
// WARNING: [rz-ghidra] Removing arg arg_22a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_cf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1208h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1db8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1210h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1170h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5870h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5830h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5838h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5828h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5860h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5868h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_40b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4088h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4070h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4078h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4068h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2580h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2947fe86h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2568h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1190h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1198h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1180h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4098h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Removing arg arg_2560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1178h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_2a0h
// WARNING: [rz-ghidra] Removing arg arg_2088h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2090h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3cf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2098h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1868h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2bb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ea8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ca8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d6h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2438h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_557h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_528h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2588h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_40c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2590h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_540h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1960h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2690h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_40f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_988h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_47f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4808h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcbfe91h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_10d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_cb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_53fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3628h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3638h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ad8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3528h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_568h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3640h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1220h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1228h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2688h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4058h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ef8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2680h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3540h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4080h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4060h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_279h
// WARNING: [rz-ghidra] Removing arg arg_55fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3630h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2430h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1948h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_271h
// WARNING: [rz-ghidra] Removing arg arg_918h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2d48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26eh
// WARNING: [rz-ghidra] Removing arg arg_3730h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3718h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3708h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3738h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_567h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1118h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1568h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_40c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_980h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_990h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2947fe8fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3728h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1540h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_276h
// WARNING: [rz-ghidra] Removing arg arg_970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3700h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2920h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_748h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcbfe82h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_36f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_11d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ba8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bb0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcbfe8ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fcbfe92h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b0h
// WARNING: [rz-ghidra] Removing arg arg_15b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Removing arg arg_22e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ba0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1dfh
// WARNING: [rz-ghidra] Removing arg arg_c38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1940h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_e1h
// WARNING: [rz-ghidra] Detected overlap for variable var_26dh
// WARNING: [rz-ghidra] Removing arg arg_1b18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2df8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ac8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2148h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_878h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1730h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3168h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1838h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2078h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_db8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2160h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_16a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ef8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1a8h
// WARNING: [rz-ghidra] Removing arg arg_27c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_898h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel

void fcn.14003bd10(int64_t arg1, int64_t var_28h, int64_t arg_80h, int64_t arg_88h, int64_t arg_e0h, int64_t arg_e8h,
                  int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h, int64_t arg_110h,
                  int64_t arg_118h, int64_t arg_120h)
{
    uint8_t uVar1;
    int64_t var_10h;
    int64_t var_3bd6ba08h;
    int64_t var_10f0h;
    int64_t var_10b0h;
    int64_t var_fa8h;
    int64_t var_fa0h;
    int64_t var_f88h;
    int64_t var_ed0h;
    int64_t var_ec8h;
    int64_t var_a58h;
    int64_t var_a50h;
    int64_t var_a00h;
    int64_t var_900h;
    int64_t var_6f0h;
    int64_t var_640h;
    int64_t var_628h;
    int64_t var_610h;
    int64_t var_5d0h;
    int64_t var_5b8h;
    int64_t var_538h;
    int64_t var_530h;
    int64_t var_528h;
    int64_t var_520h;
    int64_t var_4e0h;
    int64_t var_4d8h;
    int64_t var_4c8h;
    int64_t var_4c0h;
    int64_t var_4b1h;
    int64_t var_490h;
    int64_t var_448h;
    int64_t var_440h;
    int64_t var_438h;
    int64_t var_428h;
    int64_t var_418h;
    int64_t var_410h;
    int64_t var_408h;
    int64_t var_400h;
    int64_t var_3f8h;
    int64_t var_3d0h;
    int64_t var_3c0h;
    int64_t var_3b8h;
    int64_t var_2f8h;
    int64_t var_2f0h;
    int64_t var_2e8h;
    int64_t var_2d8h;
    int64_t var_2d0h;
    int64_t var_2c8h;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_298h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1bah;
    int64_t var_1b2h;
    int64_t var_1aah;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e9h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014003bd46. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (33 cases) at 0x14097a604
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a604) + 0x14097a604))();
    return;
}

// ============================================================
// Function: FUN_14003bf40
// Address: 0x14003bf40
// Size: 37 bytes
// ============================================================
void fcn.14003bf40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14003bf70
// Address: 0x14003bf70
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14003bf70(undefined8 placeholder_0, int64_t arg2, int64_t arg_98h, int64_t arg_1d0h)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x118) = 2;
    fcn.14011ec40(*(undefined8 *)(arg2 + 0x250), arg2 + 0x118);
    return;
}

// ============================================================
// Function: FUN_14003bfb0
// Address: 0x14003bfb0
// Size: 25 bytes
// ============================================================
void fcn.14003bfb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003bfd0
// Address: 0x14003bfd0
// Size: 60 bytes
// ============================================================
undefined8 fcn.14003bfd0(undefined8 placeholder_0, int64_t arg2, int64_t arg_1b8h, int64_t arg_1c8h, int64_t arg_1e8h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x268));
    *(undefined8 *)(arg2 + 0x238) = uVar1;
    *(int64_t *)(arg2 + 0x248) = iVar2;
    return 0x14003be6d;
}

// ============================================================
// Function: FUN_14003c010
// Address: 0x14003c010
// Size: 25 bytes
// ============================================================
void fcn.14003c010(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003c030
// Address: 0x14003c030
// Size: 55 bytes
// ============================================================
undefined8 fcn.14003c030(undefined8 placeholder_0, int64_t arg2, int64_t arg_1b8h, int64_t arg_1c8h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x238) = uVar1;
    *(int64_t *)(arg2 + 0x248) = iVar2;
    return 0x14003be6d;
}

// ============================================================
// Function: FUN_14003c070
// Address: 0x14003c070
// Size: 25 bytes
// ============================================================
void fcn.14003c070(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003c090
// Address: 0x14003c090
// Size: 60 bytes
// ============================================================
undefined8 fcn.14003c090(undefined8 placeholder_0, int64_t arg2, int64_t arg_1c8h, int64_t arg_1d0h, int64_t arg_1e0h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x260));
    *(undefined8 *)(arg2 + 0x250) = uVar1;
    *(int64_t *)(arg2 + 0x248) = iVar2;
    return 0x14003beed;
}

// ============================================================
// Function: FUN_14003c0d0
// Address: 0x14003c0d0
// Size: 25 bytes
// ============================================================
void fcn.14003c0d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003c0f0
// Address: 0x14003c0f0
// Size: 55 bytes
// ============================================================
undefined8 fcn.14003c0f0(undefined8 placeholder_0, int64_t arg2, int64_t arg_1c8h, int64_t arg_1d0h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x250) = uVar1;
    *(int64_t *)(arg2 + 0x248) = iVar2;
    return 0x14003beed;
}

// ============================================================
// Function: FUN_14003c130
// Address: 0x14003c130
// Size: 67 bytes
// ============================================================
void fcn.14003c130(undefined8 placeholder_0, int64_t arg2, int64_t arg_1c8h, int64_t arg_1d0h)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x248) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x250), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x248) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14003c180
// Address: 0x14003c180
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e90h because it doesn't fit into ProtoModel

void fcn.14003c180(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14003c18d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00001e90 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14003c1ab;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014003c1bc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a624) + 0x14097a624))();
    return;
}

// ============================================================
// Function: FUN_14003c380
// Address: 0x14003c380
// Size: 37 bytes
// ============================================================
void fcn.14003c380(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14003c3b0
// Address: 0x14003c3b0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14003c3b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xf58) = 2;
    fcn.14011d460(*(undefined8 *)(arg2 + 0x1ea0), arg2 + 0xf58);
    return;
}

// ============================================================
// Function: FUN_14003c3f0
// Address: 0x14003c3f0
// Size: 25 bytes
// ============================================================
void fcn.14003c3f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003c410
// Address: 0x14003c410
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.14003c410(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1eb8));
    *(undefined8 *)(arg2 + 0x1e88) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x14003c2a7;
}

// ============================================================
// Function: FUN_14003c450
// Address: 0x14003c450
// Size: 25 bytes
// ============================================================
void fcn.14003c450(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003c470
// Address: 0x14003c470
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.14003c470(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1e88) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x14003c2a7;
}

// ============================================================
// Function: FUN_14003c4b0
// Address: 0x14003c4b0
// Size: 25 bytes
// ============================================================
void fcn.14003c4b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003c4d0
// Address: 0x14003c4d0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.14003c4d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1eb0));
    *(undefined8 *)(arg2 + 0x1ea0) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x14003c327;
}

// ============================================================
// Function: FUN_14003c510
// Address: 0x14003c510
// Size: 25 bytes
// ============================================================
void fcn.14003c510(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003c530
// Address: 0x14003c530
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.14003c530(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1ea0) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x14003c327;
}

// ============================================================
// Function: FUN_14003c570
// Address: 0x14003c570
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel

void fcn.14003c570(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1e98) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1ea0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1e98) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14003c5c0
// Address: 0x14003c5c0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_29d0h because it doesn't fit into ProtoModel

void fcn.14003c5c0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14003c5cd;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000029d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14003c5eb;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014003c5fc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a644) + 0x14097a644))();
    return;
}

// ============================================================
// Function: FUN_14003c7c0
// Address: 0x14003c7c0
// Size: 37 bytes
// ============================================================
void fcn.14003c7c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14003c7f0
// Address: 0x14003c7f0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2960h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14003c7f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x14f8) = 2;
    fcn.14011f930(*(undefined8 *)(arg2 + 0x29e0), arg2 + 0x14f8);
    return;
}

// ============================================================
// Function: FUN_14003c830
// Address: 0x14003c830
// Size: 25 bytes
// ============================================================
void fcn.14003c830(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003c850
// Address: 0x14003c850
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2978h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2948h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel

undefined8 fcn.14003c850(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x29f8));
    *(undefined8 *)(arg2 + 0x29c8) = uVar1;
    *(int64_t *)(arg2 + 0x29d8) = iVar2;
    return 0x14003c6e7;
}

// ============================================================
// Function: FUN_14003c890
// Address: 0x14003c890
// Size: 25 bytes
// ============================================================
void fcn.14003c890(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003c8b0
// Address: 0x14003c8b0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2948h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel

undefined8 fcn.14003c8b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x29c8) = uVar1;
    *(int64_t *)(arg2 + 0x29d8) = iVar2;
    return 0x14003c6e7;
}

// ============================================================
// Function: FUN_14003c8f0
// Address: 0x14003c8f0
// Size: 25 bytes
// ============================================================
void fcn.14003c8f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003c910
// Address: 0x14003c910
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2970h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2960h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel

undefined8 fcn.14003c910(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x29f0));
    *(undefined8 *)(arg2 + 0x29e0) = uVar1;
    *(int64_t *)(arg2 + 0x29d8) = iVar2;
    return 0x14003c767;
}

// ============================================================
// Function: FUN_14003c950
// Address: 0x14003c950
// Size: 25 bytes
// ============================================================
void fcn.14003c950(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14003c970
// Address: 0x14003c970
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2960h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel

undefined8 fcn.14003c970(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x29e0) = uVar1;
    *(int64_t *)(arg2 + 0x29d8) = iVar2;
    return 0x14003c767;
}

// ============================================================
// Function: FUN_14003c9b0
// Address: 0x14003c9b0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2960h because it doesn't fit into ProtoModel

void fcn.14003c9b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x29d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x29e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x29d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14003ca00
// Address: 0x14003ca00
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2010h because it doesn't fit into ProtoModel

void fcn.14003ca00(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14003ca0d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00002010 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14003ca2b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014003ca3c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097a664) + 0x14097a664))();
    return;
}

// ============================================================
// Function: FUN_14003cc00
// Address: 0x14003cc00
// Size: 37 bytes
// ============================================================
void fcn.14003cc00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_14003cc30
// Address: 0x14003cc30
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.14003cc30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1018) = 2;
    fcn.140120590(*(undefined8 *)(arg2 + 0x2020), arg2 + 0x1018);
    return;
}

