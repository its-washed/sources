// Chunk 32 - 50 functions

// ============================================================
// Function: FUN_140024fa0
// Address: 0x140024fa0
// Size: 108 bytes
// ============================================================
void fcn.140024fa0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0xbf8);
    puVar2 = *(undefined8 **)(arg2 + 0xc28);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0xc30) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xc20), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0xc30) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0xc10);
    uVar4 = *(undefined4 *)(arg2 + 0xc04);
    uVar5 = *(undefined4 *)(arg2 + 0xc08);
    uVar6 = *(undefined4 *)(arg2 + 0xc0c);
    *puVar1 = *(undefined4 *)(arg2 + 0xc00);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140025010
// Address: 0x140025010
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1be8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd0h because it doesn't fit into ProtoModel

void fcn.140025010(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x14002501d;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001c10 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025045;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x1bf0);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002505c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x1bc0);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025144;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00001be8 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00001bd8 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x00001bdc + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00001be0 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00001be4 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00001bf8 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001c08 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001c00 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00001bd0 + iVar9) = *(int64_t *)(&stack0x00001c00 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400250fc;
                (*pcVar3)(*(undefined8 *)(&stack0x00001bf8 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001c08 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001c00 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001c08 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025127;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00001bf8 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x00001bdc + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00001be0 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00001be4 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00001bd8 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00001be8 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140025150
// Address: 0x140025150
// Size: 44 bytes
// ============================================================
void fcn.140025150(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012370(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140025180
// Address: 0x140025180
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1b68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ba0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b90h because it doesn't fit into ProtoModel

void fcn.140025180(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1be8);
    puVar2 = *(undefined8 **)(arg2 + 0x1c18);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1c20) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1c10), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1c20) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1c00);
    uVar4 = *(undefined4 *)(arg2 + 0x1bf4);
    uVar5 = *(undefined4 *)(arg2 + 0x1bf8);
    uVar6 = *(undefined4 *)(arg2 + 0x1bfc);
    *puVar1 = *(undefined4 *)(arg2 + 0x1bf0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_1400251f0
// Address: 0x1400251f0
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1508h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1518h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14e0h because it doesn't fit into ProtoModel

void fcn.1400251f0(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400251fd;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001520 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025225;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x1500);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002523c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x14d0);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025324;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x000014f8 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x000014e8 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x000014ec + iVar9) = uVar5;
        *(undefined4 *)(&stack0x000014f0 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x000014f4 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00001508 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001518 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001510 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x000014e0 + iVar9) = *(int64_t *)(&stack0x00001510 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400252dc;
                (*pcVar3)(*(undefined8 *)(&stack0x00001508 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001518 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001510 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001518 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025307;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00001508 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x000014ec + iVar9);
        uVar6 = *(undefined4 *)(&stack0x000014f0 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x000014f4 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x000014e8 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x000014f8 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140025330
// Address: 0x140025330
// Size: 44 bytes
// ============================================================
void fcn.140025330(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012670(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140025360
// Address: 0x140025360
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_14a0h because it doesn't fit into ProtoModel

void fcn.140025360(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x14f8);
    puVar2 = *(undefined8 **)(arg2 + 0x1528);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1530) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1520), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1530) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1510);
    uVar4 = *(undefined4 *)(arg2 + 0x1504);
    uVar5 = *(undefined4 *)(arg2 + 0x1508);
    uVar6 = *(undefined4 *)(arg2 + 0x150c);
    *puVar1 = *(undefined4 *)(arg2 + 0x1500);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_1400253d0
// Address: 0x1400253d0
// Size: 304 bytes
// ============================================================
void fcn.1400253d0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_f00h;
    int64_t var_ea8h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0xed0);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_f00h, arg1 + 0x30, 0xea0);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_f00h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_140025500
// Address: 0x140025500
// Size: 44 bytes
// ============================================================
void fcn.140025500(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.1400122b0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140025530
// Address: 0x140025530
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e70h because it doesn't fit into ProtoModel

void fcn.140025530(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0xec8);
    puVar2 = *(undefined8 **)(arg2 + 0xef8);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0xf00) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xef0), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0xf00) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0xee0);
    uVar4 = *(undefined4 *)(arg2 + 0xed4);
    uVar5 = *(undefined4 *)(arg2 + 0xed8);
    uVar6 = *(undefined4 *)(arg2 + 0xedc);
    *puVar1 = *(undefined4 *)(arg2 + 0xed0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_1400255a0
// Address: 0x1400255a0
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1368h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel

void fcn.1400255a0(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400255ad;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x000013a0 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400255d5;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x1380);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400255ec;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x1350);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400256d4;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00001378 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00001368 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x0000136c + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00001370 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00001374 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00001388 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001398 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001390 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00001360 + iVar9) = *(int64_t *)(&stack0x00001390 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002568c;
                (*pcVar3)(*(undefined8 *)(&stack0x00001388 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001398 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001390 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001398 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400256b7;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00001388 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x0000136c + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00001370 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00001374 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00001368 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00001378 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_1400256e0
// Address: 0x1400256e0
// Size: 44 bytes
// ============================================================
void fcn.1400256e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012af0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140025710
// Address: 0x140025710
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1310h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1320h because it doesn't fit into ProtoModel

void fcn.140025710(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1378);
    puVar2 = *(undefined8 **)(arg2 + 0x13a8);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x13b0) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x13a0), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x13b0) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1390);
    uVar4 = *(undefined4 *)(arg2 + 0x1384);
    uVar5 = *(undefined4 *)(arg2 + 5000);
    uVar6 = *(undefined4 *)(arg2 + 0x138c);
    *puVar1 = *(undefined4 *)(arg2 + 0x1380);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140025780
// Address: 0x140025780
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1880h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1868h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1878h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1870h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1840h because it doesn't fit into ProtoModel

void fcn.140025780(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x14002578d;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001880 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400257b5;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x1860);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400257cc;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x1830);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400258b4;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00001858 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00001848 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x0000184c + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00001850 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00001854 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00001868 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001878 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001870 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00001840 + iVar9) = *(int64_t *)(&stack0x00001870 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002586c;
                (*pcVar3)(*(undefined8 *)(&stack0x00001868 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001878 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001870 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001878 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025897;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00001868 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x0000184c + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00001850 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00001854 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00001848 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00001858 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_1400258c0
// Address: 0x1400258c0
// Size: 44 bytes
// ============================================================
void fcn.1400258c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012130(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_1400258f0
// Address: 0x1400258f0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_17d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1808h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1810h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1800h because it doesn't fit into ProtoModel

void fcn.1400258f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1858);
    puVar2 = *(undefined8 **)(arg2 + 0x1888);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1890) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1880), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1890) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1870);
    uVar4 = *(undefined4 *)(arg2 + 0x1864);
    uVar5 = *(undefined4 *)(arg2 + 0x1868);
    uVar6 = *(undefined4 *)(arg2 + 0x186c);
    *puVar1 = *(undefined4 *)(arg2 + 0x1860);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140025960
// Address: 0x140025960
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel

void fcn.140025960(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x14002596d;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001010 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025995;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0xff0);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400259ac;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0xfc0);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025a94;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00000fe8 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00000fd8 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x00000fdc + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00000fe0 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00000fe4 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00000ff8 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001008 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001000 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00000fd0 + iVar9) = *(int64_t *)(&stack0x00001000 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025a4c;
                (*pcVar3)(*(undefined8 *)(&stack0x00000ff8 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001008 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001000 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001008 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025a77;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00000ff8 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x00000fdc + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00000fe0 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00000fe4 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00000fd8 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00000fe8 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140025aa0
// Address: 0x140025aa0
// Size: 44 bytes
// ============================================================
void fcn.140025aa0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012f70(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140025ad0
// Address: 0x140025ad0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f90h because it doesn't fit into ProtoModel

void fcn.140025ad0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0xfe8);
    puVar2 = *(undefined8 **)(arg2 + 0x1018);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1020) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1010), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1020) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1000);
    uVar4 = *(undefined4 *)(arg2 + 0xff4);
    uVar5 = *(undefined4 *)(arg2 + 0xff8);
    uVar6 = *(undefined4 *)(arg2 + 0xffc);
    *puVar1 = *(undefined4 *)(arg2 + 0xff0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140025b40
// Address: 0x140025b40
// Size: 304 bytes
// ============================================================
void fcn.140025b40(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_fc0h;
    int64_t var_f68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0xf90);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_fc0h, arg1 + 0x30, 0xf60);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_fc0h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_140025c70
// Address: 0x140025c70
// Size: 44 bytes
// ============================================================
void fcn.140025c70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140013030(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140025ca0
// Address: 0x140025ca0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f30h because it doesn't fit into ProtoModel

void fcn.140025ca0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0xf88);
    puVar2 = *(undefined8 **)(arg2 + 0xfb8);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0xfc0) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xfb0), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0xfc0) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 4000);
    uVar4 = *(undefined4 *)(arg2 + 0xf94);
    uVar5 = *(undefined4 *)(arg2 + 0xf98);
    uVar6 = *(undefined4 *)(arg2 + 0xf9c);
    *puVar1 = *(undefined4 *)(arg2 + 0xf90);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140025d10
// Address: 0x140025d10
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1430h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1408h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1420h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel

void fcn.140025d10(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x140025d1d;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001430 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025d45;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x1410);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025d5c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x13e0);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025e44;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00001408 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x000013f8 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x000013fc + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00001400 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00001404 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00001418 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001428 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001420 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x000013f0 + iVar9) = *(int64_t *)(&stack0x00001420 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025dfc;
                (*pcVar3)(*(undefined8 *)(&stack0x00001418 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001428 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001420 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001428 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025e27;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00001418 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x000013fc + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00001400 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00001404 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x000013f8 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00001408 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140025e50
// Address: 0x140025e50
// Size: 44 bytes
// ============================================================
void fcn.140025e50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012970(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140025e80
// Address: 0x140025e80
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b0h because it doesn't fit into ProtoModel

void fcn.140025e80(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1408);
    puVar2 = *(undefined8 **)(arg2 + 0x1438);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1440) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1430), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1440) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1420);
    uVar4 = *(undefined4 *)(arg2 + 0x1414);
    uVar5 = *(undefined4 *)(arg2 + 0x1418);
    uVar6 = *(undefined4 *)(arg2 + 0x141c);
    *puVar1 = *(undefined4 *)(arg2 + 0x1410);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140025ef0
// Address: 0x140025ef0
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1900h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18d0h because it doesn't fit into ProtoModel

void fcn.140025ef0(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x140025efd;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001910 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025f25;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x18f0);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025f3c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x18c0);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026024;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x000018e8 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x000018d8 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x000018dc + iVar9) = uVar5;
        *(undefined4 *)(&stack0x000018e0 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x000018e4 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x000018f8 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001908 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001900 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x000018d0 + iVar9) = *(int64_t *)(&stack0x00001900 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140025fdc;
                (*pcVar3)(*(undefined8 *)(&stack0x000018f8 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001908 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001900 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001908 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026007;
                fcn.1404d3c50(*(undefined8 *)(&stack0x000018f8 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x000018dc + iVar9);
        uVar6 = *(undefined4 *)(&stack0x000018e0 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x000018e4 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x000018d8 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x000018e8 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140026030
// Address: 0x140026030
// Size: 44 bytes
// ============================================================
void fcn.140026030(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012c70(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140026060
// Address: 0x140026060
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1868h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1898h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1880h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1870h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1890h because it doesn't fit into ProtoModel

void fcn.140026060(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x18e8);
    puVar2 = *(undefined8 **)(arg2 + 0x1918);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1920) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1910), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1920) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1900);
    uVar4 = *(undefined4 *)(arg2 + 0x18f4);
    uVar5 = *(undefined4 *)(arg2 + 0x18f8);
    uVar6 = *(undefined4 *)(arg2 + 0x18fc);
    *puVar1 = *(undefined4 *)(arg2 + 0x18f0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_1400260d0
// Address: 0x1400260d0
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel

void fcn.1400260d0(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400260dd;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001400 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026105;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x13e0);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002611c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x13b0);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026204;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x000013d8 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x000013c8 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x000013cc + iVar9) = uVar5;
        *(undefined4 *)(&stack0x000013d0 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x000013d4 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x000013e8 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x000013f8 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x000013f0 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x000013c0 + iVar9) = *(int64_t *)(&stack0x000013f0 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400261bc;
                (*pcVar3)(*(undefined8 *)(&stack0x000013e8 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x000013f8 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x000013f0 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x000013f8 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400261e7;
                fcn.1404d3c50(*(undefined8 *)(&stack0x000013e8 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x000013cc + iVar9);
        uVar6 = *(undefined4 *)(&stack0x000013d0 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x000013d4 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x000013c8 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x000013d8 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140026210
// Address: 0x140026210
// Size: 44 bytes
// ============================================================
void fcn.140026210(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012a30(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140026240
// Address: 0x140026240
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel

void fcn.140026240(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x13d8);
    puVar2 = *(undefined8 **)(arg2 + 0x1408);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1410) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1400), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1410) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x13f0);
    uVar4 = *(undefined4 *)(arg2 + 0x13e4);
    uVar5 = *(undefined4 *)(arg2 + 0x13e8);
    uVar6 = *(undefined4 *)(arg2 + 0x13ec);
    *puVar1 = *(undefined4 *)(arg2 + 0x13e0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_1400262b0
// Address: 0x1400262b0
// Size: 304 bytes
// ============================================================
void fcn.1400262b0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_7c0h;
    int64_t var_768h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0x790);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_7c0h, arg1 + 0x30, 0x760);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_7c0h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_1400263e0
// Address: 0x1400263e0
// Size: 44 bytes
// ============================================================
void fcn.1400263e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140002f50(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140026410
// Address: 0x140026410
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_708h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_738h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_740h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_730h because it doesn't fit into ProtoModel

void fcn.140026410(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x788);
    puVar2 = *(undefined8 **)(arg2 + 0x7b8);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x7c0) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x7b0), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x7c0) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x7a0);
    uVar4 = *(undefined4 *)(arg2 + 0x794);
    uVar5 = *(undefined4 *)(arg2 + 0x798);
    uVar6 = *(undefined4 *)(arg2 + 0x79c);
    *puVar1 = *(undefined4 *)(arg2 + 0x790);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140026480
// Address: 0x140026480
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel

void fcn.140026480(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x14002648d;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x000013d0 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400264b5;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x13b0);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400264cc;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x1380);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1400265b4;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x000013a8 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00001398 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x0000139c + iVar9) = uVar5;
        *(undefined4 *)(&stack0x000013a0 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x000013a4 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x000013b8 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x000013c8 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x000013c0 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00001390 + iVar9) = *(int64_t *)(&stack0x000013c0 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002656c;
                (*pcVar3)(*(undefined8 *)(&stack0x000013b8 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x000013c8 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x000013c0 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x000013c8 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026597;
                fcn.1404d3c50(*(undefined8 *)(&stack0x000013b8 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x0000139c + iVar9);
        uVar6 = *(undefined4 *)(&stack0x000013a0 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x000013a4 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00001398 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x000013a8 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_1400265c0
// Address: 0x1400265c0
// Size: 44 bytes
// ============================================================
void fcn.1400265c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012070(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_1400265f0
// Address: 0x1400265f0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1328h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1358h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1360h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1350h because it doesn't fit into ProtoModel

void fcn.1400265f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x13a8);
    puVar2 = *(undefined8 **)(arg2 + 0x13d8);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x13e0) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x13d0), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x13e0) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x13c0);
    uVar4 = *(undefined4 *)(arg2 + 0x13b4);
    uVar5 = *(undefined4 *)(arg2 + 0x13b8);
    uVar6 = *(undefined4 *)(arg2 + 0x13bc);
    *puVar1 = *(undefined4 *)(arg2 + 0x13b0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140026660
// Address: 0x140026660
// Size: 304 bytes
// ============================================================
void fcn.140026660(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_760h;
    int64_t var_708h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = -2;
    cVar1 = fcn.140799610(arg1, arg1 + 0x730);
    if (cVar1 != '\0') {
        fcn.140951cf0(&var_760h, arg1 + 0x30, 0x700);
        *(undefined4 *)(arg1 + 0x30) = 2;
        if ((int32_t)var_760h != 1) {
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        var_48h = *(int64_t *)(arg1 + 0x48);
        var_58h._0_4_ = *(undefined4 *)(arg1 + 0x38);
        var_58h._4_4_ = *(undefined4 *)(arg1 + 0x3c);
        uStack_50 = *(undefined4 *)(arg1 + 0x40);
        uStack_4c = *(undefined4 *)(arg1 + 0x44);
        if (((*(char *)arg2 == '\0') && (*(int64_t *)(arg2 + 8) != 0)) &&
           (var_38h = *(int64_t *)(arg2 + 0x10), var_38h != 0)) {
            var_28h = *(undefined8 *)(arg2 + 0x18);
            var_30h = arg2;
            if (*(code **)var_28h != (code *)0x0) {
                var_60h = arg2 + 8;
                (**(code **)var_28h)(var_38h);
            }
            arg2 = var_30h;
            if (*(int64_t *)(var_28h + 8) != 0) {
                fcn.1404d3c50(var_38h, *(int64_t *)(var_28h + 8), *(undefined8 *)(var_28h + 0x10));
            }
        }
        *(undefined8 *)arg2 = 0;
        *(undefined4 *)(arg2 + 8) = (undefined4)var_58h;
        *(undefined4 *)(arg2 + 0xc) = var_58h._4_4_;
        *(undefined4 *)(arg2 + 0x10) = uStack_50;
        *(undefined4 *)(arg2 + 0x14) = uStack_4c;
        *(int64_t *)(arg2 + 0x18) = var_48h;
    }
    return;
}

// ============================================================
// Function: FUN_140026790
// Address: 0x140026790
// Size: 44 bytes
// ============================================================
void fcn.140026790(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140002010(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_1400267c0
// Address: 0x1400267c0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_6a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6d0h because it doesn't fit into ProtoModel

void fcn.1400267c0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x728);
    puVar2 = *(undefined8 **)(arg2 + 0x758);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x760) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x750), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x760) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x740);
    uVar4 = *(undefined4 *)(arg2 + 0x734);
    uVar5 = *(undefined4 *)(arg2 + 0x738);
    uVar6 = *(undefined4 *)(arg2 + 0x73c);
    *puVar1 = *(undefined4 *)(arg2 + 0x730);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140026830
// Address: 0x140026830
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1010h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1008h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1000h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fd0h because it doesn't fit into ProtoModel

void fcn.140026830(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x14002683d;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001010 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026865;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0xff0);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002687c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0xfc0);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026964;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00000fe8 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00000fd8 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x00000fdc + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00000fe0 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00000fe4 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00000ff8 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001008 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001000 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00000fd0 + iVar9) = *(int64_t *)(&stack0x00001000 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x14002691c;
                (*pcVar3)(*(undefined8 *)(&stack0x00000ff8 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001008 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001000 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001008 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026947;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00000ff8 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x00000fdc + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00000fe0 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00000fe4 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00000fd8 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00000fe8 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140026970
// Address: 0x140026970
// Size: 44 bytes
// ============================================================
void fcn.140026970(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.1400131b0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_1400269a0
// Address: 0x1400269a0
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f98h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f90h because it doesn't fit into ProtoModel

void fcn.1400269a0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0xfe8);
    puVar2 = *(undefined8 **)(arg2 + 0x1018);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1020) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1010), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1020) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1000);
    uVar4 = *(undefined4 *)(arg2 + 0xff4);
    uVar5 = *(undefined4 *)(arg2 + 0xff8);
    uVar6 = *(undefined4 *)(arg2 + 0xffc);
    *puVar1 = *(undefined4 *)(arg2 + 0xff0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140026a10
// Address: 0x140026a10
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1d00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc0h because it doesn't fit into ProtoModel

void fcn.140026a10(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x140026a1d;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001d00 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026a45;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x1ce0);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026a5c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x1cb0);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026b44;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00001cd8 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00001cc8 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x00001ccc + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00001cd0 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00001cd4 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00001ce8 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001cf8 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001cf0 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00001cc0 + iVar9) = *(int64_t *)(&stack0x00001cf0 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026afc;
                (*pcVar3)(*(undefined8 *)(&stack0x00001ce8 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001cf8 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001cf0 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001cf8 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026b27;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00001ce8 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x00001ccc + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00001cd0 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00001cd4 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00001cc8 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00001cd8 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140026b50
// Address: 0x140026b50
// Size: 44 bytes
// ============================================================
void fcn.140026b50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.140012bb0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140026b80
// Address: 0x140026b80
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1c58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel

void fcn.140026b80(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x1cd8);
    puVar2 = *(undefined8 **)(arg2 + 0x1d08);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x1d10) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1d00), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x1d10) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x1cf0);
    uVar4 = *(undefined4 *)(arg2 + 0x1ce4);
    uVar5 = *(undefined4 *)(arg2 + 0x1ce8);
    uVar6 = *(undefined4 *)(arg2 + 0x1cec);
    *puVar1 = *(undefined4 *)(arg2 + 0x1ce0);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140026bf0
// Address: 0x140026bf0
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2e70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e30h because it doesn't fit into ProtoModel

void fcn.140026bf0(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x140026bfd;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00002e70 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026c25;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x2e50);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026c3c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x2e20);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026d24;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00002e48 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00002e38 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x00002e3c + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00002e40 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00002e44 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00002e58 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00002e68 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00002e60 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00002e30 + iVar9) = *(int64_t *)(&stack0x00002e60 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026cdc;
                (*pcVar3)(*(undefined8 *)(&stack0x00002e58 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00002e68 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00002e60 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00002e68 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026d07;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00002e58 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x00002e3c + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00002e40 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00002e44 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00002e38 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00002e48 + iVar9);
    }
    return;
}

// ============================================================
// Function: FUN_140026d30
// Address: 0x140026d30
// Size: 44 bytes
// ============================================================
void fcn.140026d30(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(int32_t *)(arg2 + 0x28) != 1) {
        fcn.14000cee0(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_140026d60
// Address: 0x140026d60
// Size: 108 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2dc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2df8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2de0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2dd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2df0h because it doesn't fit into ProtoModel

void fcn.140026d60(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t var_10h;
    
    puVar1 = *(undefined4 **)(arg2 + 0x2e48);
    puVar2 = *(undefined8 **)(arg2 + 0x2e78);
    iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x2e80) + 8);
    if (iVar3 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x2e70), iVar3, *(undefined8 *)(*(int64_t *)(arg2 + 0x2e80) + 0x10));
    }
    *puVar2 = 0;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(arg2 + 0x2e60);
    uVar4 = *(undefined4 *)(arg2 + 0x2e54);
    uVar5 = *(undefined4 *)(arg2 + 0x2e58);
    uVar6 = *(undefined4 *)(arg2 + 0x2e5c);
    *puVar1 = *(undefined4 *)(arg2 + 0x2e50);
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_140026dd0
// Address: 0x140026dd0
// Size: 310 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1d00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cc0h because it doesn't fit into ProtoModel

void fcn.140026dd0(int64_t arg_68h)
{
    int64_t iVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    char cVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x140026ddd;
    iVar9 = fcn.14094c690();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00001d00 + iVar9) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026e05;
    cVar8 = fcn.140799610(extraout_XMM0_Da, in_RCX + 0x1ce0);
    if (cVar8 != '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026e1c;
        fcn.140951cf0((int64_t)&var_10h + iVar9, in_RCX + 0x30, 0x1cb0);
        *(undefined4 *)(in_RCX + 0x30) = 2;
        if (*(int32_t *)((int64_t)&var_10h + iVar9) != 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026f04;
            fcn.1409788a0(0x14097a000, 0x45, 0x14097a090);
            do {
                invalidInstructionException();
            } while( true );
        }
        *(undefined8 *)(&stack0x00001cd8 + iVar9) = *(undefined8 *)(in_RCX + 0x48);
        uVar5 = *(undefined4 *)(in_RCX + 0x3c);
        uVar6 = *(undefined4 *)(in_RCX + 0x40);
        uVar7 = *(undefined4 *)(in_RCX + 0x44);
        *(undefined4 *)(&stack0x00001cc8 + iVar9) = *(undefined4 *)(in_RCX + 0x38);
        *(undefined4 *)(&stack0x00001ccc + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00001cd0 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00001cd4 + iVar9) = uVar7;
        if (((*(char *)in_RDX == '\0') && (in_RDX[1] != 0)) &&
           (iVar1 = in_RDX[2], *(int64_t *)(&stack0x00001ce8 + iVar9) = iVar1, iVar1 != 0)) {
            ppcVar2 = (code **)in_RDX[3];
            *(code ***)(&stack0x00001cf8 + iVar9) = ppcVar2;
            pcVar3 = *ppcVar2;
            *(undefined8 **)(&stack0x00001cf0 + iVar9) = in_RDX;
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)(&stack0x00001cc0 + iVar9) = *(int64_t *)(&stack0x00001cf0 + iVar9) + 8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026ebc;
                (*pcVar3)(*(undefined8 *)(&stack0x00001ce8 + iVar9));
            }
            iVar1 = *(int64_t *)(*(int64_t *)(&stack0x00001cf8 + iVar9) + 8);
            in_RDX = *(undefined8 **)(&stack0x00001cf0 + iVar9);
            if (iVar1 != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(&stack0x00001cf8 + iVar9) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x140026ee7;
                fcn.1404d3c50(*(undefined8 *)(&stack0x00001ce8 + iVar9), iVar1, uVar4);
            }
        }
        *in_RDX = 0;
        uVar5 = *(undefined4 *)(&stack0x00001ccc + iVar9);
        uVar6 = *(undefined4 *)(&stack0x00001cd0 + iVar9);
        uVar7 = *(undefined4 *)(&stack0x00001cd4 + iVar9);
        *(undefined4 *)(in_RDX + 1) = *(undefined4 *)(&stack0x00001cc8 + iVar9);
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
        *(undefined4 *)(in_RDX + 2) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0x14) = uVar7;
        in_RDX[3] = *(undefined8 *)(&stack0x00001cd8 + iVar9);
    }
    return;
}

