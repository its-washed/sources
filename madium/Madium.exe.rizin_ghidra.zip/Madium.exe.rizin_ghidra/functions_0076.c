// Chunk 76 - 50 functions

// ============================================================
// Function: FUN_140056360
// Address: 0x140056360
// Size: 505 bytes
// ============================================================
void fcn.140056360(int64_t var_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_a8h, int64_t arg_128h, int64_t arg_130h
                  , int64_t arg_138h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h, int64_t arg_160h,
                  int64_t arg_168h, int64_t arg_170h, int64_t arg_178h, int64_t arg_180h, int64_t arg_198h,
                  int64_t arg_1b0h, int64_t arg_1c0h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_76b7ff08h;
    int64_t var_3bd6b798h;
    int64_t var_7e0h;
    int64_t var_788h;
    int64_t var_360h;
    int64_t var_348h;
    int64_t var_1a8h;
    int64_t var_150h;
    int64_t var_48h;
    int64_t var_30h;
    undefined8 uStack_20;
    int64_t var_18h;
    int64_t var_8h;
    
    uStack_20 = 0x14005636d;
    iVar2 = func_0x00014094c690();
    *(undefined8 *)(&stack0x00001e90 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14005638b;
    uVar1 = func_0x000140797b10();
    // WARNING: Could not recover jumptable at 0x00014005639c. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (512 cases) at 0x14097b264
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b264) + 0x14097b264))();
    return;
}

// ============================================================
// Function: FUN_140056560
// Address: 0x140056560
// Size: 37 bytes
// ============================================================
void fcn.140056560(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140056590
// Address: 0x140056590
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_ed8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140056590(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xf58) = 2;
    fcn.14011d460(*(undefined8 *)(arg2 + 0x1ea0), arg2 + 0xf58);
    return;
}

// ============================================================
// Function: FUN_1400565d0
// Address: 0x1400565d0
// Size: 25 bytes
// ============================================================
void fcn.1400565d0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400565f0
// Address: 0x1400565f0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.1400565f0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1eb8));
    *(undefined8 *)(arg2 + 0x1e88) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140056487;
}

// ============================================================
// Function: FUN_140056630
// Address: 0x140056630
// Size: 25 bytes
// ============================================================
void fcn.140056630(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140056650
// Address: 0x140056650
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140056650(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1e88) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140056487;
}

// ============================================================
// Function: FUN_140056690
// Address: 0x140056690
// Size: 25 bytes
// ============================================================
void fcn.140056690(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400566b0
// Address: 0x1400566b0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.1400566b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1eb0));
    *(undefined8 *)(arg2 + 0x1ea0) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140056507;
}

// ============================================================
// Function: FUN_1400566f0
// Address: 0x1400566f0
// Size: 25 bytes
// ============================================================
void fcn.1400566f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140056710
// Address: 0x140056710
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel

undefined8 fcn.140056710(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1ea0) = uVar1;
    *(int64_t *)(arg2 + 0x1e98) = iVar2;
    return 0x140056507;
}

// ============================================================
// Function: FUN_140056750
// Address: 0x140056750
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1e18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1e20h because it doesn't fit into ProtoModel

void fcn.140056750(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1e98) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1ea0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1e98) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_1400567a0
// Address: 0x1400567a0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1fb0h because it doesn't fit into ProtoModel

void fcn.1400567a0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x1400567ad;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x00001fb0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x1400567cb;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x0001400567dc. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b284) + 0x14097b284))();
    return;
}

// ============================================================
// Function: FUN_1400569a0
// Address: 0x1400569a0
// Size: 37 bytes
// ============================================================
void fcn.1400569a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1400569d0
// Address: 0x1400569d0
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400569d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0xfe8) = 2;
    fcn.14011edb0(*(undefined8 *)(arg2 + 0x1fc0), arg2 + 0xfe8);
    return;
}

// ============================================================
// Function: FUN_140056a10
// Address: 0x140056a10
// Size: 25 bytes
// ============================================================
void fcn.140056a10(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140056a30
// Address: 0x140056a30
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.140056a30(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1fd8));
    *(undefined8 *)(arg2 + 0x1fa8) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x1400568c7;
}

// ============================================================
// Function: FUN_140056a70
// Address: 0x140056a70
// Size: 25 bytes
// ============================================================
void fcn.140056a70(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140056a90
// Address: 0x140056a90
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f28h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.140056a90(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1fa8) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x1400568c7;
}

// ============================================================
// Function: FUN_140056ad0
// Address: 0x140056ad0
// Size: 25 bytes
// ============================================================
void fcn.140056ad0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140056af0
// Address: 0x140056af0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.140056af0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1fd0));
    *(undefined8 *)(arg2 + 0x1fc0) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x140056947;
}

// ============================================================
// Function: FUN_140056b30
// Address: 0x140056b30
// Size: 25 bytes
// ============================================================
void fcn.140056b30(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140056b50
// Address: 0x140056b50
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel

undefined8 fcn.140056b50(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1fc0) = uVar1;
    *(int64_t *)(arg2 + 0x1fb8) = iVar2;
    return 0x140056947;
}

// ============================================================
// Function: FUN_140056b90
// Address: 0x140056b90
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1f38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1f40h because it doesn't fit into ProtoModel

void fcn.140056b90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1fb8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1fc0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1fb8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140056be0
// Address: 0x140056be0
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.140056be0(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x140056bed;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x140056c0b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140056c1c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b2a4) + 0x14097b2a4))();
    return;
}

// ============================================================
// Function: FUN_140056de0
// Address: 0x140056de0
// Size: 37 bytes
// ============================================================
void fcn.140056de0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140056e10
// Address: 0x140056e10
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140056e10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011da20(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140056e50
// Address: 0x140056e50
// Size: 25 bytes
// ============================================================
void fcn.140056e50(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140056e70
// Address: 0x140056e70
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140056e70(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140056d07;
}

// ============================================================
// Function: FUN_140056eb0
// Address: 0x140056eb0
// Size: 25 bytes
// ============================================================
void fcn.140056eb0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140056ed0
// Address: 0x140056ed0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140056ed0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140056d07;
}

// ============================================================
// Function: FUN_140056f10
// Address: 0x140056f10
// Size: 25 bytes
// ============================================================
void fcn.140056f10(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140056f30
// Address: 0x140056f30
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140056f30(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140056d87;
}

// ============================================================
// Function: FUN_140056f70
// Address: 0x140056f70
// Size: 25 bytes
// ============================================================
void fcn.140056f70(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140056f90
// Address: 0x140056f90
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140056f90(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140056d87;
}

// ============================================================
// Function: FUN_140056fd0
// Address: 0x140056fd0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel

void fcn.140056fd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140057020
// Address: 0x140057020
// Size: 505 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d0h because it doesn't fit into ProtoModel

void fcn.140057020(int64_t arg_68h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_20;
    
    uStack_20 = 0x14005702d;
    iVar2 = fcn.14094c690();
    *(undefined8 *)(&stack0x000026d0 + -iVar2) = 0xfffffffffffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x14005704b;
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x00014005705c. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b2c4) + 0x14097b2c4))();
    return;
}

// ============================================================
// Function: FUN_140057220
// Address: 0x140057220
// Size: 37 bytes
// ============================================================
void fcn.140057220(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140796f10(arg2 + 0x28);
    return;
}

// ============================================================
// Function: FUN_140057250
// Address: 0x140057250
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140057250(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    *(undefined4 *)(arg2 + 0x1378) = 2;
    fcn.14011da20(*(undefined8 *)(arg2 + 0x26e0), arg2 + 0x1378);
    return;
}

// ============================================================
// Function: FUN_140057290
// Address: 0x140057290
// Size: 25 bytes
// ============================================================
void fcn.140057290(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400572b0
// Address: 0x1400572b0
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400572b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f8));
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140057147;
}

// ============================================================
// Function: FUN_1400572f0
// Address: 0x1400572f0
// Size: 25 bytes
// ============================================================
void fcn.1400572f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140057310
// Address: 0x140057310
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2648h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140057310(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26c8) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140057147;
}

// ============================================================
// Function: FUN_140057350
// Address: 0x140057350
// Size: 25 bytes
// ============================================================
void fcn.140057350(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140057370
// Address: 0x140057370
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2670h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140057370(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26f0));
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400571c7;
}

// ============================================================
// Function: FUN_1400573b0
// Address: 0x1400573b0
// Size: 25 bytes
// ============================================================
void fcn.1400573b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400573d0
// Address: 0x1400573d0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.1400573d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26e0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x1400571c7;
}

// ============================================================
// Function: FUN_140057410
// Address: 0x140057410
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

void fcn.140057410(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x26d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x26e0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x26d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_140057460
// Address: 0x140057460
// Size: 526 bytes
// ============================================================
void fcn.140057460(int64_t arg1)
{
    uint8_t uVar1;
    int64_t var_788h;
    int64_t var_28h;
    
    uVar1 = fcn.140797b10();
    // WARNING: Could not recover jumptable at 0x000140057495. Too many branches
    // WARNING: Treating indirect jump as call
    (*(code *)((int64_t)*(int32_t *)((uint64_t)uVar1 * 4 + 0x14097b2e4) + 0x14097b2e4))();
    return;
}

// ============================================================
// Function: FUN_140057670
// Address: 0x140057670
// Size: 49 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_750h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140057670(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_60h;
    
    *(undefined4 *)(arg2 + 0x20) = 2;
    fcn.14011e150(*(undefined8 *)(arg2 + 2000), arg2 + 0x20);
    return;
}

