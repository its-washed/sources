// Chunk 28 - 50 functions

// ============================================================
// Function: FUN_140020500
// Address: 0x140020500
// Size: 23 bytes
// ============================================================
void fcn.140020500(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020520
// Address: 0x140020520
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b8h because it doesn't fit into ProtoModel

undefined8 fcn.140020520(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2748));
    *(undefined8 *)(arg2 + 0x2730) = uVar1;
    *(int64_t *)(arg2 + 0x2738) = iVar2;
    return 0x1400204ea;
}

// ============================================================
// Function: FUN_140020560
// Address: 0x140020560
// Size: 23 bytes
// ============================================================
void fcn.140020560(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020580
// Address: 0x140020580
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26b8h because it doesn't fit into ProtoModel

undefined8 fcn.140020580(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2730) = uVar1;
    *(int64_t *)(arg2 + 0x2738) = iVar2;
    return 0x1400204ea;
}

// ============================================================
// Function: FUN_1400205c0
// Address: 0x1400205c0
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_38d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_38c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c88h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400205c0(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1400205cb;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000038d8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000038c0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400205f8;
    fcn.14011faa0();
    *(undefined8 *)(&stack0x00001c78 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000038c0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00001c80 + iVar1) = 0;
    *(undefined8 *)(&stack0x00001c88 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00001c70 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020630;
    fcn.14011faa0(*(int64_t *)(&stack0x000038c0 + iVar1), &stack0x00001c70 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140020650
// Address: 0x140020650
// Size: 23 bytes
// ============================================================
void fcn.140020650(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020670
// Address: 0x140020670
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3868h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3858h because it doesn't fit into ProtoModel

undefined8 fcn.140020670(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x38e8));
    *(undefined8 *)(arg2 + 0x38d0) = uVar1;
    *(int64_t *)(arg2 + 0x38d8) = iVar2;
    return 0x14002063a;
}

// ============================================================
// Function: FUN_1400206b0
// Address: 0x1400206b0
// Size: 23 bytes
// ============================================================
void fcn.1400206b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400206d0
// Address: 0x1400206d0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3850h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3858h because it doesn't fit into ProtoModel

undefined8 fcn.1400206d0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x38d0) = uVar1;
    *(int64_t *)(arg2 + 0x38d8) = iVar2;
    return 0x14002063a;
}

// ============================================================
// Function: FUN_140020710
// Address: 0x140020710
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_31b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_31a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_18e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140020710(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002071b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000031b8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000031a0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020748;
    fcn.14011ead0();
    *(undefined8 *)(&stack0x000018e8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000031a0 + iVar1) + 8);
    *(undefined8 *)(&stack0x000018f0 + iVar1) = 0;
    *(undefined8 *)(&stack0x000018f8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x000018e0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020780;
    fcn.14011ead0(*(int64_t *)(&stack0x000031a0 + iVar1), &stack0x000018e0 + iVar1);
    return;
}

// ============================================================
// Function: FUN_1400207a0
// Address: 0x1400207a0
// Size: 23 bytes
// ============================================================
void fcn.1400207a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400207c0
// Address: 0x1400207c0
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3148h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3130h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3138h because it doesn't fit into ProtoModel

undefined8 fcn.1400207c0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x31c8));
    *(undefined8 *)(arg2 + 0x31b0) = uVar1;
    *(int64_t *)(arg2 + 0x31b8) = iVar2;
    return 0x14002078a;
}

// ============================================================
// Function: FUN_140020800
// Address: 0x140020800
// Size: 23 bytes
// ============================================================
void fcn.140020800(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020820
// Address: 0x140020820
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3130h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3138h because it doesn't fit into ProtoModel

undefined8 fcn.140020820(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x31b0) = uVar1;
    *(int64_t *)(arg2 + 0x31b8) = iVar2;
    return 0x14002078a;
}

// ============================================================
// Function: FUN_140020860
// Address: 0x140020860
// Size: 132 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140020860(int64_t arg1)
{
    int64_t var_380h;
    int64_t var_328h;
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_30h;
    int64_t var_18h;
    
    var_18h = -2;
    var_30h = arg1;
    fcn.140120700();
    var_1d0h = *(int64_t *)(var_30h + 8);
    var_1c8h = 0;
    var_1d8h._0_4_ = 1;
    fcn.140120700(var_30h, &var_1d8h);
    return;
}

// ============================================================
// Function: FUN_1400208f0
// Address: 0x1400208f0
// Size: 23 bytes
// ============================================================
void fcn.1400208f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020910
// Address: 0x140020910
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_308h because it doesn't fit into ProtoModel

undefined8 fcn.140020910(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x398));
    *(undefined8 *)(arg2 + 0x380) = uVar1;
    *(int64_t *)(arg2 + 0x388) = iVar2;
    return 0x1400208d4;
}

// ============================================================
// Function: FUN_140020950
// Address: 0x140020950
// Size: 23 bytes
// ============================================================
void fcn.140020950(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020970
// Address: 0x140020970
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_300h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_308h because it doesn't fit into ProtoModel

undefined8 fcn.140020970(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x380) = uVar1;
    *(int64_t *)(arg2 + 0x388) = iVar2;
    return 0x1400208d4;
}

// ============================================================
// Function: FUN_1400209b0
// Address: 0x1400209b0
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1400209b0(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1400209bb;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000013b8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000013a0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400209e8;
    fcn.14011dd00();
    *(undefined8 *)(&stack0x000009e8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000013a0 + iVar1) + 8);
    *(undefined8 *)(&stack0x000009f0 + iVar1) = 0;
    *(undefined8 *)(&stack0x000009f8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x000009e0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020a20;
    fcn.14011dd00(*(int64_t *)(&stack0x000013a0 + iVar1), &stack0x000009e0 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140020a40
// Address: 0x140020a40
// Size: 23 bytes
// ============================================================
void fcn.140020a40(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020a60
// Address: 0x140020a60
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.140020a60(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13c8));
    *(undefined8 *)(arg2 + 0x13b0) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x140020a2a;
}

// ============================================================
// Function: FUN_140020aa0
// Address: 0x140020aa0
// Size: 23 bytes
// ============================================================
void fcn.140020aa0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020ac0
// Address: 0x140020ac0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.140020ac0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x13b0) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x140020a2a;
}

// ============================================================
// Function: FUN_140020b00
// Address: 0x140020b00
// Size: 117 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140020b00(int64_t arg1)
{
    int64_t var_150h;
    int64_t var_f8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_30h;
    int64_t var_18h;
    
    var_18h = -2;
    var_30h = arg1;
    fcn.14011dfe0();
    var_b8h = *(int64_t *)(var_30h + 8);
    var_b0h = 0;
    var_c0h._0_4_ = 1;
    fcn.14011dfe0(var_30h, &var_c0h);
    return;
}

// ============================================================
// Function: FUN_140020b80
// Address: 0x140020b80
// Size: 23 bytes
// ============================================================
void fcn.140020b80(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020ba0
// Address: 0x140020ba0
// Size: 56 bytes
// ============================================================
undefined8 fcn.140020ba0(undefined8 placeholder_0, int64_t arg2, int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e8h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x168));
    *(undefined8 *)(arg2 + 0x150) = uVar1;
    *(int64_t *)(arg2 + 0x158) = iVar2;
    return 0x140020b65;
}

// ============================================================
// Function: FUN_140020be0
// Address: 0x140020be0
// Size: 23 bytes
// ============================================================
void fcn.140020be0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020c00
// Address: 0x140020c00
// Size: 51 bytes
// ============================================================
undefined8 fcn.140020c00(undefined8 placeholder_0, int64_t arg2, int64_t arg_d0h, int64_t arg_d8h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x150) = uVar1;
    *(int64_t *)(arg2 + 0x158) = iVar2;
    return 0x140020b65;
}

// ============================================================
// Function: FUN_140020c40
// Address: 0x140020c40
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_17d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_17c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c00h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_bf0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140020c40(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x140020c4b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000017d8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000017c0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020c78;
    fcn.14011f4e0();
    *(undefined8 *)(&stack0x00000bf8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000017c0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00000c00 + iVar1) = 0;
    *(undefined8 *)(&stack0x00000c08 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00000bf0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020cb0;
    fcn.14011f4e0(*(int64_t *)(&stack0x000017c0 + iVar1), &stack0x00000bf0 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140020cd0
// Address: 0x140020cd0
// Size: 23 bytes
// ============================================================
void fcn.140020cd0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020cf0
// Address: 0x140020cf0
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1768h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1750h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1758h because it doesn't fit into ProtoModel

undefined8 fcn.140020cf0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x17e8));
    *(undefined8 *)(arg2 + 0x17d0) = uVar1;
    *(int64_t *)(arg2 + 0x17d8) = iVar2;
    return 0x140020cba;
}

// ============================================================
// Function: FUN_140020d30
// Address: 0x140020d30
// Size: 23 bytes
// ============================================================
void fcn.140020d30(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020d50
// Address: 0x140020d50
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1750h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1758h because it doesn't fit into ProtoModel

undefined8 fcn.140020d50(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x17d0) = uVar1;
    *(int64_t *)(arg2 + 0x17d8) = iVar2;
    return 0x140020cba;
}

// ============================================================
// Function: FUN_140020d90
// Address: 0x140020d90
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_26d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_26c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1380h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1370h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140020d90(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x140020d9b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x000026d8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x000026c0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020dc8;
    fcn.14011db90();
    *(undefined8 *)(&stack0x00001378 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x000026c0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00001380 + iVar1) = 0;
    *(undefined8 *)(&stack0x00001388 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00001370 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020e00;
    fcn.14011db90(*(int64_t *)(&stack0x000026c0 + iVar1), &stack0x00001370 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140020e20
// Address: 0x140020e20
// Size: 23 bytes
// ============================================================
void fcn.140020e20(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020e40
// Address: 0x140020e40
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140020e40(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x26e8));
    *(undefined8 *)(arg2 + 0x26d0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140020e0a;
}

// ============================================================
// Function: FUN_140020e80
// Address: 0x140020e80
// Size: 23 bytes
// ============================================================
void fcn.140020e80(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020ea0
// Address: 0x140020ea0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2658h because it doesn't fit into ProtoModel

undefined8 fcn.140020ea0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x26d0) = uVar1;
    *(int64_t *)(arg2 + 0x26d8) = iVar2;
    return 0x140020e0a;
}

// ============================================================
// Function: FUN_140020ee0
// Address: 0x140020ee0
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2798h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2780h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140020ee0(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x140020eeb;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00002798 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00002780 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020f18;
    fcn.14011e7f0();
    *(undefined8 *)(&stack0x000013d8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00002780 + iVar1) + 8);
    *(undefined8 *)(&stack0x000013e0 + iVar1) = 0;
    *(undefined8 *)(&stack0x000013e8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x000013d0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140020f50;
    fcn.14011e7f0(*(int64_t *)(&stack0x00002780 + iVar1), &stack0x000013d0 + iVar1);
    return;
}

// ============================================================
// Function: FUN_140020f70
// Address: 0x140020f70
// Size: 23 bytes
// ============================================================
void fcn.140020f70(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020f90
// Address: 0x140020f90
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2728h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2718h because it doesn't fit into ProtoModel

undefined8 fcn.140020f90(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x27a8));
    *(undefined8 *)(arg2 + 0x2790) = uVar1;
    *(int64_t *)(arg2 + 0x2798) = iVar2;
    return 0x140020f5a;
}

// ============================================================
// Function: FUN_140020fd0
// Address: 0x140020fd0
// Size: 23 bytes
// ============================================================
void fcn.140020fd0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140020ff0
// Address: 0x140020ff0
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2710h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2718h because it doesn't fit into ProtoModel

undefined8 fcn.140020ff0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2790) = uVar1;
    *(int64_t *)(arg2 + 0x2798) = iVar2;
    return 0x140020f5a;
}

// ============================================================
// Function: FUN_140021030
// Address: 0x140021030
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3980h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ce8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1cd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140021030(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002103b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00003998 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00003980 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x140021068;
    fcn.14011e230();
    *(undefined8 *)(&stack0x00001cd8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00003980 + iVar1) + 8);
    *(undefined8 *)(&stack0x00001ce0 + iVar1) = 0;
    *(undefined8 *)(&stack0x00001ce8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00001cd0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400210a0;
    fcn.14011e230(*(int64_t *)(&stack0x00003980 + iVar1), &stack0x00001cd0 + iVar1);
    return;
}

// ============================================================
// Function: FUN_1400210c0
// Address: 0x1400210c0
// Size: 23 bytes
// ============================================================
void fcn.1400210c0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1400210e0
// Address: 0x1400210e0
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3928h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3918h because it doesn't fit into ProtoModel

undefined8 fcn.1400210e0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x39a8));
    *(undefined8 *)(arg2 + 0x3990) = uVar1;
    *(int64_t *)(arg2 + 0x3998) = iVar2;
    return 0x1400210aa;
}

// ============================================================
// Function: FUN_140021120
// Address: 0x140021120
// Size: 23 bytes
// ============================================================
void fcn.140021120(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_140021140
// Address: 0x140021140
// Size: 51 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3918h because it doesn't fit into ProtoModel

undefined8 fcn.140021140(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x3990) = uVar1;
    *(int64_t *)(arg2 + 0x3998) = iVar2;
    return 0x1400210aa;
}

// ============================================================
// Function: FUN_140021180
// Address: 0x140021180
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fa0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_fe0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.140021180(int64_t arg_78h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x14002118b;
    iVar1 = fcn.14094c690();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00001fb8 + iVar1) = 0xfffffffffffffffe;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)(&stack0x00001fa0 + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400211b8;
    fcn.14011e680();
    *(undefined8 *)(&stack0x00000fe8 + iVar1) = *(undefined8 *)(*(int64_t *)(&stack0x00001fa0 + iVar1) + 8);
    *(undefined8 *)(&stack0x00000ff0 + iVar1) = 0;
    *(undefined8 *)(&stack0x00000ff8 + iVar1) = in_R8;
    *(undefined4 *)(&stack0x00000fe0 + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1400211f0;
    fcn.14011e680(*(int64_t *)(&stack0x00001fa0 + iVar1), &stack0x00000fe0 + iVar1);
    return;
}

