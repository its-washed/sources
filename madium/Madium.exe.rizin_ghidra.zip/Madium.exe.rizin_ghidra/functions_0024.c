// Chunk 24 - 50 functions

// ============================================================
// Function: FUN_14001c140
// Address: 0x14001c140
// Size: 37 bytes
// ============================================================
void fcn.14001c140(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0x1020);
    return;
}

// ============================================================
// Function: FUN_14001c170
// Address: 0x14001c170
// Size: 58 bytes
// ============================================================
void fcn.14001c170(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0x1040);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x1040);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001c1b0
// Address: 0x14001c1b0
// Size: 41 bytes
// ============================================================
void fcn.14001c1b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1080, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001c1e0
// Address: 0x14001c1e0
// Size: 34 bytes
// ============================================================
void fcn.14001c1e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140013270(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001c210
// Address: 0x14001c210
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001c210(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140011970(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xb50) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xb50) + 0x18))(*(undefined8 *)(arg1 + 0xb58));
    }
    piVar1 = *(int64_t **)(arg1 + 0xb60);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xb60);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0xb80);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001c310
// Address: 0x14001c310
// Size: 51 bytes
// ============================================================
void fcn.14001c310(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001c350
// Address: 0x14001c350
// Size: 37 bytes
// ============================================================
void fcn.14001c350(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xb40);
    return;
}

// ============================================================
// Function: FUN_14001c380
// Address: 0x14001c380
// Size: 58 bytes
// ============================================================
void fcn.14001c380(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xb60);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xb60);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001c3c0
// Address: 0x14001c3c0
// Size: 41 bytes
// ============================================================
void fcn.14001c3c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0xb80, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001c3f0
// Address: 0x14001c3f0
// Size: 34 bytes
// ============================================================
void fcn.14001c3f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.140013330(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001c420
// Address: 0x14001c420
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001c420(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x0001400114b0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xc10) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xc10) + 0x18))(*(undefined8 *)(arg1 + 0xc18));
    }
    piVar1 = *(int64_t **)(arg1 + 0xc20);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xc20);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0xc80);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001c520
// Address: 0x14001c520
// Size: 51 bytes
// ============================================================
void fcn.14001c520(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001c560
// Address: 0x14001c560
// Size: 37 bytes
// ============================================================
void fcn.14001c560(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xc00);
    return;
}

// ============================================================
// Function: FUN_14001c590
// Address: 0x14001c590
// Size: 58 bytes
// ============================================================
void fcn.14001c590(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xc20);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xc20);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001c5d0
// Address: 0x14001c5d0
// Size: 41 bytes
// ============================================================
void fcn.14001c5d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0xc80, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001c600
// Address: 0x14001c600
// Size: 34 bytes
// ============================================================
void fcn.14001c600(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400134b0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001c630
// Address: 0x14001c630
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001c630(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code **ppcVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x20);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x000140794980(arg1 + 0x20);
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        if ((*(int64_t *)(arg1 + 0x38) != 0) && (iVar2 = *(int64_t *)(arg1 + 0x40), iVar2 != 0)) {
            ppcVar3 = *(code ***)(arg1 + 0x48);
            if (*ppcVar3 != (code *)0x0) {
                (**ppcVar3)(iVar2);
            }
            if (ppcVar3[1] != (code *)0x0) {
                fcn.1404d3c50(iVar2, ppcVar3[1], ppcVar3[2]);
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        func_0x000140011bd0(arg1 + 0x38);
    }
    if (*(int64_t *)(arg1 + 0xf70) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0xf70) + 0x18))(*(undefined8 *)(arg1 + 0xf78));
    }
    piVar1 = *(int64_t **)(arg1 + 0xf80);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            fcn.14045efb0(arg1 + 0xf80);
        }
    }
    uVar4 = *(undefined8 *)(arg1 + -8);
    uVar5 = (*(code *)0xe5f2d8)(arg1, 0x1000);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, uVar4);
    return;
}

// ============================================================
// Function: FUN_14001c730
// Address: 0x14001c730
// Size: 51 bytes
// ============================================================
void fcn.14001c730(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001c770
// Address: 0x14001c770
// Size: 37 bytes
// ============================================================
void fcn.14001c770(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d190(*(int64_t *)(arg2 + 0x30) + 0xf60);
    return;
}

// ============================================================
// Function: FUN_14001c7a0
// Address: 0x14001c7a0
// Size: 58 bytes
// ============================================================
void fcn.14001c7a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    piVar2 = *(int64_t **)(iVar1 + 0xf80);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0xf80);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001c7e0
// Address: 0x14001c7e0
// Size: 41 bytes
// ============================================================
void fcn.14001c7e0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x30), 0x1000, 0x80);
    return;
}

// ============================================================
// Function: FUN_14001c810
// Address: 0x14001c810
// Size: 34 bytes
// ============================================================
void fcn.14001c810(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1400133f0(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001c840
// Address: 0x14001c840
// Size: 230 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001c840(int64_t arg1)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    var_10h = -2;
    uVar1 = *(uint8_t *)arg1;
    if (2 < uVar1) {
        if (uVar1 == 3) {
            iVar4 = *(int64_t *)(arg1 + 8);
            if (iVar4 != 0) {
                iVar3 = *(int64_t *)(arg1 + 0x10);
                uVar6 = 1;
code_r0x0001404d3c50:
                iVar5 = iVar3;
                if (0x10 < uVar6) {
                    iVar5 = *(int64_t *)(iVar3 + -8);
                }
                var_40h = 0x140901d3e;
                uVar2 = (*(code *)0xe5f2d8)(iVar3, iVar4);
    // WARNING: Treating indirect jump as call
                (*(code *)0xe5f2ea)(uVar2, 0, iVar5);
                return;
            }
        } else if (uVar1 == 4) {
            var_20h = arg1 + 8;
            var_18h = arg1;
            func_0x000140286ef0();
            if (*(int64_t *)var_20h != 0) {
                iVar3 = *(int64_t *)(var_18h + 0x10);
                iVar4 = *(int64_t *)var_20h << 5;
                uVar6 = 8;
                goto code_r0x0001404d3c50;
            }
        } else {
            iVar4 = *(int64_t *)(arg1 + 8);
            if (iVar4 == 0) {
                var_28h = 0;
            } else {
                var_50h = *(int64_t *)(arg1 + 0x10);
                var_28h = *(int64_t *)(arg1 + 0x18);
                var_60h = 0;
                var_40h = 0;
                var_58h = iVar4;
                var_38h = iVar4;
                var_30h = var_50h;
            }
            var_68h = (int64_t)(iVar4 != 0);
            var_48h = var_68h;
            func_0x00014044bab0(&var_68h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001c930
// Address: 0x14001c930
// Size: 59 bytes
// ============================================================
void fcn.14001c930(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_18h;
    
    if (**(int64_t **)(arg2 + 0x68) != 0) {
        fcn.1404d3c50(*(undefined8 *)(*(int64_t *)(arg2 + 0x70) + 0x10), **(int64_t **)(arg2 + 0x68) << 5, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14001c990
// Address: 0x14001c990
// Size: 174 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001c990(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    func_0x00014001be30();
    piVar1 = *(int64_t **)(arg1 + 0x200);
    LOCK();
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (*piVar1 == 0) {
        func_0x0001406c65c0(arg1 + 0x200);
    }
    if (*(int64_t *)(arg1 + 0x1c8) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x1d0), *(int64_t *)(arg1 + 0x1c8), 1);
    }
    if (*(char *)(arg1 + 0x1e0) == '\x06') {
        if (*(int64_t *)(arg1 + 0x1e8) != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 0x1f0), *(int64_t *)(arg1 + 0x1e8), 1);
        }
    } else {
        fcn.14001c840(arg1 + 0x1e0);
    }
    if (*(int64_t *)(arg1 + 0x1b8) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x1b0), *(int64_t *)(arg1 + 0x1b8) << 2, 2);
    }
    iVar2 = *(int64_t *)(arg1 + 0x188);
    iVar3 = *(int64_t *)(arg1 + 400);
    var_40h = 0;
    while (var_40h != iVar3) {
        iVar4 = var_40h * 0x68;
        iVar6 = iVar2 + iVar4;
        var_40h = var_40h + 1;
        iVar4 = *(int64_t *)(iVar2 + 0x40 + iVar4);
        if (iVar4 != 0) {
            (**(code **)(iVar4 + 0x20))(iVar6 + 0x58, *(undefined8 *)(iVar6 + 0x48), *(undefined8 *)(iVar6 + 0x50));
        }
        (**(code **)(*(int64_t *)(iVar6 + 0x18) + 0x20))
                  (iVar6 + 0x30, *(undefined8 *)(iVar6 + 0x20), *(undefined8 *)(iVar6 + 0x28));
    }
    if (*(int64_t *)(arg1 + 0x180) != 0) {
        fcn.1404d3c50(iVar2, *(int64_t *)(arg1 + 0x180) * 0x68, 8);
    }
    iVar2 = *(int64_t *)(arg1 + 0x1a0);
    iVar3 = *(int64_t *)(arg1 + 0x1a8);
    var_30h = 0;
    iVar6 = iVar2 + 0x38;
    while (iVar3 != var_30h) {
        var_30h = var_30h + 1;
        (**(code **)(*(int64_t *)(iVar6 + -0x18) + 0x20))
                  (iVar6, *(undefined8 *)(iVar6 + -0x10), *(undefined8 *)(iVar6 + -8));
        iVar6 = iVar6 + 0x48;
    }
    if (*(int64_t *)(arg1 + 0x198) == 0) {
        return;
    }
    uVar5 = (*(code *)0xe5f2d8)(iVar2, *(int64_t *)(arg1 + 0x198) * 0x48);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar5, 0, iVar2);
    return;
}

// ============================================================
// Function: FUN_14001ca40
// Address: 0x14001ca40
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001ca40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    piVar2 = *(int64_t **)(iVar1 + 0x200);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1406c65c0(iVar1 + 0x200);
    }
    return;
}

// ============================================================
// Function: FUN_14001ca80
// Address: 0x14001ca80
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001ca80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    if (*(int64_t *)(iVar1 + 0x1c8) != 0) {
        fcn.1404d3c50(*(undefined8 *)(iVar1 + 0x1d0), *(int64_t *)(iVar1 + 0x1c8), 1);
    }
    fcn.14001b5c0(iVar1 + 0x1e0);
    return;
}

// ============================================================
// Function: FUN_14001cad0
// Address: 0x14001cad0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001cad0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001cc40(*(int64_t *)(arg2 + 0x28) + 0x168);
    return;
}

// ============================================================
// Function: FUN_14001cb00
// Address: 0x14001cb00
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001cb00(int64_t arg1)
{
    int64_t *piVar1;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    func_0x000140796e40();
    if (*(char *)arg1 == '\0') {
        piVar1 = *(int64_t **)(arg1 + 8);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x000140795240();
        }
    } else {
        piVar1 = *(int64_t **)(arg1 + 8);
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            func_0x000140794980();
        }
    }
    if ((*(int64_t *)(arg1 + 0x10) != 0) && (*(int64_t *)(arg1 + 0x38) != 0)) {
    // WARNING: Could not recover jumptable at 0x00014001cb63. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)(arg1 + 0x38) + 0x18))(*(undefined8 *)(arg1 + 0x40));
        return;
    }
    return;
}

// ============================================================
// Function: FUN_14001cb70
// Address: 0x14001cb70
// Size: 56 bytes
// ============================================================
void fcn.14001cb70(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    if ((*(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x10) != 0) &&
       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x38), iVar1 != 0)) {
        (**(code **)(iVar1 + 0x18))(*(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x40));
    }
    return;
}

// ============================================================
// Function: FUN_14001cbb0
// Address: 0x14001cbb0
// Size: 30 bytes
// ============================================================
void fcn.14001cbb0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.14001d160(*(undefined8 *)(arg2 + 0x20));
    return;
}

// ============================================================
// Function: FUN_14001cbd0
// Address: 0x14001cbd0
// Size: 64 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001cbd0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (arg1 == 0) {
        return;
    }
    func_0x0001404403b0();
    uVar1 = (*(code *)0xe5f2d8)(arg1, 0x20);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar1, 0, arg1);
    return;
}

// ============================================================
// Function: FUN_14001cc10
// Address: 0x14001cc10
// Size: 41 bytes
// ============================================================
void fcn.14001cc10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    
    fcn.1404d3c50(*(undefined8 *)(arg2 + 0x20), 0x20, 8);
    return;
}

// ============================================================
// Function: FUN_14001cc40
// Address: 0x14001cc40
// Size: 351 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.14001cc40(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t var_28h;
    int64_t iStack_40;
    int64_t iStack_30;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    if (*(int64_t *)(arg1 + 0x50) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x48), *(int64_t *)(arg1 + 0x50) << 2, 2);
    }
    iVar1 = *(int64_t *)(arg1 + 0x20);
    iVar2 = *(int64_t *)(arg1 + 0x28);
    iStack_40 = 0;
    while (iStack_40 != iVar2) {
        iVar3 = iStack_40 * 0x68;
        iVar5 = iVar1 + iVar3;
        iStack_40 = iStack_40 + 1;
        iVar3 = *(int64_t *)(iVar1 + 0x40 + iVar3);
        if (iVar3 != 0) {
            (**(code **)(iVar3 + 0x20))(iVar5 + 0x58, *(undefined8 *)(iVar5 + 0x48), *(undefined8 *)(iVar5 + 0x50));
        }
        (**(code **)(*(int64_t *)(iVar5 + 0x18) + 0x20))
                  (iVar5 + 0x30, *(undefined8 *)(iVar5 + 0x20), *(undefined8 *)(iVar5 + 0x28));
    }
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        fcn.1404d3c50(iVar1, *(int64_t *)(arg1 + 0x18) * 0x68, 8);
    }
    iVar1 = *(int64_t *)(arg1 + 0x38);
    iVar2 = *(int64_t *)(arg1 + 0x40);
    iStack_30 = 0;
    iVar5 = iVar1 + 0x38;
    while (iVar2 != iStack_30) {
        iStack_30 = iStack_30 + 1;
        (**(code **)(*(int64_t *)(iVar5 + -0x18) + 0x20))
                  (iVar5, *(undefined8 *)(iVar5 + -0x10), *(undefined8 *)(iVar5 + -8));
        iVar5 = iVar5 + 0x48;
    }
    if (*(int64_t *)(arg1 + 0x30) == 0) {
        return;
    }
    uVar4 = (*(code *)0xe5f2d8)(iVar1, *(int64_t *)(arg1 + 0x30) * 0x48);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar4, 0, iVar1);
    return;
}

// ============================================================
// Function: FUN_14001cda0
// Address: 0x14001cda0
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001cda0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg2 + 0x40);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    for (iVar3 = *(int64_t *)(arg2 + 0x38); iVar3 != iVar1; iVar3 = iVar3 + 1) {
        func_0x000140274170(iVar3 * 0x68 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_14001cdf0
// Address: 0x14001cdf0
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.14001cdf0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 0x18);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1 * 0x68, 8);
    }
    fcn.140001c60(*(int64_t *)(arg2 + 0x30) + 0x30);
    return;
}

// ============================================================
// Function: FUN_14001ce40
// Address: 0x14001ce40
// Size: 96 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001ce40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    for (iVar3 = *(int64_t *)(arg2 + 0x48); iVar1 != iVar3; iVar3 = iVar3 + 1) {
        (**(code **)(*(int64_t *)(iVar2 + 0x20 + iVar3 * 0x48) + 0x20))
                  (iVar2 + iVar3 * 0x48 + 0x38, *(undefined8 *)(iVar2 + 0x28 + iVar3 * 0x48), 
                   *(undefined8 *)(iVar2 + 0x30 + iVar3 * 0x48));
    }
    return;
}

// ============================================================
// Function: FUN_14001cea0
// Address: 0x14001cea0
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.14001cea0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_20h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 0x30);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x40), iVar1 * 0x48, 8);
    }
    return;
}

// ============================================================
// Function: FUN_14001cee0
// Address: 0x14001cee0
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001cee0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x48);
    (**(code **)(*(int64_t *)(iVar1 + 0x18) + 0x20))
              (iVar1 + 0x30, *(undefined8 *)(iVar1 + 0x20), *(undefined8 *)(iVar1 + 0x28));
    return;
}

// ============================================================
// Function: FUN_14001cf20
// Address: 0x14001cf20
// Size: 112 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.14001cf20(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    iVar3 = *(int64_t *)(arg1 + 0x10);
    if (iVar3 != 0) {
        puVar4 = (undefined8 *)(iVar1 + 8);
        do {
            if (puVar4[-1] != 0) {
                fcn.1404d3c50(*puVar4, puVar4[-1], 1);
            }
            puVar4 = puVar4 + 0xb;
            iVar3 = iVar3 + -1;
        } while (iVar3 != 0);
    }
    if (*(int64_t *)arg1 == 0) {
        return;
    }
    uVar2 = (*(code *)0xe5f2d8)(iVar1, *(int64_t *)arg1 * 0x58);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, iVar1);
    return;
}

// ============================================================
// Function: FUN_14001cf90
// Address: 0x14001cf90
// Size: 58 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

void fcn.14001cf90(int64_t arg1)
{
    undefined8 uVar1;
    
    if (*(int64_t *)arg1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 8), *(int64_t *)arg1, 1);
    }
    uVar1 = (*(code *)0xe5f2d8)(arg1, 0x58);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar1, 0, arg1);
    return;
}

// ============================================================
// Function: FUN_14001cfd0
// Address: 0x14001cfd0
// Size: 394 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)

int64_t fcn.14001cfd0(int64_t arg1)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    
    if (*(int64_t *)(arg1 + 0x108) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x110), *(int64_t *)(arg1 + 0x108), 1);
    }
    if (*(int64_t *)(arg1 + 0x80) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x88), *(int64_t *)(arg1 + 0x80), 1);
    }
    if (*(int64_t *)(arg1 + 0x138) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x140), *(int64_t *)(arg1 + 0x138), 1);
    }
    if (*(int64_t *)(arg1 + 0x120) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x128), *(int64_t *)(arg1 + 0x120), 1);
    }
    if (*(int64_t *)(arg1 + 0x150) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x158), *(int64_t *)(arg1 + 0x150), 1);
    }
    if (*(int64_t *)(arg1 + 0x168) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x170), *(int64_t *)(arg1 + 0x168), 1);
    }
    if (*(int64_t *)(arg1 + 0x180) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x188), *(int64_t *)(arg1 + 0x180), 1);
    }
    if ((*(int32_t *)(arg1 + 0xd8) != 2) && (*(int64_t *)(arg1 + 0xe8) != 0)) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0xf0), *(int64_t *)(arg1 + 0xe8), 1);
    }
    if (*(int64_t *)(arg1 + 0x198) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x1a0), *(int64_t *)(arg1 + 0x198), 1);
    }
    if (*(int64_t *)(arg1 + 0x1b0) != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg1 + 0x1b8), *(int64_t *)(arg1 + 0x1b0), 1);
    }
    if (*(int64_t *)(arg1 + 0x208) == 0) {
        return -*(int64_t *)(arg1 + 0x208);
    }
    uVar1 = *(undefined8 *)(arg1 + 0x210);
    uVar2 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
    iVar3 = (*(code *)0xe5f2ea)(uVar2, 0, uVar1);
    return iVar3;
}

// ============================================================
// Function: FUN_14001d190
// Address: 0x14001d190
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.14001d190(int64_t arg1)
{
    int64_t *piVar1;
    code **ppcVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    code *pcVar6;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        (**(code **)(*(int64_t *)(arg1 + 0x10) + 0x18))(*(undefined8 *)(arg1 + 0x18));
    }
    piVar1 = *(int64_t **)(arg1 + 0x20);
    if (piVar1 != (int64_t *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
            iVar5 = *(int64_t *)(arg1 + 0x20);
            ppcVar2 = *(code ***)(arg1 + 0x28);
            pcVar3 = ppcVar2[2];
            if (*ppcVar2 != (code *)0x0) {
                (**ppcVar2)(((uint64_t)(pcVar3 + -1) & 0xfffffffffffffff0) + iVar5 + 0x10);
            }
            if (iVar5 != -1) {
                LOCK();
                piVar1 = (int64_t *)(iVar5 + 8);
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (*piVar1 == 0) {
                    pcVar6 = (code *)0x8;
                    if ((code *)0x8 < pcVar3) {
                        pcVar6 = pcVar3;
                    }
                    if ((-(int64_t)pcVar6 & (uint64_t)(ppcVar2[1] + (int64_t)pcVar6 + 0xf)) != 0) {
                        if ((code *)0x10 < pcVar6) {
                            iVar5 = *(int64_t *)(iVar5 + -8);
                        }
                        uVar4 = (*(code *)0xe5f2d8)();
    // WARNING: Treating indirect jump as call
                        (*(code *)0xe5f2ea)(uVar4, 0, iVar5);
                        return;
                    }
                }
            }
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001d1f0
// Address: 0x14001d1f0
// Size: 52 bytes
// ============================================================
void fcn.14001d1f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    piVar2 = *(int64_t **)(iVar1 + 0x20);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
            fcn.14045efb0(iVar1 + 0x20);
        }
    }
    return;
}

// ============================================================
// Function: FUN_14001d230
// Address: 0x14001d230
// Size: 434 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000140901d34)
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001d230(int64_t arg1)
{
    code **ppcVar1;
    undefined8 uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (*(int32_t *)arg1 == 2) {
        piVar3 = *(int64_t **)(arg1 + 8);
        if (piVar3 == (int64_t *)0x0) {
            return;
        }
        iVar4 = piVar3[0xb];
        if (iVar4 != 0) {
            ppcVar1 = (code **)piVar3[0xc];
            if (*ppcVar1 != (code *)0x0) {
                (**ppcVar1)(iVar4);
            }
            if (ppcVar1[1] != (code *)0x0) {
                fcn.1404d3c50(iVar4, ppcVar1[1], ppcVar1[2]);
            }
        }
        if (*piVar3 != 0) {
            fcn.1404d3c50(piVar3[1], *piVar3, 1);
        }
    } else {
        if ((9 < *(uint8_t *)(arg1 + 0xf8)) && (*(int64_t *)(arg1 + 0x108) != 0)) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 0x100), *(int64_t *)(arg1 + 0x108), 1);
        }
        if (*(int64_t *)(arg1 + 0x88) != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 0x90), *(int64_t *)(arg1 + 0x88), 1);
        }
        fcn.14001cc40(arg1 + 0x28);
        if ((*(int64_t *)arg1 != 0) && (*(int64_t *)(arg1 + 8) != 0)) {
            (**(code **)(*(int64_t *)(arg1 + 8) + 0x20))
                      (arg1 + 0x20, *(undefined8 *)(arg1 + 0x10), *(undefined8 *)(arg1 + 0x18));
        }
        iVar4 = *(int64_t *)(arg1 + 0xf0);
        if (iVar4 != 0) {
            puVar5 = (undefined8 *)(*(int64_t *)(arg1 + 0xe8) + 8);
            do {
                if (puVar5[-1] != 0) {
                    fcn.1404d3c50(*puVar5, puVar5[-1], 1);
                }
                puVar5 = puVar5 + 0xb;
                iVar4 = iVar4 + -1;
            } while (iVar4 != 0);
        }
        if (*(int64_t *)(arg1 + 0xe0) != 0) {
            fcn.1404d3c50(*(undefined8 *)(arg1 + 0xe8), *(int64_t *)(arg1 + 0xe0) * 0x58, 8);
        }
        piVar3 = *(int64_t **)(arg1 + 0x110);
        LOCK();
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (*piVar3 == 0) {
            func_0x0001404da6a0(arg1 + 0x110);
        }
        uVar2 = *(undefined8 *)(arg1 + 0x118);
        ppcVar1 = *(code ***)(arg1 + 0x120);
        if (*ppcVar1 != (code *)0x0) {
            (**ppcVar1)(uVar2);
        }
        if (ppcVar1[1] != (code *)0x0) {
            fcn.1404d3c50(uVar2, ppcVar1[1], ppcVar1[2]);
        }
        piVar3 = *(int64_t **)(arg1 + 0x130);
        if (piVar3 == (int64_t *)0x0) {
            return;
        }
        fcn.14001cb00((int64_t)piVar3);
    }
    uVar2 = (*(code *)0xe5f2d8)(piVar3, 0x70);
    // WARNING: Treating indirect jump as call
    (*(code *)0xe5f2ea)(uVar2, 0, piVar3);
    return;
}

// ============================================================
// Function: FUN_14001d3f0
// Address: 0x14001d3f0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001d3f0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    if ((**(int64_t **)(arg2 + 0x38) != 0) && (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + 8), iVar1 != 0)) {
        iVar2 = *(int64_t *)(arg2 + 0x38);
        (**(code **)(iVar1 + 0x20))(iVar2 + 0x20, *(undefined8 *)(iVar2 + 0x10), *(undefined8 *)(iVar2 + 0x18));
    }
    return;
}

// ============================================================
// Function: FUN_14001d440
// Address: 0x14001d440
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001d440(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg2 + 0x38);
    fcn.14001cf20(iVar1 + 0xe0);
    piVar2 = *(int64_t **)(iVar1 + 0x110);
    LOCK();
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
        fcn.1404da6a0(*(int64_t *)(arg2 + 0x38) + 0x110);
    }
    return;
}

// ============================================================
// Function: FUN_14001d490
// Address: 0x14001d490
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001d490(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.14001dae0(*(undefined8 *)(*(int64_t *)(arg2 + 0x38) + 0x118), *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + 0x120)
                 );
    return;
}

// ============================================================
// Function: FUN_14001d4d0
// Address: 0x14001d4d0
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.14001d4d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x28), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x30) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14001d510
// Address: 0x14001d510
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.14001d510(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_8h;
    
    fcn.140002e20(*(undefined8 *)(*(int64_t *)(arg2 + 0x38) + 0x130));
    return;
}

