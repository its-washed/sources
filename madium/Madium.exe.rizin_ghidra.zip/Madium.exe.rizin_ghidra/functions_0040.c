// Chunk 40 - 50 functions

// ============================================================
// Function: FUN_14002e710
// Address: 0x14002e710
// Size: 53 bytes
// ============================================================
undefined8 fcn.14002e710(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1410) = uVar1;
    *(int64_t *)(arg2 + 0x1418) = iVar2;
    return 0x14002e64a;
}

// ============================================================
// Function: FUN_14002e750
// Address: 0x14002e750
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1390h because it doesn't fit into ProtoModel

void fcn.14002e750(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1418) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1410), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1418) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002e7a0
// Address: 0x14002e7a0
// Size: 24 bytes
// ============================================================
void fcn.14002e7a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002e7c0
// Address: 0x14002e7c0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002e7c0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_a60h;
    int64_t var_a08h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_a60h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011d5d0(var_40h + 0x20, &var_a60h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xa50, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x0001400145f0(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002e8b0
// Address: 0x14002e8b0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_9f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel

undefined8 fcn.14002e8b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xa70));
    *(undefined8 *)(arg2 + 0xa50) = uVar1;
    *(int64_t *)(arg2 + 0xa58) = iVar2;
    return 0x14002e854;
}

// ============================================================
// Function: FUN_14002e8f0
// Address: 0x14002e8f0
// Size: 24 bytes
// ============================================================
void fcn.14002e8f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002e910
// Address: 0x14002e910
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel

undefined8 fcn.14002e910(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xa50) = uVar1;
    *(int64_t *)(arg2 + 0xa58) = iVar2;
    return 0x14002e854;
}

// ============================================================
// Function: FUN_14002e950
// Address: 0x14002e950
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_9d8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_9d0h because it doesn't fit into ProtoModel

void fcn.14002e950(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xa58) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xa50), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xa58) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002e9a0
// Address: 0x14002e9a0
// Size: 24 bytes
// ============================================================
void fcn.14002e9a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002e9c0
// Address: 0x14002e9c0
// Size: 323 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ah

void fcn.14002e9c0(int64_t arg1)
{
    uint8_t uVar1;
    char cVar2;
    uint64_t in_RDX;
    int64_t var_7b0h;
    int64_t var_758h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    undefined var_2ah;
    uint8_t var_29h;
    int64_t var_28h;
    
    var_28h = -2;
    uVar1 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_7b0h._0_4_ = 2;
        var_2ah = 1;
        var_48h = arg1;
        var_29h = uVar1;
        var_50h = func_0x000140796790(*(undefined8 *)(arg1 + 0x28));
        var_38h = var_48h + 0x30;
        func_0x00014007b410();
        func_0x000140951cf0(var_38h, &var_7b0h, 0x760);
        var_2ah = 0;
        func_0x000140796f10(&var_50h);
        arg1 = var_48h;
        uVar1 = var_29h;
    }
    if ((uVar1 & 1) != 0) {
        func_0x000140796b10(arg1 + 0x790, 0);
    }
    cVar2 = func_0x000140797e30(arg1);
    if (cVar2 != '\0') {
        func_0x00014000c740(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_14002eb10
// Address: 0x14002eb10
// Size: 46 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_72eh because it doesn't fit into ProtoModel

void fcn.14002eb10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    if (*(char *)(arg2 + 0x7ae) != '\0') {
        fcn.14007b410(arg2 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_14002eb40
// Address: 0x14002eb40
// Size: 25 bytes
// ============================================================
void fcn.14002eb40(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002eb60
// Address: 0x14002eb60
// Size: 60 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_738h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_718h because it doesn't fit into ProtoModel

undefined8 fcn.14002eb60(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x7b8));
    *(undefined8 *)(arg2 + 0x7a0) = uVar1;
    *(int64_t *)(arg2 + 0x798) = iVar2;
    return 0x14002ea95;
}

// ============================================================
// Function: FUN_14002eba0
// Address: 0x14002eba0
// Size: 25 bytes
// ============================================================
void fcn.14002eba0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002ebc0
// Address: 0x14002ebc0
// Size: 55 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_718h because it doesn't fit into ProtoModel

undefined8 fcn.14002ebc0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x7a0) = uVar1;
    *(int64_t *)(arg2 + 0x798) = iVar2;
    return 0x14002ea95;
}

// ============================================================
// Function: FUN_14002ec00
// Address: 0x14002ec00
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_718h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel

void fcn.14002ec00(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x798) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x7a0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x798) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002ec50
// Address: 0x14002ec50
// Size: 68 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_720h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_708h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_72eh because it doesn't fit into ProtoModel

void fcn.14002ec50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_10h;
    int64_t var_58h;
    
    fcn.140951cf0(*(undefined8 *)(arg2 + 0x7a0), arg2 + 0x28, 0x760);
    fcn.140796f10(arg2 + 0x788);
    *(undefined *)(arg2 + 0x7ae) = 0;
    return;
}

// ============================================================
// Function: FUN_14002eca0
// Address: 0x14002eca0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2e58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e57h because it doesn't fit into ProtoModel

void fcn.14002eca0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002ecac;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00002e58 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00002e38 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ecce;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00002e57)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ecf4;
        func_0x00014011d2f0(*(int64_t *)(&stack0x00002e38 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00002e57)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ed14;
        func_0x000140796b10(*(int64_t *)(&stack0x00002e38 + iVar4) + 0x2e50, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00002e38 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ed23;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ed2f;
        func_0x000140013570(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002eda0
// Address: 0x14002eda0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2df0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2dd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2dd8h because it doesn't fit into ProtoModel

undefined8 fcn.14002eda0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x2e70));
    *(undefined8 *)(arg2 + 0x2e50) = uVar1;
    *(int64_t *)(arg2 + 0x2e58) = iVar2;
    return 0x14002ed3a;
}

// ============================================================
// Function: FUN_14002ede0
// Address: 0x14002ede0
// Size: 24 bytes
// ============================================================
void fcn.14002ede0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002ee00
// Address: 0x14002ee00
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2dd0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2dd8h because it doesn't fit into ProtoModel

undefined8 fcn.14002ee00(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x2e50) = uVar1;
    *(int64_t *)(arg2 + 0x2e58) = iVar2;
    return 0x14002ed3a;
}

// ============================================================
// Function: FUN_14002ee40
// Address: 0x14002ee40
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2dd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2dd0h because it doesn't fit into ProtoModel

void fcn.14002ee40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x2e58) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x2e50), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x2e58) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002ee90
// Address: 0x14002ee90
// Size: 24 bytes
// ============================================================
void fcn.14002ee90(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002eeb0
// Address: 0x14002eeb0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_13b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1398h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_13b7h because it doesn't fit into ProtoModel

void fcn.14002eeb0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002eebc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x000013b8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001398 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002eede;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x000013b7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ef04;
        func_0x00014011f090(*(int64_t *)(&stack0x00001398 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x000013b7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ef24;
        func_0x000140796b10(*(int64_t *)(&stack0x00001398 + iVar4) + 0x13b0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001398 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ef33;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002ef3f;
        func_0x000140014a10(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002efb0
// Address: 0x14002efb0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.14002efb0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x13d0));
    *(undefined8 *)(arg2 + 0x13b0) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x14002ef4a;
}

// ============================================================
// Function: FUN_14002eff0
// Address: 0x14002eff0
// Size: 24 bytes
// ============================================================
void fcn.14002eff0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002f010
// Address: 0x14002f010
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel

undefined8 fcn.14002f010(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x13b0) = uVar1;
    *(int64_t *)(arg2 + 0x13b8) = iVar2;
    return 0x14002ef4a;
}

// ============================================================
// Function: FUN_14002f050
// Address: 0x14002f050
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1330h because it doesn't fit into ProtoModel

void fcn.14002f050(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x13b8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x13b0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x13b8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002f0a0
// Address: 0x14002f0a0
// Size: 24 bytes
// ============================================================
void fcn.14002f0a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002f0c0
// Address: 0x14002f0c0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002f0c0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_1e8h;
    int64_t var_188h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_1e8h._0_4_ = 2;
        var_21h = uVar2;
        func_0x000140120700(var_40h + 0x20, &var_1e8h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0x1d8, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014001b3b0(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002f1b0
// Address: 0x14002f1b0
// Size: 58 bytes
// ============================================================
undefined8 fcn.14002f1b0(undefined8 placeholder_0, int64_t arg2, int64_t arg_150h, int64_t arg_158h, int64_t arg_170h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1f0));
    *(undefined8 *)(arg2 + 0x1d0) = uVar1;
    *(int64_t *)(arg2 + 0x1d8) = iVar2;
    return 0x14002f154;
}

// ============================================================
// Function: FUN_14002f1f0
// Address: 0x14002f1f0
// Size: 24 bytes
// ============================================================
void fcn.14002f1f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002f210
// Address: 0x14002f210
// Size: 53 bytes
// ============================================================
undefined8 fcn.14002f210(undefined8 placeholder_0, int64_t arg2, int64_t arg_150h, int64_t arg_158h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1d0) = uVar1;
    *(int64_t *)(arg2 + 0x1d8) = iVar2;
    return 0x14002f154;
}

// ============================================================
// Function: FUN_14002f250
// Address: 0x14002f250
// Size: 65 bytes
// ============================================================
void fcn.14002f250(undefined8 placeholder_0, int64_t arg2, int64_t arg_150h, int64_t arg_158h)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1d8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1d0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1d8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002f2a0
// Address: 0x14002f2a0
// Size: 24 bytes
// ============================================================
void fcn.14002f2a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002f2c0
// Address: 0x14002f2c0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002f2c0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_fa0h;
    int64_t var_f48h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_fa0h._0_4_ = 2;
        var_21h = uVar2;
        func_0x00014011ffd0(var_40h + 0x20, &var_fa0h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0xf90, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x00014001af90(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002f3b0
// Address: 0x14002f3b0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f18h because it doesn't fit into ProtoModel

undefined8 fcn.14002f3b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0xfb0));
    *(undefined8 *)(arg2 + 0xf90) = uVar1;
    *(int64_t *)(arg2 + 0xf98) = iVar2;
    return 0x14002f354;
}

// ============================================================
// Function: FUN_14002f3f0
// Address: 0x14002f3f0
// Size: 24 bytes
// ============================================================
void fcn.14002f3f0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002f410
// Address: 0x14002f410
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f18h because it doesn't fit into ProtoModel

undefined8 fcn.14002f410(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0xf90) = uVar1;
    *(int64_t *)(arg2 + 0xf98) = iVar2;
    return 0x14002f354;
}

// ============================================================
// Function: FUN_14002f450
// Address: 0x14002f450
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_f18h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_f10h because it doesn't fit into ProtoModel

void fcn.14002f450(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0xf98) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0xf90), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xf98) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002f4a0
// Address: 0x14002f4a0
// Size: 24 bytes
// ============================================================
void fcn.14002f4a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002f4c0
// Address: 0x14002f4c0
// Size: 246 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1bf8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bf7h because it doesn't fit into ProtoModel

void fcn.14002f4c0(int64_t arg_70h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    undefined8 uStack_18;
    
    uStack_18 = 0x14002f4cc;
    iVar4 = func_0x00014094c690();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00001bf8 + iVar4) = 0xfffffffffffffffe;
    *(undefined8 *)(&stack0x00001bd8 + iVar4) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002f4ee;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        (&stack0x00001bf7)[iVar4] = uVar2;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002f514;
        func_0x0001401202b0(*(int64_t *)(&stack0x00001bd8 + iVar4) + 0x20, (int64_t)&var_18h + iVar4);
        uVar2 = (&stack0x00001bf7)[iVar4];
    }
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002f534;
        func_0x000140796b10(*(int64_t *)(&stack0x00001bd8 + iVar4) + 0x1bf0, 0);
    }
    uVar1 = *(undefined8 *)(&stack0x00001bd8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002f543;
    cVar3 = func_0x000140797e30(uVar1);
    if (cVar3 != '\0') {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x14002f54f;
        func_0x000140018860(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002f5c0
// Address: 0x14002f5c0
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1b90h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b78h because it doesn't fit into ProtoModel

undefined8 fcn.14002f5c0(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1c10));
    *(undefined8 *)(arg2 + 0x1bf0) = uVar1;
    *(int64_t *)(arg2 + 0x1bf8) = iVar2;
    return 0x14002f55a;
}

// ============================================================
// Function: FUN_14002f600
// Address: 0x14002f600
// Size: 24 bytes
// ============================================================
void fcn.14002f600(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002f620
// Address: 0x14002f620
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1b70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b78h because it doesn't fit into ProtoModel

undefined8 fcn.14002f620(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(0);
    *(undefined8 *)(arg2 + 0x1bf0) = uVar1;
    *(int64_t *)(arg2 + 0x1bf8) = iVar2;
    return 0x14002f55a;
}

// ============================================================
// Function: FUN_14002f660
// Address: 0x14002f660
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1b78h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b70h because it doesn't fit into ProtoModel

void fcn.14002f660(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x1bf8) + 8);
    if (iVar1 != 0) {
        fcn.1404d3c50(*(undefined8 *)(arg2 + 0x1bf0), iVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0x1bf8) + 0x10));
    }
    return;
}

// ============================================================
// Function: FUN_14002f6b0
// Address: 0x14002f6b0
// Size: 24 bytes
// ============================================================
void fcn.14002f6b0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_14002f6d0
// Address: 0x14002f6d0
// Size: 240 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.14002f6d0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    char cVar3;
    uint64_t in_RDX;
    int64_t var_1e8h;
    int64_t var_188h;
    int64_t var_40h;
    uint8_t var_21h;
    int64_t var_20h;
    
    var_20h = -2;
    var_40h = arg1;
    uVar2 = func_0x000140797dd0();
    if ((in_RDX & 1) != 0) {
        var_1e8h._0_4_ = 2;
        var_21h = uVar2;
        func_0x000140120700(var_40h + 0x20, &var_1e8h);
        uVar2 = var_21h;
    }
    if ((uVar2 & 1) != 0) {
        func_0x000140796b10(var_40h + 0x1d8, 0);
    }
    iVar1 = var_40h;
    cVar3 = func_0x000140797e30(var_40h);
    if (cVar3 != '\0') {
        func_0x0001400171b0(iVar1);
    }
    return;
}

// ============================================================
// Function: FUN_14002f7c0
// Address: 0x14002f7c0
// Size: 58 bytes
// ============================================================
undefined8 fcn.14002f7c0(undefined8 placeholder_0, int64_t arg2, int64_t arg_150h, int64_t arg_158h, int64_t arg_170h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_10h;
    
    iVar2 = arg2;
    uVar1 = fcn.14097721f(*(undefined8 *)(arg2 + 0x1f0));
    *(undefined8 *)(arg2 + 0x1d0) = uVar1;
    *(int64_t *)(arg2 + 0x1d8) = iVar2;
    return 0x14002f764;
}

// ============================================================
// Function: FUN_14002f800
// Address: 0x14002f800
// Size: 24 bytes
// ============================================================
void fcn.14002f800(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    fcn.14097885b();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

