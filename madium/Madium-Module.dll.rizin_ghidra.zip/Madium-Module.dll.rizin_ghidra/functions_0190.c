// Chunk 190 - 50 functions

// ============================================================
// Function: FUN_1802551a0
// Address: 0x1802551a0
// Size: 108 bytes
// ============================================================
undefined8 * fcn.1802551a0(int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    int32_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    undefined8 unaff_RSI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802551b0;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    if (in_RCX != (undefined8 *)0x0) {
        if ((*(uint8_t *)((int64_t)in_RCX + 0x14) & 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802551f2;
            puVar6 = (undefined8 *)func_0x000180224d60(0x18, 0x1804e5df0, 0xf8);
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802551dc;
            puVar6 = (undefined8 *)func_0x000180224d60(0x18, 0x1804e5df0, 0xf8);
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 9;
            }
        }
        if (puVar6 != (undefined8 *)0x0) {
            uVar1 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
            iVar2 = *(int32_t *)(((uint64_t)(uVar1 & 4) | 8) + (int64_t)in_RCX);
            if (puVar6 != in_RCX) {
                if (*(int32_t *)((int64_t)puVar6 + 0xc) < iVar2) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025522d;
                    iVar7 = func_0x000180256190(puVar6, iVar2);
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025523a;
                        func_0x000180255290(puVar6);
                        return (undefined8 *)0x0;
                    }
                }
                if (0 < *(int32_t *)(in_RCX + 1)) {
                    uVar3 = *in_RCX;
                    uVar4 = *puVar6;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180255264;
                    func_0x000180498030(uVar4, uVar3, (int64_t)iVar2 << 3);
                }
                *(undefined4 *)(puVar6 + 2) = *(undefined4 *)(in_RCX + 2);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(in_RCX + 1);
            }
            return puVar6;
        }
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18025520c
// Address: 0x18025520c
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.1802551a0(int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    int32_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    undefined8 unaff_RSI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802551b0;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    if (in_RCX != (undefined8 *)0x0) {
        if ((*(uint8_t *)((int64_t)in_RCX + 0x14) & 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802551f2;
            puVar6 = (undefined8 *)func_0x000180224d60(0x18, 0x1804e5df0, 0xf8);
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802551dc;
            puVar6 = (undefined8 *)func_0x000180224d60(0x18, 0x1804e5df0, 0xf8);
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 9;
            }
        }
        if (puVar6 != (undefined8 *)0x0) {
            uVar1 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
            iVar2 = *(int32_t *)(((uint64_t)(uVar1 & 4) | 8) + (int64_t)in_RCX);
            if (puVar6 != in_RCX) {
                if (*(int32_t *)((int64_t)puVar6 + 0xc) < iVar2) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025522d;
                    iVar7 = func_0x000180256190(puVar6, iVar2);
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025523a;
                        func_0x000180255290(puVar6);
                        return (undefined8 *)0x0;
                    }
                }
                if (0 < *(int32_t *)(in_RCX + 1)) {
                    uVar3 = *in_RCX;
                    uVar4 = *puVar6;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180255264;
                    func_0x000180498030(uVar4, uVar3, (int64_t)iVar2 << 3);
                }
                *(undefined4 *)(puVar6 + 2) = *(undefined4 *)(in_RCX + 2);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(in_RCX + 1);
            }
            return puVar6;
        }
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18025524c
// Address: 0x18025524c
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.1802551a0(int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    int32_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    undefined8 unaff_RSI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802551b0;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    if (in_RCX != (undefined8 *)0x0) {
        if ((*(uint8_t *)((int64_t)in_RCX + 0x14) & 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802551f2;
            puVar6 = (undefined8 *)func_0x000180224d60(0x18, 0x1804e5df0, 0xf8);
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802551dc;
            puVar6 = (undefined8 *)func_0x000180224d60(0x18, 0x1804e5df0, 0xf8);
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 9;
            }
        }
        if (puVar6 != (undefined8 *)0x0) {
            uVar1 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
            iVar2 = *(int32_t *)(((uint64_t)(uVar1 & 4) | 8) + (int64_t)in_RCX);
            if (puVar6 != in_RCX) {
                if (*(int32_t *)((int64_t)puVar6 + 0xc) < iVar2) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025522d;
                    iVar7 = func_0x000180256190(puVar6, iVar2);
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025523a;
                        func_0x000180255290(puVar6);
                        return (undefined8 *)0x0;
                    }
                }
                if (0 < *(int32_t *)(in_RCX + 1)) {
                    uVar3 = *in_RCX;
                    uVar4 = *puVar6;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180255264;
                    func_0x000180498030(uVar4, uVar3, (int64_t)iVar2 << 3);
                }
                *(undefined4 *)(puVar6 + 2) = *(undefined4 *)(in_RCX + 2);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(in_RCX + 1);
            }
            return puVar6;
        }
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_180255283
// Address: 0x180255283
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.1802551a0(int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    int32_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    undefined8 unaff_RSI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802551b0;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    if (in_RCX != (undefined8 *)0x0) {
        if ((*(uint8_t *)((int64_t)in_RCX + 0x14) & 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802551f2;
            puVar6 = (undefined8 *)func_0x000180224d60(0x18, 0x1804e5df0, 0xf8);
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802551dc;
            puVar6 = (undefined8 *)func_0x000180224d60(0x18, 0x1804e5df0, 0xf8);
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 9;
            }
        }
        if (puVar6 != (undefined8 *)0x0) {
            uVar1 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
            iVar2 = *(int32_t *)(((uint64_t)(uVar1 & 4) | 8) + (int64_t)in_RCX);
            if (puVar6 != in_RCX) {
                if (*(int32_t *)((int64_t)puVar6 + 0xc) < iVar2) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025522d;
                    iVar7 = func_0x000180256190(puVar6, iVar2);
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025523a;
                        func_0x000180255290(puVar6);
                        return (undefined8 *)0x0;
                    }
                }
                if (0 < *(int32_t *)(in_RCX + 1)) {
                    uVar3 = *in_RCX;
                    uVar4 = *puVar6;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180255264;
                    func_0x000180498030(uVar4, uVar3, (int64_t)iVar2 << 3);
                }
                *(undefined4 *)(puVar6 + 2) = *(undefined4 *)(in_RCX + 2);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(in_RCX + 1);
            }
            return puVar6;
        }
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_180255290
// Address: 0x180255290
// Size: 118 bytes
// ============================================================
void fcn.180255290(int64_t arg1)
{
    int32_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802552a0;
        iVar3 = func_0x00018045a350();
        iVar3 = -iVar3;
        if ((*(uint32_t *)(arg1 + 0x14) & 2) == 0) {
            if ((*(uint32_t *)(arg1 + 0x14) & 8) == 0) {
                uVar2 = *(undefined8 *)arg1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802552e5;
                func_0x000180224990(uVar2, 0x1804e5df0, 0xd2);
            } else {
                iVar1 = *(int32_t *)(arg1 + 0xc);
                uVar2 = *(undefined8 *)arg1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802552ce;
                func_0x000180225130(uVar2, (int64_t)iVar1 << 3, 0x1804e5df0, 0xce);
            }
        }
        if ((*(uint8_t *)(arg1 + 0x14) & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180255300;
            func_0x000180224990(arg1, 0x1804e5df0, 0xe9);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180255400
// Address: 0x180255400
// Size: 37 bytes
// ============================================================
void fcn.180255400(void)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025540a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180255420;
    fcn.180255b10(*(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802554c0
// Address: 0x1802554c0
// Size: 58 bytes
// ============================================================
void fcn.1802554c0(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802554ca;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x1802554e4;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + -iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined4 *)(iVar1 + 0x14) = 1;
    return;
}

// ============================================================
// Function: FUN_180255500
// Address: 0x180255500
// Size: 32 bytes
// ============================================================
uint64_t fcn.180255500(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_78h,
                      int64_t arg_80h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    uint32_t uVar6;
    undefined8 unaff_RBP;
    uint32_t uVar7;
    undefined8 unaff_RSI;
    uint32_t uVar8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 *puVar9;
    uint32_t uVar10;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025550c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = *(int32_t *)(in_RCX + 1);
    uVar8 = iVar4 - 1;
    if ((*(uint8_t *)((int64_t)in_RCX + 0x14) & 4) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RSI;
        uVar7 = 0;
        *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R12;
        uVar6 = 0;
        iVar4 = *(int32_t *)((int64_t)in_RCX + 0xc);
        *(undefined8 *)((int64_t)&var_18h + iVar5) = unaff_R15;
        uVar10 = 0;
        if (0 < iVar4) {
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
            *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_R14;
            puVar9 = (undefined8 *)*in_RCX;
            do {
                uVar1 = *puVar9;
                uVar2 = (int32_t)((uVar6 ^ uVar8) - 1 & ~(uVar6 ^ uVar8)) >> 0x1f;
                uVar7 = uVar7 | uVar2;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025556e;
                uVar3 = fcn.1802555f0(uVar1);
                puVar9 = puVar9 + 1;
                uVar6 = uVar6 + 1;
                uVar10 = uVar10 + (~uVar7 & 0x40) + (uVar3 & uVar2);
            } while ((int32_t)uVar6 < iVar4);
        }
        return (uint64_t)(0xffffffffU - ((int32_t)(~uVar8 - 1 & uVar8) >> 0x1f) & uVar10);
    }
    if (iVar4 != 0) {
        uVar1 = *(undefined8 *)(*in_RCX + -8 + (int64_t)iVar4 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802555d6;
        iVar4 = fcn.1802555f0(uVar1);
        return (uint64_t)(iVar4 + uVar8 * 0x40);
    }
    return (int64_t)iVar4;
}

// ============================================================
// Function: FUN_180255520
// Address: 0x180255520
// Size: 36 bytes
// ============================================================
uint64_t fcn.180255500(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_78h,
                      int64_t arg_80h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    uint32_t uVar6;
    undefined8 unaff_RBP;
    uint32_t uVar7;
    undefined8 unaff_RSI;
    uint32_t uVar8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 *puVar9;
    uint32_t uVar10;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025550c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = *(int32_t *)(in_RCX + 1);
    uVar8 = iVar4 - 1;
    if ((*(uint8_t *)((int64_t)in_RCX + 0x14) & 4) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RSI;
        uVar7 = 0;
        *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R12;
        uVar6 = 0;
        iVar4 = *(int32_t *)((int64_t)in_RCX + 0xc);
        *(undefined8 *)((int64_t)&var_18h + iVar5) = unaff_R15;
        uVar10 = 0;
        if (0 < iVar4) {
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
            *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_R14;
            puVar9 = (undefined8 *)*in_RCX;
            do {
                uVar1 = *puVar9;
                uVar2 = (int32_t)((uVar6 ^ uVar8) - 1 & ~(uVar6 ^ uVar8)) >> 0x1f;
                uVar7 = uVar7 | uVar2;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025556e;
                uVar3 = fcn.1802555f0(uVar1);
                puVar9 = puVar9 + 1;
                uVar6 = uVar6 + 1;
                uVar10 = uVar10 + (~uVar7 & 0x40) + (uVar3 & uVar2);
            } while ((int32_t)uVar6 < iVar4);
        }
        return (uint64_t)(0xffffffffU - ((int32_t)(~uVar8 - 1 & uVar8) >> 0x1f) & uVar10);
    }
    if (iVar4 != 0) {
        uVar1 = *(undefined8 *)(*in_RCX + -8 + (int64_t)iVar4 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802555d6;
        iVar4 = fcn.1802555f0(uVar1);
        return (uint64_t)(iVar4 + uVar8 * 0x40);
    }
    return (int64_t)iVar4;
}

// ============================================================
// Function: FUN_180255544
// Address: 0x180255544
// Size: 78 bytes
// ============================================================
uint64_t fcn.180255500(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_78h,
                      int64_t arg_80h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    uint32_t uVar6;
    undefined8 unaff_RBP;
    uint32_t uVar7;
    undefined8 unaff_RSI;
    uint32_t uVar8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 *puVar9;
    uint32_t uVar10;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025550c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = *(int32_t *)(in_RCX + 1);
    uVar8 = iVar4 - 1;
    if ((*(uint8_t *)((int64_t)in_RCX + 0x14) & 4) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RSI;
        uVar7 = 0;
        *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R12;
        uVar6 = 0;
        iVar4 = *(int32_t *)((int64_t)in_RCX + 0xc);
        *(undefined8 *)((int64_t)&var_18h + iVar5) = unaff_R15;
        uVar10 = 0;
        if (0 < iVar4) {
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
            *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_R14;
            puVar9 = (undefined8 *)*in_RCX;
            do {
                uVar1 = *puVar9;
                uVar2 = (int32_t)((uVar6 ^ uVar8) - 1 & ~(uVar6 ^ uVar8)) >> 0x1f;
                uVar7 = uVar7 | uVar2;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025556e;
                uVar3 = fcn.1802555f0(uVar1);
                puVar9 = puVar9 + 1;
                uVar6 = uVar6 + 1;
                uVar10 = uVar10 + (~uVar7 & 0x40) + (uVar3 & uVar2);
            } while ((int32_t)uVar6 < iVar4);
        }
        return (uint64_t)(0xffffffffU - ((int32_t)(~uVar8 - 1 & uVar8) >> 0x1f) & uVar10);
    }
    if (iVar4 != 0) {
        uVar1 = *(undefined8 *)(*in_RCX + -8 + (int64_t)iVar4 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802555d6;
        iVar4 = fcn.1802555f0(uVar1);
        return (uint64_t)(iVar4 + uVar8 * 0x40);
    }
    return (int64_t)iVar4;
}

// ============================================================
// Function: FUN_180255592
// Address: 0x180255592
// Size: 45 bytes
// ============================================================
uint64_t fcn.180255500(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_78h,
                      int64_t arg_80h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    uint32_t uVar6;
    undefined8 unaff_RBP;
    uint32_t uVar7;
    undefined8 unaff_RSI;
    uint32_t uVar8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 *puVar9;
    uint32_t uVar10;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025550c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = *(int32_t *)(in_RCX + 1);
    uVar8 = iVar4 - 1;
    if ((*(uint8_t *)((int64_t)in_RCX + 0x14) & 4) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RSI;
        uVar7 = 0;
        *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R12;
        uVar6 = 0;
        iVar4 = *(int32_t *)((int64_t)in_RCX + 0xc);
        *(undefined8 *)((int64_t)&var_18h + iVar5) = unaff_R15;
        uVar10 = 0;
        if (0 < iVar4) {
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
            *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_R14;
            puVar9 = (undefined8 *)*in_RCX;
            do {
                uVar1 = *puVar9;
                uVar2 = (int32_t)((uVar6 ^ uVar8) - 1 & ~(uVar6 ^ uVar8)) >> 0x1f;
                uVar7 = uVar7 | uVar2;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025556e;
                uVar3 = fcn.1802555f0(uVar1);
                puVar9 = puVar9 + 1;
                uVar6 = uVar6 + 1;
                uVar10 = uVar10 + (~uVar7 & 0x40) + (uVar3 & uVar2);
            } while ((int32_t)uVar6 < iVar4);
        }
        return (uint64_t)(0xffffffffU - ((int32_t)(~uVar8 - 1 & uVar8) >> 0x1f) & uVar10);
    }
    if (iVar4 != 0) {
        uVar1 = *(undefined8 *)(*in_RCX + -8 + (int64_t)iVar4 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802555d6;
        iVar4 = fcn.1802555f0(uVar1);
        return (uint64_t)(iVar4 + uVar8 * 0x40);
    }
    return (int64_t)iVar4;
}

// ============================================================
// Function: FUN_1802555bf
// Address: 0x1802555bf
// Size: 34 bytes
// ============================================================
uint64_t fcn.180255500(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_78h,
                      int64_t arg_80h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    uint32_t uVar6;
    undefined8 unaff_RBP;
    uint32_t uVar7;
    undefined8 unaff_RSI;
    uint32_t uVar8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 *puVar9;
    uint32_t uVar10;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025550c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = *(int32_t *)(in_RCX + 1);
    uVar8 = iVar4 - 1;
    if ((*(uint8_t *)((int64_t)in_RCX + 0x14) & 4) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RSI;
        uVar7 = 0;
        *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R12;
        uVar6 = 0;
        iVar4 = *(int32_t *)((int64_t)in_RCX + 0xc);
        *(undefined8 *)((int64_t)&var_18h + iVar5) = unaff_R15;
        uVar10 = 0;
        if (0 < iVar4) {
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
            *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_R14;
            puVar9 = (undefined8 *)*in_RCX;
            do {
                uVar1 = *puVar9;
                uVar2 = (int32_t)((uVar6 ^ uVar8) - 1 & ~(uVar6 ^ uVar8)) >> 0x1f;
                uVar7 = uVar7 | uVar2;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025556e;
                uVar3 = fcn.1802555f0(uVar1);
                puVar9 = puVar9 + 1;
                uVar6 = uVar6 + 1;
                uVar10 = uVar10 + (~uVar7 & 0x40) + (uVar3 & uVar2);
            } while ((int32_t)uVar6 < iVar4);
        }
        return (uint64_t)(0xffffffffU - ((int32_t)(~uVar8 - 1 & uVar8) >> 0x1f) & uVar10);
    }
    if (iVar4 != 0) {
        uVar1 = *(undefined8 *)(*in_RCX + -8 + (int64_t)iVar4 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802555d6;
        iVar4 = fcn.1802555f0(uVar1);
        return (uint64_t)(iVar4 + uVar8 * 0x40);
    }
    return (int64_t)iVar4;
}

// ============================================================
// Function: FUN_1802556d0
// Address: 0x1802556d0
// Size: 58 bytes
// ============================================================
void fcn.1802556d0(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802556da;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x1802556f4;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + -iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined4 *)(iVar1 + 0x14) = 9;
    return;
}

// ============================================================
// Function: FUN_180255780
// Address: 0x180255780
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Variable var_7h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.180255780(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar4;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025579a;
    iVar1 = fcn.18045a350();
    if ((int32_t)(uint32_t)in_RDX < 0) {
code_r0x00018025580d:
        uVar3 = 0;
    } else {
        uVar4 = in_RDX >> 6 & 0x3ffffff;
        if (*(int32_t *)(in_RCX + 1) <= (int32_t)uVar4) {
            uVar5 = (int32_t)uVar4 + 1;
            piVar2 = in_RCX;
            if (*(int32_t *)((int64_t)in_RCX + 0xc) < (int32_t)uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x1802557c7;
                piVar2 = (int64_t *)func_0x000180256190();
            }
            if (piVar2 == (int64_t *)0x0) goto code_r0x00018025580d;
            for (iVar1 = (int64_t)*(int32_t *)(in_RCX + 1); iVar1 < (int64_t)(uint64_t)uVar5; iVar1 = iVar1 + 1) {
                *(undefined8 *)(*in_RCX + iVar1 * 8) = 0;
            }
            *(uint32_t *)(in_RCX + 1) = uVar5;
        }
        uVar3 = 1;
        *(uint64_t *)(*in_RCX + uVar4 * 8) = *(uint64_t *)(*in_RCX + uVar4 * 8) | 1LL << ((uint32_t)in_RDX & 0x3f);
    }
    return uVar3;
}

// ============================================================
// Function: FUN_180255860
// Address: 0x180255860
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180255860(int64_t arg_30h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t **ppiVar2;
    int64_t **in_RCX;
    int64_t in_RDX;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180255870;
    iVar1 = fcn.18045a350();
    ppiVar2 = in_RCX;
    if (*(int32_t *)((int64_t)in_RCX + 0xc) < 1) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18025588e;
        ppiVar2 = (int64_t **)func_0x000180256190();
    }
    if (ppiVar2 != (int64_t **)0x0) {
        *(undefined4 *)(in_RCX + 2) = 0;
        **in_RCX = in_RDX;
        *(uint32_t *)(in_RCX + 1) = (uint32_t)(in_RDX != 0);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1802558d0
// Address: 0x1802558d0
// Size: 52 bytes
// ============================================================
undefined8 fcn.1802558d0(undefined8 param_1, undefined8 param_2, int32_t param_3)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802558da;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_3 < 0) {
        return 0xffffffff;
    }
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802558ff;
    uVar2 = fcn.180255d90(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000060 + iVar1));
    return uVar2;
}

// ============================================================
// Function: FUN_180255910
// Address: 0x180255910
// Size: 37 bytes
// ============================================================
void fcn.180255910(void)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025591a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180255930;
    fcn.180255b10(*(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180255940
// Address: 0x180255940
// Size: 31 bytes
// ============================================================
void fcn.180255940(void)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025594a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025595a;
    fcn.1802cd800(*(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180255960
// Address: 0x180255960
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint32_t fcn.180255960(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    uint64_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    uint64_t *puVar6;
    int64_t *piVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar1 = (int32_t *)(arg2 + 8);
    piVar7 = *(int64_t **)arg2;
    if (((*(uint8_t *)(arg1 + 0x14) & 4) != 0) && (*(int32_t *)(arg1 + 8) == *piVar1)) {
        uVar9 = 0;
        iVar8 = 0;
        if (0 < *piVar1) {
            iVar10 = *(int64_t *)arg1 - (int64_t)piVar7;
            do {
                iVar8 = iVar8 + 1;
                uVar3 = (uint32_t)((uint64_t)*piVar7 >> 0x20);
                uVar4 = (uint32_t)((uint64_t)*(int64_t *)((int64_t)piVar7 + iVar10) >> 0x20);
                uVar5 = (int32_t)(((uint32_t)((uint64_t)(*(int64_t *)((int64_t)piVar7 + iVar10) - *piVar7) >> 0x20) ^
                                   uVar3 | uVar3 ^ uVar4) ^ uVar4) >> 0x1f;
                uVar3 = (uint32_t)((uint64_t)*(undefined8 *)((int64_t)piVar7 + iVar10) >> 0x20);
                uVar4 = (uint32_t)((uint64_t)*piVar7 >> 0x20);
                uVar3 = (int32_t)(((uint32_t)((uint64_t)(*piVar7 - *(int64_t *)((int64_t)piVar7 + iVar10)) >> 0x20) ^
                                   uVar3 | uVar3 ^ uVar4) ^ uVar4) >> 0x1f;
                uVar9 = (uVar9 & ~uVar5 | uVar5) & ~uVar3 | uVar3 & 1;
                piVar7 = piVar7 + 1;
            } while (iVar8 < *piVar1);
        }
        return uVar9;
    }
    iVar8 = *(int32_t *)(arg1 + 8);
    uVar9 = iVar8 - *piVar1;
    if (uVar9 == 0) {
        iVar8 = iVar8 + -1;
        iVar10 = (int64_t)iVar8;
        if (-1 < iVar8) {
            puVar6 = (uint64_t *)(piVar7 + iVar10);
            do {
                uVar2 = *(uint64_t *)((int64_t)puVar6 + (*(int64_t *)arg1 - (int64_t)piVar7));
                if (uVar2 != *puVar6) {
                    uVar9 = 0xffffffff;
                    if (*puVar6 < uVar2) {
                        uVar9 = 1;
                    }
                    return uVar9;
                }
                puVar6 = puVar6 + -1;
                iVar10 = iVar10 + -1;
            } while (-1 < iVar10);
        }
        uVar9 = 0;
    }
    return uVar9;
}

// ============================================================
// Function: FUN_180255988
// Address: 0x180255988
// Size: 213 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint32_t fcn.180255960(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    uint64_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    uint64_t *puVar6;
    int64_t *piVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar1 = (int32_t *)(arg2 + 8);
    piVar7 = *(int64_t **)arg2;
    if (((*(uint8_t *)(arg1 + 0x14) & 4) != 0) && (*(int32_t *)(arg1 + 8) == *piVar1)) {
        uVar9 = 0;
        iVar8 = 0;
        if (0 < *piVar1) {
            iVar10 = *(int64_t *)arg1 - (int64_t)piVar7;
            do {
                iVar8 = iVar8 + 1;
                uVar3 = (uint32_t)((uint64_t)*piVar7 >> 0x20);
                uVar4 = (uint32_t)((uint64_t)*(int64_t *)((int64_t)piVar7 + iVar10) >> 0x20);
                uVar5 = (int32_t)(((uint32_t)((uint64_t)(*(int64_t *)((int64_t)piVar7 + iVar10) - *piVar7) >> 0x20) ^
                                   uVar3 | uVar3 ^ uVar4) ^ uVar4) >> 0x1f;
                uVar3 = (uint32_t)((uint64_t)*(undefined8 *)((int64_t)piVar7 + iVar10) >> 0x20);
                uVar4 = (uint32_t)((uint64_t)*piVar7 >> 0x20);
                uVar3 = (int32_t)(((uint32_t)((uint64_t)(*piVar7 - *(int64_t *)((int64_t)piVar7 + iVar10)) >> 0x20) ^
                                   uVar3 | uVar3 ^ uVar4) ^ uVar4) >> 0x1f;
                uVar9 = (uVar9 & ~uVar5 | uVar5) & ~uVar3 | uVar3 & 1;
                piVar7 = piVar7 + 1;
            } while (iVar8 < *piVar1);
        }
        return uVar9;
    }
    iVar8 = *(int32_t *)(arg1 + 8);
    uVar9 = iVar8 - *piVar1;
    if (uVar9 == 0) {
        iVar8 = iVar8 + -1;
        iVar10 = (int64_t)iVar8;
        if (-1 < iVar8) {
            puVar6 = (uint64_t *)(piVar7 + iVar10);
            do {
                uVar2 = *(uint64_t *)((int64_t)puVar6 + (*(int64_t *)arg1 - (int64_t)piVar7));
                if (uVar2 != *puVar6) {
                    uVar9 = 0xffffffff;
                    if (*puVar6 < uVar2) {
                        uVar9 = 1;
                    }
                    return uVar9;
                }
                puVar6 = puVar6 + -1;
                iVar10 = iVar10 + -1;
            } while (-1 < iVar10);
        }
        uVar9 = 0;
    }
    return uVar9;
}

// ============================================================
// Function: FUN_180255a5d
// Address: 0x180255a5d
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint32_t fcn.180255960(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    uint64_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    uint64_t *puVar6;
    int64_t *piVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar1 = (int32_t *)(arg2 + 8);
    piVar7 = *(int64_t **)arg2;
    if (((*(uint8_t *)(arg1 + 0x14) & 4) != 0) && (*(int32_t *)(arg1 + 8) == *piVar1)) {
        uVar9 = 0;
        iVar8 = 0;
        if (0 < *piVar1) {
            iVar10 = *(int64_t *)arg1 - (int64_t)piVar7;
            do {
                iVar8 = iVar8 + 1;
                uVar3 = (uint32_t)((uint64_t)*piVar7 >> 0x20);
                uVar4 = (uint32_t)((uint64_t)*(int64_t *)((int64_t)piVar7 + iVar10) >> 0x20);
                uVar5 = (int32_t)(((uint32_t)((uint64_t)(*(int64_t *)((int64_t)piVar7 + iVar10) - *piVar7) >> 0x20) ^
                                   uVar3 | uVar3 ^ uVar4) ^ uVar4) >> 0x1f;
                uVar3 = (uint32_t)((uint64_t)*(undefined8 *)((int64_t)piVar7 + iVar10) >> 0x20);
                uVar4 = (uint32_t)((uint64_t)*piVar7 >> 0x20);
                uVar3 = (int32_t)(((uint32_t)((uint64_t)(*piVar7 - *(int64_t *)((int64_t)piVar7 + iVar10)) >> 0x20) ^
                                   uVar3 | uVar3 ^ uVar4) ^ uVar4) >> 0x1f;
                uVar9 = (uVar9 & ~uVar5 | uVar5) & ~uVar3 | uVar3 & 1;
                piVar7 = piVar7 + 1;
            } while (iVar8 < *piVar1);
        }
        return uVar9;
    }
    iVar8 = *(int32_t *)(arg1 + 8);
    uVar9 = iVar8 - *piVar1;
    if (uVar9 == 0) {
        iVar8 = iVar8 + -1;
        iVar10 = (int64_t)iVar8;
        if (-1 < iVar8) {
            puVar6 = (uint64_t *)(piVar7 + iVar10);
            do {
                uVar2 = *(uint64_t *)((int64_t)puVar6 + (*(int64_t *)arg1 - (int64_t)piVar7));
                if (uVar2 != *puVar6) {
                    uVar9 = 0xffffffff;
                    if (*puVar6 < uVar2) {
                        uVar9 = 1;
                    }
                    return uVar9;
                }
                puVar6 = puVar6 + -1;
                iVar10 = iVar10 + -1;
            } while (-1 < iVar10);
        }
        uVar9 = 0;
    }
    return uVar9;
}

// ============================================================
// Function: FUN_180255b10
// Address: 0x180255b10
// Size: 635 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t * fcn.180255b10(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint8_t *in_RCX;
    uint8_t *puVar3;
    int32_t in_EDX;
    int64_t iVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    uint8_t *puVar9;
    int64_t *in_R8;
    int32_t in_R9D;
    uint64_t uVar10;
    uint64_t uVar11;
    uint32_t uVar12;
    int64_t iVar13;
    int64_t *piVar14;
    uint64_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x180255b32;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar8 = (uint64_t)in_EDX;
    uVar15 = 0;
    uVar12 = 0;
    if (in_EDX < 0) {
code_r0x000180255cc9:
        in_R8 = (int64_t *)0x0;
    } else {
        piVar14 = (int64_t *)0x0;
        if (in_R8 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180255b77;
            in_R8 = (int64_t *)fcn.180224d60(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2));
            if (in_R8 == (int64_t *)0x0) {
                in_R8 = (int64_t *)0x0;
            } else {
                *(undefined4 *)((int64_t)in_R8 + 0x14) = 1;
            }
            piVar14 = in_R8;
            if (in_R8 == (int64_t *)0x0) goto code_r0x000180255cc9;
        }
        if (in_EDX == 0) {
            iVar13 = *in_R8;
            if (iVar13 != 0) {
                iVar1 = *(int32_t *)((int64_t)in_R8 + 0xc);
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180255bb3;
                func_0x000180244fc0(iVar13, (int64_t)iVar1 << 3);
            }
            *(undefined4 *)(in_R8 + 2) = 0;
            *(undefined4 *)(in_R8 + 1) = 0;
            return in_R8;
        }
        if (in_R9D == 1) {
            puVar3 = in_RCX + (uVar8 - 1);
            puVar9 = in_RCX;
        } else {
            puVar9 = in_RCX + (uVar8 - 1);
            puVar3 = in_RCX;
        }
        iVar4 = -1;
        iVar13 = 1;
        if (in_R9D != 1) {
            iVar13 = -1;
            iVar4 = 1;
        }
        if (*(int32_t *)((int64_t)&arg_58h + iVar2) == 0) {
            uVar15 = (uint64_t)(uint32_t)(*puVar3 >> 7);
            uVar12 = -(uint32_t)(*puVar3 >> 7 != 0) & 0xff;
        }
        do {
            if (*puVar3 != uVar12) break;
            puVar3 = puVar3 + iVar4;
            uVar6 = (int32_t)uVar8 - 1;
            uVar8 = (uint64_t)uVar6;
        } while (0 < (int32_t)uVar6);
        if (uVar12 == 0xff) {
            if (((int32_t)uVar8 == 0) || (-1 < (char)*puVar3)) {
                uVar8 = (uint64_t)((int32_t)uVar8 + 1);
                goto code_r0x000180255c35;
            }
        } else {
code_r0x000180255c35:
            if ((int32_t)uVar8 == 0) {
                *(undefined4 *)(in_R8 + 1) = 0;
                return in_R8;
            }
        }
        iVar1 = (int32_t)uVar8 + -1;
        iVar1 = ((int32_t)((iVar1 >> 0x1f & 7U) + iVar1) >> 3) + 1;
        if (*(int32_t *)((int64_t)in_R8 + 0xc) < iVar1) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180255c66;
            iVar4 = func_0x000180256190(in_R8, iVar1);
            if (iVar4 == 0) {
                if (piVar14 != (int64_t *)0x0) {
                    if ((*(uint32_t *)((int64_t)piVar14 + 0x14) & 2) == 0) {
                        iVar13 = *piVar14;
                        if ((*(uint32_t *)((int64_t)piVar14 + 0x14) & 8) == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180255cad;
                            func_0x000180224990(iVar13, 0x1804e5df0, 0xd2);
                        } else {
                            iVar1 = *(int32_t *)((int64_t)piVar14 + 0xc);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180255c99;
                            func_0x000180225130(iVar13, (int64_t)iVar1 << 3, 0x1804e5df0, 0xce);
                        }
                    }
                    if ((*(uint8_t *)((int64_t)piVar14 + 0x14) & 1) != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180255cc9;
                        func_0x000180224990(piVar14, 0x1804e5df0, 0xe9);
                    }
                }
                goto code_r0x000180255cc9;
            }
        }
        uVar11 = 0;
        *(int32_t *)(in_R8 + 1) = iVar1;
        *(int32_t *)(in_R8 + 2) = (int32_t)uVar15;
        while (iVar1 != 0) {
            iVar1 = iVar1 + -1;
            uVar10 = 0;
            uVar7 = (uint32_t)uVar8;
            for (uVar6 = 0; (0 < (int32_t)uVar7 && (uVar6 < 0x40)); uVar6 = uVar6 + 8) {
                uVar5 = ((uint64_t)*puVar9 ^ (uint64_t)uVar12) + uVar15 & 0xff;
                uVar15 = (uint64_t)(uVar5 < ((uint64_t)*puVar9 ^ (uint64_t)uVar12));
                uVar10 = uVar10 | uVar5 << ((uint8_t)uVar6 & 0x3f);
                uVar7 = (int32_t)uVar8 - 1;
                uVar8 = (uint64_t)uVar7;
                puVar9 = puVar9 + iVar13;
            }
            *(uint64_t *)(*in_R8 + uVar11 * 8) = uVar10;
            uVar11 = (uint64_t)((int32_t)uVar11 + 1);
        }
        uVar12 = *(uint32_t *)(in_R8 + 1);
        uVar8 = (uint64_t)(int32_t)uVar12;
        if (0 < (int32_t)uVar12) {
            iVar2 = *in_R8 + uVar8 * 8;
            do {
                uVar12 = (uint32_t)uVar8;
                piVar14 = (int64_t *)(iVar2 + -8);
                iVar2 = iVar2 + -8;
                if (*piVar14 != 0) break;
                uVar12 = uVar12 - 1;
                uVar8 = (uint64_t)uVar12;
            } while (0 < (int32_t)uVar12);
            *(uint32_t *)(in_R8 + 1) = uVar12;
        }
        if (uVar12 == 0) {
            *(undefined4 *)(in_R8 + 2) = 0;
        }
    }
    return in_R8;
}

// ============================================================
// Function: FUN_180255d90
// Address: 0x180255d90
// Size: 487 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180255d90(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_68h)
{
    int64_t *piVar1;
    bool bVar2;
    int64_t iVar3;
    uint8_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int64_t iVar9;
    undefined4 uVar10;
    int64_t *in_RCX;
    uint8_t *in_RDX;
    uint32_t uVar11;
    uint32_t uVar12;
    uint8_t uVar13;
    uint32_t in_R8D;
    int64_t iVar14;
    int32_t in_R9D;
    uint64_t uVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x180255db2;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar11 = 0;
    uVar17 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x180255dd2;
    iVar5 = fcn.180255500(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar9), *(int64_t *)((int64_t)&arg_50h + iVar9));
    iVar6 = (int32_t)(iVar5 + 7 + (iVar5 + 7 >> 0x1f & 7U)) >> 3;
    uVar12 = 0;
    if (*(int32_t *)((int64_t)&arg_68h + iVar9) == 0) {
        uVar11 = *(uint32_t *)(in_RCX + 2);
        uVar17 = -(uVar11 != 0);
        uVar12 = uVar11;
        if (iVar6 * 8 == iVar5) {
            uVar12 = (uint32_t)(uVar11 == 0);
        }
    }
    uVar7 = iVar6 + uVar12;
    if ((in_R8D != 0xffffffff) && (bVar2 = (int32_t)in_R8D < (int32_t)uVar7, uVar7 = in_R8D, bVar2)) {
        iVar14 = *in_RCX;
        iVar3 = in_RCX[1];
        uVar8 = *(uint32_t *)(in_RCX + 1);
        uVar15 = (uint64_t)(int32_t)uVar8;
        *(int64_t *)((int64_t)&var_8h + iVar9) = in_RCX[2];
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar9) = iVar14;
        *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20) = iVar3;
        if (0 < (int32_t)uVar8) {
            iVar14 = iVar14 + uVar15 * 8;
            do {
                uVar8 = (uint32_t)uVar15;
                piVar1 = (int64_t *)(iVar14 + -8);
                iVar14 = iVar14 + -8;
                if (*piVar1 != 0) break;
                uVar8 = uVar8 - 1;
                uVar15 = (uint64_t)uVar8;
            } while (0 < (int32_t)uVar8);
            *(uint32_t *)((int64_t)&iStackX_20 + iVar9 + -0x20) = uVar8;
        }
        uVar10 = *(undefined4 *)((int64_t)&var_8h + iVar9);
        if (uVar8 == 0) {
            uVar10 = 0;
        }
        *(undefined4 *)((int64_t)&var_8h + iVar9) = uVar10;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x180255e9c;
        iVar5 = fcn.180255500(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar9), *(int64_t *)((int64_t)&arg_48h + iVar9), 
                              *(int64_t *)((int64_t)&arg_50h + iVar9));
        if ((int32_t)in_R8D < (int32_t)(((int32_t)(iVar5 + 7 + (iVar5 + 7 >> 0x1f & 7U)) >> 3) + uVar12)) {
            return 0xffffffffffffffff;
        }
    }
    uVar12 = *(uint32_t *)((int64_t)in_RCX + 0xc);
    if ((uVar12 & 0x1fffffff) == 0) {
        if (uVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x180255e3e;
            fcn.1804986e0(in_RDX, 0, (int64_t)(int32_t)uVar7);
        }
    } else {
        if (in_R9D != 1) {
            in_RDX = in_RDX + (int32_t)(uVar7 - 1);
        }
        iVar9 = 1;
        if (in_R9D != 1) {
            iVar9 = -1;
        }
        iVar5 = *(int32_t *)(in_RCX + 1);
        uVar15 = 0;
        uVar16 = 0;
        if (uVar7 != 0) {
            do {
                uVar13 = (uint8_t)(*(uint64_t *)(*in_RCX + (uVar15 & 0xfffffffffffffff8)) >>
                                  (((uint8_t)uVar15 & 7) << 3)) &
                         (uint8_t)((int64_t)(uVar16 - (int64_t)(iVar5 << 3)) >> 0x3f) ^ uVar17;
                uVar4 = uVar13 + (char)uVar11;
                *in_RDX = uVar4;
                uVar11 = (uint32_t)(uVar4 < uVar13);
                in_RDX = in_RDX + iVar9;
                uVar15 = uVar15 - ((int64_t)(uVar15 - ((int64_t)(int32_t)(uVar12 << 3) + -1)) >> 0x3f);
                uVar16 = uVar16 + 1;
            } while (uVar16 < (uint64_t)(int64_t)(int32_t)uVar7);
        }
    }
    return (uint64_t)uVar7;
}

// ============================================================
// Function: FUN_180255f80
// Address: 0x180255f80
// Size: 203 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180255f80(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint64_t uVar1;
    uint64_t uVar2;
    undefined8 uVar3;
    uint64_t *puVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    bool bVar10;
    bool bVar11;
    int64_t var_8h;
    
    iVar7 = (int32_t)arg3;
    iVar5 = (int64_t)iVar7 + -1;
    iVar8 = (int32_t)arg4;
    if (iVar8 < 0) {
        iVar9 = (int64_t)iVar8;
        if (iVar9 < 0) {
            piVar6 = (int64_t *)(arg2 + (iVar5 - iVar9) * 8);
            do {
                if (*piVar6 != 0) {
                    return 0xffffffff;
                }
                piVar6 = piVar6 + -1;
                iVar9 = iVar9 + 1;
            } while (iVar9 < 0);
        }
    } else if ((0 < iVar8) && (iVar9 = (int64_t)iVar8, iVar8 != 0)) {
        piVar6 = (int64_t *)(arg1 + (iVar9 + iVar5) * 8);
        do {
            if (*piVar6 != 0) {
                return 1;
            }
            iVar9 = iVar9 + -1;
            piVar6 = piVar6 + -1;
        } while (0 < iVar9);
    }
    if (iVar7 != 0) {
        uVar1 = *(uint64_t *)(arg1 + iVar5 * 8);
        uVar2 = *(uint64_t *)(arg2 + iVar5 * 8);
        bVar10 = uVar1 < uVar2;
        bVar11 = uVar1 == uVar2;
        if (!bVar11) {
code_r0x000180255fce:
            uVar3 = 0xffffffff;
            if (!bVar10 && !bVar11) {
                uVar3 = 1;
            }
            return uVar3;
        }
        iVar5 = (int64_t)(iVar7 + -2);
        if (-1 < iVar7 + -2) {
            puVar4 = (uint64_t *)(arg2 + iVar5 * 8);
            do {
                uVar1 = *(uint64_t *)((int64_t)puVar4 + (arg1 - arg2));
                bVar10 = uVar1 < *puVar4;
                bVar11 = uVar1 == *puVar4;
                if (!bVar11) goto code_r0x000180255fce;
                puVar4 = puVar4 + -1;
                iVar5 = iVar5 + -1;
            } while (-1 < iVar5);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802560d0
// Address: 0x1802560d0
// Size: 28 bytes
// ============================================================
void fcn.1802560d0(int64_t *param_1)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint32_t uVar3;
    undefined8 unaff_RBX;
    int64_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int64_t var_10h;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar5 = 0;
    uVar6 = 0;
    if (0 < *(int32_t *)((int64_t)param_1 + 0xc)) {
        *(undefined8 *)(&stack0x00000000 + iVar2) = unaff_RBX;
        iVar4 = 0;
        do {
            uVar3 = (int32_t)(((uint32_t)((uint64_t)-*(int64_t *)(iVar4 + *param_1) >> 0x20) |
                              (uint32_t)((uint64_t)*(int64_t *)(iVar4 + *param_1) >> 0x20)) &
                             uVar5 - *(int32_t *)(param_1 + 1)) >> 0x1f;
            *(uint32_t *)((int64_t)&var_10h + iVar2) = uVar3;
            uVar5 = uVar5 + 1;
            uVar1 = *(uint32_t *)((int64_t)&var_10h + iVar2);
            *(uint32_t *)((int64_t)&var_10h + iVar2) = ~uVar3;
            uVar6 = uVar5 & uVar1 | *(uint32_t *)((int64_t)&var_10h + iVar2) & uVar6;
            iVar4 = iVar4 + 8;
        } while ((int32_t)uVar5 < *(int32_t *)((int64_t)param_1 + 0xc));
    }
    *(uint32_t *)(param_1 + 1) = uVar6;
    uVar5 = (int32_t)(uVar6 - 1 & ~uVar6) >> 0x1f;
    *(uint32_t *)((int64_t)&var_10h + iVar2) = uVar5;
    *(uint32_t *)((int64_t)&var_10h + iVar2) = ~uVar5;
    *(uint32_t *)(param_1 + 2) = *(uint32_t *)(param_1 + 2) & *(uint32_t *)((int64_t)&var_10h + iVar2);
    return;
}

// ============================================================
// Function: FUN_1802560ec
// Address: 0x1802560ec
// Size: 109 bytes
// ============================================================
void fcn.1802560d0(int64_t *param_1)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint32_t uVar3;
    undefined8 unaff_RBX;
    int64_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int64_t var_10h;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar5 = 0;
    uVar6 = 0;
    if (0 < *(int32_t *)((int64_t)param_1 + 0xc)) {
        *(undefined8 *)(&stack0x00000000 + iVar2) = unaff_RBX;
        iVar4 = 0;
        do {
            uVar3 = (int32_t)(((uint32_t)((uint64_t)-*(int64_t *)(iVar4 + *param_1) >> 0x20) |
                              (uint32_t)((uint64_t)*(int64_t *)(iVar4 + *param_1) >> 0x20)) &
                             uVar5 - *(int32_t *)(param_1 + 1)) >> 0x1f;
            *(uint32_t *)((int64_t)&var_10h + iVar2) = uVar3;
            uVar5 = uVar5 + 1;
            uVar1 = *(uint32_t *)((int64_t)&var_10h + iVar2);
            *(uint32_t *)((int64_t)&var_10h + iVar2) = ~uVar3;
            uVar6 = uVar5 & uVar1 | *(uint32_t *)((int64_t)&var_10h + iVar2) & uVar6;
            iVar4 = iVar4 + 8;
        } while ((int32_t)uVar5 < *(int32_t *)((int64_t)param_1 + 0xc));
    }
    *(uint32_t *)(param_1 + 1) = uVar6;
    uVar5 = (int32_t)(uVar6 - 1 & ~uVar6) >> 0x1f;
    *(uint32_t *)((int64_t)&var_10h + iVar2) = uVar5;
    *(uint32_t *)((int64_t)&var_10h + iVar2) = ~uVar5;
    *(uint32_t *)(param_1 + 2) = *(uint32_t *)(param_1 + 2) & *(uint32_t *)((int64_t)&var_10h + iVar2);
    return;
}

// ============================================================
// Function: FUN_180256159
// Address: 0x180256159
// Size: 50 bytes
// ============================================================
void fcn.1802560d0(int64_t *param_1)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint32_t uVar3;
    undefined8 unaff_RBX;
    int64_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int64_t var_10h;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar5 = 0;
    uVar6 = 0;
    if (0 < *(int32_t *)((int64_t)param_1 + 0xc)) {
        *(undefined8 *)(&stack0x00000000 + iVar2) = unaff_RBX;
        iVar4 = 0;
        do {
            uVar3 = (int32_t)(((uint32_t)((uint64_t)-*(int64_t *)(iVar4 + *param_1) >> 0x20) |
                              (uint32_t)((uint64_t)*(int64_t *)(iVar4 + *param_1) >> 0x20)) &
                             uVar5 - *(int32_t *)(param_1 + 1)) >> 0x1f;
            *(uint32_t *)((int64_t)&var_10h + iVar2) = uVar3;
            uVar5 = uVar5 + 1;
            uVar1 = *(uint32_t *)((int64_t)&var_10h + iVar2);
            *(uint32_t *)((int64_t)&var_10h + iVar2) = ~uVar3;
            uVar6 = uVar5 & uVar1 | *(uint32_t *)((int64_t)&var_10h + iVar2) & uVar6;
            iVar4 = iVar4 + 8;
        } while ((int32_t)uVar5 < *(int32_t *)((int64_t)param_1 + 0xc));
    }
    *(uint32_t *)(param_1 + 1) = uVar6;
    uVar5 = (int32_t)(uVar6 - 1 & ~uVar6) >> 0x1f;
    *(uint32_t *)((int64_t)&var_10h + iVar2) = uVar5;
    *(uint32_t *)((int64_t)&var_10h + iVar2) = ~uVar5;
    *(uint32_t *)(param_1 + 2) = *(uint32_t *)(param_1 + 2) & *(uint32_t *)((int64_t)&var_10h + iVar2);
    return;
}

// ============================================================
// Function: FUN_180256190
// Address: 0x180256190
// Size: 336 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t * fcn.180256190(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802561a5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_EDX <= *(int32_t *)((int64_t)in_RCX + 0xc)) {
        return in_RCX;
    }
    if (in_EDX < 0x800000) {
        if ((*(uint32_t *)((int64_t)in_RCX + 0x14) & 2) == 0) {
            if ((*(uint32_t *)((int64_t)in_RCX + 0x14) & 8) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180256259;
                iVar4 = fcn.180224e40(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025624c;
                iVar4 = fcn.180224fe0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                      *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                                      *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
            }
            if (iVar4 == 0) {
                return (int64_t *)0x0;
            }
            iVar1 = *(int32_t *)(in_RCX + 1);
            if (0 < iVar1) {
                iVar2 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025627b;
                fcn.180498030(iVar4, iVar2, (int64_t)iVar1 << 3);
            }
            if (*in_RCX != 0) {
                if ((*(uint8_t *)((int64_t)in_RCX + 0x14) & 8) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802562a3;
                    fcn.180225130(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    *in_RCX = iVar4;
                    *(int32_t *)((int64_t)in_RCX + 0xc) = in_EDX;
                    return in_RCX;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802562c7;
                fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
            }
            *in_RCX = iVar4;
            *(int32_t *)((int64_t)in_RCX + 0xc) = in_EDX;
            return in_RCX;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025620c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180256224;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802561c4;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802561dc;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802561ee;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_180256300
// Address: 0x180256300
// Size: 35 bytes
// ============================================================
int64_t * fcn.180256300(int64_t *param_1, int32_t param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (param_2 <= *(int32_t *)((int64_t)param_1 + 0xc)) {
        return param_1;
    }
    *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x1802561a5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int32_t *)((int64_t)param_1 + 0xc) < param_2) {
        if (param_2 < 0x800000) {
            if ((*(uint32_t *)((int64_t)param_1 + 0x14) & 2) == 0) {
                if ((*(uint32_t *)((int64_t)param_1 + 0x14) & 8) == 0) {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x180256259;
                    iVar4 = fcn.180224e40(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5));
                } else {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18025624c;
                    iVar4 = fcn.180224fe0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), 
                                          *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                                          *(int64_t *)(&stack0x00000058 + iVar3 + iVar5), 
                                          *(int64_t *)(&stack0x00000060 + iVar3 + iVar5), 
                                          *(int64_t *)(&stack0x00000068 + iVar3 + iVar5), 
                                          *(int64_t *)(&stack0x00000070 + iVar3 + iVar5), 
                                          *(int64_t *)(&stack0x00000078 + iVar3 + iVar5));
                }
                if (iVar4 == 0) {
                    return (int64_t *)0x0;
                }
                iVar1 = *(int32_t *)(param_1 + 1);
                if (0 < iVar1) {
                    iVar2 = *param_1;
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18025627b;
                    fcn.180498030(iVar4, iVar2, (int64_t)iVar1 << 3);
                }
                if (*param_1 != 0) {
                    if ((*(uint8_t *)((int64_t)param_1 + 0x14) & 8) != 0) {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802562a3;
                        fcn.180225130(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), 
                                      *(int64_t *)(&stack0x00000048 + iVar3 + iVar5));
                        *param_1 = iVar4;
                        *(int32_t *)((int64_t)param_1 + 0xc) = param_2;
                        return param_1;
                    }
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802562c7;
                    fcn.180224b90(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000048 + iVar3 + iVar5));
                }
                *param_1 = iVar4;
                *(int32_t *)((int64_t)param_1 + 0xc) = param_2;
                return param_1;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18025620c;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), *(int64_t *)(&stack0x00000048 + iVar3 + iVar5)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x180256224;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), *(int64_t *)(&stack0x00000048 + iVar3 + iVar5)
                          , *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                          *(int64_t *)(&stack0x00000058 + iVar3 + iVar5), *(int64_t *)(&stack0x00000070 + iVar3 + iVar5)
                         );
        } else {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802561c4;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), *(int64_t *)(&stack0x00000048 + iVar3 + iVar5)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802561dc;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), *(int64_t *)(&stack0x00000048 + iVar3 + iVar5)
                          , *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                          *(int64_t *)(&stack0x00000058 + iVar3 + iVar5), *(int64_t *)(&stack0x00000070 + iVar3 + iVar5)
                         );
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802561ee;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar5));
        return (int64_t *)0x0;
    }
    return param_1;
}

// ============================================================
// Function: FUN_180256430
// Address: 0x180256430
// Size: 37 bytes
// ============================================================
void fcn.180256430(int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x180254c3a;
    iVar1 = fcn.18045a350(0x1804e5e80, 0x80, in_RCX);
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_48h + iVar1 + iVar2) = 1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar2) = 0x180254c4d;
    fcn.180255b10(*(int64_t *)(&stack0x00000058 + iVar1 + iVar2), *(int64_t *)(&stack0x00000060 + iVar1 + iVar2), 
                  *(int64_t *)(&stack0x00000068 + iVar1 + iVar2), *(int64_t *)(&stack0x00000078 + iVar1 + iVar2));
    return;
}

// ============================================================
// Function: FUN_180256460
// Address: 0x180256460
// Size: 50 bytes
// ============================================================
undefined8 * fcn.180256460(int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h, int64_t arg_88h)
{
    int32_t iVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 *in_RCX;
    undefined8 *puVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_RCX != (undefined8 *)0x0) {
        puVar9 = (undefined8 *)0x1804fd268;
        *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_RSI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar8) = 0x180255125;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        iVar1 = *(int32_t *)(((uint64_t)(*(uint32_t *)((int64_t)puVar9 + 0x14) & 4) | 8) + (int64_t)puVar9);
        if (in_RCX != puVar9) {
            puVar6 = in_RCX;
            if (*(int32_t *)((int64_t)in_RCX + 0xc) < iVar1) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x180255152;
                puVar6 = (undefined8 *)
                         fcn.180256190(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar8), 
                                       *(int64_t *)(&stack0x00000048 + iVar5 + iVar8));
            }
            if (puVar6 == (undefined8 *)0x0) {
                return (undefined8 *)0x0;
            }
            if (0 < *(int32_t *)(puVar9 + 1)) {
                uVar3 = *puVar9;
                uVar4 = *in_RCX;
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x18025517f;
                fcn.180498030(uVar4, uVar3, (int64_t)iVar1 << 3);
            }
            *(undefined4 *)(in_RCX + 2) = *(undefined4 *)(puVar9 + 2);
            *(undefined4 *)(in_RCX + 1) = *(undefined4 *)(puVar9 + 1);
        }
        return in_RCX;
    }
    puVar9 = (undefined8 *)0x1804fd268;
    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar8 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar8) = 0x1802551b0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (puVar9 != (undefined8 *)0x0) {
        if ((*(uint8_t *)((int64_t)puVar9 + 0x14) & 8) == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x1802551f2;
            puVar6 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar8));
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 1;
            }
        } else {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x1802551dc;
            puVar6 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar8));
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 9;
            }
        }
        if (puVar6 != (undefined8 *)0x0) {
            uVar2 = *(uint32_t *)((int64_t)puVar9 + 0x14);
            *(undefined8 *)((int64_t)&arg_58h + iVar5 + iVar8) = unaff_RSI;
            iVar1 = *(int32_t *)(((uint64_t)(uVar2 & 4) | 8) + (int64_t)puVar9);
            if (puVar6 != puVar9) {
                if (*(int32_t *)((int64_t)puVar6 + 0xc) < iVar1) {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x18025522d;
                    iVar7 = fcn.180256190(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar8), 
                                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar8));
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x18025523a;
                        fcn.180255290((int64_t)puVar6);
                        return (undefined8 *)0x0;
                    }
                }
                if (0 < *(int32_t *)(puVar9 + 1)) {
                    uVar3 = *puVar9;
                    uVar4 = *puVar6;
                    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x180255264;
                    fcn.180498030(uVar4, uVar3, (int64_t)iVar1 << 3);
                }
                *(undefined4 *)(puVar6 + 2) = *(undefined4 *)(puVar9 + 2);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(puVar9 + 1);
            }
            return puVar6;
        }
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_1802564a0
// Address: 0x1802564a0
// Size: 50 bytes
// ============================================================
undefined8 * fcn.1802564a0(undefined8 *param_1)
{
    int32_t iVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (param_1 != (undefined8 *)0x0) {
        puVar9 = (undefined8 *)0x1804fd280;
        *(undefined8 *)(&stack0x00000038 + iVar8) = unaff_RBX;
        *(undefined8 *)(&stack0x00000040 + iVar8) = unaff_RSI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar8) = 0x180255125;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        iVar1 = *(int32_t *)(((uint64_t)(*(uint32_t *)((int64_t)puVar9 + 0x14) & 4) | 8) + (int64_t)puVar9);
        if (param_1 != puVar9) {
            puVar6 = param_1;
            if (*(int32_t *)((int64_t)param_1 + 0xc) < iVar1) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x180255152;
                puVar6 = (undefined8 *)
                         fcn.180256190(*(int64_t *)(&stack0x00000040 + iVar5 + iVar8), 
                                       *(int64_t *)(&stack0x00000048 + iVar5 + iVar8));
            }
            if (puVar6 == (undefined8 *)0x0) {
                return (undefined8 *)0x0;
            }
            if (0 < *(int32_t *)(puVar9 + 1)) {
                uVar3 = *puVar9;
                uVar4 = *param_1;
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x18025517f;
                fcn.180498030(uVar4, uVar3, (int64_t)iVar1 << 3);
            }
            *(undefined4 *)(param_1 + 2) = *(undefined4 *)(puVar9 + 2);
            *(undefined4 *)(param_1 + 1) = *(undefined4 *)(puVar9 + 1);
        }
        return param_1;
    }
    puVar9 = (undefined8 *)0x1804fd280;
    *(undefined8 *)(&stack0x00000040 + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar8 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar8) = 0x1802551b0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (puVar9 != (undefined8 *)0x0) {
        if ((*(uint8_t *)((int64_t)puVar9 + 0x14) & 8) == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x1802551f2;
            puVar6 = (undefined8 *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar5 + iVar8));
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 1;
            }
        } else {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x1802551dc;
            puVar6 = (undefined8 *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar5 + iVar8));
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 9;
            }
        }
        if (puVar6 != (undefined8 *)0x0) {
            uVar2 = *(uint32_t *)((int64_t)puVar9 + 0x14);
            *(undefined8 *)(&stack0x00000058 + iVar5 + iVar8) = unaff_RSI;
            iVar1 = *(int32_t *)(((uint64_t)(uVar2 & 4) | 8) + (int64_t)puVar9);
            if (puVar6 != puVar9) {
                if (*(int32_t *)((int64_t)puVar6 + 0xc) < iVar1) {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x18025522d;
                    iVar7 = fcn.180256190(*(int64_t *)(&stack0x00000040 + iVar5 + iVar8), 
                                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar8));
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x18025523a;
                        fcn.180255290((int64_t)puVar6);
                        return (undefined8 *)0x0;
                    }
                }
                if (0 < *(int32_t *)(puVar9 + 1)) {
                    uVar3 = *puVar9;
                    uVar4 = *puVar6;
                    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x180255264;
                    fcn.180498030(uVar4, uVar3, (int64_t)iVar1 << 3);
                }
                *(undefined4 *)(puVar6 + 2) = *(undefined4 *)(puVar9 + 2);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(puVar9 + 1);
            }
            return puVar6;
        }
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_1802564e0
// Address: 0x1802564e0
// Size: 50 bytes
// ============================================================
undefined8 * fcn.1802564e0(undefined8 *param_1)
{
    int32_t iVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (param_1 != (undefined8 *)0x0) {
        puVar9 = (undefined8 *)0x1804fd298;
        *(undefined8 *)(&stack0x00000038 + iVar8) = unaff_RBX;
        *(undefined8 *)(&stack0x00000040 + iVar8) = unaff_RSI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar8) = 0x180255125;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        iVar1 = *(int32_t *)(((uint64_t)(*(uint32_t *)((int64_t)puVar9 + 0x14) & 4) | 8) + (int64_t)puVar9);
        if (param_1 != puVar9) {
            puVar6 = param_1;
            if (*(int32_t *)((int64_t)param_1 + 0xc) < iVar1) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x180255152;
                puVar6 = (undefined8 *)
                         fcn.180256190(*(int64_t *)(&stack0x00000040 + iVar5 + iVar8), 
                                       *(int64_t *)(&stack0x00000048 + iVar5 + iVar8));
            }
            if (puVar6 == (undefined8 *)0x0) {
                return (undefined8 *)0x0;
            }
            if (0 < *(int32_t *)(puVar9 + 1)) {
                uVar3 = *puVar9;
                uVar4 = *param_1;
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x18025517f;
                fcn.180498030(uVar4, uVar3, (int64_t)iVar1 << 3);
            }
            *(undefined4 *)(param_1 + 2) = *(undefined4 *)(puVar9 + 2);
            *(undefined4 *)(param_1 + 1) = *(undefined4 *)(puVar9 + 1);
        }
        return param_1;
    }
    puVar9 = (undefined8 *)0x1804fd298;
    *(undefined8 *)(&stack0x00000040 + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar8 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar8) = 0x1802551b0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (puVar9 != (undefined8 *)0x0) {
        if ((*(uint8_t *)((int64_t)puVar9 + 0x14) & 8) == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x1802551f2;
            puVar6 = (undefined8 *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar5 + iVar8));
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 1;
            }
        } else {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x1802551dc;
            puVar6 = (undefined8 *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar5 + iVar8));
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 9;
            }
        }
        if (puVar6 != (undefined8 *)0x0) {
            uVar2 = *(uint32_t *)((int64_t)puVar9 + 0x14);
            *(undefined8 *)(&stack0x00000058 + iVar5 + iVar8) = unaff_RSI;
            iVar1 = *(int32_t *)(((uint64_t)(uVar2 & 4) | 8) + (int64_t)puVar9);
            if (puVar6 != puVar9) {
                if (*(int32_t *)((int64_t)puVar6 + 0xc) < iVar1) {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x18025522d;
                    iVar7 = fcn.180256190(*(int64_t *)(&stack0x00000040 + iVar5 + iVar8), 
                                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar8));
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x18025523a;
                        fcn.180255290((int64_t)puVar6);
                        return (undefined8 *)0x0;
                    }
                }
                if (0 < *(int32_t *)(puVar9 + 1)) {
                    uVar3 = *puVar9;
                    uVar4 = *puVar6;
                    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x180255264;
                    fcn.180498030(uVar4, uVar3, (int64_t)iVar1 << 3);
                }
                *(undefined4 *)(puVar6 + 2) = *(undefined4 *)(puVar9 + 2);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(puVar9 + 1);
            }
            return puVar6;
        }
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_180256520
// Address: 0x180256520
// Size: 50 bytes
// ============================================================
undefined8 * fcn.180256520(undefined8 *param_1)
{
    int32_t iVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (param_1 != (undefined8 *)0x0) {
        puVar9 = (undefined8 *)0x1804fd2c8;
        *(undefined8 *)(&stack0x00000038 + iVar8) = unaff_RBX;
        *(undefined8 *)(&stack0x00000040 + iVar8) = unaff_RSI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar8) = 0x180255125;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        iVar1 = *(int32_t *)(((uint64_t)(*(uint32_t *)((int64_t)puVar9 + 0x14) & 4) | 8) + (int64_t)puVar9);
        if (param_1 != puVar9) {
            puVar6 = param_1;
            if (*(int32_t *)((int64_t)param_1 + 0xc) < iVar1) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x180255152;
                puVar6 = (undefined8 *)
                         fcn.180256190(*(int64_t *)(&stack0x00000040 + iVar5 + iVar8), 
                                       *(int64_t *)(&stack0x00000048 + iVar5 + iVar8));
            }
            if (puVar6 == (undefined8 *)0x0) {
                return (undefined8 *)0x0;
            }
            if (0 < *(int32_t *)(puVar9 + 1)) {
                uVar3 = *puVar9;
                uVar4 = *param_1;
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x18025517f;
                fcn.180498030(uVar4, uVar3, (int64_t)iVar1 << 3);
            }
            *(undefined4 *)(param_1 + 2) = *(undefined4 *)(puVar9 + 2);
            *(undefined4 *)(param_1 + 1) = *(undefined4 *)(puVar9 + 1);
        }
        return param_1;
    }
    puVar9 = (undefined8 *)0x1804fd2c8;
    *(undefined8 *)(&stack0x00000040 + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar8 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar8) = 0x1802551b0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (puVar9 != (undefined8 *)0x0) {
        if ((*(uint8_t *)((int64_t)puVar9 + 0x14) & 8) == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x1802551f2;
            puVar6 = (undefined8 *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar5 + iVar8));
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 1;
            }
        } else {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x1802551dc;
            puVar6 = (undefined8 *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar5 + iVar8));
            if (puVar6 != (undefined8 *)0x0) {
                *(undefined4 *)((int64_t)puVar6 + 0x14) = 9;
            }
        }
        if (puVar6 != (undefined8 *)0x0) {
            uVar2 = *(uint32_t *)((int64_t)puVar9 + 0x14);
            *(undefined8 *)(&stack0x00000058 + iVar5 + iVar8) = unaff_RSI;
            iVar1 = *(int32_t *)(((uint64_t)(uVar2 & 4) | 8) + (int64_t)puVar9);
            if (puVar6 != puVar9) {
                if (*(int32_t *)((int64_t)puVar6 + 0xc) < iVar1) {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x18025522d;
                    iVar7 = fcn.180256190(*(int64_t *)(&stack0x00000040 + iVar5 + iVar8), 
                                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar8));
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x18025523a;
                        fcn.180255290((int64_t)puVar6);
                        return (undefined8 *)0x0;
                    }
                }
                if (0 < *(int32_t *)(puVar9 + 1)) {
                    uVar3 = *puVar9;
                    uVar4 = *puVar6;
                    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x180255264;
                    fcn.180498030(uVar4, uVar3, (int64_t)iVar1 << 3);
                }
                *(undefined4 *)(puVar6 + 2) = *(undefined4 *)(puVar9 + 2);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(puVar9 + 1);
            }
            return puVar6;
        }
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_180256560
// Address: 0x180256560
// Size: 638 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180256560(int64_t arg_28h, int64_t arg_60h, int64_t arg_68h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int32_t in_ECX;
    int32_t in_EDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180256578;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_28h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3);
    if ((in_ECX == 0) || (in_R8D == 0)) goto code_r0x000180256645;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802565b8;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_8h + iVar3));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e744;
    }
    if (iVar2 == 0) goto code_r0x000180256645;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802565de;
    piVar4 = (int32_t *)fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
    uVar6 = *(undefined8 *)0x18077e738;
    if (piVar4 == (int32_t *)0x0) goto code_r0x000180256645;
    *piVar4 = in_ECX;
    piVar4[1] = in_EDX;
    piVar4[2] = in_R8D;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802565fb;
    iVar2 = fcn.180222950(uVar6);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180256604;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025661c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025662e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180256643;
        fcn.180224990(piVar4, 0x1804e63d0, 0xa6);
        goto code_r0x000180256645;
    }
    *(int32_t *)((int64_t)&iStackX_20 + iVar3 + -8) = in_ECX;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = 0x18023bd90;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180256695;
    iVar5 = fcn.18022c840(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3));
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802566b1;
        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_8h + iVar3));
        iVar2 = 0;
        if (iVar1 != 0) {
            iVar2 = *(int32_t *)0x18077e744;
        }
        if (iVar2 == 0) {
code_r0x0001802566f4:
            if (*(int64_t *)0x18077e728 == 0) goto code_r0x000180256700;
        } else {
            if (*(int64_t *)0x18077e728 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802566d9;
                iVar2 = fcn.180221a50(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                if (-1 < iVar2) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802566eb;
                    iVar5 = fcn.180222340(*(int64_t *)0x18077e728, iVar2);
                    if (iVar5 != 0) goto code_r0x0001802567b6;
                }
                goto code_r0x0001802566f4;
            }
code_r0x000180256700:
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025670c;
            uVar6 = fcn.180221ee0(0x180247c40);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025671b;
            *(int64_t *)0x18077e728 = fcn.180222290(uVar6, 0x180196ec0);
            if (*(int64_t *)0x18077e728 == 0) goto code_r0x0001802567b6;
        }
        if (*(int64_t *)0x18077e730 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180256740;
            uVar6 = fcn.180221ee0(0x180256a20);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025674f;
            *(int64_t *)0x18077e730 = fcn.180222290(uVar6, 0x180196ec0);
            if (*(int64_t *)0x18077e730 == 0) goto code_r0x0001802567b6;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025676d;
        iVar2 = fcn.180222110(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                              *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180256780;
            iVar2 = fcn.180222110(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                                  *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3));
            if (iVar2 == 0) {
                piVar4 = (int32_t *)0x0;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180256795;
                fcn.1802222d0(*(int64_t *)0x18077e728);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802567a1;
                fcn.1802222d0(*(int64_t *)0x18077e730);
                piVar4 = (int32_t *)0x0;
            }
        }
    }
code_r0x0001802567b6:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802567cb;
    fcn.180224990(piVar4, 0x1804e63d0, 0xcc);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802567d7;
    fcn.180222910(*(undefined8 *)0x18077e738);
code_r0x000180256645:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180256652;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_28h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1802567e0
// Address: 0x1802567e0
// Size: 28 bytes
// ============================================================
void fcn.1802567e0(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_98h, int64_t arg_b0h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t in_ECX;
    undefined4 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 *in_R8;
    int32_t iVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar6 = 1;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 0x10) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3) = 0x1802568b3;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_50h + iVar4 + iVar3) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar4 + iVar3;
    if (in_ECX == 0) goto code_r0x000180256976;
    *(int32_t *)((int64_t)&arg_40h + iVar4 + iVar3) = in_ECX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar3) = 0x18023bd90;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180256903;
    iVar5 = fcn.18022c840(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180256922;
        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3));
        iVar2 = 0;
        if (iVar1 != 0) {
            iVar2 = *(int32_t *)0x18077e744;
        }
        if (iVar2 == 0) goto code_r0x000180256976;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180256941;
            iVar2 = fcn.180222850(*(undefined8 *)0x18077e738);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x18025694a;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000038 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180256962;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180256974;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
                goto code_r0x000180256976;
            }
        }
        if (*(int64_t *)0x18077e728 != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x1802569aa;
            iVar2 = fcn.180221a50(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
            if (-1 < iVar2) {
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x1802569bc;
                iVar5 = fcn.180222340(*(int64_t *)0x18077e728, iVar2);
            }
        }
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x1802569cf;
            fcn.180222910(*(undefined8 *)0x18077e738);
        }
        if (iVar5 == 0) goto code_r0x000180256976;
    }
    if (in_RDX != (undefined4 *)0x0) {
        *in_RDX = *(undefined4 *)(iVar5 + 4);
    }
    if (in_R8 != (undefined4 *)0x0) {
        *in_R8 = *(undefined4 *)(iVar5 + 8);
    }
code_r0x000180256976:
    *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180256983;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_50h + iVar4 + iVar3) ^ (int64_t)auStackX_10 + iVar4 + iVar3);
    return;
}

// ============================================================
// Function: FUN_180256800
// Address: 0x180256800
// Size: 99 bytes
// ============================================================
void fcn.180256800(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025680a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180256820;
    fcn.180222290(*(undefined8 *)0x18077e728, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025682f;
    fcn.180222050(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025683b;
    fcn.180221d50(*(undefined8 *)0x18077e730);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180256847;
    fcn.1802227d0(*(undefined8 *)0x18077e738);
    *(undefined8 *)0x18077e728 = 0;
    *(undefined8 *)0x18077e730 = 0;
    *(undefined8 *)0x18077e738 = 0;
    return;
}

// ============================================================
// Function: FUN_180256870
// Address: 0x180256870
// Size: 44 bytes
// ============================================================
void fcn.180256870(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025687a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180256882;
    *(int64_t *)0x18077e738 = fcn.180222800();
    *(uint32_t *)0x18077e744 = (uint32_t)(*(int64_t *)0x18077e738 != 0);
    return;
}

// ============================================================
// Function: FUN_1802568a0
// Address: 0x1802568a0
// Size: 336 bytes
// ============================================================
void fcn.1802567e0(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_98h, int64_t arg_b0h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t in_ECX;
    undefined4 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 *in_R8;
    int32_t iVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar6 = 1;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 0x10) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3) = 0x1802568b3;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_50h + iVar4 + iVar3) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar4 + iVar3;
    if (in_ECX == 0) goto code_r0x000180256976;
    *(int32_t *)((int64_t)&arg_40h + iVar4 + iVar3) = in_ECX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar3) = 0x18023bd90;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180256903;
    iVar5 = fcn.18022c840(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180256922;
        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3));
        iVar2 = 0;
        if (iVar1 != 0) {
            iVar2 = *(int32_t *)0x18077e744;
        }
        if (iVar2 == 0) goto code_r0x000180256976;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180256941;
            iVar2 = fcn.180222850(*(undefined8 *)0x18077e738);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x18025694a;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000038 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180256962;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180256974;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3));
                goto code_r0x000180256976;
            }
        }
        if (*(int64_t *)0x18077e728 != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x1802569aa;
            iVar2 = fcn.180221a50(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
            if (-1 < iVar2) {
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x1802569bc;
                iVar5 = fcn.180222340(*(int64_t *)0x18077e728, iVar2);
            }
        }
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x1802569cf;
            fcn.180222910(*(undefined8 *)0x18077e738);
        }
        if (iVar5 == 0) goto code_r0x000180256976;
    }
    if (in_RDX != (undefined4 *)0x0) {
        *in_RDX = *(undefined4 *)(iVar5 + 4);
    }
    if (in_R8 != (undefined4 *)0x0) {
        *in_R8 = *(undefined4 *)(iVar5 + 8);
    }
code_r0x000180256976:
    *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180256983;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_50h + iVar4 + iVar3) ^ (int64_t)auStackX_10 + iVar4 + iVar3);
    return;
}

// ============================================================
// Function: FUN_1802569f0
// Address: 0x1802569f0
// Size: 35 bytes
// ============================================================
void fcn.1802569f0(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4) = 0x18022499a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar3 + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_180256a40
// Address: 0x180256a40
// Size: 101 bytes
// ============================================================
void fcn.180256a40(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180256a50;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        iVar1 = *(int64_t *)arg1;
        piVar3 = (int64_t *)arg1;
        while (iVar1 != 0) {
            piVar3 = piVar3 + 5;
            iVar1 = *piVar3;
        }
        if (*(int32_t *)(piVar3 + 1) == 0x7f) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180256a8a;
            fcn.180225130(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180256a9f;
        fcn.180224990(arg1, 0x1804e6400, 0xf1);
    }
    return;
}

// ============================================================
// Function: FUN_180256ae0
// Address: 0x180256ae0
// Size: 70 bytes
// ============================================================
void fcn.180256ae0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180256aea;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x180256c20;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180248230;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180256c80;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180256b21;
    fcn.180280c20(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x000000b0 + iVar1), *(int64_t *)(&stack0x000000b8 + iVar1), 
                  *(int64_t *)(&stack0x000000c0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180256b30
// Address: 0x180256b30
// Size: 94 bytes
// ============================================================
void fcn.180256b30(int64_t arg1)
{
    undefined8 *puVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180256b40;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        puVar1 = (undefined8 *)(arg1 + 0x20);
        iVar2 = *(int32_t *)puVar1;
        *(int32_t *)puVar1 = *(int32_t *)puVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180256b6b;
            fcn.180224990(uVar3, 0x1804e6418, 0x27);
            uVar3 = *(undefined8 *)arg1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180256b73;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180256b88;
            fcn.180224990(arg1, 0x1804e6418, 0x2a);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180256b90
// Address: 0x180256b90
// Size: 58 bytes
// ============================================================
undefined8 fcn.180256b90(undefined8 *param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x180256b9c;
    iVar1 = fcn.18045a350();
    if (param_1[0xd] == 0) {
        return 0;
    }
    uVar2 = *param_1;
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180256bb9;
    uVar2 = fcn.18027e810(uVar2);
    // WARNING: Could not recover jumptable at 0x000180256bc7. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (*(code *)param_1[0xd])(0, uVar2, (code *)param_1[0xd]);
    return uVar2;
}

// ============================================================
// Function: FUN_180256bd0
// Address: 0x180256bd0
// Size: 70 bytes
// ============================================================
void fcn.180256bd0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180256bda;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x180256c20;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180248230;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180256c80;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180256c11;
    fcn.180280ca0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000080 + iVar1), *(int64_t *)(&stack0x000000b0 + iVar1), 
                  *(int64_t *)(&stack0x000000b8 + iVar1), *(int64_t *)(&stack0x000000c0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180256c20
// Address: 0x180256c20
// Size: 94 bytes
// ============================================================
void fcn.180256c20(int64_t arg1)
{
    undefined8 *puVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180256c30;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        puVar1 = (undefined8 *)(arg1 + 0x20);
        iVar2 = *(int32_t *)puVar1;
        *(int32_t *)puVar1 = *(int32_t *)puVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180256c5b;
            fcn.180224990(uVar3, 0x1804e6418, 0x27);
            uVar3 = *(undefined8 *)arg1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180256c63;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180256c78;
            fcn.180224990(arg1, 0x1804e6418, 0x2a);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180256c80
// Address: 0x180256c80
// Size: 768 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t * fcn.180256c80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                       int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined4 in_ECX;
    int64_t in_RDX;
    int64_t *piVar7;
    int64_t in_R8;
    int32_t iVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180256ca2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar1 = *(int32_t **)(in_RDX + 0x10);
    iVar8 = 0;
    iVar9 = 0;
    iVar3 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180256cd1;
    piVar5 = (int64_t *)fcn.180224d60(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    if (piVar5 == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180256f03;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180256f1b;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180256f2d;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
        return (int64_t *)0x0;
    }
    *(undefined4 *)(piVar5 + 4) = 1;
    *(undefined4 *)(piVar5 + 1) = in_ECX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180256cef;
    iVar6 = func_0x000180282210(in_RDX);
    piVar5[2] = iVar6;
    if (iVar6 != 0) {
        piVar5[3] = *(int64_t *)(in_RDX + 0x18);
        iVar2 = *piVar1;
        if (iVar2 != 0) {
            piVar7 = (int64_t *)(piVar1 + 2);
            do {
    // switch table (13 cases) at 0x180256f4c
                switch(iVar2) {
                case 1:
                    if (piVar5[5] == 0) {
                        iVar9 = iVar9 + 1;
                        piVar5[5] = *piVar7;
                    }
                    break;
                case 2:
                    if (piVar5[6] == 0) {
                        piVar5[6] = *piVar7;
                    }
                    break;
                case 3:
                    if (piVar5[7] == 0) {
                        iVar9 = iVar9 + 1;
                        piVar5[7] = *piVar7;
                    }
                    break;
                case 4:
                    if (piVar5[8] == 0) {
                        piVar5[8] = *piVar7;
code_r0x000180256e4a:
                        iVar3 = 1;
                    }
                    break;
                case 5:
                    if (piVar5[9] == 0) {
                        iVar8 = iVar8 + 1;
                        piVar5[9] = *piVar7;
                    }
                    break;
                case 6:
                    if (piVar5[10] == 0) {
                        iVar8 = iVar8 + 1;
                        piVar5[10] = *piVar7;
                    }
                    break;
                case 7:
                    if (piVar5[0xe] == 0) {
                        piVar5[0xe] = *piVar7;
                    }
                    break;
                case 8:
                    if (piVar5[0xf] == 0) {
                        piVar5[0xf] = *piVar7;
                    }
                    break;
                case 9:
                    if (piVar5[0x10] == 0) {
                        piVar5[0x10] = *piVar7;
                    }
                    break;
                case 10:
                    if (piVar5[0xb] == 0) {
                        piVar5[0xb] = *piVar7;
                    }
                    break;
                case 0xb:
                    if (piVar5[0xc] == 0) {
                        piVar5[0xc] = *piVar7;
                    }
                    break;
                case 0xc:
                    if (piVar5[0xd] == 0) {
                        piVar5[0xd] = *piVar7;
                    }
                    break;
                case 0xd:
                    if (piVar5[0x11] == 0) {
                        piVar5[0x11] = *piVar7;
                        goto code_r0x000180256e4a;
                    }
                }
                iVar2 = *(int32_t *)(piVar7 + 1);
                piVar7 = piVar7 + 2;
            } while (iVar2 != 0);
            if ((iVar8 + iVar3 == 3) && (iVar9 == 2)) {
                if (in_R8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180256e7b;
                    iVar3 = func_0x00018027fb30(in_R8);
                    if (iVar3 == 0) goto code_r0x000180256eba;
                }
                *piVar5 = in_R8;
                return piVar5;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180256e90;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180256ea8;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180256eba;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
    }
code_r0x000180256eba:
    LOCK();
    piVar7 = piVar5 + 4;
    iVar3 = *(int32_t *)piVar7;
    *(int32_t *)piVar7 = *(int32_t *)piVar7 + -1;
    UNLOCK();
    if (iVar3 < 2) {
        iVar6 = piVar5[2];
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180256edf;
        fcn.180224990(iVar6, 0x1804e6418, 0x27);
        iVar6 = *piVar5;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180256ee7;
        fcn.18027edb0(iVar6);
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180256efc;
        fcn.180224990(piVar5, 0x1804e6418, 0x2a);
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_180256f80
// Address: 0x180256f80
// Size: 230 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.180256f80(int64_t arg_28h)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180256f90;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX[1] != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180256fb4;
        piVar7 = (int64_t *)
                 fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                               *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
        if (piVar7 != (int64_t *)0x0) {
            uVar2 = *(undefined4 *)((int64_t)in_RCX + 4);
            uVar3 = *(undefined4 *)(in_RCX + 1);
            uVar4 = *(undefined4 *)((int64_t)in_RCX + 0xc);
            *(undefined4 *)piVar7 = *(undefined4 *)in_RCX;
            *(undefined4 *)((int64_t)piVar7 + 4) = uVar2;
            *(undefined4 *)(piVar7 + 1) = uVar3;
            *(undefined4 *)((int64_t)piVar7 + 0xc) = uVar4;
            iVar8 = *piVar7;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180256fca;
            iVar5 = fcn.180248230(iVar8);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180256fd3;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180256feb;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180256ffd;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar6));
                uVar9 = 0x40;
            } else {
                iVar8 = in_RCX[1];
                pcVar1 = *(code **)(*in_RCX + 0x30);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025702c;
                iVar8 = (*pcVar1)(iVar8);
                piVar7[1] = iVar8;
                if (iVar8 != 0) {
                    return piVar7;
                }
                pcVar1 = *(code **)(*piVar7 + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180257040;
                (*pcVar1)(0);
                iVar8 = *piVar7;
                piVar7[1] = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180257050;
                fcn.180256b30(iVar8);
                uVar9 = 0x2f;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180257012;
            fcn.180224990(piVar7, 0x1804e6448, uVar9);
        }
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_180257070
// Address: 0x180257070
// Size: 78 bytes
// ============================================================
void fcn.180257070(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180257080;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        iVar1 = *(int64_t *)(arg1 + 8);
        pcVar2 = *(code **)(*(int64_t *)arg1 + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257093;
        (*pcVar2)(iVar1);
        iVar1 = *(int64_t *)arg1;
        *(int64_t *)(arg1 + 8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802570a3;
        fcn.180256b30(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802570b8;
        fcn.180224990(arg1, 0x1804e6448, 0x2f);
    }
    return;
}

// ============================================================
// Function: FUN_1802570c0
// Address: 0x1802570c0
// Size: 29 bytes
// ============================================================
undefined8
fcn.1802570c0(int64_t arg_40h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_d0h,
             int64_t arg_180h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    undefined4 extraout_XMM0_Da;
    undefined8 auStackX_18 [2];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)auStackX_18 + iVar7 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar7) = 0x18025788c;
    iVar8 = fcn.18045a350(extraout_XMM0_Da, 0x18063dcac);
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)&arg_d0h + iVar8 + iVar7) = 0;
    if (in_RCX[1] != 0) {
        *(undefined8 *)((int64_t)&arg_70h + iVar8 + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_78h + iVar8 + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_80h + iVar8 + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_98h + iVar8 + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_a0h + iVar8 + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_b0h + iVar8 + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7) = 0;
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x1802578f4;
        puVar9 = (undefined4 *)func_0x000180229cc0((int64_t)&arg_40h + iVar8 + iVar7);
        uVar3 = puVar9[1];
        uVar4 = puVar9[2];
        uVar5 = puVar9[3];
        *(undefined4 *)((int64_t)&arg_70h + iVar8 + iVar7) = *puVar9;
        *(undefined4 *)((int64_t)&arg_70h + iVar8 + iVar7 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_78h + iVar8 + iVar7) = uVar4;
        *(undefined4 *)((int64_t)&arg_78h + iVar8 + iVar7 + 4) = uVar5;
        uVar3 = puVar9[5];
        uVar4 = puVar9[6];
        uVar5 = puVar9[7];
        *(undefined4 *)((int64_t)&arg_80h + iVar8 + iVar7) = puVar9[4];
        *(undefined4 *)((int64_t)&arg_80h + iVar8 + iVar7 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_88h + iVar8 + iVar7) = uVar4;
        *(undefined4 *)((int64_t)&arg_88h + iVar8 + iVar7 + 4) = uVar5;
        iVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar7) = *(undefined8 *)(puVar9 + 8);
        pcVar2 = *(code **)(iVar1 + 0x78);
        if (pcVar2 == (code *)0x0) {
            pcVar2 = *(code **)(iVar1 + 0x70);
            if (pcVar2 == (code *)0x0) {
                return 0;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180257947;
            iVar6 = (*pcVar2)((int64_t)&arg_70h + iVar8 + iVar7);
        } else {
            iVar1 = in_RCX[1];
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180257928;
            iVar6 = (*pcVar2)(iVar1, (int64_t)&arg_70h + iVar8 + iVar7);
        }
        if (iVar6 != 0) {
            return *(undefined8 *)((int64_t)&arg_d0h + iVar8 + iVar7);
        }
    }
    return 0;
}

