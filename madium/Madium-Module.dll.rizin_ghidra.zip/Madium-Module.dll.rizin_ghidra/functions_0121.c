// Chunk 121 - 50 functions

// ============================================================
// Function: FUN_18019f5a3
// Address: 0x18019f5a3
// Size: 143 bytes
// ============================================================
undefined8 fcn.18019f5a3(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    int32_t unaff_EBX;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t *piVar5;
    int64_t unaff_R12;
    int64_t **unaff_R14;
    int64_t **unaff_R15;
    bool bVar6;
    
    do {
        if ((int32_t)unaff_R12 < *(int32_t *)(unaff_RBP + unaff_RSI * 4)) {
            piVar1 = *unaff_R15;
            piVar3 = *unaff_R14;
            piVar4 = piVar1;
            piVar5 = piVar3;
            if (piVar1 != (int64_t *)0x0) {
                do {
                    if (piVar3 == (int64_t *)0x0) break;
                    piVar2 = (int64_t *)piVar3[2];
                    if (((unaff_EBX == *(int32_t *)(*piVar3 + 0x44)) && (*(int32_t *)(piVar3 + 1) != (int32_t)unaff_R12)
                        ) && (piVar3 != piVar4)) {
                        if (piVar3 == piVar5) {
                            piVar5 = piVar2;
                        }
                        if (piVar3[3] != 0) {
                            *(int64_t **)(piVar3[3] + 0x10) = piVar2;
                        }
                        if (piVar3[2] != 0) {
                            *(int64_t *)(piVar3[2] + 0x18) = piVar3[3];
                        }
                        piVar4[2] = (int64_t)piVar3;
                        piVar3[3] = (int64_t)piVar4;
                        piVar3[2] = unaff_R12;
                        piVar4 = piVar3;
                    }
                    bVar6 = piVar3 != piVar1;
                    piVar3 = piVar2;
                } while (bVar6);
            }
            *unaff_R14 = piVar5;
            *unaff_R15 = piVar4;
        }
        unaff_EBX = unaff_EBX + -1;
        unaff_RSI = unaff_RSI + -1;
        if (unaff_RSI < 0) {
            func_0x000180224990();
            return 1;
        }
    } while( true );
}

// ============================================================
// Function: FUN_18019f632
// Address: 0x18019f632
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_40h

undefined8 fcn.18019f5a3(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    int32_t unaff_EBX;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t *piVar5;
    int64_t unaff_R12;
    int64_t **unaff_R14;
    int64_t **unaff_R15;
    bool bVar6;
    
    do {
        if ((int32_t)unaff_R12 < *(int32_t *)(unaff_RBP + unaff_RSI * 4)) {
            piVar1 = *unaff_R15;
            piVar3 = *unaff_R14;
            piVar4 = piVar1;
            piVar5 = piVar3;
            if (piVar1 != (int64_t *)0x0) {
                do {
                    if (piVar3 == (int64_t *)0x0) break;
                    piVar2 = (int64_t *)piVar3[2];
                    if (((unaff_EBX == *(int32_t *)(*piVar3 + 0x44)) && (*(int32_t *)(piVar3 + 1) != (int32_t)unaff_R12)
                        ) && (piVar3 != piVar4)) {
                        if (piVar3 == piVar5) {
                            piVar5 = piVar2;
                        }
                        if (piVar3[3] != 0) {
                            *(int64_t **)(piVar3[3] + 0x10) = piVar2;
                        }
                        if (piVar3[2] != 0) {
                            *(int64_t *)(piVar3[2] + 0x18) = piVar3[3];
                        }
                        piVar4[2] = (int64_t)piVar3;
                        piVar3[3] = (int64_t)piVar4;
                        piVar3[2] = unaff_R12;
                        piVar4 = piVar3;
                    }
                    bVar6 = piVar3 != piVar1;
                    piVar3 = piVar2;
                } while (bVar6);
            }
            *unaff_R14 = piVar5;
            *unaff_R15 = piVar4;
        }
        unaff_EBX = unaff_EBX + -1;
        unaff_RSI = unaff_RSI + -1;
        if (unaff_RSI < 0) {
            func_0x000180224990();
            return 1;
        }
    } while( true );
}

// ============================================================
// Function: FUN_18019f670
// Address: 0x18019f670
// Size: 3208 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

int64_t fcn.18019f670(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                     int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h,
                     int64_t arg_b8h)
{
    char *pcVar1;
    char *pcVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    code *pcVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined8 *puVar11;
    int32_t iVar12;
    int32_t iVar13;
    int64_t iVar14;
    uint64_t uVar15;
    int64_t *piVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t iVar19;
    uint32_t uVar20;
    int64_t *piVar21;
    int64_t *piVar22;
    int64_t *piVar23;
    uint32_t *puVar24;
    int32_t iVar25;
    uint64_t uVar26;
    undefined8 uVar27;
    char *pcVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_48;
    
    uStack_48 = 0x18019f69a;
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    iVar14 = func_0x00018045a350();
    iVar14 = -iVar14;
    pcVar28 = *(char **)((int64_t)&arg_b0h + iVar14);
    uVar26 = 0;
    iVar17 = *(int64_t *)(arg1 + 8);
    *(undefined8 *)((int64_t)&var_20h + iVar14) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar14) = 0;
    bVar29 = false;
    if (pcVar28 == (char *)0x0) {
        return 0;
    }
    if (arg3 == 0) {
        return 0;
    }
    if (arg4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x18019f6f0;
    iVar12 = func_0x000180498f90(pcVar28, 0x1804ad4e8, 0xd);
    if (iVar12 == 0) {
        uVar20 = 0x10000;
        bVar29 = false;
code_r0x00018019f762:
        *(uint32_t *)(*(int64_t *)((int64_t)&arg_b8h + iVar14) + 0x1c) =
             uVar20 | *(uint32_t *)(*(int64_t *)((int64_t)&arg_b8h + iVar14) + 0x1c) & 0xfffcffff;
code_r0x00018019f792:
        if ((*(uint8_t *)(*(int64_t *)(iVar17 + 0xd8) + 0x50) & 0x10) == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x18019f7a4;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x18019f7bc;
            func_0x0001802295a0(0x1804ad498, 0x4f6, 0x1804ad528);
            *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x18019f7ce;
            func_0x0001802296d0(0x14, 0x9e, 0);
            return 0;
        }
        if (uVar20 == 0x10000) {
            pcVar28 = "ECDHE-ECDSA-AES128-GCM-SHA256";
        } else if (uVar20 == 0x20000) {
            pcVar28 = "ECDHE-ECDSA-AES256-GCM-SHA384";
        } else if ((uVar20 == 0x30000) && (pcVar28 = "ECDHE-ECDSA-AES256-GCM-SHA384", !bVar29)) {
            pcVar28 = "ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384";
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x18019f716;
        iVar12 = func_0x000180498f90(pcVar28, 0x1804ad4f8, 0xb);
        if (iVar12 == 0) {
            uVar20 = 0x30000;
            bVar29 = true;
            goto code_r0x00018019f762;
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x18019f739;
        iVar12 = func_0x000180498f90(pcVar28, 0x1804ad508, 9);
        if (iVar12 == 0) {
            uVar20 = 0x30000;
            bVar29 = false;
            goto code_r0x00018019f762;
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x18019f759;
        iVar12 = func_0x000180498f90(pcVar28, 0x1804ad518, 9);
        if (iVar12 == 0) {
            uVar20 = 0x20000;
            bVar29 = false;
            goto code_r0x00018019f762;
        }
        uVar20 = *(uint32_t *)(*(int64_t *)((int64_t)&arg_b8h + iVar14) + 0x1c) & 0x30000;
        if (uVar20 != 0) goto code_r0x00018019f792;
    }
    uVar3 = *(undefined4 *)(arg1 + 0x694);
    *(undefined4 *)((int64_t)&var_10h + iVar14) = *(undefined4 *)(arg1 + 0x698);
    *(undefined4 *)((int64_t)&arg_b0h + iVar14) = *(undefined4 *)(arg1 + 0x69c);
    *(undefined4 *)((int64_t)&var_18h + iVar14) = *(undefined4 *)(arg1 + 0x690);
    *(undefined4 *)((int64_t)&var_10h + iVar14 + 4) = uVar3;
    pcVar7 = *(code **)(iVar17 + 0xc0);
    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x18019f842;
    iVar12 = (*pcVar7)();
    uVar15 = uVar26;
    if (0 < iVar12) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x18019f863;
        uVar15 = func_0x000180224ed0((int64_t)iVar12, 0x20, 0x1804ad498, 0x5c6);
        if (uVar15 == 0) {
            return 0;
        }
    }
    *(int64_t *)(&stack0x00000000 + iVar14) = (int64_t)&arg_28h + iVar14;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar14) = (int64_t)&var_20h + iVar14;
    *(uint64_t *)(&stack0xfffffffffffffff0 + iVar14) = uVar15;
    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar14) = uVar3;
    *(undefined4 *)(&stack0xffffffffffffffe0 + iVar14) = *(undefined4 *)((int64_t)&var_18h + iVar14);
    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x18019f8ab;
    func_0x00018019e850(iVar17, iVar12, *(undefined4 *)((int64_t)&var_10h + iVar14), 
                        *(undefined4 *)((int64_t)&arg_b0h + iVar14));
    piVar21 = *(int64_t **)((int64_t)&arg_28h + iVar14);
    piVar16 = *(int64_t **)((int64_t)&var_20h + iVar14);
    piVar22 = piVar16;
    piVar23 = piVar21;
    if (piVar21 != (int64_t *)0x0) {
        do {
            if (piVar22 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar22[2];
            if ((((*(uint8_t *)(*piVar22 + 0x1c) & 4) != 0) && ((*(uint8_t *)(*piVar22 + 0x20) & 8) != 0)) &&
               (*(int32_t *)(piVar22 + 1) == 0)) {
                if (piVar22 != piVar23) {
                    if (piVar22 == piVar16) {
                        piVar16 = piVar8;
                    }
                    if (piVar22[3] != 0) {
                        *(int64_t **)(piVar22[3] + 0x10) = piVar8;
                    }
                    if (piVar22[2] != 0) {
                        *(int64_t *)(piVar22[2] + 0x18) = piVar22[3];
                    }
                    piVar23[2] = (int64_t)piVar22;
                    piVar22[3] = (int64_t)piVar23;
                    piVar22[2] = 0;
                    piVar23 = piVar22;
                }
                *(undefined4 *)(piVar22 + 1) = 1;
            }
            bVar29 = piVar22 != piVar21;
            piVar22 = piVar8;
        } while (bVar29);
    }
    piVar21 = piVar16;
    piVar22 = piVar23;
    if (piVar23 != (int64_t *)0x0) {
        do {
            if (piVar21 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar21[2];
            if (((*(uint8_t *)(*piVar21 + 0x1c) & 4) != 0) && (*(int32_t *)(piVar21 + 1) == 0)) {
                if (piVar21 != piVar22) {
                    if (piVar21 == piVar16) {
                        piVar16 = piVar8;
                    }
                    if (piVar21[3] != 0) {
                        *(int64_t **)(piVar21[3] + 0x10) = piVar8;
                    }
                    if (piVar21[2] != 0) {
                        *(int64_t *)(piVar21[2] + 0x18) = piVar21[3];
                    }
                    piVar22[2] = (int64_t)piVar21;
                    piVar21[3] = (int64_t)piVar22;
                    piVar21[2] = 0;
                    piVar22 = piVar21;
                }
                *(undefined4 *)(piVar21 + 1) = 1;
            }
            bVar29 = piVar21 != piVar23;
            piVar21 = piVar8;
        } while (bVar29);
    }
    piVar21 = piVar16;
    piVar23 = piVar22;
    if (piVar16 != (int64_t *)0x0) {
        do {
            if (piVar22 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar22[3];
            if (((*(uint8_t *)(*piVar22 + 0x1c) & 4) != 0) && (*(int32_t *)(piVar22 + 1) != 0)) {
                if (piVar22 != piVar21) {
                    if (piVar22 == piVar23) {
                        piVar23 = piVar8;
                    }
                    if (piVar22[2] != 0) {
                        *(int64_t **)(piVar22[2] + 0x18) = piVar8;
                    }
                    if (piVar22[3] != 0) {
                        *(int64_t *)(piVar22[3] + 0x10) = piVar22[2];
                    }
                    piVar21[3] = (int64_t)piVar22;
                    piVar22[2] = (int64_t)piVar21;
                    piVar22[3] = 0;
                    piVar21 = piVar22;
                }
                *(undefined4 *)(piVar22 + 1) = 0;
            }
            bVar29 = piVar22 != piVar16;
            piVar22 = piVar8;
        } while (bVar29);
    }
    piVar16 = piVar21;
    piVar22 = piVar23;
    if (piVar23 != (int64_t *)0x0) {
        do {
            if (piVar16 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar16[2];
            if (((*(uint32_t *)(*piVar16 + 0x24) & 0x3000) != 0) && (*(int32_t *)(piVar16 + 1) == 0)) {
                if (piVar16 != piVar22) {
                    if (piVar16 == piVar21) {
                        piVar21 = piVar8;
                    }
                    if (piVar16[3] != 0) {
                        *(int64_t **)(piVar16[3] + 0x10) = piVar8;
                    }
                    if (piVar16[2] != 0) {
                        *(int64_t *)(piVar16[2] + 0x18) = piVar16[3];
                    }
                    piVar22[2] = (int64_t)piVar16;
                    piVar16[3] = (int64_t)piVar22;
                    piVar16[2] = 0;
                    piVar22 = piVar16;
                }
                *(undefined4 *)(piVar16 + 1) = 1;
            }
            bVar29 = piVar16 != piVar23;
            piVar16 = piVar8;
        } while (bVar29);
    }
    piVar16 = piVar21;
    piVar23 = piVar22;
    if (piVar22 != (int64_t *)0x0) {
        do {
            if (piVar16 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar16[2];
            if (((*(uint32_t *)(*piVar16 + 0x24) & 0x80000) != 0) && (*(int32_t *)(piVar16 + 1) == 0)) {
                if (piVar16 != piVar23) {
                    if (piVar16 == piVar21) {
                        piVar21 = piVar8;
                    }
                    if (piVar16[3] != 0) {
                        *(int64_t **)(piVar16[3] + 0x10) = piVar8;
                    }
                    if (piVar16[2] != 0) {
                        *(int64_t *)(piVar16[2] + 0x18) = piVar16[3];
                    }
                    piVar23[2] = (int64_t)piVar16;
                    piVar16[3] = (int64_t)piVar23;
                    piVar16[2] = 0;
                    piVar23 = piVar16;
                }
                *(undefined4 *)(piVar16 + 1) = 1;
            }
            bVar29 = piVar16 != piVar22;
            piVar16 = piVar8;
        } while (bVar29);
    }
    piVar16 = piVar21;
    piVar22 = piVar23;
    if (piVar23 != (int64_t *)0x0) {
        do {
            if (piVar16 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar16[2];
            if (((*(uint32_t *)(*piVar16 + 0x24) & 0x3c0c0) != 0) && (*(int32_t *)(piVar16 + 1) == 0)) {
                if (piVar16 != piVar22) {
                    if (piVar16 == piVar21) {
                        piVar21 = piVar8;
                    }
                    if (piVar16[3] != 0) {
                        *(int64_t **)(piVar16[3] + 0x10) = piVar8;
                    }
                    if (piVar16[2] != 0) {
                        *(int64_t *)(piVar16[2] + 0x18) = piVar16[3];
                    }
                    piVar22[2] = (int64_t)piVar16;
                    piVar16[3] = (int64_t)piVar22;
                    piVar16[2] = 0;
                    piVar22 = piVar16;
                }
                *(undefined4 *)(piVar16 + 1) = 1;
            }
            bVar29 = piVar16 != piVar23;
            piVar16 = piVar8;
        } while (bVar29);
    }
    piVar16 = piVar21;
    piVar23 = piVar22;
    if (piVar22 != (int64_t *)0x0) {
        do {
            if (piVar16 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar16[2];
            if (*(int32_t *)(piVar16 + 1) == 0) {
                if (piVar16 != piVar23) {
                    if (piVar16 == piVar21) {
                        piVar21 = piVar8;
                    }
                    if (piVar16[3] != 0) {
                        *(int64_t **)(piVar16[3] + 0x10) = piVar8;
                    }
                    if (piVar16[2] != 0) {
                        *(int64_t *)(piVar16[2] + 0x18) = piVar16[3];
                    }
                    piVar23[2] = (int64_t)piVar16;
                    piVar16[3] = (int64_t)piVar23;
                    piVar16[2] = 0;
                    piVar23 = piVar16;
                }
                *(undefined4 *)(piVar16 + 1) = 1;
            }
            bVar29 = piVar16 != piVar22;
            piVar16 = piVar8;
        } while (bVar29);
    }
    piVar16 = piVar21;
    piVar22 = piVar23;
    if (piVar23 != (int64_t *)0x0) {
        do {
            if (piVar16 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar16[2];
            if ((((*(uint8_t *)(*piVar16 + 0x28) & 1) != 0) && (*(int32_t *)(piVar16 + 1) != 0)) && (piVar16 != piVar22)
               ) {
                if (piVar16 == piVar21) {
                    piVar21 = piVar8;
                }
                if (piVar16[3] != 0) {
                    *(int64_t **)(piVar16[3] + 0x10) = piVar8;
                }
                if (piVar16[2] != 0) {
                    *(int64_t *)(piVar16[2] + 0x18) = piVar16[3];
                }
                piVar22[2] = (int64_t)piVar16;
                piVar16[3] = (int64_t)piVar22;
                piVar16[2] = 0;
                piVar22 = piVar16;
            }
            bVar29 = piVar16 != piVar23;
            piVar16 = piVar8;
        } while (bVar29);
    }
    piVar16 = piVar21;
    piVar23 = piVar22;
    if (piVar22 != (int64_t *)0x0) {
        do {
            if (piVar16 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar16[2];
            if ((((*(uint8_t *)(*piVar16 + 0x20) & 4) != 0) && (*(int32_t *)(piVar16 + 1) != 0)) && (piVar16 != piVar23)
               ) {
                if (piVar16 == piVar21) {
                    piVar21 = piVar8;
                }
                if (piVar16[3] != 0) {
                    *(int64_t **)(piVar16[3] + 0x10) = piVar8;
                }
                if (piVar16[2] != 0) {
                    *(int64_t *)(piVar16[2] + 0x18) = piVar16[3];
                }
                piVar23[2] = (int64_t)piVar16;
                piVar16[3] = (int64_t)piVar23;
                piVar16[2] = 0;
                piVar23 = piVar16;
            }
            bVar29 = piVar16 != piVar22;
            piVar16 = piVar8;
        } while (bVar29);
    }
    piVar16 = piVar21;
    piVar22 = piVar23;
    if (piVar23 != (int64_t *)0x0) {
        do {
            if (piVar16 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar16[2];
            if ((((*(uint8_t *)(*piVar16 + 0x1c) & 1) != 0) && (*(int32_t *)(piVar16 + 1) != 0)) && (piVar16 != piVar22)
               ) {
                if (piVar16 == piVar21) {
                    piVar21 = piVar8;
                }
                if (piVar16[3] != 0) {
                    *(int64_t **)(piVar16[3] + 0x10) = piVar8;
                }
                if (piVar16[2] != 0) {
                    *(int64_t *)(piVar16[2] + 0x18) = piVar16[3];
                }
                piVar22[2] = (int64_t)piVar16;
                piVar16[3] = (int64_t)piVar22;
                piVar16[2] = 0;
                piVar22 = piVar16;
            }
            bVar29 = piVar16 != piVar23;
            piVar16 = piVar8;
        } while (bVar29);
    }
    piVar16 = piVar21;
    piVar23 = piVar22;
    if (piVar22 != (int64_t *)0x0) {
        do {
            if (piVar16 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar16[2];
            if ((((*(uint8_t *)(*piVar16 + 0x1c) & 8) != 0) && (*(int32_t *)(piVar16 + 1) != 0)) && (piVar16 != piVar23)
               ) {
                if (piVar16 == piVar21) {
                    piVar21 = piVar8;
                }
                if (piVar16[3] != 0) {
                    *(int64_t **)(piVar16[3] + 0x10) = piVar8;
                }
                if (piVar16[2] != 0) {
                    *(int64_t *)(piVar16[2] + 0x18) = piVar16[3];
                }
                piVar23[2] = (int64_t)piVar16;
                piVar16[3] = (int64_t)piVar23;
                piVar16[2] = 0;
                piVar23 = piVar16;
            }
            bVar29 = piVar16 != piVar22;
            piVar16 = piVar8;
        } while (bVar29);
    }
    piVar16 = piVar21;
    piVar22 = piVar23;
    if (piVar23 != (int64_t *)0x0) {
        do {
            if (piVar16 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar16[2];
            if ((((*(uint8_t *)(*piVar16 + 0x24) & 4) != 0) && (*(int32_t *)(piVar16 + 1) != 0)) && (piVar16 != piVar22)
               ) {
                if (piVar16 == piVar21) {
                    piVar21 = piVar8;
                }
                if (piVar16[3] != 0) {
                    *(int64_t **)(piVar16[3] + 0x10) = piVar8;
                }
                if (piVar16[2] != 0) {
                    *(int64_t *)(piVar16[2] + 0x18) = piVar16[3];
                }
                piVar22[2] = (int64_t)piVar16;
                piVar16[3] = (int64_t)piVar22;
                piVar16[2] = 0;
                piVar22 = piVar16;
            }
            bVar29 = piVar16 != piVar23;
            piVar16 = piVar8;
        } while (bVar29);
    }
    *(int64_t **)((int64_t)&var_20h + iVar14) = piVar21;
    *(int64_t **)((int64_t)&arg_28h + iVar14) = piVar22;
    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x18019fdd4;
    iVar13 = func_0x00018019f500((int64_t)&var_20h + iVar14, (int64_t)&arg_28h + iVar14);
    if (iVar13 == 0) {
        uVar27 = 0x60a;
        goto code_r0x00018019fdde;
    }
    piVar21 = *(int64_t **)((int64_t)&var_20h + iVar14);
    piVar16 = *(int64_t **)((int64_t)&arg_28h + iVar14);
    piVar22 = piVar16;
    piVar23 = piVar21;
    if (piVar21 != (int64_t *)0x0) {
        do {
            if (piVar16 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar16[3];
            if (((*(int32_t *)(*piVar16 + 0x2c) == 0x303) && (*(int32_t *)(piVar16 + 1) != 0)) && (piVar16 != piVar23))
            {
                if (piVar16 == piVar22) {
                    piVar22 = piVar8;
                }
                if (piVar16[2] != 0) {
                    *(int64_t **)(piVar16[2] + 0x18) = piVar8;
                }
                if (piVar16[3] != 0) {
                    *(int64_t *)(piVar16[3] + 0x10) = piVar16[2];
                }
                piVar23[3] = (int64_t)piVar16;
                piVar16[2] = (int64_t)piVar23;
                piVar16[3] = 0;
                piVar23 = piVar16;
            }
            bVar29 = piVar16 != piVar21;
            piVar16 = piVar8;
        } while (bVar29);
    }
    piVar21 = piVar22;
    piVar16 = piVar23;
    if (piVar23 != (int64_t *)0x0) {
        do {
            if (piVar21 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar21[3];
            if ((((*(uint8_t *)(*piVar21 + 0x28) & 0x40) != 0) && (*(int32_t *)(piVar21 + 1) != 0)) &&
               (piVar21 != piVar16)) {
                if (piVar21 == piVar22) {
                    piVar22 = piVar8;
                }
                if (piVar21[2] != 0) {
                    *(int64_t **)(piVar21[2] + 0x18) = piVar8;
                }
                if (piVar21[3] != 0) {
                    *(int64_t *)(piVar21[3] + 0x10) = piVar21[2];
                }
                piVar16[3] = (int64_t)piVar21;
                piVar21[2] = (int64_t)piVar16;
                piVar21[3] = 0;
                piVar16 = piVar21;
            }
            bVar29 = piVar21 != piVar23;
            piVar21 = piVar8;
        } while (bVar29);
    }
    piVar21 = piVar22;
    piVar23 = piVar16;
    if (piVar16 != (int64_t *)0x0) {
        do {
            if (piVar21 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar21[3];
            if ((((*(uint8_t *)(*piVar21 + 0x1c) & 6) != 0) && (*(int32_t *)(piVar21 + 1) != 0)) && (piVar21 != piVar23)
               ) {
                if (piVar21 == piVar22) {
                    piVar22 = piVar8;
                }
                if (piVar21[2] != 0) {
                    *(int64_t **)(piVar21[2] + 0x18) = piVar8;
                }
                if (piVar21[3] != 0) {
                    *(int64_t *)(piVar21[3] + 0x10) = piVar21[2];
                }
                piVar23[3] = (int64_t)piVar21;
                piVar21[2] = (int64_t)piVar23;
                piVar21[3] = 0;
                piVar23 = piVar21;
            }
            bVar29 = piVar21 != piVar16;
            piVar21 = piVar8;
        } while (bVar29);
    }
    piVar21 = piVar22;
    piVar16 = piVar23;
    if (piVar23 != (int64_t *)0x0) {
        do {
            if (piVar21 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar21[3];
            if ((((*(uint8_t *)(*piVar21 + 0x1c) & 6) != 0) && ((*(uint8_t *)(*piVar21 + 0x28) & 0x40) != 0)) &&
               ((*(int32_t *)(piVar21 + 1) != 0 && (piVar21 != piVar16)))) {
                if (piVar21 == piVar22) {
                    piVar22 = piVar8;
                }
                if (piVar21[2] != 0) {
                    *(int64_t **)(piVar21[2] + 0x18) = piVar8;
                }
                if (piVar21[3] != 0) {
                    *(int64_t *)(piVar21[3] + 0x10) = piVar21[2];
                }
                piVar16[3] = (int64_t)piVar21;
                piVar21[2] = (int64_t)piVar16;
                piVar21[3] = 0;
                piVar16 = piVar21;
            }
            bVar29 = piVar21 != piVar23;
            piVar21 = piVar8;
        } while (bVar29);
    }
    piVar23 = piVar22;
    piVar21 = piVar16;
    if (piVar16 != (int64_t *)0x0) {
        do {
            if (piVar23 == (int64_t *)0x0) break;
            piVar8 = (int64_t *)piVar23[3];
            if (*(int32_t *)(piVar23 + 1) != 0) {
                if (piVar23 != piVar21) {
                    if (piVar23 == piVar22) {
                        piVar22 = piVar8;
                    }
                    if (piVar23[2] != 0) {
                        *(int64_t **)(piVar23[2] + 0x18) = piVar8;
                    }
                    if (piVar23[3] != 0) {
                        *(int64_t *)(piVar23[3] + 0x10) = piVar23[2];
                    }
                    piVar21[3] = (int64_t)piVar23;
                    piVar23[2] = (int64_t)piVar21;
                    piVar23[3] = 0;
                    piVar21 = piVar23;
                }
                *(undefined4 *)(piVar23 + 1) = 0;
            }
            bVar29 = piVar23 != piVar16;
            piVar23 = piVar8;
        } while (bVar29);
    }
    *(int64_t **)((int64_t)&var_20h + iVar14) = piVar21;
    *(int64_t **)((int64_t)&arg_28h + iVar14) = piVar22;
    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a003c;
    piVar16 = (int64_t *)func_0x000180224ed0((int64_t)(iVar12 + 0x50), 8, 0x1804ad498, 0x635);
    *(int64_t **)((int64_t)&arg_30h + iVar14) = piVar16;
    if (piVar16 == (int64_t *)0x0) {
        uVar27 = 0x637;
        goto code_r0x00018019fdde;
    }
    uVar20 = *(uint32_t *)((int64_t)&var_18h + iVar14);
    *(uint32_t *)((int64_t)&var_10h + iVar14) = ~*(uint32_t *)((int64_t)&var_10h + iVar14);
    *(uint32_t *)((int64_t)&arg_b0h + iVar14) = ~*(uint32_t *)((int64_t)&arg_b0h + iVar14);
    puVar24 = (uint32_t *)((int64_t)&var_10h + iVar14 + 4);
    *puVar24 = ~*puVar24;
    for (; piVar21 != (int64_t *)0x0; piVar21 = (int64_t *)piVar21[2]) {
        *piVar16 = *piVar21;
        piVar16 = piVar16 + 1;
    }
    uVar4 = *(uint32_t *)((int64_t)&var_10h + iVar14 + 4);
    puVar24 = (uint32_t *)0x1804ab8d0;
    uVar5 = *(uint32_t *)((int64_t)&arg_b0h + iVar14);
    uVar6 = *(uint32_t *)((int64_t)&var_10h + iVar14);
    do {
        if (((((puVar24[-1] == 0) || ((uVar6 & puVar24[-1]) != 0)) && ((*puVar24 == 0 || ((uVar5 & *puVar24) != 0)))) &&
            ((puVar24[1] == 0 || ((~uVar20 & puVar24[1]) != 0)))) && ((puVar24[2] == 0 || ((uVar4 & puVar24[2]) != 0))))
        {
            *piVar16 = (int64_t)(int32_t)uVar26 * 0x50 + 0x1804ab8b0;
            piVar16 = piVar16 + 1;
        }
        uVar26 = (uint64_t)((int32_t)uVar26 + 1);
        puVar24 = puVar24 + 0x14;
    } while ((int64_t)puVar24 < 0x1804ad180);
    iVar25 = 0;
    *piVar16 = 0;
    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a011e;
    iVar12 = func_0x000180498f90(pcVar28, 0x1804ad5f0, 7);
    uVar27 = *(undefined8 *)((int64_t)&arg_30h + iVar14);
    iVar13 = 1;
    uVar9 = *(undefined8 *)((int64_t)&arg_98h + iVar14);
    uVar10 = *(undefined8 *)((int64_t)&arg_b8h + iVar14);
    if (iVar12 == 0) {
        *(undefined8 *)(&stack0xffffffffffffffe0 + iVar14) = uVar10;
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a015b;
        iVar13 = func_0x00018019f010(0x1804ad600, (int64_t)&var_20h + iVar14, (int64_t)&arg_28h + iVar14, uVar27);
        pcVar1 = pcVar28 + 7;
        pcVar2 = pcVar28 + 7;
        pcVar28 = pcVar28 + 8;
        if (*pcVar1 != ':') {
            pcVar28 = pcVar2;
        }
        if (iVar13 != 0) goto code_r0x0001801a0173;
    } else {
code_r0x0001801a0173:
        if (*pcVar28 != '\0') {
            *(undefined8 *)(&stack0xffffffffffffffe0 + iVar14) = uVar10;
            *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a0192;
            iVar13 = func_0x00018019f010(pcVar28, (int64_t)&var_20h + iVar14, (int64_t)&arg_28h + iVar14, uVar27);
        }
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a01aa;
    func_0x000180224990(uVar27, 0x1804ad498, 0x64f);
    if (iVar13 == 0) {
        uVar27 = 0x652;
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a01bf;
        iVar17 = func_0x000180221f20();
        if (iVar17 != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a01da;
            iVar12 = func_0x000180222010(uVar9);
            if (0 < iVar12) {
                iVar19 = *(int64_t *)((int64_t)&arg_90h + iVar14);
                uVar20 = *(uint32_t *)((int64_t)&var_18h + iVar14);
                do {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a01fb;
                    iVar18 = func_0x000180222340(uVar9, iVar25);
                    if (((*(uint32_t *)(iVar18 + 0x24) & uVar20) == 0) &&
                       ((*(uint32_t *)(iVar19 + 0x694) &
                        *(uint32_t *)((uint64_t)*(uint8_t *)(iVar18 + 0x40) * 8 + 0x1804ab760)) == 0)) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a021b;
                        iVar12 = func_0x000180222110(iVar17, iVar18);
                        if (iVar12 == 0) {
                            uVar27 = 0x66e;
                            goto code_r0x0001801a0225;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a024b;
                        func_0x000180221890(uVar9, iVar25);
                        iVar25 = iVar25 + -1;
                    }
                    iVar25 = iVar25 + 1;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a0257;
                    iVar12 = func_0x000180222010(uVar9);
                } while (iVar25 < iVar12);
            }
            puVar11 = *(undefined8 **)((int64_t)&var_20h + iVar14);
            do {
                if (puVar11 == (undefined8 *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a0298;
                    func_0x000180224990(uVar15, 0x1804ad498, 0x687);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a02a0;
                    iVar19 = func_0x000180221950(iVar17);
                    if (iVar19 != 0) {
                        piVar21 = *(int64_t **)((int64_t)&arg_a8h + iVar14);
                        iVar18 = *piVar21;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a02b8;
                        func_0x000180221d50(iVar18);
                        *piVar21 = iVar19;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a02ca;
                        func_0x000180222270(iVar19, 0x180197350);
                        iVar19 = *piVar21;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a02d2;
                        func_0x0001802222d0(iVar19);
                        piVar21 = *(int64_t **)((int64_t)&arg_a0h + iVar14);
                        iVar19 = *piVar21;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a02e2;
                        func_0x000180221d50(iVar19);
                        *piVar21 = iVar17;
                        return iVar17;
                    }
code_r0x0001801a0234:
                    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a023c;
                    func_0x000180221d50(iVar17);
                    return 0;
                }
                if (*(int32_t *)(puVar11 + 1) != 0) {
                    uVar27 = *puVar11;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a0276;
                    iVar12 = func_0x000180222110(iVar17, uVar27);
                    if (iVar12 == 0) {
                        uVar27 = 0x67e;
code_r0x0001801a0225:
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801a0234;
                        func_0x000180224990(uVar15, 0x1804ad498, uVar27);
                        goto code_r0x0001801a0234;
                    }
                }
                puVar11 = (undefined8 *)puVar11[2];
            } while( true );
        }
        uVar27 = 0x65b;
    }
code_r0x00018019fdde:
    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x18019fded;
    func_0x000180224990(uVar15, 0x1804ad498, uVar27);
    return 0;
}

// ============================================================
// Function: FUN_1801a0300
// Address: 0x1801a0300
// Size: 67 bytes
// ============================================================
int32_t * fcn.1801a0300(int64_t param_1, undefined8 param_2, int32_t param_3)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int32_t *piVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a030c;
    iVar2 = fcn.18045a350();
    pcVar1 = *(code **)(*(int64_t *)(param_1 + 0x18) + 0xa8);
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801a0323;
    piVar3 = (int32_t *)(*pcVar1)(param_2);
    if ((piVar3 != (int32_t *)0x0) && (param_3 == 0)) {
        piVar4 = (int32_t *)0x0;
        if (*piVar3 != 0) {
            piVar4 = piVar3;
        }
        return piVar4;
    }
    return piVar3;
}

// ============================================================
// Function: FUN_1801a0380
// Address: 0x1801a0380
// Size: 57 bytes
// ============================================================
undefined8 fcn.1801a0380(int64_t param_1)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a038c;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801a0397;
    uVar1 = fcn.1801c69e0();
    if (uVar1 < 0xe) {
        return *(undefined8 *)(*(int64_t *)(param_1 + 8) + 0x560 + (uint64_t)uVar1 * 8);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a03c0
// Address: 0x1801a03c0
// Size: 1297 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801a03c0(int64_t arg_48h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    uint8_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    int64_t *piVar8;
    uint32_t *puVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801a03d9;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar11 = 0;
    puVar9 = (uint32_t *)0x1804ab6a0;
    *(undefined4 *)(in_RCX + 0xd2) = 0;
    piVar8 = in_RCX + 0x94;
    iVar10 = 0x18;
    do {
        uVar1 = puVar9[1];
        if (uVar1 != 0) {
            uVar2 = in_RCX[0x8c];
            uVar3 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0416;
            iVar7 = func_0x0001801973d0(uVar3, uVar1, uVar2);
            *piVar8 = iVar7;
            if (iVar7 == 0) {
                *(uint32_t *)(in_RCX + 0xd2) = *(uint32_t *)(in_RCX + 0xd2) | *puVar9;
            }
        }
        piVar8 = piVar8 + 1;
        puVar9 = puVar9 + 2;
        iVar10 = iVar10 + -1;
    } while (iVar10 != 0);
    *(undefined4 *)((int64_t)in_RCX + 0x694) = 0;
    puVar9 = (uint32_t *)0x1804ab760;
    piVar8 = in_RCX + 0xba;
    do {
        uVar2 = in_RCX[0x8c];
        uVar1 = puVar9[1];
        uVar3 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0462;
        iVar10 = func_0x000180197550(uVar3, uVar1, uVar2);
        piVar8[-0xe] = iVar10;
        if (iVar10 == 0) {
            *(uint32_t *)((int64_t)in_RCX + 0x694) = *(uint32_t *)((int64_t)in_RCX + 0x694) | *puVar9;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a047d;
            iVar5 = func_0x00018020f800(iVar10);
            if (iVar5 < 1) {
                return 0;
            }
            *piVar8 = (int64_t)iVar5;
        }
        uVar11 = uVar11 + 1;
        piVar8 = piVar8 + 1;
        puVar9 = puVar9 + 2;
    } while (uVar11 < 0xe);
    in_RCX[0xd3] = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a04a7;
    func_0x000180229b10();
    uVar2 = in_RCX[0x8c];
    uVar3 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a04bd;
    iVar10 = func_0x000180248180(uVar3, 0x1804ad420, uVar2);
    if (iVar10 == 0) {
        *(uint32_t *)((int64_t)in_RCX + 0x69c) = *(uint32_t *)((int64_t)in_RCX + 0x69c) | 2;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a04d3;
        func_0x0001802481d0(iVar10);
    }
    uVar2 = in_RCX[0x8c];
    uVar3 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a04e9;
    iVar10 = func_0x0001802495c0(uVar3, 0x1804ad19c, uVar2);
    if (iVar10 == 0) {
        *(uint32_t *)(in_RCX + 0xd3) = *(uint32_t *)(in_RCX + 0xd3) | 0x102;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0502;
        func_0x000180249610(iVar10);
    }
    uVar2 = in_RCX[0x8c];
    uVar3 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0518;
    iVar10 = func_0x0001802495c0(uVar3, 0x1804ad1b0, uVar2);
    if (iVar10 == 0) {
        *(uint32_t *)(in_RCX + 0xd3) = *(uint32_t *)(in_RCX + 0xd3) | 0x84;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0531;
        func_0x000180249610(iVar10);
    }
    uVar2 = in_RCX[0x8c];
    uVar3 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0547;
    iVar10 = func_0x000180248180(uVar3, 0x1804ad21c, uVar2);
    if (iVar10 == 0) {
        *(uint32_t *)((int64_t)in_RCX + 0x69c) = *(uint32_t *)((int64_t)in_RCX + 0x69c) | 8;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a055d;
        func_0x0001802481d0(iVar10);
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0562;
    func_0x0001802299d0();
    var_10h = 0;
    var_8h._0_4_ = 0;
    *(undefined4 *)(in_RCX + 0x8d) = 0x357;
    *(undefined4 *)((int64_t)in_RCX + 0x46c) = 0x357;
    *(undefined4 *)(in_RCX + 0x8e) = 0x357;
    *(undefined4 *)((int64_t)in_RCX + 0x474) = 0;
    *(undefined4 *)(in_RCX + 0x8f) = 0x357;
    *(undefined4 *)((int64_t)in_RCX + 0x47c) = 0x357;
    *(undefined4 *)(in_RCX + 0x90) = 0x357;
    *(undefined4 *)((int64_t)in_RCX + 0x484) = 0;
    *(undefined4 *)(in_RCX + 0x91) = 0x357;
    *(undefined4 *)((int64_t)in_RCX + 0x48c) = 0;
    *(undefined4 *)(in_RCX + 0x92) = 0;
    *(undefined4 *)((int64_t)in_RCX + 0x494) = 0;
    in_RCX[0x93] = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a05ba;
    iVar10 = func_0x0001802479a0(&var_10h, 0x1804ad428, 0xffffffff);
    if (iVar10 != 0) {
        *(int64_t *)(&stack0x00000000 + iVar6) = iVar10;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a05da;
        iVar5 = func_0x000180247bb0(&var_8h, 0, 0, 0);
        if (iVar5 < 1) {
            var_8h._0_4_ = 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a05eb;
    func_0x0001801bca50(var_10h);
    *(int32_t *)((int64_t)in_RCX + 0x474) = (int32_t)var_8h;
    if ((int32_t)var_8h == 0) {
        *(uint32_t *)((int64_t)in_RCX + 0x694) = *(uint32_t *)((int64_t)in_RCX + 0x694) | 8;
    } else {
        in_RCX[0xbd] = 0x20;
    }
    var_10h = 0;
    var_8h._0_4_ = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a062a;
    iVar10 = func_0x0001802479a0(&var_10h, 0x1804ad438, 0xffffffff);
    if (iVar10 != 0) {
        *(int64_t *)(&stack0x00000000 + iVar6) = iVar10;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a064a;
        iVar5 = func_0x000180247bb0(&var_8h, 0, 0, 0);
        if (iVar5 < 1) {
            var_8h._0_4_ = 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a065b;
    func_0x0001801bca50(var_10h);
    *(int32_t *)((int64_t)in_RCX + 0x484) = (int32_t)var_8h;
    if ((int32_t)var_8h == 0) {
        *(uint32_t *)((int64_t)in_RCX + 0x694) = *(uint32_t *)((int64_t)in_RCX + 0x694) | 0x100;
    } else {
        in_RCX[0xc1] = 0x20;
    }
    var_10h = 0;
    var_8h._0_4_ = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a069d;
    iVar10 = func_0x0001802479a0(&var_10h, 0x1804ad448, 0xffffffff);
    if (iVar10 != 0) {
        *(int64_t *)(&stack0x00000000 + iVar6) = iVar10;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a06bd;
        iVar5 = func_0x000180247bb0(&var_8h, 0, 0, 0);
        if (iVar5 < 1) {
            var_8h._0_4_ = 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a06ce;
    func_0x0001801bca50(var_10h);
    *(int32_t *)(in_RCX + 0x93) = (int32_t)var_8h;
    if ((int32_t)var_8h == 0) {
        *(uint32_t *)((int64_t)in_RCX + 0x694) = *(uint32_t *)((int64_t)in_RCX + 0x694) | 0x400;
    } else {
        in_RCX[0xc6] = 0x20;
    }
    var_10h = 0;
    var_8h._0_4_ = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0710;
    iVar10 = func_0x0001802479a0(&var_10h, 0x1804ad458, 0xffffffff);
    if (iVar10 != 0) {
        *(int64_t *)(&stack0x00000000 + iVar6) = iVar10;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0730;
        iVar5 = func_0x000180247bb0(&var_8h, 0, 0, 0);
        if (iVar5 < 1) {
            var_8h._0_4_ = 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0741;
    func_0x0001801bca50(var_10h);
    *(int32_t *)((int64_t)in_RCX + 0x49c) = (int32_t)var_8h;
    if ((int32_t)var_8h == 0) {
        *(uint32_t *)((int64_t)in_RCX + 0x694) = *(uint32_t *)((int64_t)in_RCX + 0x694) | 0x800;
    } else {
        in_RCX[199] = 0x20;
    }
    var_10h = 0;
    var_8h._0_4_ = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0783;
    iVar10 = func_0x0001802479a0(&var_10h, 0x1804ad468, 0xffffffff);
    if (iVar10 != 0) {
        *(int64_t *)(&stack0x00000000 + iVar6) = iVar10;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a07a3;
        iVar5 = func_0x000180247bb0(&var_8h, 0, 0, 0);
        if (iVar5 < 1) {
            var_8h._0_4_ = 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a07b4;
    func_0x0001801bca50(var_10h);
    if ((int32_t)var_8h == 0) {
        *(uint32_t *)((int64_t)in_RCX + 0x69c) = *(uint32_t *)((int64_t)in_RCX + 0x69c) | 0xa0;
    }
    var_10h = 0;
    var_8h._0_4_ = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a07e2;
    iVar10 = func_0x0001802479a0(&var_10h, 0x1804ad478, 0xffffffff);
    if (iVar10 != 0) {
        *(int64_t *)(&stack0x00000000 + iVar6) = iVar10;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0802;
        iVar5 = func_0x000180247bb0(&var_8h, 0, 0, 0);
        if (iVar5 < 1) {
            var_8h._0_4_ = 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0813;
    func_0x0001801bca50(var_10h);
    if ((int32_t)var_8h == 0) {
        *(uint32_t *)((int64_t)in_RCX + 0x69c) = *(uint32_t *)((int64_t)in_RCX + 0x69c) | 0x80;
    }
    var_10h = 0;
    var_8h._0_4_ = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0841;
    iVar10 = func_0x0001802479a0(&var_10h, 0x1804ad488, 0xffffffff);
    if (iVar10 != 0) {
        *(int64_t *)(&stack0x00000000 + iVar6) = iVar10;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0861;
        iVar5 = func_0x000180247bb0(&var_8h, 0, 0, 0);
        if (iVar5 < 1) {
            var_8h._0_4_ = 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801a0872;
    func_0x0001801bca50(var_10h);
    if ((int32_t)var_8h == 0) {
        *(uint32_t *)((int64_t)in_RCX + 0x69c) = *(uint32_t *)((int64_t)in_RCX + 0x69c) | 0x80;
    }
    uVar4 = (uint8_t)*(undefined4 *)((int64_t)in_RCX + 0x69c);
    if ((uVar4 & 0xa0) == 0xa0) {
        *(uint32_t *)(in_RCX + 0xd3) = *(uint32_t *)(in_RCX + 0xd3) | 0x10;
    }
    if ((char)uVar4 < '\0') {
        *(uint32_t *)(in_RCX + 0xd3) = *(uint32_t *)(in_RCX + 0xd3) | 0x200;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801a0900
// Address: 0x1801a0900
// Size: 60 bytes
// ============================================================
undefined8 fcn.1801a0900(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a090c;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801a0917;
    iVar1 = fcn.1801c69e0();
    uVar3 = iVar1 >> 8 & 0xff;
    if (uVar3 < 0xe) {
        return *(undefined8 *)(*(int64_t *)(param_1 + 8) + 0x560 + (uint64_t)uVar3 * 8);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a0940
// Address: 0x1801a0940
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801a0940(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t *in_RDX;
    undefined8 unaff_RDI;
    int64_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a0959;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0970;
    uVar5 = func_0x000180221950(uVar5);
    if (uVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0989;
        iVar3 = func_0x000180222010(uVar5);
        while (0 < iVar3) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a099a;
            iVar6 = func_0x000180222340(uVar5, 0);
            if (*(int32_t *)(iVar6 + 0x2c) != 0x304) break;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09ad;
            func_0x000180221890(uVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09b5;
            iVar3 = func_0x000180222010(uVar5);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09c1;
        iVar3 = func_0x000180222010(in_R9);
        iVar3 = iVar3 + -1;
        if (-1 < iVar3) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R12;
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09de;
                iVar6 = func_0x000180222340(in_R9, iVar3);
                if (((*(uint32_t *)(in_RCX + 0x690) & *(uint32_t *)(iVar6 + 0x24)) == 0) &&
                   ((*(uint32_t *)(in_RCX + 0x694) &
                    *(uint32_t *)((uint64_t)*(uint8_t *)(iVar6 + 0x40) * 8 + 0x1804ab760)) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a04;
                    func_0x000180222320(uVar5, iVar6);
                }
                iVar3 = iVar3 + -1;
            } while (-1 < iVar3);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a16;
        iVar6 = func_0x000180221950(uVar5);
        if (iVar6 != 0) {
            iVar1 = *in_R8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a32;
            func_0x000180221d50(iVar1);
            *in_R8 = iVar6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a44;
            func_0x000180222270(iVar6, 0x180197350);
            iVar1 = *in_R8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a4c;
            func_0x0001802222d0(iVar1);
            uVar2 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a54;
            func_0x000180221d50(uVar2);
            *in_RDX = uVar5;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a26;
            func_0x000180221d50(uVar5);
        }
        uVar5 = (uint64_t)(iVar6 != 0);
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1801a097f
// Address: 0x1801a097f
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801a0940(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t *in_RDX;
    undefined8 unaff_RDI;
    int64_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a0959;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0970;
    uVar5 = func_0x000180221950(uVar5);
    if (uVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0989;
        iVar3 = func_0x000180222010(uVar5);
        while (0 < iVar3) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a099a;
            iVar6 = func_0x000180222340(uVar5, 0);
            if (*(int32_t *)(iVar6 + 0x2c) != 0x304) break;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09ad;
            func_0x000180221890(uVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09b5;
            iVar3 = func_0x000180222010(uVar5);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09c1;
        iVar3 = func_0x000180222010(in_R9);
        iVar3 = iVar3 + -1;
        if (-1 < iVar3) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R12;
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09de;
                iVar6 = func_0x000180222340(in_R9, iVar3);
                if (((*(uint32_t *)(in_RCX + 0x690) & *(uint32_t *)(iVar6 + 0x24)) == 0) &&
                   ((*(uint32_t *)(in_RCX + 0x694) &
                    *(uint32_t *)((uint64_t)*(uint8_t *)(iVar6 + 0x40) * 8 + 0x1804ab760)) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a04;
                    func_0x000180222320(uVar5, iVar6);
                }
                iVar3 = iVar3 + -1;
            } while (-1 < iVar3);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a16;
        iVar6 = func_0x000180221950(uVar5);
        if (iVar6 != 0) {
            iVar1 = *in_R8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a32;
            func_0x000180221d50(iVar1);
            *in_R8 = iVar6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a44;
            func_0x000180222270(iVar6, 0x180197350);
            iVar1 = *in_R8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a4c;
            func_0x0001802222d0(iVar1);
            uVar2 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a54;
            func_0x000180221d50(uVar2);
            *in_RDX = uVar5;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a26;
            func_0x000180221d50(uVar5);
        }
        uVar5 = (uint64_t)(iVar6 != 0);
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1801a09c8
// Address: 0x1801a09c8
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801a0940(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t *in_RDX;
    undefined8 unaff_RDI;
    int64_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a0959;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0970;
    uVar5 = func_0x000180221950(uVar5);
    if (uVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0989;
        iVar3 = func_0x000180222010(uVar5);
        while (0 < iVar3) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a099a;
            iVar6 = func_0x000180222340(uVar5, 0);
            if (*(int32_t *)(iVar6 + 0x2c) != 0x304) break;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09ad;
            func_0x000180221890(uVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09b5;
            iVar3 = func_0x000180222010(uVar5);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09c1;
        iVar3 = func_0x000180222010(in_R9);
        iVar3 = iVar3 + -1;
        if (-1 < iVar3) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R12;
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09de;
                iVar6 = func_0x000180222340(in_R9, iVar3);
                if (((*(uint32_t *)(in_RCX + 0x690) & *(uint32_t *)(iVar6 + 0x24)) == 0) &&
                   ((*(uint32_t *)(in_RCX + 0x694) &
                    *(uint32_t *)((uint64_t)*(uint8_t *)(iVar6 + 0x40) * 8 + 0x1804ab760)) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a04;
                    func_0x000180222320(uVar5, iVar6);
                }
                iVar3 = iVar3 + -1;
            } while (-1 < iVar3);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a16;
        iVar6 = func_0x000180221950(uVar5);
        if (iVar6 != 0) {
            iVar1 = *in_R8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a32;
            func_0x000180221d50(iVar1);
            *in_R8 = iVar6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a44;
            func_0x000180222270(iVar6, 0x180197350);
            iVar1 = *in_R8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a4c;
            func_0x0001802222d0(iVar1);
            uVar2 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a54;
            func_0x000180221d50(uVar2);
            *in_RDX = uVar5;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a26;
            func_0x000180221d50(uVar5);
        }
        uVar5 = (uint64_t)(iVar6 != 0);
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1801a0a0e
// Address: 0x1801a0a0e
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801a0940(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t *in_RDX;
    undefined8 unaff_RDI;
    int64_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a0959;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0970;
    uVar5 = func_0x000180221950(uVar5);
    if (uVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0989;
        iVar3 = func_0x000180222010(uVar5);
        while (0 < iVar3) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a099a;
            iVar6 = func_0x000180222340(uVar5, 0);
            if (*(int32_t *)(iVar6 + 0x2c) != 0x304) break;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09ad;
            func_0x000180221890(uVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09b5;
            iVar3 = func_0x000180222010(uVar5);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09c1;
        iVar3 = func_0x000180222010(in_R9);
        iVar3 = iVar3 + -1;
        if (-1 < iVar3) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R12;
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09de;
                iVar6 = func_0x000180222340(in_R9, iVar3);
                if (((*(uint32_t *)(in_RCX + 0x690) & *(uint32_t *)(iVar6 + 0x24)) == 0) &&
                   ((*(uint32_t *)(in_RCX + 0x694) &
                    *(uint32_t *)((uint64_t)*(uint8_t *)(iVar6 + 0x40) * 8 + 0x1804ab760)) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a04;
                    func_0x000180222320(uVar5, iVar6);
                }
                iVar3 = iVar3 + -1;
            } while (-1 < iVar3);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a16;
        iVar6 = func_0x000180221950(uVar5);
        if (iVar6 != 0) {
            iVar1 = *in_R8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a32;
            func_0x000180221d50(iVar1);
            *in_R8 = iVar6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a44;
            func_0x000180222270(iVar6, 0x180197350);
            iVar1 = *in_R8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a4c;
            func_0x0001802222d0(iVar1);
            uVar2 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a54;
            func_0x000180221d50(uVar2);
            *in_RDX = uVar5;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a26;
            func_0x000180221d50(uVar5);
        }
        uVar5 = (uint64_t)(iVar6 != 0);
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1801a0a61
// Address: 0x1801a0a61
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801a0940(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t *in_RDX;
    undefined8 unaff_RDI;
    int64_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a0959;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0970;
    uVar5 = func_0x000180221950(uVar5);
    if (uVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0989;
        iVar3 = func_0x000180222010(uVar5);
        while (0 < iVar3) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a099a;
            iVar6 = func_0x000180222340(uVar5, 0);
            if (*(int32_t *)(iVar6 + 0x2c) != 0x304) break;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09ad;
            func_0x000180221890(uVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09b5;
            iVar3 = func_0x000180222010(uVar5);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09c1;
        iVar3 = func_0x000180222010(in_R9);
        iVar3 = iVar3 + -1;
        if (-1 < iVar3) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R12;
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a09de;
                iVar6 = func_0x000180222340(in_R9, iVar3);
                if (((*(uint32_t *)(in_RCX + 0x690) & *(uint32_t *)(iVar6 + 0x24)) == 0) &&
                   ((*(uint32_t *)(in_RCX + 0x694) &
                    *(uint32_t *)((uint64_t)*(uint8_t *)(iVar6 + 0x40) * 8 + 0x1804ab760)) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a04;
                    func_0x000180222320(uVar5, iVar6);
                }
                iVar3 = iVar3 + -1;
            } while (-1 < iVar3);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a16;
        iVar6 = func_0x000180221950(uVar5);
        if (iVar6 != 0) {
            iVar1 = *in_R8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a32;
            func_0x000180221d50(iVar1);
            *in_R8 = iVar6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a44;
            func_0x000180222270(iVar6, 0x180197350);
            iVar1 = *in_R8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a4c;
            func_0x0001802222d0(iVar1);
            uVar2 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a54;
            func_0x000180221d50(uVar2);
            *in_RDX = uVar5;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a0a26;
            func_0x000180221d50(uVar5);
        }
        uVar5 = (uint64_t)(iVar6 != 0);
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1801a0a80
// Address: 0x1801a0a80
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801a0a80(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a0a90;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RDX != 0) {
        if (*(int64_t *)(in_RCX + 0x130) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a0aad;
            iVar3 = func_0x000180221f20();
            *(int64_t *)(in_RCX + 0x130) = iVar3;
            if (iVar3 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a0ac1;
        uVar4 = func_0x000180238460(in_RDX);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a0ac9;
        iVar3 = func_0x0001802348d0(uVar4);
        if (iVar3 != 0) {
            uVar4 = *(undefined8 *)(in_RCX + 0x130);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a0ae0;
            iVar1 = func_0x000180222110(uVar4, iVar3);
            if (iVar1 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a0aec;
            func_0x0001802348f0(iVar3);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a0b10
// Address: 0x1801a0b10
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801a0b10(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a0b20;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a0b3c;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)(in_RCX + 0x128) = in_RDX;
    return;
}

// ============================================================
// Function: FUN_1801a0b50
// Address: 0x1801a0b50
// Size: 35 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2eh

void fcn.1801a0b50(int64_t arg_28h, int64_t arg_60h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801a0b5e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000460 + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar3);
    *(undefined8 *)(&stack0x00000490 + iVar3) = unaff_RSI;
    iVar10 = 0;
    *(undefined8 *)(&stack0x00000470 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0ba4;
    uVar4 = func_0x000180229130(0x1801a2d40, 0x1801a2c90);
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x180195290;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bcd;
    iVar5 = func_0x000180229290(uVar4, 0x1801952b0, 0x180195290, 0x1801952b0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bda;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bf2;
        func_0x0001802295a0(0x1804ad6e8, 0x3be, 0x1804ad7c0);
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c04;
        func_0x0001802296d0(0x14, 0x8000f, 0);
    } else {
        *(undefined8 *)(&stack0x000004c0 + iVar3) = unaff_RBX;
        *(undefined8 *)(&stack0x00000488 + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c21;
        iVar1 = func_0x000180222010(in_RCX);
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c3a;
                uVar4 = func_0x000180222340(in_RCX, iVar10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c45;
                func_0x000180228fb0(iVar5, uVar4);
                iVar10 = iVar10 + 1;
            } while (iVar10 < iVar1);
        }
        *(undefined8 *)(&stack0x00000480 + iVar3) = unaff_R12;
        *(undefined8 *)(&stack0x00000478 + iVar3) = unaff_R13;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c68;
        iVar6 = func_0x00018024b460((int64_t)&var_20h + iVar3, in_RDX);
        while (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c88;
            iVar7 = func_0x000180498cd0(iVar6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c93;
            iVar8 = func_0x000180498cd0(in_RDX);
            if (0x400 < (uint64_t)(iVar8 + 2 + iVar7)) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0da5;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0dbd;
                func_0x0001802295a0(0x1804ad6e8, 0x3da, 0x1804ad7c0);
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0dcf;
                func_0x0001802296d0(0x14, 0x10e, 0);
                goto code_r0x0001801a0df7;
            }
            *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0cc5;
            iVar10 = func_0x000180245f70((int64_t)&arg_60h + iVar3, 0x400, 0x1804ad7e4, in_RDX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0cd6;
            iVar1 = func_0x000180472e30((int64_t)&arg_60h + iVar3, (int64_t)&arg_28h + iVar3);
            if ((iVar1 != 0) || ((*(uint16_t *)((int64_t)&arg_28h + iVar3 + 6) & 0xf000) != 0x4000)) {
                if (0x3fe < iVar10 - 1U) goto code_r0x0001801a0df7;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d07;
                iVar10 = func_0x0001801a1130(in_RCX, (int64_t)&arg_60h + iVar3, iVar5);
                if (iVar10 == 0) goto code_r0x0001801a0df7;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d1c;
            iVar6 = func_0x00018024b460((int64_t)&var_20h + iVar3, in_RDX);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d2d;
        piVar9 = (int32_t *)func_0x00018046b77c();
        if (*piVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d3b;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d53;
            func_0x0001802295a0(0x1804ad6e8, 0x3ee, 0x1804ad7c0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d59;
            uVar2 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d6f;
            func_0x0001802296d0(2, uVar2, 0x1804ad7f0, in_RDX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d74;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d8c;
            func_0x0001802295a0(0x1804ad6e8, 0x3f0, 0x1804ad7c0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d9e;
            func_0x0001802296d0(0x14, 0x80002, 0);
        }
    }
code_r0x0001801a0df7:
    if (*(int64_t *)((int64_t)&var_20h + iVar3) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e19;
        func_0x00018024b400((int64_t)&var_20h + iVar3);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e21;
    func_0x000180228ec0(iVar5);
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e34;
    func_0x000180459870(*(uint64_t *)(&stack0x00000460 + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801a0b73
// Address: 0x1801a0b73
// Size: 150 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2eh

void fcn.1801a0b50(int64_t arg_28h, int64_t arg_60h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801a0b5e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000460 + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar3);
    *(undefined8 *)(&stack0x00000490 + iVar3) = unaff_RSI;
    iVar10 = 0;
    *(undefined8 *)(&stack0x00000470 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0ba4;
    uVar4 = func_0x000180229130(0x1801a2d40, 0x1801a2c90);
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x180195290;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bcd;
    iVar5 = func_0x000180229290(uVar4, 0x1801952b0, 0x180195290, 0x1801952b0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bda;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bf2;
        func_0x0001802295a0(0x1804ad6e8, 0x3be, 0x1804ad7c0);
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c04;
        func_0x0001802296d0(0x14, 0x8000f, 0);
    } else {
        *(undefined8 *)(&stack0x000004c0 + iVar3) = unaff_RBX;
        *(undefined8 *)(&stack0x00000488 + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c21;
        iVar1 = func_0x000180222010(in_RCX);
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c3a;
                uVar4 = func_0x000180222340(in_RCX, iVar10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c45;
                func_0x000180228fb0(iVar5, uVar4);
                iVar10 = iVar10 + 1;
            } while (iVar10 < iVar1);
        }
        *(undefined8 *)(&stack0x00000480 + iVar3) = unaff_R12;
        *(undefined8 *)(&stack0x00000478 + iVar3) = unaff_R13;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c68;
        iVar6 = func_0x00018024b460((int64_t)&var_20h + iVar3, in_RDX);
        while (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c88;
            iVar7 = func_0x000180498cd0(iVar6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c93;
            iVar8 = func_0x000180498cd0(in_RDX);
            if (0x400 < (uint64_t)(iVar8 + 2 + iVar7)) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0da5;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0dbd;
                func_0x0001802295a0(0x1804ad6e8, 0x3da, 0x1804ad7c0);
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0dcf;
                func_0x0001802296d0(0x14, 0x10e, 0);
                goto code_r0x0001801a0df7;
            }
            *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0cc5;
            iVar10 = func_0x000180245f70((int64_t)&arg_60h + iVar3, 0x400, 0x1804ad7e4, in_RDX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0cd6;
            iVar1 = func_0x000180472e30((int64_t)&arg_60h + iVar3, (int64_t)&arg_28h + iVar3);
            if ((iVar1 != 0) || ((*(uint16_t *)((int64_t)&arg_28h + iVar3 + 6) & 0xf000) != 0x4000)) {
                if (0x3fe < iVar10 - 1U) goto code_r0x0001801a0df7;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d07;
                iVar10 = func_0x0001801a1130(in_RCX, (int64_t)&arg_60h + iVar3, iVar5);
                if (iVar10 == 0) goto code_r0x0001801a0df7;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d1c;
            iVar6 = func_0x00018024b460((int64_t)&var_20h + iVar3, in_RDX);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d2d;
        piVar9 = (int32_t *)func_0x00018046b77c();
        if (*piVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d3b;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d53;
            func_0x0001802295a0(0x1804ad6e8, 0x3ee, 0x1804ad7c0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d59;
            uVar2 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d6f;
            func_0x0001802296d0(2, uVar2, 0x1804ad7f0, in_RDX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d74;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d8c;
            func_0x0001802295a0(0x1804ad6e8, 0x3f0, 0x1804ad7c0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d9e;
            func_0x0001802296d0(0x14, 0x80002, 0);
        }
    }
code_r0x0001801a0df7:
    if (*(int64_t *)((int64_t)&var_20h + iVar3) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e19;
        func_0x00018024b400((int64_t)&var_20h + iVar3);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e21;
    func_0x000180228ec0(iVar5);
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e34;
    func_0x000180459870(*(uint64_t *)(&stack0x00000460 + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801a0c09
// Address: 0x1801a0c09
// Size: 494 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2eh

void fcn.1801a0b50(int64_t arg_28h, int64_t arg_60h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801a0b5e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000460 + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar3);
    *(undefined8 *)(&stack0x00000490 + iVar3) = unaff_RSI;
    iVar10 = 0;
    *(undefined8 *)(&stack0x00000470 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0ba4;
    uVar4 = func_0x000180229130(0x1801a2d40, 0x1801a2c90);
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x180195290;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bcd;
    iVar5 = func_0x000180229290(uVar4, 0x1801952b0, 0x180195290, 0x1801952b0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bda;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bf2;
        func_0x0001802295a0(0x1804ad6e8, 0x3be, 0x1804ad7c0);
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c04;
        func_0x0001802296d0(0x14, 0x8000f, 0);
    } else {
        *(undefined8 *)(&stack0x000004c0 + iVar3) = unaff_RBX;
        *(undefined8 *)(&stack0x00000488 + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c21;
        iVar1 = func_0x000180222010(in_RCX);
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c3a;
                uVar4 = func_0x000180222340(in_RCX, iVar10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c45;
                func_0x000180228fb0(iVar5, uVar4);
                iVar10 = iVar10 + 1;
            } while (iVar10 < iVar1);
        }
        *(undefined8 *)(&stack0x00000480 + iVar3) = unaff_R12;
        *(undefined8 *)(&stack0x00000478 + iVar3) = unaff_R13;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c68;
        iVar6 = func_0x00018024b460((int64_t)&var_20h + iVar3, in_RDX);
        while (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c88;
            iVar7 = func_0x000180498cd0(iVar6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c93;
            iVar8 = func_0x000180498cd0(in_RDX);
            if (0x400 < (uint64_t)(iVar8 + 2 + iVar7)) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0da5;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0dbd;
                func_0x0001802295a0(0x1804ad6e8, 0x3da, 0x1804ad7c0);
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0dcf;
                func_0x0001802296d0(0x14, 0x10e, 0);
                goto code_r0x0001801a0df7;
            }
            *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0cc5;
            iVar10 = func_0x000180245f70((int64_t)&arg_60h + iVar3, 0x400, 0x1804ad7e4, in_RDX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0cd6;
            iVar1 = func_0x000180472e30((int64_t)&arg_60h + iVar3, (int64_t)&arg_28h + iVar3);
            if ((iVar1 != 0) || ((*(uint16_t *)((int64_t)&arg_28h + iVar3 + 6) & 0xf000) != 0x4000)) {
                if (0x3fe < iVar10 - 1U) goto code_r0x0001801a0df7;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d07;
                iVar10 = func_0x0001801a1130(in_RCX, (int64_t)&arg_60h + iVar3, iVar5);
                if (iVar10 == 0) goto code_r0x0001801a0df7;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d1c;
            iVar6 = func_0x00018024b460((int64_t)&var_20h + iVar3, in_RDX);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d2d;
        piVar9 = (int32_t *)func_0x00018046b77c();
        if (*piVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d3b;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d53;
            func_0x0001802295a0(0x1804ad6e8, 0x3ee, 0x1804ad7c0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d59;
            uVar2 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d6f;
            func_0x0001802296d0(2, uVar2, 0x1804ad7f0, in_RDX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d74;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d8c;
            func_0x0001802295a0(0x1804ad6e8, 0x3f0, 0x1804ad7c0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d9e;
            func_0x0001802296d0(0x14, 0x80002, 0);
        }
    }
code_r0x0001801a0df7:
    if (*(int64_t *)((int64_t)&var_20h + iVar3) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e19;
        func_0x00018024b400((int64_t)&var_20h + iVar3);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e21;
    func_0x000180228ec0(iVar5);
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e34;
    func_0x000180459870(*(uint64_t *)(&stack0x00000460 + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801a0df7
// Address: 0x1801a0df7
// Size: 24 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2eh

void fcn.1801a0b50(int64_t arg_28h, int64_t arg_60h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801a0b5e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000460 + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar3);
    *(undefined8 *)(&stack0x00000490 + iVar3) = unaff_RSI;
    iVar10 = 0;
    *(undefined8 *)(&stack0x00000470 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0ba4;
    uVar4 = func_0x000180229130(0x1801a2d40, 0x1801a2c90);
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x180195290;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bcd;
    iVar5 = func_0x000180229290(uVar4, 0x1801952b0, 0x180195290, 0x1801952b0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bda;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bf2;
        func_0x0001802295a0(0x1804ad6e8, 0x3be, 0x1804ad7c0);
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c04;
        func_0x0001802296d0(0x14, 0x8000f, 0);
    } else {
        *(undefined8 *)(&stack0x000004c0 + iVar3) = unaff_RBX;
        *(undefined8 *)(&stack0x00000488 + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c21;
        iVar1 = func_0x000180222010(in_RCX);
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c3a;
                uVar4 = func_0x000180222340(in_RCX, iVar10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c45;
                func_0x000180228fb0(iVar5, uVar4);
                iVar10 = iVar10 + 1;
            } while (iVar10 < iVar1);
        }
        *(undefined8 *)(&stack0x00000480 + iVar3) = unaff_R12;
        *(undefined8 *)(&stack0x00000478 + iVar3) = unaff_R13;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c68;
        iVar6 = func_0x00018024b460((int64_t)&var_20h + iVar3, in_RDX);
        while (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c88;
            iVar7 = func_0x000180498cd0(iVar6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c93;
            iVar8 = func_0x000180498cd0(in_RDX);
            if (0x400 < (uint64_t)(iVar8 + 2 + iVar7)) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0da5;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0dbd;
                func_0x0001802295a0(0x1804ad6e8, 0x3da, 0x1804ad7c0);
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0dcf;
                func_0x0001802296d0(0x14, 0x10e, 0);
                goto code_r0x0001801a0df7;
            }
            *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0cc5;
            iVar10 = func_0x000180245f70((int64_t)&arg_60h + iVar3, 0x400, 0x1804ad7e4, in_RDX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0cd6;
            iVar1 = func_0x000180472e30((int64_t)&arg_60h + iVar3, (int64_t)&arg_28h + iVar3);
            if ((iVar1 != 0) || ((*(uint16_t *)((int64_t)&arg_28h + iVar3 + 6) & 0xf000) != 0x4000)) {
                if (0x3fe < iVar10 - 1U) goto code_r0x0001801a0df7;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d07;
                iVar10 = func_0x0001801a1130(in_RCX, (int64_t)&arg_60h + iVar3, iVar5);
                if (iVar10 == 0) goto code_r0x0001801a0df7;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d1c;
            iVar6 = func_0x00018024b460((int64_t)&var_20h + iVar3, in_RDX);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d2d;
        piVar9 = (int32_t *)func_0x00018046b77c();
        if (*piVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d3b;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d53;
            func_0x0001802295a0(0x1804ad6e8, 0x3ee, 0x1804ad7c0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d59;
            uVar2 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d6f;
            func_0x0001802296d0(2, uVar2, 0x1804ad7f0, in_RDX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d74;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d8c;
            func_0x0001802295a0(0x1804ad6e8, 0x3f0, 0x1804ad7c0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d9e;
            func_0x0001802296d0(0x14, 0x80002, 0);
        }
    }
code_r0x0001801a0df7:
    if (*(int64_t *)((int64_t)&var_20h + iVar3) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e19;
        func_0x00018024b400((int64_t)&var_20h + iVar3);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e21;
    func_0x000180228ec0(iVar5);
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e34;
    func_0x000180459870(*(uint64_t *)(&stack0x00000460 + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801a0e0f
// Address: 0x1801a0e0f
// Size: 48 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_488h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_478h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2eh

void fcn.1801a0b50(int64_t arg_28h, int64_t arg_60h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t *piVar9;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801a0b5e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000460 + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar3);
    *(undefined8 *)(&stack0x00000490 + iVar3) = unaff_RSI;
    iVar10 = 0;
    *(undefined8 *)(&stack0x00000470 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0ba4;
    uVar4 = func_0x000180229130(0x1801a2d40, 0x1801a2c90);
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x180195290;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bcd;
    iVar5 = func_0x000180229290(uVar4, 0x1801952b0, 0x180195290, 0x1801952b0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bda;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0bf2;
        func_0x0001802295a0(0x1804ad6e8, 0x3be, 0x1804ad7c0);
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c04;
        func_0x0001802296d0(0x14, 0x8000f, 0);
    } else {
        *(undefined8 *)(&stack0x000004c0 + iVar3) = unaff_RBX;
        *(undefined8 *)(&stack0x00000488 + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c21;
        iVar1 = func_0x000180222010(in_RCX);
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c3a;
                uVar4 = func_0x000180222340(in_RCX, iVar10);
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c45;
                func_0x000180228fb0(iVar5, uVar4);
                iVar10 = iVar10 + 1;
            } while (iVar10 < iVar1);
        }
        *(undefined8 *)(&stack0x00000480 + iVar3) = unaff_R12;
        *(undefined8 *)(&stack0x00000478 + iVar3) = unaff_R13;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c68;
        iVar6 = func_0x00018024b460((int64_t)&var_20h + iVar3, in_RDX);
        while (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c88;
            iVar7 = func_0x000180498cd0(iVar6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0c93;
            iVar8 = func_0x000180498cd0(in_RDX);
            if (0x400 < (uint64_t)(iVar8 + 2 + iVar7)) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0da5;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0dbd;
                func_0x0001802295a0(0x1804ad6e8, 0x3da, 0x1804ad7c0);
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0dcf;
                func_0x0001802296d0(0x14, 0x10e, 0);
                goto code_r0x0001801a0df7;
            }
            *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0cc5;
            iVar10 = func_0x000180245f70((int64_t)&arg_60h + iVar3, 0x400, 0x1804ad7e4, in_RDX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0cd6;
            iVar1 = func_0x000180472e30((int64_t)&arg_60h + iVar3, (int64_t)&arg_28h + iVar3);
            if ((iVar1 != 0) || ((*(uint16_t *)((int64_t)&arg_28h + iVar3 + 6) & 0xf000) != 0x4000)) {
                if (0x3fe < iVar10 - 1U) goto code_r0x0001801a0df7;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d07;
                iVar10 = func_0x0001801a1130(in_RCX, (int64_t)&arg_60h + iVar3, iVar5);
                if (iVar10 == 0) goto code_r0x0001801a0df7;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d1c;
            iVar6 = func_0x00018024b460((int64_t)&var_20h + iVar3, in_RDX);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d2d;
        piVar9 = (int32_t *)func_0x00018046b77c();
        if (*piVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d3b;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d53;
            func_0x0001802295a0(0x1804ad6e8, 0x3ee, 0x1804ad7c0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d59;
            uVar2 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d6f;
            func_0x0001802296d0(2, uVar2, 0x1804ad7f0, in_RDX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d74;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d8c;
            func_0x0001802295a0(0x1804ad6e8, 0x3f0, 0x1804ad7c0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0d9e;
            func_0x0001802296d0(0x14, 0x80002, 0);
        }
    }
code_r0x0001801a0df7:
    if (*(int64_t *)((int64_t)&var_20h + iVar3) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e19;
        func_0x00018024b400((int64_t)&var_20h + iVar3);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e21;
    func_0x000180228ec0(iVar5);
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801a0e34;
    func_0x000180459870(*(uint64_t *)(&stack0x00000460 + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801a0e40
// Address: 0x1801a0e40
// Size: 179 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.1801a0e40(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 in_RCX;
    int64_t in_RDX;
    int32_t iVar6;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a0e5b;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0e77;
    uVar4 = func_0x000180229130(0x1801a2d40, 0x1801a2c90);
    *(undefined8 *)((int64_t)&var_18h + iVar3) = 0x180195290;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0ea0;
    iVar5 = func_0x000180229290(uVar4, 0x1801952b0, 0x180195290, 0x1801952b0);
    if (in_RDX == 0) {
        uVar4 = 0xc0102;
        uVar7 = 0x393;
    } else {
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0efd;
            iVar1 = func_0x000180222010(in_RCX);
            iVar6 = 0;
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0f0f;
                    uVar4 = func_0x000180222340(in_RCX, iVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0f1a;
                    func_0x000180228fb0(iVar5, uVar4);
                    iVar6 = iVar6 + 1;
                } while (iVar6 < iVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0f2e;
            uVar2 = func_0x0001801a1130(in_RCX, in_RDX, iVar5);
            goto code_r0x0001801a0f35;
        }
        uVar4 = 0x8000f;
        uVar7 = 0x398;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0ec8;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0edd;
    func_0x0001802295a0(0x1804ad6e8, uVar7, 0x1804ad798);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0eec;
    func_0x0001802296d0(0x14, uVar4, 0);
    uVar2 = 0;
code_r0x0001801a0f35:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0f3d;
    func_0x000180228ec0(iVar5);
    return uVar2;
}

// ============================================================
// Function: FUN_1801a0ef3
// Address: 0x1801a0ef3
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.1801a0e40(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 in_RCX;
    int64_t in_RDX;
    int32_t iVar6;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a0e5b;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0e77;
    uVar4 = func_0x000180229130(0x1801a2d40, 0x1801a2c90);
    *(undefined8 *)((int64_t)&var_18h + iVar3) = 0x180195290;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0ea0;
    iVar5 = func_0x000180229290(uVar4, 0x1801952b0, 0x180195290, 0x1801952b0);
    if (in_RDX == 0) {
        uVar4 = 0xc0102;
        uVar7 = 0x393;
    } else {
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0efd;
            iVar1 = func_0x000180222010(in_RCX);
            iVar6 = 0;
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0f0f;
                    uVar4 = func_0x000180222340(in_RCX, iVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0f1a;
                    func_0x000180228fb0(iVar5, uVar4);
                    iVar6 = iVar6 + 1;
                } while (iVar6 < iVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0f2e;
            uVar2 = func_0x0001801a1130(in_RCX, in_RDX, iVar5);
            goto code_r0x0001801a0f35;
        }
        uVar4 = 0x8000f;
        uVar7 = 0x398;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0ec8;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0edd;
    func_0x0001802295a0(0x1804ad6e8, uVar7, 0x1804ad798);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0eec;
    func_0x0001802296d0(0x14, uVar4, 0);
    uVar2 = 0;
code_r0x0001801a0f35:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0f3d;
    func_0x000180228ec0(iVar5);
    return uVar2;
}

// ============================================================
// Function: FUN_1801a0f35
// Address: 0x1801a0f35
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.1801a0e40(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 in_RCX;
    int64_t in_RDX;
    int32_t iVar6;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a0e5b;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0e77;
    uVar4 = func_0x000180229130(0x1801a2d40, 0x1801a2c90);
    *(undefined8 *)((int64_t)&var_18h + iVar3) = 0x180195290;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0ea0;
    iVar5 = func_0x000180229290(uVar4, 0x1801952b0, 0x180195290, 0x1801952b0);
    if (in_RDX == 0) {
        uVar4 = 0xc0102;
        uVar7 = 0x393;
    } else {
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0efd;
            iVar1 = func_0x000180222010(in_RCX);
            iVar6 = 0;
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0f0f;
                    uVar4 = func_0x000180222340(in_RCX, iVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0f1a;
                    func_0x000180228fb0(iVar5, uVar4);
                    iVar6 = iVar6 + 1;
                } while (iVar6 < iVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0f2e;
            uVar2 = func_0x0001801a1130(in_RCX, in_RDX, iVar5);
            goto code_r0x0001801a0f35;
        }
        uVar4 = 0x8000f;
        uVar7 = 0x398;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0ec8;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0edd;
    func_0x0001802295a0(0x1804ad6e8, uVar7, 0x1804ad798);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0eec;
    func_0x0001802296d0(0x14, uVar4, 0);
    uVar2 = 0;
code_r0x0001801a0f35:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a0f3d;
    func_0x000180228ec0(iVar5);
    return uVar2;
}

// ============================================================
// Function: FUN_1801a0f60
// Address: 0x1801a0f60
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 fcn.1801a0f60(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a0f75;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a0f8a;
    uVar3 = fcn.180222270();
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a0f9e;
    uVar1 = fcn.1801a1290(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000038 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a0fab;
    fcn.180222270(in_RCX, uVar3);
    return uVar1;
}

// ============================================================
// Function: FUN_1801a0fc0
// Address: 0x1801a0fc0
// Size: 85 bytes
// ============================================================
int64_t fcn.1801a0fc0(int32_t *param_1)
{
    int64_t iVar1;
    int32_t *piVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a0fcc;
    iVar1 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        piVar2 = param_1;
        if (*param_1 == 0) {
code_r0x0001801a0ff0:
            if (*(int64_t *)(piVar2 + 0x266) != 0) {
                return *(int64_t *)(piVar2 + 0x266);
            }
            return *(int64_t *)(*(int64_t *)(param_1 + 2) + 0x128);
        }
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x1801a0feb;
            piVar2 = (int32_t *)func_0x0001801bda50();
            if (piVar2 != (int32_t *)0x0) goto code_r0x0001801a0ff0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a1020
// Address: 0x1801a1020
// Size: 104 bytes
// ============================================================
int64_t fcn.1801a1020(int32_t *param_1)
{
    int64_t iVar1;
    int32_t *piVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a102c;
    iVar1 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        piVar2 = param_1;
        if (*param_1 == 0) {
code_r0x0001801a1050:
            if (piVar2[0x1e] == 0) {
                return *(int64_t *)(piVar2 + 0xd6);
            }
            if (*(int64_t *)(piVar2 + 0x268) != 0) {
                return *(int64_t *)(piVar2 + 0x268);
            }
            return *(int64_t *)(*(int64_t *)(param_1 + 2) + 0x130);
        }
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x1801a104b;
            piVar2 = (int32_t *)func_0x0001801bda50();
            if (piVar2 != (int32_t *)0x0) goto code_r0x0001801a1050;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a1090
// Address: 0x1801a1090
// Size: 63 bytes
// ============================================================
undefined4 fcn.1801a1090(void)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a109a;
    iVar3 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar3) = 0x1801a10b0;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_20 + -iVar3));
    iVar4 = 0;
    if (iVar1 != 0) {
        iVar4 = *(int32_t *)0x18077e288;
    }
    uVar2 = 0xffffffff;
    if (iVar4 != 0) {
        uVar2 = *(undefined4 *)0x18069c680;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_1801a10d0
// Address: 0x1801a10d0
// Size: 90 bytes
// ============================================================
void fcn.1801a10d0(int64_t arg1, int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 in_RDX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 == 0) {
        return;
    }
    uStack_10 = 0x1801a10e5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int32_t *)arg1 != 0) {
        if (-1 < (char)*(int32_t *)arg1) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a10fd;
        arg1 = func_0x0001801bda50();
        if ((int32_t *)arg1 == (int32_t *)0x0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a1118;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)(arg1 + 0x998) = in_RDX;
    return;
}

// ============================================================
// Function: FUN_1801a1130
// Address: 0x1801a1130
// Size: 342 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801a1130(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a1148;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0;
    uVar5 = 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a1168;
    fcn.18023faa0();
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a1170;
    iVar3 = fcn.18021a7c0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                          *(int64_t *)((int64_t)&arg_40h + iVar2));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a117d;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a1195;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000038 + iVar2));
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a11a7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar2));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a11e8;
        iVar1 = fcn.180219d10(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2));
        if (0 < iVar1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a11ff;
            iVar3 = fcn.1802201c0(*(int64_t *)((int64_t)&var_8h + iVar2));
            while (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a120e;
                iVar3 = fcn.180238460(*(undefined8 *)((int64_t)&arg_40h + iVar2));
                if (iVar3 == 0) goto code_r0x0001801a11a7;
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a121b;
                iVar3 = fcn.1802348d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                                      *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                                      *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2), 
                                      *(int64_t *)(&stack0x00000070 + iVar2), *(int64_t *)(&stack0x00000078 + iVar2), 
                                      *(int64_t *)(&stack0x000000c8 + iVar2), *(int64_t *)(&stack0x000000d0 + iVar2));
                if (iVar3 == 0) goto code_r0x0001801a11a7;
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a122e;
                iVar4 = fcn.180229240(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8));
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a1248;
                    iVar1 = fcn.180222110(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar2), 
                                          *(int64_t *)(&stack0x00000038 + iVar2), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar2));
                    if (iVar1 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a1281;
                        fcn.1802348f0(iVar3);
                        goto code_r0x0001801a11a7;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a1257;
                    fcn.180228fb0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2));
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a123b;
                    fcn.1802348f0(iVar3);
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a126a;
                iVar3 = fcn.1802201c0(*(int64_t *)((int64_t)&var_8h + iVar2));
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a1274;
            fcn.1802203d0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar2));
            goto code_r0x0001801a11aa;
        }
    }
code_r0x0001801a11a7:
    uVar5 = 0;
code_r0x0001801a11aa:
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a11b2;
    fcn.180219f80(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801a11bc;
    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)(&stack0x00000038 + iVar2));
    return uVar5;
}

// ============================================================
// Function: FUN_1801a1290
// Address: 0x1801a1290
// Size: 354 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 fcn.1801a1290(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a12ae;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
    uVar2 = 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a12d7;
    iVar4 = func_0x000180251eb0(in_RDX, 0, 0, 0);
    if (iVar4 == 0) {
code_r0x0001801a13c3:
        uVar2 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a13ce;
        func_0x0001802513b0(iVar5);
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a12eb;
        iVar1 = func_0x0001802518c0(iVar4);
        while (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a12fb;
            iVar1 = func_0x000180251950(iVar4);
            if (iVar1 != 0) break;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a130b;
            iVar5 = func_0x000180251c80(iVar4);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a131f;
                iVar1 = func_0x000180203a00(iVar5);
                if (iVar1 == 1) {
                    if (0 < in_R8D) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a1331;
                        func_0x000180251490(iVar5);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a1340;
                        uVar2 = fcn.1801a1290(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                              *(int64_t *)(&stack0x00000028 + iVar3));
                    }
                } else if (iVar1 == 5) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a1352;
                    iVar6 = func_0x000180251470(iVar5);
                    if (iVar6 == 0) goto code_r0x0001801a13c3;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a135f;
                    iVar6 = fcn.180238460(iVar6);
                    if (iVar6 == 0) goto code_r0x0001801a13c3;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a136c;
                    iVar6 = fcn.1802348d0(*(int64_t *)((int64_t)&var_10h + iVar3), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar3), 
                                          *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3)
                                          , *(int64_t *)(&stack0x00000070 + iVar3), 
                                          *(int64_t *)(&stack0x00000078 + iVar3), *(int64_t *)(&stack0x000000c8 + iVar3)
                                          , *(int64_t *)(&stack0x000000d0 + iVar3));
                    if (iVar6 == 0) goto code_r0x0001801a13c3;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a137f;
                    iVar1 = func_0x000180221a50(in_RCX, iVar6);
                    if (iVar1 < 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a1398;
                        iVar1 = fcn.180222110(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                              *(int64_t *)(&stack0x00000030 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar3));
                        if (iVar1 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a13c3;
                            fcn.1802348f0(iVar6);
                            goto code_r0x0001801a13c3;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a138b;
                        fcn.1802348f0(iVar6);
                    }
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a13a4;
                func_0x0001802513b0(iVar5);
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a13ac;
            iVar1 = func_0x0001802518c0(iVar4);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a13b9;
        fcn.1802203d0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801a13d6;
    func_0x000180251880(iVar4);
    return uVar2;
}

// ============================================================
// Function: FUN_1801a1400
// Address: 0x1801a1400
// Size: 942 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1801a1400(int64_t arg1, int64_t arg2, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_e8h)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    int64_t iVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int32_t iVar16;
    int64_t **ppiVar17;
    int32_t iVar18;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_40;
    int64_t var_18h;
    
    uStack_40 = 0x1801a141f;
    var_8h = arg1;
    var_10h = arg2;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    piVar11 = (int64_t *)0x0;
    iVar13 = 0;
    *(undefined8 *)((int64_t)&arg_70h + iVar10) = 0;
    if (arg1 == 0) {
        ppiVar17 = *(int64_t ***)(arg2 + 0x158);
    } else {
        ppiVar17 = *(int64_t ***)(arg1 + 0x878);
        arg2 = *(int64_t *)(arg1 + 8);
    }
    piVar1 = *ppiVar17;
    *(int64_t **)((int64_t)&var_8h + iVar10) = piVar1;
    iVar6 = 0;
    iVar18 = 0;
    iVar7 = 0;
    *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18) = arg2;
    *(int64_t ***)(&stack0xfffffffffffffff8 + iVar10) = ppiVar17;
    *(uint32_t *)((int64_t)&arg_68h + iVar10) = (uint32_t)in_R8 & 4;
    if (*piVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a147d;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1495;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), *(int64_t *)((int64_t)aiStackX_18 + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a14a7;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar10));
        iVar7 = iVar6;
code_r0x0001801a1782:
        iVar6 = iVar7;
        if (*(int32_t *)((int64_t)&arg_68h + iVar10) == 0) goto code_r0x0001801a1794;
    } else {
        if ((in_R8 & 4) == 0) {
            piVar11 = ppiVar17[0xe];
            if (piVar11 == (int64_t *)0x0) {
                piVar11 = *(int64_t **)(arg2 + 0x28);
            }
            if ((in_R8 & 1) != 0) {
                *(int64_t *)((int64_t)&arg_70h + iVar10) = piVar1[2];
            }
code_r0x0001801a1536:
            puVar2 = *(undefined8 **)((int64_t)aiStackX_18 + iVar10 + -0x18);
            uVar12 = puVar2[0x8c];
            uVar3 = *puVar2;
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a154a;
            iVar13 = func_0x00018024c080(uVar3, uVar12);
            if (iVar13 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1557;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10))
                ;
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a156f;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10)
                              , *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar10));
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1581;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar10));
                iVar7 = iVar6;
            } else {
                iVar14 = *piVar1;
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a159c;
                iVar5 = func_0x00018024bbe0(iVar13, piVar11, iVar14, *(undefined8 *)((int64_t)&arg_70h + iVar10));
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a15a5;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a15bd;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a15cf;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar10));
                    iVar7 = iVar6;
                } else {
                    uVar8 = *(uint32_t *)((int64_t)ppiVar17 + 0x1c);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a15e5;
                    func_0x00018024c330(iVar13, uVar8 & 0x30000);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a15ed;
                    iVar6 = func_0x00018024c740(iVar13);
                    if (iVar6 < 1) {
                        if ((in_R8 & 8) == 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a16f2;
                            uVar9 = func_0x00018024bbd0(iVar13);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a16f9;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1711;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar10));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1718;
                            func_0x000180250ec0(uVar9);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1731;
                            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar10));
                            goto code_r0x0001801a1782;
                        }
                        if ((in_R8 & 0x10) != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1606;
                            fcn.1802203d0(*(int64_t *)((int64_t)&var_18h + iVar10), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar10));
                        }
                        iVar18 = 2;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1613;
                    iVar14 = func_0x00018024b970(iVar13);
                    *(int64_t *)((int64_t)&arg_70h + iVar10) = iVar14;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1626;
                    func_0x0001802222a0(iVar14);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a162e;
                    fcn.18021fe80(*(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar10));
                    if ((in_R8 & 2) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a163c;
                        iVar7 = func_0x000180222010(iVar14);
                        if (0 < iVar7) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1648;
                            iVar7 = func_0x000180222010(iVar14);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1653;
                            uVar12 = func_0x000180222340(iVar14, iVar7 + -1);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a165b;
                            uVar8 = func_0x00018023bbb0(uVar12);
                            if ((uVar8 >> 0xd & 1) != 0) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1669;
                                func_0x000180222020(iVar14);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1671;
                                fcn.18021fe80(*(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar10));
                            }
                        }
                    }
                    iVar6 = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a167b;
                    iVar7 = func_0x000180222010(iVar14);
                    if (iVar7 < 1) {
                        iVar4 = piVar1[2];
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1774;
                        func_0x000180238640(iVar4);
                        piVar1[2] = iVar14;
                        iVar7 = iVar18;
                        if (iVar18 == 0) {
                            iVar7 = 1;
                        }
                    } else {
                        uVar12 = *(undefined8 *)(&stack0x00000058 + iVar10);
                        uVar3 = *(undefined8 *)((int64_t)&arg_60h + iVar10);
                        do {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a169d;
                            uVar15 = func_0x000180222340(iVar14, iVar6);
                            *(undefined4 *)((int64_t)&var_18h + iVar10) = 0;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a16b6;
                            iVar7 = func_0x0001801a8d20(uVar12, uVar3, uVar15, 0);
                            if (iVar7 != 1) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1738;
                                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1750;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar10));
                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a175f;
                                fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar10));
                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1767;
                                func_0x000180238640(iVar14);
                                iVar7 = 0;
                                goto code_r0x0001801a1782;
                            }
                            iVar6 = iVar6 + 1;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a16c7;
                            iVar7 = func_0x000180222010(iVar14);
                        } while (iVar6 < iVar7);
                        iVar14 = *(int64_t *)((int64_t)&var_8h + iVar10);
                        uVar12 = *(undefined8 *)(iVar14 + 0x10);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a16d9;
                        func_0x000180238640(uVar12);
                        *(undefined8 *)(iVar14 + 0x10) = *(undefined8 *)((int64_t)&arg_70h + iVar10);
                        iVar7 = 1;
                    }
                }
            }
            goto code_r0x0001801a1782;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a14b5;
        piVar11 = (int64_t *)func_0x00018021f3d0();
        if (piVar11 != (int64_t *)0x0) {
            iVar14 = piVar1[2];
            iVar16 = 0;
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a14cc;
            iVar5 = func_0x000180222010(iVar14);
            if (0 < iVar5) {
                do {
                    iVar14 = piVar1[2];
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a14db;
                    uVar12 = func_0x000180222340(iVar14, iVar16);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a14e6;
                    iVar5 = func_0x00018021f070(piVar11, uVar12);
                    if (iVar5 == 0) goto code_r0x0001801a178c;
                    iVar14 = piVar1[2];
                    iVar16 = iVar16 + 1;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a14f9;
                    iVar5 = func_0x000180222010(iVar14);
                } while (iVar16 < iVar5);
            }
            iVar14 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1508;
            iVar5 = func_0x00018021f070(piVar11, iVar14);
            if (iVar5 != 0) {
                ppiVar17 = *(int64_t ***)(&stack0xfffffffffffffff8 + iVar10);
                goto code_r0x0001801a1536;
            }
        }
    }
code_r0x0001801a178c:
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a1794;
    func_0x00018021f290(piVar11);
code_r0x0001801a1794:
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a179c;
    func_0x00018024b910(iVar13);
    return iVar6;
}

// ============================================================
// Function: FUN_1801a17b0
// Address: 0x1801a17b0
// Size: 193 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801a17b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t *piVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a17c0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        piVar5 = *(int64_t **)(in_RDX + 0x158);
    } else {
        piVar5 = *(int64_t **)(in_RCX + 0x878);
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RDI;
    iVar1 = *piVar5;
    if (iVar1 != 0) {
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a17fb;
        iVar2 = func_0x0001801a8d20();
        if (iVar2 == 1) {
            if (*(int64_t *)(iVar1 + 0x10) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a1853;
                iVar4 = func_0x000180221f20();
                *(int64_t *)(iVar1 + 0x10) = iVar4;
                if (iVar4 == 0) {
                    return false;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a1867;
            iVar2 = fcn.180222110(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
            return iVar2 != 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a1807;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a181f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a182e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    }
    return false;
}

// ============================================================
// Function: FUN_1801a1880
// Address: 0x1801a1880
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801a1880(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_158h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t *piVar6;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a1895;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a18a9;
    uVar4 = fcn.1802375f0(in_R8);
    if ((int32_t)uVar4 == 0) {
        return uVar4;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    if (in_RCX == 0) {
        piVar6 = *(int64_t **)(in_RDX + 0x158);
    } else {
        piVar6 = *(int64_t **)(in_RCX + 0x878);
    }
    iVar1 = *piVar6;
    if (iVar1 != 0) {
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a18f8;
        iVar2 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3), 
                              *(int64_t *)(&stack0x000000c8 + iVar3));
        if (iVar2 == 1) {
            if (*(int64_t *)(iVar1 + 0x10) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a1958;
                iVar5 = fcn.180221f20();
                *(int64_t *)(iVar1 + 0x10) = iVar5;
                if (iVar5 == 0) goto code_r0x0001801a192b;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a196c;
            iVar2 = fcn.180222110(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
            if (iVar2 != 0) {
                return 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a1904;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a191c;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a192b;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        }
    }
code_r0x0001801a192b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a1933;
    fcn.18021fe80(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801a18bd
// Address: 0x1801a18bd
// Size: 141 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801a1880(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_158h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t *piVar6;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a1895;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a18a9;
    uVar4 = fcn.1802375f0(in_R8);
    if ((int32_t)uVar4 == 0) {
        return uVar4;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    if (in_RCX == 0) {
        piVar6 = *(int64_t **)(in_RDX + 0x158);
    } else {
        piVar6 = *(int64_t **)(in_RCX + 0x878);
    }
    iVar1 = *piVar6;
    if (iVar1 != 0) {
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a18f8;
        iVar2 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3), 
                              *(int64_t *)(&stack0x000000c8 + iVar3));
        if (iVar2 == 1) {
            if (*(int64_t *)(iVar1 + 0x10) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a1958;
                iVar5 = fcn.180221f20();
                *(int64_t *)(iVar1 + 0x10) = iVar5;
                if (iVar5 == 0) goto code_r0x0001801a192b;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a196c;
            iVar2 = fcn.180222110(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
            if (iVar2 != 0) {
                return 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a1904;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a191c;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a192b;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        }
    }
code_r0x0001801a192b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a1933;
    fcn.18021fe80(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801a194a
// Address: 0x1801a194a
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801a1880(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_158h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t *piVar6;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a1895;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a18a9;
    uVar4 = fcn.1802375f0(in_R8);
    if ((int32_t)uVar4 == 0) {
        return uVar4;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    if (in_RCX == 0) {
        piVar6 = *(int64_t **)(in_RDX + 0x158);
    } else {
        piVar6 = *(int64_t **)(in_RCX + 0x878);
    }
    iVar1 = *piVar6;
    if (iVar1 != 0) {
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a18f8;
        iVar2 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3), 
                              *(int64_t *)(&stack0x000000c8 + iVar3));
        if (iVar2 == 1) {
            if (*(int64_t *)(iVar1 + 0x10) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a1958;
                iVar5 = fcn.180221f20();
                *(int64_t *)(iVar1 + 0x10) = iVar5;
                if (iVar5 == 0) goto code_r0x0001801a192b;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a196c;
            iVar2 = fcn.180222110(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
            if (iVar2 != 0) {
                return 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a1904;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a191c;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a192b;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        }
    }
code_r0x0001801a192b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a1933;
    fcn.18021fe80(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801a1980
// Address: 0x1801a1980
// Size: 1214 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t * fcn.1801a1980(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *puVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a19a4;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a19c1;
    piVar5 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_8h + iVar4));
    if (piVar5 == (int64_t *)0x0) {
        return (int64_t *)0x0;
    }
    piVar5[5] = in_RCX[5];
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a19ec;
    iVar6 = fcn.180224e40(*(int64_t *)((int64_t)&var_8h + iVar4));
    piVar5[4] = iVar6;
    if (iVar6 == 0) {
        uVar11 = 0x6e;
        goto code_r0x0001801a1cbc;
    }
    uVar10 = 0;
    *piVar5 = iVar6 + ((*in_RCX - in_RCX[4]) / 0x28) * 0x28;
    *(undefined4 *)(piVar5 + 0x16) = 1;
    if (in_RCX[1] == 0) {
code_r0x0001801a1a5b:
        piVar5[2] = in_RCX[2];
        *(undefined4 *)(piVar5 + 3) = *(undefined4 *)(in_RCX + 3);
        uVar8 = uVar10;
        uVar13 = uVar10;
        if (piVar5[5] != 0) {
            do {
                piVar9 = (int64_t *)(in_RCX[4] + uVar13);
                piVar12 = (int64_t *)(piVar5[4] + uVar13);
                if (*piVar9 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1a9b;
                    iVar3 = fcn.1802375f0();
                    if (iVar3 == 0) goto code_r0x0001801a1ba4;
                    *piVar12 = *piVar9;
                }
                if (piVar9[1] != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1ab7;
                    iVar3 = func_0x0001802308d0();
                    if (iVar3 == 0) goto code_r0x0001801a1ba4;
                    piVar12[1] = piVar9[1];
                }
                if (piVar9[2] != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1ad5;
                    iVar6 = func_0x000180238060();
                    piVar12[2] = iVar6;
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1b7a;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1b92;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1ba4;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                        goto code_r0x0001801a1ba4;
                    }
                }
                iVar6 = piVar9[3];
                if (iVar6 != 0) {
                    iVar1 = piVar9[4];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1b01;
                    iVar6 = func_0x000180223170(iVar6, iVar1, 0x1804ad6e8, 0x9b);
                    piVar12[3] = iVar6;
                    if (iVar6 == 0) goto code_r0x0001801a1ba4;
                    piVar12[4] = piVar9[4];
                }
                uVar8 = uVar8 + 1;
                uVar13 = uVar13 + 0x28;
            } while (uVar8 < (uint64_t)piVar5[5]);
        }
        if (in_RCX[8] == 0) {
            piVar5[8] = 0;
        } else {
            iVar6 = in_RCX[9];
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1b4c;
            iVar6 = func_0x000180224ed0(iVar6, 2, 0x1804ad6e8, 0xae);
            piVar5[8] = iVar6;
            if (iVar6 == 0) goto code_r0x0001801a1ba4;
            iVar1 = in_RCX[9];
            iVar2 = in_RCX[8];
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1b68;
            fcn.180498030(iVar6, iVar2, iVar1 * 2);
            piVar5[9] = in_RCX[9];
        }
        if (in_RCX[10] == 0) {
            piVar5[10] = 0;
        } else {
            iVar6 = in_RCX[0xb];
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1d11;
            iVar6 = func_0x000180224ed0(iVar6, 2, 0x1804ad6e8, 0xba);
            piVar5[10] = iVar6;
            if (iVar6 == 0) goto code_r0x0001801a1ba4;
            iVar1 = in_RCX[0xb];
            iVar2 = in_RCX[10];
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1d31;
            fcn.180498030(iVar6, iVar2, iVar1 * 2);
            piVar5[0xb] = in_RCX[0xb];
        }
        iVar6 = in_RCX[6];
        if (iVar6 != 0) {
            iVar1 = in_RCX[7];
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1d5e;
            iVar6 = func_0x000180223170(iVar6, iVar1, 0x1804ad6e8, 0xc4);
            piVar5[6] = iVar6;
            if (iVar6 == 0) goto code_r0x0001801a1ba4;
            piVar5[7] = in_RCX[7];
        }
        *(undefined4 *)((int64_t)piVar5 + 0x1c) = *(undefined4 *)((int64_t)in_RCX + 0x1c);
        piVar5[0xc] = in_RCX[0xc];
        piVar5[0xd] = in_RCX[0xd];
        if (in_RCX[0xf] != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1d97;
            iVar3 = func_0x00018021f5b0();
            if (iVar3 == 0) goto code_r0x0001801a1ba4;
            piVar5[0xf] = in_RCX[0xf];
        }
        if (in_RCX[0xe] != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1db5;
            iVar3 = func_0x00018021f5b0();
            if (iVar3 == 0) goto code_r0x0001801a1ba4;
            piVar5[0xe] = in_RCX[0xe];
        }
        piVar5[0x12] = in_RCX[0x12];
        *(undefined4 *)(piVar5 + 0x13) = *(undefined4 *)(in_RCX + 0x13);
        piVar5[0x14] = in_RCX[0x14];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1e00;
        iVar3 = func_0x00018019adf0(piVar5 + 0x10, in_RCX + 0x10);
        if (iVar3 != 0) {
            iVar6 = in_RCX[0x15];
            if (iVar6 == 0) {
                return piVar5;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1e26;
            iVar6 = func_0x0001802231e0(iVar6, 0x1804ad6e8, 0xe3);
            piVar5[0x15] = iVar6;
            if (iVar6 != 0) {
                return piVar5;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1a4b;
        iVar3 = func_0x0001802308d0();
        if (iVar3 != 0) {
            piVar5[1] = in_RCX[1];
            goto code_r0x0001801a1a5b;
        }
    }
code_r0x0001801a1ba4:
    LOCK();
    piVar9 = piVar5 + 0x16;
    iVar3 = *(int32_t *)piVar9;
    *(int32_t *)piVar9 = *(int32_t *)piVar9 + -1;
    UNLOCK();
    if (1 < iVar3) {
        return (int64_t *)0x0;
    }
    iVar6 = piVar5[1];
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1bc3;
    func_0x00018022ecc0(iVar6);
    uVar8 = uVar10;
    if (piVar5[5] != 0) {
        do {
            puVar7 = (undefined8 *)(piVar5[4] + uVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1bdf;
            fcn.18021fe80(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
            uVar11 = puVar7[1];
            *puVar7 = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1beb;
            func_0x00018022ecc0(uVar11);
            uVar11 = puVar7[2];
            puVar7[1] = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1bf8;
            func_0x000180238640(uVar11);
            uVar11 = puVar7[3];
            puVar7[2] = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1c12;
            fcn.180224990(uVar11, 0x1804ad6e8, 0x103);
            uVar10 = uVar10 + 1;
            puVar7[3] = 0;
            puVar7[4] = 0;
            uVar8 = uVar8 + 0x28;
        } while (uVar10 < (uint64_t)piVar5[5]);
    }
    iVar6 = piVar5[8];
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1c3d;
    fcn.180224990(iVar6, 0x1804ad6e8, 0x11f);
    iVar6 = piVar5[10];
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1c53;
    fcn.180224990(iVar6, 0x1804ad6e8, 0x120);
    iVar6 = piVar5[6];
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1c69;
    fcn.180224990(iVar6, 0x1804ad6e8, 0x121);
    iVar6 = piVar5[0xf];
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1c72;
    func_0x00018021f290(iVar6);
    iVar6 = piVar5[0xe];
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1c7b;
    func_0x00018021f290(iVar6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1c87;
    func_0x00018019af50(piVar5 + 0x10);
    iVar6 = piVar5[0x15];
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1ca0;
    fcn.180224990(iVar6, 0x1804ad6e8, 0x126);
    iVar6 = piVar5[4];
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1cb6;
    fcn.180224990(iVar6, 0x1804ad6e8, 0x128);
    uVar11 = 0x12a;
code_r0x0001801a1cbc:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a1ccb;
    fcn.180224990(piVar5, 0x1804ad6e8, uVar11);
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_1801a1e40
// Address: 0x1801a1e40
// Size: 52 bytes
// ============================================================
void fcn.1801a1e40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    undefined8 unaff_RSI;
    uint64_t uVar6;
    undefined8 unaff_RDI;
    undefined8 *puVar7;
    undefined8 unaff_R14;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801a1e54;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0xb0);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1e83;
            fcn.18022ecc0(uVar3);
            uVar5 = 0;
            if (*(int64_t *)(arg1 + 0x28) != 0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
                *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
                uVar6 = uVar5;
                do {
                    puVar7 = (undefined8 *)(*(int64_t *)(arg1 + 0x20) + uVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1eaf;
                    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000048 + iVar4)
                                 );
                    uVar3 = puVar7[1];
                    *puVar7 = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ebb;
                    fcn.18022ecc0(uVar3);
                    uVar3 = puVar7[2];
                    puVar7[1] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ec8;
                    fcn.180238640(uVar3);
                    uVar3 = puVar7[3];
                    puVar7[2] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ee2;
                    fcn.180224990(uVar3, 0x1804ad6e8, 0x103);
                    uVar5 = uVar5 + 1;
                    puVar7[3] = 0;
                    uVar6 = uVar6 + 0x28;
                    puVar7[4] = 0;
                } while (uVar5 < *(uint64_t *)(arg1 + 0x28));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x40);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f17;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x11f);
            uVar3 = *(undefined8 *)(arg1 + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f2d;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x120);
            uVar3 = *(undefined8 *)(arg1 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f43;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x121);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f4c;
            fcn.18021f290(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f55;
            fcn.18021f290(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f61;
            fcn.18019af50(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
            uVar3 = *(undefined8 *)(arg1 + 0xa8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f7a;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x126);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f90;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x128);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1fa5;
            fcn.180224990(arg1, 0x1804ad6e8, 0x12a);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801a1e74
// Address: 0x1801a1e74
// Size: 27 bytes
// ============================================================
void fcn.1801a1e40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    undefined8 unaff_RSI;
    uint64_t uVar6;
    undefined8 unaff_RDI;
    undefined8 *puVar7;
    undefined8 unaff_R14;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801a1e54;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0xb0);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1e83;
            fcn.18022ecc0(uVar3);
            uVar5 = 0;
            if (*(int64_t *)(arg1 + 0x28) != 0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
                *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
                uVar6 = uVar5;
                do {
                    puVar7 = (undefined8 *)(*(int64_t *)(arg1 + 0x20) + uVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1eaf;
                    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000048 + iVar4)
                                 );
                    uVar3 = puVar7[1];
                    *puVar7 = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ebb;
                    fcn.18022ecc0(uVar3);
                    uVar3 = puVar7[2];
                    puVar7[1] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ec8;
                    fcn.180238640(uVar3);
                    uVar3 = puVar7[3];
                    puVar7[2] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ee2;
                    fcn.180224990(uVar3, 0x1804ad6e8, 0x103);
                    uVar5 = uVar5 + 1;
                    puVar7[3] = 0;
                    uVar6 = uVar6 + 0x28;
                    puVar7[4] = 0;
                } while (uVar5 < *(uint64_t *)(arg1 + 0x28));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x40);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f17;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x11f);
            uVar3 = *(undefined8 *)(arg1 + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f2d;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x120);
            uVar3 = *(undefined8 *)(arg1 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f43;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x121);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f4c;
            fcn.18021f290(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f55;
            fcn.18021f290(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f61;
            fcn.18019af50(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
            uVar3 = *(undefined8 *)(arg1 + 0xa8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f7a;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x126);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f90;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x128);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1fa5;
            fcn.180224990(arg1, 0x1804ad6e8, 0x12a);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801a1e8f
// Address: 0x1801a1e8f
// Size: 114 bytes
// ============================================================
void fcn.1801a1e40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    undefined8 unaff_RSI;
    uint64_t uVar6;
    undefined8 unaff_RDI;
    undefined8 *puVar7;
    undefined8 unaff_R14;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801a1e54;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0xb0);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1e83;
            fcn.18022ecc0(uVar3);
            uVar5 = 0;
            if (*(int64_t *)(arg1 + 0x28) != 0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
                *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
                uVar6 = uVar5;
                do {
                    puVar7 = (undefined8 *)(*(int64_t *)(arg1 + 0x20) + uVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1eaf;
                    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000048 + iVar4)
                                 );
                    uVar3 = puVar7[1];
                    *puVar7 = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ebb;
                    fcn.18022ecc0(uVar3);
                    uVar3 = puVar7[2];
                    puVar7[1] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ec8;
                    fcn.180238640(uVar3);
                    uVar3 = puVar7[3];
                    puVar7[2] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ee2;
                    fcn.180224990(uVar3, 0x1804ad6e8, 0x103);
                    uVar5 = uVar5 + 1;
                    puVar7[3] = 0;
                    uVar6 = uVar6 + 0x28;
                    puVar7[4] = 0;
                } while (uVar5 < *(uint64_t *)(arg1 + 0x28));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x40);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f17;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x11f);
            uVar3 = *(undefined8 *)(arg1 + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f2d;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x120);
            uVar3 = *(undefined8 *)(arg1 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f43;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x121);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f4c;
            fcn.18021f290(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f55;
            fcn.18021f290(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f61;
            fcn.18019af50(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
            uVar3 = *(undefined8 *)(arg1 + 0xa8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f7a;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x126);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f90;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x128);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1fa5;
            fcn.180224990(arg1, 0x1804ad6e8, 0x12a);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801a1f01
// Address: 0x1801a1f01
// Size: 174 bytes
// ============================================================
void fcn.1801a1e40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    undefined8 unaff_RSI;
    uint64_t uVar6;
    undefined8 unaff_RDI;
    undefined8 *puVar7;
    undefined8 unaff_R14;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801a1e54;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0xb0);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1e83;
            fcn.18022ecc0(uVar3);
            uVar5 = 0;
            if (*(int64_t *)(arg1 + 0x28) != 0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
                *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
                uVar6 = uVar5;
                do {
                    puVar7 = (undefined8 *)(*(int64_t *)(arg1 + 0x20) + uVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1eaf;
                    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000048 + iVar4)
                                 );
                    uVar3 = puVar7[1];
                    *puVar7 = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ebb;
                    fcn.18022ecc0(uVar3);
                    uVar3 = puVar7[2];
                    puVar7[1] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ec8;
                    fcn.180238640(uVar3);
                    uVar3 = puVar7[3];
                    puVar7[2] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ee2;
                    fcn.180224990(uVar3, 0x1804ad6e8, 0x103);
                    uVar5 = uVar5 + 1;
                    puVar7[3] = 0;
                    uVar6 = uVar6 + 0x28;
                    puVar7[4] = 0;
                } while (uVar5 < *(uint64_t *)(arg1 + 0x28));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x40);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f17;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x11f);
            uVar3 = *(undefined8 *)(arg1 + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f2d;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x120);
            uVar3 = *(undefined8 *)(arg1 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f43;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x121);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f4c;
            fcn.18021f290(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f55;
            fcn.18021f290(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f61;
            fcn.18019af50(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
            uVar3 = *(undefined8 *)(arg1 + 0xa8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f7a;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x126);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f90;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x128);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1fa5;
            fcn.180224990(arg1, 0x1804ad6e8, 0x12a);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801a1faf
// Address: 0x1801a1faf
// Size: 6 bytes
// ============================================================
void fcn.1801a1e40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    undefined8 unaff_RSI;
    uint64_t uVar6;
    undefined8 unaff_RDI;
    undefined8 *puVar7;
    undefined8 unaff_R14;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801a1e54;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0xb0);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1e83;
            fcn.18022ecc0(uVar3);
            uVar5 = 0;
            if (*(int64_t *)(arg1 + 0x28) != 0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
                *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
                uVar6 = uVar5;
                do {
                    puVar7 = (undefined8 *)(*(int64_t *)(arg1 + 0x20) + uVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1eaf;
                    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000048 + iVar4)
                                 );
                    uVar3 = puVar7[1];
                    *puVar7 = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ebb;
                    fcn.18022ecc0(uVar3);
                    uVar3 = puVar7[2];
                    puVar7[1] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ec8;
                    fcn.180238640(uVar3);
                    uVar3 = puVar7[3];
                    puVar7[2] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1ee2;
                    fcn.180224990(uVar3, 0x1804ad6e8, 0x103);
                    uVar5 = uVar5 + 1;
                    puVar7[3] = 0;
                    uVar6 = uVar6 + 0x28;
                    puVar7[4] = 0;
                } while (uVar5 < *(uint64_t *)(arg1 + 0x28));
            }
            uVar3 = *(undefined8 *)(arg1 + 0x40);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f17;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x11f);
            uVar3 = *(undefined8 *)(arg1 + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f2d;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x120);
            uVar3 = *(undefined8 *)(arg1 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f43;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x121);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f4c;
            fcn.18021f290(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f55;
            fcn.18021f290(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f61;
            fcn.18019af50(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
            uVar3 = *(undefined8 *)(arg1 + 0xa8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f7a;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x126);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1f90;
            fcn.180224990(uVar3, 0x1804ad6e8, 0x128);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a1fa5;
            fcn.180224990(arg1, 0x1804ad6e8, 0x12a);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801a2080
// Address: 0x1801a2080
// Size: 261 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 * fcn.1801a2080(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 in_RCX;
    uint64_t *in_RDX;
    undefined4 *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a209e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    puVar6 = (undefined4 *)0x1804ad670;
    uVar7 = uVar8;
    do {
        uVar1 = *puVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a20bc;
        uVar5 = func_0x00018022ccf0(uVar1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a20c7;
        iVar3 = func_0x00018022fc40(in_RCX, uVar5);
        if (iVar3 != 0) {
code_r0x0001801a2161:
            if (in_RDX == (uint64_t *)0x0) {
                return puVar6;
            }
            *in_RDX = uVar7;
            return puVar6;
        }
        uVar1 = *puVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a20d6;
        uVar5 = func_0x00018022cb70(uVar1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a20e1;
        iVar3 = func_0x00018022fc40(in_RCX, uVar5);
        if (iVar3 != 0) goto code_r0x0001801a2161;
        uVar7 = uVar7 + 1;
        puVar6 = puVar6 + 2;
    } while (uVar7 < 9);
    if (*(int64_t *)(in_R8 + 0x680) != 0) {
        do {
            iVar2 = *(int64_t *)(in_R8 + 0x160);
            uVar1 = *(undefined4 *)(iVar2 + uVar8 * 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a2113;
            uVar5 = func_0x00018022ccf0(uVar1);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a211e;
            iVar3 = func_0x00018022fc40(in_RCX, uVar5);
            if (iVar3 != 0) {
code_r0x0001801a2148:
                if (in_RDX != (uint64_t *)0x0) {
                    *in_RDX = uVar8 + 9;
                }
                return (undefined4 *)(*(int64_t *)(in_R8 + 0x160) + uVar8 * 8);
            }
            uVar1 = *(undefined4 *)(iVar2 + uVar8 * 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a2129;
            uVar5 = func_0x00018022cb70(uVar1);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a2134;
            iVar3 = func_0x00018022fc40(in_RCX, uVar5);
            if (iVar3 != 0) goto code_r0x0001801a2148;
            uVar8 = uVar8 + 1;
        } while (uVar8 < *(uint64_t *)(in_R8 + 0x680));
    }
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_1801a2190
// Address: 0x1801a2190
// Size: 194 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.1801a2190(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    uint64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a21a0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (8 < in_RCX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a21c3;
        piVar2 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        if (piVar2 != (int64_t *)0x0) {
            piVar2[5] = in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a21e9;
            iVar3 = fcn.180224e40(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
            piVar2[4] = iVar3;
            if (iVar3 != 0) {
                *piVar2 = iVar3;
                piVar2[0x12] = 0x1801a26e0;
                *(undefined4 *)(piVar2 + 0x13) = 2;
                piVar2[0x14] = 0;
                *(undefined4 *)(piVar2 + 0x16) = 1;
                return piVar2;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a2207;
            fcn.180224990(piVar2, 0x1804ad6e8, 0x4f);
        }
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_1801a2260
// Address: 0x1801a2260
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801a2260(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t **in_RCX;
    int64_t *piVar4;
    int64_t in_RDX;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a2280;
    iVar3 = fcn.18045a350();
    if (in_RDX != 0) {
        piVar5 = (int64_t *)0x0;
        if (in_RCX[5] != (int64_t *)0x0) {
            piVar6 = in_RCX[4];
            piVar4 = piVar5;
            do {
                if ((*piVar6 == in_RDX) && (piVar6[1] != 0)) {
                    *in_RCX = piVar6;
                    return 1;
                }
                piVar4 = (int64_t *)((int64_t)piVar4 + 1);
                piVar6 = piVar6 + 5;
                piVar7 = piVar5;
            } while (piVar4 < in_RCX[5]);
            do {
                piVar6 = (int64_t *)((int64_t)in_RCX[4] + (int64_t)piVar7);
                if ((piVar6[1] != 0) && (iVar1 = *piVar6, iVar1 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 - iVar3) = 0x1801a22de;
                    iVar2 = func_0x000180238200(iVar1, in_RDX);
                    if (iVar2 == 0) {
                        *in_RCX = piVar6;
                        return 1;
                    }
                }
                piVar5 = (int64_t *)((int64_t)piVar5 + 1);
                piVar7 = piVar7 + 5;
            } while (piVar5 < in_RCX[5]);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a2320
// Address: 0x1801a2320
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801a2320(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a2333;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        piVar5 = *(int64_t **)(in_RDX + 0x158);
    } else {
        piVar5 = *(int64_t **)(in_RCX + 0x878);
    }
    iVar1 = *piVar5;
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R12;
        iVar6 = 0;
        *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a2389;
        iVar3 = func_0x000180222010(in_R8);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a239a;
                func_0x000180222340(in_R8, iVar6);
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a23b0;
                iVar3 = fcn.1801a8d20(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                      *(int64_t *)(&stack0x000000b8 + iVar4));
                if (iVar3 != 1) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a23fa;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a2412;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a2422;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
                    return 0;
                }
                iVar6 = iVar6 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a23c2;
                iVar3 = func_0x000180222010(in_R8);
            } while (iVar6 < iVar3);
        }
        uVar2 = *(undefined8 *)(iVar1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a23cf;
        fcn.180238640(uVar2);
        *(undefined8 *)(iVar1 + 0x10) = in_R8;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a236c
// Address: 0x1801a236c
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801a2320(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a2333;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        piVar5 = *(int64_t **)(in_RDX + 0x158);
    } else {
        piVar5 = *(int64_t **)(in_RCX + 0x878);
    }
    iVar1 = *piVar5;
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R12;
        iVar6 = 0;
        *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a2389;
        iVar3 = func_0x000180222010(in_R8);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a239a;
                func_0x000180222340(in_R8, iVar6);
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a23b0;
                iVar3 = fcn.1801a8d20(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                      *(int64_t *)(&stack0x000000b8 + iVar4));
                if (iVar3 != 1) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a23fa;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a2412;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a2422;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
                    return 0;
                }
                iVar6 = iVar6 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a23c2;
                iVar3 = func_0x000180222010(in_R8);
            } while (iVar6 < iVar3);
        }
        uVar2 = *(undefined8 *)(iVar1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a23cf;
        fcn.180238640(uVar2);
        *(undefined8 *)(iVar1 + 0x10) = in_R8;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a23f5
// Address: 0x1801a23f5
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801a2320(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a2333;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        piVar5 = *(int64_t **)(in_RDX + 0x158);
    } else {
        piVar5 = *(int64_t **)(in_RCX + 0x878);
    }
    iVar1 = *piVar5;
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R12;
        iVar6 = 0;
        *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a2389;
        iVar3 = func_0x000180222010(in_R8);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a239a;
                func_0x000180222340(in_R8, iVar6);
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a23b0;
                iVar3 = fcn.1801a8d20(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                      *(int64_t *)(&stack0x000000b8 + iVar4));
                if (iVar3 != 1) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a23fa;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a2412;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_18 + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a2422;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
                    return 0;
                }
                iVar6 = iVar6 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a23c2;
                iVar3 = func_0x000180222010(in_R8);
            } while (iVar6 < iVar3);
        }
        uVar2 = *(undefined8 *)(iVar1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801a23cf;
        fcn.180238640(uVar2);
        *(undefined8 *)(iVar1 + 0x10) = in_R8;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a2430
// Address: 0x1801a2430
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801a2430(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a2440;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a246a;
        iVar3 = func_0x000180238060(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a2480;
            iVar2 = fcn.1801a2320(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
            if (iVar2 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a248c;
            fcn.180238640(iVar3);
        }
        return 0;
    }
    uVar7 = *(undefined8 *)((int64_t)auStackX_18 + iVar5);
    *(undefined8 *)(&stack0x00000040 + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = *(undefined8 *)((int64_t)&arg_30h + iVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + -8) = uVar7;
    *(undefined8 *)(&stack0x00000008 + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + -0x18) = 0x1801a2333;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        piVar4 = *(int64_t **)(in_RDX + 0x158);
    } else {
        piVar4 = *(int64_t **)(in_RCX + 0x878);
    }
    iVar1 = *piVar4;
    if (iVar1 != 0) {
        *(undefined8 *)(&stack0x00000058 + iVar3 + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_60h + iVar3 + iVar5) = unaff_R12;
        iVar6 = 0;
        *(undefined8 *)(&stack0x00000068 + iVar3 + iVar5) = unaff_R14;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a2389;
        iVar2 = func_0x000180222010(in_R8);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a239a;
                func_0x000180222340(in_R8, iVar6);
                *(undefined4 *)((int64_t)&arg_28h + iVar3 + iVar5) = 0;
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a23b0;
                iVar2 = fcn.1801a8d20(*(int64_t *)(&stack0x00000048 + iVar3 + iVar5), 
                                      *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar5), 
                                      *(int64_t *)(&stack0x00000068 + iVar3 + iVar5), 
                                      *(int64_t *)(&stack0x000000d8 + iVar3 + iVar5));
                if (iVar2 != 1) {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a23fa;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar3 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar5));
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a2412;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar3 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar3 + iVar5));
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a2422;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar5));
                    return 0;
                }
                iVar6 = iVar6 + 1;
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a23c2;
                iVar2 = func_0x000180222010(in_R8);
            } while (iVar6 < iVar2);
        }
        uVar7 = *(undefined8 *)(iVar1 + 0x10);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a23cf;
        fcn.180238640(uVar7);
        *(int64_t *)(iVar1 + 0x10) = in_R8;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a2460
// Address: 0x1801a2460
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801a2430(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a2440;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a246a;
        iVar3 = func_0x000180238060(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a2480;
            iVar2 = fcn.1801a2320(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
            if (iVar2 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a248c;
            fcn.180238640(iVar3);
        }
        return 0;
    }
    uVar7 = *(undefined8 *)((int64_t)auStackX_18 + iVar5);
    *(undefined8 *)(&stack0x00000040 + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = *(undefined8 *)((int64_t)&arg_30h + iVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + -8) = uVar7;
    *(undefined8 *)(&stack0x00000008 + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + -0x18) = 0x1801a2333;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        piVar4 = *(int64_t **)(in_RDX + 0x158);
    } else {
        piVar4 = *(int64_t **)(in_RCX + 0x878);
    }
    iVar1 = *piVar4;
    if (iVar1 != 0) {
        *(undefined8 *)(&stack0x00000058 + iVar3 + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_60h + iVar3 + iVar5) = unaff_R12;
        iVar6 = 0;
        *(undefined8 *)(&stack0x00000068 + iVar3 + iVar5) = unaff_R14;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a2389;
        iVar2 = func_0x000180222010(in_R8);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a239a;
                func_0x000180222340(in_R8, iVar6);
                *(undefined4 *)((int64_t)&arg_28h + iVar3 + iVar5) = 0;
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a23b0;
                iVar2 = fcn.1801a8d20(*(int64_t *)(&stack0x00000048 + iVar3 + iVar5), 
                                      *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar5), 
                                      *(int64_t *)(&stack0x00000068 + iVar3 + iVar5), 
                                      *(int64_t *)(&stack0x000000d8 + iVar3 + iVar5));
                if (iVar2 != 1) {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a23fa;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar3 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar5));
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a2412;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar3 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar3 + iVar5));
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a2422;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar5));
                    return 0;
                }
                iVar6 = iVar6 + 1;
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a23c2;
                iVar2 = func_0x000180222010(in_R8);
            } while (iVar6 < iVar2);
        }
        uVar7 = *(undefined8 *)(iVar1 + 0x10);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a23cf;
        fcn.180238640(uVar7);
        *(int64_t *)(iVar1 + 0x10) = in_R8;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a249e
// Address: 0x1801a249e
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801a2430(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a2440;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a246a;
        iVar3 = func_0x000180238060(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a2480;
            iVar2 = fcn.1801a2320(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
            if (iVar2 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a248c;
            fcn.180238640(iVar3);
        }
        return 0;
    }
    uVar7 = *(undefined8 *)((int64_t)auStackX_18 + iVar5);
    *(undefined8 *)(&stack0x00000040 + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = *(undefined8 *)((int64_t)&arg_30h + iVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + -8) = uVar7;
    *(undefined8 *)(&stack0x00000008 + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + -0x18) = 0x1801a2333;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        piVar4 = *(int64_t **)(in_RDX + 0x158);
    } else {
        piVar4 = *(int64_t **)(in_RCX + 0x878);
    }
    iVar1 = *piVar4;
    if (iVar1 != 0) {
        *(undefined8 *)(&stack0x00000058 + iVar3 + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_60h + iVar3 + iVar5) = unaff_R12;
        iVar6 = 0;
        *(undefined8 *)(&stack0x00000068 + iVar3 + iVar5) = unaff_R14;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a2389;
        iVar2 = func_0x000180222010(in_R8);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a239a;
                func_0x000180222340(in_R8, iVar6);
                *(undefined4 *)((int64_t)&arg_28h + iVar3 + iVar5) = 0;
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a23b0;
                iVar2 = fcn.1801a8d20(*(int64_t *)(&stack0x00000048 + iVar3 + iVar5), 
                                      *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar5), 
                                      *(int64_t *)(&stack0x00000068 + iVar3 + iVar5), 
                                      *(int64_t *)(&stack0x000000d8 + iVar3 + iVar5));
                if (iVar2 != 1) {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a23fa;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar3 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar5));
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a2412;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar3 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar3 + iVar5));
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a2422;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar5));
                    return 0;
                }
                iVar6 = iVar6 + 1;
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a23c2;
                iVar2 = func_0x000180222010(in_R8);
            } while (iVar6 < iVar2);
        }
        uVar7 = *(undefined8 *)(iVar1 + 0x10);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5 + -0x18) = 0x1801a23cf;
        fcn.180238640(uVar7);
        *(int64_t *)(iVar1 + 0x10) = in_R8;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a24c0
// Address: 0x1801a24c0
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801a24c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar3;
    int32_t in_R8D;
    int32_t in_R9D;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a24d5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((in_R9D != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a24f3;
        uVar2 = fcn.18021f5b0(in_RDX);
        if ((int32_t)uVar2 == 0) {
            return uVar2;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
    iVar3 = 0x70;
    if (in_R8D == 0) {
        iVar3 = 0x78;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a2524;
    fcn.18021f290(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar1), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(int64_t *)(iVar3 + in_RCX) = in_RDX;
    return 1;
}

