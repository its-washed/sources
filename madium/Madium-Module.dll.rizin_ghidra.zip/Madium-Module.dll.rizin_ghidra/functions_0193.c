// Chunk 193 - 50 functions

// ============================================================
// Function: FUN_18025b180
// Address: 0x18025b180
// Size: 22 bytes
// ============================================================
undefined8 fcn.18025b180(int64_t param_1)
{
    fcn.18045a350();
    return *(undefined8 *)(param_1 + 0x28);
}

// ============================================================
// Function: FUN_18025b1a0
// Address: 0x18025b1a0
// Size: 22 bytes
// ============================================================
undefined8 fcn.18025b1a0(int64_t param_1)
{
    fcn.18045a350();
    if (param_1 != 0) {
        return *(undefined8 *)(param_1 + 0xd8);
    }
    return 0;
}

// ============================================================
// Function: FUN_18025b1c0
// Address: 0x18025b1c0
// Size: 22 bytes
// ============================================================
undefined8 fcn.18025b1c0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStackX_20 - iVar1) = 0x18027ef2a;
    fcn.18045a350();
    if (*(code **)(param_1 + 0x88) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018027ef44. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (**(code **)(param_1 + 0x88))(*(undefined8 *)(param_1 + 0xd8));
        return uVar2;
    }
    return 1;
}

// ============================================================
// Function: FUN_18025b1e0
// Address: 0x18025b1e0
// Size: 57 bytes
// ============================================================
undefined8 fcn.18025b1e0(undefined8 param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b1ec;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025b1fc;
    uVar2 = fcn.18027e820(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if ((int32_t)uVar2 == 0) {
        return uVar2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025b20e;
    fcn.18027edb0(param_1);
    return 1;
}

// ============================================================
// Function: FUN_18025b220
// Address: 0x18025b220
// Size: 35 bytes
// ============================================================
void fcn.18025b220(int64_t arg1, int64_t arg_28h, int64_t arg_58h)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 unaff_RDI;
    uint64_t uVar4;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18025b230;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar3 = *(undefined8 *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b23f;
        uVar1 = fcn.180222010(uVar3);
        if (0 < (int32_t)uVar1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            uVar4 = (uint64_t)uVar1;
            do {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b259;
                uVar3 = fcn.180222020(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2)
                                     );
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b26e;
                fcn.180224990(uVar3, 0x1804e6738, 0x6e);
                uVar4 = uVar4 - 1;
            } while (uVar4 != 0);
        }
        uVar3 = *(undefined8 *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b282;
        fcn.180221d50(uVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b297;
        fcn.180224990(arg1, 0x1804e6738, 0x77);
    }
    return;
}

// ============================================================
// Function: FUN_18025b243
// Address: 0x18025b243
// Size: 54 bytes
// ============================================================
void fcn.18025b220(int64_t arg1, int64_t arg_28h, int64_t arg_58h)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 unaff_RDI;
    uint64_t uVar4;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18025b230;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar3 = *(undefined8 *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b23f;
        uVar1 = fcn.180222010(uVar3);
        if (0 < (int32_t)uVar1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            uVar4 = (uint64_t)uVar1;
            do {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b259;
                uVar3 = fcn.180222020(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2)
                                     );
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b26e;
                fcn.180224990(uVar3, 0x1804e6738, 0x6e);
                uVar4 = uVar4 - 1;
            } while (uVar4 != 0);
        }
        uVar3 = *(undefined8 *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b282;
        fcn.180221d50(uVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b297;
        fcn.180224990(arg1, 0x1804e6738, 0x77);
    }
    return;
}

// ============================================================
// Function: FUN_18025b279
// Address: 0x18025b279
// Size: 36 bytes
// ============================================================
void fcn.18025b220(int64_t arg1, int64_t arg_28h, int64_t arg_58h)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 unaff_RDI;
    uint64_t uVar4;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18025b230;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar3 = *(undefined8 *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b23f;
        uVar1 = fcn.180222010(uVar3);
        if (0 < (int32_t)uVar1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            uVar4 = (uint64_t)uVar1;
            do {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b259;
                uVar3 = fcn.180222020(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2)
                                     );
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b26e;
                fcn.180224990(uVar3, 0x1804e6738, 0x6e);
                uVar4 = uVar4 - 1;
            } while (uVar4 != 0);
        }
        uVar3 = *(undefined8 *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b282;
        fcn.180221d50(uVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b297;
        fcn.180224990(arg1, 0x1804e6738, 0x77);
    }
    return;
}

// ============================================================
// Function: FUN_18025b2a0
// Address: 0x18025b2a0
// Size: 98 bytes
// ============================================================
int64_t fcn.18025b2a0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b2ac;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025b2c6;
    iVar2 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025b2d3;
        iVar3 = fcn.180221f20();
        *(int64_t *)(iVar2 + 0x10) = iVar3;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025b2f1;
            fcn.180224990(iVar2, 0x1804e6738, 0x62);
            return 0;
        }
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18025b310
// Address: 0x18025b310
// Size: 144 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18025b310(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b325;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8 == 0) {
        iVar1 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b33e;
        iVar1 = func_0x000180255370(in_R8);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b34a;
            iVar1 = func_0x000180255500(in_R8);
            *(undefined4 *)((int64_t)&var_18h + iVar2) = 1;
            iVar1 = ((int32_t)(iVar1 + 7 + (iVar1 + 7 >> 0x1f & 7U)) >> 3) + 1;
            goto code_r0x00018025b37f;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b367;
        iVar1 = func_0x000180255500(in_R8);
        iVar1 = (int32_t)(iVar1 + 7 + (iVar1 + 7 >> 0x1f & 7U)) >> 3;
    }
    *(undefined4 *)((int64_t)&var_18h + iVar2) = 2;
code_r0x00018025b37f:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b390;
    func_0x00018025baf0(in_RCX, in_RDX, in_R8, (int64_t)iVar1);
    return;
}

// ============================================================
// Function: FUN_18025b3a0
// Address: 0x18025b3a0
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18025b3a0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b3ba;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b3d6;
        iVar1 = func_0x000180255370(in_R8);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b3e2;
            iVar1 = func_0x000180255500(in_R8);
            *(undefined4 *)((int64_t)&var_18h + iVar2) = 1;
            in_R9 = (int64_t)((int32_t)(iVar1 + 7 + (iVar1 + 7 >> 0x1f & 7U)) >> 3);
            goto code_r0x00018025b406;
        }
    }
    *(undefined4 *)((int64_t)&var_18h + iVar2) = 2;
code_r0x00018025b406:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b414;
    func_0x00018025baf0(in_RCX, in_RDX, in_R8, in_R9);
    return;
}

// ============================================================
// Function: FUN_18025b430
// Address: 0x18025b430
// Size: 47 bytes
// ============================================================
void fcn.18025b430(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025b43f;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025b45a;
    fcn.18025b9c0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000070 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18025b460
// Address: 0x18025b460
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18025b460(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b47a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b491;
    uVar1 = fcn.180225100(in_R8);
    *(undefined4 *)((int64_t)&var_20h + iVar2) = uVar1;
    *(undefined4 *)((int64_t)&var_18h + iVar2) = 5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b4ae;
    iVar2 = fcn.18025b8f0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2));
    if (iVar2 != 0) {
        *(undefined8 *)(iVar2 + 0x28) = in_R8;
        iVar2 = 1;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18025b4e0
// Address: 0x18025b4e0
// Size: 47 bytes
// ============================================================
void fcn.18025b4e0(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025b4ef;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025b50a;
    fcn.18025b9c0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000070 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18025b510
// Address: 0x18025b510
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18025b510(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b52a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R9 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b546;
        func_0x000180498cd0(in_R8);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b551;
    uVar1 = fcn.180225100(in_R8);
    *(undefined4 *)((int64_t)&var_20h + iVar2) = uVar1;
    *(undefined4 *)((int64_t)&var_18h + iVar2) = 4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b56f;
    iVar2 = fcn.18025b8f0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2));
    if (iVar2 != 0) {
        *(undefined8 *)(iVar2 + 0x28) = in_R8;
        iVar2 = 1;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18025b5a0
// Address: 0x18025b5a0
// Size: 312 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18025b5a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 *in_RCX;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b5c0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar4 = 0;
    uVar6 = in_RCX[2];
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b5d1;
    iVar1 = fcn.180222010(uVar6);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b5e3;
    iVar3 = fcn.180256ab0((int64_t)(iVar1 + 1) * 0x28);
    iVar7 = in_RCX[1] << 3;
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b612;
        iVar4 = func_0x0001802252b0(iVar7, 0x1804e6738, 0x173);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b61f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b637;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b649;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b662;
    iVar5 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b67f;
        func_0x000180225200(iVar4, 0x1804e6738, 0x17b);
        iVar5 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b695;
        uVar6 = func_0x00018025b740(in_RCX, iVar5, iVar5 + iVar3 * 8, iVar4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b6a3;
        func_0x000180256ac0(uVar6, iVar4, iVar7);
        *in_RCX = 0;
        in_RCX[1] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b6ba;
        func_0x00018025b6e0(in_RCX);
    }
    return iVar5;
}

// ============================================================
// Function: FUN_18025b6e0
// Address: 0x18025b6e0
// Size: 31 bytes
// ============================================================
void fcn.18025b6e0(int64_t arg_28h, int64_t arg_58h)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar4;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b6ec;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar3 = *(undefined8 *)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b6fb;
    uVar1 = fcn.180222010(uVar3);
    if (0 < (int32_t)uVar1) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        uVar4 = (uint64_t)uVar1;
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b70f;
            uVar3 = fcn.180222020(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b724;
            fcn.180224990(uVar3, 0x1804e6738, 0x6e);
            uVar4 = uVar4 - 1;
        } while (uVar4 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_18025b6ff
// Address: 0x18025b6ff
// Size: 48 bytes
// ============================================================
void fcn.18025b6e0(int64_t arg_28h, int64_t arg_58h)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar4;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b6ec;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar3 = *(undefined8 *)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b6fb;
    uVar1 = fcn.180222010(uVar3);
    if (0 < (int32_t)uVar1) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        uVar4 = (uint64_t)uVar1;
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b70f;
            uVar3 = fcn.180222020(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b724;
            fcn.180224990(uVar3, 0x1804e6738, 0x6e);
            uVar4 = uVar4 - 1;
        } while (uVar4 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_18025b72f
// Address: 0x18025b72f
// Size: 6 bytes
// ============================================================
void fcn.18025b6e0(int64_t arg_28h, int64_t arg_58h)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar4;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b6ec;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar3 = *(undefined8 *)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b6fb;
    uVar1 = fcn.180222010(uVar3);
    if (0 < (int32_t)uVar1) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        uVar4 = (uint64_t)uVar1;
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b70f;
            uVar3 = fcn.180222020(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b724;
            fcn.180224990(uVar3, 0x1804e6738, 0x6e);
            uVar4 = uVar4 - 1;
        } while (uVar4 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_18025b740
// Address: 0x18025b740
// Size: 66 bytes
// ============================================================
void fcn.18025b740(int64_t arg1, int64_t arg2, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_100h)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined8 *puVar7;
    undefined8 *puVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    undefined8 unaff_RSI;
    undefined8 *puVar14;
    undefined8 *in_R8;
    undefined8 *in_R9;
    undefined8 unaff_R12;
    undefined8 *puVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_38;
    
    uStack_38 = 0x18025b75d;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    uVar3 = *(undefined8 *)(arg1 + 0x10);
    iVar13 = 0;
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b777;
    iVar9 = fcn.180222010(uVar3);
    iVar16 = (int64_t)iVar9;
    if (0 < iVar9) {
        *(undefined8 *)((int64_t)&arg_70h + iVar10) = unaff_RSI;
        puVar14 = (undefined8 *)(arg2 + 0x18);
        *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_R12;
        iVar13 = 0;
        do {
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b79e;
            puVar11 = (undefined8 *)func_0x000180222340(uVar3, iVar13);
            puVar14[-3] = *puVar11;
            *(undefined4 *)(puVar14 + -2) = *(undefined4 *)(puVar11 + 1);
            *puVar14 = puVar11[2];
            puVar14[1] = 0xffffffffffffffff;
            puVar15 = in_R8;
            puVar8 = in_R9 + puVar11[3];
            puVar7 = in_R9;
            if (*(int32_t *)((int64_t)puVar11 + 0xc) == 0) {
                puVar15 = in_R8 + puVar11[3];
                puVar8 = in_R9;
                puVar7 = in_R8;
            }
            in_R9 = puVar8;
            puVar14[-1] = puVar7;
            iVar4 = puVar11[4];
            iVar9 = *(int32_t *)(puVar11 + 1);
            if (iVar4 == 0) {
                if ((iVar9 == 7) || (iVar9 == 6)) {
                    *puVar7 = puVar11[5];
                } else if (iVar9 - 4U < 2) {
                    if (puVar11[5] == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b85a;
                        fcn.1804986e0(puVar7);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b853;
                        fcn.180498030();
                    }
                    if (*(int32_t *)(puVar11 + 1) == 4) {
                        *(undefined *)((int64_t)puVar7 + puVar11[2]) = 0;
                    }
                } else if ((uint64_t)puVar11[2] < 9) {
                    if (puVar11[2] != 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b840;
                        fcn.180498030(puVar7, puVar11 + 6);
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b82d;
                    fcn.1804986e0(puVar7, 0);
                }
            } else {
                uVar2 = *(undefined4 *)(puVar11 + 2);
                if (iVar9 == 2) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b7fe;
                    func_0x000180254da0();
                } else {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b805;
                    func_0x0001802558d0(iVar4, puVar7, uVar2);
                }
            }
            iVar13 = iVar13 + 1;
            puVar14 = puVar14 + 5;
            arg1 = *(int64_t *)((int64_t)&arg_60h + iVar10);
            iVar16 = iVar16 + -1;
            in_R8 = puVar15;
        } while (iVar16 != 0);
        arg2 = *(int64_t *)((int64_t)&arg_68h + iVar10);
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b8ae;
    puVar12 = (undefined4 *)func_0x000180229ba0(&stack0xfffffffffffffff0 + iVar10);
    uVar2 = puVar12[1];
    uVar5 = puVar12[2];
    uVar6 = puVar12[3];
    puVar1 = (undefined4 *)(arg2 + (int64_t)iVar13 * 0x28);
    *puVar1 = *puVar12;
    puVar1[1] = uVar2;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    uVar2 = puVar12[5];
    uVar5 = puVar12[6];
    uVar6 = puVar12[7];
    puVar1[4] = puVar12[4];
    puVar1[5] = uVar2;
    puVar1[6] = uVar5;
    puVar1[7] = uVar6;
    *(undefined8 *)(puVar1 + 8) = *(undefined8 *)(puVar12 + 8);
    return;
}

// ============================================================
// Function: FUN_18025b782
// Address: 0x18025b782
// Size: 290 bytes
// ============================================================
void fcn.18025b740(int64_t arg1, int64_t arg2, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_100h)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined8 *puVar7;
    undefined8 *puVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    undefined8 unaff_RSI;
    undefined8 *puVar14;
    undefined8 *in_R8;
    undefined8 *in_R9;
    undefined8 unaff_R12;
    undefined8 *puVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_38;
    
    uStack_38 = 0x18025b75d;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    uVar3 = *(undefined8 *)(arg1 + 0x10);
    iVar13 = 0;
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b777;
    iVar9 = fcn.180222010(uVar3);
    iVar16 = (int64_t)iVar9;
    if (0 < iVar9) {
        *(undefined8 *)((int64_t)&arg_70h + iVar10) = unaff_RSI;
        puVar14 = (undefined8 *)(arg2 + 0x18);
        *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_R12;
        iVar13 = 0;
        do {
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b79e;
            puVar11 = (undefined8 *)func_0x000180222340(uVar3, iVar13);
            puVar14[-3] = *puVar11;
            *(undefined4 *)(puVar14 + -2) = *(undefined4 *)(puVar11 + 1);
            *puVar14 = puVar11[2];
            puVar14[1] = 0xffffffffffffffff;
            puVar15 = in_R8;
            puVar8 = in_R9 + puVar11[3];
            puVar7 = in_R9;
            if (*(int32_t *)((int64_t)puVar11 + 0xc) == 0) {
                puVar15 = in_R8 + puVar11[3];
                puVar8 = in_R9;
                puVar7 = in_R8;
            }
            in_R9 = puVar8;
            puVar14[-1] = puVar7;
            iVar4 = puVar11[4];
            iVar9 = *(int32_t *)(puVar11 + 1);
            if (iVar4 == 0) {
                if ((iVar9 == 7) || (iVar9 == 6)) {
                    *puVar7 = puVar11[5];
                } else if (iVar9 - 4U < 2) {
                    if (puVar11[5] == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b85a;
                        fcn.1804986e0(puVar7);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b853;
                        fcn.180498030();
                    }
                    if (*(int32_t *)(puVar11 + 1) == 4) {
                        *(undefined *)((int64_t)puVar7 + puVar11[2]) = 0;
                    }
                } else if ((uint64_t)puVar11[2] < 9) {
                    if (puVar11[2] != 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b840;
                        fcn.180498030(puVar7, puVar11 + 6);
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b82d;
                    fcn.1804986e0(puVar7, 0);
                }
            } else {
                uVar2 = *(undefined4 *)(puVar11 + 2);
                if (iVar9 == 2) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b7fe;
                    func_0x000180254da0();
                } else {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b805;
                    func_0x0001802558d0(iVar4, puVar7, uVar2);
                }
            }
            iVar13 = iVar13 + 1;
            puVar14 = puVar14 + 5;
            arg1 = *(int64_t *)((int64_t)&arg_60h + iVar10);
            iVar16 = iVar16 + -1;
            in_R8 = puVar15;
        } while (iVar16 != 0);
        arg2 = *(int64_t *)((int64_t)&arg_68h + iVar10);
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b8ae;
    puVar12 = (undefined4 *)func_0x000180229ba0(&stack0xfffffffffffffff0 + iVar10);
    uVar2 = puVar12[1];
    uVar5 = puVar12[2];
    uVar6 = puVar12[3];
    puVar1 = (undefined4 *)(arg2 + (int64_t)iVar13 * 0x28);
    *puVar1 = *puVar12;
    puVar1[1] = uVar2;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    uVar2 = puVar12[5];
    uVar5 = puVar12[6];
    uVar6 = puVar12[7];
    puVar1[4] = puVar12[4];
    puVar1[5] = uVar2;
    puVar1[6] = uVar5;
    puVar1[7] = uVar6;
    *(undefined8 *)(puVar1 + 8) = *(undefined8 *)(puVar12 + 8);
    return;
}

// ============================================================
// Function: FUN_18025b8a4
// Address: 0x18025b8a4
// Size: 65 bytes
// ============================================================
void fcn.18025b740(int64_t arg1, int64_t arg2, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_100h)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined8 *puVar7;
    undefined8 *puVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    undefined8 unaff_RSI;
    undefined8 *puVar14;
    undefined8 *in_R8;
    undefined8 *in_R9;
    undefined8 unaff_R12;
    undefined8 *puVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_38;
    
    uStack_38 = 0x18025b75d;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    uVar3 = *(undefined8 *)(arg1 + 0x10);
    iVar13 = 0;
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b777;
    iVar9 = fcn.180222010(uVar3);
    iVar16 = (int64_t)iVar9;
    if (0 < iVar9) {
        *(undefined8 *)((int64_t)&arg_70h + iVar10) = unaff_RSI;
        puVar14 = (undefined8 *)(arg2 + 0x18);
        *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_R12;
        iVar13 = 0;
        do {
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b79e;
            puVar11 = (undefined8 *)func_0x000180222340(uVar3, iVar13);
            puVar14[-3] = *puVar11;
            *(undefined4 *)(puVar14 + -2) = *(undefined4 *)(puVar11 + 1);
            *puVar14 = puVar11[2];
            puVar14[1] = 0xffffffffffffffff;
            puVar15 = in_R8;
            puVar8 = in_R9 + puVar11[3];
            puVar7 = in_R9;
            if (*(int32_t *)((int64_t)puVar11 + 0xc) == 0) {
                puVar15 = in_R8 + puVar11[3];
                puVar8 = in_R9;
                puVar7 = in_R8;
            }
            in_R9 = puVar8;
            puVar14[-1] = puVar7;
            iVar4 = puVar11[4];
            iVar9 = *(int32_t *)(puVar11 + 1);
            if (iVar4 == 0) {
                if ((iVar9 == 7) || (iVar9 == 6)) {
                    *puVar7 = puVar11[5];
                } else if (iVar9 - 4U < 2) {
                    if (puVar11[5] == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b85a;
                        fcn.1804986e0(puVar7);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b853;
                        fcn.180498030();
                    }
                    if (*(int32_t *)(puVar11 + 1) == 4) {
                        *(undefined *)((int64_t)puVar7 + puVar11[2]) = 0;
                    }
                } else if ((uint64_t)puVar11[2] < 9) {
                    if (puVar11[2] != 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b840;
                        fcn.180498030(puVar7, puVar11 + 6);
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b82d;
                    fcn.1804986e0(puVar7, 0);
                }
            } else {
                uVar2 = *(undefined4 *)(puVar11 + 2);
                if (iVar9 == 2) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b7fe;
                    func_0x000180254da0();
                } else {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b805;
                    func_0x0001802558d0(iVar4, puVar7, uVar2);
                }
            }
            iVar13 = iVar13 + 1;
            puVar14 = puVar14 + 5;
            arg1 = *(int64_t *)((int64_t)&arg_60h + iVar10);
            iVar16 = iVar16 + -1;
            in_R8 = puVar15;
        } while (iVar16 != 0);
        arg2 = *(int64_t *)((int64_t)&arg_68h + iVar10);
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x18025b8ae;
    puVar12 = (undefined4 *)func_0x000180229ba0(&stack0xfffffffffffffff0 + iVar10);
    uVar2 = puVar12[1];
    uVar5 = puVar12[2];
    uVar6 = puVar12[3];
    puVar1 = (undefined4 *)(arg2 + (int64_t)iVar13 * 0x28);
    *puVar1 = *puVar12;
    puVar1[1] = uVar2;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    uVar2 = puVar12[5];
    uVar5 = puVar12[6];
    uVar6 = puVar12[7];
    puVar1[4] = puVar12[4];
    puVar1[5] = uVar2;
    puVar1[6] = uVar5;
    puVar1[7] = uVar6;
    *(undefined8 *)(puVar1 + 8) = *(undefined8 *)(puVar12 + 8);
    return;
}

// ============================================================
// Function: FUN_18025b8f0
// Address: 0x18025b8f0
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 *
fcn.18025b8f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b910;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b936;
    puVar3 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar2));
    if (puVar3 != (undefined8 *)0x0) {
        *puVar3 = in_RDX;
        *(undefined4 *)(puVar3 + 1) = *(undefined4 *)((int64_t)&arg_48h + iVar2);
        puVar3[2] = in_R8;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b954;
        iVar4 = fcn.180256ab0(in_R9);
        puVar3[3] = iVar4;
        iVar1 = *(int32_t *)((int64_t)&arg_50h + iVar2);
        *(int32_t *)((int64_t)puVar3 + 0xc) = iVar1;
        if (iVar1 == 0) {
            *in_RCX = *in_RCX + iVar4;
        } else {
            in_RCX[1] = in_RCX[1] + iVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b97b;
        iVar1 = fcn.180222110(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_40h + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2), 
                              *(int64_t *)((int64_t)&arg_50h + iVar2));
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025b994;
            fcn.180224990(puVar3, 0x1804e6738, 0x44);
            puVar3 = (undefined8 *)0x0;
        }
    }
    return puVar3;
}

// ============================================================
// Function: FUN_18025b9c0
// Address: 0x18025b9c0
// Size: 291 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18025b9c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b9e0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ba06;
    puVar3 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar2));
    if (puVar3 != (undefined8 *)0x0) {
        *(undefined4 *)(puVar3 + 1) = *(undefined4 *)(&stack0x00000048 + iVar2);
        *puVar3 = in_RDX;
        puVar3[2] = in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ba24;
        iVar4 = fcn.180256ab0(in_R9);
        puVar3[3] = iVar4;
        *(undefined4 *)((int64_t)puVar3 + 0xc) = 0;
        *in_RCX = *in_RCX + iVar4;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ba3e;
        iVar1 = fcn.180222110(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_40h + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar2));
        if (0 < iVar1) {
            if (in_R9 < 9) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025badc;
                fcn.180498030(puVar3 + 6, in_R8, in_R9);
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025baae;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025bac6;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            goto code_r0x00018025ba79;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ba57;
        fcn.180224990(puVar3, 0x1804e6738, 0x44);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ba5c;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ba74;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
code_r0x00018025ba79:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ba86;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_18025baf0
// Address: 0x18025baf0
// Size: 353 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.18025baf0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025bb0e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *(int32_t *)((int64_t)&arg_58h + iVar3);
    uVar4 = 0;
    if (1 < iVar1 - 1U) {
        return 0;
    }
    if (in_R8 == 0) {
code_r0x00018025bc21:
        *(uint32_t *)((int64_t)&var_10h + iVar3) = uVar4;
        *(int32_t *)((int64_t)&var_8h + iVar3) = iVar1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025bc3a;
        iVar3 = fcn.18025b8f0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3));
        if (iVar3 != 0) {
            *(int64_t *)(iVar3 + 0x20) = in_R8;
            return 1;
        }
    } else {
        if (iVar1 == 2) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025bb41;
            iVar2 = fcn.180255370(in_R8);
            if (iVar2 == 0) goto code_r0x00018025bb93;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025bb4a;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025bb62;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3));
        } else {
code_r0x00018025bb93:
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025bb9b;
            iVar2 = fcn.180255500(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                                  *(int64_t *)(&stack0x00000060 + iVar3));
            iVar2 = (int32_t)(iVar2 + 7 + (iVar2 + 7 >> 0x1f & 7U)) >> 3;
            if (iVar2 < 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025bbb0;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025bbc8;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
            } else {
                if ((uint64_t)(int64_t)iVar2 <= in_R9) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025bc10;
                    iVar2 = fcn.180255310(in_R8, 8);
                    uVar4 = (uint32_t)(iVar2 == 8);
                    goto code_r0x00018025bc21;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025bbde;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025bbf6;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025bb78;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
    }
    return 0;
}

// ============================================================
// Function: FUN_18025bc60
// Address: 0x18025bc60
// Size: 172 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18025bc60(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_90h, int64_t arg_a8h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 *in_R8;
    undefined8 in_R9;
    undefined8 uVar10;
    undefined8 unaff_R12;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025bc79;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    piVar1 = *(int32_t **)(in_RCX + 0x28);
    if (piVar1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bc96;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcae;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcc0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
        uVar9 = 0;
    } else {
        uVar6 = *(uint32_t *)(in_RCX + 0x18);
        if ((uVar6 >> 0xb & 1) == 0) {
            iVar7 = *piVar1;
            *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RBP;
            if (((iVar7 == 0x80) && (*(int64_t *)(piVar1 + 0xc) != 0)) &&
               (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0)) {
                if (*(int64_t *)(iVar2 + 0xa8) != 0) {
                    iVar3 = *(int64_t *)(iVar2 + 0x10);
                    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_R12;
                    iVar11 = 0x1805aadb1;
                    if (iVar3 != 0) {
                        iVar11 = iVar3;
                    }
                    if (in_RDX == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd6f;
                        func_0x000180229b10();
                        uVar10 = 0;
                    } else {
                        *(uint32_t *)(in_RCX + 0x18) = uVar6 | 0x800;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd65;
                        func_0x000180229b10();
                        uVar10 = *in_R8;
                    }
                    pcVar4 = *(code **)(iVar2 + 0xa8);
                    uVar5 = *(undefined8 *)(piVar1 + 0xc);
                    *(undefined8 *)((int64_t)&var_10h + iVar8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
                    *(undefined8 *)((int64_t)&var_8h + iVar8) = in_R9;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd95;
                    uVar6 = (*pcVar4)(uVar5, in_RDX, in_R8, uVar10);
                    if ((int32_t)uVar6 < 1) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bda0;
                        iVar7 = func_0x000180229970();
                        if (iVar7 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bda9;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                          *(int64_t *)((int64_t)&var_10h + iVar8));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bdc1;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                          *(int64_t *)((int64_t)&var_10h + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8), 
                                          *(int64_t *)((int64_t)&var_20h + iVar8), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar8));
                            *(int64_t *)((int64_t)&var_8h + iVar8) = iVar11;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bde0;
                            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bde5;
                    func_0x000180229900();
                    return (uint64_t)uVar6;
                }
            } else if ((*(int64_t *)(piVar1 + 0x1e) != 0) &&
                      (pcVar4 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xd0), pcVar4 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&var_8h + iVar8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be13;
                uVar9 = (*pcVar4)(in_RCX);
                return uVar9;
            }
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be2a;
                iVar7 = func_0x00018025c340(in_RCX, in_R9, *(undefined8 *)((int64_t)&arg_58h + iVar8));
                if (iVar7 < 1) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be40;
            uVar9 = func_0x00018025be60(in_RCX, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcd5;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bced;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcff;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
            uVar9 = 0;
        }
    }
    return uVar9;
}

// ============================================================
// Function: FUN_18025bd0c
// Address: 0x18025bd0c
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18025bc60(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_90h, int64_t arg_a8h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 *in_R8;
    undefined8 in_R9;
    undefined8 uVar10;
    undefined8 unaff_R12;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025bc79;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    piVar1 = *(int32_t **)(in_RCX + 0x28);
    if (piVar1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bc96;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcae;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcc0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
        uVar9 = 0;
    } else {
        uVar6 = *(uint32_t *)(in_RCX + 0x18);
        if ((uVar6 >> 0xb & 1) == 0) {
            iVar7 = *piVar1;
            *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RBP;
            if (((iVar7 == 0x80) && (*(int64_t *)(piVar1 + 0xc) != 0)) &&
               (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0)) {
                if (*(int64_t *)(iVar2 + 0xa8) != 0) {
                    iVar3 = *(int64_t *)(iVar2 + 0x10);
                    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_R12;
                    iVar11 = 0x1805aadb1;
                    if (iVar3 != 0) {
                        iVar11 = iVar3;
                    }
                    if (in_RDX == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd6f;
                        func_0x000180229b10();
                        uVar10 = 0;
                    } else {
                        *(uint32_t *)(in_RCX + 0x18) = uVar6 | 0x800;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd65;
                        func_0x000180229b10();
                        uVar10 = *in_R8;
                    }
                    pcVar4 = *(code **)(iVar2 + 0xa8);
                    uVar5 = *(undefined8 *)(piVar1 + 0xc);
                    *(undefined8 *)((int64_t)&var_10h + iVar8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
                    *(undefined8 *)((int64_t)&var_8h + iVar8) = in_R9;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd95;
                    uVar6 = (*pcVar4)(uVar5, in_RDX, in_R8, uVar10);
                    if ((int32_t)uVar6 < 1) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bda0;
                        iVar7 = func_0x000180229970();
                        if (iVar7 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bda9;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                          *(int64_t *)((int64_t)&var_10h + iVar8));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bdc1;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                          *(int64_t *)((int64_t)&var_10h + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8), 
                                          *(int64_t *)((int64_t)&var_20h + iVar8), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar8));
                            *(int64_t *)((int64_t)&var_8h + iVar8) = iVar11;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bde0;
                            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bde5;
                    func_0x000180229900();
                    return (uint64_t)uVar6;
                }
            } else if ((*(int64_t *)(piVar1 + 0x1e) != 0) &&
                      (pcVar4 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xd0), pcVar4 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&var_8h + iVar8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be13;
                uVar9 = (*pcVar4)(in_RCX);
                return uVar9;
            }
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be2a;
                iVar7 = func_0x00018025c340(in_RCX, in_R9, *(undefined8 *)((int64_t)&arg_58h + iVar8));
                if (iVar7 < 1) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be40;
            uVar9 = func_0x00018025be60(in_RCX, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcd5;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bced;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcff;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
            uVar9 = 0;
        }
    }
    return uVar9;
}

// ============================================================
// Function: FUN_18025bd44
// Address: 0x18025bd44
// Size: 170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18025bc60(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_90h, int64_t arg_a8h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 *in_R8;
    undefined8 in_R9;
    undefined8 uVar10;
    undefined8 unaff_R12;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025bc79;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    piVar1 = *(int32_t **)(in_RCX + 0x28);
    if (piVar1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bc96;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcae;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcc0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
        uVar9 = 0;
    } else {
        uVar6 = *(uint32_t *)(in_RCX + 0x18);
        if ((uVar6 >> 0xb & 1) == 0) {
            iVar7 = *piVar1;
            *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RBP;
            if (((iVar7 == 0x80) && (*(int64_t *)(piVar1 + 0xc) != 0)) &&
               (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0)) {
                if (*(int64_t *)(iVar2 + 0xa8) != 0) {
                    iVar3 = *(int64_t *)(iVar2 + 0x10);
                    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_R12;
                    iVar11 = 0x1805aadb1;
                    if (iVar3 != 0) {
                        iVar11 = iVar3;
                    }
                    if (in_RDX == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd6f;
                        func_0x000180229b10();
                        uVar10 = 0;
                    } else {
                        *(uint32_t *)(in_RCX + 0x18) = uVar6 | 0x800;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd65;
                        func_0x000180229b10();
                        uVar10 = *in_R8;
                    }
                    pcVar4 = *(code **)(iVar2 + 0xa8);
                    uVar5 = *(undefined8 *)(piVar1 + 0xc);
                    *(undefined8 *)((int64_t)&var_10h + iVar8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
                    *(undefined8 *)((int64_t)&var_8h + iVar8) = in_R9;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd95;
                    uVar6 = (*pcVar4)(uVar5, in_RDX, in_R8, uVar10);
                    if ((int32_t)uVar6 < 1) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bda0;
                        iVar7 = func_0x000180229970();
                        if (iVar7 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bda9;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                          *(int64_t *)((int64_t)&var_10h + iVar8));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bdc1;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                          *(int64_t *)((int64_t)&var_10h + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8), 
                                          *(int64_t *)((int64_t)&var_20h + iVar8), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar8));
                            *(int64_t *)((int64_t)&var_8h + iVar8) = iVar11;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bde0;
                            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bde5;
                    func_0x000180229900();
                    return (uint64_t)uVar6;
                }
            } else if ((*(int64_t *)(piVar1 + 0x1e) != 0) &&
                      (pcVar4 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xd0), pcVar4 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&var_8h + iVar8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be13;
                uVar9 = (*pcVar4)(in_RCX);
                return uVar9;
            }
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be2a;
                iVar7 = func_0x00018025c340(in_RCX, in_R9, *(undefined8 *)((int64_t)&arg_58h + iVar8));
                if (iVar7 < 1) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be40;
            uVar9 = func_0x00018025be60(in_RCX, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcd5;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bced;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcff;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
            uVar9 = 0;
        }
    }
    return uVar9;
}

// ============================================================
// Function: FUN_18025bdee
// Address: 0x18025bdee
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18025bc60(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_90h, int64_t arg_a8h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 *in_R8;
    undefined8 in_R9;
    undefined8 uVar10;
    undefined8 unaff_R12;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025bc79;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    piVar1 = *(int32_t **)(in_RCX + 0x28);
    if (piVar1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bc96;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcae;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcc0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
        uVar9 = 0;
    } else {
        uVar6 = *(uint32_t *)(in_RCX + 0x18);
        if ((uVar6 >> 0xb & 1) == 0) {
            iVar7 = *piVar1;
            *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RBP;
            if (((iVar7 == 0x80) && (*(int64_t *)(piVar1 + 0xc) != 0)) &&
               (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0)) {
                if (*(int64_t *)(iVar2 + 0xa8) != 0) {
                    iVar3 = *(int64_t *)(iVar2 + 0x10);
                    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_R12;
                    iVar11 = 0x1805aadb1;
                    if (iVar3 != 0) {
                        iVar11 = iVar3;
                    }
                    if (in_RDX == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd6f;
                        func_0x000180229b10();
                        uVar10 = 0;
                    } else {
                        *(uint32_t *)(in_RCX + 0x18) = uVar6 | 0x800;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd65;
                        func_0x000180229b10();
                        uVar10 = *in_R8;
                    }
                    pcVar4 = *(code **)(iVar2 + 0xa8);
                    uVar5 = *(undefined8 *)(piVar1 + 0xc);
                    *(undefined8 *)((int64_t)&var_10h + iVar8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
                    *(undefined8 *)((int64_t)&var_8h + iVar8) = in_R9;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd95;
                    uVar6 = (*pcVar4)(uVar5, in_RDX, in_R8, uVar10);
                    if ((int32_t)uVar6 < 1) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bda0;
                        iVar7 = func_0x000180229970();
                        if (iVar7 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bda9;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                          *(int64_t *)((int64_t)&var_10h + iVar8));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bdc1;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                          *(int64_t *)((int64_t)&var_10h + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8), 
                                          *(int64_t *)((int64_t)&var_20h + iVar8), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar8));
                            *(int64_t *)((int64_t)&var_8h + iVar8) = iVar11;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bde0;
                            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bde5;
                    func_0x000180229900();
                    return (uint64_t)uVar6;
                }
            } else if ((*(int64_t *)(piVar1 + 0x1e) != 0) &&
                      (pcVar4 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xd0), pcVar4 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&var_8h + iVar8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be13;
                uVar9 = (*pcVar4)(in_RCX);
                return uVar9;
            }
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be2a;
                iVar7 = func_0x00018025c340(in_RCX, in_R9, *(undefined8 *)((int64_t)&arg_58h + iVar8));
                if (iVar7 < 1) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be40;
            uVar9 = func_0x00018025be60(in_RCX, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcd5;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bced;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcff;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
            uVar9 = 0;
        }
    }
    return uVar9;
}

// ============================================================
// Function: FUN_18025be45
// Address: 0x18025be45
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18025bc60(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_90h, int64_t arg_a8h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 *in_R8;
    undefined8 in_R9;
    undefined8 uVar10;
    undefined8 unaff_R12;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025bc79;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    piVar1 = *(int32_t **)(in_RCX + 0x28);
    if (piVar1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bc96;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcae;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcc0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
        uVar9 = 0;
    } else {
        uVar6 = *(uint32_t *)(in_RCX + 0x18);
        if ((uVar6 >> 0xb & 1) == 0) {
            iVar7 = *piVar1;
            *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RBP;
            if (((iVar7 == 0x80) && (*(int64_t *)(piVar1 + 0xc) != 0)) &&
               (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0)) {
                if (*(int64_t *)(iVar2 + 0xa8) != 0) {
                    iVar3 = *(int64_t *)(iVar2 + 0x10);
                    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_R12;
                    iVar11 = 0x1805aadb1;
                    if (iVar3 != 0) {
                        iVar11 = iVar3;
                    }
                    if (in_RDX == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd6f;
                        func_0x000180229b10();
                        uVar10 = 0;
                    } else {
                        *(uint32_t *)(in_RCX + 0x18) = uVar6 | 0x800;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd65;
                        func_0x000180229b10();
                        uVar10 = *in_R8;
                    }
                    pcVar4 = *(code **)(iVar2 + 0xa8);
                    uVar5 = *(undefined8 *)(piVar1 + 0xc);
                    *(undefined8 *)((int64_t)&var_10h + iVar8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
                    *(undefined8 *)((int64_t)&var_8h + iVar8) = in_R9;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bd95;
                    uVar6 = (*pcVar4)(uVar5, in_RDX, in_R8, uVar10);
                    if ((int32_t)uVar6 < 1) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bda0;
                        iVar7 = func_0x000180229970();
                        if (iVar7 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bda9;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                          *(int64_t *)((int64_t)&var_10h + iVar8));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bdc1;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), 
                                          *(int64_t *)((int64_t)&var_10h + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8), 
                                          *(int64_t *)((int64_t)&var_20h + iVar8), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar8));
                            *(int64_t *)((int64_t)&var_8h + iVar8) = iVar11;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bde0;
                            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bde5;
                    func_0x000180229900();
                    return (uint64_t)uVar6;
                }
            } else if ((*(int64_t *)(piVar1 + 0x1e) != 0) &&
                      (pcVar4 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xd0), pcVar4 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&var_8h + iVar8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be13;
                uVar9 = (*pcVar4)(in_RCX);
                return uVar9;
            }
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be2a;
                iVar7 = func_0x00018025c340(in_RCX, in_R9, *(undefined8 *)((int64_t)&arg_58h + iVar8));
                if (iVar7 < 1) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025be40;
            uVar9 = func_0x00018025be60(in_RCX, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcd5;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bced;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025bcff;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
            uVar9 = 0;
        }
    }
    return uVar9;
}

// ============================================================
// Function: FUN_18025be60
// Address: 0x18025be60
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18025be60(int64_t arg_50h, int64_t arg_60h, int64_t arg_b8h)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t *piVar10;
    int32_t **in_R8;
    int32_t *piVar11;
    undefined8 unaff_R13;
    int64_t iVar12;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t aiStackX_10 [3];
    undefined8 uStack_38;
    int64_t var_10h;
    
    uStack_38 = 0x18025be73;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_50h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7);
    piVar10 = *(int32_t **)(in_RCX + 0x28);
    piVar11 = (int32_t *)0x0;
    uVar1 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar1 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bea9;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bec1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bed3;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
        goto code_r0x00018025bf7f;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_R14;
    if (piVar10 != (int32_t *)0x0) {
        if (((*piVar10 == 0x80) && (*(int64_t *)(piVar10 + 0xc) != 0)) &&
           (iVar9 = *(int64_t *)(piVar10 + 10), iVar9 != 0)) {
            iVar2 = *(int64_t *)(iVar9 + 0x10);
            *(undefined8 *)((int64_t)&arg_b8h + iVar7) = unaff_R13;
            iVar12 = 0x1805aadb1;
            if (iVar2 != 0) {
                iVar12 = iVar2;
            }
            if (*(int64_t *)(iVar9 + 0xa0) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf36;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf4e;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf6d;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                goto code_r0x00018025bf7f;
            }
            piVar8 = piVar11;
            if ((in_RDX == 0) || (piVar8 = (int32_t *)0x0, (uVar1 >> 9 & 1) != 0)) {
code_r0x00018025bfc4:
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc9;
                func_0x000180229b10();
                if (in_RDX != 0) goto code_r0x00018025bfce;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfb2;
                piVar8 = (int32_t *)func_0x000180258850(piVar10);
                if (piVar8 == (int32_t *)0x0) goto code_r0x00018025bfc4;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc2;
                func_0x000180229b10();
                piVar10 = piVar8;
code_r0x00018025bfce:
                piVar11 = *in_R8;
            }
            pcVar3 = *(code **)(iVar9 + 0xa0);
            uVar4 = *(undefined8 *)(piVar10 + 0xc);
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfe7;
            iVar6 = (*pcVar3)(uVar4, in_RDX, in_R8, piVar11);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bff2;
                iVar6 = func_0x000180229970();
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bffb;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c013;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                    *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c032;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                }
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c037;
            func_0x000180229900();
            if ((piVar8 == (int32_t *)0x0) && (in_RDX != 0)) {
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c057;
                func_0x000180258be0(piVar8);
            }
            goto code_r0x00018025bf7f;
        }
        if (*(int64_t *)(piVar10 + 0x1e) != 0) {
            if ((*(uint8_t *)(piVar10 + 0x28) & 1) != 0) {
                pcVar3 = *(code **)(*(int64_t *)(piVar10 + 0x1e) + 0xf8);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c083;
                iVar6 = (*pcVar3)(piVar10, in_RCX);
                if (iVar6 == 0) goto code_r0x00018025bf7f;
            }
            iVar9 = *(int64_t *)(piVar10 + 0x1e);
            piVar10[0x28] = piVar10[0x28] & 0xfffffffe;
            if ((*(uint8_t *)(iVar9 + 4) & 4) == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                if (in_RDX == 0) {
                    if (pcVar3 == (code *)0x0) {
                        uVar4 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c228;
                        iVar6 = func_0x00018020f800(uVar4);
                        if (0 < iVar6) {
                            *(int64_t *)((int64_t)&var_10h + iVar7) = (int64_t)iVar6;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c243;
                            func_0x000180247c50(piVar10, 0, in_R8, 0);
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c211;
                        (*pcVar3)(piVar10, 0, in_R8, in_RCX);
                    }
                } else {
                    uVar1 = *(uint32_t *)(in_RCX + 0x18);
                    *(undefined4 *)((int64_t)aiStackX_10 + iVar7 + -0x10) = 0;
                    if ((uVar1 & 0x200) == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c16a;
                        iVar9 = func_0x000180215470();
                        if (iVar9 == 0) goto code_r0x00018025bf7f;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c181;
                        iVar6 = func_0x000180214b00(iVar9, in_RCX);
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c18d;
                            func_0x000180215310(iVar9);
                            goto code_r0x00018025bf7f;
                        }
                        if (pcVar3 == (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1c5;
                            iVar6 = func_0x0001802146d0(iVar9, (int64_t)aiStackX_10 + iVar7, 
                                                        (int64_t)aiStackX_10 + iVar7 + -0x10);
                        } else {
                            iVar2 = *(int64_t *)(iVar9 + 0x28);
                            pcVar5 = *(code **)(*(int64_t *)(iVar2 + 0x78) + 0x78);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1b1;
                            iVar6 = (*pcVar5)(iVar2, in_RDX, in_R8, iVar9);
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1cf;
                        func_0x000180215310(iVar9);
                        if (pcVar3 != (code *)0x0) goto code_r0x00018025bf7f;
                    } else {
                        if (pcVar3 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c146;
                            (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                            goto code_r0x00018025bf7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c161;
                        iVar6 = func_0x0001802146d0(in_RCX, (int64_t)aiStackX_10 + iVar7, 
                                                    (int64_t)aiStackX_10 + iVar7 + -0x10);
                    }
                    if (iVar6 != 0) {
                        *(uint64_t *)((int64_t)&var_10h + iVar7) =
                             (uint64_t)*(uint32_t *)((int64_t)aiStackX_10 + iVar7 + -0x10);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1fc;
                        func_0x000180247c50(piVar10, in_RDX, in_R8, (int64_t)aiStackX_10 + iVar7);
                    }
                }
            } else if (in_RDX == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0b3;
                (*pcVar3)(piVar10, 0, in_R8, in_RCX);
            } else if ((*(uint32_t *)(in_RCX + 0x18) & 0x200) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0e3;
                iVar9 = func_0x000180258850(piVar10);
                if (iVar9 != 0) {
                    pcVar3 = *(code **)(*(int64_t *)(iVar9 + 0x78) + 0x78);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c106;
                    (*pcVar3)(iVar9, in_RDX, in_R8, in_RCX);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c110;
                    func_0x000180258be0(iVar9);
                }
            } else {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0d0;
                (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            }
            goto code_r0x00018025bf7f;
        }
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c256;
    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c26e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c280;
    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
code_r0x00018025bf7f:
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf8f;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18025beda
// Address: 0x18025beda
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18025be60(int64_t arg_50h, int64_t arg_60h, int64_t arg_b8h)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t *piVar10;
    int32_t **in_R8;
    int32_t *piVar11;
    undefined8 unaff_R13;
    int64_t iVar12;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t aiStackX_10 [3];
    undefined8 uStack_38;
    int64_t var_10h;
    
    uStack_38 = 0x18025be73;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_50h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7);
    piVar10 = *(int32_t **)(in_RCX + 0x28);
    piVar11 = (int32_t *)0x0;
    uVar1 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar1 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bea9;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bec1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bed3;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
        goto code_r0x00018025bf7f;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_R14;
    if (piVar10 != (int32_t *)0x0) {
        if (((*piVar10 == 0x80) && (*(int64_t *)(piVar10 + 0xc) != 0)) &&
           (iVar9 = *(int64_t *)(piVar10 + 10), iVar9 != 0)) {
            iVar2 = *(int64_t *)(iVar9 + 0x10);
            *(undefined8 *)((int64_t)&arg_b8h + iVar7) = unaff_R13;
            iVar12 = 0x1805aadb1;
            if (iVar2 != 0) {
                iVar12 = iVar2;
            }
            if (*(int64_t *)(iVar9 + 0xa0) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf36;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf4e;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf6d;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                goto code_r0x00018025bf7f;
            }
            piVar8 = piVar11;
            if ((in_RDX == 0) || (piVar8 = (int32_t *)0x0, (uVar1 >> 9 & 1) != 0)) {
code_r0x00018025bfc4:
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc9;
                func_0x000180229b10();
                if (in_RDX != 0) goto code_r0x00018025bfce;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfb2;
                piVar8 = (int32_t *)func_0x000180258850(piVar10);
                if (piVar8 == (int32_t *)0x0) goto code_r0x00018025bfc4;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc2;
                func_0x000180229b10();
                piVar10 = piVar8;
code_r0x00018025bfce:
                piVar11 = *in_R8;
            }
            pcVar3 = *(code **)(iVar9 + 0xa0);
            uVar4 = *(undefined8 *)(piVar10 + 0xc);
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfe7;
            iVar6 = (*pcVar3)(uVar4, in_RDX, in_R8, piVar11);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bff2;
                iVar6 = func_0x000180229970();
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bffb;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c013;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                    *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c032;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                }
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c037;
            func_0x000180229900();
            if ((piVar8 == (int32_t *)0x0) && (in_RDX != 0)) {
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c057;
                func_0x000180258be0(piVar8);
            }
            goto code_r0x00018025bf7f;
        }
        if (*(int64_t *)(piVar10 + 0x1e) != 0) {
            if ((*(uint8_t *)(piVar10 + 0x28) & 1) != 0) {
                pcVar3 = *(code **)(*(int64_t *)(piVar10 + 0x1e) + 0xf8);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c083;
                iVar6 = (*pcVar3)(piVar10, in_RCX);
                if (iVar6 == 0) goto code_r0x00018025bf7f;
            }
            iVar9 = *(int64_t *)(piVar10 + 0x1e);
            piVar10[0x28] = piVar10[0x28] & 0xfffffffe;
            if ((*(uint8_t *)(iVar9 + 4) & 4) == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                if (in_RDX == 0) {
                    if (pcVar3 == (code *)0x0) {
                        uVar4 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c228;
                        iVar6 = func_0x00018020f800(uVar4);
                        if (0 < iVar6) {
                            *(int64_t *)((int64_t)&var_10h + iVar7) = (int64_t)iVar6;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c243;
                            func_0x000180247c50(piVar10, 0, in_R8, 0);
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c211;
                        (*pcVar3)(piVar10, 0, in_R8, in_RCX);
                    }
                } else {
                    uVar1 = *(uint32_t *)(in_RCX + 0x18);
                    *(undefined4 *)((int64_t)aiStackX_10 + iVar7 + -0x10) = 0;
                    if ((uVar1 & 0x200) == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c16a;
                        iVar9 = func_0x000180215470();
                        if (iVar9 == 0) goto code_r0x00018025bf7f;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c181;
                        iVar6 = func_0x000180214b00(iVar9, in_RCX);
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c18d;
                            func_0x000180215310(iVar9);
                            goto code_r0x00018025bf7f;
                        }
                        if (pcVar3 == (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1c5;
                            iVar6 = func_0x0001802146d0(iVar9, (int64_t)aiStackX_10 + iVar7, 
                                                        (int64_t)aiStackX_10 + iVar7 + -0x10);
                        } else {
                            iVar2 = *(int64_t *)(iVar9 + 0x28);
                            pcVar5 = *(code **)(*(int64_t *)(iVar2 + 0x78) + 0x78);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1b1;
                            iVar6 = (*pcVar5)(iVar2, in_RDX, in_R8, iVar9);
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1cf;
                        func_0x000180215310(iVar9);
                        if (pcVar3 != (code *)0x0) goto code_r0x00018025bf7f;
                    } else {
                        if (pcVar3 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c146;
                            (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                            goto code_r0x00018025bf7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c161;
                        iVar6 = func_0x0001802146d0(in_RCX, (int64_t)aiStackX_10 + iVar7, 
                                                    (int64_t)aiStackX_10 + iVar7 + -0x10);
                    }
                    if (iVar6 != 0) {
                        *(uint64_t *)((int64_t)&var_10h + iVar7) =
                             (uint64_t)*(uint32_t *)((int64_t)aiStackX_10 + iVar7 + -0x10);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1fc;
                        func_0x000180247c50(piVar10, in_RDX, in_R8, (int64_t)aiStackX_10 + iVar7);
                    }
                }
            } else if (in_RDX == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0b3;
                (*pcVar3)(piVar10, 0, in_R8, in_RCX);
            } else if ((*(uint32_t *)(in_RCX + 0x18) & 0x200) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0e3;
                iVar9 = func_0x000180258850(piVar10);
                if (iVar9 != 0) {
                    pcVar3 = *(code **)(*(int64_t *)(iVar9 + 0x78) + 0x78);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c106;
                    (*pcVar3)(iVar9, in_RDX, in_R8, in_RCX);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c110;
                    func_0x000180258be0(iVar9);
                }
            } else {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0d0;
                (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            }
            goto code_r0x00018025bf7f;
        }
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c256;
    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c26e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c280;
    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
code_r0x00018025bf7f:
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf8f;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18025bf15
// Address: 0x18025bf15
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18025be60(int64_t arg_50h, int64_t arg_60h, int64_t arg_b8h)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t *piVar10;
    int32_t **in_R8;
    int32_t *piVar11;
    undefined8 unaff_R13;
    int64_t iVar12;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t aiStackX_10 [3];
    undefined8 uStack_38;
    int64_t var_10h;
    
    uStack_38 = 0x18025be73;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_50h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7);
    piVar10 = *(int32_t **)(in_RCX + 0x28);
    piVar11 = (int32_t *)0x0;
    uVar1 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar1 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bea9;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bec1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bed3;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
        goto code_r0x00018025bf7f;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_R14;
    if (piVar10 != (int32_t *)0x0) {
        if (((*piVar10 == 0x80) && (*(int64_t *)(piVar10 + 0xc) != 0)) &&
           (iVar9 = *(int64_t *)(piVar10 + 10), iVar9 != 0)) {
            iVar2 = *(int64_t *)(iVar9 + 0x10);
            *(undefined8 *)((int64_t)&arg_b8h + iVar7) = unaff_R13;
            iVar12 = 0x1805aadb1;
            if (iVar2 != 0) {
                iVar12 = iVar2;
            }
            if (*(int64_t *)(iVar9 + 0xa0) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf36;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf4e;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf6d;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                goto code_r0x00018025bf7f;
            }
            piVar8 = piVar11;
            if ((in_RDX == 0) || (piVar8 = (int32_t *)0x0, (uVar1 >> 9 & 1) != 0)) {
code_r0x00018025bfc4:
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc9;
                func_0x000180229b10();
                if (in_RDX != 0) goto code_r0x00018025bfce;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfb2;
                piVar8 = (int32_t *)func_0x000180258850(piVar10);
                if (piVar8 == (int32_t *)0x0) goto code_r0x00018025bfc4;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc2;
                func_0x000180229b10();
                piVar10 = piVar8;
code_r0x00018025bfce:
                piVar11 = *in_R8;
            }
            pcVar3 = *(code **)(iVar9 + 0xa0);
            uVar4 = *(undefined8 *)(piVar10 + 0xc);
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfe7;
            iVar6 = (*pcVar3)(uVar4, in_RDX, in_R8, piVar11);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bff2;
                iVar6 = func_0x000180229970();
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bffb;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c013;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                    *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c032;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                }
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c037;
            func_0x000180229900();
            if ((piVar8 == (int32_t *)0x0) && (in_RDX != 0)) {
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c057;
                func_0x000180258be0(piVar8);
            }
            goto code_r0x00018025bf7f;
        }
        if (*(int64_t *)(piVar10 + 0x1e) != 0) {
            if ((*(uint8_t *)(piVar10 + 0x28) & 1) != 0) {
                pcVar3 = *(code **)(*(int64_t *)(piVar10 + 0x1e) + 0xf8);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c083;
                iVar6 = (*pcVar3)(piVar10, in_RCX);
                if (iVar6 == 0) goto code_r0x00018025bf7f;
            }
            iVar9 = *(int64_t *)(piVar10 + 0x1e);
            piVar10[0x28] = piVar10[0x28] & 0xfffffffe;
            if ((*(uint8_t *)(iVar9 + 4) & 4) == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                if (in_RDX == 0) {
                    if (pcVar3 == (code *)0x0) {
                        uVar4 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c228;
                        iVar6 = func_0x00018020f800(uVar4);
                        if (0 < iVar6) {
                            *(int64_t *)((int64_t)&var_10h + iVar7) = (int64_t)iVar6;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c243;
                            func_0x000180247c50(piVar10, 0, in_R8, 0);
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c211;
                        (*pcVar3)(piVar10, 0, in_R8, in_RCX);
                    }
                } else {
                    uVar1 = *(uint32_t *)(in_RCX + 0x18);
                    *(undefined4 *)((int64_t)aiStackX_10 + iVar7 + -0x10) = 0;
                    if ((uVar1 & 0x200) == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c16a;
                        iVar9 = func_0x000180215470();
                        if (iVar9 == 0) goto code_r0x00018025bf7f;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c181;
                        iVar6 = func_0x000180214b00(iVar9, in_RCX);
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c18d;
                            func_0x000180215310(iVar9);
                            goto code_r0x00018025bf7f;
                        }
                        if (pcVar3 == (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1c5;
                            iVar6 = func_0x0001802146d0(iVar9, (int64_t)aiStackX_10 + iVar7, 
                                                        (int64_t)aiStackX_10 + iVar7 + -0x10);
                        } else {
                            iVar2 = *(int64_t *)(iVar9 + 0x28);
                            pcVar5 = *(code **)(*(int64_t *)(iVar2 + 0x78) + 0x78);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1b1;
                            iVar6 = (*pcVar5)(iVar2, in_RDX, in_R8, iVar9);
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1cf;
                        func_0x000180215310(iVar9);
                        if (pcVar3 != (code *)0x0) goto code_r0x00018025bf7f;
                    } else {
                        if (pcVar3 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c146;
                            (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                            goto code_r0x00018025bf7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c161;
                        iVar6 = func_0x0001802146d0(in_RCX, (int64_t)aiStackX_10 + iVar7, 
                                                    (int64_t)aiStackX_10 + iVar7 + -0x10);
                    }
                    if (iVar6 != 0) {
                        *(uint64_t *)((int64_t)&var_10h + iVar7) =
                             (uint64_t)*(uint32_t *)((int64_t)aiStackX_10 + iVar7 + -0x10);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1fc;
                        func_0x000180247c50(piVar10, in_RDX, in_R8, (int64_t)aiStackX_10 + iVar7);
                    }
                }
            } else if (in_RDX == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0b3;
                (*pcVar3)(piVar10, 0, in_R8, in_RCX);
            } else if ((*(uint32_t *)(in_RCX + 0x18) & 0x200) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0e3;
                iVar9 = func_0x000180258850(piVar10);
                if (iVar9 != 0) {
                    pcVar3 = *(code **)(*(int64_t *)(iVar9 + 0x78) + 0x78);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c106;
                    (*pcVar3)(iVar9, in_RDX, in_R8, in_RCX);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c110;
                    func_0x000180258be0(iVar9);
                }
            } else {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0d0;
                (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            }
            goto code_r0x00018025bf7f;
        }
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c256;
    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c26e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c280;
    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
code_r0x00018025bf7f:
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf8f;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18025bf77
// Address: 0x18025bf77
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18025be60(int64_t arg_50h, int64_t arg_60h, int64_t arg_b8h)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t *piVar10;
    int32_t **in_R8;
    int32_t *piVar11;
    undefined8 unaff_R13;
    int64_t iVar12;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t aiStackX_10 [3];
    undefined8 uStack_38;
    int64_t var_10h;
    
    uStack_38 = 0x18025be73;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_50h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7);
    piVar10 = *(int32_t **)(in_RCX + 0x28);
    piVar11 = (int32_t *)0x0;
    uVar1 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar1 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bea9;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bec1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bed3;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
        goto code_r0x00018025bf7f;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_R14;
    if (piVar10 != (int32_t *)0x0) {
        if (((*piVar10 == 0x80) && (*(int64_t *)(piVar10 + 0xc) != 0)) &&
           (iVar9 = *(int64_t *)(piVar10 + 10), iVar9 != 0)) {
            iVar2 = *(int64_t *)(iVar9 + 0x10);
            *(undefined8 *)((int64_t)&arg_b8h + iVar7) = unaff_R13;
            iVar12 = 0x1805aadb1;
            if (iVar2 != 0) {
                iVar12 = iVar2;
            }
            if (*(int64_t *)(iVar9 + 0xa0) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf36;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf4e;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf6d;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                goto code_r0x00018025bf7f;
            }
            piVar8 = piVar11;
            if ((in_RDX == 0) || (piVar8 = (int32_t *)0x0, (uVar1 >> 9 & 1) != 0)) {
code_r0x00018025bfc4:
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc9;
                func_0x000180229b10();
                if (in_RDX != 0) goto code_r0x00018025bfce;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfb2;
                piVar8 = (int32_t *)func_0x000180258850(piVar10);
                if (piVar8 == (int32_t *)0x0) goto code_r0x00018025bfc4;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc2;
                func_0x000180229b10();
                piVar10 = piVar8;
code_r0x00018025bfce:
                piVar11 = *in_R8;
            }
            pcVar3 = *(code **)(iVar9 + 0xa0);
            uVar4 = *(undefined8 *)(piVar10 + 0xc);
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfe7;
            iVar6 = (*pcVar3)(uVar4, in_RDX, in_R8, piVar11);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bff2;
                iVar6 = func_0x000180229970();
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bffb;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c013;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                    *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c032;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                }
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c037;
            func_0x000180229900();
            if ((piVar8 == (int32_t *)0x0) && (in_RDX != 0)) {
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c057;
                func_0x000180258be0(piVar8);
            }
            goto code_r0x00018025bf7f;
        }
        if (*(int64_t *)(piVar10 + 0x1e) != 0) {
            if ((*(uint8_t *)(piVar10 + 0x28) & 1) != 0) {
                pcVar3 = *(code **)(*(int64_t *)(piVar10 + 0x1e) + 0xf8);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c083;
                iVar6 = (*pcVar3)(piVar10, in_RCX);
                if (iVar6 == 0) goto code_r0x00018025bf7f;
            }
            iVar9 = *(int64_t *)(piVar10 + 0x1e);
            piVar10[0x28] = piVar10[0x28] & 0xfffffffe;
            if ((*(uint8_t *)(iVar9 + 4) & 4) == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                if (in_RDX == 0) {
                    if (pcVar3 == (code *)0x0) {
                        uVar4 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c228;
                        iVar6 = func_0x00018020f800(uVar4);
                        if (0 < iVar6) {
                            *(int64_t *)((int64_t)&var_10h + iVar7) = (int64_t)iVar6;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c243;
                            func_0x000180247c50(piVar10, 0, in_R8, 0);
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c211;
                        (*pcVar3)(piVar10, 0, in_R8, in_RCX);
                    }
                } else {
                    uVar1 = *(uint32_t *)(in_RCX + 0x18);
                    *(undefined4 *)((int64_t)aiStackX_10 + iVar7 + -0x10) = 0;
                    if ((uVar1 & 0x200) == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c16a;
                        iVar9 = func_0x000180215470();
                        if (iVar9 == 0) goto code_r0x00018025bf7f;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c181;
                        iVar6 = func_0x000180214b00(iVar9, in_RCX);
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c18d;
                            func_0x000180215310(iVar9);
                            goto code_r0x00018025bf7f;
                        }
                        if (pcVar3 == (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1c5;
                            iVar6 = func_0x0001802146d0(iVar9, (int64_t)aiStackX_10 + iVar7, 
                                                        (int64_t)aiStackX_10 + iVar7 + -0x10);
                        } else {
                            iVar2 = *(int64_t *)(iVar9 + 0x28);
                            pcVar5 = *(code **)(*(int64_t *)(iVar2 + 0x78) + 0x78);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1b1;
                            iVar6 = (*pcVar5)(iVar2, in_RDX, in_R8, iVar9);
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1cf;
                        func_0x000180215310(iVar9);
                        if (pcVar3 != (code *)0x0) goto code_r0x00018025bf7f;
                    } else {
                        if (pcVar3 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c146;
                            (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                            goto code_r0x00018025bf7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c161;
                        iVar6 = func_0x0001802146d0(in_RCX, (int64_t)aiStackX_10 + iVar7, 
                                                    (int64_t)aiStackX_10 + iVar7 + -0x10);
                    }
                    if (iVar6 != 0) {
                        *(uint64_t *)((int64_t)&var_10h + iVar7) =
                             (uint64_t)*(uint32_t *)((int64_t)aiStackX_10 + iVar7 + -0x10);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1fc;
                        func_0x000180247c50(piVar10, in_RDX, in_R8, (int64_t)aiStackX_10 + iVar7);
                    }
                }
            } else if (in_RDX == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0b3;
                (*pcVar3)(piVar10, 0, in_R8, in_RCX);
            } else if ((*(uint32_t *)(in_RCX + 0x18) & 0x200) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0e3;
                iVar9 = func_0x000180258850(piVar10);
                if (iVar9 != 0) {
                    pcVar3 = *(code **)(*(int64_t *)(iVar9 + 0x78) + 0x78);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c106;
                    (*pcVar3)(iVar9, in_RDX, in_R8, in_RCX);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c110;
                    func_0x000180258be0(iVar9);
                }
            } else {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0d0;
                (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            }
            goto code_r0x00018025bf7f;
        }
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c256;
    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c26e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c280;
    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
code_r0x00018025bf7f:
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf8f;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18025bf7f
// Address: 0x18025bf7f
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18025be60(int64_t arg_50h, int64_t arg_60h, int64_t arg_b8h)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t *piVar10;
    int32_t **in_R8;
    int32_t *piVar11;
    undefined8 unaff_R13;
    int64_t iVar12;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t aiStackX_10 [3];
    undefined8 uStack_38;
    int64_t var_10h;
    
    uStack_38 = 0x18025be73;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_50h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7);
    piVar10 = *(int32_t **)(in_RCX + 0x28);
    piVar11 = (int32_t *)0x0;
    uVar1 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar1 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bea9;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bec1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bed3;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
        goto code_r0x00018025bf7f;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_R14;
    if (piVar10 != (int32_t *)0x0) {
        if (((*piVar10 == 0x80) && (*(int64_t *)(piVar10 + 0xc) != 0)) &&
           (iVar9 = *(int64_t *)(piVar10 + 10), iVar9 != 0)) {
            iVar2 = *(int64_t *)(iVar9 + 0x10);
            *(undefined8 *)((int64_t)&arg_b8h + iVar7) = unaff_R13;
            iVar12 = 0x1805aadb1;
            if (iVar2 != 0) {
                iVar12 = iVar2;
            }
            if (*(int64_t *)(iVar9 + 0xa0) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf36;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf4e;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf6d;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                goto code_r0x00018025bf7f;
            }
            piVar8 = piVar11;
            if ((in_RDX == 0) || (piVar8 = (int32_t *)0x0, (uVar1 >> 9 & 1) != 0)) {
code_r0x00018025bfc4:
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc9;
                func_0x000180229b10();
                if (in_RDX != 0) goto code_r0x00018025bfce;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfb2;
                piVar8 = (int32_t *)func_0x000180258850(piVar10);
                if (piVar8 == (int32_t *)0x0) goto code_r0x00018025bfc4;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc2;
                func_0x000180229b10();
                piVar10 = piVar8;
code_r0x00018025bfce:
                piVar11 = *in_R8;
            }
            pcVar3 = *(code **)(iVar9 + 0xa0);
            uVar4 = *(undefined8 *)(piVar10 + 0xc);
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfe7;
            iVar6 = (*pcVar3)(uVar4, in_RDX, in_R8, piVar11);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bff2;
                iVar6 = func_0x000180229970();
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bffb;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c013;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                    *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c032;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                }
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c037;
            func_0x000180229900();
            if ((piVar8 == (int32_t *)0x0) && (in_RDX != 0)) {
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c057;
                func_0x000180258be0(piVar8);
            }
            goto code_r0x00018025bf7f;
        }
        if (*(int64_t *)(piVar10 + 0x1e) != 0) {
            if ((*(uint8_t *)(piVar10 + 0x28) & 1) != 0) {
                pcVar3 = *(code **)(*(int64_t *)(piVar10 + 0x1e) + 0xf8);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c083;
                iVar6 = (*pcVar3)(piVar10, in_RCX);
                if (iVar6 == 0) goto code_r0x00018025bf7f;
            }
            iVar9 = *(int64_t *)(piVar10 + 0x1e);
            piVar10[0x28] = piVar10[0x28] & 0xfffffffe;
            if ((*(uint8_t *)(iVar9 + 4) & 4) == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                if (in_RDX == 0) {
                    if (pcVar3 == (code *)0x0) {
                        uVar4 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c228;
                        iVar6 = func_0x00018020f800(uVar4);
                        if (0 < iVar6) {
                            *(int64_t *)((int64_t)&var_10h + iVar7) = (int64_t)iVar6;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c243;
                            func_0x000180247c50(piVar10, 0, in_R8, 0);
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c211;
                        (*pcVar3)(piVar10, 0, in_R8, in_RCX);
                    }
                } else {
                    uVar1 = *(uint32_t *)(in_RCX + 0x18);
                    *(undefined4 *)((int64_t)aiStackX_10 + iVar7 + -0x10) = 0;
                    if ((uVar1 & 0x200) == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c16a;
                        iVar9 = func_0x000180215470();
                        if (iVar9 == 0) goto code_r0x00018025bf7f;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c181;
                        iVar6 = func_0x000180214b00(iVar9, in_RCX);
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c18d;
                            func_0x000180215310(iVar9);
                            goto code_r0x00018025bf7f;
                        }
                        if (pcVar3 == (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1c5;
                            iVar6 = func_0x0001802146d0(iVar9, (int64_t)aiStackX_10 + iVar7, 
                                                        (int64_t)aiStackX_10 + iVar7 + -0x10);
                        } else {
                            iVar2 = *(int64_t *)(iVar9 + 0x28);
                            pcVar5 = *(code **)(*(int64_t *)(iVar2 + 0x78) + 0x78);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1b1;
                            iVar6 = (*pcVar5)(iVar2, in_RDX, in_R8, iVar9);
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1cf;
                        func_0x000180215310(iVar9);
                        if (pcVar3 != (code *)0x0) goto code_r0x00018025bf7f;
                    } else {
                        if (pcVar3 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c146;
                            (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                            goto code_r0x00018025bf7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c161;
                        iVar6 = func_0x0001802146d0(in_RCX, (int64_t)aiStackX_10 + iVar7, 
                                                    (int64_t)aiStackX_10 + iVar7 + -0x10);
                    }
                    if (iVar6 != 0) {
                        *(uint64_t *)((int64_t)&var_10h + iVar7) =
                             (uint64_t)*(uint32_t *)((int64_t)aiStackX_10 + iVar7 + -0x10);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1fc;
                        func_0x000180247c50(piVar10, in_RDX, in_R8, (int64_t)aiStackX_10 + iVar7);
                    }
                }
            } else if (in_RDX == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0b3;
                (*pcVar3)(piVar10, 0, in_R8, in_RCX);
            } else if ((*(uint32_t *)(in_RCX + 0x18) & 0x200) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0e3;
                iVar9 = func_0x000180258850(piVar10);
                if (iVar9 != 0) {
                    pcVar3 = *(code **)(*(int64_t *)(iVar9 + 0x78) + 0x78);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c106;
                    (*pcVar3)(iVar9, in_RDX, in_R8, in_RCX);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c110;
                    func_0x000180258be0(iVar9);
                }
            } else {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0d0;
                (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            }
            goto code_r0x00018025bf7f;
        }
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c256;
    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c26e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c280;
    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
code_r0x00018025bf7f:
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf8f;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18025bf9f
// Address: 0x18025bf9f
// Size: 191 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18025be60(int64_t arg_50h, int64_t arg_60h, int64_t arg_b8h)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t *piVar10;
    int32_t **in_R8;
    int32_t *piVar11;
    undefined8 unaff_R13;
    int64_t iVar12;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t aiStackX_10 [3];
    undefined8 uStack_38;
    int64_t var_10h;
    
    uStack_38 = 0x18025be73;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_50h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7);
    piVar10 = *(int32_t **)(in_RCX + 0x28);
    piVar11 = (int32_t *)0x0;
    uVar1 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar1 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bea9;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bec1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bed3;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
        goto code_r0x00018025bf7f;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_R14;
    if (piVar10 != (int32_t *)0x0) {
        if (((*piVar10 == 0x80) && (*(int64_t *)(piVar10 + 0xc) != 0)) &&
           (iVar9 = *(int64_t *)(piVar10 + 10), iVar9 != 0)) {
            iVar2 = *(int64_t *)(iVar9 + 0x10);
            *(undefined8 *)((int64_t)&arg_b8h + iVar7) = unaff_R13;
            iVar12 = 0x1805aadb1;
            if (iVar2 != 0) {
                iVar12 = iVar2;
            }
            if (*(int64_t *)(iVar9 + 0xa0) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf36;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf4e;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf6d;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                goto code_r0x00018025bf7f;
            }
            piVar8 = piVar11;
            if ((in_RDX == 0) || (piVar8 = (int32_t *)0x0, (uVar1 >> 9 & 1) != 0)) {
code_r0x00018025bfc4:
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc9;
                func_0x000180229b10();
                if (in_RDX != 0) goto code_r0x00018025bfce;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfb2;
                piVar8 = (int32_t *)func_0x000180258850(piVar10);
                if (piVar8 == (int32_t *)0x0) goto code_r0x00018025bfc4;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc2;
                func_0x000180229b10();
                piVar10 = piVar8;
code_r0x00018025bfce:
                piVar11 = *in_R8;
            }
            pcVar3 = *(code **)(iVar9 + 0xa0);
            uVar4 = *(undefined8 *)(piVar10 + 0xc);
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfe7;
            iVar6 = (*pcVar3)(uVar4, in_RDX, in_R8, piVar11);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bff2;
                iVar6 = func_0x000180229970();
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bffb;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c013;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                    *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c032;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                }
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c037;
            func_0x000180229900();
            if ((piVar8 == (int32_t *)0x0) && (in_RDX != 0)) {
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c057;
                func_0x000180258be0(piVar8);
            }
            goto code_r0x00018025bf7f;
        }
        if (*(int64_t *)(piVar10 + 0x1e) != 0) {
            if ((*(uint8_t *)(piVar10 + 0x28) & 1) != 0) {
                pcVar3 = *(code **)(*(int64_t *)(piVar10 + 0x1e) + 0xf8);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c083;
                iVar6 = (*pcVar3)(piVar10, in_RCX);
                if (iVar6 == 0) goto code_r0x00018025bf7f;
            }
            iVar9 = *(int64_t *)(piVar10 + 0x1e);
            piVar10[0x28] = piVar10[0x28] & 0xfffffffe;
            if ((*(uint8_t *)(iVar9 + 4) & 4) == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                if (in_RDX == 0) {
                    if (pcVar3 == (code *)0x0) {
                        uVar4 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c228;
                        iVar6 = func_0x00018020f800(uVar4);
                        if (0 < iVar6) {
                            *(int64_t *)((int64_t)&var_10h + iVar7) = (int64_t)iVar6;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c243;
                            func_0x000180247c50(piVar10, 0, in_R8, 0);
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c211;
                        (*pcVar3)(piVar10, 0, in_R8, in_RCX);
                    }
                } else {
                    uVar1 = *(uint32_t *)(in_RCX + 0x18);
                    *(undefined4 *)((int64_t)aiStackX_10 + iVar7 + -0x10) = 0;
                    if ((uVar1 & 0x200) == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c16a;
                        iVar9 = func_0x000180215470();
                        if (iVar9 == 0) goto code_r0x00018025bf7f;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c181;
                        iVar6 = func_0x000180214b00(iVar9, in_RCX);
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c18d;
                            func_0x000180215310(iVar9);
                            goto code_r0x00018025bf7f;
                        }
                        if (pcVar3 == (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1c5;
                            iVar6 = func_0x0001802146d0(iVar9, (int64_t)aiStackX_10 + iVar7, 
                                                        (int64_t)aiStackX_10 + iVar7 + -0x10);
                        } else {
                            iVar2 = *(int64_t *)(iVar9 + 0x28);
                            pcVar5 = *(code **)(*(int64_t *)(iVar2 + 0x78) + 0x78);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1b1;
                            iVar6 = (*pcVar5)(iVar2, in_RDX, in_R8, iVar9);
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1cf;
                        func_0x000180215310(iVar9);
                        if (pcVar3 != (code *)0x0) goto code_r0x00018025bf7f;
                    } else {
                        if (pcVar3 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c146;
                            (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                            goto code_r0x00018025bf7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c161;
                        iVar6 = func_0x0001802146d0(in_RCX, (int64_t)aiStackX_10 + iVar7, 
                                                    (int64_t)aiStackX_10 + iVar7 + -0x10);
                    }
                    if (iVar6 != 0) {
                        *(uint64_t *)((int64_t)&var_10h + iVar7) =
                             (uint64_t)*(uint32_t *)((int64_t)aiStackX_10 + iVar7 + -0x10);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1fc;
                        func_0x000180247c50(piVar10, in_RDX, in_R8, (int64_t)aiStackX_10 + iVar7);
                    }
                }
            } else if (in_RDX == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0b3;
                (*pcVar3)(piVar10, 0, in_R8, in_RCX);
            } else if ((*(uint32_t *)(in_RCX + 0x18) & 0x200) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0e3;
                iVar9 = func_0x000180258850(piVar10);
                if (iVar9 != 0) {
                    pcVar3 = *(code **)(*(int64_t *)(iVar9 + 0x78) + 0x78);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c106;
                    (*pcVar3)(iVar9, in_RDX, in_R8, in_RCX);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c110;
                    func_0x000180258be0(iVar9);
                }
            } else {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0d0;
                (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            }
            goto code_r0x00018025bf7f;
        }
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c256;
    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c26e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c280;
    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
code_r0x00018025bf7f:
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf8f;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18025c05e
// Address: 0x18025c05e
// Size: 553 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18025be60(int64_t arg_50h, int64_t arg_60h, int64_t arg_b8h)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t *piVar10;
    int32_t **in_R8;
    int32_t *piVar11;
    undefined8 unaff_R13;
    int64_t iVar12;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t aiStackX_10 [3];
    undefined8 uStack_38;
    int64_t var_10h;
    
    uStack_38 = 0x18025be73;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_50h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7);
    piVar10 = *(int32_t **)(in_RCX + 0x28);
    piVar11 = (int32_t *)0x0;
    uVar1 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar1 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bea9;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bec1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bed3;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
        goto code_r0x00018025bf7f;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_R14;
    if (piVar10 != (int32_t *)0x0) {
        if (((*piVar10 == 0x80) && (*(int64_t *)(piVar10 + 0xc) != 0)) &&
           (iVar9 = *(int64_t *)(piVar10 + 10), iVar9 != 0)) {
            iVar2 = *(int64_t *)(iVar9 + 0x10);
            *(undefined8 *)((int64_t)&arg_b8h + iVar7) = unaff_R13;
            iVar12 = 0x1805aadb1;
            if (iVar2 != 0) {
                iVar12 = iVar2;
            }
            if (*(int64_t *)(iVar9 + 0xa0) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf36;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf4e;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf6d;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                goto code_r0x00018025bf7f;
            }
            piVar8 = piVar11;
            if ((in_RDX == 0) || (piVar8 = (int32_t *)0x0, (uVar1 >> 9 & 1) != 0)) {
code_r0x00018025bfc4:
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc9;
                func_0x000180229b10();
                if (in_RDX != 0) goto code_r0x00018025bfce;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfb2;
                piVar8 = (int32_t *)func_0x000180258850(piVar10);
                if (piVar8 == (int32_t *)0x0) goto code_r0x00018025bfc4;
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfc2;
                func_0x000180229b10();
                piVar10 = piVar8;
code_r0x00018025bfce:
                piVar11 = *in_R8;
            }
            pcVar3 = *(code **)(iVar9 + 0xa0);
            uVar4 = *(undefined8 *)(piVar10 + 0xc);
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bfe7;
            iVar6 = (*pcVar3)(uVar4, in_RDX, in_R8, piVar11);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bff2;
                iVar6 = func_0x000180229970();
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bffb;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c013;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
                    *(int64_t *)((int64_t)&var_10h + iVar7) = iVar12;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c032;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
                }
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c037;
            func_0x000180229900();
            if ((piVar8 == (int32_t *)0x0) && (in_RDX != 0)) {
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c057;
                func_0x000180258be0(piVar8);
            }
            goto code_r0x00018025bf7f;
        }
        if (*(int64_t *)(piVar10 + 0x1e) != 0) {
            if ((*(uint8_t *)(piVar10 + 0x28) & 1) != 0) {
                pcVar3 = *(code **)(*(int64_t *)(piVar10 + 0x1e) + 0xf8);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c083;
                iVar6 = (*pcVar3)(piVar10, in_RCX);
                if (iVar6 == 0) goto code_r0x00018025bf7f;
            }
            iVar9 = *(int64_t *)(piVar10 + 0x1e);
            piVar10[0x28] = piVar10[0x28] & 0xfffffffe;
            if ((*(uint8_t *)(iVar9 + 4) & 4) == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                if (in_RDX == 0) {
                    if (pcVar3 == (code *)0x0) {
                        uVar4 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c228;
                        iVar6 = func_0x00018020f800(uVar4);
                        if (0 < iVar6) {
                            *(int64_t *)((int64_t)&var_10h + iVar7) = (int64_t)iVar6;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c243;
                            func_0x000180247c50(piVar10, 0, in_R8, 0);
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c211;
                        (*pcVar3)(piVar10, 0, in_R8, in_RCX);
                    }
                } else {
                    uVar1 = *(uint32_t *)(in_RCX + 0x18);
                    *(undefined4 *)((int64_t)aiStackX_10 + iVar7 + -0x10) = 0;
                    if ((uVar1 & 0x200) == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c16a;
                        iVar9 = func_0x000180215470();
                        if (iVar9 == 0) goto code_r0x00018025bf7f;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c181;
                        iVar6 = func_0x000180214b00(iVar9, in_RCX);
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c18d;
                            func_0x000180215310(iVar9);
                            goto code_r0x00018025bf7f;
                        }
                        if (pcVar3 == (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1c5;
                            iVar6 = func_0x0001802146d0(iVar9, (int64_t)aiStackX_10 + iVar7, 
                                                        (int64_t)aiStackX_10 + iVar7 + -0x10);
                        } else {
                            iVar2 = *(int64_t *)(iVar9 + 0x28);
                            pcVar5 = *(code **)(*(int64_t *)(iVar2 + 0x78) + 0x78);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1b1;
                            iVar6 = (*pcVar5)(iVar2, in_RDX, in_R8, iVar9);
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1cf;
                        func_0x000180215310(iVar9);
                        if (pcVar3 != (code *)0x0) goto code_r0x00018025bf7f;
                    } else {
                        if (pcVar3 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c146;
                            (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                            goto code_r0x00018025bf7f;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c161;
                        iVar6 = func_0x0001802146d0(in_RCX, (int64_t)aiStackX_10 + iVar7, 
                                                    (int64_t)aiStackX_10 + iVar7 + -0x10);
                    }
                    if (iVar6 != 0) {
                        *(uint64_t *)((int64_t)&var_10h + iVar7) =
                             (uint64_t)*(uint32_t *)((int64_t)aiStackX_10 + iVar7 + -0x10);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c1fc;
                        func_0x000180247c50(piVar10, in_RDX, in_R8, (int64_t)aiStackX_10 + iVar7);
                    }
                }
            } else if (in_RDX == 0) {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0b3;
                (*pcVar3)(piVar10, 0, in_R8, in_RCX);
            } else if ((*(uint32_t *)(in_RCX + 0x18) & 0x200) == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0e3;
                iVar9 = func_0x000180258850(piVar10);
                if (iVar9 != 0) {
                    pcVar3 = *(code **)(*(int64_t *)(iVar9 + 0x78) + 0x78);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c106;
                    (*pcVar3)(iVar9, in_RDX, in_R8, in_RCX);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c110;
                    func_0x000180258be0(iVar9);
                }
            } else {
                pcVar3 = *(code **)(iVar9 + 0x78);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c0d0;
                (*pcVar3)(piVar10, in_RDX, in_R8, in_RCX);
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
            }
            goto code_r0x00018025bf7f;
        }
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c256;
    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c26e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + -0x10), *(int64_t *)((int64_t)&iStackX_8 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 0x10));
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025c280;
    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar7));
code_r0x00018025bf7f:
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x18025bf8f;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18025c290
// Address: 0x18025c290
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_5fh
// WARNING: [rz-ghidra] Detected overlap for variable var_5bh
// WARNING: [rz-ghidra] Detected overlap for variable var_59h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a7h

void fcn.18025c290(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_80h)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025c29a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = 0;
    *(undefined4 *)((int64_t)&arg_40h + iVar1) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = *(undefined8 *)((int64_t)&arg_80h + iVar1);
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025c2ce;
    fcn.18025cdf0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)((int64_t)&arg_40h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                  *(int64_t *)(&stack0x00000128 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18025c2e0
// Address: 0x18025c2e0
// Size: 86 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_5fh
// WARNING: [rz-ghidra] Detected overlap for variable var_5bh
// WARNING: [rz-ghidra] Detected overlap for variable var_59h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a7h

void fcn.18025c2e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_90h)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025c2ea;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = *(undefined8 *)((int64_t)&arg_90h + iVar1);
    *(undefined4 *)((int64_t)&arg_40h + iVar1) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = *(undefined8 *)((int64_t)&arg_88h + iVar1);
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = *(undefined8 *)((int64_t)&arg_80h + iVar1);
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025c331;
    fcn.18025cdf0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)((int64_t)&arg_40h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                  *(int64_t *)(&stack0x00000128 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18025c340
// Address: 0x18025c340
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18025c340(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar9;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025c35b;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar1 = *(int32_t **)(in_RCX + 0x28);
    if ((*(uint32_t *)(in_RCX + 0x18) & 0x800) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c379;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c391;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c3a3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RDI;
    if (piVar1 != (int32_t *)0x0) {
        if (((*piVar1 == 0x80) && (*(int64_t *)(piVar1 + 0xc) != 0)) && (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0))
        {
            iVar9 = 0x1805aadb1;
            if (*(int64_t *)(iVar2 + 0x10) != 0) {
                iVar9 = *(int64_t *)(iVar2 + 0x10);
            }
            if (*(int64_t *)(iVar2 + 0x98) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c440;
                func_0x000180229b10();
                pcVar3 = *(code **)(iVar2 + 0x98);
                uVar4 = *(undefined8 *)(piVar1 + 0xc);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c453;
                uVar5 = (*pcVar3)(uVar4, in_RDX, in_R8);
                if ((int32_t)uVar5 < 1) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c45e;
                    iVar6 = func_0x000180229970();
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c467;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c47f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(int64_t *)((int64_t)&var_18h + iVar7) = iVar9;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c49e;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4a3;
                func_0x000180229900();
                return (uint64_t)uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c3fd;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c415;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(int64_t *)((int64_t)&var_18h + iVar7) = iVar9;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c434;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(piVar1 + 0x1e) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4b5;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4cd;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4df;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if ((*(uint8_t *)(piVar1 + 0x28) & 1) != 0) {
            pcVar3 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xf8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4fb;
            iVar6 = (*pcVar3)(piVar1, in_RCX);
            if (iVar6 == 0) {
                return 0;
            }
        }
        piVar1[0x28] = piVar1[0x28] & 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c514;
    uVar8 = func_0x0001802149b0(in_RCX, in_RDX, in_R8);
    return uVar8;
}

// ============================================================
// Function: FUN_18025c3aa
// Address: 0x18025c3aa
// Size: 367 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18025c340(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar9;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025c35b;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar1 = *(int32_t **)(in_RCX + 0x28);
    if ((*(uint32_t *)(in_RCX + 0x18) & 0x800) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c379;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c391;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c3a3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RDI;
    if (piVar1 != (int32_t *)0x0) {
        if (((*piVar1 == 0x80) && (*(int64_t *)(piVar1 + 0xc) != 0)) && (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0))
        {
            iVar9 = 0x1805aadb1;
            if (*(int64_t *)(iVar2 + 0x10) != 0) {
                iVar9 = *(int64_t *)(iVar2 + 0x10);
            }
            if (*(int64_t *)(iVar2 + 0x98) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c440;
                func_0x000180229b10();
                pcVar3 = *(code **)(iVar2 + 0x98);
                uVar4 = *(undefined8 *)(piVar1 + 0xc);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c453;
                uVar5 = (*pcVar3)(uVar4, in_RDX, in_R8);
                if ((int32_t)uVar5 < 1) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c45e;
                    iVar6 = func_0x000180229970();
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c467;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c47f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(int64_t *)((int64_t)&var_18h + iVar7) = iVar9;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c49e;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4a3;
                func_0x000180229900();
                return (uint64_t)uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c3fd;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c415;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(int64_t *)((int64_t)&var_18h + iVar7) = iVar9;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c434;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(piVar1 + 0x1e) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4b5;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4cd;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4df;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if ((*(uint8_t *)(piVar1 + 0x28) & 1) != 0) {
            pcVar3 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xf8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4fb;
            iVar6 = (*pcVar3)(piVar1, in_RCX);
            if (iVar6 == 0) {
                return 0;
            }
        }
        piVar1[0x28] = piVar1[0x28] & 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c514;
    uVar8 = func_0x0001802149b0(in_RCX, in_RDX, in_R8);
    return uVar8;
}

// ============================================================
// Function: FUN_18025c519
// Address: 0x18025c519
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18025c340(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar9;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025c35b;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar1 = *(int32_t **)(in_RCX + 0x28);
    if ((*(uint32_t *)(in_RCX + 0x18) & 0x800) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c379;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c391;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c3a3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RDI;
    if (piVar1 != (int32_t *)0x0) {
        if (((*piVar1 == 0x80) && (*(int64_t *)(piVar1 + 0xc) != 0)) && (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0))
        {
            iVar9 = 0x1805aadb1;
            if (*(int64_t *)(iVar2 + 0x10) != 0) {
                iVar9 = *(int64_t *)(iVar2 + 0x10);
            }
            if (*(int64_t *)(iVar2 + 0x98) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c440;
                func_0x000180229b10();
                pcVar3 = *(code **)(iVar2 + 0x98);
                uVar4 = *(undefined8 *)(piVar1 + 0xc);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c453;
                uVar5 = (*pcVar3)(uVar4, in_RDX, in_R8);
                if ((int32_t)uVar5 < 1) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c45e;
                    iVar6 = func_0x000180229970();
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c467;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c47f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(int64_t *)((int64_t)&var_18h + iVar7) = iVar9;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c49e;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4a3;
                func_0x000180229900();
                return (uint64_t)uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c3fd;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c415;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(int64_t *)((int64_t)&var_18h + iVar7) = iVar9;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c434;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(piVar1 + 0x1e) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4b5;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4cd;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4df;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if ((*(uint8_t *)(piVar1 + 0x28) & 1) != 0) {
            pcVar3 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xf8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c4fb;
            iVar6 = (*pcVar3)(piVar1, in_RCX);
            if (iVar6 == 0) {
                return 0;
            }
        }
        piVar1[0x28] = piVar1[0x28] & 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025c514;
    uVar8 = func_0x0001802149b0(in_RCX, in_RDX, in_R8);
    return uVar8;
}

// ============================================================
// Function: FUN_18025c530
// Address: 0x18025c530
// Size: 172 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18025c530(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t iVar10;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025c54a;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    piVar1 = *(int32_t **)(in_RCX + 0x28);
    if (piVar1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c567;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c57f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c591;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
        return 0xffffffff;
    }
    uVar5 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar5 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c5a9;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c5c1;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c5d3;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
        return 0;
    }
    iVar6 = *piVar1;
    *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_RSI;
    if (((iVar6 == 0x100) && (*(int64_t *)(piVar1 + 0xc) != 0)) && (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0)) {
        if (*(int64_t *)(iVar2 + 200) != 0) {
            iVar10 = 0x1805aadb1;
            if (*(int64_t *)(iVar2 + 0x10) != 0) {
                iVar10 = *(int64_t *)(iVar2 + 0x10);
            }
            *(uint32_t *)(in_RCX + 0x18) = uVar5 | 0x800;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c636;
            func_0x000180229b10();
            pcVar3 = *(code **)(iVar2 + 200);
            uVar4 = *(undefined8 *)(piVar1 + 0xc);
            *(undefined8 *)((int64_t)&iStackX_10 + iVar8 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c657;
            uVar5 = (*pcVar3)(uVar4, in_RDX, in_R8, in_R9);
            if ((int32_t)uVar5 < 1) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c662;
                iVar6 = func_0x000180229970();
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c66b;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c683;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
                    *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c6a2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c6a7;
            func_0x000180229900();
            return (uint64_t)uVar5;
        }
code_r0x00018025c6e7:
        if ((*(int64_t *)(piVar1 + 0xc) != 0) && (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0)) {
            iVar10 = 0x1805aadb1;
            if (*(int64_t *)(iVar2 + 0x10) != 0) {
                iVar10 = *(int64_t *)(iVar2 + 0x10);
            }
            if (*(int64_t *)(iVar2 + 0xb8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c720;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c738;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
                *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = iVar10;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c757;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                return 0xffffffff;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c766;
            func_0x000180229b10();
            pcVar3 = *(code **)(iVar2 + 0xb8);
            uVar4 = *(undefined8 *)(piVar1 + 0xc);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c77b;
            iVar6 = (*pcVar3)(uVar4, in_R9, *(undefined8 *)((int64_t)&arg_58h + iVar8));
            if (iVar6 < 1) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c786;
                iVar7 = func_0x000180229970();
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c78f;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c7a7;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
                    *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c7c6;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c7cb;
            func_0x000180229900();
            goto code_r0x00018025c807;
        }
    } else {
        if ((*(int64_t *)(piVar1 + 0x1e) != 0) &&
           (pcVar3 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xd8), pcVar3 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&iStackX_10 + iVar8 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c6d6;
            uVar9 = (*pcVar3)(in_RCX, in_RDX);
            return uVar9;
        }
        if (iVar6 == 0x100) goto code_r0x00018025c6e7;
    }
    if ((*(uint8_t *)(piVar1 + 0x28) & 1) != 0) {
        pcVar3 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xf8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c7ea;
        iVar6 = (*pcVar3)(piVar1, in_RCX);
        if (iVar6 == 0) {
            return 0xffffffff;
        }
    }
    piVar1[0x28] = piVar1[0x28] & 0xfffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c805;
    iVar6 = func_0x0001802149b0(in_RCX, in_R9, *(undefined8 *)((int64_t)&arg_58h + iVar8));
code_r0x00018025c807:
    if (iVar6 < 1) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c820;
    uVar9 = func_0x00018025c840(in_RCX, in_RDX, in_R8);
    return uVar9;
}

// ============================================================
// Function: FUN_18025c5dc
// Address: 0x18025c5dc
// Size: 590 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18025c530(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t iVar10;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025c54a;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    piVar1 = *(int32_t **)(in_RCX + 0x28);
    if (piVar1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c567;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c57f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c591;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
        return 0xffffffff;
    }
    uVar5 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar5 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c5a9;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c5c1;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c5d3;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
        return 0;
    }
    iVar6 = *piVar1;
    *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_RSI;
    if (((iVar6 == 0x100) && (*(int64_t *)(piVar1 + 0xc) != 0)) && (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0)) {
        if (*(int64_t *)(iVar2 + 200) != 0) {
            iVar10 = 0x1805aadb1;
            if (*(int64_t *)(iVar2 + 0x10) != 0) {
                iVar10 = *(int64_t *)(iVar2 + 0x10);
            }
            *(uint32_t *)(in_RCX + 0x18) = uVar5 | 0x800;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c636;
            func_0x000180229b10();
            pcVar3 = *(code **)(iVar2 + 200);
            uVar4 = *(undefined8 *)(piVar1 + 0xc);
            *(undefined8 *)((int64_t)&iStackX_10 + iVar8 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c657;
            uVar5 = (*pcVar3)(uVar4, in_RDX, in_R8, in_R9);
            if ((int32_t)uVar5 < 1) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c662;
                iVar6 = func_0x000180229970();
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c66b;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c683;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
                    *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c6a2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c6a7;
            func_0x000180229900();
            return (uint64_t)uVar5;
        }
code_r0x00018025c6e7:
        if ((*(int64_t *)(piVar1 + 0xc) != 0) && (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0)) {
            iVar10 = 0x1805aadb1;
            if (*(int64_t *)(iVar2 + 0x10) != 0) {
                iVar10 = *(int64_t *)(iVar2 + 0x10);
            }
            if (*(int64_t *)(iVar2 + 0xb8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c720;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c738;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
                *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = iVar10;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c757;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                return 0xffffffff;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c766;
            func_0x000180229b10();
            pcVar3 = *(code **)(iVar2 + 0xb8);
            uVar4 = *(undefined8 *)(piVar1 + 0xc);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c77b;
            iVar6 = (*pcVar3)(uVar4, in_R9, *(undefined8 *)((int64_t)&arg_58h + iVar8));
            if (iVar6 < 1) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c786;
                iVar7 = func_0x000180229970();
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c78f;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c7a7;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
                    *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c7c6;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c7cb;
            func_0x000180229900();
            goto code_r0x00018025c807;
        }
    } else {
        if ((*(int64_t *)(piVar1 + 0x1e) != 0) &&
           (pcVar3 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xd8), pcVar3 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&iStackX_10 + iVar8 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c6d6;
            uVar9 = (*pcVar3)(in_RCX, in_RDX);
            return uVar9;
        }
        if (iVar6 == 0x100) goto code_r0x00018025c6e7;
    }
    if ((*(uint8_t *)(piVar1 + 0x28) & 1) != 0) {
        pcVar3 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xf8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c7ea;
        iVar6 = (*pcVar3)(piVar1, in_RCX);
        if (iVar6 == 0) {
            return 0xffffffff;
        }
    }
    piVar1[0x28] = piVar1[0x28] & 0xfffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c805;
    iVar6 = func_0x0001802149b0(in_RCX, in_R9, *(undefined8 *)((int64_t)&arg_58h + iVar8));
code_r0x00018025c807:
    if (iVar6 < 1) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c820;
    uVar9 = func_0x00018025c840(in_RCX, in_RDX, in_R8);
    return uVar9;
}

// ============================================================
// Function: FUN_18025c82a
// Address: 0x18025c82a
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18025c530(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t iVar10;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025c54a;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    piVar1 = *(int32_t **)(in_RCX + 0x28);
    if (piVar1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c567;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c57f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c591;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
        return 0xffffffff;
    }
    uVar5 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar5 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c5a9;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c5c1;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c5d3;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
        return 0;
    }
    iVar6 = *piVar1;
    *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_RSI;
    if (((iVar6 == 0x100) && (*(int64_t *)(piVar1 + 0xc) != 0)) && (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0)) {
        if (*(int64_t *)(iVar2 + 200) != 0) {
            iVar10 = 0x1805aadb1;
            if (*(int64_t *)(iVar2 + 0x10) != 0) {
                iVar10 = *(int64_t *)(iVar2 + 0x10);
            }
            *(uint32_t *)(in_RCX + 0x18) = uVar5 | 0x800;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c636;
            func_0x000180229b10();
            pcVar3 = *(code **)(iVar2 + 200);
            uVar4 = *(undefined8 *)(piVar1 + 0xc);
            *(undefined8 *)((int64_t)&iStackX_10 + iVar8 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c657;
            uVar5 = (*pcVar3)(uVar4, in_RDX, in_R8, in_R9);
            if ((int32_t)uVar5 < 1) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c662;
                iVar6 = func_0x000180229970();
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c66b;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c683;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
                    *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c6a2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c6a7;
            func_0x000180229900();
            return (uint64_t)uVar5;
        }
code_r0x00018025c6e7:
        if ((*(int64_t *)(piVar1 + 0xc) != 0) && (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0)) {
            iVar10 = 0x1805aadb1;
            if (*(int64_t *)(iVar2 + 0x10) != 0) {
                iVar10 = *(int64_t *)(iVar2 + 0x10);
            }
            if (*(int64_t *)(iVar2 + 0xb8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c720;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c738;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
                *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = iVar10;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c757;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                return 0xffffffff;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c766;
            func_0x000180229b10();
            pcVar3 = *(code **)(iVar2 + 0xb8);
            uVar4 = *(undefined8 *)(piVar1 + 0xc);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c77b;
            iVar6 = (*pcVar3)(uVar4, in_R9, *(undefined8 *)((int64_t)&arg_58h + iVar8));
            if (iVar6 < 1) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c786;
                iVar7 = func_0x000180229970();
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c78f;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c7a7;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
                    *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c7c6;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar8));
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c7cb;
            func_0x000180229900();
            goto code_r0x00018025c807;
        }
    } else {
        if ((*(int64_t *)(piVar1 + 0x1e) != 0) &&
           (pcVar3 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xd8), pcVar3 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&iStackX_10 + iVar8 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c6d6;
            uVar9 = (*pcVar3)(in_RCX, in_RDX);
            return uVar9;
        }
        if (iVar6 == 0x100) goto code_r0x00018025c6e7;
    }
    if ((*(uint8_t *)(piVar1 + 0x28) & 1) != 0) {
        pcVar3 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xf8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c7ea;
        iVar6 = (*pcVar3)(piVar1, in_RCX);
        if (iVar6 == 0) {
            return 0xffffffff;
        }
    }
    piVar1[0x28] = piVar1[0x28] & 0xfffffffe;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c805;
    iVar6 = func_0x0001802149b0(in_RCX, in_R9, *(undefined8 *)((int64_t)&arg_58h + iVar8));
code_r0x00018025c807:
    if (iVar6 < 1) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18025c820;
    uVar9 = func_0x00018025c840(in_RCX, in_RDX, in_R8);
    return uVar9;
}

// ============================================================
// Function: FUN_18025c840
// Address: 0x18025c840
// Size: 121 bytes
// ============================================================
void fcn.18025c840(int64_t arg_58h, int64_t arg_68h, int64_t arg_70h)
{
    uint32_t uVar1;
    code *pcVar2;
    undefined8 uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t *piVar9;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    int64_t iVar10;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18025c852;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_58h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6);
    piVar9 = *(int32_t **)(in_RCX + 0x28);
    piVar7 = (int32_t *)0x0;
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -8) = 0;
    uVar1 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar1 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c888;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c8a0;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c8b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        goto code_r0x00018025cb52;
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_R14;
    if (piVar9 != (int32_t *)0x0) {
        if (((*piVar9 == 0x100) && (*(int64_t *)(piVar9 + 0xc) != 0)) && (iVar8 = *(int64_t *)(piVar9 + 10), iVar8 != 0)
           ) {
            iVar10 = 0x1805aadb1;
            if (*(int64_t *)(iVar8 + 0x10) != 0) {
                iVar10 = *(int64_t *)(iVar8 + 0x10);
            }
            if (*(int64_t *)(iVar8 + 0xc0) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c915;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c92d;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6));
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = iVar10;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c94c;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
            } else {
                if ((uVar1 >> 9 & 1) == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c95f;
                    piVar7 = (int32_t *)func_0x000180258850(piVar9);
                    if (piVar7 != (int32_t *)0x0) {
                        piVar9 = piVar7;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c96e;
                func_0x000180229b10();
                pcVar2 = *(code **)(iVar8 + 0xc0);
                uVar3 = *(undefined8 *)(piVar9 + 0xc);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c982;
                iVar5 = (*pcVar2)(uVar3, in_RDX, in_R8);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c98d;
                    iVar5 = func_0x000180229970();
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c996;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c9ae;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                        *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = iVar10;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c9cd;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c9d2;
                func_0x000180229900();
                if (piVar7 == (int32_t *)0x0) {
                    *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c9ed;
                    func_0x000180258be0(piVar7);
                }
            }
            goto code_r0x00018025cb52;
        }
        if (*(int64_t *)(piVar9 + 0x1e) != 0) {
            if ((*(uint8_t *)(piVar9 + 0x28) & 1) != 0) {
                pcVar2 = *(code **)(*(int64_t *)(piVar9 + 0x1e) + 0xf8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca19;
                iVar5 = (*pcVar2)(piVar9, in_RCX);
                if (iVar5 == 0) goto code_r0x00018025cb52;
            }
            piVar9[0x28] = piVar9[0x28] & 0xfffffffe;
            pcVar2 = *(code **)(*(int64_t *)(piVar9 + 0x1e) + 0x88);
            if ((*(uint32_t *)(in_RCX + 0x18) & 0x200) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca7b;
                iVar8 = func_0x000180215470();
                if (iVar8 == 0) goto code_r0x00018025cb52;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca8e;
                iVar5 = func_0x000180214b00(iVar8, in_RCX);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca9a;
                    func_0x000180215310(iVar8);
                    goto code_r0x00018025cb52;
                }
                if (pcVar2 == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cad8;
                    iVar5 = func_0x0001802146d0(iVar8, (int64_t)&var_18h + iVar6, (int64_t)&iStackX_10 + iVar6 + -8);
                } else {
                    iVar10 = *(int64_t *)(iVar8 + 0x28);
                    pcVar4 = *(code **)(*(int64_t *)(iVar10 + 0x78) + 0x88);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cac4;
                    iVar5 = (*pcVar4)(iVar10, in_RDX, in_R8 & 0xffffffff, iVar8);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cae2;
                func_0x000180215310(iVar8);
                if (pcVar2 != (code *)0x0) goto code_r0x00018025cb52;
            } else {
                if (pcVar2 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca50;
                    (*pcVar2)(piVar9, in_RDX, in_R8 & 0xffffffff, in_RCX);
                    *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
                    goto code_r0x00018025cb52;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca72;
                iVar5 = func_0x0001802146d0(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&iStackX_10 + iVar6 + -8);
            }
            if (iVar5 != 0) {
                *(uint64_t *)(&stack0xfffffffffffffff8 + iVar6) =
                     (uint64_t)*(uint32_t *)((int64_t)&iStackX_10 + iVar6 + -8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb0f;
                func_0x000180247f70(piVar9, in_RDX, in_R8, (int64_t)&var_18h + iVar6);
            }
            goto code_r0x00018025cb52;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb16;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb2e;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                  *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                  *(int64_t *)(&stack0x00000028 + iVar6));
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb40;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
code_r0x00018025cb52:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb62;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_18025c8b9
// Address: 0x18025c8b9
// Size: 665 bytes
// ============================================================
void fcn.18025c840(int64_t arg_58h, int64_t arg_68h, int64_t arg_70h)
{
    uint32_t uVar1;
    code *pcVar2;
    undefined8 uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t *piVar9;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    int64_t iVar10;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18025c852;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_58h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6);
    piVar9 = *(int32_t **)(in_RCX + 0x28);
    piVar7 = (int32_t *)0x0;
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -8) = 0;
    uVar1 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar1 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c888;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c8a0;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c8b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        goto code_r0x00018025cb52;
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_R14;
    if (piVar9 != (int32_t *)0x0) {
        if (((*piVar9 == 0x100) && (*(int64_t *)(piVar9 + 0xc) != 0)) && (iVar8 = *(int64_t *)(piVar9 + 10), iVar8 != 0)
           ) {
            iVar10 = 0x1805aadb1;
            if (*(int64_t *)(iVar8 + 0x10) != 0) {
                iVar10 = *(int64_t *)(iVar8 + 0x10);
            }
            if (*(int64_t *)(iVar8 + 0xc0) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c915;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c92d;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6));
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = iVar10;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c94c;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
            } else {
                if ((uVar1 >> 9 & 1) == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c95f;
                    piVar7 = (int32_t *)func_0x000180258850(piVar9);
                    if (piVar7 != (int32_t *)0x0) {
                        piVar9 = piVar7;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c96e;
                func_0x000180229b10();
                pcVar2 = *(code **)(iVar8 + 0xc0);
                uVar3 = *(undefined8 *)(piVar9 + 0xc);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c982;
                iVar5 = (*pcVar2)(uVar3, in_RDX, in_R8);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c98d;
                    iVar5 = func_0x000180229970();
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c996;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c9ae;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                        *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = iVar10;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c9cd;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c9d2;
                func_0x000180229900();
                if (piVar7 == (int32_t *)0x0) {
                    *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c9ed;
                    func_0x000180258be0(piVar7);
                }
            }
            goto code_r0x00018025cb52;
        }
        if (*(int64_t *)(piVar9 + 0x1e) != 0) {
            if ((*(uint8_t *)(piVar9 + 0x28) & 1) != 0) {
                pcVar2 = *(code **)(*(int64_t *)(piVar9 + 0x1e) + 0xf8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca19;
                iVar5 = (*pcVar2)(piVar9, in_RCX);
                if (iVar5 == 0) goto code_r0x00018025cb52;
            }
            piVar9[0x28] = piVar9[0x28] & 0xfffffffe;
            pcVar2 = *(code **)(*(int64_t *)(piVar9 + 0x1e) + 0x88);
            if ((*(uint32_t *)(in_RCX + 0x18) & 0x200) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca7b;
                iVar8 = func_0x000180215470();
                if (iVar8 == 0) goto code_r0x00018025cb52;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca8e;
                iVar5 = func_0x000180214b00(iVar8, in_RCX);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca9a;
                    func_0x000180215310(iVar8);
                    goto code_r0x00018025cb52;
                }
                if (pcVar2 == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cad8;
                    iVar5 = func_0x0001802146d0(iVar8, (int64_t)&var_18h + iVar6, (int64_t)&iStackX_10 + iVar6 + -8);
                } else {
                    iVar10 = *(int64_t *)(iVar8 + 0x28);
                    pcVar4 = *(code **)(*(int64_t *)(iVar10 + 0x78) + 0x88);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cac4;
                    iVar5 = (*pcVar4)(iVar10, in_RDX, in_R8 & 0xffffffff, iVar8);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cae2;
                func_0x000180215310(iVar8);
                if (pcVar2 != (code *)0x0) goto code_r0x00018025cb52;
            } else {
                if (pcVar2 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca50;
                    (*pcVar2)(piVar9, in_RDX, in_R8 & 0xffffffff, in_RCX);
                    *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
                    goto code_r0x00018025cb52;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca72;
                iVar5 = func_0x0001802146d0(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&iStackX_10 + iVar6 + -8);
            }
            if (iVar5 != 0) {
                *(uint64_t *)(&stack0xfffffffffffffff8 + iVar6) =
                     (uint64_t)*(uint32_t *)((int64_t)&iStackX_10 + iVar6 + -8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb0f;
                func_0x000180247f70(piVar9, in_RDX, in_R8, (int64_t)&var_18h + iVar6);
            }
            goto code_r0x00018025cb52;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb16;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb2e;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                  *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                  *(int64_t *)(&stack0x00000028 + iVar6));
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb40;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
code_r0x00018025cb52:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb62;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_18025cb52
// Address: 0x18025cb52
// Size: 31 bytes
// ============================================================
void fcn.18025c840(int64_t arg_58h, int64_t arg_68h, int64_t arg_70h)
{
    uint32_t uVar1;
    code *pcVar2;
    undefined8 uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t *piVar9;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    int64_t iVar10;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18025c852;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_58h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6);
    piVar9 = *(int32_t **)(in_RCX + 0x28);
    piVar7 = (int32_t *)0x0;
    *(undefined4 *)((int64_t)&iStackX_10 + iVar6 + -8) = 0;
    uVar1 = *(uint32_t *)(in_RCX + 0x18);
    if ((uVar1 >> 0xb & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c888;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c8a0;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c8b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
        goto code_r0x00018025cb52;
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_R14;
    if (piVar9 != (int32_t *)0x0) {
        if (((*piVar9 == 0x100) && (*(int64_t *)(piVar9 + 0xc) != 0)) && (iVar8 = *(int64_t *)(piVar9 + 10), iVar8 != 0)
           ) {
            iVar10 = 0x1805aadb1;
            if (*(int64_t *)(iVar8 + 0x10) != 0) {
                iVar10 = *(int64_t *)(iVar8 + 0x10);
            }
            if (*(int64_t *)(iVar8 + 0xc0) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c915;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c92d;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6));
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = iVar10;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c94c;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
            } else {
                if ((uVar1 >> 9 & 1) == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c95f;
                    piVar7 = (int32_t *)func_0x000180258850(piVar9);
                    if (piVar7 != (int32_t *)0x0) {
                        piVar9 = piVar7;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c96e;
                func_0x000180229b10();
                pcVar2 = *(code **)(iVar8 + 0xc0);
                uVar3 = *(undefined8 *)(piVar9 + 0xc);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c982;
                iVar5 = (*pcVar2)(uVar3, in_RDX, in_R8);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c98d;
                    iVar5 = func_0x000180229970();
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c996;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c9ae;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                        *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = iVar10;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c9cd;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c9d2;
                func_0x000180229900();
                if (piVar7 == (int32_t *)0x0) {
                    *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025c9ed;
                    func_0x000180258be0(piVar7);
                }
            }
            goto code_r0x00018025cb52;
        }
        if (*(int64_t *)(piVar9 + 0x1e) != 0) {
            if ((*(uint8_t *)(piVar9 + 0x28) & 1) != 0) {
                pcVar2 = *(code **)(*(int64_t *)(piVar9 + 0x1e) + 0xf8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca19;
                iVar5 = (*pcVar2)(piVar9, in_RCX);
                if (iVar5 == 0) goto code_r0x00018025cb52;
            }
            piVar9[0x28] = piVar9[0x28] & 0xfffffffe;
            pcVar2 = *(code **)(*(int64_t *)(piVar9 + 0x1e) + 0x88);
            if ((*(uint32_t *)(in_RCX + 0x18) & 0x200) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca7b;
                iVar8 = func_0x000180215470();
                if (iVar8 == 0) goto code_r0x00018025cb52;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca8e;
                iVar5 = func_0x000180214b00(iVar8, in_RCX);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca9a;
                    func_0x000180215310(iVar8);
                    goto code_r0x00018025cb52;
                }
                if (pcVar2 == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cad8;
                    iVar5 = func_0x0001802146d0(iVar8, (int64_t)&var_18h + iVar6, (int64_t)&iStackX_10 + iVar6 + -8);
                } else {
                    iVar10 = *(int64_t *)(iVar8 + 0x28);
                    pcVar4 = *(code **)(*(int64_t *)(iVar10 + 0x78) + 0x88);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cac4;
                    iVar5 = (*pcVar4)(iVar10, in_RDX, in_R8 & 0xffffffff, iVar8);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cae2;
                func_0x000180215310(iVar8);
                if (pcVar2 != (code *)0x0) goto code_r0x00018025cb52;
            } else {
                if (pcVar2 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca50;
                    (*pcVar2)(piVar9, in_RDX, in_R8 & 0xffffffff, in_RCX);
                    *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
                    goto code_r0x00018025cb52;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025ca72;
                iVar5 = func_0x0001802146d0(in_RCX, (int64_t)&var_18h + iVar6, (int64_t)&iStackX_10 + iVar6 + -8);
            }
            if (iVar5 != 0) {
                *(uint64_t *)(&stack0xfffffffffffffff8 + iVar6) =
                     (uint64_t)*(uint32_t *)((int64_t)&iStackX_10 + iVar6 + -8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb0f;
                func_0x000180247f70(piVar9, in_RDX, in_R8, (int64_t)&var_18h + iVar6);
            }
            goto code_r0x00018025cb52;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb16;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb2e;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                  *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                  *(int64_t *)(&stack0x00000028 + iVar6));
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb40;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
code_r0x00018025cb52:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025cb62;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_18025cb80
// Address: 0x18025cb80
// Size: 70 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_5fh
// WARNING: [rz-ghidra] Detected overlap for variable var_5bh
// WARNING: [rz-ghidra] Detected overlap for variable var_59h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a7h

void fcn.18025cb80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_80h)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025cb8a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = 0;
    *(undefined4 *)((int64_t)&arg_40h + iVar1) = 1;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = *(undefined8 *)((int64_t)&arg_80h + iVar1);
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025cbc1;
    fcn.18025cdf0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)((int64_t)&arg_40h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                  *(int64_t *)(&stack0x00000128 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18025cbd0
// Address: 0x18025cbd0
// Size: 90 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_5fh
// WARNING: [rz-ghidra] Detected overlap for variable var_5bh
// WARNING: [rz-ghidra] Detected overlap for variable var_59h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a7h

void fcn.18025cbd0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_90h)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025cbda;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = *(undefined8 *)((int64_t)&arg_90h + iVar1);
    *(undefined4 *)((int64_t)&arg_40h + iVar1) = 1;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = *(undefined8 *)((int64_t)&arg_88h + iVar1);
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = *(undefined8 *)((int64_t)&arg_80h + iVar1);
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025cc25;
    fcn.18025cdf0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)((int64_t)&arg_40h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                  *(int64_t *)(&stack0x00000128 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18025cc30
// Address: 0x18025cc30
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18025cc30(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar9;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025cc4b;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar1 = *(int32_t **)(in_RCX + 0x28);
    if ((*(uint32_t *)(in_RCX + 0x18) & 0x800) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cc69;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cc81;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cc93;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RDI;
    if (piVar1 != (int32_t *)0x0) {
        if (((*piVar1 == 0x100) && (*(int64_t *)(piVar1 + 0xc) != 0)) && (iVar2 = *(int64_t *)(piVar1 + 10), iVar2 != 0)
           ) {
            iVar9 = 0x1805aadb1;
            if (*(int64_t *)(iVar2 + 0x10) != 0) {
                iVar9 = *(int64_t *)(iVar2 + 0x10);
            }
            if (*(int64_t *)(iVar2 + 0xb8) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cced;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cd05;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                              *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar7));
                *(int64_t *)((int64_t)&var_18h + iVar7) = iVar9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cd24;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cd30;
            func_0x000180229b10();
            pcVar3 = *(code **)(iVar2 + 0xb8);
            uVar4 = *(undefined8 *)(piVar1 + 0xc);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cd43;
            uVar5 = (*pcVar3)(uVar4, in_RDX, in_R8);
            if ((int32_t)uVar5 < 1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cd4e;
                iVar6 = func_0x000180229970();
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cd57;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cd6f;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar7));
                    *(int64_t *)((int64_t)&var_18h + iVar7) = iVar9;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cd8e;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cd93;
            func_0x000180229900();
            return (uint64_t)uVar5;
        }
        if ((*(uint8_t *)(piVar1 + 0x28) & 1) != 0) {
            pcVar3 = *(code **)(*(int64_t *)(piVar1 + 0x1e) + 0xf8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cdb4;
            iVar6 = (*pcVar3)(piVar1, in_RCX);
            if (iVar6 == 0) {
                return 0;
            }
        }
        piVar1[0x28] = piVar1[0x28] & 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025cdd1;
    uVar8 = func_0x0001802149b0(in_RCX, in_RDX, in_R8);
    return uVar8;
}

