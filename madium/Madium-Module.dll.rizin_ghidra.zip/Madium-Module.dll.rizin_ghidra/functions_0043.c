// Chunk 43 - 50 functions

// ============================================================
// Function: FUN_18008e1e0
// Address: 0x18008e1e0
// Size: 72 bytes
// ============================================================
undefined8
fcn.18008e1e0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.180494da0(*(undefined8 *)arg3);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008e230
// Address: 0x18008e230
// Size: 72 bytes
// ============================================================
undefined8
fcn.18008e230(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.180494600(*(undefined8 *)arg3);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008e860
// Address: 0x18008e860
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.18008e860(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     int64_t arg_30h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (((1 < (int32_t)arg_30h) && (*(int32_t *)(arg3 + 0xc) == 6)) && (*(int32_t *)(arg_28h + 0xc) == 3)) {
        iVar3 = (int32_t)*(double *)arg_28h;
        iVar7 = iVar3;
        if (2 < (int32_t)arg_30h) {
            if (*(int32_t *)(arg_28h + 0x1c) == 3) {
                iVar7 = (int32_t)*(double *)(arg_28h + 0x10);
            } else {
                iVar7 = 0;
            }
        }
        if (((0 < iVar3) && (iVar3 <= iVar7)) && (arg3 = *(int64_t *)arg3, iVar7 <= *(int32_t *)(arg3 + 0x14))) {
            iVar8 = (iVar7 - iVar3) + 1;
            iVar6 = (int32_t)arg4;
            if (iVar6 < 0) {
                iVar6 = 1;
            }
            if (iVar8 == iVar6) {
                iVar6 = 0;
                if (3 < iVar8) {
                    iVar4 = iVar3;
                    do {
                        iVar5 = (int64_t)iVar4;
                        iVar4 = iVar4 + 4;
                        iVar2 = (int64_t)iVar6;
                        iVar6 = iVar6 + 4;
                        uVar1 = *(uint8_t *)(iVar5 + 0x17 + arg3);
                        *(undefined4 *)(arg2 + 0xc + iVar2 * 0x10) = 3;
                        *(double *)(arg2 + iVar2 * 0x10) = (double)(uint32_t)uVar1;
                        uVar1 = *(uint8_t *)(iVar5 + 0x18 + arg3);
                        *(undefined4 *)(arg2 + 0xc + (iVar2 + 1) * 0x10) = 3;
                        *(double *)(arg2 + (iVar2 + 1) * 0x10) = (double)(uint32_t)uVar1;
                        uVar1 = *(uint8_t *)(iVar5 + 0x19 + arg3);
                        *(undefined4 *)(arg2 + 0xc + (iVar2 + 2) * 0x10) = 3;
                        *(double *)(arg2 + (iVar2 + 2) * 0x10) = (double)(uint32_t)uVar1;
                        uVar1 = *(uint8_t *)(iVar5 + 0x1a + arg3);
                        *(undefined4 *)(arg2 + 0xc + (iVar2 + 3) * 0x10) = 3;
                        *(double *)(arg2 + (iVar2 + 3) * 0x10) = (double)(uint32_t)uVar1;
                    } while (iVar6 < (iVar7 - iVar3) + -2);
                }
                for (; iVar6 < iVar8; iVar6 = iVar6 + 1) {
                    uVar1 = *(uint8_t *)((int64_t)(iVar6 + iVar3) + 0x17 + arg3);
                    *(undefined4 *)(arg2 + 0xc + (int64_t)iVar6 * 0x10) = 3;
                    *(double *)(arg2 + (int64_t)iVar6 * 0x10) = (double)(uint32_t)uVar1;
                }
                return iVar8;
            }
        }
    }
    return -1;
}

// ============================================================
// Function: FUN_18008e8f6
// Address: 0x18008e8f6
// Size: 201 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.18008e860(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     int64_t arg_30h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (((1 < (int32_t)arg_30h) && (*(int32_t *)(arg3 + 0xc) == 6)) && (*(int32_t *)(arg_28h + 0xc) == 3)) {
        iVar3 = (int32_t)*(double *)arg_28h;
        iVar7 = iVar3;
        if (2 < (int32_t)arg_30h) {
            if (*(int32_t *)(arg_28h + 0x1c) == 3) {
                iVar7 = (int32_t)*(double *)(arg_28h + 0x10);
            } else {
                iVar7 = 0;
            }
        }
        if (((0 < iVar3) && (iVar3 <= iVar7)) && (arg3 = *(int64_t *)arg3, iVar7 <= *(int32_t *)(arg3 + 0x14))) {
            iVar8 = (iVar7 - iVar3) + 1;
            iVar6 = (int32_t)arg4;
            if (iVar6 < 0) {
                iVar6 = 1;
            }
            if (iVar8 == iVar6) {
                iVar6 = 0;
                if (3 < iVar8) {
                    iVar4 = iVar3;
                    do {
                        iVar5 = (int64_t)iVar4;
                        iVar4 = iVar4 + 4;
                        iVar2 = (int64_t)iVar6;
                        iVar6 = iVar6 + 4;
                        uVar1 = *(uint8_t *)(iVar5 + 0x17 + arg3);
                        *(undefined4 *)(arg2 + 0xc + iVar2 * 0x10) = 3;
                        *(double *)(arg2 + iVar2 * 0x10) = (double)(uint32_t)uVar1;
                        uVar1 = *(uint8_t *)(iVar5 + 0x18 + arg3);
                        *(undefined4 *)(arg2 + 0xc + (iVar2 + 1) * 0x10) = 3;
                        *(double *)(arg2 + (iVar2 + 1) * 0x10) = (double)(uint32_t)uVar1;
                        uVar1 = *(uint8_t *)(iVar5 + 0x19 + arg3);
                        *(undefined4 *)(arg2 + 0xc + (iVar2 + 2) * 0x10) = 3;
                        *(double *)(arg2 + (iVar2 + 2) * 0x10) = (double)(uint32_t)uVar1;
                        uVar1 = *(uint8_t *)(iVar5 + 0x1a + arg3);
                        *(undefined4 *)(arg2 + 0xc + (iVar2 + 3) * 0x10) = 3;
                        *(double *)(arg2 + (iVar2 + 3) * 0x10) = (double)(uint32_t)uVar1;
                    } while (iVar6 < (iVar7 - iVar3) + -2);
                }
                for (; iVar6 < iVar8; iVar6 = iVar6 + 1) {
                    uVar1 = *(uint8_t *)((int64_t)(iVar6 + iVar3) + 0x17 + arg3);
                    *(undefined4 *)(arg2 + 0xc + (int64_t)iVar6 * 0x10) = 3;
                    *(double *)(arg2 + (int64_t)iVar6 * 0x10) = (double)(uint32_t)uVar1;
                }
                return iVar8;
            }
        }
    }
    return -1;
}

// ============================================================
// Function: FUN_18008e9bf
// Address: 0x18008e9bf
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.18008e860(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     int64_t arg_30h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (((1 < (int32_t)arg_30h) && (*(int32_t *)(arg3 + 0xc) == 6)) && (*(int32_t *)(arg_28h + 0xc) == 3)) {
        iVar3 = (int32_t)*(double *)arg_28h;
        iVar7 = iVar3;
        if (2 < (int32_t)arg_30h) {
            if (*(int32_t *)(arg_28h + 0x1c) == 3) {
                iVar7 = (int32_t)*(double *)(arg_28h + 0x10);
            } else {
                iVar7 = 0;
            }
        }
        if (((0 < iVar3) && (iVar3 <= iVar7)) && (arg3 = *(int64_t *)arg3, iVar7 <= *(int32_t *)(arg3 + 0x14))) {
            iVar8 = (iVar7 - iVar3) + 1;
            iVar6 = (int32_t)arg4;
            if (iVar6 < 0) {
                iVar6 = 1;
            }
            if (iVar8 == iVar6) {
                iVar6 = 0;
                if (3 < iVar8) {
                    iVar4 = iVar3;
                    do {
                        iVar5 = (int64_t)iVar4;
                        iVar4 = iVar4 + 4;
                        iVar2 = (int64_t)iVar6;
                        iVar6 = iVar6 + 4;
                        uVar1 = *(uint8_t *)(iVar5 + 0x17 + arg3);
                        *(undefined4 *)(arg2 + 0xc + iVar2 * 0x10) = 3;
                        *(double *)(arg2 + iVar2 * 0x10) = (double)(uint32_t)uVar1;
                        uVar1 = *(uint8_t *)(iVar5 + 0x18 + arg3);
                        *(undefined4 *)(arg2 + 0xc + (iVar2 + 1) * 0x10) = 3;
                        *(double *)(arg2 + (iVar2 + 1) * 0x10) = (double)(uint32_t)uVar1;
                        uVar1 = *(uint8_t *)(iVar5 + 0x19 + arg3);
                        *(undefined4 *)(arg2 + 0xc + (iVar2 + 2) * 0x10) = 3;
                        *(double *)(arg2 + (iVar2 + 2) * 0x10) = (double)(uint32_t)uVar1;
                        uVar1 = *(uint8_t *)(iVar5 + 0x1a + arg3);
                        *(undefined4 *)(arg2 + 0xc + (iVar2 + 3) * 0x10) = 3;
                        *(double *)(arg2 + (iVar2 + 3) * 0x10) = (double)(uint32_t)uVar1;
                    } while (iVar6 < (iVar7 - iVar3) + -2);
                }
                for (; iVar6 < iVar8; iVar6 = iVar6 + 1) {
                    uVar1 = *(uint8_t *)((int64_t)(iVar6 + iVar3) + 0x17 + arg3);
                    *(undefined4 *)(arg2 + 0xc + (int64_t)iVar6 * 0x10) = 3;
                    *(double *)(arg2 + (int64_t)iVar6 * 0x10) = (double)(uint32_t)uVar1;
                }
                return iVar8;
            }
        }
    }
    return -1;
}

// ============================================================
// Function: FUN_18008ea10
// Address: 0x18008ea10
// Size: 269 bytes
// ============================================================
void fcn.18008ea10(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined auStack_38 [31];
    undefined uStack_19;
    int64_t var_18h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_38;
    uVar7 = (uint64_t)(int32_t)arg_30h;
    if ((((int32_t)arg_30h < 8) && ((int32_t)arg4 < 2)) &&
       (uVar4 = *(uint64_t *)(arg1 + 0x20), *(uint64_t *)(uVar4 + 0x30) < *(uint64_t *)(uVar4 + 0x28))) {
        if ((int32_t)arg_30h < 1) {
code_r0x00018008ea7b:
            iVar5 = 2;
            if (1 < (int32_t)arg_30h) {
                do {
                    iVar6 = (int64_t)iVar5;
                    if (*(int32_t *)(arg_28h + -0x14 + iVar6 * 0x10) != 3) goto code_r0x00018008eaff;
                    uVar2 = (uint32_t)*(double *)(arg_28h + (iVar6 + -2) * 0x10);
                    uVar4 = CONCAT44((int32_t)(uVar4 >> 0x20), uVar2);
                    if ((uVar2 & 0xff) != uVar2) goto code_r0x00018008eaff;
                    iVar5 = iVar5 + 1;
                    (&uStack_19)[iVar6] = (char)uVar2;
                } while (iVar5 <= (int32_t)arg_30h);
            }
            if (7 < uVar7) {
                func_0x000180459e6c(uVar4, iVar5, uVar7);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            *(undefined *)((int64_t)&var_18h + uVar7) = 0;
            uVar3 = func_0x00018009a8e0(arg1, &var_18h);
            *(undefined8 *)arg2 = uVar3;
            *(undefined4 *)(arg2 + 0xc) = 6;
            func_0x000180459870(var_10h ^ (uint64_t)auStack_38);
            return;
        }
        if (*(int32_t *)(arg3 + 0xc) == 3) {
            uVar2 = (uint32_t)*(double *)arg3;
            uVar4 = (uint64_t)(uVar2 & 0xff);
            if ((uVar2 & 0xff) == uVar2) {
                var_18h._0_1_ = (undefined)uVar2;
                goto code_r0x00018008ea7b;
            }
        }
    }
code_r0x00018008eaff:
    func_0x000180459870(var_10h ^ (uint64_t)auStack_38);
    return;
}

// ============================================================
// Function: FUN_18008eb60
// Address: 0x18008eb60
// Size: 62 bytes
// ============================================================
undefined8
fcn.18008eb60(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    
    if ((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) {
        uVar1 = fcn.1800a3b90(placeholder_0, arg3);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 6;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008eba0
// Address: 0x18008eba0
// Size: 157 bytes
// ============================================================
undefined8 fcn.18008eba0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    
    if ((((((2 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 6)) &&
         ((*(int32_t *)(arg_28h + 0xc) == 3 && (*(int32_t *)(arg_28h + 0x1c) == 3)))) &&
        ((*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30) < *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) &&
         ((iVar3 = (int32_t)*(double *)arg_28h, 0 < iVar3 &&
          (iVar2 = (int32_t)*(double *)(arg_28h + 0x10), iVar3 <= iVar2)))))) &&
       (iVar2 - 1U < *(uint32_t *)(*(int64_t *)arg3 + 0x14))) {
        uVar1 = fcn.18009a8e0(arg1, (int64_t)(iVar3 + -1) + *(int64_t *)arg3 + 0x18, (int64_t)((iVar2 - iVar3) + 1));
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 6;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008ed00
// Address: 0x18008ed00
// Size: 72 bytes
// ============================================================
undefined8
fcn.18008ed00(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.18046e0b0(*(undefined8 *)arg3);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008ed50
// Address: 0x18008ed50
// Size: 64 bytes
// ============================================================
undefined8
fcn.18008ed50(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    
    if ((1 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) {
        uVar1 = fcn.180099140(arg3, arg_28h);
        *(undefined4 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 1;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008ed90
// Address: 0x18008ed90
// Size: 70 bytes
// ============================================================
undefined8
fcn.18008ed90(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    
    if (((1 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 7)) {
        puVar4 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)arg3, arg_28h);
        uVar1 = puVar4[1];
        uVar2 = puVar4[2];
        uVar3 = puVar4[3];
        *(undefined4 *)arg2 = *puVar4;
        *(undefined4 *)(arg2 + 4) = uVar1;
        *(undefined4 *)(arg2 + 8) = uVar2;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008ede0
// Address: 0x18008ede0
// Size: 280 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008ede0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 *puVar8;
    bool bVar9;
    int64_t var_8h;
    int64_t var_10h;
    
    if ((int32_t)arg_30h < 3) {
        return 0xffffffff;
    }
    if (1 < (int32_t)arg4) {
        return 0xffffffff;
    }
    if (*(int32_t *)(arg3 + 0xc) != 7) {
        return 0xffffffff;
    }
    iVar1 = *(int32_t *)(arg_28h + 0xc);
    if (iVar1 == 0) {
        return 0xffffffff;
    }
    if (iVar1 == 3) {
        bVar9 = NAN(*(double *)arg_28h);
    } else {
        if (iVar1 != 5) goto code_r0x00018008ee5f;
        if (NAN(*(float *)arg_28h)) {
            return 0xffffffff;
        }
        if (NAN(*(float *)(arg_28h + 4))) {
            return 0xffffffff;
        }
        bVar9 = NAN(*(float *)(arg_28h + 8));
    }
    if (bVar9) {
        return 0xffffffff;
    }
code_r0x00018008ee5f:
    iVar2 = *(int64_t *)arg3;
    if (*(char *)(iVar2 + 4) != '\0') {
        return 0xffffffff;
    }
    uVar4 = *(undefined4 *)arg3;
    uVar5 = *(undefined4 *)(arg3 + 4);
    uVar6 = *(undefined4 *)(arg3 + 8);
    uVar7 = *(undefined4 *)(arg3 + 0xc);
    *(undefined4 *)arg2 = uVar4;
    *(undefined4 *)(arg2 + 4) = uVar5;
    *(undefined4 *)(arg2 + 8) = uVar6;
    *(undefined4 *)(arg2 + 0xc) = uVar7;
    puVar8 = (undefined4 *)func_0x0001800a0f40(uVar4, iVar2, arg_28h);
    uVar4 = *(undefined4 *)(arg_28h + 0x14);
    uVar5 = *(undefined4 *)(arg_28h + 0x18);
    uVar6 = *(undefined4 *)(arg_28h + 0x1c);
    *puVar8 = *(undefined4 *)(arg_28h + 0x10);
    puVar8[1] = uVar4;
    puVar8[2] = uVar5;
    puVar8[3] = uVar6;
    if (((5 < *(int32_t *)(arg_28h + 0x1c)) && ((*(uint8_t *)(iVar2 + 1) & 4) != 0)) &&
       ((*(uint8_t *)(*(int64_t *)(arg_28h + 0x10) + 1) & 3) != 0)) {
        iVar3 = *(int64_t *)(arg1 + 0x20);
        if (*(char *)(iVar3 + 0x59) == '\x02') {
            func_0x000180094420();
            return 1;
        }
        *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
        *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
        *(int64_t *)(iVar3 + 0x18) = iVar2;
    }
    return 1;
}

// ============================================================
// Function: FUN_18008ef00
// Address: 0x18008ef00
// Size: 180 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8
fcn.18008ef00(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    undefined4 *puVar6;
    int64_t var_8h;
    
    if (((((int32_t)arg_30h == 2) && ((int32_t)arg4 < 1)) && (*(int32_t *)(arg3 + 0xc) == 7)) &&
       (arg3 = *(int64_t *)arg3, *(char *)(arg3 + 4) == '\0')) {
        iVar5 = fcn.1800a1110(arg3);
        puVar6 = (undefined4 *)fcn.1800a1010(arg1, arg3, iVar5 + 1);
        uVar2 = *(undefined4 *)(arg_28h + 4);
        uVar3 = *(undefined4 *)(arg_28h + 8);
        uVar4 = *(undefined4 *)(arg_28h + 0xc);
        *puVar6 = *(undefined4 *)arg_28h;
        puVar6[1] = uVar2;
        puVar6[2] = uVar3;
        puVar6[3] = uVar4;
        if (((5 < *(int32_t *)(arg_28h + 0xc)) && ((*(uint8_t *)(arg3 + 1) & 4) != 0)) &&
           ((*(uint8_t *)(*(int64_t *)arg_28h + 1) & 3) != 0)) {
            iVar1 = *(int64_t *)(arg1 + 0x20);
            if (*(char *)(iVar1 + 0x59) == '\x02') {
                fcn.180094420();
                return 0;
            }
            *(uint8_t *)(arg3 + 1) = *(uint8_t *)(arg3 + 1) & 0xfb;
            *(undefined8 *)(arg3 + 0x18) = *(undefined8 *)(iVar1 + 0x18);
            *(int64_t *)(iVar1 + 0x18) = arg3;
        }
        return 0;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008efc0
// Address: 0x18008efc0
// Size: 227 bytes
// ============================================================
int32_t fcn.18008efc0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    int64_t var_18h;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 0)) && (*(int32_t *)(arg3 + 0xc) == 7)) {
        arg3 = *(int64_t *)arg3;
        if ((int32_t)arg_30h == 1) {
            iVar7 = fcn.1800a1110(arg3);
        } else {
            if ((int32_t)arg_30h != 3) {
                return -1;
            }
            if (*(int32_t *)(arg_28h + 0xc) != 3) {
                return -1;
            }
            if (*(int32_t *)(arg_28h + 0x1c) != 3) {
                return -1;
            }
            if (*(double *)arg_28h != 1.0) {
                return -1;
            }
            iVar7 = (int32_t)*(double *)(arg_28h + 0x10);
        }
        if (((-1 < iVar7) && (iVar7 <= *(int32_t *)(arg3 + 8))) &&
           ((iVar7 <= (int32_t)(*(int64_t *)(arg1 + 0x30) - arg2 >> 4) && (iVar7 + (int32_t)arg_30h < 0x1f41)))) {
            iVar3 = *(int64_t *)(arg3 + 0x20);
            uVar9 = 0;
            if (0 < iVar7) {
                do {
                    uVar8 = (int32_t)uVar9 + 1;
                    puVar1 = (undefined4 *)(iVar3 + uVar9 * 0x10);
                    uVar4 = puVar1[1];
                    uVar5 = puVar1[2];
                    uVar6 = puVar1[3];
                    puVar2 = (undefined4 *)(arg2 + uVar9 * 0x10);
                    *puVar2 = *puVar1;
                    puVar2[1] = uVar4;
                    puVar2[2] = uVar5;
                    puVar2[3] = uVar6;
                    uVar9 = (uint64_t)uVar8;
                } while ((int32_t)uVar8 < iVar7);
            }
            uVar9 = (int64_t)iVar7 * 0x10 + arg2;
            if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
                **(uint64_t **)(arg1 + 0x18) = uVar9;
            }
            return iVar7;
        }
    }
    return -1;
}

// ============================================================
// Function: FUN_18008f260
// Address: 0x18008f260
// Size: 121 bytes
// ============================================================
undefined8
fcn.18008f260(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    uint32_t uVar1;
    int32_t iVar2;
    
    if ((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) {
        if (*(int32_t *)(arg3 + 0xc) == 7) {
            iVar2 = fcn.1800a1110(*(undefined8 *)arg3);
            *(undefined4 *)(arg2 + 0xc) = 3;
            *(double *)arg2 = (double)iVar2;
            return 1;
        }
        if (*(int32_t *)(arg3 + 0xc) == 6) {
            uVar1 = *(uint32_t *)(*(int64_t *)arg3 + 0x14);
            *(undefined4 *)(arg2 + 0xc) = 3;
            *(double *)arg2 = (double)(uint64_t)uVar1;
            return 1;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008f340
// Address: 0x18008f340
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18008f340(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4, int64_t arg_30h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    if (((int32_t)arg_30h < 1) || (1 < (int32_t)arg4)) {
        return 0xffffffff;
    }
    iVar1 = *(int32_t *)(arg3 + 0xc);
    if (iVar1 == 7) {
        iVar6 = *(int64_t *)(*(int64_t *)arg3 + 0x10);
    } else if (iVar1 == 9) {
        iVar6 = *(int64_t *)(*(int64_t *)arg3 + 8) + (int64_t)(int64_t *)(*(int64_t *)arg3 + 8);
    } else {
        iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x440 + (int64_t)iVar1 * 8);
    }
    puVar5 = *(undefined4 **)0x180782430;
    if (iVar6 != 0) {
        puVar5 = (undefined4 *)fcn.1800a0e30(iVar6, *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x3c8));
    }
    if (puVar5[3] == 0) {
        if (iVar6 == 0) {
            *(undefined4 *)(arg2 + 0xc) = 0;
            return 1;
        }
        *(int64_t *)arg2 = iVar6;
        *(undefined4 *)(arg2 + 0xc) = 7;
        return 1;
    }
    uVar2 = puVar5[1];
    uVar3 = puVar5[2];
    uVar4 = puVar5[3];
    *(undefined4 *)arg2 = *puVar5;
    *(undefined4 *)(arg2 + 4) = uVar2;
    *(undefined4 *)(arg2 + 8) = uVar3;
    *(undefined4 *)(arg2 + 0xc) = uVar4;
    return 1;
}

// ============================================================
// Function: FUN_18008f365
// Address: 0x18008f365
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18008f340(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4, int64_t arg_30h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    if (((int32_t)arg_30h < 1) || (1 < (int32_t)arg4)) {
        return 0xffffffff;
    }
    iVar1 = *(int32_t *)(arg3 + 0xc);
    if (iVar1 == 7) {
        iVar6 = *(int64_t *)(*(int64_t *)arg3 + 0x10);
    } else if (iVar1 == 9) {
        iVar6 = *(int64_t *)(*(int64_t *)arg3 + 8) + (int64_t)(int64_t *)(*(int64_t *)arg3 + 8);
    } else {
        iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x440 + (int64_t)iVar1 * 8);
    }
    puVar5 = *(undefined4 **)0x180782430;
    if (iVar6 != 0) {
        puVar5 = (undefined4 *)fcn.1800a0e30(iVar6, *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x3c8));
    }
    if (puVar5[3] == 0) {
        if (iVar6 == 0) {
            *(undefined4 *)(arg2 + 0xc) = 0;
            return 1;
        }
        *(int64_t *)arg2 = iVar6;
        *(undefined4 *)(arg2 + 0xc) = 7;
        return 1;
    }
    uVar2 = puVar5[1];
    uVar3 = puVar5[2];
    uVar4 = puVar5[3];
    *(undefined4 *)arg2 = *puVar5;
    *(undefined4 *)(arg2 + 4) = uVar2;
    *(undefined4 *)(arg2 + 8) = uVar3;
    *(undefined4 *)(arg2 + 0xc) = uVar4;
    return 1;
}

// ============================================================
// Function: FUN_18008f3d8
// Address: 0x18008f3d8
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18008f340(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4, int64_t arg_30h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    if (((int32_t)arg_30h < 1) || (1 < (int32_t)arg4)) {
        return 0xffffffff;
    }
    iVar1 = *(int32_t *)(arg3 + 0xc);
    if (iVar1 == 7) {
        iVar6 = *(int64_t *)(*(int64_t *)arg3 + 0x10);
    } else if (iVar1 == 9) {
        iVar6 = *(int64_t *)(*(int64_t *)arg3 + 8) + (int64_t)(int64_t *)(*(int64_t *)arg3 + 8);
    } else {
        iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x440 + (int64_t)iVar1 * 8);
    }
    puVar5 = *(undefined4 **)0x180782430;
    if (iVar6 != 0) {
        puVar5 = (undefined4 *)fcn.1800a0e30(iVar6, *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x3c8));
    }
    if (puVar5[3] == 0) {
        if (iVar6 == 0) {
            *(undefined4 *)(arg2 + 0xc) = 0;
            return 1;
        }
        *(int64_t *)arg2 = iVar6;
        *(undefined4 *)(arg2 + 0xc) = 7;
        return 1;
    }
    uVar2 = puVar5[1];
    uVar3 = puVar5[2];
    uVar4 = puVar5[3];
    *(undefined4 *)arg2 = *puVar5;
    *(undefined4 *)(arg2 + 4) = uVar2;
    *(undefined4 *)(arg2 + 8) = uVar3;
    *(undefined4 *)(arg2 + 0xc) = uVar4;
    return 1;
}

// ============================================================
// Function: FUN_18008f3f7
// Address: 0x18008f3f7
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18008f340(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4, int64_t arg_30h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    if (((int32_t)arg_30h < 1) || (1 < (int32_t)arg4)) {
        return 0xffffffff;
    }
    iVar1 = *(int32_t *)(arg3 + 0xc);
    if (iVar1 == 7) {
        iVar6 = *(int64_t *)(*(int64_t *)arg3 + 0x10);
    } else if (iVar1 == 9) {
        iVar6 = *(int64_t *)(*(int64_t *)arg3 + 8) + (int64_t)(int64_t *)(*(int64_t *)arg3 + 8);
    } else {
        iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x440 + (int64_t)iVar1 * 8);
    }
    puVar5 = *(undefined4 **)0x180782430;
    if (iVar6 != 0) {
        puVar5 = (undefined4 *)fcn.1800a0e30(iVar6, *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x3c8));
    }
    if (puVar5[3] == 0) {
        if (iVar6 == 0) {
            *(undefined4 *)(arg2 + 0xc) = 0;
            return 1;
        }
        *(int64_t *)arg2 = iVar6;
        *(undefined4 *)(arg2 + 0xc) = 7;
        return 1;
    }
    uVar2 = puVar5[1];
    uVar3 = puVar5[2];
    uVar4 = puVar5[3];
    *(undefined4 *)arg2 = *puVar5;
    *(undefined4 *)(arg2 + 4) = uVar2;
    *(undefined4 *)(arg2 + 8) = uVar3;
    *(undefined4 *)(arg2 + 0xc) = uVar4;
    return 1;
}

// ============================================================
// Function: FUN_18008f409
// Address: 0x18008f409
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18008f340(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4, int64_t arg_30h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    if (((int32_t)arg_30h < 1) || (1 < (int32_t)arg4)) {
        return 0xffffffff;
    }
    iVar1 = *(int32_t *)(arg3 + 0xc);
    if (iVar1 == 7) {
        iVar6 = *(int64_t *)(*(int64_t *)arg3 + 0x10);
    } else if (iVar1 == 9) {
        iVar6 = *(int64_t *)(*(int64_t *)arg3 + 8) + (int64_t)(int64_t *)(*(int64_t *)arg3 + 8);
    } else {
        iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x440 + (int64_t)iVar1 * 8);
    }
    puVar5 = *(undefined4 **)0x180782430;
    if (iVar6 != 0) {
        puVar5 = (undefined4 *)fcn.1800a0e30(iVar6, *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x3c8));
    }
    if (puVar5[3] == 0) {
        if (iVar6 == 0) {
            *(undefined4 *)(arg2 + 0xc) = 0;
            return 1;
        }
        *(int64_t *)arg2 = iVar6;
        *(undefined4 *)(arg2 + 0xc) = 7;
        return 1;
    }
    uVar2 = puVar5[1];
    uVar3 = puVar5[2];
    uVar4 = puVar5[3];
    *(undefined4 *)arg2 = *puVar5;
    *(undefined4 *)(arg2 + 4) = uVar2;
    *(undefined4 *)(arg2 + 8) = uVar3;
    *(undefined4 *)(arg2 + 0xc) = uVar4;
    return 1;
}

// ============================================================
// Function: FUN_18008f420
// Address: 0x18008f420
// Size: 149 bytes
// ============================================================
undefined8 fcn.18008f420(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    
    if (((((1 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 7)) &&
        ((*(int32_t *)(arg_28h + 0xc) == 7 && (arg3 = *(int64_t *)arg3, *(char *)(arg3 + 4) == '\0')))) &&
       (*(int64_t *)(arg3 + 0x10) == 0)) {
        arg_28h = *(int64_t *)arg_28h;
        *(int64_t *)(arg3 + 0x10) = arg_28h;
        if (((*(uint8_t *)(arg3 + 1) & 4) != 0) && ((*(uint8_t *)(arg_28h + 1) & 3) != 0)) {
            iVar1 = *(int64_t *)(arg1 + 0x20);
            if ((uint8_t)(*(char *)(iVar1 + 0x59) - 1U) < 3) {
                fcn.180094420(iVar1, arg_28h);
            } else {
                *(uint8_t *)(arg3 + 1) = *(uint8_t *)(iVar1 + 0x58) & 3 | *(uint8_t *)(arg3 + 1) & 0xf8;
            }
        }
        *(int64_t *)arg2 = arg3;
        *(undefined4 *)(arg2 + 0xc) = 7;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008f4c0
// Address: 0x18008f4c0
// Size: 138 bytes
// ============================================================
undefined8
fcn.18008f4c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    int32_t iVar1;
    int64_t var_18h;
    
    if (((int32_t)arg_30h == 1) && ((int32_t)arg4 < 2)) {
        if (*(int32_t *)(arg3 + 0xc) == 3) {
            *(undefined8 *)arg2 = *(undefined8 *)arg3;
            *(undefined4 *)(arg2 + 0xc) = 3;
            return 1;
        }
        if (*(int32_t *)(arg3 + 0xc) == 6) {
            iVar1 = fcn.1800992c0(*(int64_t *)arg3 + 0x18, &var_18h);
            if (iVar1 != 0) {
                *(int64_t *)arg2 = var_18h;
                *(undefined4 *)(arg2 + 0xc) = 3;
                return 1;
            }
        }
        *(undefined4 *)(arg2 + 0xc) = 0;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008f550
// Address: 0x18008f550
// Size: 333 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18008f550(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    int64_t var_20h;
    undefined auStack_68 [32];
    int64_t var_48h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    if ((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) {
        iVar1 = *(int32_t *)(arg3 + 0xc);
        if (iVar1 == 0) {
            *(undefined8 *)arg2 = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x3d0);
            *(undefined4 *)(arg2 + 0xc) = 6;
        } else {
            if (iVar1 == 1) {
                piVar4 = (int64_t *)0x1805ab294;
                iVar2 = 5 - (uint64_t)(*(int32_t *)arg3 != 0);
                if (*(int32_t *)arg3 == 0) {
                    piVar4 = (int64_t *)0x1805ab28c;
                }
            } else if (iVar1 == 3) {
                if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))
                goto code_r0x00018008f682;
                iVar2 = func_0x000180098ac0(&var_48h, *(undefined8 *)arg3);
                iVar2 = iVar2 - (int64_t)&var_48h;
                piVar4 = &var_48h;
            } else {
                if (iVar1 != 4) {
                    if (iVar1 == 6) {
                        *(undefined8 *)arg2 = *(undefined8 *)arg3;
                        *(undefined4 *)(arg2 + 0xc) = 6;
                    }
                    goto code_r0x00018008f682;
                }
                if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))
                goto code_r0x00018008f682;
                iVar2 = func_0x000180099080(&var_48h, *(undefined8 *)arg3);
                iVar2 = iVar2 - (int64_t)&var_48h;
                piVar4 = &var_48h;
            }
            uVar3 = fcn.18009a8e0(arg1, piVar4, iVar2);
            *(undefined8 *)arg2 = uVar3;
            *(undefined4 *)(arg2 + 0xc) = 6;
        }
    }
code_r0x00018008f682:
    func_0x000180459870(var_18h ^ (uint64_t)auStack_68);
    return;
}

// ============================================================
// Function: FUN_18008f6e0
// Address: 0x18008f6e0
// Size: 128 bytes
// ============================================================
undefined8
fcn.18008f6e0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    float fVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 5)) {
        fVar1 = *(float *)arg3 * *(float *)arg3 + *(float *)(arg3 + 4) * *(float *)(arg3 + 4) +
                *(float *)(arg3 + 8) * *(float *)(arg3 + 8);
        if (fVar1 < 0.0) {
            fVar1 = (float)func_0x000180494560(fVar1);
        } else {
            fVar1 = SQRT(fVar1);
        }
        *(undefined4 *)(arg2 + 0xc) = 3;
        *(double *)arg2 = (double)fVar1;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008f760
// Address: 0x18008f760
// Size: 195 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18008f760(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    float fVar1;
    float fVar2;
    int64_t var_8h;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 5)) {
        fVar2 = *(float *)arg3 * *(float *)arg3 + *(float *)(arg3 + 4) * *(float *)(arg3 + 4) +
                *(float *)(arg3 + 8) * *(float *)(arg3 + 8);
        if (fVar2 < 0.0) {
            fVar2 = (float)func_0x000180494560(fVar2);
        } else {
            fVar2 = SQRT(fVar2);
        }
        fVar2 = 1.0 / fVar2;
        *(float *)arg2 = fVar2 * *(float *)arg3;
        *(float *)(arg2 + 4) = fVar2 * *(float *)(arg3 + 4);
        fVar1 = *(float *)(arg3 + 8);
        *(undefined4 *)(arg2 + 0xc) = 5;
        *(float *)(arg2 + 8) = fVar2 * fVar1;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008f920
// Address: 0x18008f920
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18008f920(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined4 uVar1;
    int64_t var_8h;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 5)) {
        uVar1 = fcn.180490aa0(*(undefined4 *)arg3);
        *(undefined4 *)arg2 = uVar1;
        uVar1 = fcn.180490aa0(*(undefined4 *)(arg3 + 4));
        *(undefined4 *)(arg2 + 4) = uVar1;
        uVar1 = fcn.180490aa0(*(undefined4 *)(arg3 + 8));
        *(undefined4 *)(arg2 + 8) = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 5;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008f9a0
// Address: 0x18008f9a0
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18008f9a0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined4 uVar1;
    int64_t var_8h;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 5)) {
        uVar1 = fcn.180471c90(*(undefined4 *)arg3);
        *(undefined4 *)arg2 = uVar1;
        uVar1 = fcn.180471c90(*(undefined4 *)(arg3 + 4));
        *(undefined4 *)(arg2 + 4) = uVar1;
        uVar1 = fcn.180471c90(*(undefined4 *)(arg3 + 8));
        *(undefined4 *)(arg2 + 8) = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 5;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008fea0
// Address: 0x18008fea0
// Size: 79 bytes
// ============================================================
undefined8
fcn.18008fea0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    int16_t iVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        iVar1 = fcn.18046ea10(*(undefined8 *)arg3);
        *(undefined4 *)(arg2 + 0xc) = 1;
        *(uint32_t *)arg2 = (uint32_t)(iVar1 == 2);
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008fef0
// Address: 0x18008fef0
// Size: 79 bytes
// ============================================================
undefined8
fcn.18008fef0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    int16_t iVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        iVar1 = fcn.18046ea10(*(undefined8 *)arg3);
        *(undefined4 *)(arg2 + 0xc) = 1;
        *(uint32_t *)arg2 = (uint32_t)(iVar1 == 1);
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008ff40
// Address: 0x18008ff40
// Size: 78 bytes
// ============================================================
undefined8
fcn.18008ff40(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    int16_t iVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        iVar1 = fcn.18046ea10(*(undefined8 *)arg3);
        *(undefined4 *)(arg2 + 0xc) = 1;
        *(uint32_t *)arg2 = (uint32_t)(iVar1 < 1);
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1800912c0
// Address: 0x1800912c0
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800912c0(int64_t arg1)
{
    char cVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((*(int32_t *)((int64_t)piVar5 + 0xc) != 10) || (iVar2 = *piVar5, iVar2 == 0)) {
        func_0x0001800883d0(arg1, 1, 0x18063cb4c);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    if (iVar2 == arg1) {
        iVar6 = 0x18063ca08;
    } else {
        cVar1 = *(char *)(iVar2 + 3);
        if (cVar1 == '\x01') {
            iVar6 = 0x18063dd50;
        } else if (cVar1 == '\x06') {
            iVar6 = 0x18063dd44;
        } else if (cVar1 == '\0') {
            if (*(int64_t *)(iVar2 + 0x18) == *(int64_t *)(iVar2 + 0x78)) {
                iVar6 = 0x18063dd50;
                if (*(int64_t *)(iVar2 + 0x40) == *(int64_t *)(iVar2 + 0x28)) {
                    iVar6 = 0x18063dd3c;
                }
            } else {
                iVar6 = 0x18063dd44;
            }
        } else {
            iVar6 = 0x18063dd3c;
        }
    }
    if (iVar6 == 0) {
        func_0x000180086510();
        return 1;
    }
    uVar4 = func_0x000180498cd0(iVar6);
    func_0x0001800867f0(arg1, iVar6, uVar4);
    return 1;
}

// ============================================================
// Function: FUN_1800912ef
// Address: 0x1800912ef
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800912c0(int64_t arg1)
{
    char cVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((*(int32_t *)((int64_t)piVar5 + 0xc) != 10) || (iVar2 = *piVar5, iVar2 == 0)) {
        func_0x0001800883d0(arg1, 1, 0x18063cb4c);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    if (iVar2 == arg1) {
        iVar6 = 0x18063ca08;
    } else {
        cVar1 = *(char *)(iVar2 + 3);
        if (cVar1 == '\x01') {
            iVar6 = 0x18063dd50;
        } else if (cVar1 == '\x06') {
            iVar6 = 0x18063dd44;
        } else if (cVar1 == '\0') {
            if (*(int64_t *)(iVar2 + 0x18) == *(int64_t *)(iVar2 + 0x78)) {
                iVar6 = 0x18063dd50;
                if (*(int64_t *)(iVar2 + 0x40) == *(int64_t *)(iVar2 + 0x28)) {
                    iVar6 = 0x18063dd3c;
                }
            } else {
                iVar6 = 0x18063dd44;
            }
        } else {
            iVar6 = 0x18063dd3c;
        }
    }
    if (iVar6 == 0) {
        func_0x000180086510();
        return 1;
    }
    uVar4 = func_0x000180498cd0(iVar6);
    func_0x0001800867f0(arg1, iVar6, uVar4);
    return 1;
}

// ============================================================
// Function: FUN_180091371
// Address: 0x180091371
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800912c0(int64_t arg1)
{
    char cVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((*(int32_t *)((int64_t)piVar5 + 0xc) != 10) || (iVar2 = *piVar5, iVar2 == 0)) {
        func_0x0001800883d0(arg1, 1, 0x18063cb4c);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    if (iVar2 == arg1) {
        iVar6 = 0x18063ca08;
    } else {
        cVar1 = *(char *)(iVar2 + 3);
        if (cVar1 == '\x01') {
            iVar6 = 0x18063dd50;
        } else if (cVar1 == '\x06') {
            iVar6 = 0x18063dd44;
        } else if (cVar1 == '\0') {
            if (*(int64_t *)(iVar2 + 0x18) == *(int64_t *)(iVar2 + 0x78)) {
                iVar6 = 0x18063dd50;
                if (*(int64_t *)(iVar2 + 0x40) == *(int64_t *)(iVar2 + 0x28)) {
                    iVar6 = 0x18063dd3c;
                }
            } else {
                iVar6 = 0x18063dd44;
            }
        } else {
            iVar6 = 0x18063dd3c;
        }
    }
    if (iVar6 == 0) {
        func_0x000180086510();
        return 1;
    }
    uVar4 = func_0x000180498cd0(iVar6);
    func_0x0001800867f0(arg1, iVar6, uVar4);
    return 1;
}

// ============================================================
// Function: FUN_180091397
// Address: 0x180091397
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800912c0(int64_t arg1)
{
    char cVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((*(int32_t *)((int64_t)piVar5 + 0xc) != 10) || (iVar2 = *piVar5, iVar2 == 0)) {
        func_0x0001800883d0(arg1, 1, 0x18063cb4c);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    if (iVar2 == arg1) {
        iVar6 = 0x18063ca08;
    } else {
        cVar1 = *(char *)(iVar2 + 3);
        if (cVar1 == '\x01') {
            iVar6 = 0x18063dd50;
        } else if (cVar1 == '\x06') {
            iVar6 = 0x18063dd44;
        } else if (cVar1 == '\0') {
            if (*(int64_t *)(iVar2 + 0x18) == *(int64_t *)(iVar2 + 0x78)) {
                iVar6 = 0x18063dd50;
                if (*(int64_t *)(iVar2 + 0x40) == *(int64_t *)(iVar2 + 0x28)) {
                    iVar6 = 0x18063dd3c;
                }
            } else {
                iVar6 = 0x18063dd44;
            }
        } else {
            iVar6 = 0x18063dd3c;
        }
    }
    if (iVar6 == 0) {
        func_0x000180086510();
        return 1;
    }
    uVar4 = func_0x000180498cd0(iVar6);
    func_0x0001800867f0(arg1, iVar6, uVar4);
    return 1;
}

// ============================================================
// Function: FUN_1800913b0
// Address: 0x1800913b0
// Size: 383 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1800913b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    code *pcVar2;
    int32_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    undefined8 *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar1 = *(char *)(arg2 + 3);
    uVar5 = arg3 & 0xffffffff;
    if (cVar1 != '\x01') {
        if (arg2 == arg1) {
            puVar6 = (undefined8 *)0x180611c70;
            goto code_r0x000180091413;
        }
        if (cVar1 != '\x06') {
            if (cVar1 != '\0') {
                puVar6 = (undefined8 *)0x180611c90;
                goto code_r0x000180091413;
            }
            if (*(int64_t *)(arg2 + 0x18) == *(int64_t *)(arg2 + 0x78)) {
                if (*(int64_t *)(arg2 + 0x40) == *(int64_t *)(arg2 + 0x28)) {
                    puVar6 = (undefined8 *)0x180611c88;
                    goto code_r0x000180091413;
                }
                goto code_r0x000180091437;
            }
        }
        puVar6 = (undefined8 *)0x180611c80;
code_r0x000180091413:
        func_0x000180086980(arg1, 0x18063ddc0, *puVar6);
        return 0xffffffff;
    }
code_r0x000180091437:
    if ((int32_t)arg3 == 0) {
        if (0x1f400 < (int64_t)(*(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) & 0xfffffffffffffff0U))
        goto code_r0x00018009150f;
    } else {
        iVar3 = func_0x000180085510(arg2, uVar5);
        if (iVar3 == 0) {
code_r0x00018009150f:
            func_0x000180088560(arg1, 0x18063dda0);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        func_0x000180085680(arg1, arg2, uVar5);
    }
    *(undefined *)(arg2 + 5) = *(undefined *)(arg1 + 5);
    uVar4 = func_0x000180093fe0(arg2, arg1, uVar5);
    if (1 < uVar4) {
        if (uVar4 != 6) {
            func_0x000180085680(arg2, arg1, 1);
            return 0xffffffff;
        }
        return 0xfffffffe;
    }
    uVar5 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    if ((int32_t)uVar5 != 0) {
        if ((0x14 < (int32_t)uVar5 + 1) && (iVar3 = func_0x000180085510(arg1), iVar3 == 0)) {
            func_0x000180088560(arg1, 0x18063dd80);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        func_0x000180085680(arg2, arg1, uVar5 & 0xffffffff);
    }
    return uVar5 & 0xffffffff;
}

// ============================================================
// Function: FUN_180091530
// Address: 0x180091530
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.180091530(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t unaff_RBX;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    if (1 < *(uint8_t *)(arg2 + 3)) {
        fcn.180085610(arg1, 2);
        fcn.180085680(arg2, arg1, 1);
        return 0xffffffff;
    }
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    iVar2 = fcn.180085510(unaff_RBX);
    if (iVar2 != 0) {
        fcn.180085680(arg2, arg1, uVar3 & 0xffffffff);
        return uVar3 & 0xffffffff;
    }
    fcn.180088560(arg1, 0x18063dd80);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800915c0
// Address: 0x1800915c0
// Size: 304 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800915c0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    uVar9 = (uint32_t)arg2;
    if ((int32_t)uVar9 < 0) {
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar7 = fcn.180085510(in_stack_00000010), iVar7 != 0)) {
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            *puVar1 = 0;
            puVar1[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            puVar2 = *(undefined4 **)(arg1 + 0x40);
            for (puVar1 = puVar2; puVar2 + -8 < puVar1; puVar1 = puVar1 + -4) {
                *puVar1 = puVar1[-4];
                puVar1[1] = puVar1[-3];
                puVar1[2] = puVar1[-2];
                puVar1[3] = puVar1[-1];
            }
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            uVar4 = puVar1[1];
            uVar5 = puVar1[2];
            uVar6 = puVar1[3];
            puVar2[-8] = *puVar1;
            puVar2[-7] = uVar4;
            puVar2[-6] = uVar5;
            puVar2[-5] = uVar6;
            return 2;
        }
    } else if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
              || (iVar7 = fcn.180085510(in_stack_00000010), iVar7 != 0)) {
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        *puVar1 = 1;
        puVar1[3] = 1;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x0001800859a0(arg1, ~uVar9);
        return (uint64_t)(uVar9 + 1);
    }
    func_0x000180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar3 = (code *)swi(3);
    uVar8 = (*pcVar3)();
    return uVar8;
}

// ============================================================
// Function: FUN_1800916f0
// Address: 0x1800916f0
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800916f0(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    int64_t arg2;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    uint32_t uVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    piVar3 = *(int64_t **)(arg1 + 0x28);
    piVar11 = piVar3;
    if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if ((*(int32_t *)((int64_t)piVar11 + 0xc) != 10) || (arg2 = *piVar11, arg2 == 0)) {
        func_0x0001800883d0(arg1, 1, 0x18063cb4c);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    uVar10 = fcn.1800913b0(arg1, arg2, 
                           (uint64_t)((int32_t)((int64_t)*(int64_t **)(arg1 + 0x40) - (int64_t)piVar3 >> 4) - 1));
    if (uVar10 != 0xfffffffe) {
        if ((int32_t)uVar10 < 0) {
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar9 = fcn.180085510(in_stack_00000010), iVar9 != 0)) {
                puVar1 = *(undefined4 **)(arg1 + 0x40);
                *puVar1 = 0;
                puVar1[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                puVar2 = *(undefined4 **)(arg1 + 0x40);
                for (puVar1 = puVar2; puVar2 + -8 < puVar1; puVar1 = puVar1 + -4) {
                    *puVar1 = puVar1[-4];
                    puVar1[1] = puVar1[-3];
                    puVar1[2] = puVar1[-2];
                    puVar1[3] = puVar1[-1];
                }
                puVar1 = *(undefined4 **)(arg1 + 0x40);
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                puVar2[-8] = *puVar1;
                puVar2[-7] = uVar6;
                puVar2[-6] = uVar7;
                puVar2[-5] = uVar8;
                return 2;
            }
        } else if (((*(char *)0x180777010 == '\0') ||
                   (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                  (iVar9 = fcn.180085510(in_stack_00000010), iVar9 != 0)) {
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            *puVar1 = 1;
            puVar1[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800859a0(arg1, ~uVar10);
            return (uint64_t)(uVar10 + 1);
        }
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    iVar4 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x538);
    if (iVar4 != 0) {
        func_0x0001800a5dc0(arg1, iVar4, arg2);
    }
    if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
        *(undefined *)(arg1 + 3) = 6;
        return 0xffffffff;
    }
    fcn.180093000(arg1, 0x18063e108);
    pcVar5 = (code *)swi(3);
    uVar12 = (*pcVar5)();
    return uVar12;
}

// ============================================================
// Function: FUN_1800917b0
// Address: 0x1800917b0
// Size: 154 bytes
// ============================================================
uint64_t fcn.1800917b0(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t arg2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t in_stack_00000010;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((*(int32_t *)((int64_t)piVar10 + 0xc) != 10) || (arg2 = *piVar10, arg2 == 0)) {
        func_0x0001800883d0(arg1, 1, 0x18063cb4c);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    if (*(char *)(arg2 + 3) != '\x06') {
        uVar9 = fcn.180091530(arg1, arg2);
        if ((int32_t)uVar9 < 0) {
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar8 = fcn.180085510(in_stack_00000010), iVar8 != 0)) {
                puVar1 = *(undefined4 **)(arg1 + 0x40);
                *puVar1 = 0;
                puVar1[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                puVar2 = *(undefined4 **)(arg1 + 0x40);
                for (puVar1 = puVar2; puVar2 + -8 < puVar1; puVar1 = puVar1 + -4) {
                    *puVar1 = puVar1[-4];
                    puVar1[1] = puVar1[-3];
                    puVar1[2] = puVar1[-2];
                    puVar1[3] = puVar1[-1];
                }
                puVar1 = *(undefined4 **)(arg1 + 0x40);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                puVar2[-8] = *puVar1;
                puVar2[-7] = uVar5;
                puVar2[-6] = uVar6;
                puVar2[-5] = uVar7;
                return 2;
            }
        } else if (((*(char *)0x180777010 == '\0') ||
                   (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                  (iVar8 = fcn.180085510(in_stack_00000010), iVar8 != 0)) {
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            *puVar1 = 1;
            puVar1[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800859a0(arg1, ~uVar9);
            return (uint64_t)(uVar9 + 1);
        }
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    iVar3 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x538);
    if (iVar3 != 0) {
        func_0x0001800a5dc0(arg1, iVar3, arg2);
    }
    if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
        *(undefined *)(arg1 + 3) = 6;
        return 0xffffffff;
    }
    fcn.180093000(arg1, 0x18063e108);
    pcVar4 = (code *)swi(3);
    uVar11 = (*pcVar4)();
    return uVar11;
}

// ============================================================
// Function: FUN_180091850
// Address: 0x180091850
// Size: 201 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.180091850(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t unaff_RDI;
    int64_t arg2;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t in_stack_00000018;
    
    piVar4 = (int64_t *)func_0x000180085370(arg1, 0xffffd8ed);
    if (*(int32_t *)((int64_t)piVar4 + 0xc) == 10) {
        arg2 = *piVar4;
    } else {
        arg2 = 0;
    }
    uVar5 = fcn.1800913b0(arg1, arg2, *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    if ((int32_t)uVar5 == -2) {
        iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x538);
        if (iVar1 != 0) {
            func_0x0001800a5dc0(arg1, iVar1, arg2);
        }
        if (*(uint16_t *)(arg1 + 0x6a) < *(uint16_t *)(arg1 + 0x68)) {
            fcn.180093000(arg1, 0x18063e108);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        *(undefined *)(arg1 + 3) = 6;
        uVar5 = 0xffffffff;
    } else if ((int32_t)uVar5 < 0) {
        iVar3 = func_0x000180085dd0(arg1, 0xffffffff);
        if (iVar3 != 0) {
            fcn.1800884a0(arg1, 1);
            func_0x0001800859a0(arg1, 0xfffffffe);
            fcn.180087c00(unaff_RDI, in_stack_00000010, in_stack_00000018);
        }
        fcn.180087960(arg1);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180091920
// Address: 0x180091920
// Size: 181 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.180091920(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t arg2;
    int64_t unaff_RBX;
    int64_t in_stack_00000010;
    int64_t in_stack_00000018;
    
    piVar4 = (int64_t *)func_0x000180085370();
    if (*(int32_t *)((int64_t)piVar4 + 0xc) == 10) {
        arg2 = *piVar4;
    } else {
        arg2 = 0;
    }
    if (*(char *)(arg2 + 3) == '\x06') {
        iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x538);
        if (iVar1 != 0) {
            func_0x0001800a5dc0(arg1, iVar1, arg2);
        }
        if (*(uint16_t *)(arg1 + 0x6a) < *(uint16_t *)(arg1 + 0x68)) {
            fcn.180093000(arg1, 0x18063e108);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        *(undefined *)(arg1 + 3) = 6;
        uVar5 = 0xffffffff;
    } else {
        uVar5 = fcn.180091530(arg1, arg2);
        if ((int32_t)uVar5 < 0) {
            iVar3 = func_0x000180085dd0(arg1, 0xffffffff);
            if (iVar3 != 0) {
                fcn.1800884a0(arg1, 1);
                func_0x0001800859a0(arg1, 0xfffffffe);
                fcn.180087c00(unaff_RBX, in_stack_00000010, in_stack_00000018);
            }
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1800919e0
// Address: 0x1800919e0
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800919e0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 != *(undefined4 **)0x180782430) && (puVar8[3] == 8)) {
        iVar6 = func_0x000180085760(arg1);
        if ((*(uint8_t *)(iVar6 + 1) & 4) != 0) {
            *(uint8_t *)(iVar6 + 1) = *(uint8_t *)(iVar6 + 1) & 0xfb;
            *(undefined8 *)(iVar6 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar6 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar6 + 0x20) + 0x18) = iVar6;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar6 + 0x18) < *(int64_t *)(iVar6 + 0x40) + 0x10U)) {
            iVar5 = fcn.180085510(in_stack_00000010);
            if (iVar5 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar1 = (code *)swi(3);
                uVar7 = (*pcVar1)();
                return uVar7;
            }
        }
        puVar8 = *(undefined4 **)(iVar6 + 0x40);
        puVar9 = *(undefined4 **)(arg1 + 0x28);
        if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
            puVar9 = *(undefined4 **)0x180782430;
        }
        uVar2 = puVar9[1];
        uVar3 = puVar9[2];
        uVar4 = puVar9[3];
        *puVar8 = *puVar9;
        puVar8[1] = uVar2;
        puVar8[2] = uVar3;
        puVar8[3] = uVar4;
        *(int64_t *)(iVar6 + 0x40) = *(int64_t *)(iVar6 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar1 = (code *)swi(3);
    uVar7 = (*pcVar1)();
    return uVar7;
}

// ============================================================
// Function: FUN_180091a13
// Address: 0x180091a13
// Size: 132 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800919e0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 != *(undefined4 **)0x180782430) && (puVar8[3] == 8)) {
        iVar6 = func_0x000180085760(arg1);
        if ((*(uint8_t *)(iVar6 + 1) & 4) != 0) {
            *(uint8_t *)(iVar6 + 1) = *(uint8_t *)(iVar6 + 1) & 0xfb;
            *(undefined8 *)(iVar6 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar6 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar6 + 0x20) + 0x18) = iVar6;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar6 + 0x18) < *(int64_t *)(iVar6 + 0x40) + 0x10U)) {
            iVar5 = fcn.180085510(in_stack_00000010);
            if (iVar5 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar1 = (code *)swi(3);
                uVar7 = (*pcVar1)();
                return uVar7;
            }
        }
        puVar8 = *(undefined4 **)(iVar6 + 0x40);
        puVar9 = *(undefined4 **)(arg1 + 0x28);
        if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
            puVar9 = *(undefined4 **)0x180782430;
        }
        uVar2 = puVar9[1];
        uVar3 = puVar9[2];
        uVar4 = puVar9[3];
        *puVar8 = *puVar9;
        puVar8[1] = uVar2;
        puVar8[2] = uVar3;
        puVar8[3] = uVar4;
        *(int64_t *)(iVar6 + 0x40) = *(int64_t *)(iVar6 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar1 = (code *)swi(3);
    uVar7 = (*pcVar1)();
    return uVar7;
}

// ============================================================
// Function: FUN_180091a97
// Address: 0x180091a97
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800919e0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 != *(undefined4 **)0x180782430) && (puVar8[3] == 8)) {
        iVar6 = func_0x000180085760(arg1);
        if ((*(uint8_t *)(iVar6 + 1) & 4) != 0) {
            *(uint8_t *)(iVar6 + 1) = *(uint8_t *)(iVar6 + 1) & 0xfb;
            *(undefined8 *)(iVar6 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar6 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar6 + 0x20) + 0x18) = iVar6;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar6 + 0x18) < *(int64_t *)(iVar6 + 0x40) + 0x10U)) {
            iVar5 = fcn.180085510(in_stack_00000010);
            if (iVar5 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar1 = (code *)swi(3);
                uVar7 = (*pcVar1)();
                return uVar7;
            }
        }
        puVar8 = *(undefined4 **)(iVar6 + 0x40);
        puVar9 = *(undefined4 **)(arg1 + 0x28);
        if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
            puVar9 = *(undefined4 **)0x180782430;
        }
        uVar2 = puVar9[1];
        uVar3 = puVar9[2];
        uVar4 = puVar9[3];
        *puVar8 = *puVar9;
        puVar8[1] = uVar2;
        puVar8[2] = uVar3;
        puVar8[3] = uVar4;
        *(int64_t *)(iVar6 + 0x40) = *(int64_t *)(iVar6 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar1 = (code *)swi(3);
    uVar7 = (*pcVar1)();
    return uVar7;
}

// ============================================================
// Function: FUN_180091aab
// Address: 0x180091aab
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800919e0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 != *(undefined4 **)0x180782430) && (puVar8[3] == 8)) {
        iVar6 = func_0x000180085760(arg1);
        if ((*(uint8_t *)(iVar6 + 1) & 4) != 0) {
            *(uint8_t *)(iVar6 + 1) = *(uint8_t *)(iVar6 + 1) & 0xfb;
            *(undefined8 *)(iVar6 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar6 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar6 + 0x20) + 0x18) = iVar6;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar6 + 0x18) < *(int64_t *)(iVar6 + 0x40) + 0x10U)) {
            iVar5 = fcn.180085510(in_stack_00000010);
            if (iVar5 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar1 = (code *)swi(3);
                uVar7 = (*pcVar1)();
                return uVar7;
            }
        }
        puVar8 = *(undefined4 **)(iVar6 + 0x40);
        puVar9 = *(undefined4 **)(arg1 + 0x28);
        if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
            puVar9 = *(undefined4 **)0x180782430;
        }
        uVar2 = puVar9[1];
        uVar3 = puVar9[2];
        uVar4 = puVar9[3];
        *puVar8 = *puVar9;
        puVar8[1] = uVar2;
        puVar8[2] = uVar3;
        puVar8[3] = uVar4;
        *(int64_t *)(iVar6 + 0x40) = *(int64_t *)(iVar6 + 0x40) + 0x10;
        return 1;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar1 = (code *)swi(3);
    uVar7 = (*pcVar1)();
    return uVar7;
}

// ============================================================
// Function: FUN_180091ad0
// Address: 0x180091ad0
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180091ad0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_18h;
    
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 != *(undefined4 **)0x180782430) && (puVar8[3] == 8)) {
        iVar6 = func_0x000180085760(arg1);
        if ((*(uint8_t *)(iVar6 + 1) & 4) != 0) {
            *(uint8_t *)(iVar6 + 1) = *(uint8_t *)(iVar6 + 1) & 0xfb;
            *(undefined8 *)(iVar6 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar6 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar6 + 0x20) + 0x18) = iVar6;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar6 + 0x18) < *(int64_t *)(iVar6 + 0x40) + 0x10U)) {
            iVar5 = fcn.180085510(unaff_retaddr);
            if (iVar5 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar1 = (code *)swi(3);
                uVar7 = (*pcVar1)();
                return uVar7;
            }
        }
        puVar8 = *(undefined4 **)(iVar6 + 0x40);
        puVar9 = *(undefined4 **)(arg1 + 0x28);
        if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
            puVar9 = *(undefined4 **)0x180782430;
        }
        uVar2 = puVar9[1];
        uVar3 = puVar9[2];
        uVar4 = puVar9[3];
        *puVar8 = *puVar9;
        puVar8[1] = uVar2;
        puVar8[2] = uVar3;
        puVar8[3] = uVar4;
        *(int64_t *)(iVar6 + 0x40) = *(int64_t *)(iVar6 + 0x40) + 0x10;
        func_0x0001800869f0(arg1, fcn.180091850, 0, 1, fcn.180091920);
        return 1;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar1 = (code *)swi(3);
    uVar7 = (*pcVar1)();
    return uVar7;
}

// ============================================================
// Function: FUN_180091b03
// Address: 0x180091b03
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180091ad0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_18h;
    
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 != *(undefined4 **)0x180782430) && (puVar8[3] == 8)) {
        iVar6 = func_0x000180085760(arg1);
        if ((*(uint8_t *)(iVar6 + 1) & 4) != 0) {
            *(uint8_t *)(iVar6 + 1) = *(uint8_t *)(iVar6 + 1) & 0xfb;
            *(undefined8 *)(iVar6 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar6 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar6 + 0x20) + 0x18) = iVar6;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar6 + 0x18) < *(int64_t *)(iVar6 + 0x40) + 0x10U)) {
            iVar5 = fcn.180085510(unaff_retaddr);
            if (iVar5 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar1 = (code *)swi(3);
                uVar7 = (*pcVar1)();
                return uVar7;
            }
        }
        puVar8 = *(undefined4 **)(iVar6 + 0x40);
        puVar9 = *(undefined4 **)(arg1 + 0x28);
        if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
            puVar9 = *(undefined4 **)0x180782430;
        }
        uVar2 = puVar9[1];
        uVar3 = puVar9[2];
        uVar4 = puVar9[3];
        *puVar8 = *puVar9;
        puVar8[1] = uVar2;
        puVar8[2] = uVar3;
        puVar8[3] = uVar4;
        *(int64_t *)(iVar6 + 0x40) = *(int64_t *)(iVar6 + 0x40) + 0x10;
        func_0x0001800869f0(arg1, fcn.180091850, 0, 1, fcn.180091920);
        return 1;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar1 = (code *)swi(3);
    uVar7 = (*pcVar1)();
    return uVar7;
}

// ============================================================
// Function: FUN_180091bab
// Address: 0x180091bab
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180091ad0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_18h;
    
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 != *(undefined4 **)0x180782430) && (puVar8[3] == 8)) {
        iVar6 = func_0x000180085760(arg1);
        if ((*(uint8_t *)(iVar6 + 1) & 4) != 0) {
            *(uint8_t *)(iVar6 + 1) = *(uint8_t *)(iVar6 + 1) & 0xfb;
            *(undefined8 *)(iVar6 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar6 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar6 + 0x20) + 0x18) = iVar6;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar6 + 0x18) < *(int64_t *)(iVar6 + 0x40) + 0x10U)) {
            iVar5 = fcn.180085510(unaff_retaddr);
            if (iVar5 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar1 = (code *)swi(3);
                uVar7 = (*pcVar1)();
                return uVar7;
            }
        }
        puVar8 = *(undefined4 **)(iVar6 + 0x40);
        puVar9 = *(undefined4 **)(arg1 + 0x28);
        if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
            puVar9 = *(undefined4 **)0x180782430;
        }
        uVar2 = puVar9[1];
        uVar3 = puVar9[2];
        uVar4 = puVar9[3];
        *puVar8 = *puVar9;
        puVar8[1] = uVar2;
        puVar8[2] = uVar3;
        puVar8[3] = uVar4;
        *(int64_t *)(iVar6 + 0x40) = *(int64_t *)(iVar6 + 0x40) + 0x10;
        func_0x0001800869f0(arg1, fcn.180091850, 0, 1, fcn.180091920);
        return 1;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar1 = (code *)swi(3);
    uVar7 = (*pcVar1)();
    return uVar7;
}

// ============================================================
// Function: FUN_180091bbf
// Address: 0x180091bbf
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180091ad0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_18h;
    
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 != *(undefined4 **)0x180782430) && (puVar8[3] == 8)) {
        iVar6 = func_0x000180085760(arg1);
        if ((*(uint8_t *)(iVar6 + 1) & 4) != 0) {
            *(uint8_t *)(iVar6 + 1) = *(uint8_t *)(iVar6 + 1) & 0xfb;
            *(undefined8 *)(iVar6 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar6 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar6 + 0x20) + 0x18) = iVar6;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar6 + 0x18) < *(int64_t *)(iVar6 + 0x40) + 0x10U)) {
            iVar5 = fcn.180085510(unaff_retaddr);
            if (iVar5 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar1 = (code *)swi(3);
                uVar7 = (*pcVar1)();
                return uVar7;
            }
        }
        puVar8 = *(undefined4 **)(iVar6 + 0x40);
        puVar9 = *(undefined4 **)(arg1 + 0x28);
        if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
            puVar9 = *(undefined4 **)0x180782430;
        }
        uVar2 = puVar9[1];
        uVar3 = puVar9[2];
        uVar4 = puVar9[3];
        *puVar8 = *puVar9;
        puVar8[1] = uVar2;
        puVar8[2] = uVar3;
        puVar8[3] = uVar4;
        *(int64_t *)(iVar6 + 0x40) = *(int64_t *)(iVar6 + 0x40) + 0x10;
        func_0x0001800869f0(arg1, fcn.180091850, 0, 1, fcn.180091920);
        return 1;
    }
    func_0x000180088470(arg1, 1, 8);
    pcVar1 = (code *)swi(3);
    uVar7 = (*pcVar1)();
    return uVar7;
}

// ============================================================
// Function: FUN_180091be0
// Address: 0x180091be0
// Size: 73 bytes
// ============================================================
undefined8 fcn.180091be0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    
    if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
        *(undefined *)(arg1 + 3) = 1;
        *(int64_t *)(arg1 + 0x28) =
             *(int64_t *)(arg1 + 0x40) +
             (int64_t)(int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) * -0x10;
        return 0xffffffff;
    }
    fcn.180093000(arg1, 0x18063e070);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

