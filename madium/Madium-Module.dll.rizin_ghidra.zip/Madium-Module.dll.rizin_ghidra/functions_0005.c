// Chunk 5 - 50 functions

// ============================================================
// Function: FUN_18000b4d0
// Address: 0x18000b4d0
// Size: 267 bytes
// ============================================================
int64_t fcn.18000b4d0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined *puVar10;
    undefined8 uStack_50;
    undefined auStack_48 [40];
    
    puVar10 = auStack_48;
    *(undefined (*) [16])arg1 = ZEXT816(0);
    uVar9 = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    uVar1 = *(uint64_t *)(arg2 + 0x10);
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    if (0x7fffffffffffffff < uVar1) {
        func_0x0001800047c0();
        pcVar2 = (code *)swi(3);
        iVar8 = (*pcVar2)();
        return iVar8;
    }
    if (uVar1 < 0x10) {
        *(uint64_t *)(arg1 + 0x10) = uVar1;
        *(undefined8 *)(arg1 + 0x18) = 0xf;
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *(undefined4 *)arg1 = *(undefined4 *)arg2;
        *(undefined4 *)(arg1 + 4) = uVar3;
        *(undefined4 *)(arg1 + 8) = uVar4;
        *(undefined4 *)(arg1 + 0xc) = uVar5;
        return arg1;
    }
    uVar6 = uVar1 | 0xf;
    if (uVar6 < 0x8000000000000000) goto code_r0x00018000b564;
    uVar7 = 0x8000000000000027;
    puVar10 = auStack_48;
    uVar6 = 0x7fffffffffffffff;
    while( true ) {
        *(undefined8 *)(puVar10 + -8) = 0x18000b555;
        iVar8 = func_0x000180459890(uVar7);
        if (iVar8 != 0) break;
        pcVar2 = (code *)swi(0x29);
        uVar6 = (*pcVar2)(5);
        puVar10 = puVar10 + 8;
code_r0x00018000b564:
        if (uVar6 < 0x16) {
            uVar6 = 0x16;
        }
        if (uVar6 == 0xffffffffffffffff) goto code_r0x00018000b5a8;
        if (uVar6 + 1 < 0x1000) {
            *(undefined8 *)(puVar10 + -8) = 0x18000b5a8;
            uVar9 = func_0x000180459890();
            goto code_r0x00018000b5a8;
        }
        uVar7 = uVar6 + 0x28;
        if (uVar7 <= uVar6 + 1) {
            *(undefined8 *)(puVar10 + -8) = 0x18000b5da;
            func_0x000180004720();
            pcVar2 = (code *)swi(3);
            iVar8 = (*pcVar2)();
            return iVar8;
        }
    }
    uVar9 = iVar8 + 0x27U & 0xffffffffffffffe0;
    *(int64_t *)(uVar9 - 8) = iVar8;
code_r0x00018000b5a8:
    *(uint64_t *)arg1 = uVar9;
    *(uint64_t *)(arg1 + 0x10) = uVar1;
    *(uint64_t *)(arg1 + 0x18) = uVar6;
    *(undefined8 *)(puVar10 + -8) = 0x18000b5c2;
    func_0x000180498030(uVar9, arg2, uVar1 + 1);
    return arg1;
}

// ============================================================
// Function: FUN_18000b5e0
// Address: 0x18000b5e0
// Size: 33 bytes
// ============================================================
void fcn.18000b5e0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t *piVar2;
    int64_t var_8h;
    
    piVar2 = (int64_t *)fcn.18000da00(arg2);
    cVar1 = (**(code **)(*piVar2 + 0x18))(piVar2);
    if (cVar1 != '\0') {
        *(undefined8 *)(arg1 + 0x68) = 0;
        return;
    }
    *(int64_t **)(arg1 + 0x68) = piVar2;
    *(undefined8 **)(arg1 + 0x18) = (undefined8 *)(arg1 + 8);
    *(undefined8 **)(arg1 + 0x20) = (undefined8 *)(arg1 + 0x10);
    *(undefined8 **)(arg1 + 0x38) = (undefined8 *)(arg1 + 0x28);
    *(undefined8 **)(arg1 + 0x40) = (undefined8 *)(arg1 + 0x30);
    *(undefined4 **)(arg1 + 0x50) = (undefined4 *)(arg1 + 0x48);
    *(undefined4 **)(arg1 + 0x58) = (undefined4 *)(arg1 + 0x4c);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined4 *)(arg1 + 0x4c) = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined4 *)(arg1 + 0x48) = 0;
    return;
}

// ============================================================
// Function: FUN_18000b610
// Address: 0x18000b610
// Size: 71 bytes
// ============================================================
int32_t fcn.18000b610(int64_t arg1)
{
    int32_t iVar1;
    
    if (*(int64_t *)(arg1 + 0x80) != 0) {
        iVar1 = (**(code **)(*(int64_t *)arg1 + 0x18))(arg1, 0xffffffff);
        if (iVar1 != -1) {
            iVar1 = fcn.18045fdf8(*(undefined8 *)(arg1 + 0x80));
            return (-1 < iVar1) - 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18000b660
// Address: 0x18000b660
// Size: 92 bytes
// ============================================================
int64_t fcn.18000b660(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    undefined8 uVar2;
    
    if ((arg2 == 0) && (arg3 == 0)) {
        uVar2 = 4;
    } else {
        uVar2 = 0;
    }
    if (*(int64_t *)(arg1 + 0x80) != 0) {
        iVar1 = func_0x000180460c50(*(int64_t *)(arg1 + 0x80), arg2, uVar2, arg3);
        if (iVar1 == 0) {
            func_0x00018000df00(arg1, *(undefined8 *)(arg1 + 0x80), 1);
            return arg1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18000b6c0
// Address: 0x18000b6c0
// Size: 212 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18000b6c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    undefined8 uVar2;
    char cVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    var_8h = *(int64_t *)(arg3 + 8) + *(int64_t *)arg3;
    if (*(int64_t *)(arg1 + 0x80) != 0) {
        cVar3 = fcn.18000de10();
        if (cVar3 != '\0') {
            iVar4 = fcn.180460f10(*(undefined8 *)(arg1 + 0x80), &var_8h);
            if (iVar4 == 0) {
                *(undefined8 *)(arg1 + 0x74) = *(undefined8 *)(arg3 + 0x10);
                if (**(int64_t **)(arg1 + 0x18) == arg1 + 0x70) {
                    iVar1 = *(int64_t *)(arg1 + 0x88);
                    uVar2 = *(undefined8 *)(arg1 + 0x90);
                    **(int64_t **)(arg1 + 0x18) = iVar1;
                    **(int64_t **)(arg1 + 0x38) = iVar1;
                    **(int32_t **)(arg1 + 0x50) = (int32_t)uVar2 - (int32_t)iVar1;
                }
                uVar2 = *(undefined8 *)(arg1 + 0x74);
                *(int64_t *)arg2 = var_8h;
                *(undefined8 *)(arg2 + 8) = 0;
                *(undefined8 *)(arg2 + 0x10) = uVar2;
                return arg2;
            }
        }
    }
    *(undefined8 *)arg2 = 0xffffffffffffffff;
    *(undefined8 *)(arg2 + 8) = 0;
    *(undefined8 *)(arg2 + 0x10) = 0;
    return arg2;
}

// ============================================================
// Function: FUN_18000b7a0
// Address: 0x18000b7a0
// Size: 199 bytes
// ============================================================
int64_t fcn.18000b7a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 uVar1;
    char cVar2;
    int32_t iVar3;
    int64_t var_8h;
    
    if (((**(int64_t **)(arg1 + 0x38) == arg1 + 0x70) && ((int32_t)arg4 == 1)) && (*(int64_t *)(arg1 + 0x68) == 0)) {
        arg3 = arg3 + -1;
    }
    if (*(int64_t *)(arg1 + 0x80) != 0) {
        cVar2 = fcn.18000de10();
        if (cVar2 != '\0') {
            if ((arg3 != 0) || ((int32_t)arg4 != 1)) {
                iVar3 = func_0x000180461500(*(undefined8 *)(arg1 + 0x80), arg3, arg4 & 0xffffffff);
                if (iVar3 != 0) goto code_r0x00018000b846;
            }
            iVar3 = func_0x000180460adc(*(undefined8 *)(arg1 + 0x80), &var_8h);
            if (iVar3 == 0) {
                func_0x00018000dd60(arg1);
                uVar1 = *(undefined8 *)(arg1 + 0x74);
                *(int64_t *)arg2 = var_8h;
                *(undefined8 *)(arg2 + 8) = 0;
                *(undefined8 *)(arg2 + 0x10) = uVar1;
                return arg2;
            }
        }
    }
code_r0x00018000b846:
    *(undefined8 *)arg2 = 0xffffffffffffffff;
    *(undefined8 *)(arg2 + 8) = 0;
    *(undefined8 *)(arg2 + 0x10) = 0;
    return arg2;
}

// ============================================================
// Function: FUN_18000b870
// Address: 0x18000b870
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18000b870(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar4 = arg3;
    if (*(int64_t *)(arg1 + 0x68) == 0) {
        if (**(int64_t **)(arg1 + 0x40) == 0) {
            iVar1 = 0;
        } else {
            iVar1 = **(int32_t **)(arg1 + 0x58);
        }
        if (0 < arg3) {
            if (0 < iVar1) {
                iVar2 = (int64_t)iVar1;
                if (arg3 < iVar1) {
                    iVar2 = arg3;
                }
                func_0x000180498030(**(int64_t **)(arg1 + 0x40), arg2, iVar2);
                iVar4 = arg3 - iVar2;
                **(int32_t **)(arg1 + 0x58) = **(int32_t **)(arg1 + 0x58) - (int32_t)iVar2;
                **(int64_t **)(arg1 + 0x40) = **(int64_t **)(arg1 + 0x40) + (int64_t)(int32_t)iVar2;
                if (iVar4 < 1) goto code_r0x00018000b988;
                arg2 = arg2 + iVar2;
            }
            if (*(int64_t *)(arg1 + 0x80) != 0) {
                iVar2 = fcn.180460a38(arg2, 1, iVar4);
                iVar4 = iVar4 - iVar2;
            }
        }
    } else if (0 < arg3) {
        do {
            if ((**(int64_t **)(arg1 + 0x40) == 0) || (iVar1 = **(int32_t **)(arg1 + 0x58), iVar1 < 1)) {
                iVar1 = (**(code **)(*(int64_t *)arg1 + 0x18))(arg1, *(undefined *)arg2);
                if (iVar1 == -1) break;
                iVar2 = -1;
                iVar3 = 1;
            } else {
                iVar3 = iVar4;
                if (iVar1 <= iVar4) {
                    iVar3 = (int64_t)iVar1;
                }
                func_0x000180498030(**(int64_t **)(arg1 + 0x40), arg2, iVar3);
                iVar2 = -iVar3;
                **(int32_t **)(arg1 + 0x58) = **(int32_t **)(arg1 + 0x58) - (int32_t)iVar3;
                **(int64_t **)(arg1 + 0x40) = **(int64_t **)(arg1 + 0x40) + (int64_t)(int32_t)iVar3;
            }
            iVar4 = iVar4 + iVar2;
            arg2 = arg2 + iVar3;
        } while (0 < iVar4);
    }
code_r0x00018000b988:
    return arg3 - iVar4;
}

// ============================================================
// Function: FUN_18000b90e
// Address: 0x18000b90e
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18000b870(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar4 = arg3;
    if (*(int64_t *)(arg1 + 0x68) == 0) {
        if (**(int64_t **)(arg1 + 0x40) == 0) {
            iVar1 = 0;
        } else {
            iVar1 = **(int32_t **)(arg1 + 0x58);
        }
        if (0 < arg3) {
            if (0 < iVar1) {
                iVar2 = (int64_t)iVar1;
                if (arg3 < iVar1) {
                    iVar2 = arg3;
                }
                func_0x000180498030(**(int64_t **)(arg1 + 0x40), arg2, iVar2);
                iVar4 = arg3 - iVar2;
                **(int32_t **)(arg1 + 0x58) = **(int32_t **)(arg1 + 0x58) - (int32_t)iVar2;
                **(int64_t **)(arg1 + 0x40) = **(int64_t **)(arg1 + 0x40) + (int64_t)(int32_t)iVar2;
                if (iVar4 < 1) goto code_r0x00018000b988;
                arg2 = arg2 + iVar2;
            }
            if (*(int64_t *)(arg1 + 0x80) != 0) {
                iVar2 = fcn.180460a38(arg2, 1, iVar4);
                iVar4 = iVar4 - iVar2;
            }
        }
    } else if (0 < arg3) {
        do {
            if ((**(int64_t **)(arg1 + 0x40) == 0) || (iVar1 = **(int32_t **)(arg1 + 0x58), iVar1 < 1)) {
                iVar1 = (**(code **)(*(int64_t *)arg1 + 0x18))(arg1, *(undefined *)arg2);
                if (iVar1 == -1) break;
                iVar2 = -1;
                iVar3 = 1;
            } else {
                iVar3 = iVar4;
                if (iVar1 <= iVar4) {
                    iVar3 = (int64_t)iVar1;
                }
                func_0x000180498030(**(int64_t **)(arg1 + 0x40), arg2, iVar3);
                iVar2 = -iVar3;
                **(int32_t **)(arg1 + 0x58) = **(int32_t **)(arg1 + 0x58) - (int32_t)iVar3;
                **(int64_t **)(arg1 + 0x40) = **(int64_t **)(arg1 + 0x40) + (int64_t)(int32_t)iVar3;
            }
            iVar4 = iVar4 + iVar2;
            arg2 = arg2 + iVar3;
        } while (0 < iVar4);
    }
code_r0x00018000b988:
    return arg3 - iVar4;
}

// ============================================================
// Function: FUN_18000b988
// Address: 0x18000b988
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18000b870(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar4 = arg3;
    if (*(int64_t *)(arg1 + 0x68) == 0) {
        if (**(int64_t **)(arg1 + 0x40) == 0) {
            iVar1 = 0;
        } else {
            iVar1 = **(int32_t **)(arg1 + 0x58);
        }
        if (0 < arg3) {
            if (0 < iVar1) {
                iVar2 = (int64_t)iVar1;
                if (arg3 < iVar1) {
                    iVar2 = arg3;
                }
                func_0x000180498030(**(int64_t **)(arg1 + 0x40), arg2, iVar2);
                iVar4 = arg3 - iVar2;
                **(int32_t **)(arg1 + 0x58) = **(int32_t **)(arg1 + 0x58) - (int32_t)iVar2;
                **(int64_t **)(arg1 + 0x40) = **(int64_t **)(arg1 + 0x40) + (int64_t)(int32_t)iVar2;
                if (iVar4 < 1) goto code_r0x00018000b988;
                arg2 = arg2 + iVar2;
            }
            if (*(int64_t *)(arg1 + 0x80) != 0) {
                iVar2 = fcn.180460a38(arg2, 1, iVar4);
                iVar4 = iVar4 - iVar2;
            }
        }
    } else if (0 < arg3) {
        do {
            if ((**(int64_t **)(arg1 + 0x40) == 0) || (iVar1 = **(int32_t **)(arg1 + 0x58), iVar1 < 1)) {
                iVar1 = (**(code **)(*(int64_t *)arg1 + 0x18))(arg1, *(undefined *)arg2);
                if (iVar1 == -1) break;
                iVar2 = -1;
                iVar3 = 1;
            } else {
                iVar3 = iVar4;
                if (iVar1 <= iVar4) {
                    iVar3 = (int64_t)iVar1;
                }
                func_0x000180498030(**(int64_t **)(arg1 + 0x40), arg2, iVar3);
                iVar2 = -iVar3;
                **(int32_t **)(arg1 + 0x58) = **(int32_t **)(arg1 + 0x58) - (int32_t)iVar3;
                **(int64_t **)(arg1 + 0x40) = **(int64_t **)(arg1 + 0x40) + (int64_t)(int32_t)iVar3;
            }
            iVar4 = iVar4 + iVar2;
            arg2 = arg2 + iVar3;
        } while (0 < iVar4);
    }
code_r0x00018000b988:
    return arg3 - iVar4;
}

// ============================================================
// Function: FUN_18000b9a0
// Address: 0x18000b9a0
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18000b9a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg3 < 1) {
        return 0;
    }
    uVar5 = arg3;
    if (*(int64_t *)(arg1 + 0x68) == 0) {
        if (**(int64_t **)(arg1 + 0x38) == 0) {
            iVar2 = 0;
        } else {
            iVar2 = **(int32_t **)(arg1 + 0x50);
        }
        if (iVar2 != 0) {
            uVar4 = arg3;
            if ((uint64_t)(int64_t)iVar2 < (uint64_t)arg3) {
                uVar4 = (int64_t)iVar2;
            }
            fcn.180498030(arg2, **(int64_t **)(arg1 + 0x38), uVar4);
            arg2 = arg2 + uVar4;
            uVar5 = arg3 - uVar4;
            **(int32_t **)(arg1 + 0x50) = **(int32_t **)(arg1 + 0x50) - (int32_t)uVar4;
            **(int64_t **)(arg1 + 0x38) = **(int64_t **)(arg1 + 0x38) + (int64_t)(int32_t)uVar4;
        }
        if (*(int64_t *)(arg1 + 0x80) != 0) {
            if (**(int64_t **)(arg1 + 0x18) == arg1 + 0x70) {
                iVar3 = *(int64_t *)(arg1 + 0x88);
                uVar1 = *(undefined8 *)(arg1 + 0x90);
                **(int64_t **)(arg1 + 0x18) = iVar3;
                **(int64_t **)(arg1 + 0x38) = iVar3;
                **(int32_t **)(arg1 + 0x50) = (int32_t)uVar1 - (int32_t)iVar3;
            }
            while (0xfff < uVar5) {
                iVar3 = fcn.1804611b4(arg2, 1, 0xfff, *(undefined8 *)(arg1 + 0x80));
                uVar5 = uVar5 - iVar3;
                if (iVar3 != 0xfff) goto code_r0x00018000bb34;
                arg2 = arg2 + 0xfff;
            }
            if (uVar5 != 0) {
                iVar3 = fcn.1804611b4(arg2, 1, uVar5, *(undefined8 *)(arg1 + 0x80));
                uVar5 = uVar5 - iVar3;
            }
        }
    } else {
        do {
            if ((**(int64_t **)(arg1 + 0x38) == 0) || (iVar2 = **(int32_t **)(arg1 + 0x50), iVar2 < 1)) {
                iVar2 = (**(code **)(*(int64_t *)arg1 + 0x38))(arg1);
                if (iVar2 == -1) break;
                *(char *)arg2 = (char)iVar2;
                iVar3 = -1;
                uVar4 = 1;
            } else {
                uVar4 = uVar5;
                if ((int64_t)iVar2 <= (int64_t)uVar5) {
                    uVar4 = (int64_t)iVar2;
                }
                fcn.180498030(arg2, **(int64_t **)(arg1 + 0x38), uVar4);
                iVar3 = -uVar4;
                **(int32_t **)(arg1 + 0x50) = **(int32_t **)(arg1 + 0x50) - (int32_t)uVar4;
                **(int64_t **)(arg1 + 0x38) = **(int64_t **)(arg1 + 0x38) + (int64_t)(int32_t)uVar4;
            }
            uVar5 = uVar5 + iVar3;
            arg2 = arg2 + uVar4;
        } while (0 < (int64_t)uVar5);
    }
code_r0x00018000bb34:
    return arg3 - uVar5;
}

// ============================================================
// Function: FUN_18000ba50
// Address: 0x18000ba50
// Size: 228 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18000b9a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg3 < 1) {
        return 0;
    }
    uVar5 = arg3;
    if (*(int64_t *)(arg1 + 0x68) == 0) {
        if (**(int64_t **)(arg1 + 0x38) == 0) {
            iVar2 = 0;
        } else {
            iVar2 = **(int32_t **)(arg1 + 0x50);
        }
        if (iVar2 != 0) {
            uVar4 = arg3;
            if ((uint64_t)(int64_t)iVar2 < (uint64_t)arg3) {
                uVar4 = (int64_t)iVar2;
            }
            fcn.180498030(arg2, **(int64_t **)(arg1 + 0x38), uVar4);
            arg2 = arg2 + uVar4;
            uVar5 = arg3 - uVar4;
            **(int32_t **)(arg1 + 0x50) = **(int32_t **)(arg1 + 0x50) - (int32_t)uVar4;
            **(int64_t **)(arg1 + 0x38) = **(int64_t **)(arg1 + 0x38) + (int64_t)(int32_t)uVar4;
        }
        if (*(int64_t *)(arg1 + 0x80) != 0) {
            if (**(int64_t **)(arg1 + 0x18) == arg1 + 0x70) {
                iVar3 = *(int64_t *)(arg1 + 0x88);
                uVar1 = *(undefined8 *)(arg1 + 0x90);
                **(int64_t **)(arg1 + 0x18) = iVar3;
                **(int64_t **)(arg1 + 0x38) = iVar3;
                **(int32_t **)(arg1 + 0x50) = (int32_t)uVar1 - (int32_t)iVar3;
            }
            while (0xfff < uVar5) {
                iVar3 = fcn.1804611b4(arg2, 1, 0xfff, *(undefined8 *)(arg1 + 0x80));
                uVar5 = uVar5 - iVar3;
                if (iVar3 != 0xfff) goto code_r0x00018000bb34;
                arg2 = arg2 + 0xfff;
            }
            if (uVar5 != 0) {
                iVar3 = fcn.1804611b4(arg2, 1, uVar5, *(undefined8 *)(arg1 + 0x80));
                uVar5 = uVar5 - iVar3;
            }
        }
    } else {
        do {
            if ((**(int64_t **)(arg1 + 0x38) == 0) || (iVar2 = **(int32_t **)(arg1 + 0x50), iVar2 < 1)) {
                iVar2 = (**(code **)(*(int64_t *)arg1 + 0x38))(arg1);
                if (iVar2 == -1) break;
                *(char *)arg2 = (char)iVar2;
                iVar3 = -1;
                uVar4 = 1;
            } else {
                uVar4 = uVar5;
                if ((int64_t)iVar2 <= (int64_t)uVar5) {
                    uVar4 = (int64_t)iVar2;
                }
                fcn.180498030(arg2, **(int64_t **)(arg1 + 0x38), uVar4);
                iVar3 = -uVar4;
                **(int32_t **)(arg1 + 0x50) = **(int32_t **)(arg1 + 0x50) - (int32_t)uVar4;
                **(int64_t **)(arg1 + 0x38) = **(int64_t **)(arg1 + 0x38) + (int64_t)(int32_t)uVar4;
            }
            uVar5 = uVar5 + iVar3;
            arg2 = arg2 + uVar4;
        } while (0 < (int64_t)uVar5);
    }
code_r0x00018000bb34:
    return arg3 - uVar5;
}

// ============================================================
// Function: FUN_18000bb34
// Address: 0x18000bb34
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18000b9a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg3 < 1) {
        return 0;
    }
    uVar5 = arg3;
    if (*(int64_t *)(arg1 + 0x68) == 0) {
        if (**(int64_t **)(arg1 + 0x38) == 0) {
            iVar2 = 0;
        } else {
            iVar2 = **(int32_t **)(arg1 + 0x50);
        }
        if (iVar2 != 0) {
            uVar4 = arg3;
            if ((uint64_t)(int64_t)iVar2 < (uint64_t)arg3) {
                uVar4 = (int64_t)iVar2;
            }
            fcn.180498030(arg2, **(int64_t **)(arg1 + 0x38), uVar4);
            arg2 = arg2 + uVar4;
            uVar5 = arg3 - uVar4;
            **(int32_t **)(arg1 + 0x50) = **(int32_t **)(arg1 + 0x50) - (int32_t)uVar4;
            **(int64_t **)(arg1 + 0x38) = **(int64_t **)(arg1 + 0x38) + (int64_t)(int32_t)uVar4;
        }
        if (*(int64_t *)(arg1 + 0x80) != 0) {
            if (**(int64_t **)(arg1 + 0x18) == arg1 + 0x70) {
                iVar3 = *(int64_t *)(arg1 + 0x88);
                uVar1 = *(undefined8 *)(arg1 + 0x90);
                **(int64_t **)(arg1 + 0x18) = iVar3;
                **(int64_t **)(arg1 + 0x38) = iVar3;
                **(int32_t **)(arg1 + 0x50) = (int32_t)uVar1 - (int32_t)iVar3;
            }
            while (0xfff < uVar5) {
                iVar3 = fcn.1804611b4(arg2, 1, 0xfff, *(undefined8 *)(arg1 + 0x80));
                uVar5 = uVar5 - iVar3;
                if (iVar3 != 0xfff) goto code_r0x00018000bb34;
                arg2 = arg2 + 0xfff;
            }
            if (uVar5 != 0) {
                iVar3 = fcn.1804611b4(arg2, 1, uVar5, *(undefined8 *)(arg1 + 0x80));
                uVar5 = uVar5 - iVar3;
            }
        }
    } else {
        do {
            if ((**(int64_t **)(arg1 + 0x38) == 0) || (iVar2 = **(int32_t **)(arg1 + 0x50), iVar2 < 1)) {
                iVar2 = (**(code **)(*(int64_t *)arg1 + 0x38))(arg1);
                if (iVar2 == -1) break;
                *(char *)arg2 = (char)iVar2;
                iVar3 = -1;
                uVar4 = 1;
            } else {
                uVar4 = uVar5;
                if ((int64_t)iVar2 <= (int64_t)uVar5) {
                    uVar4 = (int64_t)iVar2;
                }
                fcn.180498030(arg2, **(int64_t **)(arg1 + 0x38), uVar4);
                iVar3 = -uVar4;
                **(int32_t **)(arg1 + 0x50) = **(int32_t **)(arg1 + 0x50) - (int32_t)uVar4;
                **(int64_t **)(arg1 + 0x38) = **(int64_t **)(arg1 + 0x38) + (int64_t)(int32_t)uVar4;
            }
            uVar5 = uVar5 + iVar3;
            arg2 = arg2 + uVar4;
        } while (0 < (int64_t)uVar5);
    }
code_r0x00018000bb34:
    return arg3 - uVar5;
}

// ============================================================
// Function: FUN_18000bb50
// Address: 0x18000bb50
// Size: 733 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.18000bb50(int64_t arg1)
{
    undefined8 uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int32_t iVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t *piVar9;
    uint64_t uVar10;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    undefined var_58h;
    int64_t var_57h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    uVar10 = **(uint64_t **)(arg1 + 0x38);
    if (uVar10 != 0) {
        iVar4 = **(int32_t **)(arg1 + 0x50);
        if (uVar10 < uVar10 + (int64_t)iVar4) {
            **(int32_t **)(arg1 + 0x50) = iVar4 + -1;
            **(int64_t **)(arg1 + 0x38) = **(int64_t **)(arg1 + 0x38) + 1;
            puVar7 = auStack_98;
            goto code_r0x00018000be09;
        }
    }
    puVar7 = auStack_98;
    if (*(int64_t *)(arg1 + 0x80) != 0) {
        if (**(int64_t **)(arg1 + 0x18) == arg1 + 0x70) {
            uVar1 = *(undefined8 *)(arg1 + 0x90);
            iVar8 = *(int64_t *)(arg1 + 0x88);
            **(int64_t **)(arg1 + 0x18) = iVar8;
            **(int64_t **)(arg1 + 0x38) = iVar8;
            **(int32_t **)(arg1 + 0x50) = (int32_t)uVar1 - (int32_t)iVar8;
        }
        if (*(int64_t *)(arg1 + 0x68) != 0) {
            var_30h = 0;
            var_28h = 0xf;
            stack0xffffffffffffffc1 = SUB1615(ZEXT816(0), 1);
            auVar3[15] = 0;
            auVar3._0_15_ = stack0xffffffffffffffc1;
            _var_40h = auVar3 << 8;
            uVar5 = func_0x0001804603c4(*(undefined8 *)(arg1 + 0x80));
            uVar10 = var_30h;
            while( true ) {
                var_30h = uVar10;
                if (uVar5 == 0xffffffff) goto code_r0x00018000bd67;
                if (uVar10 < (uint64_t)var_28h) {
                    var_30h = uVar10 + 1;
                    piVar6 = &var_40h;
                    if (0xf < (uint64_t)var_28h) {
                        piVar6 = (int64_t *)var_40h;
                    }
                    *(char *)((int64_t)piVar6 + uVar10) = (char)uVar5;
                    *(undefined *)((int64_t)piVar6 + uVar10 + 1) = 0;
                } else {
                    func_0x00018000f010(&var_40h, 1, (undefined)var_57h, uVar5 & 0xff);
                }
                piVar6 = &var_40h;
                if (0xf < (uint64_t)var_28h) {
                    piVar6 = (int64_t *)var_40h;
                }
                piVar9 = &var_40h;
                if (0xf < (uint64_t)var_28h) {
                    piVar9 = (int64_t *)var_40h;
                }
                var_60h = (int64_t)&var_48h;
                var_68h = (int64_t)&var_57h;
                var_70h = (int64_t)&var_58h;
                var_78h = (int64_t)&var_57h + 7;
                iVar4 = (**(code **)(**(int64_t **)(arg1 + 0x68) + 0x30))
                                  (*(int64_t **)(arg1 + 0x68), arg1 + 0x74, piVar9, var_30h + (int64_t)piVar6);
                if ((iVar4 != 0) && (iVar4 != 1)) goto code_r0x00018000bd67;
                if ((undefined *)var_48h != &var_58h) break;
                piVar6 = &var_40h;
                if (0xf < (uint64_t)var_28h) {
                    piVar6 = (int64_t *)var_40h;
                }
                uVar10 = stack0xffffffffffffffb0 - (int64_t)piVar6;
                if ((uint64_t)var_30h < (uint64_t)(stack0xffffffffffffffb0 - (int64_t)piVar6)) {
                    uVar10 = var_30h;
                }
                piVar6 = &var_40h;
                if (0xf < (uint64_t)var_28h) {
                    piVar6 = (int64_t *)var_40h;
                }
                iVar8 = var_30h - uVar10;
                fcn.180498030(piVar6, (int64_t)piVar6 + uVar10, iVar8 + 1);
                var_30h = iVar8;
                uVar5 = func_0x0001804603c4(*(undefined8 *)(arg1 + 0x80));
                uVar10 = var_30h;
            }
            piVar6 = &var_40h;
            if (0xf < (uint64_t)var_28h) {
                piVar6 = (int64_t *)var_40h;
            }
            iVar8 = (var_30h - stack0xffffffffffffffb0) + (int64_t)piVar6;
            while (0 < iVar8) {
                iVar8 = iVar8 + -1;
                func_0x000180460eb8((int32_t)*(char *)(iVar8 + unique0x1000030f), *(undefined8 *)(arg1 + 0x80));
            }
code_r0x00018000bd67:
            puVar7 = auStack_98;
            if (0xf < (uint64_t)var_28h) {
                iVar8 = var_40h;
                puVar7 = auStack_98;
                if ((0xfff < var_28h + 1U) &&
                   (iVar8 = *(int64_t *)(var_40h + -8), puVar7 = auStack_98, 0x1f < (var_40h - iVar8) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar8 = (*pcVar2)(5);
                    puVar7 = auStack_90;
                }
                *(undefined8 *)(puVar7 + -8) = 0x18000be07;
                func_0x000180459c3c(iVar8);
            }
            goto code_r0x00018000be09;
        }
        iVar4 = func_0x0001804603c4(*(undefined8 *)(arg1 + 0x80));
        puVar7 = auStack_98;
        if (iVar4 != -1) {
            puVar7 = auStack_98;
        }
    }
code_r0x00018000be09:
    *(undefined8 *)(puVar7 + -8) = 0x18000be15;
    fcn.180459870(var_20h ^ (uint64_t)puVar7);
    return;
}

// ============================================================
// Function: FUN_18000be30
// Address: 0x18000be30
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18000be30(int64_t arg1, int64_t arg_38h)
{
    uint8_t *puVar1;
    uint64_t uVar2;
    int64_t var_8h;
    
    puVar1 = **(uint8_t ***)(arg1 + 0x38);
    if ((puVar1 != (uint8_t *)0x0) && (puVar1 < puVar1 + **(int32_t **)(arg1 + 0x50))) {
        return (uint64_t)*puVar1;
    }
    uVar2 = (**(code **)(*(int64_t *)arg1 + 0x38))(arg1);
    if ((int32_t)uVar2 == -1) {
        return uVar2;
    }
    (**(code **)(*(int64_t *)arg1 + 0x20))(arg1, uVar2 & 0xffffffff);
    return uVar2 & 0xffffffff;
}

// ============================================================
// Function: FUN_18000be63
// Address: 0x18000be63
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18000be30(int64_t arg1, int64_t arg_38h)
{
    uint8_t *puVar1;
    uint64_t uVar2;
    int64_t var_8h;
    
    puVar1 = **(uint8_t ***)(arg1 + 0x38);
    if ((puVar1 != (uint8_t *)0x0) && (puVar1 < puVar1 + **(int32_t **)(arg1 + 0x50))) {
        return (uint64_t)*puVar1;
    }
    uVar2 = (**(code **)(*(int64_t *)arg1 + 0x38))(arg1);
    if ((int32_t)uVar2 == -1) {
        return uVar2;
    }
    (**(code **)(*(int64_t *)arg1 + 0x20))(arg1, uVar2 & 0xffffffff);
    return uVar2 & 0xffffffff;
}

// ============================================================
// Function: FUN_18000be7d
// Address: 0x18000be7d
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18000be30(int64_t arg1, int64_t arg_38h)
{
    uint8_t *puVar1;
    uint64_t uVar2;
    int64_t var_8h;
    
    puVar1 = **(uint8_t ***)(arg1 + 0x38);
    if ((puVar1 != (uint8_t *)0x0) && (puVar1 < puVar1 + **(int32_t **)(arg1 + 0x50))) {
        return (uint64_t)*puVar1;
    }
    uVar2 = (**(code **)(*(int64_t *)arg1 + 0x38))(arg1);
    if ((int32_t)uVar2 == -1) {
        return uVar2;
    }
    (**(code **)(*(int64_t *)arg1 + 0x20))(arg1, uVar2 & 0xffffffff);
    return uVar2 & 0xffffffff;
}

// ============================================================
// Function: FUN_18000bea0
// Address: 0x18000bea0
// Size: 225 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18000bea0(int64_t arg1, int64_t arg2)
{
    undefined *puVar1;
    undefined *puVar2;
    int32_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    uVar4 = (uint32_t)arg2;
    uVar5 = **(uint64_t **)(arg1 + 0x38);
    if (((uVar5 != 0) && (**(uint64_t **)(arg1 + 0x18) < uVar5)) &&
       ((uVar4 == 0xffffffff || (*(uint8_t *)(uVar5 - 1) == uVar4)))) {
        **(int32_t **)(arg1 + 0x50) = **(int32_t **)(arg1 + 0x50) + 1;
        **(int64_t **)(arg1 + 0x38) = **(int64_t **)(arg1 + 0x38) + -1;
        uVar5 = arg2 & 0xffffffff;
        if (uVar4 == 0xffffffff) {
            uVar5 = 0;
        }
        return uVar5;
    }
    if ((*(int64_t *)(arg1 + 0x80) != 0) && (uVar4 != 0xffffffff)) {
        if ((*(int64_t *)(arg1 + 0x68) == 0) && (iVar3 = func_0x000180460eb8(arg2 & 0xff), iVar3 != -1)) {
            return arg2 & 0xffffffffU;
        }
        puVar1 = (undefined *)(arg1 + 0x70);
        if ((undefined *)**(int64_t **)(arg1 + 0x38) != puVar1) {
            *puVar1 = (char)(arg2 & 0xffffffffU);
            puVar2 = (undefined *)**(int64_t **)(arg1 + 0x18);
            if (puVar2 != puVar1) {
                *(undefined **)(arg1 + 0x88) = puVar2;
                *(int64_t *)(arg1 + 0x90) = (int64_t)**(int32_t **)(arg1 + 0x50) + **(int64_t **)(arg1 + 0x38);
            }
            **(int64_t **)(arg1 + 0x18) = (int64_t)puVar1;
            **(int64_t **)(arg1 + 0x38) = (int64_t)puVar1;
            **(int32_t **)(arg1 + 0x50) = ((int32_t)arg1 - (int32_t)puVar1) + 0x71;
            return arg2 & 0xffffffff;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18000bf90
// Address: 0x18000bf90
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18000bf90(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    char *pcVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    char cVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_88 [32];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    cVar5 = (char)arg2;
    if ((int32_t)arg2 != -1) {
        uVar1 = **(uint64_t **)(arg1 + 0x40);
        if (uVar1 != 0) {
            iVar6 = **(int32_t **)(arg1 + 0x58);
            if (uVar1 < uVar1 + (int64_t)iVar6) {
                **(int32_t **)(arg1 + 0x58) = iVar6 + -1;
                pcVar2 = **(char ***)(arg1 + 0x40);
                **(char ***)(arg1 + 0x40) = pcVar2 + 1;
                *pcVar2 = cVar5;
                goto code_r0x00018000c10b;
            }
        }
        if (*(int64_t *)(arg1 + 0x80) != 0) {
            if (**(int64_t **)(arg1 + 0x18) == arg1 + 0x70) {
                iVar8 = *(int64_t *)(arg1 + 0x88);
                uVar3 = *(undefined8 *)(arg1 + 0x90);
                **(int64_t **)(arg1 + 0x18) = iVar8;
                **(int64_t **)(arg1 + 0x38) = iVar8;
                **(int32_t **)(arg1 + 0x50) = (int32_t)uVar3 - (int32_t)iVar8;
            }
            piVar4 = *(int64_t **)(arg1 + 0x68);
            if (piVar4 != (int64_t *)0x0) {
                var_50h = (int64_t)&var_40h;
                var_58h = (int64_t)&var_10h;
                var_60h = (int64_t)&var_30h;
                var_68h = (int64_t)&var_38h;
                var_48h._0_1_ = cVar5;
                iVar6 = (**(code **)(*piVar4 + 0x38))(piVar4, arg1 + 0x74, &var_48h, (int64_t)&var_48h + 1);
                if ((iVar6 == 0) || (iVar6 == 1)) {
                    iVar8 = var_40h - (int64_t)&var_30h;
                    if ((iVar8 == 0) ||
                       (iVar7 = fcn.180460a38(&var_30h, 1, iVar8, *(undefined8 *)(arg1 + 0x80)), iVar8 == iVar7)) {
                        *(undefined *)(arg1 + 0x71) = 1;
                    }
                    goto code_r0x00018000c10b;
                }
                cVar5 = (char)var_48h;
                if (iVar6 != 3) goto code_r0x00018000c10b;
            }
            func_0x00018045f9d8((int32_t)cVar5, *(undefined8 *)(arg1 + 0x80));
        }
    }
code_r0x00018000c10b:
    fcn.180459870(var_10h ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_18000bfff
// Address: 0x18000bfff
// Size: 268 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18000bf90(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    char *pcVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    char cVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_88 [32];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    cVar5 = (char)arg2;
    if ((int32_t)arg2 != -1) {
        uVar1 = **(uint64_t **)(arg1 + 0x40);
        if (uVar1 != 0) {
            iVar6 = **(int32_t **)(arg1 + 0x58);
            if (uVar1 < uVar1 + (int64_t)iVar6) {
                **(int32_t **)(arg1 + 0x58) = iVar6 + -1;
                pcVar2 = **(char ***)(arg1 + 0x40);
                **(char ***)(arg1 + 0x40) = pcVar2 + 1;
                *pcVar2 = cVar5;
                goto code_r0x00018000c10b;
            }
        }
        if (*(int64_t *)(arg1 + 0x80) != 0) {
            if (**(int64_t **)(arg1 + 0x18) == arg1 + 0x70) {
                iVar8 = *(int64_t *)(arg1 + 0x88);
                uVar3 = *(undefined8 *)(arg1 + 0x90);
                **(int64_t **)(arg1 + 0x18) = iVar8;
                **(int64_t **)(arg1 + 0x38) = iVar8;
                **(int32_t **)(arg1 + 0x50) = (int32_t)uVar3 - (int32_t)iVar8;
            }
            piVar4 = *(int64_t **)(arg1 + 0x68);
            if (piVar4 != (int64_t *)0x0) {
                var_50h = (int64_t)&var_40h;
                var_58h = (int64_t)&var_10h;
                var_60h = (int64_t)&var_30h;
                var_68h = (int64_t)&var_38h;
                var_48h._0_1_ = cVar5;
                iVar6 = (**(code **)(*piVar4 + 0x38))(piVar4, arg1 + 0x74, &var_48h, (int64_t)&var_48h + 1);
                if ((iVar6 == 0) || (iVar6 == 1)) {
                    iVar8 = var_40h - (int64_t)&var_30h;
                    if ((iVar8 == 0) ||
                       (iVar7 = fcn.180460a38(&var_30h, 1, iVar8, *(undefined8 *)(arg1 + 0x80)), iVar8 == iVar7)) {
                        *(undefined *)(arg1 + 0x71) = 1;
                    }
                    goto code_r0x00018000c10b;
                }
                cVar5 = (char)var_48h;
                if (iVar6 != 3) goto code_r0x00018000c10b;
            }
            func_0x00018045f9d8((int32_t)cVar5, *(undefined8 *)(arg1 + 0x80));
        }
    }
code_r0x00018000c10b:
    fcn.180459870(var_10h ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_18000c10b
// Address: 0x18000c10b
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.18000bf90(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    char *pcVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    char cVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_88 [32];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    cVar5 = (char)arg2;
    if ((int32_t)arg2 != -1) {
        uVar1 = **(uint64_t **)(arg1 + 0x40);
        if (uVar1 != 0) {
            iVar6 = **(int32_t **)(arg1 + 0x58);
            if (uVar1 < uVar1 + (int64_t)iVar6) {
                **(int32_t **)(arg1 + 0x58) = iVar6 + -1;
                pcVar2 = **(char ***)(arg1 + 0x40);
                **(char ***)(arg1 + 0x40) = pcVar2 + 1;
                *pcVar2 = cVar5;
                goto code_r0x00018000c10b;
            }
        }
        if (*(int64_t *)(arg1 + 0x80) != 0) {
            if (**(int64_t **)(arg1 + 0x18) == arg1 + 0x70) {
                iVar8 = *(int64_t *)(arg1 + 0x88);
                uVar3 = *(undefined8 *)(arg1 + 0x90);
                **(int64_t **)(arg1 + 0x18) = iVar8;
                **(int64_t **)(arg1 + 0x38) = iVar8;
                **(int32_t **)(arg1 + 0x50) = (int32_t)uVar3 - (int32_t)iVar8;
            }
            piVar4 = *(int64_t **)(arg1 + 0x68);
            if (piVar4 != (int64_t *)0x0) {
                var_50h = (int64_t)&var_40h;
                var_58h = (int64_t)&var_10h;
                var_60h = (int64_t)&var_30h;
                var_68h = (int64_t)&var_38h;
                var_48h._0_1_ = cVar5;
                iVar6 = (**(code **)(*piVar4 + 0x38))(piVar4, arg1 + 0x74, &var_48h, (int64_t)&var_48h + 1);
                if ((iVar6 == 0) || (iVar6 == 1)) {
                    iVar8 = var_40h - (int64_t)&var_30h;
                    if ((iVar8 == 0) ||
                       (iVar7 = fcn.180460a38(&var_30h, 1, iVar8, *(undefined8 *)(arg1 + 0x80)), iVar8 == iVar7)) {
                        *(undefined *)(arg1 + 0x71) = 1;
                    }
                    goto code_r0x00018000c10b;
                }
                cVar5 = (char)var_48h;
                if (iVar6 != 3) goto code_r0x00018000c10b;
            }
            func_0x00018045f9d8((int32_t)cVar5, *(undefined8 *)(arg1 + 0x80));
        }
    }
code_r0x00018000c10b:
    fcn.180459870(var_10h ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_18000c170
// Address: 0x18000c170
// Size: 349 bytes
// ============================================================
void fcn.18000c170(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined8 *puVar5;
    undefined4 *puVar6;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    *(undefined8 *)arg1 = 0x1805a0888;
    if ((*(int64_t *)(arg1 + 0x80) != 0) && (**(int64_t **)(arg1 + 0x18) == arg1 + 0x70)) {
        uVar1 = *(undefined8 *)(arg1 + 0x90);
        iVar2 = *(int64_t *)(arg1 + 0x88);
        **(int64_t **)(arg1 + 0x18) = iVar2;
        **(int64_t **)(arg1 + 0x38) = iVar2;
        **(int32_t **)(arg1 + 0x50) = (int32_t)uVar1 - (int32_t)iVar2;
    }
    if (*(char *)(arg1 + 0x7c) != '\0') {
        if (*(int64_t *)(arg1 + 0x80) != 0) {
            if (**(int64_t **)(arg1 + 0x18) == arg1 + 0x70) {
                uVar1 = *(undefined8 *)(arg1 + 0x90);
                iVar2 = *(int64_t *)(arg1 + 0x88);
                **(int64_t **)(arg1 + 0x18) = iVar2;
                **(int64_t **)(arg1 + 0x38) = iVar2;
                **(int32_t **)(arg1 + 0x50) = (int32_t)uVar1 - (int32_t)iVar2;
            }
            fcn.18000de10(arg1);
            func_0x00018045ff84(*(undefined8 *)(arg1 + 0x80));
        }
        *(undefined *)(arg1 + 0x7c) = 0;
        *(undefined *)(arg1 + 0x71) = 0;
        *(int64_t *)(arg1 + 0x18) = arg1 + 8;
        *(undefined8 **)(arg1 + 0x20) = (undefined8 *)(arg1 + 0x10);
        *(int64_t *)(arg1 + 0x38) = arg1 + 0x28;
        *(undefined8 **)(arg1 + 0x40) = (undefined8 *)(arg1 + 0x30);
        *(int64_t *)(arg1 + 0x50) = arg1 + 0x48;
        *(undefined4 **)(arg1 + 0x58) = (undefined4 *)(arg1 + 0x4c);
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined8 *)(arg1 + 0x30) = 0;
        *(undefined4 *)(arg1 + 0x4c) = 0;
        **(undefined8 **)(arg1 + 0x18) = 0;
        **(undefined8 **)(arg1 + 0x38) = 0;
        **(undefined4 **)(arg1 + 0x50) = 0;
        *(undefined8 *)(arg1 + 0x80) = 0;
        *(undefined8 *)(arg1 + 0x74) = *(undefined8 *)0x1807823f8;
        *(undefined8 *)(arg1 + 0x68) = 0;
    }
    *(undefined8 *)arg1 = 0x1804a5500;
    iVar2 = *(int64_t *)(arg1 + 0x60);
    if (iVar2 == 0) {
        return;
    }
    if ((*(int64_t **)(iVar2 + 8) != (int64_t *)0x0) &&
       (puVar5 = (undefined8 *)(**(code **)(**(int64_t **)(iVar2 + 8) + 0x10))(), puVar5 != (undefined8 *)0x0)) {
        (**(code **)*puVar5)(puVar5, 1);
    }
    if ((iVar2 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar2, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = func_0x00018046b63c(uVar4);
        puVar6 = (undefined4 *)fcn.18046b77c();
        *puVar6 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18000c2d0
// Address: 0x18000c2d0
// Size: 281 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18000c2d0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((int32_t)arg2 != 0) {
        *(undefined8 *)arg1 = 0x1805ab1e0;
        *(undefined8 *)(arg1 + 0x90) = 0;
        *(undefined8 *)(arg1 + 0x98) = 0;
        *(undefined4 *)(arg1 + 0xa0) = 0;
        *(undefined8 *)(arg1 + 0xa8) = 0;
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xb8) = 0;
        *(undefined8 *)(arg1 + 0xc0) = 0;
        *(undefined8 *)(arg1 + 200) = 0;
        *(undefined8 *)(arg1 + 0x88) = 0x1804a54e0;
        *(undefined8 *)(arg1 + 0xd0) = 0;
        *(undefined8 *)(arg1 + 0xd8) = 0;
        *(undefined *)(arg1 + 0xe0) = 0;
    }
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a54f0;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x10;
    fcn.18000fe50(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1, arg1 + 8, 0);
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a6448;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x88;
    fcn.18000fd90(arg1 + 8);
    *(undefined8 *)(arg1 + 8) = 0x1804a5580;
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined4 *)(arg1 + 0x78) = 4;
    return arg1;
}

// ============================================================
// Function: FUN_18000c3f0
// Address: 0x18000c3f0
// Size: 171 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18000c3f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    bool bVar7;
    bool bVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (((arg4 & 1U) == 0) || ((*(uint8_t *)(arg1 + 0x70) & 4) == 0)) {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    if (((arg4 & 2U) == 0) || ((*(uint8_t *)(arg1 + 0x70) & 2) == 0)) {
        bVar8 = false;
    } else {
        bVar8 = true;
    }
    if ((!bVar7) && (!bVar8)) {
        uVar10 = *(int64_t *)(arg3 + 8) + *(int64_t *)arg3;
        iVar3 = **(int64_t **)(arg1 + 0x38);
        if ((*(uint8_t *)(arg1 + 0x70) & 2) == 0) {
            uVar9 = **(uint64_t **)(arg1 + 0x40);
            if ((uVar9 != 0) && (*(uint64_t *)(arg1 + 0x68) < uVar9)) {
                *(uint64_t *)(arg1 + 0x68) = uVar9;
            }
        } else {
            uVar9 = 0;
        }
        iVar4 = *(int64_t *)(arg1 + 0x68);
        iVar5 = **(int64_t **)(arg1 + 0x18);
        if ((uVar10 <= (uint64_t)(iVar4 - iVar5)) &&
           ((uVar10 == 0 || ((((arg4 & 1U) == 0 || (iVar3 != 0)) && (((arg4 & 2U) == 0 || (uVar9 != 0)))))))) {
            iVar1 = iVar5 + uVar10;
            if (((arg4 & 1U) != 0) && (iVar3 != 0)) {
                **(int64_t **)(arg1 + 0x38) = iVar1;
                **(int32_t **)(arg1 + 0x50) = (int32_t)iVar4 - (int32_t)iVar1;
            }
            if (((arg4 & 2U) != 0) && (uVar9 != 0)) {
                iVar2 = **(int32_t **)(arg1 + 0x58);
                uVar6 = **(undefined8 **)(arg1 + 0x40);
                **(int64_t **)(arg1 + 0x20) = iVar5;
                **(int64_t **)(arg1 + 0x40) = iVar1;
                **(int32_t **)(arg1 + 0x58) = (iVar2 + (int32_t)uVar6) - (int32_t)iVar1;
            }
            *(uint64_t *)arg2 = uVar10;
            goto code_r0x00018000c4f9;
        }
    }
    *(undefined8 *)arg2 = 0xffffffffffffffff;
code_r0x00018000c4f9:
    *(undefined8 *)(arg2 + 8) = 0;
    *(undefined8 *)(arg2 + 0x10) = 0;
    return arg2;
}

// ============================================================
// Function: FUN_18000c49b
// Address: 0x18000c49b
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18000c3f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    bool bVar7;
    bool bVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (((arg4 & 1U) == 0) || ((*(uint8_t *)(arg1 + 0x70) & 4) == 0)) {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    if (((arg4 & 2U) == 0) || ((*(uint8_t *)(arg1 + 0x70) & 2) == 0)) {
        bVar8 = false;
    } else {
        bVar8 = true;
    }
    if ((!bVar7) && (!bVar8)) {
        uVar10 = *(int64_t *)(arg3 + 8) + *(int64_t *)arg3;
        iVar3 = **(int64_t **)(arg1 + 0x38);
        if ((*(uint8_t *)(arg1 + 0x70) & 2) == 0) {
            uVar9 = **(uint64_t **)(arg1 + 0x40);
            if ((uVar9 != 0) && (*(uint64_t *)(arg1 + 0x68) < uVar9)) {
                *(uint64_t *)(arg1 + 0x68) = uVar9;
            }
        } else {
            uVar9 = 0;
        }
        iVar4 = *(int64_t *)(arg1 + 0x68);
        iVar5 = **(int64_t **)(arg1 + 0x18);
        if ((uVar10 <= (uint64_t)(iVar4 - iVar5)) &&
           ((uVar10 == 0 || ((((arg4 & 1U) == 0 || (iVar3 != 0)) && (((arg4 & 2U) == 0 || (uVar9 != 0)))))))) {
            iVar1 = iVar5 + uVar10;
            if (((arg4 & 1U) != 0) && (iVar3 != 0)) {
                **(int64_t **)(arg1 + 0x38) = iVar1;
                **(int32_t **)(arg1 + 0x50) = (int32_t)iVar4 - (int32_t)iVar1;
            }
            if (((arg4 & 2U) != 0) && (uVar9 != 0)) {
                iVar2 = **(int32_t **)(arg1 + 0x58);
                uVar6 = **(undefined8 **)(arg1 + 0x40);
                **(int64_t **)(arg1 + 0x20) = iVar5;
                **(int64_t **)(arg1 + 0x40) = iVar1;
                **(int32_t **)(arg1 + 0x58) = (iVar2 + (int32_t)uVar6) - (int32_t)iVar1;
            }
            *(uint64_t *)arg2 = uVar10;
            goto code_r0x00018000c4f9;
        }
    }
    *(undefined8 *)arg2 = 0xffffffffffffffff;
code_r0x00018000c4f9:
    *(undefined8 *)(arg2 + 8) = 0;
    *(undefined8 *)(arg2 + 0x10) = 0;
    return arg2;
}

// ============================================================
// Function: FUN_18000c4f2
// Address: 0x18000c4f2
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18000c3f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    bool bVar7;
    bool bVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (((arg4 & 1U) == 0) || ((*(uint8_t *)(arg1 + 0x70) & 4) == 0)) {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    if (((arg4 & 2U) == 0) || ((*(uint8_t *)(arg1 + 0x70) & 2) == 0)) {
        bVar8 = false;
    } else {
        bVar8 = true;
    }
    if ((!bVar7) && (!bVar8)) {
        uVar10 = *(int64_t *)(arg3 + 8) + *(int64_t *)arg3;
        iVar3 = **(int64_t **)(arg1 + 0x38);
        if ((*(uint8_t *)(arg1 + 0x70) & 2) == 0) {
            uVar9 = **(uint64_t **)(arg1 + 0x40);
            if ((uVar9 != 0) && (*(uint64_t *)(arg1 + 0x68) < uVar9)) {
                *(uint64_t *)(arg1 + 0x68) = uVar9;
            }
        } else {
            uVar9 = 0;
        }
        iVar4 = *(int64_t *)(arg1 + 0x68);
        iVar5 = **(int64_t **)(arg1 + 0x18);
        if ((uVar10 <= (uint64_t)(iVar4 - iVar5)) &&
           ((uVar10 == 0 || ((((arg4 & 1U) == 0 || (iVar3 != 0)) && (((arg4 & 2U) == 0 || (uVar9 != 0)))))))) {
            iVar1 = iVar5 + uVar10;
            if (((arg4 & 1U) != 0) && (iVar3 != 0)) {
                **(int64_t **)(arg1 + 0x38) = iVar1;
                **(int32_t **)(arg1 + 0x50) = (int32_t)iVar4 - (int32_t)iVar1;
            }
            if (((arg4 & 2U) != 0) && (uVar9 != 0)) {
                iVar2 = **(int32_t **)(arg1 + 0x58);
                uVar6 = **(undefined8 **)(arg1 + 0x40);
                **(int64_t **)(arg1 + 0x20) = iVar5;
                **(int64_t **)(arg1 + 0x40) = iVar1;
                **(int32_t **)(arg1 + 0x58) = (iVar2 + (int32_t)uVar6) - (int32_t)iVar1;
            }
            *(uint64_t *)arg2 = uVar10;
            goto code_r0x00018000c4f9;
        }
    }
    *(undefined8 *)arg2 = 0xffffffffffffffff;
code_r0x00018000c4f9:
    *(undefined8 *)(arg2 + 8) = 0;
    *(undefined8 *)(arg2 + 0x10) = 0;
    return arg2;
}

// ============================================================
// Function: FUN_18000c520
// Address: 0x18000c520
// Size: 405 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18000c520(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    bool bVar6;
    bool bVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (((arg_28h & 1U) == 0) || ((*(uint8_t *)(arg1 + 0x70) & 4) == 0)) {
        bVar6 = false;
    } else {
        bVar6 = true;
    }
    if (((arg_28h & 2U) == 0) || ((*(uint8_t *)(arg1 + 0x70) & 2) == 0)) {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    if ((bVar6) || (bVar7)) goto code_r0x00018000c684;
    iVar2 = **(int64_t **)(arg1 + 0x38);
    if ((*(uint8_t *)(arg1 + 0x70) & 2) == 0) {
        uVar9 = **(uint64_t **)(arg1 + 0x40);
        if ((uVar9 != 0) && (*(uint64_t *)(arg1 + 0x68) < uVar9)) {
            *(uint64_t *)(arg1 + 0x68) = uVar9;
        }
    } else {
        uVar9 = 0;
    }
    iVar3 = *(int64_t *)(arg1 + 0x68);
    iVar4 = **(int64_t **)(arg1 + 0x18);
    uVar10 = iVar3 - iVar4;
    iVar11 = (int32_t)arg4;
    if (iVar11 == 0) {
        uVar8 = 0;
code_r0x00018000c614:
        uVar8 = uVar8 + arg3;
        if ((uVar8 <= uVar10) &&
           ((uVar8 == 0 || ((((arg_28h & 1U) == 0 || (iVar2 != 0)) && (((arg_28h & 2U) == 0 || (uVar9 != 0)))))))) {
            iVar1 = uVar8 + iVar4;
            if (((arg_28h & 1U) != 0) && (iVar2 != 0)) {
                **(int64_t **)(arg1 + 0x38) = iVar1;
                **(int32_t **)(arg1 + 0x50) = (int32_t)iVar3 - (int32_t)iVar1;
            }
            if (((arg_28h & 2U) != 0) && (uVar9 != 0)) {
                iVar11 = **(int32_t **)(arg1 + 0x58);
                uVar5 = **(undefined8 **)(arg1 + 0x40);
                **(int64_t **)(arg1 + 0x20) = iVar4;
                **(int64_t **)(arg1 + 0x40) = iVar1;
                **(int32_t **)(arg1 + 0x58) = (iVar11 + (int32_t)uVar5) - (int32_t)iVar1;
            }
            *(uint64_t *)arg2 = uVar8;
            goto code_r0x00018000c68b;
        }
    } else if (iVar11 == 1) {
        if (((uint8_t)arg_28h & 3) != 3) {
            if ((arg_28h & 1U) == 0) {
                if (((arg_28h & 2U) != 0) && ((uVar9 != 0 || (iVar4 == 0)))) {
                    uVar8 = uVar9 - iVar4;
                    goto code_r0x00018000c614;
                }
            } else if ((iVar2 != 0) || (iVar4 == 0)) {
                uVar8 = iVar2 - iVar4;
                goto code_r0x00018000c614;
            }
        }
    } else {
        uVar8 = uVar10;
        if (iVar11 == 2) goto code_r0x00018000c614;
    }
code_r0x00018000c684:
    *(undefined8 *)arg2 = 0xffffffffffffffff;
code_r0x00018000c68b:
    *(undefined8 *)(arg2 + 8) = 0;
    *(undefined8 *)(arg2 + 0x10) = 0;
    return arg2;
}

// ============================================================
// Function: FUN_18000c780
// Address: 0x18000c780
// Size: 495 bytes
// ============================================================
uint64_t fcn.18000c780(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    undefined8 uVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    
    puVar5 = auStack_58;
    puVar6 = auStack_58;
    uVar4 = arg2 & 0xffffffff;
    if ((*(uint8_t *)(arg1 + 0x70) & 2) != 0) {
        return 0xffffffff;
    }
    if ((int32_t)arg2 == -1) {
        return 0;
    }
    uVar8 = **(uint64_t **)(arg1 + 0x40);
    if (uVar8 == 0) {
        uVar9 = 0;
        iVar7 = **(int64_t **)(arg1 + 0x18);
code_r0x00018000c887:
        uVar8 = 0x20;
    } else {
        iVar1 = **(int32_t **)(arg1 + 0x58);
        uVar9 = uVar8 + (int64_t)iVar1;
        if (uVar8 < uVar9) {
            **(int32_t **)(arg1 + 0x58) = iVar1 + -1;
            puVar6 = (undefined *)**(int64_t **)(arg1 + 0x40);
            **(int64_t **)(arg1 + 0x40) = (int64_t)(puVar6 + 1);
            *puVar6 = (char)uVar4;
            *(uint64_t *)(arg1 + 0x68) = uVar8 + 1;
            return uVar4;
        }
        iVar7 = **(int64_t **)(arg1 + 0x18);
        uVar9 = uVar9 - iVar7;
        if (uVar9 < 0x20) goto code_r0x00018000c887;
        if (0x3ffffffe < uVar9) {
            uVar8 = 0x7fffffff;
            if (0x7ffffffe < uVar9) {
                return 0xffffffff;
            }
            uVar11 = 0x80000026;
code_r0x00018000c85b:
            iVar10 = fcn.180459890(uVar11);
            if (iVar10 == 0) {
                pcVar3 = (code *)swi(0x29);
                iVar10 = (*pcVar3)(5);
                puVar5 = auStack_50;
            }
            uVar11 = iVar10 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar11 - 8) = iVar10;
            puVar6 = puVar5;
            goto code_r0x00018000c897;
        }
        uVar8 = uVar9 * 2;
        if (uVar8 == 0) {
            uVar11 = 0;
            puVar6 = auStack_58;
            goto code_r0x00018000c897;
        }
        if (0xfff < uVar8) {
            uVar11 = uVar8 + 0x27;
            if (uVar11 <= uVar8) {
                fcn.180004720();
                pcVar3 = (code *)swi(3);
                uVar4 = (*pcVar3)();
                return uVar4;
            }
            goto code_r0x00018000c85b;
        }
    }
    uVar11 = fcn.180459890(uVar8);
code_r0x00018000c897:
    *(undefined8 *)(puVar6 + -8) = 0x18000c8a5;
    fcn.180498030(uVar11, iVar7, uVar9);
    iVar10 = uVar11 + uVar9;
    *(int64_t *)(arg1 + 0x68) = iVar10 + 1;
    **(uint64_t **)(arg1 + 0x20) = uVar11;
    **(int64_t **)(arg1 + 0x40) = iVar10;
    **(int32_t **)(arg1 + 0x58) = ((int32_t)uVar11 - (int32_t)iVar10) + (int32_t)uVar8;
    if ((*(uint8_t *)(arg1 + 0x70) & 4) == 0) {
        uVar2 = *(undefined8 *)(arg1 + 0x68);
        iVar10 = (**(int64_t **)(arg1 + 0x38) - iVar7) + uVar11;
        **(uint64_t **)(arg1 + 0x18) = uVar11;
        **(int64_t **)(arg1 + 0x38) = iVar10;
        **(int32_t **)(arg1 + 0x50) = (int32_t)uVar2 - (int32_t)iVar10;
    } else {
        **(uint64_t **)(arg1 + 0x18) = uVar11;
        **(uint64_t **)(arg1 + 0x38) = uVar11;
        **(undefined4 **)(arg1 + 0x50) = 0;
    }
    if ((*(uint8_t *)(arg1 + 0x70) & 1) != 0) {
        *(undefined8 *)(puVar6 + -8) = 0x18000c928;
        fcn.180005aa0(arg1 + 0x74, iVar7, uVar9);
    }
    *(uint32_t *)(arg1 + 0x70) = *(uint32_t *)(arg1 + 0x70) | 1;
    **(int32_t **)(arg1 + 0x58) = **(int32_t **)(arg1 + 0x58) + -1;
    puVar6 = (undefined *)**(int64_t **)(arg1 + 0x40);
    **(int64_t **)(arg1 + 0x40) = (int64_t)(puVar6 + 1);
    *puVar6 = (char)uVar4;
    return uVar4;
}

// ============================================================
// Function: FUN_18000c970
// Address: 0x18000c970
// Size: 257 bytes
// ============================================================
void fcn.18000c970(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    undefined *puVar5;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    
    puVar5 = auStack_48;
    *(undefined8 *)arg1 = 0x1804a5580;
    if ((*(uint8_t *)(arg1 + 0x70) & 1) != 0) {
        if (**(int64_t **)(arg1 + 0x40) == 0) {
            iVar4 = (int64_t)**(int32_t **)(arg1 + 0x50) + **(int64_t **)(arg1 + 0x38);
        } else {
            iVar4 = (int64_t)**(int32_t **)(arg1 + 0x58) + **(int64_t **)(arg1 + 0x40);
        }
        iVar1 = **(int64_t **)(arg1 + 0x18);
        puVar5 = auStack_48;
        if ((0xfff < (uint64_t)(iVar4 - iVar1)) && (puVar5 = auStack_48, 0x1f < (iVar1 - *(int64_t *)(iVar1 + -8)) - 8U)
           ) {
            pcVar2 = (code *)swi(0x29);
            (*pcVar2)();
            puVar5 = auStack_40;
        }
        *(undefined8 *)(puVar5 + -8) = 0x18000c9f1;
        func_0x000180459c3c();
    }
    **(undefined8 **)(arg1 + 0x18) = 0;
    **(undefined8 **)(arg1 + 0x38) = 0;
    **(undefined4 **)(arg1 + 0x50) = 0;
    **(undefined8 **)(arg1 + 0x20) = 0;
    **(undefined8 **)(arg1 + 0x40) = 0;
    **(undefined4 **)(arg1 + 0x58) = 0;
    *(uint32_t *)(arg1 + 0x70) = *(uint32_t *)(arg1 + 0x70) & 0xfffffffe;
    *(undefined8 *)arg1 = 0x1804a5500;
    *(undefined8 *)(arg1 + 0x68) = 0;
    iVar4 = *(int64_t *)(arg1 + 0x60);
    if (iVar4 != 0) {
        if (*(int64_t **)(iVar4 + 8) != (int64_t *)0x0) {
            pcVar2 = *(code **)(**(int64_t **)(iVar4 + 8) + 0x10);
            *(undefined8 *)(puVar5 + -8) = 0x18000ca45;
            puVar3 = (undefined8 *)(*pcVar2)();
            if (puVar3 != (undefined8 *)0x0) {
                pcVar2 = *(code **)*puVar3;
                *(undefined8 *)(puVar5 + -8) = 0x18000ca58;
                (*pcVar2)(puVar3, 1);
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18000ca65;
        func_0x000180459c3c(iVar4, 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_18000ca80
// Address: 0x18000ca80
// Size: 813 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h

int64_t fcn.18000ca80(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    int64_t *piVar1;
    uint8_t *puVar2;
    uint8_t **ppuVar3;
    int32_t *piVar4;
    undefined *puVar5;
    code *pcVar6;
    bool bVar7;
    int32_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    uint32_t uVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    bool bVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_60h;
    
    uVar13 = 0;
    var_98h._0_4_ = 0;
    bVar7 = false;
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 8))();
    }
    if (*(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x10 + arg1) == 0) {
        iVar10 = *(int64_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x50 + arg1);
        if ((iVar10 == 0) || (iVar10 == arg1)) {
            bVar15 = true;
        } else {
            func_0x00018000fad0();
            bVar15 = *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x10 + arg1) == 0;
        }
    } else {
        bVar15 = false;
    }
    if ((bVar15) && (arg2 != 0)) {
        uVar11 = 0xffffffff;
        var_70h = arg1;
        do {
            puVar2 = **(uint8_t ***)(arg2 + 0x38);
            if (uVar11 == 0xffffffff) {
                if ((puVar2 == (uint8_t *)0x0) || (**(int32_t **)(arg2 + 0x50) < 1)) {
                    uVar11 = (**(code **)(*(int64_t *)arg2 + 0x30))(arg2);
                } else {
                    uVar11 = (uint32_t)*puVar2;
                }
            } else {
                if (puVar2 == (uint8_t *)0x0) {
code_r0x00018000cbbc:
                    uVar11 = (**(code **)(*(int64_t *)arg2 + 0x38))(arg2);
                } else {
                    piVar4 = *(int32_t **)(arg2 + 0x50);
                    iVar8 = *piVar4;
                    if (1 < iVar8) {
                        *piVar4 = iVar8 + -1;
                        ppuVar3 = *(uint8_t ***)(arg2 + 0x38);
                        *ppuVar3 = *ppuVar3 + 1;
                        uVar11 = (uint32_t)**ppuVar3;
                        goto code_r0x00018000cbf2;
                    }
                    if (iVar8 < 1) goto code_r0x00018000cbbc;
                    *piVar4 = iVar8 + -1;
                    puVar2 = **(uint8_t ***)(arg2 + 0x38);
                    **(uint8_t ***)(arg2 + 0x38) = puVar2 + 1;
                    uVar11 = (uint32_t)*puVar2;
                }
                if (uVar11 == 0xffffffff) {
                    uVar11 = 0xffffffff;
                } else if ((**(uint8_t ***)(arg2 + 0x38) == (uint8_t *)0x0) || (**(int32_t **)(arg2 + 0x50) < 1)) {
                    uVar11 = (**(code **)(*(int64_t *)arg2 + 0x30))(arg2);
                } else {
                    uVar11 = (uint32_t)***(uint8_t ***)(arg2 + 0x38);
                }
            }
code_r0x00018000cbf2:
            if (uVar11 == 0xffffffff) break;
            piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
            uVar14 = uVar11 & 0xff;
            if ((*(int64_t *)piVar1[8] == 0) || (piVar4 = (int32_t *)piVar1[0xb], *piVar4 < 1)) {
                uVar14 = (**(code **)(*piVar1 + 0x18))(piVar1, uVar14);
            } else {
                *piVar4 = *piVar4 + -1;
                puVar5 = *(undefined **)(int64_t *)piVar1[8];
                *(int64_t *)piVar1[8] = (int64_t)(puVar5 + 1);
                *puVar5 = (char)uVar11;
            }
            if (uVar14 == 0xffffffff) goto code_r0x00018000cc6c;
            bVar7 = true;
        } while( true );
    }
    *(undefined8 *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x28 + arg1) = 0;
    if (arg2 == 0) {
        uVar13 = 4;
        goto code_r0x00018000cced;
    }
code_r0x00018000cccf:
    if (!bVar7) {
        uVar13 = uVar13 | 2;
    }
code_r0x00018000cced:
    iVar10 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
    uVar11 = 4;
    if (*(int64_t *)(iVar10 + 0x48 + arg1) != 0) {
        uVar11 = 0;
    }
    uVar13 = uVar11 | *(uint32_t *)(iVar10 + 0x10 + arg1) & 0x17 | uVar13;
    *(uint32_t *)(iVar10 + 0x10 + arg1) = uVar13;
    uVar13 = uVar13 & *(uint32_t *)(iVar10 + 0x14 + arg1);
    if (uVar13 != 0) {
        if ((uVar13 & 4) == 0) {
            uVar12 = 0x1805aae00;
            if ((uVar13 & 2) == 0) {
                uVar12 = 0x1805aae18;
            }
        } else {
            uVar12 = 0x1805aade8;
        }
        uVar9 = func_0x000180005e50(&var_70h, 1);
        func_0x0001800069f0(&var_60h, uVar12, uVar9);
        fcn.18045bae0(CONCAT44(var_98h._4_4_, (undefined4)var_98h));
        pcVar6 = (code *)swi(3);
        iVar10 = (*pcVar6)();
        return iVar10;
    }
    iVar8 = func_0x0001804557c0();
    if (iVar8 == 0) {
        func_0x00018000fc20(arg1);
    }
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x10))();
    }
    return arg1;
code_r0x00018000cc6c:
    uVar13 = 4;
    var_98h._0_4_ = 4;
    *(undefined8 *)((int64_t)*(int32_t *)(*(int64_t *)var_70h + 4) + 0x28 + var_70h) = 0;
    goto code_r0x00018000cccf;
}

// ============================================================
// Function: FUN_18000ce40
// Address: 0x18000ce40
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000ce40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar3 = arg3;
    if (0 < arg3) {
        do {
            if ((**(int64_t **)(arg1 + 0x40) == 0) || (iVar2 = **(int32_t **)(arg1 + 0x58), iVar2 < 1)) {
                iVar2 = (**(code **)(*(int64_t *)arg1 + 0x18))(arg1, *(undefined *)arg2);
                if (iVar2 == -1) break;
                iVar1 = -1;
                iVar4 = 1;
            } else {
                iVar4 = iVar3;
                if (iVar2 <= iVar3) {
                    iVar4 = (int64_t)iVar2;
                }
                fcn.180498030(**(int64_t **)(arg1 + 0x40), arg2, iVar4);
                iVar1 = -iVar4;
                **(int32_t **)(arg1 + 0x58) = **(int32_t **)(arg1 + 0x58) - (int32_t)iVar4;
                **(int64_t **)(arg1 + 0x40) = **(int64_t **)(arg1 + 0x40) + (int64_t)(int32_t)iVar4;
            }
            iVar3 = iVar3 + iVar1;
            arg2 = arg2 + iVar4;
        } while (0 < iVar3);
    }
    return arg3 - iVar3;
}

// ============================================================
// Function: FUN_18000ce5b
// Address: 0x18000ce5b
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000ce40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar3 = arg3;
    if (0 < arg3) {
        do {
            if ((**(int64_t **)(arg1 + 0x40) == 0) || (iVar2 = **(int32_t **)(arg1 + 0x58), iVar2 < 1)) {
                iVar2 = (**(code **)(*(int64_t *)arg1 + 0x18))(arg1, *(undefined *)arg2);
                if (iVar2 == -1) break;
                iVar1 = -1;
                iVar4 = 1;
            } else {
                iVar4 = iVar3;
                if (iVar2 <= iVar3) {
                    iVar4 = (int64_t)iVar2;
                }
                fcn.180498030(**(int64_t **)(arg1 + 0x40), arg2, iVar4);
                iVar1 = -iVar4;
                **(int32_t **)(arg1 + 0x58) = **(int32_t **)(arg1 + 0x58) - (int32_t)iVar4;
                **(int64_t **)(arg1 + 0x40) = **(int64_t **)(arg1 + 0x40) + (int64_t)(int32_t)iVar4;
            }
            iVar3 = iVar3 + iVar1;
            arg2 = arg2 + iVar4;
        } while (0 < iVar3);
    }
    return arg3 - iVar3;
}

// ============================================================
// Function: FUN_18000cec8
// Address: 0x18000cec8
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000ce40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar3 = arg3;
    if (0 < arg3) {
        do {
            if ((**(int64_t **)(arg1 + 0x40) == 0) || (iVar2 = **(int32_t **)(arg1 + 0x58), iVar2 < 1)) {
                iVar2 = (**(code **)(*(int64_t *)arg1 + 0x18))(arg1, *(undefined *)arg2);
                if (iVar2 == -1) break;
                iVar1 = -1;
                iVar4 = 1;
            } else {
                iVar4 = iVar3;
                if (iVar2 <= iVar3) {
                    iVar4 = (int64_t)iVar2;
                }
                fcn.180498030(**(int64_t **)(arg1 + 0x40), arg2, iVar4);
                iVar1 = -iVar4;
                **(int32_t **)(arg1 + 0x58) = **(int32_t **)(arg1 + 0x58) - (int32_t)iVar4;
                **(int64_t **)(arg1 + 0x40) = **(int64_t **)(arg1 + 0x40) + (int64_t)(int32_t)iVar4;
            }
            iVar3 = iVar3 + iVar1;
            arg2 = arg2 + iVar4;
        } while (0 < iVar3);
    }
    return arg3 - iVar3;
}

// ============================================================
// Function: FUN_18000cee0
// Address: 0x18000cee0
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000cee0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar3 = arg3;
    if (0 < arg3) {
        do {
            if ((**(int64_t **)(arg1 + 0x38) == 0) || (iVar2 = **(int32_t **)(arg1 + 0x50), iVar2 < 1)) {
                iVar2 = (**(code **)(*(int64_t *)arg1 + 0x38))(arg1);
                if (iVar2 == -1) break;
                *(char *)arg2 = (char)iVar2;
                iVar1 = -1;
                iVar4 = 1;
            } else {
                iVar4 = iVar3;
                if (iVar2 <= iVar3) {
                    iVar4 = (int64_t)iVar2;
                }
                fcn.180498030(arg2, **(int64_t **)(arg1 + 0x38), iVar4);
                iVar1 = -iVar4;
                **(int32_t **)(arg1 + 0x50) = **(int32_t **)(arg1 + 0x50) - (int32_t)iVar4;
                **(int64_t **)(arg1 + 0x38) = **(int64_t **)(arg1 + 0x38) + (int64_t)(int32_t)iVar4;
            }
            iVar3 = iVar3 + iVar1;
            arg2 = arg2 + iVar4;
        } while (0 < iVar3);
    }
    return arg3 - iVar3;
}

// ============================================================
// Function: FUN_18000cefb
// Address: 0x18000cefb
// Size: 108 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000cee0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar3 = arg3;
    if (0 < arg3) {
        do {
            if ((**(int64_t **)(arg1 + 0x38) == 0) || (iVar2 = **(int32_t **)(arg1 + 0x50), iVar2 < 1)) {
                iVar2 = (**(code **)(*(int64_t *)arg1 + 0x38))(arg1);
                if (iVar2 == -1) break;
                *(char *)arg2 = (char)iVar2;
                iVar1 = -1;
                iVar4 = 1;
            } else {
                iVar4 = iVar3;
                if (iVar2 <= iVar3) {
                    iVar4 = (int64_t)iVar2;
                }
                fcn.180498030(arg2, **(int64_t **)(arg1 + 0x38), iVar4);
                iVar1 = -iVar4;
                **(int32_t **)(arg1 + 0x50) = **(int32_t **)(arg1 + 0x50) - (int32_t)iVar4;
                **(int64_t **)(arg1 + 0x38) = **(int64_t **)(arg1 + 0x38) + (int64_t)(int32_t)iVar4;
            }
            iVar3 = iVar3 + iVar1;
            arg2 = arg2 + iVar4;
        } while (0 < iVar3);
    }
    return arg3 - iVar3;
}

// ============================================================
// Function: FUN_18000cf67
// Address: 0x18000cf67
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000cee0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar3 = arg3;
    if (0 < arg3) {
        do {
            if ((**(int64_t **)(arg1 + 0x38) == 0) || (iVar2 = **(int32_t **)(arg1 + 0x50), iVar2 < 1)) {
                iVar2 = (**(code **)(*(int64_t *)arg1 + 0x38))(arg1);
                if (iVar2 == -1) break;
                *(char *)arg2 = (char)iVar2;
                iVar1 = -1;
                iVar4 = 1;
            } else {
                iVar4 = iVar3;
                if (iVar2 <= iVar3) {
                    iVar4 = (int64_t)iVar2;
                }
                fcn.180498030(arg2, **(int64_t **)(arg1 + 0x38), iVar4);
                iVar1 = -iVar4;
                **(int32_t **)(arg1 + 0x50) = **(int32_t **)(arg1 + 0x50) - (int32_t)iVar4;
                **(int64_t **)(arg1 + 0x38) = **(int64_t **)(arg1 + 0x38) + (int64_t)(int32_t)iVar4;
            }
            iVar3 = iVar3 + iVar1;
            arg2 = arg2 + iVar4;
        } while (0 < iVar3);
    }
    return arg3 - iVar3;
}

// ============================================================
// Function: FUN_18000cf80
// Address: 0x18000cf80
// Size: 55 bytes
// ============================================================
uint64_t fcn.18000cf80(int64_t arg1)
{
    uint8_t *puVar1;
    uint64_t uVar2;
    
    uVar2 = (**(code **)(*(int64_t *)arg1 + 0x30))();
    if ((int32_t)uVar2 == -1) {
        return uVar2;
    }
    **(int32_t **)(arg1 + 0x50) = **(int32_t **)(arg1 + 0x50) + -1;
    puVar1 = **(uint8_t ***)(arg1 + 0x38);
    **(uint8_t ***)(arg1 + 0x38) = puVar1 + 1;
    return (uint64_t)*puVar1;
}

// ============================================================
// Function: FUN_18000cfd0
// Address: 0x18000cfd0
// Size: 83 bytes
// ============================================================
void fcn.18000cfd0(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 *puVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    iVar1 = *(int64_t *)(arg1 + 0x60);
    *(undefined8 *)arg1 = 0x1804a5500;
    if (iVar1 == 0) {
        return;
    }
    if ((*(int64_t **)(iVar1 + 8) != (int64_t *)0x0) &&
       (puVar4 = (undefined8 *)(**(code **)(**(int64_t **)(iVar1 + 8) + 0x10))(), puVar4 != (undefined8 *)0x0)) {
        (**(code **)*puVar4)(puVar4, 1);
    }
    if ((iVar1 != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar1, in_R9, unaff_RBX), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = func_0x00018046b63c(uVar3);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18000d030
// Address: 0x18000d030
// Size: 25 bytes
// ============================================================
void fcn.18000d030(int64_t arg1)
{
    *(undefined8 *)arg1 = 0x1804a54d0;
    fcn.180455c14();
    return;
}

// ============================================================
// Function: FUN_18000d050
// Address: 0x18000d050
// Size: 31 bytes
// ============================================================
void fcn.18000d050(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    func_0x000180454ffc(*(undefined8 *)(arg1 + 0x20));
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        iVar1 = *(int64_t *)arg1;
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x18) * 2 + 2) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18000dccd;
        func_0x000180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined2 *)arg1 = 0;
    *(undefined8 *)(arg1 + 0x18) = 7;
    return;
}

// ============================================================
// Function: FUN_18000d070
// Address: 0x18000d070
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000d070(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
        return arg1;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000d086
// Address: 0x18000d086
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000d070(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
        return arg1;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000d0ca
// Address: 0x18000d0ca
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000d070(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
        return arg1;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000d0e0
// Address: 0x18000d0e0
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000d0e0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    arg1 = arg1 + -0xb0;
    fcn.18000a290(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x110);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000d120
// Address: 0x18000d120
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000d120(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.18000c170(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x98);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000d160
// Address: 0x18000d160
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000d160(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    arg1 = arg1 + -0x88;
    fcn.18000a310(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0xe8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000d1a0
// Address: 0x18000d1a0
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000d1a0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.18000c970(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x78);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000d1e0
// Address: 0x18000d1e0
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.18000d1e0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_8h;
    
    piVar1 = (int64_t *)(arg1 + -0x10);
    *(undefined8 *)((int64_t)*(int32_t *)(*piVar1 + 4) + -0x10 + arg1) = 0x1804a54f0;
    *(int32_t *)((int64_t)*(int32_t *)(*piVar1 + 4) + -0x14 + arg1) = *(int32_t *)(*piVar1 + 4) + -0x10;
    *(undefined8 *)arg1 = 0x1804a54d0;
    fcn.180455c14();
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(piVar1, 0x70);
    }
    return piVar1;
}

// ============================================================
// Function: FUN_18000d250
// Address: 0x18000d250
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.18000d250(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_8h;
    
    piVar1 = (int64_t *)(arg1 + -0x18);
    *(undefined8 *)((int64_t)*(int32_t *)(*piVar1 + 4) + -0x18 + arg1) = 0x1804a5600;
    *(int32_t *)((int64_t)*(int32_t *)(*piVar1 + 4) + -0x1c + arg1) = *(int32_t *)(*piVar1 + 4) + -0x18;
    *(undefined8 *)arg1 = 0x1804a54d0;
    fcn.180455c14();
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(piVar1, 0x78);
    }
    return piVar1;
}

// ============================================================
// Function: FUN_18000d2c0
// Address: 0x18000d2c0
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18000d2c0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg1 + 0x60);
    *(undefined8 *)arg1 = 0x1804a5500;
    if (iVar1 != 0) {
        if (*(int64_t **)(iVar1 + 8) != (int64_t *)0x0) {
            puVar2 = (undefined8 *)(**(code **)(**(int64_t **)(iVar1 + 8) + 0x10))();
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, 1);
            }
        }
        fcn.180459c3c(iVar1, 0x10);
    }
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x68);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000d340
// Address: 0x18000d340
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000d340(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a54d0;
    fcn.180455c14();
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x60);
    }
    return arg1;
}

