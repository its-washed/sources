// Chunk 11 - 50 functions

// ============================================================
// Function: FUN_18001b800
// Address: 0x18001b800
// Size: 33 bytes
// ============================================================
int64_t fcn.18001b800(int64_t arg1)
{
    uint64_t in_RDX;
    
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18001b830
// Address: 0x18001b830
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001b830(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg1 != arg2) {
        do {
            piVar1 = *(int64_t **)arg1;
            if (piVar1 != (int64_t *)0x0) {
                (**(code **)(*piVar1 + 0x10))(piVar1, 1);
            }
            arg1 = arg1 + 8;
        } while (arg1 != arg2);
    }
    return;
}

// ============================================================
// Function: FUN_18001b870
// Address: 0x18001b870
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.18001b870(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    code *pcVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    undefined8 *puVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar12 = auStack_68;
    puVar11 = auStack_68;
    iVar9 = (int64_t)*(undefined8 **)0x180781fe8 - (int64_t)*(undefined8 **)0x180781fe0 >> 3;
    if (iVar9 == 0x1fffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar14 = (undefined8 *)(*pcVar4)();
        return puVar14;
    }
    uVar7 = *(int64_t *)0x180781ff0 - (int64_t)*(undefined8 **)0x180781fe0 >> 3;
    if (uVar7 <= 0x1fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar9 + 1;
        iVar9 = arg2 - (int64_t)*(undefined8 **)0x180781fe0;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x2000000000000000) {
            uVar7 = uVar13 * 8;
            puVar14 = (undefined8 *)0x0;
            if (uVar7 != 0) {
                if (uVar7 < 0x1000) {
                    puVar14 = (undefined8 *)func_0x000180459890();
                    puVar12 = auStack_68;
                } else {
                    if (uVar7 + 0x27 <= uVar7) goto code_r0x00018001ba4c;
                    iVar6 = func_0x000180459890(uVar7 + 0x27);
                    if (iVar6 == 0) {
                        pcVar4 = (code *)swi(0x29);
                        iVar6 = (*pcVar4)(5);
                        puVar11 = auStack_60;
                    }
                    puVar14 = (undefined8 *)(iVar6 + 0x27U & 0xffffffffffffffe0);
                    puVar14[-1] = iVar6;
                    puVar12 = puVar11;
                }
            }
            uVar3 = *(undefined8 *)arg3;
            *(undefined8 *)arg3 = 0;
            puVar2 = puVar14 + (iVar9 >> 3);
            *(undefined8 *)(puVar12 + 0x20) = 0x180781fe0;
            *puVar2 = uVar3;
            puVar5 = *(undefined8 **)0x180781fe8;
            *(uint64_t *)(puVar12 + 0x30) = uVar13;
            *(undefined8 **)(puVar12 + 0x40) = puVar2 + 1;
            *(undefined8 **)(puVar12 + 0x38) = puVar2;
            puVar10 = puVar14;
            puVar8 = *(undefined8 **)0x180781fe0;
            if ((undefined8 *)arg2 == *(undefined8 **)0x180781fe8) {
                for (; puVar8 != puVar5; puVar8 = puVar8 + 1) {
                    uVar3 = *puVar8;
                    *puVar8 = 0;
                    *puVar10 = uVar3;
                    puVar10 = puVar10 + 1;
                }
            } else {
                for (; *(undefined8 **)0x180781fe8 = puVar5, puVar8 != (undefined8 *)arg2; puVar8 = puVar8 + 1) {
                    uVar3 = *puVar8;
                    *puVar8 = 0;
                    *puVar10 = uVar3;
                    puVar10 = puVar10 + 1;
                    puVar5 = *(undefined8 **)0x180781fe8;
                }
                *(undefined8 **)(puVar12 + 0x38) = puVar14;
                puVar10 = puVar2 + 1;
                if ((undefined8 *)arg2 != puVar5) {
                    do {
                        uVar3 = *(undefined8 *)arg2;
                        *(undefined8 *)arg2 = 0;
                        arg2 = arg2 + 8;
                        *puVar10 = uVar3;
                        puVar10 = puVar10 + 1;
                    } while ((undefined8 *)arg2 != puVar5);
                }
            }
            *(undefined8 *)(puVar12 + 0x28) = 0;
            *(undefined8 *)(puVar12 + -8) = 0x18001ba1a;
            func_0x00018001c0c0(puVar8, puVar14, uVar1, uVar13);
            *(undefined8 *)(puVar12 + -8) = 0x18001ba24;
            func_0x00018001c010(puVar12 + 0x20);
            return puVar2;
        }
    }
code_r0x00018001ba4c:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar14 = (undefined8 *)(*pcVar4)();
    return puVar14;
}

// ============================================================
// Function: FUN_18001b8af
// Address: 0x18001b8af
// Size: 407 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.18001b870(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    code *pcVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    undefined8 *puVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar12 = auStack_68;
    puVar11 = auStack_68;
    iVar9 = (int64_t)*(undefined8 **)0x180781fe8 - (int64_t)*(undefined8 **)0x180781fe0 >> 3;
    if (iVar9 == 0x1fffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar14 = (undefined8 *)(*pcVar4)();
        return puVar14;
    }
    uVar7 = *(int64_t *)0x180781ff0 - (int64_t)*(undefined8 **)0x180781fe0 >> 3;
    if (uVar7 <= 0x1fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar9 + 1;
        iVar9 = arg2 - (int64_t)*(undefined8 **)0x180781fe0;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x2000000000000000) {
            uVar7 = uVar13 * 8;
            puVar14 = (undefined8 *)0x0;
            if (uVar7 != 0) {
                if (uVar7 < 0x1000) {
                    puVar14 = (undefined8 *)func_0x000180459890();
                    puVar12 = auStack_68;
                } else {
                    if (uVar7 + 0x27 <= uVar7) goto code_r0x00018001ba4c;
                    iVar6 = func_0x000180459890(uVar7 + 0x27);
                    if (iVar6 == 0) {
                        pcVar4 = (code *)swi(0x29);
                        iVar6 = (*pcVar4)(5);
                        puVar11 = auStack_60;
                    }
                    puVar14 = (undefined8 *)(iVar6 + 0x27U & 0xffffffffffffffe0);
                    puVar14[-1] = iVar6;
                    puVar12 = puVar11;
                }
            }
            uVar3 = *(undefined8 *)arg3;
            *(undefined8 *)arg3 = 0;
            puVar2 = puVar14 + (iVar9 >> 3);
            *(undefined8 *)(puVar12 + 0x20) = 0x180781fe0;
            *puVar2 = uVar3;
            puVar5 = *(undefined8 **)0x180781fe8;
            *(uint64_t *)(puVar12 + 0x30) = uVar13;
            *(undefined8 **)(puVar12 + 0x40) = puVar2 + 1;
            *(undefined8 **)(puVar12 + 0x38) = puVar2;
            puVar10 = puVar14;
            puVar8 = *(undefined8 **)0x180781fe0;
            if ((undefined8 *)arg2 == *(undefined8 **)0x180781fe8) {
                for (; puVar8 != puVar5; puVar8 = puVar8 + 1) {
                    uVar3 = *puVar8;
                    *puVar8 = 0;
                    *puVar10 = uVar3;
                    puVar10 = puVar10 + 1;
                }
            } else {
                for (; *(undefined8 **)0x180781fe8 = puVar5, puVar8 != (undefined8 *)arg2; puVar8 = puVar8 + 1) {
                    uVar3 = *puVar8;
                    *puVar8 = 0;
                    *puVar10 = uVar3;
                    puVar10 = puVar10 + 1;
                    puVar5 = *(undefined8 **)0x180781fe8;
                }
                *(undefined8 **)(puVar12 + 0x38) = puVar14;
                puVar10 = puVar2 + 1;
                if ((undefined8 *)arg2 != puVar5) {
                    do {
                        uVar3 = *(undefined8 *)arg2;
                        *(undefined8 *)arg2 = 0;
                        arg2 = arg2 + 8;
                        *puVar10 = uVar3;
                        puVar10 = puVar10 + 1;
                    } while ((undefined8 *)arg2 != puVar5);
                }
            }
            *(undefined8 *)(puVar12 + 0x28) = 0;
            *(undefined8 *)(puVar12 + -8) = 0x18001ba1a;
            func_0x00018001c0c0(puVar8, puVar14, uVar1, uVar13);
            *(undefined8 *)(puVar12 + -8) = 0x18001ba24;
            func_0x00018001c010(puVar12 + 0x20);
            return puVar2;
        }
    }
code_r0x00018001ba4c:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar14 = (undefined8 *)(*pcVar4)();
    return puVar14;
}

// ============================================================
// Function: FUN_18001ba46
// Address: 0x18001ba46
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.18001b870(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    code *pcVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    undefined8 *puVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar12 = auStack_68;
    puVar11 = auStack_68;
    iVar9 = (int64_t)*(undefined8 **)0x180781fe8 - (int64_t)*(undefined8 **)0x180781fe0 >> 3;
    if (iVar9 == 0x1fffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar14 = (undefined8 *)(*pcVar4)();
        return puVar14;
    }
    uVar7 = *(int64_t *)0x180781ff0 - (int64_t)*(undefined8 **)0x180781fe0 >> 3;
    if (uVar7 <= 0x1fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar9 + 1;
        iVar9 = arg2 - (int64_t)*(undefined8 **)0x180781fe0;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x2000000000000000) {
            uVar7 = uVar13 * 8;
            puVar14 = (undefined8 *)0x0;
            if (uVar7 != 0) {
                if (uVar7 < 0x1000) {
                    puVar14 = (undefined8 *)func_0x000180459890();
                    puVar12 = auStack_68;
                } else {
                    if (uVar7 + 0x27 <= uVar7) goto code_r0x00018001ba4c;
                    iVar6 = func_0x000180459890(uVar7 + 0x27);
                    if (iVar6 == 0) {
                        pcVar4 = (code *)swi(0x29);
                        iVar6 = (*pcVar4)(5);
                        puVar11 = auStack_60;
                    }
                    puVar14 = (undefined8 *)(iVar6 + 0x27U & 0xffffffffffffffe0);
                    puVar14[-1] = iVar6;
                    puVar12 = puVar11;
                }
            }
            uVar3 = *(undefined8 *)arg3;
            *(undefined8 *)arg3 = 0;
            puVar2 = puVar14 + (iVar9 >> 3);
            *(undefined8 *)(puVar12 + 0x20) = 0x180781fe0;
            *puVar2 = uVar3;
            puVar5 = *(undefined8 **)0x180781fe8;
            *(uint64_t *)(puVar12 + 0x30) = uVar13;
            *(undefined8 **)(puVar12 + 0x40) = puVar2 + 1;
            *(undefined8 **)(puVar12 + 0x38) = puVar2;
            puVar10 = puVar14;
            puVar8 = *(undefined8 **)0x180781fe0;
            if ((undefined8 *)arg2 == *(undefined8 **)0x180781fe8) {
                for (; puVar8 != puVar5; puVar8 = puVar8 + 1) {
                    uVar3 = *puVar8;
                    *puVar8 = 0;
                    *puVar10 = uVar3;
                    puVar10 = puVar10 + 1;
                }
            } else {
                for (; *(undefined8 **)0x180781fe8 = puVar5, puVar8 != (undefined8 *)arg2; puVar8 = puVar8 + 1) {
                    uVar3 = *puVar8;
                    *puVar8 = 0;
                    *puVar10 = uVar3;
                    puVar10 = puVar10 + 1;
                    puVar5 = *(undefined8 **)0x180781fe8;
                }
                *(undefined8 **)(puVar12 + 0x38) = puVar14;
                puVar10 = puVar2 + 1;
                if ((undefined8 *)arg2 != puVar5) {
                    do {
                        uVar3 = *(undefined8 *)arg2;
                        *(undefined8 *)arg2 = 0;
                        arg2 = arg2 + 8;
                        *puVar10 = uVar3;
                        puVar10 = puVar10 + 1;
                    } while ((undefined8 *)arg2 != puVar5);
                }
            }
            *(undefined8 *)(puVar12 + 0x28) = 0;
            *(undefined8 *)(puVar12 + -8) = 0x18001ba1a;
            func_0x00018001c0c0(puVar8, puVar14, uVar1, uVar13);
            *(undefined8 *)(puVar12 + -8) = 0x18001ba24;
            func_0x00018001c010(puVar12 + 0x20);
            return puVar2;
        }
    }
code_r0x00018001ba4c:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar14 = (undefined8 *)(*pcVar4)();
    return puVar14;
}

// ============================================================
// Function: FUN_18001ba4c
// Address: 0x18001ba4c
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.18001b870(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    code *pcVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    undefined8 *puVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar12 = auStack_68;
    puVar11 = auStack_68;
    iVar9 = (int64_t)*(undefined8 **)0x180781fe8 - (int64_t)*(undefined8 **)0x180781fe0 >> 3;
    if (iVar9 == 0x1fffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar14 = (undefined8 *)(*pcVar4)();
        return puVar14;
    }
    uVar7 = *(int64_t *)0x180781ff0 - (int64_t)*(undefined8 **)0x180781fe0 >> 3;
    if (uVar7 <= 0x1fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar9 + 1;
        iVar9 = arg2 - (int64_t)*(undefined8 **)0x180781fe0;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x2000000000000000) {
            uVar7 = uVar13 * 8;
            puVar14 = (undefined8 *)0x0;
            if (uVar7 != 0) {
                if (uVar7 < 0x1000) {
                    puVar14 = (undefined8 *)func_0x000180459890();
                    puVar12 = auStack_68;
                } else {
                    if (uVar7 + 0x27 <= uVar7) goto code_r0x00018001ba4c;
                    iVar6 = func_0x000180459890(uVar7 + 0x27);
                    if (iVar6 == 0) {
                        pcVar4 = (code *)swi(0x29);
                        iVar6 = (*pcVar4)(5);
                        puVar11 = auStack_60;
                    }
                    puVar14 = (undefined8 *)(iVar6 + 0x27U & 0xffffffffffffffe0);
                    puVar14[-1] = iVar6;
                    puVar12 = puVar11;
                }
            }
            uVar3 = *(undefined8 *)arg3;
            *(undefined8 *)arg3 = 0;
            puVar2 = puVar14 + (iVar9 >> 3);
            *(undefined8 *)(puVar12 + 0x20) = 0x180781fe0;
            *puVar2 = uVar3;
            puVar5 = *(undefined8 **)0x180781fe8;
            *(uint64_t *)(puVar12 + 0x30) = uVar13;
            *(undefined8 **)(puVar12 + 0x40) = puVar2 + 1;
            *(undefined8 **)(puVar12 + 0x38) = puVar2;
            puVar10 = puVar14;
            puVar8 = *(undefined8 **)0x180781fe0;
            if ((undefined8 *)arg2 == *(undefined8 **)0x180781fe8) {
                for (; puVar8 != puVar5; puVar8 = puVar8 + 1) {
                    uVar3 = *puVar8;
                    *puVar8 = 0;
                    *puVar10 = uVar3;
                    puVar10 = puVar10 + 1;
                }
            } else {
                for (; *(undefined8 **)0x180781fe8 = puVar5, puVar8 != (undefined8 *)arg2; puVar8 = puVar8 + 1) {
                    uVar3 = *puVar8;
                    *puVar8 = 0;
                    *puVar10 = uVar3;
                    puVar10 = puVar10 + 1;
                    puVar5 = *(undefined8 **)0x180781fe8;
                }
                *(undefined8 **)(puVar12 + 0x38) = puVar14;
                puVar10 = puVar2 + 1;
                if ((undefined8 *)arg2 != puVar5) {
                    do {
                        uVar3 = *(undefined8 *)arg2;
                        *(undefined8 *)arg2 = 0;
                        arg2 = arg2 + 8;
                        *puVar10 = uVar3;
                        puVar10 = puVar10 + 1;
                    } while ((undefined8 *)arg2 != puVar5);
                }
            }
            *(undefined8 *)(puVar12 + 0x28) = 0;
            *(undefined8 *)(puVar12 + -8) = 0x18001ba1a;
            func_0x00018001c0c0(puVar8, puVar14, uVar1, uVar13);
            *(undefined8 *)(puVar12 + -8) = 0x18001ba24;
            func_0x00018001c010(puVar12 + 0x20);
            return puVar2;
        }
    }
code_r0x00018001ba4c:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar14 = (undefined8 *)(*pcVar4)();
    return puVar14;
}

// ============================================================
// Function: FUN_18001ba60
// Address: 0x18001ba60
// Size: 115 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018001ba9f: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018001baa4)
// WARNING: Removing unreachable block (ram,0x00018001baac)
// WARNING: Removing unreachable block (ram,0x00018001bab3)

int64_t fcn.18001ba60(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 unaff_RBX;
    undefined8 auStack_30 [6];
    
    if (0x1fffffffffffffff < *(uint64_t *)arg2) {
code_r0x00018001bacd:
        auStack_30[0] = 0x18001bad2;
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        iVar3 = (*pcVar1)();
        return iVar3;
    }
    uVar4 = *(uint64_t *)arg2 * 8;
    if (uVar4 == 0) {
        return 0;
    }
    if (0xfff < uVar4) {
        if (uVar4 + 0x27 <= uVar4) goto code_r0x00018001bacd;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18001baa4;
        uVar4 = uVar4 + 0x27;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
    do {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x1804598af;
        iVar3 = fcn.18046d050(uVar4);
        if (iVar3 != 0) {
            return iVar3;
        }
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x1804598a3;
        iVar2 = fcn.18047a460(uVar4);
    } while (iVar2 != 0);
    if (uVar4 == 0xffffffffffffffff) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x1804598cb;
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        iVar3 = (*pcVar1)();
        return iVar3;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x1804598c5;
    fcn.180454670();
    pcVar1 = (code *)swi(3);
    iVar3 = (*pcVar1)();
    return iVar3;
}

// ============================================================
// Function: FUN_18001bae0
// Address: 0x18001bae0
// Size: 265 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18001bae0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 *puVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    undefined8 *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar4 = (int64_t *)((*(uint64_t *)0x180782030 & arg4) * 0x10 + *(int64_t *)0x180782018);
    puVar6 = (undefined8 *)piVar4[1];
    if (puVar6 == *(undefined8 **)0x180782008) {
        *(undefined8 **)arg2 = *(undefined8 **)0x180782008;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    puVar3 = (undefined8 *)*piVar4;
    do {
        piVar4 = (int64_t *)puVar6[3];
        if (piVar4 == (int64_t *)0x0) {
            piVar5 = *(int64_t **)(arg3 + 8);
            piVar4 = (int64_t *)0x0;
        } else {
            LOCK();
            *(int32_t *)((int64_t)piVar4 + 0xc) = *(int32_t *)((int64_t)piVar4 + 0xc) + 1;
            UNLOCK();
            piVar5 = *(int64_t **)(arg3 + 8);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
        if (piVar4 <= piVar5) {
            piVar4 = *(int64_t **)(arg3 + 8);
            if (piVar4 == (int64_t *)0x0) {
                piVar5 = (int64_t *)puVar6[3];
                piVar4 = (int64_t *)0x0;
            } else {
                LOCK();
                *(int32_t *)((int64_t)piVar4 + 0xc) = *(int32_t *)((int64_t)piVar4 + 0xc) + 1;
                UNLOCK();
                piVar5 = (int64_t *)puVar6[3];
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar2 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar2 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
            if (piVar4 <= piVar5) {
                *(undefined8 *)arg2 = *puVar6;
                *(undefined8 **)(arg2 + 8) = puVar6;
                return arg2;
            }
        }
        if (puVar6 == puVar3) {
            *(undefined8 **)arg2 = puVar6;
            *(undefined8 *)(arg2 + 8) = 0;
            return arg2;
        }
        puVar6 = (undefined8 *)puVar6[1];
    } while( true );
}

// ============================================================
// Function: FUN_18001bbf0
// Address: 0x18001bbf0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001bbf0(undefined8 placeholder_0, int64_t arg2, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 *puVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    
    **(undefined8 **)(arg2 + 8) = 0;
    puVar5 = *(undefined8 **)arg2;
    while (puVar5 != (undefined8 *)0x0) {
        puVar3 = (undefined8 *)*puVar5;
        func_0x00018000ace0(puVar5 + 8);
        func_0x00018001c440(puVar5 + 6);
        piVar4 = (int64_t *)puVar5[3];
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar4 + 8))();
            }
        }
        fcn.180459c3c(puVar5, 0x68);
        puVar5 = puVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18001bc09
// Address: 0x18001bc09
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001bbf0(undefined8 placeholder_0, int64_t arg2, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 *puVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    
    **(undefined8 **)(arg2 + 8) = 0;
    puVar5 = *(undefined8 **)arg2;
    while (puVar5 != (undefined8 *)0x0) {
        puVar3 = (undefined8 *)*puVar5;
        func_0x00018000ace0(puVar5 + 8);
        func_0x00018001c440(puVar5 + 6);
        piVar4 = (int64_t *)puVar5[3];
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar4 + 8))();
            }
        }
        fcn.180459c3c(puVar5, 0x68);
        puVar5 = puVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18001bc5d
// Address: 0x18001bc5d
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001bbf0(undefined8 placeholder_0, int64_t arg2, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 *puVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    
    **(undefined8 **)(arg2 + 8) = 0;
    puVar5 = *(undefined8 **)arg2;
    while (puVar5 != (undefined8 *)0x0) {
        puVar3 = (undefined8 *)*puVar5;
        func_0x00018000ace0(puVar5 + 8);
        func_0x00018001c440(puVar5 + 6);
        piVar4 = (int64_t *)puVar5[3];
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar4 + 8))();
            }
        }
        fcn.180459c3c(puVar5, 0x68);
        puVar5 = puVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18001bc90
// Address: 0x18001bc90
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18001bc90(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    int32_t iVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    char in_DL;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar4 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
            (**(code **)*piVar3)(piVar3);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
            iVar4 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                (**(code **)(*piVar3 + 8))(piVar3);
            }
        }
    }
    if (in_DL == '\0') {
        return;
    }
    if ((arg1 != 0) && (iVar4 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar4 == 0))
    {
        uVar5 = (*(code *)0x699ff6)();
        uVar5 = fcn.18046b63c(uVar5);
        puVar6 = (undefined4 *)fcn.18046b77c();
        *puVar6 = uVar5;
    }
    return;
}

// ============================================================
// Function: FUN_18001bc96
// Address: 0x18001bc96
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18001bc90(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    int32_t iVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    char in_DL;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar4 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
            (**(code **)*piVar3)(piVar3);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
            iVar4 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                (**(code **)(*piVar3 + 8))(piVar3);
            }
        }
    }
    if (in_DL == '\0') {
        return;
    }
    if ((arg1 != 0) && (iVar4 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar4 == 0))
    {
        uVar5 = (*(code *)0x699ff6)();
        uVar5 = fcn.18046b63c(uVar5);
        puVar6 = (undefined4 *)fcn.18046b77c();
        *puVar6 = uVar5;
    }
    return;
}

// ============================================================
// Function: FUN_18001bcaf
// Address: 0x18001bcaf
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18001bc90(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    int32_t iVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    char in_DL;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar4 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
            (**(code **)*piVar3)(piVar3);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
            iVar4 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                (**(code **)(*piVar3 + 8))(piVar3);
            }
        }
    }
    if (in_DL == '\0') {
        return;
    }
    if ((arg1 != 0) && (iVar4 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar4 == 0))
    {
        uVar5 = (*(code *)0x699ff6)();
        uVar5 = fcn.18046b63c(uVar5);
        puVar6 = (undefined4 *)fcn.18046b77c();
        *puVar6 = uVar5;
    }
    return;
}

// ============================================================
// Function: FUN_18001bce5
// Address: 0x18001bce5
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18001bc90(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    int32_t iVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    char in_DL;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar4 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
            (**(code **)*piVar3)(piVar3);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
            iVar4 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                (**(code **)(*piVar3 + 8))(piVar3);
            }
        }
    }
    if (in_DL == '\0') {
        return;
    }
    if ((arg1 != 0) && (iVar4 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar4 == 0))
    {
        uVar5 = (*(code *)0x699ff6)();
        uVar5 = fcn.18046b63c(uVar5);
        puVar6 = (undefined4 *)fcn.18046b77c();
        *puVar6 = uVar5;
    }
    return;
}

// ============================================================
// Function: FUN_18001bcf4
// Address: 0x18001bcf4
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18001bc90(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    int32_t iVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    char in_DL;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar4 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
            (**(code **)*piVar3)(piVar3);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
            iVar4 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                (**(code **)(*piVar3 + 8))(piVar3);
            }
        }
    }
    if (in_DL == '\0') {
        return;
    }
    if ((arg1 != 0) && (iVar4 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar4 == 0))
    {
        uVar5 = (*(code *)0x699ff6)();
        uVar5 = fcn.18046b63c(uVar5);
        puVar6 = (undefined4 *)fcn.18046b77c();
        *puVar6 = uVar5;
    }
    return;
}

// ============================================================
// Function: FUN_18001bd20
// Address: 0x18001bd20
// Size: 52 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.18001bd20(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t var_18h;
    int64_t var_10h;
    
    var_18h = 0;
    var_10h = *(int64_t *)(*(int64_t *)(arg1 + 8) + 0x198);
    puVar1 = (undefined8 *)fcn.180013d30();
    fcn.180013fd0(*puVar1, &var_18h);
    return;
}

// ============================================================
// Function: FUN_18001bda0
// Address: 0x18001bda0
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18001bda0(int64_t arg1, int64_t arg_48h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar12 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar10 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar12 < 0) {
        fVar14 = (float)(uVar12 >> 1 | (uint64_t)((uint32_t)uVar12 & 1));
        fVar14 = fVar14 + fVar14;
    } else {
        fVar14 = (float)uVar12;
    }
    fVar14 = (float)func_0x000180471c90(fVar14 / *(float *)arg1);
    iVar11 = 0;
    if ((9.223372e+18 <= fVar14) && (fVar14 = fVar14 - 9.223372e+18, fVar14 < 9.223372e+18)) {
        iVar11 = -0x8000000000000000;
    }
    uVar12 = 8;
    if (8 < (uint64_t)((int64_t)fVar14 + iVar11)) {
        uVar12 = (int64_t)fVar14 + iVar11;
    }
    uVar13 = uVar10;
    if ((uVar10 < uVar12) && ((0x1ff < uVar10 || (uVar13 = uVar10 * 8, uVar10 * 8 < uVar12)))) {
        uVar13 = uVar12;
    }
    for (iVar11 = 0x3f; 0xfffffffffffffffU >> iVar11 == 0; iVar11 = iVar11 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar11 & 0x3f)) < uVar13) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar1 = *(int64_t ***)(arg1 + 8);
    uVar10 = uVar13 - 1 | 1;
    iVar11 = 0x3f;
    if (uVar10 != 0) {
        for (; uVar10 >> iVar11 == 0; iVar11 = iVar11 + -1) {
        }
    }
    iVar11 = 1LL << ((char)iVar11 + 1U & 0x3f);
    func_0x00018000f7e0(arg1 + 0x18, iVar11 * 2, ppiVar1);
    *(int64_t *)(arg1 + 0x38) = iVar11;
    *(int64_t *)(arg1 + 0x30) = iVar11 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x00018001be9b:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar9 == ppiVar1) {
                    return;
                }
                iVar11 = *(int64_t *)(arg1 + 0x18);
                ppiVar2 = (int64_t **)*ppiVar9;
                uVar10 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30);
                ppiVar3 = *(int64_t ***)(iVar11 + uVar10 * 0x10);
                if (ppiVar3 != ppiVar1) break;
                *(int64_t ***)(iVar11 + uVar10 * 0x10) = ppiVar9;
                *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar2;
            }
            ppiVar4 = *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10);
            if (ppiVar9[2] != ppiVar4[2]) break;
            ppiVar4 = (int64_t **)*ppiVar4;
            if (ppiVar4 != ppiVar9) {
                piVar5 = ppiVar9[1];
                *piVar5 = (int64_t)ppiVar2;
                ppiVar3 = (int64_t **)ppiVar2[1];
                *ppiVar3 = (int64_t *)ppiVar4;
                piVar6 = ppiVar4[1];
                *piVar6 = (int64_t)ppiVar9;
                ppiVar4[1] = (int64_t *)ppiVar3;
                ppiVar2[1] = piVar5;
                ppiVar9[1] = piVar6;
            }
            *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10) = ppiVar9;
            ppiVar9 = ppiVar2;
        }
        do {
            if (ppiVar3 == ppiVar4) {
                piVar5 = ppiVar9[1];
                *piVar5 = (int64_t)ppiVar2;
                ppiVar3 = (int64_t **)ppiVar2[1];
                *ppiVar3 = (int64_t *)ppiVar4;
                piVar6 = ppiVar4[1];
                *piVar6 = (int64_t)ppiVar9;
                ppiVar4[1] = (int64_t *)ppiVar3;
                ppiVar2[1] = piVar5;
                ppiVar9[1] = piVar6;
                *(int64_t ***)(iVar11 + uVar10 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar2;
                goto joined_r0x00018001be9b;
            }
            ppiVar4 = (int64_t **)ppiVar4[1];
        } while (ppiVar9[2] != ppiVar4[2]);
        piVar5 = *ppiVar4;
        piVar6 = ppiVar9[1];
        *piVar6 = (int64_t)ppiVar2;
        ppiVar3 = (int64_t **)ppiVar2[1];
        *ppiVar3 = piVar5;
        piVar7 = (int64_t *)piVar5[1];
        *piVar7 = (int64_t)ppiVar9;
        piVar5[1] = (int64_t)ppiVar3;
        ppiVar2[1] = piVar6;
        ppiVar9[1] = piVar7;
        ppiVar9 = ppiVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18001be5d
// Address: 0x18001be5d
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18001bda0(int64_t arg1, int64_t arg_48h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar12 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar10 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar12 < 0) {
        fVar14 = (float)(uVar12 >> 1 | (uint64_t)((uint32_t)uVar12 & 1));
        fVar14 = fVar14 + fVar14;
    } else {
        fVar14 = (float)uVar12;
    }
    fVar14 = (float)func_0x000180471c90(fVar14 / *(float *)arg1);
    iVar11 = 0;
    if ((9.223372e+18 <= fVar14) && (fVar14 = fVar14 - 9.223372e+18, fVar14 < 9.223372e+18)) {
        iVar11 = -0x8000000000000000;
    }
    uVar12 = 8;
    if (8 < (uint64_t)((int64_t)fVar14 + iVar11)) {
        uVar12 = (int64_t)fVar14 + iVar11;
    }
    uVar13 = uVar10;
    if ((uVar10 < uVar12) && ((0x1ff < uVar10 || (uVar13 = uVar10 * 8, uVar10 * 8 < uVar12)))) {
        uVar13 = uVar12;
    }
    for (iVar11 = 0x3f; 0xfffffffffffffffU >> iVar11 == 0; iVar11 = iVar11 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar11 & 0x3f)) < uVar13) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar1 = *(int64_t ***)(arg1 + 8);
    uVar10 = uVar13 - 1 | 1;
    iVar11 = 0x3f;
    if (uVar10 != 0) {
        for (; uVar10 >> iVar11 == 0; iVar11 = iVar11 + -1) {
        }
    }
    iVar11 = 1LL << ((char)iVar11 + 1U & 0x3f);
    func_0x00018000f7e0(arg1 + 0x18, iVar11 * 2, ppiVar1);
    *(int64_t *)(arg1 + 0x38) = iVar11;
    *(int64_t *)(arg1 + 0x30) = iVar11 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x00018001be9b:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar9 == ppiVar1) {
                    return;
                }
                iVar11 = *(int64_t *)(arg1 + 0x18);
                ppiVar2 = (int64_t **)*ppiVar9;
                uVar10 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30);
                ppiVar3 = *(int64_t ***)(iVar11 + uVar10 * 0x10);
                if (ppiVar3 != ppiVar1) break;
                *(int64_t ***)(iVar11 + uVar10 * 0x10) = ppiVar9;
                *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar2;
            }
            ppiVar4 = *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10);
            if (ppiVar9[2] != ppiVar4[2]) break;
            ppiVar4 = (int64_t **)*ppiVar4;
            if (ppiVar4 != ppiVar9) {
                piVar5 = ppiVar9[1];
                *piVar5 = (int64_t)ppiVar2;
                ppiVar3 = (int64_t **)ppiVar2[1];
                *ppiVar3 = (int64_t *)ppiVar4;
                piVar6 = ppiVar4[1];
                *piVar6 = (int64_t)ppiVar9;
                ppiVar4[1] = (int64_t *)ppiVar3;
                ppiVar2[1] = piVar5;
                ppiVar9[1] = piVar6;
            }
            *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10) = ppiVar9;
            ppiVar9 = ppiVar2;
        }
        do {
            if (ppiVar3 == ppiVar4) {
                piVar5 = ppiVar9[1];
                *piVar5 = (int64_t)ppiVar2;
                ppiVar3 = (int64_t **)ppiVar2[1];
                *ppiVar3 = (int64_t *)ppiVar4;
                piVar6 = ppiVar4[1];
                *piVar6 = (int64_t)ppiVar9;
                ppiVar4[1] = (int64_t *)ppiVar3;
                ppiVar2[1] = piVar5;
                ppiVar9[1] = piVar6;
                *(int64_t ***)(iVar11 + uVar10 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar2;
                goto joined_r0x00018001be9b;
            }
            ppiVar4 = (int64_t **)ppiVar4[1];
        } while (ppiVar9[2] != ppiVar4[2]);
        piVar5 = *ppiVar4;
        piVar6 = ppiVar9[1];
        *piVar6 = (int64_t)ppiVar2;
        ppiVar3 = (int64_t **)ppiVar2[1];
        *ppiVar3 = piVar5;
        piVar7 = (int64_t *)piVar5[1];
        *piVar7 = (int64_t)ppiVar9;
        piVar5[1] = (int64_t)ppiVar3;
        ppiVar2[1] = piVar6;
        ppiVar9[1] = piVar7;
        ppiVar9 = ppiVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18001bea1
// Address: 0x18001bea1
// Size: 300 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18001bda0(int64_t arg1, int64_t arg_48h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar12 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar10 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar12 < 0) {
        fVar14 = (float)(uVar12 >> 1 | (uint64_t)((uint32_t)uVar12 & 1));
        fVar14 = fVar14 + fVar14;
    } else {
        fVar14 = (float)uVar12;
    }
    fVar14 = (float)func_0x000180471c90(fVar14 / *(float *)arg1);
    iVar11 = 0;
    if ((9.223372e+18 <= fVar14) && (fVar14 = fVar14 - 9.223372e+18, fVar14 < 9.223372e+18)) {
        iVar11 = -0x8000000000000000;
    }
    uVar12 = 8;
    if (8 < (uint64_t)((int64_t)fVar14 + iVar11)) {
        uVar12 = (int64_t)fVar14 + iVar11;
    }
    uVar13 = uVar10;
    if ((uVar10 < uVar12) && ((0x1ff < uVar10 || (uVar13 = uVar10 * 8, uVar10 * 8 < uVar12)))) {
        uVar13 = uVar12;
    }
    for (iVar11 = 0x3f; 0xfffffffffffffffU >> iVar11 == 0; iVar11 = iVar11 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar11 & 0x3f)) < uVar13) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar1 = *(int64_t ***)(arg1 + 8);
    uVar10 = uVar13 - 1 | 1;
    iVar11 = 0x3f;
    if (uVar10 != 0) {
        for (; uVar10 >> iVar11 == 0; iVar11 = iVar11 + -1) {
        }
    }
    iVar11 = 1LL << ((char)iVar11 + 1U & 0x3f);
    func_0x00018000f7e0(arg1 + 0x18, iVar11 * 2, ppiVar1);
    *(int64_t *)(arg1 + 0x38) = iVar11;
    *(int64_t *)(arg1 + 0x30) = iVar11 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x00018001be9b:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar9 == ppiVar1) {
                    return;
                }
                iVar11 = *(int64_t *)(arg1 + 0x18);
                ppiVar2 = (int64_t **)*ppiVar9;
                uVar10 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30);
                ppiVar3 = *(int64_t ***)(iVar11 + uVar10 * 0x10);
                if (ppiVar3 != ppiVar1) break;
                *(int64_t ***)(iVar11 + uVar10 * 0x10) = ppiVar9;
                *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar2;
            }
            ppiVar4 = *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10);
            if (ppiVar9[2] != ppiVar4[2]) break;
            ppiVar4 = (int64_t **)*ppiVar4;
            if (ppiVar4 != ppiVar9) {
                piVar5 = ppiVar9[1];
                *piVar5 = (int64_t)ppiVar2;
                ppiVar3 = (int64_t **)ppiVar2[1];
                *ppiVar3 = (int64_t *)ppiVar4;
                piVar6 = ppiVar4[1];
                *piVar6 = (int64_t)ppiVar9;
                ppiVar4[1] = (int64_t *)ppiVar3;
                ppiVar2[1] = piVar5;
                ppiVar9[1] = piVar6;
            }
            *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10) = ppiVar9;
            ppiVar9 = ppiVar2;
        }
        do {
            if (ppiVar3 == ppiVar4) {
                piVar5 = ppiVar9[1];
                *piVar5 = (int64_t)ppiVar2;
                ppiVar3 = (int64_t **)ppiVar2[1];
                *ppiVar3 = (int64_t *)ppiVar4;
                piVar6 = ppiVar4[1];
                *piVar6 = (int64_t)ppiVar9;
                ppiVar4[1] = (int64_t *)ppiVar3;
                ppiVar2[1] = piVar5;
                ppiVar9[1] = piVar6;
                *(int64_t ***)(iVar11 + uVar10 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar2;
                goto joined_r0x00018001be9b;
            }
            ppiVar4 = (int64_t **)ppiVar4[1];
        } while (ppiVar9[2] != ppiVar4[2]);
        piVar5 = *ppiVar4;
        piVar6 = ppiVar9[1];
        *piVar6 = (int64_t)ppiVar2;
        ppiVar3 = (int64_t **)ppiVar2[1];
        *ppiVar3 = piVar5;
        piVar7 = (int64_t *)piVar5[1];
        *piVar7 = (int64_t)ppiVar9;
        piVar5[1] = (int64_t)ppiVar3;
        ppiVar2[1] = piVar6;
        ppiVar9[1] = piVar7;
        ppiVar9 = ppiVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18001bfcd
// Address: 0x18001bfcd
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18001bda0(int64_t arg1, int64_t arg_48h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar12 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar10 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar12 < 0) {
        fVar14 = (float)(uVar12 >> 1 | (uint64_t)((uint32_t)uVar12 & 1));
        fVar14 = fVar14 + fVar14;
    } else {
        fVar14 = (float)uVar12;
    }
    fVar14 = (float)func_0x000180471c90(fVar14 / *(float *)arg1);
    iVar11 = 0;
    if ((9.223372e+18 <= fVar14) && (fVar14 = fVar14 - 9.223372e+18, fVar14 < 9.223372e+18)) {
        iVar11 = -0x8000000000000000;
    }
    uVar12 = 8;
    if (8 < (uint64_t)((int64_t)fVar14 + iVar11)) {
        uVar12 = (int64_t)fVar14 + iVar11;
    }
    uVar13 = uVar10;
    if ((uVar10 < uVar12) && ((0x1ff < uVar10 || (uVar13 = uVar10 * 8, uVar10 * 8 < uVar12)))) {
        uVar13 = uVar12;
    }
    for (iVar11 = 0x3f; 0xfffffffffffffffU >> iVar11 == 0; iVar11 = iVar11 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar11 & 0x3f)) < uVar13) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar1 = *(int64_t ***)(arg1 + 8);
    uVar10 = uVar13 - 1 | 1;
    iVar11 = 0x3f;
    if (uVar10 != 0) {
        for (; uVar10 >> iVar11 == 0; iVar11 = iVar11 + -1) {
        }
    }
    iVar11 = 1LL << ((char)iVar11 + 1U & 0x3f);
    func_0x00018000f7e0(arg1 + 0x18, iVar11 * 2, ppiVar1);
    *(int64_t *)(arg1 + 0x38) = iVar11;
    *(int64_t *)(arg1 + 0x30) = iVar11 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x00018001be9b:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar9 == ppiVar1) {
                    return;
                }
                iVar11 = *(int64_t *)(arg1 + 0x18);
                ppiVar2 = (int64_t **)*ppiVar9;
                uVar10 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30);
                ppiVar3 = *(int64_t ***)(iVar11 + uVar10 * 0x10);
                if (ppiVar3 != ppiVar1) break;
                *(int64_t ***)(iVar11 + uVar10 * 0x10) = ppiVar9;
                *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar2;
            }
            ppiVar4 = *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10);
            if (ppiVar9[2] != ppiVar4[2]) break;
            ppiVar4 = (int64_t **)*ppiVar4;
            if (ppiVar4 != ppiVar9) {
                piVar5 = ppiVar9[1];
                *piVar5 = (int64_t)ppiVar2;
                ppiVar3 = (int64_t **)ppiVar2[1];
                *ppiVar3 = (int64_t *)ppiVar4;
                piVar6 = ppiVar4[1];
                *piVar6 = (int64_t)ppiVar9;
                ppiVar4[1] = (int64_t *)ppiVar3;
                ppiVar2[1] = piVar5;
                ppiVar9[1] = piVar6;
            }
            *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10) = ppiVar9;
            ppiVar9 = ppiVar2;
        }
        do {
            if (ppiVar3 == ppiVar4) {
                piVar5 = ppiVar9[1];
                *piVar5 = (int64_t)ppiVar2;
                ppiVar3 = (int64_t **)ppiVar2[1];
                *ppiVar3 = (int64_t *)ppiVar4;
                piVar6 = ppiVar4[1];
                *piVar6 = (int64_t)ppiVar9;
                ppiVar4[1] = (int64_t *)ppiVar3;
                ppiVar2[1] = piVar5;
                ppiVar9[1] = piVar6;
                *(int64_t ***)(iVar11 + uVar10 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar2;
                goto joined_r0x00018001be9b;
            }
            ppiVar4 = (int64_t **)ppiVar4[1];
        } while (ppiVar9[2] != ppiVar4[2]);
        piVar5 = *ppiVar4;
        piVar6 = ppiVar9[1];
        *piVar6 = (int64_t)ppiVar2;
        ppiVar3 = (int64_t **)ppiVar2[1];
        *ppiVar3 = piVar5;
        piVar7 = (int64_t *)piVar5[1];
        *piVar7 = (int64_t)ppiVar9;
        piVar5[1] = (int64_t)ppiVar3;
        ppiVar2[1] = piVar6;
        ppiVar9[1] = piVar7;
        ppiVar9 = ppiVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18001bfda
// Address: 0x18001bfda
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18001bda0(int64_t arg1, int64_t arg_48h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar12 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar10 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar12 < 0) {
        fVar14 = (float)(uVar12 >> 1 | (uint64_t)((uint32_t)uVar12 & 1));
        fVar14 = fVar14 + fVar14;
    } else {
        fVar14 = (float)uVar12;
    }
    fVar14 = (float)func_0x000180471c90(fVar14 / *(float *)arg1);
    iVar11 = 0;
    if ((9.223372e+18 <= fVar14) && (fVar14 = fVar14 - 9.223372e+18, fVar14 < 9.223372e+18)) {
        iVar11 = -0x8000000000000000;
    }
    uVar12 = 8;
    if (8 < (uint64_t)((int64_t)fVar14 + iVar11)) {
        uVar12 = (int64_t)fVar14 + iVar11;
    }
    uVar13 = uVar10;
    if ((uVar10 < uVar12) && ((0x1ff < uVar10 || (uVar13 = uVar10 * 8, uVar10 * 8 < uVar12)))) {
        uVar13 = uVar12;
    }
    for (iVar11 = 0x3f; 0xfffffffffffffffU >> iVar11 == 0; iVar11 = iVar11 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar11 & 0x3f)) < uVar13) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar1 = *(int64_t ***)(arg1 + 8);
    uVar10 = uVar13 - 1 | 1;
    iVar11 = 0x3f;
    if (uVar10 != 0) {
        for (; uVar10 >> iVar11 == 0; iVar11 = iVar11 + -1) {
        }
    }
    iVar11 = 1LL << ((char)iVar11 + 1U & 0x3f);
    func_0x00018000f7e0(arg1 + 0x18, iVar11 * 2, ppiVar1);
    *(int64_t *)(arg1 + 0x38) = iVar11;
    *(int64_t *)(arg1 + 0x30) = iVar11 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x00018001be9b:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar9 == ppiVar1) {
                    return;
                }
                iVar11 = *(int64_t *)(arg1 + 0x18);
                ppiVar2 = (int64_t **)*ppiVar9;
                uVar10 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30);
                ppiVar3 = *(int64_t ***)(iVar11 + uVar10 * 0x10);
                if (ppiVar3 != ppiVar1) break;
                *(int64_t ***)(iVar11 + uVar10 * 0x10) = ppiVar9;
                *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar2;
            }
            ppiVar4 = *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10);
            if (ppiVar9[2] != ppiVar4[2]) break;
            ppiVar4 = (int64_t **)*ppiVar4;
            if (ppiVar4 != ppiVar9) {
                piVar5 = ppiVar9[1];
                *piVar5 = (int64_t)ppiVar2;
                ppiVar3 = (int64_t **)ppiVar2[1];
                *ppiVar3 = (int64_t *)ppiVar4;
                piVar6 = ppiVar4[1];
                *piVar6 = (int64_t)ppiVar9;
                ppiVar4[1] = (int64_t *)ppiVar3;
                ppiVar2[1] = piVar5;
                ppiVar9[1] = piVar6;
            }
            *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10) = ppiVar9;
            ppiVar9 = ppiVar2;
        }
        do {
            if (ppiVar3 == ppiVar4) {
                piVar5 = ppiVar9[1];
                *piVar5 = (int64_t)ppiVar2;
                ppiVar3 = (int64_t **)ppiVar2[1];
                *ppiVar3 = (int64_t *)ppiVar4;
                piVar6 = ppiVar4[1];
                *piVar6 = (int64_t)ppiVar9;
                ppiVar4[1] = (int64_t *)ppiVar3;
                ppiVar2[1] = piVar5;
                ppiVar9[1] = piVar6;
                *(int64_t ***)(iVar11 + uVar10 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar2;
                goto joined_r0x00018001be9b;
            }
            ppiVar4 = (int64_t **)ppiVar4[1];
        } while (ppiVar9[2] != ppiVar4[2]);
        piVar5 = *ppiVar4;
        piVar6 = ppiVar9[1];
        *piVar6 = (int64_t)ppiVar2;
        ppiVar3 = (int64_t **)ppiVar2[1];
        *ppiVar3 = piVar5;
        piVar7 = (int64_t *)piVar5[1];
        *piVar7 = (int64_t)ppiVar9;
        piVar5[1] = (int64_t)ppiVar3;
        ppiVar2[1] = piVar6;
        ppiVar9[1] = piVar7;
        ppiVar9 = ppiVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18001c000
// Address: 0x18001c000
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18001bda0(int64_t arg1, int64_t arg_48h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar12 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar10 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar12 < 0) {
        fVar14 = (float)(uVar12 >> 1 | (uint64_t)((uint32_t)uVar12 & 1));
        fVar14 = fVar14 + fVar14;
    } else {
        fVar14 = (float)uVar12;
    }
    fVar14 = (float)func_0x000180471c90(fVar14 / *(float *)arg1);
    iVar11 = 0;
    if ((9.223372e+18 <= fVar14) && (fVar14 = fVar14 - 9.223372e+18, fVar14 < 9.223372e+18)) {
        iVar11 = -0x8000000000000000;
    }
    uVar12 = 8;
    if (8 < (uint64_t)((int64_t)fVar14 + iVar11)) {
        uVar12 = (int64_t)fVar14 + iVar11;
    }
    uVar13 = uVar10;
    if ((uVar10 < uVar12) && ((0x1ff < uVar10 || (uVar13 = uVar10 * 8, uVar10 * 8 < uVar12)))) {
        uVar13 = uVar12;
    }
    for (iVar11 = 0x3f; 0xfffffffffffffffU >> iVar11 == 0; iVar11 = iVar11 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar11 & 0x3f)) < uVar13) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar1 = *(int64_t ***)(arg1 + 8);
    uVar10 = uVar13 - 1 | 1;
    iVar11 = 0x3f;
    if (uVar10 != 0) {
        for (; uVar10 >> iVar11 == 0; iVar11 = iVar11 + -1) {
        }
    }
    iVar11 = 1LL << ((char)iVar11 + 1U & 0x3f);
    func_0x00018000f7e0(arg1 + 0x18, iVar11 * 2, ppiVar1);
    *(int64_t *)(arg1 + 0x38) = iVar11;
    *(int64_t *)(arg1 + 0x30) = iVar11 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x00018001be9b:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar9 == ppiVar1) {
                    return;
                }
                iVar11 = *(int64_t *)(arg1 + 0x18);
                ppiVar2 = (int64_t **)*ppiVar9;
                uVar10 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30);
                ppiVar3 = *(int64_t ***)(iVar11 + uVar10 * 0x10);
                if (ppiVar3 != ppiVar1) break;
                *(int64_t ***)(iVar11 + uVar10 * 0x10) = ppiVar9;
                *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar2;
            }
            ppiVar4 = *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10);
            if (ppiVar9[2] != ppiVar4[2]) break;
            ppiVar4 = (int64_t **)*ppiVar4;
            if (ppiVar4 != ppiVar9) {
                piVar5 = ppiVar9[1];
                *piVar5 = (int64_t)ppiVar2;
                ppiVar3 = (int64_t **)ppiVar2[1];
                *ppiVar3 = (int64_t *)ppiVar4;
                piVar6 = ppiVar4[1];
                *piVar6 = (int64_t)ppiVar9;
                ppiVar4[1] = (int64_t *)ppiVar3;
                ppiVar2[1] = piVar5;
                ppiVar9[1] = piVar6;
            }
            *(int64_t ***)(iVar11 + 8 + uVar10 * 0x10) = ppiVar9;
            ppiVar9 = ppiVar2;
        }
        do {
            if (ppiVar3 == ppiVar4) {
                piVar5 = ppiVar9[1];
                *piVar5 = (int64_t)ppiVar2;
                ppiVar3 = (int64_t **)ppiVar2[1];
                *ppiVar3 = (int64_t *)ppiVar4;
                piVar6 = ppiVar4[1];
                *piVar6 = (int64_t)ppiVar9;
                ppiVar4[1] = (int64_t *)ppiVar3;
                ppiVar2[1] = piVar5;
                ppiVar9[1] = piVar6;
                *(int64_t ***)(iVar11 + uVar10 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar2;
                goto joined_r0x00018001be9b;
            }
            ppiVar4 = (int64_t **)ppiVar4[1];
        } while (ppiVar9[2] != ppiVar4[2]);
        piVar5 = *ppiVar4;
        piVar6 = ppiVar9[1];
        *piVar6 = (int64_t)ppiVar2;
        ppiVar3 = (int64_t **)ppiVar2[1];
        *ppiVar3 = piVar5;
        piVar7 = (int64_t *)piVar5[1];
        *piVar7 = (int64_t)ppiVar9;
        piVar5[1] = (int64_t)ppiVar3;
        ppiVar2[1] = piVar6;
        ppiVar9[1] = piVar7;
        ppiVar9 = ppiVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18001c010
// Address: 0x18001c010
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 * fcn.18001c010(int64_t arg1, int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 *in_RAX;
    undefined4 *puVar5;
    undefined4 *puVar6;
    undefined8 unaff_RBX;
    int64_t **ppiVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar8 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return in_RAX;
    }
    ppiVar1 = *(int64_t ***)(arg1 + 0x20);
    for (ppiVar7 = *(int64_t ***)(arg1 + 0x18); ppiVar7 != ppiVar1; ppiVar7 = ppiVar7 + 1) {
        piVar2 = *ppiVar7;
        if (piVar2 != (int64_t *)0x0) {
            (**(code **)(*piVar2 + 0x10))(piVar2, 1);
        }
    }
    puVar6 = *(undefined4 **)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) {
        puVar5 = *(undefined4 **)(puVar6 + -2);
        if ((uint64_t)((int64_t)puVar6 + (-8 - (int64_t)puVar5)) < 0x20) goto code_r0x0001800f4640;
        puVar6 = (undefined4 *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)();
        puVar8 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar8 + 0x28);
    puVar5 = puVar6;
code_r0x0001800f4640:
    if (puVar5 != (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        puVar5 = (undefined4 *)(*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar5);
        if ((int32_t)puVar5 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = fcn.18046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)fcn.18046b77c();
            *puVar5 = uVar4;
        }
    }
    return puVar5;
}

// ============================================================
// Function: FUN_18001c024
// Address: 0x18001c024
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 * fcn.18001c010(int64_t arg1, int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 *in_RAX;
    undefined4 *puVar5;
    undefined4 *puVar6;
    undefined8 unaff_RBX;
    int64_t **ppiVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar8 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return in_RAX;
    }
    ppiVar1 = *(int64_t ***)(arg1 + 0x20);
    for (ppiVar7 = *(int64_t ***)(arg1 + 0x18); ppiVar7 != ppiVar1; ppiVar7 = ppiVar7 + 1) {
        piVar2 = *ppiVar7;
        if (piVar2 != (int64_t *)0x0) {
            (**(code **)(*piVar2 + 0x10))(piVar2, 1);
        }
    }
    puVar6 = *(undefined4 **)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) {
        puVar5 = *(undefined4 **)(puVar6 + -2);
        if ((uint64_t)((int64_t)puVar6 + (-8 - (int64_t)puVar5)) < 0x20) goto code_r0x0001800f4640;
        puVar6 = (undefined4 *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)();
        puVar8 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar8 + 0x28);
    puVar5 = puVar6;
code_r0x0001800f4640:
    if (puVar5 != (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        puVar5 = (undefined4 *)(*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar5);
        if ((int32_t)puVar5 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = fcn.18046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)fcn.18046b77c();
            *puVar5 = uVar4;
        }
    }
    return puVar5;
}

// ============================================================
// Function: FUN_18001c07f
// Address: 0x18001c07f
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 * fcn.18001c010(int64_t arg1, int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 *in_RAX;
    undefined4 *puVar5;
    undefined4 *puVar6;
    undefined8 unaff_RBX;
    int64_t **ppiVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar8 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return in_RAX;
    }
    ppiVar1 = *(int64_t ***)(arg1 + 0x20);
    for (ppiVar7 = *(int64_t ***)(arg1 + 0x18); ppiVar7 != ppiVar1; ppiVar7 = ppiVar7 + 1) {
        piVar2 = *ppiVar7;
        if (piVar2 != (int64_t *)0x0) {
            (**(code **)(*piVar2 + 0x10))(piVar2, 1);
        }
    }
    puVar6 = *(undefined4 **)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) {
        puVar5 = *(undefined4 **)(puVar6 + -2);
        if ((uint64_t)((int64_t)puVar6 + (-8 - (int64_t)puVar5)) < 0x20) goto code_r0x0001800f4640;
        puVar6 = (undefined4 *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)();
        puVar8 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar8 + 0x28);
    puVar5 = puVar6;
code_r0x0001800f4640:
    if (puVar5 != (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        puVar5 = (undefined4 *)(*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar5);
        if ((int32_t)puVar5 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = fcn.18046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)fcn.18046b77c();
            *puVar5 = uVar4;
        }
    }
    return puVar5;
}

// ============================================================
// Function: FUN_18001c0c0
// Address: 0x18001c0c0
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001c0c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_58h)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    undefined *puVar5;
    int64_t var_8h;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    ppiVar3 = *(int64_t ***)0x180781fe8;
    if (*(int64_t ***)0x180781fe0 != (int64_t **)0x0) {
        ppiVar4 = *(int64_t ***)0x180781fe0;
        if (*(int64_t ***)0x180781fe0 != *(int64_t ***)0x180781fe8) {
            do {
                piVar1 = *ppiVar4;
                if (piVar1 != (int64_t *)0x0) {
                    (**(code **)(*piVar1 + 0x10))(piVar1, 1);
                }
                ppiVar4 = ppiVar4 + 1;
            } while (ppiVar4 != ppiVar3);
        }
        ppiVar3 = *(int64_t ***)0x180781fe0;
        puVar5 = auStack_48;
        if (0xfff < (uint64_t)((*(int64_t *)0x180781ff0 - (int64_t)*(int64_t ***)0x180781fe0 >> 3) * 8)) {
            ppiVar3 = (int64_t **)(*(int64_t ***)0x180781fe0)[-1];
            ppiVar4 = (int64_t **)((int64_t)*(int64_t ***)0x180781fe0 + (-8 - (int64_t)ppiVar3));
            puVar5 = auStack_48;
            if ((int64_t **)0x1f < ppiVar4) {
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                ppiVar3 = ppiVar4;
                puVar5 = auStack_40;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18001c15d;
        fcn.180459c3c(ppiVar3);
    }
    *(int64_t *)0x180781fe0 = (int64_t **)arg2;
    *(int64_t *)0x180781fe8 = (int64_t **)(arg2 + arg3 * 8);
    *(int64_t *)0x180781ff0 = arg2 + arg4 * 8;
    return;
}

// ============================================================
// Function: FUN_18001c0df
// Address: 0x18001c0df
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001c0c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_58h)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    undefined *puVar5;
    int64_t var_8h;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    ppiVar3 = *(int64_t ***)0x180781fe8;
    if (*(int64_t ***)0x180781fe0 != (int64_t **)0x0) {
        ppiVar4 = *(int64_t ***)0x180781fe0;
        if (*(int64_t ***)0x180781fe0 != *(int64_t ***)0x180781fe8) {
            do {
                piVar1 = *ppiVar4;
                if (piVar1 != (int64_t *)0x0) {
                    (**(code **)(*piVar1 + 0x10))(piVar1, 1);
                }
                ppiVar4 = ppiVar4 + 1;
            } while (ppiVar4 != ppiVar3);
        }
        ppiVar3 = *(int64_t ***)0x180781fe0;
        puVar5 = auStack_48;
        if (0xfff < (uint64_t)((*(int64_t *)0x180781ff0 - (int64_t)*(int64_t ***)0x180781fe0 >> 3) * 8)) {
            ppiVar3 = (int64_t **)(*(int64_t ***)0x180781fe0)[-1];
            ppiVar4 = (int64_t **)((int64_t)*(int64_t ***)0x180781fe0 + (-8 - (int64_t)ppiVar3));
            puVar5 = auStack_48;
            if ((int64_t **)0x1f < ppiVar4) {
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                ppiVar3 = ppiVar4;
                puVar5 = auStack_40;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18001c15d;
        fcn.180459c3c(ppiVar3);
    }
    *(int64_t *)0x180781fe0 = (int64_t **)arg2;
    *(int64_t *)0x180781fe8 = (int64_t **)(arg2 + arg3 * 8);
    *(int64_t *)0x180781ff0 = arg2 + arg4 * 8;
    return;
}

// ============================================================
// Function: FUN_18001c137
// Address: 0x18001c137
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001c0c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_58h)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    undefined *puVar5;
    int64_t var_8h;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    ppiVar3 = *(int64_t ***)0x180781fe8;
    if (*(int64_t ***)0x180781fe0 != (int64_t **)0x0) {
        ppiVar4 = *(int64_t ***)0x180781fe0;
        if (*(int64_t ***)0x180781fe0 != *(int64_t ***)0x180781fe8) {
            do {
                piVar1 = *ppiVar4;
                if (piVar1 != (int64_t *)0x0) {
                    (**(code **)(*piVar1 + 0x10))(piVar1, 1);
                }
                ppiVar4 = ppiVar4 + 1;
            } while (ppiVar4 != ppiVar3);
        }
        ppiVar3 = *(int64_t ***)0x180781fe0;
        puVar5 = auStack_48;
        if (0xfff < (uint64_t)((*(int64_t *)0x180781ff0 - (int64_t)*(int64_t ***)0x180781fe0 >> 3) * 8)) {
            ppiVar3 = (int64_t **)(*(int64_t ***)0x180781fe0)[-1];
            ppiVar4 = (int64_t **)((int64_t)*(int64_t ***)0x180781fe0 + (-8 - (int64_t)ppiVar3));
            puVar5 = auStack_48;
            if ((int64_t **)0x1f < ppiVar4) {
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                ppiVar3 = ppiVar4;
                puVar5 = auStack_40;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18001c15d;
        fcn.180459c3c(ppiVar3);
    }
    *(int64_t *)0x180781fe0 = (int64_t **)arg2;
    *(int64_t *)0x180781fe8 = (int64_t **)(arg2 + arg3 * 8);
    *(int64_t *)0x180781ff0 = arg2 + arg4 * 8;
    return;
}

// ============================================================
// Function: FUN_18001c190
// Address: 0x18001c190
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.18001c190(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x00018001c2bc;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x00018001c2bc;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x00018001c2bc:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x20);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001c1ac
// Address: 0x18001c1ac
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.18001c190(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x00018001c2bc;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x00018001c2bc;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x00018001c2bc:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x20);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001c1c9
// Address: 0x18001c1c9
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.18001c190(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x00018001c2bc;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x00018001c2bc;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x00018001c2bc:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x20);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001c1f8
// Address: 0x18001c1f8
// Size: 218 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.18001c190(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x00018001c2bc;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x00018001c2bc;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x00018001c2bc:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x20);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001c2d2
// Address: 0x18001c2d2
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.18001c190(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x00018001c2bc;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x00018001c2bc;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x00018001c2bc:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x20);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001c2d7
// Address: 0x18001c2d7
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.18001c190(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x00018001c2bc;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x00018001c2bc;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x00018001c2bc:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x20);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001c2e6
// Address: 0x18001c2e6
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.18001c190(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x00018001c2bc;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x00018001c2bc;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x00018001c2bc:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x20);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001c2ec
// Address: 0x18001c2ec
// Size: 244 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.18001c190(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x00018001c2bc;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x00018001c2bc;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x00018001c2bc:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x20);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001c3e0
// Address: 0x18001c3e0
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.18001c190(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x00018001c2bc;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x00018001c2bc;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x00018001c2bc:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x20);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001c440
// Address: 0x18001c440
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001c440(int64_t arg1, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    
    puVar1 = *(undefined8 **)arg1;
    *(undefined8 *)puVar1[1] = 0;
    puVar1 = (undefined8 *)*puVar1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar2 = (undefined8 *)*puVar1;
        fcn.180459c3c(puVar1, 0x20);
        puVar1 = puVar2;
    }
    if ((*(int64_t *)arg1 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18001c45f
// Address: 0x18001c45f
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001c440(int64_t arg1, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    
    puVar1 = *(undefined8 **)arg1;
    *(undefined8 *)puVar1[1] = 0;
    puVar1 = (undefined8 *)*puVar1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar2 = (undefined8 *)*puVar1;
        fcn.180459c3c(puVar1, 0x20);
        puVar1 = puVar2;
    }
    if ((*(int64_t *)arg1 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18001c48a
// Address: 0x18001c48a
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001c440(int64_t arg1, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    
    puVar1 = *(undefined8 **)arg1;
    *(undefined8 *)puVar1[1] = 0;
    puVar1 = (undefined8 *)*puVar1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar2 = (undefined8 *)*puVar1;
        fcn.180459c3c(puVar1, 0x20);
        puVar1 = puVar2;
    }
    if ((*(int64_t *)arg1 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18001c4a0
// Address: 0x18001c4a0
// Size: 9727 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2177h
// WARNING: [rz-ghidra] Detected overlap for variable var_20e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_20f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_20ech
// WARNING: [rz-ghidra] Detected overlap for variable var_20d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1f08h
// WARNING: [rz-ghidra] Detected overlap for variable var_1f10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1f0ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1f0ah
// WARNING: [rz-ghidra] Detected overlap for variable var_1ee8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ef0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1eech
// WARNING: [rz-ghidra] Detected overlap for variable var_1eeah
// WARNING: [rz-ghidra] Detected overlap for variable var_1e28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1e30h
// WARNING: [rz-ghidra] Detected overlap for variable var_1e2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_2199h
// WARNING: [rz-ghidra] Detected overlap for variable var_2195h
// WARNING: [rz-ghidra] Detected overlap for variable var_21beh
// WARNING: [rz-ghidra] Detected overlap for variable var_21bdh
// WARNING: [rz-ghidra] Detected overlap for variable var_2088h
// WARNING: [rz-ghidra] Detected overlap for variable var_2090h
// WARNING: [rz-ghidra] Detected overlap for variable var_2074h
// WARNING: [rz-ghidra] Detected overlap for variable var_2072h
// WARNING: [rz-ghidra] Detected overlap for variable var_2071h
// WARNING: [rz-ghidra] Detected overlap for variable var_2054h
// WARNING: [rz-ghidra] Detected overlap for variable var_2034h
// WARNING: [rz-ghidra] Detected overlap for variable var_2032h
// WARNING: [rz-ghidra] Detected overlap for variable var_2031h
// WARNING: [rz-ghidra] Detected overlap for variable var_1fd1h
// WARNING: [rz-ghidra] Detected overlap for variable var_1fcdh
// WARNING: [rz-ghidra] Detected overlap for variable var_1f6fh
// WARNING: [rz-ghidra] Detected overlap for variable var_21d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_21d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_21d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1a91h
// WARNING: [rz-ghidra] Detected overlap for variable var_1a8dh
// WARNING: [rz-ghidra] Detected overlap for variable var_1a68h
// WARNING: [rz-ghidra] Detected overlap for variable var_1a70h
// WARNING: [rz-ghidra] Detected overlap for variable var_1a6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1a6ah
// WARNING: [rz-ghidra] Removing arg arg_2898h because it doesn't fit into ProtoModel

void fcn.18001c4a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t unaff_GS_OFFSET;
    undefined4 uVar5;
    int64_t var_8h;
    int64_t *piStackX_18;
    int64_t var_20h;
    int64_t var_27e0h;
    int64_t var_27a0h;
    int64_t var_2760h;
    int64_t var_2720h;
    int64_t var_26e0h;
    int64_t var_26a0h;
    int64_t var_2660h;
    int64_t var_2620h;
    int64_t var_25e0h;
    int64_t var_25a0h;
    int64_t var_2560h;
    int64_t var_2520h;
    int64_t var_24e0h;
    int64_t var_24a0h;
    int64_t var_2460h;
    int64_t var_2420h;
    int64_t var_23e0h;
    int64_t var_23a0h;
    int64_t var_2360h;
    int64_t var_2320h;
    int64_t var_22e0h;
    int64_t var_22a0h;
    int64_t var_2260h;
    int64_t var_2220h;
    int64_t var_21e0h;
    undefined4 var_21d8h;
    undefined2 var_21d4h;
    int64_t var_21d2h;
    int64_t var_21c8h;
    int64_t var_21c0h;
    int64_t var_21b0h;
    int64_t var_21a8h;
    int64_t var_21a0h;
    unkbyte5 var_2195h;
    int64_t var_2190h;
    int64_t var_2188h;
    int64_t var_2180h;
    int64_t var_2178h;
    int64_t var_2170h;
    int64_t var_2168h;
    int64_t var_2160h;
    undefined8 uStack_2158;
    int64_t var_2150h;
    int64_t var_2148h;
    int64_t var_2138h;
    undefined8 uStack_2130;
    int64_t var_2128h;
    int64_t var_2120h;
    int64_t var_2118h;
    undefined8 uStack_2110;
    int64_t var_2108h;
    int64_t var_2100h;
    int64_t var_20f8h;
    undefined4 var_20f0h;
    undefined2 var_20ech;
    int64_t var_20eah;
    int64_t var_20e0h;
    int64_t var_20d8h;
    int64_t var_20c8h;
    int64_t var_20c0h;
    int64_t var_20b8h;
    int64_t var_20a8h;
    int64_t var_20a0h;
    int64_t var_2098h;
    undefined4 var_2090h;
    int64_t var_208ch;
    int64_t var_2080h;
    int64_t var_2078h;
    int64_t var_2068h;
    int64_t var_2060h;
    int64_t var_2058h;
    int64_t var_2048h;
    int64_t var_2040h;
    int64_t var_2038h;
    int64_t var_2028h;
    int64_t var_2020h;
    int64_t var_2018h;
    int64_t var_2008h;
    int64_t var_2000h;
    int64_t var_1ff8h;
    int64_t var_1fe8h;
    int64_t var_1fe0h;
    int64_t var_1fd8h;
    unkbyte5 var_1fcdh;
    int64_t var_1fc8h;
    int64_t var_1fc0h;
    int64_t var_1fb8h;
    int64_t var_1fa8h;
    int64_t var_1fa0h;
    int64_t var_1f98h;
    int64_t var_1f88h;
    int64_t var_1f80h;
    int64_t var_1f78h;
    int64_t var_1f70h;
    int64_t var_1f68h;
    int64_t var_1f60h;
    int64_t var_1f58h;
    int64_t var_1f48h;
    int64_t var_1f40h;
    int64_t var_1f38h;
    int64_t var_1f28h;
    int64_t var_1f20h;
    int64_t var_1f18h;
    undefined4 var_1f10h;
    undefined2 var_1f0ch;
    undefined var_1f0ah;
    int64_t var_1f09h;
    int64_t var_1f00h;
    int64_t var_1ef8h;
    undefined4 var_1ef0h;
    undefined2 var_1eech;
    undefined var_1eeah;
    int64_t var_1ee9h;
    int64_t var_1ee0h;
    int64_t var_1ed8h;
    undefined8 uStack_1ed0;
    int64_t var_1ec8h;
    int64_t var_1ec0h;
    int64_t var_1eb8h;
    undefined8 uStack_1eb0;
    int64_t var_1ea8h;
    int64_t var_1ea0h;
    int64_t var_1e98h;
    undefined8 uStack_1e90;
    int64_t var_1e88h;
    int64_t var_1e80h;
    int64_t var_1e78h;
    undefined8 uStack_1e70;
    int64_t var_1e68h;
    int64_t var_1e60h;
    int64_t var_1e58h;
    undefined8 uStack_1e50;
    int64_t var_1e48h;
    int64_t var_1e40h;
    int64_t var_1e38h;
    undefined4 var_1e30h;
    undefined2 var_1e2ch;
    int64_t var_1e2ah;
    int64_t var_1e20h;
    int64_t var_1e18h;
    undefined8 uStack_1e10;
    int64_t var_1e08h;
    int64_t var_1e00h;
    int64_t var_1df8h;
    int64_t var_1de8h;
    int64_t var_1de0h;
    int64_t var_1dd8h;
    int64_t var_1dc8h;
    int64_t var_1dc0h;
    int64_t var_1db8h;
    int64_t var_1da8h;
    int64_t var_1da0h;
    int64_t var_1d98h;
    int64_t var_1d88h;
    int64_t var_1d80h;
    int64_t var_1d78h;
    int64_t var_1d68h;
    int64_t var_1d60h;
    int64_t var_1d58h;
    int64_t var_1d48h;
    int64_t var_1d40h;
    int64_t var_1d38h;
    int64_t var_1d28h;
    int64_t var_1d20h;
    int64_t var_1d18h;
    int64_t var_1d08h;
    int64_t var_1d00h;
    int64_t var_1cf8h;
    int64_t var_1ce8h;
    int64_t var_1ce0h;
    int64_t var_1cd8h;
    int64_t var_1cc8h;
    int64_t var_1cc0h;
    int64_t var_1cb8h;
    int64_t var_1ca8h;
    int64_t var_1ca0h;
    int64_t var_1c98h;
    int64_t var_1c88h;
    int64_t var_1c80h;
    int64_t var_1c78h;
    int64_t var_1c68h;
    int64_t var_1c60h;
    int64_t var_1c58h;
    int64_t var_1c48h;
    int64_t var_1c40h;
    int64_t var_1c38h;
    int64_t var_1c28h;
    int64_t var_1c20h;
    int64_t var_1c18h;
    int64_t var_1bf8h;
    int64_t var_1bd8h;
    int64_t var_1bb8h;
    int64_t var_1b98h;
    int64_t var_1b78h;
    int64_t var_1b58h;
    int64_t var_1b38h;
    int64_t var_1b18h;
    int64_t var_1b08h;
    int64_t var_1b00h;
    int64_t var_1af8h;
    int64_t var_1ae8h;
    int64_t var_1ae0h;
    int64_t var_1ad8h;
    int64_t var_1ac8h;
    int64_t var_1ac0h;
    int64_t var_1ab8h;
    int64_t var_1aa8h;
    int64_t var_1aa0h;
    int64_t var_1a98h;
    unkbyte5 var_1a8dh;
    int64_t var_1a88h;
    int64_t var_1a80h;
    int64_t var_1a78h;
    undefined4 var_1a70h;
    undefined2 var_1a6ch;
    undefined var_1a6ah;
    int64_t var_1a69h;
    int64_t var_1a60h;
    int64_t var_1a58h;
    int64_t var_1a38h;
    int64_t var_1a18h;
    int64_t var_19f8h;
    int64_t var_19d8h;
    int64_t var_19b8h;
    int64_t var_1998h;
    int64_t var_1978h;
    int64_t var_1958h;
    int64_t var_1938h;
    int64_t var_1918h;
    int64_t var_18f8h;
    int64_t var_18d8h;
    int64_t var_18b8h;
    int64_t var_1898h;
    int64_t var_1878h;
    int64_t var_1858h;
    int64_t var_1838h;
    int64_t var_1818h;
    int64_t var_17f8h;
    int64_t var_17d8h;
    int64_t var_17b8h;
    int64_t var_1798h;
    int64_t var_1778h;
    int64_t var_1758h;
    int64_t var_1738h;
    int64_t var_1718h;
    int64_t var_16f8h;
    int64_t var_16d8h;
    int64_t var_16b8h;
    int64_t var_1698h;
    int64_t var_1678h;
    int64_t var_1658h;
    int64_t var_1638h;
    int64_t var_1618h;
    int64_t var_15f8h;
    int64_t var_15d8h;
    int64_t var_15b8h;
    int64_t var_1598h;
    int64_t var_1578h;
    int64_t var_1558h;
    int64_t var_1538h;
    int64_t var_1518h;
    int64_t var_14f8h;
    int64_t var_14d8h;
    int64_t var_14b8h;
    int64_t var_1498h;
    int64_t var_1478h;
    int64_t var_1458h;
    int64_t var_1438h;
    int64_t var_1418h;
    int64_t var_13f8h;
    int64_t var_13d8h;
    int64_t var_13b8h;
    int64_t var_1398h;
    int64_t var_1378h;
    int64_t var_1358h;
    int64_t var_1338h;
    int64_t var_1318h;
    int64_t var_12f8h;
    int64_t var_12d8h;
    int64_t var_12b8h;
    int64_t var_1298h;
    int64_t var_1278h;
    int64_t var_1258h;
    int64_t var_1238h;
    int64_t var_1218h;
    int64_t var_11f8h;
    int64_t var_11d8h;
    int64_t var_11b8h;
    int64_t var_1198h;
    int64_t var_1178h;
    int64_t var_1158h;
    int64_t var_1138h;
    int64_t var_1118h;
    int64_t var_10f8h;
    int64_t var_10d8h;
    int64_t var_10b8h;
    int64_t var_1098h;
    int64_t var_1078h;
    int64_t var_1058h;
    int64_t var_1038h;
    int64_t var_1018h;
    int64_t var_ff8h;
    int64_t var_fd8h;
    int64_t var_fb8h;
    int64_t var_f98h;
    int64_t var_f78h;
    int64_t var_f58h;
    int64_t var_f38h;
    int64_t var_f18h;
    int64_t var_ef8h;
    int64_t var_ed8h;
    int64_t var_eb8h;
    int64_t var_e98h;
    int64_t var_e78h;
    int64_t var_e58h;
    int64_t var_e38h;
    int64_t var_e18h;
    int64_t var_df8h;
    int64_t var_dd8h;
    int64_t var_db8h;
    int64_t var_d98h;
    int64_t var_d78h;
    int64_t var_d58h;
    int64_t var_d38h;
    int64_t var_d18h;
    int64_t var_cf8h;
    int64_t var_cd8h;
    int64_t var_cb8h;
    int64_t var_c98h;
    int64_t var_c78h;
    int64_t var_c58h;
    int64_t var_c38h;
    int64_t var_c18h;
    int64_t var_bf8h;
    int64_t var_bd8h;
    int64_t var_bb8h;
    int64_t var_b98h;
    int64_t var_b78h;
    int64_t var_b58h;
    int64_t var_b38h;
    int64_t var_b18h;
    int64_t var_af8h;
    int64_t var_ad8h;
    int64_t var_ab8h;
    int64_t var_a98h;
    int64_t var_a78h;
    int64_t var_a58h;
    int64_t var_a38h;
    int64_t var_a18h;
    int64_t var_9f8h;
    int64_t var_9d8h;
    int64_t var_9b8h;
    int64_t var_978h;
    int64_t var_958h;
    int64_t var_918h;
    int64_t var_8f8h;
    int64_t var_8b8h;
    int64_t var_898h;
    int64_t var_858h;
    int64_t var_7f8h;
    int64_t var_798h;
    int64_t var_738h;
    int64_t var_6d8h;
    int64_t var_678h;
    int64_t var_618h;
    int64_t var_5b8h;
    int64_t var_558h;
    int64_t var_4f8h;
    int64_t var_498h;
    int64_t var_438h;
    int64_t var_3d8h;
    int64_t var_378h;
    int64_t var_318h;
    int64_t var_2b8h;
    int64_t var_258h;
    int64_t var_1f8h;
    int64_t var_198h;
    int64_t var_138h;
    int64_t var_d8h;
    int64_t var_78h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18001c4b8;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar1);
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x180782800) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c522;
        fcn.180459d18(0x180782800);
        if (*(int32_t *)0x180782800 == -1) {
            var_2170h = 9;
            var_2168h = 0xf;
            var_2178h._0_1_ = 0x6c;
            var_2180h = 0x65646f4d61746144;
            var_2178h._1_7_ = 0;
            _var_2138h = ZEXT816(0);
            var_2128h = 0;
            var_2120h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c593;
            puVar2 = (undefined4 *)fcn.180459890(0x20);
            var_2138h = (int64_t)puVar2;
            var_2128h = 0x15;
            var_2120h = 0x1f;
            *puVar2 = 0x6e65704f;
            puVar2[1] = 0x65726353;
            puVar2[2] = 0x68736e65;
            puVar2[3] = 0x4673746f;
            *(undefined8 *)((int64_t)puVar2 + 0xd) = 0x7265646c6f467374;
            *(undefined *)((int64_t)puVar2 + 0x15) = 0;
            _var_2118h = ZEXT816(0);
            var_2108h = 0;
            var_2100h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c5ec;
            puVar2 = (undefined4 *)fcn.180459890(0x20);
            var_2118h = (int64_t)puVar2;
            var_2108h = 0x10;
            var_2100h = 0x1f;
            *puVar2 = 0x6e65704f;
            puVar2[1] = 0x65646956;
            puVar2[2] = 0x6f46736f;
            puVar2[3] = 0x7265646c;
            *(undefined *)(puVar2 + 4) = 0;
            stack0xffffffffffffdf18 = 0xe;
            var_20e0h = 0xf;
            var_20f8h = 0x73676f4c6e65704f;
            var_20f0h = 0x646c6f46;
            var_20ech = 0x7265;
            var_20eah._0_2_ = 0;
            var_20c8h = 4;
            var_20c0h = 0xf;
            stack0xffffffffffffdf2d = SUB1611(ZEXT816(0), 5);
            var_20d8h._0_5_ = 0x64616f4c;
            *(undefined4 *)((int64_t)&arg_30h + iVar1) = 0;
            *(undefined8 *)((int64_t)&arg_38h + iVar1) = 0;
            *(undefined8 *)((int64_t)&arg_40h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c6ad;
            iVar3 = fcn.180459890(0x30);
            *(int64_t *)iVar3 = iVar3;
            *(int64_t *)(iVar3 + 8) = iVar3;
            *(int64_t *)((int64_t)&arg_38h + iVar1) = iVar3;
            *(undefined (*) [16])((int64_t)&arg_48h + iVar1) = ZEXT816(0);
            *(undefined8 *)((int64_t)&arg_58h + iVar1) = 0;
            *(undefined8 *)((int64_t)&arg_60h + iVar1) = 7;
            *(undefined8 *)((int64_t)&arg_68h + iVar1) = 8;
            *(undefined4 *)((int64_t)&arg_30h + iVar1) = 0x3f800000;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c6f3;
            fcn.18000f7e0((int64_t)&arg_48h + iVar1, 0x10, iVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c70c;
            fcn.18001f7a0(*(int64_t *)((int64_t)&piStackX_18 + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c720;
            fcn.18000b4d0(&var_9d8h, &var_2180h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c732;
            fcn.18001f4b0(&var_9b8h, (int64_t)&arg_30h + iVar1);
            _var_2160h = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c747;
            puVar2 = (undefined4 *)fcn.180459890(0x20);
            var_2160h = (int64_t)puVar2;
            var_2150h = 0x12;
            var_2148h = 0x1f;
            *puVar2 = 0x6b72614d;
            puVar2[1] = 0x6c707465;
            puVar2[2] = 0x53656361;
            puVar2[3] = 0x69767265;
            *(undefined2 *)(puVar2 + 4) = 0x6563;
            *(undefined *)((int64_t)puVar2 + 0x12) = 0;
            stack0xffffffffffffe0f8 = 0xf;
            var_1f00h = 0xf;
            var_1f18h = 0x7875626f52746547;
            var_1f10h = 0x616c6142;
            var_1f0ch = 0x636e;
            var_1f0ah = 0x65;
            var_1f09h._0_1_ = 0;
            stack0xffffffffffffe118 = 0xf;
            var_1ee0h = 0xf;
            var_1ef8h = 0x506d726f66726550;
            var_1ef0h = 0x68637275;
            var_1eech = 0x7361;
            var_1eeah = 0x65;
            var_1ee9h._0_1_ = 0;
            _var_1ed8h = ZEXT816(0);
            var_1ec8h = 0;
            var_1ec0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c850;
            puVar2 = (undefined4 *)fcn.180459890(0x20);
            var_1ed8h = (int64_t)puVar2;
            var_1ec8h = 0x11;
            var_1ec0h = 0x1f;
            *puVar2 = 0x66726550;
            puVar2[1] = 0x506d726f;
            puVar2[2] = 0x68637275;
            puVar2[3] = 0x56657361;
            *(undefined *)(puVar2 + 4) = 0x32;
            *(undefined *)((int64_t)puVar2 + 0x11) = 0;
            _var_1eb8h = ZEXT816(0);
            var_1ea8h = 0;
            var_1ea0h = 0;
            *(undefined8 *)((int64_t)&piStackX_18 + iVar1) = 0x1f;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c8b6;
            puVar2 = (undefined4 *)fcn.180004930(&var_1eb8h, (int64_t)&piStackX_18 + iVar1);
            var_1eb8h = (int64_t)puVar2;
            var_1ea8h = 0x13;
            var_1ea0h = *(int64_t *)((int64_t)&piStackX_18 + iVar1);
            *puVar2 = 0x66726550;
            puVar2[1] = 0x426d726f;
            puVar2[2] = 0x506b6c75;
            puVar2[3] = 0x68637275;
            *(undefined4 *)((int64_t)puVar2 + 0xf) = 0x65736168;
            *(undefined *)((int64_t)puVar2 + 0x13) = 0;
            _var_1e98h = ZEXT816(0);
            var_1e88h = 0;
            var_1e80h = 0;
            *(undefined8 *)((int64_t)&piStackX_18 + iVar1) = 0x1f;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c91c;
            puVar2 = (undefined4 *)fcn.180004930(&var_1e98h, (int64_t)&piStackX_18 + iVar1);
            var_1e98h = (int64_t)puVar2;
            var_1e88h = 0x1b;
            var_1e80h = *(int64_t *)((int64_t)&piStackX_18 + iVar1);
            *puVar2 = 0x66726550;
            puVar2[1] = 0x536d726f;
            puVar2[2] = 0x63736275;
            puVar2[3] = 0x74706972;
            *(undefined4 *)((int64_t)puVar2 + 0xb) = 0x70697263;
            *(undefined4 *)((int64_t)puVar2 + 0xf) = 0x6e6f6974;
            *(undefined4 *)((int64_t)puVar2 + 0x13) = 0x63727550;
            *(undefined4 *)((int64_t)puVar2 + 0x17) = 0x65736168;
            *(undefined *)((int64_t)puVar2 + 0x1b) = 0;
            _var_1e78h = ZEXT816(0);
            var_1e68h = 0;
            var_1e60h = 0;
            *(undefined8 *)((int64_t)&piStackX_18 + iVar1) = 0x1f;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c984;
            puVar2 = (undefined4 *)fcn.180004930(&var_1e78h, (int64_t)&piStackX_18 + iVar1);
            var_1e78h = (int64_t)puVar2;
            var_1e68h = 0x1d;
            var_1e60h = *(int64_t *)((int64_t)&piStackX_18 + iVar1);
            *puVar2 = 0x66726550;
            puVar2[1] = 0x536d726f;
            puVar2[2] = 0x63736275;
            puVar2[3] = 0x74706972;
            *(undefined4 *)((int64_t)puVar2 + 0xd) = 0x69747069;
            *(undefined4 *)((int64_t)puVar2 + 0x11) = 0x75506e6f;
            *(undefined4 *)((int64_t)puVar2 + 0x15) = 0x61686372;
            *(undefined4 *)((int64_t)puVar2 + 0x19) = 0x32566573;
            *(undefined *)((int64_t)puVar2 + 0x1d) = 0;
            _var_1e58h = ZEXT816(0);
            var_1e48h = 0;
            var_1e40h = 0;
            *(undefined8 *)((int64_t)&piStackX_18 + iVar1) = 0x1f;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c9ec;
            puVar2 = (undefined4 *)fcn.180004930(&var_1e58h, (int64_t)&piStackX_18 + iVar1);
            var_1e58h = (int64_t)puVar2;
            var_1e48h = 0x19;
            var_1e40h = *(int64_t *)((int64_t)&piStackX_18 + iVar1);
            *puVar2 = 0x66726550;
            puVar2[1] = 0x436d726f;
            puVar2[2] = 0x65636e61;
            puVar2[3] = 0x6275536c;
            *(undefined4 *)((int64_t)puVar2 + 9) = 0x6c65636e;
            *(undefined4 *)((int64_t)puVar2 + 0xd) = 0x73627553;
            *(undefined4 *)((int64_t)puVar2 + 0x11) = 0x70697263;
            *(undefined4 *)((int64_t)puVar2 + 0x15) = 0x6e6f6974;
            *(undefined *)((int64_t)puVar2 + 0x19) = 0;
            stack0xffffffffffffe1d8 = 0xe;
            var_1e20h = 0xf;
            var_1e38h = 0x755074706d6f7250;
            var_1e30h = 0x61686372;
            var_1e2ch = 0x6573;
            var_1e2ah._0_2_ = 0;
            _var_1e18h = ZEXT816(0);
            var_1e08h = 0;
            var_1e00h = 0;
            *(undefined8 *)((int64_t)&piStackX_18 + iVar1) = 0x1f;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001caa1;
            puVar2 = (undefined4 *)fcn.180004930(&var_1e18h, (int64_t)&piStackX_18 + iVar1);
            var_1e18h = (int64_t)puVar2;
            var_1e08h = 0x15;
            var_1e00h = *(int64_t *)((int64_t)&piStackX_18 + iVar1);
            *puVar2 = 0x6d6f7250;
            puVar2[1] = 0x72507470;
            puVar2[2] = 0x6375646f;
            puVar2[3] = 0x72755074;
            *(undefined8 *)((int64_t)puVar2 + 0xd) = 0x6573616863727550;
            *(undefined *)((int64_t)puVar2 + 0x15) = 0;
            _var_1df8h = ZEXT816(0);
            var_1de8h = 0;
            var_1de0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cb0a;
            fcn.180004830(&var_1df8h, 0x1806207a8, 0x16);
            _var_1dd8h = ZEXT816(0);
            var_1dc8h = 0;
            var_1dc0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cb3c;
            fcn.180004830(&var_1dd8h, 0x1806207c0, 0x14);
            _var_1db8h = ZEXT816(0);
            var_1da8h = 0;
            var_1da0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cb6e;
            fcn.180004830(&var_1db8h, 0x1806207d8, 0x12);
            _var_1d98h = ZEXT816(0);
            var_1d88h = 0;
            var_1d80h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cba0;
            fcn.180004830(&var_1d98h, 0x1806207f0, 0x14);
            _var_1d78h = ZEXT816(0);
            var_1d68h = 0;
            var_1d60h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cbd2;
            fcn.180004830(&var_1d78h, 0x180620808, 0x18);
            _var_1d58h = ZEXT816(0);
            var_1d48h = 0;
            var_1d40h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cc04;
            fcn.180004830(&var_1d58h, 0x180620828, 0x15);
            _var_1d38h = ZEXT816(0);
            var_1d28h = 0;
            var_1d20h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cc36;
            fcn.180004830(&var_1d38h, 0x180620840, 0x1a);
            _var_1d18h = ZEXT816(0);
            var_1d08h = 0;
            var_1d00h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cc68;
            fcn.180004830(&var_1d18h, 0x180620860, 0x18);
            _var_1cf8h = ZEXT816(0);
            var_1ce8h = 0;
            var_1ce0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cc9a;
            fcn.180004830(&var_1cf8h, 0x180620880, 0x14);
            _var_1cd8h = ZEXT816(0);
            var_1cc8h = 0;
            var_1cc0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cccc;
            fcn.180004830(&var_1cd8h, 0x180620898, 0x23);
            _var_1cb8h = ZEXT816(0);
            var_1ca8h = 0;
            var_1ca0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ccfe;
            fcn.180004830(&var_1cb8h, 0x1806208c0, 0x1a);
            _var_1c98h = ZEXT816(0);
            var_1c88h = 0;
            var_1c80h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cd30;
            fcn.180004830(&var_1c98h, 0x1806208e0, 0x1b);
            _var_1c78h = ZEXT816(0);
            var_1c68h = 0;
            var_1c60h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cd62;
            fcn.180004830(&var_1c78h, 0x180620900, 0x26);
            _var_1c58h = ZEXT816(0);
            var_1c48h = 0;
            var_1c40h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cd94;
            fcn.180004830(&var_1c58h, 0x180620928, 0x27);
            _var_1c38h = ZEXT816(0);
            var_1c28h = 0;
            var_1c20h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cdc6;
            fcn.180004830(&var_1c38h, 0x180620950, 0x1e);
            *(undefined4 *)((int64_t)&piStackX_18 + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cdde;
            fcn.18001f430(&var_27e0h, (int64_t)&piStackX_18 + iVar1, (int64_t)&arg_28h + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cdf6;
            fcn.18001f7a0(*(int64_t *)((int64_t)&piStackX_18 + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ce0a;
            fcn.18000b4d0(&var_978h, &var_2160h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ce1b;
            fcn.18001f4b0(&var_958h, &var_27e0h);
            var_2190h = 0xb;
            var_2188h = 0xf;
            _var_21a0h = ZEXT816(0x7672655374736554);
            stack0xffffffffffffde67 = 0x65636976;
            var_2195h = 0;
            var_21b0h = 3;
            var_21a8h = 0xf;
            stack0xffffffffffffde44 = SUB1612(ZEXT816(0), 4);
            var_21c0h._0_4_ = 0x6e7572;
            *(undefined4 *)((int64_t)&piStackX_18 + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ceb6;
            fcn.18001f430((int64_t)&arg_70h + iVar1, (int64_t)&piStackX_18 + iVar1, (int64_t)&arg_28h + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cecf;
            fcn.18001f7a0(*(int64_t *)((int64_t)&piStackX_18 + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cee3;
            fcn.18000b4d0(&var_918h, &var_21a0h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cef5;
            fcn.18001f4b0(&var_8f8h, (int64_t)&arg_70h + iVar1);
            _var_20b8h = ZEXT816(0);
            var_20a8h = 0;
            var_20a0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001cf27;
            fcn.180004830(&var_20b8h, 0x180620ac0, 0x11);
            stack0xffffffffffffdf78 = 0xc;
            var_2080h = 0xf;
            var_2098h = 0x617373654d746547;
            var_2090h = 0x64496567;
            var_208ch._0_4_ = 0;
            var_2068h = 7;
            var_2060h = 0xf;
            _var_2078h = ZEXT716(0x6873696c627550);
            var_2048h = 4;
            var_2040h = 0xf;
            stack0xffffffffffffdfad = SUB1611(ZEXT816(0), 5);
            var_2058h._0_5_ = 0x6c6c6143;
            var_2028h = 7;
            var_2020h = 0xf;
            _var_2038h = ZEXT716(0x7473614c746547);
            _var_2018h = ZEXT816(0);
            var_2008h = 0;
            var_2000h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d05c;
            fcn.180004830(&var_2018h, 0x1806209c0, 0x21);
            _var_1ff8h = ZEXT816(0);
            var_1fe8h = 0;
            var_1fe0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d08e;
            fcn.180004830(&var_1ff8h, 0x1806209e8, 0x22);
            var_1fc8h = 0xb;
            var_1fc0h = 0xf;
            _var_1fd8h = ZEXT816(0x75716552656b614d);
            stack0xffffffffffffe02f = 0x74736575;
            var_1fcdh = 0;
            _var_1fb8h = ZEXT816(0);
            var_1fa8h = 0;
            var_1fa0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d102;
            fcn.180004830(&var_1fb8h, 0x180620a20, 0x1c);
            _var_1f98h = ZEXT816(0);
            var_1f88h = 0;
            var_1f80h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d134;
            fcn.180004830(&var_1f98h, 0x180620a40, 0x1d);
            var_1f68h = 9;
            var_1f60h = 0xf;
            var_1f70h._0_1_ = 0x65;
            var_1f78h = 0x6269726373627553;
            var_1f70h._1_7_ = 0;
            _var_1f58h = ZEXT816(0);
            var_1f48h = 0;
            var_1f40h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d1a9;
            fcn.180004830(&var_1f58h, 0x180620a70, 0x20);
            _var_1f38h = ZEXT816(0);
            var_1f28h = 0;
            var_1f20h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d1db;
            fcn.180004830(&var_1f38h, 0x180620a98, 0x21);
            *(undefined4 *)((int64_t)&piStackX_18 + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d1f3;
            fcn.18001f430(&var_27a0h, (int64_t)&piStackX_18 + iVar1, (int64_t)&arg_28h + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d20b;
            fcn.18001f7a0(*(int64_t *)((int64_t)&piStackX_18 + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d21f;
            fcn.18000b4d0(&var_8b8h, &var_20b8h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d230;
            fcn.18001f4b0(&var_898h, &var_27a0h);
            stack0xffffffffffffde30 = 0xe;
            var_21c8h = 0xf;
            var_21e0h = 0x53726573776f7242;
            var_21d8h = 0x69767265;
            var_21d4h = 0x6563;
            var_21d2h._0_2_ = 0;
            _var_1b18h = ZEXT816(0);
            var_1b08h = 0;
            var_1b00h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d2af;
            fcn.180004830(&var_1b18h, 0x180620ad8, 0x11);
            _var_1af8h = ZEXT816(0);
            var_1ae8h = 0;
            var_1ae0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d2e1;
            fcn.180004830(&var_1af8h, 0x180620af0, 0x11);
            _var_1ad8h = ZEXT816(0);
            var_1ac8h = 0;
            var_1ac0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d313;
            fcn.180004830(&var_1ad8h, 0x180620b08, 0x11);
            _var_1ab8h = ZEXT816(0);
            var_1aa8h = 0;
            var_1aa0h = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d345;
            fcn.180004830(&var_1ab8h, 0x180620b20, 0x12);
            var_1a88h = 0xb;
            var_1a80h = 0xf;
            _var_1a98h = ZEXT816(0x6d6d6f43646e6553);
            stack0xffffffffffffe56f = 0x646e616d;
            var_1a8dh = 0;
            stack0xffffffffffffe598 = 0xf;
            var_1a60h = 0xf;
            var_1a78h = 0x7262794874696d45;
            var_1a70h = 0x76456469;
            var_1a6ch = 0x6e65;
            var_1a6ah = 0x74;
            var_1a69h._0_1_ = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d3f4;
            fcn.1800047e0(&var_1a58h, 0x180620b58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d408;
            fcn.1800047e0(&var_1a38h, 0x180620b70);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d41c;
            fcn.1800047e0(&var_1a18h, 0x180620b80);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1b18h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_19f8h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d446;
            fcn.18001f380(&var_2520h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d461;
            fcn.18001ed50(&var_858h, &var_21e0h, &var_2520h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d475;
            uVar4 = fcn.1800047e0(&var_1798h, 0x180620bb8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d48b;
            fcn.1800047e0(&var_1b78h, 0x180620ba8);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1b78h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1b58h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d4b5;
            fcn.18001f380(&var_2320h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d4cc;
            fcn.18001ed50(&var_7f8h, uVar4, &var_2320h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d4e0;
            uVar4 = fcn.1800047e0(&var_1778h, 0x180620bf8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d4f6;
            fcn.1800047e0(&var_19f8h, 0x180620bc8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d50a;
            fcn.1800047e0(&var_19d8h, 0x180620be0);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_19f8h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_19b8h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d534;
            fcn.18001f380(&var_2560h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d54b;
            fcn.18001ed50(&var_798h, uVar4, &var_2560h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d55f;
            uVar4 = fcn.1800047e0(&var_1758h, 0x180620c08);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d575;
            fcn.1800047e0(&var_1b58h, 0x180620be0);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1b58h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1b38h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d59f;
            fcn.18001f380(&var_25a0h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d5b6;
            fcn.18001ed50(&var_738h, uVar4, &var_25a0h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d5ca;
            uVar4 = fcn.1800047e0(&var_1738h, 0x18061fe68);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d5e0;
            fcn.1800047e0(&var_1978h, 0x180620c20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d5f4;
            fcn.1800047e0(&var_1958h, 0x180620c30);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1978h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1938h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d61e;
            fcn.18001f380(&var_24e0h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d635;
            fcn.18001ed50(&var_6d8h, uVar4, &var_24e0h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d649;
            uVar4 = fcn.1800047e0(&var_1718h, 0x180620c60);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d65f;
            fcn.1800047e0(&var_1418h, 0x180620c40);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d673;
            fcn.1800047e0(&var_13f8h, 0x180620c50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d687;
            fcn.1800047e0(&var_13d8h, 0x180620678);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d69b;
            fcn.1800047e0(&var_13b8h, 0x180620690);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1418h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1398h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d6c5;
            fcn.18001f380(&var_24a0h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d6dc;
            fcn.18001ed50(&var_678h, uVar4, &var_24a0h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d6f0;
            uVar4 = fcn.1800047e0(&var_16f8h, 0x180620c68);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d706;
            fcn.1800047e0(&var_1b38h, 0x180620c40);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1b38h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1b18h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d730;
            fcn.18001f380(&var_2460h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d747;
            fcn.18001ed50(&var_618h, uVar4, &var_2460h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d75b;
            uVar4 = fcn.1800047e0(&var_1918h, 0x180620cb0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d771;
            fcn.1800047e0(&var_1498h, 0x180620ad8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d785;
            fcn.1800047e0(&var_1478h, 0x180620af0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d799;
            fcn.1800047e0(&var_1458h, 0x180620c78);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d7ad;
            fcn.1800047e0(&var_1438h, 0x180620c90);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1498h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1418h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d7d7;
            fcn.18001f380(&var_2420h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d7ee;
            fcn.18001ed50(&var_5b8h, uVar4, &var_2420h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d802;
            uVar4 = fcn.1800047e0(&var_16d8h, 0x180620d98);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d818;
            fcn.1800047e0(&var_12b8h, 0x180620cc0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d82c;
            fcn.1800047e0(&var_1298h, 0x180620cc8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d840;
            fcn.1800047e0(&var_1278h, 0x180620cd8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d854;
            fcn.1800047e0(&var_1258h, 0x180620ce8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d868;
            fcn.1800047e0(&var_1238h, 0x180620d00);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d87c;
            fcn.1800047e0(&var_1218h, 0x180620d18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d890;
            fcn.1800047e0(&var_11f8h, 0x180620d30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d8a4;
            fcn.1800047e0(&var_11d8h, 0x180620d50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d8b8;
            fcn.1800047e0(&var_11b8h, 0x180620d60);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d8cc;
            fcn.1800047e0(&var_1198h, 0x180620d80);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d8e0;
            fcn.1800047e0(&var_1178h, 0x180620d90);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_12b8h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1158h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d90a;
            fcn.18001f380(&var_23e0h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d921;
            fcn.18001ed50(&var_558h, uVar4, &var_23e0h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d935;
            uVar4 = fcn.1800047e0(&var_16b8h, 0x180620de8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d94b;
            fcn.1800047e0(&var_1518h, 0x180620da8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d95f;
            fcn.1800047e0(&var_14f8h, 0x180620db8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d973;
            fcn.1800047e0(&var_14d8h, 0x180620dc8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d987;
            fcn.1800047e0(&var_14b8h, 0x180620dd8);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1518h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1498h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d9b1;
            fcn.18001f380(&var_23a0h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d9c8;
            fcn.18001ed50(&var_4f8h, uVar4, &var_23a0h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d9dc;
            uVar4 = fcn.1800047e0(&var_1938h, 0x180620e38);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001d9f2;
            fcn.1800047e0(&var_1398h, 0x180620da8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001da06;
            fcn.1800047e0(&var_1378h, 0x180620dd8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001da1a;
            fcn.1800047e0(&var_1358h, 0x180620df8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001da2e;
            fcn.1800047e0(&var_1338h, 0x180620dc8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001da42;
            fcn.1800047e0(&var_1318h, 0x180620e10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001da56;
            fcn.1800047e0(&var_12f8h, 0x180620db8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001da6a;
            fcn.1800047e0(&var_12d8h, 0x180620e20);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1398h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_12b8h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001da94;
            fcn.18001f380(&var_2360h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001daab;
            fcn.18001ed50(&var_498h, uVar4, &var_2360h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dabf;
            uVar4 = fcn.1800047e0(&var_18f8h, 0x180620ea0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dad5;
            fcn.1800047e0(&var_1598h, 0x180620e50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dae9;
            fcn.1800047e0(&var_1578h, 0x180620e68);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dafd;
            fcn.1800047e0(&var_1558h, 0x180620e78);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001db11;
            fcn.1800047e0(&var_1538h, 0x180620e88);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1598h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1518h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001db3b;
            fcn.18001f380(&var_26a0h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001db52;
            fcn.18001ed50(&var_438h, uVar4, &var_26a0h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001db66;
            uVar4 = fcn.1800047e0(&var_18d8h, 0x180620eb8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001db7c;
            fcn.1800047e0(&var_1b98h, 0x180620a10);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1b98h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1b78h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dba6;
            fcn.18001f380(&var_22e0h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dbbd;
            fcn.18001ed50(&var_3d8h, uVar4, &var_22e0h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dbd1;
            uVar4 = fcn.1800047e0(&var_18b8h, 0x180621198);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dbe7;
            fcn.1800047e0(&var_1158h, 0x180620ed8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dbfb;
            fcn.1800047e0(&var_1138h, 0x180620ef0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dc0f;
            fcn.1800047e0(&var_1118h, 0x180620f00);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dc23;
            fcn.1800047e0(&var_10f8h, 0x180620f10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dc37;
            fcn.1800047e0(&var_10d8h, 0x180620f28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dc4b;
            fcn.1800047e0(&var_10b8h, 0x180620f40);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dc5f;
            fcn.1800047e0(&var_1098h, 0x180620f58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dc73;
            fcn.1800047e0(&var_1078h, 0x180620f78);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dc87;
            fcn.1800047e0(&var_1058h, 0x180620f90);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dc9b;
            fcn.1800047e0(&var_1038h, 0x180620fb0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dcaf;
            fcn.1800047e0(&var_1018h, 0x180620fc8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dcc3;
            fcn.1800047e0(&var_ff8h, 0x180620fd8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dcd7;
            fcn.1800047e0(&var_fd8h, 0x180620fe8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dceb;
            fcn.1800047e0(&var_fb8h, 0x180620ff8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dcff;
            fcn.1800047e0(&var_f98h, 0x180621010);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dd13;
            fcn.1800047e0(&var_f78h, 0x180621028);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dd27;
            fcn.1800047e0(&var_f58h, 0x180621040);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dd3b;
            fcn.1800047e0(&var_f38h, 0x180621060);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dd4f;
            fcn.1800047e0(&var_f18h, 0x180621078);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dd63;
            fcn.1800047e0(&var_ef8h, 0x180621090);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dd77;
            fcn.1800047e0(&var_ed8h, 0x1806210b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dd8b;
            fcn.1800047e0(&var_eb8h, 0x1806210d8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dd9f;
            fcn.1800047e0(&var_e98h, 0x1806210f0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ddb3;
            fcn.1800047e0(&var_e78h, 0x180621118);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ddc7;
            fcn.1800047e0(&var_e58h, 0x180621130);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dddb;
            fcn.1800047e0(&var_e38h, 0x180621150);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ddef;
            fcn.1800047e0(&var_e18h, 0x180621168);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001de03;
            fcn.1800047e0(&var_df8h, 0x180621188);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1158h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_dd8h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001de2d;
            fcn.18001f380(&var_22a0h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001de44;
            fcn.18001ed50(&var_378h, uVar4, &var_22a0h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001de58;
            uVar4 = fcn.1800047e0(&var_1898h, 0x180621210);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001de6e;
            fcn.1800047e0(&var_1618h, 0x1806211a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001de82;
            fcn.1800047e0(&var_15f8h, 0x1806211c0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001de96;
            fcn.1800047e0(&var_15d8h, 0x1806211d8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001deaa;
            fcn.1800047e0(&var_15b8h, 0x1806211f0);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1618h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1598h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ded4;
            fcn.18001f380(&var_2260h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001deeb;
            fcn.18001ed50(&var_318h, uVar4, &var_2260h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001deff;
            uVar4 = fcn.1800047e0(&var_1878h, 0x1806215e8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001df15;
            fcn.1800047e0(&var_dd8h, 0x180621220);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001df29;
            fcn.1800047e0(&var_db8h, 0x180621238);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001df3d;
            fcn.1800047e0(&var_d98h, 0x180621250);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001df51;
            fcn.1800047e0(&var_d78h, 0x180621268);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001df65;
            fcn.1800047e0(&var_d58h, 0x180621280);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001df79;
            fcn.1800047e0(&var_d38h, 0x1806212b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001df8d;
            fcn.1800047e0(&var_d18h, 0x1806212c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dfa1;
            fcn.1800047e0(&var_cf8h, 0x1806212e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dfb5;
            fcn.1800047e0(&var_cd8h, 0x180621308);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dfc9;
            fcn.1800047e0(&var_cb8h, 0x180621320);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dfdd;
            fcn.1800047e0(&var_c98h, 0x180621338);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001dff1;
            fcn.1800047e0(&var_c78h, 0x180621360);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e005;
            fcn.1800047e0(&var_c58h, 0x180621378);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e019;
            fcn.1800047e0(&var_c38h, 0x180621390);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e02d;
            fcn.1800047e0(&var_c18h, 0x1806213a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e041;
            fcn.1800047e0(&var_bf8h, 0x1806213c0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e055;
            fcn.1800047e0(&var_bd8h, 0x1806213d8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e069;
            fcn.1800047e0(&var_bb8h, 0x1806213f0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e07d;
            fcn.1800047e0(&var_b98h, 0x180621408);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e091;
            fcn.1800047e0(&var_b78h, 0x180621420);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e0a5;
            fcn.1800047e0(&var_b58h, 0x180621440);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e0b9;
            fcn.1800047e0(&var_b38h, 0x180621460);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e0cd;
            fcn.1800047e0(&var_b18h, 0x180621480);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e0e1;
            fcn.1800047e0(&var_af8h, 0x1806214a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e0f5;
            fcn.1800047e0(&var_ad8h, 0x1806214c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e109;
            fcn.1800047e0(&var_ab8h, 0x1806214f0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e11d;
            fcn.1800047e0(&var_a98h, 0x180621510);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e131;
            fcn.1800047e0(&var_a78h, 0x180621538);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e145;
            fcn.1800047e0(&var_a58h, 0x180621560);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e159;
            fcn.1800047e0(&var_a38h, 0x180621578);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e16d;
            fcn.1800047e0(&var_a18h, 0x1806215a0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e181;
            fcn.1800047e0(&var_9f8h, 0x1806215c0);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_dd8h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_9d8h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e1ab;
            fcn.18001f380(&var_26e0h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e1c2;
            fcn.18001ed50(&var_2b8h, uVar4, &var_26e0h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e1d6;
            uVar4 = fcn.1800047e0(&var_1858h, 0x180621618);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e1ec;
            fcn.1800047e0(&var_1bb8h, 0x180621600);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1bb8h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1b98h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e216;
            fcn.18001f380(&var_2220h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e22d;
            fcn.18001ed50(&var_258h, uVar4, &var_2220h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e241;
            uVar4 = fcn.1800047e0(&var_1838h, 0x180621638);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e257;
            fcn.1800047e0(&var_1bd8h, 0x180621628);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1bd8h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1bb8h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e27e;
            fcn.18001f380(&var_2760h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e292;
            fcn.18001ed50(&var_1f8h, uVar4, &var_2760h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e2a6;
            uVar4 = fcn.1800047e0(&var_1818h, 0x180621680);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e2bc;
            fcn.1800047e0(&var_19b8h, 0x180621648);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e2d0;
            fcn.1800047e0(&var_1998h, 0x180621660);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_19b8h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1978h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e2f7;
            fcn.18001f380(&var_2720h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e30b;
            fcn.18001ed50(&var_198h, uVar4, &var_2720h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e31f;
            uVar4 = fcn.1800047e0(&var_17f8h, 0x1806216b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e335;
            fcn.1800047e0(&var_1bf8h, 0x180621698);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1bf8h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1bd8h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e35f;
            fcn.18001f380(&var_2660h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e376;
            fcn.18001ed50(&var_138h, uVar4, &var_2660h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e38a;
            uVar4 = fcn.1800047e0(&var_17d8h, 0x180621720);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e3a0;
            fcn.1800047e0(&var_1698h, 0x1806216c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e3b4;
            fcn.1800047e0(&var_1678h, 0x1806216e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e3c8;
            fcn.1800047e0(&var_1658h, 0x1806216f8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e3dc;
            fcn.1800047e0(&var_1638h, 0x180621708);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1698h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1618h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e406;
            fcn.18001f380(&var_2620h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e41d;
            fcn.18001ed50(&var_d8h, uVar4, &var_2620h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e431;
            uVar4 = fcn.1800047e0(&var_17b8h, 0x180621748);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e447;
            fcn.1800047e0(&var_1c18h, 0x180621738);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_1c18h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_1bf8h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e471;
            fcn.18001f380(&var_25e0h, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e488;
            uVar5 = fcn.18001ed50(&var_78h, uVar4, &var_25e0h);
            *(int64_t **)((int64_t)&piStackX_18 + iVar1) = &var_9d8h;
            *(int64_t **)((int64_t)&var_20h + iVar1) = &var_18h;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e4ab;
            fcn.18001f2c0(uVar5, (int64_t)&piStackX_18 + iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e4ca;
            fcn.180459d94(&var_9d8h, 0x60, 0x1a, 0x18001eac0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e4d7;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e4f6;
            fcn.180459d94(&var_1c18h, 0x20, 1, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e503;
            fcn.180004e40(&var_17b8h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e510;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e52f;
            fcn.180459d94(&var_1698h, 0x20, 4, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e53c;
            fcn.180004e40(&var_17d8h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e549;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e568;
            fcn.180459d94(&var_1bf8h, 0x20, 1, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e575;
            fcn.180004e40(&var_17f8h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e57f;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e59e;
            fcn.180459d94(&var_19b8h, 0x20, 2, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e5ab;
            fcn.180004e40(&var_1818h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e5b5;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e5d4;
            fcn.180459d94(&var_1bd8h, 0x20, 1, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e5e1;
            fcn.180004e40(&var_1838h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e5ee;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e60d;
            fcn.180459d94(&var_1bb8h, 0x20, 1, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e61a;
            fcn.180004e40(&var_1858h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e627;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e643;
            fcn.180459d94(&var_dd8h, 0x20, 0x20, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e650;
            fcn.180004e40(&var_1878h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e65d;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e67c;
            fcn.180459d94(&var_1618h, 0x20, 4, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e689;
            fcn.180004e40(&var_1898h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e696;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e6b5;
            fcn.180459d94(&var_1158h, 0x20, 0x1c, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e6c2;
            fcn.180004e40(&var_18b8h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e6cf;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e6ee;
            fcn.180459d94(&var_1b98h, 0x20, 1, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e6fb;
            fcn.180004e40(&var_18d8h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e708;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e727;
            fcn.180459d94(&var_1598h, 0x20, 4, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e734;
            fcn.180004e40(&var_18f8h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e741;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e760;
            fcn.180459d94(&var_1398h, 0x20, 7, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e76d;
            fcn.180004e40(&var_1938h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e77a;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e799;
            fcn.180459d94(&var_1518h, 0x20, 4, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e7a6;
            fcn.180004e40(&var_16b8h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e7b3;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e7d2;
            fcn.180459d94(&var_12b8h, 0x20, 0xb, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e7df;
            fcn.180004e40(&var_16d8h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e7ec;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e80b;
            fcn.180459d94(&var_1498h, 0x20, 4, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e818;
            fcn.180004e40(&var_1918h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e825;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e844;
            fcn.180459d94(&var_1b38h, 0x20, 1, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e851;
            fcn.180004e40(&var_16f8h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e85e;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e87d;
            fcn.180459d94(&var_1418h, 0x20, 4, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e88a;
            fcn.180004e40(&var_1718h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e897;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e8b6;
            fcn.180459d94(&var_1978h, 0x20, 2, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e8c3;
            fcn.180004e40(&var_1738h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e8d0;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e8ef;
            fcn.180459d94(&var_1b58h, 0x20, 1, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e8fc;
            fcn.180004e40(&var_1758h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e909;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e928;
            fcn.180459d94(&var_19f8h, 0x20, 2, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e935;
            fcn.180004e40(&var_1778h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e942;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e961;
            fcn.180459d94(&var_1b78h, 0x20, 1, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e96e;
            fcn.180004e40(&var_1798h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e97b;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e99a;
            fcn.180459d94(&var_1b18h, 0x20, 9, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e9a7;
            fcn.180004e40(&var_21e0h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e9b1;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e9d0;
            fcn.180459d94(&var_2098h, 0x20, 0xc, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e9dd;
            fcn.180004e40(&var_20b8h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001e9e8;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ea07;
            fcn.180459d94(&var_21c0h, 0x20, 1, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ea14;
            fcn.180004e40(&var_21a0h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ea1e;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ea3d;
            fcn.180459d94(&var_1f18h, 0x20, 0x18, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ea4a;
            fcn.180004e40(&var_2160h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ea55;
            fcn.18001eaa0(*(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ea74;
            fcn.180459d94(&var_2138h, 0x20, 4, 0x180004dd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ea81;
            fcn.180004e40(&var_2180h);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ea8d;
            fcn.180459c24(0x1804a2290);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001ea9a;
            fcn.180459cac(0x180782800);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18001c505;
    fcn.180459870(var_18h ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18001eaa0
// Address: 0x18001eaa0
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001eaa0(int64_t arg1, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    func_0x00018000ace0(arg1 + 0x18);
    puVar1 = *(undefined8 **)(int64_t *)(arg1 + 8);
    *(undefined8 *)puVar1[1] = 0;
    puVar1 = (undefined8 *)*puVar1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar2 = (undefined8 *)*puVar1;
        fcn.180004e40(puVar1 + 2);
        fcn.180459c3c(puVar1, 0x30);
        puVar1 = puVar2;
    }
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((iVar3 != 0) &&
       (iVar4 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar3, in_R9, unaff_RBX), iVar4 == 0)) {
        uVar5 = (*(code *)0x699ff6)();
        uVar5 = fcn.18046b63c(uVar5);
        puVar6 = (undefined4 *)fcn.18046b77c();
        *puVar6 = uVar5;
    }
    return;
}

// ============================================================
// Function: FUN_18001eac0
// Address: 0x18001eac0
// Size: 40 bytes
// ============================================================
void fcn.18001eac0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    func_0x00018000ace0(arg1 + 0x38);
    func_0x00018001f220(arg1 + 0x28);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar1 = *(int64_t *)arg1;
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x18) + 1) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180004e88;
        fcn.180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    return;
}

// ============================================================
// Function: FUN_18001eaf0
// Address: 0x18001eaf0
// Size: 46 bytes
// ============================================================
void fcn.18001eaf0(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    func_0x00018000ace0(arg1 + 0x18);
    func_0x00018001fa20();
    if ((*(int64_t *)(arg1 + 8) != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)(arg1 + 8), in_R9, unaff_RBX), iVar2 == 0
       )) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18001eb20
// Address: 0x18001eb20
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.18001eb20(int64_t arg1)
{
    bool bVar1;
    int64_t iVar2;
    char in_DL;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    fcn.180013530();
    bVar1 = (bool)(~(*(uint8_t *)(arg1 + 1) >> 6) & 1);
    if (in_DL != '\0') {
        var_10h._0_4_ = 3;
        var_8h = 0;
        iVar2 = (**(code **)0x180782570)(*(undefined8 *)(*(int64_t *)(arg1 + 0x50) + 0x98), &var_10h, &var_8h);
        bVar1 = *(int64_t *)(arg1 + 0x20) == *(int64_t *)(iVar2 + 0x20);
    }
    return bVar1;
}

// ============================================================
// Function: FUN_18001eb90
// Address: 0x18001eb90
// Size: 103 bytes
// ============================================================
void fcn.18001eb90(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    char cVar2;
    code **ppcVar3;
    int64_t var_8h;
    
    var_8h = arg1;
    ppcVar3 = (code **)fcn.18001eda0(arg1, &var_8h);
    pcVar1 = *ppcVar3;
    cVar2 = fcn.18001eb20(arg3);
    if (cVar2 != '\0') {
        (*pcVar1)(var_8h, arg2, arg3, arg4 & 0xffffffff);
        return;
    }
    fcn.180088560(arg3, 0x180621760);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_18001ec00
// Address: 0x18001ec00
// Size: 326 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h

void fcn.18001ec00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined auVar6 [16];
    char cVar7;
    int32_t iVar8;
    code **ppcVar9;
    int64_t iVar10;
    int64_t *piVar11;
    bool bVar12;
    int64_t var_8h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    var_8h = arg1;
    ppcVar9 = (code **)fcn.18001eda0(arg1, &var_8h);
    iVar4 = *(int64_t *)(arg4 + 8);
    if ((iVar4 != 0) && (*(int32_t *)(iVar4 + 8) != 0)) {
        pcVar5 = *ppcVar9;
        var_40h = 0;
        iVar3 = *(int32_t *)(iVar4 + 8);
        do {
            piVar11 = (int64_t *)var_40h;
            auVar6 = ZEXT816(0);
            if (iVar3 == 0) goto code_r0x00018001ec78;
            LOCK();
            iVar8 = *(int32_t *)(iVar4 + 8);
            bVar12 = iVar3 == iVar8;
            if (bVar12) {
                *(int32_t *)(iVar4 + 8) = iVar3 + 1;
                iVar8 = iVar3;
            }
            UNLOCK();
            iVar3 = iVar8;
        } while (!bVar12);
        piVar11 = *(int64_t **)(arg4 + 8);
        auVar6 = *(undefined (*) [16])arg4;
code_r0x00018001ec78:
        _var_48h = auVar6;
        iVar4 = *(int64_t *)(var_48h + 0x28);
        cVar7 = fcn.18001eb20(iVar4);
        if (cVar7 == '\0') {
            iVar10 = func_0x00018001ed90(&var_48h);
            *(undefined4 *)(iVar10 + 0x30) = 0;
            fcn.180088560(iVar4, 0x180621760);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        (*pcVar5)(var_8h, arg2, arg3, arg4, arg_28h, arg_30h);
        if (piVar11 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar11 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar11)(piVar11);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar11 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar11 + 8))(piVar11);
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001ed50
// Address: 0x18001ed50
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18001ed50(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int64_t var_8h;
    int64_t var_10h;
    
    fcn.18000b4d0();
    fcn.18001f4b0(arg1 + 0x20, arg3);
    return arg1;
}

// ============================================================
// Function: FUN_18001eda0
// Address: 0x18001eda0
// Size: 1152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h

int64_t ** fcn.18001eda0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    code *pcVar8;
    uint64_t uVar9;
    int64_t **ppiVar10;
    uint64_t uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t **ppiVar15;
    undefined8 in_R8;
    undefined8 in_R9;
    float fVar16;
    float fVar17;
    int64_t var_48h;
    int64_t var_40h;
    
    uVar14 = (((((((((uint64_t)*(uint8_t *)arg2 ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 1)
                   ) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 2)) * 0x100000001b3 ^
                 (uint64_t)*(uint8_t *)(arg2 + 3)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 4)) * 0x100000001b3 ^
               (uint64_t)*(uint8_t *)(arg2 + 5)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 6)) * 0x100000001b3 ^
             (uint64_t)*(uint8_t *)(arg2 + 7)) * 0x100000001b3;
    ppiVar10 = *(int64_t ***)(*(int64_t *)0x180782058 + 8 + (uVar14 & *(uint64_t *)0x180782070) * 0x10);
    ppiVar15 = *(int64_t ***)0x180782048;
    if (ppiVar10 != *(int64_t ***)0x180782048) {
        piVar1 = ppiVar10[2];
        ppiVar15 = ppiVar10;
        while (ppiVar10 = ppiVar15, *(int64_t **)arg2 != piVar1) {
            if (ppiVar15 == *(int64_t ***)(*(int64_t *)0x180782058 + (uVar14 & *(uint64_t *)0x180782070) * 0x10))
            goto code_r0x00018001ee6e;
            ppiVar15 = (int64_t **)ppiVar15[1];
            piVar1 = ppiVar15[2];
        }
        goto code_r0x00018001f1f5;
    }
code_r0x00018001ee6e:
    if (*(int64_t *)0x180782050 == 0x7ffffffffffffff) {
code_r0x00018001f213:
        fcn.1804546d4(0x180620428);
        pcVar8 = (code *)swi(3);
        ppiVar10 = (int64_t **)(*pcVar8)();
        return ppiVar10;
    }
    ppiVar10 = (int64_t **)fcn.180459890(0x20, *(int64_t *)0x180782058, in_R8, in_R9, 0x180782048, 0);
    ppiVar10[2] = *(int64_t **)arg2;
    ppiVar10[3] = (int64_t *)0x0;
    uVar9 = *(uint64_t *)0x180782078;
    uVar11 = *(int64_t *)0x180782050 + 1;
    if ((int64_t)uVar11 < 0) {
        fVar16 = (float)(uVar11 >> 1 | (uint64_t)((uint32_t)uVar11 & 1));
        fVar16 = fVar16 + fVar16;
    } else {
        fVar16 = (float)uVar11;
    }
    if ((int64_t)*(uint64_t *)0x180782078 < 0) {
        fVar17 = (float)(*(uint64_t *)0x180782078 >> 1 | (uint64_t)((uint32_t)*(uint64_t *)0x180782078 & 1));
        fVar17 = fVar17 + fVar17;
    } else {
        fVar17 = (float)*(uint64_t *)0x180782078;
    }
    if (*(float *)0x180782040 < fVar16 / fVar17) {
        fVar16 = (float)func_0x000180471c90(fVar16 / *(float *)0x180782040);
        ppiVar15 = *(int64_t ***)0x180782048;
        iVar12 = 0;
        if ((9.223372e+18 <= fVar16) && (fVar16 = fVar16 - 9.223372e+18, fVar16 < 9.223372e+18)) {
            iVar12 = -0x8000000000000000;
        }
        uVar11 = 8;
        if (8 < (uint64_t)((int64_t)fVar16 + iVar12)) {
            uVar11 = (int64_t)fVar16 + iVar12;
        }
        uVar13 = uVar9;
        if ((uVar9 < uVar11) && ((0x1ff < uVar9 || (uVar13 = uVar9 * 8, uVar9 * 8 < uVar11)))) {
            uVar13 = uVar11;
        }
        for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
        if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar13) {
            fcn.1804546d4(0x180620448);
            goto code_r0x00018001f213;
        }
        uVar11 = uVar13 - 1 | 1;
        iVar12 = 0x3f;
        if (uVar11 != 0) {
            for (; uVar11 >> iVar12 == 0; iVar12 = iVar12 + -1) {
            }
        }
        uVar11 = 1LL << ((char)iVar12 + 1U & 0x3f);
        fcn.18000f7e0(0x180782058, uVar11 * 2, *(int64_t ***)0x180782048);
        *(uint64_t *)0x180782070 = uVar11 - 1;
        *(uint64_t *)0x180782078 = uVar11;
        ppiVar7 = (int64_t **)**(int64_t ***)0x180782048;
        iVar12 = *(int64_t *)0x180782058;
joined_r0x00018001effd:
        *(int64_t *)0x180782058 = iVar12;
        if (ppiVar7 != ppiVar15) {
            ppiVar2 = (int64_t **)*ppiVar7;
            uVar11 = (((((((((uint64_t)*(uint8_t *)(ppiVar7 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x11)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x12)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x13)) * 0x100000001b3 ^
                        (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x14)) * 0x100000001b3 ^
                       (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x15)) * 0x100000001b3 ^
                      (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x16)) * 0x100000001b3 ^
                     (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x17)) * 0x100000001b3 & *(uint64_t *)0x180782070;
            ppiVar3 = *(int64_t ***)(iVar12 + uVar11 * 0x10);
            if (ppiVar3 == ppiVar15) {
                *(int64_t ***)(iVar12 + uVar11 * 0x10) = ppiVar7;
                *(int64_t ***)(iVar12 + 8 + uVar11 * 0x10) = ppiVar7;
                ppiVar7 = ppiVar2;
                iVar12 = *(int64_t *)0x180782058;
            } else {
                ppiVar4 = *(int64_t ***)(iVar12 + 8 + uVar11 * 0x10);
                if (ppiVar7[2] == ppiVar4[2]) {
                    ppiVar4 = (int64_t **)*ppiVar4;
                    if (ppiVar4 != ppiVar7) {
                        ppiVar3 = (int64_t **)ppiVar7[1];
                        *ppiVar3 = (int64_t *)ppiVar2;
                        ppiVar5 = (int64_t **)ppiVar2[1];
                        *ppiVar5 = (int64_t *)ppiVar4;
                        ppiVar6 = (int64_t **)ppiVar4[1];
                        *ppiVar6 = (int64_t *)ppiVar7;
                        ppiVar4[1] = (int64_t *)ppiVar5;
                        ppiVar2[1] = (int64_t *)ppiVar3;
                        ppiVar7[1] = (int64_t *)ppiVar6;
                    }
                    *(int64_t ***)(iVar12 + 8 + uVar11 * 0x10) = ppiVar7;
                    ppiVar7 = ppiVar2;
                    iVar12 = *(int64_t *)0x180782058;
                } else {
                    do {
                        if (ppiVar3 == ppiVar4) {
                            ppiVar3 = (int64_t **)ppiVar7[1];
                            *ppiVar3 = (int64_t *)ppiVar2;
                            piVar1 = ppiVar2[1];
                            *piVar1 = (int64_t)ppiVar4;
                            ppiVar5 = (int64_t **)ppiVar4[1];
                            *ppiVar5 = (int64_t *)ppiVar7;
                            ppiVar4[1] = piVar1;
                            ppiVar2[1] = (int64_t *)ppiVar3;
                            ppiVar7[1] = (int64_t *)ppiVar5;
                            *(int64_t ***)(iVar12 + uVar11 * 0x10) = ppiVar7;
                            ppiVar7 = ppiVar2;
                            iVar12 = *(int64_t *)0x180782058;
                            goto joined_r0x00018001effd;
                        }
                        ppiVar4 = (int64_t **)ppiVar4[1];
                    } while (ppiVar7[2] != ppiVar4[2]);
                    iVar12 = (int64_t)*ppiVar4;
                    ppiVar3 = (int64_t **)ppiVar7[1];
                    *ppiVar3 = (int64_t *)ppiVar2;
                    piVar1 = ppiVar2[1];
                    *piVar1 = iVar12;
                    ppiVar4 = *(int64_t ***)(iVar12 + 8);
                    *ppiVar4 = (int64_t *)ppiVar7;
                    *(int64_t **)(iVar12 + 8) = piVar1;
                    ppiVar2[1] = (int64_t *)ppiVar3;
                    ppiVar7[1] = (int64_t *)ppiVar4;
                    ppiVar7 = ppiVar2;
                    iVar12 = *(int64_t *)0x180782058;
                }
            }
            goto joined_r0x00018001effd;
        }
        ppiVar7 = *(int64_t ***)(iVar12 + 8 + (*(uint64_t *)0x180782070 & uVar14) * 0x10);
        ppiVar15 = *(int64_t ***)0x180782048;
        if (ppiVar7 != *(int64_t ***)0x180782048) {
            piVar1 = ppiVar7[2];
            ppiVar15 = ppiVar7;
            while (ppiVar10[2] != piVar1) {
                if (ppiVar15 == *(int64_t ***)(iVar12 + (*(uint64_t *)0x180782070 & uVar14) * 0x10))
                goto code_r0x00018001f16d;
                ppiVar15 = (int64_t **)ppiVar15[1];
                piVar1 = ppiVar15[2];
            }
            ppiVar15 = (int64_t **)*ppiVar15;
        }
    }
code_r0x00018001f16d:
    piVar1 = ppiVar15[1];
    *(int64_t *)0x180782050 = *(int64_t *)0x180782050 + 1;
    *ppiVar10 = (int64_t *)ppiVar15;
    ppiVar10[1] = piVar1;
    *piVar1 = (int64_t)ppiVar10;
    ppiVar15[1] = (int64_t *)ppiVar10;
    iVar12 = *(int64_t *)0x180782058;
    uVar14 = *(uint64_t *)0x180782070 & uVar14;
    ppiVar7 = *(int64_t ***)(*(int64_t *)0x180782058 + uVar14 * 0x10);
    if (ppiVar7 == *(int64_t ***)0x180782048) {
        *(int64_t ***)(*(int64_t *)0x180782058 + uVar14 * 0x10) = ppiVar10;
    } else {
        if (ppiVar7 == ppiVar15) {
            *(int64_t ***)(*(int64_t *)0x180782058 + uVar14 * 0x10) = ppiVar10;
            goto code_r0x00018001f1f5;
        }
        if (*(int64_t **)(*(int64_t *)0x180782058 + 8 + uVar14 * 0x10) != piVar1) goto code_r0x00018001f1f5;
    }
    *(int64_t ***)(iVar12 + 8 + uVar14 * 0x10) = ppiVar10;
code_r0x00018001f1f5:
    return ppiVar10 + 3;
}

