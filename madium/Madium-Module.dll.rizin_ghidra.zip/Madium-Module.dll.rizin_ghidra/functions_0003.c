// Chunk 3 - 50 functions

// ============================================================
// Function: FUN_180005e70
// Address: 0x180005e70
// Size: 445 bytes
// ============================================================
void fcn.180005e70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined auVar5 [12];
    undefined auVar6 [16];
    undefined (*pauVar7) [16];
    int64_t iVar8;
    int64_t *piVar9;
    undefined *puVar10;
    int64_t var_20h;
    undefined8 uStack_d0;
    undefined auStack_c8 [8];
    undefined auStack_c0 [24];
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    puVar10 = auStack_c8;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    var_a8h = arg1;
    pauVar7 = (undefined (*) [16])func_0x00018000b4d0(&var_98h, arg3);
    piVar9 = *(int64_t **)(arg2 + 8);
    var_a8h = (int64_t)pauVar7;
    if (*(int64_t *)pauVar7[1] != 0) {
        func_0x00018000d970(pauVar7, 0x1805aadb4, 2);
    }
    (**(code **)(*piVar9 + 0x10))(piVar9, &var_58h, *(undefined4 *)arg2);
    piVar9 = &var_58h;
    if (0xf < (uint64_t)var_40h) {
        piVar9 = (int64_t *)var_58h;
    }
    func_0x00018000d970(pauVar7, piVar9, var_48h);
    if (0xf < (uint64_t)var_40h) {
        iVar8 = var_58h;
        puVar10 = auStack_c8;
        if ((0xfff < var_40h + 1U) &&
           (iVar8 = *(int64_t *)(var_58h + -8), puVar10 = auStack_c8, 0x1f < (var_58h - iVar8) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar8 = (*pcVar1)(5);
            puVar10 = auStack_c0;
        }
        *(undefined8 *)(puVar10 + -8) = 0x180005f41;
        func_0x000180459c3c(iVar8);
    }
    auVar5 = *(undefined (*) [12])*pauVar7;
    auVar6 = *pauVar7;
    var_68h = *(int64_t *)pauVar7[1];
    var_60h = *(int64_t *)(pauVar7[1] + 8);
    *(undefined8 *)(pauVar7[1] + 8) = 0xf;
    (*pauVar7)[0] = 0;
    *(undefined8 *)pauVar7[1] = 0;
    *(undefined8 *)(pauVar7[1] + 8) = 0xf;
    (*pauVar7)[0] = 0;
    var_78h = (int64_t)&var_78h;
    if (0xf < (uint64_t)var_60h) {
        var_78h = auVar5._0_8_;
    }
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    var_a0h._0_1_ = 1;
    *(undefined8 *)(puVar10 + -8) = 0x180005fac;
    var_a8h = var_78h;
    _var_78h = auVar6;
    func_0x00018045b4e4(&var_a8h);
    *(undefined8 *)arg1 = 0x1804a53a0;
    if (0xf < (uint64_t)var_60h) {
        iVar8 = var_78h;
        if ((0xfff < var_60h + 1U) && (iVar8 = *(int64_t *)(var_78h + -8), 0x1f < (var_78h - iVar8) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar8 = (*pcVar1)(5);
            puVar10 = puVar10 + 8;
        }
        *(undefined8 *)(puVar10 + -8) = 0x180005ff6;
        func_0x000180459c3c(iVar8);
    }
    *(undefined8 *)arg1 = 0x1804a53b8;
    uVar2 = *(undefined4 *)(arg2 + 4);
    uVar3 = *(undefined4 *)(arg2 + 8);
    uVar4 = *(undefined4 *)(arg2 + 0xc);
    *(undefined4 *)(arg1 + 0x18) = *(undefined4 *)arg2;
    *(undefined4 *)(arg1 + 0x1c) = uVar2;
    *(undefined4 *)(arg1 + 0x20) = uVar3;
    *(undefined4 *)(arg1 + 0x24) = uVar4;
    *(undefined8 *)(puVar10 + -8) = 0x180006016;
    func_0x000180459870(var_38h ^ (uint64_t)puVar10);
    return;
}

// ============================================================
// Function: FUN_180006030
// Address: 0x180006030
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180006030(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a5358;
    fcn.18045b56c(arg1 + 8);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180006080
// Address: 0x180006080
// Size: 246 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180006080(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int64_t *piVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined *puVar6;
    int64_t var_18h;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar6 = auStack_78;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    piVar3 = *(int64_t **)(arg2 + 8);
    uVar1 = *(undefined4 *)arg2;
    uVar2 = *(undefined4 *)(arg2 + 4);
    var_58h = arg1;
    (**(code **)(*piVar3 + 0x10))(piVar3, &var_48h, uVar1);
    *(undefined8 *)arg1 = 0x1804a5358;
    var_50h._0_1_ = 1;
    var_58h = (int64_t)&var_48h;
    if (0xf < (uint64_t)var_30h) {
        var_58h = var_48h;
    }
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    func_0x00018045b4e4(&var_58h);
    *(undefined8 *)arg1 = 0x1804a53a0;
    if (0xf < (uint64_t)var_30h) {
        iVar5 = var_48h;
        puVar6 = auStack_78;
        if ((0xfff < var_30h + 1U) &&
           (iVar5 = *(int64_t *)(var_48h + -8), puVar6 = auStack_78, 0x1f < (var_48h - iVar5) - 8U)) {
            pcVar4 = (code *)swi(0x29);
            iVar5 = (*pcVar4)(5);
            puVar6 = auStack_70;
        }
        *(undefined8 *)(puVar6 + -8) = 0x180006142;
        fcn.180459c3c(iVar5);
    }
    *(undefined4 *)(arg1 + 0x18) = uVar1;
    *(undefined8 *)arg1 = 0x1804a53d0;
    *(undefined4 *)(arg1 + 0x1c) = uVar2;
    *(int64_t **)(arg1 + 0x20) = piVar3;
    *(undefined8 *)(puVar6 + -8) = 0x180006166;
    func_0x000180459870(*(uint64_t *)(puVar6 + 0x50) ^ (uint64_t)puVar6);
    return;
}

// ============================================================
// Function: FUN_180006180
// Address: 0x180006180
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_58h

void fcn.180006180(void)
{
    code *pcVar1;
    undefined4 *puVar2;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    
    puVar2 = (undefined4 *)fcn.180005e30(&var_48h, 0x16);
    var_58h._0_4_ = *puVar2;
    var_58h._4_4_ = puVar2[1];
    uStack_50 = puVar2[2];
    uStack_4c = puVar2[3];
    fcn.180006080((int64_t)&var_38h, (int64_t)&var_58h, var_48h);
    fcn.18045bae0(CONCAT44(var_58h._4_4_, (undefined4)var_58h));
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800061c0
// Address: 0x1800061c0
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800061c0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a53b8;
    uVar1 = *(undefined4 *)(arg2 + 0x18);
    uVar2 = *(undefined4 *)(arg2 + 0x1c);
    uVar3 = *(undefined4 *)(arg2 + 0x20);
    uVar4 = *(undefined4 *)(arg2 + 0x24);
    *(undefined8 *)arg1 = 0x1804a53d0;
    *(undefined4 *)(arg1 + 0x18) = uVar1;
    *(undefined4 *)(arg1 + 0x1c) = uVar2;
    *(undefined4 *)(arg1 + 0x20) = uVar3;
    *(undefined4 *)(arg1 + 0x24) = uVar4;
    return arg1;
}

// ============================================================
// Function: FUN_180006220
// Address: 0x180006220
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180006220(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a53b8;
    uVar1 = *(undefined4 *)(arg2 + 0x1c);
    uVar2 = *(undefined4 *)(arg2 + 0x20);
    uVar3 = *(undefined4 *)(arg2 + 0x24);
    *(undefined4 *)(arg1 + 0x18) = *(undefined4 *)(arg2 + 0x18);
    *(undefined4 *)(arg1 + 0x1c) = uVar1;
    *(undefined4 *)(arg1 + 0x20) = uVar2;
    *(undefined4 *)(arg1 + 0x24) = uVar3;
    return arg1;
}

// ============================================================
// Function: FUN_180006290
// Address: 0x180006290
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180006290(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t var_8h;
    
    uVar1 = fcn.180455d14(arg3 & 0xffffffff);
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0;
    uVar2 = fcn.180498cd0(uVar1);
    fcn.180004830(arg2, uVar1, uVar2);
    return arg2;
}

// ============================================================
// Function: FUN_1800062f0
// Address: 0x1800062f0
// Size: 33 bytes
// ============================================================
int64_t fcn.1800062f0(int64_t arg1)
{
    uint64_t in_RDX;
    
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x10);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180006330
// Address: 0x180006330
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180006330(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    if ((int32_t)arg3 == 1) {
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        puVar1 = (undefined4 *)fcn.180459890(0x20);
        *(undefined4 **)arg2 = puVar1;
        *(undefined8 *)(arg2 + 0x10) = 0x15;
        *(undefined8 *)(arg2 + 0x18) = 0x1f;
        *puVar1 = 0x74736f69;
        puVar1[1] = 0x6d616572;
        puVar1[2] = 0x72747320;
        puVar1[3] = 0x206d6165;
        *(undefined8 *)((int64_t)puVar1 + 0xd) = 0x726f727265206d61;
        *(undefined *)((int64_t)puVar1 + 0x15) = 0;
        return arg2;
    }
    uVar2 = fcn.180455d14(arg3 & 0xffffffff);
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0;
    uVar3 = fcn.180498cd0(uVar2);
    fcn.180004830(arg2, uVar2, uVar3);
    return arg2;
}

// ============================================================
// Function: FUN_1800063f0
// Address: 0x1800063f0
// Size: 182 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800063f0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t var_8h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_20h = 0;
    var_18h = fcn.180454b10(arg3 & 0xffffffff, &var_20h);
    if ((var_20h != 0) && (var_18h != 0)) {
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        fcn.180004830(arg2, var_20h, var_18h);
        sub.KERNEL32.dll_LocalFree(var_20h);
        return arg2;
    }
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0xd;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined8 *)arg2 = 0x206e776f6e6b6e75;
    *(undefined4 *)(arg2 + 8) = 0x6f727265;
    *(undefined *)(arg2 + 0xc) = 0x72;
    *(undefined *)(arg2 + 0xd) = 0;
    sub.KERNEL32.dll_LocalFree();
    return arg2;
}

// ============================================================
// Function: FUN_1800064b0
// Address: 0x1800064b0
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800064b0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t var_8h;
    
    if ((int32_t)arg3 == 0) {
        *(undefined4 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0x1806a45d0;
        return arg2;
    }
    iVar1 = fcn.180455d3c(arg3 & 0xffffffff);
    if (iVar1 == 0) {
        *(int32_t *)arg2 = (int32_t)arg3;
        *(undefined8 *)(arg2 + 8) = 0x1806a45e0;
        return arg2;
    }
    *(int32_t *)arg2 = iVar1;
    *(undefined8 *)(arg2 + 8) = 0x1806a45d0;
    return arg2;
}

// ============================================================
// Function: FUN_180006560
// Address: 0x180006560
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_58h

void fcn.180006560(int64_t arg1)
{
    code *pcVar1;
    undefined4 *puVar2;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    
    puVar2 = (undefined4 *)fcn.180006540(&var_48h, arg1 & 0xffffffff);
    var_58h._0_4_ = *puVar2;
    var_58h._4_4_ = puVar2[1];
    uStack_50 = puVar2[2];
    uStack_4c = puVar2[3];
    fcn.180006080((int64_t)&var_38h, (int64_t)&var_58h, var_48h);
    fcn.18045bae0(CONCAT44(var_58h._4_4_, (undefined4)var_58h));
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800065a0
// Address: 0x1800065a0
// Size: 43 bytes
// ============================================================
int64_t fcn.1800065a0(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1804a5438;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800065d0
// Address: 0x1800065d0
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800065d0(int64_t arg1)
{
    int32_t iVar1;
    int64_t var_8h;
    
    func_0x000180455a6c();
    if (*(int64_t *)(arg1 + 0x58) != 0) {
        fcn.180460d90();
    }
    *(undefined8 *)(arg1 + 0x58) = 0;
    if (*(int64_t *)(arg1 + 0x48) != 0) {
        fcn.180460d90();
    }
    *(undefined8 *)(arg1 + 0x48) = 0;
    if (*(int64_t *)(arg1 + 0x38) != 0) {
        fcn.180460d90();
    }
    *(undefined8 *)(arg1 + 0x38) = 0;
    if (*(int64_t *)(arg1 + 0x28) != 0) {
        fcn.180460d90();
    }
    *(undefined8 *)(arg1 + 0x28) = 0;
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        fcn.180460d90();
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        fcn.180460d90();
    }
    *(undefined8 *)(arg1 + 8) = 0;
    iVar1 = *(int32_t *)arg1;
    if (iVar1 == 0) {
    // WARNING: Treating indirect jump as call
        (*(code *)0x699f34)(0x180781520);
        return;
    }
    if (iVar1 < 8) {
        func_0x000180459188((int64_t)iVar1 * 0x28 + 0x180780df0);
    }
    return;
}

// ============================================================
// Function: FUN_1800066a0
// Address: 0x1800066a0
// Size: 47 bytes
// ============================================================
void fcn.1800066a0(int64_t arg1)
{
    undefined8 *puVar1;
    
    if (*(int64_t **)(arg1 + 8) != (int64_t *)0x0) {
        puVar1 = (undefined8 *)(**(code **)(**(int64_t **)(arg1 + 8) + 0x10))();
        if (puVar1 != (undefined8 *)0x0) {
    // WARNING: Could not recover jumptable at 0x0001800066c7. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)*puVar1)(puVar1, 1);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800066e0
// Address: 0x1800066e0
// Size: 395 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800066e0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined8 *puVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    if ((arg1 != 0) && (*(int64_t *)arg1 == 0)) {
        puVar10 = (undefined8 *)fcn.180459890(0x30);
        iVar1 = *(int64_t *)(arg2 + 8);
        if (iVar1 == 0) {
            iVar13 = 0x1805aadb1;
        } else {
            iVar13 = *(int64_t *)(iVar1 + 0x28);
            if (iVar13 == 0) {
                iVar13 = iVar1 + 0x30;
            }
        }
        func_0x000180455714(&var_a8h, 0);
        var_a0h = 0;
        var_98h._0_1_ = 0;
        var_90h = 0;
        var_88h._0_1_ = 0;
        var_80h = 0;
        var_78h._0_2_ = 0;
        var_70h = 0;
        var_68h._0_2_ = 0;
        var_60h = 0;
        var_58h._0_1_ = 0;
        var_50h = 0;
        var_48h._0_1_ = 0;
        if (iVar13 == 0) {
            func_0x000180454740(0x1805aadd8);
            pcVar2 = (code *)swi(3);
            uVar12 = (*pcVar2)();
            return uVar12;
        }
        func_0x000180455a00(&var_a8h, iVar13);
        *(undefined4 *)(puVar10 + 1) = 0;
        *puVar10 = 0x1804a5458;
        puVar11 = (undefined4 *)func_0x000180455e10(&var_40h);
        uVar3 = puVar11[1];
        uVar4 = puVar11[2];
        uVar5 = puVar11[3];
        uVar6 = puVar11[4];
        uVar7 = puVar11[5];
        uVar8 = puVar11[6];
        uVar9 = puVar11[7];
        *(undefined4 *)(puVar10 + 2) = *puVar11;
        *(undefined4 *)((int64_t)puVar10 + 0x14) = uVar3;
        *(undefined4 *)(puVar10 + 3) = uVar4;
        *(undefined4 *)((int64_t)puVar10 + 0x1c) = uVar5;
        *(undefined4 *)(puVar10 + 4) = uVar6;
        *(undefined4 *)((int64_t)puVar10 + 0x24) = uVar7;
        *(undefined4 *)(puVar10 + 5) = uVar8;
        *(undefined4 *)((int64_t)puVar10 + 0x2c) = uVar9;
        *(undefined8 **)arg1 = puVar10;
        func_0x000180455a6c(&var_a8h);
        if (var_50h != 0) {
            fcn.180460d90();
        }
        var_50h = 0;
        if (var_60h != 0) {
            fcn.180460d90();
        }
        var_60h = 0;
        if (var_70h != 0) {
            fcn.180460d90();
        }
        var_70h = 0;
        if (var_80h != 0) {
            fcn.180460d90();
        }
        var_80h = 0;
        if (var_90h != 0) {
            fcn.180460d90();
        }
        var_90h = 0;
        if (var_a0h != 0) {
            fcn.180460d90();
        }
        var_a0h = 0;
        func_0x00018045578c(&var_a8h);
    }
    return 2;
}

// ============================================================
// Function: FUN_180006880
// Address: 0x180006880
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Removing arg arg_79h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_12h

undefined * fcn.180006880(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    undefined uVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg2 != arg3) {
        do {
            uVar1 = fcn.180455ed8(*(undefined *)arg2, arg1 + 0x10);
            *(undefined *)arg2 = uVar1;
            arg2 = arg2 + 1;
        } while (arg2 != arg3);
    }
    return (undefined *)arg2;
}

// ============================================================
// Function: FUN_180006895
// Address: 0x180006895
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Removing arg arg_79h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_12h

undefined * fcn.180006880(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    undefined uVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg2 != arg3) {
        do {
            uVar1 = fcn.180455ed8(*(undefined *)arg2, arg1 + 0x10);
            *(undefined *)arg2 = uVar1;
            arg2 = arg2 + 1;
        } while (arg2 != arg3);
    }
    return (undefined *)arg2;
}

// ============================================================
// Function: FUN_1800068ba
// Address: 0x1800068ba
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Removing arg arg_79h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_12h

undefined * fcn.180006880(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    undefined uVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg2 != arg3) {
        do {
            uVar1 = fcn.180455ed8(*(undefined *)arg2, arg1 + 0x10);
            *(undefined *)arg2 = uVar1;
            arg2 = arg2 + 1;
        } while (arg2 != arg3);
    }
    return (undefined *)arg2;
}

// ============================================================
// Function: FUN_1800068e0
// Address: 0x1800068e0
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Removing arg arg_79h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_12h

undefined * fcn.1800068e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    undefined uVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg2 != arg3) {
        do {
            uVar1 = fcn.1804581c8(*(undefined *)arg2, arg1 + 0x10);
            *(undefined *)arg2 = uVar1;
            arg2 = arg2 + 1;
        } while (arg2 != arg3);
    }
    return (undefined *)arg2;
}

// ============================================================
// Function: FUN_1800068f5
// Address: 0x1800068f5
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Removing arg arg_79h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_12h

undefined * fcn.1800068e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    undefined uVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg2 != arg3) {
        do {
            uVar1 = fcn.1804581c8(*(undefined *)arg2, arg1 + 0x10);
            *(undefined *)arg2 = uVar1;
            arg2 = arg2 + 1;
        } while (arg2 != arg3);
    }
    return (undefined *)arg2;
}

// ============================================================
// Function: FUN_18000691a
// Address: 0x18000691a
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Removing arg arg_79h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_12h

undefined * fcn.1800068e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    undefined uVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg2 != arg3) {
        do {
            uVar1 = fcn.1804581c8(*(undefined *)arg2, arg1 + 0x10);
            *(undefined *)arg2 = uVar1;
            arg2 = arg2 + 1;
        } while (arg2 != arg3);
    }
    return (undefined *)arg2;
}

// ============================================================
// Function: FUN_180006940
// Address: 0x180006940
// Size: 29 bytes
// ============================================================
int64_t fcn.180006940(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4)
{
    fcn.180498030(arg4, arg2, arg3 - arg2);
    return arg3;
}

// ============================================================
// Function: FUN_180006960
// Address: 0x180006960
// Size: 31 bytes
// ============================================================
int64_t fcn.180006960(undefined8 placeholder_0, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    fcn.180498030(arg_28h, arg2, arg3 - arg2);
    return arg3;
}

// ============================================================
// Function: FUN_180006980
// Address: 0x180006980
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180006980(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a5458;
    if (*(int32_t *)(arg1 + 0x20) < 1) {
        if (*(int32_t *)(arg1 + 0x20) < 0) {
            fcn.180459c3c(*(undefined8 *)(arg1 + 0x18));
        }
    } else {
        fcn.180460d90(*(undefined8 *)(arg1 + 0x18));
    }
    fcn.180460d90(*(undefined8 *)(arg1 + 0x28));
    *(undefined8 *)arg1 = 0x1804a5438;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x30);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800069f0
// Address: 0x1800069f0
// Size: 226 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800069f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined *puVar6;
    int64_t var_20h;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    
    puVar6 = auStack_78;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    iVar5 = *(int64_t *)arg3;
    uVar2 = *(undefined4 *)(arg3 + 8);
    uVar3 = *(undefined4 *)(arg3 + 0xc);
    _var_48h = ZEXT816(0);
    var_38h = 0;
    var_30h = 0;
    var_58h = arg1;
    uVar4 = fcn.180498cd0(arg2);
    fcn.180004830(&var_48h, arg2, uVar4);
    var_58h = iVar5;
    uStack_50 = uVar2;
    uStack_4c = uVar3;
    fcn.180005e70(arg1, (int64_t)&var_58h, (int64_t)&var_48h);
    if (0xf < (uint64_t)var_30h) {
        iVar5 = var_48h;
        puVar6 = auStack_78;
        if ((0xfff < var_30h + 1U) &&
           (iVar5 = *(int64_t *)(var_48h + -8), puVar6 = auStack_78, 0x1f < (var_48h - iVar5) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar5 = (*pcVar1)(5);
            puVar6 = auStack_70;
        }
        *(undefined8 *)(puVar6 + -8) = 0x180006aa5;
        fcn.180459c3c(iVar5);
    }
    *(undefined8 *)arg1 = 0x1804a54b8;
    *(undefined8 *)(puVar6 + -8) = 0x180006abf;
    func_0x000180459870(*(uint64_t *)(puVar6 + 0x50) ^ (uint64_t)puVar6);
    return;
}

// ============================================================
// Function: FUN_180006ae0
// Address: 0x180006ae0
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180006ae0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t arg3;
    uint32_t uVar2;
    int64_t arg2_00;
    char in_R8B;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_8h;
    
    uVar2 = (uint32_t)arg2 & 0x17;
    *(uint32_t *)(arg1 + 0x10) = uVar2;
    uVar2 = uVar2 & *(uint32_t *)(arg1 + 0x14);
    if (uVar2 == 0) {
        return;
    }
    if (in_R8B != '\0') {
        fcn.18045bae0(var_48h);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uVar2 & 4) == 0) {
        arg2_00 = 0x1805aae00;
        if ((uVar2 & 2) == 0) {
            arg2_00 = 0x1805aae18;
        }
    } else {
        arg2_00 = 0x1805aade8;
    }
    arg3 = fcn.180005e50(&var_48h, 1);
    fcn.1800069f0((int64_t)&var_38h, arg2_00, arg3, var_38h);
    fcn.18045bae0(var_48h);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180006b70
// Address: 0x180006b70
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180006b70(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a53b8;
    uVar1 = *(undefined4 *)(arg2 + 0x18);
    uVar2 = *(undefined4 *)(arg2 + 0x1c);
    uVar3 = *(undefined4 *)(arg2 + 0x20);
    uVar4 = *(undefined4 *)(arg2 + 0x24);
    *(undefined8 *)arg1 = 0x1804a54b8;
    *(undefined4 *)(arg1 + 0x18) = uVar1;
    *(undefined4 *)(arg1 + 0x1c) = uVar2;
    *(undefined4 *)(arg1 + 0x20) = uVar3;
    *(undefined4 *)(arg1 + 0x24) = uVar4;
    return arg1;
}

// ============================================================
// Function: FUN_180006bd0
// Address: 0x180006bd0
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180006bd0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a54d0;
    fcn.180455c14();
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x48);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180006d10
// Address: 0x180006d10
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.180006d10(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t var_8h;
    
    uVar3 = arg2 - arg1 >> 1;
    uVar2 = arg4 - arg3 >> 1;
    uVar1 = uVar3;
    if (uVar2 < uVar3) {
        uVar1 = uVar2;
    }
    uVar1 = fcn.180005b70(arg1, arg3, uVar1);
    if ((int32_t)uVar1 == 0) {
        if (uVar3 < uVar2) {
            return 0xffffffff;
        }
        uVar1 = (uint64_t)(uVar2 < uVar3);
    }
    return uVar1;
}

// ============================================================
// Function: FUN_180006d80
// Address: 0x180006d80
// Size: 295 bytes
// ============================================================
int64_t fcn.180006d80(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int16_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int64_t arg2_00;
    int16_t *arg4;
    int16_t *arg3;
    int64_t arg1_00;
    
    cVar4 = func_0x0001800072b0(arg2);
    if (cVar4 == '\0') {
        arg1_00 = arg1;
        if (7 < *(uint64_t *)(arg1 + 0x18)) {
            arg1_00 = *(int64_t *)arg1;
        }
        iVar2 = arg1_00 + *(int64_t *)(arg1 + 0x10) * 2;
        arg3 = (int16_t *)arg2;
        if (7 < *(uint64_t *)(arg2 + 0x18)) {
            arg3 = *(int16_t **)arg2;
        }
        piVar3 = arg3 + *(int64_t *)(arg2 + 0x10);
        arg2_00 = func_0x000180006c10(arg1_00, iVar2);
        arg4 = (int16_t *)func_0x000180006c10(arg3, piVar3);
        if ((arg3 == arg4) || (iVar5 = fcn.180006d10(arg1_00, arg2_00, (int64_t)arg3, (int64_t)arg4), iVar5 == 0)) {
            if ((arg4 == piVar3) || ((*arg4 != 0x5c && (*arg4 != 0x2f)))) {
                if (arg2_00 == iVar2) {
                    if ((int64_t)(arg2_00 - arg1_00 & 0xfffffffffffffffeU) < 6) goto code_r0x000180006e81;
                } else if ((*(int16_t *)(iVar2 + -2) == 0x5c) || (*(int16_t *)(iVar2 + -2) == 0x2f))
                goto code_r0x000180006e81;
                func_0x00018000b120(arg1, 0x5c);
            } else {
                func_0x00018000b160(arg1, arg2_00 - arg1_00 >> 1);
            }
code_r0x000180006e81:
            func_0x00018000d4b0(arg1, arg4, (int64_t)piVar3 - (int64_t)arg4 >> 1);
            return arg1;
        }
    }
    if (arg1 != arg2) {
        puVar1 = (undefined8 *)(arg2 + 0x10);
        if (7 < *(uint64_t *)(arg2 + 0x18)) {
            arg2 = *(int64_t *)arg2;
        }
        func_0x00018000d7e0(arg1, arg2, *puVar1);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180006eb0
// Address: 0x180006eb0
// Size: 233 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180006eb0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined4 uVar3;
    uint64_t uVar4;
    uint32_t extraout_var;
    int64_t iVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar5 = arg1;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        iVar5 = *(int64_t *)arg1;
    }
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    uVar3 = func_0x000180454ce0();
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    if (uVar1 != 0) {
        if (0x7fffffff < uVar1) {
            fcn.180006180();
            pcVar2 = (code *)swi(3);
            iVar5 = (*pcVar2)();
            return iVar5;
        }
        uVar4 = func_0x000180454d50(uVar3, iVar5, uVar1 & 0xffffffff, 0, 0);
        if ((int32_t)(uVar4 >> 0x20) != 0) {
            fcn.180006560(uVar4 >> 0x20);
            pcVar2 = (code *)swi(3);
            iVar5 = (*pcVar2)();
            return iVar5;
        }
        func_0x00018000b3b0(arg2, (int64_t)(int32_t)uVar4, 0);
        iVar6 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar6 = *(int64_t *)arg2;
        }
        func_0x000180454d50(uVar3, iVar5, uVar1 & 0xffffffff, iVar6, (int32_t)uVar4);
        if (extraout_var != 0) {
            fcn.180006560((uint64_t)extraout_var);
            pcVar2 = (code *)swi(3);
            iVar5 = (*pcVar2)();
            return iVar5;
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_180006fa0
// Address: 0x180006fa0
// Size: 508 bytes
// ============================================================
int32_t fcn.180006fa0(int64_t arg1, int64_t arg2)
{
    uint16_t *puVar1;
    uint16_t *puVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    int64_t iVar5;
    int32_t iVar6;
    uint16_t *puVar7;
    uint16_t *puVar8;
    uint16_t *puVar9;
    int32_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    uint16_t *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    
    iVar15 = arg2;
    if (7 < *(uint64_t *)(arg2 + 0x18)) {
        iVar15 = *(int64_t *)arg2;
    }
    iVar5 = *(int64_t *)(arg2 + 0x10);
    iVar16 = arg1;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        iVar16 = *(int64_t *)arg1;
    }
    puVar1 = (uint16_t *)(iVar16 + *(int64_t *)(arg1 + 0x10) * 2);
    puVar7 = (uint16_t *)func_0x000180006c10(iVar16, puVar1);
    puVar2 = (uint16_t *)(iVar15 + iVar5 * 2);
    puVar8 = (uint16_t *)func_0x000180006c10(iVar15, puVar2);
    uVar11 = (int64_t)puVar8 - iVar15 >> 1;
    uVar12 = (int64_t)puVar7 - iVar16 >> 1;
    uVar13 = uVar12;
    if (uVar11 < uVar12) {
        uVar13 = uVar11;
    }
    iVar6 = fcn.180005b70(iVar16, iVar15, uVar13);
    if (iVar6 == 0) {
        if (uVar12 < uVar11) {
            return -1;
        }
        puVar9 = puVar7;
        if (uVar12 <= uVar11) {
            for (; (puVar14 = puVar8, puVar9 != puVar1 && ((*puVar9 == 0x5c || (*puVar9 == 0x2f)))); puVar9 = puVar9 + 1
                ) {
            }
            for (; (puVar14 != puVar2 && ((*puVar14 == 0x5c || (*puVar14 == 0x2f)))); puVar14 = puVar14 + 1) {
            }
            iVar6 = (uint32_t)(puVar7 != puVar9) - (uint32_t)(puVar8 != puVar14);
            if (iVar6 == 0) {
                iVar6 = (uint32_t)(puVar14 == puVar2) - (uint32_t)(puVar9 == puVar1);
                while ((puVar9 != puVar1 && (iVar6 == 0))) {
                    uVar3 = *puVar9;
                    if ((uVar3 == 0x5c) || (uVar3 == 0x2f)) {
                        iVar6 = 1;
                    } else {
                        iVar6 = 0;
                    }
                    uVar4 = *puVar14;
                    if ((uVar4 == 0x5c) || (uVar4 == 0x2f)) {
                        iVar10 = 1;
                    } else {
                        iVar10 = 0;
                    }
                    if (iVar10 - iVar6 != 0) {
                        return iVar10 - iVar6;
                    }
                    if ((char)iVar6 == '\0') {
                        if ((uint32_t)uVar3 - (uint32_t)uVar4 != 0) {
                            return (uint32_t)uVar3 - (uint32_t)uVar4;
                        }
                        puVar9 = puVar9 + 1;
                        puVar14 = puVar14 + 1;
                    } else {
                        do {
                            puVar9 = puVar9 + 1;
                            if (puVar9 == puVar1) break;
                        } while ((*puVar9 == 0x5c) || (*puVar9 == 0x2f));
                        do {
                            puVar14 = puVar14 + 1;
                            if (puVar14 == puVar2) break;
                        } while ((*puVar14 == 0x5c) || (*puVar14 == 0x2f));
                    }
                    iVar6 = (uint32_t)(puVar14 == puVar2) - (uint32_t)(puVar9 == puVar1);
                }
            }
            return iVar6;
        }
        iVar6 = 1;
    }
    return iVar6;
}

// ============================================================
// Function: FUN_1800071a0
// Address: 0x1800071a0
// Size: 263 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800071a0(int64_t arg1, int64_t arg2)
{
    int16_t *piVar1;
    int16_t *piVar2;
    int16_t *piVar3;
    int16_t *piVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    iVar5 = arg1;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        iVar5 = *(int64_t *)arg1;
    }
    piVar4 = (int16_t *)(iVar5 + *(int64_t *)(arg1 + 0x10) * 2);
    piVar3 = piVar4;
    piVar2 = (int16_t *)func_0x000180006c10(iVar5);
    if (piVar2 != piVar3) {
        do {
            piVar1 = piVar4;
            if ((*piVar2 != 0x5c) && (*piVar2 != 0x2f)) break;
            piVar2 = piVar2 + 1;
        } while (piVar2 != piVar3);
        do {
            piVar4 = piVar1;
            if (piVar2 == piVar3) break;
            piVar3 = piVar4 + -1;
            if ((piVar4[-1] == 0x5c) || (piVar1 = piVar3, piVar4[-1] == 0x2f)) break;
        } while( true );
    }
    piVar3 = (int16_t *)func_0x000180458100(piVar4);
    if ((piVar4 != piVar3) && (piVar2 = piVar3 + -1, piVar4 != piVar2)) {
        if (*piVar2 == 0x2e) {
            if ((piVar4 != piVar3 + -2) || (piVar3[-2] != 0x2e)) goto code_r0x000180007272;
        } else {
            for (piVar2 = piVar3 + -2; piVar4 != piVar2; piVar2 = piVar2 + -1) {
                if (*piVar2 == 0x2e) goto code_r0x000180007272;
            }
        }
    }
    piVar2 = piVar3;
code_r0x000180007272:
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0;
    func_0x00018000d380(arg2, piVar2, (int64_t)piVar3 - (int64_t)piVar2 >> 1);
    return arg2;
}

// ============================================================
// Function: FUN_1800072b0
// Address: 0x1800072b0
// Size: 114 bytes
// ============================================================
bool fcn.1800072b0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t *puVar2;
    int64_t iVar3;
    uint32_t *puVar4;
    
    puVar4 = (uint32_t *)arg1;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        puVar4 = *(uint32_t **)arg1;
    }
    iVar1 = *(int64_t *)(arg1 + 0x10) * 2;
    iVar3 = iVar1 >> 1;
    if ((1 < iVar3) && ((*puVar4 & 0xffffffdf) - 0x3a0041 < 0x1a)) {
        if (2 < iVar3) {
            if ((*(int16_t *)(puVar4 + 1) == 0x5c) || (*(int16_t *)(puVar4 + 1) == 0x2f)) {
                return true;
            }
        }
        return false;
    }
    puVar2 = (uint32_t *)func_0x000180006c10(puVar4, iVar1 + (int64_t)puVar4);
    return puVar4 != puVar2;
}

// ============================================================
// Function: FUN_180007340
// Address: 0x180007340
// Size: 281 bytes
// ============================================================
int64_t fcn.180007340(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined *puVar10;
    int64_t var_1h;
    undefined8 uStack_50;
    undefined auStack_48 [40];
    
    puVar10 = auStack_48;
    *(undefined (*) [16])arg1 = ZEXT816(0);
    uVar8 = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    uVar1 = *(uint64_t *)(arg2 + 0x10);
    if (7 < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    if (0x7ffffffffffffffe < uVar1) {
        fcn.1800047c0();
        pcVar2 = (code *)swi(3);
        iVar7 = (*pcVar2)();
        return iVar7;
    }
    if (uVar1 < 8) {
        *(uint64_t *)(arg1 + 0x10) = uVar1;
        *(undefined8 *)(arg1 + 0x18) = 7;
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *(undefined4 *)arg1 = *(undefined4 *)arg2;
        *(undefined4 *)(arg1 + 4) = uVar3;
        *(undefined4 *)(arg1 + 8) = uVar4;
        *(undefined4 *)(arg1 + 0xc) = uVar5;
        return arg1;
    }
    uVar6 = uVar1 | 7;
    if (uVar6 < 0x7fffffffffffffff) goto code_r0x0001800073e4;
    uVar9 = 0xfffffffffffffffe;
    puVar10 = auStack_48;
    uVar6 = 0x7ffffffffffffffe;
    do {
        if (uVar9 < 0x1000) {
            *(undefined8 *)(puVar10 + -8) = 0x180007423;
            uVar8 = fcn.180459890();
            goto code_r0x000180007423;
        }
        if (uVar9 + 0x27 <= uVar9) {
code_r0x000180007453:
            *(undefined8 *)(puVar10 + -8) = 0x180007458;
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            iVar7 = (*pcVar2)();
            return iVar7;
        }
        *(undefined8 *)(puVar10 + -8) = 0x1800073d5;
        iVar7 = fcn.180459890(uVar9 + 0x27);
        if (iVar7 != 0) {
            uVar8 = iVar7 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar8 - 8) = iVar7;
            goto code_r0x000180007423;
        }
        pcVar2 = (code *)swi(0x29);
        uVar6 = (*pcVar2)(5);
        puVar10 = puVar10 + 8;
code_r0x0001800073e4:
        if (uVar6 < 10) {
            uVar6 = 10;
        }
        if (0x7fffffffffffffff < uVar6 + 1) goto code_r0x000180007453;
        uVar9 = (uVar6 + 1) * 2;
        if (uVar9 == 0) {
code_r0x000180007423:
            *(uint64_t *)arg1 = uVar8;
            *(uint64_t *)(arg1 + 0x10) = uVar1;
            *(uint64_t *)(arg1 + 0x18) = uVar6;
            *(undefined8 *)(puVar10 + -8) = 0x180007441;
            fcn.180498030(uVar8, arg2, uVar1 * 2 + 2);
            return arg1;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180007460
// Address: 0x180007460
// Size: 178 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180007460(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 uStack_18;
    undefined4 uStack_14;
    undefined4 uStack_10;
    undefined4 uStack_c;
    
    uStack_18 = *(undefined4 *)arg3;
    uStack_14 = *(undefined4 *)(arg3 + 4);
    uStack_10 = *(undefined4 *)(arg3 + 8);
    uStack_c = *(undefined4 *)(arg3 + 0xc);
    fcn.180005e70(arg1, (int64_t)&uStack_18, arg2);
    *(undefined8 *)arg1 = 0x1805ab170;
    *(undefined (*) [16])(arg1 + 0x28) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x40) = 7;
    *(undefined2 *)(arg1 + 0x28) = 0;
    *(undefined (*) [16])(arg1 + 0x48) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x58) = 0;
    *(undefined8 *)(arg1 + 0x60) = 7;
    *(undefined2 *)(arg1 + 0x48) = 0;
    iVar2 = 0x1805aad28;
    if (*(int64_t *)(arg1 + 8) != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
    }
    *(undefined (*) [16])(arg1 + 0x68) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x78) = 0;
    *(undefined8 *)(arg1 + 0x80) = 0;
    uVar1 = fcn.180498cd0(iVar2);
    fcn.180004830(arg1 + 0x68, iVar2, uVar1);
    return arg1;
}

// ============================================================
// Function: FUN_180007520
// Address: 0x180007520
// Size: 291 bytes
// ============================================================
void fcn.180007520(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_58h)
{
    code *pcVar1;
    undefined auVar2 [16];
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar4 = auStack_98;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    var_78h = *(int64_t *)arg4;
    var_70h = *(int64_t *)(arg4 + 8);
    var_58h = arg1;
    fcn.180005e70(arg1, (int64_t)&var_78h, arg2);
    *(undefined8 *)arg1 = 0x1805ab170;
    fcn.180007340(arg1 + 0x28, arg3);
    *(undefined (*) [16])(arg1 + 0x48) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x58) = 0;
    *(undefined8 *)(arg1 + 0x60) = 7;
    *(undefined2 *)(arg1 + 0x48) = 0;
    var_38h = 0;
    var_30h = 7;
    stack0xffffffffffffffba = SUB1614(ZEXT816(0), 2);
    auVar2._14_2_ = 0;
    auVar2._0_14_ = stack0xffffffffffffffba;
    _var_48h = auVar2 << 0x10;
    iVar3 = 0x1805aad28;
    if (*(int64_t *)(arg1 + 8) != 0) {
        iVar3 = *(int64_t *)(arg1 + 8);
    }
    var_70h = fcn.180498cd0(iVar3);
    var_78h = iVar3;
    func_0x000180007660(arg1 + 0x68, &var_78h, arg3, &var_48h);
    if (7 < (uint64_t)var_30h) {
        iVar3 = var_48h;
        puVar4 = auStack_98;
        if ((0xfff < var_30h * 2 + 2U) &&
           (iVar3 = *(int64_t *)(var_48h + -8), puVar4 = auStack_98, 0x1f < (var_48h - iVar3) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar3 = (*pcVar1)(5);
            puVar4 = auStack_90;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180007627;
        fcn.180459c3c(iVar3);
    }
    *(undefined8 *)(puVar4 + -8) = 0x180007638;
    func_0x000180459870(*(uint64_t *)(puVar4 + 0x70) ^ (uint64_t)puVar4);
    return;
}

// ============================================================
// Function: FUN_180007660
// Address: 0x180007660
// Size: 599 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.180007660(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined *puVar7;
    int64_t var_18h;
    undefined8 uStack_c0;
    undefined auStack_b8 [8];
    undefined auStack_b0 [24];
    undefined var_98h;
    int64_t var_94h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    puVar7 = auStack_b8;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    var_94h._0_4_ = 1;
    var_78h = arg1;
    uVar4 = func_0x000180454ce0();
    var_88h = arg3;
    if (7 < *(uint64_t *)(arg3 + 0x18)) {
        var_88h = *(int64_t *)arg3;
    }
    var_80h = *(int64_t *)(arg3 + 0x10);
    func_0x00018000a550(&var_50h, uVar4, &var_88h);
    var_88h = arg4;
    if (7 < *(uint64_t *)(arg4 + 0x18)) {
        var_88h = *(int64_t *)arg4;
    }
    var_80h = *(int64_t *)(arg4 + 0x10);
    func_0x00018000a550(&var_70h, uVar4, &var_88h);
    iVar5 = 8;
    if (var_60h == 0) {
        iVar5 = 4;
    }
    func_0x00018000b240(arg1, iVar5 + *(int64_t *)(arg2 + 8) + var_40h + var_60h);
    func_0x00018000d970(arg1, *(undefined8 *)arg2, *(undefined8 *)(arg2 + 8));
    func_0x00018000d970(arg1, 0x1805aae30, 3);
    piVar6 = &var_50h;
    if (0xf < (uint64_t)var_38h) {
        piVar6 = (int64_t *)var_50h;
    }
    func_0x00018000d970(arg1, piVar6, var_40h);
    if (var_60h != 0) {
        func_0x00018000d970(arg1, 0x1805aae34, 4);
        piVar6 = &var_70h;
        if (0xf < (uint64_t)var_58h) {
            piVar6 = (int64_t *)CONCAT71(var_70h._1_7_, (undefined)var_70h);
        }
        func_0x00018000d970(arg1, piVar6, var_60h);
    }
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if (uVar1 < *(uint64_t *)(arg1 + 0x18)) {
        *(uint64_t *)(arg1 + 0x10) = uVar1 + 1;
        if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
            *(undefined2 *)(uVar1 + arg1) = 0x22;
        } else {
            *(undefined2 *)(uVar1 + *(int64_t *)arg1) = 0x22;
        }
    } else {
        func_0x00018000f010(arg1, 1, var_98h, 0x22);
    }
    if (0xf < (uint64_t)var_58h) {
        iVar3 = CONCAT71(var_70h._1_7_, (undefined)var_70h);
        iVar5 = iVar3;
        puVar7 = auStack_b8;
        if ((0xfff < var_58h + 1U) &&
           (iVar5 = *(int64_t *)(iVar3 + -8), puVar7 = auStack_b8, 0x1f < (iVar3 - iVar5) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar7 = auStack_b0;
        }
        *(undefined8 *)(puVar7 + -8) = 0x18000783c;
        fcn.180459c3c(iVar5);
    }
    var_60h = 0;
    var_58h = 0xf;
    var_70h._0_1_ = 0;
    if (0xf < (uint64_t)var_38h) {
        iVar5 = var_50h;
        if ((0xfff < var_38h + 1U) && (iVar5 = *(int64_t *)(var_50h + -8), 0x1f < (var_50h - iVar5) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar7 = puVar7 + 8;
        }
        *(undefined8 *)(puVar7 + -8) = 0x180007890;
        fcn.180459c3c(iVar5);
    }
    *(undefined8 *)(puVar7 + -8) = 0x18000789f;
    func_0x000180459870(var_30h ^ (uint64_t)puVar7);
    return;
}

// ============================================================
// Function: FUN_1800078c0
// Address: 0x1800078c0
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800078c0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.180004e40(arg1 + 0x68);
    fcn.18000dc80(arg1 + 0x48);
    fcn.18000dc80(arg1 + 0x28);
    *(undefined8 *)arg1 = 0x1804a5358;
    fcn.18045b56c(arg1 + 8);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x88);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180007920
// Address: 0x180007920
// Size: 60 bytes
// ============================================================
void fcn.180007920(int64_t arg1)
{
    fcn.180004e40(arg1 + 0x68);
    fcn.18000dc80(arg1 + 0x48);
    fcn.18000dc80(arg1 + 0x28);
    *(undefined8 *)arg1 = 0x1804a5358;
    if (*(char *)(arg1 + 0x10) != '\0') {
        fcn.180460d90(*(undefined8 *)(arg1 + 8));
    }
    *(undefined *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    return;
}

// ============================================================
// Function: FUN_180007960
// Address: 0x180007960
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h

void fcn.180007960(void)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_a8h;
    int64_t var_18h;
    
    puVar6 = (undefined4 *)fcn.180006540(&var_d8h);
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    uVar4 = puVar6[2];
    uVar5 = puVar6[3];
    fcn.1800047e0(&var_c8h, 0x1805aae60);
    var_e8h._0_4_ = uVar2;
    var_e8h._4_4_ = uVar3;
    uStack_e0 = uVar4;
    uStack_dc = uVar5;
    fcn.180007460((int64_t)&var_a8h, (int64_t)&var_c8h, (int64_t)&var_e8h);
    fcn.18045bae0(CONCAT44(var_e8h._4_4_, (undefined4)var_e8h));
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800079c0
// Address: 0x1800079c0
// Size: 134 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800079c0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a53b8;
    uVar1 = *(undefined4 *)(arg2 + 0x1c);
    uVar2 = *(undefined4 *)(arg2 + 0x20);
    uVar3 = *(undefined4 *)(arg2 + 0x24);
    *(undefined4 *)(arg1 + 0x18) = *(undefined4 *)(arg2 + 0x18);
    *(undefined4 *)(arg1 + 0x1c) = uVar1;
    *(undefined4 *)(arg1 + 0x20) = uVar2;
    *(undefined4 *)(arg1 + 0x24) = uVar3;
    *(undefined8 *)arg1 = 0x1805ab170;
    fcn.180007340(arg1 + 0x28, arg2 + 0x28);
    fcn.180007340(arg1 + 0x48, arg2 + 0x48);
    fcn.18000b4d0(arg1 + 0x68, arg2 + 0x68);
    return arg1;
}

// ============================================================
// Function: FUN_180007a50
// Address: 0x180007a50
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h

void fcn.180007a50(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t in_stack_ffffffffffffff48;
    int64_t var_a8h;
    int64_t var_18h;
    
    puVar6 = (undefined4 *)fcn.180006540(&var_d8h);
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    uVar4 = puVar6[2];
    uVar5 = puVar6[3];
    fcn.1800047e0(&var_c8h, 0x1805aae40);
    var_e8h._0_4_ = uVar2;
    var_e8h._4_4_ = uVar3;
    uStack_e0 = uVar4;
    uStack_dc = uVar5;
    fcn.180007520((int64_t)&var_a8h, (int64_t)&var_c8h, arg3, (int64_t)&var_e8h, in_stack_ffffffffffffff48);
    fcn.18045bae0(CONCAT44(var_e8h._4_4_, (undefined4)var_e8h));
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180007ac0
// Address: 0x180007ac0
// Size: 356 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.180007ac0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int64_t *piVar3;
    bool bVar4;
    undefined auStack_58 [32];
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    *(undefined4 *)arg2 = 0;
    *(undefined4 *)(arg2 + 4) = 0xffff;
    if ((*(uint32_t *)(arg1 + 0x1c) & (uint32_t)arg3) == (uint32_t)arg3) {
        *(undefined4 *)(arg2 + 8) = 0;
        uVar1 = *(uint32_t *)(arg1 + 0x10);
        uVar2 = 0x16d;
        if ((uVar1 & 1) == 0) {
            uVar2 = 0x1ff;
        }
        *(undefined4 *)(arg2 + 4) = uVar2;
        if ((uVar1 >> 10 & 1) != 0) {
            if (*(int32_t *)(arg1 + 0x14) == -0x5ffffff4) {
code_r0x000180007b27:
                uVar1 = 4;
                goto code_r0x000180007c0c;
            }
            if (*(int32_t *)(arg1 + 0x14) == -0x5ffffffd) {
code_r0x000180007b38:
                uVar1 = 10;
                goto code_r0x000180007c0c;
            }
        }
        if ((uVar1 & 0x10) == 0) {
            uVar1 = 2;
        } else {
            uVar1 = 3;
        }
        goto code_r0x000180007c0c;
    }
    if ((*(uint32_t *)(arg1 + 0x1c) & 2) == 0) {
        uVar2 = 0xffffffff;
    } else {
        uVar2 = *(undefined4 *)(arg1 + 0x10);
    }
    piVar3 = (int64_t *)(arg1 + 0x20);
    if (7 < *(uint64_t *)(arg1 + 0x38)) {
        piVar3 = (int64_t *)*piVar3;
    }
    uVar1 = func_0x000180455104(piVar3, &var_38h, arg3, uVar2);
    *(uint32_t *)(arg2 + 8) = uVar1;
    if (uVar1 == 0) {
        uVar2 = 0x16d;
        if (((uint32_t)var_28h & 1) == 0) {
            uVar2 = 0x1ff;
        }
        *(undefined4 *)(arg2 + 4) = uVar2;
        if (((uint32_t)var_28h >> 10 & 1) != 0) {
            if (var_28h._4_4_ == -0x5ffffff4) goto code_r0x000180007b27;
            if (var_28h._4_4_ == -0x5ffffffd) goto code_r0x000180007b38;
        }
        uVar1 = ((uint32_t)var_28h & 0x10 | 0x20) >> 4;
        goto code_r0x000180007c0c;
    }
    *(undefined4 *)(arg2 + 4) = 0xffff;
    if (uVar1 < 0x41) {
        if (((uVar1 != 0x40) && (uVar1 != 2)) && (uVar1 != 3)) {
            bVar4 = uVar1 == 0x35;
code_r0x000180007bfe:
            if (!bVar4) {
                uVar1 = 0;
                goto code_r0x000180007c0c;
            }
        }
    } else if ((uVar1 != 0x7b) && (uVar1 != 0xa1)) {
        bVar4 = uVar1 == 0x10b;
        goto code_r0x000180007bfe;
    }
    uVar1 = 1;
code_r0x000180007c0c:
    *(uint32_t *)arg2 = uVar1;
    func_0x000180459870(var_18h ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_180007c30
// Address: 0x180007c30
// Size: 215 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_23ah
// WARNING: [rz-ghidra] Detected overlap for variable var_238h

void fcn.180007c30(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int32_t iVar5;
    int64_t var_10h;
    undefined auStack_288 [32];
    int64_t var_268h;
    int64_t var_23ch;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_288;
    iVar3 = *(int64_t *)arg1;
    do {
        iVar5 = func_0x000180454fdc(*(undefined8 *)(iVar3 + 0x40), &var_268h);
        if (iVar5 == 0x12) {
            piVar4 = *(int64_t **)(arg1 + 8);
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)(arg1 + 8) = 0;
            if (piVar4 != (int64_t *)0x0) {
                LOCK();
                piVar1 = piVar4 + 1;
                iVar5 = *(int32_t *)piVar1;
                *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                UNLOCK();
                if (iVar5 == 1) {
                    (**(code **)*piVar4)(piVar4);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                    iVar5 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar5 == 1) {
                        (**(code **)(*piVar4 + 8))(piVar4);
                    }
                }
            }
            goto code_r0x000180007ce6;
        }
        if (iVar5 != 0) goto code_r0x000180007ce6;
    } while (((int16_t)var_23ch == 0x2e) &&
            ((var_23ch._2_2_ == 0 || ((var_23ch._2_2_ == 0x2e && (var_23ch._4_2_ == 0))))));
    func_0x000180007d10(iVar3, &var_268h);
code_r0x000180007ce6:
    func_0x000180459870(var_18h ^ (uint64_t)auStack_288);
    return;
}

// ============================================================
// Function: FUN_180007d10
// Address: 0x180007d10
// Size: 411 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180007d10(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    undefined8 *arg1_00;
    int16_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    int16_t *piVar5;
    undefined8 uVar6;
    int16_t *piVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    int16_t *piVar10;
    uint64_t uVar11;
    undefined *puVar12;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_58 [8];
    undefined auStack_50 [32];
    int64_t var_30h;
    int64_t var_20h;
    uint64_t uStack_18;
    uint64_t uStack_10;
    
    puVar12 = auStack_58;
    uStack_10 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    *(undefined4 *)(arg1 + 0x10) = *(undefined4 *)arg2;
    *(undefined4 *)(arg1 + 0x14) = *(undefined4 *)(arg2 + 0x24);
    *(undefined4 *)(arg1 + 0x1c) = 6;
    if ((*(uint32_t *)arg2 >> 10 & 1) == 0) {
        *(uint64_t *)(arg1 + 8) = CONCAT44(*(undefined4 *)(arg2 + 0x1c), *(undefined4 *)(arg2 + 0x20));
        *(undefined8 *)arg1 = *(undefined8 *)(arg2 + 0x14);
        *(undefined4 *)(arg1 + 0x1c) = 0x2e;
    }
    arg1_00 = (undefined8 *)(arg1 + 0x20);
    uVar6 = func_0x0001804766e0(arg2 + 0x2c);
    _var_30h = ZEXT816(0);
    var_20h = 0;
    uStack_18 = 0;
    func_0x00018000d380(&var_30h, arg2 + 0x2c, uVar6);
    uVar2 = *(uint64_t *)(arg1 + 0x38);
    puVar9 = arg1_00;
    if (7 < uVar2) {
        puVar9 = (undefined8 *)*arg1_00;
    }
    uVar3 = *(uint64_t *)(arg1 + 0x30);
    piVar10 = (int16_t *)((int64_t)puVar9 + uVar3 * 2);
    piVar7 = (int16_t *)func_0x000180006c10(puVar9);
    if (piVar7 == piVar10) {
code_r0x000180007e0c:
        uVar11 = (int64_t)piVar10 - (int64_t)puVar9 >> 1;
        if (uVar11 <= uVar3) {
            *(uint64_t *)(arg1 + 0x30) = uVar11;
            puVar9 = arg1_00;
            if (7 < uVar2) {
                puVar9 = (undefined8 *)*arg1_00;
            }
            *(undefined2 *)((int64_t)puVar9 + uVar11 * 2) = 0;
            fcn.180006d80((int64_t)arg1_00, (int64_t)&var_30h);
            if (7 < uStack_18) {
                iVar8 = var_30h;
                puVar12 = auStack_58;
                if ((0xfff < uStack_18 * 2 + 2) &&
                   (iVar8 = *(int64_t *)(var_30h + -8), puVar12 = auStack_58, 0x1f < (var_30h - iVar8) - 8U)) {
                    pcVar4 = (code *)swi(0x29);
                    iVar8 = (*pcVar4)(5);
                    puVar12 = auStack_50;
                }
                *(undefined8 *)(puVar12 + -8) = 0x180007e88;
                fcn.180459c3c(iVar8);
            }
            *(undefined8 *)(puVar12 + -8) = 0x180007e95;
            func_0x000180459870(*(uint64_t *)(puVar12 + 0x48) ^ (uint64_t)puVar12);
            return;
        }
        func_0x00018000f930();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    do {
        piVar5 = piVar10;
        if ((*piVar7 != 0x5c) && (*piVar7 != 0x2f)) break;
        piVar7 = piVar7 + 1;
    } while (piVar7 != piVar10);
    do {
        piVar10 = piVar5;
        if (piVar7 == piVar10) goto code_r0x000180007e0c;
        iVar1 = piVar10[-1];
        if ((iVar1 == 0x5c) || (piVar5 = piVar10 + -1, iVar1 == 0x2f)) goto code_r0x000180007e0c;
    } while( true );
}

// ============================================================
// Function: FUN_180007eb0
// Address: 0x180007eb0
// Size: 235 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180007eb0(int64_t arg1, int64_t arg2)
{
    undefined (*pauVar1) [16];
    undefined8 uVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar9 = auStack_28;
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x10) = ZEXT816(0);
    pauVar1 = (undefined (*) [16])(arg1 + 0x20);
    *pauVar1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x38) = 7;
    *(undefined2 *)*pauVar1 = 0;
    uVar2 = *(undefined8 *)(arg2 + 0x20);
    *(undefined8 *)(arg2 + 0x20) = 0xffffffffffffffff;
    *(undefined8 *)(arg1 + 0x40) = uVar2;
    puVar10 = auStack_28;
    if (pauVar1 != (undefined (*) [16])arg2) {
        if (7 < *(uint64_t *)(arg1 + 0x38)) {
            iVar3 = *(int64_t *)*pauVar1;
            iVar8 = iVar3;
            puVar9 = auStack_28;
            if ((0xfff < *(uint64_t *)(arg1 + 0x38) * 2 + 2) &&
               (iVar8 = *(int64_t *)(iVar3 + -8), puVar9 = auStack_28, 0x1f < (iVar3 - iVar8) - 8U)) {
                pcVar4 = (code *)swi(0x29);
                iVar8 = (*pcVar4)(5);
                puVar9 = auStack_20;
            }
            *(undefined8 *)(puVar9 + -8) = 0x180007f49;
            fcn.180459c3c(iVar8);
        }
        *(undefined8 *)(arg1 + 0x30) = 0;
        *(undefined8 *)(arg1 + 0x38) = 7;
        *(undefined2 *)*pauVar1 = 0;
        uVar5 = *(undefined4 *)(arg2 + 4);
        uVar6 = *(undefined4 *)(arg2 + 8);
        uVar7 = *(undefined4 *)(arg2 + 0xc);
        *(undefined4 *)*pauVar1 = *(undefined4 *)arg2;
        *(undefined4 *)(arg1 + 0x24) = uVar5;
        *(undefined4 *)(arg1 + 0x28) = uVar6;
        *(undefined4 *)(arg1 + 0x2c) = uVar7;
        uVar5 = *(undefined4 *)(arg2 + 0x14);
        uVar6 = *(undefined4 *)(arg2 + 0x18);
        uVar7 = *(undefined4 *)(arg2 + 0x1c);
        *(undefined4 *)(arg1 + 0x30) = *(undefined4 *)(arg2 + 0x10);
        *(undefined4 *)(arg1 + 0x34) = uVar5;
        *(undefined4 *)(arg1 + 0x38) = uVar6;
        *(undefined4 *)(arg1 + 0x3c) = uVar7;
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 7;
        *(undefined2 *)arg2 = 0;
        puVar10 = puVar9;
    }
    *(undefined8 *)(puVar10 + -8) = 0x180007f87;
    fcn.180007d10(arg1, arg2 + 0x28, *(int64_t *)(puVar10 + 0x28));
    return arg1;
}

// ============================================================
// Function: FUN_180007fb0
// Address: 0x180007fb0
// Size: 742 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4fh
// WARNING: [rz-ghidra] Detected overlap for variable var_305h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4dh
// WARNING: [rz-ghidra] Detected overlap for variable var_314h
// WARNING: [rz-ghidra] Detected overlap for variable var_308h
// WARNING: [rz-ghidra] Detected overlap for variable var_300h
// WARNING: [rz-ghidra] Detected overlap for variable var_2f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_272h
// WARNING: [rz-ghidra] Detected overlap for variable var_270h

void fcn.180007fb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int32_t *piVar2;
    uint8_t uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined (*pauVar6) [16];
    int64_t *piVar7;
    int32_t iVar8;
    bool bVar9;
    undefined auStack_338 [32];
    int64_t var_318h;
    undefined var_308h;
    int64_t var_307h;
    int64_t var_2f8h;
    int64_t var_2e8h;
    int64_t var_2d0h;
    int64_t var_2c8h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_274h;
    char var_50h;
    undefined2 var_4fh;
    undefined var_4dh;
    int32_t var_4ch;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_338;
    iVar8 = 0;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    var_318h = arg1;
    fcn.180007340((int64_t)&var_2c8h, arg2);
    var_2a8h = -1;
    iVar5 = func_0x0001804766e0();
    if ((iVar5 == 0) || (iVar5 != var_2b8h)) {
        var_4ch = 2;
    } else {
        fcn.180007340((int64_t)&var_2e8h, (int64_t)&var_2c8h);
        _var_308h = (undefined (*) [16])0x1805aae58;
        stack0xfffffffffffffd00 = 1;
        func_0x00018000a4a0(&var_2c8h, &var_308h);
        piVar7 = &var_2c8h;
        if (7 < (uint64_t)var_2b0h) {
            piVar7 = (int64_t *)var_2c8h;
        }
        var_4ch = func_0x00018045501c(piVar7, &var_2a8h, &var_2a0h);
        iVar5 = var_2a8h;
        if (var_4ch == 0) {
            while (var_4ch = iVar8, (int16_t)var_274h == 0x2e) {
                if (((var_274h._2_2_ != 0) && ((var_274h._2_2_ != 0x2e || (var_274h._4_2_ != 0)))) ||
                   (var_4ch = func_0x000180454fdc(iVar5, &var_2a0h), var_4ch != 0)) break;
            }
        } else if (var_4ch == 2) {
            piVar7 = &var_2e8h;
            if (7 < (uint64_t)var_2d0h) {
                piVar7 = (int64_t *)var_2e8h;
            }
            uVar4 = func_0x000180455104(piVar7, &var_308h, 3, 0xffffffff);
            if (uVar4 == 0) {
                if (((uint32_t)var_2f8h >> 10 & 1) == 0) {
code_r0x00018000812d:
                    uVar4 = ((uint32_t)var_2f8h >> 4 & 1) + 2;
                    goto code_r0x000180008166;
                }
                if (var_2f8h._4_4_ == -0x5ffffff4) {
                    uVar4 = 4;
                } else {
                    if (var_2f8h._4_4_ != -0x5ffffffd) goto code_r0x00018000812d;
                    uVar4 = 10;
                }
            } else {
                if (uVar4 < 0x41) {
                    if (((uVar4 == 0x40) || (uVar4 == 2)) || (uVar4 == 3)) goto code_r0x000180008161;
                    bVar9 = uVar4 == 0x35;
code_r0x00018000815b:
                    if (bVar9) goto code_r0x000180008161;
                    uVar3 = 0;
                } else {
                    if ((uVar4 != 0x7b) && (uVar4 != 0xa1)) {
                        bVar9 = uVar4 == 0x10b;
                        goto code_r0x00018000815b;
                    }
code_r0x000180008161:
                    uVar3 = 1;
                }
                uVar4 = (uint32_t)uVar3;
code_r0x000180008166:
                if (uVar4 == 0) goto code_r0x000180008175;
            }
            if (uVar4 != 1) {
                var_4ch = 0x12;
            }
        }
code_r0x000180008175:
        fcn.18000dc80();
        if (var_4ch == 0) {
            var_50h = '\x01';
            var_4ch = 0;
            goto code_r0x0001800081a9;
        }
        if (var_4ch == 0x12) {
            var_4ch = 0;
        }
    }
    var_50h = '\0';
code_r0x0001800081a9:
    var_4fh = (undefined2)var_307h;
    var_4dh = var_307h._2_1_;
    if (var_50h != '\0') {
        pauVar6 = (undefined (*) [16])fcn.180459890(0x58);
        *pauVar6 = ZEXT816(0);
        *(undefined4 *)(*pauVar6 + 8) = 1;
        *(undefined4 *)(*pauVar6 + 0xc) = 1;
        *(undefined8 *)*pauVar6 = 0x1805ab200;
        _var_308h = pauVar6;
        fcn.180007eb0((int64_t)(pauVar6 + 1), (int64_t)&var_2c8h);
        *(undefined (**) [16])arg1 = pauVar6 + 1;
        piVar7 = *(int64_t **)(arg1 + 8);
        *(undefined (**) [16])(arg1 + 8) = pauVar6;
        if (piVar7 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar7 + 1;
            iVar8 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                (**(code **)*piVar7)(piVar7);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                iVar8 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar8 == 1) {
                    (**(code **)(*piVar7 + 8))(piVar7);
                }
            }
        }
    }
    iVar8 = var_4ch;
    func_0x000180454ffc(var_2a8h);
    fcn.18000dc80(&var_2c8h);
    *(int32_t *)arg3 = iVar8;
    *(undefined4 *)(arg3 + 4) = var_318h._4_4_;
    *(undefined8 *)(arg3 + 8) = 0x1806a45e0;
    func_0x000180459870(var_48h ^ (uint64_t)auStack_338);
    return;
}

// ============================================================
// Function: FUN_1800082a0
// Address: 0x1800082a0
// Size: 35 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_23ah
// WARNING: [rz-ghidra] Detected overlap for variable var_238h

int64_t fcn.1800082a0(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    
    iVar2 = fcn.180007c30(arg1);
    if (iVar2 == 0) {
        return arg1;
    }
    fcn.180007960();
    pcVar1 = (code *)swi(3);
    iVar3 = (*pcVar1)();
    return iVar3;
}

