// Chunk 158 - 50 functions

// ============================================================
// Function: FUN_18020eb08
// Address: 0x18020eb08
// Size: 212 bytes
// ============================================================
void fcn.18020eb08(int64_t arg1, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_b0h,
                  int64_t arg_b8h)
{
    int32_t in_EAX;
    int32_t iVar1;
    int64_t *piVar2;
    undefined8 *unaff_RDI;
    int64_t var_20h;
    
    if ((in_EAX < 1) && (*(int64_t *)(arg1 + 0x70) != 0)) {
        arg_50h = 0;
        arg_58h._0_4_ = 0;
        arg_60h = 0;
        arg_68h = 0;
        arg_70h = 0;
        arg_78h = 0;
        arg_80h._0_4_ = 0;
        arg_88h = 0;
        arg_90h = 0;
        arg_98h = 0;
        piVar2 = (int64_t *)fcn.180229cc0(&var_20h, 0x1804bb2f4, &arg_b0h);
        arg_50h = *piVar2;
        arg_58h._0_4_ = *(undefined4 *)(piVar2 + 1);
        arg_58h._4_4_ = *(undefined4 *)((int64_t)piVar2 + 0xc);
        arg_60h = piVar2[2];
        arg_68h = piVar2[3];
        arg_70h = piVar2[4];
        iVar1 = fcn.180280760(*unaff_RDI, unaff_RDI[0x16], &arg_50h);
        if ((0 < iVar1) && (iVar1 = fcn.180229fc0(arg_68h, arg_70h), iVar1 != 0)) {
            *(int32_t *)(unaff_RDI + 0xd) = (int32_t)arg_b0h;
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020ebdc
// Address: 0x18020ebdc
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_b8h

void fcn.18020eb08(int64_t arg1, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_b0h,
                  int64_t arg_b8h)
{
    int32_t in_EAX;
    int32_t iVar1;
    int64_t *piVar2;
    undefined8 *unaff_RDI;
    int64_t var_20h;
    
    if ((in_EAX < 1) && (*(int64_t *)(arg1 + 0x70) != 0)) {
        arg_50h = 0;
        arg_58h._0_4_ = 0;
        arg_60h = 0;
        arg_68h = 0;
        arg_70h = 0;
        arg_78h = 0;
        arg_80h._0_4_ = 0;
        arg_88h = 0;
        arg_90h = 0;
        arg_98h = 0;
        piVar2 = (int64_t *)fcn.180229cc0(&var_20h, 0x1804bb2f4, &arg_b0h);
        arg_50h = *piVar2;
        arg_58h._0_4_ = *(undefined4 *)(piVar2 + 1);
        arg_58h._4_4_ = *(undefined4 *)((int64_t)piVar2 + 0xc);
        arg_60h = piVar2[2];
        arg_68h = piVar2[3];
        arg_70h = piVar2[4];
        iVar1 = fcn.180280760(*unaff_RDI, unaff_RDI[0x16], &arg_50h);
        if ((0 < iVar1) && (iVar1 = fcn.180229fc0(arg_68h, arg_70h), iVar1 != 0)) {
            *(int32_t *)(unaff_RDI + 0xd) = (int32_t)arg_b0h;
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020ec00
// Address: 0x18020ec00
// Size: 189 bytes
// ============================================================
undefined4
fcn.18020ec00(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_a8h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    undefined4 uVar8;
    undefined8 *in_RCX;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020ec0c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined4 *)((int64_t)&arg_a8h + iVar6) = *(undefined4 *)(in_RCX + 0xb);
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = 0;
    *(undefined4 *)((int64_t)&arg_50h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_70h + iVar6) = 0;
    *(undefined4 *)((int64_t)&arg_78h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_90h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020ec73;
    puVar7 = (undefined4 *)fcn.180229d80((int64_t)&var_18h + iVar6, 0x1804bb37c, (int64_t)&arg_a8h + iVar6);
    uVar1 = in_RCX[0x16];
    uVar2 = *in_RCX;
    uVar8 = puVar7[1];
    uVar3 = puVar7[2];
    uVar4 = puVar7[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar6) = *puVar7;
    *(undefined4 *)((int64_t)&arg_48h + iVar6 + 4) = uVar8;
    *(undefined4 *)((int64_t)&arg_50h + iVar6) = uVar3;
    *(undefined4 *)((int64_t)&arg_50h + iVar6 + 4) = uVar4;
    uVar8 = puVar7[5];
    uVar3 = puVar7[6];
    uVar4 = puVar7[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar6) = puVar7[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar6 + 4) = uVar8;
    *(undefined4 *)((int64_t)&arg_60h + iVar6) = uVar3;
    *(undefined4 *)((int64_t)&arg_60h + iVar6 + 4) = uVar4;
    *(undefined8 *)((int64_t)&arg_68h + iVar6) = *(undefined8 *)(puVar7 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020eca3;
    iVar5 = fcn.180280760(uVar2, uVar1, (int64_t)&arg_48h + iVar6);
    uVar8 = 0xffffffff;
    if (iVar5 != 0) {
        uVar8 = *(undefined4 *)((int64_t)&arg_a8h + iVar6);
    }
    return uVar8;
}

// ============================================================
// Function: FUN_18020ecc0
// Address: 0x18020ecc0
// Size: 195 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined4
fcn.18020ecc0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_a8h, int64_t arg_b0h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    undefined8 *in_RCX;
    undefined4 uVar9;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020ecd0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&arg_a8h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined4 *)((int64_t)&arg_50h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_70h + iVar7) = 0;
    *(undefined4 *)((int64_t)&arg_78h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_80h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_90h + iVar7) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ed35;
    puVar8 = (undefined4 *)fcn.180229cc0((int64_t)&var_18h + iVar7, 0x1804bb364, (int64_t)&arg_a8h + iVar7);
    uVar1 = in_RCX[0x16];
    uVar2 = *in_RCX;
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
    *(undefined4 *)((int64_t)&arg_50h + iVar7) = uVar4;
    *(undefined4 *)((int64_t)&arg_50h + iVar7 + 4) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
    *(undefined4 *)((int64_t)&arg_60h + iVar7) = uVar4;
    *(undefined4 *)((int64_t)&arg_60h + iVar7 + 4) = uVar5;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ed65;
    iVar6 = fcn.180280760(uVar2, uVar1, (int64_t)&arg_48h + iVar7);
    if (iVar6 == 1) {
        uVar9 = *(undefined4 *)((int64_t)&arg_a8h + iVar7);
    }
    return uVar9;
}

// ============================================================
// Function: FUN_18020ed90
// Address: 0x18020ed90
// Size: 200 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18020ed90(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_a8h, int64_t arg_b0h,
                  int64_t arg_160h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    undefined8 *in_RCX;
    undefined4 in_EDX;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020eda0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined4 *)((int64_t)&arg_b0h + iVar7) = in_EDX;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined4 *)((int64_t)&arg_50h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_70h + iVar7) = 0;
    *(undefined4 *)((int64_t)&arg_78h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_80h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_90h + iVar7) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ee04;
    puVar8 = (undefined4 *)fcn.180229d80((int64_t)&var_18h + iVar7, 0x1804bb37c, (int64_t)&arg_b0h + iVar7);
    uVar1 = in_RCX[0x16];
    uVar2 = *in_RCX;
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
    *(undefined4 *)((int64_t)&arg_50h + iVar7) = uVar4;
    *(undefined4 *)((int64_t)&arg_50h + iVar7 + 4) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
    *(undefined4 *)((int64_t)&arg_60h + iVar7) = uVar4;
    *(undefined4 *)((int64_t)&arg_60h + iVar7 + 4) = uVar5;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ee34;
    iVar6 = fcn.1802807b0(uVar2, uVar1, (int64_t)&arg_48h + iVar7);
    if (iVar6 != 0) {
        *(undefined4 *)(in_RCX + 0xb) = *(undefined4 *)((int64_t)&arg_b0h + iVar7);
    }
    return iVar6 != 0;
}

// ============================================================
// Function: FUN_18020ee70
// Address: 0x18020ee70
// Size: 25 bytes
// ============================================================
void fcn.18020ee70(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h, int64_t arg_70h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    uint32_t uVar14;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar15;
    undefined8 unaff_R14;
    int64_t var_90h;
    int64_t var_88h;
    undefined4 auStack_80 [2];
    int64_t var_78h;
    undefined4 auStack_70 [2];
    int64_t var_68h;
    int64_t var_60h;
    undefined4 auStack_58 [2];
    int64_t var_50h;
    undefined4 auStack_48 [2];
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t iStack_8;
    
    iStack_8 = 0x18020ee7a;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    iVar15 = 0;
    *(undefined8 *)(&stack0x00000020 + iVar11) = unaff_RBP;
    *(undefined8 *)(&stack0x00000018 + iVar11) = unaff_RBX;
    *(undefined8 *)(&stack0x00000010 + iVar11) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar11) = unaff_RDI;
    *(undefined8 *)(&stack0x00000020 + iVar11 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)&iStack_8 + iVar11) = 0x18020fcb6;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    *(uint64_t *)((int64_t)&var_10h + iVar11) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000020 + iVar12 + iVar11 + -0x20);
    if ((in_RCX == (int64_t *)0x0) || (iVar1 = *in_RCX, iVar1 == 0)) {
code_r0x00018020fef3:
        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fef8;
        fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020ff10;
        fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_30h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000038 + iVar12 + iVar11), *(int64_t *)(&stack0x00000050 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020ff22;
        func_0x0001802296d0(6, 0x7a, 0);
    } else {
        pcVar2 = *(code **)(iVar1 + 0x40);
        if (pcVar2 == (code *)0x0) {
            if ((*(uint32_t *)(iVar1 + 0x10) >> 0x18 & 1) == 0) {
                uVar14 = *(uint32_t *)(iVar1 + 0x10) & 0xf0007;
                if (uVar14 == 6) {
                    if ((in_RDX == 0) || (iVar15 == 0)) {
                        iVar8 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fdc9;
                        iVar8 = func_0x00018027ce70(in_RDX, (int64_t)&var_30h + iVar11, 0, 0x10);
                        if (iVar8 < 1) {
                            iVar8 = -1;
                        } else {
                            *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fded;
                            func_0x00018027ce70(in_RDX, (int64_t)&var_30h + iVar11, (int64_t)&var_20h + iVar11, iVar8);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fdfc;
                            func_0x000180498030(iVar15, (int64_t)&var_20h + iVar11, (int64_t)iVar8);
                            *(int32_t *)(iVar15 + 0x10) = iVar8;
                        }
                    }
                    goto code_r0x00018020feea;
                }
                if ((uVar14 != 7) && (uVar14 != 0x10001)) {
                    if (uVar14 == 0x10002) goto code_r0x00018020ff66;
                    if (uVar14 != 0x10003) {
                        uVar14 = 0;
                        if (in_RDX != 0) {
                            *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fd4b;
                            uVar9 = func_0x00018020e980(in_RCX);
                            if (uVar9 < 0x11) {
                                *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fd62;
                                uVar14 = func_0x00018027ccd0(in_RDX, (int64_t)&var_30h + iVar11, uVar9);
                                if (uVar14 == uVar9) {
                                    *(undefined4 *)((int64_t)&arg_28h + iVar12 + iVar11) = 0xffffffff;
                                    *(int64_t *)(&stack0x00000020 + iVar12 + iVar11) = (int64_t)&var_30h + iVar11;
                                    *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fd8a;
                                    iVar8 = func_0x000180211b70(in_RCX, 0, 0, 0);
                                    if (iVar8 != 0) goto code_r0x00018020fd93;
                                }
                            }
                            uVar14 = 0xffffffff;
                        }
code_r0x00018020fd93:
                        iVar8 = ((int32_t)uVar14 >> 0x1f & 0xfffffffeU) + 1;
                        goto code_r0x00018020feea;
                    }
                }
            } else if (*(int64_t *)(iVar1 + 0x70) != 0) {
                *(undefined8 *)((int64_t)&var_30h + iVar11) = 0;
                iVar8 = -1;
                *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fe2f;
                iVar10 = func_0x000180228af0(in_RDX, (int64_t)&var_30h + iVar11);
                if (-1 < iVar10) {
                    uVar3 = *(undefined8 *)((int64_t)&var_30h + iVar11);
                    *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fe52;
                    puVar13 = (undefined4 *)
                              func_0x000180229c70((int64_t)&arg_30h + iVar12 + iVar11, 0x1804bb3e8, uVar3, 
                                                  (int64_t)iVar10);
                    uVar3 = *(undefined8 *)((int64_t)&var_30h + iVar11);
                    uVar5 = puVar13[1];
                    uVar6 = puVar13[2];
                    uVar7 = puVar13[3];
                    *(undefined4 *)((int64_t)&arg_60h + iVar12 + iVar11) = *puVar13;
                    *(undefined4 *)((int64_t)&arg_60h + iVar12 + iVar11 + 4) = uVar5;
                    *(undefined4 *)(&stack0x00000068 + iVar12 + iVar11) = uVar6;
                    *(undefined4 *)(&stack0x0000006c + iVar12 + iVar11) = uVar7;
                    uVar5 = puVar13[5];
                    uVar6 = puVar13[6];
                    uVar7 = puVar13[7];
                    *(undefined4 *)((int64_t)&arg_70h + iVar12 + iVar11) = puVar13[4];
                    *(undefined4 *)((int64_t)&arg_70h + iVar12 + iVar11 + 4) = uVar5;
                    *(undefined4 *)(&stack0x00000078 + iVar12 + iVar11) = uVar6;
                    *(undefined4 *)(&stack0x0000007c + iVar12 + iVar11) = uVar7;
                    *(undefined8 *)((int64_t)&var_90h + iVar11) = *(undefined8 *)(puVar13 + 8);
                    *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fe85;
                    puVar13 = (undefined4 *)
                              func_0x000180229c70((int64_t)&arg_30h + iVar12 + iVar11, 0x1804bb350, uVar3, 
                                                  (int64_t)iVar10);
                    uVar5 = puVar13[1];
                    uVar6 = puVar13[2];
                    uVar7 = puVar13[3];
                    *(undefined4 *)((int64_t)auStack_80 + iVar11 + -8) = *puVar13;
                    *(undefined4 *)((int64_t)auStack_80 + iVar11 + -4) = uVar5;
                    *(undefined4 *)((int64_t)auStack_80 + iVar11) = uVar6;
                    *(undefined4 *)((int64_t)auStack_80 + iVar11 + 4) = uVar7;
                    uVar5 = puVar13[5];
                    uVar6 = puVar13[6];
                    uVar7 = puVar13[7];
                    *(undefined4 *)((int64_t)auStack_70 + iVar11 + -8) = puVar13[4];
                    *(undefined4 *)((int64_t)auStack_70 + iVar11 + -4) = uVar5;
                    *(undefined4 *)((int64_t)auStack_70 + iVar11) = uVar6;
                    *(undefined4 *)((int64_t)auStack_70 + iVar11 + 4) = uVar7;
                    *(undefined8 *)((int64_t)&var_68h + iVar11) = *(undefined8 *)(puVar13 + 8);
                    *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fea8;
                    puVar13 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_30h + iVar12 + iVar11);
                    uVar5 = puVar13[1];
                    uVar6 = puVar13[2];
                    uVar7 = puVar13[3];
                    *(undefined4 *)((int64_t)auStack_58 + iVar11 + -8) = *puVar13;
                    *(undefined4 *)((int64_t)auStack_58 + iVar11 + -4) = uVar5;
                    *(undefined4 *)((int64_t)auStack_58 + iVar11) = uVar6;
                    *(undefined4 *)((int64_t)auStack_58 + iVar11 + 4) = uVar7;
                    uVar5 = puVar13[5];
                    uVar6 = puVar13[6];
                    uVar7 = puVar13[7];
                    *(undefined4 *)((int64_t)auStack_48 + iVar11 + -8) = puVar13[4];
                    *(undefined4 *)((int64_t)auStack_48 + iVar11 + -4) = uVar5;
                    *(undefined4 *)((int64_t)auStack_48 + iVar11) = uVar6;
                    *(undefined4 *)((int64_t)auStack_48 + iVar11 + 4) = uVar7;
                    *(undefined8 *)((int64_t)&var_40h + iVar11) = *(undefined8 *)(puVar13 + 8);
                    *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fece;
                    iVar8 = func_0x000180211920(in_RCX, (int64_t)&arg_60h + iVar12 + iVar11);
                }
                uVar3 = *(undefined8 *)((int64_t)&var_30h + iVar11);
                *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fee7;
                func_0x000180224990(uVar3, 0x1804bb240, 0x4fa);
                goto code_r0x00018020feea;
            }
        } else {
            *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fcf6;
            iVar8 = (*pcVar2)();
code_r0x00018020feea:
            if (iVar8 != -2) {
                if (0 < iVar8) goto code_r0x00018020ff66;
                goto code_r0x00018020fef3;
            }
        }
        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020ff33;
        fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020ff4b;
        fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_30h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000038 + iVar12 + iVar11), *(int64_t *)(&stack0x00000050 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020ff5d;
        func_0x0001802296d0(6, 0x6b, 0);
    }
code_r0x00018020ff66:
    uVar4 = *(uint64_t *)((int64_t)&var_10h + iVar11);
    *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020ff72;
    func_0x000180459870(uVar4 ^ (uint64_t)(&stack0x00000020 + iVar12 + iVar11 + -0x20));
    return;
}

// ============================================================
// Function: FUN_18020ee90
// Address: 0x18020ee90
// Size: 38 bytes
// ============================================================
int64_t fcn.18020ee90(undefined4 *param_1)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(param_1 + 0x18) != 0) {
        return *(int64_t *)(param_1 + 0x18);
    }
    uVar1 = *param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x18022ccfa;
    iVar3 = fcn.18045a350(uVar1);
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022cd02;
    piVar4 = (int64_t *)
             fcn.18022cba0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                           *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                           *(int64_t *)(&stack0x00000060 + iVar3 + iVar2), 
                           *(int64_t *)(&stack0x00000080 + iVar3 + iVar2));
    if (piVar4 == (int64_t *)0x0) {
        return 0;
    }
    return *piVar4;
}

// ============================================================
// Function: FUN_18020eed0
// Address: 0x18020eed0
// Size: 159 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18020eed0(int64_t arg_28h, int64_t arg_68h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18020eee2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_28h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3);
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18020ef06;
        uVar1 = func_0x00018020e980();
        if (uVar1 < 0x11) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18020ef1d;
            uVar2 = func_0x00018027ccd0(in_RDX, (int64_t)&var_18h + iVar3, uVar1);
            if (uVar2 == uVar1) {
                *(undefined4 *)((int64_t)&var_10h + iVar3) = 0xffffffff;
                *(int64_t *)((int64_t)&var_8h + iVar3) = (int64_t)&var_18h + iVar3;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18020ef45;
                func_0x000180211b70(in_RCX, 0, 0, 0);
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18020ef5f;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_18020efe0
// Address: 0x18020efe0
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.18020efe0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020eff0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RCX == (int32_t *)0x0) {
        iVar5 = 0;
    } else {
        iVar5 = *in_RCX;
        if (iVar5 < 0x1a6) {
            if (iVar5 == 0x1a5) {
code_r0x00018020f0bc:
                return 0x1a5;
            }
    // switch table (162 cases) at 0x18020f0fc
            switch(iVar5) {
            case 5:
            case 0x61:
                return 5;
            case 0x1e:
            case 0x3d:
                goto code_r0x00018020f0ec;
            case 0x25:
            case 0x62:
            case 0xa6:
                return 0x25;
            }
        } else {
    // switch table (235 cases) at 0x18020f1b0
            switch(iVar5) {
            case 0x1a9:
            case 0x28b:
            case 0x28e:
                return 0x1a9;
            case 0x1ad:
            case 0x28c:
            case 0x28f:
                return 0x1ad;
            case 0x28a:
            case 0x28d:
                goto code_r0x00018020f0bc;
            case 0x290:
            case 0x291:
            case 0x292:
            case 0x293:
code_r0x00018020f0ec:
                return 0x1e;
            }
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020f008;
    uVar2 = fcn.18022cba0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020f013;
    iVar3 = fcn.18022ca20(uVar2);
    iVar4 = 0;
    if (iVar3 != 0) {
        iVar4 = iVar5;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020f021;
    fcn.18027c100(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    return iVar4;
}

// ============================================================
// Function: FUN_18020effe
// Address: 0x18020effe
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.18020efe0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020eff0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RCX == (int32_t *)0x0) {
        iVar5 = 0;
    } else {
        iVar5 = *in_RCX;
        if (iVar5 < 0x1a6) {
            if (iVar5 == 0x1a5) {
code_r0x00018020f0bc:
                return 0x1a5;
            }
    // switch table (162 cases) at 0x18020f0fc
            switch(iVar5) {
            case 5:
            case 0x61:
                return 5;
            case 0x1e:
            case 0x3d:
                goto code_r0x00018020f0ec;
            case 0x25:
            case 0x62:
            case 0xa6:
                return 0x25;
            }
        } else {
    // switch table (235 cases) at 0x18020f1b0
            switch(iVar5) {
            case 0x1a9:
            case 0x28b:
            case 0x28e:
                return 0x1a9;
            case 0x1ad:
            case 0x28c:
            case 0x28f:
                return 0x1ad;
            case 0x28a:
            case 0x28d:
                goto code_r0x00018020f0bc;
            case 0x290:
            case 0x291:
            case 0x292:
            case 0x293:
code_r0x00018020f0ec:
                return 0x1e;
            }
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020f008;
    uVar2 = fcn.18022cba0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020f013;
    iVar3 = fcn.18022ca20(uVar2);
    iVar4 = 0;
    if (iVar3 != 0) {
        iVar4 = iVar5;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020f021;
    fcn.18027c100(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    return iVar4;
}

// ============================================================
// Function: FUN_18020f033
// Address: 0x18020f033
// Size: 636 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.18020efe0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020eff0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RCX == (int32_t *)0x0) {
        iVar5 = 0;
    } else {
        iVar5 = *in_RCX;
        if (iVar5 < 0x1a6) {
            if (iVar5 == 0x1a5) {
code_r0x00018020f0bc:
                return 0x1a5;
            }
    // switch table (162 cases) at 0x18020f0fc
            switch(iVar5) {
            case 5:
            case 0x61:
                return 5;
            case 0x1e:
            case 0x3d:
                goto code_r0x00018020f0ec;
            case 0x25:
            case 0x62:
            case 0xa6:
                return 0x25;
            }
        } else {
    // switch table (235 cases) at 0x18020f1b0
            switch(iVar5) {
            case 0x1a9:
            case 0x28b:
            case 0x28e:
                return 0x1a9;
            case 0x1ad:
            case 0x28c:
            case 0x28f:
                return 0x1ad;
            case 0x28a:
            case 0x28d:
                goto code_r0x00018020f0bc;
            case 0x290:
            case 0x291:
            case 0x292:
            case 0x293:
code_r0x00018020f0ec:
                return 0x1e;
            }
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020f008;
    uVar2 = fcn.18022cba0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020f013;
    iVar3 = fcn.18022ca20(uVar2);
    iVar4 = 0;
    if (iVar3 != 0) {
        iVar4 = iVar5;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020f021;
    fcn.18027c100(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    return iVar4;
}

// ============================================================
// Function: FUN_18020f2b0
// Address: 0x18020f2b0
// Size: 98 bytes
// ============================================================
bool fcn.18020f2b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t iVar5;
    undefined8 in_RDX;
    undefined8 uVar6;
    undefined *puVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 uStackX_18;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020f2bc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        return false;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x70);
    if (iVar5 == 0) {
        iVar4 = *(int64_t *)(in_RCX + 0x60);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020f2fe;
            iVar4 = fcn.18022ccf0();
        }
        iVar1 = 0;
        iVar5 = 0;
        uVar6 = *(undefined8 *)((int64_t)&uStackX_18 + iVar3);
        puVar7 = auStackX_20 + iVar3;
    } else {
        iVar1 = *(int32_t *)(in_RCX + 0x58);
        iVar4 = 0;
        uVar6 = *(undefined8 *)((int64_t)&uStackX_18 + iVar3);
        puVar7 = auStackX_20 + iVar3;
    }
    *(undefined8 *)(puVar7 + 8) = uVar6;
    *(undefined8 *)(puVar7 + 0x10) = unaff_RBP;
    *(undefined8 *)(puVar7 + 0x18) = unaff_RSI;
    *(undefined8 *)(puVar7 + 0x20) = unaff_RDI;
    *(undefined8 *)(puVar7 + -8) = unaff_R14;
    *(undefined8 *)(puVar7 + -0x10) = 0x180280ec0;
    iVar3 = fcn.18045a350(iVar5, iVar1, iVar4, in_RDX);
    iVar3 = -iVar3;
    *(undefined8 *)(puVar7 + iVar3 + -0x10) = 0x180280ed3;
    fcn.18027f1e0();
    *(undefined8 *)(puVar7 + iVar3 + -0x10) = 0x180280edb;
    fcn.180299670(*(int64_t *)(puVar7 + iVar3 + 0x18), *(int64_t *)(puVar7 + iVar3 + 0x28), 
                  *(int64_t *)(puVar7 + iVar3 + 0x30), *(int64_t *)(puVar7 + iVar3 + 0x48), 
                  *(int64_t *)(puVar7 + iVar3 + 0x50), *(int64_t *)(puVar7 + iVar3 + 0x58), 
                  *(int64_t *)(puVar7 + iVar3 + 0x60), *(int64_t *)(puVar7 + iVar3 + 0xa8));
    if (iVar5 == 0) {
        *(undefined8 *)(puVar7 + iVar3 + -0x10) = 0x180280eee;
        iVar1 = fcn.1802993f0(*(int64_t *)(puVar7 + iVar3 + 0x18), *(int64_t *)(puVar7 + iVar3 + 0x28), 
                              *(int64_t *)(puVar7 + iVar3 + 0x38), *(int64_t *)(puVar7 + iVar3 + 0x48), 
                              *(int64_t *)(puVar7 + iVar3 + 0x58), *(int64_t *)(puVar7 + iVar3 + 0x80));
    }
    *(undefined8 *)(puVar7 + iVar3 + -0x10) = 0x180280efb;
    iVar2 = fcn.1802993f0(*(int64_t *)(puVar7 + iVar3 + 0x18), *(int64_t *)(puVar7 + iVar3 + 0x28), 
                          *(int64_t *)(puVar7 + iVar3 + 0x38), *(int64_t *)(puVar7 + iVar3 + 0x48), 
                          *(int64_t *)(puVar7 + iVar3 + 0x58), *(int64_t *)(puVar7 + iVar3 + 0x80));
    return iVar2 == iVar1;
}

// ============================================================
// Function: FUN_18020f320
// Address: 0x18020f320
// Size: 25 bytes
// ============================================================
void fcn.18020f320(int64_t arg_28h, int64_t arg_e8h, int64_t arg_140h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    code *pcVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t iVar13;
    int64_t iVar14;
    uint32_t uVar15;
    undefined8 *in_RCX;
    uint64_t uVar16;
    int64_t in_RDX;
    uint64_t uVar17;
    undefined8 unaff_RBX;
    undefined8 uVar18;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 auStack_48 [2];
    int64_t var_40h;
    undefined4 auStack_38 [2];
    int64_t var_30h;
    int64_t var_20h;
    undefined8 uStack_10;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020f32a;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    iVar13 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar10) = unaff_RBP;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar10 + -8) = unaff_RBX;
    *(undefined8 *)(&stack0x00000010 + iVar10) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar10) = unaff_RDI;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar10 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_8 + iVar10) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x180210308;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    *(uint64_t *)((int64_t)&var_20h + iVar10) = *(uint64_t *)0x1806a3940 ^ (int64_t)&uStack_8 + iVar11 + iVar10;
    if ((in_RCX == (undefined8 *)0x0) || (puVar12 = (undefined4 *)*in_RCX, puVar12 == (undefined4 *)0x0)) {
code_r0x0001802106a6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x1802106ab;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar11 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar11 + iVar10));
        *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x1802106c3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar11 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar11 + iVar10), 
                      *(int64_t *)((int64_t)&arg_28h + iVar11 + iVar10), 
                      *(int64_t *)(&stack0x00000030 + iVar11 + iVar10), *(int64_t *)(&stack0x00000048 + iVar11 + iVar10)
                     );
        *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x1802106d5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar11 + iVar10), *(int64_t *)(&stack0x00000038 + iVar11 + iVar10)
                      , *(int64_t *)(&stack0x00000060 + iVar11 + iVar10));
    } else {
        pcVar4 = *(code **)(puVar12 + 0xe);
        if (pcVar4 == (code *)0x0) {
            if (((uint32_t)puVar12[4] >> 0x18 & 1) == 0) {
                uVar15 = puVar12[4] & 0xf0007;
                if (uVar15 == 6) {
                    if ((in_RDX == 0) || (iVar13 == 0)) {
                        iVar8 = 0;
                    } else {
                        uVar2 = *(undefined4 *)(iVar13 + 0x10);
                        uVar3 = *(undefined4 *)(iVar13 + 0x14);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x1802104ce;
                        iVar8 = func_0x00018027cf70(in_RDX, uVar3, iVar13, uVar2);
                    }
                    goto code_r0x00018021069d;
                }
                if ((uVar15 != 7) && (uVar15 != 0x10001)) {
                    if (uVar15 == 0x10002) {
                        uVar16 = *(uint64_t *)(puVar12 + 0x1c);
                        if (uVar16 == 0) {
                            iVar13 = *(int64_t *)(puVar12 + 0x18);
                            if (iVar13 == 0) {
                                uVar2 = *puVar12;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x18021047b;
                                iVar13 = fcn.18022ccf0(uVar2);
                            }
                            uVar16 = 0;
                            uVar17 = uVar16;
                        } else {
                            iVar13 = 0;
                            uVar17 = (uint64_t)(uint32_t)puVar12[0x16];
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210493;
                        iVar8 = func_0x000180280ea0(uVar16, uVar17, iVar13, 0x1804bb280);
                        if (iVar8 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x1802104a7;
                            func_0x00018025fc10(in_RDX, 5, 0);
                        }
                        goto code_r0x000180210719;
                    }
                    if (uVar15 != 0x10003) {
                        uVar18 = 0;
                        iVar8 = 0;
                        if (in_RDX != 0) {
                            *(undefined8 *)((int64_t)&var_a0h + iVar10) = 0;
                            *(undefined8 **)((int64_t)&var_18h + iVar11 + iVar10) = in_RCX + 3;
                            *(undefined4 *)((int64_t)&var_98h + iVar10) = 0;
                            *(undefined8 *)((int64_t)&var_90h + iVar10) = 0;
                            *(undefined8 *)((int64_t)&var_88h + iVar10) = 0;
                            *(undefined8 *)((int64_t)&var_80h + iVar10) = 0;
                            *(undefined8 *)((int64_t)&var_78h + iVar10) = 0;
                            *(undefined4 *)((int64_t)&var_70h + iVar10) = 0;
                            *(undefined8 *)((int64_t)&var_68h + iVar10) = 0;
                            *(undefined8 *)((int64_t)&var_60h + iVar10) = 0;
                            *(undefined8 *)((int64_t)&var_58h + iVar10) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x1802103e8;
                            puVar12 = (undefined4 *)
                                      func_0x000180229c20((int64_t)&arg_28h + iVar11 + iVar10, 0x1804bb36c, 
                                                          (int64_t)&var_18h + iVar11 + iVar10, 0x10);
                            uVar5 = in_RCX[0x16];
                            uVar6 = *in_RCX;
                            uVar2 = puVar12[1];
                            uVar3 = puVar12[2];
                            uVar7 = puVar12[3];
                            *(undefined4 *)((int64_t)&var_a0h + iVar10) = *puVar12;
                            *(undefined4 *)((int64_t)&var_a0h + iVar10 + 4) = uVar2;
                            *(undefined4 *)((int64_t)&var_98h + iVar10) = uVar3;
                            *(undefined4 *)((int64_t)&var_98h + iVar10 + 4) = uVar7;
                            uVar2 = puVar12[5];
                            uVar3 = puVar12[6];
                            uVar7 = puVar12[7];
                            *(undefined4 *)((int64_t)&var_90h + iVar10) = puVar12[4];
                            *(undefined4 *)((int64_t)&var_90h + iVar10 + 4) = uVar2;
                            *(undefined4 *)((int64_t)&var_88h + iVar10) = uVar3;
                            *(undefined4 *)((int64_t)&var_88h + iVar10 + 4) = uVar7;
                            *(undefined8 *)((int64_t)&var_80h + iVar10) = *(undefined8 *)(puVar12 + 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210414;
                            iVar8 = fcn.180280760(uVar6, uVar5, (int64_t)&var_a0h + iVar10);
                            if (iVar8 != 0) {
                                uVar18 = *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar10);
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210424;
                            uVar15 = func_0x00018020e980(in_RCX);
                            if (0x10 < uVar15) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210444;
                                func_0x00018027bb50(0x1804bb258, 0x1804bb240, 0x4b);
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210452;
                            iVar8 = func_0x00018027cdf0(in_RDX, uVar18, uVar15);
                        }
                        goto code_r0x00018021069d;
                    }
                }
            } else if (*(int64_t *)(puVar12 + 0x1c) != 0) {
                *(undefined8 *)((int64_t)&arg_140h + iVar11 + iVar10) = unaff_R12;
                iVar8 = -1;
                iVar13 = 0;
                *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar10) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210516;
                puVar12 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar11 + iVar10, 0x1804bb3e8, 0, 0);
                uVar2 = puVar12[1];
                uVar3 = puVar12[2];
                uVar7 = puVar12[3];
                *(undefined4 *)((int64_t)&var_a0h + iVar10) = *puVar12;
                *(undefined4 *)((int64_t)&var_a0h + iVar10 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_98h + iVar10) = uVar3;
                *(undefined4 *)((int64_t)&var_98h + iVar10 + 4) = uVar7;
                uVar2 = puVar12[5];
                uVar3 = puVar12[6];
                uVar7 = puVar12[7];
                *(undefined4 *)((int64_t)&var_90h + iVar10) = puVar12[4];
                *(undefined4 *)((int64_t)&var_90h + iVar10 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_88h + iVar10) = uVar3;
                *(undefined4 *)((int64_t)&var_88h + iVar10 + 4) = uVar7;
                *(undefined8 *)((int64_t)&var_80h + iVar10) = *(undefined8 *)(puVar12 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210546;
                puVar12 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar11 + iVar10, 0x1804bb350, 0, 0);
                uVar2 = puVar12[1];
                uVar3 = puVar12[2];
                uVar7 = puVar12[3];
                *(undefined4 *)((int64_t)&var_78h + iVar10) = *puVar12;
                *(undefined4 *)((int64_t)&var_78h + iVar10 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_70h + iVar10) = uVar3;
                *(undefined4 *)((int64_t)&var_70h + iVar10 + 4) = uVar7;
                uVar2 = puVar12[5];
                uVar3 = puVar12[6];
                uVar7 = puVar12[7];
                *(undefined4 *)((int64_t)&var_68h + iVar10) = puVar12[4];
                *(undefined4 *)((int64_t)&var_68h + iVar10 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_60h + iVar10) = uVar3;
                *(undefined4 *)((int64_t)&var_60h + iVar10 + 4) = uVar7;
                *(undefined8 *)((int64_t)&var_58h + iVar10) = *(undefined8 *)(puVar12 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210569;
                puVar12 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_28h + iVar11 + iVar10);
                uVar2 = puVar12[1];
                uVar3 = puVar12[2];
                uVar7 = puVar12[3];
                *(undefined4 *)((int64_t)auStack_48 + iVar10 + -8) = *puVar12;
                *(undefined4 *)((int64_t)auStack_48 + iVar10 + -4) = uVar2;
                *(undefined4 *)((int64_t)auStack_48 + iVar10) = uVar3;
                *(undefined4 *)((int64_t)auStack_48 + iVar10 + 4) = uVar7;
                uVar2 = puVar12[5];
                uVar3 = puVar12[6];
                uVar7 = puVar12[7];
                *(undefined4 *)((int64_t)auStack_38 + iVar10 + -8) = puVar12[4];
                *(undefined4 *)((int64_t)auStack_38 + iVar10 + -4) = uVar2;
                *(undefined4 *)((int64_t)auStack_38 + iVar10) = uVar3;
                *(undefined4 *)((int64_t)auStack_38 + iVar10 + 4) = uVar7;
                *(undefined8 *)((int64_t)&var_30h + iVar10) = *(undefined8 *)(puVar12 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x18021058e;
                iVar9 = func_0x000180211450(in_RCX, (int64_t)&var_a0h + iVar10);
                if (iVar9 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x18021059f;
                    iVar9 = func_0x00018022aed0((int64_t)&var_a0h + iVar10);
                    iVar14 = 0xffffffff;
                    if ((iVar9 != 0) && (iVar14 = 0xffffffff, *(int64_t *)((int64_t)&var_80h + iVar10) != 0)) {
                        iVar14 = iVar13;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x1802105b3;
                    iVar9 = func_0x00018022aed0((int64_t)&var_78h + iVar10);
                    if ((iVar9 == 0) || (*(int64_t *)((int64_t)&var_58h + iVar10) == 0)) {
                        if ((int32_t)iVar14 < 0) goto code_r0x00018021067d;
                    } else {
                        iVar14 = 1;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar11 + iVar10) = in_RDX;
                    *(undefined8 *)((int64_t)&arg_e8h + iVar11 + iVar10) = unaff_R13;
                    uVar16 = *(uint64_t *)((int64_t)&var_80h + iVar14 * 0x28 + iVar10);
                    puVar1 = (undefined8 *)((int64_t)&var_a0h + iVar14 * 0x28 + iVar10);
                    uVar18 = *puVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210608;
                    iVar13 = func_0x0001802248d0(uVar16, 0x1804bb240, 0x52b);
                    if (iVar13 != 0) {
                        *(int64_t *)((int64_t)&iStackX_20 + iVar11 + iVar10) = iVar13;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210628;
                        puVar12 = (undefined4 *)
                                  func_0x000180229c70((int64_t)&arg_28h + iVar11 + iVar10, uVar18, iVar13, uVar16);
                        uVar2 = puVar12[1];
                        uVar3 = puVar12[2];
                        uVar7 = puVar12[3];
                        *(undefined4 *)puVar1 = *puVar12;
                        *(undefined4 *)((int64_t)puVar1 + 4) = uVar2;
                        *(undefined4 *)(puVar1 + 1) = uVar3;
                        *(undefined4 *)((int64_t)puVar1 + 0xc) = uVar7;
                        uVar2 = puVar12[5];
                        uVar3 = puVar12[6];
                        uVar7 = puVar12[7];
                        *(undefined4 *)(puVar1 + 2) = puVar12[4];
                        *(undefined4 *)((int64_t)puVar1 + 0x14) = uVar2;
                        *(undefined4 *)(puVar1 + 3) = uVar3;
                        *(undefined4 *)((int64_t)puVar1 + 0x1c) = uVar7;
                        puVar1[4] = *(undefined8 *)(puVar12 + 8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x18021064c;
                        iVar9 = func_0x000180211450(in_RCX, (int64_t)&var_a0h + iVar10);
                        if (iVar9 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210658;
                            iVar9 = func_0x00018022aed0(puVar1);
                            if (iVar9 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x18021066e;
                                iVar14 = func_0x000180228a50((int64_t)&var_18h + iVar11 + iVar10, 
                                                             (int64_t)&iStackX_20 + iVar11 + iVar10, uVar16 & 0xffffffff
                                                            );
                                iVar8 = -1;
                                if (iVar14 != 0) {
                                    iVar8 = 1;
                                }
                            }
                        }
                    }
                }
code_r0x00018021067d:
                *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210692;
                func_0x000180224990(iVar13, 0x1804bb240, 0x53c);
                goto code_r0x00018021069d;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210347;
            iVar8 = (*pcVar4)();
code_r0x00018021069d:
            if (iVar8 != -2) {
                if (0 < iVar8) goto code_r0x000180210719;
                goto code_r0x0001802106a6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x1802106e6;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar11 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar11 + iVar10));
        *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x1802106fe;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar11 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar11 + iVar10), 
                      *(int64_t *)((int64_t)&arg_28h + iVar11 + iVar10), 
                      *(int64_t *)(&stack0x00000030 + iVar11 + iVar10), *(int64_t *)(&stack0x00000048 + iVar11 + iVar10)
                     );
        *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210710;
        fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar11 + iVar10), *(int64_t *)(&stack0x00000038 + iVar11 + iVar10)
                      , *(int64_t *)(&stack0x00000060 + iVar11 + iVar10));
    }
code_r0x000180210719:
    uVar16 = *(uint64_t *)((int64_t)&var_20h + iVar10);
    *(undefined8 *)((int64_t)&uStack_10 + iVar11 + iVar10) = 0x180210725;
    func_0x000180459870(uVar16 ^ (int64_t)&uStack_8 + iVar11 + iVar10);
    return;
}

// ============================================================
// Function: FUN_18020f340
// Address: 0x18020f340
// Size: 282 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.18020f340(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_b0h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    undefined8 *in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020f355;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar10 = 0;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar8) = 0;
        *(undefined8 **)((int64_t)&arg_b0h + iVar8) = in_RCX + 3;
        *(undefined4 *)((int64_t)&arg_50h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_68h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_70h + iVar8) = 0;
        *(undefined4 *)((int64_t)&arg_78h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_80h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_88h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_90h + iVar8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18020f3d0;
        puVar9 = (undefined4 *)
                 func_0x000180229c20((int64_t)&var_18h + iVar8, 0x1804bb36c, (int64_t)&arg_b0h + iVar8, 0x10);
        uVar1 = in_RCX[0x16];
        uVar2 = *in_RCX;
        uVar3 = puVar9[1];
        uVar4 = puVar9[2];
        uVar5 = puVar9[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar8) = *puVar9;
        *(undefined4 *)((int64_t)&arg_48h + iVar8 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_50h + iVar8) = uVar4;
        *(undefined4 *)((int64_t)&arg_50h + iVar8 + 4) = uVar5;
        uVar3 = puVar9[5];
        uVar4 = puVar9[6];
        uVar5 = puVar9[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar8) = puVar9[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar8 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_60h + iVar8) = uVar4;
        *(undefined4 *)((int64_t)&arg_60h + iVar8 + 4) = uVar5;
        *(undefined8 *)((int64_t)&arg_68h + iVar8) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18020f400;
        iVar6 = fcn.180280760(uVar2, uVar1, (int64_t)&arg_48h + iVar8);
        if (iVar6 != 0) {
            uVar10 = *(undefined8 *)((int64_t)&arg_b0h + iVar8);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18020f413;
        uVar7 = func_0x00018020e980(in_RCX);
        if (0x10 < uVar7) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18020f433;
            func_0x00018027bb50(0x1804bb258, 0x1804bb240, 0x4b);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18020f441;
        uVar10 = func_0x00018027cdf0(in_RDX, uVar10, uVar7);
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18020f460
// Address: 0x18020f460
// Size: 72 bytes
// ============================================================
uint64_t fcn.18020f460(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint32_t uVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int64_t iVar8;
    undefined8 unaff_RBX;
    int64_t iVar9;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020f46c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    in_R9 = in_R9 & 0xffffffff;
    if ((in_RCX != (int64_t *)0x0) && (iVar1 = *in_RCX, iVar1 != 0)) {
        if (*(int64_t *)(iVar1 + 0x70) == 0) {
    // WARNING: Could not recover jumptable at 0x00018020f575. Too many branches
    // WARNING: Treating indirect jump as call
            uVar6 = (**(code **)(iVar1 + 0x20))();
            return uVar6;
        }
        iVar9 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0;
        iVar4 = *(int32_t *)(iVar1 + 4);
        iVar8 = (int64_t)iVar4;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBX;
            iVar2 = in_RCX[0x16];
            *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RDI;
            pcVar3 = *(code **)(iVar1 + 0xa8);
            if (pcVar3 != (code *)0x0) {
                *(uint64_t *)((int64_t)&var_20h + iVar5) = in_R9;
                *(int64_t *)((int64_t)&var_18h + iVar5) = in_R8;
                if (iVar4 == 1) {
                    iVar8 = iVar9;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f4e9;
                iVar4 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8 + in_R9);
                uVar7 = 0xffffffff;
                if (iVar4 != 0) {
                    uVar7 = *(uint32_t *)((int64_t)&arg_38h + iVar5);
                }
                return (uint64_t)uVar7;
            }
            if (in_R8 != 0) {
                pcVar3 = *(code **)(iVar1 + 0x98);
                *(uint64_t *)((int64_t)&var_20h + iVar5) = in_R9;
                if (iVar4 == 1) {
                    iVar8 = iVar9;
                }
                *(int64_t *)((int64_t)&var_18h + iVar5) = in_R8;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f531;
                uVar6 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8 + in_R9);
                return uVar6;
            }
            pcVar3 = *(code **)(iVar1 + 0xa0);
            if (iVar4 == 1) {
                iVar8 = iVar9;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f559;
            uVar6 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8);
            return uVar6;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020f4a8
// Address: 0x18020f4a8
// Size: 95 bytes
// ============================================================
uint64_t fcn.18020f460(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint32_t uVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int64_t iVar8;
    undefined8 unaff_RBX;
    int64_t iVar9;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020f46c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    in_R9 = in_R9 & 0xffffffff;
    if ((in_RCX != (int64_t *)0x0) && (iVar1 = *in_RCX, iVar1 != 0)) {
        if (*(int64_t *)(iVar1 + 0x70) == 0) {
    // WARNING: Could not recover jumptable at 0x00018020f575. Too many branches
    // WARNING: Treating indirect jump as call
            uVar6 = (**(code **)(iVar1 + 0x20))();
            return uVar6;
        }
        iVar9 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0;
        iVar4 = *(int32_t *)(iVar1 + 4);
        iVar8 = (int64_t)iVar4;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBX;
            iVar2 = in_RCX[0x16];
            *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RDI;
            pcVar3 = *(code **)(iVar1 + 0xa8);
            if (pcVar3 != (code *)0x0) {
                *(uint64_t *)((int64_t)&var_20h + iVar5) = in_R9;
                *(int64_t *)((int64_t)&var_18h + iVar5) = in_R8;
                if (iVar4 == 1) {
                    iVar8 = iVar9;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f4e9;
                iVar4 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8 + in_R9);
                uVar7 = 0xffffffff;
                if (iVar4 != 0) {
                    uVar7 = *(uint32_t *)((int64_t)&arg_38h + iVar5);
                }
                return (uint64_t)uVar7;
            }
            if (in_R8 != 0) {
                pcVar3 = *(code **)(iVar1 + 0x98);
                *(uint64_t *)((int64_t)&var_20h + iVar5) = in_R9;
                if (iVar4 == 1) {
                    iVar8 = iVar9;
                }
                *(int64_t *)((int64_t)&var_18h + iVar5) = in_R8;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f531;
                uVar6 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8 + in_R9);
                return uVar6;
            }
            pcVar3 = *(code **)(iVar1 + 0xa0);
            if (iVar4 == 1) {
                iVar8 = iVar9;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f559;
            uVar6 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8);
            return uVar6;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020f507
// Address: 0x18020f507
// Size: 58 bytes
// ============================================================
uint64_t fcn.18020f460(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint32_t uVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int64_t iVar8;
    undefined8 unaff_RBX;
    int64_t iVar9;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020f46c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    in_R9 = in_R9 & 0xffffffff;
    if ((in_RCX != (int64_t *)0x0) && (iVar1 = *in_RCX, iVar1 != 0)) {
        if (*(int64_t *)(iVar1 + 0x70) == 0) {
    // WARNING: Could not recover jumptable at 0x00018020f575. Too many branches
    // WARNING: Treating indirect jump as call
            uVar6 = (**(code **)(iVar1 + 0x20))();
            return uVar6;
        }
        iVar9 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0;
        iVar4 = *(int32_t *)(iVar1 + 4);
        iVar8 = (int64_t)iVar4;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBX;
            iVar2 = in_RCX[0x16];
            *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RDI;
            pcVar3 = *(code **)(iVar1 + 0xa8);
            if (pcVar3 != (code *)0x0) {
                *(uint64_t *)((int64_t)&var_20h + iVar5) = in_R9;
                *(int64_t *)((int64_t)&var_18h + iVar5) = in_R8;
                if (iVar4 == 1) {
                    iVar8 = iVar9;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f4e9;
                iVar4 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8 + in_R9);
                uVar7 = 0xffffffff;
                if (iVar4 != 0) {
                    uVar7 = *(uint32_t *)((int64_t)&arg_38h + iVar5);
                }
                return (uint64_t)uVar7;
            }
            if (in_R8 != 0) {
                pcVar3 = *(code **)(iVar1 + 0x98);
                *(uint64_t *)((int64_t)&var_20h + iVar5) = in_R9;
                if (iVar4 == 1) {
                    iVar8 = iVar9;
                }
                *(int64_t *)((int64_t)&var_18h + iVar5) = in_R8;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f531;
                uVar6 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8 + in_R9);
                return uVar6;
            }
            pcVar3 = *(code **)(iVar1 + 0xa0);
            if (iVar4 == 1) {
                iVar8 = iVar9;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f559;
            uVar6 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8);
            return uVar6;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020f541
// Address: 0x18020f541
// Size: 40 bytes
// ============================================================
uint64_t fcn.18020f460(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint32_t uVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int64_t iVar8;
    undefined8 unaff_RBX;
    int64_t iVar9;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020f46c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    in_R9 = in_R9 & 0xffffffff;
    if ((in_RCX != (int64_t *)0x0) && (iVar1 = *in_RCX, iVar1 != 0)) {
        if (*(int64_t *)(iVar1 + 0x70) == 0) {
    // WARNING: Could not recover jumptable at 0x00018020f575. Too many branches
    // WARNING: Treating indirect jump as call
            uVar6 = (**(code **)(iVar1 + 0x20))();
            return uVar6;
        }
        iVar9 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0;
        iVar4 = *(int32_t *)(iVar1 + 4);
        iVar8 = (int64_t)iVar4;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBX;
            iVar2 = in_RCX[0x16];
            *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RDI;
            pcVar3 = *(code **)(iVar1 + 0xa8);
            if (pcVar3 != (code *)0x0) {
                *(uint64_t *)((int64_t)&var_20h + iVar5) = in_R9;
                *(int64_t *)((int64_t)&var_18h + iVar5) = in_R8;
                if (iVar4 == 1) {
                    iVar8 = iVar9;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f4e9;
                iVar4 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8 + in_R9);
                uVar7 = 0xffffffff;
                if (iVar4 != 0) {
                    uVar7 = *(uint32_t *)((int64_t)&arg_38h + iVar5);
                }
                return (uint64_t)uVar7;
            }
            if (in_R8 != 0) {
                pcVar3 = *(code **)(iVar1 + 0x98);
                *(uint64_t *)((int64_t)&var_20h + iVar5) = in_R9;
                if (iVar4 == 1) {
                    iVar8 = iVar9;
                }
                *(int64_t *)((int64_t)&var_18h + iVar5) = in_R8;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f531;
                uVar6 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8 + in_R9);
                return uVar6;
            }
            pcVar3 = *(code **)(iVar1 + 0xa0);
            if (iVar4 == 1) {
                iVar8 = iVar9;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f559;
            uVar6 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8);
            return uVar6;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020f569
// Address: 0x18020f569
// Size: 23 bytes
// ============================================================
uint64_t fcn.18020f460(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint32_t uVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int64_t iVar8;
    undefined8 unaff_RBX;
    int64_t iVar9;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020f46c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    in_R9 = in_R9 & 0xffffffff;
    if ((in_RCX != (int64_t *)0x0) && (iVar1 = *in_RCX, iVar1 != 0)) {
        if (*(int64_t *)(iVar1 + 0x70) == 0) {
    // WARNING: Could not recover jumptable at 0x00018020f575. Too many branches
    // WARNING: Treating indirect jump as call
            uVar6 = (**(code **)(iVar1 + 0x20))();
            return uVar6;
        }
        iVar9 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0;
        iVar4 = *(int32_t *)(iVar1 + 4);
        iVar8 = (int64_t)iVar4;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBX;
            iVar2 = in_RCX[0x16];
            *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RDI;
            pcVar3 = *(code **)(iVar1 + 0xa8);
            if (pcVar3 != (code *)0x0) {
                *(uint64_t *)((int64_t)&var_20h + iVar5) = in_R9;
                *(int64_t *)((int64_t)&var_18h + iVar5) = in_R8;
                if (iVar4 == 1) {
                    iVar8 = iVar9;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f4e9;
                iVar4 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8 + in_R9);
                uVar7 = 0xffffffff;
                if (iVar4 != 0) {
                    uVar7 = *(uint32_t *)((int64_t)&arg_38h + iVar5);
                }
                return (uint64_t)uVar7;
            }
            if (in_R8 != 0) {
                pcVar3 = *(code **)(iVar1 + 0x98);
                *(uint64_t *)((int64_t)&var_20h + iVar5) = in_R9;
                if (iVar4 == 1) {
                    iVar8 = iVar9;
                }
                *(int64_t *)((int64_t)&var_18h + iVar5) = in_R8;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f531;
                uVar6 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8 + in_R9);
                return uVar6;
            }
            pcVar3 = *(code **)(iVar1 + 0xa0);
            if (iVar4 == 1) {
                iVar8 = iVar9;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f559;
            uVar6 = (*pcVar3)(iVar2, in_RDX, (int64_t)&arg_38h + iVar5, iVar8);
            return uVar6;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020f590
// Address: 0x18020f590
// Size: 318 bytes
// ============================================================
uint64_t fcn.18020f590(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                      int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                      int64_t arg_a8h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    int64_t *in_RCX;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020f59c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f5a7;
    iVar6 = fcn.1802153d0();
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f5bf;
        iVar6 = fcn.18022ae60(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar5) = 0;
            *(undefined4 *)((int64_t)&arg_50h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_58h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_60h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_68h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_70h + iVar5) = 0;
            *(undefined4 *)((int64_t)&arg_78h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_80h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_88h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_90h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_a8h + iVar5) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f627;
            puVar7 = (undefined4 *)
                     fcn.180229cc0((int64_t)&iStackX_20 + iVar5 + -8, 0x18063dcac, (int64_t)&arg_a8h + iVar5);
            uVar1 = puVar7[1];
            uVar2 = puVar7[2];
            uVar3 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar5) = *puVar7;
            *(undefined4 *)((int64_t)&arg_48h + iVar5 + 4) = uVar1;
            *(undefined4 *)((int64_t)&arg_50h + iVar5) = uVar2;
            *(undefined4 *)((int64_t)&arg_50h + iVar5 + 4) = uVar3;
            uVar1 = puVar7[5];
            uVar2 = puVar7[6];
            uVar3 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar5) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar5 + 4) = uVar1;
            *(undefined4 *)((int64_t)&arg_60h + iVar5) = uVar2;
            *(undefined4 *)((int64_t)&arg_60h + iVar5 + 4) = uVar3;
            *(undefined8 *)((int64_t)&arg_68h + iVar5) = *(undefined8 *)(puVar7 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f650;
            iVar4 = fcn.180215350(in_RCX, (int64_t)&arg_48h + iVar5);
            if (iVar4 != 1) {
                return 0xffffffff;
            }
            if (0x7ffffffe < *(uint64_t *)((int64_t)&arg_a8h + iVar5) - 1) {
                return 0xffffffff;
            }
            return *(uint64_t *)((int64_t)&arg_a8h + iVar5);
        }
    }
    if ((in_RCX != (int64_t *)0x0) && (*in_RCX != 0)) {
        return (uint64_t)*(uint32_t *)(*in_RCX + 8);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f696;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f6ae;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020f6c0;
    fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5), 
                  *(int64_t *)((int64_t)&arg_60h + iVar5));
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18020f6e0
// Address: 0x18020f6e0
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18020f6e0(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020f6f5;
    iVar2 = fcn.18045a350();
    if ((*(uint32_t *)(in_RCX + 0x18) & 0x400) == 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x18020f710;
        fcn.180258be0(uVar1);
    }
    *(int64_t *)(in_RCX + 0x28) = in_RDX;
    uVar3 = *(uint32_t *)(in_RCX + 0x18) | 0x400;
    if (in_RDX == 0) {
        uVar3 = *(uint32_t *)(in_RCX + 0x18) & 0xfffffbff;
    }
    *(uint32_t *)(in_RCX + 0x18) = uVar3;
    return;
}

// ============================================================
// Function: FUN_18020f750
// Address: 0x18020f750
// Size: 50 bytes
// ============================================================
int64_t fcn.18020f750(undefined4 *param_1)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 == (undefined4 *)0x0) {
        return 0;
    }
    if (*(int64_t *)(param_1 + 0x16) == 0) {
        uVar1 = *param_1;
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x18022ccfa;
        iVar3 = fcn.18045a350(uVar1);
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x18022cd02;
        piVar4 = (int64_t *)
                 fcn.18022cba0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                               *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                               *(int64_t *)(&stack0x00000060 + iVar3 + iVar2), 
                               *(int64_t *)(&stack0x00000080 + iVar3 + iVar2));
        if (piVar4 == (int64_t *)0x0) {
            return 0;
        }
        return *piVar4;
    }
    return *(int64_t *)(param_1 + 0x16);
}

// ============================================================
// Function: FUN_18020f7a0
// Address: 0x18020f7a0
// Size: 83 bytes
// ============================================================
undefined4 fcn.18020f7a0(int64_t param_1)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020f7aa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18020f7b7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18020f7cf;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18020f7e1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                      *(int64_t *)(&stack0x00000068 + iVar1));
        return 0xffffffff;
    }
    return *(undefined4 *)(param_1 + 0x40);
}

// ============================================================
// Function: FUN_18020f800
// Address: 0x18020f800
// Size: 83 bytes
// ============================================================
undefined4 fcn.18020f800(int64_t param_1)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020f80a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18020f817;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18020f82f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18020f841;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                      *(int64_t *)(&stack0x00000068 + iVar1));
        return 0xffffffff;
    }
    return *(undefined4 *)(param_1 + 8);
}

// ============================================================
// Function: FUN_18020f860
// Address: 0x18020f860
// Size: 98 bytes
// ============================================================
bool fcn.18020f860(int64_t param_1, undefined8 param_2)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined *puVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 uStackX_18;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020f86c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == 0) {
        return false;
    }
    iVar5 = *(int64_t *)(param_1 + 0x68);
    if (iVar5 == 0) {
        iVar4 = *(int64_t *)(param_1 + 0x58);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020f8ae;
            iVar4 = fcn.18022ccf0();
        }
        iVar1 = 0;
        iVar5 = 0;
        uVar6 = *(undefined8 *)((int64_t)&uStackX_18 + iVar3);
        puVar7 = auStackX_20 + iVar3;
    } else {
        iVar1 = *(int32_t *)(param_1 + 0x50);
        iVar4 = 0;
        uVar6 = *(undefined8 *)((int64_t)&uStackX_18 + iVar3);
        puVar7 = auStackX_20 + iVar3;
    }
    *(undefined8 *)(puVar7 + 8) = uVar6;
    *(undefined8 *)(puVar7 + 0x10) = unaff_RBP;
    *(undefined8 *)(puVar7 + 0x18) = unaff_RSI;
    *(undefined8 *)(puVar7 + 0x20) = unaff_RDI;
    *(undefined8 *)(puVar7 + -8) = unaff_R14;
    *(undefined8 *)(puVar7 + -0x10) = 0x180280ec0;
    iVar3 = fcn.18045a350(iVar5, iVar1, iVar4, param_2);
    iVar3 = -iVar3;
    *(undefined8 *)(puVar7 + iVar3 + -0x10) = 0x180280ed3;
    fcn.18027f1e0();
    *(undefined8 *)(puVar7 + iVar3 + -0x10) = 0x180280edb;
    fcn.180299670(*(int64_t *)(puVar7 + iVar3 + 0x18), *(int64_t *)(puVar7 + iVar3 + 0x28), 
                  *(int64_t *)(puVar7 + iVar3 + 0x30), *(int64_t *)(puVar7 + iVar3 + 0x48), 
                  *(int64_t *)(puVar7 + iVar3 + 0x50), *(int64_t *)(puVar7 + iVar3 + 0x58), 
                  *(int64_t *)(puVar7 + iVar3 + 0x60), *(int64_t *)(puVar7 + iVar3 + 0xa8));
    if (iVar5 == 0) {
        *(undefined8 *)(puVar7 + iVar3 + -0x10) = 0x180280eee;
        iVar1 = fcn.1802993f0(*(int64_t *)(puVar7 + iVar3 + 0x18), *(int64_t *)(puVar7 + iVar3 + 0x28), 
                              *(int64_t *)(puVar7 + iVar3 + 0x38), *(int64_t *)(puVar7 + iVar3 + 0x48), 
                              *(int64_t *)(puVar7 + iVar3 + 0x58), *(int64_t *)(puVar7 + iVar3 + 0x80));
    }
    *(undefined8 *)(puVar7 + iVar3 + -0x10) = 0x180280efb;
    iVar2 = fcn.1802993f0(*(int64_t *)(puVar7 + iVar3 + 0x18), *(int64_t *)(puVar7 + iVar3 + 0x28), 
                          *(int64_t *)(puVar7 + iVar3 + 0x38), *(int64_t *)(puVar7 + iVar3 + 0x48), 
                          *(int64_t *)(puVar7 + iVar3 + 0x58), *(int64_t *)(puVar7 + iVar3 + 0x80));
    return iVar2 == iVar1;
}

// ============================================================
// Function: FUN_18020f8d0
// Address: 0x18020f8d0
// Size: 86 bytes
// ============================================================
void fcn.18020f8d0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18020f8e0;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        if (*(int32_t *)(arg1 + 0x10) == 2) {
            uVar1 = *(undefined8 *)(arg1 + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020f902;
            fcn.180224990(uVar1, 0x1804bb240, 0x363);
            uVar1 = *(undefined8 *)(arg1 + 0x68);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020f90b;
            fcn.18027edb0(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020f920;
            fcn.180224990(arg1, 0x1804bb240, 0x366);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18020f930
// Address: 0x18020f930
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18020f930(int64_t arg_28h)
{
    int64_t iVar1;
    undefined4 *puVar2;
    undefined4 in_ECX;
    undefined4 in_EDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020f940;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18020f94c;
    puVar2 = (undefined4 *)fcn.180216730();
    if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = in_ECX;
        puVar2[1] = in_EDX;
        puVar2[4] = 2;
    }
    return;
}

// ============================================================
// Function: FUN_18020fa70
// Address: 0x18020fa70
// Size: 243 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h

undefined8
fcn.18020fa70(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    uint8_t *in_RCX;
    int64_t in_RDX;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020fa7c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
    *(undefined4 *)((int64_t)&arg_50h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = 0;
    *(undefined4 *)((int64_t)&arg_78h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_80h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_90h + iVar4) = 0;
    if ((in_RCX != (uint8_t *)0x0) && ((*in_RCX & 6) != 0)) {
        if (in_RDX == 0) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020faf4;
        puVar5 = (undefined4 *)
                 fcn.180229e30(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                               *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                               *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)((int64_t)&arg_50h + iVar4));
        uVar1 = puVar5[1];
        uVar2 = puVar5[2];
        uVar3 = puVar5[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar4) = *puVar5;
        *(undefined4 *)((int64_t)&arg_48h + iVar4 + 4) = uVar1;
        *(undefined4 *)((int64_t)&arg_50h + iVar4) = uVar2;
        *(undefined4 *)((int64_t)&arg_50h + iVar4 + 4) = uVar3;
        uVar1 = puVar5[5];
        uVar2 = puVar5[6];
        uVar3 = puVar5[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar4) = puVar5[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar4 + 4) = uVar1;
        *(undefined4 *)((int64_t)&arg_60h + iVar4) = uVar2;
        *(undefined4 *)((int64_t)&arg_60h + iVar4 + 4) = uVar3;
        *(undefined8 *)((int64_t)&arg_68h + iVar4) = *(undefined8 *)(puVar5 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020fb1d;
        uVar6 = fcn.1802592f0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                              *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)((int64_t)&arg_50h + iVar4), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4), *(int64_t *)((int64_t)&arg_60h + iVar4), 
                              *(int64_t *)((int64_t)&arg_68h + iVar4), *(int64_t *)((int64_t)&arg_70h + iVar4), 
                              *(int64_t *)(&stack0x00000178 + iVar4));
        return uVar6;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020fb2b;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020fb43;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020fb55;
    fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                  *(int64_t *)((int64_t)&arg_60h + iVar4));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_18020fb70
// Address: 0x18020fb70
// Size: 292 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h

int64_t fcn.18020fb70(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18020fb8f;
    var_18h = arg3;
    var_20h = arg4;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    var_a8h = 0;
    var_a0h._0_4_ = 0;
    var_98h = 0;
    var_90h = 0;
    var_88h = 0;
    var_80h = 0;
    var_78h._0_4_ = 0;
    var_70h = 0;
    var_68h = 0;
    var_60h = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18020fbd3;
    iVar1 = func_0x000180223670(arg3, 0x1804a9778);
    if (iVar1 == 0) {
        var_b0h = var_20h;
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18020fbf2;
        piVar3 = (int64_t *)fcn.180229cc0(&var_58h, 0x1804bb3dc, &var_b0h);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18020fc04;
        iVar1 = func_0x000180223670(var_18h, 0x1804af0ec);
        if (iVar1 != 0) goto code_r0x00018020fc37;
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18020fc1e;
        piVar3 = (int64_t *)
                 fcn.180229e30(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                               *(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                               *(int64_t *)(&stack0x00000030 + iVar2));
    }
    var_a8h = *piVar3;
    var_a0h._0_4_ = *(undefined4 *)(piVar3 + 1);
    var_a0h._4_4_ = *(undefined4 *)((int64_t)piVar3 + 0xc);
    var_98h = piVar3[2];
    var_90h = piVar3[3];
    var_88h = piVar3[4];
code_r0x00018020fc37:
    var_b8h = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18020fc4a;
    iVar4 = func_0x0001802591e0(placeholder_0, var_18h, placeholder_1);
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18020fc5a;
        iVar1 = func_0x00018025abd0(iVar4);
        if (0 < iVar1) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18020fc6a;
            iVar1 = fcn.1802592f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), *(int64_t *)(&stack0x00000000 + iVar2)
                                  , *(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), *(int64_t *)((int64_t)&var_20h + iVar2)
                                  , *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                  *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                                  *(int64_t *)(&stack0x00000158 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18020fc7a;
                func_0x00018025a920(iVar4, &var_b8h);
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18020fc82;
    fcn.180258be0(iVar4);
    return var_b8h;
}

// ============================================================
// Function: FUN_18020fca0
// Address: 0x18020fca0
// Size: 736 bytes
// ============================================================
void fcn.18020ee70(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h, int64_t arg_70h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    uint32_t uVar14;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar15;
    undefined8 unaff_R14;
    int64_t var_90h;
    int64_t var_88h;
    undefined4 auStack_80 [2];
    int64_t var_78h;
    undefined4 auStack_70 [2];
    int64_t var_68h;
    int64_t var_60h;
    undefined4 auStack_58 [2];
    int64_t var_50h;
    undefined4 auStack_48 [2];
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t iStack_8;
    
    iStack_8 = 0x18020ee7a;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    iVar15 = 0;
    *(undefined8 *)(&stack0x00000020 + iVar11) = unaff_RBP;
    *(undefined8 *)(&stack0x00000018 + iVar11) = unaff_RBX;
    *(undefined8 *)(&stack0x00000010 + iVar11) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar11) = unaff_RDI;
    *(undefined8 *)(&stack0x00000020 + iVar11 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)&iStack_8 + iVar11) = 0x18020fcb6;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    *(uint64_t *)((int64_t)&var_10h + iVar11) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000020 + iVar12 + iVar11 + -0x20);
    if ((in_RCX == (int64_t *)0x0) || (iVar1 = *in_RCX, iVar1 == 0)) {
code_r0x00018020fef3:
        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fef8;
        fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020ff10;
        fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_30h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000038 + iVar12 + iVar11), *(int64_t *)(&stack0x00000050 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020ff22;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar12 + iVar11), *(int64_t *)(&stack0x00000040 + iVar12 + iVar11)
                      , *(int64_t *)(&stack0x00000068 + iVar12 + iVar11));
    } else {
        pcVar2 = *(code **)(iVar1 + 0x40);
        if (pcVar2 == (code *)0x0) {
            if ((*(uint32_t *)(iVar1 + 0x10) >> 0x18 & 1) == 0) {
                uVar14 = *(uint32_t *)(iVar1 + 0x10) & 0xf0007;
                if (uVar14 == 6) {
                    if ((in_RDX == 0) || (iVar15 == 0)) {
                        iVar8 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fdc9;
                        iVar8 = func_0x00018027ce70(in_RDX, (int64_t)&var_30h + iVar11, 0, 0x10);
                        if (iVar8 < 1) {
                            iVar8 = -1;
                        } else {
                            *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fded;
                            func_0x00018027ce70(in_RDX, (int64_t)&var_30h + iVar11, (int64_t)&var_20h + iVar11, iVar8);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fdfc;
                            func_0x000180498030(iVar15, (int64_t)&var_20h + iVar11, (int64_t)iVar8);
                            *(int32_t *)(iVar15 + 0x10) = iVar8;
                        }
                    }
                    goto code_r0x00018020feea;
                }
                if ((uVar14 != 7) && (uVar14 != 0x10001)) {
                    if (uVar14 == 0x10002) goto code_r0x00018020ff66;
                    if (uVar14 != 0x10003) {
                        uVar14 = 0;
                        if (in_RDX != 0) {
                            *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fd4b;
                            uVar9 = func_0x00018020e980(in_RCX);
                            if (uVar9 < 0x11) {
                                *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fd62;
                                uVar14 = func_0x00018027ccd0(in_RDX, (int64_t)&var_30h + iVar11, uVar9);
                                if (uVar14 == uVar9) {
                                    *(undefined4 *)((int64_t)&arg_28h + iVar12 + iVar11) = 0xffffffff;
                                    *(int64_t *)(&stack0x00000020 + iVar12 + iVar11) = (int64_t)&var_30h + iVar11;
                                    *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fd8a;
                                    iVar8 = func_0x000180211b70(in_RCX, 0, 0, 0);
                                    if (iVar8 != 0) goto code_r0x00018020fd93;
                                }
                            }
                            uVar14 = 0xffffffff;
                        }
code_r0x00018020fd93:
                        iVar8 = ((int32_t)uVar14 >> 0x1f & 0xfffffffeU) + 1;
                        goto code_r0x00018020feea;
                    }
                }
            } else if (*(int64_t *)(iVar1 + 0x70) != 0) {
                *(undefined8 *)((int64_t)&var_30h + iVar11) = 0;
                iVar8 = -1;
                *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fe2f;
                iVar10 = func_0x000180228af0(in_RDX, (int64_t)&var_30h + iVar11);
                if (-1 < iVar10) {
                    uVar3 = *(undefined8 *)((int64_t)&var_30h + iVar11);
                    *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fe52;
                    puVar13 = (undefined4 *)
                              func_0x000180229c70((int64_t)&arg_30h + iVar12 + iVar11, 0x1804bb3e8, uVar3, 
                                                  (int64_t)iVar10);
                    uVar3 = *(undefined8 *)((int64_t)&var_30h + iVar11);
                    uVar5 = puVar13[1];
                    uVar6 = puVar13[2];
                    uVar7 = puVar13[3];
                    *(undefined4 *)((int64_t)&arg_60h + iVar12 + iVar11) = *puVar13;
                    *(undefined4 *)((int64_t)&arg_60h + iVar12 + iVar11 + 4) = uVar5;
                    *(undefined4 *)(&stack0x00000068 + iVar12 + iVar11) = uVar6;
                    *(undefined4 *)(&stack0x0000006c + iVar12 + iVar11) = uVar7;
                    uVar5 = puVar13[5];
                    uVar6 = puVar13[6];
                    uVar7 = puVar13[7];
                    *(undefined4 *)((int64_t)&arg_70h + iVar12 + iVar11) = puVar13[4];
                    *(undefined4 *)((int64_t)&arg_70h + iVar12 + iVar11 + 4) = uVar5;
                    *(undefined4 *)(&stack0x00000078 + iVar12 + iVar11) = uVar6;
                    *(undefined4 *)(&stack0x0000007c + iVar12 + iVar11) = uVar7;
                    *(undefined8 *)((int64_t)&var_90h + iVar11) = *(undefined8 *)(puVar13 + 8);
                    *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fe85;
                    puVar13 = (undefined4 *)
                              func_0x000180229c70((int64_t)&arg_30h + iVar12 + iVar11, 0x1804bb350, uVar3, 
                                                  (int64_t)iVar10);
                    uVar5 = puVar13[1];
                    uVar6 = puVar13[2];
                    uVar7 = puVar13[3];
                    *(undefined4 *)((int64_t)auStack_80 + iVar11 + -8) = *puVar13;
                    *(undefined4 *)((int64_t)auStack_80 + iVar11 + -4) = uVar5;
                    *(undefined4 *)((int64_t)auStack_80 + iVar11) = uVar6;
                    *(undefined4 *)((int64_t)auStack_80 + iVar11 + 4) = uVar7;
                    uVar5 = puVar13[5];
                    uVar6 = puVar13[6];
                    uVar7 = puVar13[7];
                    *(undefined4 *)((int64_t)auStack_70 + iVar11 + -8) = puVar13[4];
                    *(undefined4 *)((int64_t)auStack_70 + iVar11 + -4) = uVar5;
                    *(undefined4 *)((int64_t)auStack_70 + iVar11) = uVar6;
                    *(undefined4 *)((int64_t)auStack_70 + iVar11 + 4) = uVar7;
                    *(undefined8 *)((int64_t)&var_68h + iVar11) = *(undefined8 *)(puVar13 + 8);
                    *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fea8;
                    puVar13 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_30h + iVar12 + iVar11);
                    uVar5 = puVar13[1];
                    uVar6 = puVar13[2];
                    uVar7 = puVar13[3];
                    *(undefined4 *)((int64_t)auStack_58 + iVar11 + -8) = *puVar13;
                    *(undefined4 *)((int64_t)auStack_58 + iVar11 + -4) = uVar5;
                    *(undefined4 *)((int64_t)auStack_58 + iVar11) = uVar6;
                    *(undefined4 *)((int64_t)auStack_58 + iVar11 + 4) = uVar7;
                    uVar5 = puVar13[5];
                    uVar6 = puVar13[6];
                    uVar7 = puVar13[7];
                    *(undefined4 *)((int64_t)auStack_48 + iVar11 + -8) = puVar13[4];
                    *(undefined4 *)((int64_t)auStack_48 + iVar11 + -4) = uVar5;
                    *(undefined4 *)((int64_t)auStack_48 + iVar11) = uVar6;
                    *(undefined4 *)((int64_t)auStack_48 + iVar11 + 4) = uVar7;
                    *(undefined8 *)((int64_t)&var_40h + iVar11) = *(undefined8 *)(puVar13 + 8);
                    *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fece;
                    iVar8 = func_0x000180211920(in_RCX, (int64_t)&arg_60h + iVar12 + iVar11);
                }
                uVar3 = *(undefined8 *)((int64_t)&var_30h + iVar11);
                *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fee7;
                fcn.180224990(uVar3, 0x1804bb240, 0x4fa);
                goto code_r0x00018020feea;
            }
        } else {
            *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020fcf6;
            iVar8 = (*pcVar2)();
code_r0x00018020feea:
            if (iVar8 != -2) {
                if (0 < iVar8) goto code_r0x00018020ff66;
                goto code_r0x00018020fef3;
            }
        }
        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020ff33;
        fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020ff4b;
        fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_30h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000038 + iVar12 + iVar11), *(int64_t *)(&stack0x00000050 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020ff5d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar12 + iVar11), *(int64_t *)(&stack0x00000040 + iVar12 + iVar11)
                      , *(int64_t *)(&stack0x00000068 + iVar12 + iVar11));
    }
code_r0x00018020ff66:
    uVar4 = *(uint64_t *)((int64_t)&var_10h + iVar11);
    *(undefined8 *)((int64_t)&iStack_8 + iVar12 + iVar11) = 0x18020ff72;
    func_0x000180459870(uVar4 ^ (uint64_t)(&stack0x00000020 + iVar12 + iVar11 + -0x20));
    return;
}

// ============================================================
// Function: FUN_18020ff80
// Address: 0x18020ff80
// Size: 875 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable arg_28h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel

void fcn.18020ff80(int64_t placeholder_0, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t var_10h;
    int64_t var_18h;
    int32_t var_20h;
    int32_t var_24h;
    int64_t var_1d8h;
    undefined4 uStack_1d0;
    undefined4 uStack_1cc;
    int64_t var_1c8h;
    undefined4 uStack_1c0;
    undefined4 uStack_1bc;
    int64_t var_1b8h;
    int64_t var_1b0h;
    undefined4 uStack_1a8;
    undefined4 uStack_1a4;
    int64_t var_1a0h;
    undefined4 uStack_198;
    undefined4 uStack_194;
    int64_t var_190h;
    int64_t var_188h;
    undefined4 uStack_180;
    undefined4 uStack_17c;
    int64_t var_178h;
    undefined4 uStack_170;
    undefined4 uStack_16c;
    int64_t var_168h;
    int64_t var_160h;
    undefined4 uStack_158;
    undefined4 uStack_154;
    int64_t var_150h;
    undefined4 uStack_148;
    undefined4 uStack_144;
    int64_t var_140h;
    int64_t var_138h;
    undefined4 uStack_130;
    undefined4 uStack_12c;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    int64_t var_110h;
    undefined4 uStack_108;
    undefined4 uStack_104;
    int64_t var_100h;
    undefined4 uStack_f8;
    undefined4 uStack_f4;
    int64_t var_f0h;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined4 uStack_b8;
    undefined4 uStack_b4;
    int64_t var_b0h;
    undefined4 uStack_a8;
    undefined4 uStack_a4;
    int64_t var_a0h;
    int64_t var_98h;
    undefined4 uStack_90;
    undefined4 uStack_8c;
    int64_t var_88h;
    undefined4 uStack_80;
    undefined4 uStack_7c;
    int64_t var_78h;
    int64_t var_70h;
    undefined4 uStack_68;
    undefined4 uStack_64;
    int64_t var_60h;
    undefined4 uStack_58;
    undefined4 uStack_54;
    int64_t var_50h;
    int64_t var_48h;
    undefined4 uStack_40;
    undefined4 uStack_3c;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    int64_t var_28h;
    uint64_t uStack_18;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020ff9d;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    *(undefined4 *)((int64_t)&var_20h + iVar2 + -4) = 0;
    *(undefined4 *)((int64_t)&var_20h + iVar2) = 0;
    *(undefined4 *)((int64_t)&var_24h + iVar2) = 0;
    *(undefined4 *)(&stack0x00000028 + iVar2) = 0;
    *(undefined4 *)(&stack0x0000002c + iVar2) = 0;
    *(undefined4 *)((int64_t)&arg_30h + iVar2) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0;
    *(undefined4 *)((int64_t)&var_20h + iVar2 + -8) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020fff7;
    puVar3 = (undefined4 *)fcn.180229cc0((int64_t)&arg_50h + iVar2, 0x1804bb2e0, (int64_t)&arg_38h + iVar2);
    var_1d8h._0_4_ = *puVar3;
    var_1d8h._4_4_ = puVar3[1];
    uStack_1d0 = puVar3[2];
    uStack_1cc = puVar3[3];
    var_1c8h._0_4_ = puVar3[4];
    var_1c8h._4_4_ = puVar3[5];
    uStack_1c0 = puVar3[6];
    uStack_1bc = puVar3[7];
    var_1b8h = *(int64_t *)(puVar3 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180210026;
    puVar3 = (undefined4 *)fcn.180229cc0((int64_t)&arg_50h + iVar2, 0x1804bb2ec, (int64_t)&arg_40h + iVar2);
    var_1b0h._0_4_ = *puVar3;
    var_1b0h._4_4_ = puVar3[1];
    uStack_1a8 = puVar3[2];
    uStack_1a4 = puVar3[3];
    var_1a0h._0_4_ = puVar3[4];
    var_1a0h._4_4_ = puVar3[5];
    uStack_198 = puVar3[6];
    uStack_194 = puVar3[7];
    var_190h = *(int64_t *)(puVar3 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180210055;
    puVar3 = (undefined4 *)fcn.180229cc0((int64_t)&arg_50h + iVar2, 0x1804bb2f4, (int64_t)&arg_48h + iVar2);
    var_188h._0_4_ = *puVar3;
    var_188h._4_4_ = puVar3[1];
    uStack_180 = puVar3[2];
    uStack_17c = puVar3[3];
    var_178h._0_4_ = puVar3[4];
    var_178h._4_4_ = puVar3[5];
    uStack_170 = puVar3[6];
    uStack_16c = puVar3[7];
    var_168h = *(int64_t *)(puVar3 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180210084;
    puVar3 = (undefined4 *)fcn.180229d80((int64_t)&arg_50h + iVar2, 0x1804a95d0, (int64_t)&var_20h + iVar2 + -8);
    var_160h._0_4_ = *puVar3;
    var_160h._4_4_ = puVar3[1];
    uStack_158 = puVar3[2];
    uStack_154 = puVar3[3];
    var_150h._0_4_ = puVar3[4];
    var_150h._4_4_ = puVar3[5];
    uStack_148 = puVar3[6];
    uStack_144 = puVar3[7];
    var_140h = *(int64_t *)(puVar3 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802100b3;
    puVar3 = (undefined4 *)func_0x000180229bc0((int64_t)&arg_50h + iVar2, 0x1804bb2fc, (int64_t)&var_20h + iVar2 + -4);
    var_138h._0_4_ = *puVar3;
    var_138h._4_4_ = puVar3[1];
    uStack_130 = puVar3[2];
    uStack_12c = puVar3[3];
    var_128h._0_4_ = puVar3[4];
    var_128h._4_4_ = puVar3[5];
    uStack_120 = puVar3[6];
    uStack_11c = puVar3[7];
    var_118h = *(int64_t *)(puVar3 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802100e2;
    puVar3 = (undefined4 *)func_0x000180229bc0((int64_t)&arg_50h + iVar2, 0x1804bb308, (int64_t)&var_20h + iVar2);
    var_110h._0_4_ = *puVar3;
    var_110h._4_4_ = puVar3[1];
    uStack_108 = puVar3[2];
    uStack_104 = puVar3[3];
    var_100h._0_4_ = puVar3[4];
    var_100h._4_4_ = puVar3[5];
    uStack_f8 = puVar3[6];
    uStack_f4 = puVar3[7];
    var_f0h = *(int64_t *)(puVar3 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180210111;
    puVar3 = (undefined4 *)func_0x000180229bc0((int64_t)&arg_50h + iVar2, 0x1804bb314, (int64_t)&var_24h + iVar2);
    var_e8h._0_4_ = *puVar3;
    var_e8h._4_4_ = puVar3[1];
    uStack_e0 = puVar3[2];
    uStack_dc = puVar3[3];
    var_d8h._0_4_ = puVar3[4];
    var_d8h._4_4_ = puVar3[5];
    uStack_d0 = puVar3[6];
    uStack_cc = puVar3[7];
    var_c8h = *(int64_t *)(puVar3 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180210146;
    puVar3 = (undefined4 *)func_0x000180229bc0((int64_t)&arg_50h + iVar2, 0x1804bb318, &stack0x00000028 + iVar2);
    var_c0h._0_4_ = *puVar3;
    var_c0h._4_4_ = puVar3[1];
    uStack_b8 = puVar3[2];
    uStack_b4 = puVar3[3];
    var_b0h._0_4_ = puVar3[4];
    var_b0h._4_4_ = puVar3[5];
    uStack_a8 = puVar3[6];
    uStack_a4 = puVar3[7];
    var_a0h = *(int64_t *)(puVar3 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021017e;
    puVar3 = (undefined4 *)func_0x000180229bc0((int64_t)&arg_50h + iVar2, 0x1804bb328, &stack0x0000002c + iVar2);
    var_98h._0_4_ = *puVar3;
    var_98h._4_4_ = puVar3[1];
    uStack_90 = puVar3[2];
    uStack_8c = puVar3[3];
    var_88h._0_4_ = puVar3[4];
    var_88h._4_4_ = puVar3[5];
    uStack_80 = puVar3[6];
    uStack_7c = puVar3[7];
    var_78h = *(int64_t *)(puVar3 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802101b6;
    puVar3 = (undefined4 *)func_0x000180229bc0((int64_t)&arg_50h + iVar2, 0x1804bb338, (int64_t)&arg_30h + iVar2);
    var_70h._0_4_ = *puVar3;
    var_70h._4_4_ = puVar3[1];
    uStack_68 = puVar3[2];
    uStack_64 = puVar3[3];
    var_60h._0_4_ = puVar3[4];
    var_60h._4_4_ = puVar3[5];
    uStack_58 = puVar3[6];
    uStack_54 = puVar3[7];
    var_50h = *(int64_t *)(puVar3 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802101e2;
    puVar3 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_50h + iVar2);
    var_48h._0_4_ = *puVar3;
    var_48h._4_4_ = puVar3[1];
    uStack_40 = puVar3[2];
    uStack_3c = puVar3[3];
    var_38h._0_4_ = puVar3[4];
    var_38h._4_4_ = puVar3[5];
    uStack_30 = puVar3[6];
    uStack_2c = puVar3[7];
    var_28h = *(int64_t *)(puVar3 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180210210;
    iVar1 = func_0x000180280800(placeholder_0, &var_1d8h);
    if (0 < iVar1) {
        iVar1 = *(int32_t *)((int64_t)&var_20h + iVar2 + -4);
        uVar5 = *(uint32_t *)((int64_t)&var_20h + iVar2 + -8);
        *(undefined4 *)(placeholder_0 + 4) = *(undefined4 *)((int64_t)&arg_38h + iVar2);
        *(undefined4 *)(placeholder_0 + 0xc) = *(undefined4 *)((int64_t)&arg_40h + iVar2);
        *(undefined4 *)(placeholder_0 + 8) = *(undefined4 *)((int64_t)&arg_48h + iVar2);
        *(uint32_t *)(placeholder_0 + 0x10) = uVar5;
        if (iVar1 != 0) {
            uVar5 = uVar5 | 0x200000;
            *(uint32_t *)(placeholder_0 + 0x10) = uVar5;
        }
        if (*(int32_t *)((int64_t)&var_20h + iVar2) != 0) {
            uVar5 = uVar5 | 0x10;
            *(uint32_t *)(placeholder_0 + 0x10) = uVar5;
        }
        if (*(int32_t *)((int64_t)&var_24h + iVar2) != 0) {
            uVar5 = uVar5 | 0x4000;
            *(uint32_t *)(placeholder_0 + 0x10) = uVar5;
        }
        if (*(int32_t *)(&stack0x00000028 + iVar2) != 0) {
            uVar5 = uVar5 | 0x400000;
            *(uint32_t *)(placeholder_0 + 0x10) = uVar5;
        }
        if (*(int64_t *)(placeholder_0 + 0xa8) != 0) {
            uVar5 = uVar5 | 0x100000;
            *(uint32_t *)(placeholder_0 + 0x10) = uVar5;
        }
        if (*(int32_t *)(&stack0x0000002c + iVar2) != 0) {
            uVar5 = uVar5 | 0x200;
            *(uint32_t *)(placeholder_0 + 0x10) = uVar5;
        }
        if (*(int32_t *)((int64_t)&arg_30h + iVar2) != 0) {
            *(uint32_t *)(placeholder_0 + 0x10) = uVar5 | 0x10000000;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802102a6;
        func_0x000180211ae0(placeholder_0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802102b5;
        iVar4 = fcn.18022ae60(*(int64_t *)((int64_t)&var_20h + iVar2 + -8));
        if (iVar4 != 0) {
            *(uint32_t *)(placeholder_0 + 0x10) = *(uint32_t *)(placeholder_0 + 0x10) | 0x1000000;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802102d6;
    func_0x000180459870(uStack_18 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_1802102f0
// Address: 0x1802102f0
// Size: 503 bytes
// ============================================================
void fcn.18020f320(int64_t arg_28h, int64_t arg_e8h, int64_t arg_140h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    code *pcVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar17;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 auStack_48 [2];
    int64_t var_40h;
    undefined4 auStack_38 [2];
    int64_t var_30h;
    int64_t var_20h;
    undefined8 uStack_10;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020f32a;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    iVar14 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11) = unaff_RBP;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -8) = unaff_RBX;
    *(undefined8 *)(&stack0x00000010 + iVar11) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar11) = unaff_RDI;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_8 + iVar11) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar11) = 0x180210308;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    *(uint64_t *)((int64_t)&var_20h + iVar11) = *(uint64_t *)0x1806a3940 ^ (int64_t)&uStack_8 + iVar12 + iVar11;
    if ((in_RCX == (undefined8 *)0x0) || (puVar13 = (undefined4 *)*in_RCX, puVar13 == (undefined4 *)0x0)) {
code_r0x0001802106a6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106ab;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106c3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000048 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106d5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000038 + iVar12 + iVar11)
                      , *(int64_t *)(&stack0x00000060 + iVar12 + iVar11));
    } else {
        pcVar4 = *(code **)(puVar13 + 0xe);
        if (pcVar4 == (code *)0x0) {
            if (((uint32_t)puVar13[4] >> 0x18 & 1) == 0) {
                uVar16 = puVar13[4] & 0xf0007;
                if (uVar16 == 6) {
                    if ((in_RDX == 0) || (iVar14 == 0)) {
                        iVar9 = 0;
                    } else {
                        uVar2 = *(undefined4 *)(iVar14 + 0x10);
                        uVar3 = *(undefined4 *)(iVar14 + 0x14);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802104ce;
                        iVar9 = func_0x00018027cf70(in_RDX, uVar3, iVar14, uVar2);
                    }
                    goto code_r0x00018021069d;
                }
                if ((uVar16 != 7) && (uVar16 != 0x10001)) {
                    if (uVar16 == 0x10002) {
                        if ((*(int64_t *)(puVar13 + 0x1c) == 0) && (*(int64_t *)(puVar13 + 0x18) == 0)) {
                            uVar2 = *puVar13;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021047b;
                            fcn.18022ccf0(uVar2);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210493;
                        iVar9 = fcn.180280ea0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000038 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000040 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000048 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000050 + iVar12 + iVar11));
                        if (iVar9 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802104a7;
                            func_0x00018025fc10(in_RDX, 5, 0);
                        }
                        goto code_r0x000180210719;
                    }
                    if (uVar16 != 0x10003) {
                        uVar17 = 0;
                        iVar9 = 0;
                        if (in_RDX != 0) {
                            *(undefined8 *)((int64_t)&var_a0h + iVar11) = 0;
                            *(undefined8 **)((int64_t)&var_18h + iVar12 + iVar11) = in_RCX + 3;
                            *(undefined4 *)((int64_t)&var_98h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_90h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_88h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_80h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_78h + iVar11) = 0;
                            *(undefined4 *)((int64_t)&var_70h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_68h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_60h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_58h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802103e8;
                            puVar13 = (undefined4 *)
                                      func_0x000180229c20((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb36c, 
                                                          (int64_t)&var_18h + iVar12 + iVar11, 0x10);
                            uVar5 = in_RCX[0x16];
                            uVar6 = *in_RCX;
                            uVar2 = puVar13[1];
                            uVar3 = puVar13[2];
                            uVar8 = puVar13[3];
                            *(undefined4 *)((int64_t)&var_a0h + iVar11) = *puVar13;
                            *(undefined4 *)((int64_t)&var_a0h + iVar11 + 4) = uVar2;
                            *(undefined4 *)((int64_t)&var_98h + iVar11) = uVar3;
                            *(undefined4 *)((int64_t)&var_98h + iVar11 + 4) = uVar8;
                            uVar2 = puVar13[5];
                            uVar3 = puVar13[6];
                            uVar8 = puVar13[7];
                            *(undefined4 *)((int64_t)&var_90h + iVar11) = puVar13[4];
                            *(undefined4 *)((int64_t)&var_90h + iVar11 + 4) = uVar2;
                            *(undefined4 *)((int64_t)&var_88h + iVar11) = uVar3;
                            *(undefined4 *)((int64_t)&var_88h + iVar11 + 4) = uVar8;
                            *(undefined8 *)((int64_t)&var_80h + iVar11) = *(undefined8 *)(puVar13 + 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210414;
                            iVar9 = fcn.180280760(uVar6, uVar5, (int64_t)&var_a0h + iVar11);
                            if (iVar9 != 0) {
                                uVar17 = *(undefined8 *)((int64_t)&var_18h + iVar12 + iVar11);
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210424;
                            uVar16 = func_0x00018020e980(in_RCX);
                            if (0x10 < uVar16) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210444;
                                func_0x00018027bb50(0x1804bb258, 0x1804bb240, 0x4b);
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210452;
                            iVar9 = func_0x00018027cdf0(in_RDX, uVar17, uVar16);
                        }
                        goto code_r0x00018021069d;
                    }
                }
            } else if (*(int64_t *)(puVar13 + 0x1c) != 0) {
                *(undefined8 *)((int64_t)&arg_140h + iVar12 + iVar11) = unaff_R12;
                iVar9 = -1;
                iVar14 = 0;
                *(undefined8 *)((int64_t)&var_18h + iVar12 + iVar11) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210516;
                puVar13 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb3e8, 0, 0);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)&var_a0h + iVar11) = *puVar13;
                *(undefined4 *)((int64_t)&var_a0h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_98h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_98h + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)&var_90h + iVar11) = puVar13[4];
                *(undefined4 *)((int64_t)&var_90h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_88h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_88h + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_80h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210546;
                puVar13 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb350, 0, 0);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)&var_78h + iVar11) = *puVar13;
                *(undefined4 *)((int64_t)&var_78h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_70h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_70h + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)&var_68h + iVar11) = puVar13[4];
                *(undefined4 *)((int64_t)&var_68h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_60h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_60h + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_58h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210569;
                puVar13 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_28h + iVar12 + iVar11);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + -8) = *puVar13;
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + -4) = uVar2;
                *(undefined4 *)((int64_t)auStack_48 + iVar11) = uVar3;
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + -8) = puVar13[4];
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + -4) = uVar2;
                *(undefined4 *)((int64_t)auStack_38 + iVar11) = uVar3;
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_30h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021058e;
                iVar10 = func_0x000180211450(in_RCX, (int64_t)&var_a0h + iVar11);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021059f;
                    iVar10 = func_0x00018022aed0((int64_t)&var_a0h + iVar11);
                    iVar15 = 0xffffffff;
                    if ((iVar10 != 0) && (iVar15 = 0xffffffff, *(int64_t *)((int64_t)&var_80h + iVar11) != 0)) {
                        iVar15 = iVar14;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802105b3;
                    iVar10 = func_0x00018022aed0((int64_t)&var_78h + iVar11);
                    if ((iVar10 == 0) || (*(int64_t *)((int64_t)&var_58h + iVar11) == 0)) {
                        if ((int32_t)iVar15 < 0) goto code_r0x00018021067d;
                    } else {
                        iVar15 = 1;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar12 + iVar11) = in_RDX;
                    *(undefined8 *)((int64_t)&arg_e8h + iVar12 + iVar11) = unaff_R13;
                    uVar7 = *(uint64_t *)((int64_t)&var_80h + iVar15 * 0x28 + iVar11);
                    puVar1 = (undefined8 *)((int64_t)&var_a0h + iVar15 * 0x28 + iVar11);
                    uVar17 = *puVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210608;
                    iVar14 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                                           *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
                    if (iVar14 != 0) {
                        *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11) = iVar14;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210628;
                        puVar13 = (undefined4 *)
                                  func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, uVar17, iVar14, uVar7);
                        uVar2 = puVar13[1];
                        uVar3 = puVar13[2];
                        uVar8 = puVar13[3];
                        *(undefined4 *)puVar1 = *puVar13;
                        *(undefined4 *)((int64_t)puVar1 + 4) = uVar2;
                        *(undefined4 *)(puVar1 + 1) = uVar3;
                        *(undefined4 *)((int64_t)puVar1 + 0xc) = uVar8;
                        uVar2 = puVar13[5];
                        uVar3 = puVar13[6];
                        uVar8 = puVar13[7];
                        *(undefined4 *)(puVar1 + 2) = puVar13[4];
                        *(undefined4 *)((int64_t)puVar1 + 0x14) = uVar2;
                        *(undefined4 *)(puVar1 + 3) = uVar3;
                        *(undefined4 *)((int64_t)puVar1 + 0x1c) = uVar8;
                        puVar1[4] = *(undefined8 *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021064c;
                        iVar10 = func_0x000180211450(in_RCX, (int64_t)&var_a0h + iVar11);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210658;
                            iVar10 = func_0x00018022aed0(puVar1);
                            if (iVar10 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021066e;
                                iVar15 = func_0x000180228a50((int64_t)&var_18h + iVar12 + iVar11, 
                                                             (int64_t)&iStackX_20 + iVar12 + iVar11, uVar7 & 0xffffffff)
                                ;
                                iVar9 = -1;
                                if (iVar15 != 0) {
                                    iVar9 = 1;
                                }
                            }
                        }
                    }
                }
code_r0x00018021067d:
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210692;
                fcn.180224990(iVar14, 0x1804bb240, 0x53c);
                goto code_r0x00018021069d;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210347;
            iVar9 = (*pcVar4)();
code_r0x00018021069d:
            if (iVar9 != -2) {
                if (0 < iVar9) goto code_r0x000180210719;
                goto code_r0x0001802106a6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106e6;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106fe;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000048 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210710;
        fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000038 + iVar12 + iVar11)
                      , *(int64_t *)(&stack0x00000060 + iVar12 + iVar11));
    }
code_r0x000180210719:
    uVar7 = *(uint64_t *)((int64_t)&var_20h + iVar11);
    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210725;
    func_0x000180459870(uVar7 ^ (int64_t)&uStack_8 + iVar12 + iVar11);
    return;
}

// ============================================================
// Function: FUN_1802104e7
// Address: 0x1802104e7
// Size: 257 bytes
// ============================================================
void fcn.18020f320(int64_t arg_28h, int64_t arg_e8h, int64_t arg_140h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    code *pcVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar17;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 auStack_48 [2];
    int64_t var_40h;
    undefined4 auStack_38 [2];
    int64_t var_30h;
    int64_t var_20h;
    undefined8 uStack_10;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020f32a;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    iVar14 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11) = unaff_RBP;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -8) = unaff_RBX;
    *(undefined8 *)(&stack0x00000010 + iVar11) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar11) = unaff_RDI;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_8 + iVar11) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar11) = 0x180210308;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    *(uint64_t *)((int64_t)&var_20h + iVar11) = *(uint64_t *)0x1806a3940 ^ (int64_t)&uStack_8 + iVar12 + iVar11;
    if ((in_RCX == (undefined8 *)0x0) || (puVar13 = (undefined4 *)*in_RCX, puVar13 == (undefined4 *)0x0)) {
code_r0x0001802106a6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106ab;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106c3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000048 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106d5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000038 + iVar12 + iVar11)
                      , *(int64_t *)(&stack0x00000060 + iVar12 + iVar11));
    } else {
        pcVar4 = *(code **)(puVar13 + 0xe);
        if (pcVar4 == (code *)0x0) {
            if (((uint32_t)puVar13[4] >> 0x18 & 1) == 0) {
                uVar16 = puVar13[4] & 0xf0007;
                if (uVar16 == 6) {
                    if ((in_RDX == 0) || (iVar14 == 0)) {
                        iVar9 = 0;
                    } else {
                        uVar2 = *(undefined4 *)(iVar14 + 0x10);
                        uVar3 = *(undefined4 *)(iVar14 + 0x14);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802104ce;
                        iVar9 = func_0x00018027cf70(in_RDX, uVar3, iVar14, uVar2);
                    }
                    goto code_r0x00018021069d;
                }
                if ((uVar16 != 7) && (uVar16 != 0x10001)) {
                    if (uVar16 == 0x10002) {
                        if ((*(int64_t *)(puVar13 + 0x1c) == 0) && (*(int64_t *)(puVar13 + 0x18) == 0)) {
                            uVar2 = *puVar13;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021047b;
                            fcn.18022ccf0(uVar2);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210493;
                        iVar9 = fcn.180280ea0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000038 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000040 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000048 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000050 + iVar12 + iVar11));
                        if (iVar9 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802104a7;
                            func_0x00018025fc10(in_RDX, 5, 0);
                        }
                        goto code_r0x000180210719;
                    }
                    if (uVar16 != 0x10003) {
                        uVar17 = 0;
                        iVar9 = 0;
                        if (in_RDX != 0) {
                            *(undefined8 *)((int64_t)&var_a0h + iVar11) = 0;
                            *(undefined8 **)((int64_t)&var_18h + iVar12 + iVar11) = in_RCX + 3;
                            *(undefined4 *)((int64_t)&var_98h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_90h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_88h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_80h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_78h + iVar11) = 0;
                            *(undefined4 *)((int64_t)&var_70h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_68h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_60h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_58h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802103e8;
                            puVar13 = (undefined4 *)
                                      func_0x000180229c20((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb36c, 
                                                          (int64_t)&var_18h + iVar12 + iVar11, 0x10);
                            uVar5 = in_RCX[0x16];
                            uVar6 = *in_RCX;
                            uVar2 = puVar13[1];
                            uVar3 = puVar13[2];
                            uVar8 = puVar13[3];
                            *(undefined4 *)((int64_t)&var_a0h + iVar11) = *puVar13;
                            *(undefined4 *)((int64_t)&var_a0h + iVar11 + 4) = uVar2;
                            *(undefined4 *)((int64_t)&var_98h + iVar11) = uVar3;
                            *(undefined4 *)((int64_t)&var_98h + iVar11 + 4) = uVar8;
                            uVar2 = puVar13[5];
                            uVar3 = puVar13[6];
                            uVar8 = puVar13[7];
                            *(undefined4 *)((int64_t)&var_90h + iVar11) = puVar13[4];
                            *(undefined4 *)((int64_t)&var_90h + iVar11 + 4) = uVar2;
                            *(undefined4 *)((int64_t)&var_88h + iVar11) = uVar3;
                            *(undefined4 *)((int64_t)&var_88h + iVar11 + 4) = uVar8;
                            *(undefined8 *)((int64_t)&var_80h + iVar11) = *(undefined8 *)(puVar13 + 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210414;
                            iVar9 = fcn.180280760(uVar6, uVar5, (int64_t)&var_a0h + iVar11);
                            if (iVar9 != 0) {
                                uVar17 = *(undefined8 *)((int64_t)&var_18h + iVar12 + iVar11);
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210424;
                            uVar16 = func_0x00018020e980(in_RCX);
                            if (0x10 < uVar16) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210444;
                                func_0x00018027bb50(0x1804bb258, 0x1804bb240, 0x4b);
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210452;
                            iVar9 = func_0x00018027cdf0(in_RDX, uVar17, uVar16);
                        }
                        goto code_r0x00018021069d;
                    }
                }
            } else if (*(int64_t *)(puVar13 + 0x1c) != 0) {
                *(undefined8 *)((int64_t)&arg_140h + iVar12 + iVar11) = unaff_R12;
                iVar9 = -1;
                iVar14 = 0;
                *(undefined8 *)((int64_t)&var_18h + iVar12 + iVar11) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210516;
                puVar13 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb3e8, 0, 0);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)&var_a0h + iVar11) = *puVar13;
                *(undefined4 *)((int64_t)&var_a0h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_98h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_98h + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)&var_90h + iVar11) = puVar13[4];
                *(undefined4 *)((int64_t)&var_90h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_88h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_88h + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_80h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210546;
                puVar13 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb350, 0, 0);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)&var_78h + iVar11) = *puVar13;
                *(undefined4 *)((int64_t)&var_78h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_70h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_70h + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)&var_68h + iVar11) = puVar13[4];
                *(undefined4 *)((int64_t)&var_68h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_60h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_60h + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_58h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210569;
                puVar13 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_28h + iVar12 + iVar11);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + -8) = *puVar13;
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + -4) = uVar2;
                *(undefined4 *)((int64_t)auStack_48 + iVar11) = uVar3;
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + -8) = puVar13[4];
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + -4) = uVar2;
                *(undefined4 *)((int64_t)auStack_38 + iVar11) = uVar3;
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_30h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021058e;
                iVar10 = func_0x000180211450(in_RCX, (int64_t)&var_a0h + iVar11);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021059f;
                    iVar10 = func_0x00018022aed0((int64_t)&var_a0h + iVar11);
                    iVar15 = 0xffffffff;
                    if ((iVar10 != 0) && (iVar15 = 0xffffffff, *(int64_t *)((int64_t)&var_80h + iVar11) != 0)) {
                        iVar15 = iVar14;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802105b3;
                    iVar10 = func_0x00018022aed0((int64_t)&var_78h + iVar11);
                    if ((iVar10 == 0) || (*(int64_t *)((int64_t)&var_58h + iVar11) == 0)) {
                        if ((int32_t)iVar15 < 0) goto code_r0x00018021067d;
                    } else {
                        iVar15 = 1;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar12 + iVar11) = in_RDX;
                    *(undefined8 *)((int64_t)&arg_e8h + iVar12 + iVar11) = unaff_R13;
                    uVar7 = *(uint64_t *)((int64_t)&var_80h + iVar15 * 0x28 + iVar11);
                    puVar1 = (undefined8 *)((int64_t)&var_a0h + iVar15 * 0x28 + iVar11);
                    uVar17 = *puVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210608;
                    iVar14 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                                           *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
                    if (iVar14 != 0) {
                        *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11) = iVar14;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210628;
                        puVar13 = (undefined4 *)
                                  func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, uVar17, iVar14, uVar7);
                        uVar2 = puVar13[1];
                        uVar3 = puVar13[2];
                        uVar8 = puVar13[3];
                        *(undefined4 *)puVar1 = *puVar13;
                        *(undefined4 *)((int64_t)puVar1 + 4) = uVar2;
                        *(undefined4 *)(puVar1 + 1) = uVar3;
                        *(undefined4 *)((int64_t)puVar1 + 0xc) = uVar8;
                        uVar2 = puVar13[5];
                        uVar3 = puVar13[6];
                        uVar8 = puVar13[7];
                        *(undefined4 *)(puVar1 + 2) = puVar13[4];
                        *(undefined4 *)((int64_t)puVar1 + 0x14) = uVar2;
                        *(undefined4 *)(puVar1 + 3) = uVar3;
                        *(undefined4 *)((int64_t)puVar1 + 0x1c) = uVar8;
                        puVar1[4] = *(undefined8 *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021064c;
                        iVar10 = func_0x000180211450(in_RCX, (int64_t)&var_a0h + iVar11);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210658;
                            iVar10 = func_0x00018022aed0(puVar1);
                            if (iVar10 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021066e;
                                iVar15 = func_0x000180228a50((int64_t)&var_18h + iVar12 + iVar11, 
                                                             (int64_t)&iStackX_20 + iVar12 + iVar11, uVar7 & 0xffffffff)
                                ;
                                iVar9 = -1;
                                if (iVar15 != 0) {
                                    iVar9 = 1;
                                }
                            }
                        }
                    }
                }
code_r0x00018021067d:
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210692;
                fcn.180224990(iVar14, 0x1804bb240, 0x53c);
                goto code_r0x00018021069d;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210347;
            iVar9 = (*pcVar4)();
code_r0x00018021069d:
            if (iVar9 != -2) {
                if (0 < iVar9) goto code_r0x000180210719;
                goto code_r0x0001802106a6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106e6;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106fe;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000048 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210710;
        fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000038 + iVar12 + iVar11)
                      , *(int64_t *)(&stack0x00000060 + iVar12 + iVar11));
    }
code_r0x000180210719:
    uVar7 = *(uint64_t *)((int64_t)&var_20h + iVar11);
    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210725;
    func_0x000180459870(uVar7 ^ (int64_t)&uStack_8 + iVar12 + iVar11);
    return;
}

// ============================================================
// Function: FUN_1802105e8
// Address: 0x1802105e8
// Size: 149 bytes
// ============================================================
void fcn.18020f320(int64_t arg_28h, int64_t arg_e8h, int64_t arg_140h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    code *pcVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar17;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 auStack_48 [2];
    int64_t var_40h;
    undefined4 auStack_38 [2];
    int64_t var_30h;
    int64_t var_20h;
    undefined8 uStack_10;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020f32a;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    iVar14 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11) = unaff_RBP;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -8) = unaff_RBX;
    *(undefined8 *)(&stack0x00000010 + iVar11) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar11) = unaff_RDI;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_8 + iVar11) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar11) = 0x180210308;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    *(uint64_t *)((int64_t)&var_20h + iVar11) = *(uint64_t *)0x1806a3940 ^ (int64_t)&uStack_8 + iVar12 + iVar11;
    if ((in_RCX == (undefined8 *)0x0) || (puVar13 = (undefined4 *)*in_RCX, puVar13 == (undefined4 *)0x0)) {
code_r0x0001802106a6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106ab;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106c3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000048 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106d5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000038 + iVar12 + iVar11)
                      , *(int64_t *)(&stack0x00000060 + iVar12 + iVar11));
    } else {
        pcVar4 = *(code **)(puVar13 + 0xe);
        if (pcVar4 == (code *)0x0) {
            if (((uint32_t)puVar13[4] >> 0x18 & 1) == 0) {
                uVar16 = puVar13[4] & 0xf0007;
                if (uVar16 == 6) {
                    if ((in_RDX == 0) || (iVar14 == 0)) {
                        iVar9 = 0;
                    } else {
                        uVar2 = *(undefined4 *)(iVar14 + 0x10);
                        uVar3 = *(undefined4 *)(iVar14 + 0x14);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802104ce;
                        iVar9 = func_0x00018027cf70(in_RDX, uVar3, iVar14, uVar2);
                    }
                    goto code_r0x00018021069d;
                }
                if ((uVar16 != 7) && (uVar16 != 0x10001)) {
                    if (uVar16 == 0x10002) {
                        if ((*(int64_t *)(puVar13 + 0x1c) == 0) && (*(int64_t *)(puVar13 + 0x18) == 0)) {
                            uVar2 = *puVar13;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021047b;
                            fcn.18022ccf0(uVar2);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210493;
                        iVar9 = fcn.180280ea0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000038 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000040 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000048 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000050 + iVar12 + iVar11));
                        if (iVar9 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802104a7;
                            func_0x00018025fc10(in_RDX, 5, 0);
                        }
                        goto code_r0x000180210719;
                    }
                    if (uVar16 != 0x10003) {
                        uVar17 = 0;
                        iVar9 = 0;
                        if (in_RDX != 0) {
                            *(undefined8 *)((int64_t)&var_a0h + iVar11) = 0;
                            *(undefined8 **)((int64_t)&var_18h + iVar12 + iVar11) = in_RCX + 3;
                            *(undefined4 *)((int64_t)&var_98h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_90h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_88h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_80h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_78h + iVar11) = 0;
                            *(undefined4 *)((int64_t)&var_70h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_68h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_60h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_58h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802103e8;
                            puVar13 = (undefined4 *)
                                      func_0x000180229c20((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb36c, 
                                                          (int64_t)&var_18h + iVar12 + iVar11, 0x10);
                            uVar5 = in_RCX[0x16];
                            uVar6 = *in_RCX;
                            uVar2 = puVar13[1];
                            uVar3 = puVar13[2];
                            uVar8 = puVar13[3];
                            *(undefined4 *)((int64_t)&var_a0h + iVar11) = *puVar13;
                            *(undefined4 *)((int64_t)&var_a0h + iVar11 + 4) = uVar2;
                            *(undefined4 *)((int64_t)&var_98h + iVar11) = uVar3;
                            *(undefined4 *)((int64_t)&var_98h + iVar11 + 4) = uVar8;
                            uVar2 = puVar13[5];
                            uVar3 = puVar13[6];
                            uVar8 = puVar13[7];
                            *(undefined4 *)((int64_t)&var_90h + iVar11) = puVar13[4];
                            *(undefined4 *)((int64_t)&var_90h + iVar11 + 4) = uVar2;
                            *(undefined4 *)((int64_t)&var_88h + iVar11) = uVar3;
                            *(undefined4 *)((int64_t)&var_88h + iVar11 + 4) = uVar8;
                            *(undefined8 *)((int64_t)&var_80h + iVar11) = *(undefined8 *)(puVar13 + 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210414;
                            iVar9 = fcn.180280760(uVar6, uVar5, (int64_t)&var_a0h + iVar11);
                            if (iVar9 != 0) {
                                uVar17 = *(undefined8 *)((int64_t)&var_18h + iVar12 + iVar11);
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210424;
                            uVar16 = func_0x00018020e980(in_RCX);
                            if (0x10 < uVar16) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210444;
                                func_0x00018027bb50(0x1804bb258, 0x1804bb240, 0x4b);
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210452;
                            iVar9 = func_0x00018027cdf0(in_RDX, uVar17, uVar16);
                        }
                        goto code_r0x00018021069d;
                    }
                }
            } else if (*(int64_t *)(puVar13 + 0x1c) != 0) {
                *(undefined8 *)((int64_t)&arg_140h + iVar12 + iVar11) = unaff_R12;
                iVar9 = -1;
                iVar14 = 0;
                *(undefined8 *)((int64_t)&var_18h + iVar12 + iVar11) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210516;
                puVar13 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb3e8, 0, 0);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)&var_a0h + iVar11) = *puVar13;
                *(undefined4 *)((int64_t)&var_a0h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_98h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_98h + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)&var_90h + iVar11) = puVar13[4];
                *(undefined4 *)((int64_t)&var_90h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_88h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_88h + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_80h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210546;
                puVar13 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb350, 0, 0);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)&var_78h + iVar11) = *puVar13;
                *(undefined4 *)((int64_t)&var_78h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_70h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_70h + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)&var_68h + iVar11) = puVar13[4];
                *(undefined4 *)((int64_t)&var_68h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_60h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_60h + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_58h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210569;
                puVar13 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_28h + iVar12 + iVar11);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + -8) = *puVar13;
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + -4) = uVar2;
                *(undefined4 *)((int64_t)auStack_48 + iVar11) = uVar3;
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + -8) = puVar13[4];
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + -4) = uVar2;
                *(undefined4 *)((int64_t)auStack_38 + iVar11) = uVar3;
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_30h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021058e;
                iVar10 = func_0x000180211450(in_RCX, (int64_t)&var_a0h + iVar11);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021059f;
                    iVar10 = func_0x00018022aed0((int64_t)&var_a0h + iVar11);
                    iVar15 = 0xffffffff;
                    if ((iVar10 != 0) && (iVar15 = 0xffffffff, *(int64_t *)((int64_t)&var_80h + iVar11) != 0)) {
                        iVar15 = iVar14;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802105b3;
                    iVar10 = func_0x00018022aed0((int64_t)&var_78h + iVar11);
                    if ((iVar10 == 0) || (*(int64_t *)((int64_t)&var_58h + iVar11) == 0)) {
                        if ((int32_t)iVar15 < 0) goto code_r0x00018021067d;
                    } else {
                        iVar15 = 1;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar12 + iVar11) = in_RDX;
                    *(undefined8 *)((int64_t)&arg_e8h + iVar12 + iVar11) = unaff_R13;
                    uVar7 = *(uint64_t *)((int64_t)&var_80h + iVar15 * 0x28 + iVar11);
                    puVar1 = (undefined8 *)((int64_t)&var_a0h + iVar15 * 0x28 + iVar11);
                    uVar17 = *puVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210608;
                    iVar14 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                                           *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
                    if (iVar14 != 0) {
                        *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11) = iVar14;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210628;
                        puVar13 = (undefined4 *)
                                  func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, uVar17, iVar14, uVar7);
                        uVar2 = puVar13[1];
                        uVar3 = puVar13[2];
                        uVar8 = puVar13[3];
                        *(undefined4 *)puVar1 = *puVar13;
                        *(undefined4 *)((int64_t)puVar1 + 4) = uVar2;
                        *(undefined4 *)(puVar1 + 1) = uVar3;
                        *(undefined4 *)((int64_t)puVar1 + 0xc) = uVar8;
                        uVar2 = puVar13[5];
                        uVar3 = puVar13[6];
                        uVar8 = puVar13[7];
                        *(undefined4 *)(puVar1 + 2) = puVar13[4];
                        *(undefined4 *)((int64_t)puVar1 + 0x14) = uVar2;
                        *(undefined4 *)(puVar1 + 3) = uVar3;
                        *(undefined4 *)((int64_t)puVar1 + 0x1c) = uVar8;
                        puVar1[4] = *(undefined8 *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021064c;
                        iVar10 = func_0x000180211450(in_RCX, (int64_t)&var_a0h + iVar11);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210658;
                            iVar10 = func_0x00018022aed0(puVar1);
                            if (iVar10 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021066e;
                                iVar15 = func_0x000180228a50((int64_t)&var_18h + iVar12 + iVar11, 
                                                             (int64_t)&iStackX_20 + iVar12 + iVar11, uVar7 & 0xffffffff)
                                ;
                                iVar9 = -1;
                                if (iVar15 != 0) {
                                    iVar9 = 1;
                                }
                            }
                        }
                    }
                }
code_r0x00018021067d:
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210692;
                fcn.180224990(iVar14, 0x1804bb240, 0x53c);
                goto code_r0x00018021069d;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210347;
            iVar9 = (*pcVar4)();
code_r0x00018021069d:
            if (iVar9 != -2) {
                if (0 < iVar9) goto code_r0x000180210719;
                goto code_r0x0001802106a6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106e6;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106fe;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000048 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210710;
        fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000038 + iVar12 + iVar11)
                      , *(int64_t *)(&stack0x00000060 + iVar12 + iVar11));
    }
code_r0x000180210719:
    uVar7 = *(uint64_t *)((int64_t)&var_20h + iVar11);
    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210725;
    func_0x000180459870(uVar7 ^ (int64_t)&uStack_8 + iVar12 + iVar11);
    return;
}

// ============================================================
// Function: FUN_18021067d
// Address: 0x18021067d
// Size: 32 bytes
// ============================================================
void fcn.18020f320(int64_t arg_28h, int64_t arg_e8h, int64_t arg_140h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    code *pcVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar17;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 auStack_48 [2];
    int64_t var_40h;
    undefined4 auStack_38 [2];
    int64_t var_30h;
    int64_t var_20h;
    undefined8 uStack_10;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020f32a;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    iVar14 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11) = unaff_RBP;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -8) = unaff_RBX;
    *(undefined8 *)(&stack0x00000010 + iVar11) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar11) = unaff_RDI;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_8 + iVar11) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar11) = 0x180210308;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    *(uint64_t *)((int64_t)&var_20h + iVar11) = *(uint64_t *)0x1806a3940 ^ (int64_t)&uStack_8 + iVar12 + iVar11;
    if ((in_RCX == (undefined8 *)0x0) || (puVar13 = (undefined4 *)*in_RCX, puVar13 == (undefined4 *)0x0)) {
code_r0x0001802106a6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106ab;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106c3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000048 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106d5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000038 + iVar12 + iVar11)
                      , *(int64_t *)(&stack0x00000060 + iVar12 + iVar11));
    } else {
        pcVar4 = *(code **)(puVar13 + 0xe);
        if (pcVar4 == (code *)0x0) {
            if (((uint32_t)puVar13[4] >> 0x18 & 1) == 0) {
                uVar16 = puVar13[4] & 0xf0007;
                if (uVar16 == 6) {
                    if ((in_RDX == 0) || (iVar14 == 0)) {
                        iVar9 = 0;
                    } else {
                        uVar2 = *(undefined4 *)(iVar14 + 0x10);
                        uVar3 = *(undefined4 *)(iVar14 + 0x14);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802104ce;
                        iVar9 = func_0x00018027cf70(in_RDX, uVar3, iVar14, uVar2);
                    }
                    goto code_r0x00018021069d;
                }
                if ((uVar16 != 7) && (uVar16 != 0x10001)) {
                    if (uVar16 == 0x10002) {
                        if ((*(int64_t *)(puVar13 + 0x1c) == 0) && (*(int64_t *)(puVar13 + 0x18) == 0)) {
                            uVar2 = *puVar13;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021047b;
                            fcn.18022ccf0(uVar2);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210493;
                        iVar9 = fcn.180280ea0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000038 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000040 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000048 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000050 + iVar12 + iVar11));
                        if (iVar9 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802104a7;
                            func_0x00018025fc10(in_RDX, 5, 0);
                        }
                        goto code_r0x000180210719;
                    }
                    if (uVar16 != 0x10003) {
                        uVar17 = 0;
                        iVar9 = 0;
                        if (in_RDX != 0) {
                            *(undefined8 *)((int64_t)&var_a0h + iVar11) = 0;
                            *(undefined8 **)((int64_t)&var_18h + iVar12 + iVar11) = in_RCX + 3;
                            *(undefined4 *)((int64_t)&var_98h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_90h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_88h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_80h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_78h + iVar11) = 0;
                            *(undefined4 *)((int64_t)&var_70h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_68h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_60h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_58h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802103e8;
                            puVar13 = (undefined4 *)
                                      func_0x000180229c20((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb36c, 
                                                          (int64_t)&var_18h + iVar12 + iVar11, 0x10);
                            uVar5 = in_RCX[0x16];
                            uVar6 = *in_RCX;
                            uVar2 = puVar13[1];
                            uVar3 = puVar13[2];
                            uVar8 = puVar13[3];
                            *(undefined4 *)((int64_t)&var_a0h + iVar11) = *puVar13;
                            *(undefined4 *)((int64_t)&var_a0h + iVar11 + 4) = uVar2;
                            *(undefined4 *)((int64_t)&var_98h + iVar11) = uVar3;
                            *(undefined4 *)((int64_t)&var_98h + iVar11 + 4) = uVar8;
                            uVar2 = puVar13[5];
                            uVar3 = puVar13[6];
                            uVar8 = puVar13[7];
                            *(undefined4 *)((int64_t)&var_90h + iVar11) = puVar13[4];
                            *(undefined4 *)((int64_t)&var_90h + iVar11 + 4) = uVar2;
                            *(undefined4 *)((int64_t)&var_88h + iVar11) = uVar3;
                            *(undefined4 *)((int64_t)&var_88h + iVar11 + 4) = uVar8;
                            *(undefined8 *)((int64_t)&var_80h + iVar11) = *(undefined8 *)(puVar13 + 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210414;
                            iVar9 = fcn.180280760(uVar6, uVar5, (int64_t)&var_a0h + iVar11);
                            if (iVar9 != 0) {
                                uVar17 = *(undefined8 *)((int64_t)&var_18h + iVar12 + iVar11);
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210424;
                            uVar16 = func_0x00018020e980(in_RCX);
                            if (0x10 < uVar16) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210444;
                                func_0x00018027bb50(0x1804bb258, 0x1804bb240, 0x4b);
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210452;
                            iVar9 = func_0x00018027cdf0(in_RDX, uVar17, uVar16);
                        }
                        goto code_r0x00018021069d;
                    }
                }
            } else if (*(int64_t *)(puVar13 + 0x1c) != 0) {
                *(undefined8 *)((int64_t)&arg_140h + iVar12 + iVar11) = unaff_R12;
                iVar9 = -1;
                iVar14 = 0;
                *(undefined8 *)((int64_t)&var_18h + iVar12 + iVar11) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210516;
                puVar13 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb3e8, 0, 0);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)&var_a0h + iVar11) = *puVar13;
                *(undefined4 *)((int64_t)&var_a0h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_98h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_98h + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)&var_90h + iVar11) = puVar13[4];
                *(undefined4 *)((int64_t)&var_90h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_88h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_88h + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_80h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210546;
                puVar13 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb350, 0, 0);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)&var_78h + iVar11) = *puVar13;
                *(undefined4 *)((int64_t)&var_78h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_70h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_70h + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)&var_68h + iVar11) = puVar13[4];
                *(undefined4 *)((int64_t)&var_68h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_60h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_60h + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_58h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210569;
                puVar13 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_28h + iVar12 + iVar11);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + -8) = *puVar13;
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + -4) = uVar2;
                *(undefined4 *)((int64_t)auStack_48 + iVar11) = uVar3;
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + -8) = puVar13[4];
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + -4) = uVar2;
                *(undefined4 *)((int64_t)auStack_38 + iVar11) = uVar3;
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_30h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021058e;
                iVar10 = func_0x000180211450(in_RCX, (int64_t)&var_a0h + iVar11);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021059f;
                    iVar10 = func_0x00018022aed0((int64_t)&var_a0h + iVar11);
                    iVar15 = 0xffffffff;
                    if ((iVar10 != 0) && (iVar15 = 0xffffffff, *(int64_t *)((int64_t)&var_80h + iVar11) != 0)) {
                        iVar15 = iVar14;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802105b3;
                    iVar10 = func_0x00018022aed0((int64_t)&var_78h + iVar11);
                    if ((iVar10 == 0) || (*(int64_t *)((int64_t)&var_58h + iVar11) == 0)) {
                        if ((int32_t)iVar15 < 0) goto code_r0x00018021067d;
                    } else {
                        iVar15 = 1;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar12 + iVar11) = in_RDX;
                    *(undefined8 *)((int64_t)&arg_e8h + iVar12 + iVar11) = unaff_R13;
                    uVar7 = *(uint64_t *)((int64_t)&var_80h + iVar15 * 0x28 + iVar11);
                    puVar1 = (undefined8 *)((int64_t)&var_a0h + iVar15 * 0x28 + iVar11);
                    uVar17 = *puVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210608;
                    iVar14 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                                           *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
                    if (iVar14 != 0) {
                        *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11) = iVar14;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210628;
                        puVar13 = (undefined4 *)
                                  func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, uVar17, iVar14, uVar7);
                        uVar2 = puVar13[1];
                        uVar3 = puVar13[2];
                        uVar8 = puVar13[3];
                        *(undefined4 *)puVar1 = *puVar13;
                        *(undefined4 *)((int64_t)puVar1 + 4) = uVar2;
                        *(undefined4 *)(puVar1 + 1) = uVar3;
                        *(undefined4 *)((int64_t)puVar1 + 0xc) = uVar8;
                        uVar2 = puVar13[5];
                        uVar3 = puVar13[6];
                        uVar8 = puVar13[7];
                        *(undefined4 *)(puVar1 + 2) = puVar13[4];
                        *(undefined4 *)((int64_t)puVar1 + 0x14) = uVar2;
                        *(undefined4 *)(puVar1 + 3) = uVar3;
                        *(undefined4 *)((int64_t)puVar1 + 0x1c) = uVar8;
                        puVar1[4] = *(undefined8 *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021064c;
                        iVar10 = func_0x000180211450(in_RCX, (int64_t)&var_a0h + iVar11);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210658;
                            iVar10 = func_0x00018022aed0(puVar1);
                            if (iVar10 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021066e;
                                iVar15 = func_0x000180228a50((int64_t)&var_18h + iVar12 + iVar11, 
                                                             (int64_t)&iStackX_20 + iVar12 + iVar11, uVar7 & 0xffffffff)
                                ;
                                iVar9 = -1;
                                if (iVar15 != 0) {
                                    iVar9 = 1;
                                }
                            }
                        }
                    }
                }
code_r0x00018021067d:
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210692;
                fcn.180224990(iVar14, 0x1804bb240, 0x53c);
                goto code_r0x00018021069d;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210347;
            iVar9 = (*pcVar4)();
code_r0x00018021069d:
            if (iVar9 != -2) {
                if (0 < iVar9) goto code_r0x000180210719;
                goto code_r0x0001802106a6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106e6;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106fe;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000048 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210710;
        fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000038 + iVar12 + iVar11)
                      , *(int64_t *)(&stack0x00000060 + iVar12 + iVar11));
    }
code_r0x000180210719:
    uVar7 = *(uint64_t *)((int64_t)&var_20h + iVar11);
    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210725;
    func_0x000180459870(uVar7 ^ (int64_t)&uStack_8 + iVar12 + iVar11);
    return;
}

// ============================================================
// Function: FUN_18021069d
// Address: 0x18021069d
// Size: 152 bytes
// ============================================================
void fcn.18020f320(int64_t arg_28h, int64_t arg_e8h, int64_t arg_140h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    code *pcVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar17;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 auStack_48 [2];
    int64_t var_40h;
    undefined4 auStack_38 [2];
    int64_t var_30h;
    int64_t var_20h;
    undefined8 uStack_10;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020f32a;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    iVar14 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11) = unaff_RBP;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -8) = unaff_RBX;
    *(undefined8 *)(&stack0x00000010 + iVar11) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar11) = unaff_RDI;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_8 + iVar11) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar11) = 0x180210308;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    *(uint64_t *)((int64_t)&var_20h + iVar11) = *(uint64_t *)0x1806a3940 ^ (int64_t)&uStack_8 + iVar12 + iVar11;
    if ((in_RCX == (undefined8 *)0x0) || (puVar13 = (undefined4 *)*in_RCX, puVar13 == (undefined4 *)0x0)) {
code_r0x0001802106a6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106ab;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106c3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000048 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106d5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000038 + iVar12 + iVar11)
                      , *(int64_t *)(&stack0x00000060 + iVar12 + iVar11));
    } else {
        pcVar4 = *(code **)(puVar13 + 0xe);
        if (pcVar4 == (code *)0x0) {
            if (((uint32_t)puVar13[4] >> 0x18 & 1) == 0) {
                uVar16 = puVar13[4] & 0xf0007;
                if (uVar16 == 6) {
                    if ((in_RDX == 0) || (iVar14 == 0)) {
                        iVar9 = 0;
                    } else {
                        uVar2 = *(undefined4 *)(iVar14 + 0x10);
                        uVar3 = *(undefined4 *)(iVar14 + 0x14);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802104ce;
                        iVar9 = func_0x00018027cf70(in_RDX, uVar3, iVar14, uVar2);
                    }
                    goto code_r0x00018021069d;
                }
                if ((uVar16 != 7) && (uVar16 != 0x10001)) {
                    if (uVar16 == 0x10002) {
                        if ((*(int64_t *)(puVar13 + 0x1c) == 0) && (*(int64_t *)(puVar13 + 0x18) == 0)) {
                            uVar2 = *puVar13;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021047b;
                            fcn.18022ccf0(uVar2);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210493;
                        iVar9 = fcn.180280ea0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000038 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000040 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000048 + iVar12 + iVar11), 
                                              *(int64_t *)(&stack0x00000050 + iVar12 + iVar11));
                        if (iVar9 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802104a7;
                            func_0x00018025fc10(in_RDX, 5, 0);
                        }
                        goto code_r0x000180210719;
                    }
                    if (uVar16 != 0x10003) {
                        uVar17 = 0;
                        iVar9 = 0;
                        if (in_RDX != 0) {
                            *(undefined8 *)((int64_t)&var_a0h + iVar11) = 0;
                            *(undefined8 **)((int64_t)&var_18h + iVar12 + iVar11) = in_RCX + 3;
                            *(undefined4 *)((int64_t)&var_98h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_90h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_88h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_80h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_78h + iVar11) = 0;
                            *(undefined4 *)((int64_t)&var_70h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_68h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_60h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&var_58h + iVar11) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802103e8;
                            puVar13 = (undefined4 *)
                                      func_0x000180229c20((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb36c, 
                                                          (int64_t)&var_18h + iVar12 + iVar11, 0x10);
                            uVar5 = in_RCX[0x16];
                            uVar6 = *in_RCX;
                            uVar2 = puVar13[1];
                            uVar3 = puVar13[2];
                            uVar8 = puVar13[3];
                            *(undefined4 *)((int64_t)&var_a0h + iVar11) = *puVar13;
                            *(undefined4 *)((int64_t)&var_a0h + iVar11 + 4) = uVar2;
                            *(undefined4 *)((int64_t)&var_98h + iVar11) = uVar3;
                            *(undefined4 *)((int64_t)&var_98h + iVar11 + 4) = uVar8;
                            uVar2 = puVar13[5];
                            uVar3 = puVar13[6];
                            uVar8 = puVar13[7];
                            *(undefined4 *)((int64_t)&var_90h + iVar11) = puVar13[4];
                            *(undefined4 *)((int64_t)&var_90h + iVar11 + 4) = uVar2;
                            *(undefined4 *)((int64_t)&var_88h + iVar11) = uVar3;
                            *(undefined4 *)((int64_t)&var_88h + iVar11 + 4) = uVar8;
                            *(undefined8 *)((int64_t)&var_80h + iVar11) = *(undefined8 *)(puVar13 + 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210414;
                            iVar9 = fcn.180280760(uVar6, uVar5, (int64_t)&var_a0h + iVar11);
                            if (iVar9 != 0) {
                                uVar17 = *(undefined8 *)((int64_t)&var_18h + iVar12 + iVar11);
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210424;
                            uVar16 = func_0x00018020e980(in_RCX);
                            if (0x10 < uVar16) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210444;
                                func_0x00018027bb50(0x1804bb258, 0x1804bb240, 0x4b);
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210452;
                            iVar9 = func_0x00018027cdf0(in_RDX, uVar17, uVar16);
                        }
                        goto code_r0x00018021069d;
                    }
                }
            } else if (*(int64_t *)(puVar13 + 0x1c) != 0) {
                *(undefined8 *)((int64_t)&arg_140h + iVar12 + iVar11) = unaff_R12;
                iVar9 = -1;
                iVar14 = 0;
                *(undefined8 *)((int64_t)&var_18h + iVar12 + iVar11) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210516;
                puVar13 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb3e8, 0, 0);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)&var_a0h + iVar11) = *puVar13;
                *(undefined4 *)((int64_t)&var_a0h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_98h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_98h + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)&var_90h + iVar11) = puVar13[4];
                *(undefined4 *)((int64_t)&var_90h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_88h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_88h + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_80h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210546;
                puVar13 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, 0x1804bb350, 0, 0);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)&var_78h + iVar11) = *puVar13;
                *(undefined4 *)((int64_t)&var_78h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_70h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_70h + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)&var_68h + iVar11) = puVar13[4];
                *(undefined4 *)((int64_t)&var_68h + iVar11 + 4) = uVar2;
                *(undefined4 *)((int64_t)&var_60h + iVar11) = uVar3;
                *(undefined4 *)((int64_t)&var_60h + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_58h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210569;
                puVar13 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_28h + iVar12 + iVar11);
                uVar2 = puVar13[1];
                uVar3 = puVar13[2];
                uVar8 = puVar13[3];
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + -8) = *puVar13;
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + -4) = uVar2;
                *(undefined4 *)((int64_t)auStack_48 + iVar11) = uVar3;
                *(undefined4 *)((int64_t)auStack_48 + iVar11 + 4) = uVar8;
                uVar2 = puVar13[5];
                uVar3 = puVar13[6];
                uVar8 = puVar13[7];
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + -8) = puVar13[4];
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + -4) = uVar2;
                *(undefined4 *)((int64_t)auStack_38 + iVar11) = uVar3;
                *(undefined4 *)((int64_t)auStack_38 + iVar11 + 4) = uVar8;
                *(undefined8 *)((int64_t)&var_30h + iVar11) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021058e;
                iVar10 = func_0x000180211450(in_RCX, (int64_t)&var_a0h + iVar11);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021059f;
                    iVar10 = func_0x00018022aed0((int64_t)&var_a0h + iVar11);
                    iVar15 = 0xffffffff;
                    if ((iVar10 != 0) && (iVar15 = 0xffffffff, *(int64_t *)((int64_t)&var_80h + iVar11) != 0)) {
                        iVar15 = iVar14;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802105b3;
                    iVar10 = func_0x00018022aed0((int64_t)&var_78h + iVar11);
                    if ((iVar10 == 0) || (*(int64_t *)((int64_t)&var_58h + iVar11) == 0)) {
                        if ((int32_t)iVar15 < 0) goto code_r0x00018021067d;
                    } else {
                        iVar15 = 1;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar12 + iVar11) = in_RDX;
                    *(undefined8 *)((int64_t)&arg_e8h + iVar12 + iVar11) = unaff_R13;
                    uVar7 = *(uint64_t *)((int64_t)&var_80h + iVar15 * 0x28 + iVar11);
                    puVar1 = (undefined8 *)((int64_t)&var_a0h + iVar15 * 0x28 + iVar11);
                    uVar17 = *puVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210608;
                    iVar14 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                                           *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
                    if (iVar14 != 0) {
                        *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11) = iVar14;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210628;
                        puVar13 = (undefined4 *)
                                  func_0x000180229c70((int64_t)&arg_28h + iVar12 + iVar11, uVar17, iVar14, uVar7);
                        uVar2 = puVar13[1];
                        uVar3 = puVar13[2];
                        uVar8 = puVar13[3];
                        *(undefined4 *)puVar1 = *puVar13;
                        *(undefined4 *)((int64_t)puVar1 + 4) = uVar2;
                        *(undefined4 *)(puVar1 + 1) = uVar3;
                        *(undefined4 *)((int64_t)puVar1 + 0xc) = uVar8;
                        uVar2 = puVar13[5];
                        uVar3 = puVar13[6];
                        uVar8 = puVar13[7];
                        *(undefined4 *)(puVar1 + 2) = puVar13[4];
                        *(undefined4 *)((int64_t)puVar1 + 0x14) = uVar2;
                        *(undefined4 *)(puVar1 + 3) = uVar3;
                        *(undefined4 *)((int64_t)puVar1 + 0x1c) = uVar8;
                        puVar1[4] = *(undefined8 *)(puVar13 + 8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021064c;
                        iVar10 = func_0x000180211450(in_RCX, (int64_t)&var_a0h + iVar11);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210658;
                            iVar10 = func_0x00018022aed0(puVar1);
                            if (iVar10 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x18021066e;
                                iVar15 = func_0x000180228a50((int64_t)&var_18h + iVar12 + iVar11, 
                                                             (int64_t)&iStackX_20 + iVar12 + iVar11, uVar7 & 0xffffffff)
                                ;
                                iVar9 = -1;
                                if (iVar15 != 0) {
                                    iVar9 = 1;
                                }
                            }
                        }
                    }
                }
code_r0x00018021067d:
                *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210692;
                fcn.180224990(iVar14, 0x1804bb240, 0x53c);
                goto code_r0x00018021069d;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210347;
            iVar9 = (*pcVar4)();
code_r0x00018021069d:
            if (iVar9 != -2) {
                if (0 < iVar9) goto code_r0x000180210719;
                goto code_r0x0001802106a6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106e6;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11));
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x1802106fe;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar12 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11), 
                      *(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000048 + iVar12 + iVar11)
                     );
        *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210710;
        fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar12 + iVar11), *(int64_t *)(&stack0x00000038 + iVar12 + iVar11)
                      , *(int64_t *)(&stack0x00000060 + iVar12 + iVar11));
    }
code_r0x000180210719:
    uVar7 = *(uint64_t *)((int64_t)&var_20h + iVar11);
    *(undefined8 *)((int64_t)&uStack_10 + iVar12 + iVar11) = 0x180210725;
    func_0x000180459870(uVar7 ^ (int64_t)&uStack_8 + iVar12 + iVar11);
    return;
}

// ============================================================
// Function: FUN_180210740
// Address: 0x180210740
// Size: 75 bytes
// ============================================================
void fcn.180210740(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021074c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = *(undefined8 *)(param_1 + 0x58);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180210768;
    fcn.180224990(uVar6, 0x1804bb240, 0x363);
    uVar6 = *(undefined8 *)(param_1 + 0x68);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180210771;
    fcn.18027edb0(uVar6);
    uVar6 = *(undefined8 *)((int64_t)auStackX_18 + iVar3);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350(param_1, 0x1804bb240, 0x366);
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = uVar6;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_180210790
// Address: 0x180210790
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180210790(int64_t arg_28h, int64_t arg_30h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802107a0;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if ((in_RDX == (int64_t *)0x0) || (iVar10 = *in_RDX, iVar10 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b47;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b5f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_30h + iVar9), 
                      *(int64_t *)(&stack0x00000048 + iVar9));
        goto code_r0x000180210b64;
    }
    if (*(int64_t *)(iVar10 + 0x70) != 0) {
        if (*(int64_t *)(iVar10 + 0xd8) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a46;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a6d;
            func_0x000180211580();
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 4);
            uVar6 = *(undefined4 *)(in_RDX + 1);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xc);
            *(undefined4 *)in_RCX = *(undefined4 *)in_RDX;
            *(undefined4 *)((int64_t)in_RCX + 4) = uVar5;
            *(undefined4 *)(in_RCX + 1) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x14);
            uVar6 = *(undefined4 *)(in_RDX + 3);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x1c);
            *(undefined4 *)(in_RCX + 2) = *(undefined4 *)(in_RDX + 2);
            *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar5;
            *(undefined4 *)(in_RCX + 3) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x24);
            uVar6 = *(undefined4 *)(in_RDX + 5);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x2c);
            *(undefined4 *)(in_RCX + 4) = *(undefined4 *)(in_RDX + 4);
            *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar5;
            *(undefined4 *)(in_RCX + 5) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x34);
            uVar6 = *(undefined4 *)(in_RDX + 7);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x3c);
            *(undefined4 *)(in_RCX + 6) = *(undefined4 *)(in_RDX + 6);
            *(undefined4 *)((int64_t)in_RCX + 0x34) = uVar5;
            *(undefined4 *)(in_RCX + 7) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x3c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x44);
            uVar6 = *(undefined4 *)(in_RDX + 9);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x4c);
            *(undefined4 *)(in_RCX + 8) = *(undefined4 *)(in_RDX + 8);
            *(undefined4 *)((int64_t)in_RCX + 0x44) = uVar5;
            *(undefined4 *)(in_RCX + 9) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x4c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x54);
            uVar6 = *(undefined4 *)(in_RDX + 0xb);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x5c);
            *(undefined4 *)(in_RCX + 10) = *(undefined4 *)(in_RDX + 10);
            *(undefined4 *)((int64_t)in_RCX + 0x54) = uVar5;
            *(undefined4 *)(in_RCX + 0xb) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x5c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 100);
            uVar6 = *(undefined4 *)(in_RDX + 0xd);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x6c);
            *(undefined4 *)(in_RCX + 0xc) = *(undefined4 *)(in_RDX + 0xc);
            *(undefined4 *)((int64_t)in_RCX + 100) = uVar5;
            *(undefined4 *)(in_RCX + 0xd) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x6c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x74);
            uVar6 = *(undefined4 *)(in_RDX + 0xf);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x7c);
            *(undefined4 *)(in_RCX + 0xe) = *(undefined4 *)(in_RDX + 0xe);
            *(undefined4 *)((int64_t)in_RCX + 0x74) = uVar5;
            *(undefined4 *)(in_RCX + 0xf) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x7c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x84);
            uVar6 = *(undefined4 *)(in_RDX + 0x11);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x8c);
            *(undefined4 *)(in_RCX + 0x10) = *(undefined4 *)(in_RDX + 0x10);
            *(undefined4 *)((int64_t)in_RCX + 0x84) = uVar5;
            *(undefined4 *)(in_RCX + 0x11) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x8c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x94);
            uVar6 = *(undefined4 *)(in_RDX + 0x13);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x9c);
            *(undefined4 *)(in_RCX + 0x12) = *(undefined4 *)(in_RDX + 0x12);
            *(undefined4 *)((int64_t)in_RCX + 0x94) = uVar5;
            *(undefined4 *)(in_RCX + 0x13) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x9c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0xa4);
            uVar6 = *(undefined4 *)(in_RDX + 0x15);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xac);
            *(undefined4 *)(in_RCX + 0x14) = *(undefined4 *)(in_RDX + 0x14);
            *(undefined4 *)((int64_t)in_RCX + 0xa4) = uVar5;
            *(undefined4 *)(in_RCX + 0x15) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0xac) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0xb4);
            uVar6 = *(undefined4 *)(in_RDX + 0x17);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xbc);
            *(undefined4 *)(in_RCX + 0x16) = *(undefined4 *)(in_RDX + 0x16);
            *(undefined4 *)((int64_t)in_RCX + 0xb4) = uVar5;
            *(undefined4 *)(in_RCX + 0x17) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0xbc) = uVar7;
            in_RCX[0x16] = 0;
            iVar10 = in_RDX[0x17];
            if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x14) == 0)) {
                LOCK();
                *(int32_t *)(iVar10 + 0x78) = *(int32_t *)(iVar10 + 0x78) + 1;
                UNLOCK();
            }
            iVar10 = in_RDX[0x16];
            pcVar3 = *(code **)(*in_RDX + 0xd8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b17;
            iVar10 = (*pcVar3)(iVar10);
            in_RCX[0x16] = iVar10;
            if (iVar10 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b28;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a5e;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_30h + iVar9), 
                      *(int64_t *)(&stack0x00000048 + iVar9));
        goto code_r0x000180210b64;
    }
    if (in_RDX[1] != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802107d7;
        iVar8 = func_0x00018026b010();
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802107e0;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802107f8;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_30h + iVar9), 
                          *(int64_t *)(&stack0x00000048 + iVar9));
            goto code_r0x000180210b64;
        }
    }
    if (in_RCX != (int64_t *)0x0) {
        iVar10 = *in_RCX;
        if (iVar10 == 0) {
code_r0x0001802108e3:
            iVar10 = in_RCX[0xf];
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108f9;
            fcn.180224990(iVar10, 0x1804bb408, 0x3f);
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210902;
            fcn.18026aee0(*(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210912;
            fcn.1804986e0(in_RCX, 0, 0xc0);
        } else {
            if (*(int64_t *)(iVar10 + 0x70) == 0) {
                pcVar3 = *(code **)(iVar10 + 0x28);
                if (pcVar3 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108c6;
                    iVar8 = (*pcVar3)(in_RCX);
                    if (iVar8 == 0) goto code_r0x000180210919;
                }
                if ((in_RCX[0xf] != 0) && (*(int32_t *)(*in_RCX + 0x30) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108e3;
                    func_0x000180244fc0();
                }
                goto code_r0x0001802108e3;
            }
            iVar2 = in_RCX[0x16];
            *(undefined8 *)((int64_t)&arg_28h + iVar9) = unaff_RSI;
            if (iVar2 != 0) {
                pcVar3 = *(code **)(iVar10 + 0xd0);
                if (pcVar3 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210841;
                    (*pcVar3)();
                }
                in_RCX[0x16] = 0;
            }
            iVar10 = in_RCX[0x17];
            if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x14) == 0)) {
                LOCK();
                piVar1 = (int32_t *)(iVar10 + 0x78);
                iVar8 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar8 < 2) {
                    uVar4 = *(undefined8 *)(iVar10 + 0x60);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210883;
                    fcn.180224990(uVar4, 0x1804bb408, 0x843);
                    uVar4 = *(undefined8 *)(iVar10 + 0x70);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x18021088c;
                    fcn.18027edb0(uVar4);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108a1;
                    fcn.180224990(iVar10, 0x1804bb408, 0x846);
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108b1;
            fcn.1804986e0(in_RCX, 0, 0xc0);
        }
        *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
    }
code_r0x000180210919:
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 4);
    uVar6 = *(undefined4 *)(in_RDX + 1);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xc);
    *(undefined4 *)in_RCX = *(undefined4 *)in_RDX;
    *(undefined4 *)((int64_t)in_RCX + 4) = uVar5;
    *(undefined4 *)(in_RCX + 1) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x14);
    uVar6 = *(undefined4 *)(in_RDX + 3);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x1c);
    *(undefined4 *)(in_RCX + 2) = *(undefined4 *)(in_RDX + 2);
    *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar5;
    *(undefined4 *)(in_RCX + 3) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x24);
    uVar6 = *(undefined4 *)(in_RDX + 5);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x2c);
    *(undefined4 *)(in_RCX + 4) = *(undefined4 *)(in_RDX + 4);
    *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar5;
    *(undefined4 *)(in_RCX + 5) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x34);
    uVar6 = *(undefined4 *)(in_RDX + 7);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x3c);
    *(undefined4 *)(in_RCX + 6) = *(undefined4 *)(in_RDX + 6);
    *(undefined4 *)((int64_t)in_RCX + 0x34) = uVar5;
    *(undefined4 *)(in_RCX + 7) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x3c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x44);
    uVar6 = *(undefined4 *)(in_RDX + 9);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x4c);
    *(undefined4 *)(in_RCX + 8) = *(undefined4 *)(in_RDX + 8);
    *(undefined4 *)((int64_t)in_RCX + 0x44) = uVar5;
    *(undefined4 *)(in_RCX + 9) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x4c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x54);
    uVar6 = *(undefined4 *)(in_RDX + 0xb);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x5c);
    *(undefined4 *)(in_RCX + 10) = *(undefined4 *)(in_RDX + 10);
    *(undefined4 *)((int64_t)in_RCX + 0x54) = uVar5;
    *(undefined4 *)(in_RCX + 0xb) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x5c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 100);
    uVar6 = *(undefined4 *)(in_RDX + 0xd);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x6c);
    *(undefined4 *)(in_RCX + 0xc) = *(undefined4 *)(in_RDX + 0xc);
    *(undefined4 *)((int64_t)in_RCX + 100) = uVar5;
    *(undefined4 *)(in_RCX + 0xd) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x6c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x74);
    uVar6 = *(undefined4 *)(in_RDX + 0xf);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x7c);
    *(undefined4 *)(in_RCX + 0xe) = *(undefined4 *)(in_RDX + 0xe);
    *(undefined4 *)((int64_t)in_RCX + 0x74) = uVar5;
    *(undefined4 *)(in_RCX + 0xf) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x7c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x84);
    uVar6 = *(undefined4 *)(in_RDX + 0x11);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x8c);
    *(undefined4 *)(in_RCX + 0x10) = *(undefined4 *)(in_RDX + 0x10);
    *(undefined4 *)((int64_t)in_RCX + 0x84) = uVar5;
    *(undefined4 *)(in_RCX + 0x11) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x8c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x94);
    uVar6 = *(undefined4 *)(in_RDX + 0x13);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x9c);
    *(undefined4 *)(in_RCX + 0x12) = *(undefined4 *)(in_RDX + 0x12);
    *(undefined4 *)((int64_t)in_RCX + 0x94) = uVar5;
    *(undefined4 *)(in_RCX + 0x13) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x9c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0xa4);
    uVar6 = *(undefined4 *)(in_RDX + 0x15);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xac);
    *(undefined4 *)(in_RCX + 0x14) = *(undefined4 *)(in_RDX + 0x14);
    *(undefined4 *)((int64_t)in_RCX + 0xa4) = uVar5;
    *(undefined4 *)(in_RCX + 0x15) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0xac) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0xb4);
    uVar6 = *(undefined4 *)(in_RDX + 0x17);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xbc);
    *(undefined4 *)(in_RCX + 0x16) = *(undefined4 *)(in_RDX + 0x16);
    *(undefined4 *)((int64_t)in_RCX + 0xb4) = uVar5;
    *(undefined4 *)(in_RCX + 0x17) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0xbc) = uVar7;
    if ((in_RDX[0xf] != 0) && (*(int32_t *)(*in_RDX + 0x30) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802109b3;
        iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), 
                               *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
        in_RCX[0xf] = iVar10;
        if (iVar10 == 0) {
            *in_RCX = 0;
            return 0;
        }
        iVar2 = in_RDX[0xf];
        iVar8 = *(int32_t *)(*in_RDX + 0x30);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802109dd;
        func_0x000180498030(iVar10, iVar2, (int64_t)iVar8);
    }
    if ((*(uint32_t *)(*in_RDX + 0x10) & 0x400) != 0) {
        pcVar3 = *(code **)(*in_RDX + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a01;
        iVar8 = (*pcVar3)(in_RDX, 8, 0, in_RCX);
        if (iVar8 == 0) {
            *in_RCX = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a15;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a2d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_30h + iVar9), 
                          *(int64_t *)(&stack0x00000048 + iVar9));
code_r0x000180210b64:
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b71;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar9), *(int64_t *)(&stack0x00000038 + iVar9), 
                          *(int64_t *)(&stack0x00000060 + iVar9));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180210829
// Address: 0x180210829
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180210790(int64_t arg_28h, int64_t arg_30h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802107a0;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if ((in_RDX == (int64_t *)0x0) || (iVar10 = *in_RDX, iVar10 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b47;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b5f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_30h + iVar9), 
                      *(int64_t *)(&stack0x00000048 + iVar9));
        goto code_r0x000180210b64;
    }
    if (*(int64_t *)(iVar10 + 0x70) != 0) {
        if (*(int64_t *)(iVar10 + 0xd8) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a46;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a6d;
            func_0x000180211580();
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 4);
            uVar6 = *(undefined4 *)(in_RDX + 1);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xc);
            *(undefined4 *)in_RCX = *(undefined4 *)in_RDX;
            *(undefined4 *)((int64_t)in_RCX + 4) = uVar5;
            *(undefined4 *)(in_RCX + 1) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x14);
            uVar6 = *(undefined4 *)(in_RDX + 3);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x1c);
            *(undefined4 *)(in_RCX + 2) = *(undefined4 *)(in_RDX + 2);
            *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar5;
            *(undefined4 *)(in_RCX + 3) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x24);
            uVar6 = *(undefined4 *)(in_RDX + 5);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x2c);
            *(undefined4 *)(in_RCX + 4) = *(undefined4 *)(in_RDX + 4);
            *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar5;
            *(undefined4 *)(in_RCX + 5) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x34);
            uVar6 = *(undefined4 *)(in_RDX + 7);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x3c);
            *(undefined4 *)(in_RCX + 6) = *(undefined4 *)(in_RDX + 6);
            *(undefined4 *)((int64_t)in_RCX + 0x34) = uVar5;
            *(undefined4 *)(in_RCX + 7) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x3c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x44);
            uVar6 = *(undefined4 *)(in_RDX + 9);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x4c);
            *(undefined4 *)(in_RCX + 8) = *(undefined4 *)(in_RDX + 8);
            *(undefined4 *)((int64_t)in_RCX + 0x44) = uVar5;
            *(undefined4 *)(in_RCX + 9) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x4c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x54);
            uVar6 = *(undefined4 *)(in_RDX + 0xb);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x5c);
            *(undefined4 *)(in_RCX + 10) = *(undefined4 *)(in_RDX + 10);
            *(undefined4 *)((int64_t)in_RCX + 0x54) = uVar5;
            *(undefined4 *)(in_RCX + 0xb) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x5c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 100);
            uVar6 = *(undefined4 *)(in_RDX + 0xd);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x6c);
            *(undefined4 *)(in_RCX + 0xc) = *(undefined4 *)(in_RDX + 0xc);
            *(undefined4 *)((int64_t)in_RCX + 100) = uVar5;
            *(undefined4 *)(in_RCX + 0xd) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x6c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x74);
            uVar6 = *(undefined4 *)(in_RDX + 0xf);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x7c);
            *(undefined4 *)(in_RCX + 0xe) = *(undefined4 *)(in_RDX + 0xe);
            *(undefined4 *)((int64_t)in_RCX + 0x74) = uVar5;
            *(undefined4 *)(in_RCX + 0xf) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x7c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x84);
            uVar6 = *(undefined4 *)(in_RDX + 0x11);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x8c);
            *(undefined4 *)(in_RCX + 0x10) = *(undefined4 *)(in_RDX + 0x10);
            *(undefined4 *)((int64_t)in_RCX + 0x84) = uVar5;
            *(undefined4 *)(in_RCX + 0x11) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x8c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x94);
            uVar6 = *(undefined4 *)(in_RDX + 0x13);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x9c);
            *(undefined4 *)(in_RCX + 0x12) = *(undefined4 *)(in_RDX + 0x12);
            *(undefined4 *)((int64_t)in_RCX + 0x94) = uVar5;
            *(undefined4 *)(in_RCX + 0x13) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x9c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0xa4);
            uVar6 = *(undefined4 *)(in_RDX + 0x15);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xac);
            *(undefined4 *)(in_RCX + 0x14) = *(undefined4 *)(in_RDX + 0x14);
            *(undefined4 *)((int64_t)in_RCX + 0xa4) = uVar5;
            *(undefined4 *)(in_RCX + 0x15) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0xac) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0xb4);
            uVar6 = *(undefined4 *)(in_RDX + 0x17);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xbc);
            *(undefined4 *)(in_RCX + 0x16) = *(undefined4 *)(in_RDX + 0x16);
            *(undefined4 *)((int64_t)in_RCX + 0xb4) = uVar5;
            *(undefined4 *)(in_RCX + 0x17) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0xbc) = uVar7;
            in_RCX[0x16] = 0;
            iVar10 = in_RDX[0x17];
            if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x14) == 0)) {
                LOCK();
                *(int32_t *)(iVar10 + 0x78) = *(int32_t *)(iVar10 + 0x78) + 1;
                UNLOCK();
            }
            iVar10 = in_RDX[0x16];
            pcVar3 = *(code **)(*in_RDX + 0xd8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b17;
            iVar10 = (*pcVar3)(iVar10);
            in_RCX[0x16] = iVar10;
            if (iVar10 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b28;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a5e;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_30h + iVar9), 
                      *(int64_t *)(&stack0x00000048 + iVar9));
        goto code_r0x000180210b64;
    }
    if (in_RDX[1] != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802107d7;
        iVar8 = func_0x00018026b010();
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802107e0;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802107f8;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_30h + iVar9), 
                          *(int64_t *)(&stack0x00000048 + iVar9));
            goto code_r0x000180210b64;
        }
    }
    if (in_RCX != (int64_t *)0x0) {
        iVar10 = *in_RCX;
        if (iVar10 == 0) {
code_r0x0001802108e3:
            iVar10 = in_RCX[0xf];
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108f9;
            fcn.180224990(iVar10, 0x1804bb408, 0x3f);
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210902;
            fcn.18026aee0(*(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210912;
            fcn.1804986e0(in_RCX, 0, 0xc0);
        } else {
            if (*(int64_t *)(iVar10 + 0x70) == 0) {
                pcVar3 = *(code **)(iVar10 + 0x28);
                if (pcVar3 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108c6;
                    iVar8 = (*pcVar3)(in_RCX);
                    if (iVar8 == 0) goto code_r0x000180210919;
                }
                if ((in_RCX[0xf] != 0) && (*(int32_t *)(*in_RCX + 0x30) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108e3;
                    func_0x000180244fc0();
                }
                goto code_r0x0001802108e3;
            }
            iVar2 = in_RCX[0x16];
            *(undefined8 *)((int64_t)&arg_28h + iVar9) = unaff_RSI;
            if (iVar2 != 0) {
                pcVar3 = *(code **)(iVar10 + 0xd0);
                if (pcVar3 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210841;
                    (*pcVar3)();
                }
                in_RCX[0x16] = 0;
            }
            iVar10 = in_RCX[0x17];
            if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x14) == 0)) {
                LOCK();
                piVar1 = (int32_t *)(iVar10 + 0x78);
                iVar8 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar8 < 2) {
                    uVar4 = *(undefined8 *)(iVar10 + 0x60);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210883;
                    fcn.180224990(uVar4, 0x1804bb408, 0x843);
                    uVar4 = *(undefined8 *)(iVar10 + 0x70);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x18021088c;
                    fcn.18027edb0(uVar4);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108a1;
                    fcn.180224990(iVar10, 0x1804bb408, 0x846);
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108b1;
            fcn.1804986e0(in_RCX, 0, 0xc0);
        }
        *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
    }
code_r0x000180210919:
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 4);
    uVar6 = *(undefined4 *)(in_RDX + 1);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xc);
    *(undefined4 *)in_RCX = *(undefined4 *)in_RDX;
    *(undefined4 *)((int64_t)in_RCX + 4) = uVar5;
    *(undefined4 *)(in_RCX + 1) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x14);
    uVar6 = *(undefined4 *)(in_RDX + 3);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x1c);
    *(undefined4 *)(in_RCX + 2) = *(undefined4 *)(in_RDX + 2);
    *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar5;
    *(undefined4 *)(in_RCX + 3) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x24);
    uVar6 = *(undefined4 *)(in_RDX + 5);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x2c);
    *(undefined4 *)(in_RCX + 4) = *(undefined4 *)(in_RDX + 4);
    *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar5;
    *(undefined4 *)(in_RCX + 5) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x34);
    uVar6 = *(undefined4 *)(in_RDX + 7);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x3c);
    *(undefined4 *)(in_RCX + 6) = *(undefined4 *)(in_RDX + 6);
    *(undefined4 *)((int64_t)in_RCX + 0x34) = uVar5;
    *(undefined4 *)(in_RCX + 7) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x3c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x44);
    uVar6 = *(undefined4 *)(in_RDX + 9);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x4c);
    *(undefined4 *)(in_RCX + 8) = *(undefined4 *)(in_RDX + 8);
    *(undefined4 *)((int64_t)in_RCX + 0x44) = uVar5;
    *(undefined4 *)(in_RCX + 9) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x4c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x54);
    uVar6 = *(undefined4 *)(in_RDX + 0xb);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x5c);
    *(undefined4 *)(in_RCX + 10) = *(undefined4 *)(in_RDX + 10);
    *(undefined4 *)((int64_t)in_RCX + 0x54) = uVar5;
    *(undefined4 *)(in_RCX + 0xb) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x5c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 100);
    uVar6 = *(undefined4 *)(in_RDX + 0xd);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x6c);
    *(undefined4 *)(in_RCX + 0xc) = *(undefined4 *)(in_RDX + 0xc);
    *(undefined4 *)((int64_t)in_RCX + 100) = uVar5;
    *(undefined4 *)(in_RCX + 0xd) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x6c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x74);
    uVar6 = *(undefined4 *)(in_RDX + 0xf);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x7c);
    *(undefined4 *)(in_RCX + 0xe) = *(undefined4 *)(in_RDX + 0xe);
    *(undefined4 *)((int64_t)in_RCX + 0x74) = uVar5;
    *(undefined4 *)(in_RCX + 0xf) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x7c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x84);
    uVar6 = *(undefined4 *)(in_RDX + 0x11);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x8c);
    *(undefined4 *)(in_RCX + 0x10) = *(undefined4 *)(in_RDX + 0x10);
    *(undefined4 *)((int64_t)in_RCX + 0x84) = uVar5;
    *(undefined4 *)(in_RCX + 0x11) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x8c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x94);
    uVar6 = *(undefined4 *)(in_RDX + 0x13);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x9c);
    *(undefined4 *)(in_RCX + 0x12) = *(undefined4 *)(in_RDX + 0x12);
    *(undefined4 *)((int64_t)in_RCX + 0x94) = uVar5;
    *(undefined4 *)(in_RCX + 0x13) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x9c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0xa4);
    uVar6 = *(undefined4 *)(in_RDX + 0x15);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xac);
    *(undefined4 *)(in_RCX + 0x14) = *(undefined4 *)(in_RDX + 0x14);
    *(undefined4 *)((int64_t)in_RCX + 0xa4) = uVar5;
    *(undefined4 *)(in_RCX + 0x15) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0xac) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0xb4);
    uVar6 = *(undefined4 *)(in_RDX + 0x17);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xbc);
    *(undefined4 *)(in_RCX + 0x16) = *(undefined4 *)(in_RDX + 0x16);
    *(undefined4 *)((int64_t)in_RCX + 0xb4) = uVar5;
    *(undefined4 *)(in_RCX + 0x17) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0xbc) = uVar7;
    if ((in_RDX[0xf] != 0) && (*(int32_t *)(*in_RDX + 0x30) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802109b3;
        iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), 
                               *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
        in_RCX[0xf] = iVar10;
        if (iVar10 == 0) {
            *in_RCX = 0;
            return 0;
        }
        iVar2 = in_RDX[0xf];
        iVar8 = *(int32_t *)(*in_RDX + 0x30);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802109dd;
        func_0x000180498030(iVar10, iVar2, (int64_t)iVar8);
    }
    if ((*(uint32_t *)(*in_RDX + 0x10) & 0x400) != 0) {
        pcVar3 = *(code **)(*in_RDX + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a01;
        iVar8 = (*pcVar3)(in_RDX, 8, 0, in_RCX);
        if (iVar8 == 0) {
            *in_RCX = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a15;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a2d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_30h + iVar9), 
                          *(int64_t *)(&stack0x00000048 + iVar9));
code_r0x000180210b64:
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b71;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar9), *(int64_t *)(&stack0x00000038 + iVar9), 
                          *(int64_t *)(&stack0x00000060 + iVar9));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1802108b8
// Address: 0x1802108b8
// Size: 710 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180210790(int64_t arg_28h, int64_t arg_30h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802107a0;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if ((in_RDX == (int64_t *)0x0) || (iVar10 = *in_RDX, iVar10 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b47;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b5f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_30h + iVar9), 
                      *(int64_t *)(&stack0x00000048 + iVar9));
        goto code_r0x000180210b64;
    }
    if (*(int64_t *)(iVar10 + 0x70) != 0) {
        if (*(int64_t *)(iVar10 + 0xd8) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a46;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a6d;
            func_0x000180211580();
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 4);
            uVar6 = *(undefined4 *)(in_RDX + 1);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xc);
            *(undefined4 *)in_RCX = *(undefined4 *)in_RDX;
            *(undefined4 *)((int64_t)in_RCX + 4) = uVar5;
            *(undefined4 *)(in_RCX + 1) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x14);
            uVar6 = *(undefined4 *)(in_RDX + 3);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x1c);
            *(undefined4 *)(in_RCX + 2) = *(undefined4 *)(in_RDX + 2);
            *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar5;
            *(undefined4 *)(in_RCX + 3) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x24);
            uVar6 = *(undefined4 *)(in_RDX + 5);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x2c);
            *(undefined4 *)(in_RCX + 4) = *(undefined4 *)(in_RDX + 4);
            *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar5;
            *(undefined4 *)(in_RCX + 5) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x34);
            uVar6 = *(undefined4 *)(in_RDX + 7);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x3c);
            *(undefined4 *)(in_RCX + 6) = *(undefined4 *)(in_RDX + 6);
            *(undefined4 *)((int64_t)in_RCX + 0x34) = uVar5;
            *(undefined4 *)(in_RCX + 7) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x3c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x44);
            uVar6 = *(undefined4 *)(in_RDX + 9);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x4c);
            *(undefined4 *)(in_RCX + 8) = *(undefined4 *)(in_RDX + 8);
            *(undefined4 *)((int64_t)in_RCX + 0x44) = uVar5;
            *(undefined4 *)(in_RCX + 9) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x4c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x54);
            uVar6 = *(undefined4 *)(in_RDX + 0xb);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x5c);
            *(undefined4 *)(in_RCX + 10) = *(undefined4 *)(in_RDX + 10);
            *(undefined4 *)((int64_t)in_RCX + 0x54) = uVar5;
            *(undefined4 *)(in_RCX + 0xb) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x5c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 100);
            uVar6 = *(undefined4 *)(in_RDX + 0xd);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x6c);
            *(undefined4 *)(in_RCX + 0xc) = *(undefined4 *)(in_RDX + 0xc);
            *(undefined4 *)((int64_t)in_RCX + 100) = uVar5;
            *(undefined4 *)(in_RCX + 0xd) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x6c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x74);
            uVar6 = *(undefined4 *)(in_RDX + 0xf);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x7c);
            *(undefined4 *)(in_RCX + 0xe) = *(undefined4 *)(in_RDX + 0xe);
            *(undefined4 *)((int64_t)in_RCX + 0x74) = uVar5;
            *(undefined4 *)(in_RCX + 0xf) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x7c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x84);
            uVar6 = *(undefined4 *)(in_RDX + 0x11);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x8c);
            *(undefined4 *)(in_RCX + 0x10) = *(undefined4 *)(in_RDX + 0x10);
            *(undefined4 *)((int64_t)in_RCX + 0x84) = uVar5;
            *(undefined4 *)(in_RCX + 0x11) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x8c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x94);
            uVar6 = *(undefined4 *)(in_RDX + 0x13);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x9c);
            *(undefined4 *)(in_RCX + 0x12) = *(undefined4 *)(in_RDX + 0x12);
            *(undefined4 *)((int64_t)in_RCX + 0x94) = uVar5;
            *(undefined4 *)(in_RCX + 0x13) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x9c) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0xa4);
            uVar6 = *(undefined4 *)(in_RDX + 0x15);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xac);
            *(undefined4 *)(in_RCX + 0x14) = *(undefined4 *)(in_RDX + 0x14);
            *(undefined4 *)((int64_t)in_RCX + 0xa4) = uVar5;
            *(undefined4 *)(in_RCX + 0x15) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0xac) = uVar7;
            uVar5 = *(undefined4 *)((int64_t)in_RDX + 0xb4);
            uVar6 = *(undefined4 *)(in_RDX + 0x17);
            uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xbc);
            *(undefined4 *)(in_RCX + 0x16) = *(undefined4 *)(in_RDX + 0x16);
            *(undefined4 *)((int64_t)in_RCX + 0xb4) = uVar5;
            *(undefined4 *)(in_RCX + 0x17) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0xbc) = uVar7;
            in_RCX[0x16] = 0;
            iVar10 = in_RDX[0x17];
            if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x14) == 0)) {
                LOCK();
                *(int32_t *)(iVar10 + 0x78) = *(int32_t *)(iVar10 + 0x78) + 1;
                UNLOCK();
            }
            iVar10 = in_RDX[0x16];
            pcVar3 = *(code **)(*in_RDX + 0xd8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b17;
            iVar10 = (*pcVar3)(iVar10);
            in_RCX[0x16] = iVar10;
            if (iVar10 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b28;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a5e;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_30h + iVar9), 
                      *(int64_t *)(&stack0x00000048 + iVar9));
        goto code_r0x000180210b64;
    }
    if (in_RDX[1] != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802107d7;
        iVar8 = func_0x00018026b010();
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802107e0;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802107f8;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_30h + iVar9), 
                          *(int64_t *)(&stack0x00000048 + iVar9));
            goto code_r0x000180210b64;
        }
    }
    if (in_RCX != (int64_t *)0x0) {
        iVar10 = *in_RCX;
        if (iVar10 == 0) {
code_r0x0001802108e3:
            iVar10 = in_RCX[0xf];
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108f9;
            fcn.180224990(iVar10, 0x1804bb408, 0x3f);
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210902;
            fcn.18026aee0(*(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210912;
            fcn.1804986e0(in_RCX, 0, 0xc0);
        } else {
            if (*(int64_t *)(iVar10 + 0x70) == 0) {
                pcVar3 = *(code **)(iVar10 + 0x28);
                if (pcVar3 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108c6;
                    iVar8 = (*pcVar3)(in_RCX);
                    if (iVar8 == 0) goto code_r0x000180210919;
                }
                if ((in_RCX[0xf] != 0) && (*(int32_t *)(*in_RCX + 0x30) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108e3;
                    func_0x000180244fc0();
                }
                goto code_r0x0001802108e3;
            }
            iVar2 = in_RCX[0x16];
            *(undefined8 *)((int64_t)&arg_28h + iVar9) = unaff_RSI;
            if (iVar2 != 0) {
                pcVar3 = *(code **)(iVar10 + 0xd0);
                if (pcVar3 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210841;
                    (*pcVar3)();
                }
                in_RCX[0x16] = 0;
            }
            iVar10 = in_RCX[0x17];
            if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x14) == 0)) {
                LOCK();
                piVar1 = (int32_t *)(iVar10 + 0x78);
                iVar8 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar8 < 2) {
                    uVar4 = *(undefined8 *)(iVar10 + 0x60);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210883;
                    fcn.180224990(uVar4, 0x1804bb408, 0x843);
                    uVar4 = *(undefined8 *)(iVar10 + 0x70);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x18021088c;
                    fcn.18027edb0(uVar4);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108a1;
                    fcn.180224990(iVar10, 0x1804bb408, 0x846);
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802108b1;
            fcn.1804986e0(in_RCX, 0, 0xc0);
        }
        *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
    }
code_r0x000180210919:
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 4);
    uVar6 = *(undefined4 *)(in_RDX + 1);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xc);
    *(undefined4 *)in_RCX = *(undefined4 *)in_RDX;
    *(undefined4 *)((int64_t)in_RCX + 4) = uVar5;
    *(undefined4 *)(in_RCX + 1) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x14);
    uVar6 = *(undefined4 *)(in_RDX + 3);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x1c);
    *(undefined4 *)(in_RCX + 2) = *(undefined4 *)(in_RDX + 2);
    *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar5;
    *(undefined4 *)(in_RCX + 3) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x24);
    uVar6 = *(undefined4 *)(in_RDX + 5);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x2c);
    *(undefined4 *)(in_RCX + 4) = *(undefined4 *)(in_RDX + 4);
    *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar5;
    *(undefined4 *)(in_RCX + 5) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x34);
    uVar6 = *(undefined4 *)(in_RDX + 7);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x3c);
    *(undefined4 *)(in_RCX + 6) = *(undefined4 *)(in_RDX + 6);
    *(undefined4 *)((int64_t)in_RCX + 0x34) = uVar5;
    *(undefined4 *)(in_RCX + 7) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x3c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x44);
    uVar6 = *(undefined4 *)(in_RDX + 9);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x4c);
    *(undefined4 *)(in_RCX + 8) = *(undefined4 *)(in_RDX + 8);
    *(undefined4 *)((int64_t)in_RCX + 0x44) = uVar5;
    *(undefined4 *)(in_RCX + 9) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x4c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x54);
    uVar6 = *(undefined4 *)(in_RDX + 0xb);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x5c);
    *(undefined4 *)(in_RCX + 10) = *(undefined4 *)(in_RDX + 10);
    *(undefined4 *)((int64_t)in_RCX + 0x54) = uVar5;
    *(undefined4 *)(in_RCX + 0xb) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x5c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 100);
    uVar6 = *(undefined4 *)(in_RDX + 0xd);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x6c);
    *(undefined4 *)(in_RCX + 0xc) = *(undefined4 *)(in_RDX + 0xc);
    *(undefined4 *)((int64_t)in_RCX + 100) = uVar5;
    *(undefined4 *)(in_RCX + 0xd) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x6c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x74);
    uVar6 = *(undefined4 *)(in_RDX + 0xf);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x7c);
    *(undefined4 *)(in_RCX + 0xe) = *(undefined4 *)(in_RDX + 0xe);
    *(undefined4 *)((int64_t)in_RCX + 0x74) = uVar5;
    *(undefined4 *)(in_RCX + 0xf) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x7c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x84);
    uVar6 = *(undefined4 *)(in_RDX + 0x11);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x8c);
    *(undefined4 *)(in_RCX + 0x10) = *(undefined4 *)(in_RDX + 0x10);
    *(undefined4 *)((int64_t)in_RCX + 0x84) = uVar5;
    *(undefined4 *)(in_RCX + 0x11) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x8c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0x94);
    uVar6 = *(undefined4 *)(in_RDX + 0x13);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0x9c);
    *(undefined4 *)(in_RCX + 0x12) = *(undefined4 *)(in_RDX + 0x12);
    *(undefined4 *)((int64_t)in_RCX + 0x94) = uVar5;
    *(undefined4 *)(in_RCX + 0x13) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x9c) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0xa4);
    uVar6 = *(undefined4 *)(in_RDX + 0x15);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xac);
    *(undefined4 *)(in_RCX + 0x14) = *(undefined4 *)(in_RDX + 0x14);
    *(undefined4 *)((int64_t)in_RCX + 0xa4) = uVar5;
    *(undefined4 *)(in_RCX + 0x15) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0xac) = uVar7;
    uVar5 = *(undefined4 *)((int64_t)in_RDX + 0xb4);
    uVar6 = *(undefined4 *)(in_RDX + 0x17);
    uVar7 = *(undefined4 *)((int64_t)in_RDX + 0xbc);
    *(undefined4 *)(in_RCX + 0x16) = *(undefined4 *)(in_RDX + 0x16);
    *(undefined4 *)((int64_t)in_RCX + 0xb4) = uVar5;
    *(undefined4 *)(in_RCX + 0x17) = uVar6;
    *(undefined4 *)((int64_t)in_RCX + 0xbc) = uVar7;
    if ((in_RDX[0xf] != 0) && (*(int32_t *)(*in_RDX + 0x30) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802109b3;
        iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), 
                               *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
        in_RCX[0xf] = iVar10;
        if (iVar10 == 0) {
            *in_RCX = 0;
            return 0;
        }
        iVar2 = in_RDX[0xf];
        iVar8 = *(int32_t *)(*in_RDX + 0x30);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802109dd;
        func_0x000180498030(iVar10, iVar2, (int64_t)iVar8);
    }
    if ((*(uint32_t *)(*in_RDX + 0x10) & 0x400) != 0) {
        pcVar3 = *(code **)(*in_RDX + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a01;
        iVar8 = (*pcVar3)(in_RDX, 8, 0, in_RCX);
        if (iVar8 == 0) {
            *in_RCX = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a15;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210a2d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_30h + iVar9), 
                          *(int64_t *)(&stack0x00000048 + iVar9));
code_r0x000180210b64:
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180210b71;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar9), *(int64_t *)(&stack0x00000038 + iVar9), 
                          *(int64_t *)(&stack0x00000060 + iVar9));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180210b80
// Address: 0x180210b80
// Size: 2192 bytes
// ============================================================
void fcn.180210b80(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    bool bVar6;
    bool bVar7;
    int32_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t *in_RCX;
    int64_t iVar11;
    undefined4 in_EDX;
    undefined8 uVar12;
    int64_t iVar13;
    int32_t in_R8D;
    undefined8 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180210b94;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    bVar7 = false;
    *(int64_t *)((int64_t)aiStackX_18 + iVar9 + -0x18) = (int64_t)in_R8D;
    bVar6 = true;
    *(undefined8 *)((int64_t)&arg_40h + iVar9) = 0;
    *(undefined4 *)((int64_t)&arg_48h + iVar9) = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar9) = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar9) = 0;
    if ((in_RCX == (int64_t *)0x0) || (iVar13 = *in_RCX, iVar13 == 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180211329;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar9));
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180211341;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar9), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar9 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar9), 
                      *(int64_t *)(&stack0x00000030 + iVar9));
        goto code_r0x000180211346;
    }
    if (*(int64_t *)(iVar13 + 0x70) == 0) {
        pcVar1 = *(code **)(iVar13 + 0x48);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210c60;
            iVar8 = (*pcVar1)();
            goto code_r0x0001802112fb;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210c38;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar9));
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210c50;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar9), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar9 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar9), 
                      *(int64_t *)(&stack0x00000030 + iVar9));
        goto code_r0x000180211346;
    }
    // switch table (40 cases) at 0x180211370
    switch(in_EDX) {
    case 0:
        goto code_r0x000180211355;
    case 1:
        if ((in_R8D < 0) || (*(int32_t *)(in_RCX + 0xd) == in_R8D)) goto code_r0x000180211355;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210cad;
        puVar10 = (undefined4 *)
                  fcn.180229cc0((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb2f4, (int64_t)aiStackX_18 + iVar9 + -0x18);
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        *(undefined4 *)(in_RCX + 0xd) = 0xffffffff;
        break;
    case 2:
        bVar6 = bVar7;
    case 3:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210f56;
        puVar10 = (undefined4 *)
                  fcn.180229cc0((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb650, (int64_t)aiStackX_18 + iVar9 + -0x18);
code_r0x000180210f56:
        iVar13 = in_RCX[0x16];
        iVar11 = *in_RCX;
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        if (!bVar6) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210f8d;
            iVar8 = fcn.180280760(iVar11, iVar13, (int64_t)&arg_40h + iVar9);
            goto code_r0x0001802112fb;
        }
        goto code_r0x0001802112f1;
    case 4:
        bVar6 = bVar7;
    case 5:
        if (in_R8D < 0) goto code_r0x000180211355;
        *(int32_t *)((int64_t)&var_8h + iVar9) = in_R8D;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210e56;
        puVar10 = (undefined4 *)fcn.180229d80((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb624, (int64_t)&var_8h + iVar9);
        goto code_r0x000180210f56;
    case 6:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210ce3;
        puVar10 = (undefined4 *)func_0x000180229c70((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb5f0, in_R9);
        iVar13 = in_RCX[0x16];
        iVar11 = *in_RCX;
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210d12;
        iVar8 = fcn.180280760(iVar11, iVar13, (int64_t)&arg_40h + iVar9);
        goto code_r0x0001802112fb;
    default:
        goto code_r0x000180211300;
    case 9:
        if ((in_R8D < 0) || (*(int32_t *)((int64_t)in_RCX + 0x6c) == in_R8D)) goto code_r0x000180211355;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210d3c;
        puVar10 = (undefined4 *)
                  fcn.180229cc0((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb2ec, (int64_t)aiStackX_18 + iVar9 + -0x18);
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
        break;
    case 0x10:
        bVar6 = bVar7;
    case 0x11:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210e9b;
        puVar10 = (undefined4 *)func_0x000180229c70((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb634, in_R9);
        goto code_r0x000180210f56;
    case 0x12:
        uVar12 = 0x1804bb5f8;
        goto code_r0x0001802112bf;
    case 0x13:
        iVar13 = (int64_t)in_R8D;
        if (in_R8D < 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar9 + -0x18) = 0;
            iVar13 = 0;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210de6;
        puVar10 = (undefined4 *)func_0x000180229c70((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb608, in_R9, iVar13);
        iVar13 = in_RCX[0x16];
        iVar11 = *in_RCX;
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210e15;
        iVar8 = fcn.180280760(iVar11, iVar13, (int64_t)&arg_40h + iVar9);
        goto code_r0x0001802112fb;
    case 0x14:
        if (6 < in_R8D - 2U) goto code_r0x000180211355;
        *(int64_t *)((int64_t)aiStackX_18 + iVar9 + -0x18) = (int64_t)(0xf - in_R8D);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210d97;
        puVar10 = (undefined4 *)
                  fcn.180229cc0((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb2ec, (int64_t)aiStackX_18 + iVar9 + -0x18);
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
        break;
    case 0x16:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210eb4;
        puVar10 = (undefined4 *)func_0x000180229c70((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb638, in_R9);
        iVar13 = in_RCX[0x16];
        iVar11 = *in_RCX;
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210ee3;
        iVar8 = fcn.1802807b0(iVar11, iVar13, (int64_t)&arg_40h + iVar9);
        if (0 < iVar8) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210f01;
            puVar10 = (undefined4 *)
                      fcn.180229cc0((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb640, (int64_t)aiStackX_18 + iVar9 + -0x18
                                   );
            iVar13 = in_RCX[0x16];
            iVar11 = *in_RCX;
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
            *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
            *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
            *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
            uVar3 = puVar10[5];
            uVar4 = puVar10[6];
            uVar5 = puVar10[7];
            *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
            *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
            *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
            *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210f30;
            iVar8 = fcn.180280760(iVar11, iVar13, (int64_t)&arg_40h + iVar9);
            if (0 < iVar8) goto code_r0x000180211355;
        }
        goto code_r0x0001802112fb;
    case 0x17:
        if (in_R8D < 0) goto code_r0x000180211355;
        uVar12 = 0x1804bb6fc;
        goto code_r0x0001802112bf;
    case 0x18:
        if (in_R8D < 0) goto code_r0x000180211355;
        uVar12 = 0x1804bb618;
code_r0x0001802112bf:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802112cc;
        puVar10 = (undefined4 *)func_0x000180229c70((int64_t)aiStackX_18 + iVar9 + -8, uVar12, in_R9);
code_r0x0001802112cc:
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        break;
    case 0x19:
        if (in_R8D < 0x20) goto code_r0x000180211355;
        uVar12 = in_R9[2];
        uVar2 = in_R9[1];
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180211088;
        puVar10 = (undefined4 *)func_0x000180229c70((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb688, uVar2, uVar12);
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802110b8;
        fcn.180229d80((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb698, in_R9 + 3);
        iVar13 = in_RCX[0x16];
        iVar11 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802110e5;
        iVar8 = fcn.1802807b0(iVar11, iVar13, (int64_t)&arg_40h + iVar9);
        if (iVar8 < 1) goto code_r0x000180211355;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180211103;
        puVar10 = (undefined4 *)
                  fcn.180229cc0((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb6b0, (int64_t)aiStackX_18 + iVar9 + -0x18);
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180211133;
        fcn.180229d80((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb698, in_R9 + 3);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180211156;
        func_0x000180229ba0((int64_t)aiStackX_18 + iVar9 + -8);
        goto code_r0x000180211033;
    case 0x1a:
        uVar12 = in_R9[2];
        uVar2 = *in_R9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18021118c;
        puVar10 = (undefined4 *)func_0x000180229c70((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb6c8, uVar2, uVar12);
        uVar12 = in_R9[2];
        uVar2 = in_R9[1];
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802111c0;
        func_0x000180229c70((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb6d8, uVar2, uVar12);
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802111ee;
        fcn.180229d80((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb698, in_R9 + 3);
        iVar13 = in_RCX[0x16];
        iVar11 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18021121b;
        iVar8 = fcn.1802807b0(iVar11, iVar13, (int64_t)&arg_40h + iVar9);
        if (0 < iVar8) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180211239;
            puVar10 = (undefined4 *)
                      fcn.180229cc0((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb6e8, (int64_t)aiStackX_18 + iVar9 + -0x18
                                   );
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
            *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
            *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
            *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
            uVar3 = puVar10[5];
            uVar4 = puVar10[6];
            uVar5 = puVar10[7];
            *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
            *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
            *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
            *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18021125e;
            func_0x000180229ba0((int64_t)aiStackX_18 + iVar9 + -8);
            iVar13 = in_RCX[0x16];
            iVar11 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18021128b;
            fcn.180280760(iVar11, iVar13, (int64_t)&arg_40h + iVar9);
        }
        goto code_r0x000180211355;
    case 0x1c:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210fa8;
        puVar10 = (undefined4 *)
                  fcn.180229cc0((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb658, (int64_t)aiStackX_18 + iVar9 + -0x18);
        iVar13 = in_RCX[0x16];
        iVar11 = *in_RCX;
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210fd7;
        iVar8 = fcn.1802807b0(iVar11, iVar13, (int64_t)&arg_40h + iVar9);
        if (iVar8 < 1) goto code_r0x000180211355;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210ff5;
        puVar10 = (undefined4 *)
                  fcn.180229cc0((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb670, (int64_t)aiStackX_18 + iVar9 + -0x18);
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_40h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_40h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_50h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = uVar4;
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18021101a;
        func_0x000180229ba0((int64_t)aiStackX_18 + iVar9 + -8);
code_r0x000180211033:
        iVar13 = in_RCX[0x16];
        iVar11 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180211047;
        fcn.180280760(iVar11, iVar13, (int64_t)&arg_40h + iVar9);
        goto code_r0x000180211355;
    case 0x27:
        if (in_R8D < 0) goto code_r0x000180211355;
        *(int32_t *)((int64_t)&var_8h + iVar9) = in_R8D;
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180210e7f;
        puVar10 = (undefined4 *)fcn.180229d80((int64_t)aiStackX_18 + iVar9 + -8, 0x1804bb62c, (int64_t)&var_8h + iVar9);
        goto code_r0x0001802112cc;
    }
    iVar13 = in_RCX[0x16];
    iVar11 = *in_RCX;
code_r0x0001802112f1:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802112fb;
    iVar8 = fcn.1802807b0(iVar11, iVar13, (int64_t)&arg_40h + iVar9);
code_r0x0001802112fb:
    if (iVar8 == -1) {
code_r0x000180211300:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180211305;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar9 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar9));
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x18021131d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar9 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar9), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar9 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar9), 
                      *(int64_t *)(&stack0x00000030 + iVar9));
code_r0x000180211346:
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180211353;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_18 + iVar9), *(int64_t *)((int64_t)aiStackX_18 + iVar9 + 8), 
                      *(int64_t *)((int64_t)&arg_48h + iVar9));
    }
code_r0x000180211355:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180211361;
    func_0x000180459870(var_38h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_180211410
// Address: 0x180211410
// Size: 54 bytes
// ============================================================
void fcn.180211410(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180211420;
        iVar1 = fcn.18045a350();
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x18021142b;
        fcn.180211580();
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180211440;
        fcn.180224990(arg1, 0x1804bb408, 0x59);
    }
    return;
}

// ============================================================
// Function: FUN_180211450
// Address: 0x180211450
// Size: 54 bytes
// ============================================================
undefined8 fcn.180211450(int64_t *param_1)
{
    code *UNRECOVERED_JUMPTABLE;
    undefined8 uVar1;
    
    fcn.18045a350();
    if ((*param_1 != 0) && (UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xe8), UNRECOVERED_JUMPTABLE != (code *)0x0))
    {
    // WARNING: Could not recover jumptable at 0x00018021147c. Too many branches
    // WARNING: Treating indirect jump as call
        uVar1 = (*UNRECOVERED_JUMPTABLE)(param_1[0x16]);
        return uVar1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180211490
// Address: 0x180211490
// Size: 58 bytes
// ============================================================
void fcn.180211490(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021149a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x1802114b4;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + -iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined4 *)(iVar1 + 0x6c) = 0xffffffff;
    return;
}

// ============================================================
// Function: FUN_1802114d0
// Address: 0x1802114d0
// Size: 165 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1802114d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint64_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    bool bVar5;
    bool bVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    undefined8 uVar12;
    int64_t iVar13;
    int64_t *in_RCX;
    int64_t iVar14;
    undefined8 *in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar15;
    undefined4 uVar16;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_98;
    undefined8 uStack_90;
    undefined4 auStack_88 [2];
    undefined8 uStack_80;
    undefined8 uStack_78;
    undefined8 uStack_70;
    undefined8 uStack_68;
    undefined4 auStack_60 [2];
    undefined8 uStack_58;
    undefined8 uStack_50;
    undefined8 auStack_48 [2];
    undefined4 auStack_38 [2];
    uint64_t auStack_30 [5];
    
    auStack_30[4] = 0x1802114e0;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    iVar8 = *in_RCX;
    if ((*(uint32_t *)(iVar8 + 0x10) & 0x200) == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar11) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar11) = unaff_RDI;
        uVar12 = 0;
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)auStack_30 + iVar11 + 0x20) = 0x18021152c;
            uVar12 = func_0x00018020eec0();
            *(undefined8 *)((int64_t)auStack_30 + iVar11 + 0x20) = 0x180211534;
            uVar12 = fcn.18027f1e0(uVar12);
        }
        *(undefined8 *)((int64_t)auStack_30 + iVar11 + 0x20) = 0x18021153f;
        iVar7 = func_0x00018020eae0(in_RCX);
        if (iVar7 < 1) {
            uVar10 = 0;
        } else {
            *(undefined8 *)((int64_t)auStack_30 + iVar11 + 0x20) = 0x180211554;
            iVar7 = func_0x00018021be60(uVar12, in_RDX, (int64_t)iVar7, 0);
            uVar10 = (uint64_t)(0 < iVar7);
        }
        return uVar10;
    }
    iVar7 = 0;
    uVar15 = 6;
    uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar11);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -8) = *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -8);
    *(undefined8 *)(&stack0x00000010 + iVar11) = uVar12;
    *(undefined8 *)(&stack0x00000008 + iVar11) = unaff_RSI;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar11 + -0x20) = unaff_RDI;
    puVar1 = (uint64_t *)((int64_t)auStack_30 + iVar11 + 0x18);
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar11) = 0x180210b94;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *puVar1 = *(uint64_t *)0x1806a3940 ^ (int64_t)&iStackX_20 + iVar8 + iVar11 + -0x20;
    bVar6 = false;
    *(int64_t *)((int64_t)&iStackX_20 + iVar8 + iVar11) = (int64_t)iVar7;
    bVar5 = true;
    *(undefined8 *)(&stack0x00000060 + iVar8 + iVar11) = 0;
    *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = 0;
    *(undefined8 *)(&stack0x00000070 + iVar8 + iVar11) = 0;
    *(undefined8 *)(&stack0x00000078 + iVar8 + iVar11) = 0;
    *(undefined8 *)((int64_t)&uStack_98 + iVar11) = 0;
    *(undefined8 *)((int64_t)&uStack_90 + iVar11) = 0;
    *(undefined4 *)((int64_t)auStack_88 + iVar11) = 0;
    *(undefined8 *)((int64_t)&uStack_80 + iVar11) = 0;
    *(undefined8 *)((int64_t)&uStack_78 + iVar11) = 0;
    *(undefined8 *)((int64_t)&uStack_70 + iVar11) = 0;
    *(undefined8 *)((int64_t)&uStack_68 + iVar11) = 0;
    *(undefined4 *)((int64_t)auStack_60 + iVar11) = 0;
    *(undefined8 *)((int64_t)&uStack_58 + iVar11) = 0;
    *(undefined8 *)((int64_t)&uStack_50 + iVar11) = 0;
    *(undefined8 *)((int64_t)auStack_48 + iVar11) = 0;
    *(undefined8 *)((int64_t)auStack_48 + iVar11 + 8) = 0;
    *(undefined4 *)((int64_t)auStack_38 + iVar11) = 0;
    *(undefined8 *)((int64_t)auStack_30 + iVar11) = 0;
    *(undefined8 *)((int64_t)auStack_30 + iVar11 + 8) = 0;
    *(undefined8 *)((int64_t)auStack_30 + iVar11 + 0x10) = 0;
    if ((in_RCX == (int64_t *)0x0) || (iVar14 = *in_RCX, iVar14 == 0)) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180211329;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar8 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar11));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180211341;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar8 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar11), *(int64_t *)((int64_t)&arg_30h + iVar8 + iVar11)
                      , *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar11), 
                      *(int64_t *)(&stack0x00000050 + iVar8 + iVar11));
        goto code_r0x000180211346;
    }
    if (*(int64_t *)(iVar14 + 0x70) == 0) {
        pcVar2 = *(code **)(iVar14 + 0x48);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210c60;
            iVar7 = (*pcVar2)();
            goto code_r0x0001802112fb;
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210c38;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar8 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar11));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210c50;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar8 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar11), *(int64_t *)((int64_t)&arg_30h + iVar8 + iVar11)
                      , *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar11), 
                      *(int64_t *)(&stack0x00000050 + iVar8 + iVar11));
        goto code_r0x000180211346;
    }
    switch(uVar15) {
    case 0:
        goto code_r0x000180211355;
    case 1:
        if ((iVar7 < 0) || (*(int32_t *)(in_RCX + 0xd) == iVar7)) goto code_r0x000180211355;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210cad;
        puVar9 = (undefined4 *)
                 fcn.180229cc0((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb2f4, (int64_t)&iStackX_20 + iVar8 + iVar11);
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        uVar15 = (undefined4)*(undefined8 *)(puVar9 + 8);
        uVar16 = (undefined4)((uint64_t)*(undefined8 *)(puVar9 + 8) >> 0x20);
        *(undefined4 *)(in_RCX + 0xd) = 0xffffffff;
        break;
    case 2:
        bVar5 = bVar6;
    case 3:
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210f56;
        puVar9 = (undefined4 *)
                 fcn.180229cc0((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb650, (int64_t)&iStackX_20 + iVar8 + iVar11);
code_r0x000180210f56:
        iVar14 = in_RCX[0x16];
        iVar13 = *in_RCX;
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        *(undefined8 *)((int64_t)&uStack_98 + iVar11) = *(undefined8 *)(puVar9 + 8);
        if (!bVar5) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210f8d;
            iVar7 = fcn.180280760(iVar13, iVar14, &stack0x00000060 + iVar8 + iVar11);
            goto code_r0x0001802112fb;
        }
        goto code_r0x0001802112f1;
    case 4:
        bVar5 = bVar6;
    case 5:
        if (iVar7 < 0) goto code_r0x000180211355;
        *(int32_t *)((int64_t)&arg_28h + iVar8 + iVar11) = iVar7;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210e56;
        puVar9 = (undefined4 *)
                 fcn.180229d80((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb624, (int64_t)&arg_28h + iVar8 + iVar11);
        goto code_r0x000180210f56;
    case 6:
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210ce3;
        puVar9 = (undefined4 *)func_0x000180229c70((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb5f0, in_RDX);
        iVar14 = in_RCX[0x16];
        iVar13 = *in_RCX;
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        *(undefined8 *)((int64_t)&uStack_98 + iVar11) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210d12;
        iVar7 = fcn.180280760(iVar13, iVar14, &stack0x00000060 + iVar8 + iVar11);
        goto code_r0x0001802112fb;
    default:
        goto code_r0x000180211300;
    case 9:
        if ((iVar7 < 0) || (*(int32_t *)((int64_t)in_RCX + 0x6c) == iVar7)) goto code_r0x000180211355;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210d3c;
        puVar9 = (undefined4 *)
                 fcn.180229cc0((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb2ec, (int64_t)&iStackX_20 + iVar8 + iVar11);
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        uVar15 = (undefined4)*(undefined8 *)(puVar9 + 8);
        uVar16 = (undefined4)((uint64_t)*(undefined8 *)(puVar9 + 8) >> 0x20);
        *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
        break;
    case 0x10:
        bVar5 = bVar6;
    case 0x11:
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210e9b;
        puVar9 = (undefined4 *)func_0x000180229c70((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb634, in_RDX);
        goto code_r0x000180210f56;
    case 0x12:
        uVar12 = 0x1804bb5f8;
        goto code_r0x0001802112bf;
    case 0x13:
        iVar14 = (int64_t)iVar7;
        if (iVar7 < 0) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar8 + iVar11) = 0;
            iVar14 = 0;
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210de6;
        puVar9 = (undefined4 *)func_0x000180229c70((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb608, in_RDX, iVar14);
        iVar14 = in_RCX[0x16];
        iVar13 = *in_RCX;
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        *(undefined8 *)((int64_t)&uStack_98 + iVar11) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210e15;
        iVar7 = fcn.180280760(iVar13, iVar14, &stack0x00000060 + iVar8 + iVar11);
        goto code_r0x0001802112fb;
    case 0x14:
        if (6 < iVar7 - 2U) goto code_r0x000180211355;
        *(int64_t *)((int64_t)&iStackX_20 + iVar8 + iVar11) = (int64_t)(0xf - iVar7);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210d97;
        puVar9 = (undefined4 *)
                 fcn.180229cc0((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb2ec, (int64_t)&iStackX_20 + iVar8 + iVar11);
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        uVar15 = (undefined4)*(undefined8 *)(puVar9 + 8);
        uVar16 = (undefined4)((uint64_t)*(undefined8 *)(puVar9 + 8) >> 0x20);
        *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
        break;
    case 0x16:
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210eb4;
        puVar9 = (undefined4 *)func_0x000180229c70((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb638, in_RDX);
        iVar14 = in_RCX[0x16];
        iVar13 = *in_RCX;
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        *(undefined8 *)((int64_t)&uStack_98 + iVar11) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210ee3;
        iVar7 = fcn.1802807b0(iVar13, iVar14, &stack0x00000060 + iVar8 + iVar11);
        if (0 < iVar7) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210f01;
            puVar9 = (undefined4 *)
                     fcn.180229cc0((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb640, 
                                   (int64_t)&iStackX_20 + iVar8 + iVar11);
            iVar14 = in_RCX[0x16];
            iVar13 = *in_RCX;
            uVar15 = puVar9[1];
            uVar16 = puVar9[2];
            uVar4 = puVar9[3];
            *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
            *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
            *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
            *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
            uVar15 = puVar9[5];
            uVar16 = puVar9[6];
            uVar4 = puVar9[7];
            *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
            *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
            *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
            *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
            *(undefined8 *)((int64_t)&uStack_98 + iVar11) = *(undefined8 *)(puVar9 + 8);
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210f30;
            iVar7 = fcn.180280760(iVar13, iVar14, &stack0x00000060 + iVar8 + iVar11);
            if (0 < iVar7) goto code_r0x000180211355;
        }
        goto code_r0x0001802112fb;
    case 0x17:
        if (iVar7 < 0) goto code_r0x000180211355;
        uVar12 = 0x1804bb6fc;
        goto code_r0x0001802112bf;
    case 0x18:
        if (iVar7 < 0) goto code_r0x000180211355;
        uVar12 = 0x1804bb618;
code_r0x0001802112bf:
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x1802112cc;
        puVar9 = (undefined4 *)func_0x000180229c70((int64_t)&arg_30h + iVar8 + iVar11, uVar12, in_RDX);
code_r0x0001802112cc:
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        uVar15 = (undefined4)*(undefined8 *)(puVar9 + 8);
        uVar16 = (undefined4)((uint64_t)*(undefined8 *)(puVar9 + 8) >> 0x20);
        break;
    case 0x19:
        if (iVar7 < 0x20) goto code_r0x000180211355;
        uVar12 = in_RDX[2];
        uVar3 = in_RDX[1];
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180211088;
        puVar9 = (undefined4 *)func_0x000180229c70((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb688, uVar3, uVar12);
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        *(undefined8 *)((int64_t)&uStack_98 + iVar11) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x1802110b8;
        puVar9 = (undefined4 *)fcn.180229d80((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb698, in_RDX + 3);
        iVar14 = in_RCX[0x16];
        iVar13 = *in_RCX;
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)((int64_t)&uStack_90 + iVar11) = *puVar9;
        *(undefined4 *)((int64_t)auStack_88 + iVar11 + -4) = uVar15;
        *(undefined4 *)((int64_t)auStack_88 + iVar11) = uVar16;
        *(undefined4 *)((int64_t)auStack_88 + iVar11 + 4) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)((int64_t)&uStack_80 + iVar11) = puVar9[4];
        *(undefined4 *)((int64_t)&uStack_80 + iVar11 + 4) = uVar15;
        *(undefined4 *)((int64_t)&uStack_78 + iVar11) = uVar16;
        *(undefined4 *)((int64_t)&uStack_78 + iVar11 + 4) = uVar4;
        *(undefined8 *)((int64_t)&uStack_70 + iVar11) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x1802110e5;
        iVar7 = fcn.1802807b0(iVar13, iVar14, &stack0x00000060 + iVar8 + iVar11);
        if (iVar7 < 1) goto code_r0x000180211355;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180211103;
        puVar9 = (undefined4 *)
                 fcn.180229cc0((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb6b0, (int64_t)&iStackX_20 + iVar8 + iVar11);
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        *(undefined8 *)((int64_t)&uStack_98 + iVar11) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180211133;
        puVar9 = (undefined4 *)fcn.180229d80((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb698, in_RDX + 3);
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)((int64_t)&uStack_90 + iVar11) = *puVar9;
        *(undefined4 *)((int64_t)auStack_88 + iVar11 + -4) = uVar15;
        *(undefined4 *)((int64_t)auStack_88 + iVar11) = uVar16;
        *(undefined4 *)((int64_t)auStack_88 + iVar11 + 4) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)((int64_t)&uStack_80 + iVar11) = puVar9[4];
        *(undefined4 *)((int64_t)&uStack_80 + iVar11 + 4) = uVar15;
        *(undefined4 *)((int64_t)&uStack_78 + iVar11) = uVar16;
        *(undefined4 *)((int64_t)&uStack_78 + iVar11 + 4) = uVar4;
        *(undefined8 *)((int64_t)&uStack_70 + iVar11) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180211156;
        puVar9 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_30h + iVar8 + iVar11);
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)((int64_t)&uStack_68 + iVar11) = *puVar9;
        *(undefined4 *)((int64_t)auStack_60 + iVar11 + -4) = uVar15;
        *(undefined4 *)((int64_t)auStack_60 + iVar11) = uVar16;
        *(undefined4 *)((int64_t)auStack_60 + iVar11 + 4) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)((int64_t)&uStack_58 + iVar11) = puVar9[4];
        *(undefined4 *)((int64_t)&uStack_58 + iVar11 + 4) = uVar15;
        *(undefined4 *)((int64_t)&uStack_50 + iVar11) = uVar16;
        *(undefined4 *)((int64_t)auStack_48 + iVar11 + -4) = uVar4;
        *(undefined8 *)((int64_t)auStack_48 + iVar11) = *(undefined8 *)(puVar9 + 8);
        goto code_r0x000180211033;
    case 0x1a:
        uVar12 = in_RDX[2];
        uVar3 = *in_RDX;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x18021118c;
        puVar9 = (undefined4 *)func_0x000180229c70((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb6c8, uVar3, uVar12);
        uVar12 = in_RDX[2];
        uVar3 = in_RDX[1];
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        *(undefined8 *)((int64_t)&uStack_98 + iVar11) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x1802111c0;
        puVar9 = (undefined4 *)func_0x000180229c70((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb6d8, uVar3, uVar12);
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)((int64_t)&uStack_90 + iVar11) = *puVar9;
        *(undefined4 *)((int64_t)auStack_88 + iVar11 + -4) = uVar15;
        *(undefined4 *)((int64_t)auStack_88 + iVar11) = uVar16;
        *(undefined4 *)((int64_t)auStack_88 + iVar11 + 4) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)((int64_t)&uStack_80 + iVar11) = puVar9[4];
        *(undefined4 *)((int64_t)&uStack_80 + iVar11 + 4) = uVar15;
        *(undefined4 *)((int64_t)&uStack_78 + iVar11) = uVar16;
        *(undefined4 *)((int64_t)&uStack_78 + iVar11 + 4) = uVar4;
        *(undefined8 *)((int64_t)&uStack_70 + iVar11) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x1802111ee;
        puVar9 = (undefined4 *)fcn.180229d80((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb698, in_RDX + 3);
        iVar14 = in_RCX[0x16];
        iVar13 = *in_RCX;
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)((int64_t)&uStack_68 + iVar11) = *puVar9;
        *(undefined4 *)((int64_t)auStack_60 + iVar11 + -4) = uVar15;
        *(undefined4 *)((int64_t)auStack_60 + iVar11) = uVar16;
        *(undefined4 *)((int64_t)auStack_60 + iVar11 + 4) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)((int64_t)&uStack_58 + iVar11) = puVar9[4];
        *(undefined4 *)((int64_t)&uStack_58 + iVar11 + 4) = uVar15;
        *(undefined4 *)((int64_t)&uStack_50 + iVar11) = uVar16;
        *(undefined4 *)((int64_t)auStack_48 + iVar11 + -4) = uVar4;
        *(undefined8 *)((int64_t)auStack_48 + iVar11) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x18021121b;
        iVar7 = fcn.1802807b0(iVar13, iVar14, &stack0x00000060 + iVar8 + iVar11);
        if (0 < iVar7) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180211239;
            puVar9 = (undefined4 *)
                     fcn.180229cc0((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb6e8, 
                                   (int64_t)&iStackX_20 + iVar8 + iVar11);
            uVar15 = puVar9[1];
            uVar16 = puVar9[2];
            uVar4 = puVar9[3];
            *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
            *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
            *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
            *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
            uVar15 = puVar9[5];
            uVar16 = puVar9[6];
            uVar4 = puVar9[7];
            *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
            *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
            *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
            *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
            *(undefined8 *)((int64_t)&uStack_98 + iVar11) = *(undefined8 *)(puVar9 + 8);
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x18021125e;
            puVar9 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_30h + iVar8 + iVar11);
            iVar14 = in_RCX[0x16];
            iVar13 = *in_RCX;
            uVar15 = puVar9[1];
            uVar16 = puVar9[2];
            uVar4 = puVar9[3];
            *(undefined4 *)((int64_t)&uStack_90 + iVar11) = *puVar9;
            *(undefined4 *)((int64_t)auStack_88 + iVar11 + -4) = uVar15;
            *(undefined4 *)((int64_t)auStack_88 + iVar11) = uVar16;
            *(undefined4 *)((int64_t)auStack_88 + iVar11 + 4) = uVar4;
            uVar15 = puVar9[5];
            uVar16 = puVar9[6];
            uVar4 = puVar9[7];
            *(undefined4 *)((int64_t)&uStack_80 + iVar11) = puVar9[4];
            *(undefined4 *)((int64_t)&uStack_80 + iVar11 + 4) = uVar15;
            *(undefined4 *)((int64_t)&uStack_78 + iVar11) = uVar16;
            *(undefined4 *)((int64_t)&uStack_78 + iVar11 + 4) = uVar4;
            *(undefined8 *)((int64_t)&uStack_70 + iVar11) = *(undefined8 *)(puVar9 + 8);
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x18021128b;
            fcn.180280760(iVar13, iVar14, &stack0x00000060 + iVar8 + iVar11);
        }
        goto code_r0x000180211355;
    case 0x1c:
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210fa8;
        puVar9 = (undefined4 *)
                 fcn.180229cc0((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb658, (int64_t)&iStackX_20 + iVar8 + iVar11);
        iVar14 = in_RCX[0x16];
        iVar13 = *in_RCX;
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        *(undefined8 *)((int64_t)&uStack_98 + iVar11) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210fd7;
        iVar7 = fcn.1802807b0(iVar13, iVar14, &stack0x00000060 + iVar8 + iVar11);
        if (iVar7 < 1) goto code_r0x000180211355;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210ff5;
        puVar9 = (undefined4 *)
                 fcn.180229cc0((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb670, (int64_t)&iStackX_20 + iVar8 + iVar11);
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)(&stack0x00000060 + iVar8 + iVar11) = *puVar9;
        *(undefined4 *)(&stack0x00000064 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000068 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000006c + iVar8 + iVar11) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)(&stack0x00000070 + iVar8 + iVar11) = puVar9[4];
        *(undefined4 *)(&stack0x00000074 + iVar8 + iVar11) = uVar15;
        *(undefined4 *)(&stack0x00000078 + iVar8 + iVar11) = uVar16;
        *(undefined4 *)(&stack0x0000007c + iVar8 + iVar11) = uVar4;
        *(undefined8 *)((int64_t)&uStack_98 + iVar11) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x18021101a;
        puVar9 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_30h + iVar8 + iVar11);
        uVar15 = puVar9[1];
        uVar16 = puVar9[2];
        uVar4 = puVar9[3];
        *(undefined4 *)((int64_t)&uStack_90 + iVar11) = *puVar9;
        *(undefined4 *)((int64_t)auStack_88 + iVar11 + -4) = uVar15;
        *(undefined4 *)((int64_t)auStack_88 + iVar11) = uVar16;
        *(undefined4 *)((int64_t)auStack_88 + iVar11 + 4) = uVar4;
        uVar15 = puVar9[5];
        uVar16 = puVar9[6];
        uVar4 = puVar9[7];
        *(undefined4 *)((int64_t)&uStack_80 + iVar11) = puVar9[4];
        *(undefined4 *)((int64_t)&uStack_80 + iVar11 + 4) = uVar15;
        *(undefined4 *)((int64_t)&uStack_78 + iVar11) = uVar16;
        *(undefined4 *)((int64_t)&uStack_78 + iVar11 + 4) = uVar4;
        *(undefined8 *)((int64_t)&uStack_70 + iVar11) = *(undefined8 *)(puVar9 + 8);
code_r0x000180211033:
        iVar14 = in_RCX[0x16];
        iVar13 = *in_RCX;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180211047;
        fcn.180280760(iVar13, iVar14, &stack0x00000060 + iVar8 + iVar11);
        goto code_r0x000180211355;
    case 0x27:
        if (iVar7 < 0) goto code_r0x000180211355;
        *(int32_t *)((int64_t)&arg_28h + iVar8 + iVar11) = iVar7;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180210e7f;
        puVar9 = (undefined4 *)
                 fcn.180229d80((int64_t)&arg_30h + iVar8 + iVar11, 0x1804bb62c, (int64_t)&arg_28h + iVar8 + iVar11);
        goto code_r0x0001802112cc;
    }
    iVar14 = in_RCX[0x16];
    iVar13 = *in_RCX;
    *(uint64_t *)((int64_t)&uStack_98 + iVar11) = CONCAT44(uVar16, uVar15);
code_r0x0001802112f1:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x1802112fb;
    iVar7 = fcn.1802807b0(iVar13, iVar14, &stack0x00000060 + iVar8 + iVar11);
code_r0x0001802112fb:
    if (iVar7 == -1) {
code_r0x000180211300:
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180211305;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar8 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar11));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x18021131d;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar8 + iVar11), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar11), *(int64_t *)((int64_t)&arg_30h + iVar8 + iVar11)
                      , *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar11), 
                      *(int64_t *)(&stack0x00000050 + iVar8 + iVar11));
code_r0x000180211346:
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180211353;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar11), *(int64_t *)(&stack0x00000040 + iVar8 + iVar11)
                      , *(int64_t *)(&stack0x00000068 + iVar8 + iVar11));
    }
code_r0x000180211355:
    uVar10 = *puVar1;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8 + iVar11) = 0x180211361;
    uVar10 = func_0x000180459870(uVar10 ^ (int64_t)&iStackX_20 + iVar8 + iVar11 + -0x20);
    return uVar10;
}

// ============================================================
// Function: FUN_180211580
// Address: 0x180211580
// Size: 209 bytes
// ============================================================
undefined8 fcn.180211580(int64_t *param_1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021158c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == (int64_t *)0x0) {
        return 1;
    }
    iVar1 = *param_1;
    if (iVar1 != 0) {
        if (*(int64_t *)(iVar1 + 0x70) != 0) {
            if (param_1[0x16] != 0) {
                pcVar2 = *(code **)(iVar1 + 0xd0);
                if (pcVar2 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802115c4;
                    (*pcVar2)();
                }
                param_1[0x16] = 0;
            }
            if (param_1[0x17] != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802115e0;
                func_0x000180211a40();
            }
            goto code_r0x00018021162f;
        }
        pcVar2 = *(code **)(iVar1 + 0x28);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802115ed;
            uVar4 = (*pcVar2)();
            if ((int32_t)uVar4 == 0) {
                return uVar4;
            }
        }
        if ((param_1[0xf] != 0) && (*(int32_t *)(*param_1 + 0x30) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180211610;
            func_0x000180244fc0();
        }
    }
    iVar1 = param_1[0xf];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180211626;
    fcn.180224990(iVar1, 0x1804bb408, 0x3f);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021162f;
    fcn.18026aee0(*(int64_t *)((int64_t)&iStackX_20 + iVar3));
code_r0x00018021162f:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021163f;
    fcn.1804986e0(param_1, 0, 0xc0);
    *(undefined4 *)((int64_t)param_1 + 0x6c) = 0xffffffff;
    return 1;
}

// ============================================================
// Function: FUN_180211660
// Address: 0x180211660
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180211660(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a8h,
             int64_t arg_b0h, int64_t arg_100h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    int32_t iVar11;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211675;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar11 = (int32_t)in_RDX;
    if (*(int64_t *)(*in_RCX + 0x70) == 0) {
        if ((*(uint8_t *)(*in_RCX + 0x10) & 0x80) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802117b5;
            uVar8 = fcn.180210b80(*(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7));
            return uVar8;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802117bc;
        iVar6 = func_0x00018020eae0();
        if (iVar6 == iVar11) {
            return 1;
        }
        if ((0 < iVar11) && ((*(uint8_t *)(*in_RCX + 0x10) & 8) != 0)) goto code_r0x0001802117cd;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802117dc;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_50h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_68h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_70h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_78h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_80h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_88h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_90h + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802116ce;
        iVar6 = func_0x00018020eae0();
        if (iVar6 == iVar11) {
            return 1;
        }
        *(undefined8 *)((int64_t)&arg_b0h + iVar7) = unaff_RBP;
        iVar9 = *in_RCX;
        if ((iVar9 != 0) && (*(int64_t *)(iVar9 + 0x108) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802116f7;
            uVar8 = func_0x00018020eec0(iVar9);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802116ff;
            uVar8 = func_0x00018027e810(uVar8);
            pcVar1 = *(code **)(iVar9 + 0x108);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021170e;
            (*pcVar1)(0, uVar8);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211720;
        iVar9 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar7));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211755;
            puVar10 = (undefined4 *)fcn.180229cc0((int64_t)&var_18h + iVar7, 0x1804bb2f4, (int64_t)&arg_a8h + iVar7);
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar10;
            *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
            *(undefined4 *)((int64_t)&arg_50h + iVar7) = uVar4;
            *(undefined4 *)((int64_t)&arg_50h + iVar7 + 4) = uVar5;
            uVar3 = puVar10[5];
            uVar4 = puVar10[6];
            uVar5 = puVar10[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar10[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
            *(undefined4 *)((int64_t)&arg_60h + iVar7) = uVar4;
            *(undefined4 *)((int64_t)&arg_60h + iVar7 + 4) = uVar5;
            *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar10 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021177d;
            iVar6 = func_0x00018022b100((int64_t)&arg_48h + iVar7, in_RDX & 0xffffffff);
            if (iVar6 == 0) {
                return 0;
            }
            iVar9 = in_RCX[0x16];
            iVar2 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211799;
            iVar6 = fcn.1802807b0(iVar2, iVar9, (int64_t)&arg_48h + iVar7);
            if (iVar6 < 1) {
                return 0;
            }
code_r0x0001802117cd:
            *(int32_t *)(in_RCX + 0xd) = iVar11;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211732;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802117f4;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                  *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                  *(int64_t *)((int64_t)&arg_48h + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211806;
    fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7), 
                  *(int64_t *)((int64_t)&arg_60h + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1802116d6
// Address: 0x1802116d6
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180211660(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a8h,
             int64_t arg_b0h, int64_t arg_100h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    int32_t iVar11;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211675;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar11 = (int32_t)in_RDX;
    if (*(int64_t *)(*in_RCX + 0x70) == 0) {
        if ((*(uint8_t *)(*in_RCX + 0x10) & 0x80) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802117b5;
            uVar8 = fcn.180210b80(*(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7));
            return uVar8;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802117bc;
        iVar6 = func_0x00018020eae0();
        if (iVar6 == iVar11) {
            return 1;
        }
        if ((0 < iVar11) && ((*(uint8_t *)(*in_RCX + 0x10) & 8) != 0)) goto code_r0x0001802117cd;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802117dc;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_50h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_68h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_70h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_78h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_80h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_88h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_90h + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802116ce;
        iVar6 = func_0x00018020eae0();
        if (iVar6 == iVar11) {
            return 1;
        }
        *(undefined8 *)((int64_t)&arg_b0h + iVar7) = unaff_RBP;
        iVar9 = *in_RCX;
        if ((iVar9 != 0) && (*(int64_t *)(iVar9 + 0x108) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802116f7;
            uVar8 = func_0x00018020eec0(iVar9);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802116ff;
            uVar8 = func_0x00018027e810(uVar8);
            pcVar1 = *(code **)(iVar9 + 0x108);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021170e;
            (*pcVar1)(0, uVar8);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211720;
        iVar9 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar7));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211755;
            puVar10 = (undefined4 *)fcn.180229cc0((int64_t)&var_18h + iVar7, 0x1804bb2f4, (int64_t)&arg_a8h + iVar7);
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar10;
            *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
            *(undefined4 *)((int64_t)&arg_50h + iVar7) = uVar4;
            *(undefined4 *)((int64_t)&arg_50h + iVar7 + 4) = uVar5;
            uVar3 = puVar10[5];
            uVar4 = puVar10[6];
            uVar5 = puVar10[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar10[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
            *(undefined4 *)((int64_t)&arg_60h + iVar7) = uVar4;
            *(undefined4 *)((int64_t)&arg_60h + iVar7 + 4) = uVar5;
            *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar10 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021177d;
            iVar6 = func_0x00018022b100((int64_t)&arg_48h + iVar7, in_RDX & 0xffffffff);
            if (iVar6 == 0) {
                return 0;
            }
            iVar9 = in_RCX[0x16];
            iVar2 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211799;
            iVar6 = fcn.1802807b0(iVar2, iVar9, (int64_t)&arg_48h + iVar7);
            if (iVar6 < 1) {
                return 0;
            }
code_r0x0001802117cd:
            *(int32_t *)(in_RCX + 0xd) = iVar11;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211732;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802117f4;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                  *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                  *(int64_t *)((int64_t)&arg_48h + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211806;
    fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7), 
                  *(int64_t *)((int64_t)&arg_60h + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_18021172d
// Address: 0x18021172d
// Size: 240 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180211660(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a8h,
             int64_t arg_b0h, int64_t arg_100h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    int32_t iVar11;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211675;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar11 = (int32_t)in_RDX;
    if (*(int64_t *)(*in_RCX + 0x70) == 0) {
        if ((*(uint8_t *)(*in_RCX + 0x10) & 0x80) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802117b5;
            uVar8 = fcn.180210b80(*(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7));
            return uVar8;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802117bc;
        iVar6 = func_0x00018020eae0();
        if (iVar6 == iVar11) {
            return 1;
        }
        if ((0 < iVar11) && ((*(uint8_t *)(*in_RCX + 0x10) & 8) != 0)) goto code_r0x0001802117cd;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802117dc;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_50h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_68h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_70h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_78h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_80h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_88h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_90h + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802116ce;
        iVar6 = func_0x00018020eae0();
        if (iVar6 == iVar11) {
            return 1;
        }
        *(undefined8 *)((int64_t)&arg_b0h + iVar7) = unaff_RBP;
        iVar9 = *in_RCX;
        if ((iVar9 != 0) && (*(int64_t *)(iVar9 + 0x108) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802116f7;
            uVar8 = func_0x00018020eec0(iVar9);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802116ff;
            uVar8 = func_0x00018027e810(uVar8);
            pcVar1 = *(code **)(iVar9 + 0x108);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021170e;
            (*pcVar1)(0, uVar8);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211720;
        iVar9 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar7));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211755;
            puVar10 = (undefined4 *)fcn.180229cc0((int64_t)&var_18h + iVar7, 0x1804bb2f4, (int64_t)&arg_a8h + iVar7);
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar10;
            *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
            *(undefined4 *)((int64_t)&arg_50h + iVar7) = uVar4;
            *(undefined4 *)((int64_t)&arg_50h + iVar7 + 4) = uVar5;
            uVar3 = puVar10[5];
            uVar4 = puVar10[6];
            uVar5 = puVar10[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar10[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
            *(undefined4 *)((int64_t)&arg_60h + iVar7) = uVar4;
            *(undefined4 *)((int64_t)&arg_60h + iVar7 + 4) = uVar5;
            *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar10 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021177d;
            iVar6 = func_0x00018022b100((int64_t)&arg_48h + iVar7, in_RDX & 0xffffffff);
            if (iVar6 == 0) {
                return 0;
            }
            iVar9 = in_RCX[0x16];
            iVar2 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211799;
            iVar6 = fcn.1802807b0(iVar2, iVar9, (int64_t)&arg_48h + iVar7);
            if (iVar6 < 1) {
                return 0;
            }
code_r0x0001802117cd:
            *(int32_t *)(in_RCX + 0xd) = iVar11;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211732;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802117f4;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                  *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                  *(int64_t *)((int64_t)&arg_48h + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211806;
    fcn.1802296d0(*(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7), 
                  *(int64_t *)((int64_t)&arg_60h + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180211820
// Address: 0x180211820
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.180211820(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_a8h, int64_t arg_b0h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t *in_RCX;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211830;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(int32_t *)((int64_t)&arg_b0h + iVar9) = in_EDX;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = 0;
    uVar1 = *(uint32_t *)(in_RCX + 0xe);
    *(undefined4 *)((int64_t)&arg_50h + iVar9) = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar9) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar9) = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar9) = 0;
    uVar4 = uVar1 & 0xfffffeff;
    if (in_EDX == 0) {
        uVar4 = uVar1 | 0x100;
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar9) = 0;
    iVar2 = *in_RCX;
    *(undefined4 *)((int64_t)&arg_78h + iVar9) = 0;
    *(undefined8 *)((int64_t)&arg_80h + iVar9) = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar9) = 0;
    *(undefined8 *)((int64_t)&arg_90h + iVar9) = 0;
    *(uint32_t *)(in_RCX + 0xe) = uVar4;
    if ((iVar2 != 0) && (*(int64_t *)(iVar2 + 0x70) == 0)) {
        return true;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802118cd;
    puVar10 = (undefined4 *)fcn.180229d80((int64_t)&var_18h + iVar9, 0x1804b9d18, (int64_t)&arg_b0h + iVar9);
    iVar2 = in_RCX[0x16];
    iVar3 = *in_RCX;
    uVar5 = puVar10[1];
    uVar6 = puVar10[2];
    uVar7 = puVar10[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar9) = *puVar10;
    *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
    *(undefined4 *)((int64_t)&arg_50h + iVar9) = uVar6;
    *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4) = uVar7;
    uVar5 = puVar10[5];
    uVar6 = puVar10[6];
    uVar7 = puVar10[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar9) = puVar10[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
    *(undefined4 *)((int64_t)&arg_60h + iVar9) = uVar6;
    *(undefined4 *)((int64_t)&arg_60h + iVar9 + 4) = uVar7;
    *(undefined8 *)((int64_t)&arg_68h + iVar9) = *(undefined8 *)(puVar10 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802118fd;
    iVar8 = fcn.1802807b0(iVar3, iVar2, (int64_t)&arg_48h + iVar9);
    return iVar8 != 0;
}

