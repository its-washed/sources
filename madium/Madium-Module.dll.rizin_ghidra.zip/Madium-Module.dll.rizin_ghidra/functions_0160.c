// Chunk 160 - 50 functions

// ============================================================
// Function: FUN_180212e30
// Address: 0x180212e30
// Size: 70 bytes
// ============================================================
void fcn.180212e30(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180212e3a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x180212e80;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180211b30;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180212f40;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180212e71;
    fcn.180280ca0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000080 + iVar1), *(int64_t *)(&stack0x000000b0 + iVar1), 
                  *(int64_t *)(&stack0x000000b8 + iVar1), *(int64_t *)(&stack0x000000c0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180212e80
// Address: 0x180212e80
// Size: 101 bytes
// ============================================================
void fcn.180212e80(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180212e90;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        if (*(int32_t *)(arg1 + 0x14) == 0) {
            LOCK();
            piVar1 = (int32_t *)(arg1 + 0x78);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 < 2) {
                uVar3 = *(undefined8 *)(arg1 + 0x60);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180212ec1;
                fcn.180224990(uVar3, 0x1804bb408, 0x843);
                uVar3 = *(undefined8 *)(arg1 + 0x70);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180212eca;
                fcn.18027edb0(uVar3);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180212edf;
                fcn.180224990(arg1, 0x1804bb408, 0x846);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180212ef0
// Address: 0x180212ef0
// Size: 75 bytes
// ============================================================
void fcn.180212ef0(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180212efc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = *(undefined8 *)(param_1 + 0x60);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180212f18;
    fcn.180224990(uVar6, 0x1804bb408, 0x843);
    uVar6 = *(undefined8 *)(param_1 + 0x70);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180212f21;
    fcn.18027edb0(uVar6);
    uVar6 = *(undefined8 *)((int64_t)auStackX_18 + iVar3);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350(param_1, 0x1804bb408, 0x846);
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = uVar6;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_180212f40
// Address: 0x180212f40
// Size: 1304 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_3h extends beyond the stackframe. Try changing its type to something smaller.

int32_t * fcn.180212f40(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int64_t iVar6;
    uint64_t in_RCX;
    int64_t in_RDX;
    undefined8 *puVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t in_R8;
    int32_t iVar10;
    int64_t var_8h;
    undefined8 uStack_40;
    
    uStack_40 = 0x180212f5a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar1 = *(int32_t **)(in_RDX + 0x10);
    iVar9 = 0;
    *(undefined4 *)((int64_t)&arg_30h + iVar4) = 0;
    *(undefined4 *)((int64_t)&arg_40h + iVar4) = 0;
    iVar3 = 0;
    iVar10 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180212f8f;
    piVar5 = (int32_t *)func_0x000180224d60(0x120, 0x1804bb408, 0x735);
    if (piVar5 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802133c7;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802133df;
        func_0x0001802295a0(0x1804bb408, 0x766, 0x1804bb720);
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802133f1;
        func_0x0001802296d0(6, 0x80006, 0);
        return (int32_t *)0x0;
    }
    piVar5[0x1e] = 1;
    *piVar5 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180212fb8;
    iVar2 = func_0x000180280fa0(in_R8, in_RCX & 0xffffffff, 0x1802141d0, piVar5);
    if ((iVar2 == 0) || (*piVar5 == -1)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18021334a;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180213362;
        func_0x0001802295a0(0x1804bb408, 0x76e, 0x1804bb720);
        uVar8 = 0xc0103;
    } else {
        piVar5[0x16] = (int32_t)in_RCX;
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180212fd4;
        iVar6 = func_0x000180282210(in_RDX);
        *(int64_t *)(piVar5 + 0x18) = iVar6;
        if (iVar6 == 0) goto code_r0x000180213378;
        *(undefined8 *)(piVar5 + 0x1a) = *(undefined8 *)(in_RDX + 0x18);
        iVar2 = *piVar1;
        if (iVar2 != 0) {
            puVar7 = (undefined8 *)(piVar1 + 2);
            iVar3 = 0;
            do {
    // switch table (20 cases) at 0x180213408
                switch(iVar2) {
                case 1:
                    if (*(int64_t *)(piVar5 + 0x20) == 0) {
                        iVar10 = iVar10 + 1;
                        *(undefined8 *)(piVar5 + 0x20) = *puVar7;
                    }
                    break;
                case 2:
                    if (*(int64_t *)(piVar5 + 0x22) == 0) {
                        *(undefined8 *)(piVar5 + 0x22) = *puVar7;
                        *(undefined4 *)((int64_t)&arg_30h + iVar4) = 1;
                    }
                    break;
                case 3:
                    if (*(int64_t *)(piVar5 + 0x24) == 0) {
                        *(undefined8 *)(piVar5 + 0x24) = *puVar7;
                        *(undefined4 *)((int64_t)&arg_40h + iVar4) = 1;
                    }
                    break;
                case 4:
                    if (*(int64_t *)(piVar5 + 0x26) == 0) {
                        iVar9 = iVar9 + 1;
                        *(undefined8 *)(piVar5 + 0x26) = *puVar7;
                    }
                    break;
                case 5:
                    if (*(int64_t *)(piVar5 + 0x28) == 0) {
                        iVar9 = iVar9 + 1;
                        *(undefined8 *)(piVar5 + 0x28) = *puVar7;
                    }
                    break;
                case 6:
                    if (*(int64_t *)(piVar5 + 0x2a) == 0) {
                        *(undefined8 *)(piVar5 + 0x2a) = *puVar7;
                    }
                    break;
                case 7:
                    if (*(int64_t *)(piVar5 + 0x34) == 0) {
                        iVar10 = iVar10 + 1;
                        *(undefined8 *)(piVar5 + 0x34) = *puVar7;
                    }
                    break;
                case 8:
                    if (*(int64_t *)(piVar5 + 0x36) == 0) {
                        *(undefined8 *)(piVar5 + 0x36) = *puVar7;
                    }
                    break;
                case 9:
                    if (*(int64_t *)(piVar5 + 0x38) == 0) {
                        *(undefined8 *)(piVar5 + 0x38) = *puVar7;
                    }
                    break;
                case 10:
                    if (*(int64_t *)(piVar5 + 0x3a) == 0) {
                        *(undefined8 *)(piVar5 + 0x3a) = *puVar7;
                    }
                    break;
                case 0xb:
                    if (*(int64_t *)(piVar5 + 0x3c) == 0) {
                        *(undefined8 *)(piVar5 + 0x3c) = *puVar7;
                    }
                    break;
                case 0xc:
                    if (*(int64_t *)(piVar5 + 0x3e) == 0) {
                        *(undefined8 *)(piVar5 + 0x3e) = *puVar7;
                    }
                    break;
                case 0xd:
                    if (*(int64_t *)(piVar5 + 0x40) == 0) {
                        *(undefined8 *)(piVar5 + 0x40) = *puVar7;
                    }
                    break;
                case 0xe:
                    if (*(int64_t *)(piVar5 + 0x42) == 0) {
                        *(undefined8 *)(piVar5 + 0x42) = *puVar7;
                    }
                    break;
                case 0xf:
                    if (*(int64_t *)(piVar5 + 0x2c) == 0) {
                        iVar3 = iVar3 + 1;
                        *(undefined8 *)(piVar5 + 0x2c) = *puVar7;
                    }
                    break;
                case 0x10:
                    if (*(int64_t *)(piVar5 + 0x2e) == 0) {
                        iVar3 = iVar3 + 1;
                        *(undefined8 *)(piVar5 + 0x2e) = *puVar7;
                    }
                    break;
                case 0x11:
                    if (*(int64_t *)(piVar5 + 0x30) == 0) {
                        iVar3 = iVar3 + 1;
                        *(undefined8 *)(piVar5 + 0x30) = *puVar7;
                    }
                    break;
                case 0x12:
                    if (*(int64_t *)(piVar5 + 0x32) == 0) {
                        iVar3 = iVar3 + 1;
                        *(undefined8 *)(piVar5 + 0x32) = *puVar7;
                    }
                    break;
                case 0x13:
                    if (*(int64_t *)(piVar5 + 0x44) == 0) {
                        *(undefined8 *)(piVar5 + 0x44) = *puVar7;
                        *(undefined4 *)((int64_t)&arg_30h + iVar4) = 1;
                    }
                    break;
                case 0x14:
                    if (*(int64_t *)(piVar5 + 0x46) == 0) {
                        *(undefined8 *)(piVar5 + 0x46) = *puVar7;
                        *(undefined4 *)((int64_t)&arg_40h + iVar4) = 1;
                    }
                }
                iVar2 = *(int32_t *)(puVar7 + 1);
                puVar7 = puVar7 + 2;
            } while (iVar2 != 0);
        }
        iVar9 = iVar9 + *(int32_t *)((int64_t)&arg_30h + iVar4) + *(int32_t *)((int64_t)&arg_40h + iVar4);
        if (iVar9 == 0) {
            if (*(int64_t *)(piVar5 + 0x2a) != 0) goto code_r0x00018021329b;
            if (iVar3 == 0) goto code_r0x0001802132be;
code_r0x00018021329f:
            if (((2 < iVar3) && (*(int64_t *)(piVar5 + 0x30) != 0)) && (*(int64_t *)(piVar5 + 0x32) != 0)) {
code_r0x0001802132b8:
                if (iVar10 == 2) {
                    if (in_R8 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180213305;
                        iVar3 = func_0x00018027fb30(in_R8);
                        if (iVar3 == 0) goto code_r0x000180213378;
                    }
                    *(int64_t *)(piVar5 + 0x1c) = in_R8;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180213315;
                    iVar3 = func_0x00018020ff80(piVar5);
                    if (iVar3 != 0) {
                        return piVar5;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18021331e;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180213336;
                    func_0x0001802295a0(0x1804bb408, 0x804, 0x1804bb720);
                    uVar8 = 0xe1;
                    goto code_r0x000180213367;
                }
            }
        } else if (iVar9 - 3U < 2) {
code_r0x00018021329b:
            if (iVar3 != 0) goto code_r0x00018021329f;
            goto code_r0x0001802132b8;
        }
code_r0x0001802132be:
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802132c3;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802132db;
        func_0x0001802295a0(0x1804bb408, 0x7fb, 0x1804bb720);
        uVar8 = 0xc1;
    }
code_r0x000180213367:
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180213374;
    func_0x0001802296d0(6, uVar8, 0);
code_r0x000180213378:
    if (piVar5[5] == 0) {
        LOCK();
        piVar1 = piVar5 + 0x1e;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 < 2) {
            uVar8 = *(undefined8 *)(piVar5 + 0x18);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802133a2;
            fcn.180224990(uVar8, 0x1804bb408, 0x843);
            uVar8 = *(undefined8 *)(piVar5 + 0x1c);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802133ab;
            fcn.18027edb0(uVar8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802133c0;
            fcn.180224990(piVar5, 0x1804bb408, 0x846);
        }
    }
    return (int32_t *)0x0;
}

// ============================================================
// Function: FUN_180213460
// Address: 0x180213460
// Size: 173 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_3h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.180213460(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_c0h)
{
    int32_t *piVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    undefined4 uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    uint64_t uVar13;
    undefined4 *puVar14;
    int64_t iVar15;
    int32_t **in_RCX;
    int32_t *piVar16;
    int64_t iVar17;
    int64_t *piVar18;
    int32_t *in_RDX;
    int32_t **ppiVar19;
    undefined8 unaff_RBX;
    int64_t *piVar20;
    int32_t *piVar21;
    int32_t *in_R8;
    undefined8 in_R9;
    code *pcVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    code *pcStack_40;
    
    pcStack_40 = (code *)0x18021347b;
    iVar11 = fcn.18045a350();
    iVar17 = arg_40h;
    iVar4 = arg_28h;
    iVar6 = (int32_t)arg_30h;
    iVar11 = -iVar11;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar11);
    piVar21 = (int32_t *)0x0;
    iVar9 = 0;
    iVar10 = 0;
    piVar16 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_18h + iVar11) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar11) = in_R9;
    if (iVar6 == -1) {
        *(undefined4 *)((int64_t)&var_8h + iVar11) = *(undefined4 *)(in_RCX + 2);
    } else {
        uVar8 = (uint32_t)(iVar6 != 0);
        *(uint32_t *)((int64_t)&var_8h + iVar11) = uVar8;
        *(uint32_t *)(in_RCX + 2) = uVar8;
    }
    if ((in_RDX == (int32_t *)0x0) && (*in_RCX == (int32_t *)0x0)) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802134dc;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802134f4;
        func_0x0001802295a0(0x1804bb408, 0x76, 0x1804bb420);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213506;
        func_0x0001802296d0(6, 0x83, 0);
        goto code_r0x00018021410e;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar11) = unaff_RBX;
    if ((char)arg_38h != '\0') {
        if (in_RDX == (int32_t *)0x0) {
code_r0x000180213ba0:
            in_RDX = *in_RCX;
        } else {
code_r0x000180213a95:
            piVar16 = *in_RCX;
            if (piVar16 != (int32_t *)0x0) {
                uVar7 = *(undefined4 *)(in_RCX + 0xe);
                if (*(int64_t *)(piVar16 + 0x1c) == 0) {
                    pcVar22 = *(code **)(piVar16 + 10);
                    if (pcVar22 == (code *)0x0) {
code_r0x000180213b44:
                        if ((in_RCX[0xf] != (int32_t *)0x0) && ((*in_RCX)[0xc] != 0)) {
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b5d;
                            func_0x000180244fc0();
                        }
                        piVar16 = in_RCX[0xf];
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b73;
                        fcn.180224990(piVar16, 0x1804bb408, 0x3f);
                        piVar16 = in_RCX[1];
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b7c;
                        func_0x00018026aee0(piVar16);
                        goto code_r0x000180213b7c;
                    }
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b40;
                    iVar6 = (*pcVar22)(in_RCX);
                    if (iVar6 != 0) goto code_r0x000180213b44;
                } else {
                    if (in_RCX[0x16] != (int32_t *)0x0) {
                        pcVar22 = *(code **)(piVar16 + 0x34);
                        if (pcVar22 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ac9;
                            (*pcVar22)();
                        }
                        in_RCX[0x16] = (int32_t *)0x0;
                    }
                    piVar16 = in_RCX[0x17];
                    if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
                        LOCK();
                        piVar21 = piVar16 + 0x1e;
                        iVar6 = *piVar21;
                        *piVar21 = *piVar21 + -1;
                        UNLOCK();
                        if (iVar6 < 2) {
                            uVar12 = *(undefined8 *)(piVar16 + 0x18);
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b12;
                            fcn.180224990(uVar12, 0x1804bb408, 0x843);
                            uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b1b;
                            fcn.18027edb0(uVar12);
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b30;
                            fcn.180224990(piVar16, 0x1804bb408, 0x846);
                        }
                    }
code_r0x000180213b7c:
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b8c;
                    func_0x0001804986e0(in_RCX, 0, 0xc0);
                    *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
                }
                *(undefined4 *)(in_RCX + 2) = *(undefined4 *)((int64_t)&var_8h + iVar11);
                *(undefined4 *)(in_RCX + 0xe) = uVar7;
            }
        }
        if (*(int64_t *)(in_RDX + 0x1c) == 0) {
            if (*in_RDX == 0) {
                uVar12 = 0x180645710;
            } else {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213bc2;
                uVar12 = func_0x00018022ccf0();
            }
            *(code **)(&stack0xfffffffffffffff8 + iVar11) = fcn.180212e80;
            *(undefined8 *)(&stack0xfffffffffffffff0 + iVar11) = 0x180211b30;
            *(code **)(&stack0xffffffffffffffe8 + iVar11) = fcn.180212f40;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213bfc;
            in_RDX = (int32_t *)func_0x000180280c20(0, 2, uVar12, 0x1805aadb1);
            if (in_RDX == (int32_t *)0x0) goto code_r0x00018021410e;
            piVar16 = in_RCX[0x17];
            if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
                LOCK();
                piVar21 = piVar16 + 0x1e;
                iVar6 = *piVar21;
                *piVar21 = *piVar21 + -1;
                UNLOCK();
                if (iVar6 < 2) {
                    uVar12 = *(undefined8 *)(piVar16 + 0x18);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c3e;
                    fcn.180224990(uVar12, 0x1804bb408, 0x843);
                    uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c47;
                    fcn.18027edb0(uVar12);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c5c;
                    fcn.180224990(piVar16, 0x1804bb408, 0x846);
                }
            }
            in_RCX[0x17] = in_RDX;
            if (*(int64_t *)(in_RDX + 0x1c) == 0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c6e;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c86;
                func_0x0001802295a0(0x1804bb408, 0xcf, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c98;
                func_0x0001802296d0(6, 0x86, 0);
                goto code_r0x00018021410e;
            }
        }
        if (in_RDX != in_RCX[0x17]) {
            if (in_RDX[5] == 0) {
                LOCK();
                in_RDX[0x1e] = in_RDX[0x1e] + 1;
                UNLOCK();
            }
            piVar16 = in_RCX[0x17];
            if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
                LOCK();
                piVar21 = piVar16 + 0x1e;
                iVar6 = *piVar21;
                *piVar21 = *piVar21 + -1;
                UNLOCK();
                if (iVar6 < 2) {
                    uVar12 = *(undefined8 *)(piVar16 + 0x18);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ce9;
                    fcn.180224990(uVar12, 0x1804bb408, 0x843);
                    uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213cf2;
                    fcn.18027edb0(uVar12);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d07;
                    fcn.180224990(piVar16, 0x1804bb408, 0x846);
                }
            }
            in_RCX[0x17] = in_RDX;
        }
        cVar5 = (char)arg_38h;
        *in_RCX = in_RDX;
        if ((char)arg_38h != '\0') {
            if (*(int32_t *)((int64_t)&var_8h + iVar11) == 0) {
                iVar15 = *(int64_t *)(in_RDX + 0x2e);
            } else {
                iVar15 = *(int64_t *)(in_RDX + 0x2c);
            }
            if (((iVar15 == 0) || (*(int64_t *)(in_RDX + 0x30) == 0)) || (*(int64_t *)(in_RDX + 0x32) == 0)) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d4c;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d64;
                func_0x0001802295a0(0x1804bb408, 0xe0, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d76;
                func_0x0001802296d0(6, 0xe6, 0);
                goto code_r0x00018021410e;
            }
        }
        if (in_RCX[0x16] == (int32_t *)0x0) {
            uVar12 = *(undefined8 *)(in_RDX + 0x1c);
            pcVar22 = *(code **)(in_RDX + 0x20);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d96;
            uVar12 = func_0x00018027e810(uVar12);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d9b;
            piVar16 = (int32_t *)(*pcVar22)(uVar12);
            in_RCX[0x16] = piVar16;
            if (piVar16 == (int32_t *)0x0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213dac;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213dc4;
                func_0x0001802295a0(0x1804bb408, 0xe7, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213dd6;
                func_0x0001802296d0(6, 0x86, 0);
                goto code_r0x00018021410e;
            }
        }
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213df0;
            iVar6 = func_0x000180211820(in_RCX, 0);
            if (iVar6 == 0) goto code_r0x00018021410e;
        }
        if (iVar17 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar11) = 0;
            *(undefined4 *)((int64_t)&arg_30h + iVar11) = 0;
            *(undefined8 *)((int64_t)&arg_38h + iVar11) = 0;
            *(undefined8 *)((int64_t)&arg_40h + iVar11) = 0;
            var_b0h = 0;
            var_a8h._0_4_ = 0;
            var_a0h = 0;
            var_98h = 0;
            var_90h = 0;
            var_88h = 0;
            var_80h._0_4_ = 0;
            var_78h = 0;
            var_70h = 0;
            var_68h = 0;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213e4d;
            puVar14 = (undefined4 *)func_0x00018022ae60(iVar17, 0x1804bb2f4);
            if (puVar14 != (undefined4 *)0x0) {
                uVar7 = puVar14[1];
                uVar2 = puVar14[2];
                uVar3 = puVar14[3];
                *(undefined4 *)((int64_t)&arg_28h + iVar11) = *puVar14;
                *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4) = uVar7;
                *(undefined4 *)((int64_t)&arg_30h + iVar11) = uVar2;
                *(undefined4 *)((int64_t)&arg_30h + iVar11 + 4) = uVar3;
                uVar7 = puVar14[5];
                uVar2 = puVar14[6];
                uVar3 = puVar14[7];
                *(undefined4 *)((int64_t)&arg_38h + iVar11) = puVar14[4];
                *(undefined4 *)((int64_t)&arg_38h + iVar11 + 4) = uVar7;
                *(undefined4 *)((int64_t)&arg_40h + iVar11) = uVar2;
                *(undefined4 *)((int64_t)&arg_40h + iVar11 + 4) = uVar3;
            }
            piVar20 = (int64_t *)((int64_t)&arg_28h + iVar11);
            if (puVar14 != (undefined4 *)0x0) {
                piVar20 = &var_b0h;
            }
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213e8c;
            puVar14 = (undefined4 *)func_0x00018022ae60(iVar17, 0x1804bb2ec);
            piVar18 = piVar20;
            if (puVar14 != (undefined4 *)0x0) {
                uVar7 = puVar14[1];
                uVar2 = puVar14[2];
                uVar3 = puVar14[3];
                piVar18 = piVar20 + 5;
                *(undefined4 *)piVar20 = *puVar14;
                *(undefined4 *)((int64_t)piVar20 + 4) = uVar7;
                *(undefined4 *)(piVar20 + 1) = uVar2;
                *(undefined4 *)((int64_t)piVar20 + 0xc) = uVar3;
                uVar7 = puVar14[5];
                uVar2 = puVar14[6];
                uVar3 = puVar14[7];
                *(undefined4 *)(piVar20 + 2) = puVar14[4];
                *(undefined4 *)((int64_t)piVar20 + 0x14) = uVar7;
                *(undefined4 *)(piVar20 + 3) = uVar2;
                *(undefined4 *)((int64_t)piVar20 + 0x1c) = uVar3;
                piVar20[4] = *(int64_t *)(puVar14 + 8);
            }
            if (piVar18 != (int64_t *)((int64_t)&arg_28h + iVar11)) {
                if ((*in_RCX == (int32_t *)0x0) || (pcVar22 = *(code **)(*in_RCX + 0x3c), pcVar22 == (code *)0x0)) {
code_r0x000180213f45:
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f4a;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f62;
                    func_0x0001802295a0(0x1804bb408, 0x112, 0x1804bb420);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f74;
                    func_0x0001802296d0(6, 0xdd, 0);
                    goto code_r0x00018021410e;
                }
                piVar16 = in_RCX[0x16];
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ee1;
                iVar6 = (*pcVar22)(piVar16, (int64_t)&arg_28h + iVar11);
                if (iVar6 < 1) {
                    if (iVar6 == 0) goto code_r0x000180213f45;
                } else {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ef6;
                    iVar15 = func_0x00018022ae60((int64_t)&arg_28h + iVar11, 0x1804bb2f4);
                    if (iVar15 != 0) {
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f07;
                        iVar6 = func_0x000180229fc0(iVar15, in_RCX + 0xd);
                        if (iVar6 == 0) {
                            *(undefined4 *)(in_RCX + 0xd) = 0xffffffff;
                            goto code_r0x000180213f45;
                        }
                    }
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f25;
                    iVar15 = func_0x00018022ae60((int64_t)&arg_28h + iVar11, 0x1804bb2ec);
                    if (iVar15 != 0) {
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f36;
                        iVar6 = func_0x000180229fc0(iVar15, (int64_t)in_RCX + 0x6c);
                        if (iVar6 == 0) {
                            *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
                            goto code_r0x000180213f45;
                        }
                    }
                }
            }
        }
        if (cVar5 != '\0') goto code_r0x00018021410e;
        piVar16 = *in_RCX;
        if (*(int32_t *)((int64_t)&var_8h + iVar11) == 0) {
            if (*(int64_t *)(piVar16 + 0x24) != 0) {
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802140c6;
                    iVar10 = func_0x00018020e980(in_RCX);
                }
                iVar15 = *(int64_t *)((int64_t)&var_10h + iVar11);
                if (iVar15 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802140da;
                    iVar9 = func_0x00018020eae0(in_RCX);
                }
                pcVar22 = *(code **)(*in_RCX + 0x24);
                goto code_r0x0001802140e6;
            }
            if ((*(int64_t *)((int64_t)&var_10h + iVar11) != 0) || (*(int64_t *)(piVar16 + 0x46) == 0)) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180214087;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021409f;
                func_0x0001802295a0(0x1804bb408, 0x143, 0x1804bb420);
                *(code **)((int64_t)&pcStack_40 + iVar11) = case.default.0x180213965;
                func_0x0001802296d0(6, 0x86, 0);
                goto code_r0x00018021410e;
            }
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021405a;
                iVar9 = func_0x00018020e980(in_RCX);
            }
            pcVar22 = *(code **)(*in_RCX + 0x46);
        } else {
            if (*(int64_t *)(piVar16 + 0x22) != 0) {
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021400f;
                    iVar10 = func_0x00018020e980(in_RCX);
                }
                iVar15 = *(int64_t *)((int64_t)&var_10h + iVar11);
                if (iVar15 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180214023;
                    iVar9 = func_0x00018020eae0(in_RCX);
                }
                pcVar22 = *(code **)(*in_RCX + 0x22);
code_r0x0001802140e6:
                *(int64_t *)(&stack0xfffffffffffffff0 + iVar11) = iVar17;
                *(int64_t *)(&stack0xffffffffffffffe8 + iVar11) = (int64_t)iVar10;
                piVar16 = in_RCX[0x16];
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180214106;
                (*pcVar22)(piVar16, iVar15, (int64_t)iVar9, iVar4);
                goto code_r0x00018021410e;
            }
            if ((*(int64_t *)((int64_t)&var_10h + iVar11) != 0) || (*(int64_t *)(piVar16 + 0x44) == 0)) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213fcd;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213fe5;
                func_0x0001802295a0(0x1804bb408, 0x129, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ff7;
                func_0x0001802296d0(6, 0x86, 0);
                goto code_r0x00018021410e;
            }
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213fb7;
                iVar9 = func_0x00018020e980(in_RCX);
            }
            pcVar22 = *(code **)(*in_RCX + 0x44);
        }
        piVar16 = in_RCX[0x16];
        *(int64_t *)(&stack0xffffffffffffffe8 + iVar11) = iVar17;
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021407d;
        (*pcVar22)(piVar16, 0, iVar4, (int64_t)iVar9);
        goto code_r0x00018021410e;
    }
    if ((in_RCX[1] == (int32_t *)0x0) || (*in_RCX == (int32_t *)0x0)) {
        if (in_RDX != (int32_t *)0x0) goto code_r0x0001802135db;
code_r0x0001802135f0:
        if (((in_RCX[1] == (int32_t *)0x0) && (piVar16 == (int32_t *)0x0)) && (in_R8 == (int32_t *)0x0)) {
            if (in_RDX == (int32_t *)0x0) {
                if ((*in_RCX == (int32_t *)0x0) || ((*in_RCX)[5] != 2)) goto code_r0x000180213ba0;
            } else if (in_RDX[5] != 2) {
                if (*in_RCX != (int32_t *)0x0) {
                    pcVar22 = *(code **)(*in_RCX + 10);
                    if (pcVar22 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213626;
                        iVar6 = (*pcVar22)(in_RCX);
                        if (iVar6 == 0) goto code_r0x00018021410e;
                    }
                    piVar16 = in_RCX[0xf];
                    iVar6 = (*in_RCX)[0xc];
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021364b;
                    func_0x000180224b90(piVar16, (int64_t)iVar6, 0x1804bb408, 0xa7);
                    in_RCX[0xf] = (int32_t *)0x0;
                }
                goto code_r0x000180213a95;
            }
        }
        piVar16 = in_RCX[0x17];
        if (*in_RCX == piVar16) {
            *in_RCX = (int32_t *)0x0;
        }
        if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
            LOCK();
            piVar1 = piVar16 + 0x1e;
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 < 2) {
                uVar12 = *(undefined8 *)(piVar16 + 0x18);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802136a8;
                fcn.180224990(uVar12, 0x1804bb408, 0x843);
                uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802136b1;
                fcn.18027edb0(uVar12);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802136c6;
                fcn.180224990(piVar16, 0x1804bb408, 0x846);
            }
        }
        in_RCX[0x17] = (int32_t *)0x0;
        if (in_RDX != (int32_t *)0x0) {
            piVar16 = *in_RCX;
            if (piVar16 != (int32_t *)0x0) {
                uVar7 = *(undefined4 *)(in_RCX + 0xe);
                if (*(int64_t *)(piVar16 + 0x1c) == 0) {
                    pcVar22 = *(code **)(piVar16 + 10);
                    if (pcVar22 == (code *)0x0) {
code_r0x00018021378c:
                        if ((in_RCX[0xf] != (int32_t *)0x0) && ((*in_RCX)[0xc] != 0)) {
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137a5;
                            func_0x000180244fc0();
                        }
                        piVar16 = in_RCX[0xf];
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137bb;
                        fcn.180224990(piVar16, 0x1804bb408, 0x3f);
                        piVar16 = in_RCX[1];
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137c4;
                        func_0x00018026aee0(piVar16);
                        goto code_r0x0001802137c4;
                    }
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213788;
                    iVar6 = (*pcVar22)(in_RCX);
                    if (iVar6 != 0) goto code_r0x00018021378c;
                } else {
                    if (in_RCX[0x16] != (int32_t *)0x0) {
                        pcVar22 = *(code **)(piVar16 + 0x34);
                        piVar16 = piVar21;
                        if (pcVar22 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213711;
                            (*pcVar22)();
                            piVar16 = in_RCX[0x17];
                        }
                        in_RCX[0x16] = (int32_t *)0x0;
                        if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
                            LOCK();
                            piVar1 = piVar16 + 0x1e;
                            iVar6 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar6 < 2) {
                                uVar12 = *(undefined8 *)(piVar16 + 0x18);
                                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021375a;
                                fcn.180224990(uVar12, 0x1804bb408, 0x843);
                                uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213763;
                                fcn.18027edb0(uVar12);
                                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213778;
                                fcn.180224990(piVar16, 0x1804bb408, 0x846);
                            }
                        }
                    }
code_r0x0001802137c4:
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137d4;
                    func_0x0001804986e0(in_RCX, 0, 0xc0);
                    *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
                }
                *(undefined4 *)(in_RCX + 2) = *(undefined4 *)((int64_t)&var_8h + iVar11);
                *(undefined4 *)(in_RCX + 0xe) = uVar7;
            }
            if (in_R8 == (int32_t *)0x0) {
                in_R8 = *(int32_t **)((int64_t)&var_18h + iVar11);
                if (*(int32_t **)((int64_t)&var_18h + iVar11) != (int32_t *)0x0) goto code_r0x000180213837;
            } else {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137f3;
                iVar6 = func_0x00018026b010(in_R8);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137fc;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213814;
                    func_0x0001802295a0(0x1804bb408, 0x163, 0x1804bb420);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213826;
                    func_0x0001802296d0(6, 0x86, 0);
                    goto code_r0x00018021410e;
                }
code_r0x000180213837:
                piVar21 = in_R8;
                iVar6 = *in_RDX;
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213842;
                in_RDX = (int32_t *)func_0x00018026ab80(piVar21, iVar6);
                if (in_RDX == (int32_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021384f;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213867;
                    func_0x0001802295a0(0x1804bb408, 0x173, 0x1804bb420);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213879;
                    func_0x0001802296d0(6, 0x86, 0);
                    goto code_r0x00018021410e;
                }
            }
            in_RCX[1] = piVar21;
            *in_RCX = in_RDX;
            iVar6 = in_RDX[0xc];
            if (iVar6 == 0) {
                in_RCX[0xf] = (int32_t *)0x0;
            } else {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802138a7;
                piVar16 = (int32_t *)func_0x000180224d60((int64_t)iVar6, 0x1804bb408, 0x184);
                in_RCX[0xf] = piVar16;
                if (piVar16 == (int32_t *)0x0) {
                    *in_RCX = (int32_t *)0x0;
                    goto code_r0x00018021410e;
                }
            }
            iVar6 = in_RDX[2];
            *(uint32_t *)(in_RCX + 0xe) = *(uint32_t *)(in_RCX + 0xe) & 1;
            *(int32_t *)(in_RCX + 0xd) = iVar6;
            if ((*(uint8_t *)(*in_RCX + 4) & 0x40) != 0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802138e4;
                iVar6 = func_0x000180210b80(in_RCX, 0, 0, 0);
                if (iVar6 < 1) {
                    *in_RCX = (int32_t *)0x0;
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802138f4;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021390c;
                    func_0x0001802295a0(0x1804bb408, 0x192, 0x1804bb420);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021391e;
                    func_0x0001802296d0(6, 0x86, 0);
                    goto code_r0x00018021410e;
                }
            }
        }
    } else if ((in_RDX != (int32_t *)0x0) && (*in_RDX != **in_RCX)) {
code_r0x0001802135db:
        piVar16 = piVar21;
        if (in_R8 == (int32_t *)0x0) {
            iVar6 = *in_RDX;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802135e8;
            piVar16 = (int32_t *)func_0x00018026abf0(iVar6);
            *(int32_t **)((int64_t)&var_18h + iVar11) = piVar16;
        }
        goto code_r0x0001802135f0;
    }
    if (*in_RCX == (int32_t *)0x0) goto code_r0x00018021410e;
    iVar6 = (*in_RCX)[1];
    if ((iVar6 != 1) && ((iVar6 - 8U & 0xfffffff7) != 0)) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021357b;
        func_0x00018027bb50(0x1804bb440, 0x1804bb408, 0x1a0);
    }
    if ((*(uint8_t *)(in_RCX + 0xe) & 1) == 0) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021358d;
        uVar12 = func_0x00018020e940(in_RCX);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213595;
        iVar6 = func_0x00018020efb0(uVar12);
        if (iVar6 == 0x10002) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802135a5;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802135bd;
            func_0x0001802295a0(0x1804bb408, 0x1a4, 0x1804bb420);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802135cf;
            func_0x0001802296d0(6, 0xaa, 0);
            goto code_r0x00018021410e;
        }
    }
    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021392d;
    uVar12 = func_0x00018020e940(in_RCX);
    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213935;
    uVar13 = func_0x00018020ef80(uVar12);
    if ((uVar13 & 0x10) == 0) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213941;
        uVar12 = func_0x00018020e940(in_RCX);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213949;
        uVar7 = func_0x00018020efb0(uVar12);
    // switch table (6 cases) at 0x180214130
        switch(uVar7) {
        case 0:
        case 1:
            break;
        case 2:
            goto code_r0x00018021396a;
        case 3:
        case 4:
            goto code_r0x000180213967;
        case 5:
            *(undefined4 *)(in_RCX + 0xb) = 0;
            if (iVar4 == 0) break;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a3c;
            iVar6 = func_0x00018020e980(in_RCX);
            iVar17 = (int64_t)iVar6;
            ppiVar19 = (int32_t **)iVar4;
            if (0xf < iVar6 - 1U) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a5b;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a73;
                func_0x0001802295a0(0x1804bb408, 0x1c7, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a85;
                func_0x0001802296d0(6, 0xc2, 0);
                goto code_r0x00018021410e;
            }
            goto code_r0x000180213999;
        default:
            goto code_r0x00018021410e;
        }
    }
    goto code_r0x00018021399e;
code_r0x000180213967:
    *(undefined4 *)(in_RCX + 0xb) = 0;
code_r0x00018021396a:
    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213972;
    uVar8 = func_0x00018020e980(in_RCX);
    if (0x10 < uVar8) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802139f7;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a0f;
        func_0x0001802295a0(0x1804bb408, 0x1b9, 0x1804bb420);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a21;
        func_0x0001802296d0(6, 0xc2, 0);
        goto code_r0x00018021410e;
    }
    iVar17 = (int64_t)(int32_t)uVar8;
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021398e;
        func_0x000180498030(in_RCX + 3, iVar4, iVar17);
    }
    ppiVar19 = in_RCX + 3;
code_r0x000180213999:
    *(code **)((int64_t)&pcStack_40 + iVar11) = case.0x180213965.0;
    func_0x000180498030(in_RCX + 5, ppiVar19, iVar17);
code_r0x00018021399e:
    if ((*(int64_t *)((int64_t)&var_10h + iVar11) != 0) || ((*(uint8_t *)(*in_RCX + 4) & 0x20) != 0)) {
        pcVar22 = *(code **)(*in_RCX + 6);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802139c9;
        iVar6 = (*pcVar22)(in_RCX, *(int64_t *)((int64_t)&var_10h + iVar11), iVar4, 
                           *(undefined4 *)((int64_t)&var_8h + iVar11));
        if (iVar6 == 0) goto code_r0x00018021410e;
    }
    *(undefined4 *)((int64_t)in_RCX + 0x14) = 0;
    *(undefined4 *)(in_RCX + 0x10) = 0;
    *(int32_t *)((int64_t)in_RCX + 0x84) = (*in_RCX)[1] + -1;
code_r0x00018021410e:
    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021411a;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar11));
    return;
}

// ============================================================
// Function: FUN_18021350d
// Address: 0x18021350d
// Size: 3073 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_3h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.180213460(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_c0h)
{
    int32_t *piVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    undefined4 uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    uint64_t uVar13;
    undefined4 *puVar14;
    int64_t iVar15;
    int32_t **in_RCX;
    int32_t *piVar16;
    int64_t iVar17;
    int64_t *piVar18;
    int32_t *in_RDX;
    int32_t **ppiVar19;
    undefined8 unaff_RBX;
    int64_t *piVar20;
    int32_t *piVar21;
    int32_t *in_R8;
    undefined8 in_R9;
    code *pcVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    code *pcStack_40;
    
    pcStack_40 = (code *)0x18021347b;
    iVar11 = fcn.18045a350();
    iVar17 = arg_40h;
    iVar4 = arg_28h;
    iVar6 = (int32_t)arg_30h;
    iVar11 = -iVar11;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar11);
    piVar21 = (int32_t *)0x0;
    iVar9 = 0;
    iVar10 = 0;
    piVar16 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_18h + iVar11) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar11) = in_R9;
    if (iVar6 == -1) {
        *(undefined4 *)((int64_t)&var_8h + iVar11) = *(undefined4 *)(in_RCX + 2);
    } else {
        uVar8 = (uint32_t)(iVar6 != 0);
        *(uint32_t *)((int64_t)&var_8h + iVar11) = uVar8;
        *(uint32_t *)(in_RCX + 2) = uVar8;
    }
    if ((in_RDX == (int32_t *)0x0) && (*in_RCX == (int32_t *)0x0)) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802134dc;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802134f4;
        func_0x0001802295a0(0x1804bb408, 0x76, 0x1804bb420);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213506;
        func_0x0001802296d0(6, 0x83, 0);
        goto code_r0x00018021410e;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar11) = unaff_RBX;
    if ((char)arg_38h != '\0') {
        if (in_RDX == (int32_t *)0x0) {
code_r0x000180213ba0:
            in_RDX = *in_RCX;
        } else {
code_r0x000180213a95:
            piVar16 = *in_RCX;
            if (piVar16 != (int32_t *)0x0) {
                uVar7 = *(undefined4 *)(in_RCX + 0xe);
                if (*(int64_t *)(piVar16 + 0x1c) == 0) {
                    pcVar22 = *(code **)(piVar16 + 10);
                    if (pcVar22 == (code *)0x0) {
code_r0x000180213b44:
                        if ((in_RCX[0xf] != (int32_t *)0x0) && ((*in_RCX)[0xc] != 0)) {
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b5d;
                            func_0x000180244fc0();
                        }
                        piVar16 = in_RCX[0xf];
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b73;
                        fcn.180224990(piVar16, 0x1804bb408, 0x3f);
                        piVar16 = in_RCX[1];
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b7c;
                        func_0x00018026aee0(piVar16);
                        goto code_r0x000180213b7c;
                    }
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b40;
                    iVar6 = (*pcVar22)(in_RCX);
                    if (iVar6 != 0) goto code_r0x000180213b44;
                } else {
                    if (in_RCX[0x16] != (int32_t *)0x0) {
                        pcVar22 = *(code **)(piVar16 + 0x34);
                        if (pcVar22 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ac9;
                            (*pcVar22)();
                        }
                        in_RCX[0x16] = (int32_t *)0x0;
                    }
                    piVar16 = in_RCX[0x17];
                    if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
                        LOCK();
                        piVar21 = piVar16 + 0x1e;
                        iVar6 = *piVar21;
                        *piVar21 = *piVar21 + -1;
                        UNLOCK();
                        if (iVar6 < 2) {
                            uVar12 = *(undefined8 *)(piVar16 + 0x18);
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b12;
                            fcn.180224990(uVar12, 0x1804bb408, 0x843);
                            uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b1b;
                            fcn.18027edb0(uVar12);
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b30;
                            fcn.180224990(piVar16, 0x1804bb408, 0x846);
                        }
                    }
code_r0x000180213b7c:
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b8c;
                    func_0x0001804986e0(in_RCX, 0, 0xc0);
                    *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
                }
                *(undefined4 *)(in_RCX + 2) = *(undefined4 *)((int64_t)&var_8h + iVar11);
                *(undefined4 *)(in_RCX + 0xe) = uVar7;
            }
        }
        if (*(int64_t *)(in_RDX + 0x1c) == 0) {
            if (*in_RDX == 0) {
                uVar12 = 0x180645710;
            } else {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213bc2;
                uVar12 = func_0x00018022ccf0();
            }
            *(code **)(&stack0xfffffffffffffff8 + iVar11) = fcn.180212e80;
            *(undefined8 *)(&stack0xfffffffffffffff0 + iVar11) = 0x180211b30;
            *(code **)(&stack0xffffffffffffffe8 + iVar11) = fcn.180212f40;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213bfc;
            in_RDX = (int32_t *)func_0x000180280c20(0, 2, uVar12, 0x1805aadb1);
            if (in_RDX == (int32_t *)0x0) goto code_r0x00018021410e;
            piVar16 = in_RCX[0x17];
            if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
                LOCK();
                piVar21 = piVar16 + 0x1e;
                iVar6 = *piVar21;
                *piVar21 = *piVar21 + -1;
                UNLOCK();
                if (iVar6 < 2) {
                    uVar12 = *(undefined8 *)(piVar16 + 0x18);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c3e;
                    fcn.180224990(uVar12, 0x1804bb408, 0x843);
                    uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c47;
                    fcn.18027edb0(uVar12);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c5c;
                    fcn.180224990(piVar16, 0x1804bb408, 0x846);
                }
            }
            in_RCX[0x17] = in_RDX;
            if (*(int64_t *)(in_RDX + 0x1c) == 0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c6e;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c86;
                func_0x0001802295a0(0x1804bb408, 0xcf, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c98;
                func_0x0001802296d0(6, 0x86, 0);
                goto code_r0x00018021410e;
            }
        }
        if (in_RDX != in_RCX[0x17]) {
            if (in_RDX[5] == 0) {
                LOCK();
                in_RDX[0x1e] = in_RDX[0x1e] + 1;
                UNLOCK();
            }
            piVar16 = in_RCX[0x17];
            if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
                LOCK();
                piVar21 = piVar16 + 0x1e;
                iVar6 = *piVar21;
                *piVar21 = *piVar21 + -1;
                UNLOCK();
                if (iVar6 < 2) {
                    uVar12 = *(undefined8 *)(piVar16 + 0x18);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ce9;
                    fcn.180224990(uVar12, 0x1804bb408, 0x843);
                    uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213cf2;
                    fcn.18027edb0(uVar12);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d07;
                    fcn.180224990(piVar16, 0x1804bb408, 0x846);
                }
            }
            in_RCX[0x17] = in_RDX;
        }
        cVar5 = (char)arg_38h;
        *in_RCX = in_RDX;
        if ((char)arg_38h != '\0') {
            if (*(int32_t *)((int64_t)&var_8h + iVar11) == 0) {
                iVar15 = *(int64_t *)(in_RDX + 0x2e);
            } else {
                iVar15 = *(int64_t *)(in_RDX + 0x2c);
            }
            if (((iVar15 == 0) || (*(int64_t *)(in_RDX + 0x30) == 0)) || (*(int64_t *)(in_RDX + 0x32) == 0)) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d4c;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d64;
                func_0x0001802295a0(0x1804bb408, 0xe0, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d76;
                func_0x0001802296d0(6, 0xe6, 0);
                goto code_r0x00018021410e;
            }
        }
        if (in_RCX[0x16] == (int32_t *)0x0) {
            uVar12 = *(undefined8 *)(in_RDX + 0x1c);
            pcVar22 = *(code **)(in_RDX + 0x20);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d96;
            uVar12 = func_0x00018027e810(uVar12);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d9b;
            piVar16 = (int32_t *)(*pcVar22)(uVar12);
            in_RCX[0x16] = piVar16;
            if (piVar16 == (int32_t *)0x0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213dac;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213dc4;
                func_0x0001802295a0(0x1804bb408, 0xe7, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213dd6;
                func_0x0001802296d0(6, 0x86, 0);
                goto code_r0x00018021410e;
            }
        }
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213df0;
            iVar6 = func_0x000180211820(in_RCX, 0);
            if (iVar6 == 0) goto code_r0x00018021410e;
        }
        if (iVar17 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar11) = 0;
            *(undefined4 *)((int64_t)&arg_30h + iVar11) = 0;
            *(undefined8 *)((int64_t)&arg_38h + iVar11) = 0;
            *(undefined8 *)((int64_t)&arg_40h + iVar11) = 0;
            var_b0h = 0;
            var_a8h._0_4_ = 0;
            var_a0h = 0;
            var_98h = 0;
            var_90h = 0;
            var_88h = 0;
            var_80h._0_4_ = 0;
            var_78h = 0;
            var_70h = 0;
            var_68h = 0;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213e4d;
            puVar14 = (undefined4 *)func_0x00018022ae60(iVar17, 0x1804bb2f4);
            if (puVar14 != (undefined4 *)0x0) {
                uVar7 = puVar14[1];
                uVar2 = puVar14[2];
                uVar3 = puVar14[3];
                *(undefined4 *)((int64_t)&arg_28h + iVar11) = *puVar14;
                *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4) = uVar7;
                *(undefined4 *)((int64_t)&arg_30h + iVar11) = uVar2;
                *(undefined4 *)((int64_t)&arg_30h + iVar11 + 4) = uVar3;
                uVar7 = puVar14[5];
                uVar2 = puVar14[6];
                uVar3 = puVar14[7];
                *(undefined4 *)((int64_t)&arg_38h + iVar11) = puVar14[4];
                *(undefined4 *)((int64_t)&arg_38h + iVar11 + 4) = uVar7;
                *(undefined4 *)((int64_t)&arg_40h + iVar11) = uVar2;
                *(undefined4 *)((int64_t)&arg_40h + iVar11 + 4) = uVar3;
            }
            piVar20 = (int64_t *)((int64_t)&arg_28h + iVar11);
            if (puVar14 != (undefined4 *)0x0) {
                piVar20 = &var_b0h;
            }
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213e8c;
            puVar14 = (undefined4 *)func_0x00018022ae60(iVar17, 0x1804bb2ec);
            piVar18 = piVar20;
            if (puVar14 != (undefined4 *)0x0) {
                uVar7 = puVar14[1];
                uVar2 = puVar14[2];
                uVar3 = puVar14[3];
                piVar18 = piVar20 + 5;
                *(undefined4 *)piVar20 = *puVar14;
                *(undefined4 *)((int64_t)piVar20 + 4) = uVar7;
                *(undefined4 *)(piVar20 + 1) = uVar2;
                *(undefined4 *)((int64_t)piVar20 + 0xc) = uVar3;
                uVar7 = puVar14[5];
                uVar2 = puVar14[6];
                uVar3 = puVar14[7];
                *(undefined4 *)(piVar20 + 2) = puVar14[4];
                *(undefined4 *)((int64_t)piVar20 + 0x14) = uVar7;
                *(undefined4 *)(piVar20 + 3) = uVar2;
                *(undefined4 *)((int64_t)piVar20 + 0x1c) = uVar3;
                piVar20[4] = *(int64_t *)(puVar14 + 8);
            }
            if (piVar18 != (int64_t *)((int64_t)&arg_28h + iVar11)) {
                if ((*in_RCX == (int32_t *)0x0) || (pcVar22 = *(code **)(*in_RCX + 0x3c), pcVar22 == (code *)0x0)) {
code_r0x000180213f45:
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f4a;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f62;
                    func_0x0001802295a0(0x1804bb408, 0x112, 0x1804bb420);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f74;
                    func_0x0001802296d0(6, 0xdd, 0);
                    goto code_r0x00018021410e;
                }
                piVar16 = in_RCX[0x16];
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ee1;
                iVar6 = (*pcVar22)(piVar16, (int64_t)&arg_28h + iVar11);
                if (iVar6 < 1) {
                    if (iVar6 == 0) goto code_r0x000180213f45;
                } else {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ef6;
                    iVar15 = func_0x00018022ae60((int64_t)&arg_28h + iVar11, 0x1804bb2f4);
                    if (iVar15 != 0) {
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f07;
                        iVar6 = func_0x000180229fc0(iVar15, in_RCX + 0xd);
                        if (iVar6 == 0) {
                            *(undefined4 *)(in_RCX + 0xd) = 0xffffffff;
                            goto code_r0x000180213f45;
                        }
                    }
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f25;
                    iVar15 = func_0x00018022ae60((int64_t)&arg_28h + iVar11, 0x1804bb2ec);
                    if (iVar15 != 0) {
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f36;
                        iVar6 = func_0x000180229fc0(iVar15, (int64_t)in_RCX + 0x6c);
                        if (iVar6 == 0) {
                            *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
                            goto code_r0x000180213f45;
                        }
                    }
                }
            }
        }
        if (cVar5 != '\0') goto code_r0x00018021410e;
        piVar16 = *in_RCX;
        if (*(int32_t *)((int64_t)&var_8h + iVar11) == 0) {
            if (*(int64_t *)(piVar16 + 0x24) != 0) {
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802140c6;
                    iVar10 = func_0x00018020e980(in_RCX);
                }
                iVar15 = *(int64_t *)((int64_t)&var_10h + iVar11);
                if (iVar15 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802140da;
                    iVar9 = func_0x00018020eae0(in_RCX);
                }
                pcVar22 = *(code **)(*in_RCX + 0x24);
                goto code_r0x0001802140e6;
            }
            if ((*(int64_t *)((int64_t)&var_10h + iVar11) != 0) || (*(int64_t *)(piVar16 + 0x46) == 0)) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180214087;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021409f;
                func_0x0001802295a0(0x1804bb408, 0x143, 0x1804bb420);
                *(code **)((int64_t)&pcStack_40 + iVar11) = case.default.0x180213965;
                func_0x0001802296d0(6, 0x86, 0);
                goto code_r0x00018021410e;
            }
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021405a;
                iVar9 = func_0x00018020e980(in_RCX);
            }
            pcVar22 = *(code **)(*in_RCX + 0x46);
        } else {
            if (*(int64_t *)(piVar16 + 0x22) != 0) {
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021400f;
                    iVar10 = func_0x00018020e980(in_RCX);
                }
                iVar15 = *(int64_t *)((int64_t)&var_10h + iVar11);
                if (iVar15 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180214023;
                    iVar9 = func_0x00018020eae0(in_RCX);
                }
                pcVar22 = *(code **)(*in_RCX + 0x22);
code_r0x0001802140e6:
                *(int64_t *)(&stack0xfffffffffffffff0 + iVar11) = iVar17;
                *(int64_t *)(&stack0xffffffffffffffe8 + iVar11) = (int64_t)iVar10;
                piVar16 = in_RCX[0x16];
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180214106;
                (*pcVar22)(piVar16, iVar15, (int64_t)iVar9, iVar4);
                goto code_r0x00018021410e;
            }
            if ((*(int64_t *)((int64_t)&var_10h + iVar11) != 0) || (*(int64_t *)(piVar16 + 0x44) == 0)) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213fcd;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213fe5;
                func_0x0001802295a0(0x1804bb408, 0x129, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ff7;
                func_0x0001802296d0(6, 0x86, 0);
                goto code_r0x00018021410e;
            }
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213fb7;
                iVar9 = func_0x00018020e980(in_RCX);
            }
            pcVar22 = *(code **)(*in_RCX + 0x44);
        }
        piVar16 = in_RCX[0x16];
        *(int64_t *)(&stack0xffffffffffffffe8 + iVar11) = iVar17;
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021407d;
        (*pcVar22)(piVar16, 0, iVar4, (int64_t)iVar9);
        goto code_r0x00018021410e;
    }
    if ((in_RCX[1] == (int32_t *)0x0) || (*in_RCX == (int32_t *)0x0)) {
        if (in_RDX != (int32_t *)0x0) goto code_r0x0001802135db;
code_r0x0001802135f0:
        if (((in_RCX[1] == (int32_t *)0x0) && (piVar16 == (int32_t *)0x0)) && (in_R8 == (int32_t *)0x0)) {
            if (in_RDX == (int32_t *)0x0) {
                if ((*in_RCX == (int32_t *)0x0) || ((*in_RCX)[5] != 2)) goto code_r0x000180213ba0;
            } else if (in_RDX[5] != 2) {
                if (*in_RCX != (int32_t *)0x0) {
                    pcVar22 = *(code **)(*in_RCX + 10);
                    if (pcVar22 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213626;
                        iVar6 = (*pcVar22)(in_RCX);
                        if (iVar6 == 0) goto code_r0x00018021410e;
                    }
                    piVar16 = in_RCX[0xf];
                    iVar6 = (*in_RCX)[0xc];
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021364b;
                    func_0x000180224b90(piVar16, (int64_t)iVar6, 0x1804bb408, 0xa7);
                    in_RCX[0xf] = (int32_t *)0x0;
                }
                goto code_r0x000180213a95;
            }
        }
        piVar16 = in_RCX[0x17];
        if (*in_RCX == piVar16) {
            *in_RCX = (int32_t *)0x0;
        }
        if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
            LOCK();
            piVar1 = piVar16 + 0x1e;
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 < 2) {
                uVar12 = *(undefined8 *)(piVar16 + 0x18);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802136a8;
                fcn.180224990(uVar12, 0x1804bb408, 0x843);
                uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802136b1;
                fcn.18027edb0(uVar12);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802136c6;
                fcn.180224990(piVar16, 0x1804bb408, 0x846);
            }
        }
        in_RCX[0x17] = (int32_t *)0x0;
        if (in_RDX != (int32_t *)0x0) {
            piVar16 = *in_RCX;
            if (piVar16 != (int32_t *)0x0) {
                uVar7 = *(undefined4 *)(in_RCX + 0xe);
                if (*(int64_t *)(piVar16 + 0x1c) == 0) {
                    pcVar22 = *(code **)(piVar16 + 10);
                    if (pcVar22 == (code *)0x0) {
code_r0x00018021378c:
                        if ((in_RCX[0xf] != (int32_t *)0x0) && ((*in_RCX)[0xc] != 0)) {
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137a5;
                            func_0x000180244fc0();
                        }
                        piVar16 = in_RCX[0xf];
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137bb;
                        fcn.180224990(piVar16, 0x1804bb408, 0x3f);
                        piVar16 = in_RCX[1];
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137c4;
                        func_0x00018026aee0(piVar16);
                        goto code_r0x0001802137c4;
                    }
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213788;
                    iVar6 = (*pcVar22)(in_RCX);
                    if (iVar6 != 0) goto code_r0x00018021378c;
                } else {
                    if (in_RCX[0x16] != (int32_t *)0x0) {
                        pcVar22 = *(code **)(piVar16 + 0x34);
                        piVar16 = piVar21;
                        if (pcVar22 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213711;
                            (*pcVar22)();
                            piVar16 = in_RCX[0x17];
                        }
                        in_RCX[0x16] = (int32_t *)0x0;
                        if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
                            LOCK();
                            piVar1 = piVar16 + 0x1e;
                            iVar6 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar6 < 2) {
                                uVar12 = *(undefined8 *)(piVar16 + 0x18);
                                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021375a;
                                fcn.180224990(uVar12, 0x1804bb408, 0x843);
                                uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213763;
                                fcn.18027edb0(uVar12);
                                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213778;
                                fcn.180224990(piVar16, 0x1804bb408, 0x846);
                            }
                        }
                    }
code_r0x0001802137c4:
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137d4;
                    func_0x0001804986e0(in_RCX, 0, 0xc0);
                    *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
                }
                *(undefined4 *)(in_RCX + 2) = *(undefined4 *)((int64_t)&var_8h + iVar11);
                *(undefined4 *)(in_RCX + 0xe) = uVar7;
            }
            if (in_R8 == (int32_t *)0x0) {
                in_R8 = *(int32_t **)((int64_t)&var_18h + iVar11);
                if (*(int32_t **)((int64_t)&var_18h + iVar11) != (int32_t *)0x0) goto code_r0x000180213837;
            } else {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137f3;
                iVar6 = func_0x00018026b010(in_R8);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137fc;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213814;
                    func_0x0001802295a0(0x1804bb408, 0x163, 0x1804bb420);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213826;
                    func_0x0001802296d0(6, 0x86, 0);
                    goto code_r0x00018021410e;
                }
code_r0x000180213837:
                piVar21 = in_R8;
                iVar6 = *in_RDX;
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213842;
                in_RDX = (int32_t *)func_0x00018026ab80(piVar21, iVar6);
                if (in_RDX == (int32_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021384f;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213867;
                    func_0x0001802295a0(0x1804bb408, 0x173, 0x1804bb420);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213879;
                    func_0x0001802296d0(6, 0x86, 0);
                    goto code_r0x00018021410e;
                }
            }
            in_RCX[1] = piVar21;
            *in_RCX = in_RDX;
            iVar6 = in_RDX[0xc];
            if (iVar6 == 0) {
                in_RCX[0xf] = (int32_t *)0x0;
            } else {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802138a7;
                piVar16 = (int32_t *)func_0x000180224d60((int64_t)iVar6, 0x1804bb408, 0x184);
                in_RCX[0xf] = piVar16;
                if (piVar16 == (int32_t *)0x0) {
                    *in_RCX = (int32_t *)0x0;
                    goto code_r0x00018021410e;
                }
            }
            iVar6 = in_RDX[2];
            *(uint32_t *)(in_RCX + 0xe) = *(uint32_t *)(in_RCX + 0xe) & 1;
            *(int32_t *)(in_RCX + 0xd) = iVar6;
            if ((*(uint8_t *)(*in_RCX + 4) & 0x40) != 0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802138e4;
                iVar6 = func_0x000180210b80(in_RCX, 0, 0, 0);
                if (iVar6 < 1) {
                    *in_RCX = (int32_t *)0x0;
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802138f4;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021390c;
                    func_0x0001802295a0(0x1804bb408, 0x192, 0x1804bb420);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021391e;
                    func_0x0001802296d0(6, 0x86, 0);
                    goto code_r0x00018021410e;
                }
            }
        }
    } else if ((in_RDX != (int32_t *)0x0) && (*in_RDX != **in_RCX)) {
code_r0x0001802135db:
        piVar16 = piVar21;
        if (in_R8 == (int32_t *)0x0) {
            iVar6 = *in_RDX;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802135e8;
            piVar16 = (int32_t *)func_0x00018026abf0(iVar6);
            *(int32_t **)((int64_t)&var_18h + iVar11) = piVar16;
        }
        goto code_r0x0001802135f0;
    }
    if (*in_RCX == (int32_t *)0x0) goto code_r0x00018021410e;
    iVar6 = (*in_RCX)[1];
    if ((iVar6 != 1) && ((iVar6 - 8U & 0xfffffff7) != 0)) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021357b;
        func_0x00018027bb50(0x1804bb440, 0x1804bb408, 0x1a0);
    }
    if ((*(uint8_t *)(in_RCX + 0xe) & 1) == 0) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021358d;
        uVar12 = func_0x00018020e940(in_RCX);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213595;
        iVar6 = func_0x00018020efb0(uVar12);
        if (iVar6 == 0x10002) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802135a5;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802135bd;
            func_0x0001802295a0(0x1804bb408, 0x1a4, 0x1804bb420);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802135cf;
            func_0x0001802296d0(6, 0xaa, 0);
            goto code_r0x00018021410e;
        }
    }
    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021392d;
    uVar12 = func_0x00018020e940(in_RCX);
    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213935;
    uVar13 = func_0x00018020ef80(uVar12);
    if ((uVar13 & 0x10) == 0) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213941;
        uVar12 = func_0x00018020e940(in_RCX);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213949;
        uVar7 = func_0x00018020efb0(uVar12);
    // switch table (6 cases) at 0x180214130
        switch(uVar7) {
        case 0:
        case 1:
            break;
        case 2:
            goto code_r0x00018021396a;
        case 3:
        case 4:
            goto code_r0x000180213967;
        case 5:
            *(undefined4 *)(in_RCX + 0xb) = 0;
            if (iVar4 == 0) break;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a3c;
            iVar6 = func_0x00018020e980(in_RCX);
            iVar17 = (int64_t)iVar6;
            ppiVar19 = (int32_t **)iVar4;
            if (0xf < iVar6 - 1U) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a5b;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a73;
                func_0x0001802295a0(0x1804bb408, 0x1c7, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a85;
                func_0x0001802296d0(6, 0xc2, 0);
                goto code_r0x00018021410e;
            }
            goto code_r0x000180213999;
        default:
            goto code_r0x00018021410e;
        }
    }
    goto code_r0x00018021399e;
code_r0x000180213967:
    *(undefined4 *)(in_RCX + 0xb) = 0;
code_r0x00018021396a:
    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213972;
    uVar8 = func_0x00018020e980(in_RCX);
    if (0x10 < uVar8) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802139f7;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a0f;
        func_0x0001802295a0(0x1804bb408, 0x1b9, 0x1804bb420);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a21;
        func_0x0001802296d0(6, 0xc2, 0);
        goto code_r0x00018021410e;
    }
    iVar17 = (int64_t)(int32_t)uVar8;
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021398e;
        func_0x000180498030(in_RCX + 3, iVar4, iVar17);
    }
    ppiVar19 = in_RCX + 3;
code_r0x000180213999:
    *(code **)((int64_t)&pcStack_40 + iVar11) = case.0x180213965.0;
    func_0x000180498030(in_RCX + 5, ppiVar19, iVar17);
code_r0x00018021399e:
    if ((*(int64_t *)((int64_t)&var_10h + iVar11) != 0) || ((*(uint8_t *)(*in_RCX + 4) & 0x20) != 0)) {
        pcVar22 = *(code **)(*in_RCX + 6);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802139c9;
        iVar6 = (*pcVar22)(in_RCX, *(int64_t *)((int64_t)&var_10h + iVar11), iVar4, 
                           *(undefined4 *)((int64_t)&var_8h + iVar11));
        if (iVar6 == 0) goto code_r0x00018021410e;
    }
    *(undefined4 *)((int64_t)in_RCX + 0x14) = 0;
    *(undefined4 *)(in_RCX + 0x10) = 0;
    *(int32_t *)((int64_t)in_RCX + 0x84) = (*in_RCX)[1] + -1;
code_r0x00018021410e:
    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021411a;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar11));
    return;
}

// ============================================================
// Function: FUN_18021410e
// Address: 0x18021410e
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_3h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.180213460(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_c0h)
{
    int32_t *piVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    undefined4 uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    uint64_t uVar13;
    undefined4 *puVar14;
    int64_t iVar15;
    int32_t **in_RCX;
    int32_t *piVar16;
    int64_t iVar17;
    int64_t *piVar18;
    int32_t *in_RDX;
    int32_t **ppiVar19;
    undefined8 unaff_RBX;
    int64_t *piVar20;
    int32_t *piVar21;
    int32_t *in_R8;
    undefined8 in_R9;
    code *pcVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    code *pcStack_40;
    
    pcStack_40 = (code *)0x18021347b;
    iVar11 = fcn.18045a350();
    iVar17 = arg_40h;
    iVar4 = arg_28h;
    iVar6 = (int32_t)arg_30h;
    iVar11 = -iVar11;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar11);
    piVar21 = (int32_t *)0x0;
    iVar9 = 0;
    iVar10 = 0;
    piVar16 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_18h + iVar11) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar11) = in_R9;
    if (iVar6 == -1) {
        *(undefined4 *)((int64_t)&var_8h + iVar11) = *(undefined4 *)(in_RCX + 2);
    } else {
        uVar8 = (uint32_t)(iVar6 != 0);
        *(uint32_t *)((int64_t)&var_8h + iVar11) = uVar8;
        *(uint32_t *)(in_RCX + 2) = uVar8;
    }
    if ((in_RDX == (int32_t *)0x0) && (*in_RCX == (int32_t *)0x0)) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802134dc;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802134f4;
        func_0x0001802295a0(0x1804bb408, 0x76, 0x1804bb420);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213506;
        func_0x0001802296d0(6, 0x83, 0);
        goto code_r0x00018021410e;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar11) = unaff_RBX;
    if ((char)arg_38h != '\0') {
        if (in_RDX == (int32_t *)0x0) {
code_r0x000180213ba0:
            in_RDX = *in_RCX;
        } else {
code_r0x000180213a95:
            piVar16 = *in_RCX;
            if (piVar16 != (int32_t *)0x0) {
                uVar7 = *(undefined4 *)(in_RCX + 0xe);
                if (*(int64_t *)(piVar16 + 0x1c) == 0) {
                    pcVar22 = *(code **)(piVar16 + 10);
                    if (pcVar22 == (code *)0x0) {
code_r0x000180213b44:
                        if ((in_RCX[0xf] != (int32_t *)0x0) && ((*in_RCX)[0xc] != 0)) {
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b5d;
                            func_0x000180244fc0();
                        }
                        piVar16 = in_RCX[0xf];
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b73;
                        fcn.180224990(piVar16, 0x1804bb408, 0x3f);
                        piVar16 = in_RCX[1];
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b7c;
                        func_0x00018026aee0(piVar16);
                        goto code_r0x000180213b7c;
                    }
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b40;
                    iVar6 = (*pcVar22)(in_RCX);
                    if (iVar6 != 0) goto code_r0x000180213b44;
                } else {
                    if (in_RCX[0x16] != (int32_t *)0x0) {
                        pcVar22 = *(code **)(piVar16 + 0x34);
                        if (pcVar22 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ac9;
                            (*pcVar22)();
                        }
                        in_RCX[0x16] = (int32_t *)0x0;
                    }
                    piVar16 = in_RCX[0x17];
                    if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
                        LOCK();
                        piVar21 = piVar16 + 0x1e;
                        iVar6 = *piVar21;
                        *piVar21 = *piVar21 + -1;
                        UNLOCK();
                        if (iVar6 < 2) {
                            uVar12 = *(undefined8 *)(piVar16 + 0x18);
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b12;
                            fcn.180224990(uVar12, 0x1804bb408, 0x843);
                            uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b1b;
                            fcn.18027edb0(uVar12);
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b30;
                            fcn.180224990(piVar16, 0x1804bb408, 0x846);
                        }
                    }
code_r0x000180213b7c:
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213b8c;
                    func_0x0001804986e0(in_RCX, 0, 0xc0);
                    *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
                }
                *(undefined4 *)(in_RCX + 2) = *(undefined4 *)((int64_t)&var_8h + iVar11);
                *(undefined4 *)(in_RCX + 0xe) = uVar7;
            }
        }
        if (*(int64_t *)(in_RDX + 0x1c) == 0) {
            if (*in_RDX == 0) {
                uVar12 = 0x180645710;
            } else {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213bc2;
                uVar12 = func_0x00018022ccf0();
            }
            *(code **)(&stack0xfffffffffffffff8 + iVar11) = fcn.180212e80;
            *(undefined8 *)(&stack0xfffffffffffffff0 + iVar11) = 0x180211b30;
            *(code **)(&stack0xffffffffffffffe8 + iVar11) = fcn.180212f40;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213bfc;
            in_RDX = (int32_t *)func_0x000180280c20(0, 2, uVar12, 0x1805aadb1);
            if (in_RDX == (int32_t *)0x0) goto code_r0x00018021410e;
            piVar16 = in_RCX[0x17];
            if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
                LOCK();
                piVar21 = piVar16 + 0x1e;
                iVar6 = *piVar21;
                *piVar21 = *piVar21 + -1;
                UNLOCK();
                if (iVar6 < 2) {
                    uVar12 = *(undefined8 *)(piVar16 + 0x18);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c3e;
                    fcn.180224990(uVar12, 0x1804bb408, 0x843);
                    uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c47;
                    fcn.18027edb0(uVar12);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c5c;
                    fcn.180224990(piVar16, 0x1804bb408, 0x846);
                }
            }
            in_RCX[0x17] = in_RDX;
            if (*(int64_t *)(in_RDX + 0x1c) == 0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c6e;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c86;
                func_0x0001802295a0(0x1804bb408, 0xcf, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213c98;
                func_0x0001802296d0(6, 0x86, 0);
                goto code_r0x00018021410e;
            }
        }
        if (in_RDX != in_RCX[0x17]) {
            if (in_RDX[5] == 0) {
                LOCK();
                in_RDX[0x1e] = in_RDX[0x1e] + 1;
                UNLOCK();
            }
            piVar16 = in_RCX[0x17];
            if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
                LOCK();
                piVar21 = piVar16 + 0x1e;
                iVar6 = *piVar21;
                *piVar21 = *piVar21 + -1;
                UNLOCK();
                if (iVar6 < 2) {
                    uVar12 = *(undefined8 *)(piVar16 + 0x18);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ce9;
                    fcn.180224990(uVar12, 0x1804bb408, 0x843);
                    uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213cf2;
                    fcn.18027edb0(uVar12);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d07;
                    fcn.180224990(piVar16, 0x1804bb408, 0x846);
                }
            }
            in_RCX[0x17] = in_RDX;
        }
        cVar5 = (char)arg_38h;
        *in_RCX = in_RDX;
        if ((char)arg_38h != '\0') {
            if (*(int32_t *)((int64_t)&var_8h + iVar11) == 0) {
                iVar15 = *(int64_t *)(in_RDX + 0x2e);
            } else {
                iVar15 = *(int64_t *)(in_RDX + 0x2c);
            }
            if (((iVar15 == 0) || (*(int64_t *)(in_RDX + 0x30) == 0)) || (*(int64_t *)(in_RDX + 0x32) == 0)) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d4c;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d64;
                func_0x0001802295a0(0x1804bb408, 0xe0, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d76;
                func_0x0001802296d0(6, 0xe6, 0);
                goto code_r0x00018021410e;
            }
        }
        if (in_RCX[0x16] == (int32_t *)0x0) {
            uVar12 = *(undefined8 *)(in_RDX + 0x1c);
            pcVar22 = *(code **)(in_RDX + 0x20);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d96;
            uVar12 = func_0x00018027e810(uVar12);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213d9b;
            piVar16 = (int32_t *)(*pcVar22)(uVar12);
            in_RCX[0x16] = piVar16;
            if (piVar16 == (int32_t *)0x0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213dac;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213dc4;
                func_0x0001802295a0(0x1804bb408, 0xe7, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213dd6;
                func_0x0001802296d0(6, 0x86, 0);
                goto code_r0x00018021410e;
            }
        }
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213df0;
            iVar6 = func_0x000180211820(in_RCX, 0);
            if (iVar6 == 0) goto code_r0x00018021410e;
        }
        if (iVar17 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar11) = 0;
            *(undefined4 *)((int64_t)&arg_30h + iVar11) = 0;
            *(undefined8 *)((int64_t)&arg_38h + iVar11) = 0;
            *(undefined8 *)((int64_t)&arg_40h + iVar11) = 0;
            var_b0h = 0;
            var_a8h._0_4_ = 0;
            var_a0h = 0;
            var_98h = 0;
            var_90h = 0;
            var_88h = 0;
            var_80h._0_4_ = 0;
            var_78h = 0;
            var_70h = 0;
            var_68h = 0;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213e4d;
            puVar14 = (undefined4 *)func_0x00018022ae60(iVar17, 0x1804bb2f4);
            if (puVar14 != (undefined4 *)0x0) {
                uVar7 = puVar14[1];
                uVar2 = puVar14[2];
                uVar3 = puVar14[3];
                *(undefined4 *)((int64_t)&arg_28h + iVar11) = *puVar14;
                *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4) = uVar7;
                *(undefined4 *)((int64_t)&arg_30h + iVar11) = uVar2;
                *(undefined4 *)((int64_t)&arg_30h + iVar11 + 4) = uVar3;
                uVar7 = puVar14[5];
                uVar2 = puVar14[6];
                uVar3 = puVar14[7];
                *(undefined4 *)((int64_t)&arg_38h + iVar11) = puVar14[4];
                *(undefined4 *)((int64_t)&arg_38h + iVar11 + 4) = uVar7;
                *(undefined4 *)((int64_t)&arg_40h + iVar11) = uVar2;
                *(undefined4 *)((int64_t)&arg_40h + iVar11 + 4) = uVar3;
            }
            piVar20 = (int64_t *)((int64_t)&arg_28h + iVar11);
            if (puVar14 != (undefined4 *)0x0) {
                piVar20 = &var_b0h;
            }
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213e8c;
            puVar14 = (undefined4 *)func_0x00018022ae60(iVar17, 0x1804bb2ec);
            piVar18 = piVar20;
            if (puVar14 != (undefined4 *)0x0) {
                uVar7 = puVar14[1];
                uVar2 = puVar14[2];
                uVar3 = puVar14[3];
                piVar18 = piVar20 + 5;
                *(undefined4 *)piVar20 = *puVar14;
                *(undefined4 *)((int64_t)piVar20 + 4) = uVar7;
                *(undefined4 *)(piVar20 + 1) = uVar2;
                *(undefined4 *)((int64_t)piVar20 + 0xc) = uVar3;
                uVar7 = puVar14[5];
                uVar2 = puVar14[6];
                uVar3 = puVar14[7];
                *(undefined4 *)(piVar20 + 2) = puVar14[4];
                *(undefined4 *)((int64_t)piVar20 + 0x14) = uVar7;
                *(undefined4 *)(piVar20 + 3) = uVar2;
                *(undefined4 *)((int64_t)piVar20 + 0x1c) = uVar3;
                piVar20[4] = *(int64_t *)(puVar14 + 8);
            }
            if (piVar18 != (int64_t *)((int64_t)&arg_28h + iVar11)) {
                if ((*in_RCX == (int32_t *)0x0) || (pcVar22 = *(code **)(*in_RCX + 0x3c), pcVar22 == (code *)0x0)) {
code_r0x000180213f45:
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f4a;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f62;
                    func_0x0001802295a0(0x1804bb408, 0x112, 0x1804bb420);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f74;
                    func_0x0001802296d0(6, 0xdd, 0);
                    goto code_r0x00018021410e;
                }
                piVar16 = in_RCX[0x16];
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ee1;
                iVar6 = (*pcVar22)(piVar16, (int64_t)&arg_28h + iVar11);
                if (iVar6 < 1) {
                    if (iVar6 == 0) goto code_r0x000180213f45;
                } else {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ef6;
                    iVar15 = func_0x00018022ae60((int64_t)&arg_28h + iVar11, 0x1804bb2f4);
                    if (iVar15 != 0) {
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f07;
                        iVar6 = func_0x000180229fc0(iVar15, in_RCX + 0xd);
                        if (iVar6 == 0) {
                            *(undefined4 *)(in_RCX + 0xd) = 0xffffffff;
                            goto code_r0x000180213f45;
                        }
                    }
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f25;
                    iVar15 = func_0x00018022ae60((int64_t)&arg_28h + iVar11, 0x1804bb2ec);
                    if (iVar15 != 0) {
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213f36;
                        iVar6 = func_0x000180229fc0(iVar15, (int64_t)in_RCX + 0x6c);
                        if (iVar6 == 0) {
                            *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
                            goto code_r0x000180213f45;
                        }
                    }
                }
            }
        }
        if (cVar5 != '\0') goto code_r0x00018021410e;
        piVar16 = *in_RCX;
        if (*(int32_t *)((int64_t)&var_8h + iVar11) == 0) {
            if (*(int64_t *)(piVar16 + 0x24) != 0) {
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802140c6;
                    iVar10 = func_0x00018020e980(in_RCX);
                }
                iVar15 = *(int64_t *)((int64_t)&var_10h + iVar11);
                if (iVar15 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802140da;
                    iVar9 = func_0x00018020eae0(in_RCX);
                }
                pcVar22 = *(code **)(*in_RCX + 0x24);
                goto code_r0x0001802140e6;
            }
            if ((*(int64_t *)((int64_t)&var_10h + iVar11) != 0) || (*(int64_t *)(piVar16 + 0x46) == 0)) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180214087;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021409f;
                func_0x0001802295a0(0x1804bb408, 0x143, 0x1804bb420);
                *(code **)((int64_t)&pcStack_40 + iVar11) = case.default.0x180213965;
                func_0x0001802296d0(6, 0x86, 0);
                goto code_r0x00018021410e;
            }
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021405a;
                iVar9 = func_0x00018020e980(in_RCX);
            }
            pcVar22 = *(code **)(*in_RCX + 0x46);
        } else {
            if (*(int64_t *)(piVar16 + 0x22) != 0) {
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021400f;
                    iVar10 = func_0x00018020e980(in_RCX);
                }
                iVar15 = *(int64_t *)((int64_t)&var_10h + iVar11);
                if (iVar15 != 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180214023;
                    iVar9 = func_0x00018020eae0(in_RCX);
                }
                pcVar22 = *(code **)(*in_RCX + 0x22);
code_r0x0001802140e6:
                *(int64_t *)(&stack0xfffffffffffffff0 + iVar11) = iVar17;
                *(int64_t *)(&stack0xffffffffffffffe8 + iVar11) = (int64_t)iVar10;
                piVar16 = in_RCX[0x16];
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180214106;
                (*pcVar22)(piVar16, iVar15, (int64_t)iVar9, iVar4);
                goto code_r0x00018021410e;
            }
            if ((*(int64_t *)((int64_t)&var_10h + iVar11) != 0) || (*(int64_t *)(piVar16 + 0x44) == 0)) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213fcd;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213fe5;
                func_0x0001802295a0(0x1804bb408, 0x129, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213ff7;
                func_0x0001802296d0(6, 0x86, 0);
                goto code_r0x00018021410e;
            }
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213fb7;
                iVar9 = func_0x00018020e980(in_RCX);
            }
            pcVar22 = *(code **)(*in_RCX + 0x44);
        }
        piVar16 = in_RCX[0x16];
        *(int64_t *)(&stack0xffffffffffffffe8 + iVar11) = iVar17;
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021407d;
        (*pcVar22)(piVar16, 0, iVar4, (int64_t)iVar9);
        goto code_r0x00018021410e;
    }
    if ((in_RCX[1] == (int32_t *)0x0) || (*in_RCX == (int32_t *)0x0)) {
        if (in_RDX != (int32_t *)0x0) goto code_r0x0001802135db;
code_r0x0001802135f0:
        if (((in_RCX[1] == (int32_t *)0x0) && (piVar16 == (int32_t *)0x0)) && (in_R8 == (int32_t *)0x0)) {
            if (in_RDX == (int32_t *)0x0) {
                if ((*in_RCX == (int32_t *)0x0) || ((*in_RCX)[5] != 2)) goto code_r0x000180213ba0;
            } else if (in_RDX[5] != 2) {
                if (*in_RCX != (int32_t *)0x0) {
                    pcVar22 = *(code **)(*in_RCX + 10);
                    if (pcVar22 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213626;
                        iVar6 = (*pcVar22)(in_RCX);
                        if (iVar6 == 0) goto code_r0x00018021410e;
                    }
                    piVar16 = in_RCX[0xf];
                    iVar6 = (*in_RCX)[0xc];
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021364b;
                    func_0x000180224b90(piVar16, (int64_t)iVar6, 0x1804bb408, 0xa7);
                    in_RCX[0xf] = (int32_t *)0x0;
                }
                goto code_r0x000180213a95;
            }
        }
        piVar16 = in_RCX[0x17];
        if (*in_RCX == piVar16) {
            *in_RCX = (int32_t *)0x0;
        }
        if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
            LOCK();
            piVar1 = piVar16 + 0x1e;
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 < 2) {
                uVar12 = *(undefined8 *)(piVar16 + 0x18);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802136a8;
                fcn.180224990(uVar12, 0x1804bb408, 0x843);
                uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802136b1;
                fcn.18027edb0(uVar12);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802136c6;
                fcn.180224990(piVar16, 0x1804bb408, 0x846);
            }
        }
        in_RCX[0x17] = (int32_t *)0x0;
        if (in_RDX != (int32_t *)0x0) {
            piVar16 = *in_RCX;
            if (piVar16 != (int32_t *)0x0) {
                uVar7 = *(undefined4 *)(in_RCX + 0xe);
                if (*(int64_t *)(piVar16 + 0x1c) == 0) {
                    pcVar22 = *(code **)(piVar16 + 10);
                    if (pcVar22 == (code *)0x0) {
code_r0x00018021378c:
                        if ((in_RCX[0xf] != (int32_t *)0x0) && ((*in_RCX)[0xc] != 0)) {
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137a5;
                            func_0x000180244fc0();
                        }
                        piVar16 = in_RCX[0xf];
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137bb;
                        fcn.180224990(piVar16, 0x1804bb408, 0x3f);
                        piVar16 = in_RCX[1];
                        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137c4;
                        func_0x00018026aee0(piVar16);
                        goto code_r0x0001802137c4;
                    }
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213788;
                    iVar6 = (*pcVar22)(in_RCX);
                    if (iVar6 != 0) goto code_r0x00018021378c;
                } else {
                    if (in_RCX[0x16] != (int32_t *)0x0) {
                        pcVar22 = *(code **)(piVar16 + 0x34);
                        piVar16 = piVar21;
                        if (pcVar22 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213711;
                            (*pcVar22)();
                            piVar16 = in_RCX[0x17];
                        }
                        in_RCX[0x16] = (int32_t *)0x0;
                        if ((piVar16 != (int32_t *)0x0) && (piVar16[5] == 0)) {
                            LOCK();
                            piVar1 = piVar16 + 0x1e;
                            iVar6 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar6 < 2) {
                                uVar12 = *(undefined8 *)(piVar16 + 0x18);
                                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021375a;
                                fcn.180224990(uVar12, 0x1804bb408, 0x843);
                                uVar12 = *(undefined8 *)(piVar16 + 0x1c);
                                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213763;
                                fcn.18027edb0(uVar12);
                                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213778;
                                fcn.180224990(piVar16, 0x1804bb408, 0x846);
                            }
                        }
                    }
code_r0x0001802137c4:
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137d4;
                    func_0x0001804986e0(in_RCX, 0, 0xc0);
                    *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
                }
                *(undefined4 *)(in_RCX + 2) = *(undefined4 *)((int64_t)&var_8h + iVar11);
                *(undefined4 *)(in_RCX + 0xe) = uVar7;
            }
            if (in_R8 == (int32_t *)0x0) {
                in_R8 = *(int32_t **)((int64_t)&var_18h + iVar11);
                if (*(int32_t **)((int64_t)&var_18h + iVar11) != (int32_t *)0x0) goto code_r0x000180213837;
            } else {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137f3;
                iVar6 = func_0x00018026b010(in_R8);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802137fc;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213814;
                    func_0x0001802295a0(0x1804bb408, 0x163, 0x1804bb420);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213826;
                    func_0x0001802296d0(6, 0x86, 0);
                    goto code_r0x00018021410e;
                }
code_r0x000180213837:
                piVar21 = in_R8;
                iVar6 = *in_RDX;
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213842;
                in_RDX = (int32_t *)func_0x00018026ab80(piVar21, iVar6);
                if (in_RDX == (int32_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021384f;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213867;
                    func_0x0001802295a0(0x1804bb408, 0x173, 0x1804bb420);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213879;
                    func_0x0001802296d0(6, 0x86, 0);
                    goto code_r0x00018021410e;
                }
            }
            in_RCX[1] = piVar21;
            *in_RCX = in_RDX;
            iVar6 = in_RDX[0xc];
            if (iVar6 == 0) {
                in_RCX[0xf] = (int32_t *)0x0;
            } else {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802138a7;
                piVar16 = (int32_t *)func_0x000180224d60((int64_t)iVar6, 0x1804bb408, 0x184);
                in_RCX[0xf] = piVar16;
                if (piVar16 == (int32_t *)0x0) {
                    *in_RCX = (int32_t *)0x0;
                    goto code_r0x00018021410e;
                }
            }
            iVar6 = in_RDX[2];
            *(uint32_t *)(in_RCX + 0xe) = *(uint32_t *)(in_RCX + 0xe) & 1;
            *(int32_t *)(in_RCX + 0xd) = iVar6;
            if ((*(uint8_t *)(*in_RCX + 4) & 0x40) != 0) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802138e4;
                iVar6 = func_0x000180210b80(in_RCX, 0, 0, 0);
                if (iVar6 < 1) {
                    *in_RCX = (int32_t *)0x0;
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802138f4;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021390c;
                    func_0x0001802295a0(0x1804bb408, 0x192, 0x1804bb420);
                    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021391e;
                    func_0x0001802296d0(6, 0x86, 0);
                    goto code_r0x00018021410e;
                }
            }
        }
    } else if ((in_RDX != (int32_t *)0x0) && (*in_RDX != **in_RCX)) {
code_r0x0001802135db:
        piVar16 = piVar21;
        if (in_R8 == (int32_t *)0x0) {
            iVar6 = *in_RDX;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802135e8;
            piVar16 = (int32_t *)func_0x00018026abf0(iVar6);
            *(int32_t **)((int64_t)&var_18h + iVar11) = piVar16;
        }
        goto code_r0x0001802135f0;
    }
    if (*in_RCX == (int32_t *)0x0) goto code_r0x00018021410e;
    iVar6 = (*in_RCX)[1];
    if ((iVar6 != 1) && ((iVar6 - 8U & 0xfffffff7) != 0)) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021357b;
        func_0x00018027bb50(0x1804bb440, 0x1804bb408, 0x1a0);
    }
    if ((*(uint8_t *)(in_RCX + 0xe) & 1) == 0) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021358d;
        uVar12 = func_0x00018020e940(in_RCX);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213595;
        iVar6 = func_0x00018020efb0(uVar12);
        if (iVar6 == 0x10002) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802135a5;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802135bd;
            func_0x0001802295a0(0x1804bb408, 0x1a4, 0x1804bb420);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802135cf;
            func_0x0001802296d0(6, 0xaa, 0);
            goto code_r0x00018021410e;
        }
    }
    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021392d;
    uVar12 = func_0x00018020e940(in_RCX);
    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213935;
    uVar13 = func_0x00018020ef80(uVar12);
    if ((uVar13 & 0x10) == 0) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213941;
        uVar12 = func_0x00018020e940(in_RCX);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213949;
        uVar7 = func_0x00018020efb0(uVar12);
    // switch table (6 cases) at 0x180214130
        switch(uVar7) {
        case 0:
        case 1:
            break;
        case 2:
            goto code_r0x00018021396a;
        case 3:
        case 4:
            goto code_r0x000180213967;
        case 5:
            *(undefined4 *)(in_RCX + 0xb) = 0;
            if (iVar4 == 0) break;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a3c;
            iVar6 = func_0x00018020e980(in_RCX);
            iVar17 = (int64_t)iVar6;
            ppiVar19 = (int32_t **)iVar4;
            if (0xf < iVar6 - 1U) {
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a5b;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a73;
                func_0x0001802295a0(0x1804bb408, 0x1c7, 0x1804bb420);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a85;
                func_0x0001802296d0(6, 0xc2, 0);
                goto code_r0x00018021410e;
            }
            goto code_r0x000180213999;
        default:
            goto code_r0x00018021410e;
        }
    }
    goto code_r0x00018021399e;
code_r0x000180213967:
    *(undefined4 *)(in_RCX + 0xb) = 0;
code_r0x00018021396a:
    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213972;
    uVar8 = func_0x00018020e980(in_RCX);
    if (0x10 < uVar8) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802139f7;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a0f;
        func_0x0001802295a0(0x1804bb408, 0x1b9, 0x1804bb420);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x180213a21;
        func_0x0001802296d0(6, 0xc2, 0);
        goto code_r0x00018021410e;
    }
    iVar17 = (int64_t)(int32_t)uVar8;
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021398e;
        func_0x000180498030(in_RCX + 3, iVar4, iVar17);
    }
    ppiVar19 = in_RCX + 3;
code_r0x000180213999:
    *(code **)((int64_t)&pcStack_40 + iVar11) = case.0x180213965.0;
    func_0x000180498030(in_RCX + 5, ppiVar19, iVar17);
code_r0x00018021399e:
    if ((*(int64_t *)((int64_t)&var_10h + iVar11) != 0) || ((*(uint8_t *)(*in_RCX + 4) & 0x20) != 0)) {
        pcVar22 = *(code **)(*in_RCX + 6);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x1802139c9;
        iVar6 = (*pcVar22)(in_RCX, *(int64_t *)((int64_t)&var_10h + iVar11), iVar4, 
                           *(undefined4 *)((int64_t)&var_8h + iVar11));
        if (iVar6 == 0) goto code_r0x00018021410e;
    }
    *(undefined4 *)((int64_t)in_RCX + 0x14) = 0;
    *(undefined4 *)(in_RCX + 0x10) = 0;
    *(int32_t *)((int64_t)in_RCX + 0x84) = (*in_RCX)[1] + -1;
code_r0x00018021410e:
    *(undefined8 *)((int64_t)&pcStack_40 + iVar11) = 0x18021411a;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar11));
    return;
}

// ============================================================
// Function: FUN_180214150
// Address: 0x180214150
// Size: 53 bytes
// ============================================================
void fcn.180214150(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021415a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x180214174;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + -iVar1));
    if (iVar1 != 0) {
        *(undefined4 *)(iVar1 + 0x78) = 1;
    }
    return;
}

// ============================================================
// Function: FUN_1802141d0
// Address: 0x1802141d0
// Size: 76 bytes
// ============================================================
void fcn.1802141d0(undefined8 param_1, int32_t *param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802141dc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802141ec;
    iVar3 = fcn.180281b80(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
    if ((*param_2 != -1) && (iVar3 != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802141fe;
        iVar1 = fcn.18020efd0(iVar3);
        if ((*param_2 != 0) && (*param_2 != iVar1)) {
            *param_2 = -1;
            return;
        }
        *param_2 = iVar1;
    }
    return;
}

// ============================================================
// Function: FUN_180214220
// Address: 0x180214220
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4
fcn.180214220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_68h)
{
    uint32_t uVar1;
    uint32_t *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined4 uVar9;
    undefined8 unaff_RBP;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180214239;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021425f;
    iVar8 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_8 + iVar7));
    if (iVar8 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBP;
    uVar9 = 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021427f;
    func_0x00018020f6d0(iVar8, 1);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214294;
    iVar6 = func_0x000180216170(iVar8, *(undefined8 *)((int64_t)&arg_48h + iVar7), 0, 
                                *(undefined8 *)((int64_t)&arg_50h + iVar7));
    if (iVar6 != 0) {
        if (in_RDX == 0) {
code_r0x0001802143e0:
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143ee;
            iVar6 = func_0x0001802146d0(iVar8, in_R8, in_R9);
            if (iVar6 != 0) goto code_r0x0001802143f4;
        } else if ((*(uint32_t *)(iVar8 + 0x18) >> 0xb & 1) == 0) {
            puVar2 = *(uint32_t **)(iVar8 + 0x28);
            if (((puVar2 == (uint32_t *)0x0) || (uVar1 = *puVar2, (uVar1 & 0xc1f0) == 0)) ||
               (*(int64_t *)(puVar2 + 0xc) == 0)) {
                iVar3 = *(int64_t *)(iVar8 + 8);
                if (((iVar3 == 0) || (*(int64_t *)(iVar3 + 0x68) == 0)) || ((*(uint32_t *)(iVar8 + 0x18) >> 8 & 1) != 0)
                   ) {
                    pcVar4 = *(code **)(iVar8 + 0x30);
                    if (pcVar4 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143dc;
                        iVar6 = (*pcVar4)(iVar8, in_RCX, in_RDX);
                        goto code_r0x0001802143dc;
                    }
                } else {
                    pcVar4 = *(code **)(iVar3 + 0x88);
                    if (pcVar4 != (code *)0x0) {
                        uVar5 = *(undefined8 *)(iVar8 + 0x38);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143c6;
                        iVar6 = (*pcVar4)(uVar5, in_RCX, in_RDX);
                        goto code_r0x0001802143dc;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021438d;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143a5;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143b7;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                }
            } else {
                if (uVar1 == 0x80) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214312;
                    iVar6 = func_0x00018025c340(iVar8, in_RCX, in_RDX);
                } else {
                    if (uVar1 != 0x100) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214337;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7)
                                     );
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021434f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7)
                                      , *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214361;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                        goto code_r0x0001802143f2;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021432d;
                    iVar6 = func_0x00018025cc30(iVar8, in_RCX, in_RDX);
                }
code_r0x0001802143dc:
                if (iVar6 != 0) goto code_r0x0001802143e0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802142b3;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802142cb;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802142dd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
        }
    }
code_r0x0001802143f2:
    uVar9 = 0;
code_r0x0001802143f4:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143fe;
    func_0x000180215aa0(iVar8, 0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214413;
    fcn.180224990(iVar8, 0x1804bb7b8, 0x8c);
    return uVar9;
}

// ============================================================
// Function: FUN_18021426b
// Address: 0x18021426b
// Size: 431 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4
fcn.180214220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_68h)
{
    uint32_t uVar1;
    uint32_t *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined4 uVar9;
    undefined8 unaff_RBP;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180214239;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021425f;
    iVar8 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_8 + iVar7));
    if (iVar8 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBP;
    uVar9 = 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021427f;
    func_0x00018020f6d0(iVar8, 1);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214294;
    iVar6 = func_0x000180216170(iVar8, *(undefined8 *)((int64_t)&arg_48h + iVar7), 0, 
                                *(undefined8 *)((int64_t)&arg_50h + iVar7));
    if (iVar6 != 0) {
        if (in_RDX == 0) {
code_r0x0001802143e0:
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143ee;
            iVar6 = func_0x0001802146d0(iVar8, in_R8, in_R9);
            if (iVar6 != 0) goto code_r0x0001802143f4;
        } else if ((*(uint32_t *)(iVar8 + 0x18) >> 0xb & 1) == 0) {
            puVar2 = *(uint32_t **)(iVar8 + 0x28);
            if (((puVar2 == (uint32_t *)0x0) || (uVar1 = *puVar2, (uVar1 & 0xc1f0) == 0)) ||
               (*(int64_t *)(puVar2 + 0xc) == 0)) {
                iVar3 = *(int64_t *)(iVar8 + 8);
                if (((iVar3 == 0) || (*(int64_t *)(iVar3 + 0x68) == 0)) || ((*(uint32_t *)(iVar8 + 0x18) >> 8 & 1) != 0)
                   ) {
                    pcVar4 = *(code **)(iVar8 + 0x30);
                    if (pcVar4 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143dc;
                        iVar6 = (*pcVar4)(iVar8, in_RCX, in_RDX);
                        goto code_r0x0001802143dc;
                    }
                } else {
                    pcVar4 = *(code **)(iVar3 + 0x88);
                    if (pcVar4 != (code *)0x0) {
                        uVar5 = *(undefined8 *)(iVar8 + 0x38);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143c6;
                        iVar6 = (*pcVar4)(uVar5, in_RCX, in_RDX);
                        goto code_r0x0001802143dc;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021438d;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143a5;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143b7;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                }
            } else {
                if (uVar1 == 0x80) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214312;
                    iVar6 = func_0x00018025c340(iVar8, in_RCX, in_RDX);
                } else {
                    if (uVar1 != 0x100) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214337;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7)
                                     );
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021434f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7)
                                      , *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214361;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                        goto code_r0x0001802143f2;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021432d;
                    iVar6 = func_0x00018025cc30(iVar8, in_RCX, in_RDX);
                }
code_r0x0001802143dc:
                if (iVar6 != 0) goto code_r0x0001802143e0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802142b3;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802142cb;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802142dd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
        }
    }
code_r0x0001802143f2:
    uVar9 = 0;
code_r0x0001802143f4:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143fe;
    func_0x000180215aa0(iVar8, 0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214413;
    fcn.180224990(iVar8, 0x1804bb7b8, 0x8c);
    return uVar9;
}

// ============================================================
// Function: FUN_18021441a
// Address: 0x18021441a
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4
fcn.180214220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_68h)
{
    uint32_t uVar1;
    uint32_t *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined4 uVar9;
    undefined8 unaff_RBP;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180214239;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021425f;
    iVar8 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_8 + iVar7));
    if (iVar8 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBP;
    uVar9 = 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021427f;
    func_0x00018020f6d0(iVar8, 1);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214294;
    iVar6 = func_0x000180216170(iVar8, *(undefined8 *)((int64_t)&arg_48h + iVar7), 0, 
                                *(undefined8 *)((int64_t)&arg_50h + iVar7));
    if (iVar6 != 0) {
        if (in_RDX == 0) {
code_r0x0001802143e0:
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143ee;
            iVar6 = func_0x0001802146d0(iVar8, in_R8, in_R9);
            if (iVar6 != 0) goto code_r0x0001802143f4;
        } else if ((*(uint32_t *)(iVar8 + 0x18) >> 0xb & 1) == 0) {
            puVar2 = *(uint32_t **)(iVar8 + 0x28);
            if (((puVar2 == (uint32_t *)0x0) || (uVar1 = *puVar2, (uVar1 & 0xc1f0) == 0)) ||
               (*(int64_t *)(puVar2 + 0xc) == 0)) {
                iVar3 = *(int64_t *)(iVar8 + 8);
                if (((iVar3 == 0) || (*(int64_t *)(iVar3 + 0x68) == 0)) || ((*(uint32_t *)(iVar8 + 0x18) >> 8 & 1) != 0)
                   ) {
                    pcVar4 = *(code **)(iVar8 + 0x30);
                    if (pcVar4 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143dc;
                        iVar6 = (*pcVar4)(iVar8, in_RCX, in_RDX);
                        goto code_r0x0001802143dc;
                    }
                } else {
                    pcVar4 = *(code **)(iVar3 + 0x88);
                    if (pcVar4 != (code *)0x0) {
                        uVar5 = *(undefined8 *)(iVar8 + 0x38);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143c6;
                        iVar6 = (*pcVar4)(uVar5, in_RCX, in_RDX);
                        goto code_r0x0001802143dc;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021438d;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143a5;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143b7;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                }
            } else {
                if (uVar1 == 0x80) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214312;
                    iVar6 = func_0x00018025c340(iVar8, in_RCX, in_RDX);
                } else {
                    if (uVar1 != 0x100) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214337;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7)
                                     );
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021434f;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7)
                                      , *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214361;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                        goto code_r0x0001802143f2;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18021432d;
                    iVar6 = func_0x00018025cc30(iVar8, in_RCX, in_RDX);
                }
code_r0x0001802143dc:
                if (iVar6 != 0) goto code_r0x0001802143e0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802142b3;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802142cb;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802142dd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
        }
    }
code_r0x0001802143f2:
    uVar9 = 0;
code_r0x0001802143f4:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802143fe;
    func_0x000180215aa0(iVar8, 0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180214413;
    fcn.180224990(iVar8, 0x1804bb7b8, 0x8c);
    return uVar9;
}

// ============================================================
// Function: FUN_180214430
// Address: 0x180214430
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.180214430(int64_t arg_28h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180214440;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021444b;
    uVar1 = fcn.1802146d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180214457;
    fcn.180215aa0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
    return uVar1;
}

// ============================================================
// Function: FUN_180214470
// Address: 0x180214470
// Size: 598 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4
fcn.180214470(int64_t placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_48h, int64_t arg_58h,
             int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h, int64_t arg_98h, int64_t arg_b8h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined4 uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021448a;
    var_18h = arg3;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    iVar1 = *(int64_t *)(placeholder_0 + 8);
    uVar8 = 0;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802144a3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802144bb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                      *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                      *(int64_t *)((int64_t)&arg_48h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802144cd;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar9));
        uVar8 = 0;
    } else if (*(int64_t *)(iVar1 + 0x68) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802144e6;
        iVar7 = func_0x00018020fa50(iVar1);
        if ((iVar7 != 0) && (*(uint64_t *)((int64_t)&arg_b8h + iVar9) < 0x80000000)) {
            pcVar2 = *(code **)(*(int64_t *)(placeholder_0 + 8) + 0x48);
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180214511;
            iVar7 = (*pcVar2)(placeholder_0, 3, *(uint64_t *)((int64_t)&arg_b8h + iVar9), 0);
            if (iVar7 != 0) {
                pcVar2 = *(code **)(*(int64_t *)(placeholder_0 + 8) + 0x28);
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180214526;
                uVar8 = (*pcVar2)(placeholder_0, placeholder_1);
                pcVar2 = *(code **)(*(int64_t *)(placeholder_0 + 8) + 0x38);
                if (pcVar2 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x18021453a;
                    (*pcVar2)(placeholder_0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180214547;
                    func_0x00018020f6d0(placeholder_0, 2);
                }
                iVar7 = *(int32_t *)(*(int64_t *)(placeholder_0 + 8) + 0x44);
                uVar3 = *(undefined8 *)(placeholder_0 + 0x20);
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180214558;
                func_0x000180244fc0(uVar3, (int64_t)iVar7);
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180214562;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x18021457a;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                      *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                      *(int64_t *)((int64_t)&arg_48h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x18021458c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar9));
    } else if (*(int64_t *)(iVar1 + 0x90) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x18021459f;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802145b7;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                      *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                      *(int64_t *)((int64_t)&arg_48h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802145c9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar9));
        uVar8 = 0;
    } else if ((*(uint32_t *)(placeholder_0 + 0x18) & 0x800) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180214628;
        puVar10 = (undefined4 *)
                  func_0x000180229cc0((int64_t)&iStackX_20 + iVar9 + -8, 0x1804bb88c, (int64_t)&arg_b8h + iVar9);
        uVar4 = puVar10[1];
        uVar5 = puVar10[2];
        uVar6 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000050 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00000054 + iVar9) = uVar6;
        uVar4 = puVar10[5];
        uVar5 = puVar10[6];
        uVar6 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000060 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x00000064 + iVar9) = uVar6;
        *(undefined8 *)((int64_t)&arg_68h + iVar9) = *(undefined8 *)(puVar10 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x18021464e;
        puVar10 = (undefined4 *)func_0x000180229ba0((int64_t)&iStackX_20 + iVar9 + -8);
        uVar4 = puVar10[1];
        uVar5 = puVar10[2];
        uVar6 = puVar10[3];
        *(undefined4 *)((int64_t)&arg_70h + iVar9) = *puVar10;
        *(undefined4 *)((int64_t)&arg_70h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000078 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x0000007c + iVar9) = uVar6;
        uVar4 = puVar10[5];
        uVar5 = puVar10[6];
        uVar6 = puVar10[7];
        *(undefined4 *)((int64_t)&arg_80h + iVar9) = puVar10[4];
        *(undefined4 *)((int64_t)&arg_80h + iVar9 + 4) = uVar4;
        *(undefined4 *)(&stack0x00000088 + iVar9) = uVar5;
        *(undefined4 *)(&stack0x0000008c + iVar9) = uVar6;
        *(undefined8 *)((int64_t)&arg_90h + iVar9) = *(undefined8 *)(puVar10 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x18021467d;
        iVar7 = func_0x0001802154c0(placeholder_0, (int64_t)&arg_48h + iVar9);
        if (-1 < iVar7) {
            uVar3 = *(undefined8 *)(placeholder_0 + 0x38);
            pcVar2 = *(code **)(*(int64_t *)(placeholder_0 + 8) + 0x90);
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802146a6;
            uVar8 = (*pcVar2)(uVar3, placeholder_1, (int64_t)&arg_b8h + iVar9, 
                              *(undefined8 *)((int64_t)&arg_b8h + iVar9));
        }
        *(uint32_t *)(placeholder_0 + 0x18) = *(uint32_t *)(placeholder_0 + 0x18) | 0x800;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802145de;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802145f6;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                      *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                      *(int64_t *)((int64_t)&arg_48h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180214608;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar9));
        uVar8 = 0;
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1802146d0
// Address: 0x1802146d0
// Size: 360 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1802146d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint32_t *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802146ea;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar4 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = 0;
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021470f;
        uVar5 = func_0x00018020f590();
        if (-1 < (int32_t)uVar5) {
            if (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x68) == 0) {
                if (0x40 < uVar5) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180214743;
                    func_0x00018027bb50(0x1804bb848, 0x1804bb7b8, 0x1e5);
                }
                pcVar2 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x28);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180214754;
                uVar6 = (*pcVar2)(in_RCX, in_RDX);
                if (in_R8 != (uint32_t *)0x0) {
                    *in_R8 = uVar5;
                }
                pcVar2 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x38);
                if (pcVar2 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021476f;
                    (*pcVar2)(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021477c;
                    func_0x00018020f6d0(in_RCX, 2);
                }
                uVar3 = *(undefined8 *)(in_RCX + 0x20);
                iVar1 = *(int32_t *)(*(int64_t *)(in_RCX + 8) + 0x44);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021478d;
                func_0x000180244fc0(uVar3, (int64_t)iVar1);
                return (uint64_t)uVar6;
            }
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x90);
            if (pcVar2 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802147a5;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            } else if ((*(uint32_t *)(in_RCX + 0x18) & 0x800) == 0) {
                uVar3 = *(undefined8 *)(in_RCX + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802147d3;
                uVar8 = (*pcVar2)(uVar3, in_RDX, (int64_t)&arg_28h + iVar7, (int64_t)(int32_t)uVar5);
                *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 0x800;
                if (in_R8 == (uint32_t *)0x0) {
                    return uVar8;
                }
                if (*(uint64_t *)((int64_t)&arg_28h + iVar7) < 0x100000000) {
                    *in_R8 = (uint32_t)*(uint64_t *)((int64_t)&arg_28h + iVar7);
                    return uVar8;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802147f7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802147ba;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18021480f;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180214821;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180214840
// Address: 0x180214840
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180214840(int64_t arg_28h, int64_t arg_38h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint32_t uVar1;
    uint32_t *puVar2;
    int32_t *piVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int32_t *piVar9;
    int32_t **in_RCX;
    int32_t *in_RDX;
    int32_t **ppiVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    undefined8 uVar12;
    int32_t *piVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 uStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180214850;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180214860;
    fcn.180215aa0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000050 + iVar6));
    piVar13 = (int32_t *)0x0;
    uVar12 = 0;
    uVar8 = *(undefined8 *)((int64_t)&arg_28h + iVar6);
    uVar11 = *(undefined8 *)((int64_t)&var_18h + iVar6);
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar6) = uVar11;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar6 + -8) = unaff_R12;
    *(undefined8 *)(&stack0x00000000 + iVar6) = unaff_R13;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180216187;
    iVar7 = fcn.18045a350(in_RCX, in_RDX, 0);
    iVar7 = -iVar7;
    piVar9 = (int32_t *)0x0;
    puVar2 = (uint32_t *)in_RCX[5];
    if (((puVar2 != (uint32_t *)0x0) && (uVar1 = *puVar2, (uVar1 & 0xc1f0) != 0)) && (*(int64_t *)(puVar2 + 0xc) != 0))
    {
        if (uVar1 == 0x80) {
            *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802161d1;
            uVar8 = func_0x00018025c290(in_RCX, 0, in_RDX);
            return uVar8;
        }
        if (uVar1 == 0x100) {
            *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802161ef;
            uVar8 = func_0x00018025cb80(in_RCX, 0, in_RDX);
            return uVar8;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802161f9;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216211;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216223;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216237;
    func_0x00018020f580(in_RCX, 0x802);
    if (in_RDX == (int32_t *)0x0) {
        in_RDX = in_RCX[1];
        if (in_RDX == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216397;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802163af;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000048 + iVar7 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802163c1;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
            return 0;
        }
    } else {
        *in_RCX = in_RDX;
    }
    piVar3 = in_RCX[2];
    *(undefined8 *)((int64_t)&arg_68h + iVar7 + iVar6) = uVar8;
    *(undefined8 *)((int64_t)&arg_70h + iVar7 + iVar6) = unaff_R15;
    if (((piVar3 == (int32_t *)0x0) || (in_RCX[1] == (int32_t *)0x0)) || (*in_RDX != *in_RCX[1])) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216274;
        func_0x00018026aee0();
        in_RCX[2] = (int32_t *)0x0;
        if (piVar13 == (int32_t *)0x0) {
            iVar5 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216288;
            piVar9 = (int32_t *)func_0x00018026ada0(iVar5);
            if (((in_RCX[2] != (int32_t *)0x0) || (piVar9 != (int32_t *)0x0)) ||
               (((*(uint32_t *)(in_RCX + 3) & 0x100) != 0 || (in_RDX[4] == 2)))) goto code_r0x000180216528;
            if (in_RCX[1] != (int32_t *)0x0) {
                if (*(int64_t *)(in_RCX[1] + 0xe) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802162d1;
                    iVar5 = func_0x00018020f740(in_RCX, 2);
                    if (iVar5 == 0) {
                        pcVar4 = *(code **)(in_RCX[1] + 0xe);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802162e2;
                        (*pcVar4)(in_RCX);
                    }
                }
                if ((in_RCX[4] != (int32_t *)0x0) && (0 < in_RCX[1][0x11])) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802162ff;
                    func_0x00018020f740(in_RCX, 4);
                    piVar9 = in_RCX[4];
                    iVar5 = in_RCX[1][0x11];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021631d;
                    func_0x000180224b90(piVar9, (int64_t)iVar5, 0x1804bb7b8, 0x26);
                    in_RCX[4] = (int32_t *)0x0;
                }
            }
            if (in_RCX[1] == in_RDX) {
                if (*(int64_t *)(in_RDX + 0x1a) == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021633a;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                } else {
code_r0x000180216475:
                    if ((*(int64_t *)(in_RDX + 0x1a) != 0) && (in_RCX[8] != in_RDX)) {
                        if (in_RDX[4] == 0) {
                            LOCK();
                            in_RDX[0x1c] = in_RDX[0x1c] + 1;
                            UNLOCK();
                        }
                        piVar9 = in_RCX[8];
                        if ((piVar9 != (int32_t *)0x0) && (piVar9[4] == 0)) {
                            LOCK();
                            piVar9 = piVar9 + 0x1c;
                            iVar5 = *piVar9;
                            *piVar9 = *piVar9 + -1;
                            UNLOCK();
                            if (iVar5 < 2) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802164b3;
                                func_0x000180210740();
                            }
                        }
                        in_RCX[8] = in_RDX;
                    }
                    piVar9 = in_RCX[7];
                    in_RCX[1] = in_RDX;
                    if (piVar9 == (int32_t *)0x0) {
                        uVar8 = *(undefined8 *)(in_RDX + 0x1a);
                        pcVar4 = *(code **)(in_RDX + 0x1e);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802164d0;
                        uVar8 = func_0x00018027e810(uVar8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802164d5;
                        piVar9 = (int32_t *)(*pcVar4)(uVar8);
                        in_RCX[7] = piVar9;
                        if (piVar9 == (int32_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802164e6;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                    }
                    pcVar4 = *(code **)(in_RCX[1] + 0x20);
                    if (pcVar4 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216523;
                        uVar8 = (*pcVar4)(piVar9, uVar12);
                        return uVar8;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021650c;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                }
code_r0x000180216346:
                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216352;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216364;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802163cd;
                iVar5 = func_0x000180215910(in_RCX);
                if (iVar5 != 0) {
                    if (*(int64_t *)(in_RDX + 0x1a) == 0) {
                        if (*in_RDX == 0) {
                            uVar8 = 0x180645710;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802163e6;
                            uVar8 = func_0x00018022ccf0();
                        }
                        *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar6) = 0x180215c10;
                        *(undefined8 *)((int64_t)&var_20h + iVar7 + iVar6) = 0x180215670;
                        *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0x180215c50;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216429;
                        in_RDX = (int32_t *)func_0x000180280c20(0, 1, uVar8, 0x1805aadb1);
                        if (in_RDX == (int32_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216436;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                        piVar9 = in_RCX[8];
                        if ((piVar9 != (int32_t *)0x0) && (piVar9[4] == 0)) {
                            LOCK();
                            piVar9 = piVar9 + 0x1c;
                            iVar5 = *piVar9;
                            *piVar9 = *piVar9 + -1;
                            UNLOCK();
                            if (iVar5 < 2) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021646c;
                                func_0x000180210740();
                            }
                        }
                        in_RCX[8] = in_RDX;
                    }
                    goto code_r0x000180216475;
                }
            }
        } else {
code_r0x000180216528:
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216530;
            iVar5 = func_0x000180215910(in_RCX);
            if (iVar5 != 0) {
                piVar3 = in_RCX[8];
                if (in_RCX[1] == piVar3) {
                    in_RCX[1] = (int32_t *)0x0;
                }
                if ((piVar3 != (int32_t *)0x0) && (piVar3[4] == 0)) {
                    LOCK();
                    piVar3 = piVar3 + 0x1c;
                    iVar5 = *piVar3;
                    *piVar3 = *piVar3 + -1;
                    UNLOCK();
                    if (iVar5 < 2) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021656f;
                        func_0x000180210740();
                    }
                }
                in_RCX[8] = (int32_t *)0x0;
                if (in_RDX != (int32_t *)0x0) {
                    if (piVar13 == (int32_t *)0x0) {
                        if (piVar9 == (int32_t *)0x0) {
                            in_RCX[2] = (int32_t *)0x0;
                            goto code_r0x00018021660b;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021658d;
                        iVar5 = func_0x00018026b010(piVar13);
                        piVar9 = piVar13;
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216596;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                    }
                    iVar5 = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165b9;
                    in_RDX = (int32_t *)func_0x00018026ad30(piVar9, iVar5);
                    if (in_RDX == (int32_t *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165c6;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165de;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165f0;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165f8;
                        func_0x00018026aee0(piVar9);
                        goto code_r0x000180216364;
                    }
                    in_RCX[2] = piVar9;
                }
code_r0x00018021660b:
                ppiVar10 = in_RCX + 1;
                piVar9 = *ppiVar10;
                if (piVar9 != in_RDX) {
                    if (piVar9 != (int32_t *)0x0) {
                        if (*(int64_t *)(piVar9 + 0xe) != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216632;
                            iVar5 = func_0x00018020f740(in_RCX, 2);
                            if (iVar5 == 0) {
                                pcVar4 = *(code **)(*ppiVar10 + 0xe);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216642;
                                (*pcVar4)(in_RCX);
                            }
                        }
                        if ((in_RCX[4] != (int32_t *)0x0) && (0 < (*ppiVar10)[0x11])) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216662;
                            func_0x00018020f740(in_RCX, 4);
                            piVar9 = in_RCX[4];
                            iVar5 = in_RCX[1][0x11];
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021667f;
                            func_0x000180224b90(piVar9, (int64_t)iVar5, 0x1804bb7b8, 0x26);
                            in_RCX[4] = (int32_t *)0x0;
                        }
                    }
                    in_RCX[1] = in_RDX;
                    if (((*(uint32_t *)(in_RCX + 3) & 0x100) == 0) && (in_RDX[0x11] != 0)) {
                        in_RCX[6] = *(int32_t **)(in_RDX + 8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802166b3;
                        piVar9 = (int32_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6));
                        in_RCX[4] = piVar9;
                        if (piVar9 == (int32_t *)0x0) goto code_r0x000180216364;
                    }
                }
                goto code_r0x0001802166c0;
            }
        }
code_r0x000180216364:
        uVar8 = 0;
    } else {
code_r0x0001802166c0:
        puVar2 = (uint32_t *)in_RCX[5];
        if ((puVar2 != (uint32_t *)0x0) && (((*puVar2 & 0xc1f0) == 0 || (*(int64_t *)(puVar2 + 10) == 0)))) {
            *(int32_t ***)((int64_t)&var_20h + iVar7 + iVar6) = in_RCX;
            *(undefined4 *)((int64_t)&var_18h + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802166f5;
            iVar5 = func_0x000180258740(puVar2, 0xffffffff, 0xc1f0, 7);
            if ((iVar5 < 1) && (iVar5 != -2)) goto code_r0x000180216364;
        }
        if ((*(uint32_t *)(in_RCX + 3) & 0x100) == 0) {
            pcVar4 = *(code **)(in_RCX[1] + 6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216722;
            uVar8 = (*pcVar4)(in_RCX);
        } else {
            uVar8 = 1;
        }
    }
    return uVar8;
}

// ============================================================
// Function: FUN_180214880
// Address: 0x180214880
// Size: 28 bytes
// ============================================================
undefined8 fcn.180214880(int32_t **param_1, int32_t *param_2, int32_t *param_3)
{
    uint32_t uVar1;
    uint32_t *puVar2;
    int32_t *piVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int32_t *piVar9;
    undefined8 uVar10;
    undefined8 unaff_RBX;
    int32_t **ppiVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021488a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = 0;
    *(undefined8 *)(&stack0x00000040 + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000018 + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_R12;
    *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_R13;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x180216187;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar9 = (int32_t *)0x0;
    puVar2 = (uint32_t *)param_1[5];
    if (((puVar2 != (uint32_t *)0x0) && (uVar1 = *puVar2, (uVar1 & 0xc1f0) != 0)) && (*(int64_t *)(puVar2 + 0xc) != 0))
    {
        if (uVar1 == 0x80) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802161d1;
            uVar8 = func_0x00018025c290(param_1, 0, param_2);
            return uVar8;
        }
        if (uVar1 == 0x100) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802161ef;
            uVar8 = func_0x00018025cb80(param_1, 0, param_2);
            return uVar8;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802161f9;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), *(int64_t *)(&stack0x00000028 + iVar7 + iVar6)
                     );
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216211;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), *(int64_t *)(&stack0x00000028 + iVar7 + iVar6)
                      , *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000038 + iVar7 + iVar6), 
                      *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216223;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar7 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216237;
    func_0x00018020f580(param_1, 0x802);
    if (param_2 == (int32_t *)0x0) {
        param_2 = param_1[1];
        if (param_2 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216397;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802163af;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000028 + iVar7 + iVar6), *(int64_t *)(&stack0x00000030 + iVar7 + iVar6)
                          , *(int64_t *)(&stack0x00000038 + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802163c1;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar7 + iVar6));
            return 0;
        }
    } else {
        *param_1 = param_2;
    }
    piVar3 = param_1[2];
    *(undefined8 *)(&stack0x00000070 + iVar7 + iVar6) = unaff_RBX;
    *(undefined8 *)(&stack0x00000078 + iVar7 + iVar6) = unaff_R15;
    if (((piVar3 == (int32_t *)0x0) || (param_1[1] == (int32_t *)0x0)) || (*param_2 != *param_1[1])) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216274;
        func_0x00018026aee0();
        param_1[2] = (int32_t *)0x0;
        if (param_3 == (int32_t *)0x0) {
            iVar5 = *param_2;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216288;
            piVar9 = (int32_t *)func_0x00018026ada0(iVar5);
            if (((param_1[2] != (int32_t *)0x0) || (piVar9 != (int32_t *)0x0)) ||
               (((*(uint32_t *)(param_1 + 3) & 0x100) != 0 || (param_2[4] == 2)))) goto code_r0x000180216528;
            if (param_1[1] != (int32_t *)0x0) {
                if (*(int64_t *)(param_1[1] + 0xe) != 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802162d1;
                    iVar5 = func_0x00018020f740(param_1, 2);
                    if (iVar5 == 0) {
                        pcVar4 = *(code **)(param_1[1] + 0xe);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802162e2;
                        (*pcVar4)(param_1);
                    }
                }
                if ((param_1[4] != (int32_t *)0x0) && (0 < param_1[1][0x11])) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802162ff;
                    func_0x00018020f740(param_1, 4);
                    piVar9 = param_1[4];
                    iVar5 = param_1[1][0x11];
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021631d;
                    func_0x000180224b90(piVar9, (int64_t)iVar5, 0x1804bb7b8, 0x26);
                    param_1[4] = (int32_t *)0x0;
                }
            }
            if (param_1[1] == param_2) {
                if (*(int64_t *)(param_2 + 0x1a) == 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021633a;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
                } else {
code_r0x000180216475:
                    if ((*(int64_t *)(param_2 + 0x1a) != 0) && (param_1[8] != param_2)) {
                        if (param_2[4] == 0) {
                            LOCK();
                            param_2[0x1c] = param_2[0x1c] + 1;
                            UNLOCK();
                        }
                        piVar9 = param_1[8];
                        if ((piVar9 != (int32_t *)0x0) && (piVar9[4] == 0)) {
                            LOCK();
                            piVar9 = piVar9 + 0x1c;
                            iVar5 = *piVar9;
                            *piVar9 = *piVar9 + -1;
                            UNLOCK();
                            if (iVar5 < 2) {
                                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802164b3;
                                func_0x000180210740();
                            }
                        }
                        param_1[8] = param_2;
                    }
                    piVar9 = param_1[7];
                    param_1[1] = param_2;
                    if (piVar9 == (int32_t *)0x0) {
                        uVar10 = *(undefined8 *)(param_2 + 0x1a);
                        pcVar4 = *(code **)(param_2 + 0x1e);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802164d0;
                        uVar10 = func_0x00018027e810(uVar10);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802164d5;
                        piVar9 = (int32_t *)(*pcVar4)(uVar10);
                        param_1[7] = piVar9;
                        if (piVar9 == (int32_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802164e6;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                    }
                    pcVar4 = *(code **)(param_1[1] + 0x20);
                    if (pcVar4 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216523;
                        uVar8 = (*pcVar4)(piVar9, uVar8);
                        return uVar8;
                    }
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021650c;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
                }
code_r0x000180216346:
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216352;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000028 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000038 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216364;
                fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar7 + iVar6));
            } else {
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802163cd;
                iVar5 = func_0x000180215910(param_1);
                if (iVar5 != 0) {
                    if (*(int64_t *)(param_2 + 0x1a) == 0) {
                        if (*param_2 == 0) {
                            uVar10 = 0x180645710;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802163e6;
                            uVar10 = func_0x00018022ccf0();
                        }
                        *(undefined8 *)(&stack0x00000030 + iVar7 + iVar6) = 0x180215c10;
                        *(undefined8 *)(&stack0x00000028 + iVar7 + iVar6) = 0x180215670;
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + iVar6) = 0x180215c50;
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216429;
                        param_2 = (int32_t *)func_0x000180280c20(0, 1, uVar10, 0x1805aadb1);
                        if (param_2 == (int32_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216436;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                        piVar9 = param_1[8];
                        if ((piVar9 != (int32_t *)0x0) && (piVar9[4] == 0)) {
                            LOCK();
                            piVar9 = piVar9 + 0x1c;
                            iVar5 = *piVar9;
                            *piVar9 = *piVar9 + -1;
                            UNLOCK();
                            if (iVar5 < 2) {
                                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021646c;
                                func_0x000180210740();
                            }
                        }
                        param_1[8] = param_2;
                    }
                    goto code_r0x000180216475;
                }
            }
        } else {
code_r0x000180216528:
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216530;
            iVar5 = func_0x000180215910(param_1);
            if (iVar5 != 0) {
                piVar3 = param_1[8];
                if (param_1[1] == piVar3) {
                    param_1[1] = (int32_t *)0x0;
                }
                if ((piVar3 != (int32_t *)0x0) && (piVar3[4] == 0)) {
                    LOCK();
                    piVar3 = piVar3 + 0x1c;
                    iVar5 = *piVar3;
                    *piVar3 = *piVar3 + -1;
                    UNLOCK();
                    if (iVar5 < 2) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021656f;
                        func_0x000180210740();
                    }
                }
                param_1[8] = (int32_t *)0x0;
                if (param_2 != (int32_t *)0x0) {
                    if (param_3 == (int32_t *)0x0) {
                        if (piVar9 == (int32_t *)0x0) {
                            param_1[2] = (int32_t *)0x0;
                            goto code_r0x00018021660b;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021658d;
                        iVar5 = func_0x00018026b010(param_3);
                        piVar9 = param_3;
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216596;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                    }
                    iVar5 = *param_2;
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802165b9;
                    param_2 = (int32_t *)func_0x00018026ad30(piVar9, iVar5);
                    if (param_2 == (int32_t *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802165c6;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802165de;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000028 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802165f0;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802165f8;
                        func_0x00018026aee0(piVar9);
                        goto code_r0x000180216364;
                    }
                    param_1[2] = piVar9;
                }
code_r0x00018021660b:
                ppiVar11 = param_1 + 1;
                piVar9 = *ppiVar11;
                if (piVar9 != param_2) {
                    if (piVar9 != (int32_t *)0x0) {
                        if (*(int64_t *)(piVar9 + 0xe) != 0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216632;
                            iVar5 = func_0x00018020f740(param_1, 2);
                            if (iVar5 == 0) {
                                pcVar4 = *(code **)(*ppiVar11 + 0xe);
                                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216642;
                                (*pcVar4)(param_1);
                            }
                        }
                        if ((param_1[4] != (int32_t *)0x0) && (0 < (*ppiVar11)[0x11])) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216662;
                            func_0x00018020f740(param_1, 4);
                            piVar9 = param_1[4];
                            iVar5 = param_1[1][0x11];
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021667f;
                            func_0x000180224b90(piVar9, (int64_t)iVar5, 0x1804bb7b8, 0x26);
                            param_1[4] = (int32_t *)0x0;
                        }
                    }
                    param_1[1] = param_2;
                    if (((*(uint32_t *)(param_1 + 3) & 0x100) == 0) && (param_2[0x11] != 0)) {
                        param_1[6] = *(int32_t **)(param_2 + 8);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802166b3;
                        piVar9 = (int32_t *)fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6));
                        param_1[4] = piVar9;
                        if (piVar9 == (int32_t *)0x0) goto code_r0x000180216364;
                    }
                }
                goto code_r0x0001802166c0;
            }
        }
code_r0x000180216364:
        uVar8 = 0;
    } else {
code_r0x0001802166c0:
        puVar2 = (uint32_t *)param_1[5];
        if ((puVar2 != (uint32_t *)0x0) && (((*puVar2 & 0xc1f0) == 0 || (*(int64_t *)(puVar2 + 10) == 0)))) {
            *(int32_t ***)(&stack0x00000028 + iVar7 + iVar6) = param_1;
            *(undefined4 *)((int64_t)&iStackX_20 + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802166f5;
            iVar5 = func_0x000180258740(puVar2, 0xffffffff, 0xc1f0, 7);
            if ((iVar5 < 1) && (iVar5 != -2)) goto code_r0x000180216364;
        }
        if ((*(uint32_t *)(param_1 + 3) & 0x100) == 0) {
            pcVar4 = *(code **)(param_1[1] + 6);
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216722;
            uVar8 = (*pcVar4)(param_1);
        } else {
            uVar8 = 1;
        }
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1802148a0
// Address: 0x1802148a0
// Size: 25 bytes
// ============================================================
undefined8 fcn.1802148a0(int32_t **param_1, int32_t *param_2, undefined8 param_3)
{
    uint32_t uVar1;
    uint32_t *puVar2;
    int32_t *piVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int32_t *piVar9;
    undefined8 unaff_RBX;
    int32_t **ppiVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t *piVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802148aa;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    piVar11 = (int32_t *)0x0;
    *(undefined8 *)(&stack0x00000040 + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000018 + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_R12;
    *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_R13;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x180216187;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar9 = (int32_t *)0x0;
    puVar2 = (uint32_t *)param_1[5];
    if (((puVar2 != (uint32_t *)0x0) && (uVar1 = *puVar2, (uVar1 & 0xc1f0) != 0)) && (*(int64_t *)(puVar2 + 0xc) != 0))
    {
        if (uVar1 == 0x80) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802161d1;
            uVar8 = func_0x00018025c290(param_1, 0, param_2);
            return uVar8;
        }
        if (uVar1 == 0x100) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802161ef;
            uVar8 = func_0x00018025cb80(param_1, 0, param_2);
            return uVar8;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802161f9;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), *(int64_t *)(&stack0x00000028 + iVar7 + iVar6)
                     );
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216211;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), *(int64_t *)(&stack0x00000028 + iVar7 + iVar6)
                      , *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000038 + iVar7 + iVar6), 
                      *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216223;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar7 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216237;
    func_0x00018020f580(param_1, 0x802);
    if (param_2 == (int32_t *)0x0) {
        param_2 = param_1[1];
        if (param_2 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216397;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802163af;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000028 + iVar7 + iVar6), *(int64_t *)(&stack0x00000030 + iVar7 + iVar6)
                          , *(int64_t *)(&stack0x00000038 + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802163c1;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar7 + iVar6));
            return 0;
        }
    } else {
        *param_1 = param_2;
    }
    piVar3 = param_1[2];
    *(undefined8 *)(&stack0x00000070 + iVar7 + iVar6) = unaff_RBX;
    *(undefined8 *)(&stack0x00000078 + iVar7 + iVar6) = unaff_R15;
    if (((piVar3 == (int32_t *)0x0) || (param_1[1] == (int32_t *)0x0)) || (*param_2 != *param_1[1])) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216274;
        func_0x00018026aee0();
        param_1[2] = (int32_t *)0x0;
        if (piVar11 == (int32_t *)0x0) {
            iVar5 = *param_2;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216288;
            piVar9 = (int32_t *)func_0x00018026ada0(iVar5);
            if (((param_1[2] != (int32_t *)0x0) || (piVar9 != (int32_t *)0x0)) ||
               (((*(uint32_t *)(param_1 + 3) & 0x100) != 0 || (param_2[4] == 2)))) goto code_r0x000180216528;
            if (param_1[1] != (int32_t *)0x0) {
                if (*(int64_t *)(param_1[1] + 0xe) != 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802162d1;
                    iVar5 = func_0x00018020f740(param_1, 2);
                    if (iVar5 == 0) {
                        pcVar4 = *(code **)(param_1[1] + 0xe);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802162e2;
                        (*pcVar4)(param_1);
                    }
                }
                if ((param_1[4] != (int32_t *)0x0) && (0 < param_1[1][0x11])) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802162ff;
                    func_0x00018020f740(param_1, 4);
                    piVar9 = param_1[4];
                    iVar5 = param_1[1][0x11];
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021631d;
                    func_0x000180224b90(piVar9, (int64_t)iVar5, 0x1804bb7b8, 0x26);
                    param_1[4] = (int32_t *)0x0;
                }
            }
            if (param_1[1] == param_2) {
                if (*(int64_t *)(param_2 + 0x1a) == 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021633a;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
                } else {
code_r0x000180216475:
                    if ((*(int64_t *)(param_2 + 0x1a) != 0) && (param_1[8] != param_2)) {
                        if (param_2[4] == 0) {
                            LOCK();
                            param_2[0x1c] = param_2[0x1c] + 1;
                            UNLOCK();
                        }
                        piVar9 = param_1[8];
                        if ((piVar9 != (int32_t *)0x0) && (piVar9[4] == 0)) {
                            LOCK();
                            piVar9 = piVar9 + 0x1c;
                            iVar5 = *piVar9;
                            *piVar9 = *piVar9 + -1;
                            UNLOCK();
                            if (iVar5 < 2) {
                                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802164b3;
                                func_0x000180210740();
                            }
                        }
                        param_1[8] = param_2;
                    }
                    piVar9 = param_1[7];
                    param_1[1] = param_2;
                    if (piVar9 == (int32_t *)0x0) {
                        uVar8 = *(undefined8 *)(param_2 + 0x1a);
                        pcVar4 = *(code **)(param_2 + 0x1e);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802164d0;
                        uVar8 = func_0x00018027e810(uVar8);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802164d5;
                        piVar9 = (int32_t *)(*pcVar4)(uVar8);
                        param_1[7] = piVar9;
                        if (piVar9 == (int32_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802164e6;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                    }
                    pcVar4 = *(code **)(param_1[1] + 0x20);
                    if (pcVar4 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216523;
                        uVar8 = (*pcVar4)(piVar9, param_3);
                        return uVar8;
                    }
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021650c;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
                }
code_r0x000180216346:
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216352;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000028 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000038 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216364;
                fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar7 + iVar6));
            } else {
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802163cd;
                iVar5 = func_0x000180215910(param_1);
                if (iVar5 != 0) {
                    if (*(int64_t *)(param_2 + 0x1a) == 0) {
                        if (*param_2 == 0) {
                            uVar8 = 0x180645710;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802163e6;
                            uVar8 = func_0x00018022ccf0();
                        }
                        *(undefined8 *)(&stack0x00000030 + iVar7 + iVar6) = 0x180215c10;
                        *(undefined8 *)(&stack0x00000028 + iVar7 + iVar6) = 0x180215670;
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + iVar6) = 0x180215c50;
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216429;
                        param_2 = (int32_t *)func_0x000180280c20(0, 1, uVar8, 0x1805aadb1);
                        if (param_2 == (int32_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216436;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                        piVar9 = param_1[8];
                        if ((piVar9 != (int32_t *)0x0) && (piVar9[4] == 0)) {
                            LOCK();
                            piVar9 = piVar9 + 0x1c;
                            iVar5 = *piVar9;
                            *piVar9 = *piVar9 + -1;
                            UNLOCK();
                            if (iVar5 < 2) {
                                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021646c;
                                func_0x000180210740();
                            }
                        }
                        param_1[8] = param_2;
                    }
                    goto code_r0x000180216475;
                }
            }
        } else {
code_r0x000180216528:
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216530;
            iVar5 = func_0x000180215910(param_1);
            if (iVar5 != 0) {
                piVar3 = param_1[8];
                if (param_1[1] == piVar3) {
                    param_1[1] = (int32_t *)0x0;
                }
                if ((piVar3 != (int32_t *)0x0) && (piVar3[4] == 0)) {
                    LOCK();
                    piVar3 = piVar3 + 0x1c;
                    iVar5 = *piVar3;
                    *piVar3 = *piVar3 + -1;
                    UNLOCK();
                    if (iVar5 < 2) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021656f;
                        func_0x000180210740();
                    }
                }
                param_1[8] = (int32_t *)0x0;
                if (param_2 != (int32_t *)0x0) {
                    if (piVar11 == (int32_t *)0x0) {
                        if (piVar9 == (int32_t *)0x0) {
                            param_1[2] = (int32_t *)0x0;
                            goto code_r0x00018021660b;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021658d;
                        iVar5 = func_0x00018026b010(piVar11);
                        piVar9 = piVar11;
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216596;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                    }
                    iVar5 = *param_2;
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802165b9;
                    param_2 = (int32_t *)func_0x00018026ad30(piVar9, iVar5);
                    if (param_2 == (int32_t *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802165c6;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000028 + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802165de;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000028 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802165f0;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802165f8;
                        func_0x00018026aee0(piVar9);
                        goto code_r0x000180216364;
                    }
                    param_1[2] = piVar9;
                }
code_r0x00018021660b:
                ppiVar10 = param_1 + 1;
                piVar9 = *ppiVar10;
                if (piVar9 != param_2) {
                    if (piVar9 != (int32_t *)0x0) {
                        if (*(int64_t *)(piVar9 + 0xe) != 0) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216632;
                            iVar5 = func_0x00018020f740(param_1, 2);
                            if (iVar5 == 0) {
                                pcVar4 = *(code **)(*ppiVar10 + 0xe);
                                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216642;
                                (*pcVar4)(param_1);
                            }
                        }
                        if ((param_1[4] != (int32_t *)0x0) && (0 < (*ppiVar10)[0x11])) {
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216662;
                            func_0x00018020f740(param_1, 4);
                            piVar9 = param_1[4];
                            iVar5 = param_1[1][0x11];
                            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18021667f;
                            func_0x000180224b90(piVar9, (int64_t)iVar5, 0x1804bb7b8, 0x26);
                            param_1[4] = (int32_t *)0x0;
                        }
                    }
                    param_1[1] = param_2;
                    if (((*(uint32_t *)(param_1 + 3) & 0x100) == 0) && (param_2[0x11] != 0)) {
                        param_1[6] = *(int32_t **)(param_2 + 8);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802166b3;
                        piVar9 = (int32_t *)fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + iVar6));
                        param_1[4] = piVar9;
                        if (piVar9 == (int32_t *)0x0) goto code_r0x000180216364;
                    }
                }
                goto code_r0x0001802166c0;
            }
        }
code_r0x000180216364:
        uVar8 = 0;
    } else {
code_r0x0001802166c0:
        puVar2 = (uint32_t *)param_1[5];
        if ((puVar2 != (uint32_t *)0x0) && (((*puVar2 & 0xc1f0) == 0 || (*(int64_t *)(puVar2 + 10) == 0)))) {
            *(int32_t ***)(&stack0x00000028 + iVar7 + iVar6) = param_1;
            *(undefined4 *)((int64_t)&iStackX_20 + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x1802166f5;
            iVar5 = func_0x000180258740(puVar2, 0xffffffff, 0xc1f0, 7);
            if ((iVar5 < 1) && (iVar5 != -2)) goto code_r0x000180216364;
        }
        if ((*(uint32_t *)(param_1 + 3) & 0x100) == 0) {
            pcVar4 = *(code **)(param_1[1] + 6);
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x180216722;
            uVar8 = (*pcVar4)(param_1);
        } else {
            uVar8 = 1;
        }
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1802148c0
// Address: 0x1802148c0
// Size: 228 bytes
// ============================================================
undefined8 fcn.1802148c0(int64_t placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802148cf;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *(int64_t *)(placeholder_0 + 8);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802148e0;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802148f8;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18021490a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar3));
        return 0;
    }
    if (*(int64_t *)(iVar1 + 0x68) == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18021491d;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180214935;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180214947;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar3));
        return 0;
    }
    pcVar2 = *(code **)(iVar1 + 0x98);
    if (pcVar2 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18021495f;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180214977;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180214989;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar3));
        return 0;
    }
    uVar4 = *(undefined8 *)(placeholder_0 + 0x38);
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18021499f;
    uVar4 = (*pcVar2)(uVar4);
    return uVar4;
}

// ============================================================
// Function: FUN_1802149b0
// Address: 0x1802149b0
// Size: 272 bytes
// ============================================================
uint64_t fcn.1802149b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h, int64_t arg_68h,
                      int64_t arg_70h, int64_t arg_78h)
{
    uint32_t *puVar1;
    int32_t *piVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar11;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R14;
    undefined8 uStackX_18;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802149ba;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == 0) {
        return 1;
    }
    if ((*(uint32_t *)(in_RCX + 0x18) >> 0xb & 1) == 0) {
        puVar1 = *(uint32_t **)(in_RCX + 0x28);
        if (((puVar1 == (uint32_t *)0x0) || (uVar6 = *puVar1, (uVar6 & 0xc1f0) == 0)) ||
           (*(int64_t *)(puVar1 + 0xc) == 0)) {
            iVar9 = *(int64_t *)(in_RCX + 8);
            if (((iVar9 == 0) || (*(int64_t *)(iVar9 + 0x68) == 0)) || ((*(uint32_t *)(in_RCX + 0x18) >> 8 & 1) != 0)) {
                if (*(code **)(in_RCX + 0x30) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180214abd. Too many branches
    // WARNING: Treating indirect jump as call
                    uVar10 = (**(code **)(in_RCX + 0x30))();
                    return uVar10;
                }
                return 0;
            }
            if (*(code **)(iVar9 + 0x88) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180214aa6. Too many branches
    // WARNING: Treating indirect jump as call
                uVar10 = (**(code **)(iVar9 + 0x88))(*(undefined8 *)(in_RCX + 0x38), in_RDX);
                return uVar10;
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x180214a8a;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
        } else {
            if (uVar6 == 0x80) {
                *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RBX;
                *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_48h + iVar8) = unaff_RSI;
                *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_R14;
                *(undefined8 *)((int64_t)&uStackX_18 + iVar8) = 0x18025c35b;
                iVar9 = fcn.18045a350();
                iVar9 = -iVar9;
                piVar2 = *(int32_t **)(in_RCX + 0x28);
                if ((*(uint32_t *)(in_RCX + 0x18) & 0x800) != 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c379;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c391;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000050 + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000058 + iVar9 + iVar8), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar9 + iVar8));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c3a3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
                    return 0;
                }
                *(undefined8 *)((int64_t)&arg_60h + iVar9 + iVar8) = unaff_RDI;
                if (piVar2 != (int32_t *)0x0) {
                    if (((*piVar2 == 0x80) && (*(int64_t *)(piVar2 + 0xc) != 0)) &&
                       (iVar3 = *(int64_t *)(piVar2 + 10), iVar3 != 0)) {
                        iVar11 = 0x1805aadb1;
                        if (*(int64_t *)(iVar3 + 0x10) != 0) {
                            iVar11 = *(int64_t *)(iVar3 + 0x10);
                        }
                        if (*(int64_t *)(iVar3 + 0x98) != 0) {
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c440;
                            fcn.180229b10();
                            pcVar4 = *(code **)(iVar3 + 0x98);
                            uVar5 = *(undefined8 *)(piVar2 + 0xc);
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c453;
                            uVar6 = (*pcVar4)(uVar5, in_RDX, in_R8);
                            if ((int32_t)uVar6 < 1) {
                                *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c45e;
                                iVar7 = fcn.180229970();
                                if (iVar7 == 0) {
                                    *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c467;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8));
                                    *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c47f;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8), 
                                                  *(int64_t *)(&stack0x00000050 + iVar9 + iVar8), 
                                                  *(int64_t *)(&stack0x00000058 + iVar9 + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_70h + iVar9 + iVar8));
                                    *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8) = iVar11;
                                    *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c49e;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
                                }
                            }
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c4a3;
                            fcn.180229900();
                            return (uint64_t)uVar6;
                        }
                        *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c3fd;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8));
                        *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c415;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8), 
                                      *(int64_t *)(&stack0x00000050 + iVar9 + iVar8), 
                                      *(int64_t *)(&stack0x00000058 + iVar9 + iVar8), 
                                      *(int64_t *)((int64_t)&arg_70h + iVar9 + iVar8));
                        *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8) = iVar11;
                        *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c434;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
                        return 0;
                    }
                    if (*(int64_t *)(piVar2 + 0x1e) == 0) {
                        *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c4b5;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8));
                        *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c4cd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8), 
                                      *(int64_t *)(&stack0x00000050 + iVar9 + iVar8), 
                                      *(int64_t *)(&stack0x00000058 + iVar9 + iVar8), 
                                      *(int64_t *)((int64_t)&arg_70h + iVar9 + iVar8));
                        *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c4df;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
                        return 0;
                    }
                    if ((*(uint8_t *)(piVar2 + 0x28) & 1) != 0) {
                        pcVar4 = *(code **)(*(int64_t *)(piVar2 + 0x1e) + 0xf8);
                        *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c4fb;
                        iVar7 = (*pcVar4)(piVar2, in_RCX);
                        if (iVar7 == 0) {
                            return 0;
                        }
                    }
                    piVar2[0x28] = piVar2[0x28] & 0xfffffffe;
                }
                *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025c514;
                uVar10 = fcn.1802149b0(*(int64_t *)(&stack0x00000050 + iVar9 + iVar8), 
                                       *(int64_t *)(&stack0x00000058 + iVar9 + iVar8), 
                                       *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8), 
                                       *(int64_t *)((int64_t)&arg_78h + iVar9 + iVar8), 
                                       *(int64_t *)(&stack0x00000080 + iVar9 + iVar8), 
                                       *(int64_t *)(&stack0x00000088 + iVar9 + iVar8), 
                                       *(int64_t *)(&stack0x00000090 + iVar9 + iVar8));
                return uVar10;
            }
            if (uVar6 == 0x100) {
                *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RBX;
                *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_48h + iVar8) = unaff_RSI;
                *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_R14;
                *(undefined8 *)((int64_t)&uStackX_18 + iVar8) = 0x18025cc4b;
                iVar9 = fcn.18045a350();
                iVar9 = -iVar9;
                piVar2 = *(int32_t **)(in_RCX + 0x28);
                if ((*(uint32_t *)(in_RCX + 0x18) & 0x800) != 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cc69;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cc81;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000050 + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000058 + iVar9 + iVar8), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar9 + iVar8));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cc93;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
                    return 0;
                }
                *(undefined8 *)((int64_t)&arg_60h + iVar9 + iVar8) = unaff_RDI;
                if (piVar2 != (int32_t *)0x0) {
                    if (((*piVar2 == 0x100) && (*(int64_t *)(piVar2 + 0xc) != 0)) &&
                       (iVar3 = *(int64_t *)(piVar2 + 10), iVar3 != 0)) {
                        iVar11 = 0x1805aadb1;
                        if (*(int64_t *)(iVar3 + 0x10) != 0) {
                            iVar11 = *(int64_t *)(iVar3 + 0x10);
                        }
                        if (*(int64_t *)(iVar3 + 0xb8) == 0) {
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cced;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8));
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cd05;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8), 
                                          *(int64_t *)(&stack0x00000050 + iVar9 + iVar8), 
                                          *(int64_t *)(&stack0x00000058 + iVar9 + iVar8), 
                                          *(int64_t *)((int64_t)&arg_70h + iVar9 + iVar8));
                            *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8) = iVar11;
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cd24;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
                            return 0;
                        }
                        *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cd30;
                        fcn.180229b10();
                        pcVar4 = *(code **)(iVar3 + 0xb8);
                        uVar5 = *(undefined8 *)(piVar2 + 0xc);
                        *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cd43;
                        uVar6 = (*pcVar4)(uVar5, in_RDX, in_R8);
                        if ((int32_t)uVar6 < 1) {
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cd4e;
                            iVar7 = fcn.180229970();
                            if (iVar7 == 0) {
                                *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cd57;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8));
                                *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cd6f;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar8), 
                                              *(int64_t *)(&stack0x00000050 + iVar9 + iVar8), 
                                              *(int64_t *)(&stack0x00000058 + iVar9 + iVar8), 
                                              *(int64_t *)((int64_t)&arg_70h + iVar9 + iVar8));
                                *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar8) = iVar11;
                                *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cd8e;
                                fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
                            }
                        }
                        *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cd93;
                        fcn.180229900();
                        return (uint64_t)uVar6;
                    }
                    if ((*(uint8_t *)(piVar2 + 0x28) & 1) != 0) {
                        pcVar4 = *(code **)(*(int64_t *)(piVar2 + 0x1e) + 0xf8);
                        *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cdb4;
                        iVar7 = (*pcVar4)(piVar2, in_RCX);
                        if (iVar7 == 0) {
                            return 0;
                        }
                    }
                    piVar2[0x28] = piVar2[0x28] & 0xfffffffe;
                }
                *(undefined8 *)((int64_t)&uStackX_18 + iVar9 + iVar8) = 0x18025cdd1;
                uVar10 = fcn.1802149b0(*(int64_t *)(&stack0x00000050 + iVar9 + iVar8), 
                                       *(int64_t *)(&stack0x00000058 + iVar9 + iVar8), 
                                       *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8), 
                                       *(int64_t *)((int64_t)&arg_78h + iVar9 + iVar8), 
                                       *(int64_t *)(&stack0x00000080 + iVar9 + iVar8), 
                                       *(int64_t *)(&stack0x00000088 + iVar9 + iVar8), 
                                       *(int64_t *)(&stack0x00000090 + iVar9 + iVar8));
                return uVar10;
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x180214a54;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802149df;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802149f7;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                  *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8), 
                  *(int64_t *)(&stack0x00000050 + iVar8));
    *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x180214a09;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar8));
    return 0;
}

// ============================================================
// Function: FUN_180214ac0
// Address: 0x180214ac0
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.180214ac0(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    int32_t *piVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 *in_RCX;
    undefined4 *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t *piVar12;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180214ad0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180214ae0;
    fcn.180215aa0(*(int64_t *)((int64_t)aiStackX_18 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                  *(int64_t *)(&stack0x00000048 + iVar8), *(int64_t *)((int64_t)&arg_50h + iVar8));
    uVar11 = *(undefined8 *)((int64_t)aiStackX_18 + iVar8);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar8) = *(undefined8 *)((int64_t)&arg_28h + iVar8);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar8 + -8) = uVar11;
    *(undefined8 *)((int64_t)&var_8h + iVar8) = 0x180214b0d;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if (in_RDX == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214b20;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214b38;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), 
                      *(int64_t *)(&stack0x00000040 + iVar9 + iVar8), *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                      *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214b4a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar9 + iVar8));
        return 0;
    }
    iVar10 = *(int64_t *)(in_RDX + 2);
    *(undefined8 *)((int64_t)&arg_50h + iVar9 + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_58h + iVar9 + iVar8) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_60h + iVar9 + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_68h + iVar9 + iVar8) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_30h + iVar9 + iVar8) = unaff_R15;
    if (iVar10 == 0) {
        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214b80;
        fcn.180215aa0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), 
                      *(int64_t *)(&stack0x00000040 + iVar9 + iVar8), *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                      *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8), *(int64_t *)((int64_t)&arg_68h + iVar9 + iVar8));
        iVar10 = in_RCX[8];
        if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x10) == 0)) {
            LOCK();
            piVar1 = (int32_t *)(iVar10 + 0x70);
            iVar7 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar7 < 2) {
                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214ba3;
                fcn.180210740();
            }
        }
        uVar4 = in_RDX[1];
        uVar5 = in_RDX[2];
        uVar6 = in_RDX[3];
        *(undefined4 *)in_RCX = *in_RDX;
        *(undefined4 *)((int64_t)in_RCX + 4) = uVar4;
        *(undefined4 *)(in_RCX + 1) = uVar5;
        *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar6;
        uVar4 = in_RDX[5];
        uVar5 = in_RDX[6];
        uVar6 = in_RDX[7];
        *(undefined4 *)(in_RCX + 2) = in_RDX[4];
        *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar4;
        *(undefined4 *)(in_RCX + 3) = uVar5;
        *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar6;
        uVar4 = in_RDX[9];
        uVar5 = in_RDX[10];
        uVar6 = in_RDX[0xb];
        *(undefined4 *)(in_RCX + 4) = in_RDX[8];
        *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar4;
        *(undefined4 *)(in_RCX + 5) = uVar5;
        *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar6;
        uVar4 = in_RDX[0xd];
        uVar5 = in_RDX[0xe];
        uVar6 = in_RDX[0xf];
        *(undefined4 *)(in_RCX + 6) = in_RDX[0xc];
        *(undefined4 *)((int64_t)in_RCX + 0x34) = uVar4;
        *(undefined4 *)(in_RCX + 7) = uVar5;
        *(undefined4 *)((int64_t)in_RCX + 0x3c) = uVar6;
        in_RCX[8] = *(undefined8 *)(in_RDX + 0x10);
    } else {
        if ((*(int64_t *)(iVar10 + 0x68) == 0) || ((in_RDX[6] & 0x100) != 0)) {
            if (*(int64_t *)(in_RDX + 4) != 0) {
                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214dc4;
                iVar7 = fcn.18026b010(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8));
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214dcd;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214de5;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000040 + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214df7;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar9 + iVar8));
                    return 0;
                }
            }
            iVar10 = 0;
            if (in_RCX[1] == *(int64_t *)(in_RDX + 2)) {
                iVar10 = in_RCX[4];
                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214e1b;
                fcn.18020f6d0(in_RCX, 4);
            }
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214e2a;
            fcn.180215aa0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), *(int64_t *)(&stack0x00000040 + iVar9 + iVar8)
                          , *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_68h + iVar9 + iVar8));
            uVar4 = in_RDX[1];
            uVar5 = in_RDX[2];
            uVar6 = in_RDX[3];
            *(undefined4 *)in_RCX = *in_RDX;
            *(undefined4 *)((int64_t)in_RCX + 4) = uVar4;
            *(undefined4 *)(in_RCX + 1) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar6;
            uVar4 = in_RDX[5];
            uVar5 = in_RDX[6];
            uVar6 = in_RDX[7];
            *(undefined4 *)(in_RCX + 2) = in_RDX[4];
            *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar4;
            *(undefined4 *)(in_RCX + 3) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar6;
            uVar4 = in_RDX[9];
            uVar5 = in_RDX[10];
            uVar6 = in_RDX[0xb];
            *(undefined4 *)(in_RCX + 4) = in_RDX[8];
            *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar4;
            *(undefined4 *)(in_RCX + 5) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar6;
            uVar4 = in_RDX[0xd];
            uVar5 = in_RDX[0xe];
            uVar6 = in_RDX[0xf];
            *(undefined4 *)(in_RCX + 6) = in_RDX[0xc];
            *(undefined4 *)((int64_t)in_RCX + 0x34) = uVar4;
            *(undefined4 *)(in_RCX + 7) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0x3c) = uVar6;
            in_RCX[8] = *(undefined8 *)(in_RDX + 0x10);
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214e5f;
            fcn.18020f580(in_RCX, 0x400);
            in_RCX[4] = 0;
            in_RCX[5] = 0;
            if ((*(int64_t *)(in_RDX + 8) != 0) && (*(int32_t *)(in_RCX[1] + 0x44) != 0)) {
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214ea6;
                    iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                           *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
                    in_RCX[4] = iVar10;
                    if (iVar10 == 0) {
                        return 0;
                    }
                } else {
                    in_RCX[4] = iVar10;
                }
                uVar11 = *(undefined8 *)(in_RDX + 8);
                iVar7 = *(int32_t *)(in_RCX[1] + 0x44);
                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214ed2;
                fcn.180498030(iVar10, uVar11, (int64_t)iVar7);
            }
            piVar12 = in_RCX + 5;
            in_RCX[6] = *(undefined8 *)(in_RDX + 0xc);
            if (*(int64_t *)(in_RDX + 10) != 0) {
                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214eec;
                iVar10 = fcn.180258850(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                       *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), 
                                       *(int64_t *)(&stack0x00000040 + iVar9 + iVar8));
                *piVar12 = iVar10;
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f05;
                    iVar7 = fcn.18020f740(in_RCX, 0x400);
                    if (iVar7 == 0) {
                        iVar10 = *piVar12;
                        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f11;
                        fcn.180258be0(iVar10);
                        *piVar12 = 0;
                    }
                    if (in_RCX[7] != 0) {
                        if ((in_RCX[1] != 0) && (pcVar2 = *(code **)(in_RCX[1] + 0xa8), pcVar2 != (code *)0x0)) {
                            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f34;
                            (*pcVar2)();
                        }
                        in_RCX[7] = 0;
                        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f45;
                        fcn.18020f6d0(in_RCX, 2);
                    }
                    if (in_RCX[1] != 0) {
                        if (*(int64_t *)(in_RCX[1] + 0x38) != 0) {
                            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f61;
                            iVar7 = fcn.18020f740(in_RCX, 2);
                            if (iVar7 == 0) {
                                pcVar2 = *(code **)(in_RCX[1] + 0x38);
                                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f73;
                                (*pcVar2)(in_RCX);
                            }
                        }
                        if ((in_RCX[4] != 0) && (0 < *(int32_t *)(in_RCX[1] + 0x44))) {
                            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f8f;
                            iVar7 = fcn.18020f740(in_RCX, 4);
                            if (iVar7 == 0) {
                                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214fb1;
                                fcn.180224b90(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                              *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
                                in_RCX[4] = 0;
                            }
                        }
                    }
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214fbe;
                    fcn.18026aee0(*(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
                    iVar10 = in_RCX[8];
                    in_RCX[2] = 0;
                    if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x10) == 0)) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar10 + 0x70);
                        iVar7 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar7 < 2) {
                            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214fe4;
                            fcn.180210740();
                        }
                    }
                    in_RCX[8] = 0;
                    *in_RCX = 0;
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214ff8;
                    fcn.180244fc0(in_RCX, 0x48);
                    return 0;
                }
            }
            pcVar2 = *(code **)(in_RCX[1] + 0x30);
            if (pcVar2 == (code *)0x0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180215011;
            uVar11 = (*pcVar2)(in_RCX, in_RDX);
            return uVar11;
        }
        if (*(int64_t *)(iVar10 + 0xb8) == 0) {
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214c61;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214c79;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), *(int64_t *)(&stack0x00000040 + iVar9 + iVar8)
                          , *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214c8b;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar9 + iVar8));
            return 0;
        }
        if ((in_RCX[1] == iVar10) && (pcVar2 = *(code **)(iVar10 + 0xb0), pcVar2 != (code *)0x0)) {
            uVar11 = *(undefined8 *)(in_RDX + 0xe);
            uVar3 = in_RCX[7];
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214caf;
            (*pcVar2)(uVar3, uVar11);
            uVar11 = in_RCX[5];
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214cbc;
            fcn.180258be0(uVar11);
            in_RCX[5] = 0;
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214ccb;
            fcn.180215750(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8));
            *(undefined4 *)(in_RCX + 3) = in_RDX[6];
            in_RCX[6] = *(undefined8 *)(in_RDX + 0xc);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214ce8;
            fcn.180215aa0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), *(int64_t *)(&stack0x00000040 + iVar9 + iVar8)
                          , *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_68h + iVar9 + iVar8));
            iVar10 = *(int64_t *)(in_RDX + 0x10);
            if (in_RCX[8] != iVar10) {
                if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x10) == 0)) {
                    LOCK();
                    *(int32_t *)(iVar10 + 0x70) = *(int32_t *)(iVar10 + 0x70) + 1;
                    UNLOCK();
                }
                iVar10 = in_RCX[8];
                if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x10) == 0)) {
                    LOCK();
                    piVar1 = (int32_t *)(iVar10 + 0x70);
                    iVar7 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar7 < 2) {
                        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214d24;
                        fcn.180210740();
                    }
                }
            }
            uVar4 = in_RDX[1];
            uVar5 = in_RDX[2];
            uVar6 = in_RDX[3];
            *(undefined4 *)in_RCX = *in_RDX;
            *(undefined4 *)((int64_t)in_RCX + 4) = uVar4;
            *(undefined4 *)(in_RCX + 1) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar6;
            uVar4 = in_RDX[5];
            uVar5 = in_RDX[6];
            uVar6 = in_RDX[7];
            *(undefined4 *)(in_RCX + 2) = in_RDX[4];
            *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar4;
            *(undefined4 *)(in_RCX + 3) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar6;
            uVar4 = in_RDX[9];
            uVar5 = in_RDX[10];
            uVar6 = in_RDX[0xb];
            *(undefined4 *)(in_RCX + 4) = in_RDX[8];
            *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar4;
            *(undefined4 *)(in_RCX + 5) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar6;
            uVar4 = in_RDX[0xd];
            uVar5 = in_RDX[0xe];
            uVar6 = in_RDX[0xf];
            *(undefined4 *)(in_RCX + 6) = in_RDX[0xc];
            *(undefined4 *)((int64_t)in_RCX + 0x34) = uVar4;
            *(undefined4 *)(in_RCX + 7) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0x3c) = uVar6;
            in_RCX[8] = *(undefined8 *)(in_RDX + 0x10);
            in_RCX[5] = 0;
            in_RCX[7] = 0;
            if (*(int64_t *)(in_RDX + 0xe) != 0) {
                pcVar2 = *(code **)(*(int64_t *)(in_RDX + 2) + 0xb8);
                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214d73;
                iVar10 = (*pcVar2)();
                in_RCX[7] = iVar10;
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214d85;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214d9d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000040 + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214daf;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar9 + iVar8));
                    return 0;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214bdc;
    fcn.18020f580(in_RCX, 0x400);
    if (*(int64_t *)(in_RDX + 10) != 0) {
        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214bee;
        iVar10 = fcn.180258850(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                               *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), 
                               *(int64_t *)(&stack0x00000040 + iVar9 + iVar8));
        in_RCX[5] = iVar10;
        if (iVar10 == 0) {
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214bff;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214c17;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), *(int64_t *)(&stack0x00000040 + iVar9 + iVar8)
                          , *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214c29;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar9 + iVar8));
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214c33;
            fcn.180215aa0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), *(int64_t *)(&stack0x00000040 + iVar9 + iVar8)
                          , *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_68h + iVar9 + iVar8));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180214b00
// Address: 0x180214b00
// Size: 1336 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.180214ac0(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    int32_t *piVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 *in_RCX;
    undefined4 *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t *piVar12;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180214ad0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180214ae0;
    fcn.180215aa0(*(int64_t *)((int64_t)aiStackX_18 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                  *(int64_t *)(&stack0x00000048 + iVar8), *(int64_t *)((int64_t)&arg_50h + iVar8));
    uVar11 = *(undefined8 *)((int64_t)aiStackX_18 + iVar8);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar8) = *(undefined8 *)((int64_t)&arg_28h + iVar8);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar8 + -8) = uVar11;
    *(undefined8 *)((int64_t)&var_8h + iVar8) = 0x180214b0d;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if (in_RDX == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214b20;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214b38;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), 
                      *(int64_t *)(&stack0x00000040 + iVar9 + iVar8), *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                      *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214b4a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar9 + iVar8));
        return 0;
    }
    iVar10 = *(int64_t *)(in_RDX + 2);
    *(undefined8 *)((int64_t)&arg_50h + iVar9 + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_58h + iVar9 + iVar8) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_60h + iVar9 + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_68h + iVar9 + iVar8) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_30h + iVar9 + iVar8) = unaff_R15;
    if (iVar10 == 0) {
        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214b80;
        fcn.180215aa0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), 
                      *(int64_t *)(&stack0x00000040 + iVar9 + iVar8), *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                      *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8), *(int64_t *)((int64_t)&arg_68h + iVar9 + iVar8));
        iVar10 = in_RCX[8];
        if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x10) == 0)) {
            LOCK();
            piVar1 = (int32_t *)(iVar10 + 0x70);
            iVar7 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar7 < 2) {
                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214ba3;
                fcn.180210740();
            }
        }
        uVar4 = in_RDX[1];
        uVar5 = in_RDX[2];
        uVar6 = in_RDX[3];
        *(undefined4 *)in_RCX = *in_RDX;
        *(undefined4 *)((int64_t)in_RCX + 4) = uVar4;
        *(undefined4 *)(in_RCX + 1) = uVar5;
        *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar6;
        uVar4 = in_RDX[5];
        uVar5 = in_RDX[6];
        uVar6 = in_RDX[7];
        *(undefined4 *)(in_RCX + 2) = in_RDX[4];
        *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar4;
        *(undefined4 *)(in_RCX + 3) = uVar5;
        *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar6;
        uVar4 = in_RDX[9];
        uVar5 = in_RDX[10];
        uVar6 = in_RDX[0xb];
        *(undefined4 *)(in_RCX + 4) = in_RDX[8];
        *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar4;
        *(undefined4 *)(in_RCX + 5) = uVar5;
        *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar6;
        uVar4 = in_RDX[0xd];
        uVar5 = in_RDX[0xe];
        uVar6 = in_RDX[0xf];
        *(undefined4 *)(in_RCX + 6) = in_RDX[0xc];
        *(undefined4 *)((int64_t)in_RCX + 0x34) = uVar4;
        *(undefined4 *)(in_RCX + 7) = uVar5;
        *(undefined4 *)((int64_t)in_RCX + 0x3c) = uVar6;
        in_RCX[8] = *(undefined8 *)(in_RDX + 0x10);
    } else {
        if ((*(int64_t *)(iVar10 + 0x68) == 0) || ((in_RDX[6] & 0x100) != 0)) {
            if (*(int64_t *)(in_RDX + 4) != 0) {
                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214dc4;
                iVar7 = fcn.18026b010(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8));
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214dcd;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214de5;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000040 + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214df7;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar9 + iVar8));
                    return 0;
                }
            }
            iVar10 = 0;
            if (in_RCX[1] == *(int64_t *)(in_RDX + 2)) {
                iVar10 = in_RCX[4];
                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214e1b;
                fcn.18020f6d0(in_RCX, 4);
            }
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214e2a;
            fcn.180215aa0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), *(int64_t *)(&stack0x00000040 + iVar9 + iVar8)
                          , *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_68h + iVar9 + iVar8));
            uVar4 = in_RDX[1];
            uVar5 = in_RDX[2];
            uVar6 = in_RDX[3];
            *(undefined4 *)in_RCX = *in_RDX;
            *(undefined4 *)((int64_t)in_RCX + 4) = uVar4;
            *(undefined4 *)(in_RCX + 1) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar6;
            uVar4 = in_RDX[5];
            uVar5 = in_RDX[6];
            uVar6 = in_RDX[7];
            *(undefined4 *)(in_RCX + 2) = in_RDX[4];
            *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar4;
            *(undefined4 *)(in_RCX + 3) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar6;
            uVar4 = in_RDX[9];
            uVar5 = in_RDX[10];
            uVar6 = in_RDX[0xb];
            *(undefined4 *)(in_RCX + 4) = in_RDX[8];
            *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar4;
            *(undefined4 *)(in_RCX + 5) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar6;
            uVar4 = in_RDX[0xd];
            uVar5 = in_RDX[0xe];
            uVar6 = in_RDX[0xf];
            *(undefined4 *)(in_RCX + 6) = in_RDX[0xc];
            *(undefined4 *)((int64_t)in_RCX + 0x34) = uVar4;
            *(undefined4 *)(in_RCX + 7) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0x3c) = uVar6;
            in_RCX[8] = *(undefined8 *)(in_RDX + 0x10);
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214e5f;
            fcn.18020f580(in_RCX, 0x400);
            in_RCX[4] = 0;
            in_RCX[5] = 0;
            if ((*(int64_t *)(in_RDX + 8) != 0) && (*(int32_t *)(in_RCX[1] + 0x44) != 0)) {
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214ea6;
                    iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                           *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
                    in_RCX[4] = iVar10;
                    if (iVar10 == 0) {
                        return 0;
                    }
                } else {
                    in_RCX[4] = iVar10;
                }
                uVar11 = *(undefined8 *)(in_RDX + 8);
                iVar7 = *(int32_t *)(in_RCX[1] + 0x44);
                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214ed2;
                fcn.180498030(iVar10, uVar11, (int64_t)iVar7);
            }
            piVar12 = in_RCX + 5;
            in_RCX[6] = *(undefined8 *)(in_RDX + 0xc);
            if (*(int64_t *)(in_RDX + 10) != 0) {
                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214eec;
                iVar10 = fcn.180258850(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                       *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), 
                                       *(int64_t *)(&stack0x00000040 + iVar9 + iVar8));
                *piVar12 = iVar10;
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f05;
                    iVar7 = fcn.18020f740(in_RCX, 0x400);
                    if (iVar7 == 0) {
                        iVar10 = *piVar12;
                        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f11;
                        fcn.180258be0(iVar10);
                        *piVar12 = 0;
                    }
                    if (in_RCX[7] != 0) {
                        if ((in_RCX[1] != 0) && (pcVar2 = *(code **)(in_RCX[1] + 0xa8), pcVar2 != (code *)0x0)) {
                            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f34;
                            (*pcVar2)();
                        }
                        in_RCX[7] = 0;
                        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f45;
                        fcn.18020f6d0(in_RCX, 2);
                    }
                    if (in_RCX[1] != 0) {
                        if (*(int64_t *)(in_RCX[1] + 0x38) != 0) {
                            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f61;
                            iVar7 = fcn.18020f740(in_RCX, 2);
                            if (iVar7 == 0) {
                                pcVar2 = *(code **)(in_RCX[1] + 0x38);
                                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f73;
                                (*pcVar2)(in_RCX);
                            }
                        }
                        if ((in_RCX[4] != 0) && (0 < *(int32_t *)(in_RCX[1] + 0x44))) {
                            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214f8f;
                            iVar7 = fcn.18020f740(in_RCX, 4);
                            if (iVar7 == 0) {
                                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214fb1;
                                fcn.180224b90(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                              *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
                                in_RCX[4] = 0;
                            }
                        }
                    }
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214fbe;
                    fcn.18026aee0(*(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
                    iVar10 = in_RCX[8];
                    in_RCX[2] = 0;
                    if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x10) == 0)) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar10 + 0x70);
                        iVar7 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar7 < 2) {
                            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214fe4;
                            fcn.180210740();
                        }
                    }
                    in_RCX[8] = 0;
                    *in_RCX = 0;
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214ff8;
                    fcn.180244fc0(in_RCX, 0x48);
                    return 0;
                }
            }
            pcVar2 = *(code **)(in_RCX[1] + 0x30);
            if (pcVar2 == (code *)0x0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180215011;
            uVar11 = (*pcVar2)(in_RCX, in_RDX);
            return uVar11;
        }
        if (*(int64_t *)(iVar10 + 0xb8) == 0) {
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214c61;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214c79;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), *(int64_t *)(&stack0x00000040 + iVar9 + iVar8)
                          , *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214c8b;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar9 + iVar8));
            return 0;
        }
        if ((in_RCX[1] == iVar10) && (pcVar2 = *(code **)(iVar10 + 0xb0), pcVar2 != (code *)0x0)) {
            uVar11 = *(undefined8 *)(in_RDX + 0xe);
            uVar3 = in_RCX[7];
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214caf;
            (*pcVar2)(uVar3, uVar11);
            uVar11 = in_RCX[5];
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214cbc;
            fcn.180258be0(uVar11);
            in_RCX[5] = 0;
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214ccb;
            fcn.180215750(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8));
            *(undefined4 *)(in_RCX + 3) = in_RDX[6];
            in_RCX[6] = *(undefined8 *)(in_RDX + 0xc);
        } else {
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214ce8;
            fcn.180215aa0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), *(int64_t *)(&stack0x00000040 + iVar9 + iVar8)
                          , *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_68h + iVar9 + iVar8));
            iVar10 = *(int64_t *)(in_RDX + 0x10);
            if (in_RCX[8] != iVar10) {
                if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x10) == 0)) {
                    LOCK();
                    *(int32_t *)(iVar10 + 0x70) = *(int32_t *)(iVar10 + 0x70) + 1;
                    UNLOCK();
                }
                iVar10 = in_RCX[8];
                if ((iVar10 != 0) && (*(int32_t *)(iVar10 + 0x10) == 0)) {
                    LOCK();
                    piVar1 = (int32_t *)(iVar10 + 0x70);
                    iVar7 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar7 < 2) {
                        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214d24;
                        fcn.180210740();
                    }
                }
            }
            uVar4 = in_RDX[1];
            uVar5 = in_RDX[2];
            uVar6 = in_RDX[3];
            *(undefined4 *)in_RCX = *in_RDX;
            *(undefined4 *)((int64_t)in_RCX + 4) = uVar4;
            *(undefined4 *)(in_RCX + 1) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar6;
            uVar4 = in_RDX[5];
            uVar5 = in_RDX[6];
            uVar6 = in_RDX[7];
            *(undefined4 *)(in_RCX + 2) = in_RDX[4];
            *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar4;
            *(undefined4 *)(in_RCX + 3) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar6;
            uVar4 = in_RDX[9];
            uVar5 = in_RDX[10];
            uVar6 = in_RDX[0xb];
            *(undefined4 *)(in_RCX + 4) = in_RDX[8];
            *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar4;
            *(undefined4 *)(in_RCX + 5) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar6;
            uVar4 = in_RDX[0xd];
            uVar5 = in_RDX[0xe];
            uVar6 = in_RDX[0xf];
            *(undefined4 *)(in_RCX + 6) = in_RDX[0xc];
            *(undefined4 *)((int64_t)in_RCX + 0x34) = uVar4;
            *(undefined4 *)(in_RCX + 7) = uVar5;
            *(undefined4 *)((int64_t)in_RCX + 0x3c) = uVar6;
            in_RCX[8] = *(undefined8 *)(in_RDX + 0x10);
            in_RCX[5] = 0;
            in_RCX[7] = 0;
            if (*(int64_t *)(in_RDX + 0xe) != 0) {
                pcVar2 = *(code **)(*(int64_t *)(in_RDX + 2) + 0xb8);
                *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214d73;
                iVar10 = (*pcVar2)();
                in_RCX[7] = iVar10;
                if (iVar10 == 0) {
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214d85;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214d9d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000040 + iVar9 + iVar8), 
                                  *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
                    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214daf;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar9 + iVar8));
                    return 0;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214bdc;
    fcn.18020f580(in_RCX, 0x400);
    if (*(int64_t *)(in_RDX + 10) != 0) {
        *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214bee;
        iVar10 = fcn.180258850(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                               *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), 
                               *(int64_t *)(&stack0x00000040 + iVar9 + iVar8));
        in_RCX[5] = iVar10;
        if (iVar10 == 0) {
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214bff;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8));
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214c17;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), *(int64_t *)(&stack0x00000040 + iVar9 + iVar8)
                          , *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8));
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214c29;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar9 + iVar8));
            *(undefined8 *)((int64_t)&var_8h + iVar9 + iVar8) = 0x180214c33;
            fcn.180215aa0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar9 + iVar8), *(int64_t *)(&stack0x00000040 + iVar9 + iVar8)
                          , *(int64_t *)(&stack0x00000048 + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar8), 
                          *(int64_t *)((int64_t)&arg_68h + iVar9 + iVar8));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180215040
// Address: 0x180215040
// Size: 578 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180215040(int64_t arg_98h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t in_RCX;
    int64_t iVar7;
    int32_t in_EDX;
    int32_t in_R8D;
    code *pcVar8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_88h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t iStack_10;
    
    iStack_10 = 0x18021505a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    var_58h = 0;
    iVar3 = 0;
    var_50h._0_4_ = 0;
    var_48h = 0;
    var_40h = 0;
    var_38h = 0;
    var_30h = 0;
    var_28h._0_4_ = 0;
    var_20h = 0;
    uStack_18 = 0;
    iStack_10 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x180215095;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x1802150ad;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x1802150bf;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
        return 0;
    }
    iVar7 = *(int64_t *)(in_RCX + 8);
    if ((iVar7 != 0) && (*(int64_t *)(iVar7 + 0x68) == 0)) {
        pcVar8 = *(code **)(iVar7 + 0x48);
        if (pcVar8 == (code *)0x0) {
            *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x1802150e3;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
            *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x1802150fb;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x18021510d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x180215117;
        iVar3 = (*pcVar8)();
        goto code_r0x000180215268;
    }
    if (in_EDX == 2) {
        iVar4 = 9999;
        if (in_R8D != 0) {
            iVar4 = in_R8D;
        }
        *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x1802151ee;
        piVar6 = (int64_t *)func_0x000180229e30(&var_88h, 0x1804bb8d8, in_R9, (int64_t)iVar4);
        var_58h = *piVar6;
        var_50h._0_4_ = *(undefined4 *)(piVar6 + 1);
        var_50h._4_4_ = *(undefined4 *)((int64_t)piVar6 + 0xc);
        var_48h = piVar6[2];
        var_40h = piVar6[3];
        var_38h = piVar6[4];
        piVar1 = *(int32_t **)(in_RCX + 0x28);
        if (((piVar1 == (int32_t *)0x0) ||
            (((*piVar1 != 0x100 && (*piVar1 != 0x80)) || (iVar7 = *(int64_t *)(piVar1 + 0xc), iVar7 == 0)))) ||
           (pcVar8 = *(code **)(*(int64_t *)(piVar1 + 10) + 0x100), pcVar8 == (code *)0x0)) {
            if (*(int64_t *)(in_RCX + 8) == 0) goto code_r0x000180215268;
            pcVar8 = *(code **)(*(int64_t *)(in_RCX + 8) + 0xd0);
            goto code_r0x000180215254;
        }
    } else {
        if (in_EDX == 3) {
            var_8h = (int64_t)in_R8D;
            *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x180215162;
            piVar6 = (int64_t *)func_0x000180229cc0(&var_88h, 0x1804bb88c, &var_8h);
        } else {
            if (in_EDX != 0x1d) {
                return 0;
            }
            *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x180215145;
            piVar6 = (int64_t *)func_0x000180229c70(&var_88h, 0x1804b4ce0, in_R9, (int64_t)in_R8D);
        }
        var_58h = *piVar6;
        var_50h._0_4_ = *(undefined4 *)(piVar6 + 1);
        var_50h._4_4_ = *(undefined4 *)((int64_t)piVar6 + 0xc);
        var_48h = piVar6[2];
        var_40h = piVar6[3];
        var_38h = piVar6[4];
        piVar1 = *(int32_t **)(in_RCX + 0x28);
        if (((piVar1 == (int32_t *)0x0) || ((*piVar1 != 0x100 && (*piVar1 != 0x80)))) ||
           ((iVar7 = *(int64_t *)(piVar1 + 0xc), iVar7 == 0 ||
            (pcVar8 = *(code **)(*(int64_t *)(piVar1 + 10) + 0x110), pcVar8 == (code *)0x0)))) {
            if (*(int64_t *)(in_RCX + 8) == 0) goto code_r0x000180215268;
            pcVar8 = *(code **)(*(int64_t *)(in_RCX + 8) + 200);
code_r0x000180215254:
            if (pcVar8 != (code *)0x0) {
                uVar2 = *(undefined8 *)(in_RCX + 0x38);
                *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x180215264;
                iVar3 = (*pcVar8)(uVar2, &var_58h);
            }
            goto code_r0x000180215268;
        }
    }
    *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x180215242;
    iVar3 = (*pcVar8)(iVar7, &var_58h);
code_r0x000180215268:
    if (iVar3 < 1) {
        iVar3 = 0;
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180215290
// Address: 0x180215290
// Size: 126 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180215290(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802152a0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802152bd;
    iVar3 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802152d0;
        iVar1 = fcn.180214b00(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2));
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802152de;
            fcn.180215aa0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802152f3;
            fcn.180224990(iVar3, 0x1804bb7b8, 0x8c);
            return 0;
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180215310
// Address: 0x180215310
// Size: 56 bytes
// ============================================================
void fcn.180215310(int64_t arg1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180215320;
        iVar1 = fcn.18045a350();
        iVar1 = -iVar1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021532d;
        fcn.180215aa0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180215342;
        fcn.180224990(arg1, 0x1804bb7b8, 0x8c);
    }
    return;
}

// ============================================================
// Function: FUN_180215350
// Address: 0x180215350
// Size: 117 bytes
// ============================================================
undefined8 fcn.180215350(int64_t param_1)
{
    int32_t *piVar1;
    code *UNRECOVERED_JUMPTABLE;
    undefined8 uVar2;
    
    fcn.18045a350();
    piVar1 = *(int32_t **)(param_1 + 0x28);
    if (((piVar1 != (int32_t *)0x0) && (((*piVar1 == 0x100 || (*piVar1 == 0x80)) && (*(int64_t *)(piVar1 + 0xc) != 0))))
       && (*(code **)(*(int64_t *)(piVar1 + 10) + 0x100) != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x00018021539b. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (**(code **)(*(int64_t *)(piVar1 + 10) + 0x100))(*(int64_t *)(piVar1 + 0xc));
        return uVar2;
    }
    if ((*(int64_t *)(param_1 + 8) != 0) &&
       (UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(param_1 + 8) + 0xd0), UNRECOVERED_JUMPTABLE != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x0001802153bb. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (*UNRECOVERED_JUMPTABLE)(*(undefined8 *)(param_1 + 0x38));
        return uVar2;
    }
    return 0;
}

// ============================================================
// Function: FUN_1802153d0
// Address: 0x1802153d0
// Size: 149 bytes
// ============================================================
undefined8 fcn.1802153d0(int64_t param_1)
{
    int32_t *piVar1;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802153dc;
    iVar2 = fcn.18045a350();
    if (param_1 != 0) {
        piVar1 = *(int32_t **)(param_1 + 0x28);
        if (((piVar1 != (int32_t *)0x0) &&
            (((*piVar1 == 0x100 || (*piVar1 == 0x80)) && (*(int64_t *)(piVar1 + 0xc) != 0)))) &&
           (*(code **)(*(int64_t *)(piVar1 + 10) + 0x108) != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x000180215420. Too many branches
    // WARNING: Treating indirect jump as call
            uVar3 = (**(code **)(*(int64_t *)(piVar1 + 10) + 0x108))();
            return uVar3;
        }
        if ((*(int64_t *)(param_1 + 8) != 0) && (*(int64_t *)(*(int64_t *)(param_1 + 8) + 0xe8) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x18021543b;
            uVar3 = func_0x00018020f790();
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180215443;
            uVar3 = func_0x00018027e810(uVar3);
            UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(param_1 + 8) + 0xe8);
    // WARNING: Could not recover jumptable at 0x00018021545a. Too many branches
    // WARNING: Treating indirect jump as call
            uVar3 = (*UNRECOVERED_JUMPTABLE)(*(undefined8 *)(param_1 + 0x38), uVar3, UNRECOVERED_JUMPTABLE);
            return uVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180215470
// Address: 0x180215470
// Size: 40 bytes
// ============================================================
int64_t fcn.180215470(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar4 = 0x48;
    *(undefined8 *)(&stack0x00000030 + iVar1) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x180224d70;
    iVar2 = fcn.18045a350(0x48, 0x1804bb7b8, 0x83);
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x180224d7b;
    iVar3 = fcn.1802248d0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1)
                         );
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x180224d90;
        fcn.1804986e0(iVar3, 0, uVar4);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_1802154a0
// Address: 0x1802154a0
// Size: 24 bytes
// ============================================================
undefined8 fcn.1802154a0(undefined8 *param_1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    code *pcVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 auStackX_18 [2];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar9 = 0;
    *(undefined8 *)(&stack0x00000048 + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar7 + 8) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_18 + iVar7) = 0x180215ab0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (param_1 == (undefined8 *)0x0) {
        return 1;
    }
    *(undefined8 *)(&stack0x00000058 + iVar8 + iVar7) = unaff_RDI;
    *(undefined8 *)(&stack0x00000060 + iVar8 + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180215ad5;
    iVar6 = fcn.18020f740();
    if (iVar6 == 0) {
        uVar3 = param_1[5];
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180215ae5;
        fcn.180258be0(uVar3);
        param_1[5] = 0;
    }
    piVar1 = param_1 + 1;
    if (param_1[7] != 0) {
        if ((*piVar1 != 0) && (pcVar4 = *(code **)(*piVar1 + 0xa8), pcVar4 != (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180215b0c;
            (*pcVar4)();
        }
        param_1[7] = 0;
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180215b1d;
        fcn.18020f6d0(param_1, 2);
    }
    iVar5 = *piVar1;
    if (iVar5 != 0) {
        *(undefined8 *)(&stack0x00000050 + iVar8 + iVar7) = unaff_RSI;
        if (*(int64_t *)(iVar5 + 0x38) != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180215b40;
            iVar6 = fcn.18020f740(param_1, 2);
            if (iVar6 == 0) {
                pcVar4 = *(code **)(*piVar1 + 0x38);
                *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180215b50;
                (*pcVar4)(param_1);
            }
        }
        if ((param_1[4] != 0) && (0 < *(int32_t *)(*piVar1 + 0x44))) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180215b70;
            iVar6 = fcn.18020f740(param_1, 4);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180215b91;
                fcn.180224b90(*(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
                param_1[4] = 0;
            }
        }
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180215ba3;
    fcn.18026aee0(*(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
    param_1[2] = 0;
    if (iVar9 == 0) {
        iVar5 = param_1[8];
        if ((iVar5 != 0) && (*(int32_t *)(iVar5 + 0x10) == 0)) {
            LOCK();
            piVar2 = (int32_t *)(iVar5 + 0x70);
            iVar9 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar9 < 2) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180215bd3;
                fcn.180210740();
            }
        }
        param_1[8] = 0;
        *param_1 = 0;
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180215be7;
        fcn.180244fc0(param_1, 0x48);
    }
    return 1;
}

// ============================================================
// Function: FUN_1802154c0
// Address: 0x1802154c0
// Size: 117 bytes
// ============================================================
undefined8 fcn.1802154c0(int64_t param_1)
{
    int32_t *piVar1;
    code *UNRECOVERED_JUMPTABLE;
    undefined8 uVar2;
    
    fcn.18045a350();
    piVar1 = *(int32_t **)(param_1 + 0x28);
    if (((piVar1 != (int32_t *)0x0) && (((*piVar1 == 0x100 || (*piVar1 == 0x80)) && (*(int64_t *)(piVar1 + 0xc) != 0))))
       && (*(code **)(*(int64_t *)(piVar1 + 10) + 0x110) != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x00018021550b. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (**(code **)(*(int64_t *)(piVar1 + 10) + 0x110))(*(int64_t *)(piVar1 + 0xc));
        return uVar2;
    }
    if ((*(int64_t *)(param_1 + 8) != 0) &&
       (UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(param_1 + 8) + 200), UNRECOVERED_JUMPTABLE != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x00018021552b. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (*UNRECOVERED_JUMPTABLE)(*(undefined8 *)(param_1 + 0x38));
        return uVar2;
    }
    return 0;
}

// ============================================================
// Function: FUN_180215540
// Address: 0x180215540
// Size: 70 bytes
// ============================================================
void fcn.180215540(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021554a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x180215c10;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180215670;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180215c50;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180215581;
    fcn.180280c20(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x000000b0 + iVar1), *(int64_t *)(&stack0x000000b8 + iVar1), 
                  *(int64_t *)(&stack0x000000c0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180215590
// Address: 0x180215590
// Size: 49 bytes
// ============================================================
void fcn.180215590(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_8;
    
    if (arg1 != 0) {
        uStack_8 = 0x18021559f;
        iVar3 = fcn.18045a350();
        if (*(int32_t *)(arg1 + 0x10) == 0) {
            LOCK();
            piVar1 = (int32_t *)(arg1 + 0x70);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 < 2) {
                *(undefined8 *)((int64_t)&uStack_8 - iVar3) = 0x1802155bc;
                fcn.180210740();
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802155d0
// Address: 0x1802155d0
// Size: 74 bytes
// ============================================================
undefined8 fcn.1802155d0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802155dc;
    iVar1 = fcn.18045a350();
    if ((param_1 != 0) && (*(int64_t *)(param_1 + 0xe8) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1802155f6;
        uVar2 = func_0x00018020f790();
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1802155fe;
        uVar2 = func_0x00018027e810(uVar2);
    // WARNING: Could not recover jumptable at 0x00018021560f. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (**(code **)(param_1 + 0xe8))(0, uVar2, *(code **)(param_1 + 0xe8));
        return uVar2;
    }
    return 0;
}

// ============================================================
// Function: FUN_180215620
// Address: 0x180215620
// Size: 74 bytes
// ============================================================
undefined8 fcn.180215620(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021562c;
    iVar1 = fcn.18045a350();
    if ((param_1 != 0) && (*(int64_t *)(param_1 + 0xe0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180215646;
        uVar2 = func_0x00018020f790();
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x18021564e;
        uVar2 = func_0x00018027e810(uVar2);
    // WARNING: Could not recover jumptable at 0x00018021565f. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (**(code **)(param_1 + 0xe0))(0, uVar2, *(code **)(param_1 + 0xe0));
        return uVar2;
    }
    return 0;
}

// ============================================================
// Function: FUN_180215680
// Address: 0x180215680
// Size: 201 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4
fcn.180215680(int64_t arg_28h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h, int64_t arg_78h, int64_t arg_88h,
             int64_t arg_98h, int64_t arg_e0h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180215695;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0x180215c10;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = 0x180215670;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0x180215c50;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802156cf;
    iVar5 = fcn.180280c20(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4), *(int64_t *)(&stack0x000000b0 + iVar4), 
                          *(int64_t *)(&stack0x000000b8 + iVar4));
    uVar3 = 0;
    *(undefined4 *)((int64_t)&arg_38h + iVar4) = 0;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
        *(int64_t *)((int64_t)&var_18h + iVar4) = iVar5;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180215704;
        uVar3 = fcn.180214220(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
        if (*(int32_t *)(iVar5 + 0x10) == 0) {
            LOCK();
            piVar1 = (int32_t *)(iVar5 + 0x70);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 < 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180215723;
                fcn.180210740(iVar5);
            }
        }
    }
    if (*(uint64_t **)((int64_t)&arg_88h + iVar4) != (uint64_t *)0x0) {
        **(uint64_t **)((int64_t)&arg_88h + iVar4) = (uint64_t)*(uint32_t *)((int64_t)&arg_38h + iVar4);
    }
    return uVar3;
}

// ============================================================
// Function: FUN_180215750
// Address: 0x180215750
// Size: 154 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180215750(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180215760;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(in_RCX + 8) != 0) {
        if (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x38) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180215782;
            iVar2 = fcn.18020f740();
            if (iVar2 == 0) {
                pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180215793;
                (*pcVar1)(in_RCX);
            }
        }
        if ((*(int64_t *)(in_RCX + 0x20) != 0) && (0 < *(int32_t *)(*(int64_t *)(in_RCX + 8) + 0x44))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802157b1;
            iVar2 = fcn.18020f740(in_RCX, 4);
            if ((iVar2 == 0) || (in_EDX != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802157d7;
                fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)(in_RCX + 0x20) = 0;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802157f0
// Address: 0x1802157f0
// Size: 70 bytes
// ============================================================
void fcn.1802157f0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802157fa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x180215c10;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180215670;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180215c50;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180215831;
    fcn.180280ca0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000080 + iVar1), *(int64_t *)(&stack0x000000b0 + iVar1), 
                  *(int64_t *)(&stack0x000000b8 + iVar1), *(int64_t *)(&stack0x000000c0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180215840
// Address: 0x180215840
// Size: 199 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180215840(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    int32_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 *in_RCX;
    int32_t in_EDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180215860;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX[7] != 0) {
        if ((in_RCX[1] != 0) && (pcVar3 = *(code **)(in_RCX[1] + 0xa8), pcVar3 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021588e;
            (*pcVar3)();
        }
        in_RCX[7] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021589f;
        fcn.18020f6d0(in_RCX, 2);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802158a9;
    fcn.180215750(*(int64_t *)((int64_t)&var_18h + iVar5));
    if (in_EDX != 0) {
        in_RCX[1] = 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802158ba;
    fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar5));
    in_RCX[2] = 0;
    if (in_R8D == 0) {
        iVar4 = in_RCX[8];
        if ((iVar4 != 0) && (*(int32_t *)(iVar4 + 0x10) == 0)) {
            LOCK();
            piVar1 = (int32_t *)(iVar4 + 0x70);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 < 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802158e5;
                fcn.180210740();
            }
        }
        in_RCX[8] = 0;
        *in_RCX = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180215910
// Address: 0x180215910
// Size: 124 bytes
// ============================================================
undefined8 fcn.180215910(int64_t param_1)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021591c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(param_1 + 0x38) != 0) {
        if (*(int64_t *)(param_1 + 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180215939;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180215951;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180215963;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
        pcVar1 = *(code **)(*(int64_t *)(param_1 + 8) + 0xa8);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180215979;
            (*pcVar1)();
        }
        *(undefined8 *)(param_1 + 0x38) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180215990
// Address: 0x180215990
// Size: 258 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180215990(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 in_RCX;
    undefined4 *in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802159ae;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802159d6;
    iVar5 = fcn.180224d60(*(int64_t *)((int64_t)&var_8h + iVar4));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802159ec;
        iVar6 = func_0x000180259210(in_R8, in_RCX, in_R9);
        if (iVar6 != 0) {
            if (in_RDX == (undefined4 *)0x0) {
code_r0x000180215a0c:
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180215a17;
                func_0x00018020f6e0(iVar5, iVar6);
                return iVar5;
            }
            uVar1 = *in_RDX;
            uVar2 = *(undefined8 *)(in_RDX + 2);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180215a08;
            iVar3 = func_0x000180259270(iVar6, uVar2, uVar1);
            if (0 < iVar3) goto code_r0x000180215a0c;
            goto code_r0x000180215a4b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180215a21;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180215a39;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180215a4b;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
code_r0x000180215a4b:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180215a53;
    fcn.180258be0(iVar6);
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180215a62;
        fcn.180215aa0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000040 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180215a77;
        fcn.180224990(iVar5, 0x1804bb7b8, 0x8c);
    }
    return 0;
}

// ============================================================
// Function: FUN_180215aa0
// Address: 0x180215aa0
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180215aa0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    code *pcVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180215ab0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == (undefined8 *)0x0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ad5;
    iVar6 = fcn.18020f740();
    if (iVar6 == 0) {
        uVar3 = in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ae5;
        fcn.180258be0(uVar3);
        in_RCX[5] = 0;
    }
    piVar1 = in_RCX + 1;
    if (in_RCX[7] != 0) {
        if ((*piVar1 != 0) && (pcVar4 = *(code **)(*piVar1 + 0xa8), pcVar4 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b0c;
            (*pcVar4)();
        }
        in_RCX[7] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b1d;
        fcn.18020f6d0(in_RCX, 2);
    }
    iVar5 = *piVar1;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RSI;
        if (*(int64_t *)(iVar5 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b40;
            iVar6 = fcn.18020f740(in_RCX, 2);
            if (iVar6 == 0) {
                pcVar4 = *(code **)(*piVar1 + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b50;
                (*pcVar4)(in_RCX);
            }
        }
        if ((in_RCX[4] != 0) && (0 < *(int32_t *)(*piVar1 + 0x44))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b70;
            iVar6 = fcn.18020f740(in_RCX, 4);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b91;
                fcn.180224b90(*(int64_t *)((int64_t)&iStackX_18 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                in_RCX[4] = 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ba3;
    fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar7));
    in_RCX[2] = 0;
    if (in_EDX == 0) {
        iVar5 = in_RCX[8];
        if ((iVar5 != 0) && (*(int32_t *)(iVar5 + 0x10) == 0)) {
            LOCK();
            piVar2 = (int32_t *)(iVar5 + 0x70);
            iVar6 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar6 < 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215bd3;
                fcn.180210740();
            }
        }
        in_RCX[8] = 0;
        *in_RCX = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215be7;
        fcn.180244fc0(in_RCX, 0x48);
    }
    return 1;
}

// ============================================================
// Function: FUN_180215ac1
// Address: 0x180215ac1
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180215aa0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    code *pcVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180215ab0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == (undefined8 *)0x0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ad5;
    iVar6 = fcn.18020f740();
    if (iVar6 == 0) {
        uVar3 = in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ae5;
        fcn.180258be0(uVar3);
        in_RCX[5] = 0;
    }
    piVar1 = in_RCX + 1;
    if (in_RCX[7] != 0) {
        if ((*piVar1 != 0) && (pcVar4 = *(code **)(*piVar1 + 0xa8), pcVar4 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b0c;
            (*pcVar4)();
        }
        in_RCX[7] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b1d;
        fcn.18020f6d0(in_RCX, 2);
    }
    iVar5 = *piVar1;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RSI;
        if (*(int64_t *)(iVar5 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b40;
            iVar6 = fcn.18020f740(in_RCX, 2);
            if (iVar6 == 0) {
                pcVar4 = *(code **)(*piVar1 + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b50;
                (*pcVar4)(in_RCX);
            }
        }
        if ((in_RCX[4] != 0) && (0 < *(int32_t *)(*piVar1 + 0x44))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b70;
            iVar6 = fcn.18020f740(in_RCX, 4);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b91;
                fcn.180224b90(*(int64_t *)((int64_t)&iStackX_18 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                in_RCX[4] = 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ba3;
    fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar7));
    in_RCX[2] = 0;
    if (in_EDX == 0) {
        iVar5 = in_RCX[8];
        if ((iVar5 != 0) && (*(int32_t *)(iVar5 + 0x10) == 0)) {
            LOCK();
            piVar2 = (int32_t *)(iVar5 + 0x70);
            iVar6 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar6 < 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215bd3;
                fcn.180210740();
            }
        }
        in_RCX[8] = 0;
        *in_RCX = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215be7;
        fcn.180244fc0(in_RCX, 0x48);
    }
    return 1;
}

// ============================================================
// Function: FUN_180215b25
// Address: 0x180215b25
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180215aa0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    code *pcVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180215ab0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == (undefined8 *)0x0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ad5;
    iVar6 = fcn.18020f740();
    if (iVar6 == 0) {
        uVar3 = in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ae5;
        fcn.180258be0(uVar3);
        in_RCX[5] = 0;
    }
    piVar1 = in_RCX + 1;
    if (in_RCX[7] != 0) {
        if ((*piVar1 != 0) && (pcVar4 = *(code **)(*piVar1 + 0xa8), pcVar4 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b0c;
            (*pcVar4)();
        }
        in_RCX[7] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b1d;
        fcn.18020f6d0(in_RCX, 2);
    }
    iVar5 = *piVar1;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RSI;
        if (*(int64_t *)(iVar5 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b40;
            iVar6 = fcn.18020f740(in_RCX, 2);
            if (iVar6 == 0) {
                pcVar4 = *(code **)(*piVar1 + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b50;
                (*pcVar4)(in_RCX);
            }
        }
        if ((in_RCX[4] != 0) && (0 < *(int32_t *)(*piVar1 + 0x44))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b70;
            iVar6 = fcn.18020f740(in_RCX, 4);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b91;
                fcn.180224b90(*(int64_t *)((int64_t)&iStackX_18 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                in_RCX[4] = 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ba3;
    fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar7));
    in_RCX[2] = 0;
    if (in_EDX == 0) {
        iVar5 = in_RCX[8];
        if ((iVar5 != 0) && (*(int32_t *)(iVar5 + 0x10) == 0)) {
            LOCK();
            piVar2 = (int32_t *)(iVar5 + 0x70);
            iVar6 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar6 < 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215bd3;
                fcn.180210740();
            }
        }
        in_RCX[8] = 0;
        *in_RCX = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215be7;
        fcn.180244fc0(in_RCX, 0x48);
    }
    return 1;
}

// ============================================================
// Function: FUN_180215b9a
// Address: 0x180215b9a
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180215aa0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    code *pcVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180215ab0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == (undefined8 *)0x0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ad5;
    iVar6 = fcn.18020f740();
    if (iVar6 == 0) {
        uVar3 = in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ae5;
        fcn.180258be0(uVar3);
        in_RCX[5] = 0;
    }
    piVar1 = in_RCX + 1;
    if (in_RCX[7] != 0) {
        if ((*piVar1 != 0) && (pcVar4 = *(code **)(*piVar1 + 0xa8), pcVar4 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b0c;
            (*pcVar4)();
        }
        in_RCX[7] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b1d;
        fcn.18020f6d0(in_RCX, 2);
    }
    iVar5 = *piVar1;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RSI;
        if (*(int64_t *)(iVar5 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b40;
            iVar6 = fcn.18020f740(in_RCX, 2);
            if (iVar6 == 0) {
                pcVar4 = *(code **)(*piVar1 + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b50;
                (*pcVar4)(in_RCX);
            }
        }
        if ((in_RCX[4] != 0) && (0 < *(int32_t *)(*piVar1 + 0x44))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b70;
            iVar6 = fcn.18020f740(in_RCX, 4);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b91;
                fcn.180224b90(*(int64_t *)((int64_t)&iStackX_18 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                in_RCX[4] = 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ba3;
    fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar7));
    in_RCX[2] = 0;
    if (in_EDX == 0) {
        iVar5 = in_RCX[8];
        if ((iVar5 != 0) && (*(int32_t *)(iVar5 + 0x10) == 0)) {
            LOCK();
            piVar2 = (int32_t *)(iVar5 + 0x70);
            iVar6 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar6 < 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215bd3;
                fcn.180210740();
            }
        }
        in_RCX[8] = 0;
        *in_RCX = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215be7;
        fcn.180244fc0(in_RCX, 0x48);
    }
    return 1;
}

// ============================================================
// Function: FUN_180215bb0
// Address: 0x180215bb0
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180215aa0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    code *pcVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180215ab0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == (undefined8 *)0x0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ad5;
    iVar6 = fcn.18020f740();
    if (iVar6 == 0) {
        uVar3 = in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ae5;
        fcn.180258be0(uVar3);
        in_RCX[5] = 0;
    }
    piVar1 = in_RCX + 1;
    if (in_RCX[7] != 0) {
        if ((*piVar1 != 0) && (pcVar4 = *(code **)(*piVar1 + 0xa8), pcVar4 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b0c;
            (*pcVar4)();
        }
        in_RCX[7] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b1d;
        fcn.18020f6d0(in_RCX, 2);
    }
    iVar5 = *piVar1;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RSI;
        if (*(int64_t *)(iVar5 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b40;
            iVar6 = fcn.18020f740(in_RCX, 2);
            if (iVar6 == 0) {
                pcVar4 = *(code **)(*piVar1 + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b50;
                (*pcVar4)(in_RCX);
            }
        }
        if ((in_RCX[4] != 0) && (0 < *(int32_t *)(*piVar1 + 0x44))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b70;
            iVar6 = fcn.18020f740(in_RCX, 4);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b91;
                fcn.180224b90(*(int64_t *)((int64_t)&iStackX_18 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                in_RCX[4] = 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ba3;
    fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar7));
    in_RCX[2] = 0;
    if (in_EDX == 0) {
        iVar5 = in_RCX[8];
        if ((iVar5 != 0) && (*(int32_t *)(iVar5 + 0x10) == 0)) {
            LOCK();
            piVar2 = (int32_t *)(iVar5 + 0x70);
            iVar6 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar6 < 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215bd3;
                fcn.180210740();
            }
        }
        in_RCX[8] = 0;
        *in_RCX = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215be7;
        fcn.180244fc0(in_RCX, 0x48);
    }
    return 1;
}

// ============================================================
// Function: FUN_180215bfc
// Address: 0x180215bfc
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180215aa0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    code *pcVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180215ab0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX == (undefined8 *)0x0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ad5;
    iVar6 = fcn.18020f740();
    if (iVar6 == 0) {
        uVar3 = in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ae5;
        fcn.180258be0(uVar3);
        in_RCX[5] = 0;
    }
    piVar1 = in_RCX + 1;
    if (in_RCX[7] != 0) {
        if ((*piVar1 != 0) && (pcVar4 = *(code **)(*piVar1 + 0xa8), pcVar4 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b0c;
            (*pcVar4)();
        }
        in_RCX[7] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b1d;
        fcn.18020f6d0(in_RCX, 2);
    }
    iVar5 = *piVar1;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RSI;
        if (*(int64_t *)(iVar5 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b40;
            iVar6 = fcn.18020f740(in_RCX, 2);
            if (iVar6 == 0) {
                pcVar4 = *(code **)(*piVar1 + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b50;
                (*pcVar4)(in_RCX);
            }
        }
        if ((in_RCX[4] != 0) && (0 < *(int32_t *)(*piVar1 + 0x44))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b70;
            iVar6 = fcn.18020f740(in_RCX, 4);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215b91;
                fcn.180224b90(*(int64_t *)((int64_t)&iStackX_18 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                in_RCX[4] = 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215ba3;
    fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar7));
    in_RCX[2] = 0;
    if (in_EDX == 0) {
        iVar5 = in_RCX[8];
        if ((iVar5 != 0) && (*(int32_t *)(iVar5 + 0x10) == 0)) {
            LOCK();
            piVar2 = (int32_t *)(iVar5 + 0x70);
            iVar6 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar6 < 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215bd3;
                fcn.180210740();
            }
        }
        in_RCX[8] = 0;
        *in_RCX = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180215be7;
        fcn.180244fc0(in_RCX, 0x48);
    }
    return 1;
}

// ============================================================
// Function: FUN_180215c10
// Address: 0x180215c10
// Size: 49 bytes
// ============================================================
void fcn.180215c10(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_8;
    
    if (arg1 != 0) {
        uStack_8 = 0x180215c1f;
        iVar3 = fcn.18045a350();
        if (*(int32_t *)(arg1 + 0x10) == 0) {
            LOCK();
            piVar1 = (int32_t *)(arg1 + 0x70);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 < 2) {
                *(undefined8 *)((int64_t)&uStack_8 - iVar3) = 0x180215c3c;
                fcn.180210740();
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180215c50
// Address: 0x180215c50
// Size: 1312 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.180215c50(int64_t arg_28h, int64_t arg_38h, int64_t arg_160h)
{
    int32_t *piVar1;
    uint64_t uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int32_t *piVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    uint64_t in_RCX;
    int64_t in_RDX;
    undefined8 *puVar13;
    int64_t in_R8;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e0h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_8h;
    
    uStack_40 = 0x180215c6f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar9 = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar8);
    piVar1 = *(int32_t **)(in_RDX + 0x10);
    iVar7 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180215caa;
    piVar10 = (int32_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar8));
    if (piVar10 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802160df;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802160f7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                      *(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar8 + 0x10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180216109;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar8));
        goto code_r0x00018021610b;
    }
    piVar10[0x1c] = 1;
    *piVar10 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180215cd5;
    iVar6 = func_0x000180280fa0(in_R8, in_RCX & 0xffffffff, 0x1802167a0, piVar10);
    if ((iVar6 == 0) || (*piVar10 == -1)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180216091;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802160a9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                      *(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar8 + 0x10));
code_r0x0001802160ae:
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802160bb;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar8));
    } else {
        piVar10[0x14] = (int32_t)in_RCX;
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180215cf2;
        iVar11 = func_0x000180282210(in_RDX);
        *(int64_t *)(piVar10 + 0x16) = iVar11;
        if (iVar11 != 0) {
            *(undefined8 *)(piVar10 + 0x18) = *(undefined8 *)(in_RDX + 0x18);
            iVar6 = *piVar1;
            if (iVar6 == 0) {
code_r0x000180216037:
                if (*(int64_t *)(piVar10 + 0x28) == 0) {
code_r0x000180216044:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180216049;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180216061;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), *(int64_t *)((int64_t)&var_8h + iVar8)
                                  , *(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar8 + 0x10));
                    goto code_r0x0001802160ae;
                }
            } else {
                puVar13 = (undefined8 *)(piVar1 + 2);
                do {
    // switch table (15 cases) at 0x180216134
                    switch(iVar6) {
                    case 1:
                        if (*(int64_t *)(piVar10 + 0x1e) == 0) {
                            iVar7 = iVar7 + 1;
                            *(undefined8 *)(piVar10 + 0x1e) = *puVar13;
                        }
                        break;
                    case 2:
                        if (*(int64_t *)(piVar10 + 0x20) == 0) {
                            iVar7 = iVar7 + 1;
                            *(undefined8 *)(piVar10 + 0x20) = *puVar13;
                        }
                        break;
                    case 3:
                        if (*(int64_t *)(piVar10 + 0x22) == 0) {
                            iVar7 = iVar7 + 1;
                            *(undefined8 *)(piVar10 + 0x22) = *puVar13;
                        }
                        break;
                    case 4:
                        if (*(int64_t *)(piVar10 + 0x24) == 0) {
                            iVar7 = iVar7 + 1;
                            *(undefined8 *)(piVar10 + 0x24) = *puVar13;
                        }
                        break;
                    case 5:
                        if (*(int64_t *)(piVar10 + 0x28) == 0) {
                            *(undefined8 *)(piVar10 + 0x28) = *puVar13;
                        }
                        break;
                    case 6:
                        if (*(int64_t *)(piVar10 + 0x2a) == 0) {
                            iVar7 = iVar7 + 1;
                            *(undefined8 *)(piVar10 + 0x2a) = *puVar13;
                        }
                        break;
                    case 7:
                        if (*(int64_t *)(piVar10 + 0x2e) == 0) {
                            *(undefined8 *)(piVar10 + 0x2e) = *puVar13;
                        }
                        break;
                    case 8:
                        if (*(int64_t *)(piVar10 + 0x30) == 0) {
                            *(undefined8 *)(piVar10 + 0x30) = *puVar13;
                        }
                        break;
                    case 9:
                        if (*(int64_t *)(piVar10 + 0x32) == 0) {
                            *(undefined8 *)(piVar10 + 0x32) = *puVar13;
                        }
                        break;
                    case 10:
                        if (*(int64_t *)(piVar10 + 0x34) == 0) {
                            *(undefined8 *)(piVar10 + 0x34) = *puVar13;
                        }
                        break;
                    case 0xb:
                        if (*(int64_t *)(piVar10 + 0x36) == 0) {
                            *(undefined8 *)(piVar10 + 0x36) = *puVar13;
                        }
                        break;
                    case 0xc:
                        if (*(int64_t *)(piVar10 + 0x38) == 0) {
                            *(undefined8 *)(piVar10 + 0x38) = *puVar13;
                        }
                        break;
                    case 0xd:
                        if (*(int64_t *)(piVar10 + 0x3a) == 0) {
                            *(undefined8 *)(piVar10 + 0x3a) = *puVar13;
                        }
                        break;
                    case 0xe:
                        if (*(int64_t *)(piVar10 + 0x26) == 0) {
                            iVar7 = iVar7 + 1;
                            *(undefined8 *)(piVar10 + 0x26) = *puVar13;
                        }
                        break;
                    case 0xf:
                        if (*(int64_t *)(piVar10 + 0x2c) == 0) {
                            *(undefined8 *)(piVar10 + 0x2c) = *puVar13;
                        }
                    }
                    iVar6 = *(int32_t *)(puVar13 + 1);
                    puVar13 = puVar13 + 2;
                } while (iVar6 != 0);
                if (iVar7 == 0) goto code_r0x000180216037;
                if (1 < iVar7 - 5U) goto code_r0x000180216044;
            }
            if (in_R8 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180215ee5;
                iVar7 = func_0x00018027fb30(in_R8);
                if (iVar7 == 0) goto code_r0x0001802160bb;
            }
            *(int64_t *)(piVar10 + 0x1a) = in_R8;
            *(undefined4 *)((int64_t)&var_18h + iVar8) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar8 + 4) = 0;
            *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 0;
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180215f1b;
            puVar12 = (undefined4 *)
                      func_0x000180229cc0((int64_t)&stack0x00000000 + iVar8, 0x1804bb2e0, (int64_t)&var_8h + iVar8);
            uVar3 = puVar12[1];
            uVar4 = puVar12[2];
            uVar5 = puVar12[3];
            *(undefined4 *)((int64_t)&arg_28h + iVar8) = *puVar12;
            *(undefined4 *)((int64_t)&arg_28h + iVar8 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000030 + iVar8) = uVar4;
            *(undefined4 *)(&stack0x00000034 + iVar8) = uVar5;
            uVar3 = puVar12[5];
            uVar4 = puVar12[6];
            uVar5 = puVar12[7];
            *(undefined4 *)((int64_t)&arg_38h + iVar8) = puVar12[4];
            *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000040 + iVar8) = uVar4;
            *(undefined4 *)(&stack0x00000044 + iVar8) = uVar5;
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180215f4c;
            func_0x000180229cc0((int64_t)&stack0x00000000 + iVar8, 0x18063dcac, &stack0xfffffffffffffff0 + iVar8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180215f7b;
            func_0x000180229bc0((int64_t)&stack0x00000000 + iVar8, 0x1804bb8e0, (int64_t)&var_18h + iVar8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180215faa;
            func_0x000180229bc0((int64_t)&stack0x00000000 + iVar8, 0x1804bb8e8, (int64_t)&var_18h + iVar8 + 4);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180215fcd;
            func_0x000180229ba0((int64_t)&stack0x00000000 + iVar8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180215ff3;
            iVar7 = func_0x000180280850(piVar10, (int64_t)&arg_28h + iVar8);
            uVar2 = *(uint64_t *)(&stack0xfffffffffffffff0 + iVar8);
            if (((uVar2 < 0x80000000) && (*(uint64_t *)((int64_t)&var_8h + iVar8) < 0x80000000)) && (0 < iVar7)) {
                piVar10[0x10] = (int32_t)*(uint64_t *)((int64_t)&var_8h + iVar8);
                piVar10[2] = (int32_t)uVar2;
                if (*(int32_t *)((int64_t)&var_18h + iVar8) != 0) {
                    piVar10[3] = piVar10[3] | 2;
                }
                if (*(int32_t *)((int64_t)&var_18h + iVar8 + 4) != 0) {
                    piVar10[3] = piVar10[3] | 8;
                }
                goto code_r0x00018021610b;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18021606d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180216085;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                          *(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar8 + 0x10));
            goto code_r0x0001802160ae;
        }
    }
code_r0x0001802160bb:
    if (piVar10[4] == 0) {
        LOCK();
        piVar1 = piVar10 + 0x1c;
        iVar7 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar7 < 2) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802160d8;
            fcn.180210740(piVar10);
        }
    }
code_r0x00018021610b:
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180216117;
    func_0x000180459870(uVar9 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_180216170
// Address: 0x180216170
// Size: 215 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

undefined8 fcn.180214840(int64_t arg_28h, int64_t arg_38h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint32_t uVar1;
    uint32_t *puVar2;
    int32_t *piVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int32_t *piVar9;
    int32_t **in_RCX;
    int32_t *in_RDX;
    int32_t **ppiVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    undefined8 uVar12;
    int32_t *piVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 uStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180214850;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180214860;
    fcn.180215aa0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000050 + iVar6));
    piVar13 = (int32_t *)0x0;
    uVar12 = 0;
    uVar8 = *(undefined8 *)((int64_t)&arg_28h + iVar6);
    uVar11 = *(undefined8 *)((int64_t)&var_18h + iVar6);
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar6) = uVar11;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar6 + -8) = unaff_R12;
    *(undefined8 *)(&stack0x00000000 + iVar6) = unaff_R13;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180216187;
    iVar7 = fcn.18045a350(in_RCX, in_RDX, 0);
    iVar7 = -iVar7;
    piVar9 = (int32_t *)0x0;
    puVar2 = (uint32_t *)in_RCX[5];
    if (((puVar2 != (uint32_t *)0x0) && (uVar1 = *puVar2, (uVar1 & 0xc1f0) != 0)) && (*(int64_t *)(puVar2 + 0xc) != 0))
    {
        if (uVar1 == 0x80) {
            *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802161d1;
            uVar8 = func_0x00018025c290(in_RCX, 0, in_RDX);
            return uVar8;
        }
        if (uVar1 == 0x100) {
            *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802161ef;
            uVar8 = func_0x00018025cb80(in_RCX, 0, in_RDX);
            return uVar8;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802161f9;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216211;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216223;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216237;
    fcn.18020f580(in_RCX, 0x802);
    if (in_RDX == (int32_t *)0x0) {
        in_RDX = in_RCX[1];
        if (in_RDX == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216397;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802163af;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000048 + iVar7 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802163c1;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
            return 0;
        }
    } else {
        *in_RCX = in_RDX;
    }
    piVar3 = in_RCX[2];
    *(undefined8 *)((int64_t)&arg_68h + iVar7 + iVar6) = uVar8;
    *(undefined8 *)((int64_t)&arg_70h + iVar7 + iVar6) = unaff_R15;
    if (((piVar3 == (int32_t *)0x0) || (in_RCX[1] == (int32_t *)0x0)) || (*in_RDX != *in_RCX[1])) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216274;
        fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
        in_RCX[2] = (int32_t *)0x0;
        if (piVar13 == (int32_t *)0x0) {
            iVar5 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216288;
            piVar9 = (int32_t *)func_0x00018026ada0(iVar5);
            if (((in_RCX[2] != (int32_t *)0x0) || (piVar9 != (int32_t *)0x0)) ||
               (((*(uint32_t *)(in_RCX + 3) & 0x100) != 0 || (in_RDX[4] == 2)))) goto code_r0x000180216528;
            if (in_RCX[1] != (int32_t *)0x0) {
                if (*(int64_t *)(in_RCX[1] + 0xe) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802162d1;
                    iVar5 = fcn.18020f740(in_RCX, 2);
                    if (iVar5 == 0) {
                        pcVar4 = *(code **)(in_RCX[1] + 0xe);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802162e2;
                        (*pcVar4)(in_RCX);
                    }
                }
                if ((in_RCX[4] != (int32_t *)0x0) && (0 < in_RCX[1][0x11])) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802162ff;
                    fcn.18020f740(in_RCX, 4);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021631d;
                    fcn.180224b90(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                    in_RCX[4] = (int32_t *)0x0;
                }
            }
            if (in_RCX[1] == in_RDX) {
                if (*(int64_t *)(in_RDX + 0x1a) == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021633a;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                } else {
code_r0x000180216475:
                    if ((*(int64_t *)(in_RDX + 0x1a) != 0) && (in_RCX[8] != in_RDX)) {
                        if (in_RDX[4] == 0) {
                            LOCK();
                            in_RDX[0x1c] = in_RDX[0x1c] + 1;
                            UNLOCK();
                        }
                        piVar9 = in_RCX[8];
                        if ((piVar9 != (int32_t *)0x0) && (piVar9[4] == 0)) {
                            LOCK();
                            piVar9 = piVar9 + 0x1c;
                            iVar5 = *piVar9;
                            *piVar9 = *piVar9 + -1;
                            UNLOCK();
                            if (iVar5 < 2) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802164b3;
                                fcn.180210740();
                            }
                        }
                        in_RCX[8] = in_RDX;
                    }
                    piVar9 = in_RCX[7];
                    in_RCX[1] = in_RDX;
                    if (piVar9 == (int32_t *)0x0) {
                        uVar8 = *(undefined8 *)(in_RDX + 0x1a);
                        pcVar4 = *(code **)(in_RDX + 0x1e);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802164d0;
                        uVar8 = func_0x00018027e810(uVar8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802164d5;
                        piVar9 = (int32_t *)(*pcVar4)(uVar8);
                        in_RCX[7] = piVar9;
                        if (piVar9 == (int32_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802164e6;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                    }
                    pcVar4 = *(code **)(in_RCX[1] + 0x20);
                    if (pcVar4 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216523;
                        uVar8 = (*pcVar4)(piVar9, uVar12);
                        return uVar8;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021650c;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                }
code_r0x000180216346:
                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216352;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216364;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802163cd;
                iVar5 = fcn.180215910(in_RCX);
                if (iVar5 != 0) {
                    if (*(int64_t *)(in_RDX + 0x1a) == 0) {
                        if (*in_RDX != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802163e6;
                            func_0x00018022ccf0();
                        }
                        *(code **)((int64_t)&arg_28h + iVar7 + iVar6) = fcn.180215c10;
                        *(undefined8 *)((int64_t)&var_20h + iVar7 + iVar6) = 0x180215670;
                        *(code **)((int64_t)&var_18h + iVar7 + iVar6) = fcn.180215c50;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216429;
                        in_RDX = (int32_t *)
                                 fcn.180280c20(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                               *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                                               *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                               *(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                               *(int64_t *)(&stack0x000000a8 + iVar7 + iVar6), 
                                               *(int64_t *)(&stack0x000000b0 + iVar7 + iVar6), 
                                               *(int64_t *)(&stack0x000000b8 + iVar7 + iVar6));
                        if (in_RDX == (int32_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216436;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                        piVar9 = in_RCX[8];
                        if ((piVar9 != (int32_t *)0x0) && (piVar9[4] == 0)) {
                            LOCK();
                            piVar9 = piVar9 + 0x1c;
                            iVar5 = *piVar9;
                            *piVar9 = *piVar9 + -1;
                            UNLOCK();
                            if (iVar5 < 2) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021646c;
                                fcn.180210740();
                            }
                        }
                        in_RCX[8] = in_RDX;
                    }
                    goto code_r0x000180216475;
                }
            }
        } else {
code_r0x000180216528:
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216530;
            iVar5 = fcn.180215910(in_RCX);
            if (iVar5 != 0) {
                piVar3 = in_RCX[8];
                if (in_RCX[1] == piVar3) {
                    in_RCX[1] = (int32_t *)0x0;
                }
                if ((piVar3 != (int32_t *)0x0) && (piVar3[4] == 0)) {
                    LOCK();
                    piVar3 = piVar3 + 0x1c;
                    iVar5 = *piVar3;
                    *piVar3 = *piVar3 + -1;
                    UNLOCK();
                    if (iVar5 < 2) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021656f;
                        fcn.180210740();
                    }
                }
                in_RCX[8] = (int32_t *)0x0;
                if (in_RDX != (int32_t *)0x0) {
                    if (piVar13 == (int32_t *)0x0) {
                        if (piVar9 == (int32_t *)0x0) {
                            in_RCX[2] = (int32_t *)0x0;
                            goto code_r0x00018021660b;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021658d;
                        iVar5 = fcn.18026b010(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6));
                        piVar9 = piVar13;
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216596;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                    }
                    iVar5 = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165b9;
                    in_RDX = (int32_t *)func_0x00018026ad30(piVar9, iVar5);
                    if (in_RDX == (int32_t *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165c6;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165de;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165f0;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165f8;
                        fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                        goto code_r0x000180216364;
                    }
                    in_RCX[2] = piVar9;
                }
code_r0x00018021660b:
                ppiVar10 = in_RCX + 1;
                piVar9 = *ppiVar10;
                if (piVar9 != in_RDX) {
                    if (piVar9 != (int32_t *)0x0) {
                        if (*(int64_t *)(piVar9 + 0xe) != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216632;
                            iVar5 = fcn.18020f740(in_RCX, 2);
                            if (iVar5 == 0) {
                                pcVar4 = *(code **)(*ppiVar10 + 0xe);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216642;
                                (*pcVar4)(in_RCX);
                            }
                        }
                        if ((in_RCX[4] != (int32_t *)0x0) && (0 < (*ppiVar10)[0x11])) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216662;
                            fcn.18020f740(in_RCX, 4);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021667f;
                            fcn.180224b90(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                            in_RCX[4] = (int32_t *)0x0;
                        }
                    }
                    in_RCX[1] = in_RDX;
                    if (((*(uint32_t *)(in_RCX + 3) & 0x100) == 0) && (in_RDX[0x11] != 0)) {
                        in_RCX[6] = *(int32_t **)(in_RDX + 8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802166b3;
                        piVar9 = (int32_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6));
                        in_RCX[4] = piVar9;
                        if (piVar9 == (int32_t *)0x0) goto code_r0x000180216364;
                    }
                }
                goto code_r0x0001802166c0;
            }
        }
code_r0x000180216364:
        uVar8 = 0;
    } else {
code_r0x0001802166c0:
        puVar2 = (uint32_t *)in_RCX[5];
        if ((puVar2 != (uint32_t *)0x0) && (((*puVar2 & 0xc1f0) == 0 || (*(int64_t *)(puVar2 + 10) == 0)))) {
            *(int32_t ***)((int64_t)&var_20h + iVar7 + iVar6) = in_RCX;
            *(undefined4 *)((int64_t)&var_18h + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802166f5;
            iVar5 = func_0x000180258740(puVar2, 0xffffffff, 0xc1f0, 7);
            if ((iVar5 < 1) && (iVar5 != -2)) goto code_r0x000180216364;
        }
        if ((*(uint32_t *)(in_RCX + 3) & 0x100) == 0) {
            pcVar4 = *(code **)(in_RCX[1] + 6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216722;
            uVar8 = (*pcVar4)(in_RCX);
        } else {
            uVar8 = 1;
        }
    }
    return uVar8;
}

// ============================================================
// Function: FUN_180216247
// Address: 0x180216247
// Size: 297 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

undefined8 fcn.180214840(int64_t arg_28h, int64_t arg_38h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint32_t uVar1;
    uint32_t *puVar2;
    int32_t *piVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int32_t *piVar9;
    int32_t **in_RCX;
    int32_t *in_RDX;
    int32_t **ppiVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    undefined8 uVar12;
    int32_t *piVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 uStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180214850;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180214860;
    fcn.180215aa0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000050 + iVar6));
    piVar13 = (int32_t *)0x0;
    uVar12 = 0;
    uVar8 = *(undefined8 *)((int64_t)&arg_28h + iVar6);
    uVar11 = *(undefined8 *)((int64_t)&var_18h + iVar6);
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar6) = uVar11;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar6 + -8) = unaff_R12;
    *(undefined8 *)(&stack0x00000000 + iVar6) = unaff_R13;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180216187;
    iVar7 = fcn.18045a350(in_RCX, in_RDX, 0);
    iVar7 = -iVar7;
    piVar9 = (int32_t *)0x0;
    puVar2 = (uint32_t *)in_RCX[5];
    if (((puVar2 != (uint32_t *)0x0) && (uVar1 = *puVar2, (uVar1 & 0xc1f0) != 0)) && (*(int64_t *)(puVar2 + 0xc) != 0))
    {
        if (uVar1 == 0x80) {
            *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802161d1;
            uVar8 = func_0x00018025c290(in_RCX, 0, in_RDX);
            return uVar8;
        }
        if (uVar1 == 0x100) {
            *(undefined8 *)((int64_t)&var_18h + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802161ef;
            uVar8 = func_0x00018025cb80(in_RCX, 0, in_RDX);
            return uVar8;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802161f9;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216211;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216223;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216237;
    fcn.18020f580(in_RCX, 0x802);
    if (in_RDX == (int32_t *)0x0) {
        in_RDX = in_RCX[1];
        if (in_RDX == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216397;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802163af;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), *(int64_t *)(&stack0x00000048 + iVar7 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802163c1;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
            return 0;
        }
    } else {
        *in_RCX = in_RDX;
    }
    piVar3 = in_RCX[2];
    *(undefined8 *)((int64_t)&arg_68h + iVar7 + iVar6) = uVar8;
    *(undefined8 *)((int64_t)&arg_70h + iVar7 + iVar6) = unaff_R15;
    if (((piVar3 == (int32_t *)0x0) || (in_RCX[1] == (int32_t *)0x0)) || (*in_RDX != *in_RCX[1])) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216274;
        fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
        in_RCX[2] = (int32_t *)0x0;
        if (piVar13 == (int32_t *)0x0) {
            iVar5 = *in_RDX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216288;
            piVar9 = (int32_t *)func_0x00018026ada0(iVar5);
            if (((in_RCX[2] != (int32_t *)0x0) || (piVar9 != (int32_t *)0x0)) ||
               (((*(uint32_t *)(in_RCX + 3) & 0x100) != 0 || (in_RDX[4] == 2)))) goto code_r0x000180216528;
            if (in_RCX[1] != (int32_t *)0x0) {
                if (*(int64_t *)(in_RCX[1] + 0xe) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802162d1;
                    iVar5 = fcn.18020f740(in_RCX, 2);
                    if (iVar5 == 0) {
                        pcVar4 = *(code **)(in_RCX[1] + 0xe);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802162e2;
                        (*pcVar4)(in_RCX);
                    }
                }
                if ((in_RCX[4] != (int32_t *)0x0) && (0 < in_RCX[1][0x11])) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802162ff;
                    fcn.18020f740(in_RCX, 4);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021631d;
                    fcn.180224b90(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                    in_RCX[4] = (int32_t *)0x0;
                }
            }
            if (in_RCX[1] == in_RDX) {
                if (*(int64_t *)(in_RDX + 0x1a) == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021633a;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                } else {
code_r0x000180216475:
                    if ((*(int64_t *)(in_RDX + 0x1a) != 0) && (in_RCX[8] != in_RDX)) {
                        if (in_RDX[4] == 0) {
                            LOCK();
                            in_RDX[0x1c] = in_RDX[0x1c] + 1;
                            UNLOCK();
                        }
                        piVar9 = in_RCX[8];
                        if ((piVar9 != (int32_t *)0x0) && (piVar9[4] == 0)) {
                            LOCK();
                            piVar9 = piVar9 + 0x1c;
                            iVar5 = *piVar9;
                            *piVar9 = *piVar9 + -1;
                            UNLOCK();
                            if (iVar5 < 2) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802164b3;
                                fcn.180210740();
                            }
                        }
                        in_RCX[8] = in_RDX;
                    }
                    piVar9 = in_RCX[7];
                    in_RCX[1] = in_RDX;
                    if (piVar9 == (int32_t *)0x0) {
                        uVar8 = *(undefined8 *)(in_RDX + 0x1a);
                        pcVar4 = *(code **)(in_RDX + 0x1e);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802164d0;
                        uVar8 = func_0x00018027e810(uVar8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802164d5;
                        piVar9 = (int32_t *)(*pcVar4)(uVar8);
                        in_RCX[7] = piVar9;
                        if (piVar9 == (int32_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802164e6;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                    }
                    pcVar4 = *(code **)(in_RCX[1] + 0x20);
                    if (pcVar4 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216523;
                        uVar8 = (*pcVar4)(piVar9, uVar12);
                        return uVar8;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021650c;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                }
code_r0x000180216346:
                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216352;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216364;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802163cd;
                iVar5 = fcn.180215910(in_RCX);
                if (iVar5 != 0) {
                    if (*(int64_t *)(in_RDX + 0x1a) == 0) {
                        if (*in_RDX != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802163e6;
                            func_0x00018022ccf0();
                        }
                        *(code **)((int64_t)&arg_28h + iVar7 + iVar6) = fcn.180215c10;
                        *(undefined8 *)((int64_t)&var_20h + iVar7 + iVar6) = 0x180215670;
                        *(code **)((int64_t)&var_18h + iVar7 + iVar6) = fcn.180215c50;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216429;
                        in_RDX = (int32_t *)
                                 fcn.180280c20(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                               *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                                               *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                               *(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                               *(int64_t *)(&stack0x000000a8 + iVar7 + iVar6), 
                                               *(int64_t *)(&stack0x000000b0 + iVar7 + iVar6), 
                                               *(int64_t *)(&stack0x000000b8 + iVar7 + iVar6));
                        if (in_RDX == (int32_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216436;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                        piVar9 = in_RCX[8];
                        if ((piVar9 != (int32_t *)0x0) && (piVar9[4] == 0)) {
                            LOCK();
                            piVar9 = piVar9 + 0x1c;
                            iVar5 = *piVar9;
                            *piVar9 = *piVar9 + -1;
                            UNLOCK();
                            if (iVar5 < 2) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021646c;
                                fcn.180210740();
                            }
                        }
                        in_RCX[8] = in_RDX;
                    }
                    goto code_r0x000180216475;
                }
            }
        } else {
code_r0x000180216528:
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216530;
            iVar5 = fcn.180215910(in_RCX);
            if (iVar5 != 0) {
                piVar3 = in_RCX[8];
                if (in_RCX[1] == piVar3) {
                    in_RCX[1] = (int32_t *)0x0;
                }
                if ((piVar3 != (int32_t *)0x0) && (piVar3[4] == 0)) {
                    LOCK();
                    piVar3 = piVar3 + 0x1c;
                    iVar5 = *piVar3;
                    *piVar3 = *piVar3 + -1;
                    UNLOCK();
                    if (iVar5 < 2) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021656f;
                        fcn.180210740();
                    }
                }
                in_RCX[8] = (int32_t *)0x0;
                if (in_RDX != (int32_t *)0x0) {
                    if (piVar13 == (int32_t *)0x0) {
                        if (piVar9 == (int32_t *)0x0) {
                            in_RCX[2] = (int32_t *)0x0;
                            goto code_r0x00018021660b;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021658d;
                        iVar5 = fcn.18026b010(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6));
                        piVar9 = piVar13;
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216596;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                            goto code_r0x000180216346;
                        }
                    }
                    iVar5 = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165b9;
                    in_RDX = (int32_t *)func_0x00018026ad30(piVar9, iVar5);
                    if (in_RDX == (int32_t *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165c6;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165de;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000030 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165f0;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802165f8;
                        fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                        goto code_r0x000180216364;
                    }
                    in_RCX[2] = piVar9;
                }
code_r0x00018021660b:
                ppiVar10 = in_RCX + 1;
                piVar9 = *ppiVar10;
                if (piVar9 != in_RDX) {
                    if (piVar9 != (int32_t *)0x0) {
                        if (*(int64_t *)(piVar9 + 0xe) != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216632;
                            iVar5 = fcn.18020f740(in_RCX, 2);
                            if (iVar5 == 0) {
                                pcVar4 = *(code **)(*ppiVar10 + 0xe);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216642;
                                (*pcVar4)(in_RCX);
                            }
                        }
                        if ((in_RCX[4] != (int32_t *)0x0) && (0 < (*ppiVar10)[0x11])) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216662;
                            fcn.18020f740(in_RCX, 4);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x18021667f;
                            fcn.180224b90(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7 + iVar6));
                            in_RCX[4] = (int32_t *)0x0;
                        }
                    }
                    in_RCX[1] = in_RDX;
                    if (((*(uint32_t *)(in_RCX + 3) & 0x100) == 0) && (in_RDX[0x11] != 0)) {
                        in_RCX[6] = *(int32_t **)(in_RDX + 8);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802166b3;
                        piVar9 = (int32_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar7 + iVar6));
                        in_RCX[4] = piVar9;
                        if (piVar9 == (int32_t *)0x0) goto code_r0x000180216364;
                    }
                }
                goto code_r0x0001802166c0;
            }
        }
code_r0x000180216364:
        uVar8 = 0;
    } else {
code_r0x0001802166c0:
        puVar2 = (uint32_t *)in_RCX[5];
        if ((puVar2 != (uint32_t *)0x0) && (((*puVar2 & 0xc1f0) == 0 || (*(int64_t *)(puVar2 + 10) == 0)))) {
            *(int32_t ***)((int64_t)&var_20h + iVar7 + iVar6) = in_RCX;
            *(undefined4 *)((int64_t)&var_18h + iVar7 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x1802166f5;
            iVar5 = func_0x000180258740(puVar2, 0xffffffff, 0xc1f0, 7);
            if ((iVar5 < 1) && (iVar5 != -2)) goto code_r0x000180216364;
        }
        if ((*(uint32_t *)(in_RCX + 3) & 0x100) == 0) {
            pcVar4 = *(code **)(in_RCX[1] + 6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7 + iVar6) = 0x180216722;
            uVar8 = (*pcVar4)(in_RCX);
        } else {
            uVar8 = 1;
        }
    }
    return uVar8;
}

