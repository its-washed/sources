// Chunk 38 - 50 functions

// ============================================================
// Function: FUN_180086866
// Address: 0x180086866
// Size: 59 bytes
// ============================================================
void fcn.180086866(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t unaff_RDI;
    
    puVar1 = *(undefined8 **)(unaff_RDI + 0x40);
    uVar2 = fcn.18009a8e0();
    *puVar1 = uVar2;
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 6;
    *(int64_t *)(unaff_RDI + 0x40) = *(int64_t *)(unaff_RDI + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_1800868a1
// Address: 0x1800868a1
// Size: 24 bytes
// ============================================================
void fcn.1800868a1(void)
{
    code *pcVar1;
    
    fcn.180099450();
    fcn.180087960();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800868c0
// Address: 0x1800868c0
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800868c0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg2 != 0) {
        uVar5 = fcn.180498cd0(arg2);
        iVar1 = *(int64_t *)(arg1 + 0x20);
        if (*(uint64_t *)(iVar1 + 0x28) <= *(uint64_t *)(iVar1 + 0x30)) {
            (**(code **)0x180782658)(arg1, 1, uVar5, iVar1, unaff_RDI);
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            iVar4 = fcn.180085510(unaff_RBP);
            if (iVar4 == 0) {
                fcn.180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
        }
        puVar2 = *(undefined8 **)(arg1 + 0x40);
        uVar5 = fcn.18009a8e0(arg1, arg2, uVar5);
        *puVar2 = uVar5;
        *(undefined4 *)((int64_t)puVar2 + 0xc) = 6;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar4 = fcn.180085510(var_10h);
        if (iVar4 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    }
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_180086910
// Address: 0x180086910
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ffh
// WARNING: [rz-ghidra] Detected overlap for variable var_4fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_4f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_500h
// WARNING: [rz-ghidra] Detected overlap for variable var_494h
// WARNING: [rz-ghidra] Detected overlap for variable var_490h
// WARNING: [rz-ghidra] Detected overlap for variable var_46ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4c4h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4cch

void fcn.180086910(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStackY_258 [32];
    undefined auStack_228 [504];
    undefined8 uStack_30;
    uint64_t uStack_28;
    
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        uStack_30 = 0x18008693e;
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    uStack_28 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_258;
    fcn.1800102c0(arg1, arg2);
    fcn.180467554(0, arg3);
    puVar1 = *(undefined8 **)(arg1 + 0x40);
    uVar2 = fcn.180498cd0(auStack_228);
    uVar2 = fcn.18009a8e0(arg1, auStack_228, uVar2);
    *puVar1 = uVar2;
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 6;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        fcn.1800934a0(arg1, 1);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    fcn.180459870(uStack_28 ^ (uint64_t)auStackY_258);
    return;
}

// ============================================================
// Function: FUN_180086980
// Address: 0x180086980
// Size: 98 bytes
// ============================================================
void fcn.180086980(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar1 = *(int64_t *)(arg1 + 0x20);
    var_18h = arg3;
    var_20h = arg4;
    if (*(uint64_t *)(iVar1 + 0x28) <= *(uint64_t *)(iVar1 + 0x30)) {
        (**(code **)0x180782658)(arg1, CONCAT71((unkint7)((uint64_t)iVar1 >> 8), 1));
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    fcn.180099380(arg1, arg2, &var_18h);
    return;
}

// ============================================================
// Function: FUN_1800869f0
// Address: 0x1800869f0
// Size: 302 bytes
// ============================================================
void fcn.1800869f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t unaff_RBP;
    uint32_t uVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    
    uVar10 = (uint32_t)arg4;
    uVar11 = (uint64_t)(int32_t)uVar10;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar8 = fcn.180085510(unaff_RBP), iVar8 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x78)) {
        uVar12 = *(undefined8 *)(arg1 + 0x58);
    } else {
        uVar12 = *(undefined8 *)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x10);
    }
    iVar9 = func_0x0001800942b0(arg1, arg4 & 0xffffffff, uVar12);
    *(int64_t *)(iVar9 + 0x20) = arg2;
    *(int64_t *)(iVar9 + 0x28) = arg_28h - (int64_t)(int64_t *)(iVar9 + 0x28);
    *(int64_t *)(iVar9 + 0x30) = (iVar9 + 0x30) - arg3;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + uVar11 * -0x10;
    while (uVar10 != 0) {
        uVar10 = (int32_t)uVar11 - 1;
        uVar11 = (uint64_t)uVar10;
        puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 0x40) + (int64_t)(int32_t)uVar10 * 0x10);
        uVar5 = puVar1[1];
        uVar6 = puVar1[2];
        uVar7 = puVar1[3];
        puVar2 = (undefined4 *)(iVar9 + 0x38 + (int64_t)(int32_t)uVar10 * 0x10);
        *puVar2 = *puVar1;
        puVar2[1] = uVar5;
        puVar2[2] = uVar6;
        puVar2[3] = uVar7;
    }
    piVar3 = *(int64_t **)(arg1 + 0x40);
    *piVar3 = iVar9;
    *(undefined4 *)((int64_t)piVar3 + 0xc) = 8;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_180086b20
// Address: 0x180086b20
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180086b20(int64_t arg1, int64_t arg2)
{
    uint32_t *puVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(in_stack_00000010);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    puVar1 = *(uint32_t **)(arg1 + 0x40);
    *puVar1 = (uint32_t)((int32_t)arg2 != 0);
    puVar1[3] = 1;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_180086ba0
// Address: 0x180086ba0
// Size: 126 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180086ba0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(unaff_RSI);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = arg2;
    *(int32_t *)(piVar1 + 1) = (int32_t)arg3;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 2;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_180086c20
// Address: 0x180086c20
// Size: 155 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.180086c20(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(in_stack_00000010);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar4 = (*pcVar2)();
            return uVar4;
        }
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = arg1;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 10;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return (uint64_t)(*(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8) == arg1);
}

// ============================================================
// Function: FUN_180086cc0
// Address: 0x180086cc0
// Size: 108 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180086cc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    int64_t var_20h;
    undefined auStackY_58 [32];
    int64_t var_38h;
    undefined4 var_2ch;
    int64_t var_28h;
    int64_t in_stack_ffffffffffffffe0;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_58;
    iVar4 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar2 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar2 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            uVar6 = func_0x000180085370(arg1, arg2 & 0xffffffff);
        } else {
            uVar6 = (int64_t)iVar4 * 0x10 + *(int64_t *)(arg1 + 0x40);
        }
    } else {
        uVar6 = *(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar4 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar6) {
            uVar6 = *(uint64_t *)0x180782430;
        }
    }
    piVar5 = (int64_t *)(arg1 + 0x40);
    uVar3 = fcn.180498cd0(arg3);
    var_38h = fcn.18009a8e0(arg1, arg3, uVar3);
    var_2ch = 6;
    func_0x0001800a8490(arg1, uVar6, &var_38h, *piVar5);
    *piVar5 = *piVar5 + 0x10;
    fcn.180459870(var_28h ^ (uint64_t)auStackY_58);
    return;
}

// ============================================================
// Function: FUN_180086d2c
// Address: 0x180086d2c
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180086cc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    int64_t var_20h;
    undefined auStackY_58 [32];
    int64_t var_38h;
    undefined4 var_2ch;
    int64_t var_28h;
    int64_t in_stack_ffffffffffffffe0;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_58;
    iVar4 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar2 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar2 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            uVar6 = func_0x000180085370(arg1, arg2 & 0xffffffff);
        } else {
            uVar6 = (int64_t)iVar4 * 0x10 + *(int64_t *)(arg1 + 0x40);
        }
    } else {
        uVar6 = *(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar4 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar6) {
            uVar6 = *(uint64_t *)0x180782430;
        }
    }
    piVar5 = (int64_t *)(arg1 + 0x40);
    uVar3 = fcn.180498cd0(arg3);
    var_38h = fcn.18009a8e0(arg1, arg3, uVar3);
    var_2ch = 6;
    func_0x0001800a8490(arg1, uVar6, &var_38h, *piVar5);
    *piVar5 = *piVar5 + 0x10;
    fcn.180459870(var_28h ^ (uint64_t)auStackY_58);
    return;
}

// ============================================================
// Function: FUN_180086dd9
// Address: 0x180086dd9
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180086cc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    int64_t var_20h;
    undefined auStackY_58 [32];
    int64_t var_38h;
    undefined4 var_2ch;
    int64_t var_28h;
    int64_t in_stack_ffffffffffffffe0;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_58;
    iVar4 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar2 = fcn.180085510(in_stack_ffffffffffffffe0);
        if (iVar2 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            uVar6 = func_0x000180085370(arg1, arg2 & 0xffffffff);
        } else {
            uVar6 = (int64_t)iVar4 * 0x10 + *(int64_t *)(arg1 + 0x40);
        }
    } else {
        uVar6 = *(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar4 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar6) {
            uVar6 = *(uint64_t *)0x180782430;
        }
    }
    piVar5 = (int64_t *)(arg1 + 0x40);
    uVar3 = fcn.180498cd0(arg3);
    var_38h = fcn.18009a8e0(arg1, arg3, uVar3);
    var_2ch = 6;
    func_0x0001800a8490(arg1, uVar6, &var_38h, *piVar5);
    *piVar5 = *piVar5 + 0x10;
    fcn.180459870(var_28h ^ (uint64_t)auStackY_58);
    return;
}

// ============================================================
// Function: FUN_180086e00
// Address: 0x180086e00
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180086e00(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int64_t iVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    int64_t var_10h;
    int64_t var_20h;
    
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar7 = fcn.180085510(var_10h);
        if (iVar7 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            uVar10 = (*pcVar3)();
            return uVar10;
        }
    }
    iVar1 = *(int64_t *)(arg1 + 0x40);
    uVar8 = fcn.180498cd0(arg3);
    uVar8 = fcn.18009a8e0(arg1, arg3, uVar8);
    puVar9 = (undefined4 *)func_0x0001800a0e30(*(undefined8 *)(iVar1 + -0x10), uVar8);
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    uVar4 = puVar9[1];
    uVar5 = puVar9[2];
    uVar6 = puVar9[3];
    *puVar2 = *puVar9;
    puVar2[1] = uVar4;
    puVar2[2] = uVar5;
    puVar2[3] = uVar6;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return (uint64_t)*(uint32_t *)(*(int64_t *)(arg1 + 0x40) + -4);
}

// ============================================================
// Function: FUN_180086e58
// Address: 0x180086e58
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180086e00(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int64_t iVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    int64_t var_10h;
    int64_t var_20h;
    
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar7 = fcn.180085510(var_10h);
        if (iVar7 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            uVar10 = (*pcVar3)();
            return uVar10;
        }
    }
    iVar1 = *(int64_t *)(arg1 + 0x40);
    uVar8 = fcn.180498cd0(arg3);
    uVar8 = fcn.18009a8e0(arg1, arg3, uVar8);
    puVar9 = (undefined4 *)func_0x0001800a0e30(*(undefined8 *)(iVar1 + -0x10), uVar8);
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    uVar4 = puVar9[1];
    uVar5 = puVar9[2];
    uVar6 = puVar9[3];
    *puVar2 = *puVar9;
    puVar2[1] = uVar4;
    puVar2[2] = uVar5;
    puVar2[3] = uVar6;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return (uint64_t)*(uint32_t *)(*(int64_t *)(arg1 + 0x40) + -4);
}

// ============================================================
// Function: FUN_180086ea9
// Address: 0x180086ea9
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180086e00(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int64_t iVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    int64_t var_10h;
    int64_t var_20h;
    
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar7 = fcn.180085510(var_10h);
        if (iVar7 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            uVar10 = (*pcVar3)();
            return uVar10;
        }
    }
    iVar1 = *(int64_t *)(arg1 + 0x40);
    uVar8 = fcn.180498cd0(arg3);
    uVar8 = fcn.18009a8e0(arg1, arg3, uVar8);
    puVar9 = (undefined4 *)func_0x0001800a0e30(*(undefined8 *)(iVar1 + -0x10), uVar8);
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    uVar4 = puVar9[1];
    uVar5 = puVar9[2];
    uVar6 = puVar9[3];
    *puVar2 = *puVar9;
    puVar2[1] = uVar4;
    puVar2[2] = uVar5;
    puVar2[3] = uVar6;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return (uint64_t)*(uint32_t *)(*(int64_t *)(arg1 + 0x40) + -4);
}

// ============================================================
// Function: FUN_180086ed0
// Address: 0x180086ed0
// Size: 243 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.180086ed0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined8 *puVar7;
    undefined4 *puVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int64_t *piVar11;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar10 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar6 = fcn.180085510(unaff_RSI);
        if (iVar6 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar9 = (*pcVar2)();
            return uVar9;
        }
    }
    if (iVar10 < 1) {
        if (iVar10 < -9999) {
            puVar7 = (undefined8 *)func_0x000180085370(arg1, arg2 & 0xffffffff);
        } else {
            puVar7 = (undefined8 *)((int64_t)iVar10 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        puVar7 = (undefined8 *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar10 * 0x10);
        if (*(undefined8 **)(arg1 + 0x40) <= puVar7) {
            puVar7 = *(undefined8 **)0x180782430;
        }
    }
    piVar11 = (int64_t *)(arg1 + 0x40);
    puVar8 = (undefined4 *)func_0x0001800a0d50(*puVar7, arg3 & 0xffffffff);
    puVar1 = (undefined4 *)*piVar11;
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *puVar1 = *puVar8;
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    *piVar11 = *piVar11 + 0x10;
    return (uint64_t)*(uint32_t *)(*piVar11 + -4);
}

// ============================================================
// Function: FUN_180086fd0
// Address: 0x180086fd0
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180086fd0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int64_t unaff_RBP;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(unaff_RBP);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    puVar1 = *(undefined8 **)(arg1 + 0x40);
    uVar4 = func_0x0001800a09e0(arg1, arg2 & 0xffffffff, arg3 & 0xffffffff);
    *puVar1 = uVar4;
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 7;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_180087045
// Address: 0x180087045
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180086fd0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int64_t unaff_RBP;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(unaff_RBP);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    puVar1 = *(undefined8 **)(arg1 + 0x40);
    uVar4 = func_0x0001800a09e0(arg1, arg2 & 0xffffffff, arg3 & 0xffffffff);
    *puVar1 = uVar4;
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 7;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_18008707f
// Address: 0x18008707f
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180086fd0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int64_t unaff_RBP;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(unaff_RBP);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    puVar1 = *(undefined8 **)(arg1 + 0x40);
    uVar4 = func_0x0001800a09e0(arg1, arg2 & 0xffffffff, arg3 & 0xffffffff);
    *puVar1 = uVar4;
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 7;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_1800870a0
// Address: 0x1800870a0
// Size: 116 bytes
// ============================================================
void fcn.1800870a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    
    iVar3 = (int32_t)arg3;
    iVar2 = (int32_t)arg2;
    if (0 < iVar2) {
        piVar1 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar1) {
            piVar1 = *(int64_t **)0x180782430;
        }
        *(bool *)(*piVar1 + 4) = iVar3 != 0;
        return;
    }
    if (-10000 < iVar2) {
        *(bool *)(*(int64_t *)((int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40)) + 4) = iVar3 != 0;
        return;
    }
    piVar1 = (int64_t *)fcn.180085370();
    *(bool *)(*piVar1 + 4) = iVar3 != 0;
    return;
}

// ============================================================
// Function: FUN_180087120
// Address: 0x180087120
// Size: 303 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.180087120(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t **ppiVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    iVar5 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar2 = fcn.180085510(in_stack_00000010);
        if (iVar2 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            uVar4 = (*pcVar1)();
            return uVar4;
        }
    }
    if (iVar5 < 1) {
        if (iVar5 < -9999) {
            piVar3 = (int64_t *)fcn.180085370(arg1, arg2 & 0xffffffff);
        } else {
            piVar3 = (int64_t *)((int64_t)iVar5 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar3 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar5 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
            piVar3 = *(int64_t **)0x180782430;
        }
    }
    ppiVar6 = (int64_t **)(arg1 + 0x40);
    iVar5 = *(int32_t *)((int64_t)piVar3 + 0xc);
    if (iVar5 == 7) {
        iVar7 = *(int64_t *)(*piVar3 + 0x10);
    } else if (iVar5 == 9) {
        iVar7 = *(int64_t *)(*piVar3 + 8) + (int64_t)(int64_t *)(*piVar3 + 8);
    } else if (iVar5 == 0xd) {
        iVar7 = *(int64_t *)(*(int64_t *)(*piVar3 + 0x10) + 0x38);
    } else {
        iVar7 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x440 + (int64_t)iVar5 * 8);
    }
    if (iVar7 != 0) {
        piVar3 = *ppiVar6;
        *piVar3 = iVar7;
        *(undefined4 *)((int64_t)piVar3 + 0xc) = 7;
        *ppiVar6 = *ppiVar6 + 2;
    }
    return (uint64_t)(iVar7 != 0);
}

// ============================================================
// Function: FUN_180087250
// Address: 0x180087250
// Size: 273 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180087250(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    iVar6 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(in_stack_00000010);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    if (iVar6 < 1) {
        if (iVar6 < -9999) {
            piVar4 = (int64_t *)fcn.180085370(arg1, arg2 & 0xffffffff);
        } else {
            piVar4 = (int64_t *)((int64_t)iVar6 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar4 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar6 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
    }
    piVar7 = (int64_t *)(arg1 + 0x40);
    puVar1 = (undefined8 *)*piVar7;
    if (*(int32_t *)((int64_t)piVar4 + 0xc) == 8) {
        uVar5 = *(undefined8 *)(*piVar4 + 0x10);
    } else {
        if (*(int32_t *)((int64_t)piVar4 + 0xc) != 10) {
            *(undefined4 *)((int64_t)puVar1 + 0xc) = 0;
            *piVar7 = *piVar7 + 0x10;
            return;
        }
        uVar5 = *(undefined8 *)(*piVar4 + 0x58);
    }
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 7;
    *puVar1 = uVar5;
    *piVar7 = *piVar7 + 0x10;
    return;
}

// ============================================================
// Function: FUN_180087370
// Address: 0x180087370
// Size: 197 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180087370(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int32_t iVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    int64_t var_20h;
    undefined auStack_58 [32];
    int64_t var_38h;
    undefined4 var_2ch;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    iVar2 = (int32_t)arg2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            uVar3 = fcn.180085370();
        } else {
            uVar3 = (int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40);
        }
    } else {
        uVar3 = *(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar3) {
            uVar3 = *(uint64_t *)0x180782430;
        }
    }
    piVar4 = (int64_t *)(arg1 + 0x40);
    uVar1 = fcn.180498cd0(arg3);
    var_38h = fcn.18009a8e0(arg1, arg3, uVar1);
    var_2ch = 6;
    func_0x0001800a8680(arg1, uVar3, &var_38h, *piVar4 + -0x10);
    *piVar4 = *piVar4 + -0x10;
    fcn.180459870(var_28h ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_180087440
// Address: 0x180087440
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_4h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

void fcn.180087440(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    bool bVar11;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = (int32_t)arg2;
    if (iVar8 < 1) {
        if (iVar8 < -9999) {
            piVar10 = (int64_t *)fcn.180085370();
        } else {
            piVar10 = (int64_t *)((int64_t)iVar8 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar8 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
    }
    piVar9 = (int64_t *)(arg1 + 0x40);
    iVar1 = *piVar10;
    if (*(char *)(iVar1 + 4) == '\0') {
        iVar2 = *piVar9;
        piVar7 = (int64_t *)func_0x0001800a0ea0(iVar1, iVar2 + -0x20);
        bVar11 = piVar7 == *(int64_t **)0x180782430;
        *(undefined *)(iVar1 + 5) = 0;
        if (bVar11) {
            piVar7 = (int64_t *)func_0x0001800a0f90(arg1, iVar1, iVar2 + -0x20);
        }
        uVar4 = *(undefined4 *)(iVar2 + -0xc);
        uVar5 = *(undefined4 *)(iVar2 + -8);
        uVar6 = *(undefined4 *)(iVar2 + -4);
        *(undefined4 *)piVar7 = *(undefined4 *)(iVar2 + -0x10);
        *(undefined4 *)((int64_t)piVar7 + 4) = uVar4;
        *(undefined4 *)(piVar7 + 1) = uVar5;
        *(undefined4 *)((int64_t)piVar7 + 0xc) = uVar6;
        if (5 < *(int32_t *)(*piVar9 + -4)) {
            iVar1 = *piVar10;
            if (((*(uint8_t *)(iVar1 + 1) & 4) != 0) && ((*(uint8_t *)(*(int64_t *)(*piVar9 + -0x10) + 1) & 3) != 0)) {
                iVar2 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar2 + 0x59) == '\x02') {
                    func_0x000180094420();
                    *piVar9 = *piVar9 + -0x20;
                    return;
                }
                *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                *(undefined8 *)(iVar1 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                *(int64_t *)(iVar2 + 0x18) = iVar1;
            }
        }
        *piVar9 = *piVar9 + -0x20;
        return;
    }
    func_0x000180092f10(arg1);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800874a8
// Address: 0x1800874a8
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_4h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

void fcn.180087440(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    bool bVar11;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = (int32_t)arg2;
    if (iVar8 < 1) {
        if (iVar8 < -9999) {
            piVar10 = (int64_t *)fcn.180085370();
        } else {
            piVar10 = (int64_t *)((int64_t)iVar8 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar8 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
    }
    piVar9 = (int64_t *)(arg1 + 0x40);
    iVar1 = *piVar10;
    if (*(char *)(iVar1 + 4) == '\0') {
        iVar2 = *piVar9;
        piVar7 = (int64_t *)func_0x0001800a0ea0(iVar1, iVar2 + -0x20);
        bVar11 = piVar7 == *(int64_t **)0x180782430;
        *(undefined *)(iVar1 + 5) = 0;
        if (bVar11) {
            piVar7 = (int64_t *)func_0x0001800a0f90(arg1, iVar1, iVar2 + -0x20);
        }
        uVar4 = *(undefined4 *)(iVar2 + -0xc);
        uVar5 = *(undefined4 *)(iVar2 + -8);
        uVar6 = *(undefined4 *)(iVar2 + -4);
        *(undefined4 *)piVar7 = *(undefined4 *)(iVar2 + -0x10);
        *(undefined4 *)((int64_t)piVar7 + 4) = uVar4;
        *(undefined4 *)(piVar7 + 1) = uVar5;
        *(undefined4 *)((int64_t)piVar7 + 0xc) = uVar6;
        if (5 < *(int32_t *)(*piVar9 + -4)) {
            iVar1 = *piVar10;
            if (((*(uint8_t *)(iVar1 + 1) & 4) != 0) && ((*(uint8_t *)(*(int64_t *)(*piVar9 + -0x10) + 1) & 3) != 0)) {
                iVar2 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar2 + 0x59) == '\x02') {
                    func_0x000180094420();
                    *piVar9 = *piVar9 + -0x20;
                    return;
                }
                *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                *(undefined8 *)(iVar1 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                *(int64_t *)(iVar2 + 0x18) = iVar1;
            }
        }
        *piVar9 = *piVar9 + -0x20;
        return;
    }
    func_0x000180092f10(arg1);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800874f8
// Address: 0x1800874f8
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_4h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5h

void fcn.180087440(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    bool bVar11;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = (int32_t)arg2;
    if (iVar8 < 1) {
        if (iVar8 < -9999) {
            piVar10 = (int64_t *)fcn.180085370();
        } else {
            piVar10 = (int64_t *)((int64_t)iVar8 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar8 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
    }
    piVar9 = (int64_t *)(arg1 + 0x40);
    iVar1 = *piVar10;
    if (*(char *)(iVar1 + 4) == '\0') {
        iVar2 = *piVar9;
        piVar7 = (int64_t *)func_0x0001800a0ea0(iVar1, iVar2 + -0x20);
        bVar11 = piVar7 == *(int64_t **)0x180782430;
        *(undefined *)(iVar1 + 5) = 0;
        if (bVar11) {
            piVar7 = (int64_t *)func_0x0001800a0f90(arg1, iVar1, iVar2 + -0x20);
        }
        uVar4 = *(undefined4 *)(iVar2 + -0xc);
        uVar5 = *(undefined4 *)(iVar2 + -8);
        uVar6 = *(undefined4 *)(iVar2 + -4);
        *(undefined4 *)piVar7 = *(undefined4 *)(iVar2 + -0x10);
        *(undefined4 *)((int64_t)piVar7 + 4) = uVar4;
        *(undefined4 *)(piVar7 + 1) = uVar5;
        *(undefined4 *)((int64_t)piVar7 + 0xc) = uVar6;
        if (5 < *(int32_t *)(*piVar9 + -4)) {
            iVar1 = *piVar10;
            if (((*(uint8_t *)(iVar1 + 1) & 4) != 0) && ((*(uint8_t *)(*(int64_t *)(*piVar9 + -0x10) + 1) & 3) != 0)) {
                iVar2 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar2 + 0x59) == '\x02') {
                    func_0x000180094420();
                    *piVar9 = *piVar9 + -0x20;
                    return;
                }
                *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                *(undefined8 *)(iVar1 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                *(int64_t *)(iVar2 + 0x18) = iVar1;
            }
        }
        *piVar9 = *piVar9 + -0x20;
        return;
    }
    func_0x000180092f10(arg1);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180087560
// Address: 0x180087560
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180087560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar11 = arg3 & 0xffffffff;
    iVar8 = (int32_t)arg2;
    if (iVar8 < 1) {
        if (iVar8 < -9999) {
            piVar10 = (int64_t *)fcn.180085370();
        } else {
            piVar10 = (int64_t *)((int64_t)iVar8 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar8 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
    }
    piVar9 = (int64_t *)(arg1 + 0x40);
    if (*(char *)(*piVar10 + 4) == '\0') {
        iVar1 = *piVar9;
        puVar7 = (undefined4 *)func_0x0001800a1010(arg1, *piVar10, uVar11 & 0xffffffff);
        uVar4 = *(undefined4 *)(iVar1 + -0xc);
        uVar5 = *(undefined4 *)(iVar1 + -8);
        uVar6 = *(undefined4 *)(iVar1 + -4);
        *puVar7 = *(undefined4 *)(iVar1 + -0x10);
        puVar7[1] = uVar4;
        puVar7[2] = uVar5;
        puVar7[3] = uVar6;
        if (5 < *(int32_t *)(*piVar9 + -4)) {
            iVar1 = *piVar10;
            if (((*(uint8_t *)(iVar1 + 1) & 4) != 0) && ((*(uint8_t *)(*(int64_t *)(*piVar9 + -0x10) + 1) & 3) != 0)) {
                iVar2 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar2 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                    *(undefined8 *)(iVar1 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                    *(int64_t *)(iVar2 + 0x18) = iVar1;
                }
            }
        }
        *piVar9 = *piVar9 + -0x10;
        return;
    }
    func_0x000180092f10(arg1);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800875cd
// Address: 0x1800875cd
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180087560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar11 = arg3 & 0xffffffff;
    iVar8 = (int32_t)arg2;
    if (iVar8 < 1) {
        if (iVar8 < -9999) {
            piVar10 = (int64_t *)fcn.180085370();
        } else {
            piVar10 = (int64_t *)((int64_t)iVar8 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar8 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
    }
    piVar9 = (int64_t *)(arg1 + 0x40);
    if (*(char *)(*piVar10 + 4) == '\0') {
        iVar1 = *piVar9;
        puVar7 = (undefined4 *)func_0x0001800a1010(arg1, *piVar10, uVar11 & 0xffffffff);
        uVar4 = *(undefined4 *)(iVar1 + -0xc);
        uVar5 = *(undefined4 *)(iVar1 + -8);
        uVar6 = *(undefined4 *)(iVar1 + -4);
        *puVar7 = *(undefined4 *)(iVar1 + -0x10);
        puVar7[1] = uVar4;
        puVar7[2] = uVar5;
        puVar7[3] = uVar6;
        if (5 < *(int32_t *)(*piVar9 + -4)) {
            iVar1 = *piVar10;
            if (((*(uint8_t *)(iVar1 + 1) & 4) != 0) && ((*(uint8_t *)(*(int64_t *)(*piVar9 + -0x10) + 1) & 3) != 0)) {
                iVar2 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar2 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                    *(undefined8 *)(iVar1 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                    *(int64_t *)(iVar2 + 0x18) = iVar1;
                }
            }
        }
        *piVar9 = *piVar9 + -0x10;
        return;
    }
    func_0x000180092f10(arg1);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800875f2
// Address: 0x1800875f2
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180087560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar11 = arg3 & 0xffffffff;
    iVar8 = (int32_t)arg2;
    if (iVar8 < 1) {
        if (iVar8 < -9999) {
            piVar10 = (int64_t *)fcn.180085370();
        } else {
            piVar10 = (int64_t *)((int64_t)iVar8 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar8 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
    }
    piVar9 = (int64_t *)(arg1 + 0x40);
    if (*(char *)(*piVar10 + 4) == '\0') {
        iVar1 = *piVar9;
        puVar7 = (undefined4 *)func_0x0001800a1010(arg1, *piVar10, uVar11 & 0xffffffff);
        uVar4 = *(undefined4 *)(iVar1 + -0xc);
        uVar5 = *(undefined4 *)(iVar1 + -8);
        uVar6 = *(undefined4 *)(iVar1 + -4);
        *puVar7 = *(undefined4 *)(iVar1 + -0x10);
        puVar7[1] = uVar4;
        puVar7[2] = uVar5;
        puVar7[3] = uVar6;
        if (5 < *(int32_t *)(*piVar9 + -4)) {
            iVar1 = *piVar10;
            if (((*(uint8_t *)(iVar1 + 1) & 4) != 0) && ((*(uint8_t *)(*(int64_t *)(*piVar9 + -0x10) + 1) & 3) != 0)) {
                iVar2 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar2 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                    *(undefined8 *)(iVar1 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                    *(int64_t *)(iVar2 + 0x18) = iVar1;
                }
            }
        }
        *piVar9 = *piVar9 + -0x10;
        return;
    }
    func_0x000180092f10(arg1);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180087650
// Address: 0x180087650
// Size: 263 bytes
// ============================================================
undefined8 fcn.180087650(int64_t arg1, int64_t arg2)
{
    uint8_t uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    
    iVar4 = (int32_t)arg2;
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            piVar6 = (int64_t *)fcn.180085370();
        } else {
            piVar6 = (int64_t *)((int64_t)iVar4 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar4 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar5 = 0;
    if (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0) {
        iVar5 = *(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    }
    iVar4 = *(int32_t *)((int64_t)piVar6 + 0xc);
    if (iVar4 == 7) {
        if (*(char *)(*piVar6 + 4) != '\0') {
            func_0x000180092f10(arg1);
            pcVar2 = (code *)swi(3);
            uVar3 = (*pcVar2)();
            return uVar3;
        }
        *(int64_t *)(*piVar6 + 0x10) = iVar5;
    } else {
        if (iVar4 != 9) {
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x440 + (int64_t)iVar4 * 8) = iVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            return 1;
        }
        *(int64_t *)(*piVar6 + 8) = iVar5 - (int64_t)(int64_t *)(*piVar6 + 8);
    }
    if (iVar5 != 0) {
        uVar1 = *(uint8_t *)(*piVar6 + 1);
        if (((uVar1 & 4) != 0) && ((*(uint8_t *)(iVar5 + 1) & 3) != 0)) {
            if (2 < (uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U)) {
                *(uint8_t *)(*piVar6 + 1) = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | uVar1 & 0xf8;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                return 1;
            }
            func_0x000180094420();
        }
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    return 1;
}

// ============================================================
// Function: FUN_180087760
// Address: 0x180087760
// Size: 164 bytes
// ============================================================
uint64_t fcn.180087760(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    
    iVar2 = *(int64_t *)(arg1 + 0x40);
    if (*(int32_t *)(iVar2 + -0x14) == 8) {
        *(undefined8 *)(*(int64_t *)(iVar2 + -0x20) + 0x10) = *(undefined8 *)(iVar2 + -0x10);
    } else {
        if (*(int32_t *)(iVar2 + -0x14) != 10) {
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            return 0;
        }
        *(undefined8 *)(*(int64_t *)(iVar2 + -0x20) + 0x58) = *(undefined8 *)(iVar2 + -0x10);
    }
    uVar5 = 1;
    uVar1 = *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1);
    if (((uVar1 & 4) != 0) &&
       (iVar3 = *(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10), (*(uint8_t *)(iVar3 + 1) & 3) != 0)) {
        iVar4 = *(int64_t *)(arg1 + 0x20);
        if (2 < (uint8_t)(*(char *)(iVar4 + 0x59) - 1U)) {
            *(uint8_t *)(*(int64_t *)(iVar2 + -0x20) + 1) = *(uint8_t *)(iVar4 + 0x58) & 3 | uVar1 & 0xf8;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            return 1;
        }
        fcn.180094420(iVar4, iVar3);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    return uVar5 & 0xffffffff;
}

// ============================================================
// Function: FUN_180087810
// Address: 0x180087810
// Size: 126 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180087810(int64_t arg1, int64_t arg2)
{
    char cVar1;
    uint16_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    bool bVar6;
    bool bVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar10 = (int32_t)arg2 + 1;
    if ((((iVar10 < 1) && (*(char *)0x180777010 != '\0')) &&
        (**(uint64_t **)(arg1 + 0x18) < (uint64_t)((int64_t)-(int32_t)arg2 * 0x10 + *(int64_t *)(arg1 + 0x40)))) &&
       (iVar8 = fcn.180085510(var_10h), iVar8 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    iVar9 = *(int64_t *)(arg1 + 0x40) + (int64_t)iVar10 * -0x10;
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + 1;
    uVar2 = *(uint16_t *)(arg1 + 0x68);
    if (199 < uVar2) {
        if (uVar2 == 200) {
            fcn.180093000(arg1, 0x18063e0f0, 1, 0);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        if (0xe0 < uVar2) {
            fcn.1800931b0(arg1, 5);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
    }
    bVar6 = false;
    iVar3 = *(int64_t *)(arg1 + 0x18);
    iVar4 = *(int64_t *)(arg1 + 0x78);
    if (((iVar3 != iVar4) && (iVar11 = **(int64_t **)(iVar3 + 8), *(char *)(iVar11 + 3) != '\0')) &&
       (iVar11 + 0x28 + *(int64_t *)(iVar11 + 0x28) != 0)) {
        *(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + 1;
        bVar6 = true;
    }
    iVar11 = iVar9 - *(int64_t *)(arg1 + 0x38);
    fcn.180093530(arg1, iVar9, 1);
    cVar1 = *(char *)(arg1 + 3);
    if (((cVar1 == '\x01') || (cVar1 == '\x06')) || (cVar1 == '\x7f')) {
        bVar7 = true;
    } else {
        bVar7 = false;
    }
    if ((bVar6) && (*(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + -1, bVar7)) {
        *(int64_t *)((*(int64_t *)(arg1 + 0x78) - iVar4) + iVar3) = iVar11 + 0x10 + *(int64_t *)(arg1 + 0x38);
    }
    if (!bVar7) {
        *(int64_t *)(arg1 + 0x40) = iVar11 + 0x10 + *(int64_t *)(arg1 + 0x38);
    }
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + -1;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30) < *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28)) {
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001800936d2. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x180782658)(arg1, 1);
    return;
}

// ============================================================
// Function: FUN_1800878a0
// Address: 0x1800878a0
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800878a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    undefined4 in_stack_fffffffffffffff0;
    undefined4 in_stack_fffffffffffffff4;
    
    iVar3 = (int32_t)arg3;
    if ((((int32_t)arg2 + 1 < iVar3) && (*(char *)0x180777010 != '\0')) &&
       (**(uint64_t **)(arg1 + 0x18) <
        (uint64_t)((int64_t)((iVar3 - (int32_t)arg2) + -1) * 0x10 + *(int64_t *)(arg1 + 0x40)))) {
        iVar2 = fcn.180085510(CONCAT44(in_stack_fffffffffffffff4, in_stack_fffffffffffffff0));
        if (iVar2 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    fcn.180094080(0);
    if (iVar3 == -1) {
        if (**(uint64_t **)(arg1 + 0x18) <= *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180087960
// Address: 0x180087960
// Size: 15 bytes
// ============================================================
void fcn.180087960(undefined8 param_1)
{
    code *pcVar1;
    
    fcn.1800931b0(param_1, 2);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180087970
// Address: 0x180087970
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_7h

uint64_t fcn.180087970(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_30h;
    
    iVar14 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    uVar16 = 1;
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar9 = fcn.180085510(unaff_retaddr), iVar9 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (iVar14 < 1) {
        if (iVar14 < -9999) {
            piVar10 = (int64_t *)fcn.180085370(arg1, arg2 & 0xffffffff);
        } else {
            piVar10 = (int64_t *)((int64_t)iVar14 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar14 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    iVar4 = *piVar10;
    iVar14 = puVar3[-1];
    if (iVar14 == 0) {
        iVar9 = -1;
    } else {
        if (iVar14 == 3) {
            iVar9 = (int32_t)*(double *)(puVar3 + -4);
            if ((double)iVar9 != *(double *)(puVar3 + -4)) {
                iVar9 = -1;
            }
            if ((0 < iVar9) && (iVar9 <= *(int32_t *)(iVar4 + 8))) {
                iVar9 = iVar9 + -1;
                goto code_r0x000180087ae4;
            }
        }
        iVar12 = func_0x0001800a00a0(iVar4, puVar3 + -4);
        iVar9 = func_0x000180099200(iVar12 + 0x10, puVar3 + -4);
        while (iVar9 == 0) {
            uVar2 = *(uint32_t *)(iVar12 + 0x1c);
            if (((((uint8_t)uVar2 & 0xf) == 0xe) && (5 < iVar14)) &&
               (*(int64_t *)(iVar12 + 0x10) == *(int64_t *)(puVar3 + -4))) break;
            if ((uVar2 & 0xfffffff0) == 0) {
                fcn.180093000(arg1, 0x18063ea78);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar12 = iVar12 + ((int64_t)(int32_t)uVar2 >> 4) * 0x20;
            iVar9 = func_0x000180099200(iVar12 + 0x10, puVar3 + -4);
        }
        iVar9 = (int32_t)(iVar12 - *(int64_t *)(iVar4 + 0x28) >> 5) + *(int32_t *)(iVar4 + 8);
    }
code_r0x000180087ae4:
    iVar14 = *(int32_t *)(iVar4 + 8);
    iVar9 = iVar9 + 1;
    if (iVar9 < iVar14) {
        do {
            iVar12 = (int64_t)iVar9;
            iVar9 = iVar9 + 1;
            if (*(int32_t *)(*(int64_t *)(iVar4 + 0x20) + 0xc + iVar12 * 0x10) != 0) {
                puVar3[-1] = 3;
                *(double *)(puVar3 + -4) = (double)iVar9;
                puVar1 = (undefined4 *)(*(int64_t *)(iVar4 + 0x20) + iVar12 * 0x10);
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                *puVar3 = *puVar1;
                puVar3[1] = uVar6;
                puVar3[2] = uVar7;
                puVar3[3] = uVar8;
                goto code_r0x000180087b48;
            }
        } while (iVar9 < iVar14);
    }
    iVar15 = 1 << (*(uint8_t *)(iVar4 + 7) & 0x1f);
    iVar9 = iVar9 - iVar14;
    if (iVar9 < iVar15) {
        iVar12 = *(int64_t *)(iVar4 + 0x28);
        do {
            iVar13 = (int64_t)iVar9 * 0x20;
            if (*(int32_t *)(iVar13 + 0xc + iVar12) != 0) {
                *(undefined8 *)(puVar3 + -4) = *(undefined8 *)(iVar13 + 0x10 + iVar12);
                puVar3[-2] = *(undefined4 *)(iVar13 + 0x18 + iVar12);
                puVar3[-1] = *(uint32_t *)(iVar13 + 0x1c + iVar12) & 0xf;
                puVar1 = (undefined4 *)(iVar13 + *(int64_t *)(iVar4 + 0x28));
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                *puVar3 = *puVar1;
                puVar3[1] = uVar6;
                puVar3[2] = uVar7;
                puVar3[3] = uVar8;
                goto code_r0x000180087b48;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar15);
    }
    uVar16 = 0;
code_r0x000180087b48:
    *(uint64_t *)(arg1 + 0x40) = (uint64_t)uVar16 * 0x20 + *(int64_t *)(arg1 + 0x40) + -0x10;
    return (uint64_t)uVar16;
}

// ============================================================
// Function: FUN_1800879cf
// Address: 0x1800879cf
// Size: 426 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_7h

uint64_t fcn.180087970(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_30h;
    
    iVar14 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    uVar16 = 1;
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar9 = fcn.180085510(unaff_retaddr), iVar9 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (iVar14 < 1) {
        if (iVar14 < -9999) {
            piVar10 = (int64_t *)fcn.180085370(arg1, arg2 & 0xffffffff);
        } else {
            piVar10 = (int64_t *)((int64_t)iVar14 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar14 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    iVar4 = *piVar10;
    iVar14 = puVar3[-1];
    if (iVar14 == 0) {
        iVar9 = -1;
    } else {
        if (iVar14 == 3) {
            iVar9 = (int32_t)*(double *)(puVar3 + -4);
            if ((double)iVar9 != *(double *)(puVar3 + -4)) {
                iVar9 = -1;
            }
            if ((0 < iVar9) && (iVar9 <= *(int32_t *)(iVar4 + 8))) {
                iVar9 = iVar9 + -1;
                goto code_r0x000180087ae4;
            }
        }
        iVar12 = func_0x0001800a00a0(iVar4, puVar3 + -4);
        iVar9 = func_0x000180099200(iVar12 + 0x10, puVar3 + -4);
        while (iVar9 == 0) {
            uVar2 = *(uint32_t *)(iVar12 + 0x1c);
            if (((((uint8_t)uVar2 & 0xf) == 0xe) && (5 < iVar14)) &&
               (*(int64_t *)(iVar12 + 0x10) == *(int64_t *)(puVar3 + -4))) break;
            if ((uVar2 & 0xfffffff0) == 0) {
                fcn.180093000(arg1, 0x18063ea78);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar12 = iVar12 + ((int64_t)(int32_t)uVar2 >> 4) * 0x20;
            iVar9 = func_0x000180099200(iVar12 + 0x10, puVar3 + -4);
        }
        iVar9 = (int32_t)(iVar12 - *(int64_t *)(iVar4 + 0x28) >> 5) + *(int32_t *)(iVar4 + 8);
    }
code_r0x000180087ae4:
    iVar14 = *(int32_t *)(iVar4 + 8);
    iVar9 = iVar9 + 1;
    if (iVar9 < iVar14) {
        do {
            iVar12 = (int64_t)iVar9;
            iVar9 = iVar9 + 1;
            if (*(int32_t *)(*(int64_t *)(iVar4 + 0x20) + 0xc + iVar12 * 0x10) != 0) {
                puVar3[-1] = 3;
                *(double *)(puVar3 + -4) = (double)iVar9;
                puVar1 = (undefined4 *)(*(int64_t *)(iVar4 + 0x20) + iVar12 * 0x10);
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                *puVar3 = *puVar1;
                puVar3[1] = uVar6;
                puVar3[2] = uVar7;
                puVar3[3] = uVar8;
                goto code_r0x000180087b48;
            }
        } while (iVar9 < iVar14);
    }
    iVar15 = 1 << (*(uint8_t *)(iVar4 + 7) & 0x1f);
    iVar9 = iVar9 - iVar14;
    if (iVar9 < iVar15) {
        iVar12 = *(int64_t *)(iVar4 + 0x28);
        do {
            iVar13 = (int64_t)iVar9 * 0x20;
            if (*(int32_t *)(iVar13 + 0xc + iVar12) != 0) {
                *(undefined8 *)(puVar3 + -4) = *(undefined8 *)(iVar13 + 0x10 + iVar12);
                puVar3[-2] = *(undefined4 *)(iVar13 + 0x18 + iVar12);
                puVar3[-1] = *(uint32_t *)(iVar13 + 0x1c + iVar12) & 0xf;
                puVar1 = (undefined4 *)(iVar13 + *(int64_t *)(iVar4 + 0x28));
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                *puVar3 = *puVar1;
                puVar3[1] = uVar6;
                puVar3[2] = uVar7;
                puVar3[3] = uVar8;
                goto code_r0x000180087b48;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar15);
    }
    uVar16 = 0;
code_r0x000180087b48:
    *(uint64_t *)(arg1 + 0x40) = (uint64_t)uVar16 * 0x20 + *(int64_t *)(arg1 + 0x40) + -0x10;
    return (uint64_t)uVar16;
}

// ============================================================
// Function: FUN_180087b79
// Address: 0x180087b79
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_7h

uint64_t fcn.180087970(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_30h;
    
    iVar14 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    uVar16 = 1;
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar9 = fcn.180085510(unaff_retaddr), iVar9 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (iVar14 < 1) {
        if (iVar14 < -9999) {
            piVar10 = (int64_t *)fcn.180085370(arg1, arg2 & 0xffffffff);
        } else {
            piVar10 = (int64_t *)((int64_t)iVar14 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar14 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    iVar4 = *piVar10;
    iVar14 = puVar3[-1];
    if (iVar14 == 0) {
        iVar9 = -1;
    } else {
        if (iVar14 == 3) {
            iVar9 = (int32_t)*(double *)(puVar3 + -4);
            if ((double)iVar9 != *(double *)(puVar3 + -4)) {
                iVar9 = -1;
            }
            if ((0 < iVar9) && (iVar9 <= *(int32_t *)(iVar4 + 8))) {
                iVar9 = iVar9 + -1;
                goto code_r0x000180087ae4;
            }
        }
        iVar12 = func_0x0001800a00a0(iVar4, puVar3 + -4);
        iVar9 = func_0x000180099200(iVar12 + 0x10, puVar3 + -4);
        while (iVar9 == 0) {
            uVar2 = *(uint32_t *)(iVar12 + 0x1c);
            if (((((uint8_t)uVar2 & 0xf) == 0xe) && (5 < iVar14)) &&
               (*(int64_t *)(iVar12 + 0x10) == *(int64_t *)(puVar3 + -4))) break;
            if ((uVar2 & 0xfffffff0) == 0) {
                fcn.180093000(arg1, 0x18063ea78);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar12 = iVar12 + ((int64_t)(int32_t)uVar2 >> 4) * 0x20;
            iVar9 = func_0x000180099200(iVar12 + 0x10, puVar3 + -4);
        }
        iVar9 = (int32_t)(iVar12 - *(int64_t *)(iVar4 + 0x28) >> 5) + *(int32_t *)(iVar4 + 8);
    }
code_r0x000180087ae4:
    iVar14 = *(int32_t *)(iVar4 + 8);
    iVar9 = iVar9 + 1;
    if (iVar9 < iVar14) {
        do {
            iVar12 = (int64_t)iVar9;
            iVar9 = iVar9 + 1;
            if (*(int32_t *)(*(int64_t *)(iVar4 + 0x20) + 0xc + iVar12 * 0x10) != 0) {
                puVar3[-1] = 3;
                *(double *)(puVar3 + -4) = (double)iVar9;
                puVar1 = (undefined4 *)(*(int64_t *)(iVar4 + 0x20) + iVar12 * 0x10);
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                *puVar3 = *puVar1;
                puVar3[1] = uVar6;
                puVar3[2] = uVar7;
                puVar3[3] = uVar8;
                goto code_r0x000180087b48;
            }
        } while (iVar9 < iVar14);
    }
    iVar15 = 1 << (*(uint8_t *)(iVar4 + 7) & 0x1f);
    iVar9 = iVar9 - iVar14;
    if (iVar9 < iVar15) {
        iVar12 = *(int64_t *)(iVar4 + 0x28);
        do {
            iVar13 = (int64_t)iVar9 * 0x20;
            if (*(int32_t *)(iVar13 + 0xc + iVar12) != 0) {
                *(undefined8 *)(puVar3 + -4) = *(undefined8 *)(iVar13 + 0x10 + iVar12);
                puVar3[-2] = *(undefined4 *)(iVar13 + 0x18 + iVar12);
                puVar3[-1] = *(uint32_t *)(iVar13 + 0x1c + iVar12) & 0xf;
                puVar1 = (undefined4 *)(iVar13 + *(int64_t *)(iVar4 + 0x28));
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                *puVar3 = *puVar1;
                puVar3[1] = uVar6;
                puVar3[2] = uVar7;
                puVar3[3] = uVar8;
                goto code_r0x000180087b48;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar15);
    }
    uVar16 = 0;
code_r0x000180087b48:
    *(uint64_t *)(arg1 + 0x40) = (uint64_t)uVar16 * 0x20 + *(int64_t *)(arg1 + 0x40) + -0x10;
    return (uint64_t)uVar16;
}

// ============================================================
// Function: FUN_180087bcc
// Address: 0x180087bcc
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_7h

uint64_t fcn.180087970(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_30h;
    
    iVar14 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    uVar16 = 1;
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar9 = fcn.180085510(unaff_retaddr), iVar9 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (iVar14 < 1) {
        if (iVar14 < -9999) {
            piVar10 = (int64_t *)fcn.180085370(arg1, arg2 & 0xffffffff);
        } else {
            piVar10 = (int64_t *)((int64_t)iVar14 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar14 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    iVar4 = *piVar10;
    iVar14 = puVar3[-1];
    if (iVar14 == 0) {
        iVar9 = -1;
    } else {
        if (iVar14 == 3) {
            iVar9 = (int32_t)*(double *)(puVar3 + -4);
            if ((double)iVar9 != *(double *)(puVar3 + -4)) {
                iVar9 = -1;
            }
            if ((0 < iVar9) && (iVar9 <= *(int32_t *)(iVar4 + 8))) {
                iVar9 = iVar9 + -1;
                goto code_r0x000180087ae4;
            }
        }
        iVar12 = func_0x0001800a00a0(iVar4, puVar3 + -4);
        iVar9 = func_0x000180099200(iVar12 + 0x10, puVar3 + -4);
        while (iVar9 == 0) {
            uVar2 = *(uint32_t *)(iVar12 + 0x1c);
            if (((((uint8_t)uVar2 & 0xf) == 0xe) && (5 < iVar14)) &&
               (*(int64_t *)(iVar12 + 0x10) == *(int64_t *)(puVar3 + -4))) break;
            if ((uVar2 & 0xfffffff0) == 0) {
                fcn.180093000(arg1, 0x18063ea78);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar12 = iVar12 + ((int64_t)(int32_t)uVar2 >> 4) * 0x20;
            iVar9 = func_0x000180099200(iVar12 + 0x10, puVar3 + -4);
        }
        iVar9 = (int32_t)(iVar12 - *(int64_t *)(iVar4 + 0x28) >> 5) + *(int32_t *)(iVar4 + 8);
    }
code_r0x000180087ae4:
    iVar14 = *(int32_t *)(iVar4 + 8);
    iVar9 = iVar9 + 1;
    if (iVar9 < iVar14) {
        do {
            iVar12 = (int64_t)iVar9;
            iVar9 = iVar9 + 1;
            if (*(int32_t *)(*(int64_t *)(iVar4 + 0x20) + 0xc + iVar12 * 0x10) != 0) {
                puVar3[-1] = 3;
                *(double *)(puVar3 + -4) = (double)iVar9;
                puVar1 = (undefined4 *)(*(int64_t *)(iVar4 + 0x20) + iVar12 * 0x10);
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                *puVar3 = *puVar1;
                puVar3[1] = uVar6;
                puVar3[2] = uVar7;
                puVar3[3] = uVar8;
                goto code_r0x000180087b48;
            }
        } while (iVar9 < iVar14);
    }
    iVar15 = 1 << (*(uint8_t *)(iVar4 + 7) & 0x1f);
    iVar9 = iVar9 - iVar14;
    if (iVar9 < iVar15) {
        iVar12 = *(int64_t *)(iVar4 + 0x28);
        do {
            iVar13 = (int64_t)iVar9 * 0x20;
            if (*(int32_t *)(iVar13 + 0xc + iVar12) != 0) {
                *(undefined8 *)(puVar3 + -4) = *(undefined8 *)(iVar13 + 0x10 + iVar12);
                puVar3[-2] = *(undefined4 *)(iVar13 + 0x18 + iVar12);
                puVar3[-1] = *(uint32_t *)(iVar13 + 0x1c + iVar12) & 0xf;
                puVar1 = (undefined4 *)(iVar13 + *(int64_t *)(iVar4 + 0x28));
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                *puVar3 = *puVar1;
                puVar3[1] = uVar6;
                puVar3[2] = uVar7;
                puVar3[3] = uVar8;
                goto code_r0x000180087b48;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar15);
    }
    uVar16 = 0;
code_r0x000180087b48:
    *(uint64_t *)(arg1 + 0x40) = (uint64_t)uVar16 * 0x20 + *(int64_t *)(arg1 + 0x40) + -0x10;
    return (uint64_t)uVar16;
}

// ============================================================
// Function: FUN_180087be4
// Address: 0x180087be4
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_7h

uint64_t fcn.180087970(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_30h;
    
    iVar14 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    uVar16 = 1;
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar9 = fcn.180085510(unaff_retaddr), iVar9 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (iVar14 < 1) {
        if (iVar14 < -9999) {
            piVar10 = (int64_t *)fcn.180085370(arg1, arg2 & 0xffffffff);
        } else {
            piVar10 = (int64_t *)((int64_t)iVar14 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar14 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    iVar4 = *piVar10;
    iVar14 = puVar3[-1];
    if (iVar14 == 0) {
        iVar9 = -1;
    } else {
        if (iVar14 == 3) {
            iVar9 = (int32_t)*(double *)(puVar3 + -4);
            if ((double)iVar9 != *(double *)(puVar3 + -4)) {
                iVar9 = -1;
            }
            if ((0 < iVar9) && (iVar9 <= *(int32_t *)(iVar4 + 8))) {
                iVar9 = iVar9 + -1;
                goto code_r0x000180087ae4;
            }
        }
        iVar12 = func_0x0001800a00a0(iVar4, puVar3 + -4);
        iVar9 = func_0x000180099200(iVar12 + 0x10, puVar3 + -4);
        while (iVar9 == 0) {
            uVar2 = *(uint32_t *)(iVar12 + 0x1c);
            if (((((uint8_t)uVar2 & 0xf) == 0xe) && (5 < iVar14)) &&
               (*(int64_t *)(iVar12 + 0x10) == *(int64_t *)(puVar3 + -4))) break;
            if ((uVar2 & 0xfffffff0) == 0) {
                fcn.180093000(arg1, 0x18063ea78);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar12 = iVar12 + ((int64_t)(int32_t)uVar2 >> 4) * 0x20;
            iVar9 = func_0x000180099200(iVar12 + 0x10, puVar3 + -4);
        }
        iVar9 = (int32_t)(iVar12 - *(int64_t *)(iVar4 + 0x28) >> 5) + *(int32_t *)(iVar4 + 8);
    }
code_r0x000180087ae4:
    iVar14 = *(int32_t *)(iVar4 + 8);
    iVar9 = iVar9 + 1;
    if (iVar9 < iVar14) {
        do {
            iVar12 = (int64_t)iVar9;
            iVar9 = iVar9 + 1;
            if (*(int32_t *)(*(int64_t *)(iVar4 + 0x20) + 0xc + iVar12 * 0x10) != 0) {
                puVar3[-1] = 3;
                *(double *)(puVar3 + -4) = (double)iVar9;
                puVar1 = (undefined4 *)(*(int64_t *)(iVar4 + 0x20) + iVar12 * 0x10);
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                *puVar3 = *puVar1;
                puVar3[1] = uVar6;
                puVar3[2] = uVar7;
                puVar3[3] = uVar8;
                goto code_r0x000180087b48;
            }
        } while (iVar9 < iVar14);
    }
    iVar15 = 1 << (*(uint8_t *)(iVar4 + 7) & 0x1f);
    iVar9 = iVar9 - iVar14;
    if (iVar9 < iVar15) {
        iVar12 = *(int64_t *)(iVar4 + 0x28);
        do {
            iVar13 = (int64_t)iVar9 * 0x20;
            if (*(int32_t *)(iVar13 + 0xc + iVar12) != 0) {
                *(undefined8 *)(puVar3 + -4) = *(undefined8 *)(iVar13 + 0x10 + iVar12);
                puVar3[-2] = *(undefined4 *)(iVar13 + 0x18 + iVar12);
                puVar3[-1] = *(uint32_t *)(iVar13 + 0x1c + iVar12) & 0xf;
                puVar1 = (undefined4 *)(iVar13 + *(int64_t *)(iVar4 + 0x28));
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                *puVar3 = *puVar1;
                puVar3[1] = uVar6;
                puVar3[2] = uVar7;
                puVar3[3] = uVar8;
                goto code_r0x000180087b48;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar15);
    }
    uVar16 = 0;
code_r0x000180087b48:
    *(uint64_t *)(arg1 + 0x40) = (uint64_t)uVar16 * 0x20 + *(int64_t *)(arg1 + 0x40) + -0x10;
    return (uint64_t)uVar16;
}

// ============================================================
// Function: FUN_180087c00
// Address: 0x180087c00
// Size: 866 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180087c00(int64_t arg1, int64_t arg_28h, int64_t arg_40h, int64_t arg_48h)
{
    uint8_t uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined *puVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    int32_t iVar12;
    int64_t *piVar13;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_2b8 [32];
    int64_t var_298h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_238h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_2b8;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    uVar11 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) - 1;
    var_288h._0_4_ = 2;
    do {
        iVar12 = (int32_t)var_288h;
        var_280h = (int64_t)uVar11;
        uVar9 = 2;
        piVar7 = (int64_t *)((int64_t)(int32_t)uVar11 * 0x10 + *(int64_t *)(arg1 + 0x28));
        if ((*(int32_t *)((int64_t)piVar7 + -4) == 6) || (*(int32_t *)((int64_t)piVar7 + -4) == 3)) {
            if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
                if (*(int32_t *)((int64_t)piVar7 + 0xc) != 3) goto code_r0x000180087d11;
                iVar5 = func_0x000180098ac0(&var_270h, *piVar7);
                iVar5 = fcn.18009a8e0(arg1, &var_270h, iVar5 - (int64_t)&var_270h);
                *piVar7 = iVar5;
                *(undefined4 *)((int64_t)piVar7 + 0xc) = 6;
            }
            uVar8 = (uint64_t)*(uint32_t *)(*piVar7 + 0x14);
            if (*(uint32_t *)(*piVar7 + 0x14) == 0) {
                if (*(int32_t *)((int64_t)piVar7 + -4) != 6) {
                    func_0x0001800a8360(arg1, piVar7 + -2);
                }
            } else {
                uVar10 = 1;
                if (1 < iVar12) {
                    do {
                        iVar2 = *(int32_t *)((int64_t)piVar7 + uVar10 * -0x10 + 0xc);
                        if (iVar2 != 6) {
                            if (iVar2 != 3) break;
                            iVar5 = func_0x000180098ac0(&var_270h, piVar7[uVar10 * -2]);
                            iVar5 = fcn.18009a8e0(arg1, &var_270h, iVar5 - (int64_t)&var_270h);
                            piVar7[uVar10 * -2] = iVar5;
                            *(undefined4 *)((int64_t)piVar7 + uVar10 * -0x10 + 0xc) = 6;
                        }
                        if (0x40000000 - uVar8 < (uint64_t)*(uint32_t *)(piVar7[uVar10 * -2] + 0x14)) {
                            fcn.180093000(arg1, 0x18063dcf0);
                            pcVar4 = (code *)swi(3);
                            (*pcVar4)();
                            return;
                        }
                        uVar8 = uVar8 + *(uint32_t *)(piVar7[uVar10 * -2] + 0x14);
                        uVar11 = (int32_t)uVar10 + 1;
                        uVar10 = (uint64_t)uVar11;
                    } while ((int32_t)uVar11 < iVar12);
                }
                uVar9 = (uint32_t)uVar10;
                if (uVar8 < 0x200) {
                    puVar6 = (undefined *)0x0;
                    piVar13 = &var_238h;
                } else {
                    if (0x40000000 < uVar8) {
                        fcn.180098420(arg1);
                        pcVar4 = (code *)swi(3);
                        (*pcVar4)();
                        return;
                    }
                    puVar6 = (undefined *)fcn.180098710(arg1, uVar8 + 0x19, *(undefined *)(arg1 + 4));
                    uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
                    puVar6[2] = 6;
                    puVar6[1] = uVar1 & 3;
                    *puVar6 = *(undefined *)(arg1 + 4);
                    *(undefined4 *)(puVar6 + 4) = 0x8000ffff;
                    *(int32_t *)(puVar6 + 0x10) = -0x10 - (int32_t)puVar6;
                    piVar13 = (int64_t *)(puVar6 + 0x18);
                    *(int32_t *)(puVar6 + 0x14) = (int32_t)uVar8;
                    *(undefined8 *)(puVar6 + 8) = 0;
                }
                uVar8 = 0;
                var_278h = (int64_t)piVar13;
                uVar11 = uVar9;
                while (0 < (int32_t)uVar11) {
                    uVar3 = *(uint32_t *)(piVar7[uVar10 * -2 + 2] + 0x14);
                    fcn.180498030(piVar13, piVar7[uVar10 * -2 + 2] + 0x18, uVar3);
                    uVar8 = uVar8 + uVar3;
                    uVar11 = (int32_t)uVar10 - 1;
                    uVar10 = (uint64_t)uVar11;
                    piVar13 = (int64_t *)((int64_t)piVar13 + (uint64_t)uVar3);
                    iVar12 = (int32_t)var_288h;
                }
                if (uVar8 < 0x200) {
                    iVar5 = fcn.18009a8e0(arg1, var_278h, uVar8);
                } else {
                    iVar5 = func_0x00018009a7e0(arg1, puVar6);
                }
                uVar11 = (uint32_t)var_280h;
                *(undefined4 *)((int64_t)(piVar7 + (int64_t)(int32_t)uVar9 * -2 + 2) + 0xc) = 6;
                piVar7[(int64_t)(int32_t)uVar9 * -2 + 2] = iVar5;
            }
        } else {
code_r0x000180087d11:
            iVar5 = func_0x0001800a3b10(arg1, piVar7 + -2, 0x12);
            if ((*(int32_t *)(iVar5 + 0xc) == 0) &&
               (iVar5 = func_0x0001800a3b10(arg1, piVar7, 0x12), *(int32_t *)(iVar5 + 0xc) == 0)) {
                func_0x000180092d90(arg1, piVar7 + -2, piVar7);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            var_298h = (int64_t)piVar7;
            func_0x0001800a83e0(arg1, piVar7 + -2, iVar5, piVar7 + -2);
        }
        var_288h._0_4_ = iVar12 + (1 - uVar9);
        if ((int32_t)var_288h < 2) {
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            fcn.180459870(var_38h ^ (uint64_t)auStack_2b8);
            return;
        }
        uVar11 = uVar11 + (1 - uVar9);
    } while( true );
}

// ============================================================
// Function: FUN_180087f70
// Address: 0x180087f70
// Size: 195 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180087f70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(unaff_RSI);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            iVar4 = (*pcVar2)();
            return iVar4;
        }
    }
    iVar4 = func_0x0001800a3c80(arg1, arg2, arg3 & 0xffffffff);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = iVar4;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 9;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return iVar4 + 0x10;
}

// ============================================================
// Function: FUN_180088040
// Address: 0x180088040
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined * fcn.180088040(int64_t arg1, int64_t arg2)
{
    uint8_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined *puVar5;
    int64_t iVar6;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar4 = fcn.180085510(unaff_RBX);
        if (iVar4 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            puVar5 = (undefined *)(*pcVar3)();
            return puVar5;
        }
    }
    if ((uint64_t)arg2 < 0x40000001) {
        iVar6 = arg2;
        if ((uint64_t)arg2 < 8) {
            iVar6 = 8;
        }
        puVar5 = (undefined *)fcn.180098710(arg1, iVar6 + 8, *(undefined *)(arg1 + 4));
        uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
        puVar5[2] = 0xb;
        puVar5[1] = uVar1 & 3;
        *puVar5 = *(undefined *)(arg1 + 4);
        *(int32_t *)(puVar5 + 4) = (int32_t)arg2;
        func_0x0001804986e0(puVar5 + 8, 0);
        puVar2 = *(undefined8 **)(arg1 + 0x40);
        *puVar2 = puVar5;
        *(undefined4 *)((int64_t)puVar2 + 0xc) = 0xb;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return puVar5 + 8;
    }
    fcn.180098420(arg1);
    pcVar3 = (code *)swi(3);
    puVar5 = (undefined *)(*pcVar3)();
    return puVar5;
}

// ============================================================
// Function: FUN_1800880cf
// Address: 0x1800880cf
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined * fcn.180088040(int64_t arg1, int64_t arg2)
{
    uint8_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined *puVar5;
    int64_t iVar6;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar4 = fcn.180085510(unaff_RBX);
        if (iVar4 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            puVar5 = (undefined *)(*pcVar3)();
            return puVar5;
        }
    }
    if ((uint64_t)arg2 < 0x40000001) {
        iVar6 = arg2;
        if ((uint64_t)arg2 < 8) {
            iVar6 = 8;
        }
        puVar5 = (undefined *)fcn.180098710(arg1, iVar6 + 8, *(undefined *)(arg1 + 4));
        uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
        puVar5[2] = 0xb;
        puVar5[1] = uVar1 & 3;
        *puVar5 = *(undefined *)(arg1 + 4);
        *(int32_t *)(puVar5 + 4) = (int32_t)arg2;
        func_0x0001804986e0(puVar5 + 8, 0);
        puVar2 = *(undefined8 **)(arg1 + 0x40);
        *puVar2 = puVar5;
        *(undefined4 *)((int64_t)puVar2 + 0xc) = 0xb;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return puVar5 + 8;
    }
    fcn.180098420(arg1);
    pcVar3 = (code *)swi(3);
    puVar5 = (undefined *)(*pcVar3)();
    return puVar5;
}

// ============================================================
// Function: FUN_180088137
// Address: 0x180088137
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined * fcn.180088040(int64_t arg1, int64_t arg2)
{
    uint8_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined *puVar5;
    int64_t iVar6;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar4 = fcn.180085510(unaff_RBX);
        if (iVar4 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            puVar5 = (undefined *)(*pcVar3)();
            return puVar5;
        }
    }
    if ((uint64_t)arg2 < 0x40000001) {
        iVar6 = arg2;
        if ((uint64_t)arg2 < 8) {
            iVar6 = 8;
        }
        puVar5 = (undefined *)fcn.180098710(arg1, iVar6 + 8, *(undefined *)(arg1 + 4));
        uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
        puVar5[2] = 0xb;
        puVar5[1] = uVar1 & 3;
        *puVar5 = *(undefined *)(arg1 + 4);
        *(int32_t *)(puVar5 + 4) = (int32_t)arg2;
        func_0x0001804986e0(puVar5 + 8, 0);
        puVar2 = *(undefined8 **)(arg1 + 0x40);
        *puVar2 = puVar5;
        *(undefined4 *)((int64_t)puVar2 + 0xc) = 0xb;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return puVar5 + 8;
    }
    fcn.180098420(arg1);
    pcVar3 = (code *)swi(3);
    puVar5 = (undefined *)(*pcVar3)();
    return puVar5;
}

// ============================================================
// Function: FUN_180088160
// Address: 0x180088160
// Size: 385 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180088160(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int32_t iVar10;
    int64_t unaff_RSI;
    int64_t iVar11;
    int32_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar12 = (int32_t)arg3;
    iVar11 = (int64_t)iVar12;
    iVar10 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar8 = fcn.180085510(unaff_RSI), iVar8 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar4 = (code *)swi(3);
        iVar11 = (*pcVar4)();
        return iVar11;
    }
    if (iVar10 < 1) {
        if (iVar10 < -9999) {
            piVar9 = (int64_t *)fcn.180085370(arg1, arg2 & 0xffffffff);
        } else {
            piVar9 = (int64_t *)((int64_t)iVar10 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar10 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 8) {
        return 0;
    }
    iVar1 = *piVar9;
    if (*(char *)(iVar1 + 3) == '\0') {
        if (iVar12 < 1) {
            return 0;
        }
        iVar3 = *(int64_t *)(iVar1 + 0x20);
        if ((int32_t)(uint32_t)*(uint8_t *)(iVar3 + 6) < iVar12) {
            return 0;
        }
        piVar9 = (int64_t *)(iVar11 * 0x10 + 0x18 + iVar1);
        if (*(int32_t *)((int64_t)piVar9 + 0xc) == 0x10) {
            piVar9 = *(int64_t **)(*piVar9 + 8);
        }
        if (iVar12 <= *(int32_t *)(iVar3 + 0x94)) {
            iVar11 = *(int64_t *)((iVar11 * 8 - *(int64_t *)(iVar3 + 8)) + iVar3) + 0x18;
            if (iVar11 == 0) {
                return 0;
            }
            goto code_r0x000180088244;
        }
    } else {
        if (iVar12 < 1) {
            return 0;
        }
        if ((int32_t)(uint32_t)*(uint8_t *)(iVar1 + 4) < iVar12) {
            return 0;
        }
        piVar9 = (int64_t *)(iVar11 * 0x10 + 0x28 + iVar1);
    }
    iVar11 = 0x1805aadb1;
code_r0x000180088244:
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    uVar5 = *(undefined4 *)((int64_t)piVar9 + 4);
    uVar6 = *(undefined4 *)(piVar9 + 1);
    uVar7 = *(undefined4 *)((int64_t)piVar9 + 0xc);
    *puVar2 = *(undefined4 *)piVar9;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return iVar11;
}

// ============================================================
// Function: FUN_180088300
// Address: 0x180088300
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180088300(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    
    if (((*(uint64_t *)(arg1 + 0x78) < *(uint64_t *)(arg1 + 0x18)) &&
        (iVar2 = **(int64_t **)(*(uint64_t *)(arg1 + 0x18) + 8), iVar2 != 0)) && (*(char *)(iVar2 + 3) != '\0')) {
        iVar2 = (int64_t)(int64_t *)(iVar2 + 0x30) - *(int64_t *)(iVar2 + 0x30);
        if (iVar2 != 0) {
            iVar1 = fcn.180498f10(iVar2, 0x1806203d0);
            if (iVar1 == 0) {
                iVar2 = *(int64_t *)(arg1 + 8) + 0x18;
                if (*(int64_t *)(arg1 + 8) == 0) {
                    iVar2 = 0;
                }
                return iVar2;
            }
        }
    } else {
        iVar2 = 0;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180088380
// Address: 0x180088380
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180088380(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar2 = fcn.180088300(arg1);
    if (iVar2 != 0) {
        fcn.180088560(arg1, 0x18063d988, arg2 & 0xffffffffU, iVar2, arg3);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    fcn.180088560(arg1, 0x18063d968, arg2 & 0xffffffffU, arg3);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800883d0
// Address: 0x1800883d0
// Size: 154 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h

void fcn.1800883d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar2 = fcn.180088300(arg1);
    iVar3 = fcn.180085430(arg1, arg2 & 0xffffffff);
    if (iVar3 == 0) {
        if (iVar2 != 0) {
            fcn.180088560(arg1, 0x18063d9e8, arg2 & 0xffffffffU, iVar2, arg3);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        fcn.180088560(arg1, 0x18063d9c0, arg2 & 0xffffffffU, arg3);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar4 = fcn.1800a3c60(arg1, iVar3);
    if (iVar2 != 0) {
        fcn.180088560(arg1, 0x18063d930, arg2 & 0xffffffffU, iVar2, arg3, uVar4);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    fcn.180088560(arg1, 0x18063d900, arg2 & 0xffffffffU, arg3, uVar4);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180088470
// Address: 0x180088470
// Size: 33 bytes
// ============================================================
void fcn.180088470(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t arg3_00;
    uint64_t uVar2;
    
    uVar2 = arg2 & 0xffffffff;
    arg3_00 = fcn.180085d30(arg1, arg3 & 0xffffffff);
    fcn.1800883d0(arg1, uVar2 & 0xffffffff, arg3_00);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800884a0
// Address: 0x1800884a0
// Size: 192 bytes
// ============================================================
void fcn.1800884a0(int64_t arg1)
{
    int32_t iVar1;
    uint64_t uVar2;
    int32_t iVar3;
    undefined8 in_RDX;
    undefined auStack_178 [32];
    int64_t var_158h;
    int64_t var_140h;
    int64_t var_134h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_178;
    iVar1 = func_0x000180092a10(arg1, in_RDX, 0x18063d9b8, &var_158h);
    if ((iVar1 == 0) || ((int32_t)(uint32_t)var_134h < 1)) {
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar3 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
            iVar1 = iVar3 * 2;
            if (iVar3 < 1) {
                iVar1 = iVar3 + 1;
            }
            func_0x000180093240(arg1, iVar1, 0);
        }
        uVar2 = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (**(uint64_t **)(arg1 + 0x18) < uVar2) {
            **(uint64_t **)(arg1 + 0x18) = uVar2;
        }
        func_0x0001800867f0(arg1, 0x1805aadb1, 0);
    } else {
        fcn.180086980(arg1, 0x18063d9b0, var_140h, (uint64_t)(uint32_t)var_134h);
    }
    fcn.180459870(var_18h ^ (uint64_t)auStack_178);
    return;
}

