// Chunk 64 - 50 functions

// ============================================================
// Function: FUN_1800cd348
// Address: 0x1800cd348
// Size: 611 bytes
// ============================================================
undefined8
fcn.1800cd348(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h,
             int64_t arg_68h, int64_t arg_70h)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t *unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar15;
    uint64_t *puVar16;
    int64_t in_R11;
    uint64_t *unaff_R12;
    undefined8 unaff_R13;
    uint64_t uVar17;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_20h;
    
    *(undefined8 *)(in_R11 + 0x18) = unaff_RBX;
    *(undefined8 *)(in_R11 + -0x18) = unaff_RBP;
    *(undefined8 *)(in_R11 + -0x20) = unaff_RDI;
    *(undefined8 *)(in_R11 + -0x28) = unaff_R13;
    *(undefined8 *)(in_R11 + -0x30) = unaff_R14;
    *(undefined8 *)(in_R11 + -0x38) = unaff_R15;
    do {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        uVar4 = *unaff_R12;
        iVar9 = piVar3[1];
        if ((uint64_t)(iVar9 * 3) >> 2 <= (uint64_t)piVar3[2]) {
            unaff_RSI = (uint64_t *)arg_68h;
            if ((piVar3[2] != 0) && (uVar4 != piVar3[3])) {
                uVar11 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar12 = 0;
                do {
                    uVar11 = uVar11 & iVar9 - 1U;
                    uVar17 = *(uint64_t *)(*piVar3 + uVar11 * 0x18);
                    if (uVar17 == uVar4) goto code_r0x0001800cd515;
                    if (uVar17 == piVar3[3]) break;
                    uVar11 = uVar11 + 1 + uVar12;
                    uVar12 = uVar12 + 1;
                } while (uVar12 <= iVar9 - 1U);
            }
            uVar11 = piVar3[3];
            if (iVar9 == 0) {
                uVar12 = 0x10;
                iVar9 = func_0x000180459890(0x180);
                uVar13 = 0;
                iVar15 = iVar9;
                uVar17 = 0x10;
code_r0x0001800cd440:
                do {
                    iVar1 = uVar13 * 0x18;
                    uVar13 = uVar13 + 1;
                    *(int64_t *)(iVar1 + iVar15) = piVar3[3];
                    *(undefined (*) [16])(iVar1 + 8 + iVar15) = ZEXT816(0);
                    *(undefined8 *)(iVar1 + 8 + iVar15) = 0;
                    *(undefined2 *)(iVar1 + 0x10 + iVar15) = 0;
                } while (uVar13 < uVar12);
            } else {
                uVar12 = iVar9 * 2;
                if (uVar12 == 0) {
                    iVar9 = 0;
                    uVar17 = 0;
                } else {
                    iVar9 = func_0x000180459890(iVar9 * 0x30);
                    uVar13 = 0;
                    iVar15 = iVar9;
                    uVar17 = uVar12;
                    if (uVar12 != 0) goto code_r0x0001800cd440;
                }
            }
            uVar12 = 0;
            if (piVar3[1] != 0) {
                do {
                    iVar15 = uVar12 * 0x18;
                    uVar13 = *(uint64_t *)(iVar15 + *piVar3);
                    if (uVar13 != piVar3[3]) {
                        uVar10 = (uVar13 >> 5 ^ uVar13) >> 4;
                        uVar14 = 0;
                        do {
                            uVar10 = uVar10 & uVar17 - 1;
                            puVar16 = (uint64_t *)(iVar9 + uVar10 * 0x18);
                            uVar5 = *(uint64_t *)(iVar9 + uVar10 * 0x18);
                            if (uVar5 == uVar11) {
                                *puVar16 = uVar13;
                                goto code_r0x0001800cd4df;
                            }
                            if (uVar5 == uVar13) goto code_r0x0001800cd4df;
                            uVar10 = uVar10 + 1 + uVar14;
                            uVar14 = uVar14 + 1;
                        } while (uVar14 <= uVar17 - 1);
                        puVar16 = (uint64_t *)0x0;
code_r0x0001800cd4df:
                        iVar1 = *piVar3;
                        *puVar16 = *(uint64_t *)(iVar1 + iVar15);
                        puVar2 = (undefined4 *)(iVar1 + 8 + iVar15);
                        uVar6 = puVar2[1];
                        uVar7 = puVar2[2];
                        uVar8 = puVar2[3];
                        *(undefined4 *)(puVar16 + 1) = *puVar2;
                        *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
                        *(undefined4 *)(puVar16 + 2) = uVar7;
                        *(undefined4 *)((int64_t)puVar16 + 0x14) = uVar8;
                    }
                    uVar12 = uVar12 + 1;
                } while (uVar12 < (uint64_t)piVar3[1]);
            }
            iVar15 = *piVar3;
            *piVar3 = iVar9;
            piVar3[1] = uVar17;
            if (iVar15 != 0) {
                func_0x0001800f4640();
            }
        }
code_r0x0001800cd515:
        uVar11 = (uVar4 >> 5 ^ uVar4) >> 4;
        uVar12 = 0;
        do {
            uVar11 = uVar11 & piVar3[1] - 1U;
            puVar16 = (uint64_t *)(*piVar3 + uVar11 * 0x18);
            uVar17 = *(uint64_t *)(*piVar3 + uVar11 * 0x18);
            if (uVar17 == piVar3[3]) {
                *puVar16 = uVar4;
                piVar3[2] = piVar3[2] + 1;
                goto code_r0x0001800cd573;
            }
            if (uVar17 == uVar4) goto code_r0x0001800cd573;
            uVar11 = uVar11 + 1 + uVar12;
            uVar12 = uVar12 + 1;
        } while (uVar12 <= piVar3[1] - 1U);
        puVar16 = (uint64_t *)0x0;
code_r0x0001800cd573:
        unaff_R12 = unaff_R12 + 1;
        puVar16[1] = 0;
        arg1 = arg_60h;
        if (unaff_R12 == unaff_RSI) {
            return CONCAT71((unkint7)(uVar17 >> 8), 1);
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800cd5ab
// Address: 0x1800cd5ab
// Size: 10 bytes
// ============================================================
undefined8
fcn.1800cd348(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h,
             int64_t arg_68h, int64_t arg_70h)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t *unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar15;
    uint64_t *puVar16;
    int64_t in_R11;
    uint64_t *unaff_R12;
    undefined8 unaff_R13;
    uint64_t uVar17;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_20h;
    
    *(undefined8 *)(in_R11 + 0x18) = unaff_RBX;
    *(undefined8 *)(in_R11 + -0x18) = unaff_RBP;
    *(undefined8 *)(in_R11 + -0x20) = unaff_RDI;
    *(undefined8 *)(in_R11 + -0x28) = unaff_R13;
    *(undefined8 *)(in_R11 + -0x30) = unaff_R14;
    *(undefined8 *)(in_R11 + -0x38) = unaff_R15;
    do {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        uVar4 = *unaff_R12;
        iVar9 = piVar3[1];
        if ((uint64_t)(iVar9 * 3) >> 2 <= (uint64_t)piVar3[2]) {
            unaff_RSI = (uint64_t *)arg_68h;
            if ((piVar3[2] != 0) && (uVar4 != piVar3[3])) {
                uVar11 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar12 = 0;
                do {
                    uVar11 = uVar11 & iVar9 - 1U;
                    uVar17 = *(uint64_t *)(*piVar3 + uVar11 * 0x18);
                    if (uVar17 == uVar4) goto code_r0x0001800cd515;
                    if (uVar17 == piVar3[3]) break;
                    uVar11 = uVar11 + 1 + uVar12;
                    uVar12 = uVar12 + 1;
                } while (uVar12 <= iVar9 - 1U);
            }
            uVar11 = piVar3[3];
            if (iVar9 == 0) {
                uVar12 = 0x10;
                iVar9 = func_0x000180459890(0x180);
                uVar13 = 0;
                iVar15 = iVar9;
                uVar17 = 0x10;
code_r0x0001800cd440:
                do {
                    iVar1 = uVar13 * 0x18;
                    uVar13 = uVar13 + 1;
                    *(int64_t *)(iVar1 + iVar15) = piVar3[3];
                    *(undefined (*) [16])(iVar1 + 8 + iVar15) = ZEXT816(0);
                    *(undefined8 *)(iVar1 + 8 + iVar15) = 0;
                    *(undefined2 *)(iVar1 + 0x10 + iVar15) = 0;
                } while (uVar13 < uVar12);
            } else {
                uVar12 = iVar9 * 2;
                if (uVar12 == 0) {
                    iVar9 = 0;
                    uVar17 = 0;
                } else {
                    iVar9 = func_0x000180459890(iVar9 * 0x30);
                    uVar13 = 0;
                    iVar15 = iVar9;
                    uVar17 = uVar12;
                    if (uVar12 != 0) goto code_r0x0001800cd440;
                }
            }
            uVar12 = 0;
            if (piVar3[1] != 0) {
                do {
                    iVar15 = uVar12 * 0x18;
                    uVar13 = *(uint64_t *)(iVar15 + *piVar3);
                    if (uVar13 != piVar3[3]) {
                        uVar10 = (uVar13 >> 5 ^ uVar13) >> 4;
                        uVar14 = 0;
                        do {
                            uVar10 = uVar10 & uVar17 - 1;
                            puVar16 = (uint64_t *)(iVar9 + uVar10 * 0x18);
                            uVar5 = *(uint64_t *)(iVar9 + uVar10 * 0x18);
                            if (uVar5 == uVar11) {
                                *puVar16 = uVar13;
                                goto code_r0x0001800cd4df;
                            }
                            if (uVar5 == uVar13) goto code_r0x0001800cd4df;
                            uVar10 = uVar10 + 1 + uVar14;
                            uVar14 = uVar14 + 1;
                        } while (uVar14 <= uVar17 - 1);
                        puVar16 = (uint64_t *)0x0;
code_r0x0001800cd4df:
                        iVar1 = *piVar3;
                        *puVar16 = *(uint64_t *)(iVar1 + iVar15);
                        puVar2 = (undefined4 *)(iVar1 + 8 + iVar15);
                        uVar6 = puVar2[1];
                        uVar7 = puVar2[2];
                        uVar8 = puVar2[3];
                        *(undefined4 *)(puVar16 + 1) = *puVar2;
                        *(undefined4 *)((int64_t)puVar16 + 0xc) = uVar6;
                        *(undefined4 *)(puVar16 + 2) = uVar7;
                        *(undefined4 *)((int64_t)puVar16 + 0x14) = uVar8;
                    }
                    uVar12 = uVar12 + 1;
                } while (uVar12 < (uint64_t)piVar3[1]);
            }
            iVar15 = *piVar3;
            *piVar3 = iVar9;
            piVar3[1] = uVar17;
            if (iVar15 != 0) {
                func_0x0001800f4640();
            }
        }
code_r0x0001800cd515:
        uVar11 = (uVar4 >> 5 ^ uVar4) >> 4;
        uVar12 = 0;
        do {
            uVar11 = uVar11 & piVar3[1] - 1U;
            puVar16 = (uint64_t *)(*piVar3 + uVar11 * 0x18);
            uVar17 = *(uint64_t *)(*piVar3 + uVar11 * 0x18);
            if (uVar17 == piVar3[3]) {
                *puVar16 = uVar4;
                piVar3[2] = piVar3[2] + 1;
                goto code_r0x0001800cd573;
            }
            if (uVar17 == uVar4) goto code_r0x0001800cd573;
            uVar11 = uVar11 + 1 + uVar12;
            uVar12 = uVar12 + 1;
        } while (uVar12 <= piVar3[1] - 1U);
        puVar16 = (uint64_t *)0x0;
code_r0x0001800cd573:
        unaff_R12 = unaff_R12 + 1;
        puVar16[1] = 0;
        arg1 = arg_60h;
        if (unaff_R12 == unaff_RSI) {
            return CONCAT71((unkint7)(uVar17 >> 8), 1);
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800cd5c0
// Address: 0x1800cd5c0
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800cd5c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint32_t uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t *puVar9;
    uint64_t *puVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = 2;
    var_28h = 0x1806203dc;
    puVar10 = (uint64_t *)0x0;
    piVar4 = (int64_t *)func_0x0001800d8ef0(arg2, &var_28h);
    if ((piVar4 != (int64_t *)0x0) && (var_10h = *piVar4, var_10h != 0)) {
        puVar5 = (undefined4 *)func_0x0001800cd960(arg1, &var_10h);
        *puVar5 = 1;
    }
    if (arg3 != 0) {
        var_28h = *(int64_t *)arg3;
        while (var_28h != 0) {
            uVar3 = func_0x000180498cd0(var_28h);
            var_20h = (int64_t)uVar3;
            puVar6 = (uint64_t *)func_0x0001800d8ef0(arg2, &var_28h);
            if ((puVar6 != (uint64_t *)0x0) && (uVar1 = *puVar6, uVar1 != 0)) {
                if ((uint64_t)(*(int64_t *)(arg1 + 8) * 3) >> 2 <= *(uint64_t *)(arg1 + 0x10)) {
                    if ((*(uint64_t *)(arg1 + 0x10) != 0) && (uVar1 != *(uint64_t *)(arg1 + 0x18))) {
                        puVar9 = (uint64_t *)(*(int64_t *)(arg1 + 8) + -1);
                        uVar7 = (uVar1 >> 5 ^ uVar1) >> 4;
                        puVar6 = puVar10;
                        do {
                            uVar7 = uVar7 & (uint64_t)puVar9;
                            uVar2 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
                            if (uVar2 == uVar1) goto code_r0x0001800cd6ed;
                            if (uVar2 == *(uint64_t *)(arg1 + 0x18)) break;
                            uVar7 = uVar7 + 1 + (int64_t)puVar6;
                            puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
                        } while (puVar6 <= puVar9);
                    }
                    func_0x0001800cdb00(arg1);
                }
code_r0x0001800cd6ed:
                puVar9 = (uint64_t *)(*(int64_t *)(arg1 + 8) + -1);
                uVar7 = (uVar1 >> 5 ^ uVar1) >> 4;
                puVar6 = puVar10;
                do {
                    uVar7 = uVar7 & (uint64_t)puVar9;
                    puVar8 = (uint64_t *)(uVar7 * 0x10 + *(int64_t *)arg1);
                    if (*puVar8 == *(uint64_t *)(arg1 + 0x18)) {
                        *puVar8 = uVar1;
                        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
                        break;
                    }
                    if (*puVar8 == uVar1) break;
                    uVar7 = uVar7 + 1 + (int64_t)puVar6;
                    puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
                    puVar8 = puVar10;
                } while (puVar6 <= puVar9);
                *(undefined4 *)(puVar8 + 1) = 1;
            }
            piVar4 = (int64_t *)(arg3 + 8);
            arg3 = arg3 + 8;
            var_28h = *piVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800cd635
// Address: 0x1800cd635
// Size: 300 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800cd5c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint32_t uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t *puVar9;
    uint64_t *puVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = 2;
    var_28h = 0x1806203dc;
    puVar10 = (uint64_t *)0x0;
    piVar4 = (int64_t *)func_0x0001800d8ef0(arg2, &var_28h);
    if ((piVar4 != (int64_t *)0x0) && (var_10h = *piVar4, var_10h != 0)) {
        puVar5 = (undefined4 *)func_0x0001800cd960(arg1, &var_10h);
        *puVar5 = 1;
    }
    if (arg3 != 0) {
        var_28h = *(int64_t *)arg3;
        while (var_28h != 0) {
            uVar3 = func_0x000180498cd0(var_28h);
            var_20h = (int64_t)uVar3;
            puVar6 = (uint64_t *)func_0x0001800d8ef0(arg2, &var_28h);
            if ((puVar6 != (uint64_t *)0x0) && (uVar1 = *puVar6, uVar1 != 0)) {
                if ((uint64_t)(*(int64_t *)(arg1 + 8) * 3) >> 2 <= *(uint64_t *)(arg1 + 0x10)) {
                    if ((*(uint64_t *)(arg1 + 0x10) != 0) && (uVar1 != *(uint64_t *)(arg1 + 0x18))) {
                        puVar9 = (uint64_t *)(*(int64_t *)(arg1 + 8) + -1);
                        uVar7 = (uVar1 >> 5 ^ uVar1) >> 4;
                        puVar6 = puVar10;
                        do {
                            uVar7 = uVar7 & (uint64_t)puVar9;
                            uVar2 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
                            if (uVar2 == uVar1) goto code_r0x0001800cd6ed;
                            if (uVar2 == *(uint64_t *)(arg1 + 0x18)) break;
                            uVar7 = uVar7 + 1 + (int64_t)puVar6;
                            puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
                        } while (puVar6 <= puVar9);
                    }
                    func_0x0001800cdb00(arg1);
                }
code_r0x0001800cd6ed:
                puVar9 = (uint64_t *)(*(int64_t *)(arg1 + 8) + -1);
                uVar7 = (uVar1 >> 5 ^ uVar1) >> 4;
                puVar6 = puVar10;
                do {
                    uVar7 = uVar7 & (uint64_t)puVar9;
                    puVar8 = (uint64_t *)(uVar7 * 0x10 + *(int64_t *)arg1);
                    if (*puVar8 == *(uint64_t *)(arg1 + 0x18)) {
                        *puVar8 = uVar1;
                        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
                        break;
                    }
                    if (*puVar8 == uVar1) break;
                    uVar7 = uVar7 + 1 + (int64_t)puVar6;
                    puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
                    puVar8 = puVar10;
                } while (puVar6 <= puVar9);
                *(undefined4 *)(puVar8 + 1) = 1;
            }
            piVar4 = (int64_t *)(arg3 + 8);
            arg3 = arg3 + 8;
            var_28h = *piVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800cd761
// Address: 0x1800cd761
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800cd5c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint32_t uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t *puVar9;
    uint64_t *puVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = 2;
    var_28h = 0x1806203dc;
    puVar10 = (uint64_t *)0x0;
    piVar4 = (int64_t *)func_0x0001800d8ef0(arg2, &var_28h);
    if ((piVar4 != (int64_t *)0x0) && (var_10h = *piVar4, var_10h != 0)) {
        puVar5 = (undefined4 *)func_0x0001800cd960(arg1, &var_10h);
        *puVar5 = 1;
    }
    if (arg3 != 0) {
        var_28h = *(int64_t *)arg3;
        while (var_28h != 0) {
            uVar3 = func_0x000180498cd0(var_28h);
            var_20h = (int64_t)uVar3;
            puVar6 = (uint64_t *)func_0x0001800d8ef0(arg2, &var_28h);
            if ((puVar6 != (uint64_t *)0x0) && (uVar1 = *puVar6, uVar1 != 0)) {
                if ((uint64_t)(*(int64_t *)(arg1 + 8) * 3) >> 2 <= *(uint64_t *)(arg1 + 0x10)) {
                    if ((*(uint64_t *)(arg1 + 0x10) != 0) && (uVar1 != *(uint64_t *)(arg1 + 0x18))) {
                        puVar9 = (uint64_t *)(*(int64_t *)(arg1 + 8) + -1);
                        uVar7 = (uVar1 >> 5 ^ uVar1) >> 4;
                        puVar6 = puVar10;
                        do {
                            uVar7 = uVar7 & (uint64_t)puVar9;
                            uVar2 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
                            if (uVar2 == uVar1) goto code_r0x0001800cd6ed;
                            if (uVar2 == *(uint64_t *)(arg1 + 0x18)) break;
                            uVar7 = uVar7 + 1 + (int64_t)puVar6;
                            puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
                        } while (puVar6 <= puVar9);
                    }
                    func_0x0001800cdb00(arg1);
                }
code_r0x0001800cd6ed:
                puVar9 = (uint64_t *)(*(int64_t *)(arg1 + 8) + -1);
                uVar7 = (uVar1 >> 5 ^ uVar1) >> 4;
                puVar6 = puVar10;
                do {
                    uVar7 = uVar7 & (uint64_t)puVar9;
                    puVar8 = (uint64_t *)(uVar7 * 0x10 + *(int64_t *)arg1);
                    if (*puVar8 == *(uint64_t *)(arg1 + 0x18)) {
                        *puVar8 = uVar1;
                        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
                        break;
                    }
                    if (*puVar8 == uVar1) break;
                    uVar7 = uVar7 + 1 + (int64_t)puVar6;
                    puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
                    puVar8 = puVar10;
                } while (puVar6 <= puVar9);
                *(undefined4 *)(puVar8 + 1) = 1;
            }
            piVar4 = (int64_t *)(arg3 + 8);
            arg3 = arg3 + 8;
            var_28h = *piVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800cd770
// Address: 0x1800cd770
// Size: 45 bytes
// ============================================================
void fcn.1800cd770(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_28h = 0x1806416e8;
    var_20h = arg1;
    var_18h = arg2;
    (***(code ***)arg3)(arg3, &var_28h);
    return;
}

// ============================================================
// Function: FUN_1800cd7a0
// Address: 0x1800cd7a0
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cd7a0(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t *puVar15;
    uint64_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar11 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar11 * 3) >> 2) || (iVar9 = func_0x0001800ac770(), iVar9 != 0))
    goto code_r0x0001800cd940;
    puVar1 = (uint64_t *)(arg1 + 0x18);
    uVar4 = *puVar1;
    if (iVar11 == 0) {
        uVar14 = 0x10;
        iVar9 = func_0x000180459890(0x180);
        uVar12 = 0;
        uVar16 = 0x10;
        iVar11 = iVar9;
code_r0x0001800cd840:
        do {
            iVar2 = uVar12 * 0x18;
            uVar12 = uVar12 + 1;
            *(uint64_t *)(iVar2 + iVar9) = *puVar1;
            *(undefined (*) [16])(iVar2 + 8 + iVar9) = ZEXT816(0);
            *(undefined8 *)(iVar2 + 8 + iVar9) = 0;
            *(undefined2 *)(iVar2 + 0x10 + iVar9) = 0;
        } while (uVar12 < uVar14);
    } else {
        uVar14 = iVar11 * 2;
        if (uVar14 == 0) {
            uVar16 = 0;
            iVar11 = 0;
        } else {
            iVar9 = func_0x000180459890(iVar11 * 0x30);
            uVar12 = 0;
            uVar16 = uVar14;
            iVar11 = iVar9;
            if (uVar14 != 0) goto code_r0x0001800cd840;
        }
    }
    uVar14 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            iVar9 = uVar14 * 0x18;
            uVar12 = *(uint64_t *)(iVar9 + *(int64_t *)arg1);
            if (uVar12 != *puVar1) {
                uVar10 = (uVar12 >> 5 ^ uVar12) >> 4;
                uVar13 = 0;
                do {
                    uVar10 = uVar10 & uVar16 - 1;
                    puVar15 = (uint64_t *)(iVar11 + uVar10 * 0x18);
                    uVar5 = *(uint64_t *)(iVar11 + uVar10 * 0x18);
                    if (uVar5 == uVar4) {
                        *puVar15 = uVar12;
                        goto code_r0x0001800cd8f7;
                    }
                    if (uVar5 == uVar12) goto code_r0x0001800cd8f7;
                    uVar10 = uVar10 + 1 + uVar13;
                    uVar13 = uVar13 + 1;
                } while (uVar13 <= uVar16 - 1);
                puVar15 = (uint64_t *)0x0;
code_r0x0001800cd8f7:
                iVar2 = *(int64_t *)arg1;
                *puVar15 = *(uint64_t *)(iVar2 + iVar9);
                puVar3 = (undefined4 *)(iVar2 + 8 + iVar9);
                uVar6 = puVar3[1];
                uVar7 = puVar3[2];
                uVar8 = puVar3[3];
                *(undefined4 *)(puVar15 + 1) = *puVar3;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar6;
                *(undefined4 *)(puVar15 + 2) = uVar7;
                *(undefined4 *)((int64_t)puVar15 + 0x14) = uVar8;
            }
            uVar14 = uVar14 + 1;
        } while (uVar14 < *(uint64_t *)(arg1 + 8));
    }
    iVar9 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar11;
    *(uint64_t *)(arg1 + 8) = uVar16;
    if (iVar9 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800cd940:
    iVar11 = func_0x0001800c14e0(arg1, arg2);
    return iVar11 + 8;
}

// ============================================================
// Function: FUN_1800cd7d6
// Address: 0x1800cd7d6
// Size: 357 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cd7a0(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t *puVar15;
    uint64_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar11 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar11 * 3) >> 2) || (iVar9 = func_0x0001800ac770(), iVar9 != 0))
    goto code_r0x0001800cd940;
    puVar1 = (uint64_t *)(arg1 + 0x18);
    uVar4 = *puVar1;
    if (iVar11 == 0) {
        uVar14 = 0x10;
        iVar9 = func_0x000180459890(0x180);
        uVar12 = 0;
        uVar16 = 0x10;
        iVar11 = iVar9;
code_r0x0001800cd840:
        do {
            iVar2 = uVar12 * 0x18;
            uVar12 = uVar12 + 1;
            *(uint64_t *)(iVar2 + iVar9) = *puVar1;
            *(undefined (*) [16])(iVar2 + 8 + iVar9) = ZEXT816(0);
            *(undefined8 *)(iVar2 + 8 + iVar9) = 0;
            *(undefined2 *)(iVar2 + 0x10 + iVar9) = 0;
        } while (uVar12 < uVar14);
    } else {
        uVar14 = iVar11 * 2;
        if (uVar14 == 0) {
            uVar16 = 0;
            iVar11 = 0;
        } else {
            iVar9 = func_0x000180459890(iVar11 * 0x30);
            uVar12 = 0;
            uVar16 = uVar14;
            iVar11 = iVar9;
            if (uVar14 != 0) goto code_r0x0001800cd840;
        }
    }
    uVar14 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            iVar9 = uVar14 * 0x18;
            uVar12 = *(uint64_t *)(iVar9 + *(int64_t *)arg1);
            if (uVar12 != *puVar1) {
                uVar10 = (uVar12 >> 5 ^ uVar12) >> 4;
                uVar13 = 0;
                do {
                    uVar10 = uVar10 & uVar16 - 1;
                    puVar15 = (uint64_t *)(iVar11 + uVar10 * 0x18);
                    uVar5 = *(uint64_t *)(iVar11 + uVar10 * 0x18);
                    if (uVar5 == uVar4) {
                        *puVar15 = uVar12;
                        goto code_r0x0001800cd8f7;
                    }
                    if (uVar5 == uVar12) goto code_r0x0001800cd8f7;
                    uVar10 = uVar10 + 1 + uVar13;
                    uVar13 = uVar13 + 1;
                } while (uVar13 <= uVar16 - 1);
                puVar15 = (uint64_t *)0x0;
code_r0x0001800cd8f7:
                iVar2 = *(int64_t *)arg1;
                *puVar15 = *(uint64_t *)(iVar2 + iVar9);
                puVar3 = (undefined4 *)(iVar2 + 8 + iVar9);
                uVar6 = puVar3[1];
                uVar7 = puVar3[2];
                uVar8 = puVar3[3];
                *(undefined4 *)(puVar15 + 1) = *puVar3;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar6;
                *(undefined4 *)(puVar15 + 2) = uVar7;
                *(undefined4 *)((int64_t)puVar15 + 0x14) = uVar8;
            }
            uVar14 = uVar14 + 1;
        } while (uVar14 < *(uint64_t *)(arg1 + 8));
    }
    iVar9 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar11;
    *(uint64_t *)(arg1 + 8) = uVar16;
    if (iVar9 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800cd940:
    iVar11 = func_0x0001800c14e0(arg1, arg2);
    return iVar11 + 8;
}

// ============================================================
// Function: FUN_1800cd93b
// Address: 0x1800cd93b
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cd7a0(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t *puVar15;
    uint64_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar11 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar11 * 3) >> 2) || (iVar9 = func_0x0001800ac770(), iVar9 != 0))
    goto code_r0x0001800cd940;
    puVar1 = (uint64_t *)(arg1 + 0x18);
    uVar4 = *puVar1;
    if (iVar11 == 0) {
        uVar14 = 0x10;
        iVar9 = func_0x000180459890(0x180);
        uVar12 = 0;
        uVar16 = 0x10;
        iVar11 = iVar9;
code_r0x0001800cd840:
        do {
            iVar2 = uVar12 * 0x18;
            uVar12 = uVar12 + 1;
            *(uint64_t *)(iVar2 + iVar9) = *puVar1;
            *(undefined (*) [16])(iVar2 + 8 + iVar9) = ZEXT816(0);
            *(undefined8 *)(iVar2 + 8 + iVar9) = 0;
            *(undefined2 *)(iVar2 + 0x10 + iVar9) = 0;
        } while (uVar12 < uVar14);
    } else {
        uVar14 = iVar11 * 2;
        if (uVar14 == 0) {
            uVar16 = 0;
            iVar11 = 0;
        } else {
            iVar9 = func_0x000180459890(iVar11 * 0x30);
            uVar12 = 0;
            uVar16 = uVar14;
            iVar11 = iVar9;
            if (uVar14 != 0) goto code_r0x0001800cd840;
        }
    }
    uVar14 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            iVar9 = uVar14 * 0x18;
            uVar12 = *(uint64_t *)(iVar9 + *(int64_t *)arg1);
            if (uVar12 != *puVar1) {
                uVar10 = (uVar12 >> 5 ^ uVar12) >> 4;
                uVar13 = 0;
                do {
                    uVar10 = uVar10 & uVar16 - 1;
                    puVar15 = (uint64_t *)(iVar11 + uVar10 * 0x18);
                    uVar5 = *(uint64_t *)(iVar11 + uVar10 * 0x18);
                    if (uVar5 == uVar4) {
                        *puVar15 = uVar12;
                        goto code_r0x0001800cd8f7;
                    }
                    if (uVar5 == uVar12) goto code_r0x0001800cd8f7;
                    uVar10 = uVar10 + 1 + uVar13;
                    uVar13 = uVar13 + 1;
                } while (uVar13 <= uVar16 - 1);
                puVar15 = (uint64_t *)0x0;
code_r0x0001800cd8f7:
                iVar2 = *(int64_t *)arg1;
                *puVar15 = *(uint64_t *)(iVar2 + iVar9);
                puVar3 = (undefined4 *)(iVar2 + 8 + iVar9);
                uVar6 = puVar3[1];
                uVar7 = puVar3[2];
                uVar8 = puVar3[3];
                *(undefined4 *)(puVar15 + 1) = *puVar3;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = uVar6;
                *(undefined4 *)(puVar15 + 2) = uVar7;
                *(undefined4 *)((int64_t)puVar15 + 0x14) = uVar8;
            }
            uVar14 = uVar14 + 1;
        } while (uVar14 < *(uint64_t *)(arg1 + 8));
    }
    iVar9 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar11;
    *(uint64_t *)(arg1 + 8) = uVar16;
    if (iVar9 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800cd940:
    iVar11 = func_0x0001800c14e0(arg1, arg2);
    return iVar11 + 8;
}

// ============================================================
// Function: FUN_1800cd960
// Address: 0x1800cd960
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cd960(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800cdae1;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800cda00:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined4 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            uVar9 = 0;
            iVar3 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800cda00;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar8 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar6 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar6 == uVar1) {
                        *puVar6 = uVar4;
                        goto code_r0x0001800cda9f;
                    }
                    if (*puVar6 == uVar4) goto code_r0x0001800cda9f;
                    uVar5 = uVar5 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar9 - 1);
                puVar6 = (uint64_t *)0x0;
code_r0x0001800cda9f:
                iVar2 = *(int64_t *)arg1;
                *puVar6 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800cdae1:
    iVar3 = func_0x0001800c1340(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800cd993
// Address: 0x1800cd993
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cd960(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800cdae1;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800cda00:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined4 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            uVar9 = 0;
            iVar3 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800cda00;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar8 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar6 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar6 == uVar1) {
                        *puVar6 = uVar4;
                        goto code_r0x0001800cda9f;
                    }
                    if (*puVar6 == uVar4) goto code_r0x0001800cda9f;
                    uVar5 = uVar5 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar9 - 1);
                puVar6 = (uint64_t *)0x0;
code_r0x0001800cda9f:
                iVar2 = *(int64_t *)arg1;
                *puVar6 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800cdae1:
    iVar3 = func_0x0001800c1340(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800cd99d
// Address: 0x1800cd99d
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cd960(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800cdae1;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800cda00:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined4 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            uVar9 = 0;
            iVar3 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800cda00;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar8 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar6 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar6 == uVar1) {
                        *puVar6 = uVar4;
                        goto code_r0x0001800cda9f;
                    }
                    if (*puVar6 == uVar4) goto code_r0x0001800cda9f;
                    uVar5 = uVar5 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar9 - 1);
                puVar6 = (uint64_t *)0x0;
code_r0x0001800cda9f:
                iVar2 = *(int64_t *)arg1;
                *puVar6 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800cdae1:
    iVar3 = func_0x0001800c1340(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800cda40
// Address: 0x1800cda40
// Size: 156 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cd960(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800cdae1;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800cda00:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined4 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            uVar9 = 0;
            iVar3 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800cda00;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar8 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar6 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar6 == uVar1) {
                        *puVar6 = uVar4;
                        goto code_r0x0001800cda9f;
                    }
                    if (*puVar6 == uVar4) goto code_r0x0001800cda9f;
                    uVar5 = uVar5 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar9 - 1);
                puVar6 = (uint64_t *)0x0;
code_r0x0001800cda9f:
                iVar2 = *(int64_t *)arg1;
                *puVar6 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800cdae1:
    iVar3 = func_0x0001800c1340(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800cdadc
// Address: 0x1800cdadc
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800cd960(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800cdae1;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800cda00:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined4 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            uVar9 = 0;
            iVar3 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800cda00;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar8 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar6 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar6 == uVar1) {
                        *puVar6 = uVar4;
                        goto code_r0x0001800cda9f;
                    }
                    if (*puVar6 == uVar4) goto code_r0x0001800cda9f;
                    uVar5 = uVar5 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar9 - 1);
                puVar6 = (uint64_t *)0x0;
code_r0x0001800cda9f:
                iVar2 = *(int64_t *)arg1;
                *puVar6 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                *(undefined4 *)(puVar6 + 1) = *(undefined4 *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800cdae1:
    iVar3 = func_0x0001800c1340(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800cdb00
// Address: 0x1800cdb00
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800cdb00(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = 0x10;
    } else {
        uVar9 = iVar4 * 2;
        if (uVar9 == 0) {
            uVar12 = 0;
            iVar4 = 0;
            goto code_r0x0001800cdba3;
        }
        iVar4 = func_0x000180459890(iVar4 << 5);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = uVar9;
        if (uVar9 == 0) goto code_r0x0001800cdba3;
    }
    do {
        uVar7 = uVar6 + 1;
        *(uint64_t *)(iVar10 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x18);
        *(undefined4 *)(iVar10 + 8 + uVar6 * 0x10) = 0;
        uVar6 = uVar7;
    } while (uVar7 < uVar9);
code_r0x0001800cdba3:
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x18)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar11 = 0;
                do {
                    uVar7 = uVar7 & uVar12 - 1;
                    puVar8 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar6;
                        goto code_r0x0001800cdc1f;
                    }
                    if (*puVar8 == uVar6) goto code_r0x0001800cdc1f;
                    uVar7 = uVar7 + 1 + uVar11;
                    uVar11 = uVar11 + 1;
                } while (uVar11 <= uVar12 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800cdc1f:
                iVar10 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(iVar10 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar4;
    *(uint64_t *)(arg1 + 8) = uVar12;
    if (iVar10 == 0) {
        return;
    }
    if ((iVar10 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar10), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = func_0x00018046b63c(uVar3);
        puVar5 = (undefined4 *)func_0x00018046b77c();
        *puVar5 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_1800cdb07
// Address: 0x1800cdb07
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800cdb00(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = 0x10;
    } else {
        uVar9 = iVar4 * 2;
        if (uVar9 == 0) {
            uVar12 = 0;
            iVar4 = 0;
            goto code_r0x0001800cdba3;
        }
        iVar4 = func_0x000180459890(iVar4 << 5);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = uVar9;
        if (uVar9 == 0) goto code_r0x0001800cdba3;
    }
    do {
        uVar7 = uVar6 + 1;
        *(uint64_t *)(iVar10 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x18);
        *(undefined4 *)(iVar10 + 8 + uVar6 * 0x10) = 0;
        uVar6 = uVar7;
    } while (uVar7 < uVar9);
code_r0x0001800cdba3:
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x18)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar11 = 0;
                do {
                    uVar7 = uVar7 & uVar12 - 1;
                    puVar8 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar6;
                        goto code_r0x0001800cdc1f;
                    }
                    if (*puVar8 == uVar6) goto code_r0x0001800cdc1f;
                    uVar7 = uVar7 + 1 + uVar11;
                    uVar11 = uVar11 + 1;
                } while (uVar11 <= uVar12 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800cdc1f:
                iVar10 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(iVar10 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar4;
    *(uint64_t *)(arg1 + 8) = uVar12;
    if (iVar10 == 0) {
        return;
    }
    if ((iVar10 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar10), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = func_0x00018046b63c(uVar3);
        puVar5 = (undefined4 *)func_0x00018046b77c();
        *puVar5 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_1800cdb12
// Address: 0x1800cdb12
// Size: 174 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800cdb00(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = 0x10;
    } else {
        uVar9 = iVar4 * 2;
        if (uVar9 == 0) {
            uVar12 = 0;
            iVar4 = 0;
            goto code_r0x0001800cdba3;
        }
        iVar4 = func_0x000180459890(iVar4 << 5);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = uVar9;
        if (uVar9 == 0) goto code_r0x0001800cdba3;
    }
    do {
        uVar7 = uVar6 + 1;
        *(uint64_t *)(iVar10 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x18);
        *(undefined4 *)(iVar10 + 8 + uVar6 * 0x10) = 0;
        uVar6 = uVar7;
    } while (uVar7 < uVar9);
code_r0x0001800cdba3:
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x18)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar11 = 0;
                do {
                    uVar7 = uVar7 & uVar12 - 1;
                    puVar8 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar6;
                        goto code_r0x0001800cdc1f;
                    }
                    if (*puVar8 == uVar6) goto code_r0x0001800cdc1f;
                    uVar7 = uVar7 + 1 + uVar11;
                    uVar11 = uVar11 + 1;
                } while (uVar11 <= uVar12 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800cdc1f:
                iVar10 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(iVar10 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar4;
    *(uint64_t *)(arg1 + 8) = uVar12;
    if (iVar10 == 0) {
        return;
    }
    if ((iVar10 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar10), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = func_0x00018046b63c(uVar3);
        puVar5 = (undefined4 *)func_0x00018046b77c();
        *puVar5 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_1800cdbc0
// Address: 0x1800cdbc0
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800cdb00(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = 0x10;
    } else {
        uVar9 = iVar4 * 2;
        if (uVar9 == 0) {
            uVar12 = 0;
            iVar4 = 0;
            goto code_r0x0001800cdba3;
        }
        iVar4 = func_0x000180459890(iVar4 << 5);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = uVar9;
        if (uVar9 == 0) goto code_r0x0001800cdba3;
    }
    do {
        uVar7 = uVar6 + 1;
        *(uint64_t *)(iVar10 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x18);
        *(undefined4 *)(iVar10 + 8 + uVar6 * 0x10) = 0;
        uVar6 = uVar7;
    } while (uVar7 < uVar9);
code_r0x0001800cdba3:
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x18)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar11 = 0;
                do {
                    uVar7 = uVar7 & uVar12 - 1;
                    puVar8 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar6;
                        goto code_r0x0001800cdc1f;
                    }
                    if (*puVar8 == uVar6) goto code_r0x0001800cdc1f;
                    uVar7 = uVar7 + 1 + uVar11;
                    uVar11 = uVar11 + 1;
                } while (uVar11 <= uVar12 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800cdc1f:
                iVar10 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(iVar10 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar4;
    *(uint64_t *)(arg1 + 8) = uVar12;
    if (iVar10 == 0) {
        return;
    }
    if ((iVar10 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar10), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = func_0x00018046b63c(uVar3);
        puVar5 = (undefined4 *)func_0x00018046b77c();
        *puVar5 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_1800cdc66
// Address: 0x1800cdc66
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800cdb00(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = 0x10;
    } else {
        uVar9 = iVar4 * 2;
        if (uVar9 == 0) {
            uVar12 = 0;
            iVar4 = 0;
            goto code_r0x0001800cdba3;
        }
        iVar4 = func_0x000180459890(iVar4 << 5);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = uVar9;
        if (uVar9 == 0) goto code_r0x0001800cdba3;
    }
    do {
        uVar7 = uVar6 + 1;
        *(uint64_t *)(iVar10 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x18);
        *(undefined4 *)(iVar10 + 8 + uVar6 * 0x10) = 0;
        uVar6 = uVar7;
    } while (uVar7 < uVar9);
code_r0x0001800cdba3:
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x18)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar11 = 0;
                do {
                    uVar7 = uVar7 & uVar12 - 1;
                    puVar8 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar6;
                        goto code_r0x0001800cdc1f;
                    }
                    if (*puVar8 == uVar6) goto code_r0x0001800cdc1f;
                    uVar7 = uVar7 + 1 + uVar11;
                    uVar11 = uVar11 + 1;
                } while (uVar11 <= uVar12 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800cdc1f:
                iVar10 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(iVar10 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar4;
    *(uint64_t *)(arg1 + 8) = uVar12;
    if (iVar10 == 0) {
        return;
    }
    if ((iVar10 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar10), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = func_0x00018046b63c(uVar3);
        puVar5 = (undefined4 *)func_0x00018046b77c();
        *puVar5 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_1800cdc80
// Address: 0x1800cdc80
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800cdc80(int64_t arg1)
{
    uint64_t uVar1;
    undefined in_DL;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) != uVar1) {
        *(uint64_t *)(arg1 + 0x10) = uVar1 + 1;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        *(undefined *)(uVar1 + arg1) = in_DL;
        *(undefined *)(uVar1 + 1 + arg1) = 0;
        return;
    }
    fcn.18000ee80(1);
    return;
}

// ============================================================
// Function: FUN_1800cdce0
// Address: 0x1800cdce0
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800cdce0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint8_t uVar3;
    int64_t var_8h;
    int64_t var_38h;
    
    do {
        uVar3 = 0;
        uVar1 = *(uint64_t *)(arg1 + 0x10);
        if (0x7f < (uint64_t)arg2) {
            uVar3 = 0x80;
        }
        uVar3 = uVar3 | (uint8_t)arg2 & 0x7f;
        if (*(uint64_t *)(arg1 + 0x18) == uVar1) {
            fcn.18000ee80(1);
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar1 + 1;
            if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                *(uint8_t *)(uVar1 + arg1) = uVar3;
                *(undefined *)(uVar1 + 1 + arg1) = 0;
            } else {
                iVar2 = *(int64_t *)arg1;
                *(uint8_t *)(uVar1 + iVar2) = uVar3;
                *(undefined *)(uVar1 + 1 + iVar2) = 0;
            }
        }
        arg2 = (uint64_t)arg2 >> 7;
    } while (arg2 != 0);
    return;
}

// ============================================================
// Function: FUN_1800cde40
// Address: 0x1800cde40
// Size: 2051 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1800cde40(int64_t arg1, int64_t arg_a8h)
{
    undefined4 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint64_t uVar16;
    undefined (*pauVar17) [16];
    undefined *puVar18;
    undefined4 *puVar19;
    undefined (*pauVar20) [16];
    undefined4 *puVar21;
    undefined (*pauVar22) [16];
    undefined8 *puVar23;
    undefined (*pauVar24) [16];
    int64_t unaff_R12;
    undefined (*unaff_R13) [16];
    int64_t unaff_R14;
    undefined4 *puVar25;
    undefined4 *puVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_188 [8];
    undefined auStack_180 [28];
    int64_t var_164h;
    int64_t var_148h;
    
    puVar18 = auStack_188;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xffffffffffffffff;
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0;
    *(undefined8 *)(arg1 + 0x48) = 0;
    *(undefined8 *)(arg1 + 0x50) = 0;
    *(undefined8 *)(arg1 + 0x58) = 0;
    *(undefined8 *)(arg1 + 0x60) = 0;
    *(undefined8 *)(arg1 + 0x68) = 0;
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined8 *)(arg1 + 0x78) = 0;
    *(undefined8 *)(arg1 + 0x80) = 0;
    *(undefined8 *)(arg1 + 0x88) = 0;
    *(undefined8 *)(arg1 + 0x90) = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xb8) = 0;
    *(undefined8 *)(arg1 + 0xc0) = 0;
    *(undefined8 *)(arg1 + 200) = 0;
    *(undefined8 *)(arg1 + 0xd0) = 0;
    *(undefined8 *)(arg1 + 0xd8) = 0;
    *(undefined8 *)(arg1 + 0xe0) = 0;
    *(undefined *)(arg1 + 0xe8) = 0;
    *(undefined8 *)(arg1 + 0xf0) = 0;
    *(undefined8 *)(arg1 + 0xf8) = 0;
    *(undefined8 *)(arg1 + 0x100) = 0;
    *(undefined4 *)(arg1 + 0x108) = 0;
    *(undefined4 *)(arg1 + 0x10c) = (undefined4)var_164h;
    *(undefined8 *)(arg1 + 0x110) = 0xffffffffffffffff;
    *(undefined8 *)(arg1 + 0x118) = 0;
    func_0x0001804986e0(&var_148h, 0, 0x108);
    *(undefined8 *)(arg1 + 0x128) = 0;
    *(undefined8 *)(arg1 + 0x130) = 0;
    *(undefined8 *)(arg1 + 0x138) = 0;
    piVar12 = (int64_t *)(arg1 + 0x140);
    piVar9 = &var_148h;
    iVar15 = 2;
    do {
        uVar6 = *(undefined4 *)((int64_t)piVar9 + 4);
        uVar7 = *(undefined4 *)(piVar9 + 1);
        uVar8 = *(undefined4 *)((int64_t)piVar9 + 0xc);
        *(undefined4 *)piVar12 = *(undefined4 *)piVar9;
        *(undefined4 *)((int64_t)piVar12 + 4) = uVar6;
        *(undefined4 *)(piVar12 + 1) = uVar7;
        *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar8;
        uVar6 = *(undefined4 *)((int64_t)piVar9 + 0x14);
        uVar7 = *(undefined4 *)(piVar9 + 3);
        uVar8 = *(undefined4 *)((int64_t)piVar9 + 0x1c);
        *(undefined4 *)(piVar12 + 2) = *(undefined4 *)(piVar9 + 2);
        *(undefined4 *)((int64_t)piVar12 + 0x14) = uVar6;
        *(undefined4 *)(piVar12 + 3) = uVar7;
        *(undefined4 *)((int64_t)piVar12 + 0x1c) = uVar8;
        uVar6 = *(undefined4 *)((int64_t)piVar9 + 0x24);
        uVar7 = *(undefined4 *)(piVar9 + 5);
        uVar8 = *(undefined4 *)((int64_t)piVar9 + 0x2c);
        *(undefined4 *)(piVar12 + 4) = *(undefined4 *)(piVar9 + 4);
        *(undefined4 *)((int64_t)piVar12 + 0x24) = uVar6;
        *(undefined4 *)(piVar12 + 5) = uVar7;
        *(undefined4 *)((int64_t)piVar12 + 0x2c) = uVar8;
        uVar6 = *(undefined4 *)((int64_t)piVar9 + 0x34);
        uVar7 = *(undefined4 *)(piVar9 + 7);
        uVar8 = *(undefined4 *)((int64_t)piVar9 + 0x3c);
        *(undefined4 *)(piVar12 + 6) = *(undefined4 *)(piVar9 + 6);
        *(undefined4 *)((int64_t)piVar12 + 0x34) = uVar6;
        *(undefined4 *)(piVar12 + 7) = uVar7;
        *(undefined4 *)((int64_t)piVar12 + 0x3c) = uVar8;
        uVar6 = *(undefined4 *)((int64_t)piVar9 + 0x44);
        uVar7 = *(undefined4 *)(piVar9 + 9);
        uVar8 = *(undefined4 *)((int64_t)piVar9 + 0x4c);
        *(undefined4 *)(piVar12 + 8) = *(undefined4 *)(piVar9 + 8);
        *(undefined4 *)((int64_t)piVar12 + 0x44) = uVar6;
        *(undefined4 *)(piVar12 + 9) = uVar7;
        *(undefined4 *)((int64_t)piVar12 + 0x4c) = uVar8;
        uVar6 = *(undefined4 *)((int64_t)piVar9 + 0x54);
        uVar7 = *(undefined4 *)(piVar9 + 0xb);
        uVar8 = *(undefined4 *)((int64_t)piVar9 + 0x5c);
        *(undefined4 *)(piVar12 + 10) = *(undefined4 *)(piVar9 + 10);
        *(undefined4 *)((int64_t)piVar12 + 0x54) = uVar6;
        *(undefined4 *)(piVar12 + 0xb) = uVar7;
        *(undefined4 *)((int64_t)piVar12 + 0x5c) = uVar8;
        uVar6 = *(undefined4 *)((int64_t)piVar9 + 100);
        uVar7 = *(undefined4 *)(piVar9 + 0xd);
        uVar8 = *(undefined4 *)((int64_t)piVar9 + 0x6c);
        *(undefined4 *)(piVar12 + 0xc) = *(undefined4 *)(piVar9 + 0xc);
        *(undefined4 *)((int64_t)piVar12 + 100) = uVar6;
        *(undefined4 *)(piVar12 + 0xd) = uVar7;
        *(undefined4 *)((int64_t)piVar12 + 0x6c) = uVar8;
        uVar6 = *(undefined4 *)((int64_t)piVar9 + 0x74);
        uVar7 = *(undefined4 *)(piVar9 + 0xf);
        uVar8 = *(undefined4 *)((int64_t)piVar9 + 0x7c);
        *(undefined4 *)(piVar12 + 0xe) = *(undefined4 *)(piVar9 + 0xe);
        *(undefined4 *)((int64_t)piVar12 + 0x74) = uVar6;
        *(undefined4 *)(piVar12 + 0xf) = uVar7;
        *(undefined4 *)((int64_t)piVar12 + 0x7c) = uVar8;
        piVar12 = piVar12 + 0x10;
        piVar9 = piVar9 + 0x10;
        iVar15 = iVar15 + -1;
    } while (iVar15 != 0);
    *piVar12 = *piVar9;
    *(undefined8 *)(arg1 + 0x250) = 0;
    *(undefined8 *)(arg1 + 600) = 0;
    *(undefined8 *)(arg1 + 0x260) = 0;
    *(undefined4 *)(arg1 + 0x268) = 0xffffffff;
    *(undefined4 *)(arg1 + 0x270) = 0;
    *(undefined8 *)(arg1 + 0x278) = 0;
    *(undefined8 *)(arg1 + 0x280) = 0;
    *(undefined8 *)(arg1 + 0x288) = 0;
    *(undefined8 *)(arg1 + 0x290) = 0;
    *(undefined8 *)(arg1 + 0x298) = 0;
    *(undefined8 *)(arg1 + 0x2a0) = 0;
    *(undefined8 *)(arg1 + 0x2a8) = 0;
    *(undefined8 *)(arg1 + 0x2b0) = 0;
    *(undefined8 *)(arg1 + 0x2b8) = 0;
    *(undefined8 *)(arg1 + 0x2c0) = 0;
    *(undefined8 *)(arg1 + 0x2c8) = 0;
    *(undefined8 *)(arg1 + 0x2d0) = 0;
    *(undefined8 *)(arg1 + 0x2d8) = 0;
    *(undefined8 *)(arg1 + 0x2e0) = 0;
    *(undefined8 *)(arg1 + 0x2e8) = 0;
    *(undefined8 *)(arg1 + 0x2f0) = 0;
    *(undefined8 *)(arg1 + 0x2f8) = 0;
    *(undefined8 *)(arg1 + 0x300) = 0;
    *(undefined8 *)(arg1 + 0x308) = 0;
    *(undefined8 *)(arg1 + 0x310) = 0;
    *(undefined8 *)(arg1 + 800) = 0;
    *(undefined8 *)(arg1 + 0x328) = 0;
    *(undefined8 *)(arg1 + 0x330) = 0;
    *(undefined8 *)(arg1 + 0x338) = 0;
    *(undefined8 *)(arg1 + 0x340) = 0;
    *(undefined8 *)(arg1 + 0x348) = 0;
    *(undefined (*) [16])(arg1 + 0x350) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x360) = 0;
    *(undefined8 *)(arg1 + 0x368) = 0xf;
    *(undefined *)(arg1 + 0x350) = 0;
    *(undefined8 *)(arg1 + 0x370) = 0x180776fe8;
    *(undefined (*) [16])(arg1 + 0x378) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x388) = 0;
    *(undefined8 *)(arg1 + 0x390) = 0xf;
    *(undefined *)(arg1 + 0x378) = 0;
    *(undefined4 *)(arg1 + 0x398) = 0;
    *(undefined8 *)(arg1 + 0x3a0) = 0;
    *(undefined8 *)(arg1 + 0x3a8) = 0;
    *(undefined8 *)(arg1 + 0x3b0) = 0;
    *(undefined8 *)(arg1 + 0x3b8) = 0;
    *(undefined8 *)(arg1 + 0x3c0) = 0;
    *(undefined8 *)(arg1 + 0x3c8) = 0;
    *(undefined (*) [16])(arg1 + 0x3d0) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x3e0) = 0;
    *(undefined8 *)(arg1 + 1000) = 0xf;
    *(undefined *)(arg1 + 0x3d0) = 0;
    *(undefined8 *)(arg1 + 0x3f0) = 0;
    func_0x0001800d30b0(arg1 + 0x28, 0x20);
    func_0x0001800d30b0(arg1 + 0x40, 0x20);
    iVar15 = *(int64_t *)(arg1 + 0x58);
    if ((uint64_t)((*(int64_t *)(arg1 + 0x68) - iVar15 >> 3) * -0x5555555555555555) < 0x10) {
        iVar14 = *(int64_t *)(arg1 + 0x60);
        iVar10 = func_0x000180459890(0x180);
        func_0x000180498030(iVar10, *(int64_t *)(arg1 + 0x58), *(int64_t *)(arg1 + 0x60) - *(int64_t *)(arg1 + 0x58));
        iVar13 = *(int64_t *)(arg1 + 0x58);
        if (iVar13 == 0) {
code_r0x0001800ce214:
            *(int64_t *)(arg1 + 0x58) = iVar10;
            *(int64_t *)(arg1 + 0x60) = iVar10 + (iVar14 - iVar15 >> 3) * 8;
            *(int64_t *)(arg1 + 0x68) = iVar10 + 0x180;
            goto code_r0x0001800ce237;
        }
        uVar11 = (*(int64_t *)(arg1 + 0x68) - iVar13 >> 3) * 8;
        if (uVar11 < 0x1000) {
code_r0x0001800ce20c:
            func_0x000180459c3c(iVar13, uVar11);
            goto code_r0x0001800ce214;
        }
        if ((iVar13 - *(int64_t *)(iVar13 + -8)) - 8U < 0x20) {
            uVar11 = uVar11 + 0x27;
            iVar13 = *(int64_t *)(iVar13 + -8);
            goto code_r0x0001800ce20c;
        }
code_r0x0001800ce5ef:
        iVar15 = 5;
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar18 = auStack_180;
    } else {
code_r0x0001800ce237:
        func_0x0001800d30b0(arg1 + 0x70, 0x10);
        if (7 < (uint64_t)((*(int64_t *)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * -0x30c30c30c30c30c3)) {
            return arg1;
        }
        unaff_R12 = *(int64_t *)(arg1 + 8) - *(int64_t *)arg1;
        unaff_R13 = (undefined (*) [16])func_0x000180459890();
        puVar1 = *(undefined4 **)(arg1 + 8);
        puVar21 = *(undefined4 **)arg1;
        pauVar22 = unaff_R13;
        if (puVar21 != puVar1) {
            pauVar24 = unaff_R13 + 3;
            puVar25 = puVar21 + 0xc;
            pauVar17 = unaff_R13 + 5;
            puVar26 = puVar21 + 0x14;
            puVar23 = (undefined8 *)(puVar21 + 0x1c);
            pauVar20 = unaff_R13 + 8;
            puVar19 = puVar21 + 0x22;
            do {
                pauVar20 = (undefined (*) [16])(*pauVar20 + 8);
                *pauVar22 = ZEXT816(0);
                *(undefined8 *)pauVar22[1] = 0;
                *(undefined8 *)(pauVar22[1] + 8) = 0;
                uVar6 = puVar21[1];
                uVar7 = puVar21[2];
                uVar8 = puVar21[3];
                *(undefined4 *)*pauVar22 = *puVar21;
                *(undefined4 *)(*pauVar22 + 4) = uVar6;
                *(undefined4 *)(*pauVar22 + 8) = uVar7;
                *(undefined4 *)(*pauVar22 + 0xc) = uVar8;
                uVar6 = puVar21[5];
                uVar7 = puVar21[6];
                uVar8 = puVar21[7];
                *(undefined4 *)pauVar22[1] = puVar21[4];
                *(undefined4 *)(pauVar22[1] + 4) = uVar6;
                *(undefined4 *)(pauVar22[1] + 8) = uVar7;
                *(undefined4 *)(pauVar22[1] + 0xc) = uVar8;
                *(undefined8 *)(puVar21 + 4) = 0;
                *(undefined8 *)(puVar21 + 6) = 0xf;
                *(undefined *)puVar21 = 0;
                pauVar22[2][0] = *(undefined *)(puVar21 + 8);
                pauVar22[2][1] = *(undefined *)((int64_t)puVar21 + 0x21);
                pauVar22[2][2] = *(undefined *)((int64_t)puVar21 + 0x22);
                pauVar22[2][3] = *(undefined *)((int64_t)puVar21 + 0x23);
                *(undefined4 *)(pauVar22[2] + 4) = puVar21[9];
                *(undefined4 *)(pauVar22[2] + 8) = puVar21[10];
                *pauVar24 = ZEXT816(0);
                *(undefined8 *)pauVar24[1] = 0;
                *(undefined8 *)(pauVar24[1] + 8) = 0;
                uVar6 = puVar25[1];
                uVar7 = puVar25[2];
                uVar8 = puVar25[3];
                *(undefined4 *)*pauVar24 = *puVar25;
                *(undefined4 *)(*pauVar24 + 4) = uVar6;
                *(undefined4 *)(*pauVar24 + 8) = uVar7;
                *(undefined4 *)(*pauVar24 + 0xc) = uVar8;
                uVar6 = puVar25[5];
                uVar7 = puVar25[6];
                uVar8 = puVar25[7];
                *(undefined4 *)pauVar24[1] = puVar25[4];
                *(undefined4 *)(pauVar24[1] + 4) = uVar6;
                *(undefined4 *)(pauVar24[1] + 8) = uVar7;
                *(undefined4 *)(pauVar24[1] + 0xc) = uVar8;
                *(undefined8 *)(puVar25 + 4) = 0;
                *(undefined8 *)(puVar25 + 6) = 0xf;
                *(undefined *)puVar25 = 0;
                *pauVar17 = ZEXT816(0);
                *(undefined8 *)pauVar17[1] = 0;
                *(undefined8 *)(pauVar17[1] + 8) = 0;
                uVar6 = puVar26[1];
                uVar7 = puVar26[2];
                uVar8 = puVar26[3];
                *(undefined4 *)*pauVar17 = *puVar26;
                *(undefined4 *)(*pauVar17 + 4) = uVar6;
                *(undefined4 *)(*pauVar17 + 8) = uVar7;
                *(undefined4 *)(*pauVar17 + 0xc) = uVar8;
                uVar6 = puVar26[5];
                uVar7 = puVar26[6];
                uVar8 = puVar26[7];
                *(undefined4 *)pauVar17[1] = puVar26[4];
                *(undefined4 *)(pauVar17[1] + 4) = uVar6;
                *(undefined4 *)(pauVar17[1] + 8) = uVar7;
                *(undefined4 *)(pauVar17[1] + 0xc) = uVar8;
                *(undefined8 *)(puVar26 + 4) = 0;
                *(undefined8 *)(puVar26 + 6) = 0xf;
                *(undefined *)puVar26 = 0;
                uVar2 = puVar23[2];
                puVar23[2] = 0;
                uVar3 = puVar23[1];
                puVar23[1] = 0;
                uVar4 = *puVar23;
                *puVar23 = 0;
                *(undefined8 *)pauVar22[7] = uVar4;
                *(undefined8 *)(pauVar22[7] + 8) = uVar3;
                *(undefined8 *)pauVar22[8] = uVar2;
                *pauVar20 = ZEXT816(0);
                *(undefined8 *)pauVar20[1] = 0;
                *(undefined8 *)(pauVar20[1] + 8) = 0;
                uVar6 = puVar19[1];
                uVar7 = puVar19[2];
                uVar8 = puVar19[3];
                *(undefined4 *)*pauVar20 = *puVar19;
                *(undefined4 *)(*pauVar20 + 4) = uVar6;
                *(undefined4 *)(*pauVar20 + 8) = uVar7;
                *(undefined4 *)(*pauVar20 + 0xc) = uVar8;
                uVar6 = puVar19[5];
                uVar7 = puVar19[6];
                uVar8 = puVar19[7];
                *(undefined4 *)pauVar20[1] = puVar19[4];
                *(undefined4 *)(pauVar20[1] + 4) = uVar6;
                *(undefined4 *)(pauVar20[1] + 8) = uVar7;
                *(undefined4 *)(pauVar20[1] + 0xc) = uVar8;
                *(undefined8 *)(puVar19 + 4) = 0;
                *(undefined8 *)(puVar19 + 6) = 0xf;
                *(undefined *)puVar19 = 0;
                pauVar22 = (undefined (*) [16])(pauVar22[10] + 8);
                puVar21 = puVar21 + 0x2a;
                pauVar24 = (undefined (*) [16])(pauVar24[10] + 8);
                puVar25 = puVar25 + 0x2a;
                pauVar17 = (undefined (*) [16])(pauVar17[10] + 8);
                puVar26 = puVar26 + 0x2a;
                puVar23 = puVar23 + 0x15;
                pauVar20 = pauVar20 + 10;
                puVar19 = puVar19 + 0x2a;
            } while (puVar21 != puVar1);
        }
        unaff_R14 = -0x30c30c30c30c30c3;
        func_0x0001800c1e20(pauVar22, pauVar22);
        piVar12 = *(int64_t **)arg1;
        if (piVar12 == (int64_t *)0x0) goto code_r0x0001800ce601;
        piVar9 = *(int64_t **)(arg1 + 8);
        for (; piVar12 != piVar9; piVar12 = piVar12 + 0x15) {
            uVar11 = piVar12[0x14];
            if (0xf < uVar11) {
                iVar15 = piVar12[0x11];
                uVar16 = uVar11 + 1;
                if (0xfff < uVar16) {
                    if (0x1f < (iVar15 - *(int64_t *)(iVar15 + -8)) - 8U) goto code_r0x0001800ce5ef;
                    uVar16 = uVar11 + 0x28;
                    iVar15 = *(int64_t *)(iVar15 + -8);
                }
                func_0x000180459c3c(iVar15, uVar16);
            }
            piVar12[0x13] = 0;
            piVar12[0x14] = 0xf;
            *(undefined *)(piVar12 + 0x11) = 0;
            func_0x00018002ee50(piVar12 + 0xe);
            uVar11 = piVar12[0xd];
            if (0xf < uVar11) {
                iVar15 = piVar12[10];
                uVar16 = uVar11 + 1;
                if (0xfff < uVar16) {
                    if (0x1f < (iVar15 - *(int64_t *)(iVar15 + -8)) - 8U) goto code_r0x0001800ce5ef;
                    uVar16 = uVar11 + 0x28;
                    iVar15 = *(int64_t *)(iVar15 + -8);
                }
                func_0x000180459c3c(iVar15, uVar16);
            }
            piVar12[0xc] = 0;
            piVar12[0xd] = 0xf;
            *(undefined *)(piVar12 + 10) = 0;
            uVar11 = piVar12[9];
            if (0xf < uVar11) {
                iVar15 = piVar12[6];
                uVar16 = uVar11 + 1;
                if (0xfff < uVar16) {
                    if (0x1f < (iVar15 - *(int64_t *)(iVar15 + -8)) - 8U) goto code_r0x0001800ce5ef;
                    uVar16 = uVar11 + 0x28;
                    iVar15 = *(int64_t *)(iVar15 + -8);
                }
                func_0x000180459c3c(iVar15, uVar16);
            }
            piVar12[8] = 0;
            piVar12[9] = 0xf;
            *(undefined *)(piVar12 + 6) = 0;
            uVar11 = piVar12[3];
            if (0xf < uVar11) {
                iVar15 = *piVar12;
                uVar16 = uVar11 + 1;
                if (0xfff < uVar16) {
                    if (0x1f < (iVar15 - *(int64_t *)(iVar15 + -8)) - 8U) goto code_r0x0001800ce5ef;
                    uVar16 = uVar11 + 0x28;
                    iVar15 = *(int64_t *)(iVar15 + -8);
                }
                func_0x000180459c3c(iVar15, uVar16);
            }
            piVar12[2] = 0;
            piVar12[3] = 0xf;
            *(undefined *)piVar12 = 0;
        }
        iVar15 = *(int64_t *)arg1;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar15 >> 3) * 8)) &&
           (iVar14 = iVar15 - *(int64_t *)(iVar15 + -8), iVar15 = *(int64_t *)(iVar15 + -8), puVar18 = auStack_188,
           0x1f < iVar14 - 8U)) goto code_r0x0001800ce5ef;
    }
    *(undefined8 *)(puVar18 + -8) = 0x1800ce601;
    func_0x000180459c3c(iVar15);
code_r0x0001800ce601:
    *(undefined (**) [16])arg1 = unaff_R13;
    *(undefined **)(arg1 + 8) = (undefined *)((unaff_R12 >> 3) * unaff_R14 * 0xa8 + (int64_t)unaff_R13);
    *(undefined (**) [16])(arg1 + 0x10) = unaff_R13 + 0x54;
    return arg1;
}

// ============================================================
// Function: FUN_1800ce650
// Address: 0x1800ce650
// Size: 895 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_d6h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d7h
// WARNING: [rz-ghidra] Detected overlap for variable var_d5h

void fcn.1800ce650(int64_t arg1, int64_t arg_58h)
{
    code *pcVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined auVar4 [16];
    undefined auVar5 [16];
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    undefined *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t iVar16;
    undefined4 uVar17;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    int64_t var_20h;
    undefined8 uStack_150;
    undefined auStack_148 [8];
    undefined auStack_140 [24];
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    
    puVar12 = auStack_148;
    puVar11 = auStack_148;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_148;
    iVar8 = *(int64_t *)(arg1 + 8);
    iVar15 = iVar8 - *(int64_t *)arg1 >> 3;
    iVar16 = iVar15 * -0x30c30c30c30c30c3;
    uVar17 = 0;
    uVar10 = 0;
    var_e8h = 0;
    var_e0h = 0xf;
    stack0xffffffffffffff09 = SUB1615(ZEXT816(0), 1);
    auVar2[15] = 0;
    auVar2._0_15_ = stack0xffffffffffffff09;
    _var_f8h = auVar2 << 8;
    var_d8h._0_1_ = 0;
    var_d8h._2_1_ = 0;
    stack0xffffffffffffff2c = 0;
    var_b8h = 0;
    var_b0h = 0xf;
    stack0xffffffffffffff39 = SUB1615(ZEXT816(0), 1);
    auVar3[15] = 0;
    auVar3._0_15_ = stack0xffffffffffffff39;
    _var_c8h = auVar3 << 8;
    var_98h = 0;
    var_90h = 0xf;
    stack0xffffffffffffff59 = SUB1615(ZEXT816(0), 1);
    auVar4[15] = 0;
    auVar4._0_15_ = stack0xffffffffffffff59;
    _var_a8h = auVar4 << 8;
    _var_88h = ZEXT816(0);
    var_78h = 0;
    var_60h = 0;
    var_58h = 0xf;
    stack0xffffffffffffff91 = SUB1615(ZEXT816(0), 1);
    auVar5[15] = 0;
    auVar5._0_15_ = stack0xffffffffffffff91;
    _var_70h = auVar5 << 8;
    iVar7 = *(int64_t *)(arg1 + 0x10);
    if (iVar8 == iVar7) {
        if (iVar16 == 0x186186186186186) {
            func_0x000180010010();
code_r0x0001800ce9c9:
            func_0x000180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar9 = (iVar7 - *(int64_t *)arg1 >> 3) * -0x30c30c30c30c30c3;
        uVar6 = 0x186186186186186 - (uVar9 >> 1);
        if (uVar6 <= uVar9 && uVar9 - uVar6 != 0) goto code_r0x0001800ce9c9;
        uVar6 = iVar16 + 1;
        uVar9 = uVar9 + (uVar9 >> 1);
        uVar13 = uVar6;
        if (uVar6 <= uVar9) {
            uVar13 = uVar9;
        }
        if (0x186186186186186 < uVar13) goto code_r0x0001800ce9c9;
        uVar9 = uVar13 * 0xa8;
        if (uVar9 != 0) {
            if (uVar9 < 0x1000) {
                uVar10 = func_0x000180459890();
                puVar12 = auStack_148;
                uVar17 = extraout_XMM0_Da_01;
            } else {
                if (uVar9 + 0x27 <= uVar9) goto code_r0x0001800ce9c9;
                iVar7 = func_0x000180459890(uVar9 + 0x27);
                uVar17 = extraout_XMM0_Da;
                if (iVar7 == 0) {
                    pcVar1 = (code *)swi(0x29);
                    iVar7 = (*pcVar1)(5);
                    puVar11 = auStack_140;
                    uVar17 = extraout_XMM0_Da_00;
                }
                uVar10 = iVar7 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar10 - 8) = iVar7;
                puVar12 = puVar11;
            }
        }
        iVar7 = iVar15 * 8 + uVar10;
        uVar9 = iVar7 + 0xa8;
        *(int64_t *)(puVar12 + 0x20) = arg1;
        *(uint64_t *)(puVar12 + 0x28) = uVar10;
        *(uint64_t *)(puVar12 + 0x30) = uVar13;
        *(uint64_t *)(puVar12 + 0x38) = uVar9;
        *(uint64_t *)(puVar12 + 0x40) = uVar9;
        *(undefined8 *)(puVar12 + -8) = 0x1800ce810;
        func_0x0001800d4720(uVar17, iVar7, puVar12 + 0x50);
        iVar7 = *(int64_t *)(arg1 + 8);
        iVar15 = *(int64_t *)arg1;
        uVar14 = uVar10;
        if (iVar8 != iVar7) {
            *(undefined8 *)(puVar12 + -8) = 0x1800ce827;
            func_0x0001800d4160(iVar15, iVar8, uVar10);
            iVar7 = *(int64_t *)(arg1 + 8);
            iVar15 = iVar8;
            uVar14 = uVar9;
        }
        *(undefined8 *)(puVar12 + -8) = 0x1800ce836;
        func_0x0001800d4160(iVar15, iVar7, uVar14);
        *(undefined8 *)(puVar12 + -8) = 0x1800ce847;
        func_0x0001800d44a0(arg1, uVar10, uVar6, uVar13);
    } else {
        func_0x0001800d4720(iVar7, iVar8, &var_f8h);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0xa8;
        puVar12 = auStack_148;
    }
    *(int32_t *)(arg1 + 0x18) = (int32_t)iVar16;
    *(undefined *)(arg1 + 0xe8) = 0;
    *(undefined4 *)(arg1 + 0x270) = 0;
    if ((uint64_t)var_58h < 0x10) {
code_r0x0001800ce89a:
        if (var_88h != 0) {
            uVar10 = (var_78h - var_88h >> 2) * 4;
            iVar8 = var_88h;
            if (0xfff < uVar10) {
                if (0x1f < (var_88h - *(int64_t *)(var_88h + -8)) - 8U) goto code_r0x0001800ce98a;
                uVar10 = uVar10 + 0x27;
                iVar8 = *(int64_t *)(var_88h + -8);
            }
            *(undefined8 *)(puVar12 + -8) = 0x1800ce8e5;
            func_0x000180459c3c(iVar8, uVar10);
        }
        if (0xf < (uint64_t)var_90h) {
            uVar10 = var_90h + 1;
            iVar8 = var_a8h;
            if (0xfff < uVar10) {
                if (0x1f < (var_a8h - *(int64_t *)(var_a8h + -8)) - 8U) goto code_r0x0001800ce98a;
                uVar10 = var_90h + 0x28;
                iVar8 = *(int64_t *)(var_a8h + -8);
            }
            *(undefined8 *)(puVar12 + -8) = 0x1800ce91e;
            func_0x000180459c3c(iVar8, uVar10);
        }
        if (0xf < (uint64_t)var_b0h) {
            uVar10 = var_b0h + 1;
            iVar8 = var_c8h;
            if (0xfff < uVar10) {
                if (0x1f < (var_c8h - *(int64_t *)(var_c8h + -8)) - 8U) goto code_r0x0001800ce98a;
                uVar10 = var_b0h + 0x28;
                iVar8 = *(int64_t *)(var_c8h + -8);
            }
            *(undefined8 *)(puVar12 + -8) = 0x1800ce957;
            func_0x000180459c3c(iVar8, uVar10);
        }
        if (*(uint64_t *)(puVar12 + 0x68) < 0x10) goto code_r0x0001800ce999;
        iVar8 = *(int64_t *)(puVar12 + 0x50);
        if ((0xfff < *(uint64_t *)(puVar12 + 0x68) + 1) &&
           (iVar7 = iVar8 - *(int64_t *)(iVar8 + -8), iVar8 = *(int64_t *)(iVar8 + -8), 0x1f < iVar7 - 8U))
        goto code_r0x0001800ce98a;
    } else {
        uVar10 = var_58h + 1;
        iVar8 = var_70h;
        if (uVar10 < 0x1000) {
code_r0x0001800ce895:
            *(undefined8 *)(puVar12 + -8) = 0x1800ce89a;
            func_0x000180459c3c(iVar8, uVar10);
            goto code_r0x0001800ce89a;
        }
        if ((var_70h - *(int64_t *)(var_70h + -8)) - 8U < 0x20) {
            uVar10 = var_58h + 0x28;
            iVar8 = *(int64_t *)(var_70h + -8);
            goto code_r0x0001800ce895;
        }
code_r0x0001800ce98a:
        pcVar1 = (code *)swi(0x29);
        iVar8 = (*pcVar1)(5);
        puVar12 = puVar12 + 8;
    }
    *(undefined8 *)(puVar12 + -8) = 0x1800ce999;
    func_0x000180459c3c(iVar8);
code_r0x0001800ce999:
    *(undefined8 *)(puVar12 + -8) = 0x1800ce9a8;
    func_0x000180459870(var_48h ^ (uint64_t)puVar12);
    return;
}

// ============================================================
// Function: FUN_1800ce9d0
// Address: 0x1800ce9d0
// Size: 843 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800ce9d0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    code *pcVar5;
    uint64_t uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    undefined8 *puVar13;
    undefined *puVar14;
    int64_t iVar15;
    undefined in_R8B;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_20h;
    uint64_t uStack_18;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    iVar15 = (uint64_t)*(uint32_t *)(arg1 + 0x18) * 0xa8 + *(int64_t *)arg1;
    *(char *)(iVar15 + 0x20) = (char)arg2;
    *(undefined *)(iVar15 + 0x22) = in_R8B;
    puVar14 = auStack_58;
    if (*(code **)(arg1 + 0x3f0) != (code *)0x0) {
        uVar9 = (**(code **)(arg1 + 0x3f0))(arg1, &var_38h, iVar15 + 0x70);
        func_0x000180012c10(iVar15 + 0x30, uVar9);
        puVar14 = auStack_58;
        if (0xf < (uint64_t)var_20h) {
            iVar10 = var_38h;
            puVar14 = auStack_58;
            if ((0xfff < var_20h + 1U) &&
               (iVar10 = *(int64_t *)(var_38h + -8), puVar14 = auStack_58, 0x1f < (var_38h - iVar10) - 8U)) {
                pcVar5 = (code *)swi(0x29);
                iVar10 = (*pcVar5)(5);
                puVar14 = auStack_50;
            }
            *(undefined8 *)(puVar14 + -8) = 0x1800cea6e;
            func_0x000180459c3c(iVar10);
        }
    }
    iVar10 = *(int64_t *)(arg1 + 0x30);
    iVar3 = *(int64_t *)(arg1 + 0x28);
    *(undefined8 *)(puVar14 + -8) = 0x1800cea8a;
    func_0x00018000b240(iVar15, (iVar10 - iVar3 >> 2) * 7 + 0x20);
    piVar4 = *(int64_t **)(arg1 + 0x370);
    if (piVar4 != (int64_t *)0x0) {
        iVar10 = *(int64_t *)(arg1 + 0x28);
        iVar3 = *(int64_t *)(arg1 + 0x30);
        pcVar5 = *(code **)(*piVar4 + 8);
        *(undefined8 *)(puVar14 + -8) = 0x1800ceaab;
        (*pcVar5)(piVar4, iVar10, iVar3 - iVar10 >> 2);
    }
    uVar2 = *(undefined4 *)(arg1 + 0x18);
    *(undefined8 *)(puVar14 + -8) = 0x1800ceabe;
    func_0x0001800d0ea0(arg1, iVar15, uVar2);
    *(undefined4 *)(arg1 + 0x18) = 0xffffffff;
    iVar15 = *(int64_t *)(arg1 + 0x28);
    *(int64_t *)(arg1 + 0x20) = *(int64_t *)(arg1 + 0x20) + (*(int64_t *)(arg1 + 0x30) - iVar15 >> 2);
    if (iVar15 != *(int64_t *)(arg1 + 0x30)) {
        *(int64_t *)(arg1 + 0x30) = iVar15;
    }
    if (*(int64_t *)(arg1 + 0x40) != *(int64_t *)(arg1 + 0x48)) {
        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x40);
    }
    if (*(int64_t *)(arg1 + 0x58) != *(int64_t *)(arg1 + 0x60)) {
        *(int64_t *)(arg1 + 0x60) = *(int64_t *)(arg1 + 0x58);
    }
    if (*(int64_t *)(arg1 + 0x70) != *(int64_t *)(arg1 + 0x78)) {
        *(int64_t *)(arg1 + 0x78) = *(int64_t *)(arg1 + 0x70);
    }
    if (*(int64_t *)(arg1 + 0x88) != *(int64_t *)(arg1 + 0x90)) {
        *(int64_t *)(arg1 + 0x90) = *(int64_t *)(arg1 + 0x88);
    }
    if (*(int64_t *)(arg1 + 0xd0) != *(int64_t *)(arg1 + 0xd8)) {
        *(int64_t *)(arg1 + 0xd8) = *(int64_t *)(arg1 + 0xd0);
    }
    if (*(int64_t *)(arg1 + 0xa0) != *(int64_t *)(arg1 + 0xa8)) {
        *(int64_t *)(arg1 + 0xa8) = *(int64_t *)(arg1 + 0xa0);
    }
    if (*(int64_t *)(arg1 + 0x278) != *(int64_t *)(arg1 + 0x280)) {
        *(int64_t *)(arg1 + 0x280) = *(int64_t *)(arg1 + 0x278);
    }
    if (*(int64_t *)(arg1 + 0x290) != *(int64_t *)(arg1 + 0x298)) {
        *(int64_t *)(arg1 + 0x298) = *(int64_t *)(arg1 + 0x290);
    }
    if (*(int64_t *)(arg1 + 0x2a8) != *(int64_t *)(arg1 + 0x2b0)) {
        *(int64_t *)(arg1 + 0x2b0) = *(int64_t *)(arg1 + 0x2a8);
    }
    if (*(int64_t *)(arg1 + 0x2c0) != *(int64_t *)(arg1 + 0x2c8)) {
        *(int64_t *)(arg1 + 0x2c8) = *(int64_t *)(arg1 + 0x2c0);
    }
    uVar12 = 0;
    if (*(int64_t *)(arg1 + 0x100) != 0) {
        uVar6 = *(uint64_t *)(arg1 + 0xf8);
        iVar15 = *(int64_t *)(arg1 + 0xf0);
        if (uVar6 < 0x21) {
            uVar11 = uVar12;
            if (uVar6 != 0) {
                do {
                    uVar2 = *(undefined4 *)(arg1 + 0x10c);
                    uVar7 = *(undefined4 *)(arg1 + 0x110);
                    uVar8 = *(undefined4 *)(arg1 + 0x114);
                    iVar10 = uVar11 * 0x20;
                    uVar11 = uVar11 + 1;
                    puVar1 = (undefined4 *)(iVar10 + iVar15);
                    *puVar1 = *(undefined4 *)(arg1 + 0x108);
                    puVar1[1] = uVar2;
                    puVar1[2] = uVar7;
                    puVar1[3] = uVar8;
                    *(undefined8 *)(iVar10 + 0x10 + iVar15) = *(undefined8 *)(arg1 + 0x118);
                    *(undefined4 *)(iVar15 + 0x18 + iVar10) = 0;
                } while (uVar11 < uVar6);
            }
        } else {
            *(undefined8 *)(puVar14 + -8) = 0x1800cebd4;
            func_0x0001800f4640(iVar15);
            *(undefined8 *)(arg1 + 0xf0) = 0;
            *(undefined8 *)(arg1 + 0xf8) = 0;
        }
        *(undefined8 *)(arg1 + 0x100) = 0;
    }
    if (*(int64_t *)(arg1 + 0x138) != 0) {
        uVar6 = *(uint64_t *)(arg1 + 0x130);
        uVar9 = *(undefined8 *)(arg1 + 0x128);
        if (uVar6 < 0x21) {
            *(undefined8 *)(puVar14 + -8) = 0x1800cec65;
            func_0x0001800d4300(uVar9, uVar6, arg1 + 0x140);
        } else {
            *(undefined8 *)(puVar14 + -8) = 0x1800cec49;
            func_0x0001800f4640();
            *(undefined8 *)(arg1 + 0x128) = 0;
            *(undefined8 *)(arg1 + 0x130) = 0;
        }
        *(undefined8 *)(arg1 + 0x138) = 0;
    }
    if (*(int64_t *)(arg1 + 0x260) != 0) {
        uVar6 = *(uint64_t *)(arg1 + 600);
        iVar15 = *(int64_t *)(arg1 + 0x250);
        if (uVar6 < 0x21) {
            if (uVar6 != 0) {
                do {
                    *(undefined4 *)(iVar15 + uVar12 * 8) = *(undefined4 *)(arg1 + 0x268);
                    *(undefined2 *)(iVar15 + 4 + uVar12 * 8) = 0;
                    uVar12 = uVar12 + 1;
                } while (uVar12 < uVar6);
            }
        } else {
            *(undefined8 *)(puVar14 + -8) = 0x1800cec91;
            func_0x0001800f4640(iVar15);
            *(undefined8 *)(arg1 + 0x250) = 0;
            *(undefined8 *)(arg1 + 600) = 0;
        }
        *(undefined8 *)(arg1 + 0x260) = 0;
    }
    if (*(int64_t *)(arg1 + 0x338) != *(int64_t *)(arg1 + 0x340)) {
        *(int64_t *)(arg1 + 0x340) = *(int64_t *)(arg1 + 0x338);
    }
    puVar13 = (undefined8 *)(arg1 + 0x350);
    *(undefined8 *)(arg1 + 0x360) = 0;
    if (0xf < *(uint64_t *)(arg1 + 0x368)) {
        puVar13 = (undefined8 *)*puVar13;
    }
    *(undefined *)puVar13 = 0;
    *(undefined8 *)(puVar14 + -8) = 0x1800ced0b;
    func_0x000180459870(*(uint64_t *)(puVar14 + 0x40) ^ (uint64_t)puVar14);
    return;
}

// ============================================================
// Function: FUN_1800ced20
// Address: 0x1800ced20
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

uint64_t fcn.1800ced20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_90h)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int32_t *piVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    uint32_t *puVar18;
    int32_t *piVar19;
    int64_t iVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uStackX_20;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar2 = (int64_t *)(arg1 + 0xf0);
    iVar8 = fcn.1800d3fe0(piVar2);
    puVar18 = (uint32_t *)(iVar8 + 0x18);
    if (iVar8 == 0) {
        puVar18 = (uint32_t *)0x0;
    }
    if (puVar18 != (uint32_t *)0x0) {
        return (uint64_t)*puVar18;
    }
    uVar9 = (*(int64_t *)(arg1 + 0x60) - *(int64_t *)(arg1 + 0x58) >> 3) * -0x5555555555555555;
    uVar7 = (uint32_t)uVar9;
    if (0x7fffff < uVar7) {
        return 0xffffffff;
    }
    iVar8 = *(int64_t *)(arg1 + 0xf8);
    if ((*(uint64_t *)(arg1 + 0x100) < (uint64_t)(iVar8 * 3) >> 2) ||
       (iVar10 = fcn.1800d3fe0(piVar2, arg2), iVar10 != 0)) goto code_r0x0001800cefdc;
    piVar1 = (int32_t *)(arg1 + 0x108);
    iVar3 = *piVar1;
    iVar10 = *(int64_t *)(arg1 + 0x110);
    if (iVar8 == 0) {
        var_8h = *(int64_t *)(arg1 + 0x118);
        uVar16 = 0x10;
        iVar11 = fcn.180459890();
        uStackX_20 = 0x10;
        uVar13 = 0;
        iVar8 = iVar11;
        iVar20 = iVar11;
        uVar17 = 0x10;
code_r0x0001800cee70:
        do {
            iVar4 = *(int32_t *)(arg1 + 0x10c);
            iVar5 = *(int32_t *)(arg1 + 0x110);
            iVar6 = *(int32_t *)(arg1 + 0x114);
            iVar12 = uVar13 * 0x20;
            uVar13 = uVar13 + 1;
            piVar19 = (int32_t *)(iVar12 + iVar11);
            *piVar19 = *piVar1;
            piVar19[1] = iVar4;
            piVar19[2] = iVar5;
            piVar19[3] = iVar6;
            *(undefined8 *)(iVar12 + 0x10 + iVar11) = *(undefined8 *)(arg1 + 0x118);
            *(undefined4 *)(iVar12 + 0x18 + iVar20) = 0;
        } while (uVar13 < uVar16);
    } else {
        var_8h = *(int64_t *)(arg1 + 0x118);
        uVar16 = iVar8 * 2;
        if (uVar16 == 0) {
            iVar8 = 0;
            uVar17 = 0;
            uStackX_20 = 0;
        } else {
            iVar11 = fcn.180459890();
            uVar13 = 0;
            iVar8 = iVar11;
            iVar20 = iVar11;
            uVar17 = uVar16;
            uStackX_20 = uVar16;
            if (uVar16 != 0) goto code_r0x0001800cee70;
        }
    }
    uVar16 = 0;
    if (*(int64_t *)(arg1 + 0xf8) != 0) {
        do {
            iVar20 = uVar16 * 0x20;
            piVar19 = (int32_t *)(*piVar2 + iVar20);
            iVar4 = *piVar19;
            if (((iVar4 != *piVar1) || (*(int64_t *)(piVar19 + 2) != *(int64_t *)(arg1 + 0x110))) ||
               (*(int64_t *)(piVar19 + 4) != *(int64_t *)(arg1 + 0x118))) {
                uVar17 = uVar17 - 1;
                uVar13 = fcn.1800cdd90();
                uVar15 = 0;
                while( true ) {
                    piVar14 = (int32_t *)((uVar13 & uVar17) * 0x20 + iVar8);
                    if (((*piVar14 == iVar3) && (*(int64_t *)(piVar14 + 2) == iVar10)) &&
                       (*(int64_t *)(piVar14 + 4) == var_8h)) {
                        iVar4 = piVar19[1];
                        iVar5 = piVar19[2];
                        iVar6 = piVar19[3];
                        *piVar14 = *piVar19;
                        piVar14[1] = iVar4;
                        piVar14[2] = iVar5;
                        piVar14[3] = iVar6;
                        *(undefined8 *)(piVar14 + 4) = *(undefined8 *)(piVar19 + 4);
                        goto code_r0x0001800cef76;
                    }
                    if (((*piVar14 == iVar4) && (*(int64_t *)(piVar14 + 2) == *(int64_t *)(piVar19 + 2))) &&
                       (*(int64_t *)(piVar14 + 4) == *(int64_t *)(piVar19 + 4))) goto code_r0x0001800cef76;
                    iVar11 = (uVar13 & uVar17) + uVar15;
                    uVar15 = uVar15 + 1;
                    if (uVar17 < uVar15) break;
                    uVar13 = iVar11 + 1;
                }
                piVar14 = (int32_t *)0x0;
code_r0x0001800cef76:
                iVar11 = *piVar2;
                piVar19 = (int32_t *)(iVar11 + iVar20);
                iVar4 = piVar19[1];
                iVar5 = piVar19[2];
                iVar6 = piVar19[3];
                *piVar14 = *piVar19;
                piVar14[1] = iVar4;
                piVar14[2] = iVar5;
                piVar14[3] = iVar6;
                *(undefined8 *)(piVar14 + 4) = *(undefined8 *)(iVar11 + 0x10 + iVar20);
                piVar14[6] = *(int32_t *)(iVar11 + 0x18 + iVar20);
                uVar17 = uStackX_20;
            }
            uVar16 = uVar16 + 1;
        } while (uVar16 < *(uint64_t *)(arg1 + 0xf8));
    }
    iVar10 = *piVar2;
    *piVar2 = iVar8;
    *(uint64_t *)(arg1 + 0xf8) = uVar17;
    if (iVar10 != 0) {
        fcn.1800f4640();
    }
code_r0x0001800cefdc:
    iVar8 = fcn.1800d40a0(piVar2, arg2);
    *(uint32_t *)(iVar8 + 0x18) = uVar7;
    fcn.1800d2f00((int64_t *)(arg1 + 0x58), arg3);
    return uVar9 & 0xffffffff;
}

// ============================================================
// Function: FUN_1800cedc8
// Address: 0x1800cedc8
// Size: 527 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

uint64_t fcn.1800ced20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_90h)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int32_t *piVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    uint32_t *puVar18;
    int32_t *piVar19;
    int64_t iVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uStackX_20;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar2 = (int64_t *)(arg1 + 0xf0);
    iVar8 = fcn.1800d3fe0(piVar2);
    puVar18 = (uint32_t *)(iVar8 + 0x18);
    if (iVar8 == 0) {
        puVar18 = (uint32_t *)0x0;
    }
    if (puVar18 != (uint32_t *)0x0) {
        return (uint64_t)*puVar18;
    }
    uVar9 = (*(int64_t *)(arg1 + 0x60) - *(int64_t *)(arg1 + 0x58) >> 3) * -0x5555555555555555;
    uVar7 = (uint32_t)uVar9;
    if (0x7fffff < uVar7) {
        return 0xffffffff;
    }
    iVar8 = *(int64_t *)(arg1 + 0xf8);
    if ((*(uint64_t *)(arg1 + 0x100) < (uint64_t)(iVar8 * 3) >> 2) ||
       (iVar10 = fcn.1800d3fe0(piVar2, arg2), iVar10 != 0)) goto code_r0x0001800cefdc;
    piVar1 = (int32_t *)(arg1 + 0x108);
    iVar3 = *piVar1;
    iVar10 = *(int64_t *)(arg1 + 0x110);
    if (iVar8 == 0) {
        var_8h = *(int64_t *)(arg1 + 0x118);
        uVar16 = 0x10;
        iVar11 = fcn.180459890();
        uStackX_20 = 0x10;
        uVar13 = 0;
        iVar8 = iVar11;
        iVar20 = iVar11;
        uVar17 = 0x10;
code_r0x0001800cee70:
        do {
            iVar4 = *(int32_t *)(arg1 + 0x10c);
            iVar5 = *(int32_t *)(arg1 + 0x110);
            iVar6 = *(int32_t *)(arg1 + 0x114);
            iVar12 = uVar13 * 0x20;
            uVar13 = uVar13 + 1;
            piVar19 = (int32_t *)(iVar12 + iVar11);
            *piVar19 = *piVar1;
            piVar19[1] = iVar4;
            piVar19[2] = iVar5;
            piVar19[3] = iVar6;
            *(undefined8 *)(iVar12 + 0x10 + iVar11) = *(undefined8 *)(arg1 + 0x118);
            *(undefined4 *)(iVar12 + 0x18 + iVar20) = 0;
        } while (uVar13 < uVar16);
    } else {
        var_8h = *(int64_t *)(arg1 + 0x118);
        uVar16 = iVar8 * 2;
        if (uVar16 == 0) {
            iVar8 = 0;
            uVar17 = 0;
            uStackX_20 = 0;
        } else {
            iVar11 = fcn.180459890();
            uVar13 = 0;
            iVar8 = iVar11;
            iVar20 = iVar11;
            uVar17 = uVar16;
            uStackX_20 = uVar16;
            if (uVar16 != 0) goto code_r0x0001800cee70;
        }
    }
    uVar16 = 0;
    if (*(int64_t *)(arg1 + 0xf8) != 0) {
        do {
            iVar20 = uVar16 * 0x20;
            piVar19 = (int32_t *)(*piVar2 + iVar20);
            iVar4 = *piVar19;
            if (((iVar4 != *piVar1) || (*(int64_t *)(piVar19 + 2) != *(int64_t *)(arg1 + 0x110))) ||
               (*(int64_t *)(piVar19 + 4) != *(int64_t *)(arg1 + 0x118))) {
                uVar17 = uVar17 - 1;
                uVar13 = fcn.1800cdd90();
                uVar15 = 0;
                while( true ) {
                    piVar14 = (int32_t *)((uVar13 & uVar17) * 0x20 + iVar8);
                    if (((*piVar14 == iVar3) && (*(int64_t *)(piVar14 + 2) == iVar10)) &&
                       (*(int64_t *)(piVar14 + 4) == var_8h)) {
                        iVar4 = piVar19[1];
                        iVar5 = piVar19[2];
                        iVar6 = piVar19[3];
                        *piVar14 = *piVar19;
                        piVar14[1] = iVar4;
                        piVar14[2] = iVar5;
                        piVar14[3] = iVar6;
                        *(undefined8 *)(piVar14 + 4) = *(undefined8 *)(piVar19 + 4);
                        goto code_r0x0001800cef76;
                    }
                    if (((*piVar14 == iVar4) && (*(int64_t *)(piVar14 + 2) == *(int64_t *)(piVar19 + 2))) &&
                       (*(int64_t *)(piVar14 + 4) == *(int64_t *)(piVar19 + 4))) goto code_r0x0001800cef76;
                    iVar11 = (uVar13 & uVar17) + uVar15;
                    uVar15 = uVar15 + 1;
                    if (uVar17 < uVar15) break;
                    uVar13 = iVar11 + 1;
                }
                piVar14 = (int32_t *)0x0;
code_r0x0001800cef76:
                iVar11 = *piVar2;
                piVar19 = (int32_t *)(iVar11 + iVar20);
                iVar4 = piVar19[1];
                iVar5 = piVar19[2];
                iVar6 = piVar19[3];
                *piVar14 = *piVar19;
                piVar14[1] = iVar4;
                piVar14[2] = iVar5;
                piVar14[3] = iVar6;
                *(undefined8 *)(piVar14 + 4) = *(undefined8 *)(iVar11 + 0x10 + iVar20);
                piVar14[6] = *(int32_t *)(iVar11 + 0x18 + iVar20);
                uVar17 = uStackX_20;
            }
            uVar16 = uVar16 + 1;
        } while (uVar16 < *(uint64_t *)(arg1 + 0xf8));
    }
    iVar10 = *piVar2;
    *piVar2 = iVar8;
    *(uint64_t *)(arg1 + 0xf8) = uVar17;
    if (iVar10 != 0) {
        fcn.1800f4640();
    }
code_r0x0001800cefdc:
    iVar8 = fcn.1800d40a0(piVar2, arg2);
    *(uint32_t *)(iVar8 + 0x18) = uVar7;
    fcn.1800d2f00((int64_t *)(arg1 + 0x58), arg3);
    return uVar9 & 0xffffffff;
}

// ============================================================
// Function: FUN_1800cefd7
// Address: 0x1800cefd7
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

uint64_t fcn.1800ced20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_90h)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int32_t *piVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    uint32_t *puVar18;
    int32_t *piVar19;
    int64_t iVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uStackX_20;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar2 = (int64_t *)(arg1 + 0xf0);
    iVar8 = fcn.1800d3fe0(piVar2);
    puVar18 = (uint32_t *)(iVar8 + 0x18);
    if (iVar8 == 0) {
        puVar18 = (uint32_t *)0x0;
    }
    if (puVar18 != (uint32_t *)0x0) {
        return (uint64_t)*puVar18;
    }
    uVar9 = (*(int64_t *)(arg1 + 0x60) - *(int64_t *)(arg1 + 0x58) >> 3) * -0x5555555555555555;
    uVar7 = (uint32_t)uVar9;
    if (0x7fffff < uVar7) {
        return 0xffffffff;
    }
    iVar8 = *(int64_t *)(arg1 + 0xf8);
    if ((*(uint64_t *)(arg1 + 0x100) < (uint64_t)(iVar8 * 3) >> 2) ||
       (iVar10 = fcn.1800d3fe0(piVar2, arg2), iVar10 != 0)) goto code_r0x0001800cefdc;
    piVar1 = (int32_t *)(arg1 + 0x108);
    iVar3 = *piVar1;
    iVar10 = *(int64_t *)(arg1 + 0x110);
    if (iVar8 == 0) {
        var_8h = *(int64_t *)(arg1 + 0x118);
        uVar16 = 0x10;
        iVar11 = fcn.180459890();
        uStackX_20 = 0x10;
        uVar13 = 0;
        iVar8 = iVar11;
        iVar20 = iVar11;
        uVar17 = 0x10;
code_r0x0001800cee70:
        do {
            iVar4 = *(int32_t *)(arg1 + 0x10c);
            iVar5 = *(int32_t *)(arg1 + 0x110);
            iVar6 = *(int32_t *)(arg1 + 0x114);
            iVar12 = uVar13 * 0x20;
            uVar13 = uVar13 + 1;
            piVar19 = (int32_t *)(iVar12 + iVar11);
            *piVar19 = *piVar1;
            piVar19[1] = iVar4;
            piVar19[2] = iVar5;
            piVar19[3] = iVar6;
            *(undefined8 *)(iVar12 + 0x10 + iVar11) = *(undefined8 *)(arg1 + 0x118);
            *(undefined4 *)(iVar12 + 0x18 + iVar20) = 0;
        } while (uVar13 < uVar16);
    } else {
        var_8h = *(int64_t *)(arg1 + 0x118);
        uVar16 = iVar8 * 2;
        if (uVar16 == 0) {
            iVar8 = 0;
            uVar17 = 0;
            uStackX_20 = 0;
        } else {
            iVar11 = fcn.180459890();
            uVar13 = 0;
            iVar8 = iVar11;
            iVar20 = iVar11;
            uVar17 = uVar16;
            uStackX_20 = uVar16;
            if (uVar16 != 0) goto code_r0x0001800cee70;
        }
    }
    uVar16 = 0;
    if (*(int64_t *)(arg1 + 0xf8) != 0) {
        do {
            iVar20 = uVar16 * 0x20;
            piVar19 = (int32_t *)(*piVar2 + iVar20);
            iVar4 = *piVar19;
            if (((iVar4 != *piVar1) || (*(int64_t *)(piVar19 + 2) != *(int64_t *)(arg1 + 0x110))) ||
               (*(int64_t *)(piVar19 + 4) != *(int64_t *)(arg1 + 0x118))) {
                uVar17 = uVar17 - 1;
                uVar13 = fcn.1800cdd90();
                uVar15 = 0;
                while( true ) {
                    piVar14 = (int32_t *)((uVar13 & uVar17) * 0x20 + iVar8);
                    if (((*piVar14 == iVar3) && (*(int64_t *)(piVar14 + 2) == iVar10)) &&
                       (*(int64_t *)(piVar14 + 4) == var_8h)) {
                        iVar4 = piVar19[1];
                        iVar5 = piVar19[2];
                        iVar6 = piVar19[3];
                        *piVar14 = *piVar19;
                        piVar14[1] = iVar4;
                        piVar14[2] = iVar5;
                        piVar14[3] = iVar6;
                        *(undefined8 *)(piVar14 + 4) = *(undefined8 *)(piVar19 + 4);
                        goto code_r0x0001800cef76;
                    }
                    if (((*piVar14 == iVar4) && (*(int64_t *)(piVar14 + 2) == *(int64_t *)(piVar19 + 2))) &&
                       (*(int64_t *)(piVar14 + 4) == *(int64_t *)(piVar19 + 4))) goto code_r0x0001800cef76;
                    iVar11 = (uVar13 & uVar17) + uVar15;
                    uVar15 = uVar15 + 1;
                    if (uVar17 < uVar15) break;
                    uVar13 = iVar11 + 1;
                }
                piVar14 = (int32_t *)0x0;
code_r0x0001800cef76:
                iVar11 = *piVar2;
                piVar19 = (int32_t *)(iVar11 + iVar20);
                iVar4 = piVar19[1];
                iVar5 = piVar19[2];
                iVar6 = piVar19[3];
                *piVar14 = *piVar19;
                piVar14[1] = iVar4;
                piVar14[2] = iVar5;
                piVar14[3] = iVar6;
                *(undefined8 *)(piVar14 + 4) = *(undefined8 *)(iVar11 + 0x10 + iVar20);
                piVar14[6] = *(int32_t *)(iVar11 + 0x18 + iVar20);
                uVar17 = uStackX_20;
            }
            uVar16 = uVar16 + 1;
        } while (uVar16 < *(uint64_t *)(arg1 + 0xf8));
    }
    iVar10 = *piVar2;
    *piVar2 = iVar8;
    *(uint64_t *)(arg1 + 0xf8) = uVar17;
    if (iVar10 != 0) {
        fcn.1800f4640();
    }
code_r0x0001800cefdc:
    iVar8 = fcn.1800d40a0(piVar2, arg2);
    *(uint32_t *)(iVar8 + 0x18) = uVar7;
    fcn.1800d2f00((int64_t *)(arg1 + 0x58), arg3);
    return uVar9 & 0xffffffff;
}

// ============================================================
// Function: FUN_1800cf010
// Address: 0x1800cf010
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_40h

uint64_t fcn.1800cf010(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint8_t *puVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint32_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    uint64_t uVar15;
    undefined *puVar16;
    uint64_t uVar17;
    int64_t iVar18;
    int64_t iVar19;
    uint64_t uVar20;
    bool bVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    
    piVar1 = (int64_t *)(arg1 + 0x2f0);
    iVar10 = *(int64_t *)(arg1 + 0x2f8);
    if ((uint64_t)(iVar10 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x300)) {
        if (*(uint64_t *)(arg1 + 0x300) != 0) {
            iVar18 = *(int64_t *)arg2;
            if ((iVar18 == 0) || (*(int64_t *)(arg1 + 0x308) == 0)) {
                if (iVar18 != *(int64_t *)(arg1 + 0x308)) goto code_r0x0001800cf0aa;
            } else if ((*(int64_t *)(arg2 + 8) != *(int64_t *)(arg1 + 0x310)) ||
                      (iVar9 = func_0x000180497f30(), iVar9 != 0)) {
code_r0x0001800cf0aa:
                uVar15 = *(uint64_t *)(arg2 + 8);
                uVar17 = iVar10 - 1;
                uVar12 = 0x811c9dc5;
                if (uVar15 != 0) {
                    uVar11 = 0;
                    do {
                        puVar2 = (uint8_t *)(iVar18 + uVar11);
                        uVar11 = uVar11 + 1;
                        uVar12 = (*puVar2 ^ uVar12) * 0x1000193;
                    } while (uVar11 < uVar15);
                }
                iVar10 = *piVar1;
                uVar11 = (uint64_t)uVar12;
                uVar20 = 0;
                do {
                    uVar11 = uVar11 & uVar17;
                    iVar14 = uVar11 * 0x18;
                    iVar19 = *(int64_t *)(iVar14 + iVar10);
                    if (iVar19 == 0) {
                        if (iVar18 == 0) goto code_r0x0001800cf3de;
code_r0x0001800cf156:
                        bVar21 = iVar19 == *(int64_t *)(arg1 + 0x308);
code_r0x0001800cf15d:
                        if (bVar21) break;
                    } else {
                        if (((iVar18 != 0) && (*(uint64_t *)(iVar14 + 8 + iVar10) == uVar15)) &&
                           (iVar9 = func_0x000180497f30(iVar19, iVar18), iVar9 == 0)) goto code_r0x0001800cf3de;
                        if (*(int64_t *)(arg1 + 0x308) == 0) goto code_r0x0001800cf156;
                        if (*(int64_t *)(iVar14 + 8 + iVar10) == *(int64_t *)(arg1 + 0x310)) {
                            iVar9 = func_0x000180497f30(iVar19);
                            bVar21 = iVar9 == 0;
                            goto code_r0x0001800cf15d;
                        }
                    }
                    iVar14 = uVar11 + uVar20;
                    uVar20 = uVar20 + 1;
                    if (uVar17 < uVar20) break;
                    uVar11 = iVar14 + 1;
                } while( true );
            }
        }
        iVar10 = *(int64_t *)(arg1 + 0x308);
        if (*(int64_t *)(arg1 + 0x2f8) == 0) {
            var_20h = *(int64_t *)(arg1 + 0x310);
            uVar15 = 0x10;
            iVar14 = fcn.180459890();
            var_58h = 0x10;
            uVar11 = 0;
            uVar17 = 0x10;
            iVar18 = iVar14;
            var_18h = iVar14;
code_r0x0001800cf200:
            do {
                uVar6 = *(undefined4 *)(arg1 + 0x30c);
                uVar7 = *(undefined4 *)(arg1 + 0x310);
                uVar8 = *(undefined4 *)(arg1 + 0x314);
                uVar20 = uVar11 + 1;
                puVar13 = (undefined4 *)(iVar14 + uVar11 * 0x18);
                *puVar13 = *(undefined4 *)(arg1 + 0x308);
                puVar13[1] = uVar6;
                puVar13[2] = uVar7;
                puVar13[3] = uVar8;
                *(undefined4 *)(iVar14 + 0x10 + uVar11 * 0x18) = 0;
                uVar11 = uVar20;
            } while (uVar20 < uVar15);
        } else {
            var_20h = *(int64_t *)(arg1 + 0x310);
            uVar15 = *(int64_t *)(arg1 + 0x2f8) * 2;
            if (uVar15 == 0) {
                uVar17 = 0;
                iVar18 = 0;
                var_58h = 0;
                var_18h = 0;
            } else {
                iVar14 = fcn.180459890();
                uVar11 = 0;
                uVar17 = uVar15;
                iVar18 = iVar14;
                var_18h = iVar14;
                var_58h = uVar15;
                if (uVar15 != 0) goto code_r0x0001800cf200;
            }
        }
        var_50h = 0;
        if (*(int64_t *)(arg1 + 0x2f8) != 0) {
code_r0x0001800cf260:
            iVar19 = var_50h;
            iVar14 = *(int64_t *)(*piVar1 + var_50h * 0x18);
            piVar3 = (int64_t *)(*piVar1 + var_50h * 0x18);
            if ((iVar14 == 0) || (*(int64_t *)(arg1 + 0x308) == 0)) {
                if (iVar14 != *(int64_t *)(arg1 + 0x308)) goto code_r0x0001800cf2b4;
            } else if ((piVar3[1] != *(int64_t *)(arg1 + 0x310)) ||
                      (iVar9 = func_0x000180497f30(), iVar18 = var_18h, iVar9 != 0)) {
code_r0x0001800cf2b4:
                uVar12 = 0x811c9dc5;
                if (piVar3[1] != 0) {
                    uVar15 = 0;
                    do {
                        puVar2 = (uint8_t *)(iVar14 + uVar15);
                        uVar15 = uVar15 + 1;
                        uVar12 = (*puVar2 ^ uVar12) * 0x1000193;
                    } while (uVar15 < (uint64_t)piVar3[1]);
                }
                uVar15 = (uint64_t)uVar12;
                uVar11 = 0;
                do {
                    uVar15 = uVar15 & uVar17 - 1;
                    iVar14 = *(int64_t *)(iVar18 + uVar15 * 0x18);
                    puVar13 = (undefined4 *)(iVar18 + uVar15 * 0x18);
                    if (iVar14 == 0) {
                        if (iVar10 == 0) goto code_r0x0001800cf36a;
code_r0x0001800cf346:
                        bVar21 = iVar14 == *piVar3;
code_r0x0001800cf349:
                        if (bVar21) goto code_r0x0001800cf371;
                    } else {
                        if (((iVar10 != 0) && (*(int64_t *)(puVar13 + 2) == var_20h)) &&
                           (iVar9 = func_0x000180497f30(iVar14, iVar10), iVar9 == 0)) {
code_r0x0001800cf36a:
                            uVar6 = *(undefined4 *)((int64_t)piVar3 + 4);
                            uVar7 = *(undefined4 *)(piVar3 + 1);
                            uVar8 = *(undefined4 *)((int64_t)piVar3 + 0xc);
                            *puVar13 = *(undefined4 *)piVar3;
                            puVar13[1] = uVar6;
                            puVar13[2] = uVar7;
                            puVar13[3] = uVar8;
                            goto code_r0x0001800cf371;
                        }
                        if (*piVar3 == 0) goto code_r0x0001800cf346;
                        if (*(int64_t *)(puVar13 + 2) == piVar3[1]) {
                            iVar9 = func_0x000180497f30(iVar14);
                            bVar21 = iVar9 == 0;
                            goto code_r0x0001800cf349;
                        }
                    }
                    iVar18 = uVar15 + uVar11;
                    uVar11 = uVar11 + 1;
                    if (uVar17 - 1 < uVar11) goto code_r0x0001800cf366;
                    uVar15 = iVar18 + 1;
                    iVar18 = var_18h;
                } while( true );
            }
            goto code_r0x0001800cf3a1;
        }
code_r0x0001800cf3b6:
        iVar10 = *piVar1;
        *piVar1 = iVar18;
        *(uint64_t *)(arg1 + 0x2f8) = uVar17;
        if (iVar10 != 0) {
            fcn.1800f4640();
        }
    }
code_r0x0001800cf3de:
    iVar10 = func_0x0001800d3850(piVar1, arg2);
    if ((*(int32_t *)(iVar10 + 0x10) != 0) ||
       (*(undefined4 *)(iVar10 + 0x10) = *(undefined4 *)(arg1 + 0x300), (*(uint8_t *)(arg1 + 0x398) & 1) == 0))
    goto code_r0x0001800cf43a;
    puVar13 = *(undefined4 **)(arg1 + 0x328);
    if (puVar13 != *(undefined4 **)(arg1 + 0x330)) {
        uVar6 = *(undefined4 *)(arg2 + 4);
        uVar7 = *(undefined4 *)(arg2 + 8);
        uVar8 = *(undefined4 *)(arg2 + 0xc);
        *puVar13 = *(undefined4 *)arg2;
        puVar13[1] = uVar6;
        puVar13[2] = uVar7;
        puVar13[3] = uVar8;
        *(int64_t *)(arg1 + 0x328) = *(int64_t *)(arg1 + 0x328) + 0x10;
        goto code_r0x0001800cf43a;
    }
    iVar18 = (int64_t)puVar13 - *(int64_t *)(arg1 + 800) >> 4;
    if (iVar18 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar5 = (code *)swi(3);
        uVar15 = (*pcVar5)();
        return uVar15;
    }
    uVar15 = (int64_t)*(undefined4 **)(arg1 + 0x330) - *(int64_t *)(arg1 + 800) >> 4;
    if (0xfffffffffffffff - (uVar15 >> 1) < uVar15) {
code_r0x0001800cf5c7:
        fcn.180004720();
        pcVar5 = (code *)swi(3);
        uVar15 = (*pcVar5)();
        return uVar15;
    }
    uVar17 = iVar18 + 1;
    uVar15 = (uVar15 >> 1) + uVar15;
    uVar11 = uVar17;
    if (uVar17 <= uVar15) {
        uVar11 = uVar15;
    }
    if (0xfffffffffffffff < uVar11) goto code_r0x0001800cf5c7;
    uVar15 = uVar11 * 0x10;
    if (uVar15 == 0) {
        uVar15 = 0;
code_r0x0001800cf4f6:
        uVar6 = *(undefined4 *)(arg2 + 4);
        uVar7 = *(undefined4 *)(arg2 + 8);
        uVar8 = *(undefined4 *)(arg2 + 0xc);
        puVar4 = (undefined4 *)(iVar18 * 0x10 + uVar15);
        *puVar4 = *(undefined4 *)arg2;
        puVar4[1] = uVar6;
        puVar4[2] = uVar7;
        puVar4[3] = uVar8;
        puVar4 = *(undefined4 **)(arg1 + 800);
        if (puVar13 == *(undefined4 **)(arg1 + 0x328)) {
            iVar14 = (int64_t)*(undefined4 **)(arg1 + 0x328) - (int64_t)puVar4;
            uVar20 = uVar15;
            puVar13 = puVar4;
        } else {
            fcn.180498030(uVar15, puVar4, (int64_t)puVar13 - (int64_t)puVar4);
            iVar14 = *(int64_t *)(arg1 + 0x328) - (int64_t)puVar13;
            uVar20 = uVar15 + 0x10 + iVar18 * 0x10;
        }
        fcn.180498030(uVar20, puVar13, iVar14);
        iVar18 = *(int64_t *)(arg1 + 800);
        if (iVar18 != 0) {
            iVar14 = iVar18;
            puVar16 = auStack_78;
            if ((0xfff < (*(int64_t *)(arg1 + 0x330) - iVar18 & 0xfffffffffffffff0U)) &&
               (iVar14 = *(int64_t *)(iVar18 + -8), arg2 = uVar15, puVar16 = auStack_78, 0x1f < (iVar18 - iVar14) - 8U))
            goto code_r0x0001800cf587;
            goto code_r0x0001800cf591;
        }
    } else {
        if (uVar15 < 0x1000) {
            uVar15 = fcn.180459890();
            goto code_r0x0001800cf4f6;
        }
        if (uVar15 + 0x27 <= uVar15) goto code_r0x0001800cf5c7;
        iVar14 = fcn.180459890(uVar15 + 0x27);
        if (iVar14 != 0) {
            uVar15 = iVar14 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar15 - 8) = iVar14;
            goto code_r0x0001800cf4f6;
        }
code_r0x0001800cf587:
        pcVar5 = (code *)swi(0x29);
        iVar14 = (*pcVar5)(5);
        uVar15 = arg2;
        puVar16 = auStack_70;
code_r0x0001800cf591:
        *(undefined8 *)(puVar16 + -8) = 0x1800cf596;
        fcn.180459c3c(iVar14);
    }
    *(uint64_t *)(arg1 + 800) = uVar15;
    *(uint64_t *)(arg1 + 0x328) = uVar17 * 0x10 + uVar15;
    *(uint64_t *)(arg1 + 0x330) = uVar11 * 0x10 + uVar15;
code_r0x0001800cf43a:
    return (uint64_t)*(uint32_t *)(iVar10 + 0x10);
code_r0x0001800cf366:
    puVar13 = (undefined4 *)0x0;
code_r0x0001800cf371:
    iVar18 = *piVar1;
    puVar4 = (undefined4 *)(iVar18 + var_50h * 0x18);
    uVar6 = puVar4[1];
    uVar7 = puVar4[2];
    uVar8 = puVar4[3];
    *puVar13 = *puVar4;
    puVar13[1] = uVar6;
    puVar13[2] = uVar7;
    puVar13[3] = uVar8;
    puVar13[4] = *(undefined4 *)(iVar18 + 0x10 + var_50h * 0x18);
    uVar17 = var_58h;
    iVar18 = var_18h;
    iVar19 = var_50h;
code_r0x0001800cf3a1:
    var_50h = iVar19 + 1;
    if (*(uint64_t *)(arg1 + 0x2f8) <= (uint64_t)var_50h) goto code_r0x0001800cf3b6;
    goto code_r0x0001800cf260;
}

// ============================================================
// Function: FUN_1800cf029
// Address: 0x1800cf029
// Size: 982 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_40h

uint64_t fcn.1800cf010(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint8_t *puVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint32_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    uint64_t uVar15;
    undefined *puVar16;
    uint64_t uVar17;
    int64_t iVar18;
    int64_t iVar19;
    uint64_t uVar20;
    bool bVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    
    piVar1 = (int64_t *)(arg1 + 0x2f0);
    iVar10 = *(int64_t *)(arg1 + 0x2f8);
    if ((uint64_t)(iVar10 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x300)) {
        if (*(uint64_t *)(arg1 + 0x300) != 0) {
            iVar18 = *(int64_t *)arg2;
            if ((iVar18 == 0) || (*(int64_t *)(arg1 + 0x308) == 0)) {
                if (iVar18 != *(int64_t *)(arg1 + 0x308)) goto code_r0x0001800cf0aa;
            } else if ((*(int64_t *)(arg2 + 8) != *(int64_t *)(arg1 + 0x310)) ||
                      (iVar9 = func_0x000180497f30(), iVar9 != 0)) {
code_r0x0001800cf0aa:
                uVar15 = *(uint64_t *)(arg2 + 8);
                uVar17 = iVar10 - 1;
                uVar12 = 0x811c9dc5;
                if (uVar15 != 0) {
                    uVar11 = 0;
                    do {
                        puVar2 = (uint8_t *)(iVar18 + uVar11);
                        uVar11 = uVar11 + 1;
                        uVar12 = (*puVar2 ^ uVar12) * 0x1000193;
                    } while (uVar11 < uVar15);
                }
                iVar10 = *piVar1;
                uVar11 = (uint64_t)uVar12;
                uVar20 = 0;
                do {
                    uVar11 = uVar11 & uVar17;
                    iVar14 = uVar11 * 0x18;
                    iVar19 = *(int64_t *)(iVar14 + iVar10);
                    if (iVar19 == 0) {
                        if (iVar18 == 0) goto code_r0x0001800cf3de;
code_r0x0001800cf156:
                        bVar21 = iVar19 == *(int64_t *)(arg1 + 0x308);
code_r0x0001800cf15d:
                        if (bVar21) break;
                    } else {
                        if (((iVar18 != 0) && (*(uint64_t *)(iVar14 + 8 + iVar10) == uVar15)) &&
                           (iVar9 = func_0x000180497f30(iVar19, iVar18), iVar9 == 0)) goto code_r0x0001800cf3de;
                        if (*(int64_t *)(arg1 + 0x308) == 0) goto code_r0x0001800cf156;
                        if (*(int64_t *)(iVar14 + 8 + iVar10) == *(int64_t *)(arg1 + 0x310)) {
                            iVar9 = func_0x000180497f30(iVar19);
                            bVar21 = iVar9 == 0;
                            goto code_r0x0001800cf15d;
                        }
                    }
                    iVar14 = uVar11 + uVar20;
                    uVar20 = uVar20 + 1;
                    if (uVar17 < uVar20) break;
                    uVar11 = iVar14 + 1;
                } while( true );
            }
        }
        iVar10 = *(int64_t *)(arg1 + 0x308);
        if (*(int64_t *)(arg1 + 0x2f8) == 0) {
            var_20h = *(int64_t *)(arg1 + 0x310);
            uVar15 = 0x10;
            iVar14 = fcn.180459890();
            var_58h = 0x10;
            uVar11 = 0;
            uVar17 = 0x10;
            iVar18 = iVar14;
            var_18h = iVar14;
code_r0x0001800cf200:
            do {
                uVar6 = *(undefined4 *)(arg1 + 0x30c);
                uVar7 = *(undefined4 *)(arg1 + 0x310);
                uVar8 = *(undefined4 *)(arg1 + 0x314);
                uVar20 = uVar11 + 1;
                puVar13 = (undefined4 *)(iVar14 + uVar11 * 0x18);
                *puVar13 = *(undefined4 *)(arg1 + 0x308);
                puVar13[1] = uVar6;
                puVar13[2] = uVar7;
                puVar13[3] = uVar8;
                *(undefined4 *)(iVar14 + 0x10 + uVar11 * 0x18) = 0;
                uVar11 = uVar20;
            } while (uVar20 < uVar15);
        } else {
            var_20h = *(int64_t *)(arg1 + 0x310);
            uVar15 = *(int64_t *)(arg1 + 0x2f8) * 2;
            if (uVar15 == 0) {
                uVar17 = 0;
                iVar18 = 0;
                var_58h = 0;
                var_18h = 0;
            } else {
                iVar14 = fcn.180459890();
                uVar11 = 0;
                uVar17 = uVar15;
                iVar18 = iVar14;
                var_18h = iVar14;
                var_58h = uVar15;
                if (uVar15 != 0) goto code_r0x0001800cf200;
            }
        }
        var_50h = 0;
        if (*(int64_t *)(arg1 + 0x2f8) != 0) {
code_r0x0001800cf260:
            iVar19 = var_50h;
            iVar14 = *(int64_t *)(*piVar1 + var_50h * 0x18);
            piVar3 = (int64_t *)(*piVar1 + var_50h * 0x18);
            if ((iVar14 == 0) || (*(int64_t *)(arg1 + 0x308) == 0)) {
                if (iVar14 != *(int64_t *)(arg1 + 0x308)) goto code_r0x0001800cf2b4;
            } else if ((piVar3[1] != *(int64_t *)(arg1 + 0x310)) ||
                      (iVar9 = func_0x000180497f30(), iVar18 = var_18h, iVar9 != 0)) {
code_r0x0001800cf2b4:
                uVar12 = 0x811c9dc5;
                if (piVar3[1] != 0) {
                    uVar15 = 0;
                    do {
                        puVar2 = (uint8_t *)(iVar14 + uVar15);
                        uVar15 = uVar15 + 1;
                        uVar12 = (*puVar2 ^ uVar12) * 0x1000193;
                    } while (uVar15 < (uint64_t)piVar3[1]);
                }
                uVar15 = (uint64_t)uVar12;
                uVar11 = 0;
                do {
                    uVar15 = uVar15 & uVar17 - 1;
                    iVar14 = *(int64_t *)(iVar18 + uVar15 * 0x18);
                    puVar13 = (undefined4 *)(iVar18 + uVar15 * 0x18);
                    if (iVar14 == 0) {
                        if (iVar10 == 0) goto code_r0x0001800cf36a;
code_r0x0001800cf346:
                        bVar21 = iVar14 == *piVar3;
code_r0x0001800cf349:
                        if (bVar21) goto code_r0x0001800cf371;
                    } else {
                        if (((iVar10 != 0) && (*(int64_t *)(puVar13 + 2) == var_20h)) &&
                           (iVar9 = func_0x000180497f30(iVar14, iVar10), iVar9 == 0)) {
code_r0x0001800cf36a:
                            uVar6 = *(undefined4 *)((int64_t)piVar3 + 4);
                            uVar7 = *(undefined4 *)(piVar3 + 1);
                            uVar8 = *(undefined4 *)((int64_t)piVar3 + 0xc);
                            *puVar13 = *(undefined4 *)piVar3;
                            puVar13[1] = uVar6;
                            puVar13[2] = uVar7;
                            puVar13[3] = uVar8;
                            goto code_r0x0001800cf371;
                        }
                        if (*piVar3 == 0) goto code_r0x0001800cf346;
                        if (*(int64_t *)(puVar13 + 2) == piVar3[1]) {
                            iVar9 = func_0x000180497f30(iVar14);
                            bVar21 = iVar9 == 0;
                            goto code_r0x0001800cf349;
                        }
                    }
                    iVar18 = uVar15 + uVar11;
                    uVar11 = uVar11 + 1;
                    if (uVar17 - 1 < uVar11) goto code_r0x0001800cf366;
                    uVar15 = iVar18 + 1;
                    iVar18 = var_18h;
                } while( true );
            }
            goto code_r0x0001800cf3a1;
        }
code_r0x0001800cf3b6:
        iVar10 = *piVar1;
        *piVar1 = iVar18;
        *(uint64_t *)(arg1 + 0x2f8) = uVar17;
        if (iVar10 != 0) {
            fcn.1800f4640();
        }
    }
code_r0x0001800cf3de:
    iVar10 = func_0x0001800d3850(piVar1, arg2);
    if ((*(int32_t *)(iVar10 + 0x10) != 0) ||
       (*(undefined4 *)(iVar10 + 0x10) = *(undefined4 *)(arg1 + 0x300), (*(uint8_t *)(arg1 + 0x398) & 1) == 0))
    goto code_r0x0001800cf43a;
    puVar13 = *(undefined4 **)(arg1 + 0x328);
    if (puVar13 != *(undefined4 **)(arg1 + 0x330)) {
        uVar6 = *(undefined4 *)(arg2 + 4);
        uVar7 = *(undefined4 *)(arg2 + 8);
        uVar8 = *(undefined4 *)(arg2 + 0xc);
        *puVar13 = *(undefined4 *)arg2;
        puVar13[1] = uVar6;
        puVar13[2] = uVar7;
        puVar13[3] = uVar8;
        *(int64_t *)(arg1 + 0x328) = *(int64_t *)(arg1 + 0x328) + 0x10;
        goto code_r0x0001800cf43a;
    }
    iVar18 = (int64_t)puVar13 - *(int64_t *)(arg1 + 800) >> 4;
    if (iVar18 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar5 = (code *)swi(3);
        uVar15 = (*pcVar5)();
        return uVar15;
    }
    uVar15 = (int64_t)*(undefined4 **)(arg1 + 0x330) - *(int64_t *)(arg1 + 800) >> 4;
    if (0xfffffffffffffff - (uVar15 >> 1) < uVar15) {
code_r0x0001800cf5c7:
        fcn.180004720();
        pcVar5 = (code *)swi(3);
        uVar15 = (*pcVar5)();
        return uVar15;
    }
    uVar17 = iVar18 + 1;
    uVar15 = (uVar15 >> 1) + uVar15;
    uVar11 = uVar17;
    if (uVar17 <= uVar15) {
        uVar11 = uVar15;
    }
    if (0xfffffffffffffff < uVar11) goto code_r0x0001800cf5c7;
    uVar15 = uVar11 * 0x10;
    if (uVar15 == 0) {
        uVar15 = 0;
code_r0x0001800cf4f6:
        uVar6 = *(undefined4 *)(arg2 + 4);
        uVar7 = *(undefined4 *)(arg2 + 8);
        uVar8 = *(undefined4 *)(arg2 + 0xc);
        puVar4 = (undefined4 *)(iVar18 * 0x10 + uVar15);
        *puVar4 = *(undefined4 *)arg2;
        puVar4[1] = uVar6;
        puVar4[2] = uVar7;
        puVar4[3] = uVar8;
        puVar4 = *(undefined4 **)(arg1 + 800);
        if (puVar13 == *(undefined4 **)(arg1 + 0x328)) {
            iVar14 = (int64_t)*(undefined4 **)(arg1 + 0x328) - (int64_t)puVar4;
            uVar20 = uVar15;
            puVar13 = puVar4;
        } else {
            fcn.180498030(uVar15, puVar4, (int64_t)puVar13 - (int64_t)puVar4);
            iVar14 = *(int64_t *)(arg1 + 0x328) - (int64_t)puVar13;
            uVar20 = uVar15 + 0x10 + iVar18 * 0x10;
        }
        fcn.180498030(uVar20, puVar13, iVar14);
        iVar18 = *(int64_t *)(arg1 + 800);
        if (iVar18 != 0) {
            iVar14 = iVar18;
            puVar16 = auStack_78;
            if ((0xfff < (*(int64_t *)(arg1 + 0x330) - iVar18 & 0xfffffffffffffff0U)) &&
               (iVar14 = *(int64_t *)(iVar18 + -8), arg2 = uVar15, puVar16 = auStack_78, 0x1f < (iVar18 - iVar14) - 8U))
            goto code_r0x0001800cf587;
            goto code_r0x0001800cf591;
        }
    } else {
        if (uVar15 < 0x1000) {
            uVar15 = fcn.180459890();
            goto code_r0x0001800cf4f6;
        }
        if (uVar15 + 0x27 <= uVar15) goto code_r0x0001800cf5c7;
        iVar14 = fcn.180459890(uVar15 + 0x27);
        if (iVar14 != 0) {
            uVar15 = iVar14 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar15 - 8) = iVar14;
            goto code_r0x0001800cf4f6;
        }
code_r0x0001800cf587:
        pcVar5 = (code *)swi(0x29);
        iVar14 = (*pcVar5)(5);
        uVar15 = arg2;
        puVar16 = auStack_70;
code_r0x0001800cf591:
        *(undefined8 *)(puVar16 + -8) = 0x1800cf596;
        fcn.180459c3c(iVar14);
    }
    *(uint64_t *)(arg1 + 800) = uVar15;
    *(uint64_t *)(arg1 + 0x328) = uVar17 * 0x10 + uVar15;
    *(uint64_t *)(arg1 + 0x330) = uVar11 * 0x10 + uVar15;
code_r0x0001800cf43a:
    return (uint64_t)*(uint32_t *)(iVar10 + 0x10);
code_r0x0001800cf366:
    puVar13 = (undefined4 *)0x0;
code_r0x0001800cf371:
    iVar18 = *piVar1;
    puVar4 = (undefined4 *)(iVar18 + var_50h * 0x18);
    uVar6 = puVar4[1];
    uVar7 = puVar4[2];
    uVar8 = puVar4[3];
    *puVar13 = *puVar4;
    puVar13[1] = uVar6;
    puVar13[2] = uVar7;
    puVar13[3] = uVar8;
    puVar13[4] = *(undefined4 *)(iVar18 + 0x10 + var_50h * 0x18);
    uVar17 = var_58h;
    iVar18 = var_18h;
    iVar19 = var_50h;
code_r0x0001800cf3a1:
    var_50h = iVar19 + 1;
    if (*(uint64_t *)(arg1 + 0x2f8) <= (uint64_t)var_50h) goto code_r0x0001800cf3b6;
    goto code_r0x0001800cf260;
}

// ============================================================
// Function: FUN_1800cf3ff
// Address: 0x1800cf3ff
// Size: 462 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_40h

uint64_t fcn.1800cf010(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint8_t *puVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint32_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    uint64_t uVar15;
    undefined *puVar16;
    uint64_t uVar17;
    int64_t iVar18;
    int64_t iVar19;
    uint64_t uVar20;
    bool bVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    
    piVar1 = (int64_t *)(arg1 + 0x2f0);
    iVar10 = *(int64_t *)(arg1 + 0x2f8);
    if ((uint64_t)(iVar10 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x300)) {
        if (*(uint64_t *)(arg1 + 0x300) != 0) {
            iVar18 = *(int64_t *)arg2;
            if ((iVar18 == 0) || (*(int64_t *)(arg1 + 0x308) == 0)) {
                if (iVar18 != *(int64_t *)(arg1 + 0x308)) goto code_r0x0001800cf0aa;
            } else if ((*(int64_t *)(arg2 + 8) != *(int64_t *)(arg1 + 0x310)) ||
                      (iVar9 = func_0x000180497f30(), iVar9 != 0)) {
code_r0x0001800cf0aa:
                uVar15 = *(uint64_t *)(arg2 + 8);
                uVar17 = iVar10 - 1;
                uVar12 = 0x811c9dc5;
                if (uVar15 != 0) {
                    uVar11 = 0;
                    do {
                        puVar2 = (uint8_t *)(iVar18 + uVar11);
                        uVar11 = uVar11 + 1;
                        uVar12 = (*puVar2 ^ uVar12) * 0x1000193;
                    } while (uVar11 < uVar15);
                }
                iVar10 = *piVar1;
                uVar11 = (uint64_t)uVar12;
                uVar20 = 0;
                do {
                    uVar11 = uVar11 & uVar17;
                    iVar14 = uVar11 * 0x18;
                    iVar19 = *(int64_t *)(iVar14 + iVar10);
                    if (iVar19 == 0) {
                        if (iVar18 == 0) goto code_r0x0001800cf3de;
code_r0x0001800cf156:
                        bVar21 = iVar19 == *(int64_t *)(arg1 + 0x308);
code_r0x0001800cf15d:
                        if (bVar21) break;
                    } else {
                        if (((iVar18 != 0) && (*(uint64_t *)(iVar14 + 8 + iVar10) == uVar15)) &&
                           (iVar9 = func_0x000180497f30(iVar19, iVar18), iVar9 == 0)) goto code_r0x0001800cf3de;
                        if (*(int64_t *)(arg1 + 0x308) == 0) goto code_r0x0001800cf156;
                        if (*(int64_t *)(iVar14 + 8 + iVar10) == *(int64_t *)(arg1 + 0x310)) {
                            iVar9 = func_0x000180497f30(iVar19);
                            bVar21 = iVar9 == 0;
                            goto code_r0x0001800cf15d;
                        }
                    }
                    iVar14 = uVar11 + uVar20;
                    uVar20 = uVar20 + 1;
                    if (uVar17 < uVar20) break;
                    uVar11 = iVar14 + 1;
                } while( true );
            }
        }
        iVar10 = *(int64_t *)(arg1 + 0x308);
        if (*(int64_t *)(arg1 + 0x2f8) == 0) {
            var_20h = *(int64_t *)(arg1 + 0x310);
            uVar15 = 0x10;
            iVar14 = fcn.180459890();
            var_58h = 0x10;
            uVar11 = 0;
            uVar17 = 0x10;
            iVar18 = iVar14;
            var_18h = iVar14;
code_r0x0001800cf200:
            do {
                uVar6 = *(undefined4 *)(arg1 + 0x30c);
                uVar7 = *(undefined4 *)(arg1 + 0x310);
                uVar8 = *(undefined4 *)(arg1 + 0x314);
                uVar20 = uVar11 + 1;
                puVar13 = (undefined4 *)(iVar14 + uVar11 * 0x18);
                *puVar13 = *(undefined4 *)(arg1 + 0x308);
                puVar13[1] = uVar6;
                puVar13[2] = uVar7;
                puVar13[3] = uVar8;
                *(undefined4 *)(iVar14 + 0x10 + uVar11 * 0x18) = 0;
                uVar11 = uVar20;
            } while (uVar20 < uVar15);
        } else {
            var_20h = *(int64_t *)(arg1 + 0x310);
            uVar15 = *(int64_t *)(arg1 + 0x2f8) * 2;
            if (uVar15 == 0) {
                uVar17 = 0;
                iVar18 = 0;
                var_58h = 0;
                var_18h = 0;
            } else {
                iVar14 = fcn.180459890();
                uVar11 = 0;
                uVar17 = uVar15;
                iVar18 = iVar14;
                var_18h = iVar14;
                var_58h = uVar15;
                if (uVar15 != 0) goto code_r0x0001800cf200;
            }
        }
        var_50h = 0;
        if (*(int64_t *)(arg1 + 0x2f8) != 0) {
code_r0x0001800cf260:
            iVar19 = var_50h;
            iVar14 = *(int64_t *)(*piVar1 + var_50h * 0x18);
            piVar3 = (int64_t *)(*piVar1 + var_50h * 0x18);
            if ((iVar14 == 0) || (*(int64_t *)(arg1 + 0x308) == 0)) {
                if (iVar14 != *(int64_t *)(arg1 + 0x308)) goto code_r0x0001800cf2b4;
            } else if ((piVar3[1] != *(int64_t *)(arg1 + 0x310)) ||
                      (iVar9 = func_0x000180497f30(), iVar18 = var_18h, iVar9 != 0)) {
code_r0x0001800cf2b4:
                uVar12 = 0x811c9dc5;
                if (piVar3[1] != 0) {
                    uVar15 = 0;
                    do {
                        puVar2 = (uint8_t *)(iVar14 + uVar15);
                        uVar15 = uVar15 + 1;
                        uVar12 = (*puVar2 ^ uVar12) * 0x1000193;
                    } while (uVar15 < (uint64_t)piVar3[1]);
                }
                uVar15 = (uint64_t)uVar12;
                uVar11 = 0;
                do {
                    uVar15 = uVar15 & uVar17 - 1;
                    iVar14 = *(int64_t *)(iVar18 + uVar15 * 0x18);
                    puVar13 = (undefined4 *)(iVar18 + uVar15 * 0x18);
                    if (iVar14 == 0) {
                        if (iVar10 == 0) goto code_r0x0001800cf36a;
code_r0x0001800cf346:
                        bVar21 = iVar14 == *piVar3;
code_r0x0001800cf349:
                        if (bVar21) goto code_r0x0001800cf371;
                    } else {
                        if (((iVar10 != 0) && (*(int64_t *)(puVar13 + 2) == var_20h)) &&
                           (iVar9 = func_0x000180497f30(iVar14, iVar10), iVar9 == 0)) {
code_r0x0001800cf36a:
                            uVar6 = *(undefined4 *)((int64_t)piVar3 + 4);
                            uVar7 = *(undefined4 *)(piVar3 + 1);
                            uVar8 = *(undefined4 *)((int64_t)piVar3 + 0xc);
                            *puVar13 = *(undefined4 *)piVar3;
                            puVar13[1] = uVar6;
                            puVar13[2] = uVar7;
                            puVar13[3] = uVar8;
                            goto code_r0x0001800cf371;
                        }
                        if (*piVar3 == 0) goto code_r0x0001800cf346;
                        if (*(int64_t *)(puVar13 + 2) == piVar3[1]) {
                            iVar9 = func_0x000180497f30(iVar14);
                            bVar21 = iVar9 == 0;
                            goto code_r0x0001800cf349;
                        }
                    }
                    iVar18 = uVar15 + uVar11;
                    uVar11 = uVar11 + 1;
                    if (uVar17 - 1 < uVar11) goto code_r0x0001800cf366;
                    uVar15 = iVar18 + 1;
                    iVar18 = var_18h;
                } while( true );
            }
            goto code_r0x0001800cf3a1;
        }
code_r0x0001800cf3b6:
        iVar10 = *piVar1;
        *piVar1 = iVar18;
        *(uint64_t *)(arg1 + 0x2f8) = uVar17;
        if (iVar10 != 0) {
            fcn.1800f4640();
        }
    }
code_r0x0001800cf3de:
    iVar10 = func_0x0001800d3850(piVar1, arg2);
    if ((*(int32_t *)(iVar10 + 0x10) != 0) ||
       (*(undefined4 *)(iVar10 + 0x10) = *(undefined4 *)(arg1 + 0x300), (*(uint8_t *)(arg1 + 0x398) & 1) == 0))
    goto code_r0x0001800cf43a;
    puVar13 = *(undefined4 **)(arg1 + 0x328);
    if (puVar13 != *(undefined4 **)(arg1 + 0x330)) {
        uVar6 = *(undefined4 *)(arg2 + 4);
        uVar7 = *(undefined4 *)(arg2 + 8);
        uVar8 = *(undefined4 *)(arg2 + 0xc);
        *puVar13 = *(undefined4 *)arg2;
        puVar13[1] = uVar6;
        puVar13[2] = uVar7;
        puVar13[3] = uVar8;
        *(int64_t *)(arg1 + 0x328) = *(int64_t *)(arg1 + 0x328) + 0x10;
        goto code_r0x0001800cf43a;
    }
    iVar18 = (int64_t)puVar13 - *(int64_t *)(arg1 + 800) >> 4;
    if (iVar18 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar5 = (code *)swi(3);
        uVar15 = (*pcVar5)();
        return uVar15;
    }
    uVar15 = (int64_t)*(undefined4 **)(arg1 + 0x330) - *(int64_t *)(arg1 + 800) >> 4;
    if (0xfffffffffffffff - (uVar15 >> 1) < uVar15) {
code_r0x0001800cf5c7:
        fcn.180004720();
        pcVar5 = (code *)swi(3);
        uVar15 = (*pcVar5)();
        return uVar15;
    }
    uVar17 = iVar18 + 1;
    uVar15 = (uVar15 >> 1) + uVar15;
    uVar11 = uVar17;
    if (uVar17 <= uVar15) {
        uVar11 = uVar15;
    }
    if (0xfffffffffffffff < uVar11) goto code_r0x0001800cf5c7;
    uVar15 = uVar11 * 0x10;
    if (uVar15 == 0) {
        uVar15 = 0;
code_r0x0001800cf4f6:
        uVar6 = *(undefined4 *)(arg2 + 4);
        uVar7 = *(undefined4 *)(arg2 + 8);
        uVar8 = *(undefined4 *)(arg2 + 0xc);
        puVar4 = (undefined4 *)(iVar18 * 0x10 + uVar15);
        *puVar4 = *(undefined4 *)arg2;
        puVar4[1] = uVar6;
        puVar4[2] = uVar7;
        puVar4[3] = uVar8;
        puVar4 = *(undefined4 **)(arg1 + 800);
        if (puVar13 == *(undefined4 **)(arg1 + 0x328)) {
            iVar14 = (int64_t)*(undefined4 **)(arg1 + 0x328) - (int64_t)puVar4;
            uVar20 = uVar15;
            puVar13 = puVar4;
        } else {
            fcn.180498030(uVar15, puVar4, (int64_t)puVar13 - (int64_t)puVar4);
            iVar14 = *(int64_t *)(arg1 + 0x328) - (int64_t)puVar13;
            uVar20 = uVar15 + 0x10 + iVar18 * 0x10;
        }
        fcn.180498030(uVar20, puVar13, iVar14);
        iVar18 = *(int64_t *)(arg1 + 800);
        if (iVar18 != 0) {
            iVar14 = iVar18;
            puVar16 = auStack_78;
            if ((0xfff < (*(int64_t *)(arg1 + 0x330) - iVar18 & 0xfffffffffffffff0U)) &&
               (iVar14 = *(int64_t *)(iVar18 + -8), arg2 = uVar15, puVar16 = auStack_78, 0x1f < (iVar18 - iVar14) - 8U))
            goto code_r0x0001800cf587;
            goto code_r0x0001800cf591;
        }
    } else {
        if (uVar15 < 0x1000) {
            uVar15 = fcn.180459890();
            goto code_r0x0001800cf4f6;
        }
        if (uVar15 + 0x27 <= uVar15) goto code_r0x0001800cf5c7;
        iVar14 = fcn.180459890(uVar15 + 0x27);
        if (iVar14 != 0) {
            uVar15 = iVar14 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar15 - 8) = iVar14;
            goto code_r0x0001800cf4f6;
        }
code_r0x0001800cf587:
        pcVar5 = (code *)swi(0x29);
        iVar14 = (*pcVar5)(5);
        uVar15 = arg2;
        puVar16 = auStack_70;
code_r0x0001800cf591:
        *(undefined8 *)(puVar16 + -8) = 0x1800cf596;
        fcn.180459c3c(iVar14);
    }
    *(uint64_t *)(arg1 + 800) = uVar15;
    *(uint64_t *)(arg1 + 0x328) = uVar17 * 0x10 + uVar15;
    *(uint64_t *)(arg1 + 0x330) = uVar11 * 0x10 + uVar15;
code_r0x0001800cf43a:
    return (uint64_t)*(uint32_t *)(iVar10 + 0x10);
code_r0x0001800cf366:
    puVar13 = (undefined4 *)0x0;
code_r0x0001800cf371:
    iVar18 = *piVar1;
    puVar4 = (undefined4 *)(iVar18 + var_50h * 0x18);
    uVar6 = puVar4[1];
    uVar7 = puVar4[2];
    uVar8 = puVar4[3];
    *puVar13 = *puVar4;
    puVar13[1] = uVar6;
    puVar13[2] = uVar7;
    puVar13[3] = uVar8;
    puVar13[4] = *(undefined4 *)(iVar18 + 0x10 + var_50h * 0x18);
    uVar17 = var_58h;
    iVar18 = var_18h;
    iVar19 = var_50h;
code_r0x0001800cf3a1:
    var_50h = iVar19 + 1;
    if (*(uint64_t *)(arg1 + 0x2f8) <= (uint64_t)var_50h) goto code_r0x0001800cf3b6;
    goto code_r0x0001800cf260;
}

// ============================================================
// Function: FUN_1800cf5d0
// Address: 0x1800cf5d0
// Size: 54 bytes
// ============================================================
void fcn.1800cf5d0(int64_t arg1)
{
    int64_t in_stack_00000030;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_20h._0_4_ = 0;
    var_38h._0_4_ = 0;
    var_28h = 0;
    _var_18h = ZEXT816(0);
    var_30h = 0;
    fcn.1800ced20(arg1, (int64_t)&var_38h, (int64_t)&var_20h, in_stack_00000030);
    return;
}

// ============================================================
// Function: FUN_1800cf610
// Address: 0x1800cf610
// Size: 69 bytes
// ============================================================
void fcn.1800cf610(int64_t arg1)
{
    uint8_t in_DL;
    int64_t in_stack_00000030;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    var_18h = (int64_t)in_DL;
    var_38h._0_4_ = 1;
    stack0xffffffffffffffd1 = SUB1615(ZEXT816(0), 1);
    var_30h._0_1_ = in_DL;
    var_20h._0_4_ = 1;
    var_10h = 0;
    fcn.1800ced20(arg1, (int64_t)&var_20h, (int64_t)&var_38h, in_stack_00000030);
    return;
}

// ============================================================
// Function: FUN_1800cf660
// Address: 0x1800cf660
// Size: 77 bytes
// ============================================================
void fcn.1800cf660(int64_t arg1)
{
    uint64_t in_XMM1_Qa;
    int64_t var_10h;
    int64_t in_stack_00000030;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    var_20h._0_4_ = 2;
    var_28h = 0;
    var_38h._0_4_ = 2;
    uStack_10 = 0;
    var_18h = in_XMM1_Qa;
    fcn.1800ced20(arg1, (int64_t)&var_38h, (int64_t)&var_20h, in_stack_00000030);
    return;
}

// ============================================================
// Function: FUN_1800cf6b0
// Address: 0x1800cf6b0
// Size: 65 bytes
// ============================================================
void fcn.1800cf6b0(int64_t arg1, int64_t arg2)
{
    int64_t in_stack_00000030;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0;
    var_18h = arg2;
    var_20h._0_4_ = 3;
    var_38h._0_4_ = 3;
    var_28h = 0;
    var_30h = arg2;
    fcn.1800ced20(arg1, (int64_t)&var_38h, (int64_t)&var_20h, in_stack_00000030);
    return;
}

// ============================================================
// Function: FUN_1800cf700
// Address: 0x1800cf700
// Size: 134 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1800cf700(int64_t arg1, int64_t arg_28h)
{
    undefined4 in_XMM1_Da;
    undefined4 in_XMM2_Da;
    undefined4 in_XMM3_Da;
    int64_t var_10h;
    int64_t in_stack_00000030;
    int64_t var_38h;
    undefined auStack_30 [8];
    undefined4 uStack_28;
    undefined4 uStack_24;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_ch;
    
    var_20h._0_4_ = 4;
    var_38h._0_4_ = 4;
    auStack_30._4_4_ = in_XMM2_Da;
    auStack_30._0_4_ = in_XMM1_Da;
    uStack_28 = in_XMM3_Da;
    uStack_24 = (undefined4)arg_28h;
    var_ch._0_4_ = (undefined4)arg_28h;
    fcn.1800ced20(arg1, (int64_t)&var_20h, (int64_t)&var_38h, in_stack_00000030);
    return;
}

// ============================================================
// Function: FUN_1800cf790
// Address: 0x1800cf790
// Size: 96 bytes
// ============================================================
void fcn.1800cf790(int64_t arg1, int64_t arg2)
{
    int64_t in_stack_00000020;
    int64_t var_48h;
    int64_t var_40h;
    undefined8 uStack_38;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_48h._0_4_ = *(undefined4 *)arg2;
    var_48h._4_4_ = *(undefined4 *)(arg2 + 4);
    uStack_38 = var_40h;
    var_40h = *(undefined8 *)(arg2 + 8);
    var_40h._0_4_ = fcn.1800cf010(arg1, (int64_t)&var_48h);
    var_48h._0_4_ = 5;
    stack0xffffffffffffffc4 = SUB1612(ZEXT816(0), 4);
    var_20h = (int64_t)(uint32_t)var_40h;
    var_28h._0_4_ = 5;
    var_18h = 0;
    fcn.1800ced20(arg1, (int64_t)&var_28h, (int64_t)&var_48h, in_stack_00000020);
    return;
}

// ============================================================
// Function: FUN_1800cf7f0
// Address: 0x1800cf7f0
// Size: 68 bytes
// ============================================================
void fcn.1800cf7f0(int64_t arg1, int64_t arg2)
{
    int64_t in_stack_00000030;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    var_18h = arg2 & 0xffffffff;
    var_38h._0_4_ = 6;
    stack0xffffffffffffffd4 = SUB1612(ZEXT816(0), 4);
    var_30h._0_4_ = (int32_t)arg2;
    var_20h._0_4_ = 6;
    var_10h = 0;
    fcn.1800ced20(arg1, (int64_t)&var_20h, (int64_t)&var_38h, in_stack_00000030);
    return;
}

// ============================================================
// Function: FUN_1800cf840
// Address: 0x1800cf840
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800cf840(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    bool bVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint64_t uVar20;
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    piVar1 = (int64_t *)(arg1 + 0x128);
    var_1a8h = arg2;
    iVar10 = func_0x0001800d3ab0(piVar1);
    iVar14 = iVar10 + 0x108;
    if (iVar10 == 0) {
        iVar14 = 0;
    }
    if (iVar14 == 0) {
        piVar15 = (int64_t *)(arg1 + 0x58);
        uVar19 = (int32_t)(*(int64_t *)(arg1 + 0x60) - *piVar15 >> 3) * -0x55555555;
        var_1a0h = (int64_t)piVar15;
        if (uVar19 < 0x800000) {
            piVar18 = (int64_t *)(arg1 + 0xa0);
            var_190h._0_4_ = 7;
            iVar14 = *(int64_t *)(arg1 + 0x130);
            stack0xfffffffffffffe7c = SUB1612(ZEXT816(0), 4);
            var_188h._0_4_ = (int32_t)(*(int64_t *)(arg1 + 0xa8) - *piVar18 >> 3) * 0x3e0f83e1;
            var_198h = (int64_t)piVar18;
            if (((uint64_t)(iVar14 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x138)) &&
               (iVar10 = func_0x0001800d3ab0(piVar1, arg2), iVar10 == 0)) {
                iVar10 = 0x10;
                if (iVar14 != 0) {
                    iVar10 = iVar14 * 2;
                }
                func_0x0001800d3f10(&var_178h, arg1 + 0x140, iVar10);
                uVar20 = 0;
                if (*(int64_t *)(arg1 + 0x130) != 0) {
                    do {
                        iVar14 = *piVar1 + uVar20 * 0x10c;
                        uVar4 = *(uint32_t *)(iVar14 + 0x100);
                        uVar16 = (uint64_t)uVar4;
                        if (*(char *)0x180777fb8 == '\0') {
                            if (uVar4 != *(uint32_t *)(arg1 + 0x240)) goto code_r0x0001800cfa46;
                            iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 << 2);
joined_r0x0001800cfa37:
                            if (iVar9 != 0) goto code_r0x0001800cfa46;
                        } else {
                            if (((uVar4 == *(uint32_t *)(arg1 + 0x240)) &&
                                (iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 * 4), iVar9 == 0)) &&
                               (*(char *)(iVar14 + 0x104) == *(char *)(arg1 + 0x244))) {
                                bVar8 = true;
                            } else {
                                bVar8 = false;
                            }
                            if (*(char *)(iVar14 + 0x104) == '\0') {
                                if (bVar8) goto code_r0x0001800cfad7;
                            } else if (bVar8) {
                                iVar9 = func_0x000180497f30(iVar14 + 0x80, arg1 + 0x1c0, uVar16 * 4);
                                goto joined_r0x0001800cfa37;
                            }
code_r0x0001800cfa46:
                            puVar11 = (undefined8 *)func_0x0001800d3c50(&var_178h, iVar14);
                            puVar17 = (undefined8 *)(*piVar1 + uVar20 * 0x10c);
                            iVar14 = 2;
                            puVar12 = puVar17;
                            puVar13 = puVar11;
                            do {
                                puVar2 = puVar13 + 0x10;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 4);
                                uVar6 = *(undefined4 *)(puVar12 + 1);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0xc);
                                puVar3 = puVar12 + 0x10;
                                *(undefined4 *)puVar13 = *(undefined4 *)puVar12;
                                *(undefined4 *)((int64_t)puVar13 + 4) = uVar5;
                                *(undefined4 *)(puVar13 + 1) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0xc) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x14);
                                uVar6 = *(undefined4 *)(puVar12 + 3);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x1c);
                                *(undefined4 *)(puVar13 + 2) = *(undefined4 *)(puVar12 + 2);
                                *(undefined4 *)((int64_t)puVar13 + 0x14) = uVar5;
                                *(undefined4 *)(puVar13 + 3) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x1c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x24);
                                uVar6 = *(undefined4 *)(puVar12 + 5);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x2c);
                                *(undefined4 *)(puVar13 + 4) = *(undefined4 *)(puVar12 + 4);
                                *(undefined4 *)((int64_t)puVar13 + 0x24) = uVar5;
                                *(undefined4 *)(puVar13 + 5) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x2c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x34);
                                uVar6 = *(undefined4 *)(puVar12 + 7);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x3c);
                                *(undefined4 *)(puVar13 + 6) = *(undefined4 *)(puVar12 + 6);
                                *(undefined4 *)((int64_t)puVar13 + 0x34) = uVar5;
                                *(undefined4 *)(puVar13 + 7) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x3c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x44);
                                uVar6 = *(undefined4 *)(puVar12 + 9);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x4c);
                                *(undefined4 *)(puVar13 + 8) = *(undefined4 *)(puVar12 + 8);
                                *(undefined4 *)((int64_t)puVar13 + 0x44) = uVar5;
                                *(undefined4 *)(puVar13 + 9) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x4c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x54);
                                uVar6 = *(undefined4 *)(puVar12 + 0xb);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x5c);
                                *(undefined4 *)(puVar13 + 10) = *(undefined4 *)(puVar12 + 10);
                                *(undefined4 *)((int64_t)puVar13 + 0x54) = uVar5;
                                *(undefined4 *)(puVar13 + 0xb) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x5c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 100);
                                uVar6 = *(undefined4 *)(puVar12 + 0xd);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x6c);
                                *(undefined4 *)(puVar13 + 0xc) = *(undefined4 *)(puVar12 + 0xc);
                                *(undefined4 *)((int64_t)puVar13 + 100) = uVar5;
                                *(undefined4 *)(puVar13 + 0xd) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x6c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x74);
                                uVar6 = *(undefined4 *)(puVar12 + 0xf);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x7c);
                                *(undefined4 *)(puVar13 + 0xe) = *(undefined4 *)(puVar12 + 0xe);
                                *(undefined4 *)((int64_t)puVar13 + 0x74) = uVar5;
                                *(undefined4 *)(puVar13 + 0xf) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x7c) = uVar7;
                                iVar14 = iVar14 + -1;
                                puVar12 = puVar3;
                                puVar13 = puVar2;
                            } while (iVar14 != 0);
                            *puVar2 = *puVar3;
                            *(undefined4 *)(puVar11 + 0x21) = *(undefined4 *)(puVar17 + 0x21);
                        }
code_r0x0001800cfad7:
                        uVar20 = uVar20 + 1;
                        piVar15 = (int64_t *)var_1a0h;
                        arg2 = var_1a8h;
                        piVar18 = (int64_t *)var_198h;
                    } while (uVar20 < *(uint64_t *)(arg1 + 0x130));
                }
                iVar14 = *piVar1;
                *piVar1 = var_178h;
                *(int64_t *)(arg1 + 0x130) = var_170h;
                if (iVar14 != 0) {
                    fcn.1800f4640();
                }
            }
            iVar14 = func_0x0001800d3c50(piVar1, arg2);
            *(uint32_t *)(iVar14 + 0x108) = uVar19;
            func_0x0001800d2c50(piVar18, arg2);
            fcn.1800d2f00(piVar15, &var_190h);
        }
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_1800cf894
// Address: 0x1800cf894
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800cf840(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    bool bVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint64_t uVar20;
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    piVar1 = (int64_t *)(arg1 + 0x128);
    var_1a8h = arg2;
    iVar10 = func_0x0001800d3ab0(piVar1);
    iVar14 = iVar10 + 0x108;
    if (iVar10 == 0) {
        iVar14 = 0;
    }
    if (iVar14 == 0) {
        piVar15 = (int64_t *)(arg1 + 0x58);
        uVar19 = (int32_t)(*(int64_t *)(arg1 + 0x60) - *piVar15 >> 3) * -0x55555555;
        var_1a0h = (int64_t)piVar15;
        if (uVar19 < 0x800000) {
            piVar18 = (int64_t *)(arg1 + 0xa0);
            var_190h._0_4_ = 7;
            iVar14 = *(int64_t *)(arg1 + 0x130);
            stack0xfffffffffffffe7c = SUB1612(ZEXT816(0), 4);
            var_188h._0_4_ = (int32_t)(*(int64_t *)(arg1 + 0xa8) - *piVar18 >> 3) * 0x3e0f83e1;
            var_198h = (int64_t)piVar18;
            if (((uint64_t)(iVar14 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x138)) &&
               (iVar10 = func_0x0001800d3ab0(piVar1, arg2), iVar10 == 0)) {
                iVar10 = 0x10;
                if (iVar14 != 0) {
                    iVar10 = iVar14 * 2;
                }
                func_0x0001800d3f10(&var_178h, arg1 + 0x140, iVar10);
                uVar20 = 0;
                if (*(int64_t *)(arg1 + 0x130) != 0) {
                    do {
                        iVar14 = *piVar1 + uVar20 * 0x10c;
                        uVar4 = *(uint32_t *)(iVar14 + 0x100);
                        uVar16 = (uint64_t)uVar4;
                        if (*(char *)0x180777fb8 == '\0') {
                            if (uVar4 != *(uint32_t *)(arg1 + 0x240)) goto code_r0x0001800cfa46;
                            iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 << 2);
joined_r0x0001800cfa37:
                            if (iVar9 != 0) goto code_r0x0001800cfa46;
                        } else {
                            if (((uVar4 == *(uint32_t *)(arg1 + 0x240)) &&
                                (iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 * 4), iVar9 == 0)) &&
                               (*(char *)(iVar14 + 0x104) == *(char *)(arg1 + 0x244))) {
                                bVar8 = true;
                            } else {
                                bVar8 = false;
                            }
                            if (*(char *)(iVar14 + 0x104) == '\0') {
                                if (bVar8) goto code_r0x0001800cfad7;
                            } else if (bVar8) {
                                iVar9 = func_0x000180497f30(iVar14 + 0x80, arg1 + 0x1c0, uVar16 * 4);
                                goto joined_r0x0001800cfa37;
                            }
code_r0x0001800cfa46:
                            puVar11 = (undefined8 *)func_0x0001800d3c50(&var_178h, iVar14);
                            puVar17 = (undefined8 *)(*piVar1 + uVar20 * 0x10c);
                            iVar14 = 2;
                            puVar12 = puVar17;
                            puVar13 = puVar11;
                            do {
                                puVar2 = puVar13 + 0x10;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 4);
                                uVar6 = *(undefined4 *)(puVar12 + 1);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0xc);
                                puVar3 = puVar12 + 0x10;
                                *(undefined4 *)puVar13 = *(undefined4 *)puVar12;
                                *(undefined4 *)((int64_t)puVar13 + 4) = uVar5;
                                *(undefined4 *)(puVar13 + 1) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0xc) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x14);
                                uVar6 = *(undefined4 *)(puVar12 + 3);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x1c);
                                *(undefined4 *)(puVar13 + 2) = *(undefined4 *)(puVar12 + 2);
                                *(undefined4 *)((int64_t)puVar13 + 0x14) = uVar5;
                                *(undefined4 *)(puVar13 + 3) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x1c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x24);
                                uVar6 = *(undefined4 *)(puVar12 + 5);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x2c);
                                *(undefined4 *)(puVar13 + 4) = *(undefined4 *)(puVar12 + 4);
                                *(undefined4 *)((int64_t)puVar13 + 0x24) = uVar5;
                                *(undefined4 *)(puVar13 + 5) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x2c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x34);
                                uVar6 = *(undefined4 *)(puVar12 + 7);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x3c);
                                *(undefined4 *)(puVar13 + 6) = *(undefined4 *)(puVar12 + 6);
                                *(undefined4 *)((int64_t)puVar13 + 0x34) = uVar5;
                                *(undefined4 *)(puVar13 + 7) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x3c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x44);
                                uVar6 = *(undefined4 *)(puVar12 + 9);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x4c);
                                *(undefined4 *)(puVar13 + 8) = *(undefined4 *)(puVar12 + 8);
                                *(undefined4 *)((int64_t)puVar13 + 0x44) = uVar5;
                                *(undefined4 *)(puVar13 + 9) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x4c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x54);
                                uVar6 = *(undefined4 *)(puVar12 + 0xb);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x5c);
                                *(undefined4 *)(puVar13 + 10) = *(undefined4 *)(puVar12 + 10);
                                *(undefined4 *)((int64_t)puVar13 + 0x54) = uVar5;
                                *(undefined4 *)(puVar13 + 0xb) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x5c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 100);
                                uVar6 = *(undefined4 *)(puVar12 + 0xd);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x6c);
                                *(undefined4 *)(puVar13 + 0xc) = *(undefined4 *)(puVar12 + 0xc);
                                *(undefined4 *)((int64_t)puVar13 + 100) = uVar5;
                                *(undefined4 *)(puVar13 + 0xd) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x6c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x74);
                                uVar6 = *(undefined4 *)(puVar12 + 0xf);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x7c);
                                *(undefined4 *)(puVar13 + 0xe) = *(undefined4 *)(puVar12 + 0xe);
                                *(undefined4 *)((int64_t)puVar13 + 0x74) = uVar5;
                                *(undefined4 *)(puVar13 + 0xf) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x7c) = uVar7;
                                iVar14 = iVar14 + -1;
                                puVar12 = puVar3;
                                puVar13 = puVar2;
                            } while (iVar14 != 0);
                            *puVar2 = *puVar3;
                            *(undefined4 *)(puVar11 + 0x21) = *(undefined4 *)(puVar17 + 0x21);
                        }
code_r0x0001800cfad7:
                        uVar20 = uVar20 + 1;
                        piVar15 = (int64_t *)var_1a0h;
                        arg2 = var_1a8h;
                        piVar18 = (int64_t *)var_198h;
                    } while (uVar20 < *(uint64_t *)(arg1 + 0x130));
                }
                iVar14 = *piVar1;
                *piVar1 = var_178h;
                *(int64_t *)(arg1 + 0x130) = var_170h;
                if (iVar14 != 0) {
                    fcn.1800f4640();
                }
            }
            iVar14 = func_0x0001800d3c50(piVar1, arg2);
            *(uint32_t *)(iVar14 + 0x108) = uVar19;
            func_0x0001800d2c50(piVar18, arg2);
            fcn.1800d2f00(piVar15, &var_190h);
        }
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_1800cf8da
// Address: 0x1800cf8da
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800cf840(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    bool bVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint64_t uVar20;
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    piVar1 = (int64_t *)(arg1 + 0x128);
    var_1a8h = arg2;
    iVar10 = func_0x0001800d3ab0(piVar1);
    iVar14 = iVar10 + 0x108;
    if (iVar10 == 0) {
        iVar14 = 0;
    }
    if (iVar14 == 0) {
        piVar15 = (int64_t *)(arg1 + 0x58);
        uVar19 = (int32_t)(*(int64_t *)(arg1 + 0x60) - *piVar15 >> 3) * -0x55555555;
        var_1a0h = (int64_t)piVar15;
        if (uVar19 < 0x800000) {
            piVar18 = (int64_t *)(arg1 + 0xa0);
            var_190h._0_4_ = 7;
            iVar14 = *(int64_t *)(arg1 + 0x130);
            stack0xfffffffffffffe7c = SUB1612(ZEXT816(0), 4);
            var_188h._0_4_ = (int32_t)(*(int64_t *)(arg1 + 0xa8) - *piVar18 >> 3) * 0x3e0f83e1;
            var_198h = (int64_t)piVar18;
            if (((uint64_t)(iVar14 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x138)) &&
               (iVar10 = func_0x0001800d3ab0(piVar1, arg2), iVar10 == 0)) {
                iVar10 = 0x10;
                if (iVar14 != 0) {
                    iVar10 = iVar14 * 2;
                }
                func_0x0001800d3f10(&var_178h, arg1 + 0x140, iVar10);
                uVar20 = 0;
                if (*(int64_t *)(arg1 + 0x130) != 0) {
                    do {
                        iVar14 = *piVar1 + uVar20 * 0x10c;
                        uVar4 = *(uint32_t *)(iVar14 + 0x100);
                        uVar16 = (uint64_t)uVar4;
                        if (*(char *)0x180777fb8 == '\0') {
                            if (uVar4 != *(uint32_t *)(arg1 + 0x240)) goto code_r0x0001800cfa46;
                            iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 << 2);
joined_r0x0001800cfa37:
                            if (iVar9 != 0) goto code_r0x0001800cfa46;
                        } else {
                            if (((uVar4 == *(uint32_t *)(arg1 + 0x240)) &&
                                (iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 * 4), iVar9 == 0)) &&
                               (*(char *)(iVar14 + 0x104) == *(char *)(arg1 + 0x244))) {
                                bVar8 = true;
                            } else {
                                bVar8 = false;
                            }
                            if (*(char *)(iVar14 + 0x104) == '\0') {
                                if (bVar8) goto code_r0x0001800cfad7;
                            } else if (bVar8) {
                                iVar9 = func_0x000180497f30(iVar14 + 0x80, arg1 + 0x1c0, uVar16 * 4);
                                goto joined_r0x0001800cfa37;
                            }
code_r0x0001800cfa46:
                            puVar11 = (undefined8 *)func_0x0001800d3c50(&var_178h, iVar14);
                            puVar17 = (undefined8 *)(*piVar1 + uVar20 * 0x10c);
                            iVar14 = 2;
                            puVar12 = puVar17;
                            puVar13 = puVar11;
                            do {
                                puVar2 = puVar13 + 0x10;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 4);
                                uVar6 = *(undefined4 *)(puVar12 + 1);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0xc);
                                puVar3 = puVar12 + 0x10;
                                *(undefined4 *)puVar13 = *(undefined4 *)puVar12;
                                *(undefined4 *)((int64_t)puVar13 + 4) = uVar5;
                                *(undefined4 *)(puVar13 + 1) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0xc) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x14);
                                uVar6 = *(undefined4 *)(puVar12 + 3);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x1c);
                                *(undefined4 *)(puVar13 + 2) = *(undefined4 *)(puVar12 + 2);
                                *(undefined4 *)((int64_t)puVar13 + 0x14) = uVar5;
                                *(undefined4 *)(puVar13 + 3) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x1c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x24);
                                uVar6 = *(undefined4 *)(puVar12 + 5);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x2c);
                                *(undefined4 *)(puVar13 + 4) = *(undefined4 *)(puVar12 + 4);
                                *(undefined4 *)((int64_t)puVar13 + 0x24) = uVar5;
                                *(undefined4 *)(puVar13 + 5) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x2c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x34);
                                uVar6 = *(undefined4 *)(puVar12 + 7);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x3c);
                                *(undefined4 *)(puVar13 + 6) = *(undefined4 *)(puVar12 + 6);
                                *(undefined4 *)((int64_t)puVar13 + 0x34) = uVar5;
                                *(undefined4 *)(puVar13 + 7) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x3c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x44);
                                uVar6 = *(undefined4 *)(puVar12 + 9);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x4c);
                                *(undefined4 *)(puVar13 + 8) = *(undefined4 *)(puVar12 + 8);
                                *(undefined4 *)((int64_t)puVar13 + 0x44) = uVar5;
                                *(undefined4 *)(puVar13 + 9) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x4c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x54);
                                uVar6 = *(undefined4 *)(puVar12 + 0xb);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x5c);
                                *(undefined4 *)(puVar13 + 10) = *(undefined4 *)(puVar12 + 10);
                                *(undefined4 *)((int64_t)puVar13 + 0x54) = uVar5;
                                *(undefined4 *)(puVar13 + 0xb) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x5c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 100);
                                uVar6 = *(undefined4 *)(puVar12 + 0xd);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x6c);
                                *(undefined4 *)(puVar13 + 0xc) = *(undefined4 *)(puVar12 + 0xc);
                                *(undefined4 *)((int64_t)puVar13 + 100) = uVar5;
                                *(undefined4 *)(puVar13 + 0xd) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x6c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x74);
                                uVar6 = *(undefined4 *)(puVar12 + 0xf);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x7c);
                                *(undefined4 *)(puVar13 + 0xe) = *(undefined4 *)(puVar12 + 0xe);
                                *(undefined4 *)((int64_t)puVar13 + 0x74) = uVar5;
                                *(undefined4 *)(puVar13 + 0xf) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x7c) = uVar7;
                                iVar14 = iVar14 + -1;
                                puVar12 = puVar3;
                                puVar13 = puVar2;
                            } while (iVar14 != 0);
                            *puVar2 = *puVar3;
                            *(undefined4 *)(puVar11 + 0x21) = *(undefined4 *)(puVar17 + 0x21);
                        }
code_r0x0001800cfad7:
                        uVar20 = uVar20 + 1;
                        piVar15 = (int64_t *)var_1a0h;
                        arg2 = var_1a8h;
                        piVar18 = (int64_t *)var_198h;
                    } while (uVar20 < *(uint64_t *)(arg1 + 0x130));
                }
                iVar14 = *piVar1;
                *piVar1 = var_178h;
                *(int64_t *)(arg1 + 0x130) = var_170h;
                if (iVar14 != 0) {
                    fcn.1800f4640();
                }
            }
            iVar14 = func_0x0001800d3c50(piVar1, arg2);
            *(uint32_t *)(iVar14 + 0x108) = uVar19;
            func_0x0001800d2c50(piVar18, arg2);
            fcn.1800d2f00(piVar15, &var_190h);
        }
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_1800cf947
// Address: 0x1800cf947
// Size: 469 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800cf840(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    bool bVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint64_t uVar20;
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    piVar1 = (int64_t *)(arg1 + 0x128);
    var_1a8h = arg2;
    iVar10 = func_0x0001800d3ab0(piVar1);
    iVar14 = iVar10 + 0x108;
    if (iVar10 == 0) {
        iVar14 = 0;
    }
    if (iVar14 == 0) {
        piVar15 = (int64_t *)(arg1 + 0x58);
        uVar19 = (int32_t)(*(int64_t *)(arg1 + 0x60) - *piVar15 >> 3) * -0x55555555;
        var_1a0h = (int64_t)piVar15;
        if (uVar19 < 0x800000) {
            piVar18 = (int64_t *)(arg1 + 0xa0);
            var_190h._0_4_ = 7;
            iVar14 = *(int64_t *)(arg1 + 0x130);
            stack0xfffffffffffffe7c = SUB1612(ZEXT816(0), 4);
            var_188h._0_4_ = (int32_t)(*(int64_t *)(arg1 + 0xa8) - *piVar18 >> 3) * 0x3e0f83e1;
            var_198h = (int64_t)piVar18;
            if (((uint64_t)(iVar14 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x138)) &&
               (iVar10 = func_0x0001800d3ab0(piVar1, arg2), iVar10 == 0)) {
                iVar10 = 0x10;
                if (iVar14 != 0) {
                    iVar10 = iVar14 * 2;
                }
                func_0x0001800d3f10(&var_178h, arg1 + 0x140, iVar10);
                uVar20 = 0;
                if (*(int64_t *)(arg1 + 0x130) != 0) {
                    do {
                        iVar14 = *piVar1 + uVar20 * 0x10c;
                        uVar4 = *(uint32_t *)(iVar14 + 0x100);
                        uVar16 = (uint64_t)uVar4;
                        if (*(char *)0x180777fb8 == '\0') {
                            if (uVar4 != *(uint32_t *)(arg1 + 0x240)) goto code_r0x0001800cfa46;
                            iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 << 2);
joined_r0x0001800cfa37:
                            if (iVar9 != 0) goto code_r0x0001800cfa46;
                        } else {
                            if (((uVar4 == *(uint32_t *)(arg1 + 0x240)) &&
                                (iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 * 4), iVar9 == 0)) &&
                               (*(char *)(iVar14 + 0x104) == *(char *)(arg1 + 0x244))) {
                                bVar8 = true;
                            } else {
                                bVar8 = false;
                            }
                            if (*(char *)(iVar14 + 0x104) == '\0') {
                                if (bVar8) goto code_r0x0001800cfad7;
                            } else if (bVar8) {
                                iVar9 = func_0x000180497f30(iVar14 + 0x80, arg1 + 0x1c0, uVar16 * 4);
                                goto joined_r0x0001800cfa37;
                            }
code_r0x0001800cfa46:
                            puVar11 = (undefined8 *)func_0x0001800d3c50(&var_178h, iVar14);
                            puVar17 = (undefined8 *)(*piVar1 + uVar20 * 0x10c);
                            iVar14 = 2;
                            puVar12 = puVar17;
                            puVar13 = puVar11;
                            do {
                                puVar2 = puVar13 + 0x10;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 4);
                                uVar6 = *(undefined4 *)(puVar12 + 1);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0xc);
                                puVar3 = puVar12 + 0x10;
                                *(undefined4 *)puVar13 = *(undefined4 *)puVar12;
                                *(undefined4 *)((int64_t)puVar13 + 4) = uVar5;
                                *(undefined4 *)(puVar13 + 1) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0xc) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x14);
                                uVar6 = *(undefined4 *)(puVar12 + 3);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x1c);
                                *(undefined4 *)(puVar13 + 2) = *(undefined4 *)(puVar12 + 2);
                                *(undefined4 *)((int64_t)puVar13 + 0x14) = uVar5;
                                *(undefined4 *)(puVar13 + 3) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x1c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x24);
                                uVar6 = *(undefined4 *)(puVar12 + 5);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x2c);
                                *(undefined4 *)(puVar13 + 4) = *(undefined4 *)(puVar12 + 4);
                                *(undefined4 *)((int64_t)puVar13 + 0x24) = uVar5;
                                *(undefined4 *)(puVar13 + 5) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x2c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x34);
                                uVar6 = *(undefined4 *)(puVar12 + 7);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x3c);
                                *(undefined4 *)(puVar13 + 6) = *(undefined4 *)(puVar12 + 6);
                                *(undefined4 *)((int64_t)puVar13 + 0x34) = uVar5;
                                *(undefined4 *)(puVar13 + 7) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x3c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x44);
                                uVar6 = *(undefined4 *)(puVar12 + 9);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x4c);
                                *(undefined4 *)(puVar13 + 8) = *(undefined4 *)(puVar12 + 8);
                                *(undefined4 *)((int64_t)puVar13 + 0x44) = uVar5;
                                *(undefined4 *)(puVar13 + 9) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x4c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x54);
                                uVar6 = *(undefined4 *)(puVar12 + 0xb);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x5c);
                                *(undefined4 *)(puVar13 + 10) = *(undefined4 *)(puVar12 + 10);
                                *(undefined4 *)((int64_t)puVar13 + 0x54) = uVar5;
                                *(undefined4 *)(puVar13 + 0xb) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x5c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 100);
                                uVar6 = *(undefined4 *)(puVar12 + 0xd);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x6c);
                                *(undefined4 *)(puVar13 + 0xc) = *(undefined4 *)(puVar12 + 0xc);
                                *(undefined4 *)((int64_t)puVar13 + 100) = uVar5;
                                *(undefined4 *)(puVar13 + 0xd) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x6c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x74);
                                uVar6 = *(undefined4 *)(puVar12 + 0xf);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x7c);
                                *(undefined4 *)(puVar13 + 0xe) = *(undefined4 *)(puVar12 + 0xe);
                                *(undefined4 *)((int64_t)puVar13 + 0x74) = uVar5;
                                *(undefined4 *)(puVar13 + 0xf) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x7c) = uVar7;
                                iVar14 = iVar14 + -1;
                                puVar12 = puVar3;
                                puVar13 = puVar2;
                            } while (iVar14 != 0);
                            *puVar2 = *puVar3;
                            *(undefined4 *)(puVar11 + 0x21) = *(undefined4 *)(puVar17 + 0x21);
                        }
code_r0x0001800cfad7:
                        uVar20 = uVar20 + 1;
                        piVar15 = (int64_t *)var_1a0h;
                        arg2 = var_1a8h;
                        piVar18 = (int64_t *)var_198h;
                    } while (uVar20 < *(uint64_t *)(arg1 + 0x130));
                }
                iVar14 = *piVar1;
                *piVar1 = var_178h;
                *(int64_t *)(arg1 + 0x130) = var_170h;
                if (iVar14 != 0) {
                    fcn.1800f4640();
                }
            }
            iVar14 = func_0x0001800d3c50(piVar1, arg2);
            *(uint32_t *)(iVar14 + 0x108) = uVar19;
            func_0x0001800d2c50(piVar18, arg2);
            fcn.1800d2f00(piVar15, &var_190h);
        }
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_1800cfb1c
// Address: 0x1800cfb1c
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800cf840(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    bool bVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint64_t uVar20;
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    piVar1 = (int64_t *)(arg1 + 0x128);
    var_1a8h = arg2;
    iVar10 = func_0x0001800d3ab0(piVar1);
    iVar14 = iVar10 + 0x108;
    if (iVar10 == 0) {
        iVar14 = 0;
    }
    if (iVar14 == 0) {
        piVar15 = (int64_t *)(arg1 + 0x58);
        uVar19 = (int32_t)(*(int64_t *)(arg1 + 0x60) - *piVar15 >> 3) * -0x55555555;
        var_1a0h = (int64_t)piVar15;
        if (uVar19 < 0x800000) {
            piVar18 = (int64_t *)(arg1 + 0xa0);
            var_190h._0_4_ = 7;
            iVar14 = *(int64_t *)(arg1 + 0x130);
            stack0xfffffffffffffe7c = SUB1612(ZEXT816(0), 4);
            var_188h._0_4_ = (int32_t)(*(int64_t *)(arg1 + 0xa8) - *piVar18 >> 3) * 0x3e0f83e1;
            var_198h = (int64_t)piVar18;
            if (((uint64_t)(iVar14 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x138)) &&
               (iVar10 = func_0x0001800d3ab0(piVar1, arg2), iVar10 == 0)) {
                iVar10 = 0x10;
                if (iVar14 != 0) {
                    iVar10 = iVar14 * 2;
                }
                func_0x0001800d3f10(&var_178h, arg1 + 0x140, iVar10);
                uVar20 = 0;
                if (*(int64_t *)(arg1 + 0x130) != 0) {
                    do {
                        iVar14 = *piVar1 + uVar20 * 0x10c;
                        uVar4 = *(uint32_t *)(iVar14 + 0x100);
                        uVar16 = (uint64_t)uVar4;
                        if (*(char *)0x180777fb8 == '\0') {
                            if (uVar4 != *(uint32_t *)(arg1 + 0x240)) goto code_r0x0001800cfa46;
                            iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 << 2);
joined_r0x0001800cfa37:
                            if (iVar9 != 0) goto code_r0x0001800cfa46;
                        } else {
                            if (((uVar4 == *(uint32_t *)(arg1 + 0x240)) &&
                                (iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 * 4), iVar9 == 0)) &&
                               (*(char *)(iVar14 + 0x104) == *(char *)(arg1 + 0x244))) {
                                bVar8 = true;
                            } else {
                                bVar8 = false;
                            }
                            if (*(char *)(iVar14 + 0x104) == '\0') {
                                if (bVar8) goto code_r0x0001800cfad7;
                            } else if (bVar8) {
                                iVar9 = func_0x000180497f30(iVar14 + 0x80, arg1 + 0x1c0, uVar16 * 4);
                                goto joined_r0x0001800cfa37;
                            }
code_r0x0001800cfa46:
                            puVar11 = (undefined8 *)func_0x0001800d3c50(&var_178h, iVar14);
                            puVar17 = (undefined8 *)(*piVar1 + uVar20 * 0x10c);
                            iVar14 = 2;
                            puVar12 = puVar17;
                            puVar13 = puVar11;
                            do {
                                puVar2 = puVar13 + 0x10;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 4);
                                uVar6 = *(undefined4 *)(puVar12 + 1);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0xc);
                                puVar3 = puVar12 + 0x10;
                                *(undefined4 *)puVar13 = *(undefined4 *)puVar12;
                                *(undefined4 *)((int64_t)puVar13 + 4) = uVar5;
                                *(undefined4 *)(puVar13 + 1) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0xc) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x14);
                                uVar6 = *(undefined4 *)(puVar12 + 3);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x1c);
                                *(undefined4 *)(puVar13 + 2) = *(undefined4 *)(puVar12 + 2);
                                *(undefined4 *)((int64_t)puVar13 + 0x14) = uVar5;
                                *(undefined4 *)(puVar13 + 3) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x1c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x24);
                                uVar6 = *(undefined4 *)(puVar12 + 5);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x2c);
                                *(undefined4 *)(puVar13 + 4) = *(undefined4 *)(puVar12 + 4);
                                *(undefined4 *)((int64_t)puVar13 + 0x24) = uVar5;
                                *(undefined4 *)(puVar13 + 5) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x2c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x34);
                                uVar6 = *(undefined4 *)(puVar12 + 7);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x3c);
                                *(undefined4 *)(puVar13 + 6) = *(undefined4 *)(puVar12 + 6);
                                *(undefined4 *)((int64_t)puVar13 + 0x34) = uVar5;
                                *(undefined4 *)(puVar13 + 7) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x3c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x44);
                                uVar6 = *(undefined4 *)(puVar12 + 9);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x4c);
                                *(undefined4 *)(puVar13 + 8) = *(undefined4 *)(puVar12 + 8);
                                *(undefined4 *)((int64_t)puVar13 + 0x44) = uVar5;
                                *(undefined4 *)(puVar13 + 9) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x4c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x54);
                                uVar6 = *(undefined4 *)(puVar12 + 0xb);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x5c);
                                *(undefined4 *)(puVar13 + 10) = *(undefined4 *)(puVar12 + 10);
                                *(undefined4 *)((int64_t)puVar13 + 0x54) = uVar5;
                                *(undefined4 *)(puVar13 + 0xb) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x5c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 100);
                                uVar6 = *(undefined4 *)(puVar12 + 0xd);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x6c);
                                *(undefined4 *)(puVar13 + 0xc) = *(undefined4 *)(puVar12 + 0xc);
                                *(undefined4 *)((int64_t)puVar13 + 100) = uVar5;
                                *(undefined4 *)(puVar13 + 0xd) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x6c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x74);
                                uVar6 = *(undefined4 *)(puVar12 + 0xf);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x7c);
                                *(undefined4 *)(puVar13 + 0xe) = *(undefined4 *)(puVar12 + 0xe);
                                *(undefined4 *)((int64_t)puVar13 + 0x74) = uVar5;
                                *(undefined4 *)(puVar13 + 0xf) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x7c) = uVar7;
                                iVar14 = iVar14 + -1;
                                puVar12 = puVar3;
                                puVar13 = puVar2;
                            } while (iVar14 != 0);
                            *puVar2 = *puVar3;
                            *(undefined4 *)(puVar11 + 0x21) = *(undefined4 *)(puVar17 + 0x21);
                        }
code_r0x0001800cfad7:
                        uVar20 = uVar20 + 1;
                        piVar15 = (int64_t *)var_1a0h;
                        arg2 = var_1a8h;
                        piVar18 = (int64_t *)var_198h;
                    } while (uVar20 < *(uint64_t *)(arg1 + 0x130));
                }
                iVar14 = *piVar1;
                *piVar1 = var_178h;
                *(int64_t *)(arg1 + 0x130) = var_170h;
                if (iVar14 != 0) {
                    fcn.1800f4640();
                }
            }
            iVar14 = func_0x0001800d3c50(piVar1, arg2);
            *(uint32_t *)(iVar14 + 0x108) = uVar19;
            func_0x0001800d2c50(piVar18, arg2);
            fcn.1800d2f00(piVar15, &var_190h);
        }
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_1800cfb56
// Address: 0x1800cfb56
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800cf840(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    bool bVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint64_t uVar20;
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    piVar1 = (int64_t *)(arg1 + 0x128);
    var_1a8h = arg2;
    iVar10 = func_0x0001800d3ab0(piVar1);
    iVar14 = iVar10 + 0x108;
    if (iVar10 == 0) {
        iVar14 = 0;
    }
    if (iVar14 == 0) {
        piVar15 = (int64_t *)(arg1 + 0x58);
        uVar19 = (int32_t)(*(int64_t *)(arg1 + 0x60) - *piVar15 >> 3) * -0x55555555;
        var_1a0h = (int64_t)piVar15;
        if (uVar19 < 0x800000) {
            piVar18 = (int64_t *)(arg1 + 0xa0);
            var_190h._0_4_ = 7;
            iVar14 = *(int64_t *)(arg1 + 0x130);
            stack0xfffffffffffffe7c = SUB1612(ZEXT816(0), 4);
            var_188h._0_4_ = (int32_t)(*(int64_t *)(arg1 + 0xa8) - *piVar18 >> 3) * 0x3e0f83e1;
            var_198h = (int64_t)piVar18;
            if (((uint64_t)(iVar14 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x138)) &&
               (iVar10 = func_0x0001800d3ab0(piVar1, arg2), iVar10 == 0)) {
                iVar10 = 0x10;
                if (iVar14 != 0) {
                    iVar10 = iVar14 * 2;
                }
                func_0x0001800d3f10(&var_178h, arg1 + 0x140, iVar10);
                uVar20 = 0;
                if (*(int64_t *)(arg1 + 0x130) != 0) {
                    do {
                        iVar14 = *piVar1 + uVar20 * 0x10c;
                        uVar4 = *(uint32_t *)(iVar14 + 0x100);
                        uVar16 = (uint64_t)uVar4;
                        if (*(char *)0x180777fb8 == '\0') {
                            if (uVar4 != *(uint32_t *)(arg1 + 0x240)) goto code_r0x0001800cfa46;
                            iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 << 2);
joined_r0x0001800cfa37:
                            if (iVar9 != 0) goto code_r0x0001800cfa46;
                        } else {
                            if (((uVar4 == *(uint32_t *)(arg1 + 0x240)) &&
                                (iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 * 4), iVar9 == 0)) &&
                               (*(char *)(iVar14 + 0x104) == *(char *)(arg1 + 0x244))) {
                                bVar8 = true;
                            } else {
                                bVar8 = false;
                            }
                            if (*(char *)(iVar14 + 0x104) == '\0') {
                                if (bVar8) goto code_r0x0001800cfad7;
                            } else if (bVar8) {
                                iVar9 = func_0x000180497f30(iVar14 + 0x80, arg1 + 0x1c0, uVar16 * 4);
                                goto joined_r0x0001800cfa37;
                            }
code_r0x0001800cfa46:
                            puVar11 = (undefined8 *)func_0x0001800d3c50(&var_178h, iVar14);
                            puVar17 = (undefined8 *)(*piVar1 + uVar20 * 0x10c);
                            iVar14 = 2;
                            puVar12 = puVar17;
                            puVar13 = puVar11;
                            do {
                                puVar2 = puVar13 + 0x10;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 4);
                                uVar6 = *(undefined4 *)(puVar12 + 1);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0xc);
                                puVar3 = puVar12 + 0x10;
                                *(undefined4 *)puVar13 = *(undefined4 *)puVar12;
                                *(undefined4 *)((int64_t)puVar13 + 4) = uVar5;
                                *(undefined4 *)(puVar13 + 1) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0xc) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x14);
                                uVar6 = *(undefined4 *)(puVar12 + 3);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x1c);
                                *(undefined4 *)(puVar13 + 2) = *(undefined4 *)(puVar12 + 2);
                                *(undefined4 *)((int64_t)puVar13 + 0x14) = uVar5;
                                *(undefined4 *)(puVar13 + 3) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x1c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x24);
                                uVar6 = *(undefined4 *)(puVar12 + 5);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x2c);
                                *(undefined4 *)(puVar13 + 4) = *(undefined4 *)(puVar12 + 4);
                                *(undefined4 *)((int64_t)puVar13 + 0x24) = uVar5;
                                *(undefined4 *)(puVar13 + 5) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x2c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x34);
                                uVar6 = *(undefined4 *)(puVar12 + 7);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x3c);
                                *(undefined4 *)(puVar13 + 6) = *(undefined4 *)(puVar12 + 6);
                                *(undefined4 *)((int64_t)puVar13 + 0x34) = uVar5;
                                *(undefined4 *)(puVar13 + 7) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x3c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x44);
                                uVar6 = *(undefined4 *)(puVar12 + 9);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x4c);
                                *(undefined4 *)(puVar13 + 8) = *(undefined4 *)(puVar12 + 8);
                                *(undefined4 *)((int64_t)puVar13 + 0x44) = uVar5;
                                *(undefined4 *)(puVar13 + 9) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x4c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x54);
                                uVar6 = *(undefined4 *)(puVar12 + 0xb);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x5c);
                                *(undefined4 *)(puVar13 + 10) = *(undefined4 *)(puVar12 + 10);
                                *(undefined4 *)((int64_t)puVar13 + 0x54) = uVar5;
                                *(undefined4 *)(puVar13 + 0xb) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x5c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 100);
                                uVar6 = *(undefined4 *)(puVar12 + 0xd);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x6c);
                                *(undefined4 *)(puVar13 + 0xc) = *(undefined4 *)(puVar12 + 0xc);
                                *(undefined4 *)((int64_t)puVar13 + 100) = uVar5;
                                *(undefined4 *)(puVar13 + 0xd) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x6c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x74);
                                uVar6 = *(undefined4 *)(puVar12 + 0xf);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x7c);
                                *(undefined4 *)(puVar13 + 0xe) = *(undefined4 *)(puVar12 + 0xe);
                                *(undefined4 *)((int64_t)puVar13 + 0x74) = uVar5;
                                *(undefined4 *)(puVar13 + 0xf) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x7c) = uVar7;
                                iVar14 = iVar14 + -1;
                                puVar12 = puVar3;
                                puVar13 = puVar2;
                            } while (iVar14 != 0);
                            *puVar2 = *puVar3;
                            *(undefined4 *)(puVar11 + 0x21) = *(undefined4 *)(puVar17 + 0x21);
                        }
code_r0x0001800cfad7:
                        uVar20 = uVar20 + 1;
                        piVar15 = (int64_t *)var_1a0h;
                        arg2 = var_1a8h;
                        piVar18 = (int64_t *)var_198h;
                    } while (uVar20 < *(uint64_t *)(arg1 + 0x130));
                }
                iVar14 = *piVar1;
                *piVar1 = var_178h;
                *(int64_t *)(arg1 + 0x130) = var_170h;
                if (iVar14 != 0) {
                    fcn.1800f4640();
                }
            }
            iVar14 = func_0x0001800d3c50(piVar1, arg2);
            *(uint32_t *)(iVar14 + 0x108) = uVar19;
            func_0x0001800d2c50(piVar18, arg2);
            fcn.1800d2f00(piVar15, &var_190h);
        }
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_1800cfb66
// Address: 0x1800cfb66
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800cf840(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    bool bVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    int64_t *piVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint64_t uVar20;
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    piVar1 = (int64_t *)(arg1 + 0x128);
    var_1a8h = arg2;
    iVar10 = func_0x0001800d3ab0(piVar1);
    iVar14 = iVar10 + 0x108;
    if (iVar10 == 0) {
        iVar14 = 0;
    }
    if (iVar14 == 0) {
        piVar15 = (int64_t *)(arg1 + 0x58);
        uVar19 = (int32_t)(*(int64_t *)(arg1 + 0x60) - *piVar15 >> 3) * -0x55555555;
        var_1a0h = (int64_t)piVar15;
        if (uVar19 < 0x800000) {
            piVar18 = (int64_t *)(arg1 + 0xa0);
            var_190h._0_4_ = 7;
            iVar14 = *(int64_t *)(arg1 + 0x130);
            stack0xfffffffffffffe7c = SUB1612(ZEXT816(0), 4);
            var_188h._0_4_ = (int32_t)(*(int64_t *)(arg1 + 0xa8) - *piVar18 >> 3) * 0x3e0f83e1;
            var_198h = (int64_t)piVar18;
            if (((uint64_t)(iVar14 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x138)) &&
               (iVar10 = func_0x0001800d3ab0(piVar1, arg2), iVar10 == 0)) {
                iVar10 = 0x10;
                if (iVar14 != 0) {
                    iVar10 = iVar14 * 2;
                }
                func_0x0001800d3f10(&var_178h, arg1 + 0x140, iVar10);
                uVar20 = 0;
                if (*(int64_t *)(arg1 + 0x130) != 0) {
                    do {
                        iVar14 = *piVar1 + uVar20 * 0x10c;
                        uVar4 = *(uint32_t *)(iVar14 + 0x100);
                        uVar16 = (uint64_t)uVar4;
                        if (*(char *)0x180777fb8 == '\0') {
                            if (uVar4 != *(uint32_t *)(arg1 + 0x240)) goto code_r0x0001800cfa46;
                            iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 << 2);
joined_r0x0001800cfa37:
                            if (iVar9 != 0) goto code_r0x0001800cfa46;
                        } else {
                            if (((uVar4 == *(uint32_t *)(arg1 + 0x240)) &&
                                (iVar9 = func_0x000180497f30(iVar14, arg1 + 0x140, uVar16 * 4), iVar9 == 0)) &&
                               (*(char *)(iVar14 + 0x104) == *(char *)(arg1 + 0x244))) {
                                bVar8 = true;
                            } else {
                                bVar8 = false;
                            }
                            if (*(char *)(iVar14 + 0x104) == '\0') {
                                if (bVar8) goto code_r0x0001800cfad7;
                            } else if (bVar8) {
                                iVar9 = func_0x000180497f30(iVar14 + 0x80, arg1 + 0x1c0, uVar16 * 4);
                                goto joined_r0x0001800cfa37;
                            }
code_r0x0001800cfa46:
                            puVar11 = (undefined8 *)func_0x0001800d3c50(&var_178h, iVar14);
                            puVar17 = (undefined8 *)(*piVar1 + uVar20 * 0x10c);
                            iVar14 = 2;
                            puVar12 = puVar17;
                            puVar13 = puVar11;
                            do {
                                puVar2 = puVar13 + 0x10;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 4);
                                uVar6 = *(undefined4 *)(puVar12 + 1);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0xc);
                                puVar3 = puVar12 + 0x10;
                                *(undefined4 *)puVar13 = *(undefined4 *)puVar12;
                                *(undefined4 *)((int64_t)puVar13 + 4) = uVar5;
                                *(undefined4 *)(puVar13 + 1) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0xc) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x14);
                                uVar6 = *(undefined4 *)(puVar12 + 3);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x1c);
                                *(undefined4 *)(puVar13 + 2) = *(undefined4 *)(puVar12 + 2);
                                *(undefined4 *)((int64_t)puVar13 + 0x14) = uVar5;
                                *(undefined4 *)(puVar13 + 3) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x1c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x24);
                                uVar6 = *(undefined4 *)(puVar12 + 5);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x2c);
                                *(undefined4 *)(puVar13 + 4) = *(undefined4 *)(puVar12 + 4);
                                *(undefined4 *)((int64_t)puVar13 + 0x24) = uVar5;
                                *(undefined4 *)(puVar13 + 5) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x2c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x34);
                                uVar6 = *(undefined4 *)(puVar12 + 7);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x3c);
                                *(undefined4 *)(puVar13 + 6) = *(undefined4 *)(puVar12 + 6);
                                *(undefined4 *)((int64_t)puVar13 + 0x34) = uVar5;
                                *(undefined4 *)(puVar13 + 7) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x3c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x44);
                                uVar6 = *(undefined4 *)(puVar12 + 9);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x4c);
                                *(undefined4 *)(puVar13 + 8) = *(undefined4 *)(puVar12 + 8);
                                *(undefined4 *)((int64_t)puVar13 + 0x44) = uVar5;
                                *(undefined4 *)(puVar13 + 9) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x4c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x54);
                                uVar6 = *(undefined4 *)(puVar12 + 0xb);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x5c);
                                *(undefined4 *)(puVar13 + 10) = *(undefined4 *)(puVar12 + 10);
                                *(undefined4 *)((int64_t)puVar13 + 0x54) = uVar5;
                                *(undefined4 *)(puVar13 + 0xb) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x5c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 100);
                                uVar6 = *(undefined4 *)(puVar12 + 0xd);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x6c);
                                *(undefined4 *)(puVar13 + 0xc) = *(undefined4 *)(puVar12 + 0xc);
                                *(undefined4 *)((int64_t)puVar13 + 100) = uVar5;
                                *(undefined4 *)(puVar13 + 0xd) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x6c) = uVar7;
                                uVar5 = *(undefined4 *)((int64_t)puVar12 + 0x74);
                                uVar6 = *(undefined4 *)(puVar12 + 0xf);
                                uVar7 = *(undefined4 *)((int64_t)puVar12 + 0x7c);
                                *(undefined4 *)(puVar13 + 0xe) = *(undefined4 *)(puVar12 + 0xe);
                                *(undefined4 *)((int64_t)puVar13 + 0x74) = uVar5;
                                *(undefined4 *)(puVar13 + 0xf) = uVar6;
                                *(undefined4 *)((int64_t)puVar13 + 0x7c) = uVar7;
                                iVar14 = iVar14 + -1;
                                puVar12 = puVar3;
                                puVar13 = puVar2;
                            } while (iVar14 != 0);
                            *puVar2 = *puVar3;
                            *(undefined4 *)(puVar11 + 0x21) = *(undefined4 *)(puVar17 + 0x21);
                        }
code_r0x0001800cfad7:
                        uVar20 = uVar20 + 1;
                        piVar15 = (int64_t *)var_1a0h;
                        arg2 = var_1a8h;
                        piVar18 = (int64_t *)var_198h;
                    } while (uVar20 < *(uint64_t *)(arg1 + 0x130));
                }
                iVar14 = *piVar1;
                *piVar1 = var_178h;
                *(int64_t *)(arg1 + 0x130) = var_170h;
                if (iVar14 != 0) {
                    fcn.1800f4640();
                }
            }
            iVar14 = func_0x0001800d3c50(piVar1, arg2);
            *(uint32_t *)(iVar14 + 0x108) = uVar19;
            func_0x0001800d2c50(piVar18, arg2);
            fcn.1800d2f00(piVar15, &var_190h);
        }
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_1800cfb90
// Address: 0x1800cfb90
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800cfb90(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint16_t *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t *puVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_10h._0_4_ = (undefined4)arg2;
    piVar1 = (int64_t *)(arg1 + 0x250);
    iVar5 = fcn.1800d3940(piVar1);
    puVar6 = (uint16_t *)(iVar5 + 4);
    if (iVar5 == 0) {
        puVar6 = (uint16_t *)0x0;
    }
    if (puVar6 != (uint16_t *)0x0) {
        return (uint64_t)*puVar6;
    }
    uVar11 = *(int64_t *)(arg1 + 0x78) - *(int64_t *)(arg1 + 0x70) >> 2;
    if (0x7fff < (uint32_t)uVar11) {
        return 0xffffffff;
    }
    iVar7 = *(int64_t *)(arg1 + 600);
    if ((*(uint64_t *)(arg1 + 0x260) < (uint64_t)(iVar7 * 3) >> 2) || (iVar5 != 0)) goto code_r0x0001800cfd9a;
    uVar2 = *(uint32_t *)(arg1 + 0x268);
    if (iVar7 == 0) {
        uVar12 = 0x10;
        iVar7 = fcn.180459890();
        uVar8 = 0;
        iVar5 = iVar7;
        uVar13 = 0x10;
code_r0x0001800cfc90:
        do {
            *(uint32_t *)(iVar7 + uVar8 * 8) = *(uint32_t *)(arg1 + 0x268);
            *(undefined2 *)(iVar7 + 4 + uVar8 * 8) = 0;
            uVar8 = uVar8 + 1;
        } while (uVar8 < uVar12);
    } else {
        uVar12 = iVar7 * 2;
        if (uVar12 == 0) {
            iVar5 = 0;
            uVar13 = 0;
        } else {
            iVar7 = fcn.180459890();
            uVar8 = 0;
            iVar5 = iVar7;
            uVar13 = uVar12;
            if (uVar12 != 0) goto code_r0x0001800cfc90;
        }
    }
    uVar12 = 0;
    if (*(int64_t *)(arg1 + 600) != 0) {
        do {
            uVar3 = *(uint32_t *)(*piVar1 + uVar12 * 8);
            if (uVar3 != *(uint32_t *)(arg1 + 0x268)) {
                uVar8 = (((((uint64_t)(uVar3 & 0xff) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                          (uint64_t)(uVar3 >> 8 & 0xff)) * 0x100000001b3 ^ (uint64_t)(uVar3 >> 0x10 & 0xff)) *
                         0x100000001b3 ^ (uint64_t)(uVar3 >> 0x18)) * 0x100000001b3;
                uVar9 = 0;
                do {
                    uVar8 = uVar8 & uVar13 - 1;
                    uVar4 = *(uint32_t *)(iVar5 + uVar8 * 8);
                    puVar10 = (uint32_t *)(iVar5 + uVar8 * 8);
                    if (uVar4 == uVar2) {
                        *puVar10 = uVar3;
                        goto code_r0x0001800cfd4c;
                    }
                    if (uVar4 == uVar3) goto code_r0x0001800cfd4c;
                    uVar8 = uVar8 + 1 + uVar9;
                    uVar9 = uVar9 + 1;
                } while (uVar9 <= uVar13 - 1);
                puVar10 = (uint32_t *)0x0;
code_r0x0001800cfd4c:
                iVar7 = *piVar1;
                *puVar10 = *(uint32_t *)(iVar7 + uVar12 * 8);
                *(undefined2 *)(puVar10 + 1) = *(undefined2 *)(iVar7 + uVar12 * 8 + 4);
            }
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(arg1 + 600));
    }
    iVar7 = *piVar1;
    *(uint64_t *)(arg1 + 600) = uVar13;
    *piVar1 = iVar5;
    if (iVar7 != 0) {
        fcn.1800f4640();
    }
code_r0x0001800cfd9a:
    iVar5 = fcn.1800d3a00(piVar1, &var_10h);
    *(int16_t *)(iVar5 + 4) = (int16_t)uVar11;
    fcn.1800d31a0(arg1 + 0x70, &var_10h);
    return uVar11 & 0xffff;
}

// ============================================================
// Function: FUN_1800cfbd0
// Address: 0x1800cfbd0
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800cfb90(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint16_t *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t *puVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_10h._0_4_ = (undefined4)arg2;
    piVar1 = (int64_t *)(arg1 + 0x250);
    iVar5 = fcn.1800d3940(piVar1);
    puVar6 = (uint16_t *)(iVar5 + 4);
    if (iVar5 == 0) {
        puVar6 = (uint16_t *)0x0;
    }
    if (puVar6 != (uint16_t *)0x0) {
        return (uint64_t)*puVar6;
    }
    uVar11 = *(int64_t *)(arg1 + 0x78) - *(int64_t *)(arg1 + 0x70) >> 2;
    if (0x7fff < (uint32_t)uVar11) {
        return 0xffffffff;
    }
    iVar7 = *(int64_t *)(arg1 + 600);
    if ((*(uint64_t *)(arg1 + 0x260) < (uint64_t)(iVar7 * 3) >> 2) || (iVar5 != 0)) goto code_r0x0001800cfd9a;
    uVar2 = *(uint32_t *)(arg1 + 0x268);
    if (iVar7 == 0) {
        uVar12 = 0x10;
        iVar7 = fcn.180459890();
        uVar8 = 0;
        iVar5 = iVar7;
        uVar13 = 0x10;
code_r0x0001800cfc90:
        do {
            *(uint32_t *)(iVar7 + uVar8 * 8) = *(uint32_t *)(arg1 + 0x268);
            *(undefined2 *)(iVar7 + 4 + uVar8 * 8) = 0;
            uVar8 = uVar8 + 1;
        } while (uVar8 < uVar12);
    } else {
        uVar12 = iVar7 * 2;
        if (uVar12 == 0) {
            iVar5 = 0;
            uVar13 = 0;
        } else {
            iVar7 = fcn.180459890();
            uVar8 = 0;
            iVar5 = iVar7;
            uVar13 = uVar12;
            if (uVar12 != 0) goto code_r0x0001800cfc90;
        }
    }
    uVar12 = 0;
    if (*(int64_t *)(arg1 + 600) != 0) {
        do {
            uVar3 = *(uint32_t *)(*piVar1 + uVar12 * 8);
            if (uVar3 != *(uint32_t *)(arg1 + 0x268)) {
                uVar8 = (((((uint64_t)(uVar3 & 0xff) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                          (uint64_t)(uVar3 >> 8 & 0xff)) * 0x100000001b3 ^ (uint64_t)(uVar3 >> 0x10 & 0xff)) *
                         0x100000001b3 ^ (uint64_t)(uVar3 >> 0x18)) * 0x100000001b3;
                uVar9 = 0;
                do {
                    uVar8 = uVar8 & uVar13 - 1;
                    uVar4 = *(uint32_t *)(iVar5 + uVar8 * 8);
                    puVar10 = (uint32_t *)(iVar5 + uVar8 * 8);
                    if (uVar4 == uVar2) {
                        *puVar10 = uVar3;
                        goto code_r0x0001800cfd4c;
                    }
                    if (uVar4 == uVar3) goto code_r0x0001800cfd4c;
                    uVar8 = uVar8 + 1 + uVar9;
                    uVar9 = uVar9 + 1;
                } while (uVar9 <= uVar13 - 1);
                puVar10 = (uint32_t *)0x0;
code_r0x0001800cfd4c:
                iVar7 = *piVar1;
                *puVar10 = *(uint32_t *)(iVar7 + uVar12 * 8);
                *(undefined2 *)(puVar10 + 1) = *(undefined2 *)(iVar7 + uVar12 * 8 + 4);
            }
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(arg1 + 600));
    }
    iVar7 = *piVar1;
    *(uint64_t *)(arg1 + 600) = uVar13;
    *piVar1 = iVar5;
    if (iVar7 != 0) {
        fcn.1800f4640();
    }
code_r0x0001800cfd9a:
    iVar5 = fcn.1800d3a00(piVar1, &var_10h);
    *(int16_t *)(iVar5 + 4) = (int16_t)uVar11;
    fcn.1800d31a0(arg1 + 0x70, &var_10h);
    return uVar11 & 0xffff;
}

// ============================================================
// Function: FUN_1800cfc0d
// Address: 0x1800cfc0d
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800cfb90(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint16_t *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t *puVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_10h._0_4_ = (undefined4)arg2;
    piVar1 = (int64_t *)(arg1 + 0x250);
    iVar5 = fcn.1800d3940(piVar1);
    puVar6 = (uint16_t *)(iVar5 + 4);
    if (iVar5 == 0) {
        puVar6 = (uint16_t *)0x0;
    }
    if (puVar6 != (uint16_t *)0x0) {
        return (uint64_t)*puVar6;
    }
    uVar11 = *(int64_t *)(arg1 + 0x78) - *(int64_t *)(arg1 + 0x70) >> 2;
    if (0x7fff < (uint32_t)uVar11) {
        return 0xffffffff;
    }
    iVar7 = *(int64_t *)(arg1 + 600);
    if ((*(uint64_t *)(arg1 + 0x260) < (uint64_t)(iVar7 * 3) >> 2) || (iVar5 != 0)) goto code_r0x0001800cfd9a;
    uVar2 = *(uint32_t *)(arg1 + 0x268);
    if (iVar7 == 0) {
        uVar12 = 0x10;
        iVar7 = fcn.180459890();
        uVar8 = 0;
        iVar5 = iVar7;
        uVar13 = 0x10;
code_r0x0001800cfc90:
        do {
            *(uint32_t *)(iVar7 + uVar8 * 8) = *(uint32_t *)(arg1 + 0x268);
            *(undefined2 *)(iVar7 + 4 + uVar8 * 8) = 0;
            uVar8 = uVar8 + 1;
        } while (uVar8 < uVar12);
    } else {
        uVar12 = iVar7 * 2;
        if (uVar12 == 0) {
            iVar5 = 0;
            uVar13 = 0;
        } else {
            iVar7 = fcn.180459890();
            uVar8 = 0;
            iVar5 = iVar7;
            uVar13 = uVar12;
            if (uVar12 != 0) goto code_r0x0001800cfc90;
        }
    }
    uVar12 = 0;
    if (*(int64_t *)(arg1 + 600) != 0) {
        do {
            uVar3 = *(uint32_t *)(*piVar1 + uVar12 * 8);
            if (uVar3 != *(uint32_t *)(arg1 + 0x268)) {
                uVar8 = (((((uint64_t)(uVar3 & 0xff) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                          (uint64_t)(uVar3 >> 8 & 0xff)) * 0x100000001b3 ^ (uint64_t)(uVar3 >> 0x10 & 0xff)) *
                         0x100000001b3 ^ (uint64_t)(uVar3 >> 0x18)) * 0x100000001b3;
                uVar9 = 0;
                do {
                    uVar8 = uVar8 & uVar13 - 1;
                    uVar4 = *(uint32_t *)(iVar5 + uVar8 * 8);
                    puVar10 = (uint32_t *)(iVar5 + uVar8 * 8);
                    if (uVar4 == uVar2) {
                        *puVar10 = uVar3;
                        goto code_r0x0001800cfd4c;
                    }
                    if (uVar4 == uVar3) goto code_r0x0001800cfd4c;
                    uVar8 = uVar8 + 1 + uVar9;
                    uVar9 = uVar9 + 1;
                } while (uVar9 <= uVar13 - 1);
                puVar10 = (uint32_t *)0x0;
code_r0x0001800cfd4c:
                iVar7 = *piVar1;
                *puVar10 = *(uint32_t *)(iVar7 + uVar12 * 8);
                *(undefined2 *)(puVar10 + 1) = *(undefined2 *)(iVar7 + uVar12 * 8 + 4);
            }
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(arg1 + 600));
    }
    iVar7 = *piVar1;
    *(uint64_t *)(arg1 + 600) = uVar13;
    *piVar1 = iVar5;
    if (iVar7 != 0) {
        fcn.1800f4640();
    }
code_r0x0001800cfd9a:
    iVar5 = fcn.1800d3a00(piVar1, &var_10h);
    *(int16_t *)(iVar5 + 4) = (int16_t)uVar11;
    fcn.1800d31a0(arg1 + 0x70, &var_10h);
    return uVar11 & 0xffff;
}

// ============================================================
// Function: FUN_1800cfc2c
// Address: 0x1800cfc2c
// Size: 361 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800cfb90(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint16_t *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t *puVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_10h._0_4_ = (undefined4)arg2;
    piVar1 = (int64_t *)(arg1 + 0x250);
    iVar5 = fcn.1800d3940(piVar1);
    puVar6 = (uint16_t *)(iVar5 + 4);
    if (iVar5 == 0) {
        puVar6 = (uint16_t *)0x0;
    }
    if (puVar6 != (uint16_t *)0x0) {
        return (uint64_t)*puVar6;
    }
    uVar11 = *(int64_t *)(arg1 + 0x78) - *(int64_t *)(arg1 + 0x70) >> 2;
    if (0x7fff < (uint32_t)uVar11) {
        return 0xffffffff;
    }
    iVar7 = *(int64_t *)(arg1 + 600);
    if ((*(uint64_t *)(arg1 + 0x260) < (uint64_t)(iVar7 * 3) >> 2) || (iVar5 != 0)) goto code_r0x0001800cfd9a;
    uVar2 = *(uint32_t *)(arg1 + 0x268);
    if (iVar7 == 0) {
        uVar12 = 0x10;
        iVar7 = fcn.180459890();
        uVar8 = 0;
        iVar5 = iVar7;
        uVar13 = 0x10;
code_r0x0001800cfc90:
        do {
            *(uint32_t *)(iVar7 + uVar8 * 8) = *(uint32_t *)(arg1 + 0x268);
            *(undefined2 *)(iVar7 + 4 + uVar8 * 8) = 0;
            uVar8 = uVar8 + 1;
        } while (uVar8 < uVar12);
    } else {
        uVar12 = iVar7 * 2;
        if (uVar12 == 0) {
            iVar5 = 0;
            uVar13 = 0;
        } else {
            iVar7 = fcn.180459890();
            uVar8 = 0;
            iVar5 = iVar7;
            uVar13 = uVar12;
            if (uVar12 != 0) goto code_r0x0001800cfc90;
        }
    }
    uVar12 = 0;
    if (*(int64_t *)(arg1 + 600) != 0) {
        do {
            uVar3 = *(uint32_t *)(*piVar1 + uVar12 * 8);
            if (uVar3 != *(uint32_t *)(arg1 + 0x268)) {
                uVar8 = (((((uint64_t)(uVar3 & 0xff) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                          (uint64_t)(uVar3 >> 8 & 0xff)) * 0x100000001b3 ^ (uint64_t)(uVar3 >> 0x10 & 0xff)) *
                         0x100000001b3 ^ (uint64_t)(uVar3 >> 0x18)) * 0x100000001b3;
                uVar9 = 0;
                do {
                    uVar8 = uVar8 & uVar13 - 1;
                    uVar4 = *(uint32_t *)(iVar5 + uVar8 * 8);
                    puVar10 = (uint32_t *)(iVar5 + uVar8 * 8);
                    if (uVar4 == uVar2) {
                        *puVar10 = uVar3;
                        goto code_r0x0001800cfd4c;
                    }
                    if (uVar4 == uVar3) goto code_r0x0001800cfd4c;
                    uVar8 = uVar8 + 1 + uVar9;
                    uVar9 = uVar9 + 1;
                } while (uVar9 <= uVar13 - 1);
                puVar10 = (uint32_t *)0x0;
code_r0x0001800cfd4c:
                iVar7 = *piVar1;
                *puVar10 = *(uint32_t *)(iVar7 + uVar12 * 8);
                *(undefined2 *)(puVar10 + 1) = *(undefined2 *)(iVar7 + uVar12 * 8 + 4);
            }
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(arg1 + 600));
    }
    iVar7 = *piVar1;
    *(uint64_t *)(arg1 + 600) = uVar13;
    *piVar1 = iVar5;
    if (iVar7 != 0) {
        fcn.1800f4640();
    }
code_r0x0001800cfd9a:
    iVar5 = fcn.1800d3a00(piVar1, &var_10h);
    *(int16_t *)(iVar5 + 4) = (int16_t)uVar11;
    fcn.1800d31a0(arg1 + 0x70, &var_10h);
    return uVar11 & 0xffff;
}

// ============================================================
// Function: FUN_1800cfd95
// Address: 0x1800cfd95
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800cfb90(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint16_t *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t *puVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_10h._0_4_ = (undefined4)arg2;
    piVar1 = (int64_t *)(arg1 + 0x250);
    iVar5 = fcn.1800d3940(piVar1);
    puVar6 = (uint16_t *)(iVar5 + 4);
    if (iVar5 == 0) {
        puVar6 = (uint16_t *)0x0;
    }
    if (puVar6 != (uint16_t *)0x0) {
        return (uint64_t)*puVar6;
    }
    uVar11 = *(int64_t *)(arg1 + 0x78) - *(int64_t *)(arg1 + 0x70) >> 2;
    if (0x7fff < (uint32_t)uVar11) {
        return 0xffffffff;
    }
    iVar7 = *(int64_t *)(arg1 + 600);
    if ((*(uint64_t *)(arg1 + 0x260) < (uint64_t)(iVar7 * 3) >> 2) || (iVar5 != 0)) goto code_r0x0001800cfd9a;
    uVar2 = *(uint32_t *)(arg1 + 0x268);
    if (iVar7 == 0) {
        uVar12 = 0x10;
        iVar7 = fcn.180459890();
        uVar8 = 0;
        iVar5 = iVar7;
        uVar13 = 0x10;
code_r0x0001800cfc90:
        do {
            *(uint32_t *)(iVar7 + uVar8 * 8) = *(uint32_t *)(arg1 + 0x268);
            *(undefined2 *)(iVar7 + 4 + uVar8 * 8) = 0;
            uVar8 = uVar8 + 1;
        } while (uVar8 < uVar12);
    } else {
        uVar12 = iVar7 * 2;
        if (uVar12 == 0) {
            iVar5 = 0;
            uVar13 = 0;
        } else {
            iVar7 = fcn.180459890();
            uVar8 = 0;
            iVar5 = iVar7;
            uVar13 = uVar12;
            if (uVar12 != 0) goto code_r0x0001800cfc90;
        }
    }
    uVar12 = 0;
    if (*(int64_t *)(arg1 + 600) != 0) {
        do {
            uVar3 = *(uint32_t *)(*piVar1 + uVar12 * 8);
            if (uVar3 != *(uint32_t *)(arg1 + 0x268)) {
                uVar8 = (((((uint64_t)(uVar3 & 0xff) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                          (uint64_t)(uVar3 >> 8 & 0xff)) * 0x100000001b3 ^ (uint64_t)(uVar3 >> 0x10 & 0xff)) *
                         0x100000001b3 ^ (uint64_t)(uVar3 >> 0x18)) * 0x100000001b3;
                uVar9 = 0;
                do {
                    uVar8 = uVar8 & uVar13 - 1;
                    uVar4 = *(uint32_t *)(iVar5 + uVar8 * 8);
                    puVar10 = (uint32_t *)(iVar5 + uVar8 * 8);
                    if (uVar4 == uVar2) {
                        *puVar10 = uVar3;
                        goto code_r0x0001800cfd4c;
                    }
                    if (uVar4 == uVar3) goto code_r0x0001800cfd4c;
                    uVar8 = uVar8 + 1 + uVar9;
                    uVar9 = uVar9 + 1;
                } while (uVar9 <= uVar13 - 1);
                puVar10 = (uint32_t *)0x0;
code_r0x0001800cfd4c:
                iVar7 = *piVar1;
                *puVar10 = *(uint32_t *)(iVar7 + uVar12 * 8);
                *(undefined2 *)(puVar10 + 1) = *(undefined2 *)(iVar7 + uVar12 * 8 + 4);
            }
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(arg1 + 600));
    }
    iVar7 = *piVar1;
    *(uint64_t *)(arg1 + 600) = uVar13;
    *piVar1 = iVar5;
    if (iVar7 != 0) {
        fcn.1800f4640();
    }
code_r0x0001800cfd9a:
    iVar5 = fcn.1800d3a00(piVar1, &var_10h);
    *(int16_t *)(iVar5 + 4) = (int16_t)uVar11;
    fcn.1800d31a0(arg1 + 0x70, &var_10h);
    return uVar11 & 0xffff;
}

// ============================================================
// Function: FUN_1800cfdd0
// Address: 0x1800cfdd0
// Size: 84 bytes
// ============================================================
void fcn.1800cfdd0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    undefined4 *puVar3;
    code *pcVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined4 *puVar7;
    undefined *puVar8;
    undefined8 *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    int64_t iVar15;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined8 auStack_30 [3];
    
    arg_28h._0_4_ =
         (((uint32_t)(uint8_t)arg_28h << 8 | (uint32_t)placeholder_3 & 0xff) << 8 | (uint32_t)placeholder_2 & 0xff) << 8
         | (uint32_t)arg2;
    auStack_30[0] = 0x1800cfe0f;
    fcn.1800d31a0(arg1 + 0x28, &arg_28h);
    puVar1 = (uint64_t *)(arg1 + 0x40);
    puVar9 = (undefined8 *)auStack_38;
    puVar10 = auStack_38;
    puVar7 = *(undefined4 **)(arg1 + 0x48);
    if (puVar7 != *(undefined4 **)(arg1 + 0x50)) {
        *puVar7 = *(undefined4 *)(arg1 + 0x270);
        *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 4;
        return;
    }
    iVar15 = (int64_t)((int64_t)puVar7 - *puVar1) >> 2;
    if (iVar15 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar6 = (int64_t)((int64_t)*(undefined4 **)(arg1 + 0x50) - *puVar1) >> 2;
    if (uVar6 <= 0x3fffffffffffffff - (uVar6 >> 1)) {
        uVar2 = iVar15 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar11 = uVar2;
        if (uVar2 <= uVar6) {
            uVar11 = uVar6;
        }
        if (uVar11 < 0x4000000000000000) {
            uVar6 = uVar11 * 4;
            if (uVar6 == 0) {
                uVar6 = 0;
                puVar10 = auStack_38;
            } else if (uVar6 < 0x1000) {
                uVar6 = fcn.180459890();
            } else {
                if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800d32fa;
                iVar13 = fcn.180459890(uVar6 + 0x27);
                if (iVar13 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar13 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                uVar6 = iVar13 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar13;
                puVar10 = (undefined *)puVar9;
            }
            *(undefined4 *)(uVar6 + iVar15 * 4) = *(undefined4 *)(arg1 + 0x270);
            puVar3 = (undefined4 *)*puVar1;
            if (puVar7 == *(undefined4 **)(arg1 + 0x48)) {
                iVar13 = (int64_t)*(undefined4 **)(arg1 + 0x48) - (int64_t)puVar3;
                uVar14 = uVar6;
                puVar7 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800d32b0;
                fcn.180498030(uVar6, puVar3, (int64_t)puVar7 - (int64_t)puVar3);
                iVar13 = *(int64_t *)(arg1 + 0x48) - (int64_t)puVar7;
                uVar14 = uVar6 + (iVar15 + 1) * 4;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800d32c7;
            fcn.180498030(uVar14, puVar7, iVar13);
            uVar12 = *(undefined8 *)(puVar10 + 0x28);
            *(undefined8 *)(puVar10 + 0x30) = *(undefined8 *)(puVar10 + 0x30);
            *(undefined8 *)(puVar10 + 0x28) = *(undefined8 *)(puVar10 + 0x40);
            *(undefined8 *)(puVar10 + 0x20) = uVar12;
            *(undefined8 *)(puVar10 + 0x18) = *(undefined8 *)(puVar10 + 0x48);
            uVar14 = *puVar1;
            if (uVar14 != 0) {
                uVar5 = uVar14;
                puVar8 = puVar10 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x50) - uVar14) >> 2) * 4)) {
                    uVar5 = *(uint64_t *)(uVar14 - 8);
                    uVar14 = (uVar14 - uVar5) - 8;
                    puVar8 = puVar10 + -0x10;
                    if (0x1f < uVar14) {
                        pcVar4 = (code *)swi(0x29);
                        uVar5 = uVar14;
                        (*pcVar4)(5);
                        puVar8 = puVar10 + -8;
                    }
                }
                *(undefined8 *)(puVar8 + -8) = 0x180030d9f;
                fcn.180459c3c(uVar5);
            }
            *puVar1 = uVar6;
            *(uint64_t *)(arg1 + 0x48) = uVar6 + uVar2 * 4;
            *(uint64_t *)(arg1 + 0x50) = uVar6 + uVar11 * 4;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

