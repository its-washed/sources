// Chunk 34 - 50 functions

// ============================================================
// Function: FUN_180072daf
// Address: 0x180072daf
// Size: 288 bytes
// ============================================================
void fcn.180072daf(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined *puVar1;
    undefined *puVar2;
    undefined uVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    int32_t unaff_R14D;
    
    uVar5 = 0;
    do {
        puVar1 = *(undefined **)(arg1 + 0xc0);
        if (puVar1 < *(undefined **)(arg1 + 200)) {
            uVar3 = *puVar1;
            *(undefined **)(arg1 + 0xc0) = puVar1 + 1;
        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
            uVar3 = 0;
        } else {
            func_0x000180069750(arg1);
            uVar3 = **(undefined **)(arg1 + 0xc0);
            *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
        }
        *(undefined *)(arg2 + 2 + uVar5 * 4) = uVar3;
        puVar1 = (undefined *)(arg2 + uVar5 * 4);
        puVar2 = *(undefined **)(arg1 + 0xc0);
        if (puVar2 < *(undefined **)(arg1 + 200)) {
            uVar3 = *puVar2;
            *(undefined **)(arg1 + 0xc0) = puVar2 + 1;
        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
            uVar3 = 0;
        } else {
            func_0x000180069750(arg1);
            uVar3 = **(undefined **)(arg1 + 0xc0);
            *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
        }
        puVar1[1] = uVar3;
        puVar2 = *(undefined **)(arg1 + 0xc0);
        if (puVar2 < *(undefined **)(arg1 + 200)) {
            uVar3 = *puVar2;
            *(undefined **)(arg1 + 0xc0) = puVar2 + 1;
        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
            uVar3 = 0;
        } else {
            func_0x000180069750(arg1);
            uVar3 = **(undefined **)(arg1 + 0xc0);
            *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
        }
        *puVar1 = uVar3;
        uVar3 = 0xff;
        if (unaff_R14D == (int32_t)uVar5) {
            uVar3 = 0;
        }
        uVar4 = (int32_t)uVar5 + 1;
        uVar5 = (uint64_t)uVar4;
        puVar1[3] = uVar3;
    } while ((int32_t)uVar4 < (int32_t)arg3);
    return;
}

// ============================================================
// Function: FUN_180072ecf
// Address: 0x180072ecf
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_40h

void fcn.180072daf(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined *puVar1;
    undefined *puVar2;
    undefined uVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    int32_t unaff_R14D;
    
    uVar5 = 0;
    do {
        puVar1 = *(undefined **)(arg1 + 0xc0);
        if (puVar1 < *(undefined **)(arg1 + 200)) {
            uVar3 = *puVar1;
            *(undefined **)(arg1 + 0xc0) = puVar1 + 1;
        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
            uVar3 = 0;
        } else {
            func_0x000180069750(arg1);
            uVar3 = **(undefined **)(arg1 + 0xc0);
            *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
        }
        *(undefined *)(arg2 + 2 + uVar5 * 4) = uVar3;
        puVar1 = (undefined *)(arg2 + uVar5 * 4);
        puVar2 = *(undefined **)(arg1 + 0xc0);
        if (puVar2 < *(undefined **)(arg1 + 200)) {
            uVar3 = *puVar2;
            *(undefined **)(arg1 + 0xc0) = puVar2 + 1;
        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
            uVar3 = 0;
        } else {
            func_0x000180069750(arg1);
            uVar3 = **(undefined **)(arg1 + 0xc0);
            *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
        }
        puVar1[1] = uVar3;
        puVar2 = *(undefined **)(arg1 + 0xc0);
        if (puVar2 < *(undefined **)(arg1 + 200)) {
            uVar3 = *puVar2;
            *(undefined **)(arg1 + 0xc0) = puVar2 + 1;
        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
            uVar3 = 0;
        } else {
            func_0x000180069750(arg1);
            uVar3 = **(undefined **)(arg1 + 0xc0);
            *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
        }
        *puVar1 = uVar3;
        uVar3 = 0xff;
        if (unaff_R14D == (int32_t)uVar5) {
            uVar3 = 0;
        }
        uVar4 = (int32_t)uVar5 + 1;
        uVar5 = (uint64_t)uVar4;
        puVar1[3] = uVar3;
    } while ((int32_t)uVar4 < (int32_t)arg3);
    return;
}

// ============================================================
// Function: FUN_180072ed0
// Address: 0x180072ed0
// Size: 346 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180072ed0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    uint8_t uVar2;
    undefined4 uVar3;
    char *pcVar4;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    
    pcVar4 = *(char **)(arg1 + 0xc0);
    if (*(char **)(arg1 + 200) <= pcVar4) {
        if (*(int32_t *)(arg1 + 0x30) == 0) {
            return 0;
        }
        func_0x000180069750();
        pcVar4 = *(char **)(arg1 + 0xc0);
    }
    cVar1 = *pcVar4;
    *(char **)(arg1 + 0xc0) = pcVar4 + 1;
    if (((((cVar1 == 'G') && (cVar1 = func_0x0001800697d0(arg1), cVar1 == 'I')) &&
         (cVar1 = func_0x0001800697d0(arg1), cVar1 == 'F')) &&
        ((cVar1 = func_0x0001800697d0(arg1), cVar1 == '8' &&
         (cVar1 = func_0x0001800697d0(arg1), (cVar1 - 0x37U & 0xfd) == 0)))) &&
       (cVar1 = func_0x0001800697d0(arg1), cVar1 == 'a')) {
        *(undefined8 *)
         (*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 0x28) =
             0x1805aadb1;
        uVar3 = func_0x000180069a30(arg1);
        *(undefined4 *)arg2 = uVar3;
        uVar3 = func_0x000180069a30(arg1);
        *(undefined4 *)(arg2 + 4) = uVar3;
        uVar2 = func_0x0001800697d0(arg1);
        *(uint32_t *)(arg2 + 0x20) = (uint32_t)uVar2;
        uVar2 = func_0x0001800697d0(arg1);
        *(uint32_t *)(arg2 + 0x24) = (uint32_t)uVar2;
        uVar2 = func_0x0001800697d0(arg1);
        *(uint32_t *)(arg2 + 0x28) = (uint32_t)uVar2;
        *(undefined4 *)(arg2 + 0x2c) = 0xffffffff;
        if ((*(int32_t *)arg2 < 0x1000001) && (*(int32_t *)(arg2 + 4) < 0x1000001)) {
            uVar2 = (uint8_t)*(undefined4 *)(arg2 + 0x20);
            if ((char)uVar2 < '\0') {
                func_0x000180072d90(arg1, arg2 + 0x34, 2 << (uVar2 & 7), 0xffffffff);
            }
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180073030
// Address: 0x180073030
// Size: 279 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180073030(int64_t arg1)
{
    undefined *puVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined *puVar4;
    uint16_t in_DX;
    int32_t iVar5;
    int64_t var_8h;
    
    if (-1 < *(int16_t *)(arg1 + 0x834 + (uint64_t)in_DX * 4)) {
        fcn.180073030(arg1);
    }
    if (*(int32_t *)(arg1 + 0x8860) < *(int32_t *)(arg1 + 0x8858)) {
        iVar2 = *(int64_t *)(arg1 + 8);
        iVar5 = *(int32_t *)(arg1 + 0x885c) + *(int32_t *)(arg1 + 0x8860);
        *(undefined *)((int64_t)((int32_t)(iVar5 + (iVar5 >> 0x1f & 3U)) >> 2) + *(int64_t *)(arg1 + 0x18)) = 1;
        uVar3 = (uint64_t)*(uint8_t *)(arg1 + 0x837 + (uint64_t)in_DX * 4);
        puVar1 = (undefined *)(*(int64_t *)(arg1 + 0x8838) + uVar3 * 4);
        if (0x80 < *(uint8_t *)(*(int64_t *)(arg1 + 0x8838) + 3 + uVar3 * 4)) {
            puVar4 = (undefined *)(iVar5 + iVar2);
            *puVar4 = puVar1[2];
            puVar4[1] = puVar1[1];
            puVar4[2] = *puVar1;
            puVar4[3] = puVar1[3];
        }
        *(int32_t *)(arg1 + 0x885c) = *(int32_t *)(arg1 + 0x885c) + 4;
        if (*(int32_t *)(arg1 + 0x8854) <= *(int32_t *)(arg1 + 0x885c)) {
            *(undefined4 *)(arg1 + 0x885c) = *(undefined4 *)(arg1 + 0x884c);
            *(int32_t *)(arg1 + 0x8860) = *(int32_t *)(arg1 + 0x8860) + *(int32_t *)(arg1 + 0x8844);
            iVar5 = *(int32_t *)(arg1 + 0x8860);
            while ((*(int32_t *)(arg1 + 0x8858) <= iVar5 && (iVar5 = *(int32_t *)(arg1 + 0x8840), 0 < iVar5))) {
                *(int32_t *)(arg1 + 0x8840) = iVar5 + -1;
                iVar5 = *(int32_t *)(arg1 + 0x8864) << ((uint8_t)iVar5 & 0x1f);
                *(int32_t *)(arg1 + 0x8844) = iVar5;
                iVar5 = *(int32_t *)(arg1 + 0x8850) + (iVar5 >> 1);
                *(int32_t *)(arg1 + 0x8860) = iVar5;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180073150
// Address: 0x180073150
// Size: 2591 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

int64_t fcn.180073150(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    char cVar1;
    char *pcVar2;
    bool bVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    uint8_t uVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    char *pcVar15;
    uint8_t *puVar16;
    uint8_t *puVar17;
    uint64_t uVar18;
    undefined uVar19;
    int64_t iVar20;
    int32_t *piVar21;
    uint32_t uVar22;
    uint32_t uVar23;
    uint32_t uVar24;
    uint64_t uVar25;
    uint32_t uVar26;
    uint32_t uVar27;
    uint32_t uVar28;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_44h;
    
    if (*(int64_t *)(arg2 + 8) == 0) {
        iVar4 = fcn.180072ed0(arg1, arg2);
        if (iVar4 == 0) {
            return 0;
        }
        iVar4 = *(int32_t *)arg2;
        if (iVar4 < 0) {
            return 0;
        }
        if ((iVar4 != 0) && ((int32_t)(0x7fffffff / (int64_t)iVar4) < 4)) {
            return 0;
        }
        if (iVar4 * 4 < 0) {
            return 0;
        }
        iVar5 = *(int32_t *)(arg2 + 4);
        if (iVar5 < 0) {
            return 0;
        }
        if ((iVar5 != 0) && ((int32_t)(0x7fffffff / (int64_t)iVar5) < iVar4 * 4)) {
            return 0;
        }
        iVar4 = iVar4 * iVar5;
        iVar20 = (int64_t)(iVar4 * 4);
        uVar9 = func_0x00018046d050(iVar20);
        *(undefined8 *)(arg2 + 8) = uVar9;
        uVar9 = func_0x00018046d050(iVar20);
        *(undefined8 *)(arg2 + 0x10) = uVar9;
        iVar10 = func_0x00018046d050((int64_t)iVar4);
        *(int64_t *)(arg2 + 0x18) = iVar10;
        if (*(int64_t *)(arg2 + 8) == 0) {
            return 0;
        }
        if (*(int64_t *)(arg2 + 0x10) == 0) {
            return 0;
        }
        if (iVar10 == 0) {
            return 0;
        }
        func_0x0001804986e0(*(int64_t *)(arg2 + 8), 0, iVar20);
        func_0x0001804986e0(*(undefined8 *)(arg2 + 0x10), 0, iVar20);
        func_0x0001804986e0(*(undefined8 *)(arg2 + 0x18), 0, (int64_t)iVar4);
        bVar3 = true;
    } else {
        uVar11 = (uint8_t)*(undefined4 *)(arg2 + 0x30);
        bVar3 = false;
        if (((uVar11 & 0x1c) == 0xc) || ((uVar11 & 0x1c) == 8)) {
            uVar18 = 0;
            iVar4 = *(int32_t *)arg2 * *(int32_t *)(arg2 + 4);
            if (0 < iVar4) {
                do {
                    if (*(char *)(uVar18 + *(int64_t *)(arg2 + 0x18)) != '\0') {
                        iVar10 = (int64_t)((int32_t)uVar18 * 4);
                        *(undefined4 *)(iVar10 + *(int64_t *)(arg2 + 8)) =
                             *(undefined4 *)(iVar10 + *(int64_t *)(arg2 + 0x10));
                    }
                    uVar24 = (int32_t)uVar18 + 1;
                    uVar18 = (uint64_t)uVar24;
                } while ((int32_t)uVar24 < iVar4);
            }
        }
        func_0x000180498030(*(undefined8 *)(arg2 + 0x10), *(undefined8 *)(arg2 + 8), 
                            (int64_t)(*(int32_t *)(arg2 + 4) * *(int32_t *)arg2 * 4));
    }
    func_0x0001804986e0(*(undefined8 *)(arg2 + 0x18), 0, (int64_t)(*(int32_t *)arg2 * *(int32_t *)(arg2 + 4)));
code_r0x000180073300:
    pcVar2 = *(char **)(arg1 + 0xc0);
    if (pcVar2 < *(char **)(arg1 + 200)) {
        cVar1 = *pcVar2;
    } else {
        if (*(int32_t *)(arg1 + 0x30) == 0) {
            return 0;
        }
        func_0x000180069750(arg1);
        pcVar2 = *(char **)(arg1 + 0xc0);
        cVar1 = *pcVar2;
    }
    piVar21 = (int32_t *)(arg1 + 0x30);
    pcVar15 = pcVar2 + 1;
    *(char **)(arg1 + 0xc0) = pcVar15;
    if (cVar1 == '!') {
        if (pcVar15 < *(char **)(arg1 + 200)) {
            cVar1 = *pcVar15;
            puVar16 = (uint8_t *)(pcVar2 + 2);
        } else {
            if (*piVar21 == 0) goto code_r0x000180073490;
            func_0x000180069750(arg1);
            cVar1 = **(char **)(arg1 + 0xc0);
            puVar16 = (uint8_t *)(*(char **)(arg1 + 0xc0) + 1);
        }
        *(uint8_t **)(arg1 + 0xc0) = puVar16;
        if (cVar1 != -7) goto code_r0x000180073490;
        if (*(uint8_t **)(arg1 + 200) <= puVar16) goto code_r0x0001800733a0;
        uVar11 = *puVar16;
        goto code_r0x0001800733bf;
    }
    if (cVar1 == ',') {
        iVar5 = func_0x000180069a30(arg1);
        iVar6 = func_0x000180069a30(arg1);
        iVar7 = func_0x000180069a30(arg1);
        iVar8 = func_0x000180069a30(arg1);
        iVar4 = *(int32_t *)arg2;
        if (iVar4 < iVar7 + iVar5) {
            return 0;
        }
        if (*(int32_t *)(arg2 + 4) < iVar8 + iVar6) {
            return 0;
        }
        *(int32_t *)(arg2 + 0x8864) = iVar4 * 4;
        *(int32_t *)(arg2 + 0x884c) = iVar5 * 4;
        *(int32_t *)(arg2 + 0x8854) = (iVar7 + iVar5) * 4;
        iVar8 = (iVar8 + iVar6) * iVar4 * 4;
        *(int32_t *)(arg2 + 0x8858) = iVar8;
        *(int32_t *)(arg2 + 0x885c) = iVar5 * 4;
        iVar4 = iVar4 * iVar6 * 4;
        *(int32_t *)(arg2 + 0x8850) = iVar4;
        *(int32_t *)(arg2 + 0x8860) = iVar4;
        if (iVar7 == 0) {
            *(int32_t *)(arg2 + 0x8860) = iVar8;
        }
        puVar16 = *(uint8_t **)(arg1 + 0xc0);
        if (puVar16 < *(uint8_t **)(arg1 + 200)) {
            uVar24 = (uint32_t)*puVar16;
            *(uint8_t **)(arg1 + 0xc0) = puVar16 + 1;
        } else if (*piVar21 == 0) {
            uVar24 = 0;
        } else {
            func_0x000180069750(arg1);
            uVar24 = (uint32_t)**(uint8_t **)(arg1 + 0xc0);
            *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
        }
        *(uint32_t *)(arg2 + 0x8848) = uVar24;
        iVar4 = *(int32_t *)(arg2 + 0x8864) * 8;
        if ((uVar24 & 0x40) == 0) {
            iVar4 = *(int32_t *)(arg2 + 0x8864);
        }
        *(int32_t *)(arg2 + 0x8844) = iVar4;
        *(uint32_t *)(arg2 + 0x8840) = -(uint32_t)((uVar24 & 0x40) != 0) & 3;
        if ((char)uVar24 < '\0') {
            iVar10 = arg2 + 0x434;
            func_0x000180072d90();
        } else {
            if ((*(uint8_t *)(arg2 + 0x20) & 0x80) == 0) {
                return 0;
            }
            iVar10 = arg2 + 0x34;
        }
        *(int64_t *)(arg2 + 0x8838) = iVar10;
        puVar16 = *(uint8_t **)(arg1 + 0xc0);
        if (*(uint8_t **)(arg1 + 200) <= puVar16) {
            if (*piVar21 == 0) {
                uVar11 = 0;
                goto code_r0x00018007379a;
            }
            func_0x000180069750(arg1);
            puVar16 = *(uint8_t **)(arg1 + 0xc0);
        }
        uVar11 = *puVar16;
        *(uint8_t **)(arg1 + 0xc0) = puVar16 + 1;
        if (uVar11 < 0xd) {
code_r0x00018007379a:
            uVar25 = 1;
            uVar24 = 0;
            var_10h._0_4_ = 1;
            var_18h = 0;
            var_20h._0_4_ = 0;
            uVar23 = 1 << (uVar11 & 0x1f);
            uVar18 = 0;
            if (0 < 1 << (uVar11 & 0x1f)) {
                do {
                    *(undefined2 *)(arg2 + 0x834 + uVar18 * 4) = 0xffff;
                    *(char *)(arg2 + 0x836 + uVar18 * 4) = (char)uVar18;
                    *(char *)(arg2 + 0x837 + uVar18 * 4) = (char)uVar18;
                    uVar13 = (int32_t)uVar18 + 1;
                    uVar18 = (uint64_t)uVar13;
                } while ((int32_t)uVar13 < (int32_t)uVar23);
            }
            uVar13 = 0;
            do {
                uVar28 = 0xffffffff;
                iVar4 = uVar11 + 1;
                uVar26 = (1 << ((uint8_t)(uVar11 + 1) & 0x1f)) - 1;
                uVar27 = uVar23 + 2;
                uVar22 = uVar24;
                while( true ) {
                    for (; (int32_t)var_20h < iVar4; var_20h._0_4_ = (int32_t)var_20h + 8) {
                        if (uVar13 == 0) {
                            puVar16 = *(uint8_t **)(arg1 + 0xc0);
                            if (*(uint8_t **)(arg1 + 200) <= puVar16) {
                                if (*piVar21 == 0) goto code_r0x000180073af8;
                                func_0x000180069750(arg1);
                                puVar16 = *(uint8_t **)(arg1 + 0xc0);
                                uVar22 = (uint32_t)var_18h;
                            }
                            uVar12 = *puVar16;
                            *(uint8_t **)(arg1 + 0xc0) = puVar16 + 1;
                            uVar13 = (uint32_t)uVar12;
                            if (uVar12 == 0) goto code_r0x000180073af8;
                        }
                        puVar16 = *(uint8_t **)(arg1 + 0xc0);
                        uVar13 = uVar13 - 1;
                        if (puVar16 < *(uint8_t **)(arg1 + 200)) {
                            uVar12 = *puVar16;
                            *(uint8_t **)(arg1 + 0xc0) = puVar16 + 1;
                        } else if (*piVar21 == 0) {
                            uVar12 = 0;
                        } else {
                            func_0x000180069750(arg1);
                            uVar12 = **(uint8_t **)(arg1 + 0xc0);
                            *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                            uVar22 = (uint32_t)var_18h;
                        }
                        uVar25 = (uint64_t)(uint32_t)var_10h;
                        uVar22 = uVar22 | (uint32_t)uVar12 << ((uint8_t)(int32_t)var_20h & 0x1f);
                        var_18h = (int64_t)uVar22;
                    }
                    var_20h._0_4_ = (int32_t)var_20h - iVar4;
                    uVar24 = (int32_t)uVar22 >> ((uint8_t)iVar4 & 0x1f);
                    uVar22 = uVar22 & uVar26;
                    var_18h = (int64_t)uVar24;
                    if (uVar22 == uVar23) break;
                    if (uVar22 == uVar23 + 1) {
                        if (uVar13 != 0) {
                            if ((int32_t)uVar13 < 0) {
                                *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                            } else if ((*(int64_t *)(arg1 + 0x10) == 0) ||
                                      (iVar4 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0),
                                      (int32_t)uVar13 <= iVar4)) {
                                *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + (int64_t)(int32_t)uVar13;
                            } else {
                                *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                                (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), uVar13 - iVar4);
                            }
                        }
                        goto code_r0x000180073a70;
                    }
                    if ((int32_t)uVar27 < (int32_t)uVar22) {
                        return 0;
                    }
                    if ((int32_t)uVar25 != 0) {
                        return 0;
                    }
                    if ((int32_t)uVar28 < 0) {
                        if (uVar22 == uVar27) {
                            return 0;
                        }
                    } else {
                        uVar14 = uVar27 + 1;
                        if (0x2000 < (int32_t)uVar14) {
                            return 0;
                        }
                        iVar10 = arg2 + (int64_t)(int32_t)uVar27 * 4;
                        *(int16_t *)(iVar10 + 0x834) = (int16_t)uVar28;
                        uVar19 = *(undefined *)(arg2 + 0x836 + (int64_t)(int32_t)uVar28 * 4);
                        *(undefined *)(iVar10 + 0x836) = uVar19;
                        if (uVar22 != uVar14) {
                            uVar19 = *(undefined *)(arg2 + 0x836 + (int64_t)(int32_t)uVar22 * 4);
                        }
                        *(undefined *)(iVar10 + 0x837) = uVar19;
                        uVar27 = uVar14;
                    }
                    uVar28 = uVar22;
                    fcn.180073030(arg2);
                    uVar22 = uVar24;
                    if (((uVar26 & uVar27) == 0) && ((int32_t)uVar27 < 0x1000)) {
                        iVar4 = iVar4 + 1;
                        uVar26 = (1 << ((uint8_t)iVar4 & 0x1f)) - 1;
                    }
                }
                uVar25 = 0;
                var_10h._0_4_ = 0;
            } while( true );
        }
    } else if (cVar1 == ';') {
        return arg1;
    }
    return 0;
code_r0x0001800733a0:
    if (*piVar21 != 0) {
        func_0x000180069750(arg1);
        puVar16 = *(uint8_t **)(arg1 + 0xc0);
        uVar11 = *puVar16;
code_r0x0001800733bf:
        puVar17 = puVar16 + 1;
        *(uint8_t **)(arg1 + 0xc0) = puVar17;
        if (uVar11 == 4) {
            if (puVar17 < *(uint8_t **)(arg1 + 200)) {
                uVar24 = (uint32_t)*puVar17;
                *(uint8_t **)(arg1 + 0xc0) = puVar16 + 2;
            } else if (*piVar21 == 0) {
                uVar24 = 0;
            } else {
                func_0x000180069750(arg1);
                uVar24 = (uint32_t)**(uint8_t **)(arg1 + 0xc0);
                *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
            }
            *(uint32_t *)(arg2 + 0x30) = uVar24;
            iVar4 = func_0x000180069a30(arg1);
            *(int32_t *)(arg2 + 0x8868) = iVar4 * 10;
            if (-1 < *(int32_t *)(arg2 + 0x2c)) {
                *(undefined *)(arg2 + 0x37 + (int64_t)*(int32_t *)(arg2 + 0x2c) * 4) = 0xff;
            }
            if ((*(uint8_t *)(arg2 + 0x30) & 1) == 0) {
                if ((*(int64_t *)(arg1 + 0x10) == 0) ||
                   (iVar4 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), 0 < iVar4)) {
                    *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 1;
                    *(undefined4 *)(arg2 + 0x2c) = 0xffffffff;
                } else {
                    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                    (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 1 - iVar4);
                    *(undefined4 *)(arg2 + 0x2c) = 0xffffffff;
                }
            } else {
                puVar16 = *(uint8_t **)(arg1 + 0xc0);
                if (puVar16 < *(uint8_t **)(arg1 + 200)) {
                    uVar11 = *puVar16;
                    *(uint8_t **)(arg1 + 0xc0) = puVar16 + 1;
                } else if (*piVar21 == 0) {
                    uVar11 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar11 = **(uint8_t **)(arg1 + 0xc0);
                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                }
                *(uint32_t *)(arg2 + 0x2c) = (uint32_t)uVar11;
                *(undefined *)(arg2 + 0x37 + (uint64_t)uVar11 * 4) = 0;
            }
code_r0x000180073490:
            puVar16 = *(uint8_t **)(arg1 + 0xc0);
            if (puVar16 < *(uint8_t **)(arg1 + 200)) {
                uVar11 = *puVar16;
            } else {
                if (*piVar21 == 0) goto code_r0x000180073300;
                func_0x000180069750(arg1);
                puVar16 = *(uint8_t **)(arg1 + 0xc0);
                uVar11 = *puVar16;
            }
            puVar16 = puVar16 + 1;
            *(uint8_t **)(arg1 + 0xc0) = puVar16;
            if (uVar11 == 0) goto code_r0x000180073300;
            if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x0001800735ba:
                *(uint8_t **)(arg1 + 0xc0) = puVar16 + uVar11;
            } else {
                iVar4 = *(int32_t *)(arg1 + 200) - (int32_t)puVar16;
                if ((int32_t)(uint32_t)uVar11 <= iVar4) goto code_r0x0001800735ba;
                *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), (uint32_t)uVar11 - iVar4);
            }
            goto code_r0x000180073490;
        }
        if (uVar11 != 0) {
            if (*(int64_t *)(arg1 + 0x10) != 0) {
                iVar4 = *(int32_t *)(arg1 + 200) - (int32_t)puVar17;
                if (iVar4 < (int32_t)(uint32_t)uVar11) {
                    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                    (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), (uint32_t)uVar11 - iVar4);
                    goto code_r0x000180073300;
                }
            }
            *(uint8_t **)(arg1 + 0xc0) = puVar17 + uVar11;
        }
    }
    goto code_r0x000180073300;
code_r0x000180073a70:
    puVar16 = *(uint8_t **)(arg1 + 0xc0);
    if (puVar16 < *(uint8_t **)(arg1 + 200)) {
        uVar11 = *puVar16;
    } else {
        if (*piVar21 == 0) {
code_r0x000180073af8:
            iVar10 = *(int64_t *)(arg2 + 8);
            if (iVar10 == 0) {
                return 0;
            }
            if (!bVar3) {
                return iVar10;
            }
            if (*(int32_t *)(arg2 + 0x24) < 1) {
                return iVar10;
            }
            uVar18 = 0;
            iVar4 = *(int32_t *)(arg2 + 4) * *(int32_t *)arg2;
            if (0 < iVar4) {
                do {
                    if (*(char *)(uVar18 + *(int64_t *)(arg2 + 0x18)) == '\0') {
                        *(undefined *)(arg2 + 0x37 + (int64_t)*(int32_t *)(arg2 + 0x24) * 4) = 0xff;
                        *(undefined4 *)((int64_t)((int32_t)uVar18 * 4) + *(int64_t *)(arg2 + 8)) =
                             *(undefined4 *)(arg2 + 0x34 + (int64_t)*(int32_t *)(arg2 + 0x24) * 4);
                    }
                    uVar24 = (int32_t)uVar18 + 1;
                    uVar18 = (uint64_t)uVar24;
                } while ((int32_t)uVar24 < iVar4);
                return iVar10;
            }
            return iVar10;
        }
        func_0x000180069750(arg1);
        puVar16 = *(uint8_t **)(arg1 + 0xc0);
        uVar11 = *puVar16;
    }
    puVar16 = puVar16 + 1;
    *(uint8_t **)(arg1 + 0xc0) = puVar16;
    if (uVar11 == 0) goto code_r0x000180073af8;
    if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x000180073ae6:
        *(uint8_t **)(arg1 + 0xc0) = puVar16 + uVar11;
    } else {
        iVar4 = *(int32_t *)(arg1 + 200) - (int32_t)puVar16;
        if ((int32_t)(uint32_t)uVar11 <= iVar4) goto code_r0x000180073ae6;
        *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
        (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), (uint32_t)uVar11 - iVar4);
    }
    goto code_r0x000180073a70;
}

// ============================================================
// Function: FUN_180073b70
// Address: 0x180073b70
// Size: 183 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_8888h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_88d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_88e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.180073b70(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined4 *in_RDX;
    undefined4 *in_R8;
    int64_t iVar3;
    int64_t in_R9;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180073b83;
    iVar1 = func_0x00018045a350();
    iVar1 = -iVar1;
    *(uint64_t *)(&stack0x00008888 + iVar1) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar1);
    iVar3 = 0x8870;
    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180073bb3;
    func_0x0001804986e0((int64_t)&var_18h + iVar1, 0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180073bc0;
    iVar2 = fcn.180073150(in_RCX, (int64_t)&var_18h + iVar1, iVar3, in_R9, *(int64_t *)((int64_t)aiStackX_8 + iVar1));
    iVar3 = 0;
    if (iVar2 != in_RCX) {
        iVar3 = iVar2;
    }
    if (iVar3 == 0) {
        if (*(int64_t *)((int64_t)&var_20h + iVar1) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180073bec;
            func_0x000180460d90();
        }
    } else {
        *in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar1);
        *in_R8 = *(undefined4 *)((int64_t)&var_18h + iVar1 + 4);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180073bf6;
    func_0x000180460d90(*(undefined8 *)((int64_t)&arg_30h + iVar1));
    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180073c00;
    func_0x000180460d90(*(undefined8 *)((int64_t)&arg_28h + iVar1));
    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180073c13;
    func_0x000180459870(*(uint64_t *)(&stack0x00008888 + iVar1) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180073c30
// Address: 0x180073c30
// Size: 179 bytes
// ============================================================
undefined8 fcn.180073c30(int64_t arg1, int64_t arg2)
{
    char cVar1;
    uint8_t *puVar2;
    uint32_t uVar3;
    int32_t iVar4;
    
    iVar4 = 0;
    cVar1 = *(char *)arg2;
    while( true ) {
        if (cVar1 == '\0') {
            *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
            *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
            return 1;
        }
        puVar2 = *(uint8_t **)(arg1 + 0xc0);
        if (puVar2 < *(uint8_t **)(arg1 + 200)) {
            uVar3 = (uint32_t)*puVar2;
            *(uint8_t **)(arg1 + 0xc0) = puVar2 + 1;
        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
            uVar3 = 0;
        } else {
            func_0x000180069750(arg1);
            uVar3 = (uint32_t)**(uint8_t **)(arg1 + 0xc0);
            *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
        }
        if (uVar3 != (int32_t)*(char *)(iVar4 + arg2)) break;
        iVar4 = iVar4 + 1;
        cVar1 = *(char *)(iVar4 + arg2);
    }
    return 0;
}

// ============================================================
// Function: FUN_180073cf0
// Address: 0x180073cf0
// Size: 102 bytes
// ============================================================
void fcn.180073cf0(int64_t arg1)
{
    int32_t iVar1;
    
    iVar1 = fcn.180073c30(arg1, 0x18063cc70);
    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
    *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
    if (iVar1 == 0) {
        fcn.180073c30(arg1, 0x18063ccc0);
        *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
        *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
    }
    return;
}

// ============================================================
// Function: FUN_180073d60
// Address: 0x180073d60
// Size: 327 bytes
// ============================================================
int64_t fcn.180073d60(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    char *pcVar3;
    int32_t iVar4;
    char cVar5;
    
    pcVar3 = *(char **)(arg1 + 0xc0);
    iVar4 = 0;
    if (*(char **)(arg1 + 200) <= pcVar3) {
        iVar1 = *(int32_t *)(arg1 + 0x30);
        iVar4 = 0;
        goto joined_r0x000180073d95;
    }
    cVar5 = *pcVar3;
    *(char **)(arg1 + 0xc0) = pcVar3 + 1;
code_r0x000180073db5:
    if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x000180073dd1:
        if (*(uint64_t *)(arg1 + 200) <= *(uint64_t *)(arg1 + 0xc0)) goto code_r0x000180073e71;
    } else {
        iVar1 = (**(code **)(arg1 + 0x20))(*(undefined8 *)(arg1 + 0x28));
        if (iVar1 != 0) {
            if (*(int32_t *)(arg1 + 0x30) != 0) goto code_r0x000180073dd1;
            goto code_r0x000180073e71;
        }
    }
    if (cVar5 == '\n') goto code_r0x000180073e71;
    iVar2 = (int64_t)iVar4;
    iVar4 = iVar4 + 1;
    *(char *)(iVar2 + arg2) = cVar5;
    if (iVar4 != 0x3ff) {
        pcVar3 = *(char **)(arg1 + 0xc0);
        if (pcVar3 < *(char **)(arg1 + 200)) {
            cVar5 = *pcVar3;
            *(char **)(arg1 + 0xc0) = pcVar3 + 1;
        } else {
            iVar1 = *(int32_t *)(arg1 + 0x30);
joined_r0x000180073d95:
            if (iVar1 == 0) {
                cVar5 = '\0';
            } else {
                func_0x000180069750(arg1);
                cVar5 = **(char **)(arg1 + 0xc0);
                *(char **)(arg1 + 0xc0) = *(char **)(arg1 + 0xc0) + 1;
            }
        }
        goto code_r0x000180073db5;
    }
code_r0x000180073e30:
    do {
        if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x000180073e48:
            if (*(uint64_t *)(arg1 + 200) <= *(uint64_t *)(arg1 + 0xc0)) goto code_r0x000180073e71;
code_r0x000180073e58:
            pcVar3 = *(char **)(arg1 + 0xc0);
        } else {
            iVar1 = (**(code **)(arg1 + 0x20))(*(undefined8 *)(arg1 + 0x28));
            if (iVar1 != 0) {
                if (*(int32_t *)(arg1 + 0x30) != 0) goto code_r0x000180073e48;
                goto code_r0x000180073e71;
            }
            pcVar3 = *(char **)(arg1 + 0xc0);
            if (*(char **)(arg1 + 200) <= pcVar3) {
                if (*(int32_t *)(arg1 + 0x30) != 0) {
                    func_0x000180069750(arg1);
                    goto code_r0x000180073e58;
                }
                goto code_r0x000180073e30;
            }
        }
        cVar5 = *pcVar3;
        *(char **)(arg1 + 0xc0) = pcVar3 + 1;
        if (cVar5 == '\n') {
code_r0x000180073e71:
            *(undefined *)(iVar4 + arg2) = 0;
            return arg2;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180073eb0
// Address: 0x180073eb0
// Size: 298 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180073eb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t unaff_RBX;
    double dVar2;
    float fVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = (int32_t)arg3;
    if (*(char *)(arg2 + 3) == '\0') {
        if (iVar1 != 1) {
            if (iVar1 != 2) {
                if (iVar1 != 3) {
                    if (iVar1 != 4) {
                        return;
                    }
                    *(undefined4 *)(arg1 + 0xc) = 0x3f800000;
                }
                *(undefined8 *)(arg1 + 4) = 0;
                *(undefined4 *)arg1 = 0;
                return;
            }
            *(undefined4 *)(arg1 + 4) = 0x3f800000;
        }
        *(undefined4 *)arg1 = 0;
    } else {
        dVar2 = (double)fcn.18046d9a0(unaff_RBX);
        fVar3 = (float)dVar2;
        if (iVar1 < 3) {
            *(float *)arg1 =
                 ((float)((uint32_t)*(uint8_t *)(arg2 + 1) + (uint32_t)*(uint8_t *)arg2 +
                         (uint32_t)*(uint8_t *)(arg2 + 2)) * fVar3) / 3.0;
            if (iVar1 == 2) {
                *(undefined4 *)(arg1 + 4) = 0x3f800000;
                return;
            }
        } else {
            *(float *)arg1 = (float)(uint32_t)*(uint8_t *)arg2 * fVar3;
            *(float *)(arg1 + 4) = (float)(uint32_t)*(uint8_t *)(arg2 + 1) * fVar3;
            *(float *)(arg1 + 8) = (float)(uint32_t)*(uint8_t *)(arg2 + 2) * fVar3;
            if (iVar1 == 4) {
                *(undefined4 *)(arg1 + 0xc) = 0x3f800000;
                return;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180073fe0
// Address: 0x180073fe0
// Size: 522 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_464h
// WARNING: [rz-ghidra] Detected overlap for variable var_466h
// WARNING: [rz-ghidra] Detected overlap for variable var_467h
// WARNING: [rz-ghidra] Detected overlap for variable var_465h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel

void fcn.180073fe0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    undefined *puVar2;
    bool bVar3;
    undefined uVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint8_t *puVar12;
    uint8_t *puVar13;
    char cVar14;
    int64_t iVar15;
    int32_t iVar16;
    char cVar17;
    uint32_t uVar18;
    char cVar19;
    uint8_t uVar20;
    char *pcVar21;
    int32_t iVar22;
    uint8_t uVar23;
    int64_t var_20h;
    undefined auStack_488 [32];
    int64_t var_468h;
    int64_t var_460h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_8h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_488;
    iVar10 = fcn.180073d60(arg1, (int64_t)&var_448h);
    iVar5 = func_0x000180498f10(iVar10, 0x18063ccb0);
    if (iVar5 != 0) {
        iVar11 = 0;
        do {
            iVar15 = iVar11 + 1;
            if (*(char *)(iVar10 + iVar11) != *(char *)(iVar11 + 0x18063cca8)) goto code_r0x00018007457f;
            iVar11 = iVar15;
        } while (iVar15 != 7);
    }
    var_458h = fcn.180073d60(arg1, (int64_t)&var_448h);
    if (*(char *)var_458h != '\0') {
        bVar3 = false;
        do {
            iVar5 = func_0x000180498f10(var_458h, 0x18063cc90);
            if (iVar5 == 0) {
                bVar3 = true;
            }
            var_458h = fcn.180073d60(arg1, (int64_t)&var_448h);
        } while (*(char *)var_458h != '\0');
        if (bVar3) {
            iVar10 = fcn.180073d60(arg1, (int64_t)&var_448h);
            var_458h = iVar10;
            iVar5 = func_0x000180498f90(iVar10, 0x18063cce4, 3);
            if (iVar5 == 0) {
                var_458h = iVar10 + 3;
                iVar5 = func_0x00018046c52c(var_458h, &var_458h, 10);
                cVar17 = *(char *)var_458h;
                pcVar21 = (char *)var_458h;
                while (cVar17 == ' ') {
                    pcVar21 = pcVar21 + 1;
                    cVar17 = *pcVar21;
                }
                var_460h._0_4_ = iVar5;
                var_458h = (int64_t)pcVar21;
                iVar6 = func_0x000180498f90(pcVar21, 0x18063cce0, 3);
                if (iVar6 == 0) {
                    var_458h = (int64_t)(pcVar21 + 3);
                    uVar7 = func_0x00018046c52c(var_458h);
                    var_468h._0_4_ = uVar7;
                    if ((iVar5 < 0x1000001) && ((int32_t)uVar7 < 0x1000001)) {
                        *(uint32_t *)arg2 = uVar7;
                        *(int32_t *)arg3 = iVar5;
                        if (((-1 < (int32_t)uVar7) && (-1 < iVar5)) &&
                           (((((iVar5 == 0 || ((int32_t)uVar7 <= (int32_t)(0x7fffffff / (int64_t)iVar5))) &&
                              (uVar7 * iVar5 < 0x20000000)) && (uVar7 * iVar5 * 4 < 0x20000000)) &&
                            (((iVar5 == 0 || ((int32_t)uVar7 <= (int32_t)(0x7fffffff / (int64_t)iVar5))) &&
                             (iVar10 = func_0x00018046d050(), var_450h = iVar10, iVar10 != 0)))))) {
                            if (0x7ff7 < uVar7 - 8) {
                                iVar6 = 0;
                                goto code_r0x000180074606;
                            }
                            iVar11 = 0;
                            var_468h._4_4_ = 0;
                            if (0 < iVar5) {
                                do {
                                    pcVar21 = *(char **)(arg1 + 0xc0);
                                    piVar1 = (int32_t *)(arg1 + 0x30);
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar17 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar17 = '\0';
                                    } else {
                                        func_0x000180069750();
                                        cVar17 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar19 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar19 = '\0';
                                    } else {
                                        func_0x000180069750();
                                        cVar19 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar14 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar14 = '\0';
                                    } else {
                                        func_0x000180069750(arg1);
                                        cVar14 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (((cVar17 != '\x02') || (cVar19 != '\x02')) || (cVar14 < '\0')) {
                                        var_468h._0_4_ =
                                             CONCAT22(CONCAT11(var_468h._3_1_, cVar14), CONCAT11(cVar19, cVar17));
                                        uVar4 = func_0x0001800697d0(arg1);
                                        var_468h._0_4_ = CONCAT13(uVar4, (unkbyte3)var_468h);
                                        fcn.180073eb0(iVar10, (int64_t)&var_468h, 4);
                                        iVar6 = 0;
                                        func_0x000180460d90(iVar11);
                                        iVar22 = 1;
                                        do {
                                            func_0x000180069890(arg1, &var_460h, 4);
                                            fcn.180073eb0(iVar10 + ((int64_t)(int32_t)(uVar7 * iVar6 * 4) +
                                                                   (int64_t)(iVar22 * 4)) * 4, (int64_t)&var_460h, 4);
                                            iVar22 = iVar22 + 1;
                                            while ((int32_t)uVar7 <= iVar22) {
                                                iVar6 = iVar6 + 1;
code_r0x000180074606:
                                                if (iVar5 <= iVar6) goto code_r0x00018007457f;
                                                iVar22 = 0;
                                            }
                                        } while( true );
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar17 = *pcVar21;
                                        *(char **)(arg1 + 0xc0) = pcVar21 + 1;
                                    } else if (*piVar1 == 0) {
                                        cVar17 = '\0';
                                    } else {
                                        func_0x000180069750(arg1);
                                        cVar17 = **(char **)(arg1 + 0xc0);
                                        *(char **)(arg1 + 0xc0) = *(char **)(arg1 + 0xc0) + 1;
                                    }
                                    if (CONCAT11(cVar14, cVar17) != uVar7) {
code_r0x0001800745b5:
                                        func_0x000180460d90(iVar10);
                                        func_0x000180460d90(iVar11);
                                        goto code_r0x00018007457f;
                                    }
                                    if ((iVar11 == 0) &&
                                       (iVar11 = func_0x00018046d050((int64_t)(int32_t)(uVar7 * 4)), iVar11 == 0)) {
                                        func_0x000180460d90(iVar10);
                                        goto code_r0x00018007457f;
                                    }
                                    iVar5 = 0;
                                    uVar8 = (uint32_t)var_468h;
                                    do {
                                        iVar6 = 0;
                                        uVar18 = uVar8;
                                        uVar7 = (uint32_t)var_468h;
                                        iVar10 = var_450h;
                                        while (var_468h._0_4_ = uVar7, var_450h = iVar10, 0 < (int32_t)uVar18) {
                                            puVar12 = *(uint8_t **)(arg1 + 0xc0);
                                            if (puVar12 < *(uint8_t **)(arg1 + 200)) {
code_r0x0001800743ba:
                                                uVar20 = *puVar12;
                                                puVar13 = puVar12 + 1;
                                                *(uint8_t **)(arg1 + 0xc0) = puVar13;
                                                if (uVar20 < 0x81) goto code_r0x000180074460;
                                                if (puVar13 < *(uint8_t **)(arg1 + 200)) {
                                                    uVar23 = *puVar13;
                                                    *(uint8_t **)(arg1 + 0xc0) = puVar12 + 2;
                                                } else if (*piVar1 == 0) {
                                                    uVar23 = 0;
                                                } else {
                                                    func_0x000180069750(arg1);
                                                    uVar23 = **(uint8_t **)(arg1 + 0xc0);
                                                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                                }
                                                uVar20 = uVar20 + 0x80;
                                                iVar10 = var_450h;
                                                if (uVar18 < uVar20) goto code_r0x0001800745b5;
                                                iVar22 = 0;
                                                if (uVar20 != 0) {
                                                    iVar16 = iVar6 * 4;
                                                    do {
                                                        iVar9 = iVar16 + iVar5;
                                                        iVar6 = iVar6 + 1;
                                                        iVar16 = iVar16 + 4;
                                                        iVar22 = iVar22 + 1;
                                                        *(uint8_t *)(iVar9 + iVar11) = uVar23;
                                                    } while (iVar22 < (int32_t)(uint32_t)uVar20);
                                                }
                                            } else {
                                                if (*piVar1 != 0) {
                                                    func_0x000180069750(arg1);
                                                    puVar12 = *(uint8_t **)(arg1 + 0xc0);
                                                    goto code_r0x0001800743ba;
                                                }
                                                uVar20 = 0;
code_r0x000180074460:
                                                iVar10 = var_450h;
                                                if (uVar18 < uVar20) goto code_r0x0001800745b5;
                                                iVar22 = 0;
                                                if (uVar20 != 0) {
                                                    iVar16 = iVar6 * 4;
                                                    do {
                                                        puVar2 = *(undefined **)(arg1 + 0xc0);
                                                        if (puVar2 < *(undefined **)(arg1 + 200)) {
                                                            uVar4 = *puVar2;
                                                            *(undefined **)(arg1 + 0xc0) = puVar2 + 1;
                                                        } else if (*piVar1 == 0) {
                                                            uVar4 = 0;
                                                        } else {
                                                            func_0x000180069750(arg1);
                                                            uVar4 = **(undefined **)(arg1 + 0xc0);
                                                            *(undefined **)(arg1 + 0xc0) =
                                                                 *(undefined **)(arg1 + 0xc0) + 1;
                                                        }
                                                        iVar9 = iVar16 + iVar5;
                                                        iVar6 = iVar6 + 1;
                                                        iVar22 = iVar22 + 1;
                                                        iVar16 = iVar16 + 4;
                                                        *(undefined *)(iVar9 + iVar11) = uVar4;
                                                    } while (iVar22 < (int32_t)(uint32_t)uVar20);
                                                }
                                            }
                                            uVar8 = (uint32_t)var_468h;
                                            uVar7 = (uint32_t)var_468h;
                                            iVar10 = var_450h;
                                            uVar18 = (uint32_t)var_468h - iVar6;
                                        }
                                        iVar5 = iVar5 + 1;
                                    } while (iVar5 < 4);
                                    iVar5 = 0;
                                    if (0 < (int32_t)uVar7) {
                                        iVar6 = var_468h._4_4_ * uVar7;
                                        do {
                                            fcn.180073eb0(iVar10 + (int64_t)(iVar5 * 4 + iVar6 * 4) * 4, 
                                                          iVar5 * 4 + iVar11, 4);
                                            iVar5 = iVar5 + 1;
                                        } while (iVar5 < (int32_t)uVar7);
                                    }
                                    var_468h._4_4_ = var_468h._4_4_ + 1;
                                    iVar5 = (int32_t)var_460h;
                                } while (var_468h._4_4_ < (int32_t)var_460h);
                                if (iVar11 != 0) {
                                    func_0x000180460d90(iVar11);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x00018007457f:
    func_0x000180459870(var_48h ^ (uint64_t)auStack_488);
    return;
}

// ============================================================
// Function: FUN_1800741ea
// Address: 0x1800741ea
// Size: 917 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_464h
// WARNING: [rz-ghidra] Detected overlap for variable var_466h
// WARNING: [rz-ghidra] Detected overlap for variable var_467h
// WARNING: [rz-ghidra] Detected overlap for variable var_465h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel

void fcn.180073fe0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    undefined *puVar2;
    bool bVar3;
    undefined uVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint8_t *puVar12;
    uint8_t *puVar13;
    char cVar14;
    int64_t iVar15;
    int32_t iVar16;
    char cVar17;
    uint32_t uVar18;
    char cVar19;
    uint8_t uVar20;
    char *pcVar21;
    int32_t iVar22;
    uint8_t uVar23;
    int64_t var_20h;
    undefined auStack_488 [32];
    int64_t var_468h;
    int64_t var_460h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_8h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_488;
    iVar10 = fcn.180073d60(arg1, (int64_t)&var_448h);
    iVar5 = func_0x000180498f10(iVar10, 0x18063ccb0);
    if (iVar5 != 0) {
        iVar11 = 0;
        do {
            iVar15 = iVar11 + 1;
            if (*(char *)(iVar10 + iVar11) != *(char *)(iVar11 + 0x18063cca8)) goto code_r0x00018007457f;
            iVar11 = iVar15;
        } while (iVar15 != 7);
    }
    var_458h = fcn.180073d60(arg1, (int64_t)&var_448h);
    if (*(char *)var_458h != '\0') {
        bVar3 = false;
        do {
            iVar5 = func_0x000180498f10(var_458h, 0x18063cc90);
            if (iVar5 == 0) {
                bVar3 = true;
            }
            var_458h = fcn.180073d60(arg1, (int64_t)&var_448h);
        } while (*(char *)var_458h != '\0');
        if (bVar3) {
            iVar10 = fcn.180073d60(arg1, (int64_t)&var_448h);
            var_458h = iVar10;
            iVar5 = func_0x000180498f90(iVar10, 0x18063cce4, 3);
            if (iVar5 == 0) {
                var_458h = iVar10 + 3;
                iVar5 = func_0x00018046c52c(var_458h, &var_458h, 10);
                cVar17 = *(char *)var_458h;
                pcVar21 = (char *)var_458h;
                while (cVar17 == ' ') {
                    pcVar21 = pcVar21 + 1;
                    cVar17 = *pcVar21;
                }
                var_460h._0_4_ = iVar5;
                var_458h = (int64_t)pcVar21;
                iVar6 = func_0x000180498f90(pcVar21, 0x18063cce0, 3);
                if (iVar6 == 0) {
                    var_458h = (int64_t)(pcVar21 + 3);
                    uVar7 = func_0x00018046c52c(var_458h);
                    var_468h._0_4_ = uVar7;
                    if ((iVar5 < 0x1000001) && ((int32_t)uVar7 < 0x1000001)) {
                        *(uint32_t *)arg2 = uVar7;
                        *(int32_t *)arg3 = iVar5;
                        if (((-1 < (int32_t)uVar7) && (-1 < iVar5)) &&
                           (((((iVar5 == 0 || ((int32_t)uVar7 <= (int32_t)(0x7fffffff / (int64_t)iVar5))) &&
                              (uVar7 * iVar5 < 0x20000000)) && (uVar7 * iVar5 * 4 < 0x20000000)) &&
                            (((iVar5 == 0 || ((int32_t)uVar7 <= (int32_t)(0x7fffffff / (int64_t)iVar5))) &&
                             (iVar10 = func_0x00018046d050(), var_450h = iVar10, iVar10 != 0)))))) {
                            if (0x7ff7 < uVar7 - 8) {
                                iVar6 = 0;
                                goto code_r0x000180074606;
                            }
                            iVar11 = 0;
                            var_468h._4_4_ = 0;
                            if (0 < iVar5) {
                                do {
                                    pcVar21 = *(char **)(arg1 + 0xc0);
                                    piVar1 = (int32_t *)(arg1 + 0x30);
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar17 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar17 = '\0';
                                    } else {
                                        func_0x000180069750();
                                        cVar17 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar19 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar19 = '\0';
                                    } else {
                                        func_0x000180069750();
                                        cVar19 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar14 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar14 = '\0';
                                    } else {
                                        func_0x000180069750(arg1);
                                        cVar14 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (((cVar17 != '\x02') || (cVar19 != '\x02')) || (cVar14 < '\0')) {
                                        var_468h._0_4_ =
                                             CONCAT22(CONCAT11(var_468h._3_1_, cVar14), CONCAT11(cVar19, cVar17));
                                        uVar4 = func_0x0001800697d0(arg1);
                                        var_468h._0_4_ = CONCAT13(uVar4, (unkbyte3)var_468h);
                                        fcn.180073eb0(iVar10, (int64_t)&var_468h, 4);
                                        iVar6 = 0;
                                        func_0x000180460d90(iVar11);
                                        iVar22 = 1;
                                        do {
                                            func_0x000180069890(arg1, &var_460h, 4);
                                            fcn.180073eb0(iVar10 + ((int64_t)(int32_t)(uVar7 * iVar6 * 4) +
                                                                   (int64_t)(iVar22 * 4)) * 4, (int64_t)&var_460h, 4);
                                            iVar22 = iVar22 + 1;
                                            while ((int32_t)uVar7 <= iVar22) {
                                                iVar6 = iVar6 + 1;
code_r0x000180074606:
                                                if (iVar5 <= iVar6) goto code_r0x00018007457f;
                                                iVar22 = 0;
                                            }
                                        } while( true );
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar17 = *pcVar21;
                                        *(char **)(arg1 + 0xc0) = pcVar21 + 1;
                                    } else if (*piVar1 == 0) {
                                        cVar17 = '\0';
                                    } else {
                                        func_0x000180069750(arg1);
                                        cVar17 = **(char **)(arg1 + 0xc0);
                                        *(char **)(arg1 + 0xc0) = *(char **)(arg1 + 0xc0) + 1;
                                    }
                                    if (CONCAT11(cVar14, cVar17) != uVar7) {
code_r0x0001800745b5:
                                        func_0x000180460d90(iVar10);
                                        func_0x000180460d90(iVar11);
                                        goto code_r0x00018007457f;
                                    }
                                    if ((iVar11 == 0) &&
                                       (iVar11 = func_0x00018046d050((int64_t)(int32_t)(uVar7 * 4)), iVar11 == 0)) {
                                        func_0x000180460d90(iVar10);
                                        goto code_r0x00018007457f;
                                    }
                                    iVar5 = 0;
                                    uVar8 = (uint32_t)var_468h;
                                    do {
                                        iVar6 = 0;
                                        uVar18 = uVar8;
                                        uVar7 = (uint32_t)var_468h;
                                        iVar10 = var_450h;
                                        while (var_468h._0_4_ = uVar7, var_450h = iVar10, 0 < (int32_t)uVar18) {
                                            puVar12 = *(uint8_t **)(arg1 + 0xc0);
                                            if (puVar12 < *(uint8_t **)(arg1 + 200)) {
code_r0x0001800743ba:
                                                uVar20 = *puVar12;
                                                puVar13 = puVar12 + 1;
                                                *(uint8_t **)(arg1 + 0xc0) = puVar13;
                                                if (uVar20 < 0x81) goto code_r0x000180074460;
                                                if (puVar13 < *(uint8_t **)(arg1 + 200)) {
                                                    uVar23 = *puVar13;
                                                    *(uint8_t **)(arg1 + 0xc0) = puVar12 + 2;
                                                } else if (*piVar1 == 0) {
                                                    uVar23 = 0;
                                                } else {
                                                    func_0x000180069750(arg1);
                                                    uVar23 = **(uint8_t **)(arg1 + 0xc0);
                                                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                                }
                                                uVar20 = uVar20 + 0x80;
                                                iVar10 = var_450h;
                                                if (uVar18 < uVar20) goto code_r0x0001800745b5;
                                                iVar22 = 0;
                                                if (uVar20 != 0) {
                                                    iVar16 = iVar6 * 4;
                                                    do {
                                                        iVar9 = iVar16 + iVar5;
                                                        iVar6 = iVar6 + 1;
                                                        iVar16 = iVar16 + 4;
                                                        iVar22 = iVar22 + 1;
                                                        *(uint8_t *)(iVar9 + iVar11) = uVar23;
                                                    } while (iVar22 < (int32_t)(uint32_t)uVar20);
                                                }
                                            } else {
                                                if (*piVar1 != 0) {
                                                    func_0x000180069750(arg1);
                                                    puVar12 = *(uint8_t **)(arg1 + 0xc0);
                                                    goto code_r0x0001800743ba;
                                                }
                                                uVar20 = 0;
code_r0x000180074460:
                                                iVar10 = var_450h;
                                                if (uVar18 < uVar20) goto code_r0x0001800745b5;
                                                iVar22 = 0;
                                                if (uVar20 != 0) {
                                                    iVar16 = iVar6 * 4;
                                                    do {
                                                        puVar2 = *(undefined **)(arg1 + 0xc0);
                                                        if (puVar2 < *(undefined **)(arg1 + 200)) {
                                                            uVar4 = *puVar2;
                                                            *(undefined **)(arg1 + 0xc0) = puVar2 + 1;
                                                        } else if (*piVar1 == 0) {
                                                            uVar4 = 0;
                                                        } else {
                                                            func_0x000180069750(arg1);
                                                            uVar4 = **(undefined **)(arg1 + 0xc0);
                                                            *(undefined **)(arg1 + 0xc0) =
                                                                 *(undefined **)(arg1 + 0xc0) + 1;
                                                        }
                                                        iVar9 = iVar16 + iVar5;
                                                        iVar6 = iVar6 + 1;
                                                        iVar22 = iVar22 + 1;
                                                        iVar16 = iVar16 + 4;
                                                        *(undefined *)(iVar9 + iVar11) = uVar4;
                                                    } while (iVar22 < (int32_t)(uint32_t)uVar20);
                                                }
                                            }
                                            uVar8 = (uint32_t)var_468h;
                                            uVar7 = (uint32_t)var_468h;
                                            iVar10 = var_450h;
                                            uVar18 = (uint32_t)var_468h - iVar6;
                                        }
                                        iVar5 = iVar5 + 1;
                                    } while (iVar5 < 4);
                                    iVar5 = 0;
                                    if (0 < (int32_t)uVar7) {
                                        iVar6 = var_468h._4_4_ * uVar7;
                                        do {
                                            fcn.180073eb0(iVar10 + (int64_t)(iVar5 * 4 + iVar6 * 4) * 4, 
                                                          iVar5 * 4 + iVar11, 4);
                                            iVar5 = iVar5 + 1;
                                        } while (iVar5 < (int32_t)uVar7);
                                    }
                                    var_468h._4_4_ = var_468h._4_4_ + 1;
                                    iVar5 = (int32_t)var_460h;
                                } while (var_468h._4_4_ < (int32_t)var_460h);
                                if (iVar11 != 0) {
                                    func_0x000180460d90(iVar11);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x00018007457f:
    func_0x000180459870(var_48h ^ (uint64_t)auStack_488);
    return;
}

// ============================================================
// Function: FUN_18007457f
// Address: 0x18007457f
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_464h
// WARNING: [rz-ghidra] Detected overlap for variable var_466h
// WARNING: [rz-ghidra] Detected overlap for variable var_467h
// WARNING: [rz-ghidra] Detected overlap for variable var_465h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel

void fcn.180073fe0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    undefined *puVar2;
    bool bVar3;
    undefined uVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint8_t *puVar12;
    uint8_t *puVar13;
    char cVar14;
    int64_t iVar15;
    int32_t iVar16;
    char cVar17;
    uint32_t uVar18;
    char cVar19;
    uint8_t uVar20;
    char *pcVar21;
    int32_t iVar22;
    uint8_t uVar23;
    int64_t var_20h;
    undefined auStack_488 [32];
    int64_t var_468h;
    int64_t var_460h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_8h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_488;
    iVar10 = fcn.180073d60(arg1, (int64_t)&var_448h);
    iVar5 = func_0x000180498f10(iVar10, 0x18063ccb0);
    if (iVar5 != 0) {
        iVar11 = 0;
        do {
            iVar15 = iVar11 + 1;
            if (*(char *)(iVar10 + iVar11) != *(char *)(iVar11 + 0x18063cca8)) goto code_r0x00018007457f;
            iVar11 = iVar15;
        } while (iVar15 != 7);
    }
    var_458h = fcn.180073d60(arg1, (int64_t)&var_448h);
    if (*(char *)var_458h != '\0') {
        bVar3 = false;
        do {
            iVar5 = func_0x000180498f10(var_458h, 0x18063cc90);
            if (iVar5 == 0) {
                bVar3 = true;
            }
            var_458h = fcn.180073d60(arg1, (int64_t)&var_448h);
        } while (*(char *)var_458h != '\0');
        if (bVar3) {
            iVar10 = fcn.180073d60(arg1, (int64_t)&var_448h);
            var_458h = iVar10;
            iVar5 = func_0x000180498f90(iVar10, 0x18063cce4, 3);
            if (iVar5 == 0) {
                var_458h = iVar10 + 3;
                iVar5 = func_0x00018046c52c(var_458h, &var_458h, 10);
                cVar17 = *(char *)var_458h;
                pcVar21 = (char *)var_458h;
                while (cVar17 == ' ') {
                    pcVar21 = pcVar21 + 1;
                    cVar17 = *pcVar21;
                }
                var_460h._0_4_ = iVar5;
                var_458h = (int64_t)pcVar21;
                iVar6 = func_0x000180498f90(pcVar21, 0x18063cce0, 3);
                if (iVar6 == 0) {
                    var_458h = (int64_t)(pcVar21 + 3);
                    uVar7 = func_0x00018046c52c(var_458h);
                    var_468h._0_4_ = uVar7;
                    if ((iVar5 < 0x1000001) && ((int32_t)uVar7 < 0x1000001)) {
                        *(uint32_t *)arg2 = uVar7;
                        *(int32_t *)arg3 = iVar5;
                        if (((-1 < (int32_t)uVar7) && (-1 < iVar5)) &&
                           (((((iVar5 == 0 || ((int32_t)uVar7 <= (int32_t)(0x7fffffff / (int64_t)iVar5))) &&
                              (uVar7 * iVar5 < 0x20000000)) && (uVar7 * iVar5 * 4 < 0x20000000)) &&
                            (((iVar5 == 0 || ((int32_t)uVar7 <= (int32_t)(0x7fffffff / (int64_t)iVar5))) &&
                             (iVar10 = func_0x00018046d050(), var_450h = iVar10, iVar10 != 0)))))) {
                            if (0x7ff7 < uVar7 - 8) {
                                iVar6 = 0;
                                goto code_r0x000180074606;
                            }
                            iVar11 = 0;
                            var_468h._4_4_ = 0;
                            if (0 < iVar5) {
                                do {
                                    pcVar21 = *(char **)(arg1 + 0xc0);
                                    piVar1 = (int32_t *)(arg1 + 0x30);
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar17 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar17 = '\0';
                                    } else {
                                        func_0x000180069750();
                                        cVar17 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar19 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar19 = '\0';
                                    } else {
                                        func_0x000180069750();
                                        cVar19 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar14 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar14 = '\0';
                                    } else {
                                        func_0x000180069750(arg1);
                                        cVar14 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (((cVar17 != '\x02') || (cVar19 != '\x02')) || (cVar14 < '\0')) {
                                        var_468h._0_4_ =
                                             CONCAT22(CONCAT11(var_468h._3_1_, cVar14), CONCAT11(cVar19, cVar17));
                                        uVar4 = func_0x0001800697d0(arg1);
                                        var_468h._0_4_ = CONCAT13(uVar4, (unkbyte3)var_468h);
                                        fcn.180073eb0(iVar10, (int64_t)&var_468h, 4);
                                        iVar6 = 0;
                                        func_0x000180460d90(iVar11);
                                        iVar22 = 1;
                                        do {
                                            func_0x000180069890(arg1, &var_460h, 4);
                                            fcn.180073eb0(iVar10 + ((int64_t)(int32_t)(uVar7 * iVar6 * 4) +
                                                                   (int64_t)(iVar22 * 4)) * 4, (int64_t)&var_460h, 4);
                                            iVar22 = iVar22 + 1;
                                            while ((int32_t)uVar7 <= iVar22) {
                                                iVar6 = iVar6 + 1;
code_r0x000180074606:
                                                if (iVar5 <= iVar6) goto code_r0x00018007457f;
                                                iVar22 = 0;
                                            }
                                        } while( true );
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar17 = *pcVar21;
                                        *(char **)(arg1 + 0xc0) = pcVar21 + 1;
                                    } else if (*piVar1 == 0) {
                                        cVar17 = '\0';
                                    } else {
                                        func_0x000180069750(arg1);
                                        cVar17 = **(char **)(arg1 + 0xc0);
                                        *(char **)(arg1 + 0xc0) = *(char **)(arg1 + 0xc0) + 1;
                                    }
                                    if (CONCAT11(cVar14, cVar17) != uVar7) {
code_r0x0001800745b5:
                                        func_0x000180460d90(iVar10);
                                        func_0x000180460d90(iVar11);
                                        goto code_r0x00018007457f;
                                    }
                                    if ((iVar11 == 0) &&
                                       (iVar11 = func_0x00018046d050((int64_t)(int32_t)(uVar7 * 4)), iVar11 == 0)) {
                                        func_0x000180460d90(iVar10);
                                        goto code_r0x00018007457f;
                                    }
                                    iVar5 = 0;
                                    uVar8 = (uint32_t)var_468h;
                                    do {
                                        iVar6 = 0;
                                        uVar18 = uVar8;
                                        uVar7 = (uint32_t)var_468h;
                                        iVar10 = var_450h;
                                        while (var_468h._0_4_ = uVar7, var_450h = iVar10, 0 < (int32_t)uVar18) {
                                            puVar12 = *(uint8_t **)(arg1 + 0xc0);
                                            if (puVar12 < *(uint8_t **)(arg1 + 200)) {
code_r0x0001800743ba:
                                                uVar20 = *puVar12;
                                                puVar13 = puVar12 + 1;
                                                *(uint8_t **)(arg1 + 0xc0) = puVar13;
                                                if (uVar20 < 0x81) goto code_r0x000180074460;
                                                if (puVar13 < *(uint8_t **)(arg1 + 200)) {
                                                    uVar23 = *puVar13;
                                                    *(uint8_t **)(arg1 + 0xc0) = puVar12 + 2;
                                                } else if (*piVar1 == 0) {
                                                    uVar23 = 0;
                                                } else {
                                                    func_0x000180069750(arg1);
                                                    uVar23 = **(uint8_t **)(arg1 + 0xc0);
                                                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                                }
                                                uVar20 = uVar20 + 0x80;
                                                iVar10 = var_450h;
                                                if (uVar18 < uVar20) goto code_r0x0001800745b5;
                                                iVar22 = 0;
                                                if (uVar20 != 0) {
                                                    iVar16 = iVar6 * 4;
                                                    do {
                                                        iVar9 = iVar16 + iVar5;
                                                        iVar6 = iVar6 + 1;
                                                        iVar16 = iVar16 + 4;
                                                        iVar22 = iVar22 + 1;
                                                        *(uint8_t *)(iVar9 + iVar11) = uVar23;
                                                    } while (iVar22 < (int32_t)(uint32_t)uVar20);
                                                }
                                            } else {
                                                if (*piVar1 != 0) {
                                                    func_0x000180069750(arg1);
                                                    puVar12 = *(uint8_t **)(arg1 + 0xc0);
                                                    goto code_r0x0001800743ba;
                                                }
                                                uVar20 = 0;
code_r0x000180074460:
                                                iVar10 = var_450h;
                                                if (uVar18 < uVar20) goto code_r0x0001800745b5;
                                                iVar22 = 0;
                                                if (uVar20 != 0) {
                                                    iVar16 = iVar6 * 4;
                                                    do {
                                                        puVar2 = *(undefined **)(arg1 + 0xc0);
                                                        if (puVar2 < *(undefined **)(arg1 + 200)) {
                                                            uVar4 = *puVar2;
                                                            *(undefined **)(arg1 + 0xc0) = puVar2 + 1;
                                                        } else if (*piVar1 == 0) {
                                                            uVar4 = 0;
                                                        } else {
                                                            func_0x000180069750(arg1);
                                                            uVar4 = **(undefined **)(arg1 + 0xc0);
                                                            *(undefined **)(arg1 + 0xc0) =
                                                                 *(undefined **)(arg1 + 0xc0) + 1;
                                                        }
                                                        iVar9 = iVar16 + iVar5;
                                                        iVar6 = iVar6 + 1;
                                                        iVar22 = iVar22 + 1;
                                                        iVar16 = iVar16 + 4;
                                                        *(undefined *)(iVar9 + iVar11) = uVar4;
                                                    } while (iVar22 < (int32_t)(uint32_t)uVar20);
                                                }
                                            }
                                            uVar8 = (uint32_t)var_468h;
                                            uVar7 = (uint32_t)var_468h;
                                            iVar10 = var_450h;
                                            uVar18 = (uint32_t)var_468h - iVar6;
                                        }
                                        iVar5 = iVar5 + 1;
                                    } while (iVar5 < 4);
                                    iVar5 = 0;
                                    if (0 < (int32_t)uVar7) {
                                        iVar6 = var_468h._4_4_ * uVar7;
                                        do {
                                            fcn.180073eb0(iVar10 + (int64_t)(iVar5 * 4 + iVar6 * 4) * 4, 
                                                          iVar5 * 4 + iVar11, 4);
                                            iVar5 = iVar5 + 1;
                                        } while (iVar5 < (int32_t)uVar7);
                                    }
                                    var_468h._4_4_ = var_468h._4_4_ + 1;
                                    iVar5 = (int32_t)var_460h;
                                } while (var_468h._4_4_ < (int32_t)var_460h);
                                if (iVar11 != 0) {
                                    func_0x000180460d90(iVar11);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x00018007457f:
    func_0x000180459870(var_48h ^ (uint64_t)auStack_488);
    return;
}

// ============================================================
// Function: FUN_18007459f
// Address: 0x18007459f
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_464h
// WARNING: [rz-ghidra] Detected overlap for variable var_466h
// WARNING: [rz-ghidra] Detected overlap for variable var_467h
// WARNING: [rz-ghidra] Detected overlap for variable var_465h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel

void fcn.180073fe0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    undefined *puVar2;
    bool bVar3;
    undefined uVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint8_t *puVar12;
    uint8_t *puVar13;
    char cVar14;
    int64_t iVar15;
    int32_t iVar16;
    char cVar17;
    uint32_t uVar18;
    char cVar19;
    uint8_t uVar20;
    char *pcVar21;
    int32_t iVar22;
    uint8_t uVar23;
    int64_t var_20h;
    undefined auStack_488 [32];
    int64_t var_468h;
    int64_t var_460h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_8h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_488;
    iVar10 = fcn.180073d60(arg1, (int64_t)&var_448h);
    iVar5 = func_0x000180498f10(iVar10, 0x18063ccb0);
    if (iVar5 != 0) {
        iVar11 = 0;
        do {
            iVar15 = iVar11 + 1;
            if (*(char *)(iVar10 + iVar11) != *(char *)(iVar11 + 0x18063cca8)) goto code_r0x00018007457f;
            iVar11 = iVar15;
        } while (iVar15 != 7);
    }
    var_458h = fcn.180073d60(arg1, (int64_t)&var_448h);
    if (*(char *)var_458h != '\0') {
        bVar3 = false;
        do {
            iVar5 = func_0x000180498f10(var_458h, 0x18063cc90);
            if (iVar5 == 0) {
                bVar3 = true;
            }
            var_458h = fcn.180073d60(arg1, (int64_t)&var_448h);
        } while (*(char *)var_458h != '\0');
        if (bVar3) {
            iVar10 = fcn.180073d60(arg1, (int64_t)&var_448h);
            var_458h = iVar10;
            iVar5 = func_0x000180498f90(iVar10, 0x18063cce4, 3);
            if (iVar5 == 0) {
                var_458h = iVar10 + 3;
                iVar5 = func_0x00018046c52c(var_458h, &var_458h, 10);
                cVar17 = *(char *)var_458h;
                pcVar21 = (char *)var_458h;
                while (cVar17 == ' ') {
                    pcVar21 = pcVar21 + 1;
                    cVar17 = *pcVar21;
                }
                var_460h._0_4_ = iVar5;
                var_458h = (int64_t)pcVar21;
                iVar6 = func_0x000180498f90(pcVar21, 0x18063cce0, 3);
                if (iVar6 == 0) {
                    var_458h = (int64_t)(pcVar21 + 3);
                    uVar7 = func_0x00018046c52c(var_458h);
                    var_468h._0_4_ = uVar7;
                    if ((iVar5 < 0x1000001) && ((int32_t)uVar7 < 0x1000001)) {
                        *(uint32_t *)arg2 = uVar7;
                        *(int32_t *)arg3 = iVar5;
                        if (((-1 < (int32_t)uVar7) && (-1 < iVar5)) &&
                           (((((iVar5 == 0 || ((int32_t)uVar7 <= (int32_t)(0x7fffffff / (int64_t)iVar5))) &&
                              (uVar7 * iVar5 < 0x20000000)) && (uVar7 * iVar5 * 4 < 0x20000000)) &&
                            (((iVar5 == 0 || ((int32_t)uVar7 <= (int32_t)(0x7fffffff / (int64_t)iVar5))) &&
                             (iVar10 = func_0x00018046d050(), var_450h = iVar10, iVar10 != 0)))))) {
                            if (0x7ff7 < uVar7 - 8) {
                                iVar6 = 0;
                                goto code_r0x000180074606;
                            }
                            iVar11 = 0;
                            var_468h._4_4_ = 0;
                            if (0 < iVar5) {
                                do {
                                    pcVar21 = *(char **)(arg1 + 0xc0);
                                    piVar1 = (int32_t *)(arg1 + 0x30);
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar17 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar17 = '\0';
                                    } else {
                                        func_0x000180069750();
                                        cVar17 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar19 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar19 = '\0';
                                    } else {
                                        func_0x000180069750();
                                        cVar19 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar14 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar14 = '\0';
                                    } else {
                                        func_0x000180069750(arg1);
                                        cVar14 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (((cVar17 != '\x02') || (cVar19 != '\x02')) || (cVar14 < '\0')) {
                                        var_468h._0_4_ =
                                             CONCAT22(CONCAT11(var_468h._3_1_, cVar14), CONCAT11(cVar19, cVar17));
                                        uVar4 = func_0x0001800697d0(arg1);
                                        var_468h._0_4_ = CONCAT13(uVar4, (unkbyte3)var_468h);
                                        fcn.180073eb0(iVar10, (int64_t)&var_468h, 4);
                                        iVar6 = 0;
                                        func_0x000180460d90(iVar11);
                                        iVar22 = 1;
                                        do {
                                            func_0x000180069890(arg1, &var_460h, 4);
                                            fcn.180073eb0(iVar10 + ((int64_t)(int32_t)(uVar7 * iVar6 * 4) +
                                                                   (int64_t)(iVar22 * 4)) * 4, (int64_t)&var_460h, 4);
                                            iVar22 = iVar22 + 1;
                                            while ((int32_t)uVar7 <= iVar22) {
                                                iVar6 = iVar6 + 1;
code_r0x000180074606:
                                                if (iVar5 <= iVar6) goto code_r0x00018007457f;
                                                iVar22 = 0;
                                            }
                                        } while( true );
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar17 = *pcVar21;
                                        *(char **)(arg1 + 0xc0) = pcVar21 + 1;
                                    } else if (*piVar1 == 0) {
                                        cVar17 = '\0';
                                    } else {
                                        func_0x000180069750(arg1);
                                        cVar17 = **(char **)(arg1 + 0xc0);
                                        *(char **)(arg1 + 0xc0) = *(char **)(arg1 + 0xc0) + 1;
                                    }
                                    if (CONCAT11(cVar14, cVar17) != uVar7) {
code_r0x0001800745b5:
                                        func_0x000180460d90(iVar10);
                                        func_0x000180460d90(iVar11);
                                        goto code_r0x00018007457f;
                                    }
                                    if ((iVar11 == 0) &&
                                       (iVar11 = func_0x00018046d050((int64_t)(int32_t)(uVar7 * 4)), iVar11 == 0)) {
                                        func_0x000180460d90(iVar10);
                                        goto code_r0x00018007457f;
                                    }
                                    iVar5 = 0;
                                    uVar8 = (uint32_t)var_468h;
                                    do {
                                        iVar6 = 0;
                                        uVar18 = uVar8;
                                        uVar7 = (uint32_t)var_468h;
                                        iVar10 = var_450h;
                                        while (var_468h._0_4_ = uVar7, var_450h = iVar10, 0 < (int32_t)uVar18) {
                                            puVar12 = *(uint8_t **)(arg1 + 0xc0);
                                            if (puVar12 < *(uint8_t **)(arg1 + 200)) {
code_r0x0001800743ba:
                                                uVar20 = *puVar12;
                                                puVar13 = puVar12 + 1;
                                                *(uint8_t **)(arg1 + 0xc0) = puVar13;
                                                if (uVar20 < 0x81) goto code_r0x000180074460;
                                                if (puVar13 < *(uint8_t **)(arg1 + 200)) {
                                                    uVar23 = *puVar13;
                                                    *(uint8_t **)(arg1 + 0xc0) = puVar12 + 2;
                                                } else if (*piVar1 == 0) {
                                                    uVar23 = 0;
                                                } else {
                                                    func_0x000180069750(arg1);
                                                    uVar23 = **(uint8_t **)(arg1 + 0xc0);
                                                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                                }
                                                uVar20 = uVar20 + 0x80;
                                                iVar10 = var_450h;
                                                if (uVar18 < uVar20) goto code_r0x0001800745b5;
                                                iVar22 = 0;
                                                if (uVar20 != 0) {
                                                    iVar16 = iVar6 * 4;
                                                    do {
                                                        iVar9 = iVar16 + iVar5;
                                                        iVar6 = iVar6 + 1;
                                                        iVar16 = iVar16 + 4;
                                                        iVar22 = iVar22 + 1;
                                                        *(uint8_t *)(iVar9 + iVar11) = uVar23;
                                                    } while (iVar22 < (int32_t)(uint32_t)uVar20);
                                                }
                                            } else {
                                                if (*piVar1 != 0) {
                                                    func_0x000180069750(arg1);
                                                    puVar12 = *(uint8_t **)(arg1 + 0xc0);
                                                    goto code_r0x0001800743ba;
                                                }
                                                uVar20 = 0;
code_r0x000180074460:
                                                iVar10 = var_450h;
                                                if (uVar18 < uVar20) goto code_r0x0001800745b5;
                                                iVar22 = 0;
                                                if (uVar20 != 0) {
                                                    iVar16 = iVar6 * 4;
                                                    do {
                                                        puVar2 = *(undefined **)(arg1 + 0xc0);
                                                        if (puVar2 < *(undefined **)(arg1 + 200)) {
                                                            uVar4 = *puVar2;
                                                            *(undefined **)(arg1 + 0xc0) = puVar2 + 1;
                                                        } else if (*piVar1 == 0) {
                                                            uVar4 = 0;
                                                        } else {
                                                            func_0x000180069750(arg1);
                                                            uVar4 = **(undefined **)(arg1 + 0xc0);
                                                            *(undefined **)(arg1 + 0xc0) =
                                                                 *(undefined **)(arg1 + 0xc0) + 1;
                                                        }
                                                        iVar9 = iVar16 + iVar5;
                                                        iVar6 = iVar6 + 1;
                                                        iVar22 = iVar22 + 1;
                                                        iVar16 = iVar16 + 4;
                                                        *(undefined *)(iVar9 + iVar11) = uVar4;
                                                    } while (iVar22 < (int32_t)(uint32_t)uVar20);
                                                }
                                            }
                                            uVar8 = (uint32_t)var_468h;
                                            uVar7 = (uint32_t)var_468h;
                                            iVar10 = var_450h;
                                            uVar18 = (uint32_t)var_468h - iVar6;
                                        }
                                        iVar5 = iVar5 + 1;
                                    } while (iVar5 < 4);
                                    iVar5 = 0;
                                    if (0 < (int32_t)uVar7) {
                                        iVar6 = var_468h._4_4_ * uVar7;
                                        do {
                                            fcn.180073eb0(iVar10 + (int64_t)(iVar5 * 4 + iVar6 * 4) * 4, 
                                                          iVar5 * 4 + iVar11, 4);
                                            iVar5 = iVar5 + 1;
                                        } while (iVar5 < (int32_t)uVar7);
                                    }
                                    var_468h._4_4_ = var_468h._4_4_ + 1;
                                    iVar5 = (int32_t)var_460h;
                                } while (var_468h._4_4_ < (int32_t)var_460h);
                                if (iVar11 != 0) {
                                    func_0x000180460d90(iVar11);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x00018007457f:
    func_0x000180459870(var_48h ^ (uint64_t)auStack_488);
    return;
}

// ============================================================
// Function: FUN_18007465c
// Address: 0x18007465c
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_464h
// WARNING: [rz-ghidra] Detected overlap for variable var_466h
// WARNING: [rz-ghidra] Detected overlap for variable var_467h
// WARNING: [rz-ghidra] Detected overlap for variable var_465h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel

void fcn.180073fe0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    undefined *puVar2;
    bool bVar3;
    undefined uVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint8_t *puVar12;
    uint8_t *puVar13;
    char cVar14;
    int64_t iVar15;
    int32_t iVar16;
    char cVar17;
    uint32_t uVar18;
    char cVar19;
    uint8_t uVar20;
    char *pcVar21;
    int32_t iVar22;
    uint8_t uVar23;
    int64_t var_20h;
    undefined auStack_488 [32];
    int64_t var_468h;
    int64_t var_460h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_8h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_488;
    iVar10 = fcn.180073d60(arg1, (int64_t)&var_448h);
    iVar5 = func_0x000180498f10(iVar10, 0x18063ccb0);
    if (iVar5 != 0) {
        iVar11 = 0;
        do {
            iVar15 = iVar11 + 1;
            if (*(char *)(iVar10 + iVar11) != *(char *)(iVar11 + 0x18063cca8)) goto code_r0x00018007457f;
            iVar11 = iVar15;
        } while (iVar15 != 7);
    }
    var_458h = fcn.180073d60(arg1, (int64_t)&var_448h);
    if (*(char *)var_458h != '\0') {
        bVar3 = false;
        do {
            iVar5 = func_0x000180498f10(var_458h, 0x18063cc90);
            if (iVar5 == 0) {
                bVar3 = true;
            }
            var_458h = fcn.180073d60(arg1, (int64_t)&var_448h);
        } while (*(char *)var_458h != '\0');
        if (bVar3) {
            iVar10 = fcn.180073d60(arg1, (int64_t)&var_448h);
            var_458h = iVar10;
            iVar5 = func_0x000180498f90(iVar10, 0x18063cce4, 3);
            if (iVar5 == 0) {
                var_458h = iVar10 + 3;
                iVar5 = func_0x00018046c52c(var_458h, &var_458h, 10);
                cVar17 = *(char *)var_458h;
                pcVar21 = (char *)var_458h;
                while (cVar17 == ' ') {
                    pcVar21 = pcVar21 + 1;
                    cVar17 = *pcVar21;
                }
                var_460h._0_4_ = iVar5;
                var_458h = (int64_t)pcVar21;
                iVar6 = func_0x000180498f90(pcVar21, 0x18063cce0, 3);
                if (iVar6 == 0) {
                    var_458h = (int64_t)(pcVar21 + 3);
                    uVar7 = func_0x00018046c52c(var_458h);
                    var_468h._0_4_ = uVar7;
                    if ((iVar5 < 0x1000001) && ((int32_t)uVar7 < 0x1000001)) {
                        *(uint32_t *)arg2 = uVar7;
                        *(int32_t *)arg3 = iVar5;
                        if (((-1 < (int32_t)uVar7) && (-1 < iVar5)) &&
                           (((((iVar5 == 0 || ((int32_t)uVar7 <= (int32_t)(0x7fffffff / (int64_t)iVar5))) &&
                              (uVar7 * iVar5 < 0x20000000)) && (uVar7 * iVar5 * 4 < 0x20000000)) &&
                            (((iVar5 == 0 || ((int32_t)uVar7 <= (int32_t)(0x7fffffff / (int64_t)iVar5))) &&
                             (iVar10 = func_0x00018046d050(), var_450h = iVar10, iVar10 != 0)))))) {
                            if (0x7ff7 < uVar7 - 8) {
                                iVar6 = 0;
                                goto code_r0x000180074606;
                            }
                            iVar11 = 0;
                            var_468h._4_4_ = 0;
                            if (0 < iVar5) {
                                do {
                                    pcVar21 = *(char **)(arg1 + 0xc0);
                                    piVar1 = (int32_t *)(arg1 + 0x30);
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar17 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar17 = '\0';
                                    } else {
                                        func_0x000180069750();
                                        cVar17 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar19 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar19 = '\0';
                                    } else {
                                        func_0x000180069750();
                                        cVar19 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar14 = *pcVar21;
                                        pcVar21 = pcVar21 + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    } else if (*piVar1 == 0) {
                                        cVar14 = '\0';
                                    } else {
                                        func_0x000180069750(arg1);
                                        cVar14 = **(char **)(arg1 + 0xc0);
                                        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
                                        *(char **)(arg1 + 0xc0) = pcVar21;
                                    }
                                    if (((cVar17 != '\x02') || (cVar19 != '\x02')) || (cVar14 < '\0')) {
                                        var_468h._0_4_ =
                                             CONCAT22(CONCAT11(var_468h._3_1_, cVar14), CONCAT11(cVar19, cVar17));
                                        uVar4 = func_0x0001800697d0(arg1);
                                        var_468h._0_4_ = CONCAT13(uVar4, (unkbyte3)var_468h);
                                        fcn.180073eb0(iVar10, (int64_t)&var_468h, 4);
                                        iVar6 = 0;
                                        func_0x000180460d90(iVar11);
                                        iVar22 = 1;
                                        do {
                                            func_0x000180069890(arg1, &var_460h, 4);
                                            fcn.180073eb0(iVar10 + ((int64_t)(int32_t)(uVar7 * iVar6 * 4) +
                                                                   (int64_t)(iVar22 * 4)) * 4, (int64_t)&var_460h, 4);
                                            iVar22 = iVar22 + 1;
                                            while ((int32_t)uVar7 <= iVar22) {
                                                iVar6 = iVar6 + 1;
code_r0x000180074606:
                                                if (iVar5 <= iVar6) goto code_r0x00018007457f;
                                                iVar22 = 0;
                                            }
                                        } while( true );
                                    }
                                    if (pcVar21 < *(char **)(arg1 + 200)) {
                                        cVar17 = *pcVar21;
                                        *(char **)(arg1 + 0xc0) = pcVar21 + 1;
                                    } else if (*piVar1 == 0) {
                                        cVar17 = '\0';
                                    } else {
                                        func_0x000180069750(arg1);
                                        cVar17 = **(char **)(arg1 + 0xc0);
                                        *(char **)(arg1 + 0xc0) = *(char **)(arg1 + 0xc0) + 1;
                                    }
                                    if (CONCAT11(cVar14, cVar17) != uVar7) {
code_r0x0001800745b5:
                                        func_0x000180460d90(iVar10);
                                        func_0x000180460d90(iVar11);
                                        goto code_r0x00018007457f;
                                    }
                                    if ((iVar11 == 0) &&
                                       (iVar11 = func_0x00018046d050((int64_t)(int32_t)(uVar7 * 4)), iVar11 == 0)) {
                                        func_0x000180460d90(iVar10);
                                        goto code_r0x00018007457f;
                                    }
                                    iVar5 = 0;
                                    uVar8 = (uint32_t)var_468h;
                                    do {
                                        iVar6 = 0;
                                        uVar18 = uVar8;
                                        uVar7 = (uint32_t)var_468h;
                                        iVar10 = var_450h;
                                        while (var_468h._0_4_ = uVar7, var_450h = iVar10, 0 < (int32_t)uVar18) {
                                            puVar12 = *(uint8_t **)(arg1 + 0xc0);
                                            if (puVar12 < *(uint8_t **)(arg1 + 200)) {
code_r0x0001800743ba:
                                                uVar20 = *puVar12;
                                                puVar13 = puVar12 + 1;
                                                *(uint8_t **)(arg1 + 0xc0) = puVar13;
                                                if (uVar20 < 0x81) goto code_r0x000180074460;
                                                if (puVar13 < *(uint8_t **)(arg1 + 200)) {
                                                    uVar23 = *puVar13;
                                                    *(uint8_t **)(arg1 + 0xc0) = puVar12 + 2;
                                                } else if (*piVar1 == 0) {
                                                    uVar23 = 0;
                                                } else {
                                                    func_0x000180069750(arg1);
                                                    uVar23 = **(uint8_t **)(arg1 + 0xc0);
                                                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                                }
                                                uVar20 = uVar20 + 0x80;
                                                iVar10 = var_450h;
                                                if (uVar18 < uVar20) goto code_r0x0001800745b5;
                                                iVar22 = 0;
                                                if (uVar20 != 0) {
                                                    iVar16 = iVar6 * 4;
                                                    do {
                                                        iVar9 = iVar16 + iVar5;
                                                        iVar6 = iVar6 + 1;
                                                        iVar16 = iVar16 + 4;
                                                        iVar22 = iVar22 + 1;
                                                        *(uint8_t *)(iVar9 + iVar11) = uVar23;
                                                    } while (iVar22 < (int32_t)(uint32_t)uVar20);
                                                }
                                            } else {
                                                if (*piVar1 != 0) {
                                                    func_0x000180069750(arg1);
                                                    puVar12 = *(uint8_t **)(arg1 + 0xc0);
                                                    goto code_r0x0001800743ba;
                                                }
                                                uVar20 = 0;
code_r0x000180074460:
                                                iVar10 = var_450h;
                                                if (uVar18 < uVar20) goto code_r0x0001800745b5;
                                                iVar22 = 0;
                                                if (uVar20 != 0) {
                                                    iVar16 = iVar6 * 4;
                                                    do {
                                                        puVar2 = *(undefined **)(arg1 + 0xc0);
                                                        if (puVar2 < *(undefined **)(arg1 + 200)) {
                                                            uVar4 = *puVar2;
                                                            *(undefined **)(arg1 + 0xc0) = puVar2 + 1;
                                                        } else if (*piVar1 == 0) {
                                                            uVar4 = 0;
                                                        } else {
                                                            func_0x000180069750(arg1);
                                                            uVar4 = **(undefined **)(arg1 + 0xc0);
                                                            *(undefined **)(arg1 + 0xc0) =
                                                                 *(undefined **)(arg1 + 0xc0) + 1;
                                                        }
                                                        iVar9 = iVar16 + iVar5;
                                                        iVar6 = iVar6 + 1;
                                                        iVar22 = iVar22 + 1;
                                                        iVar16 = iVar16 + 4;
                                                        *(undefined *)(iVar9 + iVar11) = uVar4;
                                                    } while (iVar22 < (int32_t)(uint32_t)uVar20);
                                                }
                                            }
                                            uVar8 = (uint32_t)var_468h;
                                            uVar7 = (uint32_t)var_468h;
                                            iVar10 = var_450h;
                                            uVar18 = (uint32_t)var_468h - iVar6;
                                        }
                                        iVar5 = iVar5 + 1;
                                    } while (iVar5 < 4);
                                    iVar5 = 0;
                                    if (0 < (int32_t)uVar7) {
                                        iVar6 = var_468h._4_4_ * uVar7;
                                        do {
                                            fcn.180073eb0(iVar10 + (int64_t)(iVar5 * 4 + iVar6 * 4) * 4, 
                                                          iVar5 * 4 + iVar11, 4);
                                            iVar5 = iVar5 + 1;
                                        } while (iVar5 < (int32_t)uVar7);
                                    }
                                    var_468h._4_4_ = var_468h._4_4_ + 1;
                                    iVar5 = (int32_t)var_460h;
                                } while (var_468h._4_4_ < (int32_t)var_460h);
                                if (iVar11 != 0) {
                                    func_0x000180460d90(iVar11);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x00018007457f:
    func_0x000180459870(var_48h ^ (uint64_t)auStack_488);
    return;
}

// ============================================================
// Function: FUN_180074670
// Address: 0x180074670
// Size: 486 bytes
// ============================================================
void fcn.180074670(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    undefined uVar2;
    undefined *puVar3;
    int32_t iVar4;
    undefined8 *puVar5;
    
code_r0x000180074690:
    puVar1 = (uint64_t *)(arg1 + 0xc0);
code_r0x0001800746b0:
    if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x0001800746d7:
        if (*(uint64_t *)(arg1 + 200) <= *puVar1) goto code_r0x000180074744;
code_r0x0001800746df:
        if ((*(char *)arg2 != ' ') && (4 < (uint8_t)(*(char *)arg2 - 9U))) goto code_r0x000180074744;
        puVar3 = (undefined *)*puVar1;
        if (puVar3 < *(undefined **)(arg1 + 200)) {
            *(undefined *)arg2 = *puVar3;
            *puVar1 = (uint64_t)(puVar3 + 1);
        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
            *(undefined *)arg2 = 0;
        } else {
            func_0x000180069750(arg1);
            uVar2 = *(undefined *)*puVar1;
            *puVar1 = (uint64_t)((undefined *)*puVar1 + 1);
            *(undefined *)arg2 = uVar2;
        }
        goto code_r0x0001800746b0;
    }
    iVar4 = (**(code **)(arg1 + 0x20))();
    if (iVar4 == 0) goto code_r0x0001800746df;
    if (*(int32_t *)(arg1 + 0x30) != 0) goto code_r0x0001800746d7;
code_r0x000180074744:
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        iVar4 = (**(code **)(arg1 + 0x20))(*(undefined8 *)(arg1 + 0x28));
        if (iVar4 == 0) goto code_r0x00018007477a;
        if (*(int32_t *)(arg1 + 0x30) == 0) {
            return;
        }
    }
    if (*(uint64_t *)(arg1 + 200) <= *(uint64_t *)(arg1 + 0xc0)) {
        return;
    }
code_r0x00018007477a:
    if (*(char *)arg2 != '#') {
        return;
    }
code_r0x000180074790:
    if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x0001800747d1:
        if (*(uint64_t *)(arg1 + 200) <= *(uint64_t *)(arg1 + 0xc0)) goto code_r0x000180074690;
    } else {
        iVar4 = (**(code **)(arg1 + 0x20))();
        if (iVar4 != 0) {
            if (*(int32_t *)(arg1 + 0x30) != 0) goto code_r0x0001800747d1;
            goto code_r0x000180074690;
        }
    }
    puVar5 = (undefined8 *)(arg1 + 0xc0);
    if ((*(char *)arg2 == '\n') || (*(char *)arg2 == '\r')) goto code_r0x000180074690;
    puVar3 = (undefined *)*puVar5;
    if (puVar3 < *(undefined **)(arg1 + 200)) {
        *(undefined *)arg2 = *puVar3;
        *puVar5 = puVar3 + 1;
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        *(undefined *)arg2 = 0;
    } else {
        func_0x000180069750(arg1);
        uVar2 = *(undefined *)*puVar5;
        *puVar5 = (undefined *)*puVar5 + 1;
        *(undefined *)arg2 = uVar2;
    }
    goto code_r0x000180074790;
}

// ============================================================
// Function: FUN_180074860
// Address: 0x180074860
// Size: 225 bytes
// ============================================================
int32_t fcn.180074860(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    undefined uVar2;
    undefined *puVar3;
    int32_t iVar4;
    int32_t iVar5;
    
    puVar1 = (uint64_t *)(arg1 + 0xc0);
    iVar5 = 0;
    do {
        if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x0001800748b7:
            if (*(uint64_t *)(arg1 + 200) <= *puVar1) {
                return iVar5;
            }
        } else {
            iVar4 = (**(code **)(arg1 + 0x20))();
            if (iVar4 != 0) {
                if (*(int32_t *)(arg1 + 0x30) == 0) {
                    return iVar5;
                }
                goto code_r0x0001800748b7;
            }
        }
        if (9 < (uint8_t)(*(char *)arg2 - 0x30U)) {
            return iVar5;
        }
        puVar3 = (undefined *)*puVar1;
        iVar5 = (int32_t)*(char *)arg2 + (iVar5 * 5 + -0x18) * 2;
        if (puVar3 < *(undefined **)(arg1 + 200)) {
            *(undefined *)arg2 = *puVar3;
            *puVar1 = (uint64_t)(puVar3 + 1);
        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
            *(undefined *)arg2 = 0;
        } else {
            func_0x000180069750(arg1);
            uVar2 = *(undefined *)*puVar1;
            *puVar1 = (uint64_t)((undefined *)*puVar1 + 1);
            *(undefined *)arg2 = uVar2;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180074950
// Address: 0x180074950
// Size: 434 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180074950(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined8 uVar3;
    char *pcVar4;
    char cVar5;
    int64_t *piVar6;
    char cVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    pcVar4 = *(char **)(arg1 + 0xd0);
    piVar8 = &var_10h;
    if (arg2 != 0) {
        piVar8 = (int64_t *)arg2;
    }
    piVar9 = &var_10h;
    if (arg3 != 0) {
        piVar9 = (int64_t *)arg3;
    }
    *(char **)(arg1 + 0xc0) = pcVar4;
    *(char **)(arg1 + 200) = *(char **)(arg1 + 0xd8);
    piVar6 = &var_10h;
    if (arg4 != 0) {
        piVar6 = (int64_t *)arg4;
    }
    if (pcVar4 < *(char **)(arg1 + 0xd8)) {
        cVar7 = *pcVar4;
        pcVar4 = pcVar4 + 1;
        *(char **)(arg1 + 0xc0) = pcVar4;
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        cVar7 = '\0';
    } else {
        func_0x000180069750(arg1);
        cVar7 = **(char **)(arg1 + 0xc0);
        pcVar4 = *(char **)(arg1 + 0xc0) + 1;
        *(char **)(arg1 + 0xc0) = pcVar4;
    }
    if (pcVar4 < *(char **)(arg1 + 200)) {
        cVar5 = *pcVar4;
        *(char **)(arg1 + 0xc0) = pcVar4 + 1;
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        cVar5 = '\0';
    } else {
        func_0x000180069750(arg1);
        cVar5 = **(char **)(arg1 + 0xc0);
        *(char **)(arg1 + 0xc0) = *(char **)(arg1 + 0xc0) + 1;
    }
    if ((cVar7 == 'P') && ((uint8_t)(cVar5 - 0x35U) < 2)) {
        uVar1 = 1;
        if (cVar5 == '6') {
            uVar1 = 3;
        }
        *(undefined4 *)piVar6 = uVar1;
        var_8h._0_1_ = func_0x0001800697d0(arg1);
        fcn.180074670(arg1, (int64_t)&var_8h);
        uVar1 = fcn.180074860(arg1, (int64_t)&var_8h);
        *(undefined4 *)piVar8 = uVar1;
        fcn.180074670(arg1, (int64_t)&var_8h);
        uVar1 = fcn.180074860(arg1, (int64_t)&var_8h);
        *(undefined4 *)piVar9 = uVar1;
        fcn.180074670(arg1, (int64_t)&var_8h);
        iVar2 = fcn.180074860(arg1, (int64_t)&var_8h);
        if (iVar2 < 0x10000) {
            uVar3 = 8;
            if (0xff < iVar2) {
                uVar3 = 0x10;
            }
            return uVar3;
        }
    } else {
        *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
        *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
    }
    return 0;
}

// ============================================================
// Function: FUN_180074b10
// Address: 0x180074b10
// Size: 644 bytes
// ============================================================
void fcn.180074b10(int64_t arg1)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *piVar6;
    int32_t *piVar7;
    int32_t *piVar8;
    undefined *puVar9;
    int32_t *unaff_RDI;
    uint64_t uVar10;
    int32_t *piVar11;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar9 = auStack_88;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    var_68h._0_4_ = *(int32_t *)0x18077aef8;
    *(int32_t *)0x18077aef8 = *(int32_t *)0x18077aef8 + 1;
    func_0x00018000b4d0(&var_60h, arg1);
    piVar8 = *(int32_t **)0x18077afc8;
    if (*(int32_t **)0x18077afc8 != *(int32_t **)0x18077afd0) {
        **(int32_t **)0x18077afc8 = (int32_t)var_68h;
        *(int64_t *)(piVar8 + 2) = var_60h;
        *(int64_t *)(piVar8 + 4) = var_58h;
        *(int64_t *)(piVar8 + 6) = var_50h;
        *(int64_t *)(piVar8 + 8) = var_48h;
        *(int32_t **)0x18077afc8 = *(int32_t **)0x18077afc8 + 10;
        puVar9 = auStack_88;
        goto code_r0x000180074d6e;
    }
    iVar2 = ((int64_t)*(int32_t **)0x18077afc8 - (int64_t)*(int32_t **)0x18077afc0) / 0x28;
    if (iVar2 == 0x666666666666666) {
        func_0x000180010010();
code_r0x000180074d8e:
        func_0x000180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar10 = ((int64_t)*(int32_t **)0x18077afd0 - (int64_t)*(int32_t **)0x18077afc0 >> 3) * -0x3333333333333333;
    uVar3 = 0x666666666666666 - (uVar10 >> 1);
    if (uVar3 <= uVar10 && uVar10 - uVar3 != 0) goto code_r0x000180074d8e;
    uVar3 = iVar2 + 1;
    uVar10 = uVar10 + (uVar10 >> 1);
    uVar5 = uVar3;
    if (uVar3 <= uVar10) {
        uVar5 = uVar10;
    }
    if (0x666666666666666 < uVar5) goto code_r0x000180074d8e;
    uVar10 = uVar5 * 0x28;
    if (uVar10 == 0) {
        unaff_RDI = (int32_t *)0x0;
code_r0x000180074c6b:
        piVar11 = unaff_RDI + iVar2 * 10;
        *piVar11 = (int32_t)var_68h;
        *(int64_t *)(piVar11 + 2) = var_60h;
        *(int64_t *)(piVar11 + 4) = var_58h;
        *(int64_t *)(piVar11 + 6) = var_50h;
        *(int64_t *)(piVar11 + 8) = var_48h;
        piVar6 = *(int32_t **)0x18077afc0;
        piVar7 = unaff_RDI;
        if (piVar8 != *(int32_t **)0x18077afc8) {
            func_0x00018007efa0(*(int32_t **)0x18077afc0, piVar8, unaff_RDI);
            piVar7 = piVar11 + 10;
            piVar6 = piVar8;
        }
        func_0x00018007efa0(piVar6, *(int32_t **)0x18077afc8, piVar7);
        piVar7 = *(int32_t **)0x18077afc8;
        piVar8 = *(int32_t **)0x18077afc0;
        if (*(int32_t **)0x18077afc0 != (int32_t *)0x0) {
            for (; piVar8 != piVar7; piVar8 = piVar8 + 10) {
                func_0x000180004e40(piVar8 + 2);
            }
            piVar7 = *(int32_t **)0x18077afc0;
            puVar9 = auStack_88;
            if (0xfff < (uint64_t)(((int64_t)*(int32_t **)0x18077afd0 - (int64_t)*(int32_t **)0x18077afc0 >> 3) * 8)) {
                piVar7 = *(int32_t **)(*(int32_t **)0x18077afc0 + -2);
                piVar8 = (int32_t *)((int64_t)*(int32_t **)0x18077afc0 + (-8 - (int64_t)piVar7));
                puVar9 = auStack_88;
                if ((int32_t *)0x1f < piVar8) goto code_r0x000180074d3e;
            }
            goto code_r0x000180074d48;
        }
    } else {
        if (uVar10 < 0x1000) {
            unaff_RDI = (int32_t *)func_0x000180459890(uVar10);
            goto code_r0x000180074c6b;
        }
        if (uVar10 + 0x27 <= uVar10) goto code_r0x000180074d8e;
        iVar4 = func_0x000180459890();
        if (iVar4 != 0) {
            unaff_RDI = (int32_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            *(int64_t *)(unaff_RDI + -2) = iVar4;
            goto code_r0x000180074c6b;
        }
code_r0x000180074d3e:
        piVar7 = piVar8;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar9 = auStack_80;
code_r0x000180074d48:
        *(undefined8 *)(puVar9 + -8) = 0x180074d4d;
        func_0x000180459c3c(piVar7);
    }
    *(int32_t **)0x18077afc8 = unaff_RDI + uVar3 * 10;
    *(int32_t **)0x18077afd0 = unaff_RDI + uVar5 * 10;
    *(int32_t **)0x18077afc0 = unaff_RDI;
code_r0x000180074d6e:
    *(undefined8 *)(puVar9 + -8) = 0x180074d7b;
    func_0x000180459870(*(uint64_t *)(puVar9 + 0x48) ^ (uint64_t)puVar9);
    return;
}

// ============================================================
// Function: FUN_180074da0
// Address: 0x180074da0
// Size: 555 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180074da0(void)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    uint64_t uVar5;
    bool bVar6;
    int64_t var_8h;
    undefined auStack_88 [32];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar4 = func_0x000180459890(0x100);
    var_68h = iVar4;
    func_0x0001804986e0(iVar4, 0, 0x100);
    func_0x0001800664a0(iVar4);
    func_0x0001800664a0(iVar4 + 0x40);
    *(undefined4 *)(iVar4 + 0x80) = 0x101;
    *(undefined4 *)(iVar4 + 0x84) = 0x120c;
    *(undefined *)(iVar4 + 0x88) = 0;
    *(undefined8 *)(iVar4 + 0x90) = 200;
    *(undefined (*) [16])(iVar4 + 0x98) = ZEXT816(0);
    *(undefined8 *)(iVar4 + 0xa8) = 0xe;
    *(undefined8 *)(iVar4 + 0xb0) = 0xf;
    *(undefined8 *)(iVar4 + 0x98) = 0x6567677573206f4e;
    *(undefined4 *)(iVar4 + 0xa0) = 0x6f697473;
    *(undefined2 *)(iVar4 + 0xa4) = 0x736e;
    *(undefined *)(iVar4 + 0xa6) = 0;
    *(undefined8 *)(iVar4 + 0xf0) = 0;
    *(undefined8 *)(iVar4 + 0xf8) = 0;
    bVar6 = *(int64_t *)0x18077afd8 != 0;
    *(int64_t *)0x18077afd8 = iVar4;
    piVar1 = *(int64_t **)0x180782200;
    piVar2 = *(int64_t **)0x180782208;
    if (bVar6) {
        func_0x00018007d660();
        piVar1 = *(int64_t **)0x180782200;
        piVar2 = *(int64_t **)0x180782208;
    }
    for (; piVar3 = *(int64_t **)0x180782208, piVar1 != *(int64_t **)0x180782208; piVar1 = piVar1 + 1) {
        var_68h = *piVar1;
        *(int64_t **)0x180782208 = piVar2;
        var_60h = func_0x000180498cd0();
        func_0x000180161370(*(int64_t *)0x18077afd8, &var_68h);
        piVar2 = *(int64_t **)0x180782208;
        *(int64_t **)0x180782208 = piVar3;
    }
    uVar5 = 0;
    *(int64_t **)0x180782208 = piVar2;
    do {
        var_68h = *(int64_t *)(uVar5 * 8 + 0x1805ab510);
        var_60h = func_0x000180498cd0();
        func_0x000180161370(*(int64_t *)0x18077afd8, &var_68h);
        uVar5 = uVar5 + 1;
    } while (uVar5 < 0x145);
    uVar5 = 0;
    do {
        var_68h = *(int64_t *)(uVar5 * 8 + 0x1805abf40);
        var_60h = func_0x000180498cd0();
        func_0x000180161370(*(int64_t *)0x18077afd8 + 0x40, &var_68h);
        iVar4 = *(int64_t *)0x18077afd8;
        uVar5 = uVar5 + 1;
    } while (uVar5 < 0x1247);
    *(undefined4 *)(*(int64_t *)0x18077afd8 + 0x80) = 0x101;
    *(undefined *)(iVar4 + 0x88) = 0;
    *(undefined8 *)(iVar4 + 0x90) = 0x78;
    var_58h = 0x18063d1f8;
    var_20h = (int64_t)&var_58h;
    func_0x000180014e50(&var_58h, iVar4 + 0xb8);
    if (var_20h != 0) {
        (**(code **)(*(int64_t *)var_20h + 0x20))
                  (var_20h, CONCAT71((unkint7)((uint64_t)&var_58h >> 8), (int64_t *)var_20h != &var_58h));
    }
    func_0x000180459870(var_18h ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_180074fd0
// Address: 0x180074fd0
// Size: 2183 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180075330)
// WARNING: Removing unreachable block (ram,0x000180075339)
// WARNING: Removing unreachable block (ram,0x000180075346)
// WARNING: Removing unreachable block (ram,0x000180075356)
// WARNING: Removing unreachable block (ram,0x00018007536d)
// WARNING: Removing unreachable block (ram,0x000180075374)
// WARNING: Removing unreachable block (ram,0x000180075367)
// WARNING: Removing unreachable block (ram,0x000180075377)
// WARNING: [rz-ghidra] Detected overlap for variable var_63h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c7h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c6h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c5h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c0h

void fcn.180074fd0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined auVar5 [16];
    int32_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined (*pauVar9) [16];
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int64_t **ppiVar14;
    int64_t **ppiVar15;
    uint64_t uVar16;
    int64_t *piVar17;
    int64_t *piVar18;
    int64_t **unaff_RBX;
    undefined *puVar19;
    int64_t **ppiVar20;
    uint32_t uVar21;
    uint64_t uVar22;
    int64_t **ppiVar23;
    char *pcVar24;
    uint32_t uVar26;
    int32_t iVar27;
    int64_t *piVar28;
    int64_t *unaff_R15;
    undefined8 uStack_270;
    undefined auStack_268 [8];
    undefined auStack_260 [24];
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1c8h;
    undefined var_1c0h;
    int64_t var_1b8h;
    int64_t var_1b0h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_80h;
    char acStack_65 [5];
    int64_t var_60h;
    int64_t var_58h;
    char *pcVar25;
    
    puVar19 = auStack_268;
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    uVar26 = 0;
    var_240h._0_4_ = 0;
    var_138h = 0;
    var_130h = 0xf;
    stack0xfffffffffffffeb9 = SUB1615(ZEXT816(0), 1);
    auVar5[15] = 0;
    auVar5._0_15_ = stack0xfffffffffffffeb9;
    _var_148h = auVar5 << 8;
    var_128h = 0;
    var_120h._0_1_ = 1;
    piVar28 = (int64_t *)0x1;
    do {
        pcVar24 = acStack_65 + 2;
        iVar27 = (int32_t)piVar28;
        piVar18 = piVar28;
        if (iVar27 < 0) {
            uVar21 = -iVar27;
            do {
                pcVar25 = pcVar24;
                pcVar24 = pcVar25 + -1;
                *pcVar24 = (char)uVar21 + (char)((uint64_t)uVar21 / 10) * -10 + '0';
                uVar21 = (uint32_t)((uint64_t)uVar21 / 10);
            } while (uVar21 != 0);
            pcVar24 = pcVar25 + -2;
            *pcVar24 = '-';
        } else {
            do {
                pcVar24 = pcVar24 + -1;
                piVar11 = (int64_t *)((uint64_t)piVar18 / 10);
                *pcVar24 = (char)piVar18 + (char)piVar11 * -10 + '0';
                piVar18 = piVar11;
            } while ((int32_t)piVar11 != 0);
        }
        func_0x000180014b30(&var_d8h, pcVar24, acStack_65 + 2, &var_248h);
        var_240h._0_4_ = uVar26 | 0x30;
        puVar7 = (undefined4 *)func_0x000180018c80(&var_d8h, 0, 0x18063cd00, 9);
        var_f8h._0_4_ = *puVar7;
        var_f8h._4_4_ = puVar7[1];
        uStack_f0 = puVar7[2];
        uStack_ec = puVar7[3];
        piVar18 = *(int64_t **)(puVar7 + 4);
        uVar22 = *(uint64_t *)(puVar7 + 6);
        *(undefined8 *)(puVar7 + 4) = 0;
        *(undefined8 *)(puVar7 + 6) = 0xf;
        *(undefined *)puVar7 = 0;
        uVar26 = 0x70;
        var_240h._0_4_ = 0x70;
        var_e8h = (int64_t)piVar18;
        var_e0h = uVar22;
        if (0xf < (uint64_t)var_c0h) {
            uVar16 = var_c0h + 1;
            iVar12 = var_d8h;
            if (0xfff < uVar16) {
                iVar12 = *(int64_t *)(var_d8h + -8);
                if (0x1f < (var_d8h - iVar12) - 8U) break;
                uVar16 = var_c0h + 0x28;
            }
            func_0x000180459c3c(iVar12, uVar16);
        }
        ppiVar20 = *(int64_t ***)0x18077afe8;
        piVar11 = (int64_t *)CONCAT44(var_f8h._4_4_, (undefined4)var_f8h);
        unaff_RBX = *(int64_t ***)0x18077afe0;
        while( true ) {
            if (unaff_RBX == ppiVar20) {
                if (0xf < uVar22) {
                    uVar16 = uVar22 + 1;
                    if (0xfff < uVar16) {
                        if (0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)(int64_t *)piVar11[-1])))
                        goto code_r0x00018007530c;
                        uVar16 = uVar22 + 0x28;
                        piVar11 = (int64_t *)piVar11[-1];
                    }
                    func_0x000180459c3c(piVar11, uVar16);
                }
                uVar8 = func_0x000180016b80(&var_118h, piVar28);
                var_240h._0_4_ = 0x72;
                pauVar9 = (undefined (*) [16])func_0x000180018c80(uVar8, 0, 0x18063cd00, 9);
                unaff_R15 = *(int64_t **)*pauVar9;
                unaff_RBX = *(int64_t ***)(*pauVar9 + 8);
                _var_148h = *pauVar9;
                piVar28 = *(int64_t **)pauVar9[1];
                var_130h = *(int64_t *)(pauVar9[1] + 8);
                *(undefined8 *)pauVar9[1] = 0;
                *(undefined8 *)(pauVar9[1] + 8) = 0xf;
                (*pauVar9)[0] = 0;
                var_240h._0_4_ = 0xf6;
                var_138h = (int64_t)piVar28;
                if ((uint64_t)var_100h < 0x10) goto code_r0x00018007531b;
                iVar12 = CONCAT71(var_118h._1_7_, (undefined)var_118h);
                puVar19 = auStack_268;
                if ((var_100h + 1U < 0x1000) ||
                   (iVar10 = iVar12 - *(int64_t *)(iVar12 + -8), iVar12 = *(int64_t *)(iVar12 + -8),
                   puVar19 = auStack_268, iVar10 - 8U < 0x20)) goto code_r0x000180075316;
                goto code_r0x00018007530c;
            }
            piVar17 = &var_f8h;
            if (0xf < uVar22) {
                piVar17 = piVar11;
            }
            ppiVar15 = unaff_RBX;
            if ((int64_t *)0xf < unaff_RBX[3]) {
                ppiVar15 = (int64_t **)*unaff_RBX;
            }
            unaff_R15 = piVar18;
            if ((unaff_RBX[2] == piVar18) &&
               ((unaff_RBX[2] == (int64_t *)0x0 || (iVar6 = func_0x000180497f30(ppiVar15, piVar17), iVar6 == 0))))
            break;
            unaff_RBX = unaff_RBX + 6;
        }
        if (0xf < uVar22) {
            uVar16 = uVar22 + 1;
            piVar18 = piVar11;
            if (0xfff < uVar16) {
                piVar18 = (int64_t *)piVar11[-1];
                if (0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)piVar18))) break;
                uVar16 = uVar22 + 0x28;
            }
            func_0x000180459c3c(piVar18, uVar16);
        }
        piVar28 = (int64_t *)(uint64_t)(iVar27 + 1);
    } while( true );
code_r0x00018007530c:
    pcVar1 = (code *)swi(0x29);
    iVar12 = (*pcVar1)(5);
    puVar19 = auStack_260;
code_r0x000180075316:
    *(undefined8 *)(puVar19 + -8) = 0x18007531b;
    func_0x000180459c3c(iVar12);
code_r0x00018007531b:
    var_100h = 0xf;
    var_108h = 0;
    var_118h._0_1_ = 0;
    var_120h._0_1_ = 1;
    *(undefined8 *)(puVar19 + -8) = 0x18007538a;
    uVar8 = func_0x000180459890(0x5f0);
    *(undefined8 *)(puVar19 + 0x28) = uVar8;
    *(undefined8 *)(puVar19 + -8) = 0x180075397;
    piVar11 = (int64_t *)func_0x000180150450(uVar8);
    *(undefined8 *)(puVar19 + -8) = 0x1800753a3;
    var_128h = (int64_t)piVar11;
    iVar12 = func_0x0001801628d0();
    piVar11[0xbd] = iVar12;
    *(undefined *)((int64_t)piVar11 + 0x2d5) = 1;
    ppiVar20 = *(int64_t ***)0x18077afd8;
    var_1c8h._0_1_ = *(undefined *)(*(int64_t ***)0x18077afd8 + 0x10);
    var_1c8h._1_1_ = *(undefined *)((int64_t)*(int64_t ***)0x18077afd8 + 0x81);
    var_1c8h._2_1_ = *(undefined *)((int64_t)*(int64_t ***)0x18077afd8 + 0x82);
    var_1c8h._3_1_ = *(undefined *)((int64_t)*(int64_t ***)0x18077afd8 + 0x83);
    var_1c8h._4_4_ = *(undefined4 *)((int64_t)*(int64_t ***)0x18077afd8 + 0x84);
    var_1c0h = *(undefined *)(*(int64_t ***)0x18077afd8 + 0x11);
    var_1b8h = (int64_t)(*(int64_t ***)0x18077afd8)[0x12];
    *(undefined8 *)(puVar19 + -8) = 0x18007540e;
    func_0x00018000b4d0(&var_1b0h, *(int64_t ***)0x18077afd8 + 0x13);
    *(int64_t **)(puVar19 + 0x28) = &var_190h;
    var_158h = 0;
    piVar18 = ppiVar20[0x1e];
    if (piVar18 != (int64_t *)0x0) {
        pcVar1 = *(code **)*piVar18;
        *(undefined8 *)(puVar19 + -8) = 0x180075431;
        var_158h = (*pcVar1)(piVar18, &var_190h);
    }
    *(undefined *)(piVar11 + 0x2a) = (undefined)var_1c8h;
    *(undefined *)((int64_t)piVar11 + 0x151) = var_1c8h._1_1_;
    *(undefined *)((int64_t)piVar11 + 0x152) = var_1c8h._2_1_;
    *(undefined *)((int64_t)piVar11 + 0x153) = var_1c8h._3_1_;
    *(undefined4 *)((int64_t)piVar11 + 0x154) = var_1c8h._4_4_;
    *(undefined *)(piVar11 + 0x2b) = var_1c0h;
    piVar11[0x2c] = var_1b8h;
    var_150h = (int64_t)piVar11;
    if (piVar11 + 0x2d != &var_1b0h) {
        piVar18 = &var_1b0h;
        if (0xf < (uint64_t)var_198h) {
            piVar18 = (int64_t *)var_1b0h;
        }
        *(undefined8 *)(puVar19 + -8) = 0x1800754a6;
        func_0x00018000f180(piVar11 + 0x2d, piVar18, var_1a0h);
    }
    var_80h = 0;
    if (var_158h != 0) {
        pcVar1 = **(code ***)var_158h;
        *(undefined8 *)(puVar19 + -8) = 0x1800754c2;
        var_80h = (*pcVar1)(var_158h, &var_b8h);
    }
    *(undefined8 *)(puVar19 + -8) = 0x1800754dc;
    func_0x000180014e50(&var_b8h, piVar11 + 0x31);
    if (var_80h != 0) {
        pcVar1 = *(code **)(*(int64_t *)var_80h + 0x20);
        *(undefined8 *)(puVar19 + -8) = 0x1800754fb;
        (*pcVar1)(var_80h, CONCAT71((unkint7)((uint64_t)&var_b8h >> 8), (int64_t *)var_80h != &var_b8h));
    }
    piVar11[0x39] = var_150h;
    *(undefined2 *)(piVar11 + 0x26) = 1;
    *(undefined8 *)(puVar19 + 0x28) = 0x18063cce8;
    *(undefined8 *)(puVar19 + 0x30) = 0x15;
    *(undefined8 *)(puVar19 + -8) = 0x180075531;
    func_0x000180066120(piVar11, puVar19 + 0x28);
    *(undefined2 *)((int64_t)piVar11 + 0x266) = 0;
    *(undefined *)((int64_t)piVar11 + 0x26c) = 0;
    *(undefined4 *)(puVar19 + 0x60) = 0xffffc14f;
    *(undefined4 *)(puVar19 + 100) = 0xff55996a;
    *(undefined4 *)(puVar19 + 0x68) = 0xff1e1e1e;
    *(undefined4 *)(puVar19 + 0x6c) = 0xffe0e0e0;
    *(undefined4 *)(puVar19 + 0x68) = 0xff1c1c1c;
    *(undefined4 *)(piVar11 + 0xa6) = 0xffe0e0e0;
    *(undefined4 *)((int64_t)piVar11 + 0x534) = 0xffc086c5;
    *(undefined4 *)(piVar11 + 0xa7) = 0xff9bb35a;
    *(undefined4 *)((int64_t)piVar11 + 0x53c) = 0xffa8ceb5;
    *(undefined4 *)(piVar11 + 0xa8) = 0xff7891ce;
    *(undefined4 *)((int64_t)piVar11 + 0x544) = 0xff99ffff;
    *(undefined4 *)(piVar11 + 0xa9) = 0xff80c040;
    *(undefined4 *)((int64_t)piVar11 + 0x54c) = 0xfffedc9c;
    uVar2 = *(undefined4 *)(puVar19 + 100);
    uVar3 = *(undefined4 *)(puVar19 + 0x68);
    uVar4 = *(undefined4 *)(puVar19 + 0x6c);
    *(undefined4 *)(piVar11 + 0xaa) = *(undefined4 *)(puVar19 + 0x60);
    *(undefined4 *)((int64_t)piVar11 + 0x554) = uVar2;
    *(undefined4 *)(piVar11 + 0xab) = uVar3;
    *(undefined4 *)((int64_t)piVar11 + 0x55c) = uVar4;
    *(undefined4 *)(piVar11 + 0xac) = 0xffa06020;
    *(undefined4 *)((int64_t)piVar11 + 0x564) = 0xff505050;
    *(undefined4 *)(piVar11 + 0xad) = 0xff464646;
    *(undefined4 *)((int64_t)piVar11 + 0x56c) = 0xff8c8c8c;
    *(undefined4 *)(piVar11 + 0xae) = 0xff24def6;
    *(undefined4 *)((int64_t)piVar11 + 0x574) = 0xffc67842;
    *(undefined4 *)(piVar11 + 0xaf) = 0xffd560d5;
    *(undefined4 *)((int64_t)piVar11 + 0x57c) = 0xff2008c6;
    piVar11[0xb0] = -0xf1f1f006f7f80;
    *(undefined4 *)(piVar11 + 0xbc) = 0xbf800000;
    ppiVar15 = *(int64_t ***)0x18077afe8;
    if (*(int64_t ***)0x18077afe8 != *(int64_t ***)0x18077aff0) {
        **(int64_t ***)0x18077afe8 = unaff_R15;
        ppiVar15[1] = (int64_t *)unaff_RBX;
        ppiVar15[2] = piVar28;
        ppiVar15[3] = (int64_t *)var_130h;
        ppiVar15[4] = piVar11;
        *(undefined *)(ppiVar15 + 5) = 1;
        *(int64_t ***)0x18077afe8 = *(int64_t ***)0x18077afe8 + 6;
        goto code_r0x0001800757d4;
    }
    iVar12 = ((int64_t)*(int64_t ***)0x18077afe8 - (int64_t)*(int64_t ***)0x18077afe0) / 6 +
             ((int64_t)*(int64_t ***)0x18077afe8 - (int64_t)*(int64_t ***)0x18077afe0 >> 0x3f);
    iVar12 = (iVar12 >> 3) - (iVar12 >> 0x3f);
    if (iVar12 == 0x555555555555555) {
        *(undefined8 *)(puVar19 + -8) = 0x180075850;
        func_0x000180010010();
code_r0x000180075851:
        *(undefined8 *)(puVar19 + -8) = 0x180075856;
        func_0x000180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar22 = ((int64_t)*(int64_t ***)0x18077aff0 - (int64_t)*(int64_t ***)0x18077afe0 >> 4) * -0x5555555555555555;
    uVar16 = 0x555555555555555 - (uVar22 >> 1);
    if (uVar16 <= uVar22 && uVar22 - uVar16 != 0) goto code_r0x000180075851;
    uVar16 = iVar12 + 1;
    uVar22 = (uVar22 >> 1) + uVar22;
    uVar13 = uVar16;
    if (uVar16 <= uVar22) {
        uVar13 = uVar22;
    }
    if (0x555555555555555 < uVar13) goto code_r0x000180075851;
    uVar22 = uVar13 * 0x30;
    if (uVar22 == 0) {
        ppiVar20 = (int64_t **)0x0;
code_r0x0001800756cb:
        iVar10 = iVar12 * 0x30;
        ppiVar20[iVar12 * 6] = (int64_t *)var_148h;
        ppiVar20[iVar12 * 6 + 1] = (int64_t *)unaff_RBX;
        ppiVar20[iVar12 * 6 + 2] = (int64_t *)var_138h;
        ppiVar20[iVar12 * 6 + 3] = (int64_t *)var_130h;
        ppiVar20[iVar12 * 6 + 4] = piVar11;
        *(undefined *)(ppiVar20 + iVar12 * 6 + 5) = 1;
        ppiVar14 = *(int64_t ***)0x18077afe0;
        ppiVar23 = ppiVar20;
        if (ppiVar15 != *(int64_t ***)0x18077afe8) {
            *(undefined8 *)(puVar19 + -8) = 0x18007571b;
            func_0x00018007ef30(*(int64_t ***)0x18077afe0, ppiVar15, ppiVar20);
            ppiVar23 = (int64_t **)(iVar10 + 0x30 + (int64_t)ppiVar20);
            ppiVar14 = ppiVar15;
        }
        *(undefined8 *)(puVar19 + -8) = 0x180075731;
        func_0x00018007ef30(ppiVar14, *(int64_t ***)0x18077afe8, ppiVar23);
        if (*(int64_t ***)0x18077afe0 != (int64_t **)0x0) {
            *(undefined8 *)(puVar19 + -8) = 0x180075749;
            func_0x00018007d5c0(*(int64_t ***)0x18077afe0, *(int64_t ***)0x18077afe8);
            ppiVar15 = *(int64_t ***)0x18077afe0;
            if ((0xfff < (uint64_t)(((int64_t)*(int64_t ***)0x18077aff0 - (int64_t)*(int64_t ***)0x18077afe0 >> 4) << 4)
                ) && (ppiVar15 = (int64_t **)(*(int64_t ***)0x18077afe0)[-1],
                     0x1f < (uint64_t)((int64_t)*(int64_t ***)0x18077afe0 + (-8 - (int64_t)ppiVar15))))
            goto code_r0x000180075794;
            goto code_r0x00018007579e;
        }
    } else {
        if (uVar22 < 0x1000) {
            *(undefined8 *)(puVar19 + -8) = 0x1800756c8;
            ppiVar20 = (int64_t **)func_0x000180459890(uVar22);
            goto code_r0x0001800756cb;
        }
        if (uVar22 + 0x27 <= uVar22) goto code_r0x000180075851;
        *(undefined8 *)(puVar19 + -8) = 0x1800756a9;
        piVar28 = (int64_t *)func_0x000180459890();
        if (piVar28 != (int64_t *)0x0) {
            ppiVar20 = (int64_t **)((int64_t)piVar28 + 0x27U & 0xffffffffffffffe0);
            ppiVar20[-1] = piVar28;
            goto code_r0x0001800756cb;
        }
code_r0x000180075794:
        ppiVar15 = (int64_t **)0x5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar19 = puVar19 + 8;
code_r0x00018007579e:
        *(undefined8 *)(puVar19 + -8) = 0x1800757a6;
        func_0x000180459c3c(ppiVar15);
    }
    *(int64_t ***)0x18077afe8 = ppiVar20 + uVar16 * 6;
    *(int64_t ***)0x18077aff0 = ppiVar20 + uVar13 * 6;
    *(int64_t ***)0x18077afe0 = ppiVar20;
code_r0x0001800757d4:
    *(int32_t *)0x1807824e4 =
         (int32_t)((int64_t)*(int64_t ***)0x18077afe8 - (int64_t)*(int64_t ***)0x18077afe0 >> 4) * -0x55555555 + -1;
    *(undefined *)0x1807824e8 = 1;
    if (var_158h != 0) {
        pcVar1 = *(code **)(*(int64_t *)var_158h + 0x20);
        *(undefined8 *)(puVar19 + -8) = 0x18007580e;
        (*pcVar1)(var_158h, CONCAT71((unkint7)((uint64_t)&var_190h >> 8), (int64_t *)var_158h != &var_190h));
        var_158h = 0;
    }
    *(undefined8 *)(puVar19 + -8) = 0x18007581f;
    func_0x000180004e40(&var_1b0h);
    *(undefined8 *)(puVar19 + -8) = 0x18007582f;
    func_0x000180459870(var_60h ^ (uint64_t)puVar19);
    return;
}

// ============================================================
// Function: FUN_180075860
// Address: 0x180075860
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180075860(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar1 = *(int64_t *)(arg1 + 0x20);
    if (iVar1 != 0) {
        func_0x00018007dab0(iVar1);
        func_0x000180459c3c(iVar1, 0x5f0);
    }
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar1 = *(int64_t *)arg1;
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x18) + 1) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180004e88;
        func_0x000180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    return;
}

// ============================================================
// Function: FUN_1800758a0
// Address: 0x1800758a0
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800758a0(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined *puVar5;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    piVar2 = *(int64_t **)(arg1 + 0x70);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != (int64_t *)(arg1 + 0x38));
        *(undefined8 *)(arg1 + 0x70) = 0;
    }
    if (0xf < *(uint64_t *)(arg1 + 0x30)) {
        iVar1 = *(int64_t *)(arg1 + 0x18);
        iVar4 = iVar1;
        puVar5 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x30) + 1) &&
           (iVar4 = *(int64_t *)(iVar1 + -8), puVar5 = auStack_28, 0x1f < (iVar1 - iVar4) - 8U)) {
            pcVar3 = (code *)swi(0x29);
            iVar4 = (*pcVar3)(5);
            puVar5 = auStack_20;
        }
        *(undefined8 *)(puVar5 + -8) = 0x180004e88;
        func_0x000180459c3c(iVar4);
    }
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 0x18) = 0;
    return;
}

// ============================================================
// Function: FUN_1800758f0
// Address: 0x1800758f0
// Size: 1331 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800759e9)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_2h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Removing arg arg_2098h because it doesn't fit into ProtoModel

void fcn.1800758f0(int64_t arg_28h, int64_t arg_38h)
{
    uint64_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined4 *puVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 *in_RCX;
    undefined8 *puVar9;
    undefined8 *puVar10;
    uint64_t uVar11;
    undefined8 *in_RDX;
    int64_t iVar12;
    undefined8 *puVar13;
    uint64_t uVar14;
    undefined *puVar15;
    undefined *puVar16;
    undefined4 uVar17;
    undefined4 in_R8D;
    uint64_t uVar18;
    undefined8 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_1054h;
    int32_t var_54h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_18h;
    
    uStack_40 = 0x180075912;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    puVar16 = &stack0xffffffffffffffc8 + iVar4;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar4);
    *(undefined4 *)((int64_t)&var_18h + iVar4) = in_R8D;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075939;
    piVar5 = (int64_t *)func_0x000180016e80();
    puVar10 = (undefined8 *)*piVar5;
    *(undefined (*) [16])((int64_t)&var_10h + iVar4) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18007594e;
    puVar6 = (undefined4 *)func_0x000180459890(0x20);
    *(undefined4 **)((int64_t)&var_10h + iVar4) = puVar6;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = 0x15;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0x1f;
    *puVar6 = 0x61736944;
    puVar6[1] = 0x20656c62;
    puVar6[2] = 0x69746f4e;
    puVar6[3] = 0x61636966;
    *(undefined8 *)((int64_t)puVar6 + 0xd) = 0x736e6f6974616369;
    *(undefined *)((int64_t)puVar6 + 0x15) = 0;
    *(undefined2 *)(&stack0xfffffffffffffffe + iVar4) = 0;
    *(undefined8 *)(&stack0x00000000 + iVar4) = 0xe;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0xf;
    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4) = 0x746e492072657355;
    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = 0x61667265;
    *(undefined2 *)(&stack0xfffffffffffffffc + iVar4) = 0x6563;
    puVar13 = (undefined8 *)puVar10[1];
    for (puVar10 = (undefined8 *)*puVar10; puVar10 != puVar13; puVar10 = puVar10 + 7) {
        puVar9 = puVar10;
        if (0xf < (uint64_t)puVar10[3]) {
            puVar9 = (undefined8 *)*puVar10;
        }
        if (puVar10[2] == 0xe) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075a10;
            iVar3 = func_0x000180497f30(puVar9, &stack0xfffffffffffffff0 + iVar4);
            if (iVar3 == 0) {
                if (puVar10 != (undefined8 *)0x0) {
                    puVar13 = (undefined8 *)puVar10[4];
                    puVar10 = (undefined8 *)puVar10[5];
                    goto joined_r0x000180075a34;
                }
                break;
            }
        }
    }
code_r0x000180075a67:
    puVar13 = (undefined8 *)0x0;
code_r0x000180075a69:
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075a76;
    func_0x000180459c3c(puVar6, 0x20);
    if (puVar13 != (undefined8 *)0x0) {
        if (*(char *)(puVar13 + 0xc) != '\0') {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075e22;
            func_0x000180016af0();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        puVar15 = &stack0xffffffffffffffc8 + iVar4;
        if (*(char *)(puVar13 + 8) != '\0') goto code_r0x000180075a8b;
    }
    uVar14 = in_RCX[2];
    uVar11 = in_RCX[3];
    puVar10 = in_RCX;
    if (0xf < uVar11) {
        puVar10 = (undefined8 *)*in_RCX;
    }
    if (uVar14 == 7) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075ade;
        iVar3 = func_0x000180497f30(puVar10, 0x180623810, 7);
        if (iVar3 != 0) goto code_r0x000180075aec;
        uVar17 = 1;
    } else {
code_r0x000180075aec:
        puVar10 = in_RCX;
        if (0xf < uVar11) {
            puVar10 = (undefined8 *)*in_RCX;
        }
        if (uVar14 == 7) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075b0d;
            iVar3 = func_0x000180497f30(puVar10, 0x18063cc68, 7);
            if (iVar3 == 0) {
                uVar17 = 2;
                goto code_r0x000180075b6e;
            }
        }
        puVar10 = in_RCX;
        if (0xf < uVar11) {
            puVar10 = (undefined8 *)*in_RCX;
        }
        if (uVar14 == 5) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075b39;
            iVar3 = func_0x000180497f30(puVar10, 0x18062a8bc, 5);
            if (iVar3 == 0) {
                uVar17 = 3;
                goto code_r0x000180075b6e;
            }
        }
        uVar17 = 0;
        if (0xf < uVar11) {
            in_RCX = (undefined8 *)*in_RCX;
        }
        if (uVar14 == 4) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075b67;
            iVar3 = func_0x000180497f30(in_RCX, 0x1805aaf70, 4);
            if (iVar3 == 0) {
                uVar17 = 4;
            }
        }
    }
code_r0x000180075b6e:
    var_50h = 0;
    *(undefined4 *)((int64_t)&arg_38h + iVar4) = uVar17;
    var_54h = *(int32_t *)((int64_t)&var_18h + iVar4) * 200;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075b95;
    piVar5 = (int64_t *)func_0x000180013b20((int64_t)&var_18h + iVar4);
    var_50h = *piVar5 / 1000000;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075bcc;
    func_0x0001804986e0((int64_t)&arg_38h + iVar4 + 4, 0, 0x1000);
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075be0;
    func_0x0001804986e0(&var_1054h, 0, 0x1000);
    if (in_R9[2] != 0) {
        if (0xf < (uint64_t)in_R9[3]) {
            in_R9 = (undefined8 *)*in_R9;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075c08;
        func_0x0001800665b0((int64_t)&arg_38h + iVar4, 0x18063cc8c, in_R9);
    }
    if (0xf < (uint64_t)in_RDX[3]) {
        in_RDX = (undefined8 *)*in_RDX;
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075c27;
    func_0x000180066620((int64_t)&arg_38h + iVar4, 0x18063cc8c, in_RDX);
    uVar11 = *(uint64_t *)0x18077b000;
    if (*(uint64_t *)0x18077b000 != *(uint64_t *)0x18077b008) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075c4d;
        func_0x000180498030(*(uint64_t *)0x18077b000, (int64_t)&arg_38h + iVar4, 0x2010);
        *(uint64_t *)0x18077b000 = *(uint64_t *)0x18077b000 + 0x2010;
        puVar15 = &stack0xffffffffffffffc8 + iVar4;
        goto code_r0x000180075a8b;
    }
    iVar12 = (int64_t)(*(uint64_t *)0x18077b000 - *(uint64_t *)0x18077aff8) / 0x402 +
             ((int64_t)(*(uint64_t *)0x18077b000 - *(uint64_t *)0x18077aff8) >> 0x3f);
    iVar12 = (iVar12 >> 3) - (iVar12 >> 0x3f);
    if (iVar12 == 0x7fc01ff007fc0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075e16;
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = iVar12 + 1;
    uVar18 = ((int64_t)(*(uint64_t *)0x18077b008 - *(uint64_t *)0x18077aff8) >> 4) * -0x7fc01ff007fc01ff;
    uVar7 = 0x7fc01ff007fc0 - (uVar18 >> 1);
    if (uVar18 < uVar7 || uVar18 - uVar7 == 0) {
        uVar18 = uVar18 + (uVar18 >> 1);
        uVar7 = uVar1;
        if (uVar1 <= uVar18) {
            uVar7 = uVar18;
        }
        if (0x7fc01ff007fc0 < uVar7) {
code_r0x000180075e17:
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075e1c;
            func_0x000180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar7 = uVar7 * 0x2010;
        if (uVar7 == 0) {
            uVar14 = 0;
        } else {
            if (0xfff < uVar7) {
                uVar18 = uVar7 + 0x27;
                if (uVar18 <= uVar7) goto code_r0x000180075e17;
                goto code_r0x000180075d0f;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075d33;
            uVar14 = func_0x000180459890(uVar7);
        }
code_r0x000180075d36:
        iVar12 = iVar12 * 0x2010 + uVar14;
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075d53;
        func_0x000180498030(iVar12, (int64_t)&arg_38h + iVar4, 0x2010);
        if (uVar11 == *(uint64_t *)0x18077b000) {
            iVar8 = *(uint64_t *)0x18077b000 - *(uint64_t *)0x18077aff8;
            uVar18 = uVar14;
            uVar11 = *(uint64_t *)0x18077aff8;
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075d79;
            func_0x000180498030(uVar14, *(uint64_t *)0x18077aff8, uVar11 - *(uint64_t *)0x18077aff8);
            iVar8 = *(uint64_t *)0x18077b000 - uVar11;
            uVar18 = iVar12 + 0x2010;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075d92;
        func_0x000180498030(uVar18, uVar11, iVar8);
        if (*(uint64_t *)0x18077aff8 != 0) {
            uVar11 = *(uint64_t *)0x18077aff8;
            puVar16 = &stack0xffffffffffffffc8 + iVar4;
            if ((0xfff < (uint64_t)(((int64_t)(*(uint64_t *)0x18077b008 - *(uint64_t *)0x18077aff8) >> 4) * 0x10)) &&
               (uVar11 = *(uint64_t *)(*(uint64_t *)0x18077aff8 - 8), puVar16 = &stack0xffffffffffffffc8 + iVar4,
               0x1f < (*(uint64_t *)0x18077aff8 - *(uint64_t *)(*(uint64_t *)0x18077aff8 - 8)) - 8))
            goto code_r0x000180075dd7;
            goto code_r0x000180075de1;
        }
    } else {
        uVar7 = 0xfffffffffffffc00;
        uVar18 = 0xfffffffffffffc27;
code_r0x000180075d0f:
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075d14;
        iVar8 = func_0x000180459890(uVar18);
        if (iVar8 != 0) {
            uVar14 = iVar8 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar14 - 8) = iVar8;
            goto code_r0x000180075d36;
        }
code_r0x000180075dd7:
        uVar11 = 5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar16 = &stack0xffffffffffffffd0 + iVar4;
code_r0x000180075de1:
        *(undefined8 *)(puVar16 + -8) = 0x180075de9;
        func_0x000180459c3c(uVar11);
    }
    *(uint64_t *)0x18077b000 = uVar1 * 0x2010 + uVar14;
    *(uint64_t *)0x18077b008 = uVar7 + uVar14;
    puVar15 = puVar16;
    *(uint64_t *)0x18077aff8 = uVar14;
code_r0x000180075a8b:
    *(undefined8 *)(puVar15 + -8) = 0x180075a9a;
    func_0x000180459870(var_48h ^ (uint64_t)puVar15);
    return;
joined_r0x000180075a34:
    if (puVar13 == puVar10) goto code_r0x000180075a67;
    puVar9 = puVar13;
    if (0xf < (uint64_t)puVar13[3]) {
        puVar9 = (undefined8 *)*puVar13;
    }
    if (puVar13[2] == 0x15) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180075a57;
        iVar3 = func_0x000180497f30(puVar9, puVar6);
        if (iVar3 == 0) goto code_r0x000180075a69;
    }
    puVar13 = puVar13 + 0x13;
    goto joined_r0x000180075a34;
}

// ============================================================
// Function: FUN_180075e30
// Address: 0x180075e30
// Size: 474 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_198h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_151h
// WARNING: [rz-ghidra] Detected overlap for variable var_152h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_b1h
// WARNING: [rz-ghidra] Detected overlap for variable var_b2h

void fcn.180075e30(int64_t arg1)
{
    undefined uVar1;
    int64_t iVar2;
    float fVar3;
    char in_DL;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t var_198h;
    int64_t var_188h;
    undefined var_154h;
    undefined var_152h;
    undefined2 var_151h;
    int64_t var_14eh;
    int64_t var_12ch;
    int64_t var_11ch;
    int64_t var_114h;
    int64_t var_e8h;
    undefined var_b4h;
    undefined var_b2h;
    undefined2 var_b1h;
    int64_t var_aeh;
    int64_t var_8ch;
    int64_t var_7ch;
    int64_t var_74h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar2 = *(int64_t *)(arg1 + 0x38);
    uVar1 = *(undefined *)(iVar2 + 0x51);
    *(undefined *)(iVar2 + 0x51) = 0;
    func_0x000180127250(iVar2);
    func_0x0001801271e0(iVar2);
    fVar3 = *(float *)0x1806a4600;
    *(undefined *)(iVar2 + 0x51) = uVar1;
    uVar4 = func_0x00018046e060(*(float *)0x1806a4604 * fVar3);
    func_0x0001804986e0(&var_188h, 0, 0xa0);
    var_114h._0_4_ = 0x3f800000;
    var_14eh._0_2_ = 0;
    var_154h = 0;
    var_12ch._0_4_ = 0x7f7fffff;
    var_11ch._0_4_ = 0x3f800000;
    var_11ch._4_4_ = 0x3f800000;
    var_151h = 0x102;
    var_152h = 1;
    func_0x0001804986e0(&var_e8h, 0, 0xa0);
    var_74h._0_4_ = 0x3f800000;
    var_8ch._0_4_ = 0x7f7fffff;
    var_7ch._0_4_ = 0x3f800000;
    var_7ch._4_4_ = 0x3f800000;
    var_aeh._0_2_ = 0;
    var_b4h = 0;
    var_b1h = 0x102;
    var_b2h = 1;
    uVar5 = func_0x00018046e060(fVar3 * 17.0);
    *(int64_t *)0x1807824d8 = func_0x0001801279b0(*(undefined8 *)(arg1 + 0x38), 0x1806a4610, 0x53a98, uVar5, &var_188h);
    *(int64_t *)0x1807824d0 = func_0x0001801279b0(*(undefined8 *)(arg1 + 0x38), 0x1806f80b0, 0x46b58, uVar4, &var_e8h);
    if (*(int64_t *)0x1807824d8 == 0) {
        *(int64_t *)0x1807824d8 = func_0x000180127690(*(undefined8 *)(arg1 + 0x38), 0);
    }
    if (*(int64_t *)0x1807824d0 == 0) {
        *(int64_t *)0x1807824d0 = *(int64_t *)0x1807824d8;
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)0x1807824d8;
    if (in_DL != '\0') {
        func_0x0001801671d0();
        func_0x000180166d80();
    }
    return;
}

// ============================================================
// Function: FUN_180076010
// Address: 0x180076010
// Size: 515 bytes
// ============================================================
void fcn.180076010(void)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    undefined8 *puVar14;
    int64_t var_d0h;
    undefined auStack_c8 [8];
    undefined auStack_c0 [24];
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    puVar12 = auStack_c8;
    var_68h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    piVar8 = (int64_t *)func_0x000180016e80();
    puVar11 = (undefined8 *)*piVar8;
    _var_88h = ZEXT816(0);
    var_78h = 0;
    var_70h = 0;
    func_0x000180004830(&var_88h, 0x18063d038, 0x10);
    _var_a8h = ZEXT816(0);
    var_98h = 0;
    var_90h = 0;
    func_0x000180004830(&var_a8h, 0x1806202c8, 0xe);
    iVar6 = var_70h;
    iVar4 = var_90h;
    iVar3 = var_98h;
    puVar14 = (undefined8 *)*puVar11;
    puVar11 = (undefined8 *)puVar11[1];
    iVar5 = var_88h;
    iVar2 = var_a8h;
    for (; puVar14 != puVar11; puVar14 = puVar14 + 7) {
        piVar8 = &var_a8h;
        if (0xf < (uint64_t)iVar4) {
            piVar8 = (int64_t *)iVar2;
        }
        puVar9 = puVar14;
        if (0xf < (uint64_t)puVar14[3]) {
            puVar9 = (undefined8 *)*puVar14;
        }
        if ((puVar14[2] == iVar3) && ((puVar14[2] == 0 || (iVar7 = func_0x000180497f30(puVar9, piVar8), iVar7 == 0)))) {
            iVar3 = var_78h;
            if (puVar14 != (undefined8 *)0x0) {
                puVar11 = (undefined8 *)puVar14[4];
                puVar14 = (undefined8 *)puVar14[5];
                goto joined_r0x000180076110;
            }
            break;
        }
    }
code_r0x000180076162:
    if (0xf < (uint64_t)iVar4) {
        uVar10 = iVar2;
        puVar12 = auStack_c8;
        if (0xfff < iVar4 + 1U) {
            uVar10 = *(uint64_t *)(iVar2 + -8);
            uVar13 = (iVar2 - uVar10) - 8;
            puVar12 = auStack_c8;
            if (0x1f < uVar13) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                uVar10 = uVar13;
                puVar12 = auStack_c0;
            }
        }
        *(undefined8 *)(puVar12 + -8) = 0x18007619b;
        func_0x000180459c3c(uVar10);
    }
    if (0xf < (uint64_t)iVar6) {
        uVar10 = iVar5;
        if (0xfff < iVar6 + 1U) {
            uVar10 = *(uint64_t *)(iVar5 + -8);
            uVar13 = (iVar5 - uVar10) - 8;
            if (0x1f < uVar13) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar12 = puVar12 + 8;
                uVar10 = uVar13;
            }
        }
        *(undefined8 *)(puVar12 + -8) = 0x1800761d5;
        func_0x000180459c3c(uVar10);
    }
    *(undefined8 *)(puVar12 + -8) = 0x1800761fa;
    func_0x000180459870(*(uint64_t *)(puVar12 + 0x60) ^ (uint64_t)puVar12);
    return;
joined_r0x000180076110:
    if (puVar11 == puVar14) goto code_r0x000180076162;
    piVar8 = &var_88h;
    if (0xf < (uint64_t)iVar6) {
        piVar8 = (int64_t *)iVar5;
    }
    puVar9 = puVar11;
    if (0xf < (uint64_t)puVar11[3]) {
        puVar9 = (undefined8 *)*puVar11;
    }
    if ((puVar11[2] == iVar3) && ((puVar11[2] == 0 || (iVar7 = func_0x000180497f30(puVar9, piVar8), iVar7 == 0))))
    goto code_r0x000180076162;
    puVar11 = puVar11 + 0x13;
    goto joined_r0x000180076110;
}

// ============================================================
// Function: FUN_180076220
// Address: 0x180076220
// Size: 2213 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_151h
// WARNING: [rz-ghidra] Detected overlap for variable var_152h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_b1h
// WARNING: [rz-ghidra] Detected overlap for variable var_b2h
// WARNING: [rz-ghidra] Detected overlap for variable var_63h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c7h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c6h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c5h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c0h

void fcn.180076220(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined4 in_XMM1_Da;
    int64_t var_8h;
    
    *(uint32_t *)arg1 = *(uint32_t *)arg1 | 0xa0;
    *(undefined8 *)(arg1 + 0x20) = 0x180782220;
    *(undefined *)(arg1 + 0x52) = 0;
    *(undefined4 *)(arg1 + 0x1c) = 0x3f800000;
    iVar1 = *(int64_t *)0x180781f28 + 0xd90;
    *(undefined4 *)0x1806a4600 = in_XMM1_Da;
    func_0x0001800f4910();
    *(undefined4 *)(iVar1 + 0x1c) = 0x40400000;
    *(undefined4 *)(iVar1 + 0x28) = 0x43af0000;
    *(undefined4 *)(iVar1 + 0x2c) = 0x43340000;
    *(undefined4 *)(iVar1 + 0x3c) = 0x40400000;
    *(undefined4 *)(iVar1 + 0x54) = 0x40400000;
    *(undefined4 *)(iVar1 + 0xa4) = 0x40400000;
    *(undefined4 *)(iVar1 + 0x140) = 0x3f6bebec;
    *(undefined4 *)(iVar1 + 0x144) = 0x3f6bebec;
    *(undefined4 *)(iVar1 + 0x148) = 0x3f6bebec;
    *(undefined4 *)(iVar1 + 0x14c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x150) = 0x3f119192;
    *(undefined4 *)(iVar1 + 0x154) = 0x3f119192;
    *(undefined4 *)(iVar1 + 0x158) = 0x3f119192;
    *(undefined4 *)(iVar1 + 0x15c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x160) = 0x3df0f0f1;
    *(undefined4 *)(iVar1 + 0x164) = 0x3df0f0f1;
    *(undefined4 *)(iVar1 + 0x168) = 0x3df0f0f1;
    *(undefined4 *)(iVar1 + 0x16c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x170) = 0x3e109091;
    *(undefined4 *)(iVar1 + 0x174) = 0x3e109091;
    *(undefined4 *)(iVar1 + 0x178) = 0x3e109091;
    *(undefined4 *)(iVar1 + 0x17c) = 0x3f75f5f6;
    *(undefined4 *)(iVar1 + 0x180) = 0x3e189899;
    *(undefined4 *)(iVar1 + 0x184) = 0x3e189899;
    *(undefined4 *)(iVar1 + 0x188) = 0x3e189899;
    *(undefined4 *)(iVar1 + 0x18c) = 0x3f75f5f6;
    *(undefined4 *)(iVar1 + 400) = 0x3e909091;
    *(undefined4 *)(iVar1 + 0x194) = 0x3e909091;
    *(undefined4 *)(iVar1 + 0x198) = 0x3e909091;
    *(undefined8 *)(iVar1 + 0x19c) = 0x3f20a0a1;
    *(undefined8 *)(iVar1 + 0x1a4) = 0;
    *(undefined4 *)(iVar1 + 0x1ac) = 0;
    *(undefined4 *)(iVar1 + 0x1b0) = 0x3e50d0d1;
    *(undefined4 *)(iVar1 + 0x1b4) = 0x3e50d0d1;
    *(undefined4 *)(iVar1 + 0x1b8) = 0x3e50d0d1;
    *(undefined4 *)(iVar1 + 0x1bc) = 0x3f66e6e7;
    *(undefined4 *)(iVar1 + 0x1c0) = 0x3e848485;
    *(undefined4 *)(iVar1 + 0x1c4) = 0x3e848485;
    *(undefined4 *)(iVar1 + 0x1c8) = 0x3e848485;
    *(undefined4 *)(iVar1 + 0x1cc) = 0x3f66e6e7;
    *(undefined4 *)(iVar1 + 0x1d0) = 0x3ea4a4a5;
    *(undefined4 *)(iVar1 + 0x1d4) = 0x3ea4a4a5;
    *(undefined4 *)(iVar1 + 0x1d8) = 0x3ea4a4a5;
    *(undefined4 *)(iVar1 + 0x1dc) = 0x3f66e6e7;
    *(undefined4 *)(iVar1 + 0x1e0) = 0x3de0e0e1;
    *(undefined4 *)(iVar1 + 0x1e4) = 0x3de0e0e1;
    *(undefined4 *)(iVar1 + 0x1e8) = 0x3de0e0e1;
    *(undefined4 *)(iVar1 + 0x1ec) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x1f0) = 0x3e20a0a1;
    *(undefined4 *)(iVar1 + 500) = 0x3e20a0a1;
    *(undefined4 *)(iVar1 + 0x1f8) = 0x3e20a0a1;
    *(undefined4 *)(iVar1 + 0x1fc) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x200) = 0x3dc0c0c1;
    *(undefined4 *)(iVar1 + 0x204) = 0x3dc0c0c1;
    *(undefined4 *)(iVar1 + 0x208) = 0x3dc0c0c1;
    *(undefined4 *)(iVar1 + 0x20c) = 0x3f3ebebf;
    *(undefined4 *)(iVar1 + 0x210) = 0x3e109091;
    *(undefined4 *)(iVar1 + 0x214) = 0x3e109091;
    *(undefined4 *)(iVar1 + 0x218) = 0x3e109091;
    *(undefined4 *)(iVar1 + 0x21c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x220) = 0x3dc0c0c1;
    *(undefined4 *)(iVar1 + 0x224) = 0x3dc0c0c1;
    *(undefined4 *)(iVar1 + 0x228) = 0x3dc0c0c1;
    *(undefined4 *)(iVar1 + 0x22c) = 0x3f0c8c8d;
    *(undefined4 *)(iVar1 + 0x230) = 0x3eb0b0b1;
    *(undefined4 *)(iVar1 + 0x234) = 0x3eb0b0b1;
    *(undefined4 *)(iVar1 + 0x238) = 0x3eb0b0b1;
    *(undefined4 *)(iVar1 + 0x23c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x240) = 0x3ed8d8d9;
    *(undefined4 *)(iVar1 + 0x244) = 0x3ed8d8d9;
    *(undefined4 *)(iVar1 + 0x248) = 0x3ed8d8d9;
    *(undefined4 *)(iVar1 + 0x24c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x250) = 0x3f008081;
    *(undefined4 *)(iVar1 + 0x254) = 0x3f008081;
    *(undefined4 *)(iVar1 + 600) = 0x3f008081;
    *(undefined4 *)(iVar1 + 0x25c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x260) = 0x3f66e6e7;
    *(undefined4 *)(iVar1 + 0x264) = 0x3f66e6e7;
    *(undefined4 *)(iVar1 + 0x268) = 0x3f66e6e7;
    *(undefined4 *)(iVar1 + 0x26c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x270) = 0x3f078788;
    *(undefined4 *)(iVar1 + 0x274) = 0x3f078788;
    *(undefined4 *)(iVar1 + 0x278) = 0x3f078788;
    *(undefined4 *)(iVar1 + 0x27c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x280) = 0x3f2aaaab;
    *(undefined4 *)(iVar1 + 0x284) = 0x3f2aaaab;
    *(undefined4 *)(iVar1 + 0x288) = 0x3f2aaaab;
    *(undefined4 *)(iVar1 + 0x28c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x290) = 0x3e9c9c9d;
    *(undefined4 *)(iVar1 + 0x294) = 0x3e9c9c9d;
    *(undefined4 *)(iVar1 + 0x298) = 0x3e9c9c9d;
    *(undefined4 *)(iVar1 + 0x29c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x2a0) = 0x3ec0c0c1;
    *(undefined4 *)(iVar1 + 0x2a4) = 0x3ec0c0c1;
    *(undefined4 *)(iVar1 + 0x2a8) = 0x3ec0c0c1;
    *(undefined4 *)(iVar1 + 0x2ac) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x2b0) = 0x3ee8e8e9;
    *(undefined4 *)(iVar1 + 0x2b4) = 0x3ee8e8e9;
    *(undefined4 *)(iVar1 + 0x2b8) = 0x3ee8e8e9;
    *(undefined4 *)(iVar1 + 700) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x2c0) = 0x3e68e8e9;
    *(undefined4 *)(iVar1 + 0x2c4) = 0x3e68e8e9;
    *(undefined4 *)(iVar1 + 0x2c8) = 0x3e68e8e9;
    *(undefined4 *)(iVar1 + 0x2cc) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x2d0) = 0x3e989899;
    *(undefined4 *)(iVar1 + 0x2d4) = 0x3e989899;
    *(undefined4 *)(iVar1 + 0x2d8) = 0x3e989899;
    *(undefined4 *)(iVar1 + 0x2dc) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x2e0) = 0x3ec0c0c1;
    *(undefined4 *)(iVar1 + 0x2e4) = 0x3ec0c0c1;
    *(undefined4 *)(iVar1 + 0x2e8) = 0x3ec0c0c1;
    *(undefined4 *)(iVar1 + 0x2ec) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x2f0) = 0x3e9c9c9d;
    *(undefined4 *)(iVar1 + 0x2f4) = 0x3e9c9c9d;
    *(undefined4 *)(iVar1 + 0x2f8) = 0x3e9c9c9d;
    *(undefined4 *)(iVar1 + 0x2fc) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x300) = 0x3edcdcdd;
    *(undefined4 *)(iVar1 + 0x304) = 0x3edcdcdd;
    *(undefined4 *)(iVar1 + 0x308) = 0x3edcdcdd;
    *(undefined4 *)(iVar1 + 0x30c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x310) = 0x3f078788;
    *(undefined4 *)(iVar1 + 0x314) = 0x3f078788;
    *(undefined4 *)(iVar1 + 0x318) = 0x3f078788;
    *(undefined4 *)(iVar1 + 0x31c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 800) = 0x3edcdcdd;
    *(undefined4 *)(iVar1 + 0x324) = 0x3edcdcdd;
    *(undefined4 *)(iVar1 + 0x328) = 0x3edcdcdd;
    *(undefined4 *)(iVar1 + 0x32c) = 0x3eb4b4b5;
    *(undefined4 *)(iVar1 + 0x330) = 0x3f119192;
    *(undefined4 *)(iVar1 + 0x334) = 0x3f119192;
    *(undefined4 *)(iVar1 + 0x338) = 0x3f119192;
    *(undefined4 *)(iVar1 + 0x33c) = 0x3f2aaaab;
    *(undefined4 *)(iVar1 + 0x340) = 0x3f2fafb0;
    *(undefined4 *)(iVar1 + 0x344) = 0x3f2fafb0;
    *(undefined4 *)(iVar1 + 0x348) = 0x3f2fafb0;
    *(undefined4 *)(iVar1 + 0x34c) = 0x3f5cdcdd;
    *(undefined4 *)(iVar1 + 0x350) = 0x3f6bebec;
    *(undefined4 *)(iVar1 + 0x354) = 0x3f6bebec;
    *(undefined4 *)(iVar1 + 0x358) = 0x3f6bebec;
    *(undefined4 *)(iVar1 + 0x35c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x370) = 0x3e30b0b1;
    *(undefined4 *)(iVar1 + 0x374) = 0x3e30b0b1;
    *(undefined4 *)(iVar1 + 0x378) = 0x3e30b0b1;
    *(undefined4 *)(iVar1 + 0x37c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x360) = 0x3e8c8c8d;
    *(undefined4 *)(iVar1 + 0x364) = 0x3e8c8c8d;
    *(undefined4 *)(iVar1 + 0x368) = 0x3e8c8c8d;
    *(undefined4 *)(iVar1 + 0x36c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x380) = 0x3e78f8f9;
    *(undefined4 *)(iVar1 + 900) = 0x3e78f8f9;
    *(undefined4 *)(iVar1 + 0x388) = 0x3e78f8f9;
    *(undefined4 *)(iVar1 + 0x38c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x390) = 0x3f2aaaab;
    *(undefined4 *)(iVar1 + 0x394) = 0x3f2aaaab;
    *(undefined4 *)(iVar1 + 0x398) = 0x3f2aaaab;
    *(undefined4 *)(iVar1 + 0x39c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x3a0) = 0x3e189899;
    *(undefined4 *)(iVar1 + 0x3a4) = 0x3e189899;
    *(undefined4 *)(iVar1 + 0x3a8) = 0x3e189899;
    *(undefined4 *)(iVar1 + 0x3ac) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x3b0) = 0x3e58d8d9;
    *(undefined4 *)(iVar1 + 0x3b4) = 0x3e58d8d9;
    *(undefined4 *)(iVar1 + 0x3b8) = 0x3e58d8d9;
    *(undefined8 *)(iVar1 + 0x3bc) = 0x3f800000;
    *(undefined8 *)(iVar1 + 0x3c4) = 0;
    *(undefined4 *)(iVar1 + 0x3cc) = 0;
    *(undefined4 *)(iVar1 + 0x3d0) = 0x3f52d2d3;
    *(undefined4 *)(iVar1 + 0x3d4) = 0x3f52d2d3;
    *(undefined4 *)(iVar1 + 0x3d8) = 0x3f52d2d3;
    *(undefined4 *)(iVar1 + 0x3dc) = 0x3eb4b4b5;
    *(undefined4 *)(iVar1 + 0x3e0) = 0x3e109091;
    *(undefined4 *)(iVar1 + 0x3e4) = 0x3e109091;
    *(undefined4 *)(iVar1 + 1000) = 0x3e109091;
    *(undefined4 *)(iVar1 + 0x3ec) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x430) = 0x3e40c0c1;
    *(undefined4 *)(iVar1 + 0x434) = 0x3e40c0c1;
    *(undefined4 *)(iVar1 + 0x438) = 0x3e40c0c1;
    *(undefined4 *)(iVar1 + 0x43c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x440) = 0x3e9c9c9d;
    *(undefined4 *)(iVar1 + 0x444) = 0x3e9c9c9d;
    *(undefined4 *)(iVar1 + 0x448) = 0x3e9c9c9d;
    *(undefined4 *)(iVar1 + 0x44c) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x450) = 0x3e68e8e9;
    *(undefined4 *)(iVar1 + 0x454) = 0x3e68e8e9;
    *(undefined4 *)(iVar1 + 0x458) = 0x3e68e8e9;
    *(undefined8 *)(iVar1 + 0x45c) = 0x3f800000;
    *(undefined8 *)(iVar1 + 0x464) = 0;
    *(undefined4 *)(iVar1 + 0x46c) = 0;
    *(undefined4 *)(iVar1 + 0x470) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x474) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x478) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x47c) = 0x3d20a0a1;
    *(undefined4 *)(iVar1 + 0x490) = 0x3f20a0a1;
    *(undefined4 *)(iVar1 + 0x494) = 0x3f20a0a1;
    *(undefined4 *)(iVar1 + 0x498) = 0x3f20a0a1;
    *(undefined4 *)(iVar1 + 0x49c) = 0x3ea0a0a1;
    *(undefined4 *)(iVar1 + 0x4e0) = 0x3f39b9ba;
    *(undefined4 *)(iVar1 + 0x4e4) = 0x3f39b9ba;
    *(undefined4 *)(iVar1 + 0x4e8) = 0x3f39b9ba;
    *(undefined4 *)(iVar1 + 0x4ec) = 0x3f800000;
    *(undefined4 *)(iVar1 + 0x510) = 0x3f3ebebf;
    *(undefined4 *)(iVar1 + 0x514) = 0x3f3ebebf;
    *(undefined4 *)(iVar1 + 0x518) = 0x3f3ebebf;
    *(undefined4 *)(iVar1 + 0x51c) = 0x3eaaaaab;
    fcn.180075e30(arg1);
    fcn.180074da0();
    iVar1 = *(int64_t *)0x18077afe0;
    iVar2 = *(int64_t *)0x18077afe8;
    if (*(int64_t *)0x18077afe0 != *(int64_t *)0x18077afe8) {
        func_0x00018007d5c0();
        *(int64_t *)0x18077afe8 = *(int64_t *)0x18077afe0;
    }
    *(undefined4 *)0x1807824e4 = 0;
    fcn.180074fd0(iVar1, iVar2);
    iVar1 = *(int64_t *)0x18077afc8;
    iVar2 = *(int64_t *)0x18077afc0;
    if (*(int64_t *)0x18077afc0 != *(int64_t *)0x18077afc8) {
        do {
            func_0x000180004e40(iVar2 + 8);
            iVar2 = iVar2 + 0x28;
        } while (iVar2 != iVar1);
        *(int64_t *)0x18077afc8 = *(int64_t *)0x18077afc0;
    }
    *(undefined4 *)0x18077aef8 = 1;
    return;
}

// ============================================================
// Function: FUN_180076ad0
// Address: 0x180076ad0
// Size: 4503 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_beh
// WARNING: [rz-ghidra] Detected overlap for variable var_a2h
// WARNING: [rz-ghidra] Detected overlap for variable var_a1h
// WARNING: [rz-ghidra] Detected overlap for variable var_c1h
// WARNING: [rz-ghidra] Detected overlap for variable var_bdh
// WARNING: [rz-ghidra] Detected overlap for variable var_bah
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_f7h
// WARNING: [rz-ghidra] Detected overlap for variable var_f6h
// WARNING: [rz-ghidra] Detected overlap for variable var_63h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c7h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c6h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c5h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c0h
// WARNING: [rz-ghidra] Variable var_2h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Removing arg arg_2098h because it doesn't fit into ProtoModel

void fcn.180076ad0(int64_t arg1)
{
    undefined8 uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    unkuint7 Var4;
    undefined auVar5 [16];
    int64_t iVar6;
    char cVar7;
    char cVar8;
    undefined uVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    int64_t *piVar13;
    undefined4 *puVar14;
    int64_t iVar15;
    undefined uVar16;
    uint16_t uVar17;
    uint16_t **ppuVar18;
    int64_t in_RDX;
    float *pfVar19;
    uint64_t uVar20;
    int64_t iVar21;
    uint16_t *puVar22;
    undefined8 *puVar23;
    undefined *puVar24;
    uint16_t **ppuVar25;
    uint64_t uVar26;
    int32_t iVar27;
    float fVar28;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 uVar29;
    float fVar30;
    undefined8 uStackY_140;
    undefined auStackY_138 [8];
    undefined auStackY_130 [24];
    int64_t var_118h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined8 var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    puVar24 = auStackY_138;
    var_68h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_138;
    var_f0h._0_4_ = 0;
    if (*(int64_t *)0x18077afe0 == *(int64_t *)0x18077afe8) {
        fcn.180074fd0(arg1, in_RDX);
    }
    fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
             *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    iVar21 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if ((*(int64_t *)(iVar21 + 0x208) != 0) ||
       (pfVar19 = (float *)(iVar21 + 0x2d4), *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0)) {
        pfVar19 = (float *)(iVar21 + 0x2a4);
    }
    fVar28 = ((((*pfVar19 - *(float *)(iVar21 + 0x15c)) - (fVar30 + *(float *)(*(int64_t *)0x180781f28 + 0xdf0))) -
              fVar30) - *(float *)(*(int64_t *)0x180781f28 + 0xdf0)) - 2.0;
    fVar30 = 0.0;
    if (0.0 <= fVar28) {
        fVar30 = fVar28;
    }
    cVar7 = func_0x000180148870();
    if (cVar7 != '\0') {
        uVar29 = extraout_XMM0_Da;
        iVar27 = 0;
        if (0 < (int32_t)(*(int64_t *)0x18077afe8 - *(int64_t *)0x18077afe0 >> 4) * -0x55555555) {
            do {
                iVar21 = (int64_t)iVar27 * 0x30;
                piVar13 = (int64_t *)(iVar21 + *(int64_t *)0x18077afe0);
                var_108h._0_1_ = *(char *)(piVar13 + 5);
                iVar10 = 0;
                if ((*(char *)0x1807824e8 != '\0') && (iVar10 = 0, iVar27 == *(int32_t *)0x1807824e4)) {
                    iVar10 = 6;
                }
                if (0xf < (uint64_t)piVar13[3]) {
                    piVar13 = (int64_t *)*piVar13;
                }
                if (*(char *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10e) == '\0') {
                    iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2538);
                    if (iVar15 == 0) {
                        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                            uVar29 = (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                               (*(int64_t *)0x180781f28, 
                                                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645bb0);
                        }
                        *(char *)(iVar21 + 0x28 + *(int64_t *)0x18077afe0) = (char)var_108h;
                    } else {
                        var_118h = 0;
                        cVar7 = func_0x00018014ae50(iVar15, piVar13, &var_108h, iVar10);
                        uVar29 = extraout_XMM0_Da_00;
                        if (cVar7 != '\0') {
                            uVar29 = func_0x0001801076d0(*(undefined4 *)
                                                          ((int64_t)*(int16_t *)(iVar15 + 0x8a) * 0x38 +
                                                          *(int64_t *)(iVar15 + 0x10)));
                        }
                        *(char *)(iVar21 + 0x28 + *(int64_t *)0x18077afe0) = (char)var_108h;
                        if ((cVar7 != '\0') &&
                           (*(int32_t *)0x1807824e4 = iVar27,
                           *(char *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10e) == '\0')) {
                            iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2538);
                            if (iVar15 == 0) {
                                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                                    uVar29 = (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                                       (*(int64_t *)0x180781f28, 
                                                        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645bb0);
                                }
                            } else if ((*(uint8_t *)
                                         ((int64_t)*(int16_t *)(iVar15 + 0x8a) * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10))
                                       & 8) == 0) {
                                uVar29 = func_0x000180107740();
                            }
                        }
                    }
                } else {
                    *(char *)(iVar21 + 0x28 + *(int64_t *)0x18077afe0) = (char)var_108h;
                }
                iVar15 = *(int64_t *)0x18077afe8;
                if ((char)var_108h == '\0') {
                    iVar21 = *(int64_t *)0x18077afe0 + iVar21;
                    iVar11 = iVar21;
                    while (iVar6 = iVar11 + 0x30, iVar6 != iVar15) {
                        func_0x000180012c10(iVar21, iVar6);
                        uVar29 = func_0x00018007c4a0(iVar21 + 0x20, iVar11 + 0x50);
                        *(undefined *)(iVar21 + 0x28) = *(undefined *)(iVar11 + 0x58);
                        iVar21 = iVar21 + 0x30;
                        iVar11 = iVar6;
                    }
                    uVar29 = func_0x00018007d620(uVar29, *(int64_t *)0x18077afe8 + -0x30);
                    *(int64_t *)0x18077afe8 = *(int64_t *)0x18077afe8 + -0x30;
                    if (*(int64_t *)0x18077afe0 == *(int64_t *)0x18077afe8) {
                        *(int32_t *)0x1807824e4 = 0;
                        break;
                    }
                    iVar10 = (int32_t)(*(int64_t *)0x18077afe8 - *(int64_t *)0x18077afe0 >> 4) * -0x55555555;
                    if (iVar10 <= *(int32_t *)0x1807824e4) {
                        *(int32_t *)0x1807824e4 = iVar10 + -1;
                    }
                } else {
                    iVar27 = iVar27 + 1;
                }
            } while (iVar27 < (int32_t)(*(int64_t *)0x18077afe8 - *(int64_t *)0x18077afe0 >> 4) * -0x55555555);
        }
        iVar21 = *(int64_t *)0x180781f28;
        var_a8h = CONCAT44(*(undefined4 *)(*(int64_t *)0x180781f28 + 0x1100), 0x23);
        var_a0h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1104);
        var_a0h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1108);
        var_98h = CONCAT44(var_98h._4_4_, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x110c));
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_a8h);
        if (*(int32_t *)(iVar21 + 0x20bc) != 0x23) {
            *(undefined8 *)(iVar21 + 0x1100) = 0;
            *(undefined8 *)(iVar21 + 0x1108) = 0;
        }
        iVar21 = *(int64_t *)0x180781f28;
        var_a8h = CONCAT44(*(undefined4 *)(*(int64_t *)0x180781f28 + 0x1130), 0x26);
        var_a0h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1134);
        var_a0h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1138);
        var_98h = CONCAT44(var_98h._4_4_, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x113c));
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_a8h);
        if (*(int32_t *)(iVar21 + 0x20bc) != 0x26) {
            *(undefined8 *)(iVar21 + 0x1130) = 0;
            *(undefined8 *)(iVar21 + 0x1138) = 0;
        }
        iVar21 = *(int64_t *)0x180781f28;
        var_a8h = CONCAT44(*(undefined4 *)(*(int64_t *)0x180781f28 + 0x1140), 0x27);
        var_a0h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1144);
        var_a0h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1148);
        var_98h = CONCAT44(var_98h._4_4_, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x114c));
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_a8h);
        if (*(int32_t *)(iVar21 + 0x20bc) != 0x27) {
            *(undefined8 *)(iVar21 + 0x1140) = 0;
            *(undefined8 *)(iVar21 + 0x1148) = 0;
        }
        if (*(char *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10e) == '\0') {
            if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2538) == 0) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645bb0);
                }
            } else {
                var_118h = 0;
                iVar15 = 0x18063cd78;
                cVar7 = func_0x00018014ae50(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2538), 0x18063cd78, 0, 0x2000a0);
                iVar21 = 3;
                if (cVar7 != '\0') {
                    func_0x0001800f6770();
                    func_0x000180148e50();
                    fcn.180074fd0(iVar21, iVar15);
                    goto code_r0x000180076f2e;
                }
            }
        }
        iVar21 = 3;
        func_0x0001800f6770();
        func_0x000180148e50();
    }
code_r0x000180076f2e:
    *(undefined *)0x1807824e8 = 0;
    if (*(int64_t *)0x18077afe0 == *(int64_t *)0x18077afe8) {
        fcn.180074fd0(iVar21, *(int64_t *)0x18077afe0);
    }
    if ((*(int32_t *)0x1807824e4 < 0) ||
       (iVar27 = (int32_t)(*(int64_t *)0x18077afe8 - *(int64_t *)0x18077afe0 >> 4),
       SBORROW4(*(int32_t *)0x1807824e4, iVar27 * -0x55555555) == *(int32_t *)0x1807824e4 + iVar27 * 0x55555555 < 0)) {
        *(int32_t *)0x1807824e4 = 0;
    }
    iVar21 = (int64_t)*(int32_t *)0x1807824e4 * 0x30 + *(int64_t *)0x18077afe0;
    var_f8h = iVar21;
    var_e0h = iVar21;
    if (*(int64_t *)0x1807824d0 != 0) {
        func_0x000180065fc0();
    }
    iVar15 = *(int64_t *)0x180781f28;
    var_a8h = CONCAT44(*(undefined4 *)(*(int64_t *)0x180781f28 + 0xf00), 3);
    var_a0h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf04);
    var_a0h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf08);
    var_98h = CONCAT44(var_98h._4_4_, *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf0c));
    func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_a8h);
    if (*(int32_t *)(iVar15 + 0x20bc) != 3) {
        *(undefined8 *)(iVar15 + 0xf00) = 0;
        *(undefined8 *)(iVar15 + 0xf08) = 0;
    }
    var_e8h = iVar21 + 0x20;
    var_100h = (uint64_t)(uint32_t)fVar30 << 0x20;
    func_0x000180150850(*(undefined8 *)var_e8h, 0x18063cd68, &var_100h, 0);
    func_0x0001800f6770(1);
    iVar15 = *(int64_t *)0x180781f28;
    if (*(int64_t *)0x1807824d0 == 0) {
code_r0x0001800770cd:
        var_e8h = iVar21 + 0x20;
    } else {
        iVar11 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0);
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) < 1) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445d0);
            }
            goto code_r0x0001800770cd;
        }
        iVar21 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x20e8);
        func_0x0001801072d0(*(undefined8 *)(iVar21 + -0x10 + iVar11 * 0x10), 
                            *(undefined4 *)(iVar21 + -8 + iVar11 * 0x10), *(undefined4 *)(iVar21 + -4 + iVar11 * 0x10));
        *(int32_t *)(iVar15 + 0x20e0) = *(int32_t *)(iVar15 + 0x20e0) + -1;
    }
    puVar23 = (undefined8 *)var_e8h;
    var_100h = 0x4000000000000000;
    func_0x00018013c3d0(&var_100h);
    var_100h = 0;
    cVar7 = func_0x00018013a5c0(0x18062a930, &var_100h, 0);
    if (cVar7 == '\0') {
code_r0x000180077617:
        *(undefined8 *)(puVar24 + -8) = 0x18007762a;
        func_0x00018010bd60(0, 0xbf800000);
        *(undefined8 *)(puVar24 + 0x38) = 0;
        *(undefined8 *)(puVar24 + -8) = 0x180077647;
        cVar7 = func_0x00018013a5c0(0x1806250a4, puVar24 + 0x38, 0);
        if (cVar7 != '\0') {
            *(undefined8 *)(puVar24 + 0xb0) = 0x1805aadb1;
            *(undefined8 *)(puVar24 + 0xb8) = 0;
            uVar1 = *puVar23;
            *(undefined8 *)(puVar24 + -8) = 0x180077676;
            func_0x000180066120(uVar1, puVar24 + 0xb0);
            *(undefined (*) [16])(puVar24 + 0xb0) = ZEXT816(0);
            *(undefined8 *)(puVar24 + 0xc0) = 0;
            *(undefined8 *)(puVar24 + 200) = 0xf;
            puVar24[0xb0] = 0;
            *(undefined2 *)(puVar24 + 0x7e) = 0;
            *(undefined8 *)(puVar24 + 0x80) = 0xe;
            *(undefined8 *)(puVar24 + 0x88) = 0xf;
            *(undefined8 *)(puVar24 + 0x70) = 0x2064657261656c43;
            *(undefined4 *)(puVar24 + 0x78) = 0x74696445;
            *(undefined2 *)(puVar24 + 0x7c) = 0x726f;
            puVar24[0x7e] = 0;
            *(undefined (*) [16])(puVar24 + 0x90) = ZEXT816(0);
            *(undefined8 *)(puVar24 + 0xa0) = 7;
            *(undefined8 *)(puVar24 + 0xa8) = 0xf;
            *(undefined4 *)(puVar24 + 0x90) = 0x63637553;
            *(undefined2 *)(puVar24 + 0x94) = 0x7365;
            puVar24[0x96] = 0x73;
            puVar24[0x97] = 0;
            *(undefined8 *)(puVar24 + -8) = 0x18007775a;
            fcn.1800758f0(*(int64_t *)(puVar24 + 0x20), *(int64_t *)(puVar24 + 0x30));
            if (0xf < *(uint64_t *)(puVar24 + 0xa8)) {
                iVar21 = *(int64_t *)(puVar24 + 0x90);
                iVar15 = iVar21;
                if ((0xfff < *(uint64_t *)(puVar24 + 0xa8) + 1) &&
                   (iVar15 = *(int64_t *)(iVar21 + -8), 0x1f < (iVar21 - iVar15) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar15 = (*pcVar2)(5);
                    puVar24 = puVar24 + 8;
                }
                *(undefined8 *)(puVar24 + -8) = 0x1800777a3;
                func_0x000180459c3c(iVar15);
            }
            if (0xf < *(uint64_t *)(puVar24 + 0x88)) {
                iVar21 = *(int64_t *)(puVar24 + 0x70);
                iVar15 = iVar21;
                if ((0xfff < *(uint64_t *)(puVar24 + 0x88) + 1) &&
                   (iVar15 = *(int64_t *)(iVar21 + -8), 0x1f < (iVar21 - iVar15) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar15 = (*pcVar2)(5);
                    puVar24 = puVar24 + 8;
                }
                *(undefined8 *)(puVar24 + -8) = 0x1800777e9;
                func_0x000180459c3c(iVar15);
            }
            *(undefined8 *)(puVar24 + 0x80) = 0;
            *(undefined8 *)(puVar24 + 0x88) = 0xf;
            puVar24[0x70] = 0;
            uVar20 = *(uint64_t *)(puVar24 + 200);
            if (0xf < uVar20) {
                iVar21 = *(int64_t *)(puVar24 + 0xb0);
                uVar26 = uVar20 + 1;
                if (0xfff < uVar26) {
                    if (0x1f < (iVar21 - *(int64_t *)(iVar21 + -8)) - 8U) goto code_r0x000180077c25;
                    uVar26 = uVar20 + 0x28;
                    iVar21 = *(int64_t *)(iVar21 + -8);
                }
                *(undefined8 *)(puVar24 + -8) = 0x180077847;
                func_0x000180459c3c(iVar21, uVar26);
            }
        }
        *(undefined8 *)(puVar24 + -8) = 0x180077852;
        func_0x00018010bd60(0, 0xbf800000);
        *(undefined8 *)(puVar24 + 0x38) = 0;
        *(undefined8 *)(puVar24 + -8) = 0x18007786f;
        cVar7 = func_0x00018013a5c0(0x18063cda0, puVar24 + 0x38, 0);
        if (cVar7 != '\0') {
            *(undefined (*) [16])(puVar24 + 0xb0) = ZEXT816(0);
            *(undefined8 *)(puVar24 + 0xc0) = 0;
            *(undefined8 *)(puVar24 + 200) = 0xf;
            puVar24[0xb0] = 0;
            *(undefined (*) [16])(puVar24 + 0x70) = ZEXT816(0);
            *(undefined8 *)(puVar24 + 0x80) = 0xb;
            *(undefined8 *)(puVar24 + 0x88) = 0xf;
            *(undefined8 *)(puVar24 + 0x70) = 0x462064656e65704f;
            *(undefined4 *)(puVar24 + 0x77) = 0x656c6946;
            puVar24[0x7b] = 0;
            *(undefined (*) [16])(puVar24 + 0x90) = ZEXT816(0);
            *(undefined8 *)(puVar24 + 0xa0) = 7;
            *(undefined8 *)(puVar24 + 0xa8) = 0xf;
            *(undefined4 *)(puVar24 + 0x90) = 0x63637553;
            *(undefined2 *)(puVar24 + 0x94) = 0x7365;
            puVar24[0x96] = 0x73;
            puVar24[0x97] = 0;
            *(undefined8 *)(puVar24 + -8) = 0x18007794e;
            fcn.1800758f0(*(int64_t *)(puVar24 + 0x20), *(int64_t *)(puVar24 + 0x30));
            if (0xf < *(uint64_t *)(puVar24 + 0xa8)) {
                iVar21 = *(int64_t *)(puVar24 + 0x90);
                iVar15 = iVar21;
                if ((0xfff < *(uint64_t *)(puVar24 + 0xa8) + 1) &&
                   (iVar15 = *(int64_t *)(iVar21 + -8), 0x1f < (iVar21 - iVar15) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar15 = (*pcVar2)(5);
                    puVar24 = puVar24 + 8;
                }
                *(undefined8 *)(puVar24 + -8) = 0x180077997;
                func_0x000180459c3c(iVar15);
            }
            if (0xf < *(uint64_t *)(puVar24 + 0x88)) {
                iVar21 = *(int64_t *)(puVar24 + 0x70);
                iVar15 = iVar21;
                if ((0xfff < *(uint64_t *)(puVar24 + 0x88) + 1) &&
                   (iVar15 = *(int64_t *)(iVar21 + -8), 0x1f < (iVar21 - iVar15) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar15 = (*pcVar2)(5);
                    puVar24 = puVar24 + 8;
                }
                *(undefined8 *)(puVar24 + -8) = 0x1800779dd;
                func_0x000180459c3c(iVar15);
            }
            *(undefined8 *)(puVar24 + 0x80) = 0;
            *(undefined8 *)(puVar24 + 0x88) = 0xf;
            puVar24[0x70] = 0;
            uVar20 = *(uint64_t *)(puVar24 + 200);
            if (0xf < uVar20) {
                iVar21 = *(int64_t *)(puVar24 + 0xb0);
                uVar26 = uVar20 + 1;
                if (0xfff < uVar26) {
                    if (0x1f < (iVar21 - *(int64_t *)(iVar21 + -8)) - 8U) goto code_r0x000180077c25;
                    uVar26 = uVar20 + 0x28;
                    iVar21 = *(int64_t *)(iVar21 + -8);
                }
                *(undefined8 *)(puVar24 + -8) = 0x180077a3b;
                func_0x000180459c3c(iVar21, uVar26);
            }
        }
        *(undefined8 *)(puVar24 + -8) = 0x180077a46;
        func_0x00018010bd60(0, 0xbf800000);
        *(undefined8 *)(puVar24 + 0x38) = 0;
        *(undefined8 *)(puVar24 + -8) = 0x180077a63;
        cVar7 = func_0x00018013a5c0(0x18063ce08, puVar24 + 0x38, 0);
        if (cVar7 == '\0') goto code_r0x000180077c34;
        *(undefined (*) [16])(puVar24 + 0xb0) = ZEXT816(0);
        *(undefined8 *)(puVar24 + 0xc0) = 0;
        *(undefined8 *)(puVar24 + 200) = 0xf;
        puVar24[0xb0] = 0;
        *(undefined (*) [16])(puVar24 + 0x70) = ZEXT816(0);
        *(undefined8 *)(puVar24 + 0x80) = 10;
        *(undefined8 *)(puVar24 + 0x88) = 0xf;
        *(undefined8 *)(puVar24 + 0x70) = 0x6946206465766153;
        *(undefined2 *)(puVar24 + 0x78) = 0x656c;
        puVar24[0x7a] = 0;
        *(undefined (*) [16])(puVar24 + 0x90) = ZEXT816(0);
        *(undefined8 *)(puVar24 + 0xa0) = 7;
        *(undefined8 *)(puVar24 + 0xa8) = 0xf;
        *(undefined4 *)(puVar24 + 0x90) = 0x63637553;
        *(undefined2 *)(puVar24 + 0x94) = 0x7365;
        puVar24[0x96] = 0x73;
        puVar24[0x97] = 0;
        *(undefined8 *)(puVar24 + -8) = 0x180077b44;
        fcn.1800758f0(*(int64_t *)(puVar24 + 0x20), *(int64_t *)(puVar24 + 0x30));
        if (0xf < *(uint64_t *)(puVar24 + 0xa8)) {
            iVar21 = *(int64_t *)(puVar24 + 0x90);
            iVar15 = iVar21;
            if ((0xfff < *(uint64_t *)(puVar24 + 0xa8) + 1) &&
               (iVar15 = *(int64_t *)(iVar21 + -8), 0x1f < (iVar21 - iVar15) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar15 = (*pcVar2)(5);
                puVar24 = puVar24 + 8;
            }
            *(undefined8 *)(puVar24 + -8) = 0x180077b8d;
            func_0x000180459c3c(iVar15);
        }
        if (0xf < *(uint64_t *)(puVar24 + 0x88)) {
            iVar21 = *(int64_t *)(puVar24 + 0x70);
            iVar15 = iVar21;
            if ((0xfff < *(uint64_t *)(puVar24 + 0x88) + 1) &&
               (iVar15 = *(int64_t *)(iVar21 + -8), 0x1f < (iVar21 - iVar15) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar15 = (*pcVar2)(5);
                puVar24 = puVar24 + 8;
            }
            *(undefined8 *)(puVar24 + -8) = 0x180077bd3;
            func_0x000180459c3c(iVar15);
        }
        *(undefined8 *)(puVar24 + 0x80) = 0;
        *(undefined8 *)(puVar24 + 0x88) = 0xf;
        puVar24[0x70] = 0;
        if (*(uint64_t *)(puVar24 + 200) < 0x10) goto code_r0x000180077c34;
        iVar21 = *(int64_t *)(puVar24 + 0xb0);
        iVar15 = iVar21;
        if ((0xfff < *(uint64_t *)(puVar24 + 200) + 1) &&
           (iVar15 = *(int64_t *)(iVar21 + -8), 0x1f < (iVar21 - iVar15) - 8U)) goto code_r0x000180077c25;
    } else {
        puVar12 = (undefined8 *)func_0x0001800137d0();
        cVar7 = (char)var_108h;
        var_88h = *puVar12;
        var_100h = *puVar23;
        var_b8h = 0;
        var_b0h = 0xf;
        stack0xffffffffffffff39 = SUB1615(ZEXT816(0), 1);
        auVar3[15] = 0;
        auVar3._0_15_ = stack0xffffffffffffff39;
        _var_c8h = auVar3 << 8;
        var_f0h._0_4_ = (uint32_t)var_f0h | 2;
        ppuVar25 = *(uint16_t ***)(var_100h + 0x40);
        uVar20 = 0xf;
        while (ppuVar25 != *(uint16_t ***)(var_100h + 0x48)) {
            cVar8 = -1;
            if (*(uint16_t ***)(var_100h + 0x48) <= ppuVar25) {
                cVar8 = '\x01';
            }
            if (-1 < cVar8) break;
            puVar22 = *ppuVar25;
            while( true ) {
                iVar21 = var_b8h;
                if (puVar22 == ppuVar25[1]) break;
                cVar8 = -1;
                if (ppuVar25[1] <= puVar22) {
                    cVar8 = '\x01';
                }
                if (-1 < cVar8) break;
                uVar17 = *puVar22;
                if (uVar17 < 0x80) {
                    uVar26 = 1;
code_r0x000180077220:
                    var_f8h = CONCAT71(var_f8h._1_7_, (char)uVar17);
                } else {
                    uVar16 = (undefined)uVar17;
                    uVar9 = (undefined)(uVar17 >> 6);
                    if (0x7ff < uVar17) {
                        uVar17 = (uint16_t)(uint8_t)((uint8_t)(uVar17 >> 0xc) | 0xe0);
                        Var4 = CONCAT61(var_f8h._2_6_, uVar9) & 0xffffffffffff3f;
                        var_f8h._0_2_ = ((uint16_t)Var4 | 0x80) << 8;
                        var_f8h._3_5_ = (unkbyte5)(Var4 >> 0x10);
                        var_f8h = CONCAT53(var_f8h._3_5_, CONCAT12(uVar16, (int16_t)var_f8h)) & 0xffffffffff3fffff |
                                  0x800000;
                        uVar26 = 3;
                        goto code_r0x000180077220;
                    }
                    uVar26 = CONCAT71(var_f8h._1_7_, uVar9) & 0xffffffffffffff1f;
                    var_f8h._2_6_ = (unkbyte6)(uVar26 >> 0x10);
                    var_f8h = CONCAT62(var_f8h._2_6_, CONCAT11(uVar16, (char)uVar26)) & 0xffffffffffff3fff | 0x80c0;
                    uVar26 = 2;
                }
                if (uVar20 - var_b8h < uVar26) {
                    var_118h = uVar26;
                    func_0x00018000ee80(&var_c8h, uVar26, cVar7, &var_f8h);
                    puVar22 = puVar22 + 2;
                    uVar20 = var_b0h;
                } else {
                    piVar13 = &var_c8h;
                    if (0xf < uVar20) {
                        piVar13 = (int64_t *)var_c8h;
                    }
                    iVar21 = (int64_t)piVar13 + var_b8h;
                    var_b8h = uVar26 + var_b8h;
                    func_0x000180498030(iVar21, &var_f8h, uVar26);
                    *(undefined *)(iVar21 + uVar26) = 0;
                    puVar22 = puVar22 + 2;
                    uVar20 = var_b0h;
                }
            }
            ppuVar18 = (uint16_t **)(*(int64_t *)(var_100h + 0x48) + -0x38);
            if (ppuVar25 == ppuVar18) {
code_r0x00018007735b:
                ppuVar25 = ppuVar25 + 7;
            } else {
                cVar8 = -1;
                if (ppuVar18 <= ppuVar25) {
                    cVar8 = '\x01';
                }
                if (-1 < cVar8) goto code_r0x00018007735b;
                if (uVar20 == var_b8h) {
                    var_118h = 1;
                    func_0x00018000ee80(&var_c8h, 1, (char)var_108h, 0x1805ab2a0);
                    uVar20 = var_b0h;
                    goto code_r0x00018007735b;
                }
                piVar13 = &var_c8h;
                if (0xf < uVar20) {
                    piVar13 = (int64_t *)var_c8h;
                }
                puVar24 = (undefined *)((int64_t)piVar13 + var_b8h);
                var_b8h = var_b8h + 1;
                *puVar24 = 10;
                *(undefined *)((int64_t)piVar13 + iVar21 + 1) = 0;
                ppuVar25 = ppuVar25 + 7;
                uVar20 = var_b0h;
            }
        }
        piVar13 = (int64_t *)func_0x000180008740();
        var_e0h = *(int64_t *)(*piVar13 + 0x18);
        var_100h = func_0x00018045838c();
        piVar13 = (int64_t *)func_0x00018000a880(&var_a8h, &var_100h, &var_e0h, &var_c8h);
        var_e0h = *piVar13;
        var_d8h = piVar13[1];
        *piVar13 = 0;
        piVar13[1] = 0;
        func_0x00018000a9d0(var_88h, &var_e0h);
        if (var_d8h != 0) {
            func_0x000180005cf0();
        }
        if (var_a0h != 0) {
            func_0x000180005cf0();
        }
        if ((uint64_t)var_b0h < 0x10) {
code_r0x00018007742f:
            var_78h = 0;
            var_70h = 0xf;
            stack0xffffffffffffff79 = SUB1615(ZEXT816(0), 1);
            auVar5[15] = 0;
            auVar5._0_15_ = stack0xffffffffffffff79;
            _var_88h = auVar5 << 8;
            _var_c8h = ZEXT816(0);
            var_b8h = 0;
            var_b0h = 0;
            var_100h = 0x1f;
            puVar14 = (undefined4 *)func_0x000180004930(&var_c8h, &var_100h);
            var_c8h = (int64_t)puVar14;
            var_b8h = 0x10;
            var_b0h = var_100h;
            *puVar14 = 0x69726353;
            puVar14[1] = 0x65207470;
            puVar14[2] = 0x75636578;
            puVar14[3] = 0x21646574;
            *(undefined *)(puVar14 + 4) = 0;
            var_98h = 7;
            var_90h = 0xf;
            _var_a8h = ZEXT716(0x73736563637553);
            fcn.1800758f0(var_118h, CONCAT71(var_108h._1_7_, (char)var_108h));
            puVar24 = auStackY_138;
            if (0xf < (uint64_t)var_90h) {
                iVar21 = var_a8h;
                puVar24 = auStackY_138;
                if ((0xfff < var_90h + 1U) &&
                   (iVar21 = *(int64_t *)(var_a8h + -8), puVar24 = auStackY_138, 0x1f < (var_a8h - iVar21) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar21 = (*pcVar2)(5);
                    puVar24 = auStackY_130;
                }
                *(undefined8 *)(puVar24 + -8) = 0x18007756e;
                func_0x000180459c3c(iVar21);
            }
            if (0xf < *(uint64_t *)(puVar24 + 0x88)) {
                iVar21 = *(int64_t *)(puVar24 + 0x70);
                iVar15 = iVar21;
                if ((0xfff < *(uint64_t *)(puVar24 + 0x88) + 1) &&
                   (iVar15 = *(int64_t *)(iVar21 + -8), 0x1f < (iVar21 - iVar15) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar15 = (*pcVar2)(5);
                    puVar24 = puVar24 + 8;
                }
                *(undefined8 *)(puVar24 + -8) = 0x1800775b4;
                func_0x000180459c3c(iVar15);
            }
            *(undefined8 *)(puVar24 + 0x80) = 0;
            *(undefined8 *)(puVar24 + 0x88) = 0xf;
            puVar24[0x70] = 0;
            uVar20 = *(uint64_t *)(puVar24 + 200);
            if (0xf < uVar20) {
                iVar21 = *(int64_t *)(puVar24 + 0xb0);
                uVar26 = uVar20 + 1;
                if (0xfff < uVar26) {
                    if (0x1f < (iVar21 - *(int64_t *)(iVar21 + -8)) - 8U) goto code_r0x000180077c25;
                    uVar26 = uVar20 + 0x28;
                    iVar21 = *(int64_t *)(iVar21 + -8);
                }
                *(undefined8 *)(puVar24 + -8) = 0x180077612;
                func_0x000180459c3c(iVar21, uVar26);
            }
            puVar23 = *(undefined8 **)(puVar24 + 0x50);
            goto code_r0x000180077617;
        }
        uVar20 = var_b0h + 1;
        iVar21 = var_c8h;
        if (uVar20 < 0x1000) {
code_r0x00018007742a:
            func_0x000180459c3c(iVar21, uVar20);
            goto code_r0x00018007742f;
        }
        puVar24 = auStackY_138;
        if ((var_c8h - *(int64_t *)(var_c8h + -8)) - 8U < 0x20) {
            uVar20 = var_b0h + 0x28;
            iVar21 = *(int64_t *)(var_c8h + -8);
            goto code_r0x00018007742a;
        }
code_r0x000180077c25:
        pcVar2 = (code *)swi(0x29);
        iVar15 = (*pcVar2)(5);
        puVar24 = puVar24 + 8;
    }
    *(undefined8 *)(puVar24 + -8) = 0x180077c34;
    func_0x000180459c3c(iVar15);
code_r0x000180077c34:
    *(undefined8 *)(puVar24 + -8) = 0x180077c44;
    func_0x000180459870(*(uint64_t *)(puVar24 + 0xd0) ^ (uint64_t)puVar24);
    return;
}

// ============================================================
// Function: FUN_180077c70
// Address: 0x180077c70
// Size: 1539 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_11h
// WARNING: Variable defined which should be unmapped: var_19h
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_31h
// WARNING: Variable defined which should be unmapped: var_39h
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_49h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_151h
// WARNING: [rz-ghidra] Detected overlap for variable var_152h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_b1h
// WARNING: [rz-ghidra] Detected overlap for variable var_b2h

void fcn.180077c70(void)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    char cVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t **ppiVar7;
    float *pfVar8;
    undefined4 *puVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    undefined8 *puVar14;
    float fVar15;
    float fVar16;
    undefined auStack_108 [32];
    int64_t var_e8h;
    int64_t var_e0h;
    undefined8 uStack_c8;
    int64_t **ppiStack_c0;
    undefined8 uStack_b8;
    undefined8 uStack_b0;
    undefined4 uStack_a8;
    undefined2 uStack_a4;
    undefined2 uStack_a2;
    undefined8 uStack_a0;
    undefined8 uStack_98;
    undefined auStack_90 [16];
    undefined8 uStack_80;
    undefined8 uStack_78;
    undefined auStack_70 [7];
    int64_t var_69h;
    int64_t var_61h;
    int64_t var_59h;
    int64_t var_51h;
    int64_t var_43h;
    int64_t var_39h;
    int64_t var_31h;
    int64_t var_21h;
    int64_t var_19h;
    int64_t var_11h;
    
    _auStack_70 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_108;
    ppiVar7 = (int64_t **)func_0x000180016e80();
    iVar3 = *(int64_t *)0x180781f28;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if ((*(int64_t *)(iVar1 + 0x208) != 0) ||
       (pfVar8 = (float *)(iVar1 + 0x2d0), *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0)) {
        pfVar8 = (float *)(iVar1 + 0x2a0);
    }
    fVar16 = ((*pfVar8 - *(float *)(iVar1 + 0x158)) - *(float *)(*(int64_t *)0x180781f28 + 0xdec)) * 0.5;
    fVar15 = ((pfVar8[1] - *(float *)(iVar1 + 0x15c)) - *(float *)(*(int64_t *)0x180781f28 + 0xdf0)) * 0.5;
    uStack_c8 = CONCAT44(fVar15, fVar16);
    *(undefined *)(iVar1 + 0x10b) = 1;
    ppiStack_c0 = ppiVar7;
    uStack_b8 = ppiVar7;
    uVar5 = func_0x0001800f5a90(0x18063ced0, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(*(int64_t *)(iVar3 + 0x15e0) + 0x150) + -4 +
                                 (int64_t)*(int32_t *)(*(int64_t *)(iVar3 + 0x15e0) + 0x148) * 4));
    puVar14 = (undefined8 *)0x0;
    var_e8h = (uint64_t)var_e8h._4_4_ << 0x20;
    func_0x0001800fe6d0(0x18063ced0, uVar5, &uStack_c8, 1);
    var_e8h = 0x1806200c0;
    func_0x000180078280(&ppiStack_c0, 0x18063cf38, 0x180620098, 0x180620098);
    var_e8h = 0x180620120;
    func_0x000180078280(&ppiStack_c0, 0x18063cf38, 0x180620110, 0x180620110);
    var_e8h = 0x180620180;
    func_0x000180078280(&ppiStack_c0, 0x18063cf38, 0x180620170, 0x180620170);
    var_e8h = 0x1806201e0;
    func_0x000180078280(&ppiStack_c0, 0x18063cf38, 0x1806201d0, 0x1806201d0);
    func_0x0001800fea60();
    func_0x00018010bd60(0, 0xbf800000);
    iVar1 = *(int64_t *)0x180781f28;
    uStack_c8 = CONCAT44(fVar15, fVar16);
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    uVar5 = func_0x0001800f5a90(0x18063cf28, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(*(int64_t *)(iVar1 + 0x15e0) + 0x150) + -4 +
                                 (int64_t)*(int32_t *)(*(int64_t *)(iVar1 + 0x15e0) + 0x148) * 4));
    var_e8h = var_e8h & 0xffffffff00000000;
    func_0x0001800fe6d0(0x18063cf28, uVar5, &uStack_c8, 1);
    var_e8h = 0x180620240;
    func_0x000180078280(&ppiStack_c0, 0x18063cf20, 0x180620230, 0x180620230);
    func_0x000180078520(&uStack_b8);
    func_0x0001800fea60();
    iVar1 = *(int64_t *)0x180781f28;
    uStack_c8 = CONCAT44(fVar15, fVar16);
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    uVar5 = func_0x0001800f5a90(0x18063cf10, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(*(int64_t *)(iVar1 + 0x15e0) + 0x150) + -4 +
                                 (int64_t)*(int32_t *)(*(int64_t *)(iVar1 + 0x15e0) + 0x148) * 4));
    var_e8h = var_e8h & 0xffffffff00000000;
    func_0x0001800fe6d0(0x18063cf10, uVar5, &uStack_c8, 1);
    var_e8h = 0x18063cfa0;
    func_0x000180078280(&ppiStack_c0, 0x18061fff8, 0x180620030, 0x18063cf80);
    var_e8h = 0x18063cf60;
    func_0x000180078280(&ppiStack_c0, 0x18061fff8, 0x180620008, 0x180620008);
    func_0x0001800fea60();
    func_0x00018010bd60(0, 0xbf800000);
    iVar1 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    uStack_c8._0_4_ = fVar16;
    uStack_c8._4_4_ = fVar15;
    uVar5 = func_0x0001800f5a90(0x18063cf50, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(*(int64_t *)(iVar1 + 0x15e0) + 0x150) + -4 +
                                 (int64_t)*(int32_t *)(*(int64_t *)(iVar1 + 0x15e0) + 0x148) * 4));
    var_e8h = var_e8h & 0xffffffff00000000;
    func_0x0001800fe6d0(0x18063cf50, uVar5, &uStack_c8, 1);
    fVar15 = *(float *)0x1806a4604;
    uStack_b8 = (int64_t **)CONCAT44(uStack_b8._4_4_, 0x41f00000);
    uStack_c8 = CONCAT44(uStack_c8._4_4_, 0x41400000);
    var_e0h = 0x18063d050;
    var_e8h = (int64_t)&uStack_b8;
    func_0x00018013f2f0(0x18063d038, 8, 0x1806a4604, &uStack_c8);
    cVar4 = func_0x0001800fa150(0);
    if (cVar4 != '\0') {
        func_0x00018010ce60(0x18063d000);
    }
    if (*(float *)0x1806a4604 != fVar15) {
        fcn.180075e30(*(int64_t *)0x180781f28 + 0x30);
        piVar2 = *ppiVar7;
        auStack_90 = ZEXT816(0);
        puVar9 = (undefined4 *)func_0x000180459890(0x20);
        auStack_90._0_8_ = puVar9;
        uStack_80 = 0x10;
        uStack_78 = 0x1f;
        *puVar9 = 0x74696445;
        puVar9[1] = 0x4620726f;
        puVar9[2] = 0x20746e6f;
        puVar9[3] = 0x657a6953;
        *(undefined *)(puVar9 + 4) = 0;
        uStack_a2 = 0;
        uStack_a0 = 0xe;
        uStack_98 = 0xf;
        uStack_b0 = 0x746e492072657355;
        uStack_a8 = 0x61667265;
        uStack_a4 = 0x6563;
        puVar12 = (undefined8 *)piVar2[1];
        for (puVar13 = (undefined8 *)*piVar2; puVar11 = puVar14, puVar13 != puVar12; puVar13 = puVar13 + 7) {
            puVar10 = puVar13;
            if (0xf < (uint64_t)puVar13[3]) {
                puVar10 = (undefined8 *)*puVar13;
            }
            if ((puVar13[2] == 0xe) && (iVar6 = func_0x000180497f30(puVar10, &uStack_b0), iVar6 == 0)) {
                if (puVar13 != (undefined8 *)0x0) {
                    puVar12 = (undefined8 *)puVar13[4];
                    puVar13 = (undefined8 *)puVar13[5];
                    goto joined_r0x000180078155;
                }
                break;
            }
        }
code_r0x00018007818a:
        func_0x000180459c3c(puVar9, 0x20);
        if (puVar11 != (undefined8 *)0x0) {
            func_0x000180014620(puVar11, *(float *)0x1806a4604);
        }
    }
    uStack_c8 = 0;
    cVar4 = func_0x00018013a5c0(0x18063cfe8, &uStack_c8, 0);
    if (cVar4 != '\0') {
        *(undefined *)0x180781f99 = 1;
    }
    cVar4 = func_0x0001800fa150(0);
    if (cVar4 != '\0') {
        func_0x00018010ce60(0x18063d0c0);
    }
    var_e8h = 0x18063d070;
    func_0x000180078280(&ppiStack_c0, 0x18063d060, 0x1806202d8, 0x1806202d8);
    var_e8h = 0x180620350;
    func_0x000180078280(&ppiStack_c0, 0x1806202c8, 0x180620338, 0x180620338);
    func_0x0001800fea60();
    func_0x000180459870(_auStack_70 ^ (uint64_t)auStack_108);
    return;
joined_r0x000180078155:
    puVar11 = puVar14;
    if (puVar12 == puVar13) goto code_r0x00018007818a;
    puVar11 = puVar12;
    if (0xf < (uint64_t)puVar12[3]) {
        puVar11 = (undefined8 *)*puVar12;
    }
    if ((puVar12[2] == 0x10) && (iVar6 = func_0x000180497f30(puVar11, puVar9), puVar11 = puVar12, iVar6 == 0))
    goto code_r0x00018007818a;
    puVar12 = puVar12 + 0x13;
    goto joined_r0x000180078155;
}

// ============================================================
// Function: FUN_180078280
// Address: 0x180078280
// Size: 657 bytes
// ============================================================
void fcn.180078280(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    undefined uVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    char cVar8;
    int32_t iVar9;
    undefined8 uVar10;
    undefined8 *puVar11;
    uint64_t uVar12;
    int64_t *piVar13;
    undefined8 *puVar14;
    undefined *puVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    int64_t var_d0h;
    undefined auStack_c8 [8];
    undefined auStack_c0 [24];
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar15 = auStack_c8;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    puVar14 = (undefined8 *)**(int64_t **)arg1;
    _var_78h = ZEXT816(0);
    var_68h = 0;
    var_60h = 0;
    var_a0h = arg4;
    uVar10 = func_0x000180498cd0(arg3);
    func_0x000180004830(&var_78h, arg3, uVar10);
    _var_98h = ZEXT816(0);
    var_88h = 0;
    var_80h = 0;
    uVar10 = func_0x000180498cd0(arg2);
    func_0x000180004830(&var_98h, arg2, uVar10);
    iVar7 = var_60h;
    iVar5 = var_80h;
    iVar4 = var_88h;
    puVar17 = (undefined8 *)*puVar14;
    puVar14 = (undefined8 *)puVar14[1];
    iVar6 = var_78h;
    iVar3 = var_98h;
    for (; puVar17 != puVar14; puVar17 = puVar17 + 7) {
        piVar13 = &var_98h;
        if (0xf < (uint64_t)iVar5) {
            piVar13 = (int64_t *)iVar3;
        }
        puVar11 = puVar17;
        if (0xf < (uint64_t)puVar17[3]) {
            puVar11 = (undefined8 *)*puVar17;
        }
        if ((puVar17[2] == iVar4) && ((puVar17[2] == 0 || (iVar9 = func_0x000180497f30(puVar11, piVar13), iVar9 == 0))))
        {
            iVar4 = var_68h;
            if (puVar17 != (undefined8 *)0x0) {
                puVar14 = (undefined8 *)puVar17[4];
                puVar17 = (undefined8 *)puVar17[5];
                goto joined_r0x00018007838e;
            }
            break;
        }
    }
code_r0x0001800783df:
    puVar14 = (undefined8 *)0x0;
code_r0x0001800783e1:
    if (0xf < (uint64_t)iVar5) {
        uVar12 = iVar3;
        puVar15 = auStack_c8;
        if (0xfff < iVar5 + 1U) {
            uVar12 = *(uint64_t *)(iVar3 + -8);
            uVar16 = (iVar3 - uVar12) - 8;
            puVar15 = auStack_c8;
            if (0x1f < uVar16) {
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                uVar12 = uVar16;
                puVar15 = auStack_c0;
            }
        }
        *(undefined8 *)(puVar15 + -8) = 0x18007841a;
        func_0x000180459c3c(uVar12);
    }
    if (0xf < (uint64_t)iVar7) {
        uVar12 = iVar6;
        if (0xfff < iVar7 + 1U) {
            uVar12 = *(uint64_t *)(iVar6 + -8);
            uVar16 = (iVar6 - uVar12) - 8;
            if (0x1f < uVar16) {
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar15 = puVar15 + 8;
                uVar12 = uVar16;
            }
        }
        *(undefined8 *)(puVar15 + -8) = 0x180078454;
        func_0x000180459c3c(uVar12);
    }
    if (puVar14 == (undefined8 *)0x0) {
        *(undefined8 *)(puVar15 + -8) = 0x18007846a;
        func_0x000180139c00(0x18063cee8, *(undefined8 *)(puVar15 + 0x28));
    } else {
        if (*(char *)(puVar14 + 0xc) != '\0') {
            *(undefined8 *)(puVar15 + -8) = 0x180078510;
            func_0x000180016af0();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        puVar15[0x20] = *(undefined *)(puVar14 + 8);
        *(undefined8 *)(puVar15 + -8) = 0x1800784a8;
        cVar8 = func_0x00018013bcf0(*(undefined8 *)(puVar15 + 0x28), puVar15 + 0x20);
        if (cVar8 != '\0') {
            uVar1 = puVar15[0x20];
            cVar8 = *(char *)(puVar14 + 0xc);
            if (cVar8 != '\0') {
                if ((((cVar8 != -1) && (cVar8 != '\0')) && (cVar8 != '\x01')) && (cVar8 != '\x02')) {
                    *(undefined8 *)(puVar15 + -8) = 0x1800784db;
                    func_0x000180004e40(puVar14 + 8);
                }
                *(undefined *)(puVar14 + 0xc) = 0;
            }
            *(undefined *)(puVar14 + 8) = uVar1;
        }
        if (arg_28h != 0) {
            *(undefined8 *)(puVar15 + -8) = 0x1800784ef;
            cVar8 = func_0x0001800fa150(0);
            if (cVar8 != '\0') {
                *(undefined8 *)(puVar15 + -8) = 0x180078506;
                func_0x00018010ce60(0x18063cc8c, arg_28h);
            }
        }
    }
    *(undefined8 *)(puVar15 + -8) = 0x180078477;
    func_0x000180459870(*(uint64_t *)(puVar15 + 0x70) ^ (uint64_t)puVar15);
    return;
joined_r0x00018007838e:
    if (puVar14 == puVar17) goto code_r0x0001800783df;
    piVar13 = &var_78h;
    if (0xf < (uint64_t)iVar7) {
        piVar13 = (int64_t *)iVar6;
    }
    puVar11 = puVar14;
    if (0xf < (uint64_t)puVar14[3]) {
        puVar11 = (undefined8 *)*puVar14;
    }
    if ((puVar14[2] == iVar4) && ((puVar14[2] == 0 || (iVar9 = func_0x000180497f30(puVar11, piVar13), iVar9 == 0))))
    goto code_r0x0001800783e1;
    puVar14 = puVar14 + 0x13;
    goto joined_r0x00018007838e;
}

// ============================================================
// Function: FUN_180078520
// Address: 0x180078520
// Size: 697 bytes
// ============================================================
void fcn.180078520(int64_t arg1)
{
    undefined4 uVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    char cVar8;
    int32_t iVar9;
    undefined8 *puVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    undefined8 *puVar13;
    undefined8 *puVar14;
    undefined *puVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    undefined8 *puVar18;
    int64_t var_f0h;
    undefined auStack_e8 [8];
    undefined auStack_e0 [24];
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar15 = auStack_e8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    puVar13 = (undefined8 *)**(int64_t **)arg1;
    _var_70h = ZEXT816(0);
    puVar18 = (undefined8 *)0x0;
    var_60h = 0;
    var_58h = 0;
    func_0x000180004830(&var_70h, 0x180620280, 7);
    _var_90h = ZEXT816(0);
    var_80h = 0;
    var_78h = 0;
    func_0x000180004830(&var_90h, 0x18063cf20, 4);
    iVar7 = var_58h;
    iVar5 = var_78h;
    iVar4 = var_80h;
    puVar17 = (undefined8 *)*puVar13;
    puVar13 = (undefined8 *)puVar13[1];
    iVar6 = var_70h;
    iVar3 = var_90h;
    for (; puVar14 = puVar18, puVar17 != puVar13; puVar17 = puVar17 + 7) {
        piVar12 = &var_90h;
        if (0xf < (uint64_t)iVar5) {
            piVar12 = (int64_t *)iVar3;
        }
        puVar10 = puVar17;
        if (0xf < (uint64_t)puVar17[3]) {
            puVar10 = (undefined8 *)*puVar17;
        }
        if ((puVar17[2] == iVar4) && ((puVar17[2] == 0 || (iVar9 = func_0x000180497f30(puVar10, piVar12), iVar9 == 0))))
        {
            iVar4 = var_60h;
            if (puVar17 != (undefined8 *)0x0) {
                puVar13 = (undefined8 *)puVar17[4];
                puVar17 = (undefined8 *)puVar17[5];
                goto joined_r0x00018007861e;
            }
            break;
        }
    }
code_r0x000180078672:
    if (0xf < (uint64_t)iVar5) {
        uVar11 = iVar3;
        puVar15 = auStack_e8;
        if (0xfff < iVar5 + 1U) {
            uVar11 = *(uint64_t *)(iVar3 + -8);
            uVar16 = (iVar3 - uVar11) - 8;
            puVar15 = auStack_e8;
            if (0x1f < uVar16) {
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                uVar11 = uVar16;
                puVar15 = auStack_e0;
            }
        }
        *(undefined8 *)(puVar15 + -8) = 0x1800786ab;
        func_0x000180459c3c(uVar11);
    }
    if (0xf < (uint64_t)iVar7) {
        uVar11 = iVar6;
        if (0xfff < iVar7 + 1U) {
            uVar11 = *(uint64_t *)(iVar6 + -8);
            uVar16 = (iVar6 - uVar11) - 8;
            if (0x1f < uVar16) {
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar15 = puVar15 + 8;
                uVar11 = uVar16;
            }
        }
        *(undefined8 *)(puVar15 + -8) = 0x1800786e5;
        func_0x000180459c3c(uVar11);
    }
    if (puVar14 == (undefined8 *)0x0) {
        *(undefined8 *)(puVar15 + -8) = 0x1800786fd;
        func_0x000180139c00(0x18063cee8, 0x180620280);
    } else {
        if (*(char *)(puVar14 + 0xc) != '\x01') {
            *(undefined8 *)(puVar15 + -8) = 0x1800787d8;
            func_0x000180016af0();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        *(undefined4 *)(puVar15 + 0x40) = *(undefined4 *)(puVar14 + 8);
        *(undefined4 *)(puVar15 + 0x48) = 2000;
        *(undefined4 *)(puVar15 + 0x50) = 0x1e;
        *(undefined8 *)(puVar15 + 0x28) = 0x18063cee0;
        *(undefined **)(puVar15 + 0x20) = puVar15 + 0x48;
        *(undefined8 *)(puVar15 + -8) = 0x180078773;
        cVar8 = func_0x00018013f2f0(0x180620280, 4, puVar15 + 0x40, puVar15 + 0x50);
        if (cVar8 != '\0') {
            uVar1 = *(undefined4 *)(puVar15 + 0x40);
            cVar8 = *(char *)(puVar14 + 0xc);
            if (cVar8 != '\x01') {
                if ((((cVar8 != -1) && (cVar8 != '\0')) && (cVar8 != '\x01')) && (cVar8 != '\x02')) {
                    *(undefined8 *)(puVar15 + -8) = 0x1800787a5;
                    func_0x000180004e40(puVar14 + 8);
                }
                *(undefined *)(puVar14 + 0xc) = 1;
            }
            *(undefined4 *)(puVar14 + 8) = uVar1;
        }
        *(undefined8 *)(puVar15 + -8) = 0x1800787b3;
        cVar8 = func_0x0001800fa150(0);
        if (cVar8 != '\0') {
            *(undefined8 *)(puVar15 + -8) = 0x1800787ce;
            func_0x00018010ce60(0x18063cc8c, 0x180620288);
        }
    }
    *(undefined8 *)(puVar15 + -8) = 0x18007870d;
    func_0x000180459870(*(uint64_t *)(puVar15 + 0x98) ^ (uint64_t)puVar15);
    return;
joined_r0x00018007861e:
    puVar14 = puVar18;
    if (puVar13 == puVar17) goto code_r0x000180078672;
    piVar12 = &var_70h;
    if (0xf < (uint64_t)iVar7) {
        piVar12 = (int64_t *)iVar6;
    }
    puVar10 = puVar13;
    if (0xf < (uint64_t)puVar13[3]) {
        puVar10 = (undefined8 *)*puVar13;
    }
    if ((puVar13[2] == iVar4) &&
       ((puVar14 = puVar13, puVar13[2] == 0 || (iVar9 = func_0x000180497f30(puVar10, piVar12), iVar9 == 0))))
    goto code_r0x000180078672;
    puVar13 = puVar13 + 0x13;
    goto joined_r0x00018007861e;
}

// ============================================================
// Function: FUN_1800787e0
// Address: 0x1800787e0
// Size: 710 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a1h
// WARNING: [rz-ghidra] Detected overlap for variable var_a2h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.1800787e0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    undefined auStack_118 [32];
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    undefined var_a4h;
    undefined var_a2h;
    undefined2 var_a1h;
    int64_t var_9eh;
    int64_t var_7ch;
    int64_t var_6ch;
    int64_t var_64h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)0x180781f28;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    iVar2 = func_0x00018046d050(0x2ce0);
    var_38h = (int64_t)&var_e0h;
    var_e8h = iVar2;
    var_30h = iVar2;
    if (iVar2 != 0) {
        iVar2 = func_0x0001800f8690(iVar2, 0);
    }
    *(int64_t *)0x180781f28 = iVar2;
    func_0x0001800f97a0();
    if (iVar1 != 0) {
        *(int64_t *)0x180781f28 = iVar1;
    }
    uVar3 = (*(code *)0x69a69a)(*(undefined8 *)0x180781f08, 2);
    func_0x00018016a3b0(uVar3);
    *(undefined4 *)0x1806a4604 = fcn.180076010();
    fcn.180076220(*(int64_t *)0x180781f28 + 0x30);
    iVar1 = *(int64_t *)0x180781f28;
    var_f8h = 0x1805cfea0;
    func_0x000180078ab0();
    func_0x0001804986e0(&var_d8h, 0, 0xa0);
    var_64h._0_4_ = 0x3f800000;
    var_7ch._0_4_ = 0x7f7fffff;
    var_6ch._0_4_ = 0x3f800000;
    var_9eh._0_2_ = 0;
    var_a4h = 0;
    var_a1h = 0x203;
    var_a2h = 1;
    var_9eh._2_4_ = 0x42000000;
    var_6ch._4_4_ = 0x3f800000;
    var_e8h = func_0x000180127690(*(undefined8 *)(iVar1 + 0x68), &var_d8h);
    func_0x00018007c4f0(0x180782328, &var_e8h);
    var_9eh._2_4_ = 0x42800000;
    var_6ch._4_4_ = 0x40000000;
    var_e8h = func_0x000180127690(*(undefined8 *)(iVar1 + 0x68), &var_d8h);
    func_0x00018007c4f0(0x1807821e8, &var_e8h);
    var_f8h = 0x1805b5380;
    func_0x000180078ab0();
    var_f8h = 0x1805c5040;
    func_0x000180078ab0();
    func_0x0001804986e0(&var_d8h, 0, 0xa0);
    var_64h._0_4_ = 0x3f800000;
    var_7ch._0_4_ = 0x7f7fffff;
    var_6ch._0_4_ = 0x3f800000;
    var_9eh._0_2_ = 0;
    var_a4h = 0;
    var_a1h = 0x203;
    var_a2h = 1;
    var_9eh._2_4_ = 0x42000000;
    var_6ch._4_4_ = 0x3f800000;
    var_f8h = (int64_t)&var_d8h;
    var_e8h = func_0x0001801279b0(*(undefined8 *)(iVar1 + 0x68), 0x18073ec10, 0x383d4, 0x42000000);
    func_0x00018007c4f0(0x180782328, &var_e8h);
    var_9eh._2_4_ = 0x42800000;
    var_6ch._4_4_ = 0x40000000;
    var_f8h = (int64_t)&var_d8h;
    var_e8h = func_0x0001801279b0(*(undefined8 *)(iVar1 + 0x68), 0x18073ec10, 0x383d4, 0x42800000);
    func_0x00018007c4f0(0x1807821e8, &var_e8h);
    func_0x000180167a10(*(undefined8 *)0x180781f08);
    func_0x000180167380();
    func_0x000180166d80();
    func_0x000180459870(var_28h ^ (uint64_t)auStack_118);
    return;
}

// ============================================================
// Function: FUN_180078ab0
// Address: 0x180078ab0
// Size: 263 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_72h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_eeh
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h

void fcn.180078ab0(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t var_8h;
    int64_t var_b8h;
    int64_t var_a8h;
    undefined var_74h;
    undefined var_72h;
    undefined2 var_71h;
    int64_t var_6eh;
    int64_t in_stack_ffffffffffffffa0;
    int64_t var_4ch;
    int64_t var_3ch;
    int64_t var_34h;
    
    var_8h = arg1;
    fcn.1804986e0(&var_a8h, 0, 0xa0);
    var_6eh._0_2_ = 0;
    var_74h = 0;
    var_71h = 0x203;
    var_72h = 1;
    var_6eh._2_4_ = 0x42000000;
    var_8h = fcn.180127ea0(in_stack_ffffffffffffffa0);
    fcn.18007c4f0(0x180782328, &var_8h);
    var_6eh._2_4_ = 0x42800000;
    var_8h = fcn.180127ea0(in_stack_ffffffffffffffa0);
    fcn.18007c4f0(0x1807821e8, &var_8h);
    return;
}

// ============================================================
// Function: FUN_180078bc0
// Address: 0x180078bc0
// Size: 4028 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180078bc0(int64_t arg1, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                  int64_t arg_a0h, int64_t arg_b0h, int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_e0h,
                  int64_t arg_f0h, int64_t arg_100h, int64_t arg_108h, int64_t arg_110h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    char *pcVar3;
    undefined4 uVar4;
    int16_t iVar5;
    undefined8 *puVar6;
    undefined8 uVar7;
    code *pcVar8;
    undefined auVar9 [16];
    undefined auVar10 [16];
    bool bVar11;
    undefined *puVar12;
    undefined4 uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    int64_t iVar16;
    int64_t *piVar17;
    int64_t iVar18;
    uint32_t *puVar19;
    int64_t *piVar20;
    uint64_t uVar21;
    undefined8 *puVar22;
    char *pcVar23;
    float *pfVar24;
    undefined *puVar25;
    undefined8 *puVar26;
    int64_t iVar27;
    int32_t iVar28;
    int64_t *piVar29;
    uint64_t uVar30;
    float fVar31;
    undefined auVar32 [16];
    undefined8 extraout_XMM0_Qb;
    undefined auVar33 [16];
    float fVar34;
    float fVar35;
    undefined auVar36 [16];
    float fVar37;
    float fVar38;
    undefined auVar39 [16];
    float fVar40;
    undefined8 uStack_310;
    undefined auStack_308 [8];
    undefined auStack_300 [24];
    int64_t var_2e8h;
    int64_t var_2e0h;
    int64_t var_2d8h;
    int64_t var_2d0h;
    int64_t var_2c8h;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_290h;
    undefined8 uStack_288;
    undefined4 uStack_280;
    undefined4 uStack_27c;
    undefined4 uStack_278;
    undefined4 uStack_274;
    undefined4 uStack_270;
    undefined4 uStack_26c;
    float fStack_268;
    float fStack_264;
    float fStack_260;
    float fStack_25c;
    float fStack_258;
    float fStack_254;
    int64_t *piStack_250;
    undefined4 uStack_248;
    undefined4 uStack_244;
    undefined4 uStack_240;
    float fStack_23c;
    undefined4 uStack_238;
    undefined4 uStack_234;
    undefined4 uStack_230;
    int32_t iStack_22c;
    int64_t aiStack_228 [17];
    undefined4 uStack_19c;
    undefined8 uStack_198;
    undefined8 uStack_190;
    undefined8 uStack_188;
    undefined4 uStack_180;
    undefined auStack_178 [16];
    undefined auStack_168 [16];
    undefined auStack_158 [16];
    undefined8 uStack_148;
    undefined uStack_140;
    float afStack_138 [8];
    undefined auStack_118 [16];
    undefined8 uStack_108;
    uint64_t uStack_100;
    uint64_t uStack_f8;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_18h;
    int64_t var_10h;
    
    uVar21 = *(uint64_t *)0x18077af50;
    puVar25 = auStack_308;
    uStack_f8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_308;
    puVar22 = (undefined8 *)0x0;
    var_298h._0_4_ = 0;
    _var_2b0h = ZEXT816(0);
    var_2a0h = 0;
    puVar12 = auStack_308;
    if (*(uint64_t *)0x18077af50 != 0) {
        if (0xfffffffffffffff < *(uint64_t *)0x18077af50) {
            func_0x000180010010();
            pcVar8 = (code *)swi(3);
            (*pcVar8)();
            return;
        }
        uVar30 = *(uint64_t *)0x18077af50 * 0x10;
        if (uVar30 == 0) {
code_r0x000180078cba:
            iVar16 = var_2a8h;
            puVar6 = puVar22;
            for (puVar26 = (undefined8 *)var_2b0h; puVar26 != (undefined8 *)var_2a8h; puVar26 = puVar26 + 2) {
                *puVar6 = 0;
                puVar6[1] = 0;
                *puVar6 = *puVar26;
                puVar6[1] = puVar26[1];
                *puVar26 = 0;
                puVar26[1] = 0;
                puVar6 = puVar6 + 2;
            }
            if (var_2b0h != 0) {
                iVar27 = var_2b0h;
                if (var_2b0h != var_2a8h) {
                    do {
                        func_0x00018000d070(iVar27);
                        iVar27 = iVar27 + 0x10;
                    } while (iVar27 != iVar16);
                }
                uVar30 = var_2a0h - var_2b0h & 0xfffffffffffffff0;
                iVar16 = var_2b0h;
                if (0xfff < uVar30) {
                    iVar16 = *(int64_t *)(var_2b0h + -8);
                    if (0x1f < (var_2b0h - iVar16) - 8U) goto code_r0x000180078d70;
                    uVar30 = uVar30 + 0x27;
                }
                func_0x000180459c3c(iVar16, uVar30);
            }
            var_2a8h = (int64_t)puVar22;
            var_2b0h = (int64_t)puVar22;
            var_2a0h = (int64_t)(puVar22 + uVar21 * 2);
            goto code_r0x000180078d7c;
        }
        if (uVar30 < 0x1000) {
            puVar22 = (undefined8 *)func_0x000180459890(uVar30);
            goto code_r0x000180078cba;
        }
        if (uVar30 + 0x27 <= uVar30) {
            func_0x000180004720();
            pcVar8 = (code *)swi(3);
            (*pcVar8)();
            return;
        }
        iVar16 = func_0x000180459890();
        if (iVar16 != 0) {
            puVar22 = (undefined8 *)(iVar16 + 0x27U & 0xffffffffffffffe0);
            puVar22[-1] = iVar16;
            goto code_r0x000180078cba;
        }
code_r0x000180078d70:
        pcVar8 = (code *)swi(0x29);
        (*pcVar8)(5);
        puVar12 = auStack_300;
    }
    puVar25 = puVar12;
    puVar22 = *(undefined8 **)(puVar25 + 0x60);
code_r0x000180078d7c:
    puVar26 = *(undefined8 **)0x18077af48;
    for (puVar6 = (undefined8 *)**(undefined8 **)0x18077af48; puVar6 != puVar26; puVar6 = (undefined8 *)*puVar6) {
        if (puVar22 == *(undefined8 **)(puVar25 + 0x68)) {
            *(undefined8 *)(puVar25 + -8) = 0x180078dda;
            func_0x00018007fd60(puVar25 + 0x58, puVar22);
            puVar22 = *(undefined8 **)(puVar25 + 0x60);
        } else {
            *puVar22 = 0;
            puVar22[1] = 0;
            if (puVar6[3] != 0) {
                LOCK();
                piVar2 = (int32_t *)(puVar6[3] + 8);
                *piVar2 = *piVar2 + 1;
                UNLOCK();
            }
            *puVar22 = puVar6[2];
            puVar22[1] = puVar6[3];
            puVar22 = (undefined8 *)(*(int64_t *)(puVar25 + 0x60) + 0x10);
            *(undefined8 **)(puVar25 + 0x60) = puVar22;
        }
    }
    *(undefined8 *)(puVar25 + -8) = 0x180078e04;
    func_0x00018007caa0(*(int64_t *)(puVar25 + 0x58), puVar22, (int64_t)puVar22 - *(int64_t *)(puVar25 + 0x58) >> 4, 
                        puVar25[0x50]);
    piVar29 = *(int64_t **)(puVar25 + 0x58);
    piVar20 = *(int64_t **)(puVar25 + 0x60);
    *(int64_t **)(puVar25 + 0x78) = piVar20;
    piStack_250 = piVar29;
    if (piVar29 != piVar20) {
        do {
            iVar16 = *piVar29;
            if (*(char *)(iVar16 + 8) != '\0') {
                uStack_278 = *(undefined4 *)(iVar16 + 0x14);
                uStack_274 = *(undefined4 *)(iVar16 + 0x18);
                uStack_270 = *(undefined4 *)(iVar16 + 0x1c);
                uStack_26c = *(undefined4 *)(iVar16 + 0x10);
                piStack_250 = piVar29;
    // switch table (7 cases) at 0x180079b60
                switch(*(undefined4 *)(iVar16 + 0x30)) {
                case 0:
                    if (piVar29[1] != 0) {
                        LOCK();
                        piVar2 = (int32_t *)(piVar29[1] + 8);
                        *piVar2 = *piVar2 + 1;
                        UNLOCK();
                    }
                    piVar17 = (int64_t *)piVar29[1];
                    if (piVar17 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar17 + 1;
                        iVar15 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar15 == 1) {
                            pcVar8 = *(code **)*piVar17;
                            *(undefined8 *)(puVar25 + -8) = 0x18007924b;
                            (*pcVar8)(piVar17);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar17 + 0xc);
                            iVar15 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar15 == 1) {
                                pcVar8 = *(code **)(*piVar17 + 8);
                                *(undefined8 *)(puVar25 + -8) = 0x180079263;
                                (*pcVar8)(piVar17);
                            }
                        }
                    }
                    iVar27 = *(int64_t *)0x180782330;
                    iVar18 = *(int64_t *)0x180782328;
                    if (40.0 < *(float *)(iVar16 + 0x7c)) {
                        iVar27 = *(int64_t *)0x1807821f0;
                        iVar18 = *(int64_t *)0x1807821e8;
                    }
                    if ((uint64_t)(iVar27 - iVar18 >> 3) <= (uint64_t)(int64_t)*(int32_t *)(iVar16 + 0x70))
                    goto code_r0x000180079b4c;
                    iVar27 = *(int64_t *)(iVar18 + (int64_t)*(int32_t *)(iVar16 + 0x70) * 8);
                    *(undefined8 *)(puVar25 + -8) = 0x1800792af;
                    func_0x000180065fc0(iVar27);
                    piVar17 = (int64_t *)(iVar16 + 0x38);
                    aiStack_228[0] = 0x18063d288;
                    iVar15 = 0;
                    uStack_190 = 0;
                    uStack_188 = 0;
                    uStack_180 = 0;
                    auStack_178 = ZEXT816(0);
                    auStack_168 = ZEXT816(0);
                    uStack_148 = 0;
                    uStack_140 = 0;
                    *(uint32_t *)(puVar25 + 0x70) = *(uint32_t *)(puVar25 + 0x70) | 1;
                    uStack_198 = 0x1804a5600;
                    uStack_19c = 0x78;
                    aiStack_228[1] = 0;
                    *(undefined8 *)(puVar25 + -8) = 0x18007932a;
                    auStack_158 = auStack_178;
                    func_0x00018000fe50(&uStack_198, aiStack_228 + 2, 0);
                    *(undefined8 *)((int64_t)aiStack_228 + (int64_t)*(int32_t *)(aiStack_228[0] + 4)) = 0x1804a5868;
                    *(int32_t *)((int64_t)&iStack_22c + (int64_t)*(int32_t *)(aiStack_228[0] + 4)) =
                         *(int32_t *)(aiStack_228[0] + 4) + -0x90;
                    uStack_288 = aiStack_228 + 2;
                    *(undefined8 *)(puVar25 + -8) = 0x180079362;
                    func_0x00018000fd90(aiStack_228 + 2);
                    aiStack_228[2] = 0x1804a5580;
                    uVar7 = *(undefined8 *)(iVar16 + 0x48);
                    if (0xf < *(uint64_t *)(iVar16 + 0x50)) {
                        piVar17 = (int64_t *)*piVar17;
                    }
                    *(undefined8 *)(puVar25 + -8) = 0x18007938e;
                    func_0x00018007ec20(aiStack_228 + 2, piVar17, uVar7, 2);
                    uStack_108 = 0;
                    uStack_100 = 0xf;
                    auStack_118._1_15_ = SUB1615(ZEXT816(0), 1);
                    auVar9[15] = 0;
                    auVar9._0_15_ = auStack_118._1_15_;
                    auStack_118 = auVar9 << 8;
                    uStack_288 = (int64_t *)((uint64_t)uStack_288 & 0xffffffff00000000);
                    iVar28 = *(int32_t *)(aiStack_228[0] + 4);
                    *(undefined8 *)(puVar25 + -8) = 0x1800793cc;
                    func_0x000180010030((int64_t)aiStack_228 + (int64_t)iVar28, 10);
                    *(undefined8 *)(puVar25 + -8) = 0x1800793e0;
                    piVar17 = (int64_t *)func_0x00018007d3a0(aiStack_228, auStack_118);
                    if ((*(uint8_t *)((int64_t)*(int32_t *)(*piVar17 + 4) + 0x10 + (int64_t)piVar17) & 6) == 0) {
                        do {
                            pcVar23 = auStack_118;
                            if (0xf < uStack_100) {
                                pcVar23 = (char *)auStack_118._0_8_;
                            }
                            fVar38 = *(float *)(iVar16 + 0x7c);
                            *(undefined8 *)(puVar25 + -8) = 0x180079425;
                            iVar18 = func_0x000180498cd0(pcVar23);
                            pcVar3 = pcVar23 + iVar18;
                            *(undefined8 *)(puVar25 + -8) = 0x18007943d;
                            puVar19 = (uint32_t *)func_0x00018012ec80(iVar27);
                            fVar35 = (float)puVar19[5];
                            auVar39 = ZEXT816(0);
                            fVar40 = 0.0;
                            auVar36 = ZEXT816(0);
                            while( true ) {
                                fVar34 = auVar36._0_4_;
                                fVar37 = auVar39._0_4_;
                                if (pcVar3 <= pcVar23) break;
                                uVar14 = (uint32_t)*pcVar23;
                                uVar21 = (uint64_t)uStack_288 >> 0x20;
                                uStack_288 = (int64_t *)CONCAT44((int32_t)uVar21, uVar14);
                                if (uVar14 < 0x80) {
                                    pcVar23 = pcVar23 + 1;
                                } else {
                                    *(undefined8 *)(puVar25 + -8) = 0x180079482;
                                    iVar28 = func_0x0001800f5c80(&uStack_288, pcVar23, pcVar3);
                                    pcVar23 = pcVar23 + iVar28;
                                    uVar14 = (uint32_t)uStack_288;
                                }
                                if (uVar14 == 10) {
                                    if (fVar37 <= fVar34) {
                                        auVar39._0_4_ = fVar34;
                                    }
                                    fVar40 = fVar40 + fVar38;
                                    auVar36 = ZEXT816(0);
                                } else if (uVar14 != 0xd) {
                                    if ((*puVar19 <= uVar14) ||
                                       (fVar31 = *(float *)(*(int64_t *)(puVar19 + 2) + (uint64_t)uVar14 * 4),
                                       auVar32 = ZEXT416((uint32_t)fVar31), fVar31 < 0.0)) {
                                        *(undefined8 *)(puVar25 + -8) = 0x1800794c1;
                                        auVar32._0_8_ = func_0x00018012bbd0(puVar19);
                                        auVar32._8_8_ = extraout_XMM0_Qb;
                                    }
                                    fVar31 = auVar32._0_4_ * (fVar38 / fVar35) + fVar34;
                                    if (3.402823e+38 <= fVar31) break;
                                    auVar36._4_4_ = auVar32._4_4_;
                                    auVar36._0_4_ = fVar31;
                                    auVar36._8_4_ = auVar32._8_4_;
                                    auVar36._12_4_ = auVar32._12_4_;
                                }
                            }
                            if ((0.0 < fVar34) || (fVar40 == 0.0)) {
                                fVar40 = fVar40 + fVar38;
                            }
                            fVar38 = *(float *)(iVar16 + 0x58);
                            if (*(char *)(iVar16 + 0x78) != '\0') {
                                if (fVar34 <= fVar37) {
                                    auVar36._0_4_ = fVar37;
                                }
                                fVar38 = fVar38 - auVar36._0_4_ * 0.5;
                            }
                            fVar35 = (float)iVar15 * fVar40 + *(float *)(iVar16 + 0x5c);
                            if ((*(char *)(iVar16 + 0x79) != '\0') && (0.0 < *(float *)(iVar16 + 0x74))) {
                                uStack_248 = *(undefined4 *)(iVar16 + 0x60);
                                uStack_244 = *(undefined4 *)(iVar16 + 100);
                                uStack_240 = *(undefined4 *)(iVar16 + 0x68);
                                afStack_138[0] = 1.0;
                                afStack_138[1] = 1.0;
                                afStack_138[2] = -1.0;
                                afStack_138[3] = -1.0;
                                afStack_138[4] = 1.0;
                                afStack_138[5] = -1.0;
                                afStack_138[6] = -1.0;
                                afStack_138[7] = 1.0;
                                pfVar24 = afStack_138;
                                fStack_23c = *(float *)(iVar16 + 0x74);
                                do {
                                    pcVar23 = auStack_118;
                                    if (0xf < uStack_100) {
                                        pcVar23 = (char *)auStack_118._0_8_;
                                    }
                                    *(undefined8 *)(puVar25 + -8) = 0x180079590;
                                    uVar14 = func_0x0001800f5fa0(&uStack_248);
                                    fStack_260 = fVar38 + *pfVar24;
                                    fStack_25c = fVar35 + pfVar24[1];
                                    if ((((uVar14 & 0xff000000) != 0) && (pcVar23 != (char *)0x0)) && (*pcVar23 != '\0')
                                       ) {
                                        iVar18 = iVar27;
                                        if (iVar27 == 0) {
                                            iVar18 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x18);
                                        }
                                        uStack_288 = *(int64_t **)(arg1 + 0x60);
                                        uStack_280 = *(undefined4 *)(arg1 + 0x68);
                                        uStack_27c = *(undefined4 *)(arg1 + 0x6c);
                                        *(undefined4 *)(puVar25 + 0x48) = 0;
                                        *(undefined4 *)(puVar25 + 0x40) = 0;
                                        *(undefined8 *)(puVar25 + 0x38) = 0;
                                        *(char **)(puVar25 + 0x30) = pcVar23;
                                        *(undefined8 **)(puVar25 + 0x28) = &uStack_288;
                                        *(uint32_t *)(puVar25 + 0x20) = uVar14;
                                        *(undefined8 *)(puVar25 + -8) = 0x18007961f;
                                        func_0x00018012f9d0(iVar18, arg1);
                                    }
                                    pfVar24 = pfVar24 + 2;
                                } while (pfVar24 != (float *)auStack_118);
                            }
                            pcVar23 = auStack_118;
                            if (0xf < uStack_100) {
                                pcVar23 = (char *)auStack_118._0_8_;
                            }
                            *(undefined8 *)(puVar25 + -8) = 0x180079653;
                            uVar14 = func_0x0001800f5fa0(&uStack_278);
                            fStack_258 = fVar38;
                            fStack_254 = fVar35;
                            if ((((uVar14 & 0xff000000) != 0) && (pcVar23 != (char *)0x0)) && (*pcVar23 != '\0')) {
                                iVar18 = iVar27;
                                if (iVar27 == 0) {
                                    iVar18 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x18);
                                }
                                uStack_288 = *(int64_t **)(arg1 + 0x60);
                                uStack_280 = *(undefined4 *)(arg1 + 0x68);
                                uStack_27c = *(undefined4 *)(arg1 + 0x6c);
                                *(undefined4 *)(puVar25 + 0x48) = 0;
                                *(undefined4 *)(puVar25 + 0x40) = 0;
                                *(undefined8 *)(puVar25 + 0x38) = 0;
                                *(char **)(puVar25 + 0x30) = pcVar23;
                                *(undefined8 **)(puVar25 + 0x28) = &uStack_288;
                                *(uint32_t *)(puVar25 + 0x20) = uVar14;
                                *(undefined8 *)(puVar25 + -8) = 0x1800796d3;
                                func_0x00018012f9d0(iVar18, arg1);
                            }
                            iVar15 = iVar15 + 1;
                            iVar28 = *(int32_t *)(aiStack_228[0] + 4);
                            *(undefined8 *)(puVar25 + -8) = 0x1800796ec;
                            func_0x000180010030((int64_t)aiStack_228 + (int64_t)iVar28, 10);
                            *(undefined8 *)(puVar25 + -8) = 0x180079700;
                            piVar20 = (int64_t *)func_0x00018007d3a0(aiStack_228, auStack_118);
                        } while ((*(uint8_t *)((int64_t)*(int32_t *)(*piVar20 + 4) + 0x10 + (int64_t)piVar20) & 6) == 0)
                        ;
                        piVar20 = *(int64_t **)(puVar25 + 0x78);
                        piVar29 = piStack_250;
                    }
                    *(undefined8 *)(puVar25 + -8) = 0x180079720;
                    func_0x000180107520();
                    if (0xf < uStack_100) {
                        uVar21 = uStack_100 + 1;
                        iVar16 = auStack_118._0_8_;
                        if (0xfff < uVar21) {
                            iVar16 = *(int64_t *)(auStack_118._0_8_ + -8);
                            if (0x1f < (auStack_118._0_8_ - iVar16) - 8U) {
                                pcVar8 = (code *)swi(0x29);
                                (*pcVar8)(5);
                                puVar25 = puVar25 + 8;
                                goto code_r0x000180079b45;
                            }
                            uVar21 = uStack_100 + 0x28;
                        }
                        *(undefined8 *)(puVar25 + -8) = 0x180079762;
                        func_0x000180459c3c(iVar16, uVar21);
                    }
                    uStack_108 = 0;
                    uStack_100 = 0xf;
                    auVar10[15] = 0;
                    auVar10._0_15_ = auStack_118._1_15_;
                    auStack_118 = auVar10 << 8;
                    *(undefined8 *)((int64_t)aiStack_228 + (int64_t)*(int32_t *)(aiStack_228[0] + 4)) = 0x1804a5868;
                    *(int32_t *)((int64_t)&iStack_22c + (int64_t)*(int32_t *)(aiStack_228[0] + 4)) =
                         *(int32_t *)(aiStack_228[0] + 4) + -0x90;
                    *(undefined8 *)(puVar25 + -8) = 0x1800797ad;
                    func_0x00018000c970(aiStack_228 + 2);
                    *(undefined8 *)((int64_t)aiStack_228 + (int64_t)*(int32_t *)(aiStack_228[0] + 4)) = 0x1804a5600;
                    *(int32_t *)((int64_t)&iStack_22c + (int64_t)*(int32_t *)(aiStack_228[0] + 4)) =
                         *(int32_t *)(aiStack_228[0] + 4) + -0x18;
                    uStack_198 = 0x1804a54d0;
                    *(undefined8 *)(puVar25 + -8) = 0x1800797e4;
                    func_0x000180455c14(&uStack_198);
                    break;
                case 1:
                    if (piVar29[1] != 0) {
                        LOCK();
                        piVar2 = (int32_t *)(piVar29[1] + 8);
                        *piVar2 = *piVar2 + 1;
                        UNLOCK();
                    }
                    piVar17 = (int64_t *)piVar29[1];
                    if (piVar17 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar17 + 1;
                        iVar15 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar15 == 1) {
                            pcVar8 = *(code **)*piVar17;
                            *(undefined8 *)(puVar25 + -8) = 0x180078ecd;
                            (*pcVar8)(piVar17);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar17 + 0xc);
                            iVar15 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar15 == 1) {
                                pcVar8 = *(code **)(*piVar17 + 8);
                                *(undefined8 *)(puVar25 + -8) = 0x180078ee5;
                                (*pcVar8)(piVar17);
                            }
                        }
                    }
                    iVar15 = *(int32_t *)(iVar16 + 0x48);
                    *(undefined8 *)(puVar25 + -8) = 0x180078ef6;
                    uVar13 = func_0x0001800f5fa0(&uStack_278);
                    *(float *)(puVar25 + 0x20) = (float)iVar15;
                    *(undefined8 *)(puVar25 + -8) = 0x180078f0f;
                    func_0x000180126300(arg1, iVar16 + 0x38, iVar16 + 0x40, uVar13);
                    break;
                case 2:
                    if (piVar29[1] != 0) {
                        LOCK();
                        piVar2 = (int32_t *)(piVar29[1] + 8);
                        *piVar2 = *piVar2 + 1;
                        UNLOCK();
                    }
                    piVar17 = (int64_t *)piVar29[1];
                    if (piVar17 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar17 + 1;
                        iVar15 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar15 == 1) {
                            pcVar8 = *(code **)*piVar17;
                            *(undefined8 *)(puVar25 + -8) = 0x180078fda;
                            (*pcVar8)(piVar17);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar17 + 0xc);
                            iVar15 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar15 == 1) {
                                pcVar8 = *(code **)(*piVar17 + 8);
                                *(undefined8 *)(puVar25 + -8) = 0x180078ff2;
                                (*pcVar8)(piVar17);
                            }
                        }
                    }
                    fStack_268 = *(float *)(iVar16 + 0x40) + *(float *)(iVar16 + 0x38);
                    fStack_264 = *(float *)(iVar16 + 0x44) + *(float *)(iVar16 + 0x3c);
                    *(undefined8 *)(puVar25 + -8) = 0x180079019;
                    uVar13 = func_0x0001800f5fa0(&uStack_278);
                    if (*(char *)(iVar16 + 0x4c) == '\0') {
                        *(float *)(puVar25 + 0x30) = (float)*(int32_t *)(iVar16 + 0x48);
                        *(undefined4 *)(puVar25 + 0x20) = 0;
                        *(undefined8 *)(puVar25 + -8) = 0x18007905d;
                        func_0x000180126460(arg1, iVar16 + 0x38, &fStack_268, uVar13);
                    } else {
                        *(undefined4 *)(puVar25 + 0x28) = 0;
                        *(undefined4 *)(puVar25 + 0x20) = 0;
                        *(undefined8 *)(puVar25 + -8) = 0x18007903e;
                        func_0x000180126550();
                    }
                    break;
                case 3:
                    if (piVar29[1] != 0) {
                        LOCK();
                        piVar2 = (int32_t *)(piVar29[1] + 8);
                        *piVar2 = *piVar2 + 1;
                        UNLOCK();
                    }
                    piVar17 = (int64_t *)piVar29[1];
                    if (piVar17 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar17 + 1;
                        iVar15 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar15 == 1) {
                            pcVar8 = *(code **)*piVar17;
                            *(undefined8 *)(puVar25 + -8) = 0x18007908f;
                            (*pcVar8)(piVar17);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar17 + 0xc);
                            iVar15 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar15 == 1) {
                                pcVar8 = *(code **)(*piVar17 + 8);
                                *(undefined8 *)(puVar25 + -8) = 0x1800790a7;
                                (*pcVar8)(piVar17);
                            }
                        }
                    }
                    *(undefined8 *)(puVar25 + -8) = 0x1800790b0;
                    uVar14 = func_0x0001800f5fa0(&uStack_278);
                    if (*(char *)(iVar16 + 0x54) == '\0') {
                        *(float *)(puVar25 + 0x28) = (float)*(int32_t *)(iVar16 + 0x50);
                        *(uint32_t *)(puVar25 + 0x20) = uVar14;
                        *(undefined8 *)(puVar25 + -8) = 0x18007911c;
                        func_0x0001801266e0(arg1, iVar16 + 0x38, iVar16 + 0x40, iVar16 + 0x48);
                    } else if ((uVar14 & 0xff000000) != 0) {
                        *(undefined8 *)(puVar25 + -8) = 0x1800790cf;
                        func_0x0001800f3b50(arg1, iVar16 + 0x38);
                        *(undefined8 *)(puVar25 + -8) = 0x1800790db;
                        func_0x0001800f3b50(arg1, iVar16 + 0x40);
                        iVar16 = iVar16 + 0x48;
code_r0x0001800790df:
                        *(undefined8 *)(puVar25 + -8) = 0x1800790e7;
                        func_0x0001800f3b50(arg1, iVar16);
                        *(undefined8 *)(puVar25 + -8) = 0x1800790f1;
                        func_0x0001800f3bc0(arg1, uVar14);
                    }
                    break;
                case 4:
                    if (piVar29[1] != 0) {
                        LOCK();
                        piVar2 = (int32_t *)(piVar29[1] + 8);
                        *piVar2 = *piVar2 + 1;
                        UNLOCK();
                    }
                    piVar17 = (int64_t *)piVar29[1];
                    if (piVar17 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar17 + 1;
                        iVar15 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar15 == 1) {
                            pcVar8 = *(code **)*piVar17;
                            *(undefined8 *)(puVar25 + -8) = 0x180078f41;
                            (*pcVar8)(piVar17);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar17 + 0xc);
                            iVar15 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar15 == 1) {
                                pcVar8 = *(code **)(*piVar17 + 8);
                                *(undefined8 *)(puVar25 + -8) = 0x180078f59;
                                (*pcVar8)(piVar17);
                            }
                        }
                    }
                    *(undefined8 *)(puVar25 + -8) = 0x180078f62;
                    func_0x0001800f5fa0(&uStack_278);
                    if (*(char *)(iVar16 + 0x40) == '\0') {
                        *(float *)(puVar25 + 0x28) = (float)*(int32_t *)(iVar16 + 0x48);
                        *(undefined4 *)(puVar25 + 0x20) = *(undefined4 *)(iVar16 + 0x4c);
                        *(undefined8 *)(puVar25 + -8) = 0x180078fa8;
                        func_0x000180126760(arg1, iVar16 + 0x38);
                    } else {
                        *(undefined4 *)(puVar25 + 0x20) = *(undefined4 *)(iVar16 + 0x4c);
                        *(undefined8 *)(puVar25 + -8) = 0x180078f86;
                        func_0x000180126840(arg1);
                    }
                    break;
                case 5:
                    if (piVar29[1] != 0) {
                        LOCK();
                        piVar2 = (int32_t *)(piVar29[1] + 8);
                        *piVar2 = *piVar2 + 1;
                        UNLOCK();
                    }
                    piVar17 = (int64_t *)piVar29[1];
                    if (piVar17 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar17 + 1;
                        iVar15 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar15 == 1) {
                            pcVar8 = *(code **)*piVar17;
                            *(undefined8 *)(puVar25 + -8) = 0x18007914e;
                            (*pcVar8)(piVar17);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar17 + 0xc);
                            iVar15 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar15 == 1) {
                                pcVar8 = *(code **)(*piVar17 + 8);
                                *(undefined8 *)(puVar25 + -8) = 0x180079166;
                                (*pcVar8)(piVar17);
                            }
                        }
                    }
                    *(undefined8 *)(puVar25 + -8) = 0x18007916f;
                    uVar14 = func_0x0001800f5fa0(&uStack_278);
                    if (*(char *)(iVar16 + 0x5c) == '\0') {
                        if ((uVar14 & 0xff000000) != 0) {
                            iVar15 = *(int32_t *)(iVar16 + 0x58);
                            *(undefined8 *)(puVar25 + -8) = 0x1800791d0;
                            func_0x0001800f3b50(arg1, iVar16 + 0x38);
                            *(undefined8 *)(puVar25 + -8) = 0x1800791dc;
                            func_0x0001800f3b50(arg1, iVar16 + 0x40);
                            *(undefined8 *)(puVar25 + -8) = 0x1800791e8;
                            func_0x0001800f3b50(arg1, iVar16 + 0x48);
                            *(undefined8 *)(puVar25 + -8) = 0x1800791f4;
                            func_0x0001800f3b50(arg1, iVar16 + 0x50);
                            *(float *)(puVar25 + 0x28) = (float)iVar15;
                            *(undefined4 *)(puVar25 + 0x20) = 1;
                            uVar13 = *(undefined4 *)(arg1 + 0x50);
                            uVar7 = *(undefined8 *)(arg1 + 0x58);
                            *(undefined8 *)(puVar25 + -8) = 0x180079215;
                            func_0x0001801248e0(arg1, uVar7, uVar13, uVar14);
                            *(undefined4 *)(arg1 + 0x50) = 0;
                        }
                    } else if ((uVar14 & 0xff000000) != 0) {
                        *(undefined8 *)(puVar25 + -8) = 0x180079193;
                        func_0x0001800f3b50(arg1, iVar16 + 0x38);
                        *(undefined8 *)(puVar25 + -8) = 0x18007919f;
                        func_0x0001800f3b50(arg1, iVar16 + 0x40);
                        *(undefined8 *)(puVar25 + -8) = 0x1800791ab;
                        func_0x0001800f3b50(arg1, iVar16 + 0x48);
                        iVar16 = iVar16 + 0x50;
                        goto code_r0x0001800790df;
                    }
                    break;
                case 6:
                    if (piVar29[1] != 0) {
                        LOCK();
                        piVar2 = (int32_t *)(piVar29[1] + 8);
                        *piVar2 = *piVar2 + 1;
                        UNLOCK();
                    }
                    piVar17 = (int64_t *)piVar29[1];
                    if (piVar17 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar17 + 1;
                        iVar15 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar15 == 1) {
                            pcVar8 = *(code **)*piVar17;
                            *(undefined8 *)(puVar25 + -8) = 0x18007981e;
                            (*pcVar8)(piVar17);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar17 + 0xc);
                            iVar15 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar15 == 1) {
                                pcVar8 = *(code **)(*piVar17 + 8);
                                *(undefined8 *)(puVar25 + -8) = 0x180079836;
                                (*pcVar8)(piVar17);
                            }
                        }
                    }
                    if (*(int64_t *)(iVar16 + 0x38) != *(int64_t *)(iVar16 + 0x40)) {
                        iVar27 = *(int64_t *)(iVar16 + 0x270);
                        if (iVar27 != 0) {
                            fVar38 = *(float *)(iVar16 + 600);
                            if ((fVar38 == 0.0) || (fVar35 = *(float *)(iVar16 + 0x25c), fVar35 == 0.0)) {
                                fVar38 = (float)*(int32_t *)(iVar16 + 0x268);
                                fVar35 = (float)*(int32_t *)(iVar16 + 0x26c);
                            }
                            uStack_238 = 0x3f800000;
                            uStack_234 = 0x3f800000;
                            uStack_230 = 0x3f800000;
                            iStack_22c = *(int32_t *)(iVar16 + 0x10);
                            *(undefined8 *)(puVar25 + -8) = 0x1800798b2;
                            uVar14 = func_0x0001800f5fa0(&uStack_238);
                            if ((uVar14 & 0xff000000) != 0) {
                                fVar35 = fVar35 + *(float *)(iVar16 + 0x254);
                                fVar38 = fVar38 + *(float *)(iVar16 + 0x250);
                                if ((iVar27 == *(int64_t *)(arg1 + 0x78)) && (*(int64_t *)(arg1 + 0x70) == 0)) {
                                    bVar11 = false;
                                } else {
                                    piVar2 = (int32_t *)(arg1 + 0xb0);
                                    iVar15 = *(int32_t *)(arg1 + 0xb4);
                                    if (*piVar2 == iVar15) {
                                        iVar28 = *piVar2 + 1;
                                        if (iVar15 == 0) {
                                            iVar15 = 8;
                                        } else {
                                            iVar15 = iVar15 / 2 + iVar15;
                                        }
                                        if (iVar28 < iVar15) {
                                            iVar28 = iVar15;
                                        }
                                        *(undefined8 *)(puVar25 + -8) = 0x18007991c;
                                        func_0x00018011faa0(piVar2, iVar28);
                                    }
                                    iVar15 = *piVar2;
                                    iVar18 = *(int64_t *)(arg1 + 0xb8);
                                    *(undefined8 *)(iVar18 + (int64_t)iVar15 * 0x10) = 0;
                                    *(int64_t *)(iVar18 + 8 + (int64_t)iVar15 * 0x10) = iVar27;
                                    *piVar2 = *piVar2 + 1;
                                    *(undefined8 *)(arg1 + 0x70) = 0;
                                    *(int64_t *)(arg1 + 0x78) = iVar27;
                                    *(undefined8 *)(puVar25 + -8) = 0x180079941;
                                    func_0x000180124360(arg1);
                                    bVar11 = true;
                                }
                                *(undefined8 *)(puVar25 + -8) = 0x180079956;
                                func_0x000180124680(arg1, 6, 4);
                                uVar13 = *(undefined4 *)(iVar16 + 0x254);
                                uVar4 = *(undefined4 *)(iVar16 + 0x250);
                                iVar5 = *(int16_t *)(arg1 + 0x34);
                                **(int16_t **)(arg1 + 0x48) = iVar5;
                                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar5 + 1;
                                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar5 + 2;
                                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar5;
                                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar5 + 2;
                                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar5 + 3;
                                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar16 + 0x250);
                                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 8) = 0;
                                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar14;
                                iVar16 = *(int64_t *)(arg1 + 0x40);
                                *(float *)(iVar16 + 0x14) = fVar38;
                                *(undefined4 *)(iVar16 + 0x18) = uVar13;
                                *(undefined8 *)(*(int64_t *)(arg1 + 0x40) + 0x1c) = 0x3f800000;
                                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar14;
                                iVar16 = *(int64_t *)(arg1 + 0x40);
                                *(float *)(iVar16 + 0x28) = fVar38;
                                *(float *)(iVar16 + 0x2c) = fVar35;
                                iVar16 = *(int64_t *)(arg1 + 0x40);
                                *(undefined4 *)(iVar16 + 0x30) = 0x3f800000;
                                *(undefined4 *)(iVar16 + 0x34) = 0x3f800000;
                                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x38) = uVar14;
                                iVar16 = *(int64_t *)(arg1 + 0x40);
                                *(undefined4 *)(iVar16 + 0x3c) = uVar4;
                                *(float *)(iVar16 + 0x40) = fVar35;
                                iVar16 = *(int64_t *)(arg1 + 0x40);
                                *(undefined4 *)(iVar16 + 0x44) = 0;
                                *(undefined4 *)(iVar16 + 0x48) = 0x3f800000;
                                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x4c) = uVar14;
                                auVar33._0_8_ = SUB168(*(undefined (*) [16])(arg1 + 0x40), 0) + 0x50;
                                auVar33._8_8_ = SUB168(*(undefined (*) [16])(arg1 + 0x40), 8) + 0xc;
                                *(undefined (*) [16])(arg1 + 0x40) = auVar33;
                                *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + 4;
                                if (bVar11) {
                                    *(undefined8 *)(puVar25 + -8) = 0x180079a60;
                                    func_0x000180124620(arg1);
                                }
                            }
                        }
                        piVar20 = *(int64_t **)(puVar25 + 0x78);
                    }
                }
            }
            piStack_250 = piVar29 + 2;
            piVar29 = piStack_250;
        } while (piStack_250 != piVar20);
        piVar20 = *(int64_t **)(puVar25 + 0x60);
        piVar29 = *(int64_t **)(puVar25 + 0x58);
    }
    if (piVar29 != (int64_t *)0x0) {
        if (piVar29 != piVar20) {
            do {
                *(undefined8 *)(puVar25 + -8) = 0x180079a99;
                func_0x00018000d070(piVar29);
                piVar29 = piVar29 + 2;
            } while (piVar29 != piVar20);
            piVar29 = *(int64_t **)(puVar25 + 0x58);
        }
        uVar21 = *(int64_t *)(puVar25 + 0x68) - (int64_t)piVar29 & 0xfffffffffffffff0;
        piVar20 = piVar29;
        if (0xfff < uVar21) {
            piVar20 = (int64_t *)piVar29[-1];
            if (0x1f < (uint64_t)((int64_t)piVar29 + (-8 - (int64_t)piVar20))) {
code_r0x000180079b45:
                pcVar8 = (code *)swi(0x29);
                (*pcVar8)(5);
                puVar25 = puVar25 + 8;
code_r0x000180079b4c:
                *(undefined8 *)(puVar25 + -8) = 0x180079b51;
                func_0x000180060370();
                pcVar8 = (code *)swi(3);
                (*pcVar8)();
                return;
            }
            uVar21 = uVar21 + 0x27;
        }
        *(undefined8 *)(puVar25 + -8) = 0x180079adc;
        func_0x000180459c3c(piVar20, uVar21);
    }
    *(undefined8 *)(puVar25 + -8) = 0x180079aeb;
    func_0x000180459870(uStack_f8 ^ (uint64_t)puVar25);
    return;
}

// ============================================================
// Function: FUN_180079b80
// Address: 0x180079b80
// Size: 116 bytes
// ============================================================
void fcn.180079b80(int64_t arg1)
{
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a5868;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x90;
    fcn.18000c970(arg1 + 0x10);
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a5600;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x18;
    *(undefined8 *)(arg1 + 0x90) = 0x1804a54d0;
    fcn.180455c14();
    return;
}

// ============================================================
// Function: FUN_180079c00
// Address: 0x180079c00
// Size: 415 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_188h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_170h
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch

void fcn.180079c00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, undefined8 placeholder_5,
                  int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    undefined auStack_1b8 [48];
    int32_t var_188h;
    int64_t var_184h;
    int64_t var_178h;
    int32_t var_170h;
    int64_t var_16ch;
    undefined8 var_164h;
    undefined4 var_15ch;
    int64_t var_158h;
    int32_t var_150h;
    int64_t var_14ch;
    undefined4 var_144h;
    undefined4 var_140h;
    int64_t var_13ch;
    int64_t var_134h;
    int64_t var_12ch;
    int64_t var_118h;
    int64_t var_108h;
    int64_t var_e8h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1b8;
    var_50h = arg1 + (int32_t)arg2;
    var_188h = 0;
    var_184h._0_4_ = 0;
    var_108h = 0;
    var_e8h._0_4_ = 0;
    var_60h._0_4_ = 0;
    var_58h = arg1;
    var_48h = arg1;
    var_40h = var_50h;
    iVar2 = func_0x000180069540(&var_118h, &var_188h, &var_184h);
    if (iVar2 != 0) {
        var_14ch._0_4_ = (undefined4)var_184h;
        var_150h = var_188h;
        var_170h = var_188h * 4;
        var_13ch = 1;
        var_12ch = 0;
        var_14ch._4_4_ = 1;
        var_144h = 1;
        var_140h = 0x1c;
        var_134h._0_4_ = 0;
        var_134h._4_4_ = 8;
        var_16ch._0_4_ = 0;
        stack0xfffffffffffffe80 = (int64_t *)0x0;
        var_178h = iVar2;
        iVar1 = (**(code **)(**(int64_t **)0x1807821d0 + 0x28))
                          (*(int64_t **)0x1807821d0, &var_150h, &var_178h, (int64_t)&var_184h + 4);
        if (iVar1 < 0) {
            func_0x000180460d90(iVar2);
        } else {
            var_158h = 0;
            var_16ch._4_4_ = 0x1c;
            var_164h = 4;
            var_15ch = 1;
            iVar1 = (**(code **)(**(int64_t **)0x1807821d0 + 0x38))
                              (*(int64_t **)0x1807821d0, stack0xfffffffffffffe80, (int64_t)&var_16ch + 4, arg3);
            (**(code **)(*stack0xfffffffffffffe80 + 0x10))();
            if (iVar1 < 0) {
                func_0x000180460d90(iVar2);
            } else {
                func_0x000180460d90(iVar2);
                *(int32_t *)arg4 = var_188h;
                *(undefined4 *)arg_28h = (undefined4)var_184h;
            }
        }
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStack_1b8);
    return;
}

// ============================================================
// Function: FUN_180079da0
// Address: 0x180079da0
// Size: 284 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_dh

undefined8 fcn.180079da0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 uVar1;
    uint32_t uVar2;
    int64_t var_38h;
    
    uVar2 = (uint32_t)arg2;
    if ((uVar2 == 0x100) && (arg3 == 0x2d)) {
        LOCK();
        *(char *)0x1807824e0 = '\0';
        UNLOCK();
    } else {
        if (*(char *)0x1807824e0 == '\0') {
code_r0x000180079e40:
            uVar1 = (*(code *)0x69a4bc)(*(undefined8 *)0x1807821b8, arg1, arg2 & 0xffffffff, arg3, arg4);
            return uVar1;
        }
        if (*(int64_t *)0x180781f28 != 0) {
            fcn.180168ea0();
        }
        if (0x109 < uVar2) {
    // switch table (15 cases) at 0x180079e80
            switch(uVar2) {
            case 0x200:
            case 0x201:
            case 0x202:
            case 0x203:
            case 0x204:
            case 0x205:
            case 0x206:
            case 0x207:
            case 0x208:
            case 0x209:
            case 0x20a:
            case 0x20b:
            case 0x20c:
            case 0x20e:
                goto code_r0x000180079dca;
            default:
                goto code_r0x000180079e40;
            }
        }
        if (uVar2 != 0x109) {
    // switch table (7 cases) at 0x180079e64
            switch(uVar2) {
            case 0xff:
            case 0x100:
            case 0x101:
            case 0x102:
            case 0x104:
            case 0x105:
                break;
            default:
                goto code_r0x000180079e40;
            }
        }
    }
code_r0x000180079dca:
    return 0;
}

// ============================================================
// Function: FUN_180079ec0
// Address: 0x180079ec0
// Size: 9258 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_1d0h
// WARNING: Variable defined which should be unmapped: var_1c8h
// WARNING: Variable defined which should be unmapped: var_1c0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_24h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Removing unreachable block (ram,0x00018007bb9a)
// WARNING: Removing unreachable block (ram,0x00018007bbbc)
// WARNING: Removing unreachable block (ram,0x00018007bbcc)
// WARNING: Removing unreachable block (ram,0x00018007bbe1)
// WARNING: Removing unreachable block (ram,0x00018007bbe8)
// WARNING: Removing unreachable block (ram,0x00018007bd28)
// WARNING: Removing unreachable block (ram,0x00018007bd38)
// WARNING: Removing unreachable block (ram,0x00018007bd4d)
// WARNING: Removing unreachable block (ram,0x00018007bd54)
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ech
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1dch
// WARNING: [rz-ghidra] Detected overlap for variable var_1e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1e3h
// WARNING: [rz-ghidra] Detected overlap for variable var_1e1h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_1f7h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a1h
// WARNING: [rz-ghidra] Detected overlap for variable var_a2h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_beh
// WARNING: [rz-ghidra] Detected overlap for variable var_c1h
// WARNING: [rz-ghidra] Detected overlap for variable var_bdh
// WARNING: [rz-ghidra] Detected overlap for variable var_bah
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_f7h
// WARNING: [rz-ghidra] Detected overlap for variable var_f6h
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_49h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h

void fcn.180079ec0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h,
                  undefined8 placeholder_6, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint64_t *puVar1;
    undefined2 *puVar2;
    undefined4 *puVar3;
    float fVar4;
    undefined auVar5 [16];
    int16_t iVar6;
    undefined4 *puVar7;
    uint8_t *puVar8;
    code *pcVar9;
    int32_t *piVar10;
    undefined auVar11 [16];
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [12];
    undefined auVar18 [16];
    undefined4 *puVar19;
    int32_t iVar20;
    char cVar21;
    uint8_t uVar22;
    char cVar23;
    int32_t iVar24;
    undefined4 uVar25;
    undefined4 uVar26;
    int32_t iVar27;
    int64_t iVar28;
    int64_t iVar29;
    float *pfVar30;
    int64_t iVar31;
    undefined8 uVar32;
    undefined (*pauVar33) [16];
    int64_t *piVar34;
    char cVar35;
    uint8_t uVar36;
    int64_t iVar37;
    char **ppcVar38;
    undefined8 *******pppppppuVar39;
    undefined8 ******ppppppuVar40;
    undefined8 *******pppppppuVar41;
    char *pcVar42;
    int16_t iVar43;
    uint32_t uVar44;
    uint32_t uVar45;
    uint64_t uVar46;
    uint64_t uVar47;
    undefined8 *puVar48;
    uint64_t uVar49;
    int64_t *piVar50;
    undefined *puVar51;
    undefined (*pauVar52) [16];
    undefined *puVar53;
    undefined *puVar54;
    undefined *puVar55;
    undefined *puVar56;
    undefined *puVar57;
    undefined *puVar58;
    uint8_t uVar59;
    undefined4 uVar60;
    float *pfVar61;
    char **ppcVar62;
    uint8_t **ppuVar63;
    char **ppcVar64;
    uint8_t uVar65;
    uint64_t uVar66;
    char *pcVar67;
    uint8_t *puVar68;
    uint8_t *puVar69;
    int64_t iVar70;
    undefined8 *puVar71;
    char **ppcVar72;
    bool bVar73;
    float fVar74;
    float fVar75;
    float fVar76;
    float fVar77;
    undefined auVar78 [16];
    float fVar79;
    float fVar80;
    float fVar81;
    undefined4 uVar82;
    undefined4 uVar83;
    float fVar84;
    float fVar85;
    float fVar86;
    float fVar87;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStackY_240;
    undefined auStackY_238 [8];
    undefined auStackY_230 [24];
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int32_t var_1e8h;
    int64_t var_1e4h;
    int32_t var_1dch;
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t in_stack_fffffffffffffe48;
    float fVar88;
    int64_t in_stack_fffffffffffffe50;
    uint8_t **ppuVar89;
    int64_t in_stack_fffffffffffffe60;
    undefined8 uStack_198;
    undefined8 uStack_188;
    int64_t in_stack_fffffffffffffe80;
    char *pcVar90;
    int64_t in_stack_fffffffffffffe90;
    undefined8 *******pppppppuStack_168;
    int64_t iStack_158;
    undefined8 uStack_148;
    undefined in_stack_fffffffffffffec8 [16];
    undefined auStack_128 [16];
    uint64_t uStack_118;
    uint64_t uStack_110;
    undefined8 *******pppppppuStack_108;
    int64_t iStack_100;
    undefined auStack_f8 [16];
    uint64_t uStack_e8;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_24h;
    int64_t var_18h;
    int64_t var_ch;
    
    puVar56 = auStackY_238;
    puVar51 = auStackY_238;
    puVar53 = auStackY_238;
    puVar54 = auStackY_238;
    puVar55 = auStackY_238;
    puVar57 = auStackY_238;
    uStack_e8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_238;
    uVar60 = (undefined4)arg3;
    uVar44 = (uint32_t)arg2;
    uVar49 = arg2 & 0xffffffff;
    uVar66 = 1;
    uVar26 = uVar60;
    iVar37 = arg1;
    if (*(char *)0x180781f98 == '\0') {
        iVar24 = (**(code **)(**(int64_t **)0x1807821e0 + 0x38))(*(int64_t **)0x1807821e0, 0x18063d228, 0x1807821d0);
        puVar58 = auStackY_238;
        if (iVar24 < 0) goto code_r0x00018007c2cd;
        (**(code **)(*(int64_t *)arg1 + 0x60))(arg1, 0x180782160);
        (**(code **)(*(int64_t *)arg1 + 0x48))(arg1, 0, 0x18063d260, 0x1807821c8);
        *(undefined8 *)0x180781f08 = *(undefined8 *)0x180782190;
        *(undefined8 *)0x1807821b8 = (*(code *)0x69a4a8)(*(undefined8 *)0x180782190, 0xfffffffc, fcn.180079da0);
        (**(code **)(**(int64_t **)0x1807821d0 + 0x140))(*(int64_t **)0x1807821d0, 0x1807821c0);
        (**(code **)(**(int64_t **)0x1807821d0 + 0x48))
                  (*(int64_t **)0x1807821d0, *(int64_t **)0x1807821c8, 0, 0x1807821b0);
        (**(code **)(**(int64_t **)0x1807821c8 + 0x10))();
        *(int64_t **)0x1807821c8 = (int64_t *)0x0;
        fcn.1800787e0();
        LOCK();
        *(char *)0x180781f98 = '\x01';
        UNLOCK();
    }
    puVar58 = auStackY_238;
    if (*(char *)0x180781ed9 != '\0') goto code_r0x00018007c250;
    if (*(int64_t *)0x1807821b0 == 0) {
        (**(code **)(*(int64_t *)arg1 + 0x48))(arg1, 0, 0x18063d260, 0x1807821c8);
        (**(code **)(**(int64_t **)0x1807821d0 + 0x48))
                  (*(int64_t **)0x1807821d0, *(int64_t **)0x1807821c8, 0, 0x1807821b0);
        (**(code **)(**(int64_t **)0x1807821c8 + 0x10))();
        *(int64_t **)0x1807821c8 = (int64_t *)0x0;
    }
    func_0x000180167640();
    func_0x000180168c20();
    func_0x0001800fb4a0();
    iVar28 = *(int64_t *)0x180781f28;
    if (*(char *)0x1807824e0 == '\0') {
        uVar45 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) | 0x20;
    } else {
        uVar45 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) & 0xffffffdf;
    }
    bVar73 = *(char *)0x1807824e0 != '\0';
    *(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) = uVar45;
    *(bool *)(iVar28 + 0x8c) = bVar73;
    *(bool *)(iVar28 + 0xe9) = bVar73;
    *(bool *)(iVar28 + 0xe8) = bVar73;
    iVar28 = func_0x0001800fa7f0(*(undefined8 *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x48), 0, 0x1806444c0)
    ;
    fcn.180078bc0(iVar28, var_1d0h, var_1c8h, var_1c0h, in_stack_fffffffffffffe48, in_stack_fffffffffffffe50, 
                  in_stack_fffffffffffffe60, CONCAT44(uVar26, uVar44), in_stack_fffffffffffffe80, iVar37, 
                  in_stack_fffffffffffffe90, SUB168(_pppppppuStack_168, 8), iStack_158, SUB168(_uStack_148, 8), 
                  in_stack_fffffffffffffec8._0_8_, in_stack_fffffffffffffec8._8_8_);
    iVar28 = *(int64_t *)0x180781f28;
    if (*(char *)0x1807824e0 != '\0') {
        puVar7 = (undefined4 *)**(undefined8 **)(*(int64_t *)0x180781f28 + 0x2158);
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 1;
        uVar45 = *(uint32_t *)(iVar28 + 0x2008);
        *(undefined8 *)(iVar28 + 0x201c) = *(undefined8 *)(puVar7 + 8);
        *(undefined8 *)(iVar28 + 0x2024) = 0;
        *(undefined4 *)(iVar28 + 0x200c) = 1;
        *(undefined *)(iVar28 + 0x204c) = 1;
        *(uint32_t *)(iVar28 + 0x2008) = uVar45 | 2;
        *(undefined8 *)(iVar28 + 0x202c) = *(undefined8 *)(puVar7 + 10);
        *(undefined4 *)(iVar28 + 0x2010) = 1;
        uVar60 = *puVar7;
        *(uint32_t *)(iVar28 + 0x2008) = uVar45 | 0x802;
        *(undefined4 *)(iVar28 + 0x2074) = uVar60;
        func_0x0001800f6810(3);
        func_0x0001800f6810(4);
        var_1f0h = 0;
        func_0x0001800f6960(2, &var_1f0h);
        func_0x0001801019f0(0x18063d0f8, 0, 0xa20a7);
        func_0x0001800f6a20(3);
        uVar60 = *(undefined4 *)
                  (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                  (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) * 4);
        uVar25 = func_0x0001800f5a90(0x18063d0e8, 0, uVar60);
        *(undefined4 *)0x180782218 = uVar25;
        *(undefined4 *)0x180782158 = func_0x0001800f5a90(0x18063d1d0, 0, uVar60);
        bVar73 = false;
        if ((*(char *)0x18077aef4 != '\0') &&
           (*(char *)0x18077aef4 = '\0', bVar73 = false, *(char *)0x180781eda == '\0')) {
            bVar73 = true;
        }
        if (*(char *)0x180781f99 == '\0') {
            uVar60 = uVar26;
            arg1 = iVar37;
            if (bVar73) goto code_r0x00018007a25d;
        } else {
            *(char *)0x180781f99 = '\0';
code_r0x00018007a25d:
            func_0x00018011c780(uVar25);
            func_0x00018011c780(*(undefined4 *)0x180782158);
            func_0x00018011c6e0(*(undefined4 *)0x180782218, 0x40c);
            func_0x00018011c680(*(undefined4 *)0x180782218, *(undefined8 *)(puVar7 + 10));
            func_0x00018011c6e0(*(undefined4 *)0x180782158, 0);
            uVar60 = *(undefined4 *)0x180782158;
            iVar28 = func_0x0001800f60f0(*(int64_t *)0x180781f28 + 0x28e8, *(undefined4 *)0x180782158);
            if (iVar28 != 0) {
                fVar81 = (float)puVar7[9];
                *(float *)(iVar28 + 0x48) = (float)puVar7[8] + 40.0;
                *(float *)(iVar28 + 0x4c) = fVar81 + 40.0;
                *(uint32_t *)(iVar28 + 0xd8) = *(uint32_t *)(iVar28 + 0xd8) & 0xfffffff9;
                *(uint32_t *)(iVar28 + 0xd8) = *(uint32_t *)(iVar28 + 0xd8) | 1;
            }
            func_0x00018011c680(uVar60, 0x4396000044228000);
            func_0x00018011c590(0x180625068);
            func_0x00018011c590(0x18063d058);
            func_0x00018011c590(0x18063d118);
            func_0x00018011c590(0x18063d108);
            func_0x0001801155a0(*(int64_t *)0x180781f28, *(undefined4 *)0x180782218);
            *(int32_t *)0x180781ff8 = 3;
            uVar60 = uVar26;
            arg1 = iVar37;
            uVar25 = *(undefined4 *)0x180782218;
        }
        var_1f0h = 0;
        func_0x00018011c130(uVar25, &var_1f0h, 0xc);
        func_0x000180105c20();
        if (0 < *(int32_t *)0x180781ff8) {
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 0x20;
        }
        func_0x0001801019f0(0x180625068, 0, 0);
        func_0x000180139ae0(0x18063cd50);
        iVar28 = *(int64_t *)0x180781f28;
        iVar37 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if ((*(int64_t *)(iVar37 + 0x208) != 0) ||
           (pfVar30 = (float *)(iVar37 + 0x2d0), *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0)) {
            pfVar30 = (float *)(iVar37 + 0x2a0);
        }
        fVar84 = pfVar30[1] - *(float *)(iVar37 + 0x15c);
        fVar81 = ((*pfVar30 - *(float *)(iVar37 + 0x158)) - *(float *)(*(int64_t *)0x180781f28 + 0xdec)) * 0.5;
        var_1f0h = CONCAT44(fVar84, fVar81);
        *(undefined *)(iVar37 + 0x10b) = 1;
        uVar26 = func_0x0001800f5a90(0x18063cd40, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(*(int64_t *)(iVar28 + 0x15e0) + 0x150) + -4 +
                                      (int64_t)*(int32_t *)(*(int64_t *)(iVar28 + 0x15e0) + 0x148) * 4));
        var_218h = (uint64_t)var_218h._4_4_ << 0x20;
        func_0x0001800fe6d0(0x18063cd40, uVar26, &var_1f0h, 1);
        uVar32 = 0x18077af00;
        if (0xf < *(uint64_t *)0x18077af18) {
            uVar32 = *(undefined8 *)0x18077af00;
        }
        func_0x000180139ae0(0x18063cd30, uVar32);
        func_0x000180139ae0(0x18063cd20);
        func_0x0001800fea60();
        func_0x00018010bd60(0);
        iVar37 = *(int64_t *)0x180781f28;
        var_1f0h = CONCAT44(fVar84, fVar81);
        *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
        uVar26 = func_0x0001800f5a90(0x18063cd90, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(*(int64_t *)(iVar37 + 0x15e0) + 0x150) + -4 +
                                      (int64_t)*(int32_t *)(*(int64_t *)(iVar37 + 0x15e0) + 0x148) * 4));
        var_218h = var_218h & 0xffffffff00000000;
        func_0x0001800fe6d0(0x18063cd90, uVar26, &var_1f0h, 1);
        func_0x0001800fea60();
        func_0x000180105c20();
        if (0 < *(int32_t *)0x180781ff8) {
            *(int32_t *)0x180781ff8 = *(int32_t *)0x180781ff8 + -1;
        }
        iVar37 = 0x18063d058;
        func_0x0001801019f0(0x18063d058, 0, 0);
        fcn.180076ad0(iVar37);
        func_0x000180105c20();
        func_0x0001801019f0(0x18063d118, 0, 0);
        iVar37 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f80) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f80) | 1;
        *(undefined4 *)(iVar37 + 0x1f98) = 0x435c0000;
        var_1f0h = 0;
        var_200h = 0;
        var_208h = 0;
        var_210h = (uint64_t)var_210h._4_4_ << 0x20;
        var_218h = (int64_t)&var_1f0h;
        cVar21 = func_0x0001801431e0(0x18063cdf0, 0, 0x1807828c0, 0x100);
        if (cVar21 != '\0') {
            func_0x0001800f62d0();
        }
        func_0x00018010bd60(0);
        var_1f0h = 0;
        cVar21 = func_0x00018013a5c0(0x18063ce60, &var_1f0h, 0);
        if (cVar21 != '\0') {
            func_0x00018007c720();
        }
        func_0x00018010bd60(0);
        func_0x00018013bcf0(0x18063ce50, 0x18077aef5);
        iVar37 = *(int64_t *)0x180781f28;
        iVar24 = -1;
        var_1d8h._0_4_ = -1;
        var_1f0h = 0;
        *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
        uVar26 = func_0x0001800f5a90(0x18063ce38, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(*(int64_t *)(iVar37 + 0x15e0) + 0x150) + -4 +
                                      (int64_t)*(int32_t *)(*(int64_t *)(iVar37 + 0x15e0) + 0x148) * 4));
        var_218h = var_218h & 0xffffffff00000000;
        cVar21 = func_0x0001800fe6d0(0x18063ce38, uVar26, &var_1f0h, 1);
        iVar27 = -0x33333333;
        puVar51 = auStackY_238;
        if (cVar21 != '\0') {
            uStack_188 = 0;
            uVar26 = func_0x0001800f5a90(0x18063ce28, 0, 
                                         *(undefined4 *)
                                          (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                                          (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148)
                                          * 4));
            var_210h = var_210h & 0xffffffff00000000;
            var_218h = (int64_t)&uStack_188;
            cVar21 = func_0x000180131490(0x18063ce28, uVar26, 2, 0x2000241);
            iVar27 = -0x33333333;
            if (cVar21 != '\0') {
                func_0x000180136230(0x18063ce90, 0x10, 0x42b40000);
                func_0x000180136230(0x180632310, 8, 0);
                iVar37 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
                var_1f0h = iVar37;
                if (iVar37 == 0) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180645768);
                    }
                } else {
                    if (*(char *)(iVar37 + 0x239) == '\0') {
                        func_0x000180132820(iVar37);
                    }
                    iVar31 = *(int64_t *)0x180781f28;
                    iVar28 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
                    fVar81 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
                    uVar45 = 0;
                    if (0 < *(int32_t *)(iVar28 + 0x6c)) {
                        do {
                            if (((*(uint32_t *)(*(int64_t *)(iVar28 + 0x50) + ((int64_t)(int32_t)uVar45 >> 5) * 4) >>
                                  (uVar45 & 0x1f) & 1) != 0) &&
                               ((*(uint32_t *)((int64_t)(int32_t)uVar45 * 0x74 + *(int64_t *)(iVar28 + 0x18)) & 0x1000)
                                == 0)) {
                                uVar32 = func_0x000180136420(iVar28, uVar45);
                                var_218h = CONCAT44(var_218h._4_4_, 0xbf800000);
                                iVar29 = func_0x0001800fe0a0(&stack0xfffffffffffffe80, uVar32, 0, 0);
                                if (fVar81 <= *(float *)(iVar29 + 4)) {
                                    fVar81 = *(float *)(iVar29 + 4);
                                }
                            }
                            uVar45 = uVar45 + 1;
                        } while ((int32_t)uVar45 < *(int32_t *)(iVar28 + 0x6c));
                    }
                    fVar84 = *(float *)(iVar31 + 0xe00);
                    func_0x000180136540(1);
                    if (*(char *)(iVar37 + 0x24c) == '\0') {
                        fVar80 = *(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x15c);
                        var_1c0h = CONCAT44(var_1c0h._4_4_, fVar80);
                        if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) == 0) {
                            iVar24 = 0;
                        } else {
                            iVar24 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) + 0x6c);
                            var_1e4h._4_4_ = 0;
                            if (0 < iVar24) {
                                do {
                                    iVar27 = var_1e4h._4_4_;
                                    cVar21 = func_0x000180137010();
                                    if ((cVar21 != '\0') || (*(int16_t *)(iVar37 + 0x218) == iVar27)) {
                                        iVar28 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
                                        if (iVar28 == 0) {
                                            pcVar42 = (char *)0x0;
                                        } else {
                                            if (iVar27 == *(int32_t *)(iVar28 + 0x6c)) {
                                                uVar45 = 0;
                                            } else {
                                                uVar45 = *(uint32_t *)
                                                          ((int64_t)iVar27 * 0x74 + *(int64_t *)(iVar28 + 0x18));
                                            }
                                            if ((uVar45 >> 0xc & 1) == 0) {
                                                var_1dch = iVar24;
                                                pcVar42 = (char *)func_0x000180136420(iVar28);
                                            } else {
                                                pcVar42 = "";
                                            }
                                        }
                                        var_1dch = iVar24;
                                        func_0x000180107620(iVar27);
                                        iVar28 = *(int64_t *)0x180781f28;
                                        var_1d0h = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                                        if (*(char *)(var_1d0h + 0x10e) == '\0') {
                                            iVar31 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
                                            if (iVar31 == 0) {
                                                iVar27 = var_1e4h._4_4_;
                                                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                                                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                                              (*(int64_t *)0x180781f28, 
                                                               *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                                               0x180645768);
                                                    iVar27 = var_1e4h._4_4_;
                                                }
                                            } else {
                                                var_1e8h = *(int32_t *)(iVar31 + 0x74);
                                                iVar70 = (int64_t)var_1e8h * 0x74;
                                                iVar29 = *(int64_t *)(iVar31 + 0x18);
                                                pcVar67 = "";
                                                if (pcVar42 != (char *)0x0) {
                                                    pcVar67 = pcVar42;
                                                }
                                                pcVar42 = pcVar67;
                                                if (pcVar67 != (char *)0xffffffffffffffff) {
                                                    while (*pcVar42 != '\0') {
                                                        pcVar90 = pcVar42 + 1;
                                                        if (((*pcVar42 == '#') && (*pcVar90 == '#')) ||
                                                           (pcVar42 = pcVar90, pcVar90 == (char *)0xffffffffffffffff))
                                                        break;
                                                    }
                                                }
                                                var_218h = CONCAT44(var_218h._4_4_, 0xbf800000);
                                                pcVar90 = pcVar67;
                                                func_0x0001800fe0a0(&stack0xfffffffffffffe48, pcVar67, pcVar42, 0);
                                                var_1c8h = *(int64_t *)(var_1d0h + 0x158);
                                                fVar80 = *(float *)((int64_t)var_1e8h * 0x74 + 8 +
                                                                   *(int64_t *)(iVar31 + 0x18));
                                                if (fVar80 <= *(float *)(iVar31 + 0x110)) {
                                                    fVar80 = *(float *)(iVar31 + 0x110);
                                                }
                                                fVar77 = *(float *)(iVar31 + 0x7c);
                                                fVar76 = *(float *)((int64_t)var_1e8h * 0x74 + 0xc +
                                                                   *(int64_t *)(iVar31 + 0x18));
                                                if (*(float *)(iVar31 + 0x118) <= fVar76) {
                                                    fVar76 = *(float *)(iVar31 + 0x118);
                                                }
                                                fVar4 = *(float *)(iVar31 + 0x80);
                                                fVar74 = *(float *)(iVar31 + 0x84) -
                                                         (*(float *)(iVar31 + 0x88) + *(float *)(iVar31 + 0x88));
                                                fVar88 = (float)((uint64_t)in_stack_fffffffffffffe48 >> 0x20);
                                                if (fVar88 <= fVar74) {
                                                    fVar88 = fVar74;
                                                }
                                                fVar86 = 0.0;
                                                fVar85 = 0.0;
                                                bVar73 = false;
                                                var_1e4h._0_4_ = 0;
                                                fVar74 = fVar76;
                                                if (((*(uint8_t *)(iVar31 + 4) & 8) == 0) ||
                                                   ((*(uint32_t *)(iVar29 + iVar70) & 0x200) != 0)) {
code_r0x00018007aadf:
                                                    fVar87 = (float)in_stack_fffffffffffffe48;
                                                    fVar79 = (float)var_1c8h + fVar87 + 0.0 + fVar86;
                                                    if ((!bVar73) && (fVar74 = fVar79, fVar76 <= fVar79)) {
                                                        fVar74 = fVar76;
                                                    }
                                                } else {
                                                    fVar86 = (float)(int32_t)(*(float *)(iVar28 + 0x12f8) * 0.65 +
                                                                             *(float *)(iVar28 + 0xddc));
                                                    iVar43 = *(int16_t *)(iVar29 + 0x5e + iVar70);
                                                    if ((iVar43 == -1) || (bVar73 = true, iVar43 < 1))
                                                    goto code_r0x00018007aadf;
                                                    var_218h = CONCAT44(var_218h._4_4_, 0xbf800000);
                                                    pfVar30 = (float *)func_0x0001800fe0a0(&stack0xfffffffffffffe90, 
                                                                                           &var_1e4h, 0, 0);
                                                    fVar85 = *(float *)(iVar28 + 0xdf4) + *pfVar30;
                                                    fVar87 = (float)in_stack_fffffffffffffe48;
                                                    fVar79 = (float)var_1c8h + fVar87 + fVar85 + fVar86;
                                                }
                                                fVar75 = *(float *)(iVar29 + 0x4c + iVar70);
                                                if (fVar75 <= fVar74) {
                                                    fVar75 = fVar74;
                                                }
                                                *(float *)(iVar29 + 0x4c + iVar70) = fVar75;
                                                fVar74 = *(float *)(iVar29 + 0x50 + iVar70);
                                                if (fVar74 <= fVar79) {
                                                    fVar74 = fVar79;
                                                }
                                                *(float *)(iVar29 + 0x50 + iVar70) = fVar74;
                                                uVar26 = func_0x0001800f5a90(pcVar67, 0, 
                                                                             *(undefined4 *)
                                                                              (*(int64_t *)(var_1d0h + 0x150) + -4 +
                                                                              (int64_t)*(int32_t *)(var_1d0h + 0x148) *
                                                                              4));
                                                uStack_148._4_4_ = fVar77;
                                                uStack_148._0_4_ = fVar80;
                                                stack0xfffffffffffffec0 = fVar76;
                                                fVar77 = *(float *)(iVar28 + 0xe00) + *(float *)(iVar28 + 0xe00) +
                                                         fVar88 + fVar77;
                                                if (fVar4 <= fVar77) {
                                                    fVar4 = fVar77;
                                                }
                                                stack0xfffffffffffffec4 = fVar4;
                                                func_0x00018010bbf0(&stack0xfffffffffffffe60);
                                                cVar21 = func_0x00018010b530(&uStack_148, uVar26, 0);
                                                iVar37 = var_1f0h;
                                                iVar24 = var_1dch;
                                                iVar27 = var_1e4h._4_4_;
                                                if (cVar21 != '\0') {
                                                    iVar43 = *(int16_t *)(iVar31 + 0x20e);
                                                    var_218h = CONCAT44(var_218h._4_4_, 0x1000);
                                                    cVar21 = func_0x000180139d40(&uStack_148, uVar26, &var_1f8h, 
                                                                                 (int64_t)&var_1f8h + 1);
                                                    if (var_1f8h._1_1_ == '\0') {
                                                        if (((uint8_t)var_1f8h != 0) || (iVar43 == var_1e8h)) {
                                                            uVar66 = (uint64_t)(((uint8_t)var_1f8h != 0) + 0x18);
                                                            goto code_r0x00018007ac36;
                                                        }
                                                        if ((*(uint8_t *)(iVar31 + 0x94) & 1) == 0) {
                                                            _pppppppuStack_168 =
                                                                 SUB1612(*(undefined (*) [16])
                                                                          (*(int64_t *)0x180781f28 + 0x11c0), 0);
                                                            fVar77 = *(float *)(*(int64_t *)0x180781f28 + 0x11cc) *
                                                                     *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                                                            goto code_r0x00018007ac5c;
                                                        }
                                                    } else {
                                                        uVar66 = 0x1a;
code_r0x00018007ac36:
                                                        pauVar33 = (undefined (*) [16])
                                                                   (*(int64_t *)0x180781f28 + 0xd90 +
                                                                   (uVar66 + 0x14) * 0x10);
                                                        _pppppppuStack_168 = SUB1612(*pauVar33, 0);
                                                        fVar77 = *(float *)(*pauVar33 + 0xc) *
                                                                 *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
code_r0x00018007ac5c:
                                                        stack0xfffffffffffffea4 = fVar77;
                                                        uVar26 = func_0x0001800f5fa0(&pppppppuStack_168);
                                                        func_0x000180136460(3, uVar26, *(undefined4 *)(iVar31 + 0x74));
                                                    }
                                                    func_0x0001800f7d00();
                                                    if (var_1f8h._1_1_ != '\0') {
                                                        *(int16_t *)(iVar31 + 0x216) = (int16_t)var_1e8h;
                                                    }
                                                    *(float *)(var_1d0h + 0x15c) =
                                                         *(float *)(var_1d0h + 0x15c) - *(float *)(iVar28 + 0xdf0) * 0.5
                                                    ;
                                                    if ((var_1f8h._1_1_ != '\0') &&
                                                       ((*(uint8_t *)(iVar31 + 4) & 2) != 0)) {
                                                        cVar35 = '\0';
                                                        cVar23 = func_0x000180108230();
                                                        if ((cVar23 != '\0') && (*(char *)(iVar28 + 0x2400) == cVar35))
                                                        {
                                                            *(undefined2 *)(iVar31 + 0x7a) =
                                                                 *(undefined2 *)(iVar31 + 0x78);
                                                            if ((((*(float *)(iVar28 + 0x104) <= 0.0 &&
                                                                   *(float *)(iVar28 + 0x104) != 0.0) &&
                                                                 (*(float *)(iVar28 + 0x118) <= fVar80 &&
                                                                  fVar80 != *(float *)(iVar28 + 0x118))) &&
                                                                (iVar43 = *(int16_t *)(iVar29 + 0x5a + iVar70),
                                                                iVar43 != -1)) &&
                                                               ((int64_t)iVar43 * 0x74 + *(int64_t *)(iVar31 + 0x18) !=
                                                                0)) {
                                                                func_0x000180132610();
                                                            }
                                                            if (((0.0 < *(float *)(iVar28 + 0x104)) &&
                                                                (fVar76 < *(float *)(iVar28 + 0x118))) &&
                                                               ((iVar43 = *(int16_t *)(iVar29 + 0x5c + iVar70),
                                                                iVar43 != -1 &&
                                                                ((int64_t)iVar43 * 0x74 + *(int64_t *)(iVar31 + 0x18) !=
                                                                 0)))) {
                                                                func_0x000180132610();
                                                            }
                                                        }
                                                    }
                                                    fVar85 = (fVar76 - fVar86) - fVar85;
                                                    fVar77 = fVar85;
                                                    if (fVar85 <= (float)var_1c8h) {
                                                        fVar77 = (float)var_1c8h;
                                                    }
                                                    if (((*(uint8_t *)(iVar31 + 4) & 8) != 0) &&
                                                       ((*(uint32_t *)(iVar29 + iVar70) & 0x200) == 0)) {
                                                        iVar43 = *(int16_t *)(iVar29 + 0x5e + iVar70);
                                                        if (iVar43 != -1) {
                                                            if (fVar80 <= fVar85) {
                                                                fVar80 = fVar85;
                                                            }
                                                            if (0 < iVar43) {
                                                                stack0xfffffffffffffea4 =
                                                                     *(float *)(*(int64_t *)0x180781f28 + 0xedc) *
                                                                     *(float *)(*(int64_t *)0x180781f28 + 0xd9c) * 0.7;
                                                                _pppppppuStack_168 =
                                                                     *(undefined (*) [12])
                                                                      (*(int64_t *)0x180781f28 + 0xed0);
                                                                uVar26 = func_0x0001800f5fa0(&pppppppuStack_168);
                                                                func_0x0001800f6650(0, uVar26);
                                                                func_0x0001800f6cb0(fVar80 + *(float *)(iVar28 + 0xdf4)
                                                                                    , &var_1e4h, 0, 1);
                                                                func_0x0001800f6770(1);
                                                            }
                                                            stack0xfffffffffffffea4 =
                                                                 *(float *)(*(int64_t *)0x180781f28 + 0xedc) *
                                                                 *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                                                            _pppppppuStack_168 =
                                                                 *(undefined (*) [12])(*(int64_t *)0x180781f28 + 0xed0);
                                                            func_0x0001800f5fa0(&pppppppuStack_168);
                                                            var_218h = CONCAT44(var_218h._4_4_, 0x3f266666);
                                                            func_0x0001801301a0();
                                                        }
                                                        if ((cVar21 != '\0') &&
                                                           (*(int16_t *)(iVar31 + 0x21a) != var_1e8h)) {
                                                            uVar22 = *(uint8_t *)(iVar29 + 0x72 + iVar70);
                                                            if (*(int16_t *)(iVar29 + 0x5e + iVar70) == -1) {
code_r0x00018007af25:
                                                                uVar22 = uVar22 & 3;
                                                            } else {
                                                                iVar24 = 0;
                                                                do {
                                                                    iVar27 = iVar24 + 1;
                                                                    if ((*(uint8_t *)(iVar29 + 0x71 + iVar70) & 3) ==
                                                                        (uVar22 >> ((char)iVar24 * '\x02' & 0x1fU) & 3))
                                                                    {
                                                                        uVar22 = uVar22 >> ((char)(iVar27 % (int32_t)(*(
                                                            uint8_t *)(iVar29 + 0x71 + iVar70) >> 2 & 3)) * '\x02' &
                                                            0x1fU);
                                                            goto code_r0x00018007af25;
                                                            }
                                                            iVar24 = iVar27;
                                                            } while (iVar27 < 3);
                                                            uVar22 = 0;
                                                            }
                                                            iVar37 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
                                                            if ((*(uint32_t *)(iVar37 + 4) & 0x4000000) == 0) {
                                                                cVar21 = '\0';
                                                                iVar43 = 0;
                                                            } else {
                                                                cVar21 = *(char *)(iVar28 + 0x139);
                                                                iVar43 = 0;
                                                                if (cVar21 != '\0') {
                                                                    uVar66 = 0;
                                                                    if (0 < *(int32_t *)(iVar37 + 0x6c)) {
                                                                        do {
                                                                            iVar6 = *(int16_t *)
                                                                                     (uVar66 * 0x74 + 0x5e +
                                                                                     *(int64_t *)(iVar37 + 0x18));
                                                                            if (iVar6 <= iVar43) {
                                                                                iVar6 = iVar43;
                                                                            }
                                                                            iVar43 = iVar6;
                                                                            uVar45 = (int32_t)uVar66 + 1;
                                                                            uVar66 = (uint64_t)uVar45;
                                                                        } while ((int32_t)uVar45 <
                                                                                 *(int32_t *)(iVar37 + 0x6c));
                                                                    }
                                                                }
                                                            }
                                                            iVar70 = *(int64_t *)(iVar37 + 0x18) + iVar70;
                                                            *(uint8_t *)(iVar70 + 0x71) =
                                                                 *(uint8_t *)(iVar70 + 0x71) & 0xfc;
                                                            *(uint8_t *)(iVar70 + 0x71) =
                                                                 *(uint8_t *)(iVar70 + 0x71) | uVar22;
                                                            if (uVar22 == 0) {
                                                                *(undefined2 *)(iVar70 + 0x5e) = 0xffff;
                                                            } else {
                                                                if (*(int16_t *)(iVar70 + 0x5e) == -1) {
                                                                    if (cVar21 == '\0') goto code_r0x00018007afbd;
                                                                    iVar43 = iVar43 + 1;
                                                                } else {
                                                                    if (cVar21 != '\0') goto code_r0x00018007afc6;
code_r0x00018007afbd:
                                                                    iVar43 = 0;
                                                                }
                                                                *(int16_t *)(iVar70 + 0x5e) = iVar43;
                                                            }
code_r0x00018007afc6:
                                                            iVar24 = 0;
                                                            if (0 < *(int32_t *)(iVar37 + 0x6c)) {
                                                                do {
                                                                    iVar31 = (int64_t)iVar24 * 0x74 +
                                                                             *(int64_t *)(iVar37 + 0x18);
                                                                    if ((iVar31 != iVar70) && (cVar21 == '\0')) {
                                                                        *(undefined2 *)(iVar31 + 0x5e) = 0xffff;
                                                                    }
                                                                    if ((*(int16_t *)(iVar31 + 0x5e) != -1) &&
                                                                       (uVar22 = *(uint8_t *)(iVar31 + 0x71),
                                                                       ((uVar22 >> 4) >> (uVar22 & 3) & 1) == 0)) {
                                                                        *(uint8_t *)(iVar31 + 0x71) =
                                                                             (uVar22 ^ *(uint8_t *)(iVar31 + 0x72)) & 3
                                                                             ^ uVar22;
                                                                        *(undefined *)(iVar37 + 0x23c) = 1;
                                                                    }
                                                                    iVar24 = iVar24 + 1;
                                                                } while (iVar24 < *(int32_t *)(iVar37 + 0x6c));
                                                            }
                                                            *(undefined *)(iVar37 + 0x241) = 1;
                                                            *(undefined *)(iVar37 + 0x23c) = 1;
                                                        }
                                                    }
                                                    iVar20 = var_1e8h;
                                                    uStack_198 = CONCAT44(stack0xfffffffffffffec4, fVar77);
                                                    var_208h = (int64_t)&stack0xfffffffffffffe48;
                                                    var_218h = (int64_t)pcVar90;
                                                    var_210h = (int64_t)pcVar42;
                                                    func_0x0001800f7480(*(undefined8 *)(var_1d0h + 800), &var_1c8h, 
                                                                        &uStack_198, fVar77);
                                                    if (((fVar77 - (float)var_1c8h < fVar87) && ((uint8_t)var_1f8h != 0)
                                                        ) && (*(int32_t *)(iVar28 + 0x1654) == 0)) {
                                                        func_0x00018010ceb0(0x180641920, 
                                                                            (int32_t)pcVar42 - (int32_t)pcVar90, pcVar90
                                                                           );
                                                    }
                                                    cVar21 = func_0x00018010d6a0();
                                                    iVar37 = var_1f0h;
                                                    iVar24 = var_1dch;
                                                    iVar27 = var_1e4h._4_4_;
                                                    if (cVar21 != '\0') {
                                                        func_0x000180137a40(iVar20);
                                                        iVar37 = var_1f0h;
                                                        iVar24 = var_1dch;
                                                        iVar27 = var_1e4h._4_4_;
                                                    }
                                                }
                                            }
                                        }
                                        func_0x000180107740();
                                    }
                                    var_1e4h._4_4_ = iVar27 + 1;
                                } while (var_1e4h._4_4_ < iVar24);
                                fVar80 = (float)var_1c0h;
                            }
                        }
                        iVar37 = *(int64_t *)0x180781f28;
                        cVar21 = func_0x000180108070(1);
                        if (cVar21 != '\0') {
                            if (*(int64_t *)(iVar37 + 0x24d0) == 0) {
                                iVar27 = -1;
                            } else {
                                iVar27 = (int32_t)*(int16_t *)(*(int64_t *)(iVar37 + 0x24d0) + 0x20a);
                            }
                            if (((iVar27 == iVar24) && (fVar80 <= *(float *)(iVar37 + 0x11c))) &&
                               (*(float *)(iVar37 + 0x11c) < fVar80 + fVar84 + fVar84 + fVar81)) {
                                func_0x000180137a40(iVar24);
                            }
                        }
                    }
                }
                uStack_118 = 0;
                uStack_110 = 0xf;
                auStack_128._1_15_ = SUB1615(ZEXT816(0), 1);
                auVar5[15] = 0;
                auVar5._0_15_ = auStack_128._1_15_;
                auStack_128 = auVar5 << 8;
                var_1e4h._0_4_ = 0;
                var_1d0h = *(int64_t *)0x18077afc0;
                if (0 < (int32_t)((int64_t)*(undefined4 **)0x18077afc8 - *(int64_t *)0x18077afc0 >> 3) * -0x33333333) {
                    uVar45 = (uint32_t)(uint8_t)var_1f8h;
                    do {
                        uVar49 = in_stack_fffffffffffffec8._8_8_;
                        var_1c0h = (int64_t)(int32_t)var_1e4h * 5;
                        iVar37 = var_1d0h + (int64_t)(int32_t)var_1e4h * 0x28;
                        ppcVar38 = (char **)(iVar37 + 8);
                        if (0xf < *(uint64_t *)(iVar37 + 0x20)) {
                            ppcVar38 = (char **)*ppcVar38;
                        }
                        if (*(int32_t *)0x1807829c0 == 0) {
code_r0x00018007b31a:
                            func_0x000180136540(0);
                            iVar37 = var_1d0h;
                            puVar71 = (undefined8 *)(var_1c0h * 8 + 8 + var_1d0h);
                            puVar48 = puVar71;
                            if (0xf < (uint64_t)puVar71[3]) {
                                puVar48 = (undefined8 *)*puVar71;
                            }
                            if ((((uint64_t)puVar71[2] < 7) ||
                                (iVar28 = puVar71[2] + (int64_t)puVar48,
                                iVar31 = func_0x0001804581c0(puVar48, iVar28, 0x18063ccd8, 7), iVar31 == iVar28)) ||
                               (iVar31 - (int64_t)puVar48 == -1)) {
                                puVar48 = puVar71;
                                if (0xf < (uint64_t)puVar71[3]) {
                                    puVar48 = (undefined8 *)*puVar71;
                                }
                                if ((((uint64_t)puVar71[2] < 9) ||
                                    (iVar28 = puVar71[2] + (int64_t)puVar48,
                                    iVar31 = func_0x0001804581c0(puVar48, iVar28, 0x18063ccc8, 9), iVar31 == iVar28)) ||
                                   (iVar31 - (int64_t)puVar48 == -1)) {
                                    puVar48 = puVar71;
                                    if (0xf < (uint64_t)puVar71[3]) {
                                        puVar48 = (undefined8 *)*puVar71;
                                    }
                                    if ((((uint64_t)puVar71[2] < 6) ||
                                        (iVar28 = puVar71[2] + (int64_t)puVar48,
                                        iVar31 = func_0x0001804581c0(puVar48, iVar28, 0x18063cd14, 6), iVar31 == iVar28)
                                        ) || (iVar31 - (int64_t)puVar48 == -1)) {
                                        puVar1 = puVar71 + 2;
                                        if (0xf < (uint64_t)puVar71[3]) {
                                            puVar71 = (undefined8 *)*puVar71;
                                        }
                                        if (((*puVar1 < 6) ||
                                            (iVar28 = *puVar1 + (int64_t)puVar71,
                                            iVar31 = func_0x0001804581c0(puVar71, iVar28, 0x18063cd0c, 6),
                                            iVar31 == iVar28)) || (iVar31 - (int64_t)puVar71 == -1)) {
                                            uVar26 = 0;
                                        } else {
                                            uVar26 = 0x5a6e4114;
                                        }
                                    } else {
                                        uVar26 = 0x5a0f506e;
                                    }
                                } else {
                                    uVar26 = 0x5a1e5a14;
                                }
                            } else {
                                uVar26 = 0x5a14145a;
                            }
                            iVar31 = *(int64_t *)0x180781f28;
                            iVar28 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
                            if (iVar28 == 0) {
                                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                              (*(int64_t *)0x180781f28, 
                                               *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645768);
                                    iVar31 = *(int64_t *)0x180781f28;
                                }
                            } else if (*(float *)(iVar28 + 0x7c) < *(float *)(iVar28 + 300) ||
                                       *(float *)(iVar28 + 0x7c) == *(float *)(iVar28 + 300)) {
                                *(undefined4 *)(iVar28 + 0x9c) = uVar26;
                            }
                            iVar28 = *(int64_t *)(iVar31 + 0x24d0);
                            if ((iVar28 != 0) && (*(int32_t *)(iVar28 + 0x74) != 0)) {
                                if (*(int32_t *)(iVar28 + 0x74) != -1) {
                                    func_0x000180137270(iVar28);
                                    iVar31 = *(int64_t *)0x180781f28;
                                }
                                if (*(int32_t *)(iVar28 + 0x6c) < 1) {
                                    if (*(code **)(iVar31 + 0x2a40) != (code *)0x0) {
                                        (**(code **)(iVar31 + 0x2a40))
                                                  (iVar31, *(undefined8 *)(iVar31 + 0x2a48), 0x180645908);
                                    }
                                } else {
                                    func_0x0001801370a0(iVar28, 0);
                                }
                            }
                            uVar66 = var_1c0h;
                            uVar32 = func_0x000180016b80(&uStack_148, *(undefined4 *)(iVar37 + var_1c0h * 8));
                            pauVar33 = (undefined (*) [16])func_0x000180018c80(uVar32, 0, 0x18063ce80, 8);
                            auVar17 = *(undefined (*) [12])*pauVar33;
                            auVar12 = *pauVar33;
                            auVar5 = pauVar33[1];
                            *(undefined8 *)pauVar33[1] = 0;
                            *(undefined8 *)(pauVar33[1] + 8) = 0xf;
                            (*pauVar33)[0] = 0;
                            iVar28 = *(int64_t *)0x180781f28;
                            pppppppuStack_168 = &pppppppuStack_168;
                            uVar47 = auVar5._8_8_;
                            if (0xf < uVar47) {
                                pppppppuStack_168 = auVar17._0_8_;
                            }
                            uVar26 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde0);
                            *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde0) = 0;
                            uStack_198 = 0;
                            pppppppuVar39 = pppppppuStack_168;
                            _pppppppuStack_168 = auVar12;
                            cVar21 = func_0x00018013a5c0(pppppppuVar39, &uStack_198, 0x8000);
                            *(undefined4 *)(iVar28 + 0xde0) = uVar26;
                            if (uVar47 < 0x10) {
code_r0x00018007b74d:
                                auVar12[15] = 0;
                                auVar12._0_15_ = stack0xfffffffffffffe99;
                                _pppppppuStack_168 = auVar12 << 8;
                                if (uVar49 < 0x10) {
code_r0x00018007b79b:
                                    auVar13[15] = 0;
                                    auVar13._0_15_ = stack0xfffffffffffffeb9;
                                    _uStack_148 = auVar13 << 8;
                                    if (cVar21 != '\0') {
                                        puVar48 = (undefined8 *)(uVar66 * 8 + 8 + iVar37);
                                        if (0xf < (uint64_t)puVar48[3]) {
                                            puVar48 = (undefined8 *)*puVar48;
                                        }
                                        if (*(code **)(*(int64_t *)0x180781f28 + 0xc50) != (code *)0x0) {
                                            (**(code **)(*(int64_t *)0x180781f28 + 0xc50))
                                                      (*(int64_t *)0x180781f28, puVar48);
                                        }
                                    }
                                    func_0x00018010bd60(0);
                                    uVar32 = func_0x000180016b80(&pppppppuStack_108, 
                                                                 *(undefined4 *)(iVar37 + uVar66 * 8));
                                    pauVar33 = (undefined (*) [16])func_0x000180018c80(uVar32, 0, 0x18063ce74, 5);
                                    auVar17 = *(undefined (*) [12])*pauVar33;
                                    auVar12 = *pauVar33;
                                    auVar5 = pauVar33[1];
                                    *(undefined8 *)pauVar33[1] = 0;
                                    *(undefined8 *)(pauVar33[1] + 8) = 0xf;
                                    (*pauVar33)[0] = 0;
                                    iVar28 = *(int64_t *)0x180781f28;
                                    uStack_148 = (undefined8 *******)&uStack_148;
                                    uVar49 = auVar5._8_8_;
                                    if (0xf < uVar49) {
                                        uStack_148 = auVar17._0_8_;
                                    }
                                    uVar26 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde0);
                                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde0) = 0;
                                    pppppppuVar39 = uStack_148;
                                    _uStack_148 = auVar12;
                                    cVar21 = func_0x00018013a5c0(pppppppuVar39, &stack0xfffffffffffffe60, 0x8000);
                                    *(undefined4 *)(iVar28 + 0xde0) = uVar26;
                                    if (0xf < uVar49) {
                                        uVar47 = uVar49 + 1;
                                        ppppppuVar40 = uStack_148;
                                        if (0xfff < uVar47) {
                                            ppppppuVar40 = uStack_148[-1];
                                            if (0x1f < (uint64_t)((int64_t)uStack_148 + (-8 - (int64_t)ppppppuVar40)))
                                            goto code_r0x00018007bf6f;
                                            uVar47 = uVar49 + 0x28;
                                        }
                                        func_0x000180459c3c(ppppppuVar40, uVar47);
                                    }
                                    in_stack_fffffffffffffec8 = ZEXT816(0xf) << 0x40;
                                    auVar14[15] = 0;
                                    auVar14._0_15_ = stack0xfffffffffffffeb9;
                                    _uStack_148 = auVar14 << 8;
                                    if (0xf < (uint64_t)auStack_f8._8_8_) {
                                        uVar49 = auStack_f8._8_8_ + 1;
                                        pppppppuVar39 = pppppppuStack_108;
                                        if (0xfff < uVar49) {
                                            pppppppuVar39 = (undefined8 *******)pppppppuStack_108[-1];
                                            puVar56 = auStackY_238;
                                            if (0x1f < (uint64_t)
                                                       ((int64_t)pppppppuStack_108 + (-8 - (int64_t)pppppppuVar39)))
                                            goto code_r0x00018007bf8b;
                                            uVar49 = auStack_f8._8_8_ + 0x28;
                                        }
                                        func_0x000180459c3c(pppppppuVar39, uVar49);
                                    }
                                    auStack_f8 = ZEXT816(0xf) << 0x40;
                                    pppppppuStack_108 =
                                         (undefined8 *******)((uint64_t)pppppppuStack_108 & 0xffffffffffffff00);
                                    if (cVar21 != '\0') {
                                        var_1d8h._0_4_ = (int32_t)var_1e4h;
                                    }
                                    iVar28 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0);
                                    if ((iVar28 != 0) && (*(int32_t *)(iVar28 + 0x74) != 1)) {
                                        if (*(int32_t *)(iVar28 + 0x74) != -1) {
                                            func_0x000180137270(iVar28);
                                        }
                                        if (*(int32_t *)(iVar28 + 0x6c) < 2) {
                                            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                                                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                                          (*(int64_t *)0x180781f28, 
                                                           *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                                           0x180645908);
                                            }
                                        } else {
                                            func_0x0001801370a0(iVar28, 1);
                                        }
                                    }
                                    puVar71 = (undefined8 *)(uVar66 * 8 + 8 + iVar37);
                                    puVar48 = puVar71;
                                    if (0xf < (uint64_t)puVar71[3]) {
                                        puVar48 = (undefined8 *)*puVar71;
                                    }
                                    if ((((uint64_t)puVar71[2] < 7) ||
                                        (iVar28 = (int64_t)puVar48 + puVar71[2],
                                        iVar31 = func_0x0001804581c0(puVar48, iVar28, 0x18063ccd8, 7), iVar31 == iVar28)
                                        ) || (uVar26 = 0x3f800000, uVar25 = 0x3eb33333, uVar82 = 0x3eb33333,
                                             uVar83 = 0x3f800000, iVar31 - (int64_t)puVar48 == -1)) {
                                        puVar48 = puVar71;
                                        if (0xf < (uint64_t)puVar71[3]) {
                                            puVar48 = (undefined8 *)*puVar71;
                                        }
                                        if ((((uint64_t)puVar71[2] < 9) ||
                                            (iVar28 = (int64_t)puVar48 + puVar71[2],
                                            iVar31 = func_0x0001804581c0(puVar48, iVar28, 0x18063ccc8, 9),
                                            iVar31 == iVar28)) ||
                                           (uVar26 = 0x3eb33333, uVar25 = 0x3f800000, uVar82 = 0x3ee66666,
                                           uVar83 = 0x3f800000, iVar31 - (int64_t)puVar48 == -1)) {
                                            puVar48 = puVar71;
                                            if (0xf < (uint64_t)puVar71[3]) {
                                                puVar48 = (undefined8 *)*puVar71;
                                            }
                                            if ((((uint64_t)puVar71[2] < 6) ||
                                                (iVar28 = (int64_t)puVar48 + puVar71[2],
                                                iVar31 = func_0x0001804581c0(puVar48, iVar28, 0x18063cd14, 6),
                                                iVar31 == iVar28)) ||
                                               (uVar26 = 0x3f800000, uVar25 = 0x3f4ccccd, uVar82 = 0x3e800000,
                                               uVar83 = 0x3f800000, iVar31 - (int64_t)puVar48 == -1)) {
                                                puVar1 = puVar71 + 2;
                                                if (0xf < (uint64_t)puVar71[3]) {
                                                    puVar71 = (undefined8 *)*puVar71;
                                                }
                                                if (((*puVar1 < 6) ||
                                                    (iVar28 = (int64_t)puVar71 + *puVar1,
                                                    iVar31 = func_0x0001804581c0(puVar71, iVar28, 0x18063cd0c, 6),
                                                    iVar31 == iVar28)) ||
                                                   (uVar26 = 0x3ecccccd, uVar25 = 0x3f400000, uVar82 = 0x3f800000,
                                                   uVar83 = 0x3f800000, iVar31 - (int64_t)puVar71 == -1)) {
                                                    uVar26 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
                                                    uVar25 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
                                                    uVar82 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
                                                    uVar83 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xedc);
                                                }
                                            }
                                        }
                                    }
                                    iVar28 = *(int64_t *)0x180781f28;
                                    uVar66 = 0;
                                    auVar18._12_4_ = 0;
                                    auVar18._0_12_ = *(undefined (*) [12])(*(int64_t *)0x180781f28 + 0xed0);
                                    _pppppppuStack_168 = auVar18 << 0x20;
                                    func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &pppppppuStack_168);
                                    iVar31 = var_1c0h;
                                    if (*(int32_t *)(iVar28 + 0x20bc) != 0) {
                                        auVar11._4_4_ = uVar25;
                                        auVar11._0_4_ = uVar26;
                                        auVar11._8_4_ = uVar82;
                                        auVar11._12_4_ = uVar83;
                                        *(undefined (*) [16])(iVar28 + 0xed0) = auVar11;
                                    }
                                    var_1f0h = 0;
                                    uVar32 = func_0x000180016b80(&uStack_148, *(undefined4 *)(iVar37 + var_1c0h * 8));
                                    puVar48 = (undefined8 *)(iVar31 * 8 + 8 + iVar37);
                                    if (3 < 0x7fffffffffffffff - puVar48[2]) {
                                        puVar71 = puVar48;
                                        if (0xf < (uint64_t)puVar48[3]) {
                                            puVar71 = (undefined8 *)*puVar48;
                                        }
                                        var_208h = 4;
                                        var_210h = 0x18063ce6c;
                                        var_218h = puVar48[2];
                                        func_0x0001800384c0(&pppppppuStack_108, uVar45, puVar48, puVar71);
                                        func_0x00018007d810(&pppppppuStack_168, (uint8_t)var_1f8h, &pppppppuStack_108, 
                                                            uVar32);
                                        func_0x000180146c70(&pppppppuStack_168, 0, 2, &var_1f0h);
                                        auVar15[15] = 0;
                                        auVar15._0_15_ = stack0xfffffffffffffe99;
                                        _pppppppuStack_168 = auVar15 << 8;
                                        if (0xf < (uint64_t)auStack_f8._8_8_) {
                                            uVar49 = auStack_f8._8_8_ + 1;
                                            pppppppuVar39 = pppppppuStack_108;
                                            if (0xfff < uVar49) {
                                                pppppppuVar39 = (undefined8 *******)pppppppuStack_108[-1];
                                                if (0x1f < (uint64_t)
                                                           ((int64_t)pppppppuStack_108 + (-8 - (int64_t)pppppppuVar39)))
                                                goto code_r0x00018007bf7d;
                                                uVar49 = auStack_f8._8_8_ + 0x28;
                                            }
                                            func_0x000180459c3c(pppppppuVar39, uVar49);
                                        }
                                        uVar49 = in_stack_fffffffffffffec8._8_8_;
                                        if (0xf < uVar49) {
                                            uVar47 = uVar49 + 1;
                                            ppppppuVar40 = uStack_148;
                                            if (0xfff < uVar47) {
                                                ppppppuVar40 = uStack_148[-1];
                                                puVar56 = auStackY_238;
                                                if (0x1f < (uint64_t)
                                                           ((int64_t)uStack_148 + (-8 - (int64_t)ppppppuVar40)))
                                                goto code_r0x00018007bf8b;
                                                uVar47 = uVar49 + 0x28;
                                            }
                                            func_0x000180459c3c(ppppppuVar40, uVar47);
                                        }
                                        func_0x0001800f6770(1);
                                        uVar32 = func_0x000180016b80(&pppppppuStack_168, 
                                                                     *(undefined4 *)(iVar37 + iVar31 * 8));
                                        piVar34 = (int64_t *)func_0x000180018c80(uVar32, 0, 0x18063cec8, 6);
                                        pppppppuVar39 = (undefined8 *******)*piVar34;
                                        iStack_100 = piVar34[1];
                                        auStack_f8 = *(undefined (*) [16])(piVar34 + 2);
                                        piVar34[2] = 0;
                                        piVar34[3] = 0xf;
                                        *(undefined *)piVar34 = 0;
                                        uVar49 = auStack_f8._8_8_;
                                        pppppppuVar41 = &pppppppuStack_108;
                                        if (0xf < uVar49) {
                                            pppppppuVar41 = pppppppuVar39;
                                        }
                                        pppppppuStack_108 = pppppppuVar39;
                                        uVar22 = func_0x00018010d750(pppppppuVar41);
                                        uVar66 = (uint64_t)uVar22;
                                        if (0xf < uVar49) {
                                            uVar47 = uVar49 + 1;
                                            pppppppuVar41 = pppppppuVar39;
                                            if (0xfff < uVar47) {
                                                pppppppuVar41 = (undefined8 *******)pppppppuVar39[-1];
                                                if (0x1f < (uint64_t)
                                                           ((int64_t)pppppppuVar39 + (-8 - (int64_t)pppppppuVar41)))
                                                goto code_r0x00018007bf84;
                                                uVar47 = uVar49 + 0x28;
                                            }
                                            func_0x000180459c3c(pppppppuVar41, uVar47);
                                        }
                                        iVar28 = var_1c0h;
                                        if (uVar22 != 0) {
                                            var_218h = CONCAT71(var_218h._1_7_, 1);
                                            cVar21 = func_0x000180148270(0x18063cec0);
                                            iVar28 = var_1c0h;
                                            if (cVar21 != '\0') {
                                                puVar48 = (undefined8 *)(var_1c0h * 8 + 8 + iVar37);
                                                if (0xf < (uint64_t)puVar48[3]) {
                                                    puVar48 = (undefined8 *)*puVar48;
                                                }
                                                if (*(code **)(*(int64_t *)0x180781f28 + 0xc50) != (code *)0x0) {
                                                    (**(code **)(*(int64_t *)0x180781f28 + 0xc50))
                                                              (*(int64_t *)0x180781f28, puVar48);
                                                }
                                            }
                                            var_218h = CONCAT71(var_218h._1_7_, 1);
                                            cVar21 = func_0x000180148270(0x180625070);
                                            if (cVar21 != '\0') {
                                                var_1d8h._0_4_ = (int32_t)var_1e4h;
                                            }
                                            func_0x00018010d5c0();
                                        }
                                        piVar50 = (int64_t *)(iVar37 + 8 + iVar28 * 8);
                                        piVar34 = piVar50 + 2;
                                        if (0xf < (uint64_t)piVar50[3]) {
                                            piVar50 = (int64_t *)*piVar50;
                                        }
                                        func_0x00018000d970(auStack_128, piVar50, *piVar34);
                                        if (uStack_118 < uStack_110) {
                                            puVar56 = auStack_128;
                                            if (0xf < uStack_110) {
                                                puVar56 = (undefined *)auStack_128._0_8_;
                                            }
                                            puVar2 = (undefined2 *)(puVar56 + uStack_118);
                                            uStack_118 = uStack_118 + 1;
                                            *puVar2 = 10;
                                        } else {
                                            func_0x00018000f010(auStack_128, 1, (uint8_t)var_1f8h, 10);
                                        }
                                        var_1d0h = *(int64_t *)0x18077afc0;
                                        goto code_r0x00018007be69;
                                    }
                                    goto code_r0x00018007c2c7;
                                }
                                uVar47 = uVar49 + 1;
                                ppppppuVar40 = uStack_148;
                                if (uVar47 < 0x1000) {
code_r0x00018007b796:
                                    func_0x000180459c3c(ppppppuVar40, uVar47);
                                    goto code_r0x00018007b79b;
                                }
                                ppppppuVar40 = uStack_148[-1];
                                puVar56 = auStackY_238;
                                if ((uint64_t)((int64_t)uStack_148 + (-8 - (int64_t)ppppppuVar40)) < 0x20) {
                                    uVar47 = uVar49 + 0x28;
                                    goto code_r0x00018007b796;
                                }
                            } else {
                                uVar46 = uVar47 + 1;
                                ppppppuVar40 = pppppppuStack_168;
                                if (uVar46 < 0x1000) {
code_r0x00018007b748:
                                    func_0x000180459c3c(ppppppuVar40, uVar46);
                                    goto code_r0x00018007b74d;
                                }
                                ppppppuVar40 = pppppppuStack_168[-1];
                                if ((uint64_t)((int64_t)pppppppuStack_168 + (-8 - (int64_t)ppppppuVar40)) < 0x20) {
                                    uVar46 = uVar47 + 0x28;
                                    goto code_r0x00018007b748;
                                }
                                pcVar9 = (code *)swi(0x29);
                                (*pcVar9)(5);
                                puVar53 = auStackY_230;
code_r0x00018007bf6f:
                                pcVar9 = (code *)swi(0x29);
                                (*pcVar9)(5);
                                pcVar9 = (code *)swi(0x29);
                                (*pcVar9)(5);
                                puVar54 = puVar53 + 0x10;
code_r0x00018007bf7d:
                                pcVar9 = (code *)swi(0x29);
                                (*pcVar9)(5);
                                puVar55 = puVar54 + 8;
code_r0x00018007bf84:
                                pcVar9 = (code *)swi(0x29);
                                (*pcVar9)(5);
                                puVar56 = puVar55 + 8;
                            }
code_r0x00018007bf8b:
                            pcVar9 = (code *)swi(0x29);
                            (*pcVar9)(5);
                            puVar56 = puVar56 + 8;
                            goto code_r0x00018007bf92;
                        }
                        ppcVar62 = (char **)0x1805aadb1;
                        if (ppcVar38 != (char **)0x0) {
                            ppcVar62 = ppcVar38;
                        }
                        ppcVar64 = (char **)0x1805aadb1;
                        if (ppcVar38 != (char **)0x0) {
                            ppcVar64 = (char **)0x0;
                        }
                        var_1c8h = (int64_t)*(uint8_t ***)0x1807829c8;
                        ppuVar63 = *(uint8_t ***)0x1807829c8 + (int64_t)*(int32_t *)0x1807829c0 * 2;
                        ppcVar38 = ppcVar64;
                        ppuVar89 = ppuVar63;
                        if (*(uint8_t ***)0x1807829c8 != ppuVar63) {
                            do {
                                puVar69 = *(uint8_t **)(var_1c8h + 8);
                                puVar8 = *(uint8_t **)var_1c8h;
                                if (puVar8 != puVar69) {
                                    uVar22 = *puVar8;
                                    ppuVar63 = ppuVar89;
                                    if (uVar22 != 0x2d) {
                                        if (puVar69 == (uint8_t *)0x0) {
                                            ppcVar64 = ppcVar38;
                                            iVar37 = func_0x000180498cd0(puVar8);
                                            puVar69 = puVar8 + iVar37;
                                            ppcVar38 = ppcVar64;
                                            ppuVar63 = ppuVar89;
                                        }
                                        uVar49 = in_stack_fffffffffffffec8._8_8_;
                                        ppcVar72 = ppcVar62;
                                        if ((uint8_t)(uVar22 + 0x9f) < 0x1a) {
                                            uVar22 = uVar22 & 0xdf;
                                        }
                                        do {
                                            ppuVar89 = ppuVar63;
                                            if (ppcVar64 == (char **)0x0) {
                                                if (*(uint8_t *)ppcVar72 == 0) goto code_r0x00018007b2ef;
                                            } else if (ppcVar64 <= ppcVar72) goto code_r0x00018007b2ef;
                                            uVar65 = *(uint8_t *)ppcVar72;
                                            uVar36 = uVar65 & 0xdf;
                                            if (0x19 < (uint8_t)(uVar65 + 0x9f)) {
                                                uVar36 = uVar65;
                                            }
                                            ppcVar64 = ppcVar72;
                                            puVar68 = puVar8;
                                            if (uVar36 == uVar22) {
                                                do {
                                                    puVar68 = puVar68 + 1;
                                                    if (puVar69 <= puVar68) break;
                                                    ppcVar64 = (char **)((int64_t)ppcVar64 + 1);
                                                    uVar65 = *(uint8_t *)ppcVar64;
                                                    uVar36 = *puVar68;
                                                    uVar59 = uVar36 & 0xdf;
                                                    if (0x19 < (uint8_t)(uVar36 + 0x9f)) {
                                                        uVar59 = uVar36;
                                                    }
                                                    uVar36 = uVar65 & 0xdf;
                                                    if (0x19 < (uint8_t)(uVar65 + 0x9f)) {
                                                        uVar36 = uVar65;
                                                    }
                                                } while (uVar36 == uVar59);
                                                if (puVar68 == puVar69) goto code_r0x00018007b31a;
                                            }
                                            ppcVar72 = (char **)((int64_t)ppcVar72 + 1);
                                            ppcVar64 = ppcVar38;
                                        } while( true );
                                    }
                                    puVar68 = puVar8 + 1;
                                    if (puVar69 == (uint8_t *)0x0) {
                                        ppcVar64 = ppcVar38;
                                        iVar37 = func_0x000180498cd0(puVar68);
                                        puVar69 = puVar68 + iVar37;
                                        ppcVar38 = ppcVar64;
                                        ppuVar63 = ppuVar89;
                                    }
                                    uVar22 = *puVar68;
                                    ppcVar72 = ppcVar62;
                                    uVar65 = uVar22 & 0xdf;
                                    if (0x19 < (uint8_t)(uVar22 + 0x9f)) {
                                        uVar65 = uVar22;
                                    }
                                    do {
                                        ppuVar89 = ppuVar63;
                                        if (ppcVar64 == (char **)0x0) {
                                            if (*(uint8_t *)ppcVar72 == 0) break;
                                        } else if (ppcVar64 <= ppcVar72) break;
                                        uVar22 = *(uint8_t *)ppcVar72;
                                        uVar36 = uVar22 & 0xdf;
                                        if (0x19 < (uint8_t)(uVar22 + 0x9f)) {
                                            uVar36 = uVar22;
                                        }
                                        if (uVar36 == uVar65) {
                                            ppcVar64 = ppcVar72;
                                            for (puVar68 = puVar8 + 2; puVar68 < puVar69; puVar68 = puVar68 + 1) {
                                                ppcVar64 = (char **)((int64_t)ppcVar64 + 1);
                                                uVar22 = *(uint8_t *)ppcVar64;
                                                uVar36 = *puVar68;
                                                uVar59 = uVar36 & 0xdf;
                                                if (0x19 < (uint8_t)(uVar36 + 0x9f)) {
                                                    uVar59 = uVar36;
                                                }
                                                uVar36 = uVar22 & 0xdf;
                                                if (0x19 < (uint8_t)(uVar22 + 0x9f)) {
                                                    uVar36 = uVar22;
                                                }
                                                if (uVar36 != uVar59) break;
                                            }
                                            if (puVar68 == puVar69) goto code_r0x00018007be69;
                                        }
                                        ppcVar72 = (char **)((int64_t)ppcVar72 + 1);
                                        ppcVar64 = ppcVar38;
                                    } while( true );
                                }
code_r0x00018007b2ef:
                                var_1c8h = var_1c8h + 0x10;
                            } while ((uint8_t **)var_1c8h != ppuVar63);
                        }
                        uVar49 = in_stack_fffffffffffffec8._8_8_;
                        if (*(int32_t *)0x1807829d0 == 0) goto code_r0x00018007b31a;
code_r0x00018007be69:
                        var_1e4h._0_4_ = (int32_t)var_1e4h + 1;
                        iVar24 = (int32_t)((int64_t)*(undefined4 **)0x18077afc8 - var_1d0h >> 3);
                    } while (SBORROW4((int32_t)var_1e4h, iVar24 * -0x33333333) !=
                             (int32_t)var_1e4h + iVar24 * 0x33333333 < 0);
                }
                iVar37 = -0x3333333333333333;
                iVar27 = -0x33333333;
                uVar66 = 1;
                func_0x0001801346c0();
                iVar28 = *(int64_t *)0x180781f28;
                uVar45 = func_0x0001800f5a90(0x18063ceb0, 0, 
                                             *(undefined4 *)
                                              (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4
                                              + (int64_t)*(int32_t *)
                                                          (*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) * 4))
                ;
                cVar21 = func_0x000180108070(1);
                if (((cVar21 == '\0') || (cVar21 = func_0x0001801062b0(0x20), cVar21 == '\0')) ||
                   ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) != 0 ||
                    (puVar56 = auStackY_238, *(int32_t *)(*(int64_t *)0x180781f28 + 0x1640) != 0)))) {
                    puVar56 = auStackY_238;
                    if ((*(int32_t *)(iVar28 + 0x221c) != 0) &&
                       (iVar31 = *(int64_t *)(iVar28 + 0x15e0), puVar56 = auStackY_238, *(int32_t *)(iVar31 + 0x10) != 0
                       )) {
                        iVar29 = *(int64_t *)(iVar28 + 0x21d8);
                        iVar28 = iVar29;
                        iVar70 = iVar29;
                        if (iVar29 != 0) {
                            do {
                                iVar28 = *(int64_t *)(iVar70 + 0x418);
                                bVar73 = iVar70 != iVar28;
                                iVar70 = iVar28;
                            } while (bVar73);
                        }
                        puVar56 = auStackY_238;
                        if (iVar28 == iVar31) goto code_r0x00018007bf92;
                        for (; puVar56 = auStackY_238, iVar29 != 0; iVar29 = *(int64_t *)(iVar29 + 0x408)) {
                            puVar56 = auStackY_238;
                            if (iVar29 == iVar31) goto code_r0x00018007bf92;
                            puVar56 = auStackY_238;
                            if (iVar29 == iVar28) break;
                        }
                    }
                } else {
code_r0x00018007bf92:
                    iVar27 = (int32_t)iVar37;
                    *(undefined8 *)(puVar56 + -8) = 0x18007bf9e;
                    func_0x00018010d030(uVar45, 0x108);
                }
                *(undefined8 *)(puVar56 + -8) = 0x18007bfaa;
                cVar21 = func_0x00018010d4b0(uVar45, 0x141);
                if (cVar21 != '\0') {
                    puVar56[0x20] = 1;
                    *(undefined8 *)(puVar56 + -8) = 0x18007bfc5;
                    cVar21 = func_0x000180148270(0x18063ce98);
                    puVar56[0x20] = 1;
                    *(undefined8 *)(puVar56 + -8) = 0x18007bfdf;
                    cVar23 = func_0x000180148270(0x18063cf00);
                    if (cVar23 != '\0') {
                        *(undefined8 *)(puVar56 + -8) = 0x18007bfe8;
                        func_0x00018007c720();
                    }
                    *(undefined8 *)(puVar56 + -8) = 0x18007bfed;
                    func_0x00018010d5c0();
                    if (cVar21 != '\0') {
                        puVar51 = auStack_128;
                        if (0xf < uStack_110) {
                            puVar51 = (undefined *)auStack_128._0_8_;
                        }
                        pcVar9 = *(code **)(*(int64_t *)0x180781f28 + 0xc50);
                        if (pcVar9 != (code *)0x0) {
                            *(undefined8 *)(puVar56 + -8) = 0x18007c018;
                            (*pcVar9)(*(int64_t *)0x180781f28, puVar51);
                        }
                    }
                }
                if (0xf < uStack_110) {
                    uVar49 = uStack_110 + 1;
                    iVar37 = auStack_128._0_8_;
                    if (0xfff < uVar49) {
                        iVar37 = *(int64_t *)(auStack_128._0_8_ + -8);
                        if (0x1f < (auStack_128._0_8_ - iVar37) - 8U) {
                            pcVar9 = (code *)swi(0x29);
                            (*pcVar9)(5);
                            puVar57 = puVar56 + 8;
code_r0x00018007c2c7:
                            *(undefined8 *)(puVar57 + -8) = 0x18007c2cc;
                            func_0x0001800047c0();
                            puVar58 = puVar57;
code_r0x00018007c2cd:
                            *(undefined8 *)(puVar58 + -8) = 0x18007c2e2;
                            (*(code *)0x69a3d8)(0, 0x18063d170, 0, 0);
                            *(undefined8 *)(puVar58 + -8) = 0x18007c2e9;
                            func_0x00018046df68(0);
                            pcVar9 = (code *)swi(3);
                            (*pcVar9)();
                            return;
                        }
                        uVar49 = uStack_110 + 0x28;
                    }
                    *(undefined8 *)(puVar56 + -8) = 0x18007c054;
                    func_0x000180459c3c(iVar37, uVar49);
                }
                uStack_118 = 0;
                uStack_110 = 0xf;
                auVar16[15] = 0;
                auVar16._0_15_ = auStack_128._1_15_;
                auStack_128 = auVar16 << 8;
                iVar24 = *(int32_t *)(puVar56 + 0x60);
            }
            puVar51 = puVar56;
            if ((*(char *)0x18077aef5 != '\0') &&
               (*(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0xe0) <=
                *(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0xd8))) {
                *(undefined8 *)(puVar56 + -8) = 0x18007c0a2;
                func_0x00018010cc30(0x3f800000);
            }
        }
        *(undefined8 *)(puVar51 + -8) = 0x18007c0a7;
        func_0x0001800fea60();
        puVar7 = *(undefined4 **)0x18077afc8;
        if ((-1 < iVar24) &&
           (iVar24 < (int32_t)((int64_t)*(undefined4 **)0x18077afc8 - *(int64_t *)0x18077afc0 >> 3) * iVar27)) {
            puVar3 = (undefined4 *)(*(int64_t *)0x18077afc0 + (int64_t)iVar24 * 0x28);
            puVar19 = puVar3;
            while (puVar19 = puVar19 + 10, puVar19 != puVar7) {
                *puVar3 = *puVar19;
                *(undefined8 *)(puVar51 + -8) = 0x18007c0f2;
                func_0x000180012c10(puVar3 + 2, puVar19 + 2);
                puVar3 = puVar3 + 10;
            }
            *(undefined8 *)(puVar51 + -8) = 0x18007c10f;
            func_0x000180004e40(*(undefined4 **)0x18077afc8 + -8);
            *(undefined4 **)0x18077afc8 = *(undefined4 **)0x18077afc8 + -10;
        }
        *(undefined8 *)(puVar51 + -8) = 0x18007c11c;
        func_0x000180105c20();
        *(undefined8 *)(puVar51 + -8) = 0x18007c12d;
        func_0x0001801019f0(0x18063d108, 0, 0);
        *(undefined8 *)(puVar51 + -8) = 0x18007c132;
        fcn.180077c70();
        *(undefined8 *)(puVar51 + -8) = 0x18007c137;
        func_0x000180105c20();
        uVar49 = (uint64_t)uVar44;
    }
    *(undefined8 *)(puVar51 + -8) = 0x18007c153;
    func_0x0001800f6810(3);
    *(undefined8 *)(puVar51 + -8) = 0x18007c158;
    func_0x000180066720();
    *(undefined8 *)(puVar51 + -8) = 0x18007c160;
    func_0x0001800f6a20(uVar66 & 0xffffffff);
    *(undefined8 *)(puVar51 + -8) = 0x18007c165;
    func_0x0001800fdba0();
    *(undefined8 *)(puVar51 + -8) = 0x18007c16a;
    fVar76 = (float)func_0x00018007c2f0();
    *(undefined8 *)(puVar51 + -8) = 0x18007c179;
    fVar81 = fVar76;
    fVar84 = fVar76;
    fVar80 = fVar76;
    fVar77 = fVar76;
    iVar37 = func_0x0001800fa7d0();
    iVar24 = 0;
    if (0 < *(int32_t *)(iVar37 + 4)) {
        do {
            piVar10 = *(int32_t **)(*(int64_t *)(iVar37 + 0x18) + (int64_t)iVar24 * 8);
            pauVar52 = *(undefined (**) [16])(piVar10 + 2);
            pauVar33 = (undefined (*) [16])((int64_t)pauVar52 + (int64_t)*piVar10 * 0x48);
            for (; pauVar52 != pauVar33; pauVar52 = (undefined (*) [16])(pauVar52[4] + 8)) {
                auVar78._0_4_ = fVar76 * *(float *)*pauVar52;
                auVar78._4_4_ = fVar81 * *(float *)(*pauVar52 + 4);
                auVar78._8_4_ = fVar84 * *(float *)(*pauVar52 + 8);
                auVar78._12_4_ = fVar80 * *(float *)(*pauVar52 + 0xc);
                *pauVar52 = auVar78;
            }
            pfVar61 = *(float **)(piVar10 + 10);
            pfVar30 = pfVar61 + (int64_t)piVar10[8] * 5;
            for (; pfVar61 != pfVar30; pfVar61 = pfVar61 + 5) {
                *pfVar61 = fVar77 * *pfVar61;
                pfVar61[1] = fVar77 * pfVar61[1];
            }
            iVar24 = iVar24 + 1;
        } while (iVar24 < *(int32_t *)(iVar37 + 4));
    }
    pcVar9 = *(code **)(**(int64_t **)0x1807821c0 + 0x108);
    *(undefined8 *)(puVar51 + -8) = 0x18007c22b;
    (*pcVar9)(*(int64_t **)0x1807821c0, uVar66 & 0xffffffff, 0x1807821b0, 0);
    pcVar42 = (char *)(**(int64_t **)(*(int64_t *)0x180781f28 + 0x2158) + 200);
    if (*pcVar42 == '\0') {
        pcVar42 = (char *)0x0;
    }
    *(undefined8 *)(puVar51 + -8) = 0x18007c250;
    func_0x0001801660f0(pcVar42);
    puVar58 = puVar51;
code_r0x00018007c250:
    *(undefined8 *)(puVar58 + -8) = 0x18007c261;
    (**(code **)0x1807821a8)(arg1, uVar49, uVar60);
    *(undefined8 *)(puVar58 + -8) = 0x18007c26d;
    func_0x000180459870(uStack_e8 ^ (uint64_t)puVar58);
    return;
}

// ============================================================
// Function: FUN_18007c2f0
// Address: 0x18007c2f0
// Size: 51 bytes
// ============================================================
undefined8 fcn.18007c2f0(void)
{
    undefined8 uVar1;
    
    uVar1 = (*(code *)0x69a69a)(*(undefined8 *)0x180781f08, 2);
    uVar1 = fcn.18016a3b0(uVar1);
    if ((float)uVar1 <= 0.0) {
        uVar1 = 0x3f800000;
    }
    return uVar1;
}

// ============================================================
// Function: FUN_18007c330
// Address: 0x18007c330
// Size: 155 bytes
// ============================================================
void fcn.18007c330(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined auStack_78 [32];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    if (*(int64_t **)0x1807821b0 != (int64_t *)0x0) {
        (**(code **)(**(int64_t **)0x1807821b0 + 0x10))();
        *(int64_t **)0x1807821b0 = (int64_t *)0x0;
    }
    _var_48h = ZEXT816(0);
    (*(code *)0x69a3e6)(*(undefined8 *)0x180782190, &var_48h);
    var_50h._0_4_ = (undefined4)arg_30h;
    var_58h._0_4_ = (undefined4)arg_28h;
    (**(code **)0x1807821d8)(arg1, arg2 & 0xffffffff, arg3 & 0xffffffff, arg4 & 0xffffffff);
    fcn.180459870(var_38h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_18007c3d0
// Address: 0x18007c3d0
// Size: 197 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18007c3d0(int64_t arg1)
{
    undefined (*pauVar1) [16];
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    pauVar1 = (undefined (*) [16])fcn.180459890(0x60);
    *pauVar1 = ZEXT816(0);
    pauVar1[1] = ZEXT816(0);
    pauVar1[2] = ZEXT816(0);
    pauVar1[3] = ZEXT816(0);
    pauVar1[4] = ZEXT816(0);
    pauVar1[5] = ZEXT816(0);
    *(undefined4 *)*pauVar1 = 0;
    *(undefined8 *)(*pauVar1 + 8) = 0;
    *(undefined8 *)pauVar1[1] = 0;
    iVar2 = fcn.180459890(0x20);
    *(int64_t *)iVar2 = iVar2;
    *(int64_t *)(iVar2 + 8) = iVar2;
    *(int64_t *)(*pauVar1 + 8) = iVar2;
    *(undefined8 *)(pauVar1[1] + 8) = 0;
    *(undefined8 *)pauVar1[2] = 0;
    *(undefined8 *)(pauVar1[2] + 8) = 0;
    *(undefined8 *)pauVar1[3] = 7;
    *(undefined8 *)(pauVar1[3] + 8) = 8;
    *(undefined4 *)*pauVar1 = 0x3f800000;
    fcn.18000f7e0(pauVar1[1] + 8, 0x10, *(undefined8 *)(*pauVar1 + 8));
    pauVar1[4] = ZEXT816(0);
    *(undefined8 *)pauVar1[5] = 0;
    *(undefined8 *)(pauVar1[5] + 8) = 0xf;
    pauVar1[4][0] = 0;
    *(undefined (**) [16])arg1 = pauVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18007c4a0
// Address: 0x18007c4a0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18007c4a0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_8h;
    
    uVar1 = *(undefined8 *)arg2;
    *(undefined8 *)arg2 = 0;
    iVar2 = *(int64_t *)arg1;
    *(undefined8 *)arg1 = uVar1;
    if (iVar2 != 0) {
        fcn.18007dab0(iVar2);
        fcn.180459c3c(iVar2, 0x5f0);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18007c4f0
// Address: 0x18007c4f0
// Size: 413 bytes
// ============================================================
undefined8 * fcn.18007c4f0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined8 *puVar4;
    uint64_t uVar5;
    undefined8 *puVar6;
    int64_t iVar7;
    undefined *puVar8;
    int64_t iVar9;
    uint64_t uVar10;
    undefined8 *unaff_RDI;
    undefined8 *unaff_R14;
    int64_t var_1h;
    undefined auStack_68 [8];
    undefined auStack_60 [32];
    
    puVar4 = *(undefined8 **)(arg1 + 8);
    if (puVar4 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar4 = *(undefined8 *)arg2;
        puVar4 = *(undefined8 **)(arg1 + 8);
        *(undefined8 **)(arg1 + 8) = puVar4 + 1;
        return puVar4;
    }
    iVar9 = (int64_t)puVar4 - *(int64_t *)arg1 >> 3;
    if (iVar9 == 0x1fffffffffffffff) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        puVar4 = (undefined8 *)(*pcVar3)();
        return puVar4;
    }
    uVar5 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (0x1fffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x00018007c687:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        puVar4 = (undefined8 *)(*pcVar3)();
        return puVar4;
    }
    uVar1 = iVar9 + 1;
    uVar5 = uVar5 + (uVar5 >> 1);
    uVar10 = uVar1;
    if (uVar1 <= uVar5) {
        uVar10 = uVar5;
    }
    if (0x1fffffffffffffff < uVar10) goto code_r0x00018007c687;
    uVar5 = uVar10 * 8;
    if (uVar5 == 0) {
        unaff_RDI = (undefined8 *)0x0;
code_r0x00018007c5d0:
        unaff_R14 = unaff_RDI + iVar9;
        *unaff_R14 = *(undefined8 *)arg2;
        puVar2 = *(undefined8 **)arg1;
        if (puVar4 == *(undefined8 **)(arg1 + 8)) {
            iVar9 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
            puVar6 = unaff_RDI;
            puVar4 = puVar2;
        } else {
            func_0x000180498030(unaff_RDI, puVar2, (int64_t)puVar4 - (int64_t)puVar2);
            puVar6 = unaff_R14 + 1;
            iVar9 = *(int64_t *)(arg1 + 8) - (int64_t)puVar4;
        }
        func_0x000180498030(puVar6, puVar4, iVar9);
        iVar9 = *(int64_t *)arg1;
        if (iVar9 == 0) goto code_r0x00018007c65a;
        iVar7 = iVar9;
        puVar8 = auStack_68;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar9 >> 3) * 8)) &&
           (iVar7 = *(int64_t *)(iVar9 + -8), puVar8 = auStack_68, 0x1f < (iVar9 - iVar7) - 8U))
        goto code_r0x00018007c648;
    } else {
        if (uVar5 < 0x1000) {
            unaff_RDI = (undefined8 *)fcn.180459890(uVar5);
            goto code_r0x00018007c5d0;
        }
        if (uVar5 + 0x27 <= uVar5) goto code_r0x00018007c687;
        iVar7 = fcn.180459890();
        if (iVar7 != 0) {
            unaff_RDI = (undefined8 *)(iVar7 + 0x27U & 0xffffffffffffffe0);
            unaff_RDI[-1] = iVar7;
            goto code_r0x00018007c5d0;
        }
code_r0x00018007c648:
        iVar7 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar8 = auStack_60;
    }
    *(undefined8 *)(puVar8 + -8) = 0x18007c65a;
    fcn.180459c3c(iVar7);
code_r0x00018007c65a:
    *(undefined8 **)arg1 = unaff_RDI;
    *(undefined8 **)(arg1 + 8) = unaff_RDI + uVar1;
    *(undefined8 **)(arg1 + 0x10) = unaff_RDI + uVar10;
    return unaff_R14;
}

// ============================================================
// Function: FUN_18007c690
// Address: 0x18007c690
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007c690(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x10) {
            func_0x00018000d070(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xfffffffffffffff0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18007c706;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007c6a5
// Address: 0x18007c6a5
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007c690(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x10) {
            func_0x00018000d070(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xfffffffffffffff0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18007c706;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007c6e0
// Address: 0x18007c6e0
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007c690(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x10) {
            func_0x00018000d070(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xfffffffffffffff0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18007c706;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007c720
// Address: 0x18007c720
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007c720(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)0x18077afc8;
    iVar2 = *(int64_t *)0x18077afc0;
    if (*(int64_t *)0x18077afc0 != *(int64_t *)0x18077afc8) {
        do {
            fcn.180004e40(iVar2 + 8);
            iVar2 = iVar2 + 0x28;
        } while (iVar2 != iVar1);
        *(int64_t *)0x18077afc8 = *(int64_t *)0x18077afc0;
    }
    return;
}

// ============================================================
// Function: FUN_18007c770
// Address: 0x18007c770
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007c770(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x00018002ee50(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18007c7ff;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007c789
// Address: 0x18007c789
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007c770(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x00018002ee50(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18007c7ff;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007c7d6
// Address: 0x18007c7d6
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007c770(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x00018002ee50(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18007c7ff;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

