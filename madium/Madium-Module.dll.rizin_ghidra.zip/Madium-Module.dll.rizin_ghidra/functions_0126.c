// Chunk 126 - 50 functions

// ============================================================
// Function: FUN_1801af974
// Address: 0x1801af974
// Size: 49 bytes
// ============================================================
int32_t fcn.1801af974(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                     int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h,
                     int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_f8h)
{
    int32_t iVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t *piVar5;
    int64_t unaff_RDI;
    int32_t iVar6;
    int32_t *unaff_R13;
    int32_t *unaff_R14;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_20h;
    
    bVar2 = true;
    iVar6 = 0;
    arg_70h._0_4_ = 0;
    *(undefined4 *)arg2 = 0;
    if (unaff_R13 != (int32_t *)0x0) {
        *(undefined4 *)arg4 = 0;
    }
    iVar7 = *unaff_R14;
    iVar8 = iVar6;
    do {
        if (iVar7 == 0) {
            *(int32_t *)arg3 = (int32_t)arg_70h;
            if ((int32_t)arg_70h == 0) {
                iVar6 = 0xbf;
            }
            return iVar6;
        }
        iVar7 = iVar6;
        if (*(code **)(unaff_R14 + 2) == (code *)0x0) {
code_r0x0001801af9be:
            bVar2 = true;
            iVar8 = iVar7;
        } else {
            piVar5 = (int32_t *)(**(code **)(unaff_R14 + 2))();
            if ((bVar2) && (iVar8 == 0)) {
                iVar8 = *unaff_R14;
            }
            iVar4 = *(int32_t *)(unaff_RDI + 0x9b4);
            iVar1 = *piVar5;
            iVar7 = iVar8;
            if ((iVar4 != 0) && (iVar1 != iVar4)) {
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(unaff_RDI + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                    iVar3 = 1;
                    if (iVar1 < iVar4) {
                        iVar3 = -1;
                    }
                } else {
                    if (iVar4 == 0x100) {
                        iVar4 = 0xff00;
                    }
                    if (iVar1 == 0x100) {
                        iVar1 = 0xff00;
                    }
                    iVar3 = 1;
                    if (iVar4 < iVar1) {
                        iVar3 = -1;
                    }
                }
                if (iVar3 < 0) goto code_r0x0001801af9be;
            }
            iVar4 = func_0x0001801a2690();
            if ((iVar4 == 0) ||
               ((((*(int32_t *)(unaff_RDI + 0x9b8) != 0 && (iVar4 = func_0x0001801afd90(), 0 < iVar4)) ||
                 ((*(uint64_t *)(unaff_RDI + 0x9a8) & *(uint64_t *)(piVar5 + 2)) != 0)) ||
                (((*(uint8_t *)(piVar5 + 1) & 2) != 0 &&
                 ((*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x878) + 0x1c) & 0x30000) != 0))))))
            goto code_r0x0001801af9be;
            if (bVar2) {
                if ((unaff_R13 != (int32_t *)0x0) && (iVar8 != 0)) {
                    *unaff_R13 = iVar8;
                }
                arg_70h._0_4_ = *piVar5;
                *(int32_t *)arg_78h = (int32_t)arg_70h;
                bVar2 = false;
            } else {
                *(int32_t *)arg_78h = *piVar5;
            }
        }
        unaff_R14 = unaff_R14 + 6;
        iVar7 = *unaff_R14;
        arg3 = arg_80h;
    } while( true );
}

// ============================================================
// Function: FUN_1801af9a5
// Address: 0x1801af9a5
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_88h
// WARNING: Variable defined which should be unmapped: arg_48h
// WARNING: Variable defined which should be unmapped: arg_40h
// WARNING: Variable defined which should be unmapped: arg_38h
// WARNING: Variable defined which should be unmapped: arg_30h

int32_t fcn.1801af974(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                     int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h,
                     int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_f8h)
{
    int32_t iVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t *piVar5;
    int64_t unaff_RDI;
    int32_t iVar6;
    int32_t *unaff_R13;
    int32_t *unaff_R14;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_20h;
    
    bVar2 = true;
    iVar6 = 0;
    arg_70h._0_4_ = 0;
    *(undefined4 *)arg2 = 0;
    if (unaff_R13 != (int32_t *)0x0) {
        *(undefined4 *)arg4 = 0;
    }
    iVar7 = *unaff_R14;
    iVar8 = iVar6;
    do {
        if (iVar7 == 0) {
            *(int32_t *)arg3 = (int32_t)arg_70h;
            if ((int32_t)arg_70h == 0) {
                iVar6 = 0xbf;
            }
            return iVar6;
        }
        iVar7 = iVar6;
        if (*(code **)(unaff_R14 + 2) == (code *)0x0) {
code_r0x0001801af9be:
            bVar2 = true;
            iVar8 = iVar7;
        } else {
            piVar5 = (int32_t *)(**(code **)(unaff_R14 + 2))();
            if ((bVar2) && (iVar8 == 0)) {
                iVar8 = *unaff_R14;
            }
            iVar4 = *(int32_t *)(unaff_RDI + 0x9b4);
            iVar1 = *piVar5;
            iVar7 = iVar8;
            if ((iVar4 != 0) && (iVar1 != iVar4)) {
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(unaff_RDI + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                    iVar3 = 1;
                    if (iVar1 < iVar4) {
                        iVar3 = -1;
                    }
                } else {
                    if (iVar4 == 0x100) {
                        iVar4 = 0xff00;
                    }
                    if (iVar1 == 0x100) {
                        iVar1 = 0xff00;
                    }
                    iVar3 = 1;
                    if (iVar4 < iVar1) {
                        iVar3 = -1;
                    }
                }
                if (iVar3 < 0) goto code_r0x0001801af9be;
            }
            iVar4 = func_0x0001801a2690();
            if ((iVar4 == 0) ||
               ((((*(int32_t *)(unaff_RDI + 0x9b8) != 0 && (iVar4 = func_0x0001801afd90(), 0 < iVar4)) ||
                 ((*(uint64_t *)(unaff_RDI + 0x9a8) & *(uint64_t *)(piVar5 + 2)) != 0)) ||
                (((*(uint8_t *)(piVar5 + 1) & 2) != 0 &&
                 ((*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x878) + 0x1c) & 0x30000) != 0))))))
            goto code_r0x0001801af9be;
            if (bVar2) {
                if ((unaff_R13 != (int32_t *)0x0) && (iVar8 != 0)) {
                    *unaff_R13 = iVar8;
                }
                arg_70h._0_4_ = *piVar5;
                *(int32_t *)arg_78h = (int32_t)arg_70h;
                bVar2 = false;
            } else {
                *(int32_t *)arg_78h = *piVar5;
            }
        }
        unaff_R14 = unaff_R14 + 6;
        iVar7 = *unaff_R14;
        arg3 = arg_80h;
    } while( true );
}

// ============================================================
// Function: FUN_1801af9e5
// Address: 0x1801af9e5
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_88h
// WARNING: Variable defined which should be unmapped: arg_48h
// WARNING: Variable defined which should be unmapped: arg_40h
// WARNING: Variable defined which should be unmapped: arg_38h
// WARNING: Variable defined which should be unmapped: arg_30h

int32_t fcn.1801af974(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                     int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h,
                     int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_f8h)
{
    int32_t iVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t *piVar5;
    int64_t unaff_RDI;
    int32_t iVar6;
    int32_t *unaff_R13;
    int32_t *unaff_R14;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_20h;
    
    bVar2 = true;
    iVar6 = 0;
    arg_70h._0_4_ = 0;
    *(undefined4 *)arg2 = 0;
    if (unaff_R13 != (int32_t *)0x0) {
        *(undefined4 *)arg4 = 0;
    }
    iVar7 = *unaff_R14;
    iVar8 = iVar6;
    do {
        if (iVar7 == 0) {
            *(int32_t *)arg3 = (int32_t)arg_70h;
            if ((int32_t)arg_70h == 0) {
                iVar6 = 0xbf;
            }
            return iVar6;
        }
        iVar7 = iVar6;
        if (*(code **)(unaff_R14 + 2) == (code *)0x0) {
code_r0x0001801af9be:
            bVar2 = true;
            iVar8 = iVar7;
        } else {
            piVar5 = (int32_t *)(**(code **)(unaff_R14 + 2))();
            if ((bVar2) && (iVar8 == 0)) {
                iVar8 = *unaff_R14;
            }
            iVar4 = *(int32_t *)(unaff_RDI + 0x9b4);
            iVar1 = *piVar5;
            iVar7 = iVar8;
            if ((iVar4 != 0) && (iVar1 != iVar4)) {
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(unaff_RDI + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                    iVar3 = 1;
                    if (iVar1 < iVar4) {
                        iVar3 = -1;
                    }
                } else {
                    if (iVar4 == 0x100) {
                        iVar4 = 0xff00;
                    }
                    if (iVar1 == 0x100) {
                        iVar1 = 0xff00;
                    }
                    iVar3 = 1;
                    if (iVar4 < iVar1) {
                        iVar3 = -1;
                    }
                }
                if (iVar3 < 0) goto code_r0x0001801af9be;
            }
            iVar4 = func_0x0001801a2690();
            if ((iVar4 == 0) ||
               ((((*(int32_t *)(unaff_RDI + 0x9b8) != 0 && (iVar4 = func_0x0001801afd90(), 0 < iVar4)) ||
                 ((*(uint64_t *)(unaff_RDI + 0x9a8) & *(uint64_t *)(piVar5 + 2)) != 0)) ||
                (((*(uint8_t *)(piVar5 + 1) & 2) != 0 &&
                 ((*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x878) + 0x1c) & 0x30000) != 0))))))
            goto code_r0x0001801af9be;
            if (bVar2) {
                if ((unaff_R13 != (int32_t *)0x0) && (iVar8 != 0)) {
                    *unaff_R13 = iVar8;
                }
                arg_70h._0_4_ = *piVar5;
                *(int32_t *)arg_78h = (int32_t)arg_70h;
                bVar2 = false;
            } else {
                *(int32_t *)arg_78h = *piVar5;
            }
        }
        unaff_R14 = unaff_R14 + 6;
        iVar7 = *unaff_R14;
        arg3 = arg_80h;
    } while( true );
}

// ============================================================
// Function: FUN_1801afa0f
// Address: 0x1801afa0f
// Size: 274 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_88h
// WARNING: Variable defined which should be unmapped: arg_48h
// WARNING: Variable defined which should be unmapped: arg_40h
// WARNING: Variable defined which should be unmapped: arg_38h
// WARNING: Variable defined which should be unmapped: arg_30h

int32_t fcn.1801af974(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                     int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h,
                     int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_f8h)
{
    int32_t iVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t *piVar5;
    int64_t unaff_RDI;
    int32_t iVar6;
    int32_t *unaff_R13;
    int32_t *unaff_R14;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_20h;
    
    bVar2 = true;
    iVar6 = 0;
    arg_70h._0_4_ = 0;
    *(undefined4 *)arg2 = 0;
    if (unaff_R13 != (int32_t *)0x0) {
        *(undefined4 *)arg4 = 0;
    }
    iVar7 = *unaff_R14;
    iVar8 = iVar6;
    do {
        if (iVar7 == 0) {
            *(int32_t *)arg3 = (int32_t)arg_70h;
            if ((int32_t)arg_70h == 0) {
                iVar6 = 0xbf;
            }
            return iVar6;
        }
        iVar7 = iVar6;
        if (*(code **)(unaff_R14 + 2) == (code *)0x0) {
code_r0x0001801af9be:
            bVar2 = true;
            iVar8 = iVar7;
        } else {
            piVar5 = (int32_t *)(**(code **)(unaff_R14 + 2))();
            if ((bVar2) && (iVar8 == 0)) {
                iVar8 = *unaff_R14;
            }
            iVar4 = *(int32_t *)(unaff_RDI + 0x9b4);
            iVar1 = *piVar5;
            iVar7 = iVar8;
            if ((iVar4 != 0) && (iVar1 != iVar4)) {
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(unaff_RDI + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                    iVar3 = 1;
                    if (iVar1 < iVar4) {
                        iVar3 = -1;
                    }
                } else {
                    if (iVar4 == 0x100) {
                        iVar4 = 0xff00;
                    }
                    if (iVar1 == 0x100) {
                        iVar1 = 0xff00;
                    }
                    iVar3 = 1;
                    if (iVar4 < iVar1) {
                        iVar3 = -1;
                    }
                }
                if (iVar3 < 0) goto code_r0x0001801af9be;
            }
            iVar4 = func_0x0001801a2690();
            if ((iVar4 == 0) ||
               ((((*(int32_t *)(unaff_RDI + 0x9b8) != 0 && (iVar4 = func_0x0001801afd90(), 0 < iVar4)) ||
                 ((*(uint64_t *)(unaff_RDI + 0x9a8) & *(uint64_t *)(piVar5 + 2)) != 0)) ||
                (((*(uint8_t *)(piVar5 + 1) & 2) != 0 &&
                 ((*(uint32_t *)(*(int64_t *)(unaff_RDI + 0x878) + 0x1c) & 0x30000) != 0))))))
            goto code_r0x0001801af9be;
            if (bVar2) {
                if ((unaff_R13 != (int32_t *)0x0) && (iVar8 != 0)) {
                    *unaff_R13 = iVar8;
                }
                arg_70h._0_4_ = *piVar5;
                *(int32_t *)arg_78h = (int32_t)arg_70h;
                bVar2 = false;
            } else {
                *(int32_t *)arg_78h = *piVar5;
            }
        }
        unaff_R14 = unaff_R14 + 6;
        iVar7 = *unaff_R14;
        arg3 = arg_80h;
    } while( true );
}

// ============================================================
// Function: FUN_1801afb30
// Address: 0x1801afb30
// Size: 322 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint32_t fcn.1801afb30(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int32_t iVar5;
    int32_t *in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801afb45;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    iVar3 = *in_RDX;
    iVar2 = *(int32_t *)(in_RCX + 0x9b4);
    if ((iVar2 != 0) && (iVar3 != iVar2)) {
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
            iVar5 = 1;
            if (iVar3 < iVar2) {
                iVar5 = -1;
            }
        } else {
            if (iVar2 == 0x100) {
                iVar2 = 0xff00;
            }
            iVar1 = iVar3;
            if (iVar3 == 0x100) {
                iVar1 = 0xff00;
            }
            iVar5 = 1;
            if (iVar2 < iVar1) {
                iVar5 = -1;
            }
        }
        if (iVar5 < 0) {
            return 0x18c;
        }
    }
    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801afbc7;
    iVar2 = func_0x0001801a2690(in_RCX, 9, 0, iVar3);
    if (iVar2 == 0) {
        return 0x18c;
    }
    if (*(int32_t *)(in_RCX + 0x9b8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801afbf6;
        iVar3 = func_0x0001801afd90(in_RCX, iVar3);
        if (0 < iVar3) {
            return 0xa6;
        }
    }
    if ((*(uint64_t *)(in_RDX + 2) & *(uint64_t *)(in_RCX + 0x9a8)) != 0) {
        return 0x102;
    }
    if ((*(uint8_t *)(in_RDX + 1) & 2) != 0) {
        return -(uint32_t)((*(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c) & 0x30000) != 0) & 0x9e;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801afc80
// Address: 0x1801afc80
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801afc80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    int32_t iVar3;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801afc90;
    iVar1 = func_0x00018045a350();
    iVar1 = -iVar1;
    if ((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801afcbc;
        uVar2 = func_0x0001801af910();
        if ((int32_t)uVar2 != 0) {
            return uVar2;
        }
        iVar3 = *(int32_t *)((int64_t)&arg_28h + iVar1);
        *(int32_t *)(in_RCX + 0x48) = iVar3;
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
            if (0x303 < iVar3) {
                iVar3 = 0x303;
            }
        } else if (iVar3 == 0x100) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801afcea;
            uVar2 = func_0x0001801a5230(in_RCX, 0x100);
            if ((int32_t)uVar2 == 0) {
                return uVar2;
            }
        }
        *(int32_t *)(in_RCX + 0x9cc) = iVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801afde0
// Address: 0x1801afde0
// Size: 207 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801afde0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    int32_t iVar8;
    undefined8 *in_R8;
    int64_t iVar9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801afdfd;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    iVar3 = **(int32_t **)(in_RCX + 0x18);
    if (iVar3 == 0x10000) {
        iVar3 = 0x304;
        iVar9 = 0x1804af420;
    } else {
        if (iVar3 != 0x1ffff) {
            iVar3 = *(int32_t *)(in_RCX + 0x48);
            if (in_EDX == iVar3) {
                return true;
            }
            if ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) {
                if (iVar3 == 0x100) {
                    iVar3 = 0xff00;
                }
                if (in_EDX == 0x100) {
                    in_EDX = 0xff00;
                }
                iVar8 = 1;
                if (iVar3 < in_EDX) {
                    iVar8 = -1;
                }
                return iVar8 == 0;
            }
            iVar8 = 1;
            if (in_EDX < iVar3) {
                iVar8 = -1;
            }
            return iVar8 == 0;
        }
        iVar3 = 0xfefd;
        iVar9 = 0x1804af4b0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
    do {
        if (in_EDX != iVar3) {
            iVar8 = 1;
            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                if (in_EDX < iVar3) {
                    iVar8 = -1;
                }
            } else {
                iVar7 = iVar3;
                if (iVar3 == 0x100) {
                    iVar7 = 0xff00;
                }
                iVar2 = in_EDX;
                if (in_EDX == 0x100) {
                    iVar2 = 0xff00;
                }
                iVar8 = 1;
                if (iVar7 < iVar2) {
                    iVar8 = -1;
                }
            }
            if (0 < iVar8) {
                return false;
            }
        }
        iVar5 = 0x10;
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            iVar5 = 8;
        }
        pcVar1 = *(code **)(iVar5 + iVar9);
        if ((pcVar1 != (code *)0x0) && (in_EDX == iVar3)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff25;
            (*pcVar1)();
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff30;
            iVar3 = fcn.1801afb30(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            if (iVar3 == 0) {
                if ((*(int32_t *)(in_RCX + 0x78) == 0) || (in_EDX != 0x304)) {
code_r0x0001801aff82:
                    if (in_R8 != (undefined8 *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff89;
                        uVar6 = (*pcVar1)();
                        *in_R8 = uVar6;
                    }
                    return true;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff49;
                iVar3 = func_0x0001801ae690(in_RCX);
                if (iVar3 != 0) goto code_r0x0001801aff82;
            }
        }
        iVar3 = *(int32_t *)(iVar9 + 0x18);
        iVar9 = iVar9 + 0x18;
        if (iVar3 == 0) {
            return false;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801afeaf
// Address: 0x1801afeaf
// Size: 187 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801afde0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    int32_t iVar8;
    undefined8 *in_R8;
    int64_t iVar9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801afdfd;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    iVar3 = **(int32_t **)(in_RCX + 0x18);
    if (iVar3 == 0x10000) {
        iVar3 = 0x304;
        iVar9 = 0x1804af420;
    } else {
        if (iVar3 != 0x1ffff) {
            iVar3 = *(int32_t *)(in_RCX + 0x48);
            if (in_EDX == iVar3) {
                return true;
            }
            if ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) {
                if (iVar3 == 0x100) {
                    iVar3 = 0xff00;
                }
                if (in_EDX == 0x100) {
                    in_EDX = 0xff00;
                }
                iVar8 = 1;
                if (iVar3 < in_EDX) {
                    iVar8 = -1;
                }
                return iVar8 == 0;
            }
            iVar8 = 1;
            if (in_EDX < iVar3) {
                iVar8 = -1;
            }
            return iVar8 == 0;
        }
        iVar3 = 0xfefd;
        iVar9 = 0x1804af4b0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
    do {
        if (in_EDX != iVar3) {
            iVar8 = 1;
            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                if (in_EDX < iVar3) {
                    iVar8 = -1;
                }
            } else {
                iVar7 = iVar3;
                if (iVar3 == 0x100) {
                    iVar7 = 0xff00;
                }
                iVar2 = in_EDX;
                if (in_EDX == 0x100) {
                    iVar2 = 0xff00;
                }
                iVar8 = 1;
                if (iVar7 < iVar2) {
                    iVar8 = -1;
                }
            }
            if (0 < iVar8) {
                return false;
            }
        }
        iVar5 = 0x10;
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            iVar5 = 8;
        }
        pcVar1 = *(code **)(iVar5 + iVar9);
        if ((pcVar1 != (code *)0x0) && (in_EDX == iVar3)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff25;
            (*pcVar1)();
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff30;
            iVar3 = fcn.1801afb30(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            if (iVar3 == 0) {
                if ((*(int32_t *)(in_RCX + 0x78) == 0) || (in_EDX != 0x304)) {
code_r0x0001801aff82:
                    if (in_R8 != (undefined8 *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff89;
                        uVar6 = (*pcVar1)();
                        *in_R8 = uVar6;
                    }
                    return true;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff49;
                iVar3 = func_0x0001801ae690(in_RCX);
                if (iVar3 != 0) goto code_r0x0001801aff82;
            }
        }
        iVar3 = *(int32_t *)(iVar9 + 0x18);
        iVar9 = iVar9 + 0x18;
        if (iVar3 == 0) {
            return false;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801aff6a
// Address: 0x1801aff6a
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801afde0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    int32_t iVar8;
    undefined8 *in_R8;
    int64_t iVar9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801afdfd;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    iVar3 = **(int32_t **)(in_RCX + 0x18);
    if (iVar3 == 0x10000) {
        iVar3 = 0x304;
        iVar9 = 0x1804af420;
    } else {
        if (iVar3 != 0x1ffff) {
            iVar3 = *(int32_t *)(in_RCX + 0x48);
            if (in_EDX == iVar3) {
                return true;
            }
            if ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) {
                if (iVar3 == 0x100) {
                    iVar3 = 0xff00;
                }
                if (in_EDX == 0x100) {
                    in_EDX = 0xff00;
                }
                iVar8 = 1;
                if (iVar3 < in_EDX) {
                    iVar8 = -1;
                }
                return iVar8 == 0;
            }
            iVar8 = 1;
            if (in_EDX < iVar3) {
                iVar8 = -1;
            }
            return iVar8 == 0;
        }
        iVar3 = 0xfefd;
        iVar9 = 0x1804af4b0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
    do {
        if (in_EDX != iVar3) {
            iVar8 = 1;
            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                if (in_EDX < iVar3) {
                    iVar8 = -1;
                }
            } else {
                iVar7 = iVar3;
                if (iVar3 == 0x100) {
                    iVar7 = 0xff00;
                }
                iVar2 = in_EDX;
                if (in_EDX == 0x100) {
                    iVar2 = 0xff00;
                }
                iVar8 = 1;
                if (iVar7 < iVar2) {
                    iVar8 = -1;
                }
            }
            if (0 < iVar8) {
                return false;
            }
        }
        iVar5 = 0x10;
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            iVar5 = 8;
        }
        pcVar1 = *(code **)(iVar5 + iVar9);
        if ((pcVar1 != (code *)0x0) && (in_EDX == iVar3)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff25;
            (*pcVar1)();
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff30;
            iVar3 = fcn.1801afb30(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            if (iVar3 == 0) {
                if ((*(int32_t *)(in_RCX + 0x78) == 0) || (in_EDX != 0x304)) {
code_r0x0001801aff82:
                    if (in_R8 != (undefined8 *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff89;
                        uVar6 = (*pcVar1)();
                        *in_R8 = uVar6;
                    }
                    return true;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff49;
                iVar3 = func_0x0001801ae690(in_RCX);
                if (iVar3 != 0) goto code_r0x0001801aff82;
            }
        }
        iVar3 = *(int32_t *)(iVar9 + 0x18);
        iVar9 = iVar9 + 0x18;
        if (iVar3 == 0) {
            return false;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801aff82
// Address: 0x1801aff82
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801afde0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    int32_t iVar8;
    undefined8 *in_R8;
    int64_t iVar9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801afdfd;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    iVar3 = **(int32_t **)(in_RCX + 0x18);
    if (iVar3 == 0x10000) {
        iVar3 = 0x304;
        iVar9 = 0x1804af420;
    } else {
        if (iVar3 != 0x1ffff) {
            iVar3 = *(int32_t *)(in_RCX + 0x48);
            if (in_EDX == iVar3) {
                return true;
            }
            if ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) {
                if (iVar3 == 0x100) {
                    iVar3 = 0xff00;
                }
                if (in_EDX == 0x100) {
                    in_EDX = 0xff00;
                }
                iVar8 = 1;
                if (iVar3 < in_EDX) {
                    iVar8 = -1;
                }
                return iVar8 == 0;
            }
            iVar8 = 1;
            if (in_EDX < iVar3) {
                iVar8 = -1;
            }
            return iVar8 == 0;
        }
        iVar3 = 0xfefd;
        iVar9 = 0x1804af4b0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
    do {
        if (in_EDX != iVar3) {
            iVar8 = 1;
            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                if (in_EDX < iVar3) {
                    iVar8 = -1;
                }
            } else {
                iVar7 = iVar3;
                if (iVar3 == 0x100) {
                    iVar7 = 0xff00;
                }
                iVar2 = in_EDX;
                if (in_EDX == 0x100) {
                    iVar2 = 0xff00;
                }
                iVar8 = 1;
                if (iVar7 < iVar2) {
                    iVar8 = -1;
                }
            }
            if (0 < iVar8) {
                return false;
            }
        }
        iVar5 = 0x10;
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            iVar5 = 8;
        }
        pcVar1 = *(code **)(iVar5 + iVar9);
        if ((pcVar1 != (code *)0x0) && (in_EDX == iVar3)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff25;
            (*pcVar1)();
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff30;
            iVar3 = fcn.1801afb30(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            if (iVar3 == 0) {
                if ((*(int32_t *)(in_RCX + 0x78) == 0) || (in_EDX != 0x304)) {
code_r0x0001801aff82:
                    if (in_R8 != (undefined8 *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff89;
                        uVar6 = (*pcVar1)();
                        *in_R8 = uVar6;
                    }
                    return true;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801aff49;
                iVar3 = func_0x0001801ae690(in_RCX);
                if (iVar3 != 0) goto code_r0x0001801aff82;
            }
        }
        iVar3 = *(int32_t *)(iVar9 + 0x18);
        iVar9 = iVar9 + 0x18;
        if (iVar3 == 0) {
            return false;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801affd0
// Address: 0x1801affd0
// Size: 175 bytes
// ============================================================
undefined8 fcn.1801affd0(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801affdc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(param_1 + 0xbc8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801afff3;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b000b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b0021;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b0035;
    iVar1 = fcn.180214b00(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b003e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b0056;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b006c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801b0080
// Address: 0x1801b0080
// Size: 234 bytes
// ============================================================
undefined8 fcn.1801b0080(int64_t param_1)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b008c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(param_1 + 0xbc8) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801b00aa;
    iVar2 = fcn.1801da790(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801b00b3;
        iVar4 = fcn.180215470();
        *(int64_t *)(param_1 + 0xbc8) = iVar4;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801b0109;
            iVar2 = fcn.180214b00(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000028 + iVar3)
                                  , *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
            if (iVar2 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801b0112;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801b012a;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801b0140;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
            uVar1 = *(undefined8 *)(param_1 + 0xbc8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801b014c;
            fcn.180215310(uVar1);
            *(undefined8 *)(param_1 + 0xbc8) = 0;
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801b00c4;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801b00dc;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801b00f2;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
    }
    return 0;
}

// ============================================================
// Function: FUN_1801b0170
// Address: 0x1801b0170
// Size: 125 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801b0170(int64_t arg_28h, int64_t arg_40h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b0180;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8D != 0x101) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b019a;
        iVar1 = func_0x000180244000(in_RDX);
        if (iVar1 == 0) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b01ab;
    iVar1 = func_0x0001802442b0(in_RDX, (int64_t)&arg_40h + iVar2);
    if ((iVar1 != 0) && (*(uint64_t *)((int64_t)&arg_40h + iVar2) < 0x80000000)) {
        *(int64_t *)(in_RCX + 0x108) = (int64_t)(int32_t)*(uint64_t *)((int64_t)&arg_40h + iVar2);
        *(undefined8 *)(in_RCX + 0x110) = 0;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801b01f0
// Address: 0x1801b01f0
// Size: 989 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801b01f0(int64_t arg_28h, int64_t arg_38h, int64_t arg_148h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar12;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t iVar14;
    
    uStack_40 = 0x1801b020f;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar10 = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar9);
    iVar3 = *(int64_t *)(in_RCX + 0x3d0);
    iVar14 = 0;
    iVar13 = 0;
    puVar4 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar9) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
    iVar12 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar9) = 0;
    if ((iVar3 == 0) || (*(int64_t *)(in_RCX + 0x3d8) == 0)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0559;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
code_r0x0001801b055e:
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0571;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                      *(int64_t *)((int64_t)&var_18h + iVar9));
code_r0x0001801b0577:
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0587;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar9));
    } else {
        iVar5 = *(int64_t *)(*(int64_t *)(in_RCX + 0x3d8) + 8);
        if (iVar5 == 0) {
code_r0x0001801b0548:
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b054d;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                         );
            goto code_r0x0001801b055e;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b027f;
        iVar8 = func_0x0001801ab730(puVar4, iVar3, (int64_t)&arg_28h + iVar9);
        if (iVar8 == 0) goto code_r0x0001801b0548;
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b028c;
        iVar12 = fcn.180215470();
        if (iVar12 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0299;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                         );
            iVar13 = iVar14;
code_r0x0001801b029e:
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b02b1;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_18h + iVar9));
            iVar14 = iVar13;
            goto code_r0x0001801b0577;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b02d3;
        iVar8 = func_0x0001801ae510(in_RCX, (int64_t)&arg_38h + iVar9, (int64_t)&var_20h + iVar9, 
                                    (int64_t)&var_18h + iVar9);
        if (iVar8 != 0) {
            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) != 0) {
                uVar1 = *(undefined2 *)(iVar3 + 0x10);
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b02ff;
                iVar8 = func_0x0001802446f0(in_RDX, uVar1, 2);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0308;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                    goto code_r0x0001801b055e;
                }
            }
            iVar11 = iVar14;
            if (*(int64_t *)((int64_t)&arg_28h + iVar9) != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0326;
                iVar11 = func_0x00018020f750();
            }
            uVar6 = puVar4[0x8c];
            uVar7 = *puVar4;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9) = 0;
            *(int64_t *)(&stack0xfffffffffffffff0 + iVar9) = iVar5;
            *(undefined8 *)(&stack0xffffffffffffffe8 + iVar9) = uVar6;
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0351;
            iVar8 = func_0x00018025c2e0(iVar12, (int64_t)&var_10h + iVar9, iVar11, uVar7);
            if (iVar8 < 1) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b035a;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                iVar13 = iVar14;
            } else if (*(int32_t *)(iVar3 + 0x1c) == 0x390) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b037d;
                iVar8 = func_0x00018025dd20(*(undefined8 *)((int64_t)&var_10h + iVar9), 6);
                if (0 < iVar8) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0390;
                    iVar8 = func_0x00018025de80(*(undefined8 *)((int64_t)&var_10h + iVar9), 0xffffffff);
                    if (0 < iVar8) goto code_r0x0001801b03a3;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0399;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                iVar13 = iVar14;
            } else {
code_r0x0001801b03a3:
                if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b03c2;
                    iVar8 = func_0x00018025c340(iVar12, *(undefined8 *)((int64_t)&var_20h + iVar9), 
                                                *(undefined8 *)((int64_t)&var_18h + iVar9));
                    if (0 < iVar8) {
                        iVar14 = *(int64_t *)(in_RCX + 0x8f8);
                        uVar2 = *(undefined4 *)(iVar14 + 8);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b03e2;
                        iVar8 = func_0x000180215040(iVar12, 0x1d, uVar2, iVar14 + 0x50);
                        if (0 < iVar8) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b03f5;
                            iVar8 = func_0x00018025be60(iVar12, 0, (int64_t)&var_8h + iVar9);
                            if (0 < iVar8) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0410;
                                iVar13 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                       *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                if (iVar13 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0428;
                                    iVar8 = func_0x00018025be60(iVar12, iVar13, (int64_t)&var_8h + iVar9);
                                    if (0 < iVar8) goto code_r0x0001801b04bd;
                                }
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0435;
                                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                goto code_r0x0001801b029e;
                            }
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0444;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                } else {
                    uVar6 = *(undefined8 *)((int64_t)&var_18h + iVar9);
                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar9) = uVar6;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0469;
                    iVar8 = func_0x00018025bc60(iVar12, 0, (int64_t)&var_8h + iVar9, 
                                                *(undefined8 *)((int64_t)&var_20h + iVar9));
                    if (iVar8 < 1) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0472;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                    } else {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0493;
                        iVar13 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                               *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                        if (iVar13 != 0) {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + iVar9) = uVar6;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b04b9;
                            iVar8 = func_0x00018025bc60(iVar12, iVar13, (int64_t)&var_8h + iVar9, 
                                                        *(undefined8 *)((int64_t)&var_20h + iVar9));
                            if (0 < iVar8) {
code_r0x0001801b04bd:
                                if ((*(int32_t *)(iVar3 + 0x1c) == 0x32b) || (*(int32_t *)(iVar3 + 0x1c) - 0x3d3U < 2))
                                {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b04e1;
                                    func_0x000180226680(iVar13, 0, *(undefined8 *)((int64_t)&var_8h + iVar9));
                                }
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b04f7;
                                iVar8 = func_0x000180244bf0(in_RDX, iVar13, *(undefined8 *)((int64_t)&var_8h + iVar9), 2
                                                           );
                                iVar14 = iVar13;
                                if (iVar8 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0500;
                                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                    goto code_r0x0001801b055e;
                                }
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0511;
                                iVar8 = fcn.1801da790(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                                      *(int64_t *)(&stack0x00000000 + iVar9));
                                if (iVar8 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b052a;
                                    fcn.180224990(iVar13, 0x1804af528, 0x1ab);
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b0532;
                                    fcn.180215310(iVar12);
                                    goto code_r0x0001801b05a6;
                                }
                                goto code_r0x0001801b0587;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b053e;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                    }
                }
            }
            goto code_r0x0001801b029e;
        }
    }
code_r0x0001801b0587:
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b059c;
    fcn.180224990(iVar14, 0x1804af528, 0x1af);
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b05a4;
    fcn.180215310(iVar12);
code_r0x0001801b05a6:
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b05b2;
    func_0x000180459870(uVar10 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801b05d0
// Address: 0x1801b05d0
// Size: 111 bytes
// ============================================================
undefined8 fcn.1801b05d0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b05dc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b05f5;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b05fe;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b0616;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b062c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801b0640
// Address: 0x1801b0640
// Size: 495 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801b0640(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t *piVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 uVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar9;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b0650;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar5 = *(int32_t *)(in_RCX + 0x78);
    if ((iVar5 == 0) && (*(int32_t *)(in_RCX + 0xba8) != 4)) {
        *(undefined4 *)(in_RCX + 0xc0) = 1;
    }
    piVar2 = *(int32_t **)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RDI;
    iVar3 = *(int64_t *)(piVar2 + 0x36);
    if (((((((*(uint8_t *)(iVar3 + 0x50) & 8) == 0) && (iVar1 = *piVar2, 0x303 < iVar1)) && (iVar1 != 0x10000)) &&
         ((iVar5 == 0 && ((*(uint32_t *)(in_RCX + 0x160) & 0x2000) == 0)))) &&
        ((*(int32_t *)(in_RCX + 0xf0) != 0 || ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x14 & 1) != 0)))) &&
       (*(int32_t *)(in_RCX + 0x340) == 0)) {
        pcVar4 = *(code **)(iVar3 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801b06dc;
        iVar5 = (*pcVar4)(in_RCX, 0x92);
        if (iVar5 == 0) {
            return 0;
        }
    }
    iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        uVar8 = *(undefined8 *)(iVar3 + 0x20);
        uVar9 = *(undefined8 *)(iVar3 + 0x28);
    } else {
        uVar8 = *(undefined8 *)(iVar3 + 0x30);
        uVar9 = *(undefined8 *)(iVar3 + 0x38);
    }
    pcVar4 = *(code **)(iVar3 + 0x18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801b0717;
    uVar7 = (*pcVar4)(in_RCX, uVar8, uVar9, in_RCX + 0x1e0);
    if (uVar7 != 0) {
        *(uint64_t *)(in_RCX + 0x260) = uVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801b0738;
        iVar5 = func_0x0001802445f0(in_RDX, in_RCX + 0x1e0, uVar7);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801b0741;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        } else {
            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) {
                iVar3 = *(int64_t *)(in_RCX + 0x8f8);
                uVar8 = *(undefined8 *)(iVar3 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801b07c5;
                iVar5 = func_0x000180197b70(in_RCX, 0x1804af690, iVar3 + 0x50, uVar8);
                if (iVar5 == 0) {
                    return 0;
                }
            }
            if (uVar7 < 0x41) {
                if (*(int32_t *)(in_RCX + 0x78) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801b081e;
                    fcn.180498030(in_RCX + 0x468, in_RCX + 0x1e0, uVar7);
                    *(uint64_t *)(in_RCX + 0x4a8) = uVar7;
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801b0801;
                fcn.180498030(in_RCX + 0x420, in_RCX + 0x1e0, uVar7);
                *(uint64_t *)(in_RCX + 0x460) = uVar7;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801b07d4;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801b0759;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801b076f;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    }
    return 0;
}

// ============================================================
// Function: FUN_1801b0830
// Address: 0x1801b0830
// Size: 126 bytes
// ============================================================
undefined8 fcn.1801b0830(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b083c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b085a;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b0863;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b087b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b0891;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined4 *)(param_1 + 0xba4) = 0xffffffff;
    return 1;
}

// ============================================================
// Function: FUN_1801b08b0
// Address: 0x1801b08b0
// Size: 190 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1801b08b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    code *pcVar9;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    int32_t in_R9D;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801b08cd;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar8 = *(undefined8 *)(in_RCX + 0x40);
    iVar1 = *(int32_t *)(in_RCX + 0xc0);
    iVar2 = *(int64_t *)(in_RCX + 8);
    if (in_R8D != 0) {
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0xf8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b090c;
            func_0x000180226310(uVar3);
            *(undefined8 *)(in_RCX + 0xf8) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b091b;
        iVar6 = func_0x000180197630(in_RCX);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0924;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b093c;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7));
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0952;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar7));
            return 0;
        }
        *(undefined8 *)(in_RCX + 0x108) = 0;
    }
    piVar4 = *(int32_t **)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RDI;
    if (((((*(uint8_t *)(*(int64_t *)(piVar4 + 0x36) + 0x50) & 8) == 0) && (iVar6 = *piVar4, 0x303 < iVar6)) &&
        (iVar6 != 0x10000)) && ((*(int32_t *)(in_RCX + 0x78) == 0 && (*(int32_t *)(in_RCX + 0xba8) == 4)))) {
        *(undefined4 *)(in_RCX + 0xba8) = 1;
    }
    if (iVar1 != 0) {
        *(undefined4 *)(in_RCX + 0xba0) = 0;
        *(undefined4 *)(in_RCX + 0x7c) = 0;
        *(undefined4 *)(in_RCX + 0xc0) = 0;
        *(undefined4 *)(in_RCX + 0xa60) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b09ea;
        func_0x0001801da740(in_RCX);
        piVar4 = *(int32_t **)(in_RCX + 0x18);
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            if ((((*(uint8_t *)(*(int64_t *)(piVar4 + 0x36) + 0x50) & 8) == 0) && (0x303 < *piVar4)) &&
               (*piVar4 != 0x10000)) {
                iVar5 = *(int64_t *)(in_RCX + 0xb88);
                if ((*(uint8_t *)(iVar5 + 0x50) & 1) != 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 0x8f8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0a64;
                    func_0x00018019c8a0(iVar5, uVar3);
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0a73;
                func_0x000180198390(in_RCX, 1);
            }
            if (*(int32_t *)(in_RCX + 0x508) != 0) {
                LOCK();
                piVar4 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x9c);
                *piVar4 = *piVar4 + 1;
                UNLOCK();
            }
            *(undefined8 *)(in_RCX + 0x70) = 0x18019b570;
            LOCK();
            piVar4 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x80);
            *piVar4 = *piVar4 + 1;
            UNLOCK();
        } else {
            if ((((*(uint8_t *)(*(int64_t *)(piVar4 + 0x36) + 0x50) & 8) != 0) || (*piVar4 < 0x304)) ||
               (*piVar4 == 0x10000)) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0a1c;
                func_0x000180198390(in_RCX, 2);
            }
            LOCK();
            piVar4 = (int32_t *)(iVar2 + 0x8c);
            *piVar4 = *piVar4 + 1;
            UNLOCK();
            *(undefined8 *)(in_RCX + 0x70) = 0x18019b330;
        }
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) {
            *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x110) = 0;
            *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x10c) = 0;
            *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x10e) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0ae8;
            func_0x0001801c2610(in_RCX);
        }
    }
    pcVar9 = *(code **)(in_RCX + 0x958);
    if ((pcVar9 == (code *)0x0) && (pcVar9 = *(code **)(iVar2 + 0x120), pcVar9 == (code *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0b5d;
        func_0x00018019b750(in_RCX, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0b0a;
        func_0x00018019b750(in_RCX, 0);
        if ((((iVar1 != 0) ||
             (((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
              (iVar1 = **(int32_t **)(in_RCX + 0x18), iVar1 < 0x304)))) || (iVar1 == 0x10000)) ||
           ((*(int64_t *)(in_RCX + 0x260) == 0 || (*(int64_t *)(in_RCX + 0x2e8) == 0)))) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0b51;
            (*pcVar9)(uVar8, 0x20, 1);
        }
    }
    if (in_R9D == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0b74;
        func_0x00018019b750(in_RCX, 1);
        uVar8 = 2;
    } else {
        uVar8 = 1;
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1801b096e
// Address: 0x1801b096e
// Size: 505 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1801b08b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    code *pcVar9;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    int32_t in_R9D;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801b08cd;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar8 = *(undefined8 *)(in_RCX + 0x40);
    iVar1 = *(int32_t *)(in_RCX + 0xc0);
    iVar2 = *(int64_t *)(in_RCX + 8);
    if (in_R8D != 0) {
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0xf8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b090c;
            func_0x000180226310(uVar3);
            *(undefined8 *)(in_RCX + 0xf8) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b091b;
        iVar6 = func_0x000180197630(in_RCX);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0924;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b093c;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7));
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0952;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar7));
            return 0;
        }
        *(undefined8 *)(in_RCX + 0x108) = 0;
    }
    piVar4 = *(int32_t **)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RDI;
    if (((((*(uint8_t *)(*(int64_t *)(piVar4 + 0x36) + 0x50) & 8) == 0) && (iVar6 = *piVar4, 0x303 < iVar6)) &&
        (iVar6 != 0x10000)) && ((*(int32_t *)(in_RCX + 0x78) == 0 && (*(int32_t *)(in_RCX + 0xba8) == 4)))) {
        *(undefined4 *)(in_RCX + 0xba8) = 1;
    }
    if (iVar1 != 0) {
        *(undefined4 *)(in_RCX + 0xba0) = 0;
        *(undefined4 *)(in_RCX + 0x7c) = 0;
        *(undefined4 *)(in_RCX + 0xc0) = 0;
        *(undefined4 *)(in_RCX + 0xa60) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b09ea;
        func_0x0001801da740(in_RCX);
        piVar4 = *(int32_t **)(in_RCX + 0x18);
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            if ((((*(uint8_t *)(*(int64_t *)(piVar4 + 0x36) + 0x50) & 8) == 0) && (0x303 < *piVar4)) &&
               (*piVar4 != 0x10000)) {
                iVar5 = *(int64_t *)(in_RCX + 0xb88);
                if ((*(uint8_t *)(iVar5 + 0x50) & 1) != 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 0x8f8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0a64;
                    func_0x00018019c8a0(iVar5, uVar3);
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0a73;
                func_0x000180198390(in_RCX, 1);
            }
            if (*(int32_t *)(in_RCX + 0x508) != 0) {
                LOCK();
                piVar4 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x9c);
                *piVar4 = *piVar4 + 1;
                UNLOCK();
            }
            *(undefined8 *)(in_RCX + 0x70) = 0x18019b570;
            LOCK();
            piVar4 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x80);
            *piVar4 = *piVar4 + 1;
            UNLOCK();
        } else {
            if ((((*(uint8_t *)(*(int64_t *)(piVar4 + 0x36) + 0x50) & 8) != 0) || (*piVar4 < 0x304)) ||
               (*piVar4 == 0x10000)) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0a1c;
                func_0x000180198390(in_RCX, 2);
            }
            LOCK();
            piVar4 = (int32_t *)(iVar2 + 0x8c);
            *piVar4 = *piVar4 + 1;
            UNLOCK();
            *(undefined8 *)(in_RCX + 0x70) = 0x18019b330;
        }
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) {
            *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x110) = 0;
            *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x10c) = 0;
            *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x10e) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0ae8;
            func_0x0001801c2610(in_RCX);
        }
    }
    pcVar9 = *(code **)(in_RCX + 0x958);
    if ((pcVar9 == (code *)0x0) && (pcVar9 = *(code **)(iVar2 + 0x120), pcVar9 == (code *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0b5d;
        func_0x00018019b750(in_RCX, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0b0a;
        func_0x00018019b750(in_RCX, 0);
        if ((((iVar1 != 0) ||
             (((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
              (iVar1 = **(int32_t **)(in_RCX + 0x18), iVar1 < 0x304)))) || (iVar1 == 0x10000)) ||
           ((*(int64_t *)(in_RCX + 0x260) == 0 || (*(int64_t *)(in_RCX + 0x2e8) == 0)))) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0b51;
            (*pcVar9)(uVar8, 0x20, 1);
        }
    }
    if (in_R9D == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0b74;
        func_0x00018019b750(in_RCX, 1);
        uVar8 = 2;
    } else {
        uVar8 = 1;
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1801b0b67
// Address: 0x1801b0b67
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1801b08b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    code *pcVar9;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    int32_t in_R9D;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801b08cd;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar8 = *(undefined8 *)(in_RCX + 0x40);
    iVar1 = *(int32_t *)(in_RCX + 0xc0);
    iVar2 = *(int64_t *)(in_RCX + 8);
    if (in_R8D != 0) {
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0xf8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b090c;
            func_0x000180226310(uVar3);
            *(undefined8 *)(in_RCX + 0xf8) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b091b;
        iVar6 = func_0x000180197630(in_RCX);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0924;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b093c;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7));
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0952;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar7));
            return 0;
        }
        *(undefined8 *)(in_RCX + 0x108) = 0;
    }
    piVar4 = *(int32_t **)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RDI;
    if (((((*(uint8_t *)(*(int64_t *)(piVar4 + 0x36) + 0x50) & 8) == 0) && (iVar6 = *piVar4, 0x303 < iVar6)) &&
        (iVar6 != 0x10000)) && ((*(int32_t *)(in_RCX + 0x78) == 0 && (*(int32_t *)(in_RCX + 0xba8) == 4)))) {
        *(undefined4 *)(in_RCX + 0xba8) = 1;
    }
    if (iVar1 != 0) {
        *(undefined4 *)(in_RCX + 0xba0) = 0;
        *(undefined4 *)(in_RCX + 0x7c) = 0;
        *(undefined4 *)(in_RCX + 0xc0) = 0;
        *(undefined4 *)(in_RCX + 0xa60) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b09ea;
        func_0x0001801da740(in_RCX);
        piVar4 = *(int32_t **)(in_RCX + 0x18);
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            if ((((*(uint8_t *)(*(int64_t *)(piVar4 + 0x36) + 0x50) & 8) == 0) && (0x303 < *piVar4)) &&
               (*piVar4 != 0x10000)) {
                iVar5 = *(int64_t *)(in_RCX + 0xb88);
                if ((*(uint8_t *)(iVar5 + 0x50) & 1) != 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 0x8f8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0a64;
                    func_0x00018019c8a0(iVar5, uVar3);
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0a73;
                func_0x000180198390(in_RCX, 1);
            }
            if (*(int32_t *)(in_RCX + 0x508) != 0) {
                LOCK();
                piVar4 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x9c);
                *piVar4 = *piVar4 + 1;
                UNLOCK();
            }
            *(undefined8 *)(in_RCX + 0x70) = 0x18019b570;
            LOCK();
            piVar4 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x80);
            *piVar4 = *piVar4 + 1;
            UNLOCK();
        } else {
            if ((((*(uint8_t *)(*(int64_t *)(piVar4 + 0x36) + 0x50) & 8) != 0) || (*piVar4 < 0x304)) ||
               (*piVar4 == 0x10000)) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0a1c;
                func_0x000180198390(in_RCX, 2);
            }
            LOCK();
            piVar4 = (int32_t *)(iVar2 + 0x8c);
            *piVar4 = *piVar4 + 1;
            UNLOCK();
            *(undefined8 *)(in_RCX + 0x70) = 0x18019b330;
        }
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) {
            *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x110) = 0;
            *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x10c) = 0;
            *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x10e) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0ae8;
            func_0x0001801c2610(in_RCX);
        }
    }
    pcVar9 = *(code **)(in_RCX + 0x958);
    if ((pcVar9 == (code *)0x0) && (pcVar9 = *(code **)(iVar2 + 0x120), pcVar9 == (code *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0b5d;
        func_0x00018019b750(in_RCX, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0b0a;
        func_0x00018019b750(in_RCX, 0);
        if ((((iVar1 != 0) ||
             (((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
              (iVar1 = **(int32_t **)(in_RCX + 0x18), iVar1 < 0x304)))) || (iVar1 == 0x10000)) ||
           ((*(int64_t *)(in_RCX + 0x260) == 0 || (*(int64_t *)(in_RCX + 0x2e8) == 0)))) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0b51;
            (*pcVar9)(uVar8, 0x20, 1);
        }
    }
    if (in_R9D == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0b74;
        func_0x00018019b750(in_RCX, 1);
        uVar8 = 2;
    } else {
        uVar8 = 1;
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1801b0ba0
// Address: 0x1801b0ba0
// Size: 686 bytes
// ============================================================
undefined8 fcn.1801b0ba0(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined4 uVar8;
    uint64_t *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    code *pcVar12;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801b0bb1;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar1 = (int64_t *)(in_RCX + 0x108);
    uVar7 = *(undefined8 *)(in_RCX + 0x40);
    if (*(int32_t *)(in_RCX + 0x2f8) == 0x101) {
        *in_RDX = (uint64_t)*(uint32_t *)piVar1;
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RBP;
    iVar6 = *(int64_t *)(in_RCX + 0x100);
    iVar2 = *piVar1;
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_RSI;
    iVar9 = *(int64_t *)(in_RCX + 0x2f0);
    *(undefined8 *)((int64_t)&arg_68h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_R14;
    for (iVar9 = iVar9 - iVar2; iVar9 != 0; iVar9 = iVar9 - iVar3) {
        pcVar12 = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0x80);
        *(int64_t *)((int64_t)&var_10h + iVar5) = (int64_t)&arg_50h + iVar5;
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
        *(int64_t *)(&stack0x00000000 + iVar5) = iVar9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801b0c4e;
        iVar4 = (*pcVar12)(in_RCX, 0x16, 0, iVar2 + iVar6);
        if (iVar4 < 1) {
            *(undefined4 *)(in_RCX + 0x68) = 3;
            goto code_r0x0001801b0ca5;
        }
        iVar3 = *(int64_t *)((int64_t)&arg_50h + iVar5);
        *piVar1 = *piVar1 + iVar3;
        iVar2 = *piVar1;
    }
    if (**(char **)(*(int64_t *)(in_RCX + 0xf8) + 8) == '\x14') {
        iVar6 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            uVar11 = *(undefined8 *)(iVar6 + 0x30);
            uVar10 = *(undefined8 *)(iVar6 + 0x38);
        } else {
            uVar11 = *(undefined8 *)(iVar6 + 0x20);
            uVar10 = *(undefined8 *)(iVar6 + 0x28);
        }
        pcVar12 = *(code **)(iVar6 + 0x18);
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801b0cc7;
        iVar6 = (*pcVar12)(in_RCX, uVar11, uVar10, in_RCX + 0x268);
        *(int64_t *)(in_RCX + 0x2e8) = iVar6;
        if (iVar6 != 0) goto code_r0x0001801b0ce1;
code_r0x0001801b0ca5:
        *in_RDX = 0;
        uVar7 = 0;
    } else {
code_r0x0001801b0ce1:
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801b0ced;
        iVar4 = fcn.1801a2f40(in_RCX + 0xc50);
        if (iVar4 == 0) {
            if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                 (iVar4 = **(int32_t **)(in_RCX + 0x18), iVar4 < 0x304)) || (iVar4 == 0x10000)) ||
               ((*(int32_t *)(in_RCX + 0x2f8) != 4 && (*(int32_t *)(in_RCX + 0x2f8) != 0x18)))) {
                if ((*(int32_t *)(in_RCX + 0x2f8) == 2) && (0x25 < *(uint64_t *)(in_RCX + 0x108))) {
                    iVar6 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801b0daa;
                    iVar4 = fcn.180497f30(0x1804af260, iVar6 + 6, 0x20);
                    if (iVar4 == 0) goto code_r0x0001801b0dd4;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801b0dcc;
                iVar4 = fcn.1801dac70(*(int64_t *)(&stack0x00000000 + iVar5));
                if (iVar4 == 0) goto code_r0x0001801b0ca5;
            }
code_r0x0001801b0dd4:
            pcVar12 = *(code **)(in_RCX + 0x4f8);
            if (pcVar12 != (code *)0x0) {
                iVar2 = *(int64_t *)(in_RCX + 0x108);
                uVar11 = 0x16;
                iVar6 = *(int64_t *)(in_RCX + 0xf8);
                uVar8 = *(undefined4 *)(in_RCX + 0x48);
                *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)(in_RCX + 0x500);
                *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar7;
                *(int64_t *)(&stack0x00000000 + iVar5) = iVar2 + 4;
code_r0x0001801b0e11:
                uVar7 = *(undefined8 *)(iVar6 + 8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801b0e1a;
                (*pcVar12)(0, uVar8, uVar11, uVar7);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801b0d07;
            iVar4 = fcn.1801dac70(*(int64_t *)(&stack0x00000000 + iVar5));
            if (iVar4 == 0) goto code_r0x0001801b0ca5;
            pcVar12 = *(code **)(in_RCX + 0x4f8);
            if (pcVar12 != (code *)0x0) {
                uVar11 = 0;
                iVar6 = *(int64_t *)(in_RCX + 0xf8);
                uVar8 = 2;
                *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)(in_RCX + 0x500);
                uVar10 = *(undefined8 *)(in_RCX + 0x108);
                *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar7;
                *(undefined8 *)(&stack0x00000000 + iVar5) = uVar10;
                goto code_r0x0001801b0e11;
            }
        }
        *in_RDX = *(uint64_t *)(in_RCX + 0x108);
        uVar7 = 1;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_1801b0e50
// Address: 0x1801b0e50
// Size: 744 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801b0e50(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_b8h, int64_t arg_c8h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    uint8_t *puVar3;
    uint64_t uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    uint32_t *in_RDX;
    undefined8 uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_30;
    
    uStack_30 = 0x1801b0e66;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar2 = *(undefined8 *)(in_RCX + 0x40);
    uVar8 = 0;
    puVar3 = *(uint8_t **)(*(int64_t *)(in_RCX + 0xf8) + 8);
    do {
        uVar4 = *(uint64_t *)(in_RCX + 0x108);
        while (uVar4 < 4) {
            pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0x80);
            *(int64_t *)((int64_t)&var_8h + iVar7) = (int64_t)&arg_58h + iVar7;
            *(undefined4 *)((int64_t)aiStackX_18 + iVar7 + -0x18) = 0;
            *(uint64_t *)(&stack0xfffffffffffffff8 + iVar7) = 4 - uVar4;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0ed9;
            iVar6 = (*pcVar5)(in_RCX, 0x16, (int64_t)&arg_48h + iVar7, puVar3 + uVar4);
            if (iVar6 < 1) {
                *(undefined4 *)(in_RCX + 0x68) = 3;
                return 0;
            }
            if (*(char *)((int64_t)&arg_48h + iVar7) == '\x14') {
                if (((*(int64_t *)(in_RCX + 0x108) == 0) && (*(int64_t *)((int64_t)&arg_58h + iVar7) == 1)) &&
                   (*puVar3 == 1)) {
                    if ((*(int32_t *)(in_RCX + 0xac) == 0) && ((*(uint32_t *)(in_RCX + 0x160) & 0x800) != 0)) {
                        return 0;
                    }
                    *in_RDX = 0x101;
                    *(undefined4 *)(in_RCX + 0x2f8) = 0x101;
                    *(undefined8 *)(in_RCX + 0x108) = 0;
                    *(undefined8 *)(in_RCX + 0x100) = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
                    *(undefined8 *)(in_RCX + 0x2f0) = 1;
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b1049;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18));
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b1061;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar7)
                              , *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -8), *(int64_t *)(&stack0x00000028 + iVar7))
                ;
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b1077;
                fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar7));
                return 0;
            }
            if (*(char *)((int64_t)&arg_48h + iVar7) != '\x16') {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0f97;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18));
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0faf;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar7)
                              , *(int64_t *)((int64_t)aiStackX_18 + iVar7 + -8), *(int64_t *)(&stack0x00000028 + iVar7))
                ;
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0fc5;
                fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar7));
                return 0;
            }
            *(int64_t *)(in_RCX + 0x108) = *(int64_t *)(in_RCX + 0x108) + *(int64_t *)((int64_t)&arg_58h + iVar7);
            uVar4 = *(uint64_t *)(in_RCX + 0x108);
        }
        if (((*(int32_t *)(in_RCX + 0x78) != 0) || (*(int32_t *)(in_RCX + 0xac) == 1)) ||
           ((*puVar3 != 0 || (((puVar3[1] != 0 || (puVar3[2] != 0)) || (puVar3[3] != 0)))))) {
            *in_RDX = (uint32_t)*puVar3;
            *(uint32_t *)(in_RCX + 0x2f8) = (uint32_t)*puVar3;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b10bf;
            iVar6 = fcn.1801a2f40(in_RCX + 0xc50);
            if (iVar6 == 0) {
                *(uint64_t *)(in_RCX + 0x2f0) = (uint64_t)CONCAT21(CONCAT11(puVar3[1], puVar3[2]), puVar3[3]);
                iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8) + 4;
            } else {
                *(int64_t *)(in_RCX + 0x2f0) = *(int64_t *)(in_RCX + 0xd30) + 4;
                iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8);
                uVar8 = 4;
            }
            *(int64_t *)(in_RCX + 0x100) = iVar7;
            *(undefined8 *)(in_RCX + 0x108) = uVar8;
            return 1;
        }
        pcVar5 = *(code **)(in_RCX + 0x4f8);
        *(undefined8 *)(in_RCX + 0x108) = 0;
        if (pcVar5 != (code *)0x0) {
            uVar1 = *(undefined4 *)(in_RCX + 0x48);
            *(undefined8 *)((int64_t)&var_8h + iVar7) = *(undefined8 *)(in_RCX + 0x500);
            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + -0x18) = uVar2;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 4;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801b0f8d;
            (*pcVar5)(0, uVar1, 0x16, puVar3);
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801b1140
// Address: 0x1801b1140
// Size: 60 bytes
// ============================================================
int64_t fcn.1801b1140(int64_t param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar3 = *(int64_t *)(*(int64_t *)(param_1 + 0x8f8) + 0x2b8);
    if (iVar3 == 0) {
        iVar3 = *(int64_t *)(*(int64_t *)(param_1 + 0x8f8) + 0x2c0);
        if (iVar3 != 0) {
            iVar1 = iVar2 + 0x20;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x18023840a;
            iVar4 = fcn.18045a350();
            iVar4 = -iVar4;
            if (iVar3 == 0) {
                return 0;
            }
            iVar3 = *(int64_t *)(iVar3 + 0x50);
            *(undefined8 *)(&stack0x00000048 + iVar4 + iVar2) = 0x18023593a;
            iVar2 = fcn.18045a350();
            iVar2 = -iVar2;
            if (iVar3 == 0) {
                *(undefined8 *)(&stack0x00000048 + iVar2 + iVar4 + iVar1 + -0x20) = 0x180235947;
                fcn.180229480(*(int64_t *)(&stack0x00000070 + iVar2 + iVar4 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000078 + iVar2 + iVar4 + iVar1 + -0x20));
                *(undefined8 *)(&stack0x00000048 + iVar2 + iVar4 + iVar1 + -0x20) = 0x18023595f;
                fcn.1802295a0(*(int64_t *)(&stack0x00000070 + iVar2 + iVar4 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000078 + iVar2 + iVar4 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar2 + iVar4 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar2 + iVar4 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x000000a0 + iVar2 + iVar4 + iVar1 + -0x20));
                *(undefined8 *)(&stack0x00000048 + iVar2 + iVar4 + iVar1 + -0x20) = 0x180235971;
                fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar2 + iVar4 + iVar1 + -0x20));
                return 0;
            }
            iVar3 = *(int64_t *)(iVar3 + 0x10);
            if (iVar3 == 0) {
                *(undefined8 *)(&stack0x00000048 + iVar2 + iVar4 + iVar1 + -0x20) = 0x180235986;
                fcn.180229480(*(int64_t *)(&stack0x00000070 + iVar2 + iVar4 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000078 + iVar2 + iVar4 + iVar1 + -0x20));
                *(undefined8 *)(&stack0x00000048 + iVar2 + iVar4 + iVar1 + -0x20) = 0x18023599e;
                fcn.1802295a0(*(int64_t *)(&stack0x00000070 + iVar2 + iVar4 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000078 + iVar2 + iVar4 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar2 + iVar4 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar2 + iVar4 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x000000a0 + iVar2 + iVar4 + iVar1 + -0x20));
                *(undefined8 *)(&stack0x00000048 + iVar2 + iVar4 + iVar1 + -0x20) = 0x1802359b0;
                fcn.1802296d0(*(int64_t *)(&stack0x00000090 + iVar2 + iVar4 + iVar1 + -0x20));
                iVar3 = 0;
            }
            return iVar3;
        }
        iVar3 = 0;
    }
    return iVar3;
}

// ============================================================
// Function: FUN_1801b1180
// Address: 0x1801b1180
// Size: 488 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1801b1180(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar5;
    int64_t *in_R8;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    
    uStack_20 = 0x1801b1198;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
    if (in_R8 == (int64_t *)0x0) {
code_r0x0001801b12da:
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b12fe;
            iVar1 = func_0x000180244bf0(in_RDX, 0, 0, 3);
            if (iVar1 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b1307;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8));
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b12e4;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8));
        }
    } else {
        iVar6 = *in_R8;
        if (iVar6 == 0) {
            iVar6 = in_R8[1];
            if (iVar6 == 0) goto code_r0x0001801b12da;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b11fe;
            iVar1 = func_0x0001802362e0(iVar6, (int64_t)&arg_48h + iVar3);
            iVar6 = iVar5;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b11c4;
            iVar4 = func_0x0001802374f0();
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b11ce;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8));
                goto code_r0x0001801b130c;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b11e5;
            iVar1 = func_0x000180236470(iVar4, (int64_t)&arg_48h + iVar3);
        }
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b1209;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8));
        } else {
            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b1241;
                iVar2 = func_0x000180244a90(in_RDX, 3);
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b124a;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8));
                    goto code_r0x0001801b130c;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b126a;
            iVar1 = func_0x000180244bf0(in_RDX, *(undefined8 *)((int64_t)&arg_48h + iVar3), (int64_t)iVar1, 3);
            if (iVar1 != 0) {
                if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                    (iVar1 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar1)) && (iVar1 != 0x10000)) {
                    *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b12b7;
                    iVar1 = func_0x0001801c9910(in_RCX, in_RDX, 0x10000, iVar6);
                    if (iVar1 == 0) goto code_r0x0001801b1335;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b12c3;
                    iVar1 = func_0x000180244000(in_RDX);
                    if (iVar1 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b12cc;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8));
                        goto code_r0x0001801b130c;
                    }
                }
                iVar5 = 1;
                goto code_r0x0001801b1335;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b1273;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8));
        }
    }
code_r0x0001801b130c:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b131f;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_38h + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b1335;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar3));
code_r0x0001801b1335:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801b134c;
    fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar3), 0x1804af528, 0x574);
    return iVar5;
}

// ============================================================
// Function: FUN_1801b1370
// Address: 0x1801b1370
// Size: 155 bytes
// ============================================================
void fcn.1801b1370(int64_t arg_28h, int64_t arg_38h, int64_t arg_e8h, int64_t arg_148h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    undefined8 *puVar4;
    undefined *puVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int64_t in_RCX;
    int64_t iVar15;
    int64_t *in_RDX;
    uint64_t uVar16;
    uint32_t uVar17;
    undefined8 unaff_RSI;
    int64_t iVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801b1386;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_e8h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar9);
    iVar14 = 0;
    iVar18 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar9) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b13bb;
    iVar10 = fcn.180215470();
    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
    puVar4 = *(undefined8 **)(in_RCX + 8);
    iVar15 = iVar14;
    if (iVar10 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b13d1;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b13e9;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                      *(int64_t *)((int64_t)&var_18h + iVar9));
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b13ff;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar9));
        goto code_r0x0001801b18a6;
    }
    iVar12 = *(int64_t *)(in_RCX + 0x8f8);
    *(undefined8 *)((int64_t)&arg_148h + iVar9) = unaff_RSI;
    iVar11 = *(int64_t *)(iVar12 + 0x2b8);
    if (iVar11 == 0) {
        if (*(int64_t *)(iVar12 + 0x2c0) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1434;
            iVar11 = func_0x000180238400();
            if (iVar11 != 0) goto code_r0x0001801b1440;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1870;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
code_r0x0001801b1875:
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1888;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                      *(int64_t *)((int64_t)&var_18h + iVar9));
        iVar18 = iVar14;
    } else {
code_r0x0001801b1440:
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b144d;
        iVar12 = func_0x0001801a2080(iVar11, 0, puVar4);
        if (iVar12 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1457;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b146f;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_18h + iVar9));
            iVar18 = iVar14;
        } else if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1535;
            iVar8 = func_0x0001801ac160(in_RCX, iVar11);
            if (iVar8 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b153e;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1556;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                              *(int64_t *)((int64_t)&var_18h + iVar9));
            } else {
code_r0x0001801b14d6:
                uVar13 = *(undefined8 *)(in_RCX + 0x400);
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b14ea;
                iVar8 = func_0x0001801ab730(puVar4, uVar13, (int64_t)&var_20h + iVar9);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b14f3;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                    goto code_r0x0001801b1875;
                }
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
                    if (in_RDX[1] != 0x40) {
code_r0x0001801b1597:
                        if (in_RDX[1] == 0x80) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b15a9;
                            iVar8 = func_0x000180203a00(iVar11);
                            if (iVar8 == 0x3d4) goto code_r0x0001801b15b0;
                        }
                        goto code_r0x0001801b15b5;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1581;
                    iVar8 = func_0x000180203a00(iVar11);
                    if (iVar8 != 0x32b) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1590;
                        iVar8 = func_0x000180203a00(iVar11);
                        if (iVar8 != 0x3d3) goto code_r0x0001801b1597;
                    }
code_r0x0001801b15b0:
                    uVar17 = *(uint32_t *)(in_RDX + 1);
code_r0x0001801b15e1:
                    uVar16 = (uint64_t)uVar17;
                    if ((uint64_t)in_RDX[1] < uVar16) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1852;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                    } else {
                        iVar12 = *in_RDX;
                        iVar15 = in_RDX[1] - uVar16;
                        in_RDX[1] = iVar15;
                        *in_RDX = uVar16 + iVar12;
                        if (iVar15 == 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1647;
                            iVar8 = func_0x0001801ae510(in_RCX, (int64_t)&arg_38h + iVar9, (int64_t)&arg_28h + iVar9, 
                                                        (int64_t)&var_18h + iVar9);
                            iVar15 = iVar18;
                            if (iVar8 == 0) goto code_r0x0001801b18a6;
                            if (*(int64_t *)((int64_t)&var_20h + iVar9) == 0) {
                                uVar13 = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1663;
                                uVar13 = func_0x00018020f750();
                            }
                            uVar6 = puVar4[0x8c];
                            uVar7 = *puVar4;
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9) = 0;
                            *(int64_t *)(&stack0xfffffffffffffff0 + iVar9) = iVar11;
                            *(undefined8 *)(&stack0xffffffffffffffe8 + iVar9) = uVar6;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b168e;
                            iVar8 = func_0x00018025cbd0(iVar10, (int64_t)&var_10h + iVar9, uVar13, uVar7);
                            if (iVar8 < 1) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1697;
                                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b16c2;
                                iVar8 = func_0x000180203a00(iVar11);
                                if ((iVar8 == 0x32b) || (iVar8 - 0x3d3U < 2)) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b16e7;
                                    iVar14 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                           *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                    iVar15 = iVar14;
                                    if (iVar14 == 0) goto code_r0x0001801b18a6;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1701;
                                    func_0x000180226680(iVar14, iVar12, uVar17);
                                    iVar12 = iVar14;
                                }
                                if ((*(int64_t *)(in_RCX + 0x400) == 0) ||
                                   (*(int32_t *)(*(int64_t *)(in_RCX + 0x400) + 0x1c) != 0x390)) {
code_r0x0001801b174e:
                                    if (*(int32_t *)(in_RCX + 0x48) != 0x300) {
                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar9) =
                                             *(undefined8 *)((int64_t)&var_18h + iVar9);
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b17f9;
                                        iVar8 = func_0x00018025c530(iVar10, iVar12, uVar17, 
                                                                    *(undefined8 *)((int64_t)&arg_28h + iVar9));
                                        if (0 < iVar8) {
code_r0x0001801b1809:
                                            iVar15 = iVar14;
                                            if ((((*(int32_t *)(in_RCX + 0x78) == 0) &&
                                                 ((*(uint8_t *)
                                                    (*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0
                                                 )) && (iVar8 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar8)) &&
                                               ((iVar8 != 0x10000 && (*(int32_t *)(in_RCX + 0x340) == 1)))) {
                                                *(undefined4 *)((int64_t)&var_8h + iVar9) = 2;
                                            } else {
                                                *(undefined4 *)((int64_t)&var_8h + iVar9) = 3;
                                            }
                                            goto code_r0x0001801b18a6;
                                        }
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1802;
                                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
code_r0x0001801b17ad:
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b17c0;
                                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                                      *(int64_t *)(&stack0x00000000 + iVar9), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar9));
                                        iVar18 = iVar14;
                                        goto code_r0x0001801b1893;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b176d;
                                    iVar8 = func_0x00018025cc30(iVar10, *(undefined8 *)((int64_t)&arg_28h + iVar9), 
                                                                *(undefined8 *)((int64_t)&var_18h + iVar9));
                                    if (0 < iVar8) {
                                        iVar18 = *(int64_t *)(in_RCX + 0x8f8);
                                        uVar3 = *(undefined4 *)(iVar18 + 8);
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b178d;
                                        iVar8 = func_0x000180215040(iVar10, 0x1d, uVar3, iVar18 + 0x50);
                                        if (0 < iVar8) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b179f;
                                            iVar8 = func_0x00018025c840(iVar10, iVar12, uVar17);
                                            if (0 < iVar8) goto code_r0x0001801b1809;
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b17a8;
                                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                            goto code_r0x0001801b17ad;
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b17d5;
                                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1728;
                                    iVar8 = func_0x00018025dd20(*(undefined8 *)((int64_t)&var_10h + iVar9), 6);
                                    if (0 < iVar8) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b173b;
                                        iVar8 = func_0x00018025de80(*(undefined8 *)((int64_t)&var_10h + iVar9), 
                                                                    0xffffffff);
                                        if (0 < iVar8) goto code_r0x0001801b174e;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1744;
                                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b16af;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                          *(int64_t *)(&stack0x00000000 + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9));
                            iVar18 = iVar14;
                            goto code_r0x0001801b1893;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1608;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                    }
                } else {
code_r0x0001801b15b5:
                    if (1 < (uint64_t)in_RDX[1]) {
                        puVar5 = (undefined *)*in_RDX;
                        uVar17 = (uint32_t)CONCAT11(*puVar5, puVar5[1]);
                        *in_RDX = (int64_t)(puVar5 + 2);
                        in_RDX[1] = in_RDX[1] - 2;
                        goto code_r0x0001801b15e1;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1861;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1620;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                              *(int64_t *)((int64_t)&var_18h + iVar9));
            }
        } else {
            if (1 < (uint64_t)in_RDX[1]) {
                puVar5 = (undefined *)*in_RDX;
                uVar1 = puVar5[1];
                uVar2 = *puVar5;
                *in_RDX = (int64_t)(puVar5 + 2);
                in_RDX[1] = in_RDX[1] - 2;
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b14ce;
                iVar8 = func_0x0001801a98b0(in_RCX, CONCAT11(uVar2, uVar1), iVar11);
                if (iVar8 < 1) goto code_r0x0001801b18a6;
                goto code_r0x0001801b14d6;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1502;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b151a;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_18h + iVar9));
        }
    }
code_r0x0001801b1893:
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b189e;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar9));
    iVar15 = iVar18;
code_r0x0001801b18a6:
    uVar13 = *(undefined8 *)(in_RCX + 0x1a8);
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b18b2;
    func_0x000180219f80(uVar13);
    *(undefined8 *)(in_RCX + 0x1a8) = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b18c5;
    fcn.180215310(iVar10);
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b18da;
    fcn.180224990(iVar15, 0x1804af528, 0x25d);
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b18ee;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_e8h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801b140b
// Address: 0x1801b140b
// Size: 1179 bytes
// ============================================================
void fcn.1801b1370(int64_t arg_28h, int64_t arg_38h, int64_t arg_e8h, int64_t arg_148h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    undefined8 *puVar4;
    undefined *puVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int64_t in_RCX;
    int64_t iVar15;
    int64_t *in_RDX;
    uint64_t uVar16;
    uint32_t uVar17;
    undefined8 unaff_RSI;
    int64_t iVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801b1386;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_e8h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar9);
    iVar14 = 0;
    iVar18 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar9) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b13bb;
    iVar10 = fcn.180215470();
    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
    puVar4 = *(undefined8 **)(in_RCX + 8);
    iVar15 = iVar14;
    if (iVar10 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b13d1;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b13e9;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                      *(int64_t *)((int64_t)&var_18h + iVar9));
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b13ff;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar9));
        goto code_r0x0001801b18a6;
    }
    iVar12 = *(int64_t *)(in_RCX + 0x8f8);
    *(undefined8 *)((int64_t)&arg_148h + iVar9) = unaff_RSI;
    iVar11 = *(int64_t *)(iVar12 + 0x2b8);
    if (iVar11 == 0) {
        if (*(int64_t *)(iVar12 + 0x2c0) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1434;
            iVar11 = func_0x000180238400();
            if (iVar11 != 0) goto code_r0x0001801b1440;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1870;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
code_r0x0001801b1875:
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1888;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                      *(int64_t *)((int64_t)&var_18h + iVar9));
        iVar18 = iVar14;
    } else {
code_r0x0001801b1440:
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b144d;
        iVar12 = func_0x0001801a2080(iVar11, 0, puVar4);
        if (iVar12 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1457;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b146f;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_18h + iVar9));
            iVar18 = iVar14;
        } else if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1535;
            iVar8 = func_0x0001801ac160(in_RCX, iVar11);
            if (iVar8 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b153e;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1556;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                              *(int64_t *)((int64_t)&var_18h + iVar9));
            } else {
code_r0x0001801b14d6:
                uVar13 = *(undefined8 *)(in_RCX + 0x400);
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b14ea;
                iVar8 = func_0x0001801ab730(puVar4, uVar13, (int64_t)&var_20h + iVar9);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b14f3;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                    goto code_r0x0001801b1875;
                }
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
                    if (in_RDX[1] != 0x40) {
code_r0x0001801b1597:
                        if (in_RDX[1] == 0x80) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b15a9;
                            iVar8 = func_0x000180203a00(iVar11);
                            if (iVar8 == 0x3d4) goto code_r0x0001801b15b0;
                        }
                        goto code_r0x0001801b15b5;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1581;
                    iVar8 = func_0x000180203a00(iVar11);
                    if (iVar8 != 0x32b) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1590;
                        iVar8 = func_0x000180203a00(iVar11);
                        if (iVar8 != 0x3d3) goto code_r0x0001801b1597;
                    }
code_r0x0001801b15b0:
                    uVar17 = *(uint32_t *)(in_RDX + 1);
code_r0x0001801b15e1:
                    uVar16 = (uint64_t)uVar17;
                    if ((uint64_t)in_RDX[1] < uVar16) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1852;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                    } else {
                        iVar12 = *in_RDX;
                        iVar15 = in_RDX[1] - uVar16;
                        in_RDX[1] = iVar15;
                        *in_RDX = uVar16 + iVar12;
                        if (iVar15 == 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1647;
                            iVar8 = func_0x0001801ae510(in_RCX, (int64_t)&arg_38h + iVar9, (int64_t)&arg_28h + iVar9, 
                                                        (int64_t)&var_18h + iVar9);
                            iVar15 = iVar18;
                            if (iVar8 == 0) goto code_r0x0001801b18a6;
                            if (*(int64_t *)((int64_t)&var_20h + iVar9) == 0) {
                                uVar13 = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1663;
                                uVar13 = func_0x00018020f750();
                            }
                            uVar6 = puVar4[0x8c];
                            uVar7 = *puVar4;
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9) = 0;
                            *(int64_t *)(&stack0xfffffffffffffff0 + iVar9) = iVar11;
                            *(undefined8 *)(&stack0xffffffffffffffe8 + iVar9) = uVar6;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b168e;
                            iVar8 = func_0x00018025cbd0(iVar10, (int64_t)&var_10h + iVar9, uVar13, uVar7);
                            if (iVar8 < 1) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1697;
                                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b16c2;
                                iVar8 = func_0x000180203a00(iVar11);
                                if ((iVar8 == 0x32b) || (iVar8 - 0x3d3U < 2)) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b16e7;
                                    iVar14 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                           *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                    iVar15 = iVar14;
                                    if (iVar14 == 0) goto code_r0x0001801b18a6;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1701;
                                    func_0x000180226680(iVar14, iVar12, uVar17);
                                    iVar12 = iVar14;
                                }
                                if ((*(int64_t *)(in_RCX + 0x400) == 0) ||
                                   (*(int32_t *)(*(int64_t *)(in_RCX + 0x400) + 0x1c) != 0x390)) {
code_r0x0001801b174e:
                                    if (*(int32_t *)(in_RCX + 0x48) != 0x300) {
                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar9) =
                                             *(undefined8 *)((int64_t)&var_18h + iVar9);
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b17f9;
                                        iVar8 = func_0x00018025c530(iVar10, iVar12, uVar17, 
                                                                    *(undefined8 *)((int64_t)&arg_28h + iVar9));
                                        if (0 < iVar8) {
code_r0x0001801b1809:
                                            iVar15 = iVar14;
                                            if ((((*(int32_t *)(in_RCX + 0x78) == 0) &&
                                                 ((*(uint8_t *)
                                                    (*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0
                                                 )) && (iVar8 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar8)) &&
                                               ((iVar8 != 0x10000 && (*(int32_t *)(in_RCX + 0x340) == 1)))) {
                                                *(undefined4 *)((int64_t)&var_8h + iVar9) = 2;
                                            } else {
                                                *(undefined4 *)((int64_t)&var_8h + iVar9) = 3;
                                            }
                                            goto code_r0x0001801b18a6;
                                        }
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1802;
                                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
code_r0x0001801b17ad:
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b17c0;
                                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                                      *(int64_t *)(&stack0x00000000 + iVar9), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar9));
                                        iVar18 = iVar14;
                                        goto code_r0x0001801b1893;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b176d;
                                    iVar8 = func_0x00018025cc30(iVar10, *(undefined8 *)((int64_t)&arg_28h + iVar9), 
                                                                *(undefined8 *)((int64_t)&var_18h + iVar9));
                                    if (0 < iVar8) {
                                        iVar18 = *(int64_t *)(in_RCX + 0x8f8);
                                        uVar3 = *(undefined4 *)(iVar18 + 8);
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b178d;
                                        iVar8 = func_0x000180215040(iVar10, 0x1d, uVar3, iVar18 + 0x50);
                                        if (0 < iVar8) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b179f;
                                            iVar8 = func_0x00018025c840(iVar10, iVar12, uVar17);
                                            if (0 < iVar8) goto code_r0x0001801b1809;
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b17a8;
                                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                            goto code_r0x0001801b17ad;
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b17d5;
                                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1728;
                                    iVar8 = func_0x00018025dd20(*(undefined8 *)((int64_t)&var_10h + iVar9), 6);
                                    if (0 < iVar8) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b173b;
                                        iVar8 = func_0x00018025de80(*(undefined8 *)((int64_t)&var_10h + iVar9), 
                                                                    0xffffffff);
                                        if (0 < iVar8) goto code_r0x0001801b174e;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1744;
                                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b16af;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                          *(int64_t *)(&stack0x00000000 + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9));
                            iVar18 = iVar14;
                            goto code_r0x0001801b1893;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1608;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                    }
                } else {
code_r0x0001801b15b5:
                    if (1 < (uint64_t)in_RDX[1]) {
                        puVar5 = (undefined *)*in_RDX;
                        uVar17 = (uint32_t)CONCAT11(*puVar5, puVar5[1]);
                        *in_RDX = (int64_t)(puVar5 + 2);
                        in_RDX[1] = in_RDX[1] - 2;
                        goto code_r0x0001801b15e1;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1861;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1620;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                              *(int64_t *)((int64_t)&var_18h + iVar9));
            }
        } else {
            if (1 < (uint64_t)in_RDX[1]) {
                puVar5 = (undefined *)*in_RDX;
                uVar1 = puVar5[1];
                uVar2 = *puVar5;
                *in_RDX = (int64_t)(puVar5 + 2);
                in_RDX[1] = in_RDX[1] - 2;
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b14ce;
                iVar8 = func_0x0001801a98b0(in_RCX, CONCAT11(uVar2, uVar1), iVar11);
                if (iVar8 < 1) goto code_r0x0001801b18a6;
                goto code_r0x0001801b14d6;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1502;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b151a;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_18h + iVar9));
        }
    }
code_r0x0001801b1893:
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b189e;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar9));
    iVar15 = iVar18;
code_r0x0001801b18a6:
    uVar13 = *(undefined8 *)(in_RCX + 0x1a8);
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b18b2;
    func_0x000180219f80(uVar13);
    *(undefined8 *)(in_RCX + 0x1a8) = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b18c5;
    fcn.180215310(iVar10);
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b18da;
    fcn.180224990(iVar15, 0x1804af528, 0x25d);
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b18ee;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_e8h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801b18a6
// Address: 0x1801b18a6
// Size: 91 bytes
// ============================================================
void fcn.1801b1370(int64_t arg_28h, int64_t arg_38h, int64_t arg_e8h, int64_t arg_148h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    undefined8 *puVar4;
    undefined *puVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int64_t in_RCX;
    int64_t iVar15;
    int64_t *in_RDX;
    uint64_t uVar16;
    uint32_t uVar17;
    undefined8 unaff_RSI;
    int64_t iVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801b1386;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_e8h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar9);
    iVar14 = 0;
    iVar18 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar9) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b13bb;
    iVar10 = fcn.180215470();
    *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
    puVar4 = *(undefined8 **)(in_RCX + 8);
    iVar15 = iVar14;
    if (iVar10 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b13d1;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b13e9;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                      *(int64_t *)((int64_t)&var_18h + iVar9));
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b13ff;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar9));
        goto code_r0x0001801b18a6;
    }
    iVar12 = *(int64_t *)(in_RCX + 0x8f8);
    *(undefined8 *)((int64_t)&arg_148h + iVar9) = unaff_RSI;
    iVar11 = *(int64_t *)(iVar12 + 0x2b8);
    if (iVar11 == 0) {
        if (*(int64_t *)(iVar12 + 0x2c0) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1434;
            iVar11 = func_0x000180238400();
            if (iVar11 != 0) goto code_r0x0001801b1440;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1870;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
code_r0x0001801b1875:
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1888;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                      *(int64_t *)((int64_t)&var_18h + iVar9));
        iVar18 = iVar14;
    } else {
code_r0x0001801b1440:
        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b144d;
        iVar12 = func_0x0001801a2080(iVar11, 0, puVar4);
        if (iVar12 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1457;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b146f;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_18h + iVar9));
            iVar18 = iVar14;
        } else if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1535;
            iVar8 = func_0x0001801ac160(in_RCX, iVar11);
            if (iVar8 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b153e;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1556;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                              *(int64_t *)((int64_t)&var_18h + iVar9));
            } else {
code_r0x0001801b14d6:
                uVar13 = *(undefined8 *)(in_RCX + 0x400);
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b14ea;
                iVar8 = func_0x0001801ab730(puVar4, uVar13, (int64_t)&var_20h + iVar9);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b14f3;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                    goto code_r0x0001801b1875;
                }
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
                    if (in_RDX[1] != 0x40) {
code_r0x0001801b1597:
                        if (in_RDX[1] == 0x80) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b15a9;
                            iVar8 = func_0x000180203a00(iVar11);
                            if (iVar8 == 0x3d4) goto code_r0x0001801b15b0;
                        }
                        goto code_r0x0001801b15b5;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1581;
                    iVar8 = func_0x000180203a00(iVar11);
                    if (iVar8 != 0x32b) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1590;
                        iVar8 = func_0x000180203a00(iVar11);
                        if (iVar8 != 0x3d3) goto code_r0x0001801b1597;
                    }
code_r0x0001801b15b0:
                    uVar17 = *(uint32_t *)(in_RDX + 1);
code_r0x0001801b15e1:
                    uVar16 = (uint64_t)uVar17;
                    if ((uint64_t)in_RDX[1] < uVar16) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1852;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                    } else {
                        iVar12 = *in_RDX;
                        iVar15 = in_RDX[1] - uVar16;
                        in_RDX[1] = iVar15;
                        *in_RDX = uVar16 + iVar12;
                        if (iVar15 == 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1647;
                            iVar8 = func_0x0001801ae510(in_RCX, (int64_t)&arg_38h + iVar9, (int64_t)&arg_28h + iVar9, 
                                                        (int64_t)&var_18h + iVar9);
                            iVar15 = iVar18;
                            if (iVar8 == 0) goto code_r0x0001801b18a6;
                            if (*(int64_t *)((int64_t)&var_20h + iVar9) == 0) {
                                uVar13 = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1663;
                                uVar13 = func_0x00018020f750();
                            }
                            uVar6 = puVar4[0x8c];
                            uVar7 = *puVar4;
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9) = 0;
                            *(int64_t *)(&stack0xfffffffffffffff0 + iVar9) = iVar11;
                            *(undefined8 *)(&stack0xffffffffffffffe8 + iVar9) = uVar6;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b168e;
                            iVar8 = func_0x00018025cbd0(iVar10, (int64_t)&var_10h + iVar9, uVar13, uVar7);
                            if (iVar8 < 1) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1697;
                                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b16c2;
                                iVar8 = func_0x000180203a00(iVar11);
                                if ((iVar8 == 0x32b) || (iVar8 - 0x3d3U < 2)) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b16e7;
                                    iVar14 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                           *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                    iVar15 = iVar14;
                                    if (iVar14 == 0) goto code_r0x0001801b18a6;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1701;
                                    func_0x000180226680(iVar14, iVar12, uVar17);
                                    iVar12 = iVar14;
                                }
                                if ((*(int64_t *)(in_RCX + 0x400) == 0) ||
                                   (*(int32_t *)(*(int64_t *)(in_RCX + 0x400) + 0x1c) != 0x390)) {
code_r0x0001801b174e:
                                    if (*(int32_t *)(in_RCX + 0x48) != 0x300) {
                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar9) =
                                             *(undefined8 *)((int64_t)&var_18h + iVar9);
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b17f9;
                                        iVar8 = func_0x00018025c530(iVar10, iVar12, uVar17, 
                                                                    *(undefined8 *)((int64_t)&arg_28h + iVar9));
                                        if (0 < iVar8) {
code_r0x0001801b1809:
                                            iVar15 = iVar14;
                                            if ((((*(int32_t *)(in_RCX + 0x78) == 0) &&
                                                 ((*(uint8_t *)
                                                    (*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0
                                                 )) && (iVar8 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar8)) &&
                                               ((iVar8 != 0x10000 && (*(int32_t *)(in_RCX + 0x340) == 1)))) {
                                                *(undefined4 *)((int64_t)&var_8h + iVar9) = 2;
                                            } else {
                                                *(undefined4 *)((int64_t)&var_8h + iVar9) = 3;
                                            }
                                            goto code_r0x0001801b18a6;
                                        }
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1802;
                                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
code_r0x0001801b17ad:
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b17c0;
                                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                                      *(int64_t *)(&stack0x00000000 + iVar9), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar9));
                                        iVar18 = iVar14;
                                        goto code_r0x0001801b1893;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b176d;
                                    iVar8 = func_0x00018025cc30(iVar10, *(undefined8 *)((int64_t)&arg_28h + iVar9), 
                                                                *(undefined8 *)((int64_t)&var_18h + iVar9));
                                    if (0 < iVar8) {
                                        iVar18 = *(int64_t *)(in_RCX + 0x8f8);
                                        uVar3 = *(undefined4 *)(iVar18 + 8);
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b178d;
                                        iVar8 = func_0x000180215040(iVar10, 0x1d, uVar3, iVar18 + 0x50);
                                        if (0 < iVar8) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b179f;
                                            iVar8 = func_0x00018025c840(iVar10, iVar12, uVar17);
                                            if (0 < iVar8) goto code_r0x0001801b1809;
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b17a8;
                                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                            goto code_r0x0001801b17ad;
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b17d5;
                                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1728;
                                    iVar8 = func_0x00018025dd20(*(undefined8 *)((int64_t)&var_10h + iVar9), 6);
                                    if (0 < iVar8) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b173b;
                                        iVar8 = func_0x00018025de80(*(undefined8 *)((int64_t)&var_10h + iVar9), 
                                                                    0xffffffff);
                                        if (0 < iVar8) goto code_r0x0001801b174e;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1744;
                                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b16af;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), 
                                          *(int64_t *)(&stack0x00000000 + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9));
                            iVar18 = iVar14;
                            goto code_r0x0001801b1893;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1608;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                    }
                } else {
code_r0x0001801b15b5:
                    if (1 < (uint64_t)in_RDX[1]) {
                        puVar5 = (undefined *)*in_RDX;
                        uVar17 = (uint32_t)CONCAT11(*puVar5, puVar5[1]);
                        *in_RDX = (int64_t)(puVar5 + 2);
                        in_RDX[1] = in_RDX[1] - 2;
                        goto code_r0x0001801b15e1;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1861;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar9));
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1620;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar9), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                              *(int64_t *)((int64_t)&var_18h + iVar9));
            }
        } else {
            if (1 < (uint64_t)in_RDX[1]) {
                puVar5 = (undefined *)*in_RDX;
                uVar1 = puVar5[1];
                uVar2 = *puVar5;
                *in_RDX = (int64_t)(puVar5 + 2);
                in_RDX[1] = in_RDX[1] - 2;
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b14ce;
                iVar8 = func_0x0001801a98b0(in_RCX, CONCAT11(uVar2, uVar1), iVar11);
                if (iVar8 < 1) goto code_r0x0001801b18a6;
                goto code_r0x0001801b14d6;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b1502;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b151a;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)(&stack0xfffffffffffffff0 + iVar9)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_18h + iVar9));
        }
    }
code_r0x0001801b1893:
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b189e;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar9));
    iVar15 = iVar18;
code_r0x0001801b18a6:
    uVar13 = *(undefined8 *)(in_RCX + 0x1a8);
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b18b2;
    func_0x000180219f80(uVar13);
    *(undefined8 *)(in_RCX + 0x1a8) = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b18c5;
    fcn.180215310(iVar10);
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b18da;
    fcn.180224990(iVar15, 0x1804af528, 0x25d);
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801b18ee;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_e8h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801b1910
// Address: 0x1801b1910
// Size: 395 bytes
// ============================================================
undefined8 fcn.1801b1910(int64_t param_1, int64_t param_2)
{
    int16_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b191c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar2 = *(int64_t *)(param_2 + 8);
    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(param_1 + 0x18) + 0xd8) + 0x50) & 8) == 0) {
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b19e1;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b19f9;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1a0f;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
            return 0;
        }
    } else if (*(int32_t *)(param_1 + 0x48) == 0x100) {
        if (iVar2 != 2) {
code_r0x0001801b1998:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b199d;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b19b5;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b19cb;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
            return 0;
        }
    } else if (iVar2 != 0) goto code_r0x0001801b1998;
    if (*(int64_t *)(param_1 + 0x300) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b195d;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1975;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b198b;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined4 *)(param_1 + 0x1b8) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1a29;
    iVar3 = func_0x0001801c6d70(param_1);
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1a32;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1a4a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1a60;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    if (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(param_1 + 0x18) + 0xd8) + 0x50) & 8) != 0) &&
       (*(int32_t *)(param_1 + 0x48) == 0x100)) {
        piVar1 = (int16_t *)(*(int64_t *)(param_1 + 0x4f0) + 0x110);
        *piVar1 = *piVar1 + 1;
    }
    return 3;
}

// ============================================================
// Function: FUN_1801b1aa0
// Address: 0x1801b1aa0
// Size: 1126 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801b1aa0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    code *pcVar1;
    undefined8 uVar2;
    uint64_t uVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RSI;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801b1ab3;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    bVar4 = false;
    if ((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) {
        bVar4 = true;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    if (*(int32_t *)(in_RCX + 0x78) != 0) {
        pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x68);
        if (pcVar1 != (code *)0x0) {
            uVar2 = *(undefined8 *)(in_RCX + 0xc78);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1b01;
            (*pcVar1)(uVar2, 0);
        }
        if (*(int32_t *)(in_RCX + 0xba8) != 4) {
            *(undefined4 *)(in_RCX + 0xc0) = 1;
        }
        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
             (iVar5 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar5)) && (iVar5 != 0x10000)) &&
           (*(int64_t *)(in_RCX + 0xbc8) == 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1b5b;
            iVar5 = fcn.1801da790(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
            if (iVar5 == 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1b68;
            iVar7 = fcn.180215470();
            *(int64_t *)(in_RCX + 0xbc8) = iVar7;
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1b79;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1b91;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1ba7;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1bbd;
            iVar5 = fcn.180214b00(*(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6));
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1bc6;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1bde;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1bf4;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
                uVar2 = *(undefined8 *)(in_RCX + 0xbc8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1c00;
                fcn.180215310(uVar2);
                *(undefined8 *)(in_RCX + 0xbc8) = 0;
                return 0;
            }
        }
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar5 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar5)) && (iVar5 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1c3b;
        iVar5 = func_0x0001801a2f70(in_RCX + 0xc50);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1c44;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1c5c;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1c72;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
            return 0;
        }
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) &&
       (*(int32_t *)(in_RCX + 0x1b8) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1ca7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1cbf;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1cd5;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0;
    }
    *(undefined4 *)(in_RCX + 0x1b8) = 0;
    uVar3 = *(uint64_t *)(in_RCX + 0x2e8);
    if (uVar3 != in_RDX[1]) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1cf4;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1d0c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1d22;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0;
    }
    uVar2 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1d3b;
    iVar5 = func_0x0001802262e0(uVar2, in_RCX + 0x268, uVar3);
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1d44;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1d5c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1d72;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0;
    }
    if (0x40 < uVar3) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1d84;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1d9c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1db2;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0;
    }
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1dea;
        fcn.180498030(in_RCX + 0x468, in_RCX + 0x268, uVar3);
        *(uint64_t *)(in_RCX + 0x4a8) = uVar3;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1dd5;
        fcn.180498030(in_RCX + 0x420, in_RCX + 0x268, uVar3);
        *(uint64_t *)(in_RCX + 0x460) = uVar3;
    }
    iVar7 = *(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36);
    if ((((*(uint8_t *)(iVar7 + 0x50) & 8) == 0) && (iVar5 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar5)) &&
       (iVar5 != 0x10000)) {
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            pcVar1 = *(code **)(iVar7 + 8);
            *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8) = (int64_t)&arg_38h + iVar6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1e65;
            iVar5 = (*pcVar1)(in_RCX, in_RCX + 0x5f4, in_RCX + 0x5b4, 0);
            if (iVar5 == 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1e75;
            iVar5 = func_0x0001801b45f0(in_RCX);
            if (iVar5 == 0) {
                return 0;
            }
            if ((*(uint32_t *)(in_RCX + 0x160) & 0x2000) == 0) {
                pcVar1 = *(code **)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1ea2;
                iVar5 = (*pcVar1)(in_RCX, 0x111);
                if (iVar5 == 0) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1eb2;
            iVar5 = func_0x0001801d16c0(in_RCX);
        } else {
            if (*(int32_t *)(in_RCX + 0xba8) == 4) goto code_r0x0001801b1eba;
            pcVar1 = *(code **)(iVar7 + 0x10);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1e3f;
            iVar5 = (*pcVar1)(in_RCX, 0x121);
        }
        if (iVar5 == 0) {
            return 0;
        }
    }
code_r0x0001801b1eba:
    if (((bVar4) && (*(int64_t *)(in_RCX + 0x260) != 0)) &&
       ((*(int64_t *)(in_RCX + 0x2e8) != 0 &&
        (pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x70), pcVar1 != (code *)0x0)))) {
        uVar2 = *(undefined8 *)(in_RCX + 0xc78);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801b1eee;
        (*pcVar1)(uVar2, 0);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801b1f10
// Address: 0x1801b1f10
// Size: 266 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801b1f10(int64_t arg_28h)
{
    char *pcVar1;
    char cVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    char **in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b1f20;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1f35;
    iVar3 = func_0x0001801a2f70(in_RCX + 0xc50);
    if (iVar3 == 0) {
        if (in_RDX[1] != (char *)0x0) {
            cVar2 = **in_RDX;
            *in_RDX = *in_RDX + 1;
            pcVar1 = in_RDX[1] + -1;
            in_RDX[1] = pcVar1;
            if (pcVar1 == (char *)0x0) {
                if (cVar2 != '\0') {
                    if (cVar2 != '\x01') {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1f98;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1fb0;
                        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)(&stack0x00000048 + iVar4));
                        goto code_r0x0001801b2002;
                    }
                    *(undefined4 *)(in_RCX + 0xba4) = 0;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1fc7;
                iVar3 = func_0x0001801b4650(in_RCX, 0);
                return iVar3 != 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1fdf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1ff7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1f3e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b1f56;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
    }
code_r0x0001801b2002:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b200d;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
    return false;
}

// ============================================================
// Function: FUN_1801b2020
// Address: 0x1801b2020
// Size: 1151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 fcn.1801b2020(int64_t arg_68h, int64_t arg_70h, int64_t arg_80h)
{
    uint8_t uVar1;
    int32_t *piVar2;
    uint8_t *puVar3;
    undefined8 uVar4;
    unkuint3 Var5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    uint8_t *puVar11;
    uint8_t *puVar12;
    uint8_t **in_RDX;
    uint8_t *puVar13;
    int64_t iVar14;
    uint32_t uVar15;
    uint32_t uVar16;
    int64_t *in_R8;
    undefined8 *puVar17;
    int64_t iVar18;
    int64_t var_8h;
    int64_t var_10h;
    uint8_t *puStackX_18;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    
    uStack_40 = 0x1801b203a;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    puVar17 = *(undefined8 **)(in_RCX + 8);
    piVar2 = *(int32_t **)(in_RCX + 0x18);
    iVar18 = 0;
    *(undefined8 *)((int64_t)&arg_80h + iVar10) = 0;
    *(undefined4 *)((int64_t)&arg_68h + iVar10) = 0;
    *(undefined8 **)((int64_t)&var_8h + iVar10) = puVar17;
    if ((((*(uint8_t *)(*(int64_t *)(piVar2 + 0x36) + 0x50) & 8) != 0) || (iVar9 = *piVar2, iVar9 < 0x304)) ||
       (iVar9 == 0x10000)) goto code_r0x0001801b215b;
    puVar11 = *in_RDX;
    puVar12 = in_RDX[1];
    puVar13 = in_RDX[1];
    *(uint8_t **)(&stack0xfffffffffffffff8 + iVar10) = puVar11;
    *(uint8_t **)(&stack0x00000000 + iVar10) = puVar12;
    if (puVar13 == (uint8_t *)0x0) {
code_r0x0001801b214a:
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b214f;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
code_r0x0001801b20f7:
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b210a;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), *(int64_t *)(&stack0x00000000 + iVar10), 
                      *(int64_t *)((int64_t)&puStackX_18 + iVar10));
        iVar18 = 0;
    } else {
        puVar13 = puVar13 + -1;
        puVar12 = (uint8_t *)(uint64_t)*puVar11;
        if (puVar13 < puVar12) goto code_r0x0001801b214a;
        *(uint8_t **)(&stack0xfffffffffffffff8 + iVar10) = puVar11 + 1 + (int64_t)puVar12;
        *(int64_t *)(&stack0x00000000 + iVar10) = (int64_t)puVar13 - (int64_t)puVar12;
        uVar6 = *(undefined4 *)(&stack0xfffffffffffffffc + iVar10);
        uVar7 = *(undefined4 *)(&stack0x00000000 + iVar10);
        uVar8 = *(undefined4 *)(&stack0x00000004 + iVar10);
        *(undefined4 *)in_RDX = *(undefined4 *)(&stack0xfffffffffffffff8 + iVar10);
        *(undefined4 *)((int64_t)in_RDX + 4) = uVar6;
        *(undefined4 *)(in_RDX + 1) = uVar7;
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar8;
        if (*(int32_t *)(in_RCX + 0x78) != 0) {
            if (*(int64_t *)(in_RCX + 0xbb0) == 0) {
                if (puVar12 == (uint8_t *)0x0) goto code_r0x0001801b215b;
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b20f2;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10))
                ;
            } else {
                if (puVar12 == *(uint8_t **)(in_RCX + 3000)) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2129;
                    iVar9 = func_0x0001802262e0(puVar11 + 1);
                    if (iVar9 == 0) {
                        puVar17 = *(undefined8 **)((int64_t)&var_8h + iVar10);
                        goto code_r0x0001801b215b;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2132;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10))
                ;
            }
            goto code_r0x0001801b20f7;
        }
        if (puVar12 != (uint8_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2143;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
            goto code_r0x0001801b20f7;
        }
code_r0x0001801b215b:
        puVar13 = in_RDX[1];
        if (puVar13 < (uint8_t *)0x3) {
code_r0x0001801b242b:
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2430;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
code_r0x0001801b2435:
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2448;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), *(int64_t *)(&stack0x00000000 + iVar10), 
                          *(int64_t *)((int64_t)&puStackX_18 + iVar10));
        } else {
            puVar3 = *in_RDX;
            puVar12 = puVar3 + 3;
            puVar11 = puVar13 + -3;
            Var5 = CONCAT21(CONCAT11(*puVar3, puVar3[1]), puVar3[2]);
            uVar16 = (uint32_t)Var5;
            *in_RDX = puVar12;
            in_RDX[1] = puVar11;
            if (puVar11 != (uint8_t *)(uint64_t)uVar16) goto code_r0x0001801b242b;
            if (Var5 == 0) {
                return 1;
            }
            uVar15 = uVar16;
            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                (iVar9 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar9)) && (iVar9 != 0x10000)) {
                if ((uint8_t *)0x2 < puVar11) {
                    puVar11 = puVar13 + -6;
                    uVar1 = *puVar12;
                    puVar12 = puVar3 + 6;
                    uVar15 = (uint32_t)CONCAT21(CONCAT11(uVar1, puVar3[4]), puVar3[5]);
                    *in_RDX = puVar12;
                    in_RDX[1] = puVar11;
                    if (uVar15 != 0) goto code_r0x0001801b2232;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b21fe;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2216;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)&puStackX_18 + iVar10))
                    ;
                    goto code_r0x0001801b2453;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2226;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10))
                ;
                goto code_r0x0001801b2435;
            }
code_r0x0001801b2232:
            puVar13 = (uint8_t *)(uint64_t)uVar15;
            if (puVar11 < puVar13) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2424;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10))
                ;
                goto code_r0x0001801b2435;
            }
            *(uint8_t **)(&stack0xfffffffffffffff8 + iVar10) = puVar12;
            in_RDX[1] = puVar11 + -(int64_t)puVar13;
            *in_RDX = puVar13 + (int64_t)puVar12;
            uVar4 = *puVar17;
            *(undefined8 *)((int64_t)&var_18h + iVar10) = puVar17[0x8c];
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b226f;
            iVar18 = func_0x000180235e90(0, &stack0xfffffffffffffff8 + iVar10, uVar15, uVar4);
            if ((iVar18 == 0) || (*(uint8_t **)(&stack0xfffffffffffffff8 + iVar10) != puVar12 + (int64_t)puVar13)) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2418;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10))
                ;
                goto code_r0x0001801b2435;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2292;
            iVar9 = func_0x00018022fd20(iVar18);
            if (iVar9 == 0) {
                if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                    (iVar9 = **(int32_t **)(in_RCX + 0x18), iVar9 < 0x304)) || (iVar9 == 0x10000)) {
code_r0x0001801b23ee:
                    *(undefined4 *)((int64_t)&arg_68h + iVar10) = 1;
                    if (in_R8 != (int64_t *)0x0) {
                        *in_R8 = iVar18;
                        iVar18 = 0;
                    }
                    goto code_r0x0001801b245e;
                }
                if (in_RDX[1] == (uint8_t *)(uint64_t)((uVar16 - uVar15) - 3)) {
                    puVar11 = *in_RDX;
                    puVar12 = in_RDX[1];
                    puVar13 = in_RDX[1];
                    *(uint8_t **)((int64_t)&var_8h + iVar10) = puVar11;
                    *(uint8_t **)((int64_t)&puStackX_18 + iVar10 + -8) = puVar12;
                    if ((uint8_t *)0x1 < puVar13) {
                        puVar13 = puVar13 + -2;
                        puVar12 = (uint8_t *)(uint64_t)CONCAT11(*puVar11, puVar11[1]);
                        if (puVar12 <= puVar13) {
                            iVar14 = (int64_t)puVar13 - (int64_t)puVar12;
                            *(uint8_t **)((int64_t)&var_8h + iVar10) = puVar12 + (int64_t)(puVar11 + 2);
                            *(int64_t *)((int64_t)&puStackX_18 + iVar10 + -8) = iVar14;
                            if (iVar14 == 0) {
                                uVar6 = *(undefined4 *)((int64_t)&var_8h + iVar10 + 4);
                                uVar7 = *(undefined4 *)((int64_t)&puStackX_18 + iVar10 + -8);
                                uVar8 = *(undefined4 *)((int64_t)&puStackX_18 + iVar10 + -4);
                                *(uint8_t **)((int64_t)&puStackX_18 + iVar10) = puVar11 + 2;
                                *(uint8_t **)((int64_t)&var_20h + iVar10) = puVar12;
                                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_8h + iVar10);
                                *(undefined4 *)((int64_t)in_RDX + 4) = uVar6;
                                *(undefined4 *)(in_RDX + 1) = uVar7;
                                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar8;
                                if (in_RDX[1] == (uint8_t *)0x0) {
                                    *(undefined4 *)(&stack0xfffffffffffffff0 + iVar10) = 1;
                                    *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b23b9;
                                    iVar9 = func_0x0001801c9450(in_RCX, (int64_t)&puStackX_18 + iVar10, 0x10000, 
                                                                (int64_t)&arg_80h + iVar10);
                                    if (iVar9 == 0) goto code_r0x0001801b245e;
                                    *(undefined4 *)(&stack0xfffffffffffffff0 + iVar10) = 1;
                                    *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b23ea;
                                    iVar9 = func_0x0001801c9b70(in_RCX, 0x10000, 
                                                                *(undefined8 *)((int64_t)&arg_80h + iVar10), 0);
                                    if (iVar9 == 0) goto code_r0x0001801b245e;
                                    goto code_r0x0001801b23ee;
                                }
                            }
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b240c;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
                    goto code_r0x0001801b2435;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2300;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10))
                ;
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2318;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10)
                              , *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), *(int64_t *)(&stack0x00000000 + iVar10)
                              , *(int64_t *)((int64_t)&puStackX_18 + iVar10));
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b229b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10))
                ;
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b22b3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10)
                              , *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), *(int64_t *)(&stack0x00000000 + iVar10)
                              , *(int64_t *)((int64_t)&puStackX_18 + iVar10));
            }
        }
    }
code_r0x0001801b2453:
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b245e;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar10));
code_r0x0001801b245e:
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2478;
    fcn.180224990(*(undefined8 *)((int64_t)&arg_80h + iVar10), 0x1804af528, 0x525);
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801b2480;
    fcn.18022ecc0(iVar18);
    return *(undefined4 *)((int64_t)&arg_68h + iVar10);
}

// ============================================================
// Function: FUN_1801b24a0
// Address: 0x1801b24a0
// Size: 410 bytes
// ============================================================
undefined8 fcn.1801b24a0(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    int32_t iVar8;
    int64_t in_RCX;
    int64_t iVar9;
    int32_t iVar10;
    uint32_t uVar11;
    undefined8 unaff_RBP;
    int32_t iVar12;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801b24ae;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar1 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b24bd;
    iVar2 = fcn.1801db380(*(int64_t *)((int64_t)&var_10h + iVar5));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined (*) [16])(in_RCX + 0x9e8) = ZEXT816(0);
    *(undefined8 *)(in_RCX + 0x9f8) = 0;
    *(undefined4 *)(in_RCX + 0xa00) = 0;
    *(undefined *)(in_RCX + 0xa04) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b24f5;
    iVar2 = fcn.1801af910(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b24fe;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2516;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b252c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
        return 0;
    }
    iVar6 = *(int64_t *)(iVar1 + 0x5a8);
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RDI;
    iVar2 = *(int32_t *)((int64_t)&arg_40h + iVar5);
    if (iVar6 == 0) {
        uVar11 = *(uint32_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8;
        uVar13 = 0x302;
        if (uVar11 != 0) {
            uVar13 = 0xfeff;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2581;
        iVar3 = fcn.1801afd90(in_RCX, iVar2, uVar13);
        if (iVar3 < 1) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b258a;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b25a2;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                          *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5));
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b25bc;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
            return 0;
        }
        uVar13 = 0x303;
        if (uVar11 != 0) {
            uVar13 = 0xfefd;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b25e1;
        iVar3 = fcn.1801afd90(in_RCX, *(undefined4 *)((int64_t)&arg_48h + iVar5), uVar13);
        if (iVar3 < 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b25f8;
            iVar3 = fcn.180193380(in_RCX, 0x7b, uVar13, 0);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2601;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2619;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                              *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b262f;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
                return 0;
            }
        }
    }
    iVar3 = *(int32_t *)(in_RCX + 0x78);
    *(undefined8 *)((int64_t)&var_18h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R13;
    if (iVar3 == 0) {
        if ((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) {
            piVar7 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x78);
        } else {
            piVar7 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x7c);
        }
        LOCK();
        *piVar7 = *piVar7 + 1;
        UNLOCK();
        *(undefined (*) [16])(in_RCX + 0x184) = ZEXT816(0);
        *(undefined (*) [16])(in_RCX + 0x194) = ZEXT816(0);
        *(undefined4 *)(in_RCX + 0x508) = 0;
        *(undefined4 *)(in_RCX + 0x340) = 0;
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) {
            *(undefined4 *)(in_RCX + 200) = 1;
        }
code_r0x0001801b281f:
        uVar13 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2652;
        uVar13 = fcn.180193a50(in_RCX);
        iVar12 = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b265f;
        iVar3 = fcn.180222010(uVar13);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b267d;
                iVar6 = fcn.180222340(uVar13, iVar12);
                uVar11 = *(uint32_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8;
                iVar9 = 0x34;
                if (uVar11 == 0) {
                    iVar9 = 0x2c;
                }
                iVar3 = *(int32_t *)(iVar9 + iVar6);
                iVar9 = 0x38;
                if (uVar11 == 0) {
                    iVar9 = 0x30;
                }
                iVar10 = *(int32_t *)(iVar9 + iVar6);
                if (iVar2 == iVar3) {
code_r0x0001801b26ee:
                    if (iVar2 != iVar10) {
                        if (uVar11 == 0) {
                            iVar4 = 1;
                            if (iVar2 < iVar10) {
                                iVar4 = -1;
                            }
                        } else {
                            if (iVar10 == 0x100) {
                                iVar10 = 0xff00;
                            }
                            iVar3 = iVar2;
                            if (iVar2 == 0x100) {
                                iVar3 = 0xff00;
                            }
                            iVar4 = 1;
                            if (iVar10 < iVar3) {
                                iVar4 = -1;
                            }
                        }
                        if (0 < iVar4) goto code_r0x0001801b2728;
                    }
                    if ((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) {
                        LOCK();
                        piVar7 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x84);
                        *piVar7 = *piVar7 + 1;
                        UNLOCK();
                    } else {
                        LOCK();
                        piVar7 = (int32_t *)(iVar1 + 0x88);
                        *piVar7 = *piVar7 + 1;
                        UNLOCK();
                        *(undefined4 *)(in_RCX + 0x398) = 0;
                    }
                    goto code_r0x0001801b281f;
                }
                if (uVar11 == 0) {
                    iVar8 = 1;
                    if (iVar2 < iVar3) {
                        iVar8 = -1;
                    }
                } else {
                    if (iVar3 == 0x100) {
                        iVar3 = 0xff00;
                    }
                    iVar4 = iVar2;
                    if (iVar2 == 0x100) {
                        iVar4 = 0xff00;
                    }
                    iVar8 = 1;
                    if (iVar3 < iVar4) {
                        iVar8 = -1;
                    }
                }
                if (-1 < iVar8) goto code_r0x0001801b26ee;
code_r0x0001801b2728:
                iVar12 = iVar12 + 1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2732;
                iVar3 = fcn.180222010(uVar13);
            } while (iVar12 < iVar3);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b273f;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2757;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2771;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
        uVar13 = 0;
    }
    return uVar13;
}

// ============================================================
// Function: FUN_1801b263a
// Address: 0x1801b263a
// Size: 500 bytes
// ============================================================
undefined8 fcn.1801b24a0(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    int32_t iVar8;
    int64_t in_RCX;
    int64_t iVar9;
    int32_t iVar10;
    uint32_t uVar11;
    undefined8 unaff_RBP;
    int32_t iVar12;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801b24ae;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar1 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b24bd;
    iVar2 = fcn.1801db380(*(int64_t *)((int64_t)&var_10h + iVar5));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined (*) [16])(in_RCX + 0x9e8) = ZEXT816(0);
    *(undefined8 *)(in_RCX + 0x9f8) = 0;
    *(undefined4 *)(in_RCX + 0xa00) = 0;
    *(undefined *)(in_RCX + 0xa04) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b24f5;
    iVar2 = fcn.1801af910(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b24fe;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2516;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b252c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
        return 0;
    }
    iVar6 = *(int64_t *)(iVar1 + 0x5a8);
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RDI;
    iVar2 = *(int32_t *)((int64_t)&arg_40h + iVar5);
    if (iVar6 == 0) {
        uVar11 = *(uint32_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8;
        uVar13 = 0x302;
        if (uVar11 != 0) {
            uVar13 = 0xfeff;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2581;
        iVar3 = fcn.1801afd90(in_RCX, iVar2, uVar13);
        if (iVar3 < 1) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b258a;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b25a2;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                          *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5));
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b25bc;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
            return 0;
        }
        uVar13 = 0x303;
        if (uVar11 != 0) {
            uVar13 = 0xfefd;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b25e1;
        iVar3 = fcn.1801afd90(in_RCX, *(undefined4 *)((int64_t)&arg_48h + iVar5), uVar13);
        if (iVar3 < 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b25f8;
            iVar3 = fcn.180193380(in_RCX, 0x7b, uVar13, 0);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2601;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2619;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                              *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b262f;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
                return 0;
            }
        }
    }
    iVar3 = *(int32_t *)(in_RCX + 0x78);
    *(undefined8 *)((int64_t)&var_18h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R13;
    if (iVar3 == 0) {
        if ((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) {
            piVar7 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x78);
        } else {
            piVar7 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x7c);
        }
        LOCK();
        *piVar7 = *piVar7 + 1;
        UNLOCK();
        *(undefined (*) [16])(in_RCX + 0x184) = ZEXT816(0);
        *(undefined (*) [16])(in_RCX + 0x194) = ZEXT816(0);
        *(undefined4 *)(in_RCX + 0x508) = 0;
        *(undefined4 *)(in_RCX + 0x340) = 0;
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) {
            *(undefined4 *)(in_RCX + 200) = 1;
        }
code_r0x0001801b281f:
        uVar13 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2652;
        uVar13 = fcn.180193a50(in_RCX);
        iVar12 = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b265f;
        iVar3 = fcn.180222010(uVar13);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b267d;
                iVar6 = fcn.180222340(uVar13, iVar12);
                uVar11 = *(uint32_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8;
                iVar9 = 0x34;
                if (uVar11 == 0) {
                    iVar9 = 0x2c;
                }
                iVar3 = *(int32_t *)(iVar9 + iVar6);
                iVar9 = 0x38;
                if (uVar11 == 0) {
                    iVar9 = 0x30;
                }
                iVar10 = *(int32_t *)(iVar9 + iVar6);
                if (iVar2 == iVar3) {
code_r0x0001801b26ee:
                    if (iVar2 != iVar10) {
                        if (uVar11 == 0) {
                            iVar4 = 1;
                            if (iVar2 < iVar10) {
                                iVar4 = -1;
                            }
                        } else {
                            if (iVar10 == 0x100) {
                                iVar10 = 0xff00;
                            }
                            iVar3 = iVar2;
                            if (iVar2 == 0x100) {
                                iVar3 = 0xff00;
                            }
                            iVar4 = 1;
                            if (iVar10 < iVar3) {
                                iVar4 = -1;
                            }
                        }
                        if (0 < iVar4) goto code_r0x0001801b2728;
                    }
                    if ((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) {
                        LOCK();
                        piVar7 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x84);
                        *piVar7 = *piVar7 + 1;
                        UNLOCK();
                    } else {
                        LOCK();
                        piVar7 = (int32_t *)(iVar1 + 0x88);
                        *piVar7 = *piVar7 + 1;
                        UNLOCK();
                        *(undefined4 *)(in_RCX + 0x398) = 0;
                    }
                    goto code_r0x0001801b281f;
                }
                if (uVar11 == 0) {
                    iVar8 = 1;
                    if (iVar2 < iVar3) {
                        iVar8 = -1;
                    }
                } else {
                    if (iVar3 == 0x100) {
                        iVar3 = 0xff00;
                    }
                    iVar4 = iVar2;
                    if (iVar2 == 0x100) {
                        iVar4 = 0xff00;
                    }
                    iVar8 = 1;
                    if (iVar3 < iVar4) {
                        iVar8 = -1;
                    }
                }
                if (-1 < iVar8) goto code_r0x0001801b26ee;
code_r0x0001801b2728:
                iVar12 = iVar12 + 1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2732;
                iVar3 = fcn.180222010(uVar13);
            } while (iVar12 < iVar3);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b273f;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2757;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2771;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
        uVar13 = 0;
    }
    return uVar13;
}

// ============================================================
// Function: FUN_1801b282e
// Address: 0x1801b282e
// Size: 23 bytes
// ============================================================
undefined8 fcn.1801b24a0(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    int32_t iVar8;
    int64_t in_RCX;
    int64_t iVar9;
    int32_t iVar10;
    uint32_t uVar11;
    undefined8 unaff_RBP;
    int32_t iVar12;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801b24ae;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar1 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b24bd;
    iVar2 = fcn.1801db380(*(int64_t *)((int64_t)&var_10h + iVar5));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined (*) [16])(in_RCX + 0x9e8) = ZEXT816(0);
    *(undefined8 *)(in_RCX + 0x9f8) = 0;
    *(undefined4 *)(in_RCX + 0xa00) = 0;
    *(undefined *)(in_RCX + 0xa04) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b24f5;
    iVar2 = fcn.1801af910(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b24fe;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2516;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b252c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
        return 0;
    }
    iVar6 = *(int64_t *)(iVar1 + 0x5a8);
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RDI;
    iVar2 = *(int32_t *)((int64_t)&arg_40h + iVar5);
    if (iVar6 == 0) {
        uVar11 = *(uint32_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8;
        uVar13 = 0x302;
        if (uVar11 != 0) {
            uVar13 = 0xfeff;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2581;
        iVar3 = fcn.1801afd90(in_RCX, iVar2, uVar13);
        if (iVar3 < 1) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b258a;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b25a2;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                          *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5));
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b25bc;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
            return 0;
        }
        uVar13 = 0x303;
        if (uVar11 != 0) {
            uVar13 = 0xfefd;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b25e1;
        iVar3 = fcn.1801afd90(in_RCX, *(undefined4 *)((int64_t)&arg_48h + iVar5), uVar13);
        if (iVar3 < 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b25f8;
            iVar3 = fcn.180193380(in_RCX, 0x7b, uVar13, 0);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2601;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2619;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                              *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b262f;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
                return 0;
            }
        }
    }
    iVar3 = *(int32_t *)(in_RCX + 0x78);
    *(undefined8 *)((int64_t)&var_18h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R13;
    if (iVar3 == 0) {
        if ((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) {
            piVar7 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x78);
        } else {
            piVar7 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x7c);
        }
        LOCK();
        *piVar7 = *piVar7 + 1;
        UNLOCK();
        *(undefined (*) [16])(in_RCX + 0x184) = ZEXT816(0);
        *(undefined (*) [16])(in_RCX + 0x194) = ZEXT816(0);
        *(undefined4 *)(in_RCX + 0x508) = 0;
        *(undefined4 *)(in_RCX + 0x340) = 0;
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) {
            *(undefined4 *)(in_RCX + 200) = 1;
        }
code_r0x0001801b281f:
        uVar13 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2652;
        uVar13 = fcn.180193a50(in_RCX);
        iVar12 = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b265f;
        iVar3 = fcn.180222010(uVar13);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b267d;
                iVar6 = fcn.180222340(uVar13, iVar12);
                uVar11 = *(uint32_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8;
                iVar9 = 0x34;
                if (uVar11 == 0) {
                    iVar9 = 0x2c;
                }
                iVar3 = *(int32_t *)(iVar9 + iVar6);
                iVar9 = 0x38;
                if (uVar11 == 0) {
                    iVar9 = 0x30;
                }
                iVar10 = *(int32_t *)(iVar9 + iVar6);
                if (iVar2 == iVar3) {
code_r0x0001801b26ee:
                    if (iVar2 != iVar10) {
                        if (uVar11 == 0) {
                            iVar4 = 1;
                            if (iVar2 < iVar10) {
                                iVar4 = -1;
                            }
                        } else {
                            if (iVar10 == 0x100) {
                                iVar10 = 0xff00;
                            }
                            iVar3 = iVar2;
                            if (iVar2 == 0x100) {
                                iVar3 = 0xff00;
                            }
                            iVar4 = 1;
                            if (iVar10 < iVar3) {
                                iVar4 = -1;
                            }
                        }
                        if (0 < iVar4) goto code_r0x0001801b2728;
                    }
                    if ((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) {
                        LOCK();
                        piVar7 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x84);
                        *piVar7 = *piVar7 + 1;
                        UNLOCK();
                    } else {
                        LOCK();
                        piVar7 = (int32_t *)(iVar1 + 0x88);
                        *piVar7 = *piVar7 + 1;
                        UNLOCK();
                        *(undefined4 *)(in_RCX + 0x398) = 0;
                    }
                    goto code_r0x0001801b281f;
                }
                if (uVar11 == 0) {
                    iVar8 = 1;
                    if (iVar2 < iVar3) {
                        iVar8 = -1;
                    }
                } else {
                    if (iVar3 == 0x100) {
                        iVar3 = 0xff00;
                    }
                    iVar4 = iVar2;
                    if (iVar2 == 0x100) {
                        iVar4 = 0xff00;
                    }
                    iVar8 = 1;
                    if (iVar3 < iVar4) {
                        iVar8 = -1;
                    }
                }
                if (-1 < iVar8) goto code_r0x0001801b26ee;
code_r0x0001801b2728:
                iVar12 = iVar12 + 1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2732;
                iVar3 = fcn.180222010(uVar13);
            } while (iVar12 < iVar3);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b273f;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2757;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801b2771;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
        uVar13 = 0;
    }
    return uVar13;
}

// ============================================================
// Function: FUN_1801b2850
// Address: 0x1801b2850
// Size: 1131 bytes
// ============================================================
undefined8
fcn.1801b2850(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
             int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
             int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 uVar6;
    undefined8 in_RDX;
    uint64_t *puVar7;
    undefined8 in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t *piVar8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801b285f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2876;
    iVar3 = fcn.18020f800(in_RDX);
    if (iVar3 < 1) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b287f;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2897;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4));
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b28ad;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_R12;
    *(undefined4 *)((int64_t)&arg_30h + iVar4) = 0;
    *(int64_t *)((int64_t)&arg_28h + iVar4) = (int64_t)iVar3;
    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_R13;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)((int64_t)&arg_b8h + iVar4);
    *(int64_t *)((int64_t)&var_18h + iVar4) = (int64_t)iVar3;
    *(undefined8 *)((int64_t)&var_10h + iVar4) = *(undefined8 *)((int64_t)&arg_a0h + iVar4);
    *(undefined8 *)((int64_t)&var_8h + iVar4) = *(undefined8 *)((int64_t)&arg_b0h + iVar4);
    *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R14;
    *(undefined8 *)(&stack0x00000000 + iVar4) = *(undefined8 *)((int64_t)&arg_a8h + iVar4);
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b293b;
    iVar3 = fcn.1801b4180(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2944;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b295c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4));
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2972;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar4));
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2988;
        iVar3 = fcn.18020f2b0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                              *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                              *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4));
        if (((iVar3 == 0) || (*(int64_t *)((int64_t)&arg_90h + iVar4) == 0)) || (in_R9D != 0x357)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2a20;
            iVar3 = fcn.18020efa0(in_R8);
            piVar8 = *(int64_t **)((int64_t)&arg_c8h + iVar4);
            *piVar8 = (int64_t)iVar3;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2a36;
            iVar3 = fcn.18020efb0(in_R8);
            if (iVar3 == 7) {
                puVar7 = *(uint64_t **)((int64_t)&arg_d8h + iVar4);
                *puVar7 = 0xc;
                iVar5 = *(int64_t *)(in_RCX + 0x300);
                if (((iVar5 == 0) && (iVar5 = *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2f8), iVar5 == 0)) &&
                   ((*(int64_t *)(in_RCX + 0x900) == 0 ||
                    (iVar5 = *(int64_t *)(*(int64_t *)(in_RCX + 0x900) + 0x2f8), iVar5 == 0)))) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2aaf;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2ac7;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                  *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2add;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar4));
                    return 0;
                }
                uVar6 = 8;
                if ((*(uint32_t *)(iVar5 + 0x24) & 0x30000) == 0) {
                    uVar6 = 0x10;
                }
                **(undefined8 **)((int64_t)&arg_e0h + iVar4) = uVar6;
            } else {
                **(undefined8 **)((int64_t)&arg_e0h + iVar4) = 0x10;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2afc;
                iVar3 = fcn.18020ef90(in_R8);
                if (iVar3 < 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2b05;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2b1d;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                  *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2b33;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar4));
                    return 0;
                }
                puVar7 = *(uint64_t **)((int64_t)&arg_d8h + iVar4);
                *puVar7 = (int64_t)iVar3;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b29aa;
            iVar3 = fcn.18020f800();
            if (iVar3 < 1) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b29b3;
                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b29cb;
                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                              *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4));
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b29e1;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar4));
                return 0;
            }
            puVar7 = *(uint64_t **)((int64_t)&arg_d8h + iVar4);
            piVar8 = *(int64_t **)((int64_t)&arg_c8h + iVar4);
            **(uint64_t **)((int64_t)&arg_e0h + iVar4) = (int64_t)iVar3;
            *puVar7 = (int64_t)iVar3;
            *piVar8 = *(int64_t *)(in_RCX + 0x388);
        }
        piVar1 = *(int64_t **)((int64_t)&arg_d0h + iVar4);
        if (0x10 < *puVar7) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2b6d;
            iVar5 = fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
            *piVar1 = iVar5;
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2b7a;
                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2b8e;
                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                              *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4));
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2ba4;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar4));
                return 0;
            }
        }
        iVar5 = *piVar8;
        *(undefined4 *)((int64_t)&arg_30h + iVar4) = 0;
        *(int64_t *)((int64_t)&arg_28h + iVar4) = iVar5;
        *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)((int64_t)&arg_c0h + iVar4);
        *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined8 *)((int64_t)&var_8h + iVar4) = 3;
        *(undefined8 *)(&stack0x00000000 + iVar4) = 0x1804af8a8;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2bfd;
        iVar3 = fcn.1801b4180(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                              *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                              *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4));
        if (iVar3 != 0) {
            uVar2 = *puVar7;
            *(undefined4 *)((int64_t)&arg_30h + iVar4) = 0;
            *(uint64_t *)((int64_t)&arg_28h + iVar4) = uVar2;
            *(int64_t *)((int64_t)&var_20h + iVar4) = *piVar1;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
            *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 2;
            *(undefined8 *)(&stack0x00000000 + iVar4) = 0x1804af8ac;
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2c4e;
            iVar3 = fcn.1801b4180(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                  *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4));
            if (iVar3 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2c6e;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2c7c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4));
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801b2c8c;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar4));
    }
    return 0;
}

// ============================================================
// Function: FUN_1801b2cc0
// Address: 0x1801b2cc0
// Size: 39 bytes
// ============================================================
uint64_t fcn.1801b2cc0(uint64_t param_1)
{
    fcn.18045a350();
    if ((int32_t)param_1 != 0x6d) {
    // switch table (121 cases) at 0x1801d97a4
        switch((int32_t)param_1) {
        case 0:
            return 0;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
        case 0xb:
        case 0xc:
        case 0xd:
        case 0xe:
        case 0xf:
        case 0x10:
        case 0x11:
        case 0x12:
        case 0x13:
        case 0x17:
        case 0x18:
        case 0x19:
        case 0x1a:
        case 0x1b:
        case 0x1c:
        case 0x1d:
        case 0x1f:
        case 0x20:
        case 0x21:
        case 0x22:
        case 0x23:
        case 0x24:
        case 0x25:
        case 0x26:
        case 0x27:
        case 0x29:
        case 0x34:
        case 0x35:
        case 0x36:
        case 0x37:
        case 0x38:
        case 0x39:
        case 0x3a:
        case 0x3b:
        case 0x3d:
        case 0x3e:
        case 0x3f:
        case 0x40:
        case 0x41:
        case 0x42:
        case 0x43:
        case 0x44:
        case 0x45:
        case 0x48:
        case 0x49:
        case 0x4a:
        case 0x4b:
        case 0x4c:
        case 0x4d:
        case 0x4e:
        case 0x4f:
        case 0x51:
        case 0x52:
        case 0x53:
        case 0x54:
        case 0x55:
        case 0x57:
        case 0x58:
        case 0x59:
        case 0x5b:
        case 0x5c:
        case 0x5d:
        case 0x5e:
        case 0x5f:
        case 0x60:
        case 0x61:
        case 0x62:
        case 99:
        case 0x65:
        case 0x66:
        case 0x67:
        case 0x68:
        case 0x69:
        case 0x6a:
        case 0x6b:
        case 0x6c:
        case 0x75:
        case 0x76:
        case 0x77:
            return 0xffffffff;
        case 10:
            return 10;
        case 0x14:
            return 0x14;
        case 0x15:
            return 0x15;
        case 0x16:
            return 0x16;
        case 0x1e:
            return 0x1e;
        case 0x28:
        case 0x6d:
        case 0x74:
            return 0x28;
        case 0x2a:
            return 0x2a;
        case 0x2b:
            return 0x2b;
        case 0x2c:
            return 0x2c;
        case 0x2d:
            return 0x2d;
        case 0x2e:
            return 0x2e;
        case 0x2f:
            return 0x2f;
        case 0x30:
            return 0x30;
        case 0x31:
            return 0x31;
        case 0x32:
            return 0x32;
        case 0x33:
            return 0x33;
        case 0x3c:
            return 0x3c;
        case 0x46:
            return 0x46;
        case 0x47:
            return 0x47;
        case 0x50:
            return 0x50;
        case 0x56:
            return 0x56;
        case 0x5a:
            return 0x5a;
        case 100:
            return 100;
        case 0x6e:
            return 0x6e;
        case 0x6f:
            return 0x6f;
        case 0x70:
            return 0x70;
        case 0x71:
            return 0x71;
        case 0x72:
            return 0x72;
        case 0x73:
            return 0x73;
        case 0x78:
            return 0x78;
        }
    }
    return param_1 & 0xffffffff;
}

// ============================================================
// Function: FUN_1801b2cf0
// Address: 0x1801b2cf0
// Size: 2635 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_188h

void fcn.1801b2cf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_208h)
{
    undefined4 uVar1;
    code *pcVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t iVar9;
    uint32_t uVar10;
    undefined *puVar11;
    uint64_t uVar12;
    char cVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_198h;
    undefined4 var_190h;
    int64_t var_18ch;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    undefined auStack_118 [16];
    int64_t var_108h;
    int64_t var_c8h;
    int64_t var_88h;
    int64_t var_48h;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801b2d12;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar5);
    iVar8 = *(int64_t *)(in_RCX + 8);
    var_150h = (int64_t)auStack_118;
    var_138h = 0;
    var_18ch._0_4_ = 0;
    var_198h = 0;
    var_168h = 0;
    var_158h = 0;
    var_140h._0_4_ = (uint32_t)in_RDX & 1 ^ 1;
    var_170h = (int64_t)&var_c8h;
    var_180h = 0;
    var_190h = 0;
    var_130h = iVar8;
    iVar14 = 0x1804af8c8;
    var_128h = 0x10;
    cVar13 = (char)(in_RDX & 0xffffffff);
    puVar11 = auStack_118;
    if ((((uint8_t)in_RDX & 0x12) == 0x12) || (((in_RDX & 0x20) != 0 && ((in_RDX & 1) != 0)))) {
        if ((in_RDX & 0x40) == 0) {
            if (cVar13 < '\0') {
                var_138h = in_RCX + 0x674;
                unique0x00003200 = in_RCX + 0x5b4;
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3233;
                uVar6 = func_0x0001801a0380(in_RCX);
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b323b;
                var_18ch._0_4_ = fcn.18020f800(uVar6);
                if ((int32_t)var_18ch < 1) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3247;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b325f;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_18h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3275;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar5));
                    goto code_r0x0001801b3549;
                }
                var_160h = 0x1804afac8;
                iVar14 = 0x1804af8d8;
                var_170h = in_RCX + 0x734;
            } else {
                unique0x00003200 = in_RCX + 0x5f4;
                iVar14 = 0x1804af8e8;
                var_160h = 0x1804afae8;
                var_170h = in_RCX + 0x6f4;
            }
code_r0x0001801b32c5:
            var_178h = 0xc;
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b32cd;
            var_168h = func_0x0001801a0380(in_RCX);
            var_180h = *(int64_t *)(in_RCX + 0x370);
            var_158h = *(int64_t *)(in_RCX + 0x378);
            var_190h = *(undefined4 *)(in_RCX + 0x380);
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b32fd;
            iVar3 = fcn.1801da790(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                 );
            if (iVar3 == 0) goto code_r0x0001801b3549;
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b331b;
            iVar3 = func_0x000180197770(in_RCX, &var_c8h, 0x40, &var_198h);
            if (iVar3 == 0) goto code_r0x0001801b3549;
            goto code_r0x0001801b3323;
        }
        uVar6 = *(undefined8 *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2e74;
        iVar7 = func_0x00018019cae0(uVar6);
        var_178h = 0xb;
        var_160h = 0x1804afa70;
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2ea2;
        var_148h._0_4_ =
             fcn.180219d10(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                           *(int64_t *)((int64_t)&var_18h + iVar5));
        if (0 < (int32_t)var_148h) {
            if (((*(int32_t *)(in_RCX + 0xf0) == 2) && (*(int32_t *)(in_RCX + 0x1538) != 0)) &&
               (*(int32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x338) == 0)) {
                if ((*(int64_t *)(in_RCX + 0x900) == 0) ||
                   (*(int32_t *)(in_RCX + 0x1538) != *(int32_t *)(*(int64_t *)(in_RCX + 0x900) + 0x338))) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2f61;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2f79;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_18h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2f8f;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar5));
                    goto code_r0x0001801b3528;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2f1c;
                iVar7 = func_0x00018019cae0();
            }
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2f29;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2f41;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                              *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2f57;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar5));
                goto code_r0x0001801b3528;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2fa3;
            iVar3 = func_0x00018019ee60(iVar8, iVar7, &var_180h);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2fb4;
                func_0x00018019b6a0(in_RCX, 0x50);
                goto code_r0x0001801b3528;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2fc2;
            uVar4 = func_0x00018020ef80(var_180h);
            if ((uVar4 >> 0x15 & 1) == 0) {
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar5) = 0;
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2fe0;
                iVar3 = func_0x00018019ef30(iVar8, iVar7, &var_158h, &var_190h);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2ff1;
                    func_0x00018019b6a0(in_RCX, 0x50);
                    goto code_r0x0001801b3528;
                }
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2ffb;
            iVar8 = fcn.180215470();
            if (iVar8 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3008;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3020;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                              *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3036;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar5));
                goto code_r0x0001801b3528;
            }
            uVar1 = *(undefined4 *)(iVar7 + 0x40);
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3048;
            var_168h = func_0x0001801a08e0(var_130h, uVar1);
            if (var_168h == 0) {
code_r0x0001801b31cc:
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b31d1;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b31e9;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                              *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b31ff;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3207;
                fcn.180215310(iVar8);
                goto code_r0x0001801b3528;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3063;
            iVar3 = func_0x000180214880(iVar8, var_168h, 0);
            if (iVar3 == 0) goto code_r0x0001801b31cc;
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b307b;
            iVar3 = fcn.1802149b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
            if (iVar3 == 0) goto code_r0x0001801b31cc;
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3093;
            iVar3 = func_0x0001802146d0(iVar8, &var_c8h, (int64_t)&var_18ch + 4);
            if (iVar3 == 0) goto code_r0x0001801b31cc;
            var_198h = stack0xfffffffffffffe78 & 0xffffffff;
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b30aa;
            fcn.180215310(iVar8);
            uVar12 = in_RCX + 0x574;
            *(undefined4 *)((int64_t)&var_18h + iVar5) = 0;
            *(int64_t *)((int64_t)&var_10h + iVar5) = var_198h;
            *(int64_t *)((int64_t)&var_8h + iVar5) = in_RCX + 0x834;
            *(int64_t *)(&stack0x00000000 + iVar5) = var_198h;
            *(int64_t **)(&stack0xfffffffffffffff8 + iVar5) = &var_c8h;
            *(undefined8 *)(&stack0xfffffffffffffff0 + iVar5) = 0xc;
            *(undefined8 *)(&stack0xffffffffffffffe8 + iVar5) = 0x1804af938;
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3107;
            iVar3 = fcn.1801b4180(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3110;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3128;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                              *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b313e;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3143;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b315b;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                              *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3171;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar5));
                goto code_r0x0001801b3528;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b318c;
            iVar3 = func_0x000180197b70(in_RCX, 0x1804afab0, in_RCX + 0x834, var_198h);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3199;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b31b1;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                              *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b31c7;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar5));
                goto code_r0x0001801b3528;
            }
            goto code_r0x0001801b33dd;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2eae;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2ec6;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2edc;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar5));
    } else {
        if (cVar13 < '\0') {
            var_138h = in_RCX + 0x6b4;
            unique0x00003200 = in_RCX + 0x5b4;
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2dc8;
            uVar6 = func_0x0001801a0380(in_RCX);
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2dd0;
            var_18ch._0_4_ = fcn.18020f800(uVar6);
            if (0 < (int32_t)var_18ch) {
                var_160h = 0x1804afb00;
                iVar14 = 0x1804af8f8;
                goto code_r0x0001801b2e47;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2ddc;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)(&stack0xfffffffffffffff0 + iVar5)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2df4;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)(&stack0xfffffffffffffff0 + iVar5)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b2e0a;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar5));
        } else {
            iVar14 = 0x1804af908;
            stack0xfffffffffffffe78 = in_RCX + 0x5f4;
            var_160h = 0x1804afb20;
            var_170h = in_RCX + 0x6f4;
code_r0x0001801b2e47:
            var_178h = 0xc;
            if ((in_RDX & 0x40) == 0) goto code_r0x0001801b32c5;
code_r0x0001801b3323:
            iVar8 = var_198h;
            uVar12 = stack0xfffffffffffffe78;
            if (iVar14 == 0x1804af8e8) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b333f;
                func_0x0001801a0380(in_RCX);
                uVar12 = stack0xfffffffffffffe78;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0;
                *(int64_t *)((int64_t)&var_10h + iVar5) = iVar8;
                *(int64_t *)((int64_t)&var_8h + iVar5) = in_RCX + 0x634;
                *(int64_t *)(&stack0x00000000 + iVar5) = iVar8;
                *(int64_t **)(&stack0xfffffffffffffff8 + iVar5) = &var_c8h;
                *(undefined8 *)(&stack0xfffffffffffffff0 + iVar5) = 10;
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar5) = 0x1804af928;
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3394;
                iVar3 = fcn.1801b4180(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b339d;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b33b5;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_18h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b33cb;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar5));
                    goto code_r0x0001801b3522;
                }
            }
code_r0x0001801b33dd:
            iVar7 = var_168h;
            iVar8 = var_170h;
            if (var_180h != 0) {
                *(int64_t **)((int64_t)&arg_38h + iVar5) = &var_130h;
                *(int64_t **)((int64_t)&arg_30h + iVar5) = &var_128h;
                *(int64_t **)((int64_t)&arg_28h + iVar5) = &var_150h;
                *(int64_t **)((int64_t)&var_20h + iVar5) = &var_148h;
                *(int64_t **)((int64_t)&var_18h + iVar5) = &var_88h;
                *(int64_t **)((int64_t)&var_10h + iVar5) = &var_108h;
                *(int64_t *)((int64_t)&var_8h + iVar5) = var_178h;
                *(int64_t *)(&stack0x00000000 + iVar5) = iVar14;
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = iVar8;
                *(uint64_t *)(&stack0xfffffffffffffff0 + iVar5) = uVar12;
                *(int64_t *)(&stack0xffffffffffffffe8 + iVar5) = var_158h;
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b345b;
                iVar3 = fcn.1801b2850(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar5), *(int64_t *)(&stack0x00000058 + iVar5), 
                                      *(int64_t *)(&stack0x00000060 + iVar5), *(int64_t *)(&stack0x00000068 + iVar5), 
                                      *(int64_t *)(&stack0x00000070 + iVar5), *(int64_t *)(&stack0x00000078 + iVar5), 
                                      *(int64_t *)(&stack0x00000080 + iVar5), *(int64_t *)(&stack0x00000088 + iVar5), 
                                      *(int64_t *)(&stack0x00000090 + iVar5), *(int64_t *)(&stack0x00000098 + iVar5), 
                                      *(int64_t *)(&stack0x000000a0 + iVar5));
                iVar8 = var_198h;
                puVar11 = (undefined *)var_150h;
                if (iVar3 != 0) {
                    if (iVar14 == 0x1804af908) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b348a;
                        fcn.180498030(in_RCX + 0x7b4, &var_108h, var_198h);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3492;
                        func_0x0001801a0380(in_RCX);
                        iVar7 = var_170h;
                        *(undefined4 *)((int64_t)&var_18h + iVar5) = 0;
                        *(int64_t *)((int64_t)&var_10h + iVar5) = iVar8;
                        *(int64_t *)((int64_t)&var_8h + iVar5) = in_RCX + 0x7f4;
                        *(int64_t *)(&stack0x00000000 + iVar5) = iVar8;
                        *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = iVar7;
                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar5) = 10;
                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar5) = 0x1804af918;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b34e3;
                        iVar3 = fcn.1801b4180(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                              *(int64_t *)(&stack0x00000000 + iVar5), 
                                              *(int64_t *)((int64_t)&var_8h + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)((int64_t)&var_18h + iVar5));
                        if (iVar3 == 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b34f0;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3508;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)(&stack0x00000000 + iVar5), 
                                          *(int64_t *)((int64_t)&var_18h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b351e;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar5));
                            puVar11 = (undefined *)var_150h;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b35c8;
                            iVar3 = func_0x000180197b70(in_RCX, 0x1804afb38, in_RCX + 0x7f4, var_198h);
                            puVar11 = (undefined *)var_150h;
                            iVar7 = var_168h;
                            if (iVar3 != 0) goto code_r0x0001801b35ef;
                        }
                    } else {
                        if (iVar14 == 0x1804af8e8) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b35ef;
                            fcn.180498030(in_RCX + 0x774, &var_108h, var_198h);
                        }
code_r0x0001801b35ef:
                        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3603;
                        iVar3 = func_0x000180197b70(in_RCX, var_160h, &var_108h, var_198h);
                        iVar8 = var_138h;
                        puVar11 = (undefined *)var_150h;
                        if (iVar3 != 0) {
                            if (var_138h != 0) {
                                iVar9 = (int64_t)(int32_t)var_18ch;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3620;
                                uVar6 = func_0x0001801a0380(in_RCX);
                                *(int64_t *)(&stack0xffffffffffffffe8 + iVar5) = iVar9;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3637;
                                iVar3 = func_0x0001801b3740(in_RCX, uVar6, &var_108h, iVar8);
                                puVar11 = (undefined *)var_150h;
                                if (iVar3 == 0) goto code_r0x0001801b3522;
                            }
                            if ((in_RDX & 2) != 0) {
                                if ((*(int32_t *)(in_RCX + 0x78) == 0) && (iVar14 == 0x1804af8c8)) {
                                    uVar6 = *(undefined8 *)(in_RCX + 0xc80);
                                    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xc70) + 0x68);
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3672;
                                    (*pcVar2)(uVar6, 1);
                                } else {
                                    uVar6 = *(undefined8 *)(in_RCX + 0xc80);
                                    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xc70) + 0x68);
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b368b;
                                    (*pcVar2)(uVar6, 0);
                                }
                            }
                            uVar4 = (uint32_t)var_140h;
                            puVar11 = (undefined *)var_150h;
                            if ((in_RDX & 0x40) == 0) {
                                uVar10 = ~(uint32_t)((in_RDX & 0xffffffff) >> 7) & 1 | 2;
                            } else {
                                uVar10 = 1;
                            }
                            uVar1 = *(undefined4 *)(in_RCX + 0x48);
                            *(int64_t *)((int64_t)&arg_50h + iVar5) = iVar7;
                            *(undefined8 *)((int64_t)&arg_48h + iVar5) = 0;
                            *(int64_t *)((int64_t)&arg_40h + iVar5) = var_158h;
                            *(undefined4 *)((int64_t)&arg_38h + iVar5) = var_190h;
                            *(int64_t *)((int64_t)&arg_30h + iVar5) = var_130h;
                            *(int64_t *)((int64_t)&arg_28h + iVar5) = var_180h;
                            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0;
                            *(undefined8 *)((int64_t)&var_18h + iVar5) = 0;
                            *(int64_t *)((int64_t)&var_10h + iVar5) = var_128h;
                            *(int64_t *)((int64_t)&var_8h + iVar5) = var_150h;
                            *(uint64_t *)(&stack0x00000000 + iVar5) = CONCAT44(var_148h._4_4_, (int32_t)var_148h);
                            *(int64_t **)(&stack0xfffffffffffffff8 + iVar5) = &var_88h;
                            *(int64_t *)(&stack0xfffffffffffffff0 + iVar5) = var_198h;
                            *(int64_t **)(&stack0xffffffffffffffe8 + iVar5) = &var_108h;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3731;
                            func_0x0001801a4960(in_RCX, uVar1, uVar4, uVar10);
                        }
                    }
                }
            }
        }
code_r0x0001801b3522:
        if ((in_RDX & 0x40) == 0) goto code_r0x0001801b3549;
    }
code_r0x0001801b3528:
    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3531;
    uVar4 = func_0x00018020ef80(var_180h);
    if ((uVar4 >> 0x15 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3540;
        func_0x0001801975c0(var_158h);
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3549;
    func_0x0001801974e0(var_180h);
code_r0x0001801b3549:
    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b355a;
    fcn.180244fc0(&var_88h, 0x40);
    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3568;
    fcn.180244fc0(&var_108h, 0x40);
    if (puVar11 != auStack_118) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3586;
        fcn.180224990(puVar11, 0x1804af9a0, 0x300);
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1801b3597;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801b3740
// Address: 0x1801b3740
// Size: 174 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801b3740(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_68h, int64_t arg_88h)
{
    int64_t iVar1;
    uint64_t uVar2;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b3750;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_48h + iVar1) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar1) = *(undefined8 *)((int64_t)&arg_88h + iVar1);
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 8;
    *(undefined8 *)((int64_t)&var_18h + iVar1) = 0x1804af8b0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801b37a8;
    uVar2 = fcn.1801b4180(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                          *(int64_t *)((int64_t)&arg_38h + iVar1), *(int64_t *)((int64_t)&arg_40h + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
    if ((int32_t)uVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801b37b3;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801b37cb;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)((int64_t)&arg_48h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801b37e1;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar1));
        uVar2 = uVar2 & 0xffffffff;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_1801b37f0
// Address: 0x1801b37f0
// Size: 506 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_7f4h because it doesn't fit into ProtoModel

void fcn.1801b37f0(int64_t arg_28h, int64_t arg_38h, int64_t arg_78h, int64_t arg_b8h, int64_t arg_f8h, int64_t arg_158h
                  , int64_t arg_168h, int64_t arg_170h, int64_t arg_178h, int64_t arg_180h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801b380a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_f8h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar4);
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801b3838;
    iVar5 = fcn.1801a0380();
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801b3840;
    iVar6 = fcn.180215470();
    if ((iVar6 != 0) && (iVar5 != 0)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801b385f;
        iVar3 = fcn.18019b5c0(in_RCX);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801b3875;
            iVar3 = fcn.180214880(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20), 
                                  *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar4));
            if (0 < iVar3) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801b389b;
                iVar3 = fcn.1802149b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20), 
                                      *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&iStackX_20 + iVar4)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                      , *(int64_t *)((int64_t)&arg_38h + iVar4));
                if (0 < iVar3) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801b38b8;
                    iVar3 = fcn.1802146d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
                    if (0 < iVar3) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801b38ce;
                        iVar3 = fcn.180214880(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20), 
                                              *(int64_t *)(&stack0x00000030 + iVar4), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                              *(int64_t *)(&stack0x00000040 + iVar4));
                        if (0 < iVar3) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801b38e8;
                            iVar3 = fcn.1802146d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
                            if (0 < iVar3) {
                                uVar1 = *(uint32_t *)((int64_t)&arg_28h + iVar4);
                                uVar2 = *(uint32_t *)((int64_t)&arg_28h + iVar4 + 4);
                                *(undefined4 *)((int64_t)&iStackX_20 + iVar4 + -8) = 1;
                                *(uint64_t *)((int64_t)&var_10h + iVar4) = (uint64_t)uVar1;
                                *(int64_t *)((int64_t)&var_8h + iVar4) = (int64_t)&arg_b8h + iVar4;
                                *(uint64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20) = (uint64_t)uVar2;
                                *(int64_t *)(&stack0xfffffffffffffff8 + iVar4) = (int64_t)&arg_38h + iVar4;
                                *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4) =
                                     *(undefined8 *)((int64_t)&arg_168h + iVar4);
                                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar4) = in_R9;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801b3953;
                                iVar3 = fcn.1801b4180(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20), 
                                                      *(int64_t *)((int64_t)&var_8h + iVar4), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar4), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8));
                                if (iVar3 != 0) {
                                    uVar1 = *(uint32_t *)((int64_t)&arg_28h + iVar4);
                                    *(undefined4 *)((int64_t)&iStackX_20 + iVar4 + -8) = 1;
                                    *(undefined8 *)((int64_t)&var_10h + iVar4) = in_R8;
                                    *(undefined8 *)((int64_t)&var_8h + iVar4) = in_RDX;
                                    *(uint64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20) = (uint64_t)uVar1;
                                    *(int64_t *)(&stack0xfffffffffffffff8 + iVar4) = (int64_t)&arg_78h + iVar4;
                                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4) = 8;
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar4) = 0x1804af958;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801b39af;
                                    fcn.1801b4180(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar4), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar4), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8));
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801b39bd;
    fcn.180215310(iVar6);
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801b39cf;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_f8h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801b39f0
// Address: 0x1801b39f0
// Size: 579 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801b39f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h, int64_t arg_98h, int64_t arg_c8h,
                  int64_t arg_108h, int64_t arg_148h, int64_t arg_158h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    undefined4 *puVar12;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined4 *puVar13;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801b3a0c;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_148h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar9);
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801b3a2f;
    iVar10 = fcn.1801a0380();
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801b3a3a;
    uVar11 = fcn.18020f750(iVar10);
    puVar1 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_40h + iVar9) = 0;
    piVar4 = &arg_48h;
    if (iVar10 == 0) goto code_r0x0001801b3c07;
    if (puVar1[0x8c] != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801b3a7e;
        puVar12 = (undefined4 *)
                  fcn.180229e30(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                                *(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&arg_28h + iVar9), 
                                *(int64_t *)((int64_t)&arg_30h + iVar9));
        piVar4 = &arg_70h;
        uVar5 = puVar12[1];
        uVar6 = puVar12[2];
        uVar7 = puVar12[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar9) = *puVar12;
        *(undefined4 *)((int64_t)&arg_48h + iVar9 + 4) = uVar5;
        *(undefined4 *)(&stack0x00000050 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00000054 + iVar9) = uVar7;
        uVar5 = puVar12[5];
        uVar6 = puVar12[6];
        uVar7 = puVar12[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar9) = puVar12[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar9 + 4) = uVar5;
        *(undefined4 *)(&stack0x00000060 + iVar9) = uVar6;
        *(undefined4 *)(&stack0x00000064 + iVar9) = uVar7;
        *(undefined8 *)((int64_t)&arg_68h + iVar9) = *(undefined8 *)(puVar12 + 8);
    }
    puVar13 = (undefined4 *)((int64_t)piVar4 + iVar9);
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801b3ab5;
    puVar12 = (undefined4 *)fcn.180229ba0((int64_t)&arg_98h + iVar9);
    uVar5 = puVar12[1];
    uVar6 = puVar12[2];
    uVar7 = puVar12[3];
    *puVar13 = *puVar12;
    puVar13[1] = uVar5;
    puVar13[2] = uVar6;
    puVar13[3] = uVar7;
    uVar5 = puVar12[5];
    uVar6 = puVar12[6];
    uVar7 = puVar12[7];
    puVar13[4] = puVar12[4];
    puVar13[5] = uVar5;
    puVar13[6] = uVar6;
    puVar13[7] = uVar7;
    *(undefined8 *)(puVar13 + 8) = *(undefined8 *)(puVar12 + 8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801b3ae9;
    iVar8 = func_0x000180197770(in_RCX, (int64_t)&arg_108h + iVar9, 0x40, (int64_t)&arg_38h + iVar9);
    if (iVar8 != 0) {
        if (in_RDX == *(int64_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x30)) {
            in_RCX = in_RCX + 0x6b4;
        } else if ((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) {
            in_RCX = in_RCX + 0x674;
        } else {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9) = *(undefined8 *)((int64_t)&arg_38h + iVar9);
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801b3b43;
            iVar8 = fcn.1801b3740(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9)
                                  , *(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                                  *(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&arg_38h + iVar9), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar9));
            if (iVar8 == 0) goto code_r0x0001801b3bf0;
            in_RCX = (int64_t)&arg_c8h + iVar9;
        }
        uVar2 = puVar1[0x8c];
        *(int64_t *)((int64_t)&arg_30h + iVar9) = (int64_t)&arg_40h + iVar9;
        *(undefined8 *)((int64_t)&arg_28h + iVar9) = 0x80;
        *(undefined8 *)((int64_t)&var_20h + iVar9) = in_R9;
        *(undefined8 *)((int64_t)&var_18h + iVar9) = *(undefined8 *)((int64_t)&arg_38h + iVar9);
        *(int64_t *)((int64_t)&var_10h + iVar9) = (int64_t)&arg_108h + iVar9;
        *(undefined8 *)((int64_t)&var_8h + iVar9) = *(undefined8 *)((int64_t)&arg_38h + iVar9);
        *(int64_t *)(&stack0x00000000 + iVar9) = in_RCX;
        uVar3 = *puVar1;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar9) = (int64_t)&arg_48h + iVar9;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801b3bb8;
        iVar10 = func_0x0001802574e0(uVar3, 0x1804af24c, uVar2, uVar11);
        if (iVar10 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801b3bc2;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801b3bda;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                          *(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9));
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801b3bf0;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar9));
        }
    }
code_r0x0001801b3bf0:
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801b3c02;
    fcn.180244fc0((int64_t)&arg_c8h + iVar9, 0x40);
code_r0x0001801b3c07:
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801b3c17;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_148h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801b3c40
// Address: 0x1801b3c40
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801b3c40(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t in_RCX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b3c60;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801b3c78;
    fcn.1801a0380();
    *(int64_t *)((int64_t)&var_20h + iVar1) = in_RCX + 0x5b4;
    *(undefined8 *)((int64_t)&var_18h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801b3c97;
    fcn.1801b3d70(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)((int64_t)&arg_38h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar1), *(int64_t *)(&stack0x00000060 + iVar1), 
                  *(int64_t *)(&stack0x00000070 + iVar1), *(int64_t *)(&stack0x00000080 + iVar1), 
                  *(int64_t *)(&stack0x00000088 + iVar1), *(int64_t *)(&stack0x00000130 + iVar1), 
                  *(int64_t *)(&stack0x000001b0 + iVar1), *(int64_t *)(&stack0x000001b8 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801b3cc0
// Address: 0x1801b3cc0
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801b3cc0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b3cda;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b3ceb;
    uVar3 = fcn.1801a0380();
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b3cf6;
    iVar1 = fcn.18020f800(uVar3);
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b3cff;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b3d17;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b3d2d;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar2));
        uVar3 = 0;
    } else {
        *(undefined8 *)((int64_t)&var_20h + iVar2) = in_RDX;
        *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
        **(int64_t **)((int64_t)&arg_58h + iVar2) = (int64_t)iVar1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b3d5b;
        uVar3 = fcn.1801b3d70(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2), 
                              *(int64_t *)((int64_t)&arg_58h + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                              *(int64_t *)(&stack0x00000070 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2), 
                              *(int64_t *)(&stack0x00000088 + iVar2), *(int64_t *)(&stack0x00000130 + iVar2), 
                              *(int64_t *)(&stack0x000001b0 + iVar2), *(int64_t *)(&stack0x000001b8 + iVar2));
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1801b3d70
// Address: 0x1801b3d70
// Size: 811 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801b3d70(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_80h, int64_t arg_90h, int64_t arg_98h, int64_t arg_140h, int64_t arg_1c0h,
                  int64_t arg_1c8h)
{
    undefined8 uVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    int64_t aiStackX_10 [2];
    undefined4 auStackX_20 [2];
    undefined8 uStack_48;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    uStack_48 = 0x1801b3d87;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_140h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar7);
    uVar1 = *(undefined8 *)((int64_t)&arg_1c0h + iVar7);
    *(undefined8 *)((int64_t)&var_18h + iVar7) = *(undefined8 *)((int64_t)&arg_1c8h + iVar7);
    *(undefined4 *)((int64_t)&var_20h + iVar7) = 1;
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3dcd;
    fcn.18020f750(in_RDX);
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3dea;
    uVar8 = fcn.18025f200(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3df5;
    iVar9 = fcn.18025f910(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3e00;
    fcn.18025f250(uVar8);
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3e0a;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3e22;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar7));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3e38;
        fcn.18019b5e0(*(int64_t *)((int64_t)auStackX_20 + iVar7 + -0x20));
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3e47;
        iVar6 = fcn.18020f800(in_RDX);
        if (iVar6 < 1) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3e53;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3e6b;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                          *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar7));
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3e81;
            fcn.18019b5e0(*(int64_t *)((int64_t)auStackX_20 + iVar7 + -0x20));
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3e89;
            fcn.18025f7a0(iVar9);
        } else {
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3ea6;
            puVar10 = (undefined4 *)fcn.180229bc0((int64_t)&var_10h + iVar7, 0x1804a95d0, (int64_t)&var_20h + iVar7);
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)((int64_t)auStackX_20 + iVar7) = *puVar10;
            *(undefined4 *)((int64_t)auStackX_20 + iVar7 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000028 + iVar7) = uVar4;
            *(undefined4 *)(&stack0x0000002c + iVar7) = uVar5;
            uVar3 = puVar10[5];
            uVar4 = puVar10[6];
            uVar5 = puVar10[7];
            *(undefined4 *)((int64_t)&arg_30h + iVar7) = puVar10[4];
            *(undefined4 *)((int64_t)&arg_30h + iVar7 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000038 + iVar7) = uVar4;
            *(undefined4 *)(&stack0x0000003c + iVar7) = uVar5;
            *(undefined8 *)((int64_t)&arg_40h + iVar7) = *(undefined8 *)(puVar10 + 8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3edc;
            puVar10 = (undefined4 *)
                      fcn.180229e30(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                                    *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)aiStackX_10 + iVar7)
                                    , *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 8));
            piVar2 = &arg_70h;
            uVar3 = puVar10[1];
            uVar4 = puVar10[2];
            uVar5 = puVar10[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar10;
            *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000050 + iVar7) = uVar4;
            *(undefined4 *)(&stack0x00000054 + iVar7) = uVar5;
            uVar3 = puVar10[5];
            uVar4 = puVar10[6];
            uVar5 = puVar10[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar10[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000060 + iVar7) = uVar4;
            *(undefined4 *)(&stack0x00000064 + iVar7) = uVar5;
            *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar10 + 8);
            if (in_R9 != 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3f25;
                puVar10 = (undefined4 *)fcn.180229c70((int64_t)&var_10h + iVar7, 0x1804af9b0, in_R9, uVar1);
                piVar2 = &arg_98h;
                uVar3 = puVar10[1];
                uVar4 = puVar10[2];
                uVar5 = puVar10[3];
                *(undefined4 *)((int64_t)&arg_70h + iVar7) = *puVar10;
                *(undefined4 *)((int64_t)&arg_70h + iVar7 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000078 + iVar7) = uVar4;
                *(undefined4 *)(&stack0x0000007c + iVar7) = uVar5;
                uVar3 = puVar10[5];
                uVar4 = puVar10[6];
                uVar5 = puVar10[7];
                *(undefined4 *)((int64_t)&arg_80h + iVar7) = puVar10[4];
                *(undefined4 *)((int64_t)&arg_80h + iVar7 + 4) = uVar3;
                *(undefined4 *)(&stack0x00000088 + iVar7) = uVar4;
                *(undefined4 *)(&stack0x0000008c + iVar7) = uVar5;
                *(undefined8 *)((int64_t)&arg_90h + iVar7) = *(undefined8 *)(puVar10 + 8);
            }
            puVar10 = (undefined4 *)((int64_t)piVar2 + iVar7);
            if (in_R8 != 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3f6e;
                puVar11 = (undefined4 *)fcn.180229c70((int64_t)&var_10h + iVar7, 0x1804afa00, in_R8, (int64_t)iVar6);
                uVar3 = puVar11[1];
                uVar4 = puVar11[2];
                uVar5 = puVar11[3];
                *puVar10 = *puVar11;
                puVar10[1] = uVar3;
                puVar10[2] = uVar4;
                puVar10[3] = uVar5;
                uVar3 = puVar11[5];
                uVar4 = puVar11[6];
                uVar5 = puVar11[7];
                puVar10[4] = puVar11[4];
                puVar10[5] = uVar3;
                puVar10[6] = uVar4;
                puVar10[7] = uVar5;
                *(undefined8 *)(puVar10 + 8) = *(undefined8 *)(puVar11 + 8);
                puVar10 = puVar10 + 10;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3fa8;
            puVar11 = (undefined4 *)fcn.180229c70((int64_t)&var_10h + iVar7, 0x1804af9b4, 0x1804af8a0, 6);
            uVar3 = puVar11[1];
            uVar4 = puVar11[2];
            uVar5 = puVar11[3];
            *puVar10 = *puVar11;
            puVar10[1] = uVar3;
            puVar10[2] = uVar4;
            puVar10[3] = uVar5;
            uVar3 = puVar11[5];
            uVar4 = puVar11[6];
            uVar5 = puVar11[7];
            puVar10[4] = puVar11[4];
            puVar10[5] = uVar3;
            puVar10[6] = uVar4;
            puVar10[7] = uVar5;
            *(undefined8 *)(puVar10 + 8) = *(undefined8 *)(puVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b3fde;
            puVar11 = (undefined4 *)fcn.180229c70((int64_t)&var_10h + iVar7, 0x1804af9bc, 0x1804af8c0, 7);
            uVar3 = puVar11[1];
            uVar4 = puVar11[2];
            uVar5 = puVar11[3];
            puVar10[10] = *puVar11;
            puVar10[0xb] = uVar3;
            puVar10[0xc] = uVar4;
            puVar10[0xd] = uVar5;
            uVar3 = puVar11[5];
            uVar4 = puVar11[6];
            uVar5 = puVar11[7];
            puVar10[0xe] = puVar11[4];
            puVar10[0xf] = uVar3;
            puVar10[0x10] = uVar4;
            puVar10[0x11] = uVar5;
            *(undefined8 *)(puVar10 + 0x12) = *(undefined8 *)(puVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b4001;
            puVar11 = (undefined4 *)fcn.180229ba0((int64_t)&var_10h + iVar7);
            uVar1 = *(undefined8 *)((int64_t)&var_18h + iVar7);
            uVar3 = puVar11[1];
            uVar4 = puVar11[2];
            uVar5 = puVar11[3];
            puVar10[0x14] = *puVar11;
            puVar10[0x15] = uVar3;
            puVar10[0x16] = uVar4;
            puVar10[0x17] = uVar5;
            uVar3 = puVar11[5];
            uVar4 = puVar11[6];
            uVar5 = puVar11[7];
            puVar10[0x18] = puVar11[4];
            puVar10[0x19] = uVar3;
            puVar10[0x1a] = uVar4;
            puVar10[0x1b] = uVar5;
            *(undefined8 *)(puVar10 + 0x1c) = *(undefined8 *)(puVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b402f;
            iVar6 = fcn.18025fa30(iVar9, uVar1, (int64_t)iVar6, (int64_t)auStackX_20 + iVar7);
            if (iVar6 < 1) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b403a;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b4052;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar7));
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b4068;
                fcn.18019b5e0(*(int64_t *)((int64_t)auStackX_20 + iVar7 + -0x20));
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b4070;
            fcn.18025f7a0(iVar9);
        }
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801b4087;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_140h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801b40a0
// Address: 0x1801b40a0
// Size: 212 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801b40a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_68h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h,
                      int64_t arg_a8h, int64_t arg_b0h, int64_t arg_120h)
{
    int64_t iVar1;
    uint64_t uVar2;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b40b0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(uint32_t *)((int64_t)&arg_48h + iVar1) = (uint32_t)(*(int32_t *)((int64_t)&arg_b0h + iVar1) == 0);
    *(undefined8 *)((int64_t)&arg_40h + iVar1) = *(undefined8 *)((int64_t)&arg_a8h + iVar1);
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = *(undefined8 *)((int64_t)&arg_a0h + iVar1);
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = *(undefined8 *)((int64_t)&arg_98h + iVar1);
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = *(undefined8 *)((int64_t)&arg_90h + iVar1);
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_88h + iVar1);
    *(undefined8 *)((int64_t)&var_18h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801b4125;
    uVar2 = fcn.1801b4180(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                          *(int64_t *)((int64_t)&arg_38h + iVar1), *(int64_t *)((int64_t)&arg_40h + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (((int32_t)uVar2 == 0) && (*(int32_t *)((int64_t)&arg_b0h + iVar1) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801b4139;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801b4151;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)((int64_t)&arg_48h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801b4167;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar1));
        uVar2 = uVar2 & 0xffffffff;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_1801b4180
// Address: 0x1801b4180
// Size: 806 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801b4180(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    int64_t *piVar14;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t aiStackX_10 [3];
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_140h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_118h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f0h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined4 uStack_a8;
    undefined4 uStack_a4;
    int64_t var_a0h;
    undefined4 uStack_98;
    undefined4 uStack_94;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_58h;
    undefined8 uStack_48;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_48 = 0x1801b419f;
    iVar9 = fcn.18045a350();
    iVar7 = arg_48h;
    iVar6 = arg_40h;
    iVar5 = arg_38h;
    iVar4 = arg_30h;
    iVar9 = -iVar9;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar9);
    *(undefined8 *)((int64_t)&var_10h + iVar9) = in_R9;
    *(int64_t *)((int64_t)&var_8h + iVar9) = arg_28h;
    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b41f2;
    uVar10 = fcn.18025f200(*(int64_t *)((int64_t)&var_20h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9));
    *(undefined4 *)((int64_t)&var_20h + iVar9) = 2;
    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b4205;
    uVar11 = fcn.18020f750(in_R8);
    *(undefined8 *)((int64_t)&var_18h + iVar9) = uVar11;
    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b4212;
    iVar12 = fcn.18025f910(*(int64_t *)((int64_t)&var_20h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9));
    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b421d;
    fcn.18025f250(uVar10);
    if (iVar12 != 0) {
        if ((uint64_t)iVar4 < 0xfa) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b4298;
            iVar8 = fcn.18020f800(in_R8);
            if (iVar8 < 1) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b42a7;
                fcn.18025f7a0(iVar12);
                if ((int32_t)arg_58h != 0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b42b5;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b42cd;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar9));
                    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b42df;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar9 + -0x10));
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b42f7;
                puVar13 = (undefined4 *)
                          fcn.180229bc0((int64_t)aiStackX_10 + iVar9 + -0x10, 0x1804a95d0, (int64_t)&var_20h + iVar9);
                uVar1 = puVar13[1];
                uVar2 = puVar13[2];
                uVar3 = puVar13[3];
                *(undefined4 *)((int64_t)&arg_30h + iVar9) = *puVar13;
                *(undefined4 *)((int64_t)&arg_30h + iVar9 + 4) = uVar1;
                *(undefined4 *)((int64_t)&arg_38h + iVar9) = uVar2;
                *(undefined4 *)((int64_t)&arg_38h + iVar9 + 4) = uVar3;
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b432a;
                fcn.180229e30(*(int64_t *)((int64_t)&var_20h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                              *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)aiStackX_10 + iVar9), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar9 + 8));
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b435c;
                fcn.180229c70((int64_t)aiStackX_10 + iVar9 + -0x10, 0x1804af9b0, 
                              *(undefined8 *)((int64_t)&var_10h + iVar9), (int64_t)iVar8);
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b4393;
                fcn.180229c70((int64_t)aiStackX_10 + iVar9 + -0x10, 0x1804af9b4, 0x1804af8a0, 6);
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b43c5;
                fcn.180229c70((int64_t)aiStackX_10 + iVar9 + -0x10, 0x1804af9bc, 
                              *(undefined8 *)((int64_t)&var_8h + iVar9), iVar4);
                piVar14 = &var_b0h;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b43fe;
                    puVar13 = (undefined4 *)
                              fcn.180229c70((int64_t)aiStackX_10 + iVar9 + -0x10, 0x1804af9c4, iVar5, iVar6);
                    piVar14 = &var_88h;
                    var_b0h._0_4_ = *puVar13;
                    var_b0h._4_4_ = puVar13[1];
                    uStack_a8 = puVar13[2];
                    uStack_a4 = puVar13[3];
                    var_a0h._0_4_ = puVar13[4];
                    var_a0h._4_4_ = puVar13[5];
                    uStack_98 = puVar13[6];
                    uStack_94 = puVar13[7];
                    var_90h = *(int64_t *)(puVar13 + 8);
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b4425;
                puVar13 = (undefined4 *)fcn.180229ba0((int64_t)aiStackX_10 + iVar9 + -0x10);
                uVar1 = puVar13[1];
                uVar2 = puVar13[2];
                uVar3 = puVar13[3];
                *(undefined4 *)piVar14 = *puVar13;
                *(undefined4 *)((int64_t)piVar14 + 4) = uVar1;
                *(undefined4 *)(piVar14 + 1) = uVar2;
                *(undefined4 *)((int64_t)piVar14 + 0xc) = uVar3;
                uVar1 = puVar13[5];
                uVar2 = puVar13[6];
                uVar3 = puVar13[7];
                *(undefined4 *)(piVar14 + 2) = puVar13[4];
                *(undefined4 *)((int64_t)piVar14 + 0x14) = uVar1;
                *(undefined4 *)(piVar14 + 3) = uVar2;
                *(undefined4 *)((int64_t)piVar14 + 0x1c) = uVar3;
                piVar14[4] = *(int64_t *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b4454;
                iVar8 = fcn.18025fa30(iVar12, iVar7, arg_50h, (int64_t)&arg_30h + iVar9);
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b445e;
                fcn.18025f7a0(iVar12);
                if ((iVar8 < 1) && ((int32_t)arg_58h != 0)) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b4470;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b4488;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar9));
                    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b449a;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar9 + -0x10));
                }
            }
        } else {
            if ((int32_t)arg_58h != 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b4239;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9));
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b4251;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                              *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar9));
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b4263;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar9 + -0x10));
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b426b;
            fcn.18025f7a0(iVar12);
        }
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801b427c;
    fcn.180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801b44b0
// Address: 0x1801b44b0
// Size: 211 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8
fcn.1801b44b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b44bc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined4 *)((int64_t)&arg_30h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
    iVar1 = *(int64_t *)(in_RCX + 0x8f8);
    uVar2 = *(undefined8 *)(in_RCX + 0x300);
    *(undefined4 *)((int64_t)&arg_48h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = 0;
    *(undefined8 *)(iVar1 + 0x2f8) = uVar2;
    *(int64_t *)((int64_t)&var_20h + iVar4) = (int64_t)&arg_50h + iVar4;
    *(int64_t *)((int64_t)&var_18h + iVar4) = (int64_t)&arg_48h + iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b4519;
    iVar3 = fcn.18019eb60(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4), *(int64_t *)(&stack0x00000070 + iVar4), 
                          *(int64_t *)(&stack0x000000d8 + iVar4));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b452a;
        fcn.18019b6a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        return 0;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x370);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b453e;
    fcn.1801974e0(uVar2);
    uVar2 = *(undefined8 *)(in_RCX + 0x378);
    *(undefined8 *)(in_RCX + 0x370) = *(undefined8 *)((int64_t)&arg_58h + iVar4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801b4556;
    fcn.1801975c0(uVar2);
    *(undefined8 *)(in_RCX + 0x378) = *(undefined8 *)((int64_t)&arg_60h + iVar4);
    *(undefined4 *)(in_RCX + 0x380) = *(undefined4 *)((int64_t)&arg_48h + iVar4);
    *(undefined8 *)(in_RCX + 0x388) = *(undefined8 *)((int64_t)&arg_50h + iVar4);
    return 1;
}

// ============================================================
// Function: FUN_1801b4590
// Address: 0x1801b4590
// Size: 81 bytes
// ============================================================
undefined8 fcn.1801b4590(int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b459c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b45ac;
    iVar1 = fcn.1801da790(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b45ca;
        iVar1 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar2));
        if (iVar1 != 0) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801b45f0
// Address: 0x1801b45f0
// Size: 81 bytes
// ============================================================
undefined8 fcn.1801b45f0(int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801b45fc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b460c;
    iVar1 = fcn.1801da790(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801b462a;
        iVar1 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar2));
        if (iVar1 != 0) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801b4650
// Address: 0x1801b4650
// Size: 279 bytes
// ============================================================
void fcn.1801b4650(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_98h, int64_t arg_d8h, int64_t arg_118h, int64_t arg_168h,
                  int64_t arg_170h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RSI;
    undefined8 unaff_R12;
    int64_t iVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801b4662;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_118h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b4681;
    uVar6 = fcn.1801a0380();
    *(int64_t *)((int64_t)&arg_68h + iVar5) = (int64_t)&arg_88h + iVar5;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b469e;
    iVar4 = fcn.18020f800(uVar6);
    iVar8 = (int64_t)iVar4;
    if (iVar4 < 1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b46aa;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b46c2;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b46d8;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar5));
    } else {
        iVar4 = *(int32_t *)(in_RCX + 0x78);
        *(int64_t *)((int64_t)&arg_48h + iVar5) = (int64_t)&arg_70h + iVar5;
        *(int64_t *)((int64_t)&arg_40h + iVar5) = (int64_t)&arg_78h + iVar5;
        *(int64_t *)((int64_t)&arg_38h + iVar5) = (int64_t)&arg_68h + iVar5;
        *(int64_t *)((int64_t)&arg_30h + iVar5) = (int64_t)&arg_80h + iVar5;
        *(int64_t *)((int64_t)&arg_28h + iVar5) = (int64_t)&arg_d8h + iVar5;
        *(int64_t *)((int64_t)&var_20h + iVar5) = (int64_t)&arg_98h + iVar5;
        *(undefined8 *)((int64_t)&var_18h + iVar5) = 0xb;
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804af948;
        uVar2 = *(undefined8 *)(in_RCX + 0x378);
        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
        *(undefined8 *)((int64_t)&arg_168h + iVar5) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_170h + iVar5) = unaff_R12;
        iVar7 = 0x7b4;
        if (iVar4 != in_EDX) {
            iVar7 = 0x774;
        }
        iVar7 = iVar7 + in_RCX;
        *(int64_t *)(&stack0x00000000 + iVar5) = iVar7;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b4796;
        iVar4 = fcn.1801b2850(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                              *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar5), 
                              *(int64_t *)((int64_t)&arg_60h + iVar5), *(int64_t *)((int64_t)&arg_68h + iVar5), 
                              *(int64_t *)((int64_t)&arg_70h + iVar5), *(int64_t *)((int64_t)&arg_78h + iVar5), 
                              *(int64_t *)((int64_t)&arg_80h + iVar5), *(int64_t *)((int64_t)&arg_88h + iVar5), 
                              *(int64_t *)(&stack0x00000090 + iVar5), *(int64_t *)((int64_t)&arg_98h + iVar5), 
                              *(int64_t *)(&stack0x000000a0 + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                              *(int64_t *)(&stack0x000000b0 + iVar5));
        iVar3 = *(int64_t *)((int64_t)&arg_68h + iVar5);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b47b9;
            fcn.180498030(iVar7, (int64_t)&arg_98h + iVar5, iVar8);
            uVar1 = *(undefined4 *)(in_RCX + 0x48);
            *(undefined8 *)((int64_t)&arg_60h + iVar5) = uVar6;
            *(undefined8 *)((int64_t)&arg_58h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = 0;
            *(undefined4 *)((int64_t)&arg_48h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = *(undefined8 *)((int64_t)&arg_70h + iVar5);
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = *(undefined8 *)(in_RCX + 0x370);
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar5) = *(undefined8 *)((int64_t)&arg_78h + iVar5);
            *(int64_t *)((int64_t)&var_18h + iVar5) = iVar3;
            *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)((int64_t)&arg_80h + iVar5);
            *(int64_t *)((int64_t)&var_8h + iVar5) = (int64_t)&arg_d8h + iVar5;
            *(int64_t *)(&stack0x00000000 + iVar5) = iVar8;
            *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = iVar7;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b4845;
            iVar4 = func_0x0001801a4960(in_RCX, uVar1, in_EDX != 0, 3);
            if (iVar4 != 0) {
                uVar6 = 0x1804afb60;
                if (*(int32_t *)(in_RCX + 0x78) != in_EDX) {
                    uVar6 = 0x1804afb78;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b4871;
                func_0x000180197b70(in_RCX, uVar6, (int64_t)&arg_98h + iVar5, iVar8);
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b488d;
        fcn.180244fc0((int64_t)&arg_d8h + iVar5, 0x40);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b489f;
        fcn.180244fc0((int64_t)&arg_98h + iVar5, 0x40);
        if (iVar3 != (int64_t)&arg_88h + iVar5) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b48c9;
            fcn.180224990(iVar3, 0x1804af9a0, 0x342);
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b48e3;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_118h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801b4767
// Address: 0x1801b4767
// Size: 8 bytes
// ============================================================
void fcn.1801b4650(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_98h, int64_t arg_d8h, int64_t arg_118h, int64_t arg_168h,
                  int64_t arg_170h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RSI;
    undefined8 unaff_R12;
    int64_t iVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801b4662;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_118h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b4681;
    uVar6 = fcn.1801a0380();
    *(int64_t *)((int64_t)&arg_68h + iVar5) = (int64_t)&arg_88h + iVar5;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b469e;
    iVar4 = fcn.18020f800(uVar6);
    iVar8 = (int64_t)iVar4;
    if (iVar4 < 1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b46aa;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b46c2;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b46d8;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar5));
    } else {
        iVar4 = *(int32_t *)(in_RCX + 0x78);
        *(int64_t *)((int64_t)&arg_48h + iVar5) = (int64_t)&arg_70h + iVar5;
        *(int64_t *)((int64_t)&arg_40h + iVar5) = (int64_t)&arg_78h + iVar5;
        *(int64_t *)((int64_t)&arg_38h + iVar5) = (int64_t)&arg_68h + iVar5;
        *(int64_t *)((int64_t)&arg_30h + iVar5) = (int64_t)&arg_80h + iVar5;
        *(int64_t *)((int64_t)&arg_28h + iVar5) = (int64_t)&arg_d8h + iVar5;
        *(int64_t *)((int64_t)&var_20h + iVar5) = (int64_t)&arg_98h + iVar5;
        *(undefined8 *)((int64_t)&var_18h + iVar5) = 0xb;
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804af948;
        uVar2 = *(undefined8 *)(in_RCX + 0x378);
        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
        *(undefined8 *)((int64_t)&arg_168h + iVar5) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_170h + iVar5) = unaff_R12;
        iVar7 = 0x7b4;
        if (iVar4 != in_EDX) {
            iVar7 = 0x774;
        }
        iVar7 = iVar7 + in_RCX;
        *(int64_t *)(&stack0x00000000 + iVar5) = iVar7;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b4796;
        iVar4 = fcn.1801b2850(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                              *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar5), 
                              *(int64_t *)((int64_t)&arg_60h + iVar5), *(int64_t *)((int64_t)&arg_68h + iVar5), 
                              *(int64_t *)((int64_t)&arg_70h + iVar5), *(int64_t *)((int64_t)&arg_78h + iVar5), 
                              *(int64_t *)((int64_t)&arg_80h + iVar5), *(int64_t *)((int64_t)&arg_88h + iVar5), 
                              *(int64_t *)(&stack0x00000090 + iVar5), *(int64_t *)((int64_t)&arg_98h + iVar5), 
                              *(int64_t *)(&stack0x000000a0 + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                              *(int64_t *)(&stack0x000000b0 + iVar5));
        iVar3 = *(int64_t *)((int64_t)&arg_68h + iVar5);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b47b9;
            fcn.180498030(iVar7, (int64_t)&arg_98h + iVar5, iVar8);
            uVar1 = *(undefined4 *)(in_RCX + 0x48);
            *(undefined8 *)((int64_t)&arg_60h + iVar5) = uVar6;
            *(undefined8 *)((int64_t)&arg_58h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = 0;
            *(undefined4 *)((int64_t)&arg_48h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = *(undefined8 *)((int64_t)&arg_70h + iVar5);
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = *(undefined8 *)(in_RCX + 0x370);
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar5) = *(undefined8 *)((int64_t)&arg_78h + iVar5);
            *(int64_t *)((int64_t)&var_18h + iVar5) = iVar3;
            *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)((int64_t)&arg_80h + iVar5);
            *(int64_t *)((int64_t)&var_8h + iVar5) = (int64_t)&arg_d8h + iVar5;
            *(int64_t *)(&stack0x00000000 + iVar5) = iVar8;
            *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = iVar7;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b4845;
            iVar4 = func_0x0001801a4960(in_RCX, uVar1, in_EDX != 0, 3);
            if (iVar4 != 0) {
                uVar6 = 0x1804afb60;
                if (*(int32_t *)(in_RCX + 0x78) != in_EDX) {
                    uVar6 = 0x1804afb78;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b4871;
                func_0x000180197b70(in_RCX, uVar6, (int64_t)&arg_98h + iVar5, iVar8);
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b488d;
        fcn.180244fc0((int64_t)&arg_d8h + iVar5, 0x40);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b489f;
        fcn.180244fc0((int64_t)&arg_98h + iVar5, 0x40);
        if (iVar3 != (int64_t)&arg_88h + iVar5) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b48c9;
            fcn.180224990(iVar3, 0x1804af9a0, 0x342);
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801b48e3;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_118h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5));
    return;
}

