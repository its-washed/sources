// Chunk 37 - 50 functions

// ============================================================
// Function: FUN_180084d80
// Address: 0x180084d80
// Size: 42 bytes
// ============================================================
void fcn.180084d80(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t in_stack_00000008;
    
    fcn.180084f60(in_stack_00000008);
    if ((*(int64_t *)arg1 != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_180084db0
// Address: 0x180084db0
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180084db0(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 0x178);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        piVar4 = *(int64_t **)(arg1 + 0x168);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x130));
            *(undefined8 *)(arg1 + 0x168) = 0;
        }
        piVar4 = *(int64_t **)(arg1 + 0x120);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0xe8));
            *(undefined8 *)(arg1 + 0x120) = 0;
        }
        piVar4 = *(int64_t **)(arg1 + 0xd8);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0xa0));
            *(undefined8 *)(arg1 + 0xd8) = 0;
        }
        piVar4 = *(int64_t **)(arg1 + 0x90);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x58));
            *(undefined8 *)(arg1 + 0x90) = 0;
        }
        piVar4 = *(int64_t **)(arg1 + 0x48);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x10));
            *(undefined8 *)(arg1 + 0x48) = 0;
        }
        fcn.180459c3c(arg1, 400);
    }
    return;
}

// ============================================================
// Function: FUN_180084dc2
// Address: 0x180084dc2
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180084db0(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 0x178);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        piVar4 = *(int64_t **)(arg1 + 0x168);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x130));
            *(undefined8 *)(arg1 + 0x168) = 0;
        }
        piVar4 = *(int64_t **)(arg1 + 0x120);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0xe8));
            *(undefined8 *)(arg1 + 0x120) = 0;
        }
        piVar4 = *(int64_t **)(arg1 + 0xd8);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0xa0));
            *(undefined8 *)(arg1 + 0xd8) = 0;
        }
        piVar4 = *(int64_t **)(arg1 + 0x90);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x58));
            *(undefined8 *)(arg1 + 0x90) = 0;
        }
        piVar4 = *(int64_t **)(arg1 + 0x48);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x10));
            *(undefined8 *)(arg1 + 0x48) = 0;
        }
        fcn.180459c3c(arg1, 400);
    }
    return;
}

// ============================================================
// Function: FUN_180084eb7
// Address: 0x180084eb7
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180084db0(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 0x178);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        piVar4 = *(int64_t **)(arg1 + 0x168);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x130));
            *(undefined8 *)(arg1 + 0x168) = 0;
        }
        piVar4 = *(int64_t **)(arg1 + 0x120);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0xe8));
            *(undefined8 *)(arg1 + 0x120) = 0;
        }
        piVar4 = *(int64_t **)(arg1 + 0xd8);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0xa0));
            *(undefined8 *)(arg1 + 0xd8) = 0;
        }
        piVar4 = *(int64_t **)(arg1 + 0x90);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x58));
            *(undefined8 *)(arg1 + 0x90) = 0;
        }
        piVar4 = *(int64_t **)(arg1 + 0x48);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x10));
            *(undefined8 *)(arg1 + 0x48) = 0;
        }
        fcn.180459c3c(arg1, 400);
    }
    return;
}

// ============================================================
// Function: FUN_180084ec0
// Address: 0x180084ec0
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180084ec0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x40) {
            fcn.180004e40(iVar3 + 0x20);
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffc0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180084f3f;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180084ed5
// Address: 0x180084ed5
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180084ec0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x40) {
            fcn.180004e40(iVar3 + 0x20);
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffc0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180084f3f;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180084f19
// Address: 0x180084f19
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180084ec0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x40) {
            fcn.180004e40(iVar3 + 0x20);
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffc0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180084f3f;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180084f60
// Address: 0x180084f60
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180084f60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    char cVar1;
    int64_t *piVar2;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.180084f60(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RSI);
        piVar2 = *(int64_t **)arg3;
        fcn.1801702c0((int64_t *)(arg3 + 0x40));
        fcn.180004e40((int64_t *)(arg3 + 0x20));
        fcn.180459c3c(arg3, 0x88);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_180084f80
// Address: 0x180084f80
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180084f60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    char cVar1;
    int64_t *piVar2;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.180084f60(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RSI);
        piVar2 = *(int64_t **)arg3;
        fcn.1801702c0((int64_t *)(arg3 + 0x40));
        fcn.180004e40((int64_t *)(arg3 + 0x20));
        fcn.180459c3c(arg3, 0x88);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_180084fd4
// Address: 0x180084fd4
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180084f60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    char cVar1;
    int64_t *piVar2;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.180084f60(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RSI);
        piVar2 = *(int64_t **)arg3;
        fcn.1801702c0((int64_t *)(arg3 + 0x40));
        fcn.180004e40((int64_t *)(arg3 + 0x20));
        fcn.180459c3c(arg3, 0x88);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_180084ff0
// Address: 0x180084ff0
// Size: 352 bytes
// ============================================================
int64_t fcn.180084ff0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined *puVar6;
    int64_t iVar7;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    
    puVar6 = auStack_58;
    iVar7 = *(int64_t *)arg1;
    if (iVar7 != 0) {
        iVar3 = *(int64_t *)(arg1 + 8);
        for (; iVar7 != iVar3; iVar7 = iVar7 + 0x90) {
            iVar5 = *(int64_t *)(iVar7 + 0x78);
            if (iVar5 != 0) {
                iVar1 = *(int64_t *)(iVar7 + 0x80);
                for (; iVar5 != iVar1; iVar5 = iVar5 + 0x40) {
                    fcn.180004e40(iVar5 + 0x20);
                    fcn.180004e40(iVar5);
                }
                iVar5 = *(int64_t *)(iVar7 + 0x78);
                uVar4 = *(int64_t *)(iVar7 + 0x88) - iVar5 & 0xffffffffffffffc0;
                if (0xfff < uVar4) {
                    if (0x1f < (iVar5 - *(int64_t *)(iVar5 + -8)) - 8U) goto code_r0x00018008510e;
                    uVar4 = uVar4 + 0x27;
                    iVar5 = *(int64_t *)(iVar5 + -8);
                }
                fcn.180459c3c(iVar5, uVar4);
                *(undefined8 *)(iVar7 + 0x78) = 0;
                *(undefined8 *)(iVar7 + 0x80) = 0;
                *(undefined8 *)(iVar7 + 0x88) = 0;
            }
            fcn.180004e40(iVar7 + 0x40);
            fcn.180004e40(iVar7 + 0x20);
            fcn.180004e40(iVar7);
        }
        iVar7 = *(int64_t *)arg1;
        iVar3 = iVar7;
        puVar6 = auStack_58;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 4) << 4)) &&
           (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_58, 0x1f < (iVar7 - iVar3) - 8U)) {
code_r0x00018008510e:
            iVar3 = 5;
            pcVar2 = (code *)swi(0x29);
            (*pcVar2)(5);
            puVar6 = auStack_50;
        }
        *(undefined8 *)(puVar6 + -8) = 0x180085120;
        fcn.180459c3c(iVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    if ((arg2 & 1U) != 0) {
        *(undefined8 *)(puVar6 + -8) = 0x18008513e;
        fcn.180459c3c(arg1, 0x18);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180085150
// Address: 0x180085150
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180085150(int64_t arg1, int64_t arg_50h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined *puVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    int64_t var_18h;
    
    iVar7 = *(int64_t *)arg1;
    if (iVar7 != 0) {
        iVar3 = *(int64_t *)(arg1 + 8);
        for (; iVar7 != iVar3; iVar7 = iVar7 + 0x90) {
            iVar5 = *(int64_t *)(iVar7 + 0x78);
            if (iVar5 != 0) {
                iVar1 = *(int64_t *)(iVar7 + 0x80);
                for (; iVar5 != iVar1; iVar5 = iVar5 + 0x40) {
                    fcn.180004e40(iVar5 + 0x20);
                    fcn.180004e40(iVar5);
                }
                iVar5 = *(int64_t *)(iVar7 + 0x78);
                uVar4 = *(int64_t *)(iVar7 + 0x88) - iVar5 & 0xffffffffffffffc0;
                if (0xfff < uVar4) {
                    if (0x1f < (iVar5 - *(int64_t *)(iVar5 + -8)) - 8U) goto code_r0x00018008527d;
                    uVar4 = uVar4 + 0x27;
                    iVar5 = *(int64_t *)(iVar5 + -8);
                }
                fcn.180459c3c(iVar5, uVar4);
                *(undefined8 *)(iVar7 + 0x78) = 0;
                *(undefined8 *)(iVar7 + 0x80) = 0;
                *(undefined8 *)(iVar7 + 0x88) = 0;
            }
            fcn.180004e40(iVar7 + 0x40);
            fcn.180004e40(iVar7 + 0x20);
            fcn.180004e40(iVar7);
        }
        iVar7 = *(int64_t *)arg1;
        iVar3 = iVar7;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 4) << 4)) &&
           (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_38, 0x1f < (iVar7 - iVar3) - 8U)) {
code_r0x00018008527d:
            iVar3 = 5;
            pcVar2 = (code *)swi(0x29);
            (*pcVar2)(5);
            puVar6 = auStack_30;
        }
        *(undefined8 *)(puVar6 + -8) = 0x18008528f;
        fcn.180459c3c(iVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180085167
// Address: 0x180085167
// Size: 327 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180085150(int64_t arg1, int64_t arg_50h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined *puVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    int64_t var_18h;
    
    iVar7 = *(int64_t *)arg1;
    if (iVar7 != 0) {
        iVar3 = *(int64_t *)(arg1 + 8);
        for (; iVar7 != iVar3; iVar7 = iVar7 + 0x90) {
            iVar5 = *(int64_t *)(iVar7 + 0x78);
            if (iVar5 != 0) {
                iVar1 = *(int64_t *)(iVar7 + 0x80);
                for (; iVar5 != iVar1; iVar5 = iVar5 + 0x40) {
                    fcn.180004e40(iVar5 + 0x20);
                    fcn.180004e40(iVar5);
                }
                iVar5 = *(int64_t *)(iVar7 + 0x78);
                uVar4 = *(int64_t *)(iVar7 + 0x88) - iVar5 & 0xffffffffffffffc0;
                if (0xfff < uVar4) {
                    if (0x1f < (iVar5 - *(int64_t *)(iVar5 + -8)) - 8U) goto code_r0x00018008527d;
                    uVar4 = uVar4 + 0x27;
                    iVar5 = *(int64_t *)(iVar5 + -8);
                }
                fcn.180459c3c(iVar5, uVar4);
                *(undefined8 *)(iVar7 + 0x78) = 0;
                *(undefined8 *)(iVar7 + 0x80) = 0;
                *(undefined8 *)(iVar7 + 0x88) = 0;
            }
            fcn.180004e40(iVar7 + 0x40);
            fcn.180004e40(iVar7 + 0x20);
            fcn.180004e40(iVar7);
        }
        iVar7 = *(int64_t *)arg1;
        iVar3 = iVar7;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 4) << 4)) &&
           (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_38, 0x1f < (iVar7 - iVar3) - 8U)) {
code_r0x00018008527d:
            iVar3 = 5;
            pcVar2 = (code *)swi(0x29);
            (*pcVar2)(5);
            puVar6 = auStack_30;
        }
        *(undefined8 *)(puVar6 + -8) = 0x18008528f;
        fcn.180459c3c(iVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800852ae
// Address: 0x1800852ae
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180085150(int64_t arg1, int64_t arg_50h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined *puVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    int64_t var_18h;
    
    iVar7 = *(int64_t *)arg1;
    if (iVar7 != 0) {
        iVar3 = *(int64_t *)(arg1 + 8);
        for (; iVar7 != iVar3; iVar7 = iVar7 + 0x90) {
            iVar5 = *(int64_t *)(iVar7 + 0x78);
            if (iVar5 != 0) {
                iVar1 = *(int64_t *)(iVar7 + 0x80);
                for (; iVar5 != iVar1; iVar5 = iVar5 + 0x40) {
                    fcn.180004e40(iVar5 + 0x20);
                    fcn.180004e40(iVar5);
                }
                iVar5 = *(int64_t *)(iVar7 + 0x78);
                uVar4 = *(int64_t *)(iVar7 + 0x88) - iVar5 & 0xffffffffffffffc0;
                if (0xfff < uVar4) {
                    if (0x1f < (iVar5 - *(int64_t *)(iVar5 + -8)) - 8U) goto code_r0x00018008527d;
                    uVar4 = uVar4 + 0x27;
                    iVar5 = *(int64_t *)(iVar5 + -8);
                }
                fcn.180459c3c(iVar5, uVar4);
                *(undefined8 *)(iVar7 + 0x78) = 0;
                *(undefined8 *)(iVar7 + 0x80) = 0;
                *(undefined8 *)(iVar7 + 0x88) = 0;
            }
            fcn.180004e40(iVar7 + 0x40);
            fcn.180004e40(iVar7 + 0x20);
            fcn.180004e40(iVar7);
        }
        iVar7 = *(int64_t *)arg1;
        iVar3 = iVar7;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 4) << 4)) &&
           (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_38, 0x1f < (iVar7 - iVar3) - 8U)) {
code_r0x00018008527d:
            iVar3 = 5;
            pcVar2 = (code *)swi(0x29);
            (*pcVar2)(5);
            puVar6 = auStack_30;
        }
        *(undefined8 *)(puVar6 + -8) = 0x18008528f;
        fcn.180459c3c(iVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800852c0
// Address: 0x1800852c0
// Size: 162 bytes
// ============================================================
undefined8 fcn.1800852c0(void)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t unaff_GS_OFFSET;
    
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x180782a04) {
        fcn.180459d18(0x180782a04);
        if (*(int32_t *)0x180782a04 == -1) {
            puVar1 = (undefined8 *)fcn.180459890(0x20);
            uVar2 = (*(code *)0x699e24)(0x18063d888);
            *puVar1 = uVar2;
            puVar1[1] = 0;
            puVar1[2] = 0;
            puVar1[3] = 0;
            *(undefined8 **)0x180782a08 = puVar1;
            fcn.180459c24(0x1804a2ab0);
            fcn.180459cac(0x180782a04);
            return 0x180782a08;
        }
    }
    return 0x180782a08;
}

// ============================================================
// Function: FUN_180085430
// Address: 0x180085430
// Size: 107 bytes
// ============================================================
uint64_t fcn.180085430(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int32_t iVar2;
    uint64_t uVar3;
    
    iVar2 = (int32_t)arg2;
    if (0 < iVar2) {
        uVar1 = *(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar1) {
            uVar1 = *(uint64_t *)0x180782430;
        }
        if (uVar1 == *(uint64_t *)0x180782430) {
            uVar1 = 0;
        }
        return uVar1;
    }
    if (-10000 < iVar2) {
        uVar1 = (int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40);
        if (uVar1 == *(uint64_t *)0x180782430) {
            uVar1 = 0;
        }
        return uVar1;
    }
    uVar3 = *(uint64_t *)0x180782430;
    uVar1 = fcn.180085370();
    if (uVar1 == uVar3) {
        uVar1 = 0;
    }
    return uVar1;
}

// ============================================================
// Function: FUN_1800854a0
// Address: 0x1800854a0
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800854a0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar6 = fcn.180085510(in_stack_00000010);
        if (iVar6 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    puVar1 = *(undefined4 **)(arg1 + 0x40);
    uVar3 = *(undefined4 *)(arg2 + 4);
    uVar4 = *(undefined4 *)(arg2 + 8);
    uVar5 = *(undefined4 *)(arg2 + 0xc);
    *puVar1 = *(undefined4 *)arg2;
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_180085510
// Address: 0x180085510
// Size: 194 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180085510(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    int32_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    var_10h._0_4_ = (int32_t)arg2;
    if ((int32_t)var_10h < 0x1f41) {
        iVar3 = (int64_t)(int32_t)var_10h;
        if ((*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) + iVar3 < 0x1f41) {
            if ((int32_t)var_10h < 1) {
                return 1;
            }
            if ((*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) <= (int64_t)((int32_t)var_10h << 4)) &&
               (iVar1 = fcn.180093190(arg1, 0x1800855e0, &var_10h), iVar1 != 0)) {
                return 0;
            }
            uVar2 = *(int64_t *)(arg1 + 0x40) + iVar3 * 0x10;
            if (uVar2 <= **(uint64_t **)(arg1 + 0x18)) {
                return 1;
            }
            **(uint64_t **)(arg1 + 0x18) = uVar2;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180085610
// Address: 0x180085610
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180085610(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    uint64_t uVar3;
    int32_t iVar4;
    int64_t var_8h;
    
    iVar2 = (int32_t)arg2;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) <= (int64_t)(iVar2 << 4)) {
        iVar4 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar1 = iVar4;
        if (iVar4 < iVar2) {
            iVar1 = iVar2;
        }
        func_0x000180093240(arg1, iVar1 + iVar4, 0);
    }
    uVar3 = (int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40);
    if (**(uint64_t **)(arg1 + 0x18) < uVar3) {
        **(uint64_t **)(arg1 + 0x18) = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_180085680
// Address: 0x180085680
// Size: 216 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180085680(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t unaff_RSI;
    int64_t iVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg1 != arg2) {
        iVar13 = (int32_t)arg3;
        iVar12 = (int64_t)iVar13;
        if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
            *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
            *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
        }
        if (((*(char *)0x180777010 != '\0') &&
            (**(uint64_t **)(arg2 + 0x18) < (uint64_t)(iVar12 * 0x10 + *(int64_t *)(arg2 + 0x40)))) &&
           (iVar8 = fcn.180085510(arg2, arg3 & 0xffffffff, unaff_RSI), iVar8 == 0)) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        iVar3 = *(int64_t *)(arg2 + 0x40);
        uVar10 = 0;
        iVar11 = *(int64_t *)(arg1 + 0x40) + iVar12 * -0x10;
        if (0 < iVar13) {
            do {
                uVar9 = (int32_t)uVar10 + 1;
                puVar1 = (undefined4 *)(iVar11 + uVar10 * 0x10);
                uVar5 = puVar1[1];
                uVar6 = puVar1[2];
                uVar7 = puVar1[3];
                puVar2 = (undefined4 *)(iVar3 + uVar10 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar5;
                puVar2[2] = uVar6;
                puVar2[3] = uVar7;
                uVar10 = (uint64_t)uVar9;
            } while ((int32_t)uVar9 < iVar13);
        }
        *(int64_t *)(arg1 + 0x40) = iVar11;
        *(int64_t *)(arg2 + 0x40) = iVar12 * 0x10 + iVar3;
    }
    return;
}

// ============================================================
// Function: FUN_180085760
// Address: 0x180085760
// Size: 120 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined * fcn.180085760(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int32_t iVar5;
    undefined *puVar6;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    iVar2 = *(int64_t *)(arg1 + 0x20);
    if (*(uint64_t *)(iVar2 + 0x28) <= *(uint64_t *)(iVar2 + 0x30)) {
        (**(code **)0x180782658)(arg1, CONCAT71((unkint7)((uint64_t)iVar2 >> 8), 1));
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(arg1, 1, in_stack_00000010);
        if (iVar5 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            puVar6 = (undefined *)(*pcVar4)();
            return puVar6;
        }
    }
    puVar6 = (undefined *)fcn.180098710(arg1, 0x80, *(undefined *)(arg1 + 4));
    uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
    puVar6[2] = 10;
    puVar6[1] = uVar1 & 3;
    *puVar6 = *(undefined *)(arg1 + 4);
    *(undefined8 *)(puVar6 + 0x20) = *(undefined8 *)(arg1 + 0x20);
    *(int32_t *)(puVar6 + 0x60) = (int32_t)(puVar6 + 0x60);
    *(undefined4 *)(puVar6 + 3) = 0;
    *(undefined8 *)(puVar6 + 0x58) = 0;
    *(undefined8 *)(puVar6 + 0x38) = 0;
    *(undefined8 *)(puVar6 + 0x10) = 0;
    *(undefined4 *)(puVar6 + 100) = 0;
    *(undefined8 *)(puVar6 + 0x68) = 0;
    *(undefined8 *)(puVar6 + 0x18) = 0;
    *(undefined8 *)(puVar6 + 0x78) = 0;
    *(undefined8 *)(puVar6 + 8) = 0;
    *(undefined8 *)(puVar6 + 0x50) = 0;
    puVar6[4] = *(undefined *)(arg1 + 4);
    func_0x00018009a2c0(puVar6, arg1);
    *(undefined8 *)(puVar6 + 0x58) = *(undefined8 *)(arg1 + 0x58);
    puVar6[5] = *(undefined *)(arg1 + 5);
    puVar3 = *(undefined8 **)(arg1 + 0x40);
    *puVar3 = puVar6;
    *(undefined4 *)((int64_t)puVar3 + 0xc) = 10;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    pcVar4 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x550);
    if (pcVar4 != (code *)0x0) {
        (*pcVar4)(arg1, puVar6);
    }
    return puVar6;
}

// ============================================================
// Function: FUN_1800857d8
// Address: 0x1800857d8
// Size: 182 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined * fcn.180085760(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int32_t iVar5;
    undefined *puVar6;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    iVar2 = *(int64_t *)(arg1 + 0x20);
    if (*(uint64_t *)(iVar2 + 0x28) <= *(uint64_t *)(iVar2 + 0x30)) {
        (**(code **)0x180782658)(arg1, CONCAT71((unkint7)((uint64_t)iVar2 >> 8), 1));
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(arg1, 1, in_stack_00000010);
        if (iVar5 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            puVar6 = (undefined *)(*pcVar4)();
            return puVar6;
        }
    }
    puVar6 = (undefined *)fcn.180098710(arg1, 0x80, *(undefined *)(arg1 + 4));
    uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
    puVar6[2] = 10;
    puVar6[1] = uVar1 & 3;
    *puVar6 = *(undefined *)(arg1 + 4);
    *(undefined8 *)(puVar6 + 0x20) = *(undefined8 *)(arg1 + 0x20);
    *(int32_t *)(puVar6 + 0x60) = (int32_t)(puVar6 + 0x60);
    *(undefined4 *)(puVar6 + 3) = 0;
    *(undefined8 *)(puVar6 + 0x58) = 0;
    *(undefined8 *)(puVar6 + 0x38) = 0;
    *(undefined8 *)(puVar6 + 0x10) = 0;
    *(undefined4 *)(puVar6 + 100) = 0;
    *(undefined8 *)(puVar6 + 0x68) = 0;
    *(undefined8 *)(puVar6 + 0x18) = 0;
    *(undefined8 *)(puVar6 + 0x78) = 0;
    *(undefined8 *)(puVar6 + 8) = 0;
    *(undefined8 *)(puVar6 + 0x50) = 0;
    puVar6[4] = *(undefined *)(arg1 + 4);
    func_0x00018009a2c0(puVar6, arg1);
    *(undefined8 *)(puVar6 + 0x58) = *(undefined8 *)(arg1 + 0x58);
    puVar6[5] = *(undefined *)(arg1 + 5);
    puVar3 = *(undefined8 **)(arg1 + 0x40);
    *puVar3 = puVar6;
    *(undefined4 *)((int64_t)puVar3 + 0xc) = 10;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    pcVar4 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x550);
    if (pcVar4 != (code *)0x0) {
        (*pcVar4)(arg1, puVar6);
    }
    return puVar6;
}

// ============================================================
// Function: FUN_18008588e
// Address: 0x18008588e
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined * fcn.180085760(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int32_t iVar5;
    undefined *puVar6;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    iVar2 = *(int64_t *)(arg1 + 0x20);
    if (*(uint64_t *)(iVar2 + 0x28) <= *(uint64_t *)(iVar2 + 0x30)) {
        (**(code **)0x180782658)(arg1, CONCAT71((unkint7)((uint64_t)iVar2 >> 8), 1));
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(arg1, 1, in_stack_00000010);
        if (iVar5 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            puVar6 = (undefined *)(*pcVar4)();
            return puVar6;
        }
    }
    puVar6 = (undefined *)fcn.180098710(arg1, 0x80, *(undefined *)(arg1 + 4));
    uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
    puVar6[2] = 10;
    puVar6[1] = uVar1 & 3;
    *puVar6 = *(undefined *)(arg1 + 4);
    *(undefined8 *)(puVar6 + 0x20) = *(undefined8 *)(arg1 + 0x20);
    *(int32_t *)(puVar6 + 0x60) = (int32_t)(puVar6 + 0x60);
    *(undefined4 *)(puVar6 + 3) = 0;
    *(undefined8 *)(puVar6 + 0x58) = 0;
    *(undefined8 *)(puVar6 + 0x38) = 0;
    *(undefined8 *)(puVar6 + 0x10) = 0;
    *(undefined4 *)(puVar6 + 100) = 0;
    *(undefined8 *)(puVar6 + 0x68) = 0;
    *(undefined8 *)(puVar6 + 0x18) = 0;
    *(undefined8 *)(puVar6 + 0x78) = 0;
    *(undefined8 *)(puVar6 + 8) = 0;
    *(undefined8 *)(puVar6 + 0x50) = 0;
    puVar6[4] = *(undefined *)(arg1 + 4);
    func_0x00018009a2c0(puVar6, arg1);
    *(undefined8 *)(puVar6 + 0x58) = *(undefined8 *)(arg1 + 0x58);
    puVar6[5] = *(undefined *)(arg1 + 5);
    puVar3 = *(undefined8 **)(arg1 + 0x40);
    *puVar3 = puVar6;
    *(undefined4 *)((int64_t)puVar3 + 0xc) = 10;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    pcVar4 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x550);
    if (pcVar4 != (code *)0x0) {
        (*pcVar4)(arg1, puVar6);
    }
    return puVar6;
}

// ============================================================
// Function: FUN_1800858c0
// Address: 0x1800858c0
// Size: 210 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800858c0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    uint64_t uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    iVar2 = (int32_t)arg2;
    iVar6 = (int64_t)iVar2;
    if (iVar2 < 0) {
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + iVar6 * 0x10 + 0x10;
        return;
    }
    if (((*(char *)0x180777010 != '\0') &&
        (uVar4 = iVar2 - (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4),
        **(uint64_t **)(arg1 + 0x18) < (uint64_t)((int64_t)(int32_t)uVar4 * 0x10 + *(int64_t *)(arg1 + 0x40)))) &&
       (iVar2 = fcn.180085510(arg1, (uint64_t)uVar4, in_stack_00000010), iVar2 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x28);
    uVar3 = *(uint64_t *)(arg1 + 0x40);
    if (uVar3 < (uint64_t)(iVar5 + iVar6 * 0x10)) {
        do {
            *(undefined4 *)(uVar3 + 0xc) = 0;
            uVar3 = *(int64_t *)(arg1 + 0x40) + 0x10;
            *(uint64_t *)(arg1 + 0x40) = uVar3;
            iVar5 = *(int64_t *)(arg1 + 0x28);
        } while (uVar3 < (uint64_t)(iVar5 + iVar6 * 0x10));
    }
    *(int64_t *)(arg1 + 0x40) = iVar5 + iVar6 * 0x10;
    return;
}

// ============================================================
// Function: FUN_1800859a0
// Address: 0x1800859a0
// Size: 161 bytes
// ============================================================
void fcn.1800859a0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    undefined4 *puVar6;
    uint64_t *puVar7;
    
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    iVar5 = (int32_t)arg2;
    if (iVar5 < 1) {
        if (iVar5 < -9999) {
            puVar6 = (undefined4 *)fcn.180085370();
            puVar7 = (uint64_t *)(arg1 + 0x40);
        } else {
            puVar7 = (uint64_t *)(arg1 + 0x40);
            puVar6 = (undefined4 *)((int64_t)iVar5 * 0x10 + *puVar7);
        }
    } else {
        puVar7 = (uint64_t *)(arg1 + 0x40);
        puVar6 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar5 * 0x10);
        if ((undefined4 *)*puVar7 <= puVar6) {
            puVar6 = *(undefined4 **)0x180782430;
        }
    }
    for (puVar1 = (undefined4 *)*puVar7; puVar6 < puVar1; puVar1 = puVar1 + -4) {
        *puVar1 = puVar1[-4];
        puVar1[1] = puVar1[-3];
        puVar1[2] = puVar1[-2];
        puVar1[3] = puVar1[-1];
    }
    puVar1 = (undefined4 *)*puVar7;
    uVar2 = puVar1[1];
    uVar3 = puVar1[2];
    uVar4 = puVar1[3];
    *puVar6 = *puVar1;
    puVar6[1] = uVar2;
    puVar6[2] = uVar3;
    puVar6[3] = uVar4;
    return;
}

// ============================================================
// Function: FUN_180085a50
// Address: 0x180085a50
// Size: 403 bytes
// ============================================================
void fcn.180085a50(int64_t arg1, int64_t arg2)
{
    uint8_t uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int32_t iVar7;
    undefined4 *puVar8;
    undefined8 *puVar9;
    int64_t iVar10;
    int64_t iVar11;
    
    iVar7 = (int32_t)arg2;
    iVar11 = (int64_t)iVar7;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (iVar7 < 1) {
        if (-10000 < iVar7) {
            puVar8 = (undefined4 *)(iVar11 * 0x10 + *(int64_t *)(arg1 + 0x40));
            puVar9 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) + -0x10);
            goto code_r0x000180085aa5;
        }
        puVar8 = (undefined4 *)fcn.180085370(arg1, arg2 & 0xffffffff);
        puVar9 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) + -0x10);
        iVar7 = (int32_t)iVar11;
        if (iVar7 != -0x2711) {
            if (iVar7 == -0x2712) {
                uVar2 = *puVar9;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                *(undefined8 *)(arg1 + 0x58) = uVar2;
                return;
            }
            goto code_r0x000180085aa5;
        }
        iVar11 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
        *(undefined8 *)(iVar11 + 0x10) = *puVar9;
        if (((*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) < 6) || ((*(uint8_t *)(iVar11 + 1) & 4) == 0)) ||
           (iVar10 = *(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10), (*(uint8_t *)(iVar10 + 1) & 3) == 0))
        goto code_r0x000180085bbb;
        iVar6 = *(int64_t *)(arg1 + 0x20);
        if (2 < (uint8_t)(*(char *)(iVar6 + 0x59) - 1U)) {
            *(uint8_t *)(iVar11 + 1) = *(uint8_t *)(iVar6 + 0x58) & 3 | *(uint8_t *)(iVar11 + 1) & 0xf8;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            return;
        }
    } else {
        puVar8 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + -0x10 + iVar11 * 0x10);
        puVar9 = (undefined8 *)(*(undefined4 **)(arg1 + 0x40) + -4);
        if (*(undefined4 **)(arg1 + 0x40) <= puVar8) {
            puVar8 = *(undefined4 **)0x180782430;
        }
code_r0x000180085aa5:
        uVar3 = *(undefined4 *)((int64_t)puVar9 + 4);
        uVar4 = *(undefined4 *)(puVar9 + 1);
        uVar5 = *(undefined4 *)((int64_t)puVar9 + 0xc);
        *puVar8 = *(undefined4 *)puVar9;
        puVar8[1] = uVar3;
        puVar8[2] = uVar4;
        puVar8[3] = uVar5;
        if ((-0x2713 < iVar7) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) < 6)) goto code_r0x000180085bbb;
        iVar11 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
        uVar1 = *(uint8_t *)(iVar11 + 1);
        if (((uVar1 & 4) == 0) ||
           (iVar10 = *(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10), (*(uint8_t *)(iVar10 + 1) & 3) == 0))
        goto code_r0x000180085bbb;
        iVar6 = *(int64_t *)(arg1 + 0x20);
        if (2 < (uint8_t)(*(char *)(iVar6 + 0x59) - 1U)) {
            *(uint8_t *)(iVar11 + 1) = *(uint8_t *)(iVar6 + 0x58) & 3 | uVar1 & 0xf8;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            return;
        }
    }
    func_0x000180094420(iVar6, iVar10);
code_r0x000180085bbb:
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    return;
}

// ============================================================
// Function: FUN_180085bf0
// Address: 0x180085bf0
// Size: 214 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180085bf0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    iVar8 = (int32_t)arg2;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar6 = fcn.180085510(arg1, 1, in_stack_00000010);
        if (iVar6 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    if (iVar8 < 1) {
        if (iVar8 < -9999) {
            puVar7 = (undefined4 *)fcn.180085370(arg1, arg2 & 0xffffffff);
        } else {
            puVar7 = (undefined4 *)((int64_t)iVar8 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        puVar7 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar8 * 0x10);
        if (*(undefined4 **)(arg1 + 0x40) <= puVar7) {
            puVar7 = *(undefined4 **)0x180782430;
        }
    }
    piVar9 = (int64_t *)(arg1 + 0x40);
    puVar1 = (undefined4 *)*piVar9;
    uVar3 = puVar7[1];
    uVar4 = puVar7[2];
    uVar5 = puVar7[3];
    *puVar1 = *puVar7;
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    *piVar9 = *piVar9 + 0x10;
    return;
}

// ============================================================
// Function: FUN_180085cd0
// Address: 0x180085cd0
// Size: 92 bytes
// ============================================================
undefined4 fcn.180085cd0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int32_t iVar2;
    uint64_t uVar3;
    
    iVar2 = (int32_t)arg2;
    uVar3 = *(uint64_t *)0x180782430;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            uVar1 = fcn.180085370();
        } else {
            uVar1 = (int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40);
        }
    } else {
        uVar1 = *(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar1) {
            uVar1 = *(uint64_t *)0x180782430;
        }
    }
    if (uVar1 != uVar3) {
        return *(undefined4 *)(uVar1 + 0xc);
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180085d50
// Address: 0x180085d50
// Size: 120 bytes
// ============================================================
undefined8 fcn.180085d50(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t *piVar2;
    int64_t var_18h;
    
    iVar1 = (int32_t)arg2;
    if (iVar1 < 1) {
        if (iVar1 < -9999) {
            piVar2 = (int64_t *)fcn.180085370();
        } else {
            piVar2 = (int64_t *)((int64_t)iVar1 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar2 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar1 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
            piVar2 = *(int64_t **)0x180782430;
        }
    }
    if ((*(int32_t *)((int64_t)piVar2 + 0xc) != 3) &&
       ((*(int32_t *)((int64_t)piVar2 + 0xc) != 6 || (iVar1 = func_0x0001800992c0(*piVar2 + 0x18, &var_18h), iVar1 == 0)
        ))) {
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180085dd0
// Address: 0x180085dd0
// Size: 104 bytes
// ============================================================
undefined8 fcn.180085dd0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int32_t iVar2;
    uint64_t uVar3;
    
    iVar2 = (int32_t)arg2;
    uVar3 = *(uint64_t *)0x180782430;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            uVar1 = fcn.180085370();
        } else {
            uVar1 = (int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40);
        }
    } else {
        uVar1 = *(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar1) {
            uVar1 = *(uint64_t *)0x180782430;
        }
    }
    if ((uVar1 != uVar3) && ((*(int32_t *)(uVar1 + 0xc) == 6 || (*(int32_t *)(uVar1 + 0xc) == 3)))) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180085e40
// Address: 0x180085e40
// Size: 96 bytes
// ============================================================
undefined8 fcn.180085e40(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int32_t iVar2;
    
    iVar2 = (int32_t)arg2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            uVar1 = fcn.180085370();
        } else {
            uVar1 = (int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40);
        }
    } else {
        uVar1 = *(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar1) {
            uVar1 = *(uint64_t *)0x180782430;
        }
    }
    if ((*(int32_t *)(uVar1 + 0xc) != 9) && (*(int32_t *)(uVar1 + 0xc) != 2)) {
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180085ea0
// Address: 0x180085ea0
// Size: 174 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_ch

int64_t fcn.180085ea0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t *piVar2;
    int64_t var_18h;
    int64_t var_ch;
    
    iVar1 = (int32_t)arg2;
    if (iVar1 < 1) {
        if (iVar1 < -9999) {
            piVar2 = (int64_t *)fcn.180085370();
        } else {
            piVar2 = (int64_t *)((int64_t)iVar1 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar2 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar1 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
            piVar2 = *(int64_t **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)piVar2 + 0xc) != 3) {
        if ((*(int32_t *)((int64_t)piVar2 + 0xc) != 6) ||
           (iVar1 = func_0x0001800992c0(*piVar2 + 0x18, &var_18h), iVar1 == 0)) {
            if (arg3 != 0) {
                *(undefined4 *)arg3 = 0;
            }
            return 0;
        }
        piVar2 = &var_18h;
        var_ch._0_4_ = 3;
    }
    if (arg3 != 0) {
        *(undefined4 *)arg3 = 1;
    }
    return *piVar2;
}

// ============================================================
// Function: FUN_180085f50
// Address: 0x180085f50
// Size: 160 bytes
// ============================================================
int32_t fcn.180085f50(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    double *pdVar2;
    int64_t var_18h;
    
    iVar1 = (int32_t)arg2;
    if (iVar1 < 1) {
        if (iVar1 < -9999) {
            pdVar2 = (double *)fcn.180085370();
        } else {
            pdVar2 = (double *)((int64_t)iVar1 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        pdVar2 = (double *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar1 * 0x10);
        if (*(double **)(arg1 + 0x40) <= pdVar2) {
            pdVar2 = *(double **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)pdVar2 + 0xc) == 3) {
        var_18h = (int64_t)*pdVar2;
    } else if ((*(int32_t *)((int64_t)pdVar2 + 0xc) != 6) ||
              (iVar1 = func_0x0001800992c0((int64_t)*pdVar2 + 0x18, &var_18h), iVar1 == 0)) {
        if (arg3 != 0) {
            *(undefined4 *)arg3 = 0;
        }
        return 0;
    }
    if (arg3 != 0) {
        *(undefined4 *)arg3 = 1;
    }
    return (int32_t)(double)var_18h;
}

// ============================================================
// Function: FUN_180085ff0
// Address: 0x180085ff0
// Size: 100 bytes
// ============================================================
undefined8 fcn.180085ff0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    
    iVar2 = (int32_t)arg2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            piVar1 = (int32_t *)fcn.180085370();
        } else {
            piVar1 = (int32_t *)((int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10);
        if (*(int32_t **)(arg1 + 0x40) <= piVar1) {
            piVar1 = *(int32_t **)0x180782430;
        }
    }
    if ((piVar1[3] != 0) && ((piVar1[3] != 1 || (*piVar1 != 0)))) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180086060
// Address: 0x180086060
// Size: 87 bytes
// ============================================================
undefined8 fcn.180086060(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int32_t iVar2;
    
    iVar2 = (int32_t)arg2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            puVar1 = (undefined8 *)fcn.180085370();
        } else {
            puVar1 = (undefined8 *)((int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        puVar1 = (undefined8 *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10);
        if (*(undefined8 **)(arg1 + 0x40) <= puVar1) {
            puVar1 = *(undefined8 **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)puVar1 + 0xc) != 4) {
        return 0;
    }
    return *puVar1;
}

// ============================================================
// Function: FUN_1800860c0
// Address: 0x1800860c0
// Size: 308 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800860c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    iVar3 = (int64_t)iVar2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            piVar4 = (int64_t *)fcn.180085370(arg1, arg2 & 0xffffffff);
        } else {
            piVar4 = (int64_t *)(iVar3 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar4 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + iVar3 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)piVar4 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar1 = func_0x0001800a8360(arg1, piVar4);
        if (iVar1 == 0) {
            if (arg3 != 0) {
                *(undefined8 *)arg3 = 0;
            }
            return 0;
        }
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        if (iVar2 < 1) {
            if (iVar2 < -9999) {
                piVar4 = (int64_t *)fcn.180085370(arg1, arg2 & 0xffffffff);
            } else {
                piVar4 = (int64_t *)(iVar3 * 0x10 + *(int64_t *)(arg1 + 0x40));
            }
        } else {
            piVar4 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + iVar3 * 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
                piVar4 = *(int64_t **)0x180782430;
            }
        }
    }
    if (arg3 != 0) {
        *(uint64_t *)arg3 = (uint64_t)*(uint32_t *)(*piVar4 + 0x14);
    }
    return *piVar4 + 0x18;
}

// ============================================================
// Function: FUN_180086200
// Address: 0x180086200
// Size: 113 bytes
// ============================================================
uint64_t fcn.180086200(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    
    iVar1 = (int32_t)arg2;
    if (0 < iVar1) {
        uVar2 = *(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar1 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
        uVar3 = 0;
        if (*(int32_t *)(uVar2 + 0xc) == 5) {
            uVar3 = uVar2;
        }
        return uVar3;
    }
    if (-10000 < iVar1) {
        uVar3 = (int64_t)iVar1 * 0x10 + *(int64_t *)(arg1 + 0x40);
        uVar2 = 0;
        if (*(int32_t *)(uVar3 + 0xc) == 5) {
            uVar2 = uVar3;
        }
        return uVar2;
    }
    uVar3 = fcn.180085370();
    uVar2 = 0;
    if (*(int32_t *)(uVar3 + 0xc) == 5) {
        uVar2 = uVar3;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_1800862a0
// Address: 0x1800862a0
// Size: 87 bytes
// ============================================================
undefined8 fcn.1800862a0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int32_t iVar2;
    
    iVar2 = (int32_t)arg2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            puVar1 = (undefined8 *)fcn.180085370();
        } else {
            puVar1 = (undefined8 *)((int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        puVar1 = (undefined8 *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10);
        if (*(undefined8 **)(arg1 + 0x40) <= puVar1) {
            puVar1 = *(undefined8 **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)puVar1 + 0xc) == 2) {
        return *puVar1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180086300
// Address: 0x180086300
// Size: 106 bytes
// ============================================================
int64_t fcn.180086300(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    
    iVar2 = (int32_t)arg2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            piVar1 = (int64_t *)fcn.180085370();
        } else {
            piVar1 = (int64_t *)((int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar1 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar1) {
            piVar1 = *(int64_t **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)piVar1 + 0xc) != 9) {
        if (*(int32_t *)((int64_t)piVar1 + 0xc) != 2) {
            return 0;
        }
        return *piVar1;
    }
    return *piVar1 + 0x10;
}

// ============================================================
// Function: FUN_180086370
// Address: 0x180086370
// Size: 103 bytes
// ============================================================
int64_t fcn.180086370(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int32_t iVar2;
    uint32_t uVar3;
    
    uVar3 = (uint32_t)arg3;
    iVar2 = (int32_t)arg2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            piVar1 = (int64_t *)fcn.180085370();
        } else {
            piVar1 = (int64_t *)((int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar1 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar1) {
            piVar1 = *(int64_t **)0x180782430;
        }
    }
    if ((*(int32_t *)((int64_t)piVar1 + 0xc) == 9) && (*(uint8_t *)(*piVar1 + 3) == uVar3)) {
        return *piVar1 + 0x10;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800863e0
// Address: 0x1800863e0
// Size: 94 bytes
// ============================================================
uint64_t fcn.1800863e0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    
    iVar2 = (int32_t)arg2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            piVar1 = (int64_t *)fcn.180085370();
        } else {
            piVar1 = (int64_t *)((int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar1 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar1) {
            piVar1 = *(int64_t **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)piVar1 + 0xc) != 9) {
        return 0xffffffff;
    }
    return (uint64_t)*(uint8_t *)(*piVar1 + 3);
}

// ============================================================
// Function: FUN_180086440
// Address: 0x180086440
// Size: 87 bytes
// ============================================================
undefined8 fcn.180086440(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int32_t iVar2;
    
    iVar2 = (int32_t)arg2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            puVar1 = (undefined8 *)fcn.180085370();
        } else {
            puVar1 = (undefined8 *)((int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        puVar1 = (undefined8 *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10);
        if (*(undefined8 **)(arg1 + 0x40) <= puVar1) {
            puVar1 = *(undefined8 **)0x180782430;
        }
    }
    if (*(int32_t *)((int64_t)puVar1 + 0xc) == 10) {
        return *puVar1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800864a0
// Address: 0x1800864a0
// Size: 111 bytes
// ============================================================
int64_t fcn.1800864a0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    
    iVar2 = (int32_t)arg2;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            piVar1 = (int64_t *)fcn.180085370();
        } else {
            piVar1 = (int64_t *)((int64_t)iVar2 * 0x10 + *(int64_t *)(arg1 + 0x40));
        }
    } else {
        piVar1 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar1) {
            piVar1 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *(int32_t *)((int64_t)piVar1 + 0xc);
    if (iVar2 != 2) {
        if (iVar2 == 9) {
            return *piVar1 + 0x10;
        }
        if (iVar2 < 6) {
            return 0;
        }
    }
    return *piVar1;
}

// ============================================================
// Function: FUN_180086510
// Address: 0x180086510
// Size: 95 bytes
// ============================================================
void fcn.180086510(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t in_stack_00000010;
    
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar2 = fcn.180085510(arg1, 1, in_stack_00000010);
        if (iVar2 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_180086570
// Address: 0x180086570
// Size: 112 bytes
// ============================================================
void fcn.180086570(int64_t arg1)
{
    undefined8 *puVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 in_XMM1_Da;
    undefined4 in_XMM1_Db;
    int64_t unaff_retaddr;
    int64_t var_18h;
    
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(arg1, 1, unaff_retaddr);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    puVar1 = *(undefined8 **)(arg1 + 0x40);
    *puVar1 = CONCAT44(in_XMM1_Db, in_XMM1_Da);
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 3;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_1800865e0
// Address: 0x1800865e0
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800865e0(int64_t arg1, int64_t arg2)
{
    double *pdVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(arg1, 1, in_stack_00000010);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    pdVar1 = *(double **)(arg1 + 0x40);
    *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
    *pdVar1 = (double)(int32_t)arg2;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_180086660
// Address: 0x180086660
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180086660(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(arg1, 1, in_stack_00000010);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = arg2;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_1800866d0
// Address: 0x1800866d0
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800866d0(int64_t arg1, int64_t arg2)
{
    double *pdVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(arg1, 1, in_stack_00000010);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    pdVar1 = *(double **)(arg1 + 0x40);
    *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
    *pdVar1 = (double)(arg2 & 0xffffffff);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_180086750
// Address: 0x180086750
// Size: 152 bytes
// ============================================================
void fcn.180086750(int64_t arg1)
{
    undefined4 *puVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 in_XMM1_Da;
    undefined4 in_XMM2_Da;
    undefined4 in_XMM3_Da;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(arg1, 1, CONCAT44(unaff_XMM7_Dd, unaff_XMM7_Dc));
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    puVar1 = *(undefined4 **)(arg1 + 0x40);
    *puVar1 = in_XMM1_Da;
    puVar1[1] = in_XMM2_Da;
    puVar1[2] = in_XMM3_Da;
    puVar1[3] = 5;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

// ============================================================
// Function: FUN_1800867f0
// Address: 0x1800867f0
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800867f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int64_t unaff_RBP;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(arg1, 1, unaff_RBP);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    puVar1 = *(undefined8 **)(arg1 + 0x40);
    uVar4 = fcn.18009a8e0(arg1, arg2, arg3);
    *puVar1 = uVar4;
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 6;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return;
}

