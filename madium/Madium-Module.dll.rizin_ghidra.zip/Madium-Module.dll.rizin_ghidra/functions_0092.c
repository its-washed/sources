// Chunk 92 - 50 functions

// ============================================================
// Function: FUN_1801376f0
// Address: 0x1801376f0
// Size: 8 bytes
// ============================================================
void fcn.1801376f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int32_t *piVar1;
    char cVar2;
    bool bVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int16_t iVar10;
    int32_t iVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int32_t iVar14;
    uint64_t uVar15;
    uint32_t *puVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar1 = (int32_t *)(arg1 + 0x6c);
    cVar2 = *(char *)(arg1 + 0x23c);
    if (cVar2 == '\0') goto code_r0x000180137986;
    iVar9 = *piVar1;
    iVar11 = 0;
    if (iVar9 < 1) {
        iVar7 = 1;
        iVar5 = 1;
code_r0x0001801377a7:
        bVar3 = false;
    } else {
        uVar13 = 0;
        iVar14 = 0;
        do {
            iVar5 = (int64_t)iVar14 * 0x74;
            iVar7 = *(int64_t *)(arg1 + 0x18);
            iVar10 = *(int16_t *)(iVar5 + 0x5e + iVar7);
            if (iVar10 != -1) {
                if (*(char *)(iVar5 + 0x66 + iVar7) == '\0') {
                    *(undefined2 *)(iVar5 + 0x5e + iVar7) = 0xffff;
                    iVar9 = *piVar1;
                } else {
                    iVar11 = iVar11 + 1;
                    uVar13 = uVar13 | 1LL << ((int64_t)iVar10 & 0x3fU);
                }
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < iVar9);
        iVar7 = 1LL << ((uint8_t)iVar11 & 0x3f);
        iVar5 = uVar13 + 1;
        if ((iVar11 < 2) || ((*(uint32_t *)(arg1 + 4) & 0x4000000) != 0)) goto code_r0x0001801377a7;
        bVar3 = true;
    }
    if (((iVar7 == iVar5) && (!bVar3)) || (iVar11 < 1)) {
        if (((iVar11 == 0) && ((*(uint32_t *)(arg1 + 4) & 0x8000000) == 0)) && (0 < *piVar1)) {
            uVar13 = 0;
            do {
                puVar16 = (uint32_t *)(uVar13 * 0x74 + *(int64_t *)(arg1 + 0x18));
                if ((*(char *)((int64_t)puVar16 + 0x66) != '\0') && ((*puVar16 & 0x200) == 0)) {
                    iVar11 = 1;
                    *(undefined2 *)((int64_t)puVar16 + 0x5e) = 0;
                    *(uint8_t *)((int64_t)puVar16 + 0x71) =
                         *(uint8_t *)((int64_t)puVar16 + 0x71) ^
                         (*(uint8_t *)((int64_t)puVar16 + 0x71) ^ *(uint8_t *)((int64_t)puVar16 + 0x72)) & 3;
                    break;
                }
                uVar6 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar6;
            } while ((int32_t)uVar6 < *piVar1);
        }
    } else {
        iVar9 = 0;
        uVar13 = 0;
        do {
            uVar8 = 0;
            uVar15 = 0xffffffff;
            iVar14 = -1;
            if (0 < *(int32_t *)(arg1 + 0x6c)) {
                do {
                    if ((uVar13 >> (uVar8 & 0x3f) & 1) == 0) {
                        iVar10 = *(int16_t *)(uVar8 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18));
                        if ((iVar10 != -1) &&
                           (((int32_t)uVar15 == -1 ||
                            (iVar10 < *(int16_t *)((int64_t)(int32_t)uVar15 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18))))
                           )) {
                            uVar15 = uVar8;
                        }
                    }
                    iVar14 = (int32_t)uVar15;
                    uVar6 = (int32_t)uVar8 + 1;
                    uVar8 = (uint64_t)uVar6;
                } while ((int32_t)uVar6 < *(int32_t *)(arg1 + 0x6c));
            }
            uVar13 = uVar13 | 1LL << ((int64_t)iVar14 & 0x3fU);
            *(int16_t *)((int64_t)iVar14 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = (int16_t)iVar9;
            if (bVar3) {
                iVar9 = 0;
                iVar11 = 1;
                if (0 < *piVar1) {
                    do {
                        if (iVar9 != iVar14) {
                            *(undefined2 *)((int64_t)iVar9 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = 0xffff;
                        }
                        iVar9 = iVar9 + 1;
                    } while (iVar9 < *piVar1);
                }
                break;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar11);
    }
    iVar10 = (int16_t)iVar11;
    iVar9 = 0;
    if (1 < iVar10) {
        iVar9 = (int32_t)iVar10;
    }
    *(int16_t *)(arg1 + 0x200) = iVar10;
    iVar11 = *(int32_t *)(arg1 + 0x1e4);
    if (iVar11 < iVar9) {
        if (iVar11 == 0) {
            iVar14 = 8;
        } else {
            iVar14 = iVar11 / 2 + iVar11;
        }
        iVar12 = iVar9;
        if (iVar9 < iVar14) {
            iVar12 = iVar14;
        }
        if (iVar11 < iVar12) {
            uVar4 = func_0x00018046d050((int64_t)iVar12 * 0xc);
            if (*(int64_t *)(arg1 + 0x1e8) != 0) {
                func_0x000180498030(uVar4, *(int64_t *)(arg1 + 0x1e8), (int64_t)*(int32_t *)(arg1 + 0x1e0) * 0xc);
                func_0x000180460d90(*(undefined8 *)(arg1 + 0x1e8));
            }
            *(undefined8 *)(arg1 + 0x1e8) = uVar4;
            *(int32_t *)(arg1 + 0x1e4) = iVar12;
        }
    }
    *(int32_t *)(arg1 + 0x1e0) = iVar9;
    *(undefined *)(arg1 + 0x1fc) = 1;
    *(undefined *)(arg1 + 0x23c) = 0;
code_r0x000180137986:
    if (*(int16_t *)(arg1 + 0x200) == 0) {
        iVar7 = 0;
    } else if (*(int16_t *)(arg1 + 0x200) == 1) {
        iVar7 = arg1 + 0x1d0;
    } else {
        iVar7 = *(int64_t *)(arg1 + 0x1e8);
    }
    if (((cVar2 != '\0') && (iVar7 != 0)) && (iVar9 = 0, 0 < *(int32_t *)(arg1 + 0x6c))) {
        do {
            iVar17 = (int64_t)iVar9 * 0x74 + *(int64_t *)(arg1 + 0x18);
            iVar5 = (int64_t)*(int16_t *)(iVar17 + 0x5e);
            if (*(int16_t *)(iVar17 + 0x5e) != -1) {
                *(undefined4 *)(iVar7 + iVar5 * 0xc) = *(undefined4 *)(iVar17 + 0x34);
                *(int16_t *)(iVar7 + 4 + iVar5 * 0xc) = (int16_t)iVar9;
                *(undefined2 *)(iVar7 + 6 + iVar5 * 0xc) = *(undefined2 *)(iVar17 + 0x5e);
                *(uint8_t *)(iVar7 + 8 + iVar5 * 0xc) = *(uint8_t *)(iVar17 + 0x71) & 3;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x6c));
    }
    *(int32_t *)(arg1 + 0x1f8) = (int32_t)*(int16_t *)(arg1 + 0x200);
    *(int64_t *)(arg1 + 0x1f0) = iVar7;
    return;
}

// ============================================================
// Function: FUN_1801376f8
// Address: 0x1801376f8
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801376f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int32_t *piVar1;
    char cVar2;
    bool bVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int16_t iVar10;
    int32_t iVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int32_t iVar14;
    uint64_t uVar15;
    uint32_t *puVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar1 = (int32_t *)(arg1 + 0x6c);
    cVar2 = *(char *)(arg1 + 0x23c);
    if (cVar2 == '\0') goto code_r0x000180137986;
    iVar9 = *piVar1;
    iVar11 = 0;
    if (iVar9 < 1) {
        iVar7 = 1;
        iVar5 = 1;
code_r0x0001801377a7:
        bVar3 = false;
    } else {
        uVar13 = 0;
        iVar14 = 0;
        do {
            iVar5 = (int64_t)iVar14 * 0x74;
            iVar7 = *(int64_t *)(arg1 + 0x18);
            iVar10 = *(int16_t *)(iVar5 + 0x5e + iVar7);
            if (iVar10 != -1) {
                if (*(char *)(iVar5 + 0x66 + iVar7) == '\0') {
                    *(undefined2 *)(iVar5 + 0x5e + iVar7) = 0xffff;
                    iVar9 = *piVar1;
                } else {
                    iVar11 = iVar11 + 1;
                    uVar13 = uVar13 | 1LL << ((int64_t)iVar10 & 0x3fU);
                }
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < iVar9);
        iVar7 = 1LL << ((uint8_t)iVar11 & 0x3f);
        iVar5 = uVar13 + 1;
        if ((iVar11 < 2) || ((*(uint32_t *)(arg1 + 4) & 0x4000000) != 0)) goto code_r0x0001801377a7;
        bVar3 = true;
    }
    if (((iVar7 == iVar5) && (!bVar3)) || (iVar11 < 1)) {
        if (((iVar11 == 0) && ((*(uint32_t *)(arg1 + 4) & 0x8000000) == 0)) && (0 < *piVar1)) {
            uVar13 = 0;
            do {
                puVar16 = (uint32_t *)(uVar13 * 0x74 + *(int64_t *)(arg1 + 0x18));
                if ((*(char *)((int64_t)puVar16 + 0x66) != '\0') && ((*puVar16 & 0x200) == 0)) {
                    iVar11 = 1;
                    *(undefined2 *)((int64_t)puVar16 + 0x5e) = 0;
                    *(uint8_t *)((int64_t)puVar16 + 0x71) =
                         *(uint8_t *)((int64_t)puVar16 + 0x71) ^
                         (*(uint8_t *)((int64_t)puVar16 + 0x71) ^ *(uint8_t *)((int64_t)puVar16 + 0x72)) & 3;
                    break;
                }
                uVar6 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar6;
            } while ((int32_t)uVar6 < *piVar1);
        }
    } else {
        iVar9 = 0;
        uVar13 = 0;
        do {
            uVar8 = 0;
            uVar15 = 0xffffffff;
            iVar14 = -1;
            if (0 < *(int32_t *)(arg1 + 0x6c)) {
                do {
                    if ((uVar13 >> (uVar8 & 0x3f) & 1) == 0) {
                        iVar10 = *(int16_t *)(uVar8 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18));
                        if ((iVar10 != -1) &&
                           (((int32_t)uVar15 == -1 ||
                            (iVar10 < *(int16_t *)((int64_t)(int32_t)uVar15 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18))))
                           )) {
                            uVar15 = uVar8;
                        }
                    }
                    iVar14 = (int32_t)uVar15;
                    uVar6 = (int32_t)uVar8 + 1;
                    uVar8 = (uint64_t)uVar6;
                } while ((int32_t)uVar6 < *(int32_t *)(arg1 + 0x6c));
            }
            uVar13 = uVar13 | 1LL << ((int64_t)iVar14 & 0x3fU);
            *(int16_t *)((int64_t)iVar14 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = (int16_t)iVar9;
            if (bVar3) {
                iVar9 = 0;
                iVar11 = 1;
                if (0 < *piVar1) {
                    do {
                        if (iVar9 != iVar14) {
                            *(undefined2 *)((int64_t)iVar9 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = 0xffff;
                        }
                        iVar9 = iVar9 + 1;
                    } while (iVar9 < *piVar1);
                }
                break;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar11);
    }
    iVar10 = (int16_t)iVar11;
    iVar9 = 0;
    if (1 < iVar10) {
        iVar9 = (int32_t)iVar10;
    }
    *(int16_t *)(arg1 + 0x200) = iVar10;
    iVar11 = *(int32_t *)(arg1 + 0x1e4);
    if (iVar11 < iVar9) {
        if (iVar11 == 0) {
            iVar14 = 8;
        } else {
            iVar14 = iVar11 / 2 + iVar11;
        }
        iVar12 = iVar9;
        if (iVar9 < iVar14) {
            iVar12 = iVar14;
        }
        if (iVar11 < iVar12) {
            uVar4 = func_0x00018046d050((int64_t)iVar12 * 0xc);
            if (*(int64_t *)(arg1 + 0x1e8) != 0) {
                func_0x000180498030(uVar4, *(int64_t *)(arg1 + 0x1e8), (int64_t)*(int32_t *)(arg1 + 0x1e0) * 0xc);
                func_0x000180460d90(*(undefined8 *)(arg1 + 0x1e8));
            }
            *(undefined8 *)(arg1 + 0x1e8) = uVar4;
            *(int32_t *)(arg1 + 0x1e4) = iVar12;
        }
    }
    *(int32_t *)(arg1 + 0x1e0) = iVar9;
    *(undefined *)(arg1 + 0x1fc) = 1;
    *(undefined *)(arg1 + 0x23c) = 0;
code_r0x000180137986:
    if (*(int16_t *)(arg1 + 0x200) == 0) {
        iVar7 = 0;
    } else if (*(int16_t *)(arg1 + 0x200) == 1) {
        iVar7 = arg1 + 0x1d0;
    } else {
        iVar7 = *(int64_t *)(arg1 + 0x1e8);
    }
    if (((cVar2 != '\0') && (iVar7 != 0)) && (iVar9 = 0, 0 < *(int32_t *)(arg1 + 0x6c))) {
        do {
            iVar17 = (int64_t)iVar9 * 0x74 + *(int64_t *)(arg1 + 0x18);
            iVar5 = (int64_t)*(int16_t *)(iVar17 + 0x5e);
            if (*(int16_t *)(iVar17 + 0x5e) != -1) {
                *(undefined4 *)(iVar7 + iVar5 * 0xc) = *(undefined4 *)(iVar17 + 0x34);
                *(int16_t *)(iVar7 + 4 + iVar5 * 0xc) = (int16_t)iVar9;
                *(undefined2 *)(iVar7 + 6 + iVar5 * 0xc) = *(undefined2 *)(iVar17 + 0x5e);
                *(uint8_t *)(iVar7 + 8 + iVar5 * 0xc) = *(uint8_t *)(iVar17 + 0x71) & 3;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x6c));
    }
    *(int32_t *)(arg1 + 0x1f8) = (int32_t)*(int16_t *)(arg1 + 0x200);
    *(int64_t *)(arg1 + 0x1f0) = iVar7;
    return;
}

// ============================================================
// Function: FUN_180137718
// Address: 0x180137718
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801376f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int32_t *piVar1;
    char cVar2;
    bool bVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int16_t iVar10;
    int32_t iVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int32_t iVar14;
    uint64_t uVar15;
    uint32_t *puVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar1 = (int32_t *)(arg1 + 0x6c);
    cVar2 = *(char *)(arg1 + 0x23c);
    if (cVar2 == '\0') goto code_r0x000180137986;
    iVar9 = *piVar1;
    iVar11 = 0;
    if (iVar9 < 1) {
        iVar7 = 1;
        iVar5 = 1;
code_r0x0001801377a7:
        bVar3 = false;
    } else {
        uVar13 = 0;
        iVar14 = 0;
        do {
            iVar5 = (int64_t)iVar14 * 0x74;
            iVar7 = *(int64_t *)(arg1 + 0x18);
            iVar10 = *(int16_t *)(iVar5 + 0x5e + iVar7);
            if (iVar10 != -1) {
                if (*(char *)(iVar5 + 0x66 + iVar7) == '\0') {
                    *(undefined2 *)(iVar5 + 0x5e + iVar7) = 0xffff;
                    iVar9 = *piVar1;
                } else {
                    iVar11 = iVar11 + 1;
                    uVar13 = uVar13 | 1LL << ((int64_t)iVar10 & 0x3fU);
                }
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < iVar9);
        iVar7 = 1LL << ((uint8_t)iVar11 & 0x3f);
        iVar5 = uVar13 + 1;
        if ((iVar11 < 2) || ((*(uint32_t *)(arg1 + 4) & 0x4000000) != 0)) goto code_r0x0001801377a7;
        bVar3 = true;
    }
    if (((iVar7 == iVar5) && (!bVar3)) || (iVar11 < 1)) {
        if (((iVar11 == 0) && ((*(uint32_t *)(arg1 + 4) & 0x8000000) == 0)) && (0 < *piVar1)) {
            uVar13 = 0;
            do {
                puVar16 = (uint32_t *)(uVar13 * 0x74 + *(int64_t *)(arg1 + 0x18));
                if ((*(char *)((int64_t)puVar16 + 0x66) != '\0') && ((*puVar16 & 0x200) == 0)) {
                    iVar11 = 1;
                    *(undefined2 *)((int64_t)puVar16 + 0x5e) = 0;
                    *(uint8_t *)((int64_t)puVar16 + 0x71) =
                         *(uint8_t *)((int64_t)puVar16 + 0x71) ^
                         (*(uint8_t *)((int64_t)puVar16 + 0x71) ^ *(uint8_t *)((int64_t)puVar16 + 0x72)) & 3;
                    break;
                }
                uVar6 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar6;
            } while ((int32_t)uVar6 < *piVar1);
        }
    } else {
        iVar9 = 0;
        uVar13 = 0;
        do {
            uVar8 = 0;
            uVar15 = 0xffffffff;
            iVar14 = -1;
            if (0 < *(int32_t *)(arg1 + 0x6c)) {
                do {
                    if ((uVar13 >> (uVar8 & 0x3f) & 1) == 0) {
                        iVar10 = *(int16_t *)(uVar8 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18));
                        if ((iVar10 != -1) &&
                           (((int32_t)uVar15 == -1 ||
                            (iVar10 < *(int16_t *)((int64_t)(int32_t)uVar15 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18))))
                           )) {
                            uVar15 = uVar8;
                        }
                    }
                    iVar14 = (int32_t)uVar15;
                    uVar6 = (int32_t)uVar8 + 1;
                    uVar8 = (uint64_t)uVar6;
                } while ((int32_t)uVar6 < *(int32_t *)(arg1 + 0x6c));
            }
            uVar13 = uVar13 | 1LL << ((int64_t)iVar14 & 0x3fU);
            *(int16_t *)((int64_t)iVar14 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = (int16_t)iVar9;
            if (bVar3) {
                iVar9 = 0;
                iVar11 = 1;
                if (0 < *piVar1) {
                    do {
                        if (iVar9 != iVar14) {
                            *(undefined2 *)((int64_t)iVar9 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = 0xffff;
                        }
                        iVar9 = iVar9 + 1;
                    } while (iVar9 < *piVar1);
                }
                break;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar11);
    }
    iVar10 = (int16_t)iVar11;
    iVar9 = 0;
    if (1 < iVar10) {
        iVar9 = (int32_t)iVar10;
    }
    *(int16_t *)(arg1 + 0x200) = iVar10;
    iVar11 = *(int32_t *)(arg1 + 0x1e4);
    if (iVar11 < iVar9) {
        if (iVar11 == 0) {
            iVar14 = 8;
        } else {
            iVar14 = iVar11 / 2 + iVar11;
        }
        iVar12 = iVar9;
        if (iVar9 < iVar14) {
            iVar12 = iVar14;
        }
        if (iVar11 < iVar12) {
            uVar4 = func_0x00018046d050((int64_t)iVar12 * 0xc);
            if (*(int64_t *)(arg1 + 0x1e8) != 0) {
                func_0x000180498030(uVar4, *(int64_t *)(arg1 + 0x1e8), (int64_t)*(int32_t *)(arg1 + 0x1e0) * 0xc);
                func_0x000180460d90(*(undefined8 *)(arg1 + 0x1e8));
            }
            *(undefined8 *)(arg1 + 0x1e8) = uVar4;
            *(int32_t *)(arg1 + 0x1e4) = iVar12;
        }
    }
    *(int32_t *)(arg1 + 0x1e0) = iVar9;
    *(undefined *)(arg1 + 0x1fc) = 1;
    *(undefined *)(arg1 + 0x23c) = 0;
code_r0x000180137986:
    if (*(int16_t *)(arg1 + 0x200) == 0) {
        iVar7 = 0;
    } else if (*(int16_t *)(arg1 + 0x200) == 1) {
        iVar7 = arg1 + 0x1d0;
    } else {
        iVar7 = *(int64_t *)(arg1 + 0x1e8);
    }
    if (((cVar2 != '\0') && (iVar7 != 0)) && (iVar9 = 0, 0 < *(int32_t *)(arg1 + 0x6c))) {
        do {
            iVar17 = (int64_t)iVar9 * 0x74 + *(int64_t *)(arg1 + 0x18);
            iVar5 = (int64_t)*(int16_t *)(iVar17 + 0x5e);
            if (*(int16_t *)(iVar17 + 0x5e) != -1) {
                *(undefined4 *)(iVar7 + iVar5 * 0xc) = *(undefined4 *)(iVar17 + 0x34);
                *(int16_t *)(iVar7 + 4 + iVar5 * 0xc) = (int16_t)iVar9;
                *(undefined2 *)(iVar7 + 6 + iVar5 * 0xc) = *(undefined2 *)(iVar17 + 0x5e);
                *(uint8_t *)(iVar7 + 8 + iVar5 * 0xc) = *(uint8_t *)(iVar17 + 0x71) & 3;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x6c));
    }
    *(int32_t *)(arg1 + 0x1f8) = (int32_t)*(int16_t *)(arg1 + 0x200);
    *(int64_t *)(arg1 + 0x1f0) = iVar7;
    return;
}

// ============================================================
// Function: FUN_180137724
// Address: 0x180137724
// Size: 465 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801376f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int32_t *piVar1;
    char cVar2;
    bool bVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int16_t iVar10;
    int32_t iVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int32_t iVar14;
    uint64_t uVar15;
    uint32_t *puVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar1 = (int32_t *)(arg1 + 0x6c);
    cVar2 = *(char *)(arg1 + 0x23c);
    if (cVar2 == '\0') goto code_r0x000180137986;
    iVar9 = *piVar1;
    iVar11 = 0;
    if (iVar9 < 1) {
        iVar7 = 1;
        iVar5 = 1;
code_r0x0001801377a7:
        bVar3 = false;
    } else {
        uVar13 = 0;
        iVar14 = 0;
        do {
            iVar5 = (int64_t)iVar14 * 0x74;
            iVar7 = *(int64_t *)(arg1 + 0x18);
            iVar10 = *(int16_t *)(iVar5 + 0x5e + iVar7);
            if (iVar10 != -1) {
                if (*(char *)(iVar5 + 0x66 + iVar7) == '\0') {
                    *(undefined2 *)(iVar5 + 0x5e + iVar7) = 0xffff;
                    iVar9 = *piVar1;
                } else {
                    iVar11 = iVar11 + 1;
                    uVar13 = uVar13 | 1LL << ((int64_t)iVar10 & 0x3fU);
                }
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < iVar9);
        iVar7 = 1LL << ((uint8_t)iVar11 & 0x3f);
        iVar5 = uVar13 + 1;
        if ((iVar11 < 2) || ((*(uint32_t *)(arg1 + 4) & 0x4000000) != 0)) goto code_r0x0001801377a7;
        bVar3 = true;
    }
    if (((iVar7 == iVar5) && (!bVar3)) || (iVar11 < 1)) {
        if (((iVar11 == 0) && ((*(uint32_t *)(arg1 + 4) & 0x8000000) == 0)) && (0 < *piVar1)) {
            uVar13 = 0;
            do {
                puVar16 = (uint32_t *)(uVar13 * 0x74 + *(int64_t *)(arg1 + 0x18));
                if ((*(char *)((int64_t)puVar16 + 0x66) != '\0') && ((*puVar16 & 0x200) == 0)) {
                    iVar11 = 1;
                    *(undefined2 *)((int64_t)puVar16 + 0x5e) = 0;
                    *(uint8_t *)((int64_t)puVar16 + 0x71) =
                         *(uint8_t *)((int64_t)puVar16 + 0x71) ^
                         (*(uint8_t *)((int64_t)puVar16 + 0x71) ^ *(uint8_t *)((int64_t)puVar16 + 0x72)) & 3;
                    break;
                }
                uVar6 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar6;
            } while ((int32_t)uVar6 < *piVar1);
        }
    } else {
        iVar9 = 0;
        uVar13 = 0;
        do {
            uVar8 = 0;
            uVar15 = 0xffffffff;
            iVar14 = -1;
            if (0 < *(int32_t *)(arg1 + 0x6c)) {
                do {
                    if ((uVar13 >> (uVar8 & 0x3f) & 1) == 0) {
                        iVar10 = *(int16_t *)(uVar8 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18));
                        if ((iVar10 != -1) &&
                           (((int32_t)uVar15 == -1 ||
                            (iVar10 < *(int16_t *)((int64_t)(int32_t)uVar15 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18))))
                           )) {
                            uVar15 = uVar8;
                        }
                    }
                    iVar14 = (int32_t)uVar15;
                    uVar6 = (int32_t)uVar8 + 1;
                    uVar8 = (uint64_t)uVar6;
                } while ((int32_t)uVar6 < *(int32_t *)(arg1 + 0x6c));
            }
            uVar13 = uVar13 | 1LL << ((int64_t)iVar14 & 0x3fU);
            *(int16_t *)((int64_t)iVar14 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = (int16_t)iVar9;
            if (bVar3) {
                iVar9 = 0;
                iVar11 = 1;
                if (0 < *piVar1) {
                    do {
                        if (iVar9 != iVar14) {
                            *(undefined2 *)((int64_t)iVar9 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = 0xffff;
                        }
                        iVar9 = iVar9 + 1;
                    } while (iVar9 < *piVar1);
                }
                break;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar11);
    }
    iVar10 = (int16_t)iVar11;
    iVar9 = 0;
    if (1 < iVar10) {
        iVar9 = (int32_t)iVar10;
    }
    *(int16_t *)(arg1 + 0x200) = iVar10;
    iVar11 = *(int32_t *)(arg1 + 0x1e4);
    if (iVar11 < iVar9) {
        if (iVar11 == 0) {
            iVar14 = 8;
        } else {
            iVar14 = iVar11 / 2 + iVar11;
        }
        iVar12 = iVar9;
        if (iVar9 < iVar14) {
            iVar12 = iVar14;
        }
        if (iVar11 < iVar12) {
            uVar4 = func_0x00018046d050((int64_t)iVar12 * 0xc);
            if (*(int64_t *)(arg1 + 0x1e8) != 0) {
                func_0x000180498030(uVar4, *(int64_t *)(arg1 + 0x1e8), (int64_t)*(int32_t *)(arg1 + 0x1e0) * 0xc);
                func_0x000180460d90(*(undefined8 *)(arg1 + 0x1e8));
            }
            *(undefined8 *)(arg1 + 0x1e8) = uVar4;
            *(int32_t *)(arg1 + 0x1e4) = iVar12;
        }
    }
    *(int32_t *)(arg1 + 0x1e0) = iVar9;
    *(undefined *)(arg1 + 0x1fc) = 1;
    *(undefined *)(arg1 + 0x23c) = 0;
code_r0x000180137986:
    if (*(int16_t *)(arg1 + 0x200) == 0) {
        iVar7 = 0;
    } else if (*(int16_t *)(arg1 + 0x200) == 1) {
        iVar7 = arg1 + 0x1d0;
    } else {
        iVar7 = *(int64_t *)(arg1 + 0x1e8);
    }
    if (((cVar2 != '\0') && (iVar7 != 0)) && (iVar9 = 0, 0 < *(int32_t *)(arg1 + 0x6c))) {
        do {
            iVar17 = (int64_t)iVar9 * 0x74 + *(int64_t *)(arg1 + 0x18);
            iVar5 = (int64_t)*(int16_t *)(iVar17 + 0x5e);
            if (*(int16_t *)(iVar17 + 0x5e) != -1) {
                *(undefined4 *)(iVar7 + iVar5 * 0xc) = *(undefined4 *)(iVar17 + 0x34);
                *(int16_t *)(iVar7 + 4 + iVar5 * 0xc) = (int16_t)iVar9;
                *(undefined2 *)(iVar7 + 6 + iVar5 * 0xc) = *(undefined2 *)(iVar17 + 0x5e);
                *(uint8_t *)(iVar7 + 8 + iVar5 * 0xc) = *(uint8_t *)(iVar17 + 0x71) & 3;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x6c));
    }
    *(int32_t *)(arg1 + 0x1f8) = (int32_t)*(int16_t *)(arg1 + 0x200);
    *(int64_t *)(arg1 + 0x1f0) = iVar7;
    return;
}

// ============================================================
// Function: FUN_1801378f5
// Address: 0x1801378f5
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801376f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int32_t *piVar1;
    char cVar2;
    bool bVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int16_t iVar10;
    int32_t iVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int32_t iVar14;
    uint64_t uVar15;
    uint32_t *puVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar1 = (int32_t *)(arg1 + 0x6c);
    cVar2 = *(char *)(arg1 + 0x23c);
    if (cVar2 == '\0') goto code_r0x000180137986;
    iVar9 = *piVar1;
    iVar11 = 0;
    if (iVar9 < 1) {
        iVar7 = 1;
        iVar5 = 1;
code_r0x0001801377a7:
        bVar3 = false;
    } else {
        uVar13 = 0;
        iVar14 = 0;
        do {
            iVar5 = (int64_t)iVar14 * 0x74;
            iVar7 = *(int64_t *)(arg1 + 0x18);
            iVar10 = *(int16_t *)(iVar5 + 0x5e + iVar7);
            if (iVar10 != -1) {
                if (*(char *)(iVar5 + 0x66 + iVar7) == '\0') {
                    *(undefined2 *)(iVar5 + 0x5e + iVar7) = 0xffff;
                    iVar9 = *piVar1;
                } else {
                    iVar11 = iVar11 + 1;
                    uVar13 = uVar13 | 1LL << ((int64_t)iVar10 & 0x3fU);
                }
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < iVar9);
        iVar7 = 1LL << ((uint8_t)iVar11 & 0x3f);
        iVar5 = uVar13 + 1;
        if ((iVar11 < 2) || ((*(uint32_t *)(arg1 + 4) & 0x4000000) != 0)) goto code_r0x0001801377a7;
        bVar3 = true;
    }
    if (((iVar7 == iVar5) && (!bVar3)) || (iVar11 < 1)) {
        if (((iVar11 == 0) && ((*(uint32_t *)(arg1 + 4) & 0x8000000) == 0)) && (0 < *piVar1)) {
            uVar13 = 0;
            do {
                puVar16 = (uint32_t *)(uVar13 * 0x74 + *(int64_t *)(arg1 + 0x18));
                if ((*(char *)((int64_t)puVar16 + 0x66) != '\0') && ((*puVar16 & 0x200) == 0)) {
                    iVar11 = 1;
                    *(undefined2 *)((int64_t)puVar16 + 0x5e) = 0;
                    *(uint8_t *)((int64_t)puVar16 + 0x71) =
                         *(uint8_t *)((int64_t)puVar16 + 0x71) ^
                         (*(uint8_t *)((int64_t)puVar16 + 0x71) ^ *(uint8_t *)((int64_t)puVar16 + 0x72)) & 3;
                    break;
                }
                uVar6 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar6;
            } while ((int32_t)uVar6 < *piVar1);
        }
    } else {
        iVar9 = 0;
        uVar13 = 0;
        do {
            uVar8 = 0;
            uVar15 = 0xffffffff;
            iVar14 = -1;
            if (0 < *(int32_t *)(arg1 + 0x6c)) {
                do {
                    if ((uVar13 >> (uVar8 & 0x3f) & 1) == 0) {
                        iVar10 = *(int16_t *)(uVar8 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18));
                        if ((iVar10 != -1) &&
                           (((int32_t)uVar15 == -1 ||
                            (iVar10 < *(int16_t *)((int64_t)(int32_t)uVar15 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18))))
                           )) {
                            uVar15 = uVar8;
                        }
                    }
                    iVar14 = (int32_t)uVar15;
                    uVar6 = (int32_t)uVar8 + 1;
                    uVar8 = (uint64_t)uVar6;
                } while ((int32_t)uVar6 < *(int32_t *)(arg1 + 0x6c));
            }
            uVar13 = uVar13 | 1LL << ((int64_t)iVar14 & 0x3fU);
            *(int16_t *)((int64_t)iVar14 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = (int16_t)iVar9;
            if (bVar3) {
                iVar9 = 0;
                iVar11 = 1;
                if (0 < *piVar1) {
                    do {
                        if (iVar9 != iVar14) {
                            *(undefined2 *)((int64_t)iVar9 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = 0xffff;
                        }
                        iVar9 = iVar9 + 1;
                    } while (iVar9 < *piVar1);
                }
                break;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar11);
    }
    iVar10 = (int16_t)iVar11;
    iVar9 = 0;
    if (1 < iVar10) {
        iVar9 = (int32_t)iVar10;
    }
    *(int16_t *)(arg1 + 0x200) = iVar10;
    iVar11 = *(int32_t *)(arg1 + 0x1e4);
    if (iVar11 < iVar9) {
        if (iVar11 == 0) {
            iVar14 = 8;
        } else {
            iVar14 = iVar11 / 2 + iVar11;
        }
        iVar12 = iVar9;
        if (iVar9 < iVar14) {
            iVar12 = iVar14;
        }
        if (iVar11 < iVar12) {
            uVar4 = func_0x00018046d050((int64_t)iVar12 * 0xc);
            if (*(int64_t *)(arg1 + 0x1e8) != 0) {
                func_0x000180498030(uVar4, *(int64_t *)(arg1 + 0x1e8), (int64_t)*(int32_t *)(arg1 + 0x1e0) * 0xc);
                func_0x000180460d90(*(undefined8 *)(arg1 + 0x1e8));
            }
            *(undefined8 *)(arg1 + 0x1e8) = uVar4;
            *(int32_t *)(arg1 + 0x1e4) = iVar12;
        }
    }
    *(int32_t *)(arg1 + 0x1e0) = iVar9;
    *(undefined *)(arg1 + 0x1fc) = 1;
    *(undefined *)(arg1 + 0x23c) = 0;
code_r0x000180137986:
    if (*(int16_t *)(arg1 + 0x200) == 0) {
        iVar7 = 0;
    } else if (*(int16_t *)(arg1 + 0x200) == 1) {
        iVar7 = arg1 + 0x1d0;
    } else {
        iVar7 = *(int64_t *)(arg1 + 0x1e8);
    }
    if (((cVar2 != '\0') && (iVar7 != 0)) && (iVar9 = 0, 0 < *(int32_t *)(arg1 + 0x6c))) {
        do {
            iVar17 = (int64_t)iVar9 * 0x74 + *(int64_t *)(arg1 + 0x18);
            iVar5 = (int64_t)*(int16_t *)(iVar17 + 0x5e);
            if (*(int16_t *)(iVar17 + 0x5e) != -1) {
                *(undefined4 *)(iVar7 + iVar5 * 0xc) = *(undefined4 *)(iVar17 + 0x34);
                *(int16_t *)(iVar7 + 4 + iVar5 * 0xc) = (int16_t)iVar9;
                *(undefined2 *)(iVar7 + 6 + iVar5 * 0xc) = *(undefined2 *)(iVar17 + 0x5e);
                *(uint8_t *)(iVar7 + 8 + iVar5 * 0xc) = *(uint8_t *)(iVar17 + 0x71) & 3;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x6c));
    }
    *(int32_t *)(arg1 + 0x1f8) = (int32_t)*(int16_t *)(arg1 + 0x200);
    *(int64_t *)(arg1 + 0x1f0) = iVar7;
    return;
}

// ============================================================
// Function: FUN_180137986
// Address: 0x180137986
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801376f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int32_t *piVar1;
    char cVar2;
    bool bVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int16_t iVar10;
    int32_t iVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int32_t iVar14;
    uint64_t uVar15;
    uint32_t *puVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar1 = (int32_t *)(arg1 + 0x6c);
    cVar2 = *(char *)(arg1 + 0x23c);
    if (cVar2 == '\0') goto code_r0x000180137986;
    iVar9 = *piVar1;
    iVar11 = 0;
    if (iVar9 < 1) {
        iVar7 = 1;
        iVar5 = 1;
code_r0x0001801377a7:
        bVar3 = false;
    } else {
        uVar13 = 0;
        iVar14 = 0;
        do {
            iVar5 = (int64_t)iVar14 * 0x74;
            iVar7 = *(int64_t *)(arg1 + 0x18);
            iVar10 = *(int16_t *)(iVar5 + 0x5e + iVar7);
            if (iVar10 != -1) {
                if (*(char *)(iVar5 + 0x66 + iVar7) == '\0') {
                    *(undefined2 *)(iVar5 + 0x5e + iVar7) = 0xffff;
                    iVar9 = *piVar1;
                } else {
                    iVar11 = iVar11 + 1;
                    uVar13 = uVar13 | 1LL << ((int64_t)iVar10 & 0x3fU);
                }
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < iVar9);
        iVar7 = 1LL << ((uint8_t)iVar11 & 0x3f);
        iVar5 = uVar13 + 1;
        if ((iVar11 < 2) || ((*(uint32_t *)(arg1 + 4) & 0x4000000) != 0)) goto code_r0x0001801377a7;
        bVar3 = true;
    }
    if (((iVar7 == iVar5) && (!bVar3)) || (iVar11 < 1)) {
        if (((iVar11 == 0) && ((*(uint32_t *)(arg1 + 4) & 0x8000000) == 0)) && (0 < *piVar1)) {
            uVar13 = 0;
            do {
                puVar16 = (uint32_t *)(uVar13 * 0x74 + *(int64_t *)(arg1 + 0x18));
                if ((*(char *)((int64_t)puVar16 + 0x66) != '\0') && ((*puVar16 & 0x200) == 0)) {
                    iVar11 = 1;
                    *(undefined2 *)((int64_t)puVar16 + 0x5e) = 0;
                    *(uint8_t *)((int64_t)puVar16 + 0x71) =
                         *(uint8_t *)((int64_t)puVar16 + 0x71) ^
                         (*(uint8_t *)((int64_t)puVar16 + 0x71) ^ *(uint8_t *)((int64_t)puVar16 + 0x72)) & 3;
                    break;
                }
                uVar6 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar6;
            } while ((int32_t)uVar6 < *piVar1);
        }
    } else {
        iVar9 = 0;
        uVar13 = 0;
        do {
            uVar8 = 0;
            uVar15 = 0xffffffff;
            iVar14 = -1;
            if (0 < *(int32_t *)(arg1 + 0x6c)) {
                do {
                    if ((uVar13 >> (uVar8 & 0x3f) & 1) == 0) {
                        iVar10 = *(int16_t *)(uVar8 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18));
                        if ((iVar10 != -1) &&
                           (((int32_t)uVar15 == -1 ||
                            (iVar10 < *(int16_t *)((int64_t)(int32_t)uVar15 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18))))
                           )) {
                            uVar15 = uVar8;
                        }
                    }
                    iVar14 = (int32_t)uVar15;
                    uVar6 = (int32_t)uVar8 + 1;
                    uVar8 = (uint64_t)uVar6;
                } while ((int32_t)uVar6 < *(int32_t *)(arg1 + 0x6c));
            }
            uVar13 = uVar13 | 1LL << ((int64_t)iVar14 & 0x3fU);
            *(int16_t *)((int64_t)iVar14 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = (int16_t)iVar9;
            if (bVar3) {
                iVar9 = 0;
                iVar11 = 1;
                if (0 < *piVar1) {
                    do {
                        if (iVar9 != iVar14) {
                            *(undefined2 *)((int64_t)iVar9 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = 0xffff;
                        }
                        iVar9 = iVar9 + 1;
                    } while (iVar9 < *piVar1);
                }
                break;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar11);
    }
    iVar10 = (int16_t)iVar11;
    iVar9 = 0;
    if (1 < iVar10) {
        iVar9 = (int32_t)iVar10;
    }
    *(int16_t *)(arg1 + 0x200) = iVar10;
    iVar11 = *(int32_t *)(arg1 + 0x1e4);
    if (iVar11 < iVar9) {
        if (iVar11 == 0) {
            iVar14 = 8;
        } else {
            iVar14 = iVar11 / 2 + iVar11;
        }
        iVar12 = iVar9;
        if (iVar9 < iVar14) {
            iVar12 = iVar14;
        }
        if (iVar11 < iVar12) {
            uVar4 = func_0x00018046d050((int64_t)iVar12 * 0xc);
            if (*(int64_t *)(arg1 + 0x1e8) != 0) {
                func_0x000180498030(uVar4, *(int64_t *)(arg1 + 0x1e8), (int64_t)*(int32_t *)(arg1 + 0x1e0) * 0xc);
                func_0x000180460d90(*(undefined8 *)(arg1 + 0x1e8));
            }
            *(undefined8 *)(arg1 + 0x1e8) = uVar4;
            *(int32_t *)(arg1 + 0x1e4) = iVar12;
        }
    }
    *(int32_t *)(arg1 + 0x1e0) = iVar9;
    *(undefined *)(arg1 + 0x1fc) = 1;
    *(undefined *)(arg1 + 0x23c) = 0;
code_r0x000180137986:
    if (*(int16_t *)(arg1 + 0x200) == 0) {
        iVar7 = 0;
    } else if (*(int16_t *)(arg1 + 0x200) == 1) {
        iVar7 = arg1 + 0x1d0;
    } else {
        iVar7 = *(int64_t *)(arg1 + 0x1e8);
    }
    if (((cVar2 != '\0') && (iVar7 != 0)) && (iVar9 = 0, 0 < *(int32_t *)(arg1 + 0x6c))) {
        do {
            iVar17 = (int64_t)iVar9 * 0x74 + *(int64_t *)(arg1 + 0x18);
            iVar5 = (int64_t)*(int16_t *)(iVar17 + 0x5e);
            if (*(int16_t *)(iVar17 + 0x5e) != -1) {
                *(undefined4 *)(iVar7 + iVar5 * 0xc) = *(undefined4 *)(iVar17 + 0x34);
                *(int16_t *)(iVar7 + 4 + iVar5 * 0xc) = (int16_t)iVar9;
                *(undefined2 *)(iVar7 + 6 + iVar5 * 0xc) = *(undefined2 *)(iVar17 + 0x5e);
                *(uint8_t *)(iVar7 + 8 + iVar5 * 0xc) = *(uint8_t *)(iVar17 + 0x71) & 3;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x6c));
    }
    *(int32_t *)(arg1 + 0x1f8) = (int32_t)*(int16_t *)(arg1 + 0x200);
    *(int64_t *)(arg1 + 0x1f0) = iVar7;
    return;
}

// ============================================================
// Function: FUN_1801379bb
// Address: 0x1801379bb
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801376f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int32_t *piVar1;
    char cVar2;
    bool bVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int16_t iVar10;
    int32_t iVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int32_t iVar14;
    uint64_t uVar15;
    uint32_t *puVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar1 = (int32_t *)(arg1 + 0x6c);
    cVar2 = *(char *)(arg1 + 0x23c);
    if (cVar2 == '\0') goto code_r0x000180137986;
    iVar9 = *piVar1;
    iVar11 = 0;
    if (iVar9 < 1) {
        iVar7 = 1;
        iVar5 = 1;
code_r0x0001801377a7:
        bVar3 = false;
    } else {
        uVar13 = 0;
        iVar14 = 0;
        do {
            iVar5 = (int64_t)iVar14 * 0x74;
            iVar7 = *(int64_t *)(arg1 + 0x18);
            iVar10 = *(int16_t *)(iVar5 + 0x5e + iVar7);
            if (iVar10 != -1) {
                if (*(char *)(iVar5 + 0x66 + iVar7) == '\0') {
                    *(undefined2 *)(iVar5 + 0x5e + iVar7) = 0xffff;
                    iVar9 = *piVar1;
                } else {
                    iVar11 = iVar11 + 1;
                    uVar13 = uVar13 | 1LL << ((int64_t)iVar10 & 0x3fU);
                }
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < iVar9);
        iVar7 = 1LL << ((uint8_t)iVar11 & 0x3f);
        iVar5 = uVar13 + 1;
        if ((iVar11 < 2) || ((*(uint32_t *)(arg1 + 4) & 0x4000000) != 0)) goto code_r0x0001801377a7;
        bVar3 = true;
    }
    if (((iVar7 == iVar5) && (!bVar3)) || (iVar11 < 1)) {
        if (((iVar11 == 0) && ((*(uint32_t *)(arg1 + 4) & 0x8000000) == 0)) && (0 < *piVar1)) {
            uVar13 = 0;
            do {
                puVar16 = (uint32_t *)(uVar13 * 0x74 + *(int64_t *)(arg1 + 0x18));
                if ((*(char *)((int64_t)puVar16 + 0x66) != '\0') && ((*puVar16 & 0x200) == 0)) {
                    iVar11 = 1;
                    *(undefined2 *)((int64_t)puVar16 + 0x5e) = 0;
                    *(uint8_t *)((int64_t)puVar16 + 0x71) =
                         *(uint8_t *)((int64_t)puVar16 + 0x71) ^
                         (*(uint8_t *)((int64_t)puVar16 + 0x71) ^ *(uint8_t *)((int64_t)puVar16 + 0x72)) & 3;
                    break;
                }
                uVar6 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar6;
            } while ((int32_t)uVar6 < *piVar1);
        }
    } else {
        iVar9 = 0;
        uVar13 = 0;
        do {
            uVar8 = 0;
            uVar15 = 0xffffffff;
            iVar14 = -1;
            if (0 < *(int32_t *)(arg1 + 0x6c)) {
                do {
                    if ((uVar13 >> (uVar8 & 0x3f) & 1) == 0) {
                        iVar10 = *(int16_t *)(uVar8 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18));
                        if ((iVar10 != -1) &&
                           (((int32_t)uVar15 == -1 ||
                            (iVar10 < *(int16_t *)((int64_t)(int32_t)uVar15 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18))))
                           )) {
                            uVar15 = uVar8;
                        }
                    }
                    iVar14 = (int32_t)uVar15;
                    uVar6 = (int32_t)uVar8 + 1;
                    uVar8 = (uint64_t)uVar6;
                } while ((int32_t)uVar6 < *(int32_t *)(arg1 + 0x6c));
            }
            uVar13 = uVar13 | 1LL << ((int64_t)iVar14 & 0x3fU);
            *(int16_t *)((int64_t)iVar14 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = (int16_t)iVar9;
            if (bVar3) {
                iVar9 = 0;
                iVar11 = 1;
                if (0 < *piVar1) {
                    do {
                        if (iVar9 != iVar14) {
                            *(undefined2 *)((int64_t)iVar9 * 0x74 + 0x5e + *(int64_t *)(arg1 + 0x18)) = 0xffff;
                        }
                        iVar9 = iVar9 + 1;
                    } while (iVar9 < *piVar1);
                }
                break;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar11);
    }
    iVar10 = (int16_t)iVar11;
    iVar9 = 0;
    if (1 < iVar10) {
        iVar9 = (int32_t)iVar10;
    }
    *(int16_t *)(arg1 + 0x200) = iVar10;
    iVar11 = *(int32_t *)(arg1 + 0x1e4);
    if (iVar11 < iVar9) {
        if (iVar11 == 0) {
            iVar14 = 8;
        } else {
            iVar14 = iVar11 / 2 + iVar11;
        }
        iVar12 = iVar9;
        if (iVar9 < iVar14) {
            iVar12 = iVar14;
        }
        if (iVar11 < iVar12) {
            uVar4 = func_0x00018046d050((int64_t)iVar12 * 0xc);
            if (*(int64_t *)(arg1 + 0x1e8) != 0) {
                func_0x000180498030(uVar4, *(int64_t *)(arg1 + 0x1e8), (int64_t)*(int32_t *)(arg1 + 0x1e0) * 0xc);
                func_0x000180460d90(*(undefined8 *)(arg1 + 0x1e8));
            }
            *(undefined8 *)(arg1 + 0x1e8) = uVar4;
            *(int32_t *)(arg1 + 0x1e4) = iVar12;
        }
    }
    *(int32_t *)(arg1 + 0x1e0) = iVar9;
    *(undefined *)(arg1 + 0x1fc) = 1;
    *(undefined *)(arg1 + 0x23c) = 0;
code_r0x000180137986:
    if (*(int16_t *)(arg1 + 0x200) == 0) {
        iVar7 = 0;
    } else if (*(int16_t *)(arg1 + 0x200) == 1) {
        iVar7 = arg1 + 0x1d0;
    } else {
        iVar7 = *(int64_t *)(arg1 + 0x1e8);
    }
    if (((cVar2 != '\0') && (iVar7 != 0)) && (iVar9 = 0, 0 < *(int32_t *)(arg1 + 0x6c))) {
        do {
            iVar17 = (int64_t)iVar9 * 0x74 + *(int64_t *)(arg1 + 0x18);
            iVar5 = (int64_t)*(int16_t *)(iVar17 + 0x5e);
            if (*(int16_t *)(iVar17 + 0x5e) != -1) {
                *(undefined4 *)(iVar7 + iVar5 * 0xc) = *(undefined4 *)(iVar17 + 0x34);
                *(int16_t *)(iVar7 + 4 + iVar5 * 0xc) = (int16_t)iVar9;
                *(undefined2 *)(iVar7 + 6 + iVar5 * 0xc) = *(undefined2 *)(iVar17 + 0x5e);
                *(uint8_t *)(iVar7 + 8 + iVar5 * 0xc) = *(uint8_t *)(iVar17 + 0x71) & 3;
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x6c));
    }
    *(int32_t *)(arg1 + 0x1f8) = (int32_t)*(int16_t *)(arg1 + 0x200);
    *(int64_t *)(arg1 + 0x1f0) = iVar7;
    return;
}

// ============================================================
// Function: FUN_180137af0
// Address: 0x180137af0
// Size: 299 bytes
// ============================================================
void fcn.180137af0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 *puVar3;
    
    if (arg1 != 0) {
        *(undefined (*) [16])arg1 = ZEXT816(0);
        *(undefined4 *)(arg1 + 0x10) = 0;
    }
    iVar2 = 0;
    puVar3 = (undefined8 *)(arg1 + 0x14);
    iVar1 = (int32_t)arg4;
    if (3 < iVar1) {
        do {
            if (puVar3 != (undefined8 *)0x0) {
                *puVar3 = 0;
                *(undefined4 *)(puVar3 + 1) = 0xffffffff;
                *(uint8_t *)((int64_t)puVar3 + 0xe) = *(uint8_t *)((int64_t)puVar3 + 0xe) & 0xec | 0xc;
                *(undefined2 *)((int64_t)puVar3 + 0xc) = 0xffff;
            }
            if (puVar3 + 2 != (undefined8 *)0x0) {
                *(undefined4 *)(puVar3 + 2) = 0;
                *(undefined4 *)((int64_t)puVar3 + 0x14) = 0;
                *(undefined4 *)(puVar3 + 3) = 0xffffffff;
                *(uint8_t *)((int64_t)puVar3 + 0x1e) = *(uint8_t *)((int64_t)puVar3 + 0x1e) & 0xec | 0xc;
                *(undefined2 *)((int64_t)puVar3 + 0x1c) = 0xffff;
            }
            if (puVar3 + 4 != (undefined8 *)0x0) {
                *(undefined4 *)(puVar3 + 4) = 0;
                *(undefined4 *)((int64_t)puVar3 + 0x24) = 0;
                *(undefined4 *)(puVar3 + 5) = 0xffffffff;
                *(uint8_t *)((int64_t)puVar3 + 0x2e) = *(uint8_t *)((int64_t)puVar3 + 0x2e) & 0xec | 0xc;
                *(undefined2 *)((int64_t)puVar3 + 0x2c) = 0xffff;
            }
            if (puVar3 + 6 != (undefined8 *)0x0) {
                *(undefined4 *)(puVar3 + 6) = 0;
                *(undefined4 *)((int64_t)puVar3 + 0x34) = 0;
                *(undefined4 *)(puVar3 + 7) = 0xffffffff;
                *(uint8_t *)((int64_t)puVar3 + 0x3e) = *(uint8_t *)((int64_t)puVar3 + 0x3e) & 0xec | 0xc;
                *(undefined2 *)((int64_t)puVar3 + 0x3c) = 0xffff;
            }
            puVar3 = puVar3 + 8;
            iVar2 = iVar2 + 4;
        } while (iVar2 < iVar1 + -3);
    }
    for (; iVar2 < iVar1; iVar2 = iVar2 + 1) {
        if (puVar3 != (undefined8 *)0x0) {
            *puVar3 = 0;
            *(undefined4 *)(puVar3 + 1) = 0xffffffff;
            *(uint8_t *)((int64_t)puVar3 + 0xe) = *(uint8_t *)((int64_t)puVar3 + 0xe) & 0xec | 0xc;
            *(undefined2 *)((int64_t)puVar3 + 0xc) = 0xffff;
        }
        puVar3 = puVar3 + 2;
    }
    *(int32_t *)arg1 = (int32_t)arg2;
    *(int16_t *)(arg1 + 0xc) = (int16_t)arg3;
    *(int16_t *)(arg1 + 0xe) = (int16_t)arg4;
    *(undefined *)(arg1 + 0x10) = 1;
    return;
}

// ============================================================
// Function: FUN_180137c20
// Address: 0x180137c20
// Size: 112 bytes
// ============================================================
int64_t fcn.180137c20(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t unaff_RBP;
    
    iVar2 = *(int64_t *)0x180781f28;
    iVar1 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2960);
    fcn.18011f640(unaff_RBP);
    *(int32_t *)((int64_t)iVar1 + *(int64_t *)(iVar2 + 0x2968)) = (int32_t)arg2 * 0x10 + 0x18;
    iVar2 = *(int64_t *)(iVar2 + 0x2968) + (int64_t)iVar1;
    fcn.180137af0(iVar2 + 4, arg1 & 0xffffffff, arg2 & 0xffffffff, arg2 & 0xffffffff);
    return iVar2 + 4;
}

// ============================================================
// Function: FUN_180137ce0
// Address: 0x180137ce0
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c6ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2940h because it doesn't fit into ProtoModel

void fcn.180137ce0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    float fVar2;
    int16_t iVar3;
    uint32_t uVar4;
    uint8_t uVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint32_t *puVar12;
    int64_t iVar13;
    int32_t iVar14;
    bool bVar15;
    float fVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined *)(arg1 + 0x240) = 0;
    iVar10 = *(int64_t *)0x180781f28;
    if ((*(uint8_t *)(arg1 + 4) & 0x10) == 0) {
        if (*(int32_t *)(arg1 + 100) == -1) {
            puVar6 = (undefined4 *)func_0x000180137c90(*(undefined4 *)arg1);
            iVar10 = *(int64_t *)0x180781f28;
            if (puVar6 == (undefined4 *)0x0) {
                return;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            if (*(int16_t *)(puVar6 + 3) != iVar11) {
                *(undefined *)(arg1 + 0x241) = 1;
            }
            *(int32_t *)(arg1 + 100) = (int32_t)puVar6 - *(int32_t *)(iVar10 + 0x2968);
        } else {
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            puVar6 = (undefined4 *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2968) + (int64_t)*(int32_t *)(arg1 + 100));
            if (*(int16_t *)((int64_t)puVar6 + 0xe) < iVar11) {
                *puVar6 = 0;
                puVar6 = (undefined4 *)0x0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            }
        }
        iVar14 = 0;
        *(undefined4 *)(arg1 + 0x60) = puVar6[1];
        *(undefined4 *)(arg1 + 0xe4) = puVar6[2];
        if (0 < iVar11) {
            do {
                puVar12 = (uint32_t *)((int64_t)iVar14 * 0x74 + *(int64_t *)(arg1 + 0x18));
                uVar4 = *puVar12;
                fVar2 = (float)puVar12[8];
                if (((uVar4 & 0x10) == 0) || (fVar16 = fVar2, fVar2 <= 0.0)) {
                    fVar16 = -1.0;
                }
                puVar12[4] = (uint32_t)fVar16;
                if ((fVar2 <= 0.0) || (fVar16 = fVar2, (uVar4 & 8) == 0)) {
                    fVar16 = -1.0;
                }
                puVar12[7] = (uint32_t)fVar16;
                if (0.0 < fVar2) {
                    *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                }
                *(int16_t *)((int64_t)puVar12 + 0x56) = (int16_t)(((int64_t)puVar12 - *(int64_t *)(arg1 + 0x18)) / 0x74)
                ;
                uVar5 = ~(uint8_t)(uVar4 >> 1) & 1;
                *(uint8_t *)(puVar12 + 0x1a) = uVar5;
                *(uint8_t *)((int64_t)puVar12 + 0x67) = uVar5;
                *(uint16_t *)((int64_t)puVar12 + 0x5e) = ((uVar4 & 4) != 0) - 1;
                if ((uVar4 & 4) == 0) {
                    uVar5 = 0;
                } else {
                    uVar5 = ((uVar4 >> 0xf & 1) != 0) + 1;
                }
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) & 0xfc;
                iVar14 = iVar14 + 1;
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) | uVar5;
                *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        puVar9 = puVar6 + 5;
        if (0 < *(int16_t *)(puVar6 + 3)) {
            do {
                iVar3 = *(int16_t *)(puVar9 + 2);
                if ((-1 < iVar3) && ((int32_t)iVar3 < *(int32_t *)(arg1 + 0x6c))) {
                    iVar8 = *(int64_t *)(arg1 + 0x18);
                    iVar13 = (int64_t)iVar3 * 0x74;
                    if ((*(uint8_t *)(puVar6 + 1) & 1) != 0) {
                        if ((*(uint8_t *)((int64_t)puVar9 + 0xe) & 0x10) == 0) {
                            *(undefined4 *)(iVar13 + 0x10 + iVar8) = *puVar9;
                        } else {
                            *(undefined4 *)(iVar13 + 0x1c + iVar8) = *puVar9;
                        }
                    }
                    if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
                        *(undefined2 *)(iVar13 + 0x56 + iVar8) = *(undefined2 *)((int64_t)puVar9 + 10);
                    }
                    if (((*(uint8_t *)(puVar6 + 1) & 4) != 0) &&
                       (uVar5 = *(char *)((int64_t)puVar9 + 0xe) << 4, (uVar5 & 0xc0) != 0xc0)) {
                        bVar15 = (uVar5 & 0xc0) == 0x40;
                        *(bool *)(iVar13 + 0x68 + iVar8) = bVar15;
                        *(bool *)(iVar13 + 0x67 + iVar8) = bVar15;
                    }
                    *(undefined2 *)(iVar13 + 0x5e + iVar8) = *(undefined2 *)(puVar9 + 3);
                    puVar1 = (uint8_t *)(iVar13 + 0x71 + iVar8);
                    *puVar1 = *puVar1 ^ (*(uint8_t *)(iVar13 + 0x71 + iVar8) ^ *(uint8_t *)((int64_t)puVar9 + 0xe)) & 3;
                }
                iVar14 = iVar14 + 1;
                puVar9 = puVar9 + 4;
            } while (iVar14 < *(int16_t *)(puVar6 + 3));
            iVar11 = *(int32_t *)(arg1 + 0x6c);
        }
        if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
            iVar11 = *(int32_t *)(arg1 + 0x6c) * 0x10;
            if (*(int32_t *)(iVar10 + 0x2c94) < iVar11) {
                uVar7 = func_0x00018046d050();
                if (*(int64_t *)(iVar10 + 0x2c98) != 0) {
                    func_0x000180498030(uVar7);
                    func_0x000180460d90();
                }
                *(undefined8 *)(iVar10 + 0x2c98) = uVar7;
                *(int32_t *)(iVar10 + 0x2c94) = iVar11;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            iVar14 = 0;
            iVar10 = *(int64_t *)(iVar10 + 0x2c98);
            if (0 < iVar11) {
                do {
                    iVar8 = (int64_t)iVar14;
                    *(int16_t *)(iVar10 + iVar8 * 0x10) = (int16_t)iVar14;
                    iVar14 = iVar14 + 1;
                    *(int64_t *)(iVar10 + 8 + iVar8 * 0x10) = arg1;
                    iVar11 = *(int32_t *)(arg1 + 0x6c);
                } while (iVar14 < iVar11);
            }
            if (1 < (uint64_t)(int64_t)iVar11) {
                func_0x00018046f0d0(iVar10, (int64_t)iVar11, 0x10, 0x180138060);
            }
            iVar14 = 0;
            if (*(int32_t *)(arg1 + 0x6c) < 1) {
                return;
            }
            do {
                *(int16_t *)
                 ((int64_t)*(int16_t *)(iVar10 + (int64_t)iVar14 * 0x10) * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) =
                     (int16_t)iVar14;
                iVar14 = iVar14 + 1;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        if (0 < iVar11) {
            do {
                *(int16_t *)
                 (*(int64_t *)(arg1 + 0x28) +
                 (int64_t)*(int16_t *)((int64_t)iVar14 * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) * 2) = (int16_t)iVar14
                ;
                iVar14 = iVar14 + 1;
            } while (iVar14 < *(int32_t *)(arg1 + 0x6c));
        }
    }
    return;
}

// ============================================================
// Function: FUN_180137cfe
// Address: 0x180137cfe
// Size: 132 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c6ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2940h because it doesn't fit into ProtoModel

void fcn.180137ce0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    float fVar2;
    int16_t iVar3;
    uint32_t uVar4;
    uint8_t uVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint32_t *puVar12;
    int64_t iVar13;
    int32_t iVar14;
    bool bVar15;
    float fVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined *)(arg1 + 0x240) = 0;
    iVar10 = *(int64_t *)0x180781f28;
    if ((*(uint8_t *)(arg1 + 4) & 0x10) == 0) {
        if (*(int32_t *)(arg1 + 100) == -1) {
            puVar6 = (undefined4 *)func_0x000180137c90(*(undefined4 *)arg1);
            iVar10 = *(int64_t *)0x180781f28;
            if (puVar6 == (undefined4 *)0x0) {
                return;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            if (*(int16_t *)(puVar6 + 3) != iVar11) {
                *(undefined *)(arg1 + 0x241) = 1;
            }
            *(int32_t *)(arg1 + 100) = (int32_t)puVar6 - *(int32_t *)(iVar10 + 0x2968);
        } else {
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            puVar6 = (undefined4 *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2968) + (int64_t)*(int32_t *)(arg1 + 100));
            if (*(int16_t *)((int64_t)puVar6 + 0xe) < iVar11) {
                *puVar6 = 0;
                puVar6 = (undefined4 *)0x0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            }
        }
        iVar14 = 0;
        *(undefined4 *)(arg1 + 0x60) = puVar6[1];
        *(undefined4 *)(arg1 + 0xe4) = puVar6[2];
        if (0 < iVar11) {
            do {
                puVar12 = (uint32_t *)((int64_t)iVar14 * 0x74 + *(int64_t *)(arg1 + 0x18));
                uVar4 = *puVar12;
                fVar2 = (float)puVar12[8];
                if (((uVar4 & 0x10) == 0) || (fVar16 = fVar2, fVar2 <= 0.0)) {
                    fVar16 = -1.0;
                }
                puVar12[4] = (uint32_t)fVar16;
                if ((fVar2 <= 0.0) || (fVar16 = fVar2, (uVar4 & 8) == 0)) {
                    fVar16 = -1.0;
                }
                puVar12[7] = (uint32_t)fVar16;
                if (0.0 < fVar2) {
                    *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                }
                *(int16_t *)((int64_t)puVar12 + 0x56) = (int16_t)(((int64_t)puVar12 - *(int64_t *)(arg1 + 0x18)) / 0x74)
                ;
                uVar5 = ~(uint8_t)(uVar4 >> 1) & 1;
                *(uint8_t *)(puVar12 + 0x1a) = uVar5;
                *(uint8_t *)((int64_t)puVar12 + 0x67) = uVar5;
                *(uint16_t *)((int64_t)puVar12 + 0x5e) = ((uVar4 & 4) != 0) - 1;
                if ((uVar4 & 4) == 0) {
                    uVar5 = 0;
                } else {
                    uVar5 = ((uVar4 >> 0xf & 1) != 0) + 1;
                }
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) & 0xfc;
                iVar14 = iVar14 + 1;
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) | uVar5;
                *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        puVar9 = puVar6 + 5;
        if (0 < *(int16_t *)(puVar6 + 3)) {
            do {
                iVar3 = *(int16_t *)(puVar9 + 2);
                if ((-1 < iVar3) && ((int32_t)iVar3 < *(int32_t *)(arg1 + 0x6c))) {
                    iVar8 = *(int64_t *)(arg1 + 0x18);
                    iVar13 = (int64_t)iVar3 * 0x74;
                    if ((*(uint8_t *)(puVar6 + 1) & 1) != 0) {
                        if ((*(uint8_t *)((int64_t)puVar9 + 0xe) & 0x10) == 0) {
                            *(undefined4 *)(iVar13 + 0x10 + iVar8) = *puVar9;
                        } else {
                            *(undefined4 *)(iVar13 + 0x1c + iVar8) = *puVar9;
                        }
                    }
                    if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
                        *(undefined2 *)(iVar13 + 0x56 + iVar8) = *(undefined2 *)((int64_t)puVar9 + 10);
                    }
                    if (((*(uint8_t *)(puVar6 + 1) & 4) != 0) &&
                       (uVar5 = *(char *)((int64_t)puVar9 + 0xe) << 4, (uVar5 & 0xc0) != 0xc0)) {
                        bVar15 = (uVar5 & 0xc0) == 0x40;
                        *(bool *)(iVar13 + 0x68 + iVar8) = bVar15;
                        *(bool *)(iVar13 + 0x67 + iVar8) = bVar15;
                    }
                    *(undefined2 *)(iVar13 + 0x5e + iVar8) = *(undefined2 *)(puVar9 + 3);
                    puVar1 = (uint8_t *)(iVar13 + 0x71 + iVar8);
                    *puVar1 = *puVar1 ^ (*(uint8_t *)(iVar13 + 0x71 + iVar8) ^ *(uint8_t *)((int64_t)puVar9 + 0xe)) & 3;
                }
                iVar14 = iVar14 + 1;
                puVar9 = puVar9 + 4;
            } while (iVar14 < *(int16_t *)(puVar6 + 3));
            iVar11 = *(int32_t *)(arg1 + 0x6c);
        }
        if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
            iVar11 = *(int32_t *)(arg1 + 0x6c) * 0x10;
            if (*(int32_t *)(iVar10 + 0x2c94) < iVar11) {
                uVar7 = func_0x00018046d050();
                if (*(int64_t *)(iVar10 + 0x2c98) != 0) {
                    func_0x000180498030(uVar7);
                    func_0x000180460d90();
                }
                *(undefined8 *)(iVar10 + 0x2c98) = uVar7;
                *(int32_t *)(iVar10 + 0x2c94) = iVar11;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            iVar14 = 0;
            iVar10 = *(int64_t *)(iVar10 + 0x2c98);
            if (0 < iVar11) {
                do {
                    iVar8 = (int64_t)iVar14;
                    *(int16_t *)(iVar10 + iVar8 * 0x10) = (int16_t)iVar14;
                    iVar14 = iVar14 + 1;
                    *(int64_t *)(iVar10 + 8 + iVar8 * 0x10) = arg1;
                    iVar11 = *(int32_t *)(arg1 + 0x6c);
                } while (iVar14 < iVar11);
            }
            if (1 < (uint64_t)(int64_t)iVar11) {
                func_0x00018046f0d0(iVar10, (int64_t)iVar11, 0x10, 0x180138060);
            }
            iVar14 = 0;
            if (*(int32_t *)(arg1 + 0x6c) < 1) {
                return;
            }
            do {
                *(int16_t *)
                 ((int64_t)*(int16_t *)(iVar10 + (int64_t)iVar14 * 0x10) * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) =
                     (int16_t)iVar14;
                iVar14 = iVar14 + 1;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        if (0 < iVar11) {
            do {
                *(int16_t *)
                 (*(int64_t *)(arg1 + 0x28) +
                 (int64_t)*(int16_t *)((int64_t)iVar14 * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) * 2) = (int16_t)iVar14
                ;
                iVar14 = iVar14 + 1;
            } while (iVar14 < *(int32_t *)(arg1 + 0x6c));
        }
    }
    return;
}

// ============================================================
// Function: FUN_180137d82
// Address: 0x180137d82
// Size: 475 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c6ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2940h because it doesn't fit into ProtoModel

void fcn.180137ce0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    float fVar2;
    int16_t iVar3;
    uint32_t uVar4;
    uint8_t uVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint32_t *puVar12;
    int64_t iVar13;
    int32_t iVar14;
    bool bVar15;
    float fVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined *)(arg1 + 0x240) = 0;
    iVar10 = *(int64_t *)0x180781f28;
    if ((*(uint8_t *)(arg1 + 4) & 0x10) == 0) {
        if (*(int32_t *)(arg1 + 100) == -1) {
            puVar6 = (undefined4 *)func_0x000180137c90(*(undefined4 *)arg1);
            iVar10 = *(int64_t *)0x180781f28;
            if (puVar6 == (undefined4 *)0x0) {
                return;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            if (*(int16_t *)(puVar6 + 3) != iVar11) {
                *(undefined *)(arg1 + 0x241) = 1;
            }
            *(int32_t *)(arg1 + 100) = (int32_t)puVar6 - *(int32_t *)(iVar10 + 0x2968);
        } else {
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            puVar6 = (undefined4 *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2968) + (int64_t)*(int32_t *)(arg1 + 100));
            if (*(int16_t *)((int64_t)puVar6 + 0xe) < iVar11) {
                *puVar6 = 0;
                puVar6 = (undefined4 *)0x0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            }
        }
        iVar14 = 0;
        *(undefined4 *)(arg1 + 0x60) = puVar6[1];
        *(undefined4 *)(arg1 + 0xe4) = puVar6[2];
        if (0 < iVar11) {
            do {
                puVar12 = (uint32_t *)((int64_t)iVar14 * 0x74 + *(int64_t *)(arg1 + 0x18));
                uVar4 = *puVar12;
                fVar2 = (float)puVar12[8];
                if (((uVar4 & 0x10) == 0) || (fVar16 = fVar2, fVar2 <= 0.0)) {
                    fVar16 = -1.0;
                }
                puVar12[4] = (uint32_t)fVar16;
                if ((fVar2 <= 0.0) || (fVar16 = fVar2, (uVar4 & 8) == 0)) {
                    fVar16 = -1.0;
                }
                puVar12[7] = (uint32_t)fVar16;
                if (0.0 < fVar2) {
                    *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                }
                *(int16_t *)((int64_t)puVar12 + 0x56) = (int16_t)(((int64_t)puVar12 - *(int64_t *)(arg1 + 0x18)) / 0x74)
                ;
                uVar5 = ~(uint8_t)(uVar4 >> 1) & 1;
                *(uint8_t *)(puVar12 + 0x1a) = uVar5;
                *(uint8_t *)((int64_t)puVar12 + 0x67) = uVar5;
                *(uint16_t *)((int64_t)puVar12 + 0x5e) = ((uVar4 & 4) != 0) - 1;
                if ((uVar4 & 4) == 0) {
                    uVar5 = 0;
                } else {
                    uVar5 = ((uVar4 >> 0xf & 1) != 0) + 1;
                }
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) & 0xfc;
                iVar14 = iVar14 + 1;
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) | uVar5;
                *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        puVar9 = puVar6 + 5;
        if (0 < *(int16_t *)(puVar6 + 3)) {
            do {
                iVar3 = *(int16_t *)(puVar9 + 2);
                if ((-1 < iVar3) && ((int32_t)iVar3 < *(int32_t *)(arg1 + 0x6c))) {
                    iVar8 = *(int64_t *)(arg1 + 0x18);
                    iVar13 = (int64_t)iVar3 * 0x74;
                    if ((*(uint8_t *)(puVar6 + 1) & 1) != 0) {
                        if ((*(uint8_t *)((int64_t)puVar9 + 0xe) & 0x10) == 0) {
                            *(undefined4 *)(iVar13 + 0x10 + iVar8) = *puVar9;
                        } else {
                            *(undefined4 *)(iVar13 + 0x1c + iVar8) = *puVar9;
                        }
                    }
                    if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
                        *(undefined2 *)(iVar13 + 0x56 + iVar8) = *(undefined2 *)((int64_t)puVar9 + 10);
                    }
                    if (((*(uint8_t *)(puVar6 + 1) & 4) != 0) &&
                       (uVar5 = *(char *)((int64_t)puVar9 + 0xe) << 4, (uVar5 & 0xc0) != 0xc0)) {
                        bVar15 = (uVar5 & 0xc0) == 0x40;
                        *(bool *)(iVar13 + 0x68 + iVar8) = bVar15;
                        *(bool *)(iVar13 + 0x67 + iVar8) = bVar15;
                    }
                    *(undefined2 *)(iVar13 + 0x5e + iVar8) = *(undefined2 *)(puVar9 + 3);
                    puVar1 = (uint8_t *)(iVar13 + 0x71 + iVar8);
                    *puVar1 = *puVar1 ^ (*(uint8_t *)(iVar13 + 0x71 + iVar8) ^ *(uint8_t *)((int64_t)puVar9 + 0xe)) & 3;
                }
                iVar14 = iVar14 + 1;
                puVar9 = puVar9 + 4;
            } while (iVar14 < *(int16_t *)(puVar6 + 3));
            iVar11 = *(int32_t *)(arg1 + 0x6c);
        }
        if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
            iVar11 = *(int32_t *)(arg1 + 0x6c) * 0x10;
            if (*(int32_t *)(iVar10 + 0x2c94) < iVar11) {
                uVar7 = func_0x00018046d050();
                if (*(int64_t *)(iVar10 + 0x2c98) != 0) {
                    func_0x000180498030(uVar7);
                    func_0x000180460d90();
                }
                *(undefined8 *)(iVar10 + 0x2c98) = uVar7;
                *(int32_t *)(iVar10 + 0x2c94) = iVar11;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            iVar14 = 0;
            iVar10 = *(int64_t *)(iVar10 + 0x2c98);
            if (0 < iVar11) {
                do {
                    iVar8 = (int64_t)iVar14;
                    *(int16_t *)(iVar10 + iVar8 * 0x10) = (int16_t)iVar14;
                    iVar14 = iVar14 + 1;
                    *(int64_t *)(iVar10 + 8 + iVar8 * 0x10) = arg1;
                    iVar11 = *(int32_t *)(arg1 + 0x6c);
                } while (iVar14 < iVar11);
            }
            if (1 < (uint64_t)(int64_t)iVar11) {
                func_0x00018046f0d0(iVar10, (int64_t)iVar11, 0x10, 0x180138060);
            }
            iVar14 = 0;
            if (*(int32_t *)(arg1 + 0x6c) < 1) {
                return;
            }
            do {
                *(int16_t *)
                 ((int64_t)*(int16_t *)(iVar10 + (int64_t)iVar14 * 0x10) * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) =
                     (int16_t)iVar14;
                iVar14 = iVar14 + 1;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        if (0 < iVar11) {
            do {
                *(int16_t *)
                 (*(int64_t *)(arg1 + 0x28) +
                 (int64_t)*(int16_t *)((int64_t)iVar14 * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) * 2) = (int16_t)iVar14
                ;
                iVar14 = iVar14 + 1;
            } while (iVar14 < *(int32_t *)(arg1 + 0x6c));
        }
    }
    return;
}

// ============================================================
// Function: FUN_180137f5d
// Address: 0x180137f5d
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c6ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2940h because it doesn't fit into ProtoModel

void fcn.180137ce0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    float fVar2;
    int16_t iVar3;
    uint32_t uVar4;
    uint8_t uVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint32_t *puVar12;
    int64_t iVar13;
    int32_t iVar14;
    bool bVar15;
    float fVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined *)(arg1 + 0x240) = 0;
    iVar10 = *(int64_t *)0x180781f28;
    if ((*(uint8_t *)(arg1 + 4) & 0x10) == 0) {
        if (*(int32_t *)(arg1 + 100) == -1) {
            puVar6 = (undefined4 *)func_0x000180137c90(*(undefined4 *)arg1);
            iVar10 = *(int64_t *)0x180781f28;
            if (puVar6 == (undefined4 *)0x0) {
                return;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            if (*(int16_t *)(puVar6 + 3) != iVar11) {
                *(undefined *)(arg1 + 0x241) = 1;
            }
            *(int32_t *)(arg1 + 100) = (int32_t)puVar6 - *(int32_t *)(iVar10 + 0x2968);
        } else {
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            puVar6 = (undefined4 *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2968) + (int64_t)*(int32_t *)(arg1 + 100));
            if (*(int16_t *)((int64_t)puVar6 + 0xe) < iVar11) {
                *puVar6 = 0;
                puVar6 = (undefined4 *)0x0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            }
        }
        iVar14 = 0;
        *(undefined4 *)(arg1 + 0x60) = puVar6[1];
        *(undefined4 *)(arg1 + 0xe4) = puVar6[2];
        if (0 < iVar11) {
            do {
                puVar12 = (uint32_t *)((int64_t)iVar14 * 0x74 + *(int64_t *)(arg1 + 0x18));
                uVar4 = *puVar12;
                fVar2 = (float)puVar12[8];
                if (((uVar4 & 0x10) == 0) || (fVar16 = fVar2, fVar2 <= 0.0)) {
                    fVar16 = -1.0;
                }
                puVar12[4] = (uint32_t)fVar16;
                if ((fVar2 <= 0.0) || (fVar16 = fVar2, (uVar4 & 8) == 0)) {
                    fVar16 = -1.0;
                }
                puVar12[7] = (uint32_t)fVar16;
                if (0.0 < fVar2) {
                    *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                }
                *(int16_t *)((int64_t)puVar12 + 0x56) = (int16_t)(((int64_t)puVar12 - *(int64_t *)(arg1 + 0x18)) / 0x74)
                ;
                uVar5 = ~(uint8_t)(uVar4 >> 1) & 1;
                *(uint8_t *)(puVar12 + 0x1a) = uVar5;
                *(uint8_t *)((int64_t)puVar12 + 0x67) = uVar5;
                *(uint16_t *)((int64_t)puVar12 + 0x5e) = ((uVar4 & 4) != 0) - 1;
                if ((uVar4 & 4) == 0) {
                    uVar5 = 0;
                } else {
                    uVar5 = ((uVar4 >> 0xf & 1) != 0) + 1;
                }
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) & 0xfc;
                iVar14 = iVar14 + 1;
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) | uVar5;
                *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        puVar9 = puVar6 + 5;
        if (0 < *(int16_t *)(puVar6 + 3)) {
            do {
                iVar3 = *(int16_t *)(puVar9 + 2);
                if ((-1 < iVar3) && ((int32_t)iVar3 < *(int32_t *)(arg1 + 0x6c))) {
                    iVar8 = *(int64_t *)(arg1 + 0x18);
                    iVar13 = (int64_t)iVar3 * 0x74;
                    if ((*(uint8_t *)(puVar6 + 1) & 1) != 0) {
                        if ((*(uint8_t *)((int64_t)puVar9 + 0xe) & 0x10) == 0) {
                            *(undefined4 *)(iVar13 + 0x10 + iVar8) = *puVar9;
                        } else {
                            *(undefined4 *)(iVar13 + 0x1c + iVar8) = *puVar9;
                        }
                    }
                    if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
                        *(undefined2 *)(iVar13 + 0x56 + iVar8) = *(undefined2 *)((int64_t)puVar9 + 10);
                    }
                    if (((*(uint8_t *)(puVar6 + 1) & 4) != 0) &&
                       (uVar5 = *(char *)((int64_t)puVar9 + 0xe) << 4, (uVar5 & 0xc0) != 0xc0)) {
                        bVar15 = (uVar5 & 0xc0) == 0x40;
                        *(bool *)(iVar13 + 0x68 + iVar8) = bVar15;
                        *(bool *)(iVar13 + 0x67 + iVar8) = bVar15;
                    }
                    *(undefined2 *)(iVar13 + 0x5e + iVar8) = *(undefined2 *)(puVar9 + 3);
                    puVar1 = (uint8_t *)(iVar13 + 0x71 + iVar8);
                    *puVar1 = *puVar1 ^ (*(uint8_t *)(iVar13 + 0x71 + iVar8) ^ *(uint8_t *)((int64_t)puVar9 + 0xe)) & 3;
                }
                iVar14 = iVar14 + 1;
                puVar9 = puVar9 + 4;
            } while (iVar14 < *(int16_t *)(puVar6 + 3));
            iVar11 = *(int32_t *)(arg1 + 0x6c);
        }
        if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
            iVar11 = *(int32_t *)(arg1 + 0x6c) * 0x10;
            if (*(int32_t *)(iVar10 + 0x2c94) < iVar11) {
                uVar7 = func_0x00018046d050();
                if (*(int64_t *)(iVar10 + 0x2c98) != 0) {
                    func_0x000180498030(uVar7);
                    func_0x000180460d90();
                }
                *(undefined8 *)(iVar10 + 0x2c98) = uVar7;
                *(int32_t *)(iVar10 + 0x2c94) = iVar11;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            iVar14 = 0;
            iVar10 = *(int64_t *)(iVar10 + 0x2c98);
            if (0 < iVar11) {
                do {
                    iVar8 = (int64_t)iVar14;
                    *(int16_t *)(iVar10 + iVar8 * 0x10) = (int16_t)iVar14;
                    iVar14 = iVar14 + 1;
                    *(int64_t *)(iVar10 + 8 + iVar8 * 0x10) = arg1;
                    iVar11 = *(int32_t *)(arg1 + 0x6c);
                } while (iVar14 < iVar11);
            }
            if (1 < (uint64_t)(int64_t)iVar11) {
                func_0x00018046f0d0(iVar10, (int64_t)iVar11, 0x10, 0x180138060);
            }
            iVar14 = 0;
            if (*(int32_t *)(arg1 + 0x6c) < 1) {
                return;
            }
            do {
                *(int16_t *)
                 ((int64_t)*(int16_t *)(iVar10 + (int64_t)iVar14 * 0x10) * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) =
                     (int16_t)iVar14;
                iVar14 = iVar14 + 1;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        if (0 < iVar11) {
            do {
                *(int16_t *)
                 (*(int64_t *)(arg1 + 0x28) +
                 (int64_t)*(int16_t *)((int64_t)iVar14 * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) * 2) = (int16_t)iVar14
                ;
                iVar14 = iVar14 + 1;
            } while (iVar14 < *(int32_t *)(arg1 + 0x6c));
        }
    }
    return;
}

// ============================================================
// Function: FUN_180137fa3
// Address: 0x180137fa3
// Size: 165 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c6ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2940h because it doesn't fit into ProtoModel

void fcn.180137ce0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    float fVar2;
    int16_t iVar3;
    uint32_t uVar4;
    uint8_t uVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint32_t *puVar12;
    int64_t iVar13;
    int32_t iVar14;
    bool bVar15;
    float fVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined *)(arg1 + 0x240) = 0;
    iVar10 = *(int64_t *)0x180781f28;
    if ((*(uint8_t *)(arg1 + 4) & 0x10) == 0) {
        if (*(int32_t *)(arg1 + 100) == -1) {
            puVar6 = (undefined4 *)func_0x000180137c90(*(undefined4 *)arg1);
            iVar10 = *(int64_t *)0x180781f28;
            if (puVar6 == (undefined4 *)0x0) {
                return;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            if (*(int16_t *)(puVar6 + 3) != iVar11) {
                *(undefined *)(arg1 + 0x241) = 1;
            }
            *(int32_t *)(arg1 + 100) = (int32_t)puVar6 - *(int32_t *)(iVar10 + 0x2968);
        } else {
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            puVar6 = (undefined4 *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2968) + (int64_t)*(int32_t *)(arg1 + 100));
            if (*(int16_t *)((int64_t)puVar6 + 0xe) < iVar11) {
                *puVar6 = 0;
                puVar6 = (undefined4 *)0x0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            }
        }
        iVar14 = 0;
        *(undefined4 *)(arg1 + 0x60) = puVar6[1];
        *(undefined4 *)(arg1 + 0xe4) = puVar6[2];
        if (0 < iVar11) {
            do {
                puVar12 = (uint32_t *)((int64_t)iVar14 * 0x74 + *(int64_t *)(arg1 + 0x18));
                uVar4 = *puVar12;
                fVar2 = (float)puVar12[8];
                if (((uVar4 & 0x10) == 0) || (fVar16 = fVar2, fVar2 <= 0.0)) {
                    fVar16 = -1.0;
                }
                puVar12[4] = (uint32_t)fVar16;
                if ((fVar2 <= 0.0) || (fVar16 = fVar2, (uVar4 & 8) == 0)) {
                    fVar16 = -1.0;
                }
                puVar12[7] = (uint32_t)fVar16;
                if (0.0 < fVar2) {
                    *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                }
                *(int16_t *)((int64_t)puVar12 + 0x56) = (int16_t)(((int64_t)puVar12 - *(int64_t *)(arg1 + 0x18)) / 0x74)
                ;
                uVar5 = ~(uint8_t)(uVar4 >> 1) & 1;
                *(uint8_t *)(puVar12 + 0x1a) = uVar5;
                *(uint8_t *)((int64_t)puVar12 + 0x67) = uVar5;
                *(uint16_t *)((int64_t)puVar12 + 0x5e) = ((uVar4 & 4) != 0) - 1;
                if ((uVar4 & 4) == 0) {
                    uVar5 = 0;
                } else {
                    uVar5 = ((uVar4 >> 0xf & 1) != 0) + 1;
                }
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) & 0xfc;
                iVar14 = iVar14 + 1;
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) | uVar5;
                *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        puVar9 = puVar6 + 5;
        if (0 < *(int16_t *)(puVar6 + 3)) {
            do {
                iVar3 = *(int16_t *)(puVar9 + 2);
                if ((-1 < iVar3) && ((int32_t)iVar3 < *(int32_t *)(arg1 + 0x6c))) {
                    iVar8 = *(int64_t *)(arg1 + 0x18);
                    iVar13 = (int64_t)iVar3 * 0x74;
                    if ((*(uint8_t *)(puVar6 + 1) & 1) != 0) {
                        if ((*(uint8_t *)((int64_t)puVar9 + 0xe) & 0x10) == 0) {
                            *(undefined4 *)(iVar13 + 0x10 + iVar8) = *puVar9;
                        } else {
                            *(undefined4 *)(iVar13 + 0x1c + iVar8) = *puVar9;
                        }
                    }
                    if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
                        *(undefined2 *)(iVar13 + 0x56 + iVar8) = *(undefined2 *)((int64_t)puVar9 + 10);
                    }
                    if (((*(uint8_t *)(puVar6 + 1) & 4) != 0) &&
                       (uVar5 = *(char *)((int64_t)puVar9 + 0xe) << 4, (uVar5 & 0xc0) != 0xc0)) {
                        bVar15 = (uVar5 & 0xc0) == 0x40;
                        *(bool *)(iVar13 + 0x68 + iVar8) = bVar15;
                        *(bool *)(iVar13 + 0x67 + iVar8) = bVar15;
                    }
                    *(undefined2 *)(iVar13 + 0x5e + iVar8) = *(undefined2 *)(puVar9 + 3);
                    puVar1 = (uint8_t *)(iVar13 + 0x71 + iVar8);
                    *puVar1 = *puVar1 ^ (*(uint8_t *)(iVar13 + 0x71 + iVar8) ^ *(uint8_t *)((int64_t)puVar9 + 0xe)) & 3;
                }
                iVar14 = iVar14 + 1;
                puVar9 = puVar9 + 4;
            } while (iVar14 < *(int16_t *)(puVar6 + 3));
            iVar11 = *(int32_t *)(arg1 + 0x6c);
        }
        if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
            iVar11 = *(int32_t *)(arg1 + 0x6c) * 0x10;
            if (*(int32_t *)(iVar10 + 0x2c94) < iVar11) {
                uVar7 = func_0x00018046d050();
                if (*(int64_t *)(iVar10 + 0x2c98) != 0) {
                    func_0x000180498030(uVar7);
                    func_0x000180460d90();
                }
                *(undefined8 *)(iVar10 + 0x2c98) = uVar7;
                *(int32_t *)(iVar10 + 0x2c94) = iVar11;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            iVar14 = 0;
            iVar10 = *(int64_t *)(iVar10 + 0x2c98);
            if (0 < iVar11) {
                do {
                    iVar8 = (int64_t)iVar14;
                    *(int16_t *)(iVar10 + iVar8 * 0x10) = (int16_t)iVar14;
                    iVar14 = iVar14 + 1;
                    *(int64_t *)(iVar10 + 8 + iVar8 * 0x10) = arg1;
                    iVar11 = *(int32_t *)(arg1 + 0x6c);
                } while (iVar14 < iVar11);
            }
            if (1 < (uint64_t)(int64_t)iVar11) {
                func_0x00018046f0d0(iVar10, (int64_t)iVar11, 0x10, 0x180138060);
            }
            iVar14 = 0;
            if (*(int32_t *)(arg1 + 0x6c) < 1) {
                return;
            }
            do {
                *(int16_t *)
                 ((int64_t)*(int16_t *)(iVar10 + (int64_t)iVar14 * 0x10) * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) =
                     (int16_t)iVar14;
                iVar14 = iVar14 + 1;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        if (0 < iVar11) {
            do {
                *(int16_t *)
                 (*(int64_t *)(arg1 + 0x28) +
                 (int64_t)*(int16_t *)((int64_t)iVar14 * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) * 2) = (int16_t)iVar14
                ;
                iVar14 = iVar14 + 1;
            } while (iVar14 < *(int32_t *)(arg1 + 0x6c));
        }
    }
    return;
}

// ============================================================
// Function: FUN_180138048
// Address: 0x180138048
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c6ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2940h because it doesn't fit into ProtoModel

void fcn.180137ce0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    float fVar2;
    int16_t iVar3;
    uint32_t uVar4;
    uint8_t uVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint32_t *puVar12;
    int64_t iVar13;
    int32_t iVar14;
    bool bVar15;
    float fVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined *)(arg1 + 0x240) = 0;
    iVar10 = *(int64_t *)0x180781f28;
    if ((*(uint8_t *)(arg1 + 4) & 0x10) == 0) {
        if (*(int32_t *)(arg1 + 100) == -1) {
            puVar6 = (undefined4 *)func_0x000180137c90(*(undefined4 *)arg1);
            iVar10 = *(int64_t *)0x180781f28;
            if (puVar6 == (undefined4 *)0x0) {
                return;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            if (*(int16_t *)(puVar6 + 3) != iVar11) {
                *(undefined *)(arg1 + 0x241) = 1;
            }
            *(int32_t *)(arg1 + 100) = (int32_t)puVar6 - *(int32_t *)(iVar10 + 0x2968);
        } else {
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            puVar6 = (undefined4 *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2968) + (int64_t)*(int32_t *)(arg1 + 100));
            if (*(int16_t *)((int64_t)puVar6 + 0xe) < iVar11) {
                *puVar6 = 0;
                puVar6 = (undefined4 *)0x0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            }
        }
        iVar14 = 0;
        *(undefined4 *)(arg1 + 0x60) = puVar6[1];
        *(undefined4 *)(arg1 + 0xe4) = puVar6[2];
        if (0 < iVar11) {
            do {
                puVar12 = (uint32_t *)((int64_t)iVar14 * 0x74 + *(int64_t *)(arg1 + 0x18));
                uVar4 = *puVar12;
                fVar2 = (float)puVar12[8];
                if (((uVar4 & 0x10) == 0) || (fVar16 = fVar2, fVar2 <= 0.0)) {
                    fVar16 = -1.0;
                }
                puVar12[4] = (uint32_t)fVar16;
                if ((fVar2 <= 0.0) || (fVar16 = fVar2, (uVar4 & 8) == 0)) {
                    fVar16 = -1.0;
                }
                puVar12[7] = (uint32_t)fVar16;
                if (0.0 < fVar2) {
                    *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                }
                *(int16_t *)((int64_t)puVar12 + 0x56) = (int16_t)(((int64_t)puVar12 - *(int64_t *)(arg1 + 0x18)) / 0x74)
                ;
                uVar5 = ~(uint8_t)(uVar4 >> 1) & 1;
                *(uint8_t *)(puVar12 + 0x1a) = uVar5;
                *(uint8_t *)((int64_t)puVar12 + 0x67) = uVar5;
                *(uint16_t *)((int64_t)puVar12 + 0x5e) = ((uVar4 & 4) != 0) - 1;
                if ((uVar4 & 4) == 0) {
                    uVar5 = 0;
                } else {
                    uVar5 = ((uVar4 >> 0xf & 1) != 0) + 1;
                }
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) & 0xfc;
                iVar14 = iVar14 + 1;
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) | uVar5;
                *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        puVar9 = puVar6 + 5;
        if (0 < *(int16_t *)(puVar6 + 3)) {
            do {
                iVar3 = *(int16_t *)(puVar9 + 2);
                if ((-1 < iVar3) && ((int32_t)iVar3 < *(int32_t *)(arg1 + 0x6c))) {
                    iVar8 = *(int64_t *)(arg1 + 0x18);
                    iVar13 = (int64_t)iVar3 * 0x74;
                    if ((*(uint8_t *)(puVar6 + 1) & 1) != 0) {
                        if ((*(uint8_t *)((int64_t)puVar9 + 0xe) & 0x10) == 0) {
                            *(undefined4 *)(iVar13 + 0x10 + iVar8) = *puVar9;
                        } else {
                            *(undefined4 *)(iVar13 + 0x1c + iVar8) = *puVar9;
                        }
                    }
                    if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
                        *(undefined2 *)(iVar13 + 0x56 + iVar8) = *(undefined2 *)((int64_t)puVar9 + 10);
                    }
                    if (((*(uint8_t *)(puVar6 + 1) & 4) != 0) &&
                       (uVar5 = *(char *)((int64_t)puVar9 + 0xe) << 4, (uVar5 & 0xc0) != 0xc0)) {
                        bVar15 = (uVar5 & 0xc0) == 0x40;
                        *(bool *)(iVar13 + 0x68 + iVar8) = bVar15;
                        *(bool *)(iVar13 + 0x67 + iVar8) = bVar15;
                    }
                    *(undefined2 *)(iVar13 + 0x5e + iVar8) = *(undefined2 *)(puVar9 + 3);
                    puVar1 = (uint8_t *)(iVar13 + 0x71 + iVar8);
                    *puVar1 = *puVar1 ^ (*(uint8_t *)(iVar13 + 0x71 + iVar8) ^ *(uint8_t *)((int64_t)puVar9 + 0xe)) & 3;
                }
                iVar14 = iVar14 + 1;
                puVar9 = puVar9 + 4;
            } while (iVar14 < *(int16_t *)(puVar6 + 3));
            iVar11 = *(int32_t *)(arg1 + 0x6c);
        }
        if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
            iVar11 = *(int32_t *)(arg1 + 0x6c) * 0x10;
            if (*(int32_t *)(iVar10 + 0x2c94) < iVar11) {
                uVar7 = func_0x00018046d050();
                if (*(int64_t *)(iVar10 + 0x2c98) != 0) {
                    func_0x000180498030(uVar7);
                    func_0x000180460d90();
                }
                *(undefined8 *)(iVar10 + 0x2c98) = uVar7;
                *(int32_t *)(iVar10 + 0x2c94) = iVar11;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            iVar14 = 0;
            iVar10 = *(int64_t *)(iVar10 + 0x2c98);
            if (0 < iVar11) {
                do {
                    iVar8 = (int64_t)iVar14;
                    *(int16_t *)(iVar10 + iVar8 * 0x10) = (int16_t)iVar14;
                    iVar14 = iVar14 + 1;
                    *(int64_t *)(iVar10 + 8 + iVar8 * 0x10) = arg1;
                    iVar11 = *(int32_t *)(arg1 + 0x6c);
                } while (iVar14 < iVar11);
            }
            if (1 < (uint64_t)(int64_t)iVar11) {
                func_0x00018046f0d0(iVar10, (int64_t)iVar11, 0x10, 0x180138060);
            }
            iVar14 = 0;
            if (*(int32_t *)(arg1 + 0x6c) < 1) {
                return;
            }
            do {
                *(int16_t *)
                 ((int64_t)*(int16_t *)(iVar10 + (int64_t)iVar14 * 0x10) * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) =
                     (int16_t)iVar14;
                iVar14 = iVar14 + 1;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        if (0 < iVar11) {
            do {
                *(int16_t *)
                 (*(int64_t *)(arg1 + 0x28) +
                 (int64_t)*(int16_t *)((int64_t)iVar14 * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) * 2) = (int16_t)iVar14
                ;
                iVar14 = iVar14 + 1;
            } while (iVar14 < *(int32_t *)(arg1 + 0x6c));
        }
    }
    return;
}

// ============================================================
// Function: FUN_18013804d
// Address: 0x18013804d
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2968h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c6ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c68h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2940h because it doesn't fit into ProtoModel

void fcn.180137ce0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    float fVar2;
    int16_t iVar3;
    uint32_t uVar4;
    uint8_t uVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint32_t *puVar12;
    int64_t iVar13;
    int32_t iVar14;
    bool bVar15;
    float fVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined *)(arg1 + 0x240) = 0;
    iVar10 = *(int64_t *)0x180781f28;
    if ((*(uint8_t *)(arg1 + 4) & 0x10) == 0) {
        if (*(int32_t *)(arg1 + 100) == -1) {
            puVar6 = (undefined4 *)func_0x000180137c90(*(undefined4 *)arg1);
            iVar10 = *(int64_t *)0x180781f28;
            if (puVar6 == (undefined4 *)0x0) {
                return;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            if (*(int16_t *)(puVar6 + 3) != iVar11) {
                *(undefined *)(arg1 + 0x241) = 1;
            }
            *(int32_t *)(arg1 + 100) = (int32_t)puVar6 - *(int32_t *)(iVar10 + 0x2968);
        } else {
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            puVar6 = (undefined4 *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x2968) + (int64_t)*(int32_t *)(arg1 + 100));
            if (*(int16_t *)((int64_t)puVar6 + 0xe) < iVar11) {
                *puVar6 = 0;
                puVar6 = (undefined4 *)0x0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            }
        }
        iVar14 = 0;
        *(undefined4 *)(arg1 + 0x60) = puVar6[1];
        *(undefined4 *)(arg1 + 0xe4) = puVar6[2];
        if (0 < iVar11) {
            do {
                puVar12 = (uint32_t *)((int64_t)iVar14 * 0x74 + *(int64_t *)(arg1 + 0x18));
                uVar4 = *puVar12;
                fVar2 = (float)puVar12[8];
                if (((uVar4 & 0x10) == 0) || (fVar16 = fVar2, fVar2 <= 0.0)) {
                    fVar16 = -1.0;
                }
                puVar12[4] = (uint32_t)fVar16;
                if ((fVar2 <= 0.0) || (fVar16 = fVar2, (uVar4 & 8) == 0)) {
                    fVar16 = -1.0;
                }
                puVar12[7] = (uint32_t)fVar16;
                if (0.0 < fVar2) {
                    *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                }
                *(int16_t *)((int64_t)puVar12 + 0x56) = (int16_t)(((int64_t)puVar12 - *(int64_t *)(arg1 + 0x18)) / 0x74)
                ;
                uVar5 = ~(uint8_t)(uVar4 >> 1) & 1;
                *(uint8_t *)(puVar12 + 0x1a) = uVar5;
                *(uint8_t *)((int64_t)puVar12 + 0x67) = uVar5;
                *(uint16_t *)((int64_t)puVar12 + 0x5e) = ((uVar4 & 4) != 0) - 1;
                if ((uVar4 & 4) == 0) {
                    uVar5 = 0;
                } else {
                    uVar5 = ((uVar4 >> 0xf & 1) != 0) + 1;
                }
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) & 0xfc;
                iVar14 = iVar14 + 1;
                *(uint8_t *)((int64_t)puVar12 + 0x71) = *(uint8_t *)((int64_t)puVar12 + 0x71) | uVar5;
                *(undefined *)((int64_t)puVar12 + 0x6f) = 0;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        puVar9 = puVar6 + 5;
        if (0 < *(int16_t *)(puVar6 + 3)) {
            do {
                iVar3 = *(int16_t *)(puVar9 + 2);
                if ((-1 < iVar3) && ((int32_t)iVar3 < *(int32_t *)(arg1 + 0x6c))) {
                    iVar8 = *(int64_t *)(arg1 + 0x18);
                    iVar13 = (int64_t)iVar3 * 0x74;
                    if ((*(uint8_t *)(puVar6 + 1) & 1) != 0) {
                        if ((*(uint8_t *)((int64_t)puVar9 + 0xe) & 0x10) == 0) {
                            *(undefined4 *)(iVar13 + 0x10 + iVar8) = *puVar9;
                        } else {
                            *(undefined4 *)(iVar13 + 0x1c + iVar8) = *puVar9;
                        }
                    }
                    if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
                        *(undefined2 *)(iVar13 + 0x56 + iVar8) = *(undefined2 *)((int64_t)puVar9 + 10);
                    }
                    if (((*(uint8_t *)(puVar6 + 1) & 4) != 0) &&
                       (uVar5 = *(char *)((int64_t)puVar9 + 0xe) << 4, (uVar5 & 0xc0) != 0xc0)) {
                        bVar15 = (uVar5 & 0xc0) == 0x40;
                        *(bool *)(iVar13 + 0x68 + iVar8) = bVar15;
                        *(bool *)(iVar13 + 0x67 + iVar8) = bVar15;
                    }
                    *(undefined2 *)(iVar13 + 0x5e + iVar8) = *(undefined2 *)(puVar9 + 3);
                    puVar1 = (uint8_t *)(iVar13 + 0x71 + iVar8);
                    *puVar1 = *puVar1 ^ (*(uint8_t *)(iVar13 + 0x71 + iVar8) ^ *(uint8_t *)((int64_t)puVar9 + 0xe)) & 3;
                }
                iVar14 = iVar14 + 1;
                puVar9 = puVar9 + 4;
            } while (iVar14 < *(int16_t *)(puVar6 + 3));
            iVar11 = *(int32_t *)(arg1 + 0x6c);
        }
        if ((*(uint8_t *)(puVar6 + 1) & 2) != 0) {
            iVar11 = *(int32_t *)(arg1 + 0x6c) * 0x10;
            if (*(int32_t *)(iVar10 + 0x2c94) < iVar11) {
                uVar7 = func_0x00018046d050();
                if (*(int64_t *)(iVar10 + 0x2c98) != 0) {
                    func_0x000180498030(uVar7);
                    func_0x000180460d90();
                }
                *(undefined8 *)(iVar10 + 0x2c98) = uVar7;
                *(int32_t *)(iVar10 + 0x2c94) = iVar11;
            }
            iVar11 = *(int32_t *)(arg1 + 0x6c);
            iVar14 = 0;
            iVar10 = *(int64_t *)(iVar10 + 0x2c98);
            if (0 < iVar11) {
                do {
                    iVar8 = (int64_t)iVar14;
                    *(int16_t *)(iVar10 + iVar8 * 0x10) = (int16_t)iVar14;
                    iVar14 = iVar14 + 1;
                    *(int64_t *)(iVar10 + 8 + iVar8 * 0x10) = arg1;
                    iVar11 = *(int32_t *)(arg1 + 0x6c);
                } while (iVar14 < iVar11);
            }
            if (1 < (uint64_t)(int64_t)iVar11) {
                func_0x00018046f0d0(iVar10, (int64_t)iVar11, 0x10, 0x180138060);
            }
            iVar14 = 0;
            if (*(int32_t *)(arg1 + 0x6c) < 1) {
                return;
            }
            do {
                *(int16_t *)
                 ((int64_t)*(int16_t *)(iVar10 + (int64_t)iVar14 * 0x10) * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) =
                     (int16_t)iVar14;
                iVar14 = iVar14 + 1;
                iVar11 = *(int32_t *)(arg1 + 0x6c);
            } while (iVar14 < iVar11);
        }
        iVar14 = 0;
        if (0 < iVar11) {
            do {
                *(int16_t *)
                 (*(int64_t *)(arg1 + 0x28) +
                 (int64_t)*(int16_t *)((int64_t)iVar14 * 0x74 + 0x56 + *(int64_t *)(arg1 + 0x18)) * 2) = (int16_t)iVar14
                ;
                iVar14 = iVar14 + 1;
            } while (iVar14 < *(int32_t *)(arg1 + 0x6c));
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801380b0
// Address: 0x1801380b0
// Size: 122 bytes
// ============================================================
void fcn.1801380b0(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    
    iVar2 = 0;
    if (*(int32_t *)(arg1 + 0x2500) != 0) {
        do {
            iVar1 = *(int32_t *)(*(int64_t *)(arg1 + 0x2508) + 8 + (int64_t)iVar2 * 0x10);
            if ((iVar1 != -1) && (iVar3 = (int64_t)iVar1 * 0x250 + *(int64_t *)(arg1 + 0x24f8), iVar3 != 0)) {
                *(undefined4 *)(iVar3 + 100) = 0xffffffff;
            }
            iVar2 = iVar2 + 1;
        } while (iVar2 != *(int32_t *)(arg1 + 0x2500));
    }
    if (*(int64_t *)(arg1 + 0x2968) != 0) {
        *(undefined8 *)(arg1 + 0x2960) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x2968) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180138190
// Address: 0x180138190
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint32_t * fcn.180138190(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t *puVar3;
    uint32_t *puVar4;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    var_20h._0_4_ = 0;
    var_18h._0_4_ = 0;
    iVar2 = fcn.1800f3a40(arg3, 0x180645848, &var_20h, &var_18h);
    if (iVar2 < 2) {
        return (uint32_t *)0x0;
    }
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2968);
    puVar3 = (uint32_t *)0x0;
    if (iVar1 != 0) {
        puVar3 = (uint32_t *)(iVar1 + 4);
    }
    do {
        if (puVar3 == (uint32_t *)0x0) {
code_r0x00018013824f:
            puVar3 = (uint32_t *)fcn.180137c20((uint64_t)(uint32_t)var_20h, (uint64_t)(uint32_t)var_18h);
            return puVar3;
        }
        if (*puVar3 == (uint32_t)var_20h) {
            if ((int32_t)(uint32_t)var_18h <= (int32_t)*(int16_t *)((int64_t)puVar3 + 0xe)) {
                fcn.180137af0((int64_t)puVar3, (uint64_t)(uint32_t)var_20h, (uint64_t)(uint32_t)var_18h, 
                              (uint64_t)(uint32_t)(int32_t)*(int16_t *)((int64_t)puVar3 + 0xe));
                return puVar3;
            }
            *puVar3 = 0;
            goto code_r0x00018013824f;
        }
        puVar4 = (uint32_t *)((int64_t)(int32_t)puVar3[-1] + (int64_t)puVar3);
        puVar3 = (uint32_t *)0x0;
        if (puVar4 != (uint32_t *)((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2960) + 4 + iVar1)) {
            puVar3 = puVar4;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801381d5
// Address: 0x1801381d5
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint32_t * fcn.180138190(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t *puVar3;
    uint32_t *puVar4;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    var_20h._0_4_ = 0;
    var_18h._0_4_ = 0;
    iVar2 = fcn.1800f3a40(arg3, 0x180645848, &var_20h, &var_18h);
    if (iVar2 < 2) {
        return (uint32_t *)0x0;
    }
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2968);
    puVar3 = (uint32_t *)0x0;
    if (iVar1 != 0) {
        puVar3 = (uint32_t *)(iVar1 + 4);
    }
    do {
        if (puVar3 == (uint32_t *)0x0) {
code_r0x00018013824f:
            puVar3 = (uint32_t *)fcn.180137c20((uint64_t)(uint32_t)var_20h, (uint64_t)(uint32_t)var_18h);
            return puVar3;
        }
        if (*puVar3 == (uint32_t)var_20h) {
            if ((int32_t)(uint32_t)var_18h <= (int32_t)*(int16_t *)((int64_t)puVar3 + 0xe)) {
                fcn.180137af0((int64_t)puVar3, (uint64_t)(uint32_t)var_20h, (uint64_t)(uint32_t)var_18h, 
                              (uint64_t)(uint32_t)(int32_t)*(int16_t *)((int64_t)puVar3 + 0xe));
                return puVar3;
            }
            *puVar3 = 0;
            goto code_r0x00018013824f;
        }
        puVar4 = (uint32_t *)((int64_t)(int32_t)puVar3[-1] + (int64_t)puVar3);
        puVar3 = (uint32_t *)0x0;
        if (puVar4 != (uint32_t *)((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2960) + 4 + iVar1)) {
            puVar3 = puVar4;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180138244
// Address: 0x180138244
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint32_t * fcn.180138190(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t *puVar3;
    uint32_t *puVar4;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    var_20h._0_4_ = 0;
    var_18h._0_4_ = 0;
    iVar2 = fcn.1800f3a40(arg3, 0x180645848, &var_20h, &var_18h);
    if (iVar2 < 2) {
        return (uint32_t *)0x0;
    }
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2968);
    puVar3 = (uint32_t *)0x0;
    if (iVar1 != 0) {
        puVar3 = (uint32_t *)(iVar1 + 4);
    }
    do {
        if (puVar3 == (uint32_t *)0x0) {
code_r0x00018013824f:
            puVar3 = (uint32_t *)fcn.180137c20((uint64_t)(uint32_t)var_20h, (uint64_t)(uint32_t)var_18h);
            return puVar3;
        }
        if (*puVar3 == (uint32_t)var_20h) {
            if ((int32_t)(uint32_t)var_18h <= (int32_t)*(int16_t *)((int64_t)puVar3 + 0xe)) {
                fcn.180137af0((int64_t)puVar3, (uint64_t)(uint32_t)var_20h, (uint64_t)(uint32_t)var_18h, 
                              (uint64_t)(uint32_t)(int32_t)*(int16_t *)((int64_t)puVar3 + 0xe));
                return puVar3;
            }
            *puVar3 = 0;
            goto code_r0x00018013824f;
        }
        puVar4 = (uint32_t *)((int64_t)(int32_t)puVar3[-1] + (int64_t)puVar3);
        puVar3 = (uint32_t *)0x0;
        if (puVar4 != (uint32_t *)((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2960) + 4 + iVar1)) {
            puVar3 = puVar4;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180138270
// Address: 0x180138270
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.180138270(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    int32_t iVar2;
    char *pcVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h._0_4_ = 0;
    var_20h._4_4_ = 0;
    var_28h._0_4_ = 0;
    var_28h._4_4_ = 0;
    iVar2 = fcn.1800f3a40(arg4, 0x180645978, &var_20h);
    if (iVar2 != 1) {
        iVar2 = fcn.1800f3a40(arg4, 0x180645988, (int64_t)&var_20h + 4, &var_28h);
        if (((iVar2 == 1) && (-1 < var_20h._4_4_)) && (var_20h._4_4_ < *(int16_t *)(arg3 + 0xc))) {
            for (pcVar3 = (char *)((int32_t)var_28h + arg4); (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1)
            {
            }
            var_18h._0_1_ = '\0';
            iVar4 = (int64_t)var_20h._4_4_ * 0x10;
            *(int16_t *)(iVar4 + 0x1c + arg3) = (int16_t)var_20h._4_4_;
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645998, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                *(int32_t *)(iVar4 + 0x18 + arg3) = var_28h._4_4_;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x1806459a8, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                puVar1 = (uint8_t *)(iVar4 + 0x22 + arg3);
                *puVar1 = *puVar1 & 0xef;
                *(float *)(iVar4 + 0x14 + arg3) = (float)var_28h._4_4_;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 1;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645938, &var_20h, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                puVar1 = (uint8_t *)(iVar4 + 0x22 + arg3);
                *puVar1 = *puVar1 | 0x10;
                *(undefined4 *)(iVar4 + 0x14 + arg3) = (undefined4)var_20h;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 1;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645948, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                *(uint8_t *)(iVar4 + 0x22 + arg3) = (var_28h._4_1_ & 3) << 2 | *(uint8_t *)(iVar4 + 0x22 + arg3) & 0xf3;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 4;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645958, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                *(undefined2 *)(iVar4 + 0x1e + arg3) = var_28h._4_2_;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 2;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645968, (int64_t)&var_28h + 4, &var_18h, &var_28h);
            if (iVar2 == 2) {
                *(undefined2 *)(iVar4 + 0x20 + arg3) = var_28h._4_2_;
                *(uint8_t *)(iVar4 + 0x22 + arg3) =
                     ((char)var_18h == '^') + 1U | *(uint8_t *)(iVar4 + 0x22 + arg3) & 0xfc;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 8;
            }
        }
        return;
    }
    *(undefined4 *)(arg3 + 8) = (undefined4)var_20h;
    return;
}

// ============================================================
// Function: FUN_1801382f5
// Address: 0x1801382f5
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.180138270(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    int32_t iVar2;
    char *pcVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h._0_4_ = 0;
    var_20h._4_4_ = 0;
    var_28h._0_4_ = 0;
    var_28h._4_4_ = 0;
    iVar2 = fcn.1800f3a40(arg4, 0x180645978, &var_20h);
    if (iVar2 != 1) {
        iVar2 = fcn.1800f3a40(arg4, 0x180645988, (int64_t)&var_20h + 4, &var_28h);
        if (((iVar2 == 1) && (-1 < var_20h._4_4_)) && (var_20h._4_4_ < *(int16_t *)(arg3 + 0xc))) {
            for (pcVar3 = (char *)((int32_t)var_28h + arg4); (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1)
            {
            }
            var_18h._0_1_ = '\0';
            iVar4 = (int64_t)var_20h._4_4_ * 0x10;
            *(int16_t *)(iVar4 + 0x1c + arg3) = (int16_t)var_20h._4_4_;
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645998, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                *(int32_t *)(iVar4 + 0x18 + arg3) = var_28h._4_4_;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x1806459a8, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                puVar1 = (uint8_t *)(iVar4 + 0x22 + arg3);
                *puVar1 = *puVar1 & 0xef;
                *(float *)(iVar4 + 0x14 + arg3) = (float)var_28h._4_4_;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 1;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645938, &var_20h, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                puVar1 = (uint8_t *)(iVar4 + 0x22 + arg3);
                *puVar1 = *puVar1 | 0x10;
                *(undefined4 *)(iVar4 + 0x14 + arg3) = (undefined4)var_20h;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 1;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645948, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                *(uint8_t *)(iVar4 + 0x22 + arg3) = (var_28h._4_1_ & 3) << 2 | *(uint8_t *)(iVar4 + 0x22 + arg3) & 0xf3;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 4;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645958, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                *(undefined2 *)(iVar4 + 0x1e + arg3) = var_28h._4_2_;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 2;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645968, (int64_t)&var_28h + 4, &var_18h, &var_28h);
            if (iVar2 == 2) {
                *(undefined2 *)(iVar4 + 0x20 + arg3) = var_28h._4_2_;
                *(uint8_t *)(iVar4 + 0x22 + arg3) =
                     ((char)var_18h == '^') + 1U | *(uint8_t *)(iVar4 + 0x22 + arg3) & 0xfc;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 8;
            }
        }
        return;
    }
    *(undefined4 *)(arg3 + 8) = (undefined4)var_20h;
    return;
}

// ============================================================
// Function: FUN_18013838e
// Address: 0x18013838e
// Size: 352 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.180138270(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    int32_t iVar2;
    char *pcVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h._0_4_ = 0;
    var_20h._4_4_ = 0;
    var_28h._0_4_ = 0;
    var_28h._4_4_ = 0;
    iVar2 = fcn.1800f3a40(arg4, 0x180645978, &var_20h);
    if (iVar2 != 1) {
        iVar2 = fcn.1800f3a40(arg4, 0x180645988, (int64_t)&var_20h + 4, &var_28h);
        if (((iVar2 == 1) && (-1 < var_20h._4_4_)) && (var_20h._4_4_ < *(int16_t *)(arg3 + 0xc))) {
            for (pcVar3 = (char *)((int32_t)var_28h + arg4); (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1)
            {
            }
            var_18h._0_1_ = '\0';
            iVar4 = (int64_t)var_20h._4_4_ * 0x10;
            *(int16_t *)(iVar4 + 0x1c + arg3) = (int16_t)var_20h._4_4_;
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645998, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                *(int32_t *)(iVar4 + 0x18 + arg3) = var_28h._4_4_;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x1806459a8, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                puVar1 = (uint8_t *)(iVar4 + 0x22 + arg3);
                *puVar1 = *puVar1 & 0xef;
                *(float *)(iVar4 + 0x14 + arg3) = (float)var_28h._4_4_;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 1;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645938, &var_20h, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                puVar1 = (uint8_t *)(iVar4 + 0x22 + arg3);
                *puVar1 = *puVar1 | 0x10;
                *(undefined4 *)(iVar4 + 0x14 + arg3) = (undefined4)var_20h;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 1;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645948, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                *(uint8_t *)(iVar4 + 0x22 + arg3) = (var_28h._4_1_ & 3) << 2 | *(uint8_t *)(iVar4 + 0x22 + arg3) & 0xf3;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 4;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645958, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                *(undefined2 *)(iVar4 + 0x1e + arg3) = var_28h._4_2_;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 2;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645968, (int64_t)&var_28h + 4, &var_18h, &var_28h);
            if (iVar2 == 2) {
                *(undefined2 *)(iVar4 + 0x20 + arg3) = var_28h._4_2_;
                *(uint8_t *)(iVar4 + 0x22 + arg3) =
                     ((char)var_18h == '^') + 1U | *(uint8_t *)(iVar4 + 0x22 + arg3) & 0xfc;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 8;
            }
        }
        return;
    }
    *(undefined4 *)(arg3 + 8) = (undefined4)var_20h;
    return;
}

// ============================================================
// Function: FUN_1801384ee
// Address: 0x1801384ee
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.180138270(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    int32_t iVar2;
    char *pcVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h._0_4_ = 0;
    var_20h._4_4_ = 0;
    var_28h._0_4_ = 0;
    var_28h._4_4_ = 0;
    iVar2 = fcn.1800f3a40(arg4, 0x180645978, &var_20h);
    if (iVar2 != 1) {
        iVar2 = fcn.1800f3a40(arg4, 0x180645988, (int64_t)&var_20h + 4, &var_28h);
        if (((iVar2 == 1) && (-1 < var_20h._4_4_)) && (var_20h._4_4_ < *(int16_t *)(arg3 + 0xc))) {
            for (pcVar3 = (char *)((int32_t)var_28h + arg4); (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1)
            {
            }
            var_18h._0_1_ = '\0';
            iVar4 = (int64_t)var_20h._4_4_ * 0x10;
            *(int16_t *)(iVar4 + 0x1c + arg3) = (int16_t)var_20h._4_4_;
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645998, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                *(int32_t *)(iVar4 + 0x18 + arg3) = var_28h._4_4_;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x1806459a8, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                puVar1 = (uint8_t *)(iVar4 + 0x22 + arg3);
                *puVar1 = *puVar1 & 0xef;
                *(float *)(iVar4 + 0x14 + arg3) = (float)var_28h._4_4_;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 1;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645938, &var_20h, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                puVar1 = (uint8_t *)(iVar4 + 0x22 + arg3);
                *puVar1 = *puVar1 | 0x10;
                *(undefined4 *)(iVar4 + 0x14 + arg3) = (undefined4)var_20h;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 1;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645948, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                *(uint8_t *)(iVar4 + 0x22 + arg3) = (var_28h._4_1_ & 3) << 2 | *(uint8_t *)(iVar4 + 0x22 + arg3) & 0xf3;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 4;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645958, (int64_t)&var_28h + 4, &var_28h);
            if (iVar2 == 1) {
                for (pcVar3 = pcVar3 + (int32_t)var_28h; (*pcVar3 == ' ' || (*pcVar3 == '\t')); pcVar3 = pcVar3 + 1) {
                }
                *(undefined2 *)(iVar4 + 0x1e + arg3) = var_28h._4_2_;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 2;
            }
            iVar2 = fcn.1800f3a40(pcVar3, 0x180645968, (int64_t)&var_28h + 4, &var_18h, &var_28h);
            if (iVar2 == 2) {
                *(undefined2 *)(iVar4 + 0x20 + arg3) = var_28h._4_2_;
                *(uint8_t *)(iVar4 + 0x22 + arg3) =
                     ((char)var_18h == '^') + 1U | *(uint8_t *)(iVar4 + 0x22 + arg3) & 0xfc;
                *(uint32_t *)(arg3 + 4) = *(uint32_t *)(arg3 + 4) | 8;
            }
        }
        return;
    }
    *(undefined4 *)(arg3 + 8) = (undefined4)var_20h;
    return;
}

// ============================================================
// Function: FUN_180138500
// Address: 0x180138500
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_54h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h

void fcn.180138500(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    float *pfVar9;
    double dVar10;
    int32_t *piVar11;
    int32_t iVar13;
    uint64_t uVar14;
    uint8_t uVar15;
    char cVar16;
    undefined4 uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_87h;
    int64_t var_68h;
    int64_t var_54h;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined4 uVar12;
    uint64_t uVar17;
    
    piVar4 = (int32_t *)0x0;
    if (*(int64_t *)(arg1 + 0x2968) != 0) {
        piVar4 = (int32_t *)(*(int64_t *)(arg1 + 0x2968) + 4);
    }
    do {
        if (piVar4 == (int32_t *)0x0) {
            return;
        }
        if (*piVar4 != 0) {
            uVar2 = piVar4[1];
            uVar15 = (uint8_t)uVar2 & 1;
            iVar6 = *(int32_t *)arg3 + -1 + *(int16_t *)(piVar4 + 3) * 0x32;
            if (*(int32_t *)arg3 == 0) {
                iVar6 = *(int16_t *)(piVar4 + 3) * 0x32;
            }
            iVar6 = iVar6 + 0x1e;
            if (*(int32_t *)(arg3 + 4) < iVar6) {
                uVar5 = func_0x00018046d050((int64_t)iVar6);
                if (*(int64_t *)(arg3 + 8) != 0) {
                    func_0x000180498030(uVar5, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
                    func_0x000180460d90(*(undefined8 *)(arg3 + 8));
                }
                *(undefined8 *)(arg3 + 8) = uVar5;
                *(int32_t *)(arg3 + 4) = iVar6;
            }
            uVar14 = (uint64_t)(uVar2 & 8);
            uVar17 = (uint64_t)uVar15;
            func_0x0001800f65a0(arg3, 0x1806459f8, *(undefined8 *)arg2, *piVar4, (int32_t)*(int16_t *)(piVar4 + 3));
            fVar1 = (float)piVar4[2];
            if (fVar1 != 0.0) {
                func_0x0001800f65a0(fVar1, 0x180645a10, (double)fVar1);
            }
            iVar6 = 0;
            pfVar9 = (float *)(piVar4 + 5);
            if (0 < *(int16_t *)(piVar4 + 3)) {
                do {
                    iVar13 = (int32_t)uVar14;
                    cVar16 = (char)uVar17;
                    if (((((pfVar9[1] != 0.0) || (cVar16 != '\0')) || ((uVar2 & 4) != 0)) || ((uVar2 & 2) != 0)) ||
                       ((iVar13 != 0 && (*(int16_t *)(pfVar9 + 3) != -1)))) {
                        uVar18 = func_0x0001800f65a0(arg3, 0x180645a20, iVar6);
                        uVar12 = 0;
                        if (pfVar9[1] != 0.0) {
                            uVar12 = 0;
                            func_0x0001800f65a0(uVar18, 0x180645a30);
                        }
                        if (cVar16 != '\0') {
                            if ((*(uint8_t *)((int64_t)pfVar9 + 0xe) & 0x10) != 0) {
                                dVar10 = (double)*pfVar9;
                                func_0x0001800f65a0(arg3, 0x1806459b8, dVar10);
                                uVar12 = (undefined4)((uint64_t)dVar10 >> 0x20);
                                if ((*(uint8_t *)((int64_t)pfVar9 + 0xe) & 0x10) != 0) goto code_r0x0001801386d0;
                            }
                            func_0x0001800f65a0(arg3, 0x1806459c8, CONCAT44(uVar12, (int32_t)*pfVar9));
                        }
code_r0x0001801386d0:
                        if ((uVar2 & 4) != 0) {
                            func_0x0001800f65a0(arg3, 0x1806459d8, 
                                                (int32_t)(char)(*(char *)((int64_t)pfVar9 + 0xe) << 4) >> 6);
                        }
                        if ((uVar2 & 2) != 0) {
                            func_0x0001800f65a0(arg3, 0x1806459e8, (int32_t)*(int16_t *)((int64_t)pfVar9 + 10));
                        }
                        if ((iVar13 != 0) && (*(int16_t *)(pfVar9 + 3) != -1)) {
                            uVar5 = 0x5e;
                            if ((*(uint8_t *)((int64_t)pfVar9 + 0xe) & 3) == 1) {
                                uVar5 = 0x76;
                            }
                            func_0x0001800f65a0(arg3, 0x180645a40, (int32_t)*(int16_t *)(pfVar9 + 3), uVar5);
                        }
                        iVar13 = 1;
                        if (*(int32_t *)arg3 != 0) {
                            iVar13 = *(int32_t *)arg3;
                        }
                        iVar8 = *(int32_t *)(arg3 + 4);
                        iVar3 = iVar13 + 1;
                        if (iVar8 <= iVar3) {
                            iVar7 = iVar8 * 2;
                            if (iVar8 * 2 < iVar3) {
                                iVar7 = iVar3;
                            }
                            if (iVar8 < iVar7) {
                                uVar5 = func_0x00018046d050((int64_t)iVar7);
                                if (*(int64_t *)(arg3 + 8) != 0) {
                                    func_0x000180498030(uVar5, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
                                    func_0x000180460d90(*(undefined8 *)(arg3 + 8));
                                }
                                *(undefined8 *)(arg3 + 8) = uVar5;
                                *(int32_t *)(arg3 + 4) = iVar7;
                            }
                        }
                        fcn.18011f640(CONCAT44(uStack_4c, uVar2) & 0xffffffff00000002);
                        uVar14 = (uint64_t)(uVar2 & 8);
                        uVar17 = (uint64_t)uVar15;
                        *(undefined *)((int64_t)iVar13 + -1 + *(int64_t *)(arg3 + 8)) = 10;
                        *(undefined *)((int64_t)iVar13 + *(int64_t *)(arg3 + 8)) = 0;
                    }
                    iVar6 = iVar6 + 1;
                    pfVar9 = pfVar9 + 4;
                } while (iVar6 < *(int16_t *)(piVar4 + 3));
            }
            iVar6 = 1;
            if (*(int32_t *)arg3 != 0) {
                iVar6 = *(int32_t *)arg3;
            }
            iVar3 = *(int32_t *)(arg3 + 4);
            iVar13 = iVar6 + 1;
            if (iVar3 <= iVar13) {
                iVar8 = iVar3 * 2;
                if (iVar3 * 2 < iVar13) {
                    iVar8 = iVar13;
                }
                if (iVar3 < iVar8) {
                    uVar5 = func_0x00018046d050((int64_t)iVar8);
                    if (*(int64_t *)(arg3 + 8) != 0) {
                        func_0x000180498030(uVar5, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
                        func_0x000180460d90(*(undefined8 *)(arg3 + 8));
                    }
                    *(undefined8 *)(arg3 + 8) = uVar5;
                    *(int32_t *)(arg3 + 4) = iVar8;
                }
            }
            fcn.18011f640(CONCAT44(uStack_4c, uVar2) & 0xffffffff00000002);
            *(undefined *)((int64_t)iVar6 + -1 + *(int64_t *)(arg3 + 8)) = 10;
            *(undefined *)((int64_t)iVar6 + *(int64_t *)(arg3 + 8)) = 0;
        }
        piVar11 = (int32_t *)((int64_t)piVar4[-1] + (int64_t)piVar4);
        piVar4 = (int32_t *)0x0;
        if (piVar11 != (int32_t *)(*(int64_t *)(arg1 + 0x2968) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2960))) {
            piVar4 = piVar11;
        }
    } while( true );
}

// ============================================================
// Function: FUN_18013853d
// Address: 0x18013853d
// Size: 878 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_54h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h

void fcn.180138500(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    float *pfVar9;
    double dVar10;
    int32_t *piVar11;
    int32_t iVar13;
    uint64_t uVar14;
    uint8_t uVar15;
    char cVar16;
    undefined4 uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_87h;
    int64_t var_68h;
    int64_t var_54h;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined4 uVar12;
    uint64_t uVar17;
    
    piVar4 = (int32_t *)0x0;
    if (*(int64_t *)(arg1 + 0x2968) != 0) {
        piVar4 = (int32_t *)(*(int64_t *)(arg1 + 0x2968) + 4);
    }
    do {
        if (piVar4 == (int32_t *)0x0) {
            return;
        }
        if (*piVar4 != 0) {
            uVar2 = piVar4[1];
            uVar15 = (uint8_t)uVar2 & 1;
            iVar6 = *(int32_t *)arg3 + -1 + *(int16_t *)(piVar4 + 3) * 0x32;
            if (*(int32_t *)arg3 == 0) {
                iVar6 = *(int16_t *)(piVar4 + 3) * 0x32;
            }
            iVar6 = iVar6 + 0x1e;
            if (*(int32_t *)(arg3 + 4) < iVar6) {
                uVar5 = func_0x00018046d050((int64_t)iVar6);
                if (*(int64_t *)(arg3 + 8) != 0) {
                    func_0x000180498030(uVar5, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
                    func_0x000180460d90(*(undefined8 *)(arg3 + 8));
                }
                *(undefined8 *)(arg3 + 8) = uVar5;
                *(int32_t *)(arg3 + 4) = iVar6;
            }
            uVar14 = (uint64_t)(uVar2 & 8);
            uVar17 = (uint64_t)uVar15;
            func_0x0001800f65a0(arg3, 0x1806459f8, *(undefined8 *)arg2, *piVar4, (int32_t)*(int16_t *)(piVar4 + 3));
            fVar1 = (float)piVar4[2];
            if (fVar1 != 0.0) {
                func_0x0001800f65a0(fVar1, 0x180645a10, (double)fVar1);
            }
            iVar6 = 0;
            pfVar9 = (float *)(piVar4 + 5);
            if (0 < *(int16_t *)(piVar4 + 3)) {
                do {
                    iVar13 = (int32_t)uVar14;
                    cVar16 = (char)uVar17;
                    if (((((pfVar9[1] != 0.0) || (cVar16 != '\0')) || ((uVar2 & 4) != 0)) || ((uVar2 & 2) != 0)) ||
                       ((iVar13 != 0 && (*(int16_t *)(pfVar9 + 3) != -1)))) {
                        uVar18 = func_0x0001800f65a0(arg3, 0x180645a20, iVar6);
                        uVar12 = 0;
                        if (pfVar9[1] != 0.0) {
                            uVar12 = 0;
                            func_0x0001800f65a0(uVar18, 0x180645a30);
                        }
                        if (cVar16 != '\0') {
                            if ((*(uint8_t *)((int64_t)pfVar9 + 0xe) & 0x10) != 0) {
                                dVar10 = (double)*pfVar9;
                                func_0x0001800f65a0(arg3, 0x1806459b8, dVar10);
                                uVar12 = (undefined4)((uint64_t)dVar10 >> 0x20);
                                if ((*(uint8_t *)((int64_t)pfVar9 + 0xe) & 0x10) != 0) goto code_r0x0001801386d0;
                            }
                            func_0x0001800f65a0(arg3, 0x1806459c8, CONCAT44(uVar12, (int32_t)*pfVar9));
                        }
code_r0x0001801386d0:
                        if ((uVar2 & 4) != 0) {
                            func_0x0001800f65a0(arg3, 0x1806459d8, 
                                                (int32_t)(char)(*(char *)((int64_t)pfVar9 + 0xe) << 4) >> 6);
                        }
                        if ((uVar2 & 2) != 0) {
                            func_0x0001800f65a0(arg3, 0x1806459e8, (int32_t)*(int16_t *)((int64_t)pfVar9 + 10));
                        }
                        if ((iVar13 != 0) && (*(int16_t *)(pfVar9 + 3) != -1)) {
                            uVar5 = 0x5e;
                            if ((*(uint8_t *)((int64_t)pfVar9 + 0xe) & 3) == 1) {
                                uVar5 = 0x76;
                            }
                            func_0x0001800f65a0(arg3, 0x180645a40, (int32_t)*(int16_t *)(pfVar9 + 3), uVar5);
                        }
                        iVar13 = 1;
                        if (*(int32_t *)arg3 != 0) {
                            iVar13 = *(int32_t *)arg3;
                        }
                        iVar8 = *(int32_t *)(arg3 + 4);
                        iVar3 = iVar13 + 1;
                        if (iVar8 <= iVar3) {
                            iVar7 = iVar8 * 2;
                            if (iVar8 * 2 < iVar3) {
                                iVar7 = iVar3;
                            }
                            if (iVar8 < iVar7) {
                                uVar5 = func_0x00018046d050((int64_t)iVar7);
                                if (*(int64_t *)(arg3 + 8) != 0) {
                                    func_0x000180498030(uVar5, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
                                    func_0x000180460d90(*(undefined8 *)(arg3 + 8));
                                }
                                *(undefined8 *)(arg3 + 8) = uVar5;
                                *(int32_t *)(arg3 + 4) = iVar7;
                            }
                        }
                        fcn.18011f640(CONCAT44(uStack_4c, uVar2) & 0xffffffff00000002);
                        uVar14 = (uint64_t)(uVar2 & 8);
                        uVar17 = (uint64_t)uVar15;
                        *(undefined *)((int64_t)iVar13 + -1 + *(int64_t *)(arg3 + 8)) = 10;
                        *(undefined *)((int64_t)iVar13 + *(int64_t *)(arg3 + 8)) = 0;
                    }
                    iVar6 = iVar6 + 1;
                    pfVar9 = pfVar9 + 4;
                } while (iVar6 < *(int16_t *)(piVar4 + 3));
            }
            iVar6 = 1;
            if (*(int32_t *)arg3 != 0) {
                iVar6 = *(int32_t *)arg3;
            }
            iVar3 = *(int32_t *)(arg3 + 4);
            iVar13 = iVar6 + 1;
            if (iVar3 <= iVar13) {
                iVar8 = iVar3 * 2;
                if (iVar3 * 2 < iVar13) {
                    iVar8 = iVar13;
                }
                if (iVar3 < iVar8) {
                    uVar5 = func_0x00018046d050((int64_t)iVar8);
                    if (*(int64_t *)(arg3 + 8) != 0) {
                        func_0x000180498030(uVar5, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
                        func_0x000180460d90(*(undefined8 *)(arg3 + 8));
                    }
                    *(undefined8 *)(arg3 + 8) = uVar5;
                    *(int32_t *)(arg3 + 4) = iVar8;
                }
            }
            fcn.18011f640(CONCAT44(uStack_4c, uVar2) & 0xffffffff00000002);
            *(undefined *)((int64_t)iVar6 + -1 + *(int64_t *)(arg3 + 8)) = 10;
            *(undefined *)((int64_t)iVar6 + *(int64_t *)(arg3 + 8)) = 0;
        }
        piVar11 = (int32_t *)((int64_t)piVar4[-1] + (int64_t)piVar4);
        piVar4 = (int32_t *)0x0;
        if (piVar11 != (int32_t *)(*(int64_t *)(arg1 + 0x2968) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2960))) {
            piVar4 = piVar11;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801388ab
// Address: 0x1801388ab
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_54h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h

void fcn.180138500(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t *piVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    float *pfVar9;
    double dVar10;
    int32_t *piVar11;
    int32_t iVar13;
    uint64_t uVar14;
    uint8_t uVar15;
    char cVar16;
    undefined4 uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_87h;
    int64_t var_68h;
    int64_t var_54h;
    undefined4 uStack_4c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined4 uVar12;
    uint64_t uVar17;
    
    piVar4 = (int32_t *)0x0;
    if (*(int64_t *)(arg1 + 0x2968) != 0) {
        piVar4 = (int32_t *)(*(int64_t *)(arg1 + 0x2968) + 4);
    }
    do {
        if (piVar4 == (int32_t *)0x0) {
            return;
        }
        if (*piVar4 != 0) {
            uVar2 = piVar4[1];
            uVar15 = (uint8_t)uVar2 & 1;
            iVar6 = *(int32_t *)arg3 + -1 + *(int16_t *)(piVar4 + 3) * 0x32;
            if (*(int32_t *)arg3 == 0) {
                iVar6 = *(int16_t *)(piVar4 + 3) * 0x32;
            }
            iVar6 = iVar6 + 0x1e;
            if (*(int32_t *)(arg3 + 4) < iVar6) {
                uVar5 = func_0x00018046d050((int64_t)iVar6);
                if (*(int64_t *)(arg3 + 8) != 0) {
                    func_0x000180498030(uVar5, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
                    func_0x000180460d90(*(undefined8 *)(arg3 + 8));
                }
                *(undefined8 *)(arg3 + 8) = uVar5;
                *(int32_t *)(arg3 + 4) = iVar6;
            }
            uVar14 = (uint64_t)(uVar2 & 8);
            uVar17 = (uint64_t)uVar15;
            func_0x0001800f65a0(arg3, 0x1806459f8, *(undefined8 *)arg2, *piVar4, (int32_t)*(int16_t *)(piVar4 + 3));
            fVar1 = (float)piVar4[2];
            if (fVar1 != 0.0) {
                func_0x0001800f65a0(fVar1, 0x180645a10, (double)fVar1);
            }
            iVar6 = 0;
            pfVar9 = (float *)(piVar4 + 5);
            if (0 < *(int16_t *)(piVar4 + 3)) {
                do {
                    iVar13 = (int32_t)uVar14;
                    cVar16 = (char)uVar17;
                    if (((((pfVar9[1] != 0.0) || (cVar16 != '\0')) || ((uVar2 & 4) != 0)) || ((uVar2 & 2) != 0)) ||
                       ((iVar13 != 0 && (*(int16_t *)(pfVar9 + 3) != -1)))) {
                        uVar18 = func_0x0001800f65a0(arg3, 0x180645a20, iVar6);
                        uVar12 = 0;
                        if (pfVar9[1] != 0.0) {
                            uVar12 = 0;
                            func_0x0001800f65a0(uVar18, 0x180645a30);
                        }
                        if (cVar16 != '\0') {
                            if ((*(uint8_t *)((int64_t)pfVar9 + 0xe) & 0x10) != 0) {
                                dVar10 = (double)*pfVar9;
                                func_0x0001800f65a0(arg3, 0x1806459b8, dVar10);
                                uVar12 = (undefined4)((uint64_t)dVar10 >> 0x20);
                                if ((*(uint8_t *)((int64_t)pfVar9 + 0xe) & 0x10) != 0) goto code_r0x0001801386d0;
                            }
                            func_0x0001800f65a0(arg3, 0x1806459c8, CONCAT44(uVar12, (int32_t)*pfVar9));
                        }
code_r0x0001801386d0:
                        if ((uVar2 & 4) != 0) {
                            func_0x0001800f65a0(arg3, 0x1806459d8, 
                                                (int32_t)(char)(*(char *)((int64_t)pfVar9 + 0xe) << 4) >> 6);
                        }
                        if ((uVar2 & 2) != 0) {
                            func_0x0001800f65a0(arg3, 0x1806459e8, (int32_t)*(int16_t *)((int64_t)pfVar9 + 10));
                        }
                        if ((iVar13 != 0) && (*(int16_t *)(pfVar9 + 3) != -1)) {
                            uVar5 = 0x5e;
                            if ((*(uint8_t *)((int64_t)pfVar9 + 0xe) & 3) == 1) {
                                uVar5 = 0x76;
                            }
                            func_0x0001800f65a0(arg3, 0x180645a40, (int32_t)*(int16_t *)(pfVar9 + 3), uVar5);
                        }
                        iVar13 = 1;
                        if (*(int32_t *)arg3 != 0) {
                            iVar13 = *(int32_t *)arg3;
                        }
                        iVar8 = *(int32_t *)(arg3 + 4);
                        iVar3 = iVar13 + 1;
                        if (iVar8 <= iVar3) {
                            iVar7 = iVar8 * 2;
                            if (iVar8 * 2 < iVar3) {
                                iVar7 = iVar3;
                            }
                            if (iVar8 < iVar7) {
                                uVar5 = func_0x00018046d050((int64_t)iVar7);
                                if (*(int64_t *)(arg3 + 8) != 0) {
                                    func_0x000180498030(uVar5, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
                                    func_0x000180460d90(*(undefined8 *)(arg3 + 8));
                                }
                                *(undefined8 *)(arg3 + 8) = uVar5;
                                *(int32_t *)(arg3 + 4) = iVar7;
                            }
                        }
                        fcn.18011f640(CONCAT44(uStack_4c, uVar2) & 0xffffffff00000002);
                        uVar14 = (uint64_t)(uVar2 & 8);
                        uVar17 = (uint64_t)uVar15;
                        *(undefined *)((int64_t)iVar13 + -1 + *(int64_t *)(arg3 + 8)) = 10;
                        *(undefined *)((int64_t)iVar13 + *(int64_t *)(arg3 + 8)) = 0;
                    }
                    iVar6 = iVar6 + 1;
                    pfVar9 = pfVar9 + 4;
                } while (iVar6 < *(int16_t *)(piVar4 + 3));
            }
            iVar6 = 1;
            if (*(int32_t *)arg3 != 0) {
                iVar6 = *(int32_t *)arg3;
            }
            iVar3 = *(int32_t *)(arg3 + 4);
            iVar13 = iVar6 + 1;
            if (iVar3 <= iVar13) {
                iVar8 = iVar3 * 2;
                if (iVar3 * 2 < iVar13) {
                    iVar8 = iVar13;
                }
                if (iVar3 < iVar8) {
                    uVar5 = func_0x00018046d050((int64_t)iVar8);
                    if (*(int64_t *)(arg3 + 8) != 0) {
                        func_0x000180498030(uVar5, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
                        func_0x000180460d90(*(undefined8 *)(arg3 + 8));
                    }
                    *(undefined8 *)(arg3 + 8) = uVar5;
                    *(int32_t *)(arg3 + 4) = iVar8;
                }
            }
            fcn.18011f640(CONCAT44(uStack_4c, uVar2) & 0xffffffff00000002);
            *(undefined *)((int64_t)iVar6 + -1 + *(int64_t *)(arg3 + 8)) = 10;
            *(undefined *)((int64_t)iVar6 + *(int64_t *)(arg3 + 8)) = 0;
        }
        piVar11 = (int32_t *)((int64_t)piVar4[-1] + (int64_t)piVar4);
        piVar4 = (int32_t *)0x0;
        if (piVar11 != (int32_t *)(*(int64_t *)(arg1 + 0x2968) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2960))) {
            piVar4 = piVar11;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801388c0
// Address: 0x1801388c0
// Size: 429 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801388c0(void)
{
    int32_t *piVar1;
    int16_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t *piVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int32_t *piVar9;
    int32_t iVar10;
    int32_t iVar11;
    int32_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar10 = 0;
    iVar6 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2968);
    piVar5 = (int32_t *)0x0;
    if (iVar6 != 0) {
        piVar5 = (int32_t *)(iVar6 + 4);
    }
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x2960);
    if (piVar5 != (int32_t *)0x0) {
        do {
            if (*piVar5 != 0) {
                iVar10 = iVar10 + 0x14 + *(int16_t *)(piVar5 + 3) * 0x10;
            }
            piVar9 = (int32_t *)((int64_t)piVar5[-1] + (int64_t)piVar5);
            piVar5 = (int32_t *)0x0;
            if (piVar9 != (int32_t *)((int64_t)*piVar1 + 4 + iVar6)) {
                piVar5 = piVar9;
            }
        } while (piVar5 != (int32_t *)0x0);
    }
    if (iVar10 != *piVar1) {
        iVar6 = 0;
        iVar12 = 0;
        if (0 < iVar10) {
            iVar6 = func_0x00018046d050((int64_t)iVar10);
            iVar12 = iVar10;
        }
        piVar5 = (int32_t *)0x0;
        iVar10 = 0;
        if (*(int64_t *)(iVar3 + 0x2968) != 0) {
            piVar5 = (int32_t *)(*(int64_t *)(iVar3 + 0x2968) + 4);
        }
        while (piVar5 != (int32_t *)0x0) {
            iVar7 = iVar6;
            iVar14 = iVar10;
            if (*piVar5 != 0) {
                iVar2 = *(int16_t *)(piVar5 + 3);
                iVar13 = (int32_t)((int64_t)iVar2 * 0x10) + 0x18;
                iVar14 = iVar10 + iVar13;
                if (iVar12 < iVar14) {
                    if (iVar12 == 0) {
                        iVar4 = 8;
                        iVar8 = 0;
                    } else {
                        iVar4 = iVar12 / 2 + iVar12;
                        iVar8 = iVar12;
                    }
                    iVar11 = iVar14;
                    if (iVar14 < iVar4) {
                        iVar11 = iVar4;
                    }
                    if ((iVar8 < iVar11) && (iVar7 = func_0x00018046d050((int64_t)iVar11), iVar12 = iVar11, iVar6 != 0))
                    {
                        func_0x000180498030(iVar7, iVar6, (int64_t)iVar10);
                        func_0x000180460d90(iVar6);
                    }
                }
                *(int32_t *)(iVar10 + iVar7) = iVar13;
                func_0x000180498030((int64_t)iVar10 + 4 + iVar7, piVar5, (int64_t)iVar2 * 0x10 + 0x14);
            }
            piVar9 = (int32_t *)((int64_t)piVar5[-1] + (int64_t)piVar5);
            piVar5 = (int32_t *)0x0;
            iVar6 = iVar7;
            iVar10 = iVar14;
            if (piVar9 != (int32_t *)(*(int64_t *)(iVar3 + 0x2968) + (int64_t)*piVar1 + 4)) {
                piVar5 = piVar9;
            }
        }
        *piVar1 = iVar10;
        *(int32_t *)(iVar3 + 0x2964) = iVar12;
        iVar7 = *(int64_t *)(iVar3 + 0x2968);
        *(int64_t *)(iVar3 + 0x2968) = iVar6;
        if (iVar7 != 0) {
            func_0x000180460d90();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180138a70
// Address: 0x180138a70
// Size: 284 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180138a70(int64_t arg1)
{
    float *pfVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    float fVar11;
    float in_XMM1_Da;
    float fVar12;
    float fVar13;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar5 = *(int64_t *)0x180781f28;
    uVar9 = arg1 & 0xffffffff;
    while( true ) {
        iVar2 = *(int64_t *)(*(int64_t *)(iVar5 + 0x15e0) + 0x208);
        iVar8 = (int32_t)uVar9;
        if (iVar8 < 0) {
            iVar8 = *(int32_t *)(iVar2 + 0xc);
        }
        if (((*(uint32_t *)(iVar2 + 4) & 4) == 0) && (iVar8 < *(int32_t *)(iVar2 + 0x10) + -1)) {
            bVar4 = true;
            iVar6 = iVar8;
            if (iVar8 < 0) {
                iVar6 = *(int32_t *)(iVar2 + 0xc);
            }
            iVar3 = *(int64_t *)(iVar2 + 0x68);
            iVar10 = ((int64_t)iVar6 + 1) * 0x1c;
            iVar7 = (int64_t)iVar6 * 0x1c;
            if (*(char *)(iVar2 + 9) == '\0') {
                fVar11 = *(float *)(iVar10 + iVar3) - *(float *)(iVar7 + iVar3);
            } else {
                fVar11 = *(float *)(iVar10 + 4 + iVar3) - *(float *)(iVar7 + 4 + iVar3);
            }
            fVar13 = *(float *)(iVar2 + 0x18);
            fVar11 = (fVar13 - *(float *)(iVar2 + 0x14)) * fVar11;
        } else {
            fVar13 = *(float *)(iVar2 + 0x18);
            bVar4 = false;
            fVar11 = 0.0;
        }
        pfVar1 = (float *)(iVar5 + 0xe10);
        if (((*(uint32_t *)(iVar2 + 4) & 8) == 0) &&
           (fVar12 = fVar13 - (float)(*(int32_t *)(iVar2 + 0x10) - iVar8) * *pfVar1, fVar12 <= in_XMM1_Da)) {
            in_XMM1_Da = fVar12;
        }
        *(float *)((int64_t)iVar8 * 0x1c + *(int64_t *)(iVar2 + 0x68)) =
             (in_XMM1_Da - *(float *)(iVar2 + 0x14)) / (fVar13 - *(float *)(iVar2 + 0x14));
        if (!bVar4) break;
        fVar13 = *pfVar1;
        uVar9 = (uint64_t)(iVar8 + 1);
        if (fVar13 <= fVar11) {
            fVar13 = fVar11;
        }
        in_XMM1_Da = in_XMM1_Da + fVar13;
    }
    return;
}

// ============================================================
// Function: FUN_180138d00
// Address: 0x180138d00
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach

void fcn.180138d00(void)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    char cVar9;
    undefined uVar10;
    uint32_t uVar11;
    undefined4 uVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    uint64_t arg1;
    float fVar18;
    float fVar19;
    float fVar20;
    char acStackX_8 [8];
    char acStackX_10 [8];
    undefined4 uStackX_18;
    int64_t var_1ch;
    int64_t var_24h;
    int64_t var_d8h;
    int64_t var_c8h;
    float var_c0h;
    int64_t var_bch;
    undefined4 uStack_b4;
    undefined4 uStack_b0;
    float var_ach;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar13 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    iVar17 = *(int32_t *)(iVar3 + 0x248);
    piVar4 = *(int32_t **)(iVar3 + 0x208);
    if (iVar17 < 1) {
        if (*(code **)(iVar13 + 0x2a40) != (code *)0x0) {
            (**(code **)(iVar13 + 0x2a40))(iVar13, *(undefined8 *)(iVar13 + 0x2a48));
        }
    } else {
        uVar12 = *(undefined4 *)(*(int64_t *)(iVar3 + 0x250) + -4 + (int64_t)iVar17 * 4);
        *(int32_t *)(iVar3 + 0x248) = iVar17 + -1;
        *(undefined4 *)(iVar3 + 0x23c) = uVar12;
    }
    if (1 < piVar4[4]) {
        func_0x0001800fc8f0();
        func_0x000180126c00(piVar4 + 0x1c, *(undefined8 *)(iVar3 + 800));
    }
    fVar19 = (float)piVar4[8];
    if ((float)piVar4[8] <= *(float *)(iVar3 + 0x15c)) {
        fVar19 = *(float *)(iVar3 + 0x15c);
    }
    uVar2 = piVar4[1];
    piVar4[8] = (int32_t)fVar19;
    *(float *)(iVar3 + 0x15c) = fVar19;
    if ((uVar2 & 0x10) == 0) {
        *(int32_t *)(iVar3 + 0x170) = piVar4[10];
    }
    uVar10 = 0;
    if (((uVar2 & 1) == 0) && (*(char *)(iVar3 + 0x10e) == '\0')) {
        if (*(float *)(iVar3 + 0x2c4) <= fVar19) {
            fVar19 = *(float *)(iVar3 + 0x2c4);
        }
        uVar16 = 1;
        arg1 = 0xffffffff;
        fVar20 = (float)piVar4[9];
        if ((float)piVar4[9] <= *(float *)(iVar3 + 700)) {
            fVar20 = *(float *)(iVar3 + 700);
        }
        uVar10 = 0;
        if (1 < piVar4[4]) {
            do {
                iVar5 = *(int64_t *)(piVar4 + 0x1a);
                iVar15 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x208);
                if (iVar15 == 0) {
                    fVar18 = 0.0;
                } else {
                    uVar11 = uVar16;
                    if ((int32_t)uVar16 < 0) {
                        uVar11 = *(uint32_t *)(iVar15 + 0xc);
                    }
                    fVar18 = (*(float *)(iVar15 + 0x18) - *(float *)(iVar15 + 0x14)) *
                             *(float *)((int64_t)(int32_t)uVar11 * 0x1c + *(int64_t *)(iVar15 + 0x68)) +
                             *(float *)(iVar15 + 0x14);
                }
                fVar18 = fVar18 + *(float *)(iVar3 + 0x60);
                iVar17 = *piVar4;
                var_c0h = (float)(int32_t)(*(float *)(iVar13 + 0x1308) * 4.0);
                var_c8h._0_4_ = fVar18 - var_c0h;
                var_c0h = var_c0h + fVar18;
                var_c8h._4_4_ = fVar20;
                var_bch._0_4_ = fVar19;
                cVar9 = func_0x00018010b530(&var_c8h, iVar17 + uVar16, 0, 2);
                if (cVar9 != '\0') {
                    acStackX_10[0] = '\0';
                    acStackX_8[0] = '\0';
                    iVar15 = *(int64_t *)0x180781f28;
                    if (((uVar2 & 2) == 0) &&
                       (((func_0x000180139d40(&var_c8h, iVar17 + uVar16, acStackX_10, acStackX_8, 0),
                         iVar15 = *(int64_t *)0x180781f28, acStackX_10[0] != '\0' || (acStackX_8[0] != '\0')) &&
                        (*(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = 4, acStackX_8[0] != '\0')))) {
                        iVar14 = 0x1d;
                        if ((*(uint8_t *)((int64_t)(int32_t)uVar16 * 0x1c + 8 + iVar5) & 2) == 0) {
                            arg1 = (uint64_t)uVar16;
                        }
                    } else {
                        iVar14 = (uint64_t)(acStackX_10[0] != '\0') + 0x1b;
                    }
                    puVar1 = (undefined4 *)(iVar15 + 0xd90 + (iVar14 + 0x14) * 0x10);
                    var_bch._4_4_ = *puVar1;
                    uStack_b4 = puVar1[1];
                    uStack_b0 = puVar1[2];
                    var_ach = (float)puVar1[3] * *(float *)(iVar15 + 0xd9c);
                    uStackX_18 = (float)(int32_t)fVar18;
                    var_1ch._0_4_ = fVar19;
                    var_1ch._4_4_ = uStackX_18;
                    uVar12 = func_0x0001800f5fa0((int64_t)&var_bch + 4);
                    func_0x000180126300(*(undefined8 *)(iVar3 + 800), (int64_t)&var_1ch + 4, &uStackX_18, uVar12, 
                                        0x3f800000);
                }
                uVar16 = uVar16 + 1;
            } while ((int32_t)uVar16 < piVar4[4]);
            if ((int32_t)arg1 == -1) {
                uVar10 = 0;
            } else {
                if ((*(char *)((int64_t)piVar4 + 9) == '\0') && (iVar17 = 0, 0 < piVar4[4] + 1)) {
                    do {
                        iVar13 = (int64_t)iVar17;
                        iVar17 = iVar17 + 1;
                        *(undefined4 *)(iVar13 * 0x1c + 4 + *(int64_t *)(piVar4 + 0x1a)) =
                             *(undefined4 *)(iVar13 * 0x1c + *(int64_t *)(piVar4 + 0x1a));
                    } while (iVar17 < piVar4[4] + 1);
                }
                *(undefined *)((int64_t)piVar4 + 9) = 1;
                uStackX_18 = (float)CONCAT31(uStackX_18._1_3_, 1);
                fcn.180138a70(arg1);
                uVar10 = SUB41(uStackX_18, 0);
            }
        }
    }
    *(undefined *)((int64_t)piVar4 + 9) = uVar10;
    *(undefined4 *)(iVar3 + 0x298) = *(undefined4 *)(iVar3 + 0x2a8);
    *(undefined4 *)(iVar3 + 0x29c) = *(undefined4 *)(iVar3 + 0x2ac);
    *(undefined4 *)(iVar3 + 0x2a0) = *(undefined4 *)(iVar3 + 0x2b0);
    *(undefined4 *)(iVar3 + 0x2a4) = *(undefined4 *)(iVar3 + 0x2b4);
    iVar17 = piVar4[0x13];
    iVar6 = piVar4[0x14];
    iVar7 = piVar4[0x15];
    iVar8 = piVar4[0x16];
    *(undefined8 *)(iVar3 + 0x208) = 0;
    *(int32_t *)(iVar3 + 0x2a8) = iVar17;
    *(int32_t *)(iVar3 + 0x2ac) = iVar6;
    *(int32_t *)(iVar3 + 0x2b0) = iVar7;
    *(int32_t *)(iVar3 + 0x2b4) = iVar8;
    *(undefined4 *)(iVar3 + 0x1a0) = 0;
    iVar13 = *(int64_t *)0x180781f28;
    *(float *)(iVar3 + 0x158) = (float)(int32_t)(*(float *)(iVar3 + 0x19c) + *(float *)(iVar3 + 0x60) + 0.0);
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    if ((*(int64_t *)(iVar13 + 0x24d0) == 0) && (*(int64_t *)(iVar3 + 0x208) == 0)) {
        *(undefined *)(iVar3 + 0x1b8) = 1;
        return;
    }
    *(undefined *)(iVar3 + 0x1b8) = 0;
    return;
}

// ============================================================
// Function: FUN_180138d0a
// Address: 0x180138d0a
// Size: 238 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach

void fcn.180138d00(void)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    char cVar9;
    undefined uVar10;
    uint32_t uVar11;
    undefined4 uVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    uint64_t arg1;
    float fVar18;
    float fVar19;
    float fVar20;
    char acStackX_8 [8];
    char acStackX_10 [8];
    undefined4 uStackX_18;
    int64_t var_1ch;
    int64_t var_24h;
    int64_t var_d8h;
    int64_t var_c8h;
    float var_c0h;
    int64_t var_bch;
    undefined4 uStack_b4;
    undefined4 uStack_b0;
    float var_ach;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar13 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    iVar17 = *(int32_t *)(iVar3 + 0x248);
    piVar4 = *(int32_t **)(iVar3 + 0x208);
    if (iVar17 < 1) {
        if (*(code **)(iVar13 + 0x2a40) != (code *)0x0) {
            (**(code **)(iVar13 + 0x2a40))(iVar13, *(undefined8 *)(iVar13 + 0x2a48));
        }
    } else {
        uVar12 = *(undefined4 *)(*(int64_t *)(iVar3 + 0x250) + -4 + (int64_t)iVar17 * 4);
        *(int32_t *)(iVar3 + 0x248) = iVar17 + -1;
        *(undefined4 *)(iVar3 + 0x23c) = uVar12;
    }
    if (1 < piVar4[4]) {
        func_0x0001800fc8f0();
        func_0x000180126c00(piVar4 + 0x1c, *(undefined8 *)(iVar3 + 800));
    }
    fVar19 = (float)piVar4[8];
    if ((float)piVar4[8] <= *(float *)(iVar3 + 0x15c)) {
        fVar19 = *(float *)(iVar3 + 0x15c);
    }
    uVar2 = piVar4[1];
    piVar4[8] = (int32_t)fVar19;
    *(float *)(iVar3 + 0x15c) = fVar19;
    if ((uVar2 & 0x10) == 0) {
        *(int32_t *)(iVar3 + 0x170) = piVar4[10];
    }
    uVar10 = 0;
    if (((uVar2 & 1) == 0) && (*(char *)(iVar3 + 0x10e) == '\0')) {
        if (*(float *)(iVar3 + 0x2c4) <= fVar19) {
            fVar19 = *(float *)(iVar3 + 0x2c4);
        }
        uVar16 = 1;
        arg1 = 0xffffffff;
        fVar20 = (float)piVar4[9];
        if ((float)piVar4[9] <= *(float *)(iVar3 + 700)) {
            fVar20 = *(float *)(iVar3 + 700);
        }
        uVar10 = 0;
        if (1 < piVar4[4]) {
            do {
                iVar5 = *(int64_t *)(piVar4 + 0x1a);
                iVar15 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x208);
                if (iVar15 == 0) {
                    fVar18 = 0.0;
                } else {
                    uVar11 = uVar16;
                    if ((int32_t)uVar16 < 0) {
                        uVar11 = *(uint32_t *)(iVar15 + 0xc);
                    }
                    fVar18 = (*(float *)(iVar15 + 0x18) - *(float *)(iVar15 + 0x14)) *
                             *(float *)((int64_t)(int32_t)uVar11 * 0x1c + *(int64_t *)(iVar15 + 0x68)) +
                             *(float *)(iVar15 + 0x14);
                }
                fVar18 = fVar18 + *(float *)(iVar3 + 0x60);
                iVar17 = *piVar4;
                var_c0h = (float)(int32_t)(*(float *)(iVar13 + 0x1308) * 4.0);
                var_c8h._0_4_ = fVar18 - var_c0h;
                var_c0h = var_c0h + fVar18;
                var_c8h._4_4_ = fVar20;
                var_bch._0_4_ = fVar19;
                cVar9 = func_0x00018010b530(&var_c8h, iVar17 + uVar16, 0, 2);
                if (cVar9 != '\0') {
                    acStackX_10[0] = '\0';
                    acStackX_8[0] = '\0';
                    iVar15 = *(int64_t *)0x180781f28;
                    if (((uVar2 & 2) == 0) &&
                       (((func_0x000180139d40(&var_c8h, iVar17 + uVar16, acStackX_10, acStackX_8, 0),
                         iVar15 = *(int64_t *)0x180781f28, acStackX_10[0] != '\0' || (acStackX_8[0] != '\0')) &&
                        (*(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = 4, acStackX_8[0] != '\0')))) {
                        iVar14 = 0x1d;
                        if ((*(uint8_t *)((int64_t)(int32_t)uVar16 * 0x1c + 8 + iVar5) & 2) == 0) {
                            arg1 = (uint64_t)uVar16;
                        }
                    } else {
                        iVar14 = (uint64_t)(acStackX_10[0] != '\0') + 0x1b;
                    }
                    puVar1 = (undefined4 *)(iVar15 + 0xd90 + (iVar14 + 0x14) * 0x10);
                    var_bch._4_4_ = *puVar1;
                    uStack_b4 = puVar1[1];
                    uStack_b0 = puVar1[2];
                    var_ach = (float)puVar1[3] * *(float *)(iVar15 + 0xd9c);
                    uStackX_18 = (float)(int32_t)fVar18;
                    var_1ch._0_4_ = fVar19;
                    var_1ch._4_4_ = uStackX_18;
                    uVar12 = func_0x0001800f5fa0((int64_t)&var_bch + 4);
                    func_0x000180126300(*(undefined8 *)(iVar3 + 800), (int64_t)&var_1ch + 4, &uStackX_18, uVar12, 
                                        0x3f800000);
                }
                uVar16 = uVar16 + 1;
            } while ((int32_t)uVar16 < piVar4[4]);
            if ((int32_t)arg1 == -1) {
                uVar10 = 0;
            } else {
                if ((*(char *)((int64_t)piVar4 + 9) == '\0') && (iVar17 = 0, 0 < piVar4[4] + 1)) {
                    do {
                        iVar13 = (int64_t)iVar17;
                        iVar17 = iVar17 + 1;
                        *(undefined4 *)(iVar13 * 0x1c + 4 + *(int64_t *)(piVar4 + 0x1a)) =
                             *(undefined4 *)(iVar13 * 0x1c + *(int64_t *)(piVar4 + 0x1a));
                    } while (iVar17 < piVar4[4] + 1);
                }
                *(undefined *)((int64_t)piVar4 + 9) = 1;
                uStackX_18 = (float)CONCAT31(uStackX_18._1_3_, 1);
                fcn.180138a70(arg1);
                uVar10 = SUB41(uStackX_18, 0);
            }
        }
    }
    *(undefined *)((int64_t)piVar4 + 9) = uVar10;
    *(undefined4 *)(iVar3 + 0x298) = *(undefined4 *)(iVar3 + 0x2a8);
    *(undefined4 *)(iVar3 + 0x29c) = *(undefined4 *)(iVar3 + 0x2ac);
    *(undefined4 *)(iVar3 + 0x2a0) = *(undefined4 *)(iVar3 + 0x2b0);
    *(undefined4 *)(iVar3 + 0x2a4) = *(undefined4 *)(iVar3 + 0x2b4);
    iVar17 = piVar4[0x13];
    iVar6 = piVar4[0x14];
    iVar7 = piVar4[0x15];
    iVar8 = piVar4[0x16];
    *(undefined8 *)(iVar3 + 0x208) = 0;
    *(int32_t *)(iVar3 + 0x2a8) = iVar17;
    *(int32_t *)(iVar3 + 0x2ac) = iVar6;
    *(int32_t *)(iVar3 + 0x2b0) = iVar7;
    *(int32_t *)(iVar3 + 0x2b4) = iVar8;
    *(undefined4 *)(iVar3 + 0x1a0) = 0;
    iVar13 = *(int64_t *)0x180781f28;
    *(float *)(iVar3 + 0x158) = (float)(int32_t)(*(float *)(iVar3 + 0x19c) + *(float *)(iVar3 + 0x60) + 0.0);
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    if ((*(int64_t *)(iVar13 + 0x24d0) == 0) && (*(int64_t *)(iVar3 + 0x208) == 0)) {
        *(undefined *)(iVar3 + 0x1b8) = 1;
        return;
    }
    *(undefined *)(iVar3 + 0x1b8) = 0;
    return;
}

// ============================================================
// Function: FUN_180138df8
// Address: 0x180138df8
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach

void fcn.180138d00(void)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    char cVar9;
    undefined uVar10;
    uint32_t uVar11;
    undefined4 uVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    uint64_t arg1;
    float fVar18;
    float fVar19;
    float fVar20;
    char acStackX_8 [8];
    char acStackX_10 [8];
    undefined4 uStackX_18;
    int64_t var_1ch;
    int64_t var_24h;
    int64_t var_d8h;
    int64_t var_c8h;
    float var_c0h;
    int64_t var_bch;
    undefined4 uStack_b4;
    undefined4 uStack_b0;
    float var_ach;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar13 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    iVar17 = *(int32_t *)(iVar3 + 0x248);
    piVar4 = *(int32_t **)(iVar3 + 0x208);
    if (iVar17 < 1) {
        if (*(code **)(iVar13 + 0x2a40) != (code *)0x0) {
            (**(code **)(iVar13 + 0x2a40))(iVar13, *(undefined8 *)(iVar13 + 0x2a48));
        }
    } else {
        uVar12 = *(undefined4 *)(*(int64_t *)(iVar3 + 0x250) + -4 + (int64_t)iVar17 * 4);
        *(int32_t *)(iVar3 + 0x248) = iVar17 + -1;
        *(undefined4 *)(iVar3 + 0x23c) = uVar12;
    }
    if (1 < piVar4[4]) {
        func_0x0001800fc8f0();
        func_0x000180126c00(piVar4 + 0x1c, *(undefined8 *)(iVar3 + 800));
    }
    fVar19 = (float)piVar4[8];
    if ((float)piVar4[8] <= *(float *)(iVar3 + 0x15c)) {
        fVar19 = *(float *)(iVar3 + 0x15c);
    }
    uVar2 = piVar4[1];
    piVar4[8] = (int32_t)fVar19;
    *(float *)(iVar3 + 0x15c) = fVar19;
    if ((uVar2 & 0x10) == 0) {
        *(int32_t *)(iVar3 + 0x170) = piVar4[10];
    }
    uVar10 = 0;
    if (((uVar2 & 1) == 0) && (*(char *)(iVar3 + 0x10e) == '\0')) {
        if (*(float *)(iVar3 + 0x2c4) <= fVar19) {
            fVar19 = *(float *)(iVar3 + 0x2c4);
        }
        uVar16 = 1;
        arg1 = 0xffffffff;
        fVar20 = (float)piVar4[9];
        if ((float)piVar4[9] <= *(float *)(iVar3 + 700)) {
            fVar20 = *(float *)(iVar3 + 700);
        }
        uVar10 = 0;
        if (1 < piVar4[4]) {
            do {
                iVar5 = *(int64_t *)(piVar4 + 0x1a);
                iVar15 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x208);
                if (iVar15 == 0) {
                    fVar18 = 0.0;
                } else {
                    uVar11 = uVar16;
                    if ((int32_t)uVar16 < 0) {
                        uVar11 = *(uint32_t *)(iVar15 + 0xc);
                    }
                    fVar18 = (*(float *)(iVar15 + 0x18) - *(float *)(iVar15 + 0x14)) *
                             *(float *)((int64_t)(int32_t)uVar11 * 0x1c + *(int64_t *)(iVar15 + 0x68)) +
                             *(float *)(iVar15 + 0x14);
                }
                fVar18 = fVar18 + *(float *)(iVar3 + 0x60);
                iVar17 = *piVar4;
                var_c0h = (float)(int32_t)(*(float *)(iVar13 + 0x1308) * 4.0);
                var_c8h._0_4_ = fVar18 - var_c0h;
                var_c0h = var_c0h + fVar18;
                var_c8h._4_4_ = fVar20;
                var_bch._0_4_ = fVar19;
                cVar9 = func_0x00018010b530(&var_c8h, iVar17 + uVar16, 0, 2);
                if (cVar9 != '\0') {
                    acStackX_10[0] = '\0';
                    acStackX_8[0] = '\0';
                    iVar15 = *(int64_t *)0x180781f28;
                    if (((uVar2 & 2) == 0) &&
                       (((func_0x000180139d40(&var_c8h, iVar17 + uVar16, acStackX_10, acStackX_8, 0),
                         iVar15 = *(int64_t *)0x180781f28, acStackX_10[0] != '\0' || (acStackX_8[0] != '\0')) &&
                        (*(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = 4, acStackX_8[0] != '\0')))) {
                        iVar14 = 0x1d;
                        if ((*(uint8_t *)((int64_t)(int32_t)uVar16 * 0x1c + 8 + iVar5) & 2) == 0) {
                            arg1 = (uint64_t)uVar16;
                        }
                    } else {
                        iVar14 = (uint64_t)(acStackX_10[0] != '\0') + 0x1b;
                    }
                    puVar1 = (undefined4 *)(iVar15 + 0xd90 + (iVar14 + 0x14) * 0x10);
                    var_bch._4_4_ = *puVar1;
                    uStack_b4 = puVar1[1];
                    uStack_b0 = puVar1[2];
                    var_ach = (float)puVar1[3] * *(float *)(iVar15 + 0xd9c);
                    uStackX_18 = (float)(int32_t)fVar18;
                    var_1ch._0_4_ = fVar19;
                    var_1ch._4_4_ = uStackX_18;
                    uVar12 = func_0x0001800f5fa0((int64_t)&var_bch + 4);
                    func_0x000180126300(*(undefined8 *)(iVar3 + 800), (int64_t)&var_1ch + 4, &uStackX_18, uVar12, 
                                        0x3f800000);
                }
                uVar16 = uVar16 + 1;
            } while ((int32_t)uVar16 < piVar4[4]);
            if ((int32_t)arg1 == -1) {
                uVar10 = 0;
            } else {
                if ((*(char *)((int64_t)piVar4 + 9) == '\0') && (iVar17 = 0, 0 < piVar4[4] + 1)) {
                    do {
                        iVar13 = (int64_t)iVar17;
                        iVar17 = iVar17 + 1;
                        *(undefined4 *)(iVar13 * 0x1c + 4 + *(int64_t *)(piVar4 + 0x1a)) =
                             *(undefined4 *)(iVar13 * 0x1c + *(int64_t *)(piVar4 + 0x1a));
                    } while (iVar17 < piVar4[4] + 1);
                }
                *(undefined *)((int64_t)piVar4 + 9) = 1;
                uStackX_18 = (float)CONCAT31(uStackX_18._1_3_, 1);
                fcn.180138a70(arg1);
                uVar10 = SUB41(uStackX_18, 0);
            }
        }
    }
    *(undefined *)((int64_t)piVar4 + 9) = uVar10;
    *(undefined4 *)(iVar3 + 0x298) = *(undefined4 *)(iVar3 + 0x2a8);
    *(undefined4 *)(iVar3 + 0x29c) = *(undefined4 *)(iVar3 + 0x2ac);
    *(undefined4 *)(iVar3 + 0x2a0) = *(undefined4 *)(iVar3 + 0x2b0);
    *(undefined4 *)(iVar3 + 0x2a4) = *(undefined4 *)(iVar3 + 0x2b4);
    iVar17 = piVar4[0x13];
    iVar6 = piVar4[0x14];
    iVar7 = piVar4[0x15];
    iVar8 = piVar4[0x16];
    *(undefined8 *)(iVar3 + 0x208) = 0;
    *(int32_t *)(iVar3 + 0x2a8) = iVar17;
    *(int32_t *)(iVar3 + 0x2ac) = iVar6;
    *(int32_t *)(iVar3 + 0x2b0) = iVar7;
    *(int32_t *)(iVar3 + 0x2b4) = iVar8;
    *(undefined4 *)(iVar3 + 0x1a0) = 0;
    iVar13 = *(int64_t *)0x180781f28;
    *(float *)(iVar3 + 0x158) = (float)(int32_t)(*(float *)(iVar3 + 0x19c) + *(float *)(iVar3 + 0x60) + 0.0);
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    if ((*(int64_t *)(iVar13 + 0x24d0) == 0) && (*(int64_t *)(iVar3 + 0x208) == 0)) {
        *(undefined *)(iVar3 + 0x1b8) = 1;
        return;
    }
    *(undefined *)(iVar3 + 0x1b8) = 0;
    return;
}

// ============================================================
// Function: FUN_180138e31
// Address: 0x180138e31
// Size: 592 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach

void fcn.180138d00(void)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    char cVar9;
    undefined uVar10;
    uint32_t uVar11;
    undefined4 uVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    uint64_t arg1;
    float fVar18;
    float fVar19;
    float fVar20;
    char acStackX_8 [8];
    char acStackX_10 [8];
    undefined4 uStackX_18;
    int64_t var_1ch;
    int64_t var_24h;
    int64_t var_d8h;
    int64_t var_c8h;
    float var_c0h;
    int64_t var_bch;
    undefined4 uStack_b4;
    undefined4 uStack_b0;
    float var_ach;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar13 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    iVar17 = *(int32_t *)(iVar3 + 0x248);
    piVar4 = *(int32_t **)(iVar3 + 0x208);
    if (iVar17 < 1) {
        if (*(code **)(iVar13 + 0x2a40) != (code *)0x0) {
            (**(code **)(iVar13 + 0x2a40))(iVar13, *(undefined8 *)(iVar13 + 0x2a48));
        }
    } else {
        uVar12 = *(undefined4 *)(*(int64_t *)(iVar3 + 0x250) + -4 + (int64_t)iVar17 * 4);
        *(int32_t *)(iVar3 + 0x248) = iVar17 + -1;
        *(undefined4 *)(iVar3 + 0x23c) = uVar12;
    }
    if (1 < piVar4[4]) {
        func_0x0001800fc8f0();
        func_0x000180126c00(piVar4 + 0x1c, *(undefined8 *)(iVar3 + 800));
    }
    fVar19 = (float)piVar4[8];
    if ((float)piVar4[8] <= *(float *)(iVar3 + 0x15c)) {
        fVar19 = *(float *)(iVar3 + 0x15c);
    }
    uVar2 = piVar4[1];
    piVar4[8] = (int32_t)fVar19;
    *(float *)(iVar3 + 0x15c) = fVar19;
    if ((uVar2 & 0x10) == 0) {
        *(int32_t *)(iVar3 + 0x170) = piVar4[10];
    }
    uVar10 = 0;
    if (((uVar2 & 1) == 0) && (*(char *)(iVar3 + 0x10e) == '\0')) {
        if (*(float *)(iVar3 + 0x2c4) <= fVar19) {
            fVar19 = *(float *)(iVar3 + 0x2c4);
        }
        uVar16 = 1;
        arg1 = 0xffffffff;
        fVar20 = (float)piVar4[9];
        if ((float)piVar4[9] <= *(float *)(iVar3 + 700)) {
            fVar20 = *(float *)(iVar3 + 700);
        }
        uVar10 = 0;
        if (1 < piVar4[4]) {
            do {
                iVar5 = *(int64_t *)(piVar4 + 0x1a);
                iVar15 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x208);
                if (iVar15 == 0) {
                    fVar18 = 0.0;
                } else {
                    uVar11 = uVar16;
                    if ((int32_t)uVar16 < 0) {
                        uVar11 = *(uint32_t *)(iVar15 + 0xc);
                    }
                    fVar18 = (*(float *)(iVar15 + 0x18) - *(float *)(iVar15 + 0x14)) *
                             *(float *)((int64_t)(int32_t)uVar11 * 0x1c + *(int64_t *)(iVar15 + 0x68)) +
                             *(float *)(iVar15 + 0x14);
                }
                fVar18 = fVar18 + *(float *)(iVar3 + 0x60);
                iVar17 = *piVar4;
                var_c0h = (float)(int32_t)(*(float *)(iVar13 + 0x1308) * 4.0);
                var_c8h._0_4_ = fVar18 - var_c0h;
                var_c0h = var_c0h + fVar18;
                var_c8h._4_4_ = fVar20;
                var_bch._0_4_ = fVar19;
                cVar9 = func_0x00018010b530(&var_c8h, iVar17 + uVar16, 0, 2);
                if (cVar9 != '\0') {
                    acStackX_10[0] = '\0';
                    acStackX_8[0] = '\0';
                    iVar15 = *(int64_t *)0x180781f28;
                    if (((uVar2 & 2) == 0) &&
                       (((func_0x000180139d40(&var_c8h, iVar17 + uVar16, acStackX_10, acStackX_8, 0),
                         iVar15 = *(int64_t *)0x180781f28, acStackX_10[0] != '\0' || (acStackX_8[0] != '\0')) &&
                        (*(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = 4, acStackX_8[0] != '\0')))) {
                        iVar14 = 0x1d;
                        if ((*(uint8_t *)((int64_t)(int32_t)uVar16 * 0x1c + 8 + iVar5) & 2) == 0) {
                            arg1 = (uint64_t)uVar16;
                        }
                    } else {
                        iVar14 = (uint64_t)(acStackX_10[0] != '\0') + 0x1b;
                    }
                    puVar1 = (undefined4 *)(iVar15 + 0xd90 + (iVar14 + 0x14) * 0x10);
                    var_bch._4_4_ = *puVar1;
                    uStack_b4 = puVar1[1];
                    uStack_b0 = puVar1[2];
                    var_ach = (float)puVar1[3] * *(float *)(iVar15 + 0xd9c);
                    uStackX_18 = (float)(int32_t)fVar18;
                    var_1ch._0_4_ = fVar19;
                    var_1ch._4_4_ = uStackX_18;
                    uVar12 = func_0x0001800f5fa0((int64_t)&var_bch + 4);
                    func_0x000180126300(*(undefined8 *)(iVar3 + 800), (int64_t)&var_1ch + 4, &uStackX_18, uVar12, 
                                        0x3f800000);
                }
                uVar16 = uVar16 + 1;
            } while ((int32_t)uVar16 < piVar4[4]);
            if ((int32_t)arg1 == -1) {
                uVar10 = 0;
            } else {
                if ((*(char *)((int64_t)piVar4 + 9) == '\0') && (iVar17 = 0, 0 < piVar4[4] + 1)) {
                    do {
                        iVar13 = (int64_t)iVar17;
                        iVar17 = iVar17 + 1;
                        *(undefined4 *)(iVar13 * 0x1c + 4 + *(int64_t *)(piVar4 + 0x1a)) =
                             *(undefined4 *)(iVar13 * 0x1c + *(int64_t *)(piVar4 + 0x1a));
                    } while (iVar17 < piVar4[4] + 1);
                }
                *(undefined *)((int64_t)piVar4 + 9) = 1;
                uStackX_18 = (float)CONCAT31(uStackX_18._1_3_, 1);
                fcn.180138a70(arg1);
                uVar10 = SUB41(uStackX_18, 0);
            }
        }
    }
    *(undefined *)((int64_t)piVar4 + 9) = uVar10;
    *(undefined4 *)(iVar3 + 0x298) = *(undefined4 *)(iVar3 + 0x2a8);
    *(undefined4 *)(iVar3 + 0x29c) = *(undefined4 *)(iVar3 + 0x2ac);
    *(undefined4 *)(iVar3 + 0x2a0) = *(undefined4 *)(iVar3 + 0x2b0);
    *(undefined4 *)(iVar3 + 0x2a4) = *(undefined4 *)(iVar3 + 0x2b4);
    iVar17 = piVar4[0x13];
    iVar6 = piVar4[0x14];
    iVar7 = piVar4[0x15];
    iVar8 = piVar4[0x16];
    *(undefined8 *)(iVar3 + 0x208) = 0;
    *(int32_t *)(iVar3 + 0x2a8) = iVar17;
    *(int32_t *)(iVar3 + 0x2ac) = iVar6;
    *(int32_t *)(iVar3 + 0x2b0) = iVar7;
    *(int32_t *)(iVar3 + 0x2b4) = iVar8;
    *(undefined4 *)(iVar3 + 0x1a0) = 0;
    iVar13 = *(int64_t *)0x180781f28;
    *(float *)(iVar3 + 0x158) = (float)(int32_t)(*(float *)(iVar3 + 0x19c) + *(float *)(iVar3 + 0x60) + 0.0);
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    if ((*(int64_t *)(iVar13 + 0x24d0) == 0) && (*(int64_t *)(iVar3 + 0x208) == 0)) {
        *(undefined *)(iVar3 + 0x1b8) = 1;
        return;
    }
    *(undefined *)(iVar3 + 0x1b8) = 0;
    return;
}

// ============================================================
// Function: FUN_180139081
// Address: 0x180139081
// Size: 295 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach

void fcn.180138d00(void)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    char cVar9;
    undefined uVar10;
    uint32_t uVar11;
    undefined4 uVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    uint64_t arg1;
    float fVar18;
    float fVar19;
    float fVar20;
    char acStackX_8 [8];
    char acStackX_10 [8];
    undefined4 uStackX_18;
    int64_t var_1ch;
    int64_t var_24h;
    int64_t var_d8h;
    int64_t var_c8h;
    float var_c0h;
    int64_t var_bch;
    undefined4 uStack_b4;
    undefined4 uStack_b0;
    float var_ach;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar13 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    iVar17 = *(int32_t *)(iVar3 + 0x248);
    piVar4 = *(int32_t **)(iVar3 + 0x208);
    if (iVar17 < 1) {
        if (*(code **)(iVar13 + 0x2a40) != (code *)0x0) {
            (**(code **)(iVar13 + 0x2a40))(iVar13, *(undefined8 *)(iVar13 + 0x2a48));
        }
    } else {
        uVar12 = *(undefined4 *)(*(int64_t *)(iVar3 + 0x250) + -4 + (int64_t)iVar17 * 4);
        *(int32_t *)(iVar3 + 0x248) = iVar17 + -1;
        *(undefined4 *)(iVar3 + 0x23c) = uVar12;
    }
    if (1 < piVar4[4]) {
        func_0x0001800fc8f0();
        func_0x000180126c00(piVar4 + 0x1c, *(undefined8 *)(iVar3 + 800));
    }
    fVar19 = (float)piVar4[8];
    if ((float)piVar4[8] <= *(float *)(iVar3 + 0x15c)) {
        fVar19 = *(float *)(iVar3 + 0x15c);
    }
    uVar2 = piVar4[1];
    piVar4[8] = (int32_t)fVar19;
    *(float *)(iVar3 + 0x15c) = fVar19;
    if ((uVar2 & 0x10) == 0) {
        *(int32_t *)(iVar3 + 0x170) = piVar4[10];
    }
    uVar10 = 0;
    if (((uVar2 & 1) == 0) && (*(char *)(iVar3 + 0x10e) == '\0')) {
        if (*(float *)(iVar3 + 0x2c4) <= fVar19) {
            fVar19 = *(float *)(iVar3 + 0x2c4);
        }
        uVar16 = 1;
        arg1 = 0xffffffff;
        fVar20 = (float)piVar4[9];
        if ((float)piVar4[9] <= *(float *)(iVar3 + 700)) {
            fVar20 = *(float *)(iVar3 + 700);
        }
        uVar10 = 0;
        if (1 < piVar4[4]) {
            do {
                iVar5 = *(int64_t *)(piVar4 + 0x1a);
                iVar15 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x208);
                if (iVar15 == 0) {
                    fVar18 = 0.0;
                } else {
                    uVar11 = uVar16;
                    if ((int32_t)uVar16 < 0) {
                        uVar11 = *(uint32_t *)(iVar15 + 0xc);
                    }
                    fVar18 = (*(float *)(iVar15 + 0x18) - *(float *)(iVar15 + 0x14)) *
                             *(float *)((int64_t)(int32_t)uVar11 * 0x1c + *(int64_t *)(iVar15 + 0x68)) +
                             *(float *)(iVar15 + 0x14);
                }
                fVar18 = fVar18 + *(float *)(iVar3 + 0x60);
                iVar17 = *piVar4;
                var_c0h = (float)(int32_t)(*(float *)(iVar13 + 0x1308) * 4.0);
                var_c8h._0_4_ = fVar18 - var_c0h;
                var_c0h = var_c0h + fVar18;
                var_c8h._4_4_ = fVar20;
                var_bch._0_4_ = fVar19;
                cVar9 = func_0x00018010b530(&var_c8h, iVar17 + uVar16, 0, 2);
                if (cVar9 != '\0') {
                    acStackX_10[0] = '\0';
                    acStackX_8[0] = '\0';
                    iVar15 = *(int64_t *)0x180781f28;
                    if (((uVar2 & 2) == 0) &&
                       (((func_0x000180139d40(&var_c8h, iVar17 + uVar16, acStackX_10, acStackX_8, 0),
                         iVar15 = *(int64_t *)0x180781f28, acStackX_10[0] != '\0' || (acStackX_8[0] != '\0')) &&
                        (*(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = 4, acStackX_8[0] != '\0')))) {
                        iVar14 = 0x1d;
                        if ((*(uint8_t *)((int64_t)(int32_t)uVar16 * 0x1c + 8 + iVar5) & 2) == 0) {
                            arg1 = (uint64_t)uVar16;
                        }
                    } else {
                        iVar14 = (uint64_t)(acStackX_10[0] != '\0') + 0x1b;
                    }
                    puVar1 = (undefined4 *)(iVar15 + 0xd90 + (iVar14 + 0x14) * 0x10);
                    var_bch._4_4_ = *puVar1;
                    uStack_b4 = puVar1[1];
                    uStack_b0 = puVar1[2];
                    var_ach = (float)puVar1[3] * *(float *)(iVar15 + 0xd9c);
                    uStackX_18 = (float)(int32_t)fVar18;
                    var_1ch._0_4_ = fVar19;
                    var_1ch._4_4_ = uStackX_18;
                    uVar12 = func_0x0001800f5fa0((int64_t)&var_bch + 4);
                    func_0x000180126300(*(undefined8 *)(iVar3 + 800), (int64_t)&var_1ch + 4, &uStackX_18, uVar12, 
                                        0x3f800000);
                }
                uVar16 = uVar16 + 1;
            } while ((int32_t)uVar16 < piVar4[4]);
            if ((int32_t)arg1 == -1) {
                uVar10 = 0;
            } else {
                if ((*(char *)((int64_t)piVar4 + 9) == '\0') && (iVar17 = 0, 0 < piVar4[4] + 1)) {
                    do {
                        iVar13 = (int64_t)iVar17;
                        iVar17 = iVar17 + 1;
                        *(undefined4 *)(iVar13 * 0x1c + 4 + *(int64_t *)(piVar4 + 0x1a)) =
                             *(undefined4 *)(iVar13 * 0x1c + *(int64_t *)(piVar4 + 0x1a));
                    } while (iVar17 < piVar4[4] + 1);
                }
                *(undefined *)((int64_t)piVar4 + 9) = 1;
                uStackX_18 = (float)CONCAT31(uStackX_18._1_3_, 1);
                fcn.180138a70(arg1);
                uVar10 = SUB41(uStackX_18, 0);
            }
        }
    }
    *(undefined *)((int64_t)piVar4 + 9) = uVar10;
    *(undefined4 *)(iVar3 + 0x298) = *(undefined4 *)(iVar3 + 0x2a8);
    *(undefined4 *)(iVar3 + 0x29c) = *(undefined4 *)(iVar3 + 0x2ac);
    *(undefined4 *)(iVar3 + 0x2a0) = *(undefined4 *)(iVar3 + 0x2b0);
    *(undefined4 *)(iVar3 + 0x2a4) = *(undefined4 *)(iVar3 + 0x2b4);
    iVar17 = piVar4[0x13];
    iVar6 = piVar4[0x14];
    iVar7 = piVar4[0x15];
    iVar8 = piVar4[0x16];
    *(undefined8 *)(iVar3 + 0x208) = 0;
    *(int32_t *)(iVar3 + 0x2a8) = iVar17;
    *(int32_t *)(iVar3 + 0x2ac) = iVar6;
    *(int32_t *)(iVar3 + 0x2b0) = iVar7;
    *(int32_t *)(iVar3 + 0x2b4) = iVar8;
    *(undefined4 *)(iVar3 + 0x1a0) = 0;
    iVar13 = *(int64_t *)0x180781f28;
    *(float *)(iVar3 + 0x158) = (float)(int32_t)(*(float *)(iVar3 + 0x19c) + *(float *)(iVar3 + 0x60) + 0.0);
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    if ((*(int64_t *)(iVar13 + 0x24d0) == 0) && (*(int64_t *)(iVar3 + 0x208) == 0)) {
        *(undefined *)(iVar3 + 0x1b8) = 1;
        return;
    }
    *(undefined *)(iVar3 + 0x1b8) = 0;
    return;
}

// ============================================================
// Function: FUN_1801391a8
// Address: 0x1801391a8
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach

void fcn.180138d00(void)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    char cVar9;
    undefined uVar10;
    uint32_t uVar11;
    undefined4 uVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    uint64_t arg1;
    float fVar18;
    float fVar19;
    float fVar20;
    char acStackX_8 [8];
    char acStackX_10 [8];
    undefined4 uStackX_18;
    int64_t var_1ch;
    int64_t var_24h;
    int64_t var_d8h;
    int64_t var_c8h;
    float var_c0h;
    int64_t var_bch;
    undefined4 uStack_b4;
    undefined4 uStack_b0;
    float var_ach;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar13 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    iVar17 = *(int32_t *)(iVar3 + 0x248);
    piVar4 = *(int32_t **)(iVar3 + 0x208);
    if (iVar17 < 1) {
        if (*(code **)(iVar13 + 0x2a40) != (code *)0x0) {
            (**(code **)(iVar13 + 0x2a40))(iVar13, *(undefined8 *)(iVar13 + 0x2a48));
        }
    } else {
        uVar12 = *(undefined4 *)(*(int64_t *)(iVar3 + 0x250) + -4 + (int64_t)iVar17 * 4);
        *(int32_t *)(iVar3 + 0x248) = iVar17 + -1;
        *(undefined4 *)(iVar3 + 0x23c) = uVar12;
    }
    if (1 < piVar4[4]) {
        func_0x0001800fc8f0();
        func_0x000180126c00(piVar4 + 0x1c, *(undefined8 *)(iVar3 + 800));
    }
    fVar19 = (float)piVar4[8];
    if ((float)piVar4[8] <= *(float *)(iVar3 + 0x15c)) {
        fVar19 = *(float *)(iVar3 + 0x15c);
    }
    uVar2 = piVar4[1];
    piVar4[8] = (int32_t)fVar19;
    *(float *)(iVar3 + 0x15c) = fVar19;
    if ((uVar2 & 0x10) == 0) {
        *(int32_t *)(iVar3 + 0x170) = piVar4[10];
    }
    uVar10 = 0;
    if (((uVar2 & 1) == 0) && (*(char *)(iVar3 + 0x10e) == '\0')) {
        if (*(float *)(iVar3 + 0x2c4) <= fVar19) {
            fVar19 = *(float *)(iVar3 + 0x2c4);
        }
        uVar16 = 1;
        arg1 = 0xffffffff;
        fVar20 = (float)piVar4[9];
        if ((float)piVar4[9] <= *(float *)(iVar3 + 700)) {
            fVar20 = *(float *)(iVar3 + 700);
        }
        uVar10 = 0;
        if (1 < piVar4[4]) {
            do {
                iVar5 = *(int64_t *)(piVar4 + 0x1a);
                iVar15 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x208);
                if (iVar15 == 0) {
                    fVar18 = 0.0;
                } else {
                    uVar11 = uVar16;
                    if ((int32_t)uVar16 < 0) {
                        uVar11 = *(uint32_t *)(iVar15 + 0xc);
                    }
                    fVar18 = (*(float *)(iVar15 + 0x18) - *(float *)(iVar15 + 0x14)) *
                             *(float *)((int64_t)(int32_t)uVar11 * 0x1c + *(int64_t *)(iVar15 + 0x68)) +
                             *(float *)(iVar15 + 0x14);
                }
                fVar18 = fVar18 + *(float *)(iVar3 + 0x60);
                iVar17 = *piVar4;
                var_c0h = (float)(int32_t)(*(float *)(iVar13 + 0x1308) * 4.0);
                var_c8h._0_4_ = fVar18 - var_c0h;
                var_c0h = var_c0h + fVar18;
                var_c8h._4_4_ = fVar20;
                var_bch._0_4_ = fVar19;
                cVar9 = func_0x00018010b530(&var_c8h, iVar17 + uVar16, 0, 2);
                if (cVar9 != '\0') {
                    acStackX_10[0] = '\0';
                    acStackX_8[0] = '\0';
                    iVar15 = *(int64_t *)0x180781f28;
                    if (((uVar2 & 2) == 0) &&
                       (((func_0x000180139d40(&var_c8h, iVar17 + uVar16, acStackX_10, acStackX_8, 0),
                         iVar15 = *(int64_t *)0x180781f28, acStackX_10[0] != '\0' || (acStackX_8[0] != '\0')) &&
                        (*(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = 4, acStackX_8[0] != '\0')))) {
                        iVar14 = 0x1d;
                        if ((*(uint8_t *)((int64_t)(int32_t)uVar16 * 0x1c + 8 + iVar5) & 2) == 0) {
                            arg1 = (uint64_t)uVar16;
                        }
                    } else {
                        iVar14 = (uint64_t)(acStackX_10[0] != '\0') + 0x1b;
                    }
                    puVar1 = (undefined4 *)(iVar15 + 0xd90 + (iVar14 + 0x14) * 0x10);
                    var_bch._4_4_ = *puVar1;
                    uStack_b4 = puVar1[1];
                    uStack_b0 = puVar1[2];
                    var_ach = (float)puVar1[3] * *(float *)(iVar15 + 0xd9c);
                    uStackX_18 = (float)(int32_t)fVar18;
                    var_1ch._0_4_ = fVar19;
                    var_1ch._4_4_ = uStackX_18;
                    uVar12 = func_0x0001800f5fa0((int64_t)&var_bch + 4);
                    func_0x000180126300(*(undefined8 *)(iVar3 + 800), (int64_t)&var_1ch + 4, &uStackX_18, uVar12, 
                                        0x3f800000);
                }
                uVar16 = uVar16 + 1;
            } while ((int32_t)uVar16 < piVar4[4]);
            if ((int32_t)arg1 == -1) {
                uVar10 = 0;
            } else {
                if ((*(char *)((int64_t)piVar4 + 9) == '\0') && (iVar17 = 0, 0 < piVar4[4] + 1)) {
                    do {
                        iVar13 = (int64_t)iVar17;
                        iVar17 = iVar17 + 1;
                        *(undefined4 *)(iVar13 * 0x1c + 4 + *(int64_t *)(piVar4 + 0x1a)) =
                             *(undefined4 *)(iVar13 * 0x1c + *(int64_t *)(piVar4 + 0x1a));
                    } while (iVar17 < piVar4[4] + 1);
                }
                *(undefined *)((int64_t)piVar4 + 9) = 1;
                uStackX_18 = (float)CONCAT31(uStackX_18._1_3_, 1);
                fcn.180138a70(arg1);
                uVar10 = SUB41(uStackX_18, 0);
            }
        }
    }
    *(undefined *)((int64_t)piVar4 + 9) = uVar10;
    *(undefined4 *)(iVar3 + 0x298) = *(undefined4 *)(iVar3 + 0x2a8);
    *(undefined4 *)(iVar3 + 0x29c) = *(undefined4 *)(iVar3 + 0x2ac);
    *(undefined4 *)(iVar3 + 0x2a0) = *(undefined4 *)(iVar3 + 0x2b0);
    *(undefined4 *)(iVar3 + 0x2a4) = *(undefined4 *)(iVar3 + 0x2b4);
    iVar17 = piVar4[0x13];
    iVar6 = piVar4[0x14];
    iVar7 = piVar4[0x15];
    iVar8 = piVar4[0x16];
    *(undefined8 *)(iVar3 + 0x208) = 0;
    *(int32_t *)(iVar3 + 0x2a8) = iVar17;
    *(int32_t *)(iVar3 + 0x2ac) = iVar6;
    *(int32_t *)(iVar3 + 0x2b0) = iVar7;
    *(int32_t *)(iVar3 + 0x2b4) = iVar8;
    *(undefined4 *)(iVar3 + 0x1a0) = 0;
    iVar13 = *(int64_t *)0x180781f28;
    *(float *)(iVar3 + 0x158) = (float)(int32_t)(*(float *)(iVar3 + 0x19c) + *(float *)(iVar3 + 0x60) + 0.0);
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    if ((*(int64_t *)(iVar13 + 0x24d0) == 0) && (*(int64_t *)(iVar3 + 0x208) == 0)) {
        *(undefined *)(iVar3 + 0x1b8) = 1;
        return;
    }
    *(undefined *)(iVar3 + 0x1b8) = 0;
    return;
}

// ============================================================
// Function: FUN_1801391be
// Address: 0x1801391be
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach

void fcn.180138d00(void)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    char cVar9;
    undefined uVar10;
    uint32_t uVar11;
    undefined4 uVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    uint64_t arg1;
    float fVar18;
    float fVar19;
    float fVar20;
    char acStackX_8 [8];
    char acStackX_10 [8];
    undefined4 uStackX_18;
    int64_t var_1ch;
    int64_t var_24h;
    int64_t var_d8h;
    int64_t var_c8h;
    float var_c0h;
    int64_t var_bch;
    undefined4 uStack_b4;
    undefined4 uStack_b0;
    float var_ach;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar13 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    iVar17 = *(int32_t *)(iVar3 + 0x248);
    piVar4 = *(int32_t **)(iVar3 + 0x208);
    if (iVar17 < 1) {
        if (*(code **)(iVar13 + 0x2a40) != (code *)0x0) {
            (**(code **)(iVar13 + 0x2a40))(iVar13, *(undefined8 *)(iVar13 + 0x2a48));
        }
    } else {
        uVar12 = *(undefined4 *)(*(int64_t *)(iVar3 + 0x250) + -4 + (int64_t)iVar17 * 4);
        *(int32_t *)(iVar3 + 0x248) = iVar17 + -1;
        *(undefined4 *)(iVar3 + 0x23c) = uVar12;
    }
    if (1 < piVar4[4]) {
        func_0x0001800fc8f0();
        func_0x000180126c00(piVar4 + 0x1c, *(undefined8 *)(iVar3 + 800));
    }
    fVar19 = (float)piVar4[8];
    if ((float)piVar4[8] <= *(float *)(iVar3 + 0x15c)) {
        fVar19 = *(float *)(iVar3 + 0x15c);
    }
    uVar2 = piVar4[1];
    piVar4[8] = (int32_t)fVar19;
    *(float *)(iVar3 + 0x15c) = fVar19;
    if ((uVar2 & 0x10) == 0) {
        *(int32_t *)(iVar3 + 0x170) = piVar4[10];
    }
    uVar10 = 0;
    if (((uVar2 & 1) == 0) && (*(char *)(iVar3 + 0x10e) == '\0')) {
        if (*(float *)(iVar3 + 0x2c4) <= fVar19) {
            fVar19 = *(float *)(iVar3 + 0x2c4);
        }
        uVar16 = 1;
        arg1 = 0xffffffff;
        fVar20 = (float)piVar4[9];
        if ((float)piVar4[9] <= *(float *)(iVar3 + 700)) {
            fVar20 = *(float *)(iVar3 + 700);
        }
        uVar10 = 0;
        if (1 < piVar4[4]) {
            do {
                iVar5 = *(int64_t *)(piVar4 + 0x1a);
                iVar15 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x208);
                if (iVar15 == 0) {
                    fVar18 = 0.0;
                } else {
                    uVar11 = uVar16;
                    if ((int32_t)uVar16 < 0) {
                        uVar11 = *(uint32_t *)(iVar15 + 0xc);
                    }
                    fVar18 = (*(float *)(iVar15 + 0x18) - *(float *)(iVar15 + 0x14)) *
                             *(float *)((int64_t)(int32_t)uVar11 * 0x1c + *(int64_t *)(iVar15 + 0x68)) +
                             *(float *)(iVar15 + 0x14);
                }
                fVar18 = fVar18 + *(float *)(iVar3 + 0x60);
                iVar17 = *piVar4;
                var_c0h = (float)(int32_t)(*(float *)(iVar13 + 0x1308) * 4.0);
                var_c8h._0_4_ = fVar18 - var_c0h;
                var_c0h = var_c0h + fVar18;
                var_c8h._4_4_ = fVar20;
                var_bch._0_4_ = fVar19;
                cVar9 = func_0x00018010b530(&var_c8h, iVar17 + uVar16, 0, 2);
                if (cVar9 != '\0') {
                    acStackX_10[0] = '\0';
                    acStackX_8[0] = '\0';
                    iVar15 = *(int64_t *)0x180781f28;
                    if (((uVar2 & 2) == 0) &&
                       (((func_0x000180139d40(&var_c8h, iVar17 + uVar16, acStackX_10, acStackX_8, 0),
                         iVar15 = *(int64_t *)0x180781f28, acStackX_10[0] != '\0' || (acStackX_8[0] != '\0')) &&
                        (*(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = 4, acStackX_8[0] != '\0')))) {
                        iVar14 = 0x1d;
                        if ((*(uint8_t *)((int64_t)(int32_t)uVar16 * 0x1c + 8 + iVar5) & 2) == 0) {
                            arg1 = (uint64_t)uVar16;
                        }
                    } else {
                        iVar14 = (uint64_t)(acStackX_10[0] != '\0') + 0x1b;
                    }
                    puVar1 = (undefined4 *)(iVar15 + 0xd90 + (iVar14 + 0x14) * 0x10);
                    var_bch._4_4_ = *puVar1;
                    uStack_b4 = puVar1[1];
                    uStack_b0 = puVar1[2];
                    var_ach = (float)puVar1[3] * *(float *)(iVar15 + 0xd9c);
                    uStackX_18 = (float)(int32_t)fVar18;
                    var_1ch._0_4_ = fVar19;
                    var_1ch._4_4_ = uStackX_18;
                    uVar12 = func_0x0001800f5fa0((int64_t)&var_bch + 4);
                    func_0x000180126300(*(undefined8 *)(iVar3 + 800), (int64_t)&var_1ch + 4, &uStackX_18, uVar12, 
                                        0x3f800000);
                }
                uVar16 = uVar16 + 1;
            } while ((int32_t)uVar16 < piVar4[4]);
            if ((int32_t)arg1 == -1) {
                uVar10 = 0;
            } else {
                if ((*(char *)((int64_t)piVar4 + 9) == '\0') && (iVar17 = 0, 0 < piVar4[4] + 1)) {
                    do {
                        iVar13 = (int64_t)iVar17;
                        iVar17 = iVar17 + 1;
                        *(undefined4 *)(iVar13 * 0x1c + 4 + *(int64_t *)(piVar4 + 0x1a)) =
                             *(undefined4 *)(iVar13 * 0x1c + *(int64_t *)(piVar4 + 0x1a));
                    } while (iVar17 < piVar4[4] + 1);
                }
                *(undefined *)((int64_t)piVar4 + 9) = 1;
                uStackX_18 = (float)CONCAT31(uStackX_18._1_3_, 1);
                fcn.180138a70(arg1);
                uVar10 = SUB41(uStackX_18, 0);
            }
        }
    }
    *(undefined *)((int64_t)piVar4 + 9) = uVar10;
    *(undefined4 *)(iVar3 + 0x298) = *(undefined4 *)(iVar3 + 0x2a8);
    *(undefined4 *)(iVar3 + 0x29c) = *(undefined4 *)(iVar3 + 0x2ac);
    *(undefined4 *)(iVar3 + 0x2a0) = *(undefined4 *)(iVar3 + 0x2b0);
    *(undefined4 *)(iVar3 + 0x2a4) = *(undefined4 *)(iVar3 + 0x2b4);
    iVar17 = piVar4[0x13];
    iVar6 = piVar4[0x14];
    iVar7 = piVar4[0x15];
    iVar8 = piVar4[0x16];
    *(undefined8 *)(iVar3 + 0x208) = 0;
    *(int32_t *)(iVar3 + 0x2a8) = iVar17;
    *(int32_t *)(iVar3 + 0x2ac) = iVar6;
    *(int32_t *)(iVar3 + 0x2b0) = iVar7;
    *(int32_t *)(iVar3 + 0x2b4) = iVar8;
    *(undefined4 *)(iVar3 + 0x1a0) = 0;
    iVar13 = *(int64_t *)0x180781f28;
    *(float *)(iVar3 + 0x158) = (float)(int32_t)(*(float *)(iVar3 + 0x19c) + *(float *)(iVar3 + 0x60) + 0.0);
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    if ((*(int64_t *)(iVar13 + 0x24d0) == 0) && (*(int64_t *)(iVar3 + 0x208) == 0)) {
        *(undefined *)(iVar3 + 0x1b8) = 1;
        return;
    }
    *(undefined *)(iVar3 + 0x1b8) = 0;
    return;
}

// ============================================================
// Function: FUN_180139257
// Address: 0x180139257
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach

void fcn.180138d00(void)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    char cVar9;
    undefined uVar10;
    uint32_t uVar11;
    undefined4 uVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    uint64_t arg1;
    float fVar18;
    float fVar19;
    float fVar20;
    char acStackX_8 [8];
    char acStackX_10 [8];
    undefined4 uStackX_18;
    int64_t var_1ch;
    int64_t var_24h;
    int64_t var_d8h;
    int64_t var_c8h;
    float var_c0h;
    int64_t var_bch;
    undefined4 uStack_b4;
    undefined4 uStack_b0;
    float var_ach;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar13 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    iVar17 = *(int32_t *)(iVar3 + 0x248);
    piVar4 = *(int32_t **)(iVar3 + 0x208);
    if (iVar17 < 1) {
        if (*(code **)(iVar13 + 0x2a40) != (code *)0x0) {
            (**(code **)(iVar13 + 0x2a40))(iVar13, *(undefined8 *)(iVar13 + 0x2a48));
        }
    } else {
        uVar12 = *(undefined4 *)(*(int64_t *)(iVar3 + 0x250) + -4 + (int64_t)iVar17 * 4);
        *(int32_t *)(iVar3 + 0x248) = iVar17 + -1;
        *(undefined4 *)(iVar3 + 0x23c) = uVar12;
    }
    if (1 < piVar4[4]) {
        func_0x0001800fc8f0();
        func_0x000180126c00(piVar4 + 0x1c, *(undefined8 *)(iVar3 + 800));
    }
    fVar19 = (float)piVar4[8];
    if ((float)piVar4[8] <= *(float *)(iVar3 + 0x15c)) {
        fVar19 = *(float *)(iVar3 + 0x15c);
    }
    uVar2 = piVar4[1];
    piVar4[8] = (int32_t)fVar19;
    *(float *)(iVar3 + 0x15c) = fVar19;
    if ((uVar2 & 0x10) == 0) {
        *(int32_t *)(iVar3 + 0x170) = piVar4[10];
    }
    uVar10 = 0;
    if (((uVar2 & 1) == 0) && (*(char *)(iVar3 + 0x10e) == '\0')) {
        if (*(float *)(iVar3 + 0x2c4) <= fVar19) {
            fVar19 = *(float *)(iVar3 + 0x2c4);
        }
        uVar16 = 1;
        arg1 = 0xffffffff;
        fVar20 = (float)piVar4[9];
        if ((float)piVar4[9] <= *(float *)(iVar3 + 700)) {
            fVar20 = *(float *)(iVar3 + 700);
        }
        uVar10 = 0;
        if (1 < piVar4[4]) {
            do {
                iVar5 = *(int64_t *)(piVar4 + 0x1a);
                iVar15 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x208);
                if (iVar15 == 0) {
                    fVar18 = 0.0;
                } else {
                    uVar11 = uVar16;
                    if ((int32_t)uVar16 < 0) {
                        uVar11 = *(uint32_t *)(iVar15 + 0xc);
                    }
                    fVar18 = (*(float *)(iVar15 + 0x18) - *(float *)(iVar15 + 0x14)) *
                             *(float *)((int64_t)(int32_t)uVar11 * 0x1c + *(int64_t *)(iVar15 + 0x68)) +
                             *(float *)(iVar15 + 0x14);
                }
                fVar18 = fVar18 + *(float *)(iVar3 + 0x60);
                iVar17 = *piVar4;
                var_c0h = (float)(int32_t)(*(float *)(iVar13 + 0x1308) * 4.0);
                var_c8h._0_4_ = fVar18 - var_c0h;
                var_c0h = var_c0h + fVar18;
                var_c8h._4_4_ = fVar20;
                var_bch._0_4_ = fVar19;
                cVar9 = func_0x00018010b530(&var_c8h, iVar17 + uVar16, 0, 2);
                if (cVar9 != '\0') {
                    acStackX_10[0] = '\0';
                    acStackX_8[0] = '\0';
                    iVar15 = *(int64_t *)0x180781f28;
                    if (((uVar2 & 2) == 0) &&
                       (((func_0x000180139d40(&var_c8h, iVar17 + uVar16, acStackX_10, acStackX_8, 0),
                         iVar15 = *(int64_t *)0x180781f28, acStackX_10[0] != '\0' || (acStackX_8[0] != '\0')) &&
                        (*(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = 4, acStackX_8[0] != '\0')))) {
                        iVar14 = 0x1d;
                        if ((*(uint8_t *)((int64_t)(int32_t)uVar16 * 0x1c + 8 + iVar5) & 2) == 0) {
                            arg1 = (uint64_t)uVar16;
                        }
                    } else {
                        iVar14 = (uint64_t)(acStackX_10[0] != '\0') + 0x1b;
                    }
                    puVar1 = (undefined4 *)(iVar15 + 0xd90 + (iVar14 + 0x14) * 0x10);
                    var_bch._4_4_ = *puVar1;
                    uStack_b4 = puVar1[1];
                    uStack_b0 = puVar1[2];
                    var_ach = (float)puVar1[3] * *(float *)(iVar15 + 0xd9c);
                    uStackX_18 = (float)(int32_t)fVar18;
                    var_1ch._0_4_ = fVar19;
                    var_1ch._4_4_ = uStackX_18;
                    uVar12 = func_0x0001800f5fa0((int64_t)&var_bch + 4);
                    func_0x000180126300(*(undefined8 *)(iVar3 + 800), (int64_t)&var_1ch + 4, &uStackX_18, uVar12, 
                                        0x3f800000);
                }
                uVar16 = uVar16 + 1;
            } while ((int32_t)uVar16 < piVar4[4]);
            if ((int32_t)arg1 == -1) {
                uVar10 = 0;
            } else {
                if ((*(char *)((int64_t)piVar4 + 9) == '\0') && (iVar17 = 0, 0 < piVar4[4] + 1)) {
                    do {
                        iVar13 = (int64_t)iVar17;
                        iVar17 = iVar17 + 1;
                        *(undefined4 *)(iVar13 * 0x1c + 4 + *(int64_t *)(piVar4 + 0x1a)) =
                             *(undefined4 *)(iVar13 * 0x1c + *(int64_t *)(piVar4 + 0x1a));
                    } while (iVar17 < piVar4[4] + 1);
                }
                *(undefined *)((int64_t)piVar4 + 9) = 1;
                uStackX_18 = (float)CONCAT31(uStackX_18._1_3_, 1);
                fcn.180138a70(arg1);
                uVar10 = SUB41(uStackX_18, 0);
            }
        }
    }
    *(undefined *)((int64_t)piVar4 + 9) = uVar10;
    *(undefined4 *)(iVar3 + 0x298) = *(undefined4 *)(iVar3 + 0x2a8);
    *(undefined4 *)(iVar3 + 0x29c) = *(undefined4 *)(iVar3 + 0x2ac);
    *(undefined4 *)(iVar3 + 0x2a0) = *(undefined4 *)(iVar3 + 0x2b0);
    *(undefined4 *)(iVar3 + 0x2a4) = *(undefined4 *)(iVar3 + 0x2b4);
    iVar17 = piVar4[0x13];
    iVar6 = piVar4[0x14];
    iVar7 = piVar4[0x15];
    iVar8 = piVar4[0x16];
    *(undefined8 *)(iVar3 + 0x208) = 0;
    *(int32_t *)(iVar3 + 0x2a8) = iVar17;
    *(int32_t *)(iVar3 + 0x2ac) = iVar6;
    *(int32_t *)(iVar3 + 0x2b0) = iVar7;
    *(int32_t *)(iVar3 + 0x2b4) = iVar8;
    *(undefined4 *)(iVar3 + 0x1a0) = 0;
    iVar13 = *(int64_t *)0x180781f28;
    *(float *)(iVar3 + 0x158) = (float)(int32_t)(*(float *)(iVar3 + 0x19c) + *(float *)(iVar3 + 0x60) + 0.0);
    iVar3 = *(int64_t *)(iVar13 + 0x15e0);
    if ((*(int64_t *)(iVar13 + 0x24d0) == 0) && (*(int64_t *)(iVar3 + 0x208) == 0)) {
        *(undefined *)(iVar3 + 0x1b8) = 1;
        return;
    }
    *(undefined *)(iVar3 + 0x1b8) = 0;
    return;
}

// ============================================================
// Function: FUN_180139280
// Address: 0x180139280
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_110h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.180139280(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    float fVar2;
    char cVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    char *pcVar8;
    float *pfVar9;
    int64_t iVar10;
    int64_t iVar11;
    char *pcVar12;
    int32_t iVar13;
    int64_t iVar14;
    char *pcVar15;
    int32_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    float fStackX_20;
    float fStackX_24;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
    if (*(char *)(iVar10 + 0x10e) == '\0') {
        pcVar7 = "";
        pcVar15 = "";
        if (arg1 != arg2) {
            pcVar7 = (char *)arg1;
            pcVar15 = (char *)arg2;
        }
        if (pcVar15 == (char *)0x0) {
            iVar6 = func_0x000180498cd0(pcVar7);
            pcVar15 = pcVar7 + iVar6;
        }
        fVar18 = *(float *)(iVar10 + 0x244);
        fVar17 = *(float *)(iVar10 + 0x158);
        fVar20 = *(float *)(iVar10 + 400) + *(float *)(iVar10 + 0x15c);
        var_e0h._0_4_ = fVar17;
        var_e0h._4_4_ = fVar20;
        if (((int64_t)pcVar15 - (int64_t)pcVar7 < 0x7d1) || (0.0 <= fVar18)) {
            if (fVar18 < 0.0) {
                fVar18 = 0.0;
            } else if (fVar18 == 0.0) {
                fVar18 = *(float *)(iVar10 + 0x2a0) - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            } else {
                if (0.0 < fVar18) {
                    fVar18 = (*(float *)(iVar10 + 0x60) - *(float *)(iVar10 + 0xd4)) + fVar18;
                }
                fVar18 = fVar18 - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            }
            var_118h = (int64_t)(uint32_t)fVar18;
            func_0x0001800fe0a0(&fStackX_20, pcVar7, pcVar15, 0, var_118h);
            fVar22 = fStackX_24 + fVar20;
            fVar19 = fVar17 + fStackX_20;
            func_0x00018010bbf0(&fStackX_20, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar19;
            *(float *)(iVar14 + 0x1fd0) = fVar22;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar19;
            *(float *)(iVar14 + 0x1fe0) = fVar22;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if ((((fVar22 < *(float *)(iVar10 + 700) || fVar22 == *(float *)(iVar10 + 700)) ||
                 (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
                (fVar19 < *(float *)(iVar10 + 0x2b8) || fVar19 == *(float *)(iVar10 + 0x2b8))) ||
               (*(float *)(iVar10 + 0x2c0) <= fVar17)) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar19;
            var_d8h._4_4_ = fVar22;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if (pcVar15 == (char *)0x0) {
                iVar10 = func_0x000180498cd0(pcVar7);
                pcVar15 = pcVar7 + iVar10;
            }
            if (pcVar7 != pcVar15) {
                var_e0h._0_4_ = *(float *)(iVar14 + 0xed0);
                var_e0h._4_4_ = *(float *)(iVar14 + 0xed4);
                var_d8h._0_4_ = *(float *)(iVar14 + 0xed8);
                var_d8h._4_4_ = *(float *)(iVar14 + 0xedc) * *(float *)(iVar14 + 0xd9c);
                uVar4 = func_0x0001800f5fa0(&var_e0h);
                iVar10 = iVar14;
                if (((uVar4 & 0xff000000) != 0) && (*pcVar7 != '\0')) {
                    iVar10 = *(int64_t *)(iVar14 + 0x12e8);
                    fVar17 = *(float *)(iVar14 + 0x12f8);
                    iVar6 = *(int64_t *)(*(int64_t *)(iVar14 + 0x15e0) + 800);
                    if (iVar10 == 0) {
                        iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x38) + 0x18);
                    }
                    if (fVar17 == 0.0) {
                        fVar17 = *(float *)(*(int64_t *)(iVar6 + 0x38) + 0x20);
                    }
                    var_e0h._0_4_ = *(float *)(iVar6 + 0x60);
                    var_e0h._4_4_ = *(float *)(iVar6 + 100);
                    var_d8h._0_4_ = *(float *)(iVar6 + 0x68);
                    var_d8h._4_4_ = *(float *)(iVar6 + 0x6c);
                    var_118h = (int64_t)uVar4;
                    func_0x00018012f9d0(iVar10, iVar6, fVar17, &fStackX_20, var_118h, &var_e0h, pcVar7, pcVar15, fVar18
                                        , 0);
                    iVar10 = *(int64_t *)0x180781f28;
                }
                if (*(char *)(iVar14 + 0x29f8) != '\0') {
                    iVar14 = *(int64_t *)(iVar10 + 0x2a20);
                    iVar6 = *(int64_t *)(iVar10 + 0x15e0);
                    iVar1 = *(int64_t *)(iVar10 + 0x2a28);
                    *(undefined8 *)(iVar10 + 0x2a28) = 0;
                    *(undefined8 *)(iVar10 + 0x2a20) = 0;
                    if ((pcVar15 == (char *)0x0) && (pcVar15 = pcVar7, pcVar7 != (char *)0xffffffffffffffff)) {
                        while (*pcVar15 != '\0') {
                            pcVar8 = pcVar15 + 1;
                            if (((*pcVar15 == '#') && (*pcVar8 == '#')) ||
                               (pcVar15 = pcVar8, pcVar8 == (char *)0xffffffffffffffff)) break;
                        }
                    }
                    fVar18 = *(float *)(iVar10 + 0xde0);
                    if (*(float *)(iVar10 + 0xde0) <= *(float *)(iVar10 + 0xdf0)) {
                        fVar18 = *(float *)(iVar10 + 0xdf0);
                    }
                    fVar17 = *(float *)(iVar10 + 0x2a30);
                    *(float *)(iVar10 + 0x2a30) = fStackX_24;
                    if (fVar18 + fVar17 + 1.0 < fStackX_24) {
                        func_0x0001801124e0(0x180644f68);
                        *(undefined *)(iVar10 + 0x29f9) = 1;
                    }
                    if (iVar14 != 0) {
                        iVar11 = func_0x000180498cd0(iVar14);
                        func_0x000180112520(&fStackX_20, iVar14, iVar14 + iVar11);
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    iVar5 = *(int32_t *)(iVar10 + 0x2a34);
                    if (iVar13 < iVar5) {
                        *(int32_t *)(iVar10 + 0x2a34) = iVar13;
                        iVar5 = iVar13;
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    while( true ) {
                        pcVar12 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                        pcVar8 = pcVar15;
                        if (pcVar12 != (char *)0x0) {
                            pcVar8 = pcVar12;
                        }
                        if ((pcVar7 == pcVar8) && (pcVar8 == pcVar15)) break;
                        iVar16 = (iVar13 - iVar5) * 4;
                        if (*(char *)(iVar10 + 0x29f9) == '\0') {
                            iVar16 = 1;
                        }
                        func_0x0001801124e0(0x180644f70, iVar16, 0x1805aadb1, (int32_t)pcVar8 - (int32_t)pcVar7, pcVar7)
                        ;
                        *(undefined *)(iVar10 + 0x29f9) = 0;
                        if (*pcVar8 == '\n') {
                            func_0x0001801124e0(0x180644f68);
                            *(undefined *)(iVar10 + 0x29f9) = 1;
                        }
                        if (pcVar8 == pcVar15) break;
                        pcVar7 = pcVar8 + 1;
                    }
                    if (iVar1 != 0) {
                        iVar10 = func_0x000180498cd0(iVar1);
                        func_0x000180112520(&fStackX_20, iVar1, iVar10 + iVar1);
                    }
                }
            }
        } else {
            fVar18 = *(float *)(iVar14 + 0x12f8);
            fVar22 = 0.0;
            var_e8h._0_4_ = 0.0;
            iVar13 = 0;
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if ((*(char *)(iVar14 + 0x29f8) == '\0') &&
               (iVar16 = (int32_t)((*(float *)(iVar10 + 700) - fVar20) / fVar18), iVar5 = iVar13, 0 < iVar16)) {
                for (; (pcVar7 < pcVar15 && (iVar5 < iVar16)); iVar5 = iVar5 + 1) {
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    pcVar7 = pcVar7 + 1;
                }
                fStackX_24 = (float)iVar5 * fVar18 + fVar20;
            }
            var_e8h._4_4_ = fStackX_24;
            if (pcVar7 < pcVar15) {
                fVar21 = fStackX_24;
                fVar19 = fStackX_24;
                do {
                    fVar2 = fStackX_24;
                    fVar19 = fVar19 + fVar18;
                    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
                    if (((((fVar19 < *(float *)(iVar10 + 700) || fVar19 == *(float *)(iVar10 + 700)) ||
                          (*(float *)(iVar10 + 0x2c4) <= fVar21)) ||
                         (fVar17 + 3.402823e+38 < *(float *)(iVar10 + 0x2b8) ||
                          fVar17 + 3.402823e+38 == *(float *)(iVar10 + 0x2b8))) ||
                        (*(float *)(iVar10 + 0x2c0) <= fVar17)) && (*(char *)(iVar14 + 0x1652) == '\0')) break;
                    pcVar8 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                    if (pcVar8 == (char *)0x0) {
                        pcVar8 = pcVar15;
                    }
                    pfVar9 = (float *)func_0x0001800fe0a0(&var_e0h, pcVar7, pcVar8, 0, 0xbf800000);
                    if (fVar22 <= *pfVar9) {
                        fVar22 = *pfVar9;
                    }
                    var_e8h._0_4_ = fVar22;
                    func_0x0001800f6cb0(CONCAT44(fStackX_24, fStackX_20), pcVar7, pcVar8);
                    fStackX_24 = fVar2 + fVar18;
                    pcVar7 = pcVar8 + 1;
                    fVar21 = fVar21 + fVar18;
                    iVar14 = *(int64_t *)0x180781f28;
                    fVar2 = fStackX_24;
                } while (pcVar7 < pcVar15);
                for (; fVar19 = fStackX_24, pcVar7 < pcVar15; pcVar7 = pcVar7 + 1) {
                    fStackX_24 = fVar2;
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    iVar13 = iVar13 + 1;
                    fVar2 = fStackX_24;
                    fStackX_24 = fVar19;
                }
                var_e8h._4_4_ = fStackX_24 + (float)iVar13 * fVar18;
                fStackX_24 = fVar2;
            }
            var_e8h._4_4_ = var_e8h._4_4_ - fVar20;
            fVar22 = fVar17 + fVar22;
            fVar18 = var_e8h._4_4_ + fVar20;
            func_0x00018010bbf0(&var_e8h, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar22;
            *(float *)(iVar14 + 0x1fd0) = fVar18;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar22;
            *(float *)(iVar14 + 0x1fe0) = fVar18;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if (((fVar18 < *(float *)(iVar10 + 700) || fVar18 == *(float *)(iVar10 + 700)) ||
                (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
               ((fVar22 < *(float *)(iVar10 + 0x2b8) || fVar22 == *(float *)(iVar10 + 0x2b8) ||
                (*(float *)(iVar10 + 0x2c0) <= fVar17)))) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar22;
            var_d8h._4_4_ = fVar18;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801392bc
// Address: 0x1801392bc
// Size: 185 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_110h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.180139280(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    float fVar2;
    char cVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    char *pcVar8;
    float *pfVar9;
    int64_t iVar10;
    int64_t iVar11;
    char *pcVar12;
    int32_t iVar13;
    int64_t iVar14;
    char *pcVar15;
    int32_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    float fStackX_20;
    float fStackX_24;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
    if (*(char *)(iVar10 + 0x10e) == '\0') {
        pcVar7 = "";
        pcVar15 = "";
        if (arg1 != arg2) {
            pcVar7 = (char *)arg1;
            pcVar15 = (char *)arg2;
        }
        if (pcVar15 == (char *)0x0) {
            iVar6 = func_0x000180498cd0(pcVar7);
            pcVar15 = pcVar7 + iVar6;
        }
        fVar18 = *(float *)(iVar10 + 0x244);
        fVar17 = *(float *)(iVar10 + 0x158);
        fVar20 = *(float *)(iVar10 + 400) + *(float *)(iVar10 + 0x15c);
        var_e0h._0_4_ = fVar17;
        var_e0h._4_4_ = fVar20;
        if (((int64_t)pcVar15 - (int64_t)pcVar7 < 0x7d1) || (0.0 <= fVar18)) {
            if (fVar18 < 0.0) {
                fVar18 = 0.0;
            } else if (fVar18 == 0.0) {
                fVar18 = *(float *)(iVar10 + 0x2a0) - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            } else {
                if (0.0 < fVar18) {
                    fVar18 = (*(float *)(iVar10 + 0x60) - *(float *)(iVar10 + 0xd4)) + fVar18;
                }
                fVar18 = fVar18 - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            }
            var_118h = (int64_t)(uint32_t)fVar18;
            func_0x0001800fe0a0(&fStackX_20, pcVar7, pcVar15, 0, var_118h);
            fVar22 = fStackX_24 + fVar20;
            fVar19 = fVar17 + fStackX_20;
            func_0x00018010bbf0(&fStackX_20, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar19;
            *(float *)(iVar14 + 0x1fd0) = fVar22;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar19;
            *(float *)(iVar14 + 0x1fe0) = fVar22;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if ((((fVar22 < *(float *)(iVar10 + 700) || fVar22 == *(float *)(iVar10 + 700)) ||
                 (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
                (fVar19 < *(float *)(iVar10 + 0x2b8) || fVar19 == *(float *)(iVar10 + 0x2b8))) ||
               (*(float *)(iVar10 + 0x2c0) <= fVar17)) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar19;
            var_d8h._4_4_ = fVar22;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if (pcVar15 == (char *)0x0) {
                iVar10 = func_0x000180498cd0(pcVar7);
                pcVar15 = pcVar7 + iVar10;
            }
            if (pcVar7 != pcVar15) {
                var_e0h._0_4_ = *(float *)(iVar14 + 0xed0);
                var_e0h._4_4_ = *(float *)(iVar14 + 0xed4);
                var_d8h._0_4_ = *(float *)(iVar14 + 0xed8);
                var_d8h._4_4_ = *(float *)(iVar14 + 0xedc) * *(float *)(iVar14 + 0xd9c);
                uVar4 = func_0x0001800f5fa0(&var_e0h);
                iVar10 = iVar14;
                if (((uVar4 & 0xff000000) != 0) && (*pcVar7 != '\0')) {
                    iVar10 = *(int64_t *)(iVar14 + 0x12e8);
                    fVar17 = *(float *)(iVar14 + 0x12f8);
                    iVar6 = *(int64_t *)(*(int64_t *)(iVar14 + 0x15e0) + 800);
                    if (iVar10 == 0) {
                        iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x38) + 0x18);
                    }
                    if (fVar17 == 0.0) {
                        fVar17 = *(float *)(*(int64_t *)(iVar6 + 0x38) + 0x20);
                    }
                    var_e0h._0_4_ = *(float *)(iVar6 + 0x60);
                    var_e0h._4_4_ = *(float *)(iVar6 + 100);
                    var_d8h._0_4_ = *(float *)(iVar6 + 0x68);
                    var_d8h._4_4_ = *(float *)(iVar6 + 0x6c);
                    var_118h = (int64_t)uVar4;
                    func_0x00018012f9d0(iVar10, iVar6, fVar17, &fStackX_20, var_118h, &var_e0h, pcVar7, pcVar15, fVar18
                                        , 0);
                    iVar10 = *(int64_t *)0x180781f28;
                }
                if (*(char *)(iVar14 + 0x29f8) != '\0') {
                    iVar14 = *(int64_t *)(iVar10 + 0x2a20);
                    iVar6 = *(int64_t *)(iVar10 + 0x15e0);
                    iVar1 = *(int64_t *)(iVar10 + 0x2a28);
                    *(undefined8 *)(iVar10 + 0x2a28) = 0;
                    *(undefined8 *)(iVar10 + 0x2a20) = 0;
                    if ((pcVar15 == (char *)0x0) && (pcVar15 = pcVar7, pcVar7 != (char *)0xffffffffffffffff)) {
                        while (*pcVar15 != '\0') {
                            pcVar8 = pcVar15 + 1;
                            if (((*pcVar15 == '#') && (*pcVar8 == '#')) ||
                               (pcVar15 = pcVar8, pcVar8 == (char *)0xffffffffffffffff)) break;
                        }
                    }
                    fVar18 = *(float *)(iVar10 + 0xde0);
                    if (*(float *)(iVar10 + 0xde0) <= *(float *)(iVar10 + 0xdf0)) {
                        fVar18 = *(float *)(iVar10 + 0xdf0);
                    }
                    fVar17 = *(float *)(iVar10 + 0x2a30);
                    *(float *)(iVar10 + 0x2a30) = fStackX_24;
                    if (fVar18 + fVar17 + 1.0 < fStackX_24) {
                        func_0x0001801124e0(0x180644f68);
                        *(undefined *)(iVar10 + 0x29f9) = 1;
                    }
                    if (iVar14 != 0) {
                        iVar11 = func_0x000180498cd0(iVar14);
                        func_0x000180112520(&fStackX_20, iVar14, iVar14 + iVar11);
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    iVar5 = *(int32_t *)(iVar10 + 0x2a34);
                    if (iVar13 < iVar5) {
                        *(int32_t *)(iVar10 + 0x2a34) = iVar13;
                        iVar5 = iVar13;
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    while( true ) {
                        pcVar12 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                        pcVar8 = pcVar15;
                        if (pcVar12 != (char *)0x0) {
                            pcVar8 = pcVar12;
                        }
                        if ((pcVar7 == pcVar8) && (pcVar8 == pcVar15)) break;
                        iVar16 = (iVar13 - iVar5) * 4;
                        if (*(char *)(iVar10 + 0x29f9) == '\0') {
                            iVar16 = 1;
                        }
                        func_0x0001801124e0(0x180644f70, iVar16, 0x1805aadb1, (int32_t)pcVar8 - (int32_t)pcVar7, pcVar7)
                        ;
                        *(undefined *)(iVar10 + 0x29f9) = 0;
                        if (*pcVar8 == '\n') {
                            func_0x0001801124e0(0x180644f68);
                            *(undefined *)(iVar10 + 0x29f9) = 1;
                        }
                        if (pcVar8 == pcVar15) break;
                        pcVar7 = pcVar8 + 1;
                    }
                    if (iVar1 != 0) {
                        iVar10 = func_0x000180498cd0(iVar1);
                        func_0x000180112520(&fStackX_20, iVar1, iVar10 + iVar1);
                    }
                }
            }
        } else {
            fVar18 = *(float *)(iVar14 + 0x12f8);
            fVar22 = 0.0;
            var_e8h._0_4_ = 0.0;
            iVar13 = 0;
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if ((*(char *)(iVar14 + 0x29f8) == '\0') &&
               (iVar16 = (int32_t)((*(float *)(iVar10 + 700) - fVar20) / fVar18), iVar5 = iVar13, 0 < iVar16)) {
                for (; (pcVar7 < pcVar15 && (iVar5 < iVar16)); iVar5 = iVar5 + 1) {
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    pcVar7 = pcVar7 + 1;
                }
                fStackX_24 = (float)iVar5 * fVar18 + fVar20;
            }
            var_e8h._4_4_ = fStackX_24;
            if (pcVar7 < pcVar15) {
                fVar21 = fStackX_24;
                fVar19 = fStackX_24;
                do {
                    fVar2 = fStackX_24;
                    fVar19 = fVar19 + fVar18;
                    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
                    if (((((fVar19 < *(float *)(iVar10 + 700) || fVar19 == *(float *)(iVar10 + 700)) ||
                          (*(float *)(iVar10 + 0x2c4) <= fVar21)) ||
                         (fVar17 + 3.402823e+38 < *(float *)(iVar10 + 0x2b8) ||
                          fVar17 + 3.402823e+38 == *(float *)(iVar10 + 0x2b8))) ||
                        (*(float *)(iVar10 + 0x2c0) <= fVar17)) && (*(char *)(iVar14 + 0x1652) == '\0')) break;
                    pcVar8 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                    if (pcVar8 == (char *)0x0) {
                        pcVar8 = pcVar15;
                    }
                    pfVar9 = (float *)func_0x0001800fe0a0(&var_e0h, pcVar7, pcVar8, 0, 0xbf800000);
                    if (fVar22 <= *pfVar9) {
                        fVar22 = *pfVar9;
                    }
                    var_e8h._0_4_ = fVar22;
                    func_0x0001800f6cb0(CONCAT44(fStackX_24, fStackX_20), pcVar7, pcVar8);
                    fStackX_24 = fVar2 + fVar18;
                    pcVar7 = pcVar8 + 1;
                    fVar21 = fVar21 + fVar18;
                    iVar14 = *(int64_t *)0x180781f28;
                    fVar2 = fStackX_24;
                } while (pcVar7 < pcVar15);
                for (; fVar19 = fStackX_24, pcVar7 < pcVar15; pcVar7 = pcVar7 + 1) {
                    fStackX_24 = fVar2;
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    iVar13 = iVar13 + 1;
                    fVar2 = fStackX_24;
                    fStackX_24 = fVar19;
                }
                var_e8h._4_4_ = fStackX_24 + (float)iVar13 * fVar18;
                fStackX_24 = fVar2;
            }
            var_e8h._4_4_ = var_e8h._4_4_ - fVar20;
            fVar22 = fVar17 + fVar22;
            fVar18 = var_e8h._4_4_ + fVar20;
            func_0x00018010bbf0(&var_e8h, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar22;
            *(float *)(iVar14 + 0x1fd0) = fVar18;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar22;
            *(float *)(iVar14 + 0x1fe0) = fVar18;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if (((fVar18 < *(float *)(iVar10 + 700) || fVar18 == *(float *)(iVar10 + 700)) ||
                (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
               ((fVar22 < *(float *)(iVar10 + 0x2b8) || fVar22 == *(float *)(iVar10 + 0x2b8) ||
                (*(float *)(iVar10 + 0x2c0) <= fVar17)))) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar22;
            var_d8h._4_4_ = fVar18;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180139375
// Address: 0x180139375
// Size: 186 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_110h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.180139280(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    float fVar2;
    char cVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    char *pcVar8;
    float *pfVar9;
    int64_t iVar10;
    int64_t iVar11;
    char *pcVar12;
    int32_t iVar13;
    int64_t iVar14;
    char *pcVar15;
    int32_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    float fStackX_20;
    float fStackX_24;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
    if (*(char *)(iVar10 + 0x10e) == '\0') {
        pcVar7 = "";
        pcVar15 = "";
        if (arg1 != arg2) {
            pcVar7 = (char *)arg1;
            pcVar15 = (char *)arg2;
        }
        if (pcVar15 == (char *)0x0) {
            iVar6 = func_0x000180498cd0(pcVar7);
            pcVar15 = pcVar7 + iVar6;
        }
        fVar18 = *(float *)(iVar10 + 0x244);
        fVar17 = *(float *)(iVar10 + 0x158);
        fVar20 = *(float *)(iVar10 + 400) + *(float *)(iVar10 + 0x15c);
        var_e0h._0_4_ = fVar17;
        var_e0h._4_4_ = fVar20;
        if (((int64_t)pcVar15 - (int64_t)pcVar7 < 0x7d1) || (0.0 <= fVar18)) {
            if (fVar18 < 0.0) {
                fVar18 = 0.0;
            } else if (fVar18 == 0.0) {
                fVar18 = *(float *)(iVar10 + 0x2a0) - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            } else {
                if (0.0 < fVar18) {
                    fVar18 = (*(float *)(iVar10 + 0x60) - *(float *)(iVar10 + 0xd4)) + fVar18;
                }
                fVar18 = fVar18 - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            }
            var_118h = (int64_t)(uint32_t)fVar18;
            func_0x0001800fe0a0(&fStackX_20, pcVar7, pcVar15, 0, var_118h);
            fVar22 = fStackX_24 + fVar20;
            fVar19 = fVar17 + fStackX_20;
            func_0x00018010bbf0(&fStackX_20, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar19;
            *(float *)(iVar14 + 0x1fd0) = fVar22;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar19;
            *(float *)(iVar14 + 0x1fe0) = fVar22;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if ((((fVar22 < *(float *)(iVar10 + 700) || fVar22 == *(float *)(iVar10 + 700)) ||
                 (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
                (fVar19 < *(float *)(iVar10 + 0x2b8) || fVar19 == *(float *)(iVar10 + 0x2b8))) ||
               (*(float *)(iVar10 + 0x2c0) <= fVar17)) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar19;
            var_d8h._4_4_ = fVar22;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if (pcVar15 == (char *)0x0) {
                iVar10 = func_0x000180498cd0(pcVar7);
                pcVar15 = pcVar7 + iVar10;
            }
            if (pcVar7 != pcVar15) {
                var_e0h._0_4_ = *(float *)(iVar14 + 0xed0);
                var_e0h._4_4_ = *(float *)(iVar14 + 0xed4);
                var_d8h._0_4_ = *(float *)(iVar14 + 0xed8);
                var_d8h._4_4_ = *(float *)(iVar14 + 0xedc) * *(float *)(iVar14 + 0xd9c);
                uVar4 = func_0x0001800f5fa0(&var_e0h);
                iVar10 = iVar14;
                if (((uVar4 & 0xff000000) != 0) && (*pcVar7 != '\0')) {
                    iVar10 = *(int64_t *)(iVar14 + 0x12e8);
                    fVar17 = *(float *)(iVar14 + 0x12f8);
                    iVar6 = *(int64_t *)(*(int64_t *)(iVar14 + 0x15e0) + 800);
                    if (iVar10 == 0) {
                        iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x38) + 0x18);
                    }
                    if (fVar17 == 0.0) {
                        fVar17 = *(float *)(*(int64_t *)(iVar6 + 0x38) + 0x20);
                    }
                    var_e0h._0_4_ = *(float *)(iVar6 + 0x60);
                    var_e0h._4_4_ = *(float *)(iVar6 + 100);
                    var_d8h._0_4_ = *(float *)(iVar6 + 0x68);
                    var_d8h._4_4_ = *(float *)(iVar6 + 0x6c);
                    var_118h = (int64_t)uVar4;
                    func_0x00018012f9d0(iVar10, iVar6, fVar17, &fStackX_20, var_118h, &var_e0h, pcVar7, pcVar15, fVar18
                                        , 0);
                    iVar10 = *(int64_t *)0x180781f28;
                }
                if (*(char *)(iVar14 + 0x29f8) != '\0') {
                    iVar14 = *(int64_t *)(iVar10 + 0x2a20);
                    iVar6 = *(int64_t *)(iVar10 + 0x15e0);
                    iVar1 = *(int64_t *)(iVar10 + 0x2a28);
                    *(undefined8 *)(iVar10 + 0x2a28) = 0;
                    *(undefined8 *)(iVar10 + 0x2a20) = 0;
                    if ((pcVar15 == (char *)0x0) && (pcVar15 = pcVar7, pcVar7 != (char *)0xffffffffffffffff)) {
                        while (*pcVar15 != '\0') {
                            pcVar8 = pcVar15 + 1;
                            if (((*pcVar15 == '#') && (*pcVar8 == '#')) ||
                               (pcVar15 = pcVar8, pcVar8 == (char *)0xffffffffffffffff)) break;
                        }
                    }
                    fVar18 = *(float *)(iVar10 + 0xde0);
                    if (*(float *)(iVar10 + 0xde0) <= *(float *)(iVar10 + 0xdf0)) {
                        fVar18 = *(float *)(iVar10 + 0xdf0);
                    }
                    fVar17 = *(float *)(iVar10 + 0x2a30);
                    *(float *)(iVar10 + 0x2a30) = fStackX_24;
                    if (fVar18 + fVar17 + 1.0 < fStackX_24) {
                        func_0x0001801124e0(0x180644f68);
                        *(undefined *)(iVar10 + 0x29f9) = 1;
                    }
                    if (iVar14 != 0) {
                        iVar11 = func_0x000180498cd0(iVar14);
                        func_0x000180112520(&fStackX_20, iVar14, iVar14 + iVar11);
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    iVar5 = *(int32_t *)(iVar10 + 0x2a34);
                    if (iVar13 < iVar5) {
                        *(int32_t *)(iVar10 + 0x2a34) = iVar13;
                        iVar5 = iVar13;
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    while( true ) {
                        pcVar12 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                        pcVar8 = pcVar15;
                        if (pcVar12 != (char *)0x0) {
                            pcVar8 = pcVar12;
                        }
                        if ((pcVar7 == pcVar8) && (pcVar8 == pcVar15)) break;
                        iVar16 = (iVar13 - iVar5) * 4;
                        if (*(char *)(iVar10 + 0x29f9) == '\0') {
                            iVar16 = 1;
                        }
                        func_0x0001801124e0(0x180644f70, iVar16, 0x1805aadb1, (int32_t)pcVar8 - (int32_t)pcVar7, pcVar7)
                        ;
                        *(undefined *)(iVar10 + 0x29f9) = 0;
                        if (*pcVar8 == '\n') {
                            func_0x0001801124e0(0x180644f68);
                            *(undefined *)(iVar10 + 0x29f9) = 1;
                        }
                        if (pcVar8 == pcVar15) break;
                        pcVar7 = pcVar8 + 1;
                    }
                    if (iVar1 != 0) {
                        iVar10 = func_0x000180498cd0(iVar1);
                        func_0x000180112520(&fStackX_20, iVar1, iVar10 + iVar1);
                    }
                }
            }
        } else {
            fVar18 = *(float *)(iVar14 + 0x12f8);
            fVar22 = 0.0;
            var_e8h._0_4_ = 0.0;
            iVar13 = 0;
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if ((*(char *)(iVar14 + 0x29f8) == '\0') &&
               (iVar16 = (int32_t)((*(float *)(iVar10 + 700) - fVar20) / fVar18), iVar5 = iVar13, 0 < iVar16)) {
                for (; (pcVar7 < pcVar15 && (iVar5 < iVar16)); iVar5 = iVar5 + 1) {
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    pcVar7 = pcVar7 + 1;
                }
                fStackX_24 = (float)iVar5 * fVar18 + fVar20;
            }
            var_e8h._4_4_ = fStackX_24;
            if (pcVar7 < pcVar15) {
                fVar21 = fStackX_24;
                fVar19 = fStackX_24;
                do {
                    fVar2 = fStackX_24;
                    fVar19 = fVar19 + fVar18;
                    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
                    if (((((fVar19 < *(float *)(iVar10 + 700) || fVar19 == *(float *)(iVar10 + 700)) ||
                          (*(float *)(iVar10 + 0x2c4) <= fVar21)) ||
                         (fVar17 + 3.402823e+38 < *(float *)(iVar10 + 0x2b8) ||
                          fVar17 + 3.402823e+38 == *(float *)(iVar10 + 0x2b8))) ||
                        (*(float *)(iVar10 + 0x2c0) <= fVar17)) && (*(char *)(iVar14 + 0x1652) == '\0')) break;
                    pcVar8 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                    if (pcVar8 == (char *)0x0) {
                        pcVar8 = pcVar15;
                    }
                    pfVar9 = (float *)func_0x0001800fe0a0(&var_e0h, pcVar7, pcVar8, 0, 0xbf800000);
                    if (fVar22 <= *pfVar9) {
                        fVar22 = *pfVar9;
                    }
                    var_e8h._0_4_ = fVar22;
                    func_0x0001800f6cb0(CONCAT44(fStackX_24, fStackX_20), pcVar7, pcVar8);
                    fStackX_24 = fVar2 + fVar18;
                    pcVar7 = pcVar8 + 1;
                    fVar21 = fVar21 + fVar18;
                    iVar14 = *(int64_t *)0x180781f28;
                    fVar2 = fStackX_24;
                } while (pcVar7 < pcVar15);
                for (; fVar19 = fStackX_24, pcVar7 < pcVar15; pcVar7 = pcVar7 + 1) {
                    fStackX_24 = fVar2;
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    iVar13 = iVar13 + 1;
                    fVar2 = fStackX_24;
                    fStackX_24 = fVar19;
                }
                var_e8h._4_4_ = fStackX_24 + (float)iVar13 * fVar18;
                fStackX_24 = fVar2;
            }
            var_e8h._4_4_ = var_e8h._4_4_ - fVar20;
            fVar22 = fVar17 + fVar22;
            fVar18 = var_e8h._4_4_ + fVar20;
            func_0x00018010bbf0(&var_e8h, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar22;
            *(float *)(iVar14 + 0x1fd0) = fVar18;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar22;
            *(float *)(iVar14 + 0x1fe0) = fVar18;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if (((fVar18 < *(float *)(iVar10 + 700) || fVar18 == *(float *)(iVar10 + 700)) ||
                (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
               ((fVar22 < *(float *)(iVar10 + 0x2b8) || fVar22 == *(float *)(iVar10 + 0x2b8) ||
                (*(float *)(iVar10 + 0x2c0) <= fVar17)))) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar22;
            var_d8h._4_4_ = fVar18;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18013942f
// Address: 0x18013942f
// Size: 257 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_110h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.180139280(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    float fVar2;
    char cVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    char *pcVar8;
    float *pfVar9;
    int64_t iVar10;
    int64_t iVar11;
    char *pcVar12;
    int32_t iVar13;
    int64_t iVar14;
    char *pcVar15;
    int32_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    float fStackX_20;
    float fStackX_24;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
    if (*(char *)(iVar10 + 0x10e) == '\0') {
        pcVar7 = "";
        pcVar15 = "";
        if (arg1 != arg2) {
            pcVar7 = (char *)arg1;
            pcVar15 = (char *)arg2;
        }
        if (pcVar15 == (char *)0x0) {
            iVar6 = func_0x000180498cd0(pcVar7);
            pcVar15 = pcVar7 + iVar6;
        }
        fVar18 = *(float *)(iVar10 + 0x244);
        fVar17 = *(float *)(iVar10 + 0x158);
        fVar20 = *(float *)(iVar10 + 400) + *(float *)(iVar10 + 0x15c);
        var_e0h._0_4_ = fVar17;
        var_e0h._4_4_ = fVar20;
        if (((int64_t)pcVar15 - (int64_t)pcVar7 < 0x7d1) || (0.0 <= fVar18)) {
            if (fVar18 < 0.0) {
                fVar18 = 0.0;
            } else if (fVar18 == 0.0) {
                fVar18 = *(float *)(iVar10 + 0x2a0) - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            } else {
                if (0.0 < fVar18) {
                    fVar18 = (*(float *)(iVar10 + 0x60) - *(float *)(iVar10 + 0xd4)) + fVar18;
                }
                fVar18 = fVar18 - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            }
            var_118h = (int64_t)(uint32_t)fVar18;
            func_0x0001800fe0a0(&fStackX_20, pcVar7, pcVar15, 0, var_118h);
            fVar22 = fStackX_24 + fVar20;
            fVar19 = fVar17 + fStackX_20;
            func_0x00018010bbf0(&fStackX_20, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar19;
            *(float *)(iVar14 + 0x1fd0) = fVar22;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar19;
            *(float *)(iVar14 + 0x1fe0) = fVar22;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if ((((fVar22 < *(float *)(iVar10 + 700) || fVar22 == *(float *)(iVar10 + 700)) ||
                 (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
                (fVar19 < *(float *)(iVar10 + 0x2b8) || fVar19 == *(float *)(iVar10 + 0x2b8))) ||
               (*(float *)(iVar10 + 0x2c0) <= fVar17)) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar19;
            var_d8h._4_4_ = fVar22;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if (pcVar15 == (char *)0x0) {
                iVar10 = func_0x000180498cd0(pcVar7);
                pcVar15 = pcVar7 + iVar10;
            }
            if (pcVar7 != pcVar15) {
                var_e0h._0_4_ = *(float *)(iVar14 + 0xed0);
                var_e0h._4_4_ = *(float *)(iVar14 + 0xed4);
                var_d8h._0_4_ = *(float *)(iVar14 + 0xed8);
                var_d8h._4_4_ = *(float *)(iVar14 + 0xedc) * *(float *)(iVar14 + 0xd9c);
                uVar4 = func_0x0001800f5fa0(&var_e0h);
                iVar10 = iVar14;
                if (((uVar4 & 0xff000000) != 0) && (*pcVar7 != '\0')) {
                    iVar10 = *(int64_t *)(iVar14 + 0x12e8);
                    fVar17 = *(float *)(iVar14 + 0x12f8);
                    iVar6 = *(int64_t *)(*(int64_t *)(iVar14 + 0x15e0) + 800);
                    if (iVar10 == 0) {
                        iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x38) + 0x18);
                    }
                    if (fVar17 == 0.0) {
                        fVar17 = *(float *)(*(int64_t *)(iVar6 + 0x38) + 0x20);
                    }
                    var_e0h._0_4_ = *(float *)(iVar6 + 0x60);
                    var_e0h._4_4_ = *(float *)(iVar6 + 100);
                    var_d8h._0_4_ = *(float *)(iVar6 + 0x68);
                    var_d8h._4_4_ = *(float *)(iVar6 + 0x6c);
                    var_118h = (int64_t)uVar4;
                    func_0x00018012f9d0(iVar10, iVar6, fVar17, &fStackX_20, var_118h, &var_e0h, pcVar7, pcVar15, fVar18
                                        , 0);
                    iVar10 = *(int64_t *)0x180781f28;
                }
                if (*(char *)(iVar14 + 0x29f8) != '\0') {
                    iVar14 = *(int64_t *)(iVar10 + 0x2a20);
                    iVar6 = *(int64_t *)(iVar10 + 0x15e0);
                    iVar1 = *(int64_t *)(iVar10 + 0x2a28);
                    *(undefined8 *)(iVar10 + 0x2a28) = 0;
                    *(undefined8 *)(iVar10 + 0x2a20) = 0;
                    if ((pcVar15 == (char *)0x0) && (pcVar15 = pcVar7, pcVar7 != (char *)0xffffffffffffffff)) {
                        while (*pcVar15 != '\0') {
                            pcVar8 = pcVar15 + 1;
                            if (((*pcVar15 == '#') && (*pcVar8 == '#')) ||
                               (pcVar15 = pcVar8, pcVar8 == (char *)0xffffffffffffffff)) break;
                        }
                    }
                    fVar18 = *(float *)(iVar10 + 0xde0);
                    if (*(float *)(iVar10 + 0xde0) <= *(float *)(iVar10 + 0xdf0)) {
                        fVar18 = *(float *)(iVar10 + 0xdf0);
                    }
                    fVar17 = *(float *)(iVar10 + 0x2a30);
                    *(float *)(iVar10 + 0x2a30) = fStackX_24;
                    if (fVar18 + fVar17 + 1.0 < fStackX_24) {
                        func_0x0001801124e0(0x180644f68);
                        *(undefined *)(iVar10 + 0x29f9) = 1;
                    }
                    if (iVar14 != 0) {
                        iVar11 = func_0x000180498cd0(iVar14);
                        func_0x000180112520(&fStackX_20, iVar14, iVar14 + iVar11);
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    iVar5 = *(int32_t *)(iVar10 + 0x2a34);
                    if (iVar13 < iVar5) {
                        *(int32_t *)(iVar10 + 0x2a34) = iVar13;
                        iVar5 = iVar13;
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    while( true ) {
                        pcVar12 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                        pcVar8 = pcVar15;
                        if (pcVar12 != (char *)0x0) {
                            pcVar8 = pcVar12;
                        }
                        if ((pcVar7 == pcVar8) && (pcVar8 == pcVar15)) break;
                        iVar16 = (iVar13 - iVar5) * 4;
                        if (*(char *)(iVar10 + 0x29f9) == '\0') {
                            iVar16 = 1;
                        }
                        func_0x0001801124e0(0x180644f70, iVar16, 0x1805aadb1, (int32_t)pcVar8 - (int32_t)pcVar7, pcVar7)
                        ;
                        *(undefined *)(iVar10 + 0x29f9) = 0;
                        if (*pcVar8 == '\n') {
                            func_0x0001801124e0(0x180644f68);
                            *(undefined *)(iVar10 + 0x29f9) = 1;
                        }
                        if (pcVar8 == pcVar15) break;
                        pcVar7 = pcVar8 + 1;
                    }
                    if (iVar1 != 0) {
                        iVar10 = func_0x000180498cd0(iVar1);
                        func_0x000180112520(&fStackX_20, iVar1, iVar10 + iVar1);
                    }
                }
            }
        } else {
            fVar18 = *(float *)(iVar14 + 0x12f8);
            fVar22 = 0.0;
            var_e8h._0_4_ = 0.0;
            iVar13 = 0;
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if ((*(char *)(iVar14 + 0x29f8) == '\0') &&
               (iVar16 = (int32_t)((*(float *)(iVar10 + 700) - fVar20) / fVar18), iVar5 = iVar13, 0 < iVar16)) {
                for (; (pcVar7 < pcVar15 && (iVar5 < iVar16)); iVar5 = iVar5 + 1) {
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    pcVar7 = pcVar7 + 1;
                }
                fStackX_24 = (float)iVar5 * fVar18 + fVar20;
            }
            var_e8h._4_4_ = fStackX_24;
            if (pcVar7 < pcVar15) {
                fVar21 = fStackX_24;
                fVar19 = fStackX_24;
                do {
                    fVar2 = fStackX_24;
                    fVar19 = fVar19 + fVar18;
                    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
                    if (((((fVar19 < *(float *)(iVar10 + 700) || fVar19 == *(float *)(iVar10 + 700)) ||
                          (*(float *)(iVar10 + 0x2c4) <= fVar21)) ||
                         (fVar17 + 3.402823e+38 < *(float *)(iVar10 + 0x2b8) ||
                          fVar17 + 3.402823e+38 == *(float *)(iVar10 + 0x2b8))) ||
                        (*(float *)(iVar10 + 0x2c0) <= fVar17)) && (*(char *)(iVar14 + 0x1652) == '\0')) break;
                    pcVar8 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                    if (pcVar8 == (char *)0x0) {
                        pcVar8 = pcVar15;
                    }
                    pfVar9 = (float *)func_0x0001800fe0a0(&var_e0h, pcVar7, pcVar8, 0, 0xbf800000);
                    if (fVar22 <= *pfVar9) {
                        fVar22 = *pfVar9;
                    }
                    var_e8h._0_4_ = fVar22;
                    func_0x0001800f6cb0(CONCAT44(fStackX_24, fStackX_20), pcVar7, pcVar8);
                    fStackX_24 = fVar2 + fVar18;
                    pcVar7 = pcVar8 + 1;
                    fVar21 = fVar21 + fVar18;
                    iVar14 = *(int64_t *)0x180781f28;
                    fVar2 = fStackX_24;
                } while (pcVar7 < pcVar15);
                for (; fVar19 = fStackX_24, pcVar7 < pcVar15; pcVar7 = pcVar7 + 1) {
                    fStackX_24 = fVar2;
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    iVar13 = iVar13 + 1;
                    fVar2 = fStackX_24;
                    fStackX_24 = fVar19;
                }
                var_e8h._4_4_ = fStackX_24 + (float)iVar13 * fVar18;
                fStackX_24 = fVar2;
            }
            var_e8h._4_4_ = var_e8h._4_4_ - fVar20;
            fVar22 = fVar17 + fVar22;
            fVar18 = var_e8h._4_4_ + fVar20;
            func_0x00018010bbf0(&var_e8h, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar22;
            *(float *)(iVar14 + 0x1fd0) = fVar18;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar22;
            *(float *)(iVar14 + 0x1fe0) = fVar18;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if (((fVar18 < *(float *)(iVar10 + 700) || fVar18 == *(float *)(iVar10 + 700)) ||
                (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
               ((fVar22 < *(float *)(iVar10 + 0x2b8) || fVar22 == *(float *)(iVar10 + 0x2b8) ||
                (*(float *)(iVar10 + 0x2c0) <= fVar17)))) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar22;
            var_d8h._4_4_ = fVar18;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180139530
// Address: 0x180139530
// Size: 229 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_110h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.180139280(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    float fVar2;
    char cVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    char *pcVar8;
    float *pfVar9;
    int64_t iVar10;
    int64_t iVar11;
    char *pcVar12;
    int32_t iVar13;
    int64_t iVar14;
    char *pcVar15;
    int32_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    float fStackX_20;
    float fStackX_24;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
    if (*(char *)(iVar10 + 0x10e) == '\0') {
        pcVar7 = "";
        pcVar15 = "";
        if (arg1 != arg2) {
            pcVar7 = (char *)arg1;
            pcVar15 = (char *)arg2;
        }
        if (pcVar15 == (char *)0x0) {
            iVar6 = func_0x000180498cd0(pcVar7);
            pcVar15 = pcVar7 + iVar6;
        }
        fVar18 = *(float *)(iVar10 + 0x244);
        fVar17 = *(float *)(iVar10 + 0x158);
        fVar20 = *(float *)(iVar10 + 400) + *(float *)(iVar10 + 0x15c);
        var_e0h._0_4_ = fVar17;
        var_e0h._4_4_ = fVar20;
        if (((int64_t)pcVar15 - (int64_t)pcVar7 < 0x7d1) || (0.0 <= fVar18)) {
            if (fVar18 < 0.0) {
                fVar18 = 0.0;
            } else if (fVar18 == 0.0) {
                fVar18 = *(float *)(iVar10 + 0x2a0) - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            } else {
                if (0.0 < fVar18) {
                    fVar18 = (*(float *)(iVar10 + 0x60) - *(float *)(iVar10 + 0xd4)) + fVar18;
                }
                fVar18 = fVar18 - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            }
            var_118h = (int64_t)(uint32_t)fVar18;
            func_0x0001800fe0a0(&fStackX_20, pcVar7, pcVar15, 0, var_118h);
            fVar22 = fStackX_24 + fVar20;
            fVar19 = fVar17 + fStackX_20;
            func_0x00018010bbf0(&fStackX_20, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar19;
            *(float *)(iVar14 + 0x1fd0) = fVar22;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar19;
            *(float *)(iVar14 + 0x1fe0) = fVar22;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if ((((fVar22 < *(float *)(iVar10 + 700) || fVar22 == *(float *)(iVar10 + 700)) ||
                 (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
                (fVar19 < *(float *)(iVar10 + 0x2b8) || fVar19 == *(float *)(iVar10 + 0x2b8))) ||
               (*(float *)(iVar10 + 0x2c0) <= fVar17)) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar19;
            var_d8h._4_4_ = fVar22;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if (pcVar15 == (char *)0x0) {
                iVar10 = func_0x000180498cd0(pcVar7);
                pcVar15 = pcVar7 + iVar10;
            }
            if (pcVar7 != pcVar15) {
                var_e0h._0_4_ = *(float *)(iVar14 + 0xed0);
                var_e0h._4_4_ = *(float *)(iVar14 + 0xed4);
                var_d8h._0_4_ = *(float *)(iVar14 + 0xed8);
                var_d8h._4_4_ = *(float *)(iVar14 + 0xedc) * *(float *)(iVar14 + 0xd9c);
                uVar4 = func_0x0001800f5fa0(&var_e0h);
                iVar10 = iVar14;
                if (((uVar4 & 0xff000000) != 0) && (*pcVar7 != '\0')) {
                    iVar10 = *(int64_t *)(iVar14 + 0x12e8);
                    fVar17 = *(float *)(iVar14 + 0x12f8);
                    iVar6 = *(int64_t *)(*(int64_t *)(iVar14 + 0x15e0) + 800);
                    if (iVar10 == 0) {
                        iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x38) + 0x18);
                    }
                    if (fVar17 == 0.0) {
                        fVar17 = *(float *)(*(int64_t *)(iVar6 + 0x38) + 0x20);
                    }
                    var_e0h._0_4_ = *(float *)(iVar6 + 0x60);
                    var_e0h._4_4_ = *(float *)(iVar6 + 100);
                    var_d8h._0_4_ = *(float *)(iVar6 + 0x68);
                    var_d8h._4_4_ = *(float *)(iVar6 + 0x6c);
                    var_118h = (int64_t)uVar4;
                    func_0x00018012f9d0(iVar10, iVar6, fVar17, &fStackX_20, var_118h, &var_e0h, pcVar7, pcVar15, fVar18
                                        , 0);
                    iVar10 = *(int64_t *)0x180781f28;
                }
                if (*(char *)(iVar14 + 0x29f8) != '\0') {
                    iVar14 = *(int64_t *)(iVar10 + 0x2a20);
                    iVar6 = *(int64_t *)(iVar10 + 0x15e0);
                    iVar1 = *(int64_t *)(iVar10 + 0x2a28);
                    *(undefined8 *)(iVar10 + 0x2a28) = 0;
                    *(undefined8 *)(iVar10 + 0x2a20) = 0;
                    if ((pcVar15 == (char *)0x0) && (pcVar15 = pcVar7, pcVar7 != (char *)0xffffffffffffffff)) {
                        while (*pcVar15 != '\0') {
                            pcVar8 = pcVar15 + 1;
                            if (((*pcVar15 == '#') && (*pcVar8 == '#')) ||
                               (pcVar15 = pcVar8, pcVar8 == (char *)0xffffffffffffffff)) break;
                        }
                    }
                    fVar18 = *(float *)(iVar10 + 0xde0);
                    if (*(float *)(iVar10 + 0xde0) <= *(float *)(iVar10 + 0xdf0)) {
                        fVar18 = *(float *)(iVar10 + 0xdf0);
                    }
                    fVar17 = *(float *)(iVar10 + 0x2a30);
                    *(float *)(iVar10 + 0x2a30) = fStackX_24;
                    if (fVar18 + fVar17 + 1.0 < fStackX_24) {
                        func_0x0001801124e0(0x180644f68);
                        *(undefined *)(iVar10 + 0x29f9) = 1;
                    }
                    if (iVar14 != 0) {
                        iVar11 = func_0x000180498cd0(iVar14);
                        func_0x000180112520(&fStackX_20, iVar14, iVar14 + iVar11);
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    iVar5 = *(int32_t *)(iVar10 + 0x2a34);
                    if (iVar13 < iVar5) {
                        *(int32_t *)(iVar10 + 0x2a34) = iVar13;
                        iVar5 = iVar13;
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    while( true ) {
                        pcVar12 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                        pcVar8 = pcVar15;
                        if (pcVar12 != (char *)0x0) {
                            pcVar8 = pcVar12;
                        }
                        if ((pcVar7 == pcVar8) && (pcVar8 == pcVar15)) break;
                        iVar16 = (iVar13 - iVar5) * 4;
                        if (*(char *)(iVar10 + 0x29f9) == '\0') {
                            iVar16 = 1;
                        }
                        func_0x0001801124e0(0x180644f70, iVar16, 0x1805aadb1, (int32_t)pcVar8 - (int32_t)pcVar7, pcVar7)
                        ;
                        *(undefined *)(iVar10 + 0x29f9) = 0;
                        if (*pcVar8 == '\n') {
                            func_0x0001801124e0(0x180644f68);
                            *(undefined *)(iVar10 + 0x29f9) = 1;
                        }
                        if (pcVar8 == pcVar15) break;
                        pcVar7 = pcVar8 + 1;
                    }
                    if (iVar1 != 0) {
                        iVar10 = func_0x000180498cd0(iVar1);
                        func_0x000180112520(&fStackX_20, iVar1, iVar10 + iVar1);
                    }
                }
            }
        } else {
            fVar18 = *(float *)(iVar14 + 0x12f8);
            fVar22 = 0.0;
            var_e8h._0_4_ = 0.0;
            iVar13 = 0;
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if ((*(char *)(iVar14 + 0x29f8) == '\0') &&
               (iVar16 = (int32_t)((*(float *)(iVar10 + 700) - fVar20) / fVar18), iVar5 = iVar13, 0 < iVar16)) {
                for (; (pcVar7 < pcVar15 && (iVar5 < iVar16)); iVar5 = iVar5 + 1) {
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    pcVar7 = pcVar7 + 1;
                }
                fStackX_24 = (float)iVar5 * fVar18 + fVar20;
            }
            var_e8h._4_4_ = fStackX_24;
            if (pcVar7 < pcVar15) {
                fVar21 = fStackX_24;
                fVar19 = fStackX_24;
                do {
                    fVar2 = fStackX_24;
                    fVar19 = fVar19 + fVar18;
                    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
                    if (((((fVar19 < *(float *)(iVar10 + 700) || fVar19 == *(float *)(iVar10 + 700)) ||
                          (*(float *)(iVar10 + 0x2c4) <= fVar21)) ||
                         (fVar17 + 3.402823e+38 < *(float *)(iVar10 + 0x2b8) ||
                          fVar17 + 3.402823e+38 == *(float *)(iVar10 + 0x2b8))) ||
                        (*(float *)(iVar10 + 0x2c0) <= fVar17)) && (*(char *)(iVar14 + 0x1652) == '\0')) break;
                    pcVar8 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                    if (pcVar8 == (char *)0x0) {
                        pcVar8 = pcVar15;
                    }
                    pfVar9 = (float *)func_0x0001800fe0a0(&var_e0h, pcVar7, pcVar8, 0, 0xbf800000);
                    if (fVar22 <= *pfVar9) {
                        fVar22 = *pfVar9;
                    }
                    var_e8h._0_4_ = fVar22;
                    func_0x0001800f6cb0(CONCAT44(fStackX_24, fStackX_20), pcVar7, pcVar8);
                    fStackX_24 = fVar2 + fVar18;
                    pcVar7 = pcVar8 + 1;
                    fVar21 = fVar21 + fVar18;
                    iVar14 = *(int64_t *)0x180781f28;
                    fVar2 = fStackX_24;
                } while (pcVar7 < pcVar15);
                for (; fVar19 = fStackX_24, pcVar7 < pcVar15; pcVar7 = pcVar7 + 1) {
                    fStackX_24 = fVar2;
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    iVar13 = iVar13 + 1;
                    fVar2 = fStackX_24;
                    fStackX_24 = fVar19;
                }
                var_e8h._4_4_ = fStackX_24 + (float)iVar13 * fVar18;
                fStackX_24 = fVar2;
            }
            var_e8h._4_4_ = var_e8h._4_4_ - fVar20;
            fVar22 = fVar17 + fVar22;
            fVar18 = var_e8h._4_4_ + fVar20;
            func_0x00018010bbf0(&var_e8h, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar22;
            *(float *)(iVar14 + 0x1fd0) = fVar18;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar22;
            *(float *)(iVar14 + 0x1fe0) = fVar18;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if (((fVar18 < *(float *)(iVar10 + 700) || fVar18 == *(float *)(iVar10 + 700)) ||
                (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
               ((fVar22 < *(float *)(iVar10 + 0x2b8) || fVar22 == *(float *)(iVar10 + 0x2b8) ||
                (*(float *)(iVar10 + 0x2c0) <= fVar17)))) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar22;
            var_d8h._4_4_ = fVar18;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180139615
// Address: 0x180139615
// Size: 719 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_110h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.180139280(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    float fVar2;
    char cVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    char *pcVar8;
    float *pfVar9;
    int64_t iVar10;
    int64_t iVar11;
    char *pcVar12;
    int32_t iVar13;
    int64_t iVar14;
    char *pcVar15;
    int32_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    float fStackX_20;
    float fStackX_24;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
    if (*(char *)(iVar10 + 0x10e) == '\0') {
        pcVar7 = "";
        pcVar15 = "";
        if (arg1 != arg2) {
            pcVar7 = (char *)arg1;
            pcVar15 = (char *)arg2;
        }
        if (pcVar15 == (char *)0x0) {
            iVar6 = func_0x000180498cd0(pcVar7);
            pcVar15 = pcVar7 + iVar6;
        }
        fVar18 = *(float *)(iVar10 + 0x244);
        fVar17 = *(float *)(iVar10 + 0x158);
        fVar20 = *(float *)(iVar10 + 400) + *(float *)(iVar10 + 0x15c);
        var_e0h._0_4_ = fVar17;
        var_e0h._4_4_ = fVar20;
        if (((int64_t)pcVar15 - (int64_t)pcVar7 < 0x7d1) || (0.0 <= fVar18)) {
            if (fVar18 < 0.0) {
                fVar18 = 0.0;
            } else if (fVar18 == 0.0) {
                fVar18 = *(float *)(iVar10 + 0x2a0) - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            } else {
                if (0.0 < fVar18) {
                    fVar18 = (*(float *)(iVar10 + 0x60) - *(float *)(iVar10 + 0xd4)) + fVar18;
                }
                fVar18 = fVar18 - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            }
            var_118h = (int64_t)(uint32_t)fVar18;
            func_0x0001800fe0a0(&fStackX_20, pcVar7, pcVar15, 0, var_118h);
            fVar22 = fStackX_24 + fVar20;
            fVar19 = fVar17 + fStackX_20;
            func_0x00018010bbf0(&fStackX_20, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar19;
            *(float *)(iVar14 + 0x1fd0) = fVar22;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar19;
            *(float *)(iVar14 + 0x1fe0) = fVar22;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if ((((fVar22 < *(float *)(iVar10 + 700) || fVar22 == *(float *)(iVar10 + 700)) ||
                 (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
                (fVar19 < *(float *)(iVar10 + 0x2b8) || fVar19 == *(float *)(iVar10 + 0x2b8))) ||
               (*(float *)(iVar10 + 0x2c0) <= fVar17)) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar19;
            var_d8h._4_4_ = fVar22;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if (pcVar15 == (char *)0x0) {
                iVar10 = func_0x000180498cd0(pcVar7);
                pcVar15 = pcVar7 + iVar10;
            }
            if (pcVar7 != pcVar15) {
                var_e0h._0_4_ = *(float *)(iVar14 + 0xed0);
                var_e0h._4_4_ = *(float *)(iVar14 + 0xed4);
                var_d8h._0_4_ = *(float *)(iVar14 + 0xed8);
                var_d8h._4_4_ = *(float *)(iVar14 + 0xedc) * *(float *)(iVar14 + 0xd9c);
                uVar4 = func_0x0001800f5fa0(&var_e0h);
                iVar10 = iVar14;
                if (((uVar4 & 0xff000000) != 0) && (*pcVar7 != '\0')) {
                    iVar10 = *(int64_t *)(iVar14 + 0x12e8);
                    fVar17 = *(float *)(iVar14 + 0x12f8);
                    iVar6 = *(int64_t *)(*(int64_t *)(iVar14 + 0x15e0) + 800);
                    if (iVar10 == 0) {
                        iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x38) + 0x18);
                    }
                    if (fVar17 == 0.0) {
                        fVar17 = *(float *)(*(int64_t *)(iVar6 + 0x38) + 0x20);
                    }
                    var_e0h._0_4_ = *(float *)(iVar6 + 0x60);
                    var_e0h._4_4_ = *(float *)(iVar6 + 100);
                    var_d8h._0_4_ = *(float *)(iVar6 + 0x68);
                    var_d8h._4_4_ = *(float *)(iVar6 + 0x6c);
                    var_118h = (int64_t)uVar4;
                    func_0x00018012f9d0(iVar10, iVar6, fVar17, &fStackX_20, var_118h, &var_e0h, pcVar7, pcVar15, fVar18
                                        , 0);
                    iVar10 = *(int64_t *)0x180781f28;
                }
                if (*(char *)(iVar14 + 0x29f8) != '\0') {
                    iVar14 = *(int64_t *)(iVar10 + 0x2a20);
                    iVar6 = *(int64_t *)(iVar10 + 0x15e0);
                    iVar1 = *(int64_t *)(iVar10 + 0x2a28);
                    *(undefined8 *)(iVar10 + 0x2a28) = 0;
                    *(undefined8 *)(iVar10 + 0x2a20) = 0;
                    if ((pcVar15 == (char *)0x0) && (pcVar15 = pcVar7, pcVar7 != (char *)0xffffffffffffffff)) {
                        while (*pcVar15 != '\0') {
                            pcVar8 = pcVar15 + 1;
                            if (((*pcVar15 == '#') && (*pcVar8 == '#')) ||
                               (pcVar15 = pcVar8, pcVar8 == (char *)0xffffffffffffffff)) break;
                        }
                    }
                    fVar18 = *(float *)(iVar10 + 0xde0);
                    if (*(float *)(iVar10 + 0xde0) <= *(float *)(iVar10 + 0xdf0)) {
                        fVar18 = *(float *)(iVar10 + 0xdf0);
                    }
                    fVar17 = *(float *)(iVar10 + 0x2a30);
                    *(float *)(iVar10 + 0x2a30) = fStackX_24;
                    if (fVar18 + fVar17 + 1.0 < fStackX_24) {
                        func_0x0001801124e0(0x180644f68);
                        *(undefined *)(iVar10 + 0x29f9) = 1;
                    }
                    if (iVar14 != 0) {
                        iVar11 = func_0x000180498cd0(iVar14);
                        func_0x000180112520(&fStackX_20, iVar14, iVar14 + iVar11);
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    iVar5 = *(int32_t *)(iVar10 + 0x2a34);
                    if (iVar13 < iVar5) {
                        *(int32_t *)(iVar10 + 0x2a34) = iVar13;
                        iVar5 = iVar13;
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    while( true ) {
                        pcVar12 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                        pcVar8 = pcVar15;
                        if (pcVar12 != (char *)0x0) {
                            pcVar8 = pcVar12;
                        }
                        if ((pcVar7 == pcVar8) && (pcVar8 == pcVar15)) break;
                        iVar16 = (iVar13 - iVar5) * 4;
                        if (*(char *)(iVar10 + 0x29f9) == '\0') {
                            iVar16 = 1;
                        }
                        func_0x0001801124e0(0x180644f70, iVar16, 0x1805aadb1, (int32_t)pcVar8 - (int32_t)pcVar7, pcVar7)
                        ;
                        *(undefined *)(iVar10 + 0x29f9) = 0;
                        if (*pcVar8 == '\n') {
                            func_0x0001801124e0(0x180644f68);
                            *(undefined *)(iVar10 + 0x29f9) = 1;
                        }
                        if (pcVar8 == pcVar15) break;
                        pcVar7 = pcVar8 + 1;
                    }
                    if (iVar1 != 0) {
                        iVar10 = func_0x000180498cd0(iVar1);
                        func_0x000180112520(&fStackX_20, iVar1, iVar10 + iVar1);
                    }
                }
            }
        } else {
            fVar18 = *(float *)(iVar14 + 0x12f8);
            fVar22 = 0.0;
            var_e8h._0_4_ = 0.0;
            iVar13 = 0;
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if ((*(char *)(iVar14 + 0x29f8) == '\0') &&
               (iVar16 = (int32_t)((*(float *)(iVar10 + 700) - fVar20) / fVar18), iVar5 = iVar13, 0 < iVar16)) {
                for (; (pcVar7 < pcVar15 && (iVar5 < iVar16)); iVar5 = iVar5 + 1) {
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    pcVar7 = pcVar7 + 1;
                }
                fStackX_24 = (float)iVar5 * fVar18 + fVar20;
            }
            var_e8h._4_4_ = fStackX_24;
            if (pcVar7 < pcVar15) {
                fVar21 = fStackX_24;
                fVar19 = fStackX_24;
                do {
                    fVar2 = fStackX_24;
                    fVar19 = fVar19 + fVar18;
                    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
                    if (((((fVar19 < *(float *)(iVar10 + 700) || fVar19 == *(float *)(iVar10 + 700)) ||
                          (*(float *)(iVar10 + 0x2c4) <= fVar21)) ||
                         (fVar17 + 3.402823e+38 < *(float *)(iVar10 + 0x2b8) ||
                          fVar17 + 3.402823e+38 == *(float *)(iVar10 + 0x2b8))) ||
                        (*(float *)(iVar10 + 0x2c0) <= fVar17)) && (*(char *)(iVar14 + 0x1652) == '\0')) break;
                    pcVar8 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                    if (pcVar8 == (char *)0x0) {
                        pcVar8 = pcVar15;
                    }
                    pfVar9 = (float *)func_0x0001800fe0a0(&var_e0h, pcVar7, pcVar8, 0, 0xbf800000);
                    if (fVar22 <= *pfVar9) {
                        fVar22 = *pfVar9;
                    }
                    var_e8h._0_4_ = fVar22;
                    func_0x0001800f6cb0(CONCAT44(fStackX_24, fStackX_20), pcVar7, pcVar8);
                    fStackX_24 = fVar2 + fVar18;
                    pcVar7 = pcVar8 + 1;
                    fVar21 = fVar21 + fVar18;
                    iVar14 = *(int64_t *)0x180781f28;
                    fVar2 = fStackX_24;
                } while (pcVar7 < pcVar15);
                for (; fVar19 = fStackX_24, pcVar7 < pcVar15; pcVar7 = pcVar7 + 1) {
                    fStackX_24 = fVar2;
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    iVar13 = iVar13 + 1;
                    fVar2 = fStackX_24;
                    fStackX_24 = fVar19;
                }
                var_e8h._4_4_ = fStackX_24 + (float)iVar13 * fVar18;
                fStackX_24 = fVar2;
            }
            var_e8h._4_4_ = var_e8h._4_4_ - fVar20;
            fVar22 = fVar17 + fVar22;
            fVar18 = var_e8h._4_4_ + fVar20;
            func_0x00018010bbf0(&var_e8h, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar22;
            *(float *)(iVar14 + 0x1fd0) = fVar18;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar22;
            *(float *)(iVar14 + 0x1fe0) = fVar18;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if (((fVar18 < *(float *)(iVar10 + 700) || fVar18 == *(float *)(iVar10 + 700)) ||
                (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
               ((fVar22 < *(float *)(iVar10 + 0x2b8) || fVar22 == *(float *)(iVar10 + 0x2b8) ||
                (*(float *)(iVar10 + 0x2c0) <= fVar17)))) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar22;
            var_d8h._4_4_ = fVar18;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801398e4
// Address: 0x1801398e4
// Size: 394 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_110h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.180139280(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    float fVar2;
    char cVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    char *pcVar8;
    float *pfVar9;
    int64_t iVar10;
    int64_t iVar11;
    char *pcVar12;
    int32_t iVar13;
    int64_t iVar14;
    char *pcVar15;
    int32_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    float fStackX_20;
    float fStackX_24;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
    if (*(char *)(iVar10 + 0x10e) == '\0') {
        pcVar7 = "";
        pcVar15 = "";
        if (arg1 != arg2) {
            pcVar7 = (char *)arg1;
            pcVar15 = (char *)arg2;
        }
        if (pcVar15 == (char *)0x0) {
            iVar6 = func_0x000180498cd0(pcVar7);
            pcVar15 = pcVar7 + iVar6;
        }
        fVar18 = *(float *)(iVar10 + 0x244);
        fVar17 = *(float *)(iVar10 + 0x158);
        fVar20 = *(float *)(iVar10 + 400) + *(float *)(iVar10 + 0x15c);
        var_e0h._0_4_ = fVar17;
        var_e0h._4_4_ = fVar20;
        if (((int64_t)pcVar15 - (int64_t)pcVar7 < 0x7d1) || (0.0 <= fVar18)) {
            if (fVar18 < 0.0) {
                fVar18 = 0.0;
            } else if (fVar18 == 0.0) {
                fVar18 = *(float *)(iVar10 + 0x2a0) - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            } else {
                if (0.0 < fVar18) {
                    fVar18 = (*(float *)(iVar10 + 0x60) - *(float *)(iVar10 + 0xd4)) + fVar18;
                }
                fVar18 = fVar18 - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            }
            var_118h = (int64_t)(uint32_t)fVar18;
            func_0x0001800fe0a0(&fStackX_20, pcVar7, pcVar15, 0, var_118h);
            fVar22 = fStackX_24 + fVar20;
            fVar19 = fVar17 + fStackX_20;
            func_0x00018010bbf0(&fStackX_20, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar19;
            *(float *)(iVar14 + 0x1fd0) = fVar22;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar19;
            *(float *)(iVar14 + 0x1fe0) = fVar22;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if ((((fVar22 < *(float *)(iVar10 + 700) || fVar22 == *(float *)(iVar10 + 700)) ||
                 (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
                (fVar19 < *(float *)(iVar10 + 0x2b8) || fVar19 == *(float *)(iVar10 + 0x2b8))) ||
               (*(float *)(iVar10 + 0x2c0) <= fVar17)) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar19;
            var_d8h._4_4_ = fVar22;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if (pcVar15 == (char *)0x0) {
                iVar10 = func_0x000180498cd0(pcVar7);
                pcVar15 = pcVar7 + iVar10;
            }
            if (pcVar7 != pcVar15) {
                var_e0h._0_4_ = *(float *)(iVar14 + 0xed0);
                var_e0h._4_4_ = *(float *)(iVar14 + 0xed4);
                var_d8h._0_4_ = *(float *)(iVar14 + 0xed8);
                var_d8h._4_4_ = *(float *)(iVar14 + 0xedc) * *(float *)(iVar14 + 0xd9c);
                uVar4 = func_0x0001800f5fa0(&var_e0h);
                iVar10 = iVar14;
                if (((uVar4 & 0xff000000) != 0) && (*pcVar7 != '\0')) {
                    iVar10 = *(int64_t *)(iVar14 + 0x12e8);
                    fVar17 = *(float *)(iVar14 + 0x12f8);
                    iVar6 = *(int64_t *)(*(int64_t *)(iVar14 + 0x15e0) + 800);
                    if (iVar10 == 0) {
                        iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x38) + 0x18);
                    }
                    if (fVar17 == 0.0) {
                        fVar17 = *(float *)(*(int64_t *)(iVar6 + 0x38) + 0x20);
                    }
                    var_e0h._0_4_ = *(float *)(iVar6 + 0x60);
                    var_e0h._4_4_ = *(float *)(iVar6 + 100);
                    var_d8h._0_4_ = *(float *)(iVar6 + 0x68);
                    var_d8h._4_4_ = *(float *)(iVar6 + 0x6c);
                    var_118h = (int64_t)uVar4;
                    func_0x00018012f9d0(iVar10, iVar6, fVar17, &fStackX_20, var_118h, &var_e0h, pcVar7, pcVar15, fVar18
                                        , 0);
                    iVar10 = *(int64_t *)0x180781f28;
                }
                if (*(char *)(iVar14 + 0x29f8) != '\0') {
                    iVar14 = *(int64_t *)(iVar10 + 0x2a20);
                    iVar6 = *(int64_t *)(iVar10 + 0x15e0);
                    iVar1 = *(int64_t *)(iVar10 + 0x2a28);
                    *(undefined8 *)(iVar10 + 0x2a28) = 0;
                    *(undefined8 *)(iVar10 + 0x2a20) = 0;
                    if ((pcVar15 == (char *)0x0) && (pcVar15 = pcVar7, pcVar7 != (char *)0xffffffffffffffff)) {
                        while (*pcVar15 != '\0') {
                            pcVar8 = pcVar15 + 1;
                            if (((*pcVar15 == '#') && (*pcVar8 == '#')) ||
                               (pcVar15 = pcVar8, pcVar8 == (char *)0xffffffffffffffff)) break;
                        }
                    }
                    fVar18 = *(float *)(iVar10 + 0xde0);
                    if (*(float *)(iVar10 + 0xde0) <= *(float *)(iVar10 + 0xdf0)) {
                        fVar18 = *(float *)(iVar10 + 0xdf0);
                    }
                    fVar17 = *(float *)(iVar10 + 0x2a30);
                    *(float *)(iVar10 + 0x2a30) = fStackX_24;
                    if (fVar18 + fVar17 + 1.0 < fStackX_24) {
                        func_0x0001801124e0(0x180644f68);
                        *(undefined *)(iVar10 + 0x29f9) = 1;
                    }
                    if (iVar14 != 0) {
                        iVar11 = func_0x000180498cd0(iVar14);
                        func_0x000180112520(&fStackX_20, iVar14, iVar14 + iVar11);
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    iVar5 = *(int32_t *)(iVar10 + 0x2a34);
                    if (iVar13 < iVar5) {
                        *(int32_t *)(iVar10 + 0x2a34) = iVar13;
                        iVar5 = iVar13;
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    while( true ) {
                        pcVar12 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                        pcVar8 = pcVar15;
                        if (pcVar12 != (char *)0x0) {
                            pcVar8 = pcVar12;
                        }
                        if ((pcVar7 == pcVar8) && (pcVar8 == pcVar15)) break;
                        iVar16 = (iVar13 - iVar5) * 4;
                        if (*(char *)(iVar10 + 0x29f9) == '\0') {
                            iVar16 = 1;
                        }
                        func_0x0001801124e0(0x180644f70, iVar16, 0x1805aadb1, (int32_t)pcVar8 - (int32_t)pcVar7, pcVar7)
                        ;
                        *(undefined *)(iVar10 + 0x29f9) = 0;
                        if (*pcVar8 == '\n') {
                            func_0x0001801124e0(0x180644f68);
                            *(undefined *)(iVar10 + 0x29f9) = 1;
                        }
                        if (pcVar8 == pcVar15) break;
                        pcVar7 = pcVar8 + 1;
                    }
                    if (iVar1 != 0) {
                        iVar10 = func_0x000180498cd0(iVar1);
                        func_0x000180112520(&fStackX_20, iVar1, iVar10 + iVar1);
                    }
                }
            }
        } else {
            fVar18 = *(float *)(iVar14 + 0x12f8);
            fVar22 = 0.0;
            var_e8h._0_4_ = 0.0;
            iVar13 = 0;
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if ((*(char *)(iVar14 + 0x29f8) == '\0') &&
               (iVar16 = (int32_t)((*(float *)(iVar10 + 700) - fVar20) / fVar18), iVar5 = iVar13, 0 < iVar16)) {
                for (; (pcVar7 < pcVar15 && (iVar5 < iVar16)); iVar5 = iVar5 + 1) {
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    pcVar7 = pcVar7 + 1;
                }
                fStackX_24 = (float)iVar5 * fVar18 + fVar20;
            }
            var_e8h._4_4_ = fStackX_24;
            if (pcVar7 < pcVar15) {
                fVar21 = fStackX_24;
                fVar19 = fStackX_24;
                do {
                    fVar2 = fStackX_24;
                    fVar19 = fVar19 + fVar18;
                    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
                    if (((((fVar19 < *(float *)(iVar10 + 700) || fVar19 == *(float *)(iVar10 + 700)) ||
                          (*(float *)(iVar10 + 0x2c4) <= fVar21)) ||
                         (fVar17 + 3.402823e+38 < *(float *)(iVar10 + 0x2b8) ||
                          fVar17 + 3.402823e+38 == *(float *)(iVar10 + 0x2b8))) ||
                        (*(float *)(iVar10 + 0x2c0) <= fVar17)) && (*(char *)(iVar14 + 0x1652) == '\0')) break;
                    pcVar8 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                    if (pcVar8 == (char *)0x0) {
                        pcVar8 = pcVar15;
                    }
                    pfVar9 = (float *)func_0x0001800fe0a0(&var_e0h, pcVar7, pcVar8, 0, 0xbf800000);
                    if (fVar22 <= *pfVar9) {
                        fVar22 = *pfVar9;
                    }
                    var_e8h._0_4_ = fVar22;
                    func_0x0001800f6cb0(CONCAT44(fStackX_24, fStackX_20), pcVar7, pcVar8);
                    fStackX_24 = fVar2 + fVar18;
                    pcVar7 = pcVar8 + 1;
                    fVar21 = fVar21 + fVar18;
                    iVar14 = *(int64_t *)0x180781f28;
                    fVar2 = fStackX_24;
                } while (pcVar7 < pcVar15);
                for (; fVar19 = fStackX_24, pcVar7 < pcVar15; pcVar7 = pcVar7 + 1) {
                    fStackX_24 = fVar2;
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    iVar13 = iVar13 + 1;
                    fVar2 = fStackX_24;
                    fStackX_24 = fVar19;
                }
                var_e8h._4_4_ = fStackX_24 + (float)iVar13 * fVar18;
                fStackX_24 = fVar2;
            }
            var_e8h._4_4_ = var_e8h._4_4_ - fVar20;
            fVar22 = fVar17 + fVar22;
            fVar18 = var_e8h._4_4_ + fVar20;
            func_0x00018010bbf0(&var_e8h, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar22;
            *(float *)(iVar14 + 0x1fd0) = fVar18;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar22;
            *(float *)(iVar14 + 0x1fe0) = fVar18;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if (((fVar18 < *(float *)(iVar10 + 700) || fVar18 == *(float *)(iVar10 + 700)) ||
                (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
               ((fVar22 < *(float *)(iVar10 + 0x2b8) || fVar22 == *(float *)(iVar10 + 0x2b8) ||
                (*(float *)(iVar10 + 0x2c0) <= fVar17)))) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar22;
            var_d8h._4_4_ = fVar18;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180139a6e
// Address: 0x180139a6e
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_110h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.180139280(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    float fVar2;
    char cVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    char *pcVar8;
    float *pfVar9;
    int64_t iVar10;
    int64_t iVar11;
    char *pcVar12;
    int32_t iVar13;
    int64_t iVar14;
    char *pcVar15;
    int32_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    float fStackX_20;
    float fStackX_24;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
    if (*(char *)(iVar10 + 0x10e) == '\0') {
        pcVar7 = "";
        pcVar15 = "";
        if (arg1 != arg2) {
            pcVar7 = (char *)arg1;
            pcVar15 = (char *)arg2;
        }
        if (pcVar15 == (char *)0x0) {
            iVar6 = func_0x000180498cd0(pcVar7);
            pcVar15 = pcVar7 + iVar6;
        }
        fVar18 = *(float *)(iVar10 + 0x244);
        fVar17 = *(float *)(iVar10 + 0x158);
        fVar20 = *(float *)(iVar10 + 400) + *(float *)(iVar10 + 0x15c);
        var_e0h._0_4_ = fVar17;
        var_e0h._4_4_ = fVar20;
        if (((int64_t)pcVar15 - (int64_t)pcVar7 < 0x7d1) || (0.0 <= fVar18)) {
            if (fVar18 < 0.0) {
                fVar18 = 0.0;
            } else if (fVar18 == 0.0) {
                fVar18 = *(float *)(iVar10 + 0x2a0) - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            } else {
                if (0.0 < fVar18) {
                    fVar18 = (*(float *)(iVar10 + 0x60) - *(float *)(iVar10 + 0xd4)) + fVar18;
                }
                fVar18 = fVar18 - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            }
            var_118h = (int64_t)(uint32_t)fVar18;
            func_0x0001800fe0a0(&fStackX_20, pcVar7, pcVar15, 0, var_118h);
            fVar22 = fStackX_24 + fVar20;
            fVar19 = fVar17 + fStackX_20;
            func_0x00018010bbf0(&fStackX_20, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar19;
            *(float *)(iVar14 + 0x1fd0) = fVar22;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar19;
            *(float *)(iVar14 + 0x1fe0) = fVar22;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if ((((fVar22 < *(float *)(iVar10 + 700) || fVar22 == *(float *)(iVar10 + 700)) ||
                 (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
                (fVar19 < *(float *)(iVar10 + 0x2b8) || fVar19 == *(float *)(iVar10 + 0x2b8))) ||
               (*(float *)(iVar10 + 0x2c0) <= fVar17)) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar19;
            var_d8h._4_4_ = fVar22;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if (pcVar15 == (char *)0x0) {
                iVar10 = func_0x000180498cd0(pcVar7);
                pcVar15 = pcVar7 + iVar10;
            }
            if (pcVar7 != pcVar15) {
                var_e0h._0_4_ = *(float *)(iVar14 + 0xed0);
                var_e0h._4_4_ = *(float *)(iVar14 + 0xed4);
                var_d8h._0_4_ = *(float *)(iVar14 + 0xed8);
                var_d8h._4_4_ = *(float *)(iVar14 + 0xedc) * *(float *)(iVar14 + 0xd9c);
                uVar4 = func_0x0001800f5fa0(&var_e0h);
                iVar10 = iVar14;
                if (((uVar4 & 0xff000000) != 0) && (*pcVar7 != '\0')) {
                    iVar10 = *(int64_t *)(iVar14 + 0x12e8);
                    fVar17 = *(float *)(iVar14 + 0x12f8);
                    iVar6 = *(int64_t *)(*(int64_t *)(iVar14 + 0x15e0) + 800);
                    if (iVar10 == 0) {
                        iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x38) + 0x18);
                    }
                    if (fVar17 == 0.0) {
                        fVar17 = *(float *)(*(int64_t *)(iVar6 + 0x38) + 0x20);
                    }
                    var_e0h._0_4_ = *(float *)(iVar6 + 0x60);
                    var_e0h._4_4_ = *(float *)(iVar6 + 100);
                    var_d8h._0_4_ = *(float *)(iVar6 + 0x68);
                    var_d8h._4_4_ = *(float *)(iVar6 + 0x6c);
                    var_118h = (int64_t)uVar4;
                    func_0x00018012f9d0(iVar10, iVar6, fVar17, &fStackX_20, var_118h, &var_e0h, pcVar7, pcVar15, fVar18
                                        , 0);
                    iVar10 = *(int64_t *)0x180781f28;
                }
                if (*(char *)(iVar14 + 0x29f8) != '\0') {
                    iVar14 = *(int64_t *)(iVar10 + 0x2a20);
                    iVar6 = *(int64_t *)(iVar10 + 0x15e0);
                    iVar1 = *(int64_t *)(iVar10 + 0x2a28);
                    *(undefined8 *)(iVar10 + 0x2a28) = 0;
                    *(undefined8 *)(iVar10 + 0x2a20) = 0;
                    if ((pcVar15 == (char *)0x0) && (pcVar15 = pcVar7, pcVar7 != (char *)0xffffffffffffffff)) {
                        while (*pcVar15 != '\0') {
                            pcVar8 = pcVar15 + 1;
                            if (((*pcVar15 == '#') && (*pcVar8 == '#')) ||
                               (pcVar15 = pcVar8, pcVar8 == (char *)0xffffffffffffffff)) break;
                        }
                    }
                    fVar18 = *(float *)(iVar10 + 0xde0);
                    if (*(float *)(iVar10 + 0xde0) <= *(float *)(iVar10 + 0xdf0)) {
                        fVar18 = *(float *)(iVar10 + 0xdf0);
                    }
                    fVar17 = *(float *)(iVar10 + 0x2a30);
                    *(float *)(iVar10 + 0x2a30) = fStackX_24;
                    if (fVar18 + fVar17 + 1.0 < fStackX_24) {
                        func_0x0001801124e0(0x180644f68);
                        *(undefined *)(iVar10 + 0x29f9) = 1;
                    }
                    if (iVar14 != 0) {
                        iVar11 = func_0x000180498cd0(iVar14);
                        func_0x000180112520(&fStackX_20, iVar14, iVar14 + iVar11);
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    iVar5 = *(int32_t *)(iVar10 + 0x2a34);
                    if (iVar13 < iVar5) {
                        *(int32_t *)(iVar10 + 0x2a34) = iVar13;
                        iVar5 = iVar13;
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    while( true ) {
                        pcVar12 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                        pcVar8 = pcVar15;
                        if (pcVar12 != (char *)0x0) {
                            pcVar8 = pcVar12;
                        }
                        if ((pcVar7 == pcVar8) && (pcVar8 == pcVar15)) break;
                        iVar16 = (iVar13 - iVar5) * 4;
                        if (*(char *)(iVar10 + 0x29f9) == '\0') {
                            iVar16 = 1;
                        }
                        func_0x0001801124e0(0x180644f70, iVar16, 0x1805aadb1, (int32_t)pcVar8 - (int32_t)pcVar7, pcVar7)
                        ;
                        *(undefined *)(iVar10 + 0x29f9) = 0;
                        if (*pcVar8 == '\n') {
                            func_0x0001801124e0(0x180644f68);
                            *(undefined *)(iVar10 + 0x29f9) = 1;
                        }
                        if (pcVar8 == pcVar15) break;
                        pcVar7 = pcVar8 + 1;
                    }
                    if (iVar1 != 0) {
                        iVar10 = func_0x000180498cd0(iVar1);
                        func_0x000180112520(&fStackX_20, iVar1, iVar10 + iVar1);
                    }
                }
            }
        } else {
            fVar18 = *(float *)(iVar14 + 0x12f8);
            fVar22 = 0.0;
            var_e8h._0_4_ = 0.0;
            iVar13 = 0;
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if ((*(char *)(iVar14 + 0x29f8) == '\0') &&
               (iVar16 = (int32_t)((*(float *)(iVar10 + 700) - fVar20) / fVar18), iVar5 = iVar13, 0 < iVar16)) {
                for (; (pcVar7 < pcVar15 && (iVar5 < iVar16)); iVar5 = iVar5 + 1) {
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    pcVar7 = pcVar7 + 1;
                }
                fStackX_24 = (float)iVar5 * fVar18 + fVar20;
            }
            var_e8h._4_4_ = fStackX_24;
            if (pcVar7 < pcVar15) {
                fVar21 = fStackX_24;
                fVar19 = fStackX_24;
                do {
                    fVar2 = fStackX_24;
                    fVar19 = fVar19 + fVar18;
                    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
                    if (((((fVar19 < *(float *)(iVar10 + 700) || fVar19 == *(float *)(iVar10 + 700)) ||
                          (*(float *)(iVar10 + 0x2c4) <= fVar21)) ||
                         (fVar17 + 3.402823e+38 < *(float *)(iVar10 + 0x2b8) ||
                          fVar17 + 3.402823e+38 == *(float *)(iVar10 + 0x2b8))) ||
                        (*(float *)(iVar10 + 0x2c0) <= fVar17)) && (*(char *)(iVar14 + 0x1652) == '\0')) break;
                    pcVar8 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                    if (pcVar8 == (char *)0x0) {
                        pcVar8 = pcVar15;
                    }
                    pfVar9 = (float *)func_0x0001800fe0a0(&var_e0h, pcVar7, pcVar8, 0, 0xbf800000);
                    if (fVar22 <= *pfVar9) {
                        fVar22 = *pfVar9;
                    }
                    var_e8h._0_4_ = fVar22;
                    func_0x0001800f6cb0(CONCAT44(fStackX_24, fStackX_20), pcVar7, pcVar8);
                    fStackX_24 = fVar2 + fVar18;
                    pcVar7 = pcVar8 + 1;
                    fVar21 = fVar21 + fVar18;
                    iVar14 = *(int64_t *)0x180781f28;
                    fVar2 = fStackX_24;
                } while (pcVar7 < pcVar15);
                for (; fVar19 = fStackX_24, pcVar7 < pcVar15; pcVar7 = pcVar7 + 1) {
                    fStackX_24 = fVar2;
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    iVar13 = iVar13 + 1;
                    fVar2 = fStackX_24;
                    fStackX_24 = fVar19;
                }
                var_e8h._4_4_ = fStackX_24 + (float)iVar13 * fVar18;
                fStackX_24 = fVar2;
            }
            var_e8h._4_4_ = var_e8h._4_4_ - fVar20;
            fVar22 = fVar17 + fVar22;
            fVar18 = var_e8h._4_4_ + fVar20;
            func_0x00018010bbf0(&var_e8h, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar22;
            *(float *)(iVar14 + 0x1fd0) = fVar18;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar22;
            *(float *)(iVar14 + 0x1fe0) = fVar18;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if (((fVar18 < *(float *)(iVar10 + 700) || fVar18 == *(float *)(iVar10 + 700)) ||
                (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
               ((fVar22 < *(float *)(iVar10 + 0x2b8) || fVar22 == *(float *)(iVar10 + 0x2b8) ||
                (*(float *)(iVar10 + 0x2c0) <= fVar17)))) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar22;
            var_d8h._4_4_ = fVar18;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180139acb
// Address: 0x180139acb
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_110h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.180139280(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    float fVar2;
    char cVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    char *pcVar8;
    float *pfVar9;
    int64_t iVar10;
    int64_t iVar11;
    char *pcVar12;
    int32_t iVar13;
    int64_t iVar14;
    char *pcVar15;
    int32_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    float fStackX_20;
    float fStackX_24;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
    if (*(char *)(iVar10 + 0x10e) == '\0') {
        pcVar7 = "";
        pcVar15 = "";
        if (arg1 != arg2) {
            pcVar7 = (char *)arg1;
            pcVar15 = (char *)arg2;
        }
        if (pcVar15 == (char *)0x0) {
            iVar6 = func_0x000180498cd0(pcVar7);
            pcVar15 = pcVar7 + iVar6;
        }
        fVar18 = *(float *)(iVar10 + 0x244);
        fVar17 = *(float *)(iVar10 + 0x158);
        fVar20 = *(float *)(iVar10 + 400) + *(float *)(iVar10 + 0x15c);
        var_e0h._0_4_ = fVar17;
        var_e0h._4_4_ = fVar20;
        if (((int64_t)pcVar15 - (int64_t)pcVar7 < 0x7d1) || (0.0 <= fVar18)) {
            if (fVar18 < 0.0) {
                fVar18 = 0.0;
            } else if (fVar18 == 0.0) {
                fVar18 = *(float *)(iVar10 + 0x2a0) - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            } else {
                if (0.0 < fVar18) {
                    fVar18 = (*(float *)(iVar10 + 0x60) - *(float *)(iVar10 + 0xd4)) + fVar18;
                }
                fVar18 = fVar18 - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            }
            var_118h = (int64_t)(uint32_t)fVar18;
            func_0x0001800fe0a0(&fStackX_20, pcVar7, pcVar15, 0, var_118h);
            fVar22 = fStackX_24 + fVar20;
            fVar19 = fVar17 + fStackX_20;
            func_0x00018010bbf0(&fStackX_20, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar19;
            *(float *)(iVar14 + 0x1fd0) = fVar22;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar19;
            *(float *)(iVar14 + 0x1fe0) = fVar22;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if ((((fVar22 < *(float *)(iVar10 + 700) || fVar22 == *(float *)(iVar10 + 700)) ||
                 (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
                (fVar19 < *(float *)(iVar10 + 0x2b8) || fVar19 == *(float *)(iVar10 + 0x2b8))) ||
               (*(float *)(iVar10 + 0x2c0) <= fVar17)) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar19;
            var_d8h._4_4_ = fVar22;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if (pcVar15 == (char *)0x0) {
                iVar10 = func_0x000180498cd0(pcVar7);
                pcVar15 = pcVar7 + iVar10;
            }
            if (pcVar7 != pcVar15) {
                var_e0h._0_4_ = *(float *)(iVar14 + 0xed0);
                var_e0h._4_4_ = *(float *)(iVar14 + 0xed4);
                var_d8h._0_4_ = *(float *)(iVar14 + 0xed8);
                var_d8h._4_4_ = *(float *)(iVar14 + 0xedc) * *(float *)(iVar14 + 0xd9c);
                uVar4 = func_0x0001800f5fa0(&var_e0h);
                iVar10 = iVar14;
                if (((uVar4 & 0xff000000) != 0) && (*pcVar7 != '\0')) {
                    iVar10 = *(int64_t *)(iVar14 + 0x12e8);
                    fVar17 = *(float *)(iVar14 + 0x12f8);
                    iVar6 = *(int64_t *)(*(int64_t *)(iVar14 + 0x15e0) + 800);
                    if (iVar10 == 0) {
                        iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x38) + 0x18);
                    }
                    if (fVar17 == 0.0) {
                        fVar17 = *(float *)(*(int64_t *)(iVar6 + 0x38) + 0x20);
                    }
                    var_e0h._0_4_ = *(float *)(iVar6 + 0x60);
                    var_e0h._4_4_ = *(float *)(iVar6 + 100);
                    var_d8h._0_4_ = *(float *)(iVar6 + 0x68);
                    var_d8h._4_4_ = *(float *)(iVar6 + 0x6c);
                    var_118h = (int64_t)uVar4;
                    func_0x00018012f9d0(iVar10, iVar6, fVar17, &fStackX_20, var_118h, &var_e0h, pcVar7, pcVar15, fVar18
                                        , 0);
                    iVar10 = *(int64_t *)0x180781f28;
                }
                if (*(char *)(iVar14 + 0x29f8) != '\0') {
                    iVar14 = *(int64_t *)(iVar10 + 0x2a20);
                    iVar6 = *(int64_t *)(iVar10 + 0x15e0);
                    iVar1 = *(int64_t *)(iVar10 + 0x2a28);
                    *(undefined8 *)(iVar10 + 0x2a28) = 0;
                    *(undefined8 *)(iVar10 + 0x2a20) = 0;
                    if ((pcVar15 == (char *)0x0) && (pcVar15 = pcVar7, pcVar7 != (char *)0xffffffffffffffff)) {
                        while (*pcVar15 != '\0') {
                            pcVar8 = pcVar15 + 1;
                            if (((*pcVar15 == '#') && (*pcVar8 == '#')) ||
                               (pcVar15 = pcVar8, pcVar8 == (char *)0xffffffffffffffff)) break;
                        }
                    }
                    fVar18 = *(float *)(iVar10 + 0xde0);
                    if (*(float *)(iVar10 + 0xde0) <= *(float *)(iVar10 + 0xdf0)) {
                        fVar18 = *(float *)(iVar10 + 0xdf0);
                    }
                    fVar17 = *(float *)(iVar10 + 0x2a30);
                    *(float *)(iVar10 + 0x2a30) = fStackX_24;
                    if (fVar18 + fVar17 + 1.0 < fStackX_24) {
                        func_0x0001801124e0(0x180644f68);
                        *(undefined *)(iVar10 + 0x29f9) = 1;
                    }
                    if (iVar14 != 0) {
                        iVar11 = func_0x000180498cd0(iVar14);
                        func_0x000180112520(&fStackX_20, iVar14, iVar14 + iVar11);
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    iVar5 = *(int32_t *)(iVar10 + 0x2a34);
                    if (iVar13 < iVar5) {
                        *(int32_t *)(iVar10 + 0x2a34) = iVar13;
                        iVar5 = iVar13;
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    while( true ) {
                        pcVar12 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                        pcVar8 = pcVar15;
                        if (pcVar12 != (char *)0x0) {
                            pcVar8 = pcVar12;
                        }
                        if ((pcVar7 == pcVar8) && (pcVar8 == pcVar15)) break;
                        iVar16 = (iVar13 - iVar5) * 4;
                        if (*(char *)(iVar10 + 0x29f9) == '\0') {
                            iVar16 = 1;
                        }
                        func_0x0001801124e0(0x180644f70, iVar16, 0x1805aadb1, (int32_t)pcVar8 - (int32_t)pcVar7, pcVar7)
                        ;
                        *(undefined *)(iVar10 + 0x29f9) = 0;
                        if (*pcVar8 == '\n') {
                            func_0x0001801124e0(0x180644f68);
                            *(undefined *)(iVar10 + 0x29f9) = 1;
                        }
                        if (pcVar8 == pcVar15) break;
                        pcVar7 = pcVar8 + 1;
                    }
                    if (iVar1 != 0) {
                        iVar10 = func_0x000180498cd0(iVar1);
                        func_0x000180112520(&fStackX_20, iVar1, iVar10 + iVar1);
                    }
                }
            }
        } else {
            fVar18 = *(float *)(iVar14 + 0x12f8);
            fVar22 = 0.0;
            var_e8h._0_4_ = 0.0;
            iVar13 = 0;
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if ((*(char *)(iVar14 + 0x29f8) == '\0') &&
               (iVar16 = (int32_t)((*(float *)(iVar10 + 700) - fVar20) / fVar18), iVar5 = iVar13, 0 < iVar16)) {
                for (; (pcVar7 < pcVar15 && (iVar5 < iVar16)); iVar5 = iVar5 + 1) {
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    pcVar7 = pcVar7 + 1;
                }
                fStackX_24 = (float)iVar5 * fVar18 + fVar20;
            }
            var_e8h._4_4_ = fStackX_24;
            if (pcVar7 < pcVar15) {
                fVar21 = fStackX_24;
                fVar19 = fStackX_24;
                do {
                    fVar2 = fStackX_24;
                    fVar19 = fVar19 + fVar18;
                    iVar10 = *(int64_t *)(iVar14 + 0x15e0);
                    if (((((fVar19 < *(float *)(iVar10 + 700) || fVar19 == *(float *)(iVar10 + 700)) ||
                          (*(float *)(iVar10 + 0x2c4) <= fVar21)) ||
                         (fVar17 + 3.402823e+38 < *(float *)(iVar10 + 0x2b8) ||
                          fVar17 + 3.402823e+38 == *(float *)(iVar10 + 0x2b8))) ||
                        (*(float *)(iVar10 + 0x2c0) <= fVar17)) && (*(char *)(iVar14 + 0x1652) == '\0')) break;
                    pcVar8 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                    if (pcVar8 == (char *)0x0) {
                        pcVar8 = pcVar15;
                    }
                    pfVar9 = (float *)func_0x0001800fe0a0(&var_e0h, pcVar7, pcVar8, 0, 0xbf800000);
                    if (fVar22 <= *pfVar9) {
                        fVar22 = *pfVar9;
                    }
                    var_e8h._0_4_ = fVar22;
                    func_0x0001800f6cb0(CONCAT44(fStackX_24, fStackX_20), pcVar7, pcVar8);
                    fStackX_24 = fVar2 + fVar18;
                    pcVar7 = pcVar8 + 1;
                    fVar21 = fVar21 + fVar18;
                    iVar14 = *(int64_t *)0x180781f28;
                    fVar2 = fStackX_24;
                } while (pcVar7 < pcVar15);
                for (; fVar19 = fStackX_24, pcVar7 < pcVar15; pcVar7 = pcVar7 + 1) {
                    fStackX_24 = fVar2;
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    iVar13 = iVar13 + 1;
                    fVar2 = fStackX_24;
                    fStackX_24 = fVar19;
                }
                var_e8h._4_4_ = fStackX_24 + (float)iVar13 * fVar18;
                fStackX_24 = fVar2;
            }
            var_e8h._4_4_ = var_e8h._4_4_ - fVar20;
            fVar22 = fVar17 + fVar22;
            fVar18 = var_e8h._4_4_ + fVar20;
            func_0x00018010bbf0(&var_e8h, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar10 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar22;
            *(float *)(iVar14 + 0x1fd0) = fVar18;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar22;
            *(float *)(iVar14 + 0x1fe0) = fVar18;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if (((fVar18 < *(float *)(iVar10 + 700) || fVar18 == *(float *)(iVar10 + 700)) ||
                (*(float *)(iVar10 + 0x2c4) <= fVar20)) ||
               ((fVar22 < *(float *)(iVar10 + 0x2b8) || fVar22 == *(float *)(iVar10 + 0x2b8) ||
                (*(float *)(iVar10 + 0x2c0) <= fVar17)))) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            var_d8h._0_4_ = fVar22;
            var_d8h._4_4_ = fVar18;
            cVar3 = func_0x000180108120(&var_e0h, &var_d8h, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180139ae0
// Address: 0x180139ae0
// Size: 39 bytes
// ============================================================
void fcn.180139ae0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    fcn.180139b10(arg1, &var_10h);
    return;
}

// ============================================================
// Function: FUN_180139b10
// Address: 0x180139b10
// Size: 235 bytes
// ============================================================
void fcn.180139b10(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    float fVar2;
    char cVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    char *pcVar8;
    float *pfVar9;
    int64_t iVar10;
    char *pcVar11;
    int64_t iVar12;
    int32_t iVar13;
    int64_t iVar14;
    char *pcVar15;
    int32_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fStackX_20;
    float fStackX_24;
    undefined4 uVar24;
    undefined8 uVar23;
    undefined8 in_stack_fffffffffffffee8;
    float fStack_e8;
    float fStack_e4;
    float fStack_e0;
    float fStack_dc;
    float fStack_d8;
    float fStack_d4;
    undefined8 uStack_30;
    
    iVar12 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    if (*(char *)(*(int64_t *)(iVar12 + 0x15e0) + 0x10e) != '\0') {
        return;
    }
    if (*(char *)arg1 == '%') {
        if (*(char *)(arg1 + 1) == 's') {
            if (*(char *)(arg1 + 2) == '\0') {
                pcVar8 = "(null)";
                if (*(char **)arg2 != (char *)0x0) {
                    pcVar8 = *(char **)arg2;
                }
                uStack_30 = 0x180139b73;
                iVar12 = func_0x000180498cd0(pcVar8);
                pcVar11 = pcVar8 + iVar12;
                goto code_r0x000180139280;
            }
        } else if ((((*(char *)(arg1 + 1) == '.') && (*(char *)(arg1 + 2) == '*')) && (*(char *)(arg1 + 3) == 's')) &&
                  (*(char *)(arg1 + 4) == '\0')) {
            pcVar8 = *(char **)(arg2 + 8);
            iVar13 = *(int32_t *)arg2;
            if (pcVar8 == (char *)0x0) {
                iVar5 = 6;
                if (iVar13 < 6) {
                    iVar5 = iVar13;
                }
                pcVar8 = "(null)";
                pcVar11 = (char *)((int64_t)iVar5 + 0x1806442d0);
            } else {
                pcVar11 = pcVar8 + iVar13;
            }
            goto code_r0x000180139280;
        }
    }
    pcVar8 = *(char **)(iVar12 + 0x2c98);
    pcVar11 = pcVar8;
code_r0x000180139280:
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar12 = *(int64_t *)(iVar14 + 0x15e0);
    if (*(char *)(iVar12 + 0x10e) == '\0') {
        pcVar7 = "";
        pcVar15 = "";
        if (pcVar8 != pcVar11) {
            pcVar7 = pcVar8;
            pcVar15 = pcVar11;
        }
        if (pcVar15 == (char *)0x0) {
            iVar6 = func_0x000180498cd0(pcVar7);
            pcVar15 = pcVar7 + iVar6;
        }
        fVar18 = *(float *)(iVar12 + 0x244);
        fVar17 = *(float *)(iVar12 + 0x158);
        fVar20 = *(float *)(iVar12 + 400) + *(float *)(iVar12 + 0x15c);
        fStack_e0 = fVar17;
        fStack_dc = fVar20;
        if (((int64_t)pcVar15 - (int64_t)pcVar7 < 0x7d1) || (0.0 <= fVar18)) {
            if (fVar18 < 0.0) {
                fVar18 = 0.0;
            } else if (fVar18 == 0.0) {
                fVar18 = *(float *)(iVar12 + 0x2a0) - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            } else {
                if (0.0 < fVar18) {
                    fVar18 = (*(float *)(iVar12 + 0x60) - *(float *)(iVar12 + 0xd4)) + fVar18;
                }
                fVar18 = fVar18 - fVar17;
                if (fVar18 <= 1.0) {
                    fVar18 = 1.0;
                }
            }
            uVar23 = CONCAT44((int32_t)((uint64_t)in_stack_fffffffffffffee8 >> 0x20), fVar18);
            func_0x0001800fe0a0(&fStackX_20, pcVar7, pcVar15, 0, uVar23);
            uVar24 = (undefined4)((uint64_t)uVar23 >> 0x20);
            fVar22 = fStackX_24 + fVar20;
            fVar19 = fVar17 + fStackX_20;
            func_0x00018010bbf0(&fStackX_20, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar12 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar19;
            *(float *)(iVar14 + 0x1fd0) = fVar22;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar19;
            *(float *)(iVar14 + 0x1fe0) = fVar22;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if (((fVar22 < *(float *)(iVar12 + 700) || fVar22 == *(float *)(iVar12 + 700)) ||
                (*(float *)(iVar12 + 0x2c4) <= fVar20)) ||
               ((fVar19 < *(float *)(iVar12 + 0x2b8) || fVar19 == *(float *)(iVar12 + 0x2b8) ||
                (*(float *)(iVar12 + 0x2c0) <= fVar17)))) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            fStack_d8 = fVar19;
            fStack_d4 = fVar22;
            cVar3 = func_0x000180108120(&fStack_e0, &fStack_d8, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if (pcVar15 == (char *)0x0) {
                iVar12 = func_0x000180498cd0(pcVar7);
                pcVar15 = pcVar7 + iVar12;
            }
            if (pcVar7 != pcVar15) {
                fStack_e0 = *(float *)(iVar14 + 0xed0);
                fStack_dc = *(float *)(iVar14 + 0xed4);
                fStack_d8 = *(float *)(iVar14 + 0xed8);
                fStack_d4 = *(float *)(iVar14 + 0xedc) * *(float *)(iVar14 + 0xd9c);
                uVar4 = func_0x0001800f5fa0(&fStack_e0);
                iVar12 = iVar14;
                if (((uVar4 & 0xff000000) != 0) && (*pcVar7 != '\0')) {
                    iVar12 = *(int64_t *)(iVar14 + 0x12e8);
                    fVar17 = *(float *)(iVar14 + 0x12f8);
                    iVar6 = *(int64_t *)(*(int64_t *)(iVar14 + 0x15e0) + 800);
                    if (iVar12 == 0) {
                        iVar12 = *(int64_t *)(*(int64_t *)(iVar6 + 0x38) + 0x18);
                    }
                    if (fVar17 == 0.0) {
                        fVar17 = *(float *)(*(int64_t *)(iVar6 + 0x38) + 0x20);
                    }
                    fStack_e0 = *(float *)(iVar6 + 0x60);
                    fStack_dc = *(float *)(iVar6 + 100);
                    fStack_d8 = *(float *)(iVar6 + 0x68);
                    fStack_d4 = *(float *)(iVar6 + 0x6c);
                    func_0x00018012f9d0(iVar12, iVar6, fVar17, &fStackX_20, CONCAT44(uVar24, uVar4), &fStack_e0, pcVar7
                                        , pcVar15, fVar18, 0);
                    iVar12 = *(int64_t *)0x180781f28;
                }
                if (*(char *)(iVar14 + 0x29f8) != '\0') {
                    iVar14 = *(int64_t *)(iVar12 + 0x2a20);
                    iVar6 = *(int64_t *)(iVar12 + 0x15e0);
                    iVar1 = *(int64_t *)(iVar12 + 0x2a28);
                    *(undefined8 *)(iVar12 + 0x2a28) = 0;
                    *(undefined8 *)(iVar12 + 0x2a20) = 0;
                    if ((pcVar15 == (char *)0x0) && (pcVar15 = pcVar7, pcVar7 != (char *)0xffffffffffffffff)) {
                        while (*pcVar15 != '\0') {
                            pcVar8 = pcVar15 + 1;
                            if (((*pcVar15 == '#') && (*pcVar8 == '#')) ||
                               (pcVar15 = pcVar8, pcVar8 == (char *)0xffffffffffffffff)) break;
                        }
                    }
                    fVar18 = *(float *)(iVar12 + 0xde0);
                    if (*(float *)(iVar12 + 0xde0) <= *(float *)(iVar12 + 0xdf0)) {
                        fVar18 = *(float *)(iVar12 + 0xdf0);
                    }
                    fVar17 = *(float *)(iVar12 + 0x2a30);
                    *(float *)(iVar12 + 0x2a30) = fStackX_24;
                    if (fVar18 + fVar17 + 1.0 < fStackX_24) {
                        func_0x0001801124e0(0x180644f68);
                        *(undefined *)(iVar12 + 0x29f9) = 1;
                    }
                    if (iVar14 != 0) {
                        iVar10 = func_0x000180498cd0(iVar14);
                        func_0x000180112520(&fStackX_20, iVar14, iVar14 + iVar10);
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    iVar5 = *(int32_t *)(iVar12 + 0x2a34);
                    if (iVar13 < iVar5) {
                        *(int32_t *)(iVar12 + 0x2a34) = iVar13;
                        iVar5 = iVar13;
                    }
                    iVar13 = *(int32_t *)(iVar6 + 0x1e0);
                    while( true ) {
                        pcVar11 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                        pcVar8 = pcVar15;
                        if (pcVar11 != (char *)0x0) {
                            pcVar8 = pcVar11;
                        }
                        if ((pcVar7 == pcVar8) && (pcVar8 == pcVar15)) break;
                        iVar16 = (iVar13 - iVar5) * 4;
                        if (*(char *)(iVar12 + 0x29f9) == '\0') {
                            iVar16 = 1;
                        }
                        func_0x0001801124e0(0x180644f70, iVar16, 0x1805aadb1, (int32_t)pcVar8 - (int32_t)pcVar7, pcVar7)
                        ;
                        *(undefined *)(iVar12 + 0x29f9) = 0;
                        if (*pcVar8 == '\n') {
                            func_0x0001801124e0(0x180644f68);
                            *(undefined *)(iVar12 + 0x29f9) = 1;
                        }
                        if (pcVar8 == pcVar15) break;
                        pcVar7 = pcVar8 + 1;
                    }
                    if (iVar1 != 0) {
                        iVar12 = func_0x000180498cd0(iVar1);
                        func_0x000180112520(&fStackX_20, iVar1, iVar12 + iVar1);
                    }
                }
            }
        } else {
            fVar18 = *(float *)(iVar14 + 0x12f8);
            fVar22 = 0.0;
            fStack_e8 = 0.0;
            iVar13 = 0;
            fStackX_20 = fVar17;
            fStackX_24 = fVar20;
            if ((*(char *)(iVar14 + 0x29f8) == '\0') &&
               (iVar16 = (int32_t)((*(float *)(iVar12 + 700) - fVar20) / fVar18), iVar5 = iVar13, 0 < iVar16)) {
                for (; (pcVar7 < pcVar15 && (iVar5 < iVar16)); iVar5 = iVar5 + 1) {
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    pcVar7 = pcVar7 + 1;
                }
                fStackX_24 = (float)iVar5 * fVar18 + fVar20;
            }
            fStack_e4 = fStackX_24;
            if (pcVar7 < pcVar15) {
                fVar21 = fStackX_24;
                fVar19 = fStackX_24;
                do {
                    fVar2 = fStackX_24;
                    uVar24 = (undefined4)((uint64_t)in_stack_fffffffffffffee8 >> 0x20);
                    fVar19 = fVar19 + fVar18;
                    iVar12 = *(int64_t *)(iVar14 + 0x15e0);
                    if (((((fVar19 < *(float *)(iVar12 + 700) || fVar19 == *(float *)(iVar12 + 700)) ||
                          (*(float *)(iVar12 + 0x2c4) <= fVar21)) ||
                         (fVar17 + 3.402823e+38 < *(float *)(iVar12 + 0x2b8) ||
                          fVar17 + 3.402823e+38 == *(float *)(iVar12 + 0x2b8))) ||
                        (*(float *)(iVar12 + 0x2c0) <= fVar17)) && (*(char *)(iVar14 + 0x1652) == '\0')) break;
                    pcVar8 = (char *)func_0x000180498a80(pcVar7, 10, (int64_t)pcVar15 - (int64_t)pcVar7);
                    in_stack_fffffffffffffee8 = CONCAT44(uVar24, 0xbf800000);
                    if (pcVar8 == (char *)0x0) {
                        pcVar8 = pcVar15;
                    }
                    pfVar9 = (float *)func_0x0001800fe0a0(&fStack_e0, pcVar7, pcVar8, 0, in_stack_fffffffffffffee8);
                    if (fVar22 <= *pfVar9) {
                        fVar22 = *pfVar9;
                    }
                    fStack_e8 = fVar22;
                    func_0x0001800f6cb0(CONCAT44(fStackX_24, fStackX_20), pcVar7, pcVar8);
                    fStackX_24 = fVar2 + fVar18;
                    pcVar7 = pcVar8 + 1;
                    fVar21 = fVar21 + fVar18;
                    iVar14 = *(int64_t *)0x180781f28;
                    fVar2 = fStackX_24;
                } while (pcVar7 < pcVar15);
                for (; fVar19 = fStackX_24, pcVar7 < pcVar15; pcVar7 = pcVar7 + 1) {
                    fStackX_24 = fVar2;
                    pcVar7 = (char *)func_0x000180498a80(pcVar7, 10, pcVar15 + -(int64_t)pcVar7);
                    if (pcVar7 == (char *)0x0) {
                        pcVar7 = pcVar15;
                    }
                    iVar13 = iVar13 + 1;
                    fVar2 = fStackX_24;
                    fStackX_24 = fVar19;
                }
                fStack_e4 = fStackX_24 + (float)iVar13 * fVar18;
                fStackX_24 = fVar2;
            }
            fStack_e4 = fStack_e4 - fVar20;
            fVar22 = fVar17 + fVar22;
            fVar18 = fStack_e4 + fVar20;
            func_0x00018010bbf0(&fStack_e8, 0);
            iVar14 = *(int64_t *)0x180781f28;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
            iVar12 = *(int64_t *)(iVar14 + 0x15e0);
            *(undefined4 *)(iVar14 + 0x1fb8) = 0;
            *(float *)(iVar14 + 0x1fc4) = fVar17;
            *(float *)(iVar14 + 0x1fc8) = fVar20;
            *(float *)(iVar14 + 0x1fcc) = fVar22;
            *(float *)(iVar14 + 0x1fd0) = fVar18;
            *(undefined4 *)(iVar14 + 0x1fc0) = 0;
            *(float *)(iVar14 + 0x1fd4) = fVar17;
            *(float *)(iVar14 + 0x1fd8) = fVar20;
            *(float *)(iVar14 + 0x1fdc) = fVar22;
            *(float *)(iVar14 + 0x1fe0) = fVar18;
            *(undefined8 *)(iVar14 + 0x1f80) = 0;
            if (((fVar18 < *(float *)(iVar12 + 700) || fVar18 == *(float *)(iVar12 + 700)) ||
                (*(float *)(iVar12 + 0x2c4) <= fVar20)) ||
               ((fVar22 < *(float *)(iVar12 + 0x2b8) || fVar22 == *(float *)(iVar12 + 0x2b8) ||
                (*(float *)(iVar12 + 0x2c0) <= fVar17)))) {
                if (*(char *)(iVar14 + 0x1652) == '\0') {
                    return;
                }
            } else {
                *(undefined4 *)(iVar14 + 0x1fc0) = 0x100;
            }
            fStack_d8 = fVar22;
            fStack_d4 = fVar18;
            cVar3 = func_0x000180108120(&fStack_e0, &fStack_d8, 1);
            if (cVar3 != '\0') {
                *(uint32_t *)(iVar14 + 0x1fc0) = *(uint32_t *)(iVar14 + 0x1fc0) | 1;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180139c00
// Address: 0x180139c00
// Size: 126 bytes
// ============================================================
void fcn.180139c00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int64_t iStackX_10;
    int64_t iStackX_18;
    int64_t iStackX_20;
    undefined4 uStack_38;
    undefined4 uStack_34;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    undefined4 uStack_28;
    
    iVar1 = *(int64_t *)0x180781f28;
    uStack_38 = 0;
    uStack_34 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
    uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
    uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
    uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xedc);
    iStackX_10 = arg2;
    iStackX_18 = arg3;
    iStackX_20 = arg4;
    fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &uStack_38);
    if (*(int32_t *)(iVar1 + 0x20bc) != 0) {
        *(undefined4 *)(iVar1 + 0xed0) = *(undefined4 *)(iVar1 + 0xee0);
        *(undefined4 *)(iVar1 + 0xed4) = *(undefined4 *)(iVar1 + 0xee4);
        *(undefined4 *)(iVar1 + 0xed8) = *(undefined4 *)(iVar1 + 0xee8);
        *(undefined4 *)(iVar1 + 0xedc) = *(undefined4 *)(iVar1 + 0xeec);
    }
    fcn.180139b10(arg1, (int64_t)&iStackX_10);
    fcn.1800f6770(1);
    return;
}

// ============================================================
// Function: FUN_180139c80
// Address: 0x180139c80
// Size: 188 bytes
// ============================================================
void fcn.180139c80(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    float *pfVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    pfVar1 = (float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x244);
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    if (0.0 < *pfVar1 || *pfVar1 == 0.0) {
        fcn.180139b10(arg1, (int64_t)&var_10h);
    } else {
        fcn.1801061c0();
        fcn.180139b10(arg1, (int64_t)&var_10h);
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar2 = *(int32_t *)(iVar4 + 600);
        if (0 < iVar2) {
            uVar3 = *(undefined4 *)(*(int64_t *)(iVar4 + 0x260) + -4 + (int64_t)iVar2 * 4);
            *(int32_t *)(iVar4 + 600) = iVar2 + -1;
            *(undefined4 *)(iVar4 + 0x244) = uVar3;
            return;
        }
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644678);
            return;
        }
    }
    return;
}

