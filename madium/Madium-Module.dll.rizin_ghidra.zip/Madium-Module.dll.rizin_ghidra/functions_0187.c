// Chunk 187 - 50 functions

// ============================================================
// Function: FUN_18024d8fc
// Address: 0x18024d8fc
// Size: 302 bytes
// ============================================================
int32_t fcn.18024d8fc(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    int64_t unaff_RSI;
    uint64_t unaff_R12;
    int32_t unaff_R15D;
    int64_t var_20h;
    
    uVar8 = unaff_R12 & 0xffffffff;
    do {
        uVar4 = func_0x00018023eff0();
        uVar4 = func_0x00018001ed90(uVar4);
        func_0x000180265cd0(0, &arg_a0h, 0, 0, uVar4);
        uVar6 = unaff_R12;
        if (arg_a0h != 0) {
            uVar1 = func_0x00018022cd20();
            uVar5 = func_0x00018022ccf0(uVar1);
            uVar6 = func_0x00018022e160(uVar5);
        }
        uVar6 = func_0x0001802aea40(uVar6, *(undefined8 *)(unaff_RSI + 0xc0));
        if (uVar6 == 0) {
code_r0x00018024da20:
            iVar2 = 0x60;
            goto code_r0x00018024da25;
        }
        iVar2 = func_0x0001802aec30(uVar6, uVar4);
        if (iVar2 == 0) {
            iVar2 = func_0x00018023eed0();
            if (iVar2 < 1) goto code_r0x00018024da20;
            iVar2 = (int32_t)arg_90h;
            if ((int32_t)arg_90h == 0) {
                iVar3 = func_0x00018023ecb0(arg_40h, arg_a8h, 300, 0xffffffff, &arg_48h);
                iVar2 = 99;
                if (iVar3 != 0) {
                    iVar2 = (int32_t)unaff_R12;
                }
            }
            goto code_r0x00018024da25;
        }
        func_0x00018023f1c0(uVar6);
        uVar7 = (int32_t)uVar8 + 1;
        uVar8 = (uint64_t)uVar7;
    } while ((int32_t)uVar7 < unaff_R15D);
    uVar6 = unaff_R12;
    iVar2 = 100;
code_r0x00018024da25:
    func_0x00018023f1c0(uVar6);
    func_0x00018023f190();
    return iVar2;
}

// ============================================================
// Function: FUN_18024da2a
// Address: 0x18024da2a
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_50h

int32_t fcn.18024d8fc(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    int64_t unaff_RSI;
    uint64_t unaff_R12;
    int32_t unaff_R15D;
    int64_t var_20h;
    
    uVar8 = unaff_R12 & 0xffffffff;
    do {
        uVar4 = func_0x00018023eff0();
        uVar4 = func_0x00018001ed90(uVar4);
        func_0x000180265cd0(0, &arg_a0h, 0, 0, uVar4);
        uVar6 = unaff_R12;
        if (arg_a0h != 0) {
            uVar1 = func_0x00018022cd20();
            uVar5 = func_0x00018022ccf0(uVar1);
            uVar6 = func_0x00018022e160(uVar5);
        }
        uVar6 = func_0x0001802aea40(uVar6, *(undefined8 *)(unaff_RSI + 0xc0));
        if (uVar6 == 0) {
code_r0x00018024da20:
            iVar2 = 0x60;
            goto code_r0x00018024da25;
        }
        iVar2 = func_0x0001802aec30(uVar6, uVar4);
        if (iVar2 == 0) {
            iVar2 = func_0x00018023eed0();
            if (iVar2 < 1) goto code_r0x00018024da20;
            iVar2 = (int32_t)arg_90h;
            if ((int32_t)arg_90h == 0) {
                iVar3 = func_0x00018023ecb0(arg_40h, arg_a8h, 300, 0xffffffff, &arg_48h);
                iVar2 = 99;
                if (iVar3 != 0) {
                    iVar2 = (int32_t)unaff_R12;
                }
            }
            goto code_r0x00018024da25;
        }
        func_0x00018023f1c0(uVar6);
        uVar7 = (int32_t)uVar8 + 1;
        uVar8 = (uint64_t)uVar7;
    } while ((int32_t)uVar7 < unaff_R15D);
    uVar6 = unaff_R12;
    iVar2 = 100;
code_r0x00018024da25:
    func_0x00018023f1c0(uVar6);
    func_0x00018023f190();
    return iVar2;
}

// ============================================================
// Function: FUN_18024da60
// Address: 0x18024da60
// Size: 437 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_dch

bool fcn.18024da60(int64_t arg_30h, int64_t arg_48h, int64_t arg_a8h, int64_t arg_d8h, int64_t arg_e8h, int64_t arg_110h
                  , int64_t arg_128h, int64_t arg_148h)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    bool bVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    undefined8 *in_RCX;
    int64_t in_RDX;
    int64_t iVar13;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024da79;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    iVar6 = *(int32_t *)((int64_t)in_RCX + 0xb4);
    uVar10 = in_RCX[0x14];
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024da94;
    iVar5 = func_0x000180222010(uVar10);
    iVar9 = in_RCX[0x19];
    if (iVar9 == 0) {
        uVar10 = in_RCX[0x14];
        if (iVar5 + -1 <= iVar6) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dace;
            iVar9 = func_0x000180222340(uVar10, iVar5 + -1);
            if (iVar9 != 0) {
                pcVar2 = (code *)in_RCX[10];
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024daea;
                iVar6 = (*pcVar2)(in_RCX, iVar9, iVar9);
                if (iVar6 == 0) {
                    pcVar2 = (code *)in_RCX[8];
                    *(undefined4 *)(in_RCX + 0x17) = 0x21;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024db04;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    if (iVar6 == 0) goto code_r0x00018024dd16;
                }
                goto code_r0x00018024db0c;
            }
            goto code_r0x00018024dd16;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dab5;
        iVar9 = func_0x000180222340(uVar10, iVar6 + 1);
        if (iVar9 != 0) goto code_r0x00018024db0c;
code_r0x00018024dabd:
        bVar4 = true;
    } else {
code_r0x00018024db0c:
        iVar13 = 0;
        if (*(int64_t *)(in_RDX + 0xa0) == 0) {
            if (((*(uint8_t *)(iVar9 + 0xd8) & 2) != 0) && ((*(uint8_t *)(iVar9 + 0xdc) & 2) == 0)) {
                pcVar2 = (code *)in_RCX[8];
                *(undefined4 *)(in_RCX + 0x17) = 0x23;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024db43;
                iVar6 = (*pcVar2)(0, in_RCX);
                if (iVar6 == 0) goto code_r0x00018024dd16;
            }
            if ((*(uint8_t *)(in_RCX + 0x1b) & 0x80) == 0) {
                pcVar2 = (code *)in_RCX[8];
                *(undefined4 *)(in_RCX + 0x17) = 0x2c;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024db69;
                iVar6 = (*pcVar2)(0, in_RCX);
                if (iVar6 == 0) goto code_r0x00018024dd16;
            }
            if ((*(uint8_t *)(in_RCX + 0x1b) & 8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024db90;
                func_0x0001804986e0((int64_t)&var_8h + iVar8, 0, 0x120);
                if (in_RCX[0x1c] == 0) {
                    uVar10 = in_RCX[2];
                    uVar11 = in_RCX[0x19];
                    uVar3 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dbb5;
                    iVar6 = func_0x00018024bbe0((int64_t)&var_8h + iVar8, uVar3, uVar11, uVar10);
                    if (iVar6 != 0) {
                        uVar10 = in_RCX[5];
                        *(undefined8 *)((int64_t)&var_20h + iVar8) = in_RCX[3];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dbd4;
                        func_0x000180233bc0(*(undefined8 *)((int64_t)&arg_30h + iVar8));
                        *(undefined8 *)((int64_t)&arg_48h + iVar8) = in_RCX[8];
                        *(undefined8 *)((int64_t)&arg_30h + iVar8) = uVar10;
                        *(undefined8 **)((int64_t)&arg_e8h + iVar8) = in_RCX;
                        if (*(int64_t *)((int64_t)&arg_110h + iVar8) == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc05;
                            uVar7 = func_0x000180250d20((int64_t)&var_8h + iVar8);
                        } else {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dbfe;
                            uVar7 = func_0x000180250bf0();
                        }
                        if (0 < (int32_t)uVar7) {
                            uVar10 = in_RCX[0x14];
                            *(undefined8 *)((int64_t)&arg_148h + iVar8) = unaff_RDI;
                            uVar11 = *(undefined8 *)((int64_t)&arg_a8h + iVar8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc2a;
                            iVar6 = func_0x000180222010(uVar10);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc35;
                            uVar10 = func_0x000180222340(uVar10, iVar6 + -1);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc40;
                            iVar6 = func_0x000180222010(uVar11);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc4b;
                            uVar11 = func_0x000180222340(uVar11, iVar6 + -1);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc56;
                            iVar6 = func_0x000180238200(uVar10, uVar11);
                            uVar7 = (uint32_t)(iVar6 == 0);
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc70;
                        func_0x00018024b870((int64_t)&var_8h + iVar8);
                        if (0 < (int32_t)uVar7) goto code_r0x00018024dc91;
                    }
                }
                pcVar2 = (code *)in_RCX[8];
                *(undefined4 *)(in_RCX + 0x17) = 0x36;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc89;
                iVar6 = (*pcVar2)(0, in_RCX);
                if (iVar6 == 0) goto code_r0x00018024dd16;
            }
code_r0x00018024dc91:
            if ((*(uint8_t *)(in_RDX + 0x90) & 2) != 0) {
                pcVar2 = (code *)in_RCX[8];
                *(undefined4 *)(in_RCX + 0x17) = 0x29;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dcb0;
                iVar6 = (*pcVar2)(0, in_RCX);
                if (iVar6 == 0) goto code_r0x00018024dd16;
            }
        }
        if ((*(uint8_t *)(in_RCX + 0x1b) & 0x40) == 0) {
            uVar7 = *(uint32_t *)(in_RCX[5] + 0x14);
            if ((uVar7 & 2) == 0) {
                if ((uVar7 >> 0x15 & 1) != 0) goto code_r0x00018024ddba;
            } else {
                iVar13 = in_RCX[5] + 8;
            }
            in_RCX[0x1a] = in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dcee;
            uVar10 = func_0x0001801dd170(in_RDX);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dcf9;
            iVar6 = func_0x00018024c3a0(uVar10, iVar13);
            if (iVar6 != 0) {
                if (0 < iVar6) {
                    pcVar2 = (code *)in_RCX[8];
                    *(undefined4 *)(in_RCX + 0x17) = 0xb;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd48;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    if (iVar6 == 0) goto code_r0x00018024dd16;
                }
code_r0x00018024dd4c:
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd54;
                iVar12 = func_0x000180192480(in_RDX);
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd61;
                    uVar10 = func_0x000180192480(in_RDX);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd6c;
                    iVar6 = func_0x00018024c3a0(uVar10, iVar13);
                    if (iVar6 == 0) {
                        pcVar2 = (code *)in_RCX[8];
                        *(undefined4 *)(in_RCX + 0x17) = 0x10;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd85;
                        iVar6 = (*pcVar2)(0, in_RCX);
                    } else {
                        if ((-1 < iVar6) || ((*(uint8_t *)(in_RCX + 0x1b) & 2) != 0)) goto code_r0x00018024ddb3;
                        pcVar2 = (code *)in_RCX[8];
                        *(undefined4 *)(in_RCX + 0x17) = 0xc;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024ddab;
                        iVar6 = (*pcVar2)(0, in_RCX);
                    }
                    if (iVar6 == 0) goto code_r0x00018024dd16;
                }
code_r0x00018024ddb3:
                in_RCX[0x1a] = 0;
                goto code_r0x00018024ddba;
            }
            pcVar2 = (code *)in_RCX[8];
            *(undefined4 *)(in_RCX + 0x17) = 0xf;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd12;
            iVar6 = (*pcVar2)(0, in_RCX);
            if (iVar6 != 0) goto code_r0x00018024dd4c;
        } else {
code_r0x00018024ddba:
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024ddc2;
            iVar9 = func_0x000180238400(iVar9);
            if (iVar9 != 0) {
                uVar1 = *(undefined4 *)(in_RCX[5] + 0x14);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024de04;
                iVar6 = func_0x000180237810(in_RDX, iVar9, uVar1);
                if (iVar6 != 0) {
                    *(int32_t *)(in_RCX + 0x17) = iVar6;
                    pcVar2 = (code *)in_RCX[8];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024de19;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    if (iVar6 == 0) goto code_r0x00018024dd16;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024de2c;
                iVar6 = func_0x00018028ec40(in_RDX, iVar9);
                if (iVar6 < 1) {
                    pcVar2 = (code *)in_RCX[8];
                    *(undefined4 *)(in_RCX + 0x17) = 8;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024de4a;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    return iVar6 != 0;
                }
                goto code_r0x00018024dabd;
            }
            pcVar2 = (code *)in_RCX[8];
            *(undefined4 *)(in_RCX + 0x17) = 6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dddf;
            iVar6 = (*pcVar2)(0, in_RCX);
            if (iVar6 != 0) {
                return true;
            }
        }
code_r0x00018024dd16:
        bVar4 = false;
    }
    return bVar4;
}

// ============================================================
// Function: FUN_18024dc15
// Address: 0x18024dc15
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_dch

bool fcn.18024da60(int64_t arg_30h, int64_t arg_48h, int64_t arg_a8h, int64_t arg_d8h, int64_t arg_e8h, int64_t arg_110h
                  , int64_t arg_128h, int64_t arg_148h)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    bool bVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    undefined8 *in_RCX;
    int64_t in_RDX;
    int64_t iVar13;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024da79;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    iVar6 = *(int32_t *)((int64_t)in_RCX + 0xb4);
    uVar10 = in_RCX[0x14];
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024da94;
    iVar5 = func_0x000180222010(uVar10);
    iVar9 = in_RCX[0x19];
    if (iVar9 == 0) {
        uVar10 = in_RCX[0x14];
        if (iVar5 + -1 <= iVar6) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dace;
            iVar9 = func_0x000180222340(uVar10, iVar5 + -1);
            if (iVar9 != 0) {
                pcVar2 = (code *)in_RCX[10];
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024daea;
                iVar6 = (*pcVar2)(in_RCX, iVar9, iVar9);
                if (iVar6 == 0) {
                    pcVar2 = (code *)in_RCX[8];
                    *(undefined4 *)(in_RCX + 0x17) = 0x21;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024db04;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    if (iVar6 == 0) goto code_r0x00018024dd16;
                }
                goto code_r0x00018024db0c;
            }
            goto code_r0x00018024dd16;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dab5;
        iVar9 = func_0x000180222340(uVar10, iVar6 + 1);
        if (iVar9 != 0) goto code_r0x00018024db0c;
code_r0x00018024dabd:
        bVar4 = true;
    } else {
code_r0x00018024db0c:
        iVar13 = 0;
        if (*(int64_t *)(in_RDX + 0xa0) == 0) {
            if (((*(uint8_t *)(iVar9 + 0xd8) & 2) != 0) && ((*(uint8_t *)(iVar9 + 0xdc) & 2) == 0)) {
                pcVar2 = (code *)in_RCX[8];
                *(undefined4 *)(in_RCX + 0x17) = 0x23;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024db43;
                iVar6 = (*pcVar2)(0, in_RCX);
                if (iVar6 == 0) goto code_r0x00018024dd16;
            }
            if ((*(uint8_t *)(in_RCX + 0x1b) & 0x80) == 0) {
                pcVar2 = (code *)in_RCX[8];
                *(undefined4 *)(in_RCX + 0x17) = 0x2c;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024db69;
                iVar6 = (*pcVar2)(0, in_RCX);
                if (iVar6 == 0) goto code_r0x00018024dd16;
            }
            if ((*(uint8_t *)(in_RCX + 0x1b) & 8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024db90;
                func_0x0001804986e0((int64_t)&var_8h + iVar8, 0, 0x120);
                if (in_RCX[0x1c] == 0) {
                    uVar10 = in_RCX[2];
                    uVar11 = in_RCX[0x19];
                    uVar3 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dbb5;
                    iVar6 = func_0x00018024bbe0((int64_t)&var_8h + iVar8, uVar3, uVar11, uVar10);
                    if (iVar6 != 0) {
                        uVar10 = in_RCX[5];
                        *(undefined8 *)((int64_t)&var_20h + iVar8) = in_RCX[3];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dbd4;
                        func_0x000180233bc0(*(undefined8 *)((int64_t)&arg_30h + iVar8));
                        *(undefined8 *)((int64_t)&arg_48h + iVar8) = in_RCX[8];
                        *(undefined8 *)((int64_t)&arg_30h + iVar8) = uVar10;
                        *(undefined8 **)((int64_t)&arg_e8h + iVar8) = in_RCX;
                        if (*(int64_t *)((int64_t)&arg_110h + iVar8) == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc05;
                            uVar7 = func_0x000180250d20((int64_t)&var_8h + iVar8);
                        } else {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dbfe;
                            uVar7 = func_0x000180250bf0();
                        }
                        if (0 < (int32_t)uVar7) {
                            uVar10 = in_RCX[0x14];
                            *(undefined8 *)((int64_t)&arg_148h + iVar8) = unaff_RDI;
                            uVar11 = *(undefined8 *)((int64_t)&arg_a8h + iVar8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc2a;
                            iVar6 = func_0x000180222010(uVar10);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc35;
                            uVar10 = func_0x000180222340(uVar10, iVar6 + -1);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc40;
                            iVar6 = func_0x000180222010(uVar11);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc4b;
                            uVar11 = func_0x000180222340(uVar11, iVar6 + -1);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc56;
                            iVar6 = func_0x000180238200(uVar10, uVar11);
                            uVar7 = (uint32_t)(iVar6 == 0);
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc70;
                        func_0x00018024b870((int64_t)&var_8h + iVar8);
                        if (0 < (int32_t)uVar7) goto code_r0x00018024dc91;
                    }
                }
                pcVar2 = (code *)in_RCX[8];
                *(undefined4 *)(in_RCX + 0x17) = 0x36;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc89;
                iVar6 = (*pcVar2)(0, in_RCX);
                if (iVar6 == 0) goto code_r0x00018024dd16;
            }
code_r0x00018024dc91:
            if ((*(uint8_t *)(in_RDX + 0x90) & 2) != 0) {
                pcVar2 = (code *)in_RCX[8];
                *(undefined4 *)(in_RCX + 0x17) = 0x29;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dcb0;
                iVar6 = (*pcVar2)(0, in_RCX);
                if (iVar6 == 0) goto code_r0x00018024dd16;
            }
        }
        if ((*(uint8_t *)(in_RCX + 0x1b) & 0x40) == 0) {
            uVar7 = *(uint32_t *)(in_RCX[5] + 0x14);
            if ((uVar7 & 2) == 0) {
                if ((uVar7 >> 0x15 & 1) != 0) goto code_r0x00018024ddba;
            } else {
                iVar13 = in_RCX[5] + 8;
            }
            in_RCX[0x1a] = in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dcee;
            uVar10 = func_0x0001801dd170(in_RDX);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dcf9;
            iVar6 = func_0x00018024c3a0(uVar10, iVar13);
            if (iVar6 != 0) {
                if (0 < iVar6) {
                    pcVar2 = (code *)in_RCX[8];
                    *(undefined4 *)(in_RCX + 0x17) = 0xb;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd48;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    if (iVar6 == 0) goto code_r0x00018024dd16;
                }
code_r0x00018024dd4c:
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd54;
                iVar12 = func_0x000180192480(in_RDX);
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd61;
                    uVar10 = func_0x000180192480(in_RDX);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd6c;
                    iVar6 = func_0x00018024c3a0(uVar10, iVar13);
                    if (iVar6 == 0) {
                        pcVar2 = (code *)in_RCX[8];
                        *(undefined4 *)(in_RCX + 0x17) = 0x10;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd85;
                        iVar6 = (*pcVar2)(0, in_RCX);
                    } else {
                        if ((-1 < iVar6) || ((*(uint8_t *)(in_RCX + 0x1b) & 2) != 0)) goto code_r0x00018024ddb3;
                        pcVar2 = (code *)in_RCX[8];
                        *(undefined4 *)(in_RCX + 0x17) = 0xc;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024ddab;
                        iVar6 = (*pcVar2)(0, in_RCX);
                    }
                    if (iVar6 == 0) goto code_r0x00018024dd16;
                }
code_r0x00018024ddb3:
                in_RCX[0x1a] = 0;
                goto code_r0x00018024ddba;
            }
            pcVar2 = (code *)in_RCX[8];
            *(undefined4 *)(in_RCX + 0x17) = 0xf;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd12;
            iVar6 = (*pcVar2)(0, in_RCX);
            if (iVar6 != 0) goto code_r0x00018024dd4c;
        } else {
code_r0x00018024ddba:
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024ddc2;
            iVar9 = func_0x000180238400(iVar9);
            if (iVar9 != 0) {
                uVar1 = *(undefined4 *)(in_RCX[5] + 0x14);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024de04;
                iVar6 = func_0x000180237810(in_RDX, iVar9, uVar1);
                if (iVar6 != 0) {
                    *(int32_t *)(in_RCX + 0x17) = iVar6;
                    pcVar2 = (code *)in_RCX[8];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024de19;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    if (iVar6 == 0) goto code_r0x00018024dd16;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024de2c;
                iVar6 = func_0x00018028ec40(in_RDX, iVar9);
                if (iVar6 < 1) {
                    pcVar2 = (code *)in_RCX[8];
                    *(undefined4 *)(in_RCX + 0x17) = 8;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024de4a;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    return iVar6 != 0;
                }
                goto code_r0x00018024dabd;
            }
            pcVar2 = (code *)in_RCX[8];
            *(undefined4 *)(in_RCX + 0x17) = 6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dddf;
            iVar6 = (*pcVar2)(0, in_RCX);
            if (iVar6 != 0) {
                return true;
            }
        }
code_r0x00018024dd16:
        bVar4 = false;
    }
    return bVar4;
}

// ============================================================
// Function: FUN_18024dc66
// Address: 0x18024dc66
// Size: 498 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_dch

bool fcn.18024da60(int64_t arg_30h, int64_t arg_48h, int64_t arg_a8h, int64_t arg_d8h, int64_t arg_e8h, int64_t arg_110h
                  , int64_t arg_128h, int64_t arg_148h)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    bool bVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    undefined8 *in_RCX;
    int64_t in_RDX;
    int64_t iVar13;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024da79;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    iVar6 = *(int32_t *)((int64_t)in_RCX + 0xb4);
    uVar10 = in_RCX[0x14];
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024da94;
    iVar5 = func_0x000180222010(uVar10);
    iVar9 = in_RCX[0x19];
    if (iVar9 == 0) {
        uVar10 = in_RCX[0x14];
        if (iVar5 + -1 <= iVar6) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dace;
            iVar9 = func_0x000180222340(uVar10, iVar5 + -1);
            if (iVar9 != 0) {
                pcVar2 = (code *)in_RCX[10];
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024daea;
                iVar6 = (*pcVar2)(in_RCX, iVar9, iVar9);
                if (iVar6 == 0) {
                    pcVar2 = (code *)in_RCX[8];
                    *(undefined4 *)(in_RCX + 0x17) = 0x21;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024db04;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    if (iVar6 == 0) goto code_r0x00018024dd16;
                }
                goto code_r0x00018024db0c;
            }
            goto code_r0x00018024dd16;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dab5;
        iVar9 = func_0x000180222340(uVar10, iVar6 + 1);
        if (iVar9 != 0) goto code_r0x00018024db0c;
code_r0x00018024dabd:
        bVar4 = true;
    } else {
code_r0x00018024db0c:
        iVar13 = 0;
        if (*(int64_t *)(in_RDX + 0xa0) == 0) {
            if (((*(uint8_t *)(iVar9 + 0xd8) & 2) != 0) && ((*(uint8_t *)(iVar9 + 0xdc) & 2) == 0)) {
                pcVar2 = (code *)in_RCX[8];
                *(undefined4 *)(in_RCX + 0x17) = 0x23;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024db43;
                iVar6 = (*pcVar2)(0, in_RCX);
                if (iVar6 == 0) goto code_r0x00018024dd16;
            }
            if ((*(uint8_t *)(in_RCX + 0x1b) & 0x80) == 0) {
                pcVar2 = (code *)in_RCX[8];
                *(undefined4 *)(in_RCX + 0x17) = 0x2c;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024db69;
                iVar6 = (*pcVar2)(0, in_RCX);
                if (iVar6 == 0) goto code_r0x00018024dd16;
            }
            if ((*(uint8_t *)(in_RCX + 0x1b) & 8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024db90;
                func_0x0001804986e0((int64_t)&var_8h + iVar8, 0, 0x120);
                if (in_RCX[0x1c] == 0) {
                    uVar10 = in_RCX[2];
                    uVar11 = in_RCX[0x19];
                    uVar3 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dbb5;
                    iVar6 = func_0x00018024bbe0((int64_t)&var_8h + iVar8, uVar3, uVar11, uVar10);
                    if (iVar6 != 0) {
                        uVar10 = in_RCX[5];
                        *(undefined8 *)((int64_t)&var_20h + iVar8) = in_RCX[3];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dbd4;
                        func_0x000180233bc0(*(undefined8 *)((int64_t)&arg_30h + iVar8));
                        *(undefined8 *)((int64_t)&arg_48h + iVar8) = in_RCX[8];
                        *(undefined8 *)((int64_t)&arg_30h + iVar8) = uVar10;
                        *(undefined8 **)((int64_t)&arg_e8h + iVar8) = in_RCX;
                        if (*(int64_t *)((int64_t)&arg_110h + iVar8) == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc05;
                            uVar7 = func_0x000180250d20((int64_t)&var_8h + iVar8);
                        } else {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dbfe;
                            uVar7 = func_0x000180250bf0();
                        }
                        if (0 < (int32_t)uVar7) {
                            uVar10 = in_RCX[0x14];
                            *(undefined8 *)((int64_t)&arg_148h + iVar8) = unaff_RDI;
                            uVar11 = *(undefined8 *)((int64_t)&arg_a8h + iVar8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc2a;
                            iVar6 = func_0x000180222010(uVar10);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc35;
                            uVar10 = func_0x000180222340(uVar10, iVar6 + -1);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc40;
                            iVar6 = func_0x000180222010(uVar11);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc4b;
                            uVar11 = func_0x000180222340(uVar11, iVar6 + -1);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc56;
                            iVar6 = func_0x000180238200(uVar10, uVar11);
                            uVar7 = (uint32_t)(iVar6 == 0);
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc70;
                        func_0x00018024b870((int64_t)&var_8h + iVar8);
                        if (0 < (int32_t)uVar7) goto code_r0x00018024dc91;
                    }
                }
                pcVar2 = (code *)in_RCX[8];
                *(undefined4 *)(in_RCX + 0x17) = 0x36;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dc89;
                iVar6 = (*pcVar2)(0, in_RCX);
                if (iVar6 == 0) goto code_r0x00018024dd16;
            }
code_r0x00018024dc91:
            if ((*(uint8_t *)(in_RDX + 0x90) & 2) != 0) {
                pcVar2 = (code *)in_RCX[8];
                *(undefined4 *)(in_RCX + 0x17) = 0x29;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dcb0;
                iVar6 = (*pcVar2)(0, in_RCX);
                if (iVar6 == 0) goto code_r0x00018024dd16;
            }
        }
        if ((*(uint8_t *)(in_RCX + 0x1b) & 0x40) == 0) {
            uVar7 = *(uint32_t *)(in_RCX[5] + 0x14);
            if ((uVar7 & 2) == 0) {
                if ((uVar7 >> 0x15 & 1) != 0) goto code_r0x00018024ddba;
            } else {
                iVar13 = in_RCX[5] + 8;
            }
            in_RCX[0x1a] = in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dcee;
            uVar10 = func_0x0001801dd170(in_RDX);
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dcf9;
            iVar6 = func_0x00018024c3a0(uVar10, iVar13);
            if (iVar6 != 0) {
                if (0 < iVar6) {
                    pcVar2 = (code *)in_RCX[8];
                    *(undefined4 *)(in_RCX + 0x17) = 0xb;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd48;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    if (iVar6 == 0) goto code_r0x00018024dd16;
                }
code_r0x00018024dd4c:
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd54;
                iVar12 = func_0x000180192480(in_RDX);
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd61;
                    uVar10 = func_0x000180192480(in_RDX);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd6c;
                    iVar6 = func_0x00018024c3a0(uVar10, iVar13);
                    if (iVar6 == 0) {
                        pcVar2 = (code *)in_RCX[8];
                        *(undefined4 *)(in_RCX + 0x17) = 0x10;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd85;
                        iVar6 = (*pcVar2)(0, in_RCX);
                    } else {
                        if ((-1 < iVar6) || ((*(uint8_t *)(in_RCX + 0x1b) & 2) != 0)) goto code_r0x00018024ddb3;
                        pcVar2 = (code *)in_RCX[8];
                        *(undefined4 *)(in_RCX + 0x17) = 0xc;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024ddab;
                        iVar6 = (*pcVar2)(0, in_RCX);
                    }
                    if (iVar6 == 0) goto code_r0x00018024dd16;
                }
code_r0x00018024ddb3:
                in_RCX[0x1a] = 0;
                goto code_r0x00018024ddba;
            }
            pcVar2 = (code *)in_RCX[8];
            *(undefined4 *)(in_RCX + 0x17) = 0xf;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dd12;
            iVar6 = (*pcVar2)(0, in_RCX);
            if (iVar6 != 0) goto code_r0x00018024dd4c;
        } else {
code_r0x00018024ddba:
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024ddc2;
            iVar9 = func_0x000180238400(iVar9);
            if (iVar9 != 0) {
                uVar1 = *(undefined4 *)(in_RCX[5] + 0x14);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024de04;
                iVar6 = func_0x000180237810(in_RDX, iVar9, uVar1);
                if (iVar6 != 0) {
                    *(int32_t *)(in_RCX + 0x17) = iVar6;
                    pcVar2 = (code *)in_RCX[8];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024de19;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    if (iVar6 == 0) goto code_r0x00018024dd16;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024de2c;
                iVar6 = func_0x00018028ec40(in_RDX, iVar9);
                if (iVar6 < 1) {
                    pcVar2 = (code *)in_RCX[8];
                    *(undefined4 *)(in_RCX + 0x17) = 8;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024de4a;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    return iVar6 != 0;
                }
                goto code_r0x00018024dabd;
            }
            pcVar2 = (code *)in_RCX[8];
            *(undefined4 *)(in_RCX + 0x17) = 6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x18024dddf;
            iVar6 = (*pcVar2)(0, in_RCX);
            if (iVar6 != 0) {
                return true;
            }
        }
code_r0x00018024dd16:
        bVar4 = false;
    }
    return bVar4;
}

// ============================================================
// Function: FUN_18024de60
// Address: 0x18024de60
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

undefined8 fcn.18024de60(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024de70;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (((*(int64_t *)(in_RCX + 0xf8) != 0) && ((*(uint8_t *)(*(int64_t *)(in_RCX + 0xf8) + 0x28) & 5) != 0)) &&
       (in_EDX != 0)) {
        uVar3 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18024de9a;
        iVar2 = fcn.180222340(uVar3);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18024dead;
            uVar3 = fcn.18024f970(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                                  *(int64_t *)(&stack0x00000068 + iVar1), *(int64_t *)(&stack0x000000c8 + iVar1));
            if ((int32_t)uVar3 < 0) {
                return uVar3;
            }
            if (0 < (int32_t)uVar3) {
                *(int32_t *)(in_RCX + 0x9c) = in_EDX + -1;
                return 1;
            }
        }
    }
    return 3;
}

// ============================================================
// Function: FUN_18024dee0
// Address: 0x18024dee0
// Size: 2172 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18024dee0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined4 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    uint32_t uVar12;
    int32_t iVar13;
    undefined8 unaff_RDI;
    undefined8 uStack_40;
    int64_t var_10h;
    
    uStack_40 = 0x18024def6;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined4 *)((int64_t)&arg_40h + iVar8) = 0;
    uVar11 = *(undefined8 *)(in_RCX + 0xa0);
    iVar7 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024df13;
    iVar3 = func_0x000180222010(uVar11);
    iVar6 = -1;
    if (*(int64_t *)(in_RCX + 0xe0) == 0) {
        uVar12 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) >> 6 & 1;
        *(undefined4 *)((int64_t)&arg_48h + iVar8) = *(undefined4 *)(*(int64_t *)(in_RCX + 0x28) + 0x18);
    } else {
        uVar12 = 0;
        *(undefined4 *)((int64_t)&arg_48h + iVar8) = 6;
    }
    iVar13 = 0;
    *(uint32_t *)((int64_t)&arg_38h + iVar8) = uVar12;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = unaff_RDI;
    if (0 < iVar3) {
        do {
            uVar11 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024df6e;
            iVar9 = fcn.180222340(uVar11, iVar13);
            if (((*(uint8_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x10) == 0) &&
               ((*(uint32_t *)(iVar9 + 0xd8) & 0x200) != 0)) {
                if (-1 < iVar13) {
                    *(int32_t *)(in_RCX + 0xb4) = iVar13;
                }
                pcVar2 = *(code **)(in_RCX + 0x40);
                *(int64_t *)(in_RCX + 0xc0) = iVar9;
                *(undefined4 *)(in_RCX + 0xb8) = 0x22;
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024dfad;
                iVar4 = (*pcVar2)(0, in_RCX);
                if (iVar4 == 0) {
                    return 0;
                }
            }
            if ((uVar12 == 0) && ((*(uint32_t *)(iVar9 + 0xd8) & 0x400) != 0)) {
                if (-1 < iVar13) {
                    *(int32_t *)(in_RCX + 0xb4) = iVar13;
                }
                pcVar2 = *(code **)(in_RCX + 0x40);
                *(int64_t *)(in_RCX + 0xc0) = iVar9;
                *(undefined4 *)(in_RCX + 0xb8) = 0x28;
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024dfeb;
                iVar4 = (*pcVar2)(0, in_RCX);
                if (iVar4 == 0) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024dffb;
            uVar5 = func_0x00018023b980(iVar9);
            iVar10 = iVar9;
            if (iVar6 == -1) {
                if (((*(uint8_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x20) != 0) && (1 < uVar5)) {
code_r0x00018024e084:
                    if (iVar13 < 0) {
                        iVar4 = *(int32_t *)(in_RCX + 0xb4);
                    } else {
                        *(int32_t *)(in_RCX + 0xb4) = iVar13;
                        iVar4 = iVar13;
                    }
                    if (iVar9 == 0) {
                        uVar11 = *(undefined8 *)(in_RCX + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e0ae;
                        iVar10 = fcn.180222340(uVar11, iVar4);
                    }
                    *(undefined4 *)(in_RCX + 0xb8) = 0x4f;
code_r0x00018024e0b8:
                    *(int64_t *)(in_RCX + 0xc0) = iVar10;
                    pcVar2 = *(code **)(in_RCX + 0x40);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e0ca;
                    iVar4 = (*pcVar2)(0, in_RCX);
                    if (iVar4 == 0) {
                        return 0;
                    }
                }
            } else if (iVar6 == 0) {
                if (uVar5 != 0) {
                    if (iVar13 < 0) {
                        iVar4 = *(int32_t *)(in_RCX + 0xb4);
                    } else {
                        *(int32_t *)(in_RCX + 0xb4) = iVar13;
                        iVar4 = iVar13;
                    }
                    if (iVar9 == 0) {
                        uVar11 = *(undefined8 *)(in_RCX + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e069;
                        iVar10 = fcn.180222340(uVar11, iVar4);
                        *(undefined4 *)(in_RCX + 0xb8) = 0x25;
                    } else {
                        *(undefined4 *)(in_RCX + 0xb8) = 0x25;
                    }
                    goto code_r0x00018024e0b8;
                }
            } else if ((uVar5 == 0) ||
                      (((iVar13 + 1 < iVar3 || ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x20) != 0)) &&
                       (uVar5 != 1)))) goto code_r0x00018024e084;
            if (1 < iVar3) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e0e4;
                iVar10 = func_0x000180238400(iVar9);
                if (iVar10 == 0) {
code_r0x00018024e12a:
                    uVar12 = 0xffffffff;
                    if (iVar13 < 0) {
                        iVar4 = *(int32_t *)(in_RCX + 0xb4);
                    } else {
                        *(int32_t *)(in_RCX + 0xb4) = iVar13;
                        iVar4 = iVar13;
                    }
                    iVar10 = iVar9;
                    if (iVar9 == 0) {
                        uVar11 = *(undefined8 *)(in_RCX + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e159;
                        iVar10 = fcn.180222340(uVar11, iVar4);
                    }
                    *(int64_t *)(in_RCX + 0xc0) = iVar10;
                    pcVar2 = *(code **)(in_RCX + 0x40);
                    *(undefined4 *)(in_RCX + 0xb8) = 1;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e175;
                    iVar4 = (*pcVar2)(0, in_RCX);
                    if (iVar4 == 0) {
                        return 0;
                    }
code_r0x00018024e17d:
                    if (uVar12 == 0) {
                        if (iVar13 < 0) {
                            iVar4 = *(int32_t *)(in_RCX + 0xb4);
                        } else {
                            *(int32_t *)(in_RCX + 0xb4) = iVar13;
                            iVar4 = iVar13;
                        }
                        iVar10 = iVar9;
                        if (iVar9 == 0) {
                            uVar11 = *(undefined8 *)(in_RCX + 0xa0);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e1ab;
                            iVar10 = fcn.180222340(uVar11, iVar4);
                        }
                        *(int64_t *)(in_RCX + 0xc0) = iVar10;
                        pcVar2 = *(code **)(in_RCX + 0x40);
                        *(undefined4 *)(in_RCX + 0xb8) = 0x5e;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e1c7;
                        iVar4 = (*pcVar2)(0, in_RCX);
                        if (iVar4 == 0) {
                            return 0;
                        }
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e0f4;
                    iVar4 = func_0x000180203a00(iVar10);
                    if (iVar4 == 0x198) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e116;
                        iVar4 = func_0x00018022f900(iVar10, 0x1804e49d0, (int64_t)&arg_50h + iVar8);
                        if (iVar4 != 1) goto code_r0x00018024e12a;
                        uVar12 = (uint32_t)(*(int32_t *)((int64_t)&arg_50h + iVar8) == 0);
                        goto code_r0x00018024e17d;
                    }
                }
                uVar12 = *(uint32_t *)((int64_t)&arg_38h + iVar8);
            }
            if (((*(uint8_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x20) != 0) && (1 < iVar3)) {
                if (*(int32_t *)(iVar9 + 0xd0) != -1) {
                    if ((*(uint8_t *)(iVar9 + 0xd8) & 0x10) == 0) {
                        if (-1 < iVar13) {
                            *(int32_t *)(in_RCX + 0xb4) = iVar13;
                        }
                        pcVar2 = *(code **)(in_RCX + 0x40);
                        *(int64_t *)(in_RCX + 0xc0) = iVar9;
                        *(undefined4 *)(in_RCX + 0xb8) = 0x50;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e223;
                        iVar4 = (*pcVar2)(0, in_RCX);
                        if (iVar4 == 0) {
                            return 0;
                        }
                    }
                    if ((*(uint8_t *)(iVar9 + 0xdc) & 4) == 0) {
                        if (-1 < iVar13) {
                            *(int32_t *)(in_RCX + 0xb4) = iVar13;
                        }
                        pcVar2 = *(code **)(in_RCX + 0x40);
                        *(int64_t *)(in_RCX + 0xc0) = iVar9;
                        *(undefined4 *)(in_RCX + 0xb8) = 0x51;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e25a;
                        iVar4 = (*pcVar2)(0, in_RCX);
                        if (iVar4 == 0) {
                            return 0;
                        }
                    }
                }
                if ((*(uint32_t *)(iVar9 + 0xd8) & 0x10011) == 0x11) {
                    if (-1 < iVar13) {
                        *(int32_t *)(in_RCX + 0xb4) = iVar13;
                    }
                    pcVar2 = *(code **)(in_RCX + 0x40);
                    *(int64_t *)(in_RCX + 0xc0) = iVar9;
                    *(undefined4 *)(in_RCX + 0xb8) = 0x59;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e298;
                    iVar4 = (*pcVar2)(0, in_RCX);
                    if (iVar4 == 0) {
                        return 0;
                    }
                }
                if ((*(uint32_t *)(iVar9 + 0xd8) & 0x10) == 0) {
                    if ((*(uint8_t *)(iVar9 + 0xdc) & 4) != 0) {
                        if (-1 < iVar13) {
                            *(int32_t *)(in_RCX + 0xb4) = iVar13;
                        }
                        *(undefined4 *)(in_RCX + 0xb8) = 0x52;
                        goto code_r0x00018024e2e1;
                    }
                } else if ((*(uint32_t *)(iVar9 + 0xd8) & 2) == 0) {
                    if (-1 < iVar13) {
                        *(int32_t *)(in_RCX + 0xb4) = iVar13;
                    }
                    *(undefined4 *)(in_RCX + 0xb8) = 0x5c;
code_r0x00018024e2e1:
                    pcVar2 = *(code **)(in_RCX + 0x40);
                    *(int64_t *)(in_RCX + 0xc0) = iVar9;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e2f3;
                    iVar4 = (*pcVar2)(0, in_RCX);
                    if (iVar4 == 0) {
                        return 0;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e303;
                uVar11 = func_0x0001801e3990(iVar9);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e30b;
                iVar4 = func_0x0001802aca20(uVar11);
                if (iVar4 == 0) {
                    if (-1 < iVar13) {
                        *(int32_t *)(in_RCX + 0xb4) = iVar13;
                    }
                    pcVar2 = *(code **)(in_RCX + 0x40);
                    *(int64_t *)(in_RCX + 0xc0) = iVar9;
                    *(undefined4 *)(in_RCX + 0xb8) = 0x53;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e335;
                    iVar4 = (*pcVar2)(0, in_RCX);
                    if (iVar4 == 0) {
                        return 0;
                    }
                }
                if ((((*(uint8_t *)(iVar9 + 0xd8) & 0x10) != 0) || ((*(uint8_t *)(iVar9 + 0xdc) & 2) != 0)) ||
                   (*(int64_t *)(iVar9 + 0x108) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e361;
                    uVar11 = func_0x000180238460(iVar9);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e369;
                    iVar4 = func_0x0001802aca20(uVar11);
                    if (iVar4 == 0) {
                        if (-1 < iVar13) {
                            *(int32_t *)(in_RCX + 0xb4) = iVar13;
                        }
                        pcVar2 = *(code **)(in_RCX + 0x40);
                        *(int64_t *)(in_RCX + 0xc0) = iVar9;
                        *(undefined4 *)(in_RCX + 0xb8) = 0x54;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e393;
                        iVar4 = (*pcVar2)(0, in_RCX);
                        if (iVar4 == 0) {
                            return 0;
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e3a3;
                uVar11 = func_0x000180238460(iVar9);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e3ab;
                iVar4 = func_0x0001802aca20(uVar11);
                if (((iVar4 == 0) && (*(int64_t *)(iVar9 + 0x108) != 0)) &&
                   ((*(uint32_t *)(iVar9 + 0xd8) & 0x80000) == 0)) {
                    if (-1 < iVar13) {
                        *(int32_t *)(in_RCX + 0xb4) = iVar13;
                    }
                    pcVar2 = *(code **)(in_RCX + 0x40);
                    *(int64_t *)(in_RCX + 0xc0) = iVar9;
                    *(undefined4 *)(in_RCX + 0xb8) = 0x58;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e3eb;
                    iVar4 = (*pcVar2)(0, in_RCX);
                    if (iVar4 == 0) {
                        return 0;
                    }
                }
                if (*(int64_t *)(iVar9 + 0x108) != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e404;
                    iVar4 = func_0x000180222010();
                    if (iVar4 < 1) {
                        if (-1 < iVar13) {
                            *(int32_t *)(in_RCX + 0xb4) = iVar13;
                        }
                        pcVar2 = *(code **)(in_RCX + 0x40);
                        *(int64_t *)(in_RCX + 0xc0) = iVar9;
                        *(undefined4 *)(in_RCX + 0xb8) = 0x57;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e42e;
                        iVar4 = (*pcVar2)(0, in_RCX);
                        if (iVar4 == 0) {
                            return 0;
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e446;
                iVar4 = func_0x00018027cfe0(iVar9 + 0x80, iVar9 + 0x20);
                if (iVar4 != 0) {
                    if (-1 < iVar13) {
                        *(int32_t *)(in_RCX + 0xb4) = iVar13;
                    }
                    pcVar2 = *(code **)(in_RCX + 0x40);
                    *(int64_t *)(in_RCX + 0xc0) = iVar9;
                    *(undefined4 *)(in_RCX + 0xb8) = 0x4e;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e470;
                    iVar4 = (*pcVar2)(0, in_RCX);
                    if (iVar4 == 0) {
                        return 0;
                    }
                }
                if ((*(int64_t *)(iVar9 + 0xf0) != 0) && ((*(uint32_t *)(iVar9 + 0xd8) & 0x20000) != 0)) {
                    if (-1 < iVar13) {
                        *(int32_t *)(in_RCX + 0xb4) = iVar13;
                    }
                    pcVar2 = *(code **)(in_RCX + 0x40);
                    *(int64_t *)(in_RCX + 0xc0) = iVar9;
                    *(undefined4 *)(in_RCX + 0xb8) = 0x5a;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e4b4;
                    iVar4 = (*pcVar2)(0, in_RCX);
                    if (iVar4 == 0) {
                        return 0;
                    }
                }
                if ((*(int64_t *)(iVar9 + 0xe8) != 0) && ((*(uint32_t *)(iVar9 + 0xd8) & 0x40000) != 0)) {
                    if (-1 < iVar13) {
                        *(int32_t *)(in_RCX + 0xb4) = iVar13;
                    }
                    pcVar2 = *(code **)(in_RCX + 0x40);
                    *(int64_t *)(in_RCX + 0xc0) = iVar9;
                    *(undefined4 *)(in_RCX + 0xb8) = 0x5b;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e4f8;
                    iVar4 = (*pcVar2)(0, in_RCX);
                    if (iVar4 == 0) {
                        return 0;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e508;
                iVar4 = func_0x000180237590(iVar9);
                if (iVar4 < 2) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e586;
                    uVar11 = func_0x00018020f790(iVar9);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e58e;
                    iVar4 = func_0x000180222010(uVar11);
                    if (0 < iVar4) {
                        if (-1 < iVar13) {
                            *(int32_t *)(in_RCX + 0xb4) = iVar13;
                        }
                        *(undefined4 *)(in_RCX + 0xb8) = 0x5d;
                        goto code_r0x00018024e5a6;
                    }
                } else {
                    if ((iVar13 + 1 < iVar3) &&
                       ((*(int64_t **)(iVar9 + 0xf0) == (int64_t *)0x0 || (**(int64_t **)(iVar9 + 0xf0) == 0)))) {
                        if (-1 < iVar13) {
                            *(int32_t *)(in_RCX + 0xb4) = iVar13;
                        }
                        pcVar2 = *(code **)(in_RCX + 0x40);
                        *(int64_t *)(in_RCX + 0xc0) = iVar9;
                        *(undefined4 *)(in_RCX + 0xb8) = 0x55;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e54d;
                        iVar4 = (*pcVar2)(0, in_RCX);
                        if (iVar4 == 0) {
                            return 0;
                        }
                    }
                    if (((*(uint8_t *)(iVar9 + 0xd8) & 0x10) != 0) && (*(int64_t *)(iVar9 + 0xe8) == 0)) {
                        if (-1 < iVar13) {
                            *(int32_t *)(in_RCX + 0xb4) = iVar13;
                        }
                        *(undefined4 *)(in_RCX + 0xb8) = 0x56;
code_r0x00018024e5a6:
                        pcVar2 = *(code **)(in_RCX + 0x40);
                        *(int64_t *)(in_RCX + 0xc0) = iVar9;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e5b8;
                        iVar4 = (*pcVar2)(0, in_RCX);
                        if (iVar4 == 0) {
                            return 0;
                        }
                    }
                }
            }
            iVar4 = *(int32_t *)((int64_t)&arg_48h + iVar8);
            if (0 < iVar4) {
                if ((iVar13 < *(int32_t *)(in_RCX + 0x9c)) ||
                   (iVar4 != *(int32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x18))) {
code_r0x00018024e607:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e61b;
                    iVar6 = func_0x00018023bad0(iVar9, iVar4, 0 < iVar6);
                    if ((iVar6 == 0) ||
                       ((iVar6 != 1 && ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x20) != 0)))) {
code_r0x00018024e62e:
                        if (iVar13 < 0) {
                            iVar6 = *(int32_t *)(in_RCX + 0xb4);
                        } else {
                            *(int32_t *)(in_RCX + 0xb4) = iVar13;
                            iVar6 = iVar13;
                        }
                        iVar10 = iVar9;
                        if (iVar9 == 0) {
                            uVar11 = *(undefined8 *)(in_RCX + 0xa0);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e658;
                            iVar10 = fcn.180222340(uVar11, iVar6);
                        }
                        *(int64_t *)(in_RCX + 0xc0) = iVar10;
                        pcVar2 = *(code **)(in_RCX + 0x40);
                        *(undefined4 *)(in_RCX + 0xb8) = 0x1a;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e674;
                        iVar6 = (*pcVar2)(0, in_RCX);
                        if (iVar6 == 0) {
                            return 0;
                        }
                    }
                } else {
                    uVar1 = *(undefined4 *)(*(int64_t *)(in_RCX + 0x28) + 0x1c);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e5f2;
                    iVar4 = func_0x0001802a7e70(iVar9, uVar1, 4);
                    if (iVar4 != 1) {
                        if (iVar4 != 2) {
                            iVar4 = *(int32_t *)((int64_t)&arg_48h + iVar8);
                            goto code_r0x00018024e607;
                        }
                        goto code_r0x00018024e62e;
                    }
                }
            }
            if (iVar13 < 2) {
code_r0x00018024e6c1:
                if (0 < iVar13) {
                    iVar6 = *(int32_t *)((int64_t)&arg_40h + iVar8);
                    goto code_r0x00018024e6c9;
                }
            } else {
                iVar6 = *(int32_t *)((int64_t)&arg_40h + iVar8);
                if ((*(int32_t *)(iVar9 + 0xd0) != -1) && (*(int32_t *)(iVar9 + 0xd0) + iVar7 < iVar6)) {
                    pcVar2 = *(code **)(in_RCX + 0x40);
                    *(int32_t *)(in_RCX + 0xb4) = iVar13;
                    *(int64_t *)(in_RCX + 0xc0) = iVar9;
                    *(undefined4 *)(in_RCX + 0xb8) = 0x19;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e6b9;
                    iVar6 = (*pcVar2)(0, in_RCX);
                    if (iVar6 == 0) {
                        return 0;
                    }
                    goto code_r0x00018024e6c1;
                }
code_r0x00018024e6c9:
                if ((*(uint8_t *)(iVar9 + 0xd8) & 0x20) == 0) {
                    *(int32_t *)((int64_t)&arg_40h + iVar8) = iVar6 + 1;
                }
            }
            if ((*(uint32_t *)(iVar9 + 0xd8) & 0x400) == 0) {
                iVar6 = 1;
            } else {
                if (*(int32_t *)(iVar9 + 0xd4) != -1) {
                    if (*(int32_t *)(iVar9 + 0xd4) < iVar7) {
                        if (-1 < iVar13) {
                            *(int32_t *)(in_RCX + 0xb4) = iVar13;
                        }
                        pcVar2 = *(code **)(in_RCX + 0x40);
                        *(int64_t *)(in_RCX + 0xc0) = iVar9;
                        *(undefined4 *)(in_RCX + 0xb8) = 0x26;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024e71a;
                        iVar7 = (*pcVar2)(0, in_RCX);
                        if (iVar7 == 0) {
                            return 0;
                        }
                    }
                    iVar7 = *(int32_t *)(iVar9 + 0xd4);
                }
                iVar7 = iVar7 + 1;
                iVar6 = 0;
            }
            iVar13 = iVar13 + 1;
        } while (iVar13 < iVar3);
    }
    return 1;
}

// ============================================================
// Function: FUN_18024e760
// Address: 0x18024e760
// Size: 449 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18024e760(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    code *pcVar3;
    bool bVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024e784;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar10 = *(int64_t *)(in_RCX + 0x28);
    uVar2 = *(undefined8 *)(in_RCX + 8);
    iVar11 = 0;
    if (*(int64_t *)(iVar10 + 0x30) == 0) {
code_r0x00018024e840:
        iVar9 = *(int64_t *)(iVar10 + 0x48);
        if (iVar9 != 0) {
            uVar8 = *(undefined8 *)(iVar10 + 0x50);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024e858;
            iVar11 = func_0x00018023d110(uVar2, iVar9, uVar8, 0);
            if (iVar11 < 1) {
                iVar9 = *(int64_t *)(in_RCX + 8);
                *(undefined4 *)(in_RCX + 0xb4) = 0;
                if (iVar9 == 0) {
                    uVar8 = *(undefined8 *)(in_RCX + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024e879;
                    iVar9 = fcn.180222340(uVar8, 0);
                }
                *(int64_t *)(in_RCX + 0xc0) = iVar9;
                pcVar3 = *(code **)(in_RCX + 0x40);
                *(undefined4 *)(in_RCX + 0xb8) = 0x3f;
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024e895;
                iVar11 = (*pcVar3)(0, in_RCX);
                if (iVar11 == 0) goto code_r0x00018024e899;
            }
        }
        iVar9 = *(int64_t *)(iVar10 + 0x58);
        if (iVar9 != 0) {
            uVar8 = *(undefined8 *)(iVar10 + 0x60);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024e8b5;
            iVar11 = func_0x00018023d6c0(uVar2, iVar9, uVar8, 0);
            if (iVar11 < 1) {
                iVar10 = *(int64_t *)(in_RCX + 8);
                *(undefined4 *)(in_RCX + 0xb4) = 0;
                if (iVar10 == 0) {
                    uVar2 = *(undefined8 *)(in_RCX + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024e8d6;
                    iVar10 = fcn.180222340(uVar2, 0);
                }
                pcVar3 = *(code **)(in_RCX + 0x40);
                *(int64_t *)(in_RCX + 0xc0) = iVar10;
                *(undefined4 *)(in_RCX + 0xb8) = 0x40;
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024e8f3;
                iVar11 = (*pcVar3)(0, in_RCX);
                return iVar11 != 0;
            }
        }
        bVar4 = true;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024e7a6;
        iVar5 = func_0x000180222010();
        iVar9 = *(int64_t *)(iVar10 + 0x40);
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024e7c8;
            func_0x000180224990(iVar9, 0x1804e48c8, 0x39f);
            *(undefined8 *)(iVar10 + 0x40) = 0;
        }
        if (iVar5 < 1) {
            if (iVar5 == 0) goto code_r0x00018024e840;
        } else {
            do {
                uVar8 = *(undefined8 *)(iVar10 + 0x30);
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024e7dd;
                uVar8 = fcn.180222340(uVar8, iVar11);
                uVar1 = *(undefined4 *)(iVar10 + 0x38);
                *(undefined8 **)((int64_t)&var_8h + iVar7) = (undefined8 *)(iVar10 + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024e7f4;
                iVar6 = func_0x00018023d3c0(uVar2, uVar8, 0, uVar1);
                if (0 < iVar6) goto code_r0x00018024e840;
                iVar11 = iVar11 + 1;
            } while (iVar11 < iVar5);
        }
        iVar9 = *(int64_t *)(in_RCX + 8);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (iVar9 == 0) {
            uVar8 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024e820;
            iVar9 = fcn.180222340(uVar8, 0);
        }
        *(int64_t *)(in_RCX + 0xc0) = iVar9;
        pcVar3 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x3e;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024e83c;
        iVar11 = (*pcVar3)(0, in_RCX);
        if (iVar11 != 0) goto code_r0x00018024e840;
code_r0x00018024e899:
        bVar4 = false;
    }
    return bVar4;
}

// ============================================================
// Function: FUN_18024e930
// Address: 0x18024e930
// Size: 35 bytes
// ============================================================
bool fcn.18024e930(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18024e93a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18024e945;
    iVar1 = fcn.18023bda0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
    return iVar1 == 0;
}

// ============================================================
// Function: FUN_18024e960
// Address: 0x18024e960
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.18024e960(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024e975;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024e990;
    iVar3 = fcn.180237df0(*(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)(&stack0x00000068 + iVar4), 
                          *(int64_t *)(&stack0x00000070 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (in_RDX == 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024e9b6;
            in_RDX = fcn.180222340(uVar1, 0);
        }
        pcVar2 = *(code **)(in_RCX + 0x40);
        *(int64_t *)(in_RCX + 0xc0) = in_RDX;
        *(int32_t *)(in_RCX + 0xb8) = iVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024e9d2;
        iVar3 = (*pcVar2)(0, in_RCX);
        return iVar3 != 0;
    }
    return true;
}

// ============================================================
// Function: FUN_18024e996
// Address: 0x18024e996
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.18024e960(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024e975;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024e990;
    iVar3 = fcn.180237df0(*(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)(&stack0x00000068 + iVar4), 
                          *(int64_t *)(&stack0x00000070 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (in_RDX == 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024e9b6;
            in_RDX = fcn.180222340(uVar1, 0);
        }
        pcVar2 = *(code **)(in_RCX + 0x40);
        *(int64_t *)(in_RCX + 0xc0) = in_RDX;
        *(int32_t *)(in_RCX + 0xb8) = iVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024e9d2;
        iVar3 = (*pcVar2)(0, in_RCX);
        return iVar3 != 0;
    }
    return true;
}

// ============================================================
// Function: FUN_18024e9ef
// Address: 0x18024e9ef
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.18024e960(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024e975;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024e990;
    iVar3 = fcn.180237df0(*(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)(&stack0x00000068 + iVar4), 
                          *(int64_t *)(&stack0x00000070 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (in_RDX == 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024e9b6;
            in_RDX = fcn.180222340(uVar1, 0);
        }
        pcVar2 = *(code **)(in_RCX + 0x40);
        *(int64_t *)(in_RCX + 0xc0) = in_RDX;
        *(int32_t *)(in_RCX + 0xb8) = iVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024e9d2;
        iVar3 = (*pcVar2)(0, in_RCX);
        return iVar3 != 0;
    }
    return true;
}

// ============================================================
// Function: FUN_18024ea10
// Address: 0x18024ea10
// Size: 786 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_19h

undefined8 fcn.18024ea10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int32_t *piVar12;
    int64_t in_RCX;
    int32_t iVar13;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_20 [7];
    int64_t var_19h;
    
    _auStack_20 = 0x18024ea34;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined8 *)(auStack_20 + iVar6) = 0x18024ea46;
    iVar3 = fcn.180222010(uVar8);
    do {
        do {
            iVar3 = iVar3 + -1;
            if (iVar3 < 0) {
                return 1;
            }
            uVar8 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)(auStack_20 + iVar6) = 0x18024ea6f;
            iVar7 = fcn.180222340(uVar8, iVar3);
        } while ((iVar3 != 0) && ((*(uint8_t *)(iVar7 + 0xd8) & 0x20) != 0));
        if ((*(uint32_t *)(iVar7 + 0xd8) & 0x400) != 0) {
            *(undefined8 *)(auStack_20 + iVar6) = 0x18024ea9c;
            uVar8 = fcn.180238460(iVar7);
            *(undefined8 *)(auStack_20 + iVar6) = 0x18024eaa7;
            uVar9 = fcn.1801e3990(iVar7);
            *(undefined8 *)(auStack_20 + iVar6) = 0x18024eab2;
            iVar4 = func_0x0001802aca20(uVar8);
            iVar14 = iVar4 + -1;
            if (0 < iVar14) {
                *(undefined8 *)(auStack_20 + iVar6) = 0x18024eacc;
                iVar13 = func_0x0001802aca20(uVar9);
                *(undefined8 *)(auStack_20 + iVar6) = 0x18024ead7;
                iVar5 = func_0x0001802aca20(uVar8);
                if (iVar5 == iVar13 + 1) {
                    *(undefined8 *)(auStack_20 + iVar6) = 0x18024eaf0;
                    uVar9 = func_0x0001802aca50(uVar8, iVar4 + -2);
                    *(undefined8 *)(auStack_20 + iVar6) = 0x18024eaf8;
                    iVar4 = func_0x0001802007d0(uVar9);
                    *(undefined8 *)(auStack_20 + iVar6) = 0x18024eb04;
                    uVar9 = func_0x0001802aca50(uVar8, iVar14);
                    *(undefined8 *)(auStack_20 + iVar6) = 0x18024eb0c;
                    iVar13 = func_0x0001802007d0(uVar9);
                    if (iVar13 != iVar4) {
                        *(undefined8 *)(auStack_20 + iVar6) = 0x18024eb1f;
                        iVar10 = func_0x0001802348d0(uVar8);
                        if (iVar10 == 0) {
                            *(undefined8 *)(auStack_20 + iVar6) = 0x18024ece3;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6));
                            *(undefined8 *)(auStack_20 + iVar6) = 0x18024ecfb;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar6));
                            *(undefined8 *)(auStack_20 + iVar6) = 0x18024ed0d;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                            *(undefined4 *)(in_RCX + 0xb8) = 0x11;
                            return 0xffffffff;
                        }
                        *(undefined8 *)(auStack_20 + iVar6) = 0x18024eb35;
                        uVar8 = func_0x0001802ac940(iVar10, iVar14);
                        *(undefined8 *)(auStack_20 + iVar6) = 0x18024eb40;
                        fcn.18020e940(uVar8);
                        *(undefined8 *)(auStack_20 + iVar6) = 0x18024eb48;
                        iVar4 = fcn.18022cd20(*(int64_t *)((int64_t)&var_10h + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                              *(int64_t *)(&stack0x00000050 + iVar6));
                        if (iVar4 == 0xd) {
                            *(undefined8 *)(auStack_20 + iVar6) = 0x18024eb58;
                            iVar4 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar6));
                            if (iVar4 == 0) {
                                *(undefined8 *)(auStack_20 + iVar6) = 0x18024eb64;
                                func_0x000180234890(uVar8);
                                *(undefined8 *)(auStack_20 + iVar6) = 0x18024eb6c;
                                func_0x0001802348f0(iVar10);
                                goto code_r0x00018024ebaa;
                            }
                        }
                        *(undefined8 *)(auStack_20 + iVar6) = 0x18024eb7b;
                        func_0x000180234890(uVar8);
                        *(undefined8 *)(auStack_20 + iVar6) = 0x18024eb83;
                        func_0x0001802348f0(iVar10);
                    }
                }
            }
            pcVar2 = *(code **)(in_RCX + 0x40);
            *(int32_t *)(in_RCX + 0xb4) = iVar3;
            *(int64_t *)(in_RCX + 0xc0) = iVar7;
            *(undefined4 *)(in_RCX + 0xb8) = 0x48;
            *(undefined8 *)(auStack_20 + iVar6) = 0x18024eba2;
            iVar4 = (*pcVar2)(0, in_RCX);
            if (iVar4 == 0) {
                return 0;
            }
        }
code_r0x00018024ebaa:
        uVar8 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)(auStack_20 + iVar6) = 0x18024ebb6;
        iVar4 = fcn.180222010(uVar8);
joined_r0x00018024ebbc:
        iVar4 = iVar4 + -1;
        if (iVar3 < iVar4) {
            uVar8 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)(auStack_20 + iVar6) = 0x18024ebd0;
            iVar10 = fcn.180222340(uVar8, iVar4);
            iVar10 = *(int64_t *)(iVar10 + 0x110);
            if (iVar10 != 0) {
                *(undefined8 *)(auStack_20 + iVar6) = 0x18024ebeb;
                iVar14 = func_0x000180290d20(iVar7, iVar10);
                if (iVar14 == 0) {
                    if ((iVar3 != 0) || (uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x38), (uVar1 & 0x20) != 0)
                       ) goto joined_r0x00018024ebbc;
                    if ((uVar1 & 1) == 0) {
                        *(undefined8 *)(auStack_20 + iVar6) = 0x18024ec20;
                        iVar11 = fcn.1802394c0(*(int64_t *)((int64_t)&var_18h + iVar6), 
                                               *(int64_t *)((int64_t)&var_20h + iVar6), 
                                               *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                               *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                               *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                               *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                               *(int64_t *)(&stack0x00000048 + iVar6));
                        if (iVar11 != 0) {
                            iVar13 = 0;
                            *(undefined8 *)(auStack_20 + iVar6) = 0x18024ec32;
                            iVar14 = fcn.180222010(iVar11);
                            if (0 < iVar14) {
                                do {
                                    *(undefined8 *)(auStack_20 + iVar6) = 0x18024ec40;
                                    piVar12 = (int32_t *)fcn.180222340(iVar11, iVar13);
                                    if (*piVar12 == 2) {
                                        *(undefined8 *)(auStack_20 + iVar6) = 0x18024ecdc;
                                        func_0x00018028f450(iVar11);
                                        goto joined_r0x00018024ebbc;
                                    }
                                    iVar13 = iVar13 + 1;
                                    *(undefined8 *)(auStack_20 + iVar6) = 0x18024ec53;
                                    iVar14 = fcn.180222010();
                                } while (iVar13 < iVar14);
                            }
                            *(undefined8 *)(auStack_20 + iVar6) = 0x18024ec5f;
                            func_0x00018028f450(iVar11);
                        }
                    }
                    *(undefined8 *)(auStack_20 + iVar6) = 0x18024ec6a;
                    iVar14 = func_0x000180290f20(iVar7, iVar10);
                    if (iVar14 == 0) goto joined_r0x00018024ebbc;
                }
                if (iVar14 == 0x11) {
                    return 0xffffffff;
                }
                *(int32_t *)(in_RCX + 0xb8) = iVar14;
                pcVar2 = *(code **)(in_RCX + 0x40);
                *(int32_t *)(in_RCX + 0xb4) = iVar3;
                *(int64_t *)(in_RCX + 0xc0) = iVar7;
                *(undefined8 *)(auStack_20 + iVar6) = 0x18024ec96;
                iVar14 = (*pcVar2)(0, in_RCX);
                if (iVar14 == 0) {
                    return 0;
                }
            }
            goto joined_r0x00018024ebbc;
        }
    } while( true );
}

// ============================================================
// Function: FUN_18024ed30
// Address: 0x18024ed30
// Size: 556 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18024ed30(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    code *pcVar4;
    bool bVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024ed4a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int64_t *)(in_RCX + 0xe0) == 0) {
        puVar1 = (undefined8 *)(in_RCX + 0xa0);
        if (*(int32_t *)(in_RCX + 0x100) != 0) {
            uVar2 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024ed78;
            iVar6 = func_0x000180222110(uVar2, 0);
            if (iVar6 == 0) goto code_r0x00018024edcf;
        }
        uVar2 = *puVar1;
        uVar3 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x28) + 0x28);
        *(undefined4 *)((int64_t)&iStackX_20 + iVar7 + -8) = *(undefined4 *)(*(int64_t *)(in_RCX + 0x28) + 0x14);
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024edae;
        iVar6 = func_0x0001802c9a80(in_RCX + 0xa8, in_RCX + 0xb0, uVar2, uVar3);
        if (*(int32_t *)(in_RCX + 0x100) != 0) {
            uVar2 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024edc1;
            func_0x000180222020(uVar2);
        }
        if (iVar6 == 0) {
code_r0x00018024edcf:
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024edd4;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024ede9;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024edf8;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined4 *)(in_RCX + 0xb8) = 0x11;
            return 0xffffffff;
        }
        if (iVar6 == -1) {
            uVar2 = *puVar1;
            bVar5 = false;
            iVar10 = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024ee21;
            iVar6 = fcn.180222010(uVar2);
            if (0 < iVar6) {
                do {
                    uVar2 = *puVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024ee2f;
                    iVar8 = fcn.180222340(uVar2, iVar10);
                    if ((*(uint32_t *)(iVar8 + 0xd8) & 0x800) != 0) {
                        bVar5 = true;
                        if (-1 < iVar10) {
                            *(int32_t *)(in_RCX + 0xb4) = iVar10;
                        }
                        *(int64_t *)(in_RCX + 0xc0) = iVar8;
                        pcVar4 = *(code **)(in_RCX + 0x40);
                        *(undefined4 *)(in_RCX + 0xb8) = 0x2a;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024ee66;
                        iVar6 = (*pcVar4)(0, in_RCX);
                        if (iVar6 == 0) {
                            return 0;
                        }
                    }
                    uVar2 = *puVar1;
                    iVar10 = iVar10 + 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024ee74;
                    iVar6 = fcn.180222010(uVar2);
                } while (iVar10 < iVar6);
                if (bVar5) {
                    return 1;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024ee85;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024ee9d;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024eeaf;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (iVar6 == -2) {
            pcVar4 = *(code **)(in_RCX + 0x40);
            *(undefined8 *)(in_RCX + 0xc0) = 0;
            *(undefined4 *)(in_RCX + 0xb8) = 0x2b;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024eed9;
            uVar9 = (*pcVar4)(0, in_RCX);
            return uVar9;
        }
        if (iVar6 != 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024eee5;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024eefd;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024ef0f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x800) != 0) {
            pcVar4 = *(code **)(in_RCX + 0x40);
            *(undefined8 *)(in_RCX + 0xc0) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18024ef38;
            iVar6 = (*pcVar4)(2, in_RCX);
            return (uint64_t)(iVar6 != 0);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18024ef60
// Address: 0x18024ef60
// Size: 516 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18024ef60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    uint32_t uVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18024ef82;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar11 = 0;
    iVar3 = 0;
    iVar5 = 0;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14);
    uVar12 = uVar1 & 0xc00000;
    uVar9 = uVar1 & 8;
    *(uint32_t *)((int64_t)&arg_28h + iVar6) = uVar12;
    uVar13 = uVar1 & 0xc;
    if (uVar13 == 0) {
        if (uVar12 == 0) {
            return 1;
        }
    } else if (uVar12 == 0) goto code_r0x00018024f0d8;
    iVar10 = iVar11;
    if ((uVar1 & 0x800000) == 0) {
        if (uVar9 != 0) goto code_r0x00018024f003;
        iVar3 = iVar5;
        if (*(int64_t *)(in_RCX + 0xe0) != 0) {
            return 1;
        }
code_r0x00018024f020:
        do {
            uVar8 = *(undefined8 *)(in_RCX + 0xa0);
            *(int32_t *)(in_RCX + 0xb4) = iVar10;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024f034;
            iVar7 = fcn.180222340(uVar8, iVar10);
            *(int64_t *)(in_RCX + 0xc0) = iVar7;
            if ((*(uint32_t *)(iVar7 + 0xd8) & 0x2000) == 0) {
                uVar8 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024f056;
                uVar8 = fcn.180222340(uVar8, iVar10 + 1);
                *(undefined8 *)(in_RCX + 200) = uVar8;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024f065;
                iVar4 = func_0x00018024d840(in_RCX);
                if (iVar4 == 1) {
                    iVar11 = 0x4a;
                    if (*(int32_t *)(in_RCX + 0xb8) != 0) {
                        iVar11 = *(int32_t *)(in_RCX + 0xb8);
                    }
                    pcVar2 = *(code **)(in_RCX + 0x40);
                    *(int32_t *)(in_RCX + 0xb8) = iVar11;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024f114;
                    uVar8 = (*pcVar2)(0, in_RCX);
                    return uVar8;
                }
                if (iVar4 != 0) {
                    if ((uVar9 == 0) && ((uVar13 == 0 || (iVar10 != 0)))) {
                        pcVar2 = *(code **)(in_RCX + 0x40);
                        *(undefined4 *)(in_RCX + 0xb8) = 0x4a;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024f091;
                        iVar4 = (*pcVar2)(0, in_RCX);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024f0b7;
                        iVar4 = func_0x00018024d530(in_RCX);
                    }
                    if (iVar4 == 0) {
                        return 0;
                    }
                }
            }
            iVar10 = iVar10 + 1;
        } while (iVar10 <= iVar3);
        uVar12 = *(uint32_t *)((int64_t)&arg_28h + iVar6);
    } else {
        uVar8 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024efff;
        iVar3 = fcn.180222010(uVar8);
        iVar3 = iVar3 + -1;
code_r0x00018024f003:
        if (-1 < iVar3) goto code_r0x00018024f020;
    }
    if (uVar13 == 0) {
        return 1;
    }
code_r0x00018024f0d8:
    if ((uVar1 & 0x800000) == 0) {
        if (uVar9 == 0) {
            if (*(int64_t *)(in_RCX + 0xe0) != 0) {
                return 1;
            }
        } else {
            uVar8 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024f0f1;
            iVar5 = fcn.180222010(uVar8);
            iVar5 = iVar5 + -1;
        }
        if ((uVar12 != 0) && (uVar9 != 0)) {
            iVar11 = 1;
        }
        for (; iVar11 <= iVar5; iVar11 = iVar11 + 1) {
            *(int32_t *)(in_RCX + 0xb4) = iVar11;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024f14e;
            iVar3 = func_0x00018024d530(in_RCX);
            if (iVar3 == 0) {
                return 0;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18024f170
// Address: 0x18024f170
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_1eh

uint64_t fcn.18024f170(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t in_RCX;
    uint64_t in_RDX;
    int32_t iVar12;
    uint32_t uVar13;
    undefined8 unaff_RBX;
    uint64_t uVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar15;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_28;
    int64_t var_1eh;
    
    uStack_28 = 0x18024f182;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *(int64_t *)(in_RCX + 0xf8);
    uVar9 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f19e;
    iVar4 = fcn.180222010(uVar9);
    iVar15 = (int32_t)in_RDX;
    if ((((iVar2 != 0) && ((*(uint8_t *)(iVar2 + 0x28) & 5) != 0)) && (0 < iVar15)) && (iVar15 < iVar4)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f1c2;
        uVar7 = fcn.18024de60(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8));
        if ((int32_t)uVar7 != 3) {
            return uVar7;
        }
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RBP;
    uVar14 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar6 + -8) = unaff_R15;
    iVar12 = 0;
    uVar7 = in_RDX & 0xffffffff;
    if (iVar15 < iVar4) {
        do {
            uVar14 = uVar7;
            uVar9 = *(undefined8 *)(in_RCX + 0xa0);
            iVar12 = (int32_t)uVar14;
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f1fe;
            iVar8 = fcn.180222340(uVar9, uVar14);
            uVar1 = *(undefined4 *)(*(int64_t *)(in_RCX + 0x28) + 0x1c);
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f213;
            iVar5 = func_0x0001802a7e70(iVar8, uVar1, 0);
            if (iVar5 == 1) goto code_r0x00018024f3c4;
            if (iVar5 == 2) {
                if (-1 < iVar12) goto code_r0x00018024f35e;
                uVar14 = (uint64_t)*(uint32_t *)(in_RCX + 0xb4);
                goto code_r0x00018024f364;
            }
            uVar7 = (uint64_t)(iVar12 + 1U);
        } while ((int32_t)(iVar12 + 1U) < iVar4);
        if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80000) == 0) {
            return 3;
        }
    } else {
        if (iVar15 != iVar4) {
            return 3;
        }
        if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80000) == 0) {
            return 3;
        }
        uVar9 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f290;
        iVar8 = fcn.180222340(uVar9, 0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f29b;
        fcn.180229b10();
        pcVar3 = *(code **)(in_RCX + 0x80);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2aa;
        uVar9 = fcn.180238460(iVar8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2b2;
        iVar10 = (*pcVar3)(in_RCX, uVar9);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2ba;
        fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_8 + iVar6));
        if (iVar10 == 0) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2c9;
        iVar4 = fcn.180222010(iVar10);
        uVar7 = uVar14;
        uVar11 = uVar14;
        if (0 < iVar4) {
            do {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2da;
                uVar11 = fcn.180222340(iVar10, uVar7);
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2e8;
                iVar4 = func_0x000180238200(uVar11, iVar8);
                if (iVar4 == 0) break;
                uVar11 = 0;
                uVar13 = (int32_t)uVar7 + 1;
                uVar7 = (uint64_t)uVar13;
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2f9;
                iVar4 = fcn.180222010(iVar10);
            } while ((int32_t)uVar13 < iVar4);
        }
        uVar7 = uVar14;
        if (uVar11 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f312;
            iVar4 = func_0x0001802375f0(uVar11);
            uVar7 = uVar11;
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f31e;
                func_0x000180238640(iVar10);
                return 0xffffffff;
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f333;
        func_0x000180238640(iVar10);
        if (uVar11 == 0) {
            return 3;
        }
        uVar1 = *(undefined4 *)(*(int64_t *)(in_RCX + 0x28) + 0x1c);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f34d;
        iVar4 = func_0x0001802a7e70(uVar7, uVar1, 0);
        if (iVar4 == 2) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f35a;
            func_0x00018021fe80(uVar7);
code_r0x00018024f35e:
            *(int32_t *)(in_RCX + 0xb4) = iVar12;
code_r0x00018024f364:
            if (iVar8 == 0) {
                uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f377;
                iVar8 = fcn.180222340(uVar9, uVar14);
            }
            pcVar3 = *(code **)(in_RCX + 0x40);
            *(int64_t *)(in_RCX + 0xc0) = iVar8;
            *(undefined4 *)(in_RCX + 0xb8) = 0x1c;
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f397;
            iVar4 = (*pcVar3)(0, in_RCX);
            return (uint64_t)((iVar4 != 0) + 2);
        }
        uVar9 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f3b6;
        func_0x0001802221b0(uVar9, 0, uVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f3be;
        func_0x00018021fe80(iVar8);
        *(undefined4 *)(in_RCX + 0x9c) = 0;
    }
code_r0x00018024f3c4:
    if (iVar2 != 0) {
        uVar9 = *(undefined8 *)(iVar2 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f3d2;
        iVar4 = fcn.180222010(uVar9);
        if (0 < iVar4) {
            if (*(int32_t *)(iVar2 + 0x30) < 0) {
                *(int32_t *)(iVar2 + 0x30) = iVar15;
            }
            if (*(int32_t *)(iVar2 + 0x2c) < 0) {
                return 3;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18024f1cb
// Address: 0x18024f1cb
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_1eh

uint64_t fcn.18024f170(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t in_RCX;
    uint64_t in_RDX;
    int32_t iVar12;
    uint32_t uVar13;
    undefined8 unaff_RBX;
    uint64_t uVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar15;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_28;
    int64_t var_1eh;
    
    uStack_28 = 0x18024f182;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *(int64_t *)(in_RCX + 0xf8);
    uVar9 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f19e;
    iVar4 = fcn.180222010(uVar9);
    iVar15 = (int32_t)in_RDX;
    if ((((iVar2 != 0) && ((*(uint8_t *)(iVar2 + 0x28) & 5) != 0)) && (0 < iVar15)) && (iVar15 < iVar4)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f1c2;
        uVar7 = fcn.18024de60(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8));
        if ((int32_t)uVar7 != 3) {
            return uVar7;
        }
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RBP;
    uVar14 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar6 + -8) = unaff_R15;
    iVar12 = 0;
    uVar7 = in_RDX & 0xffffffff;
    if (iVar15 < iVar4) {
        do {
            uVar14 = uVar7;
            uVar9 = *(undefined8 *)(in_RCX + 0xa0);
            iVar12 = (int32_t)uVar14;
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f1fe;
            iVar8 = fcn.180222340(uVar9, uVar14);
            uVar1 = *(undefined4 *)(*(int64_t *)(in_RCX + 0x28) + 0x1c);
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f213;
            iVar5 = func_0x0001802a7e70(iVar8, uVar1, 0);
            if (iVar5 == 1) goto code_r0x00018024f3c4;
            if (iVar5 == 2) {
                if (-1 < iVar12) goto code_r0x00018024f35e;
                uVar14 = (uint64_t)*(uint32_t *)(in_RCX + 0xb4);
                goto code_r0x00018024f364;
            }
            uVar7 = (uint64_t)(iVar12 + 1U);
        } while ((int32_t)(iVar12 + 1U) < iVar4);
        if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80000) == 0) {
            return 3;
        }
    } else {
        if (iVar15 != iVar4) {
            return 3;
        }
        if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80000) == 0) {
            return 3;
        }
        uVar9 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f290;
        iVar8 = fcn.180222340(uVar9, 0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f29b;
        fcn.180229b10();
        pcVar3 = *(code **)(in_RCX + 0x80);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2aa;
        uVar9 = fcn.180238460(iVar8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2b2;
        iVar10 = (*pcVar3)(in_RCX, uVar9);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2ba;
        fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_8 + iVar6));
        if (iVar10 == 0) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2c9;
        iVar4 = fcn.180222010(iVar10);
        uVar7 = uVar14;
        uVar11 = uVar14;
        if (0 < iVar4) {
            do {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2da;
                uVar11 = fcn.180222340(iVar10, uVar7);
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2e8;
                iVar4 = func_0x000180238200(uVar11, iVar8);
                if (iVar4 == 0) break;
                uVar11 = 0;
                uVar13 = (int32_t)uVar7 + 1;
                uVar7 = (uint64_t)uVar13;
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2f9;
                iVar4 = fcn.180222010(iVar10);
            } while ((int32_t)uVar13 < iVar4);
        }
        uVar7 = uVar14;
        if (uVar11 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f312;
            iVar4 = func_0x0001802375f0(uVar11);
            uVar7 = uVar11;
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f31e;
                func_0x000180238640(iVar10);
                return 0xffffffff;
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f333;
        func_0x000180238640(iVar10);
        if (uVar11 == 0) {
            return 3;
        }
        uVar1 = *(undefined4 *)(*(int64_t *)(in_RCX + 0x28) + 0x1c);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f34d;
        iVar4 = func_0x0001802a7e70(uVar7, uVar1, 0);
        if (iVar4 == 2) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f35a;
            func_0x00018021fe80(uVar7);
code_r0x00018024f35e:
            *(int32_t *)(in_RCX + 0xb4) = iVar12;
code_r0x00018024f364:
            if (iVar8 == 0) {
                uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f377;
                iVar8 = fcn.180222340(uVar9, uVar14);
            }
            pcVar3 = *(code **)(in_RCX + 0x40);
            *(int64_t *)(in_RCX + 0xc0) = iVar8;
            *(undefined4 *)(in_RCX + 0xb8) = 0x1c;
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f397;
            iVar4 = (*pcVar3)(0, in_RCX);
            return (uint64_t)((iVar4 != 0) + 2);
        }
        uVar9 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f3b6;
        func_0x0001802221b0(uVar9, 0, uVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f3be;
        func_0x00018021fe80(iVar8);
        *(undefined4 *)(in_RCX + 0x9c) = 0;
    }
code_r0x00018024f3c4:
    if (iVar2 != 0) {
        uVar9 = *(undefined8 *)(iVar2 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f3d2;
        iVar4 = fcn.180222010(uVar9);
        if (0 < iVar4) {
            if (*(int32_t *)(iVar2 + 0x30) < 0) {
                *(int32_t *)(iVar2 + 0x30) = iVar15;
            }
            if (*(int32_t *)(iVar2 + 0x2c) < 0) {
                return 3;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18024f252
// Address: 0x18024f252
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_1eh

uint64_t fcn.18024f170(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t in_RCX;
    uint64_t in_RDX;
    int32_t iVar12;
    uint32_t uVar13;
    undefined8 unaff_RBX;
    uint64_t uVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar15;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_28;
    int64_t var_1eh;
    
    uStack_28 = 0x18024f182;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *(int64_t *)(in_RCX + 0xf8);
    uVar9 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f19e;
    iVar4 = fcn.180222010(uVar9);
    iVar15 = (int32_t)in_RDX;
    if ((((iVar2 != 0) && ((*(uint8_t *)(iVar2 + 0x28) & 5) != 0)) && (0 < iVar15)) && (iVar15 < iVar4)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f1c2;
        uVar7 = fcn.18024de60(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8));
        if ((int32_t)uVar7 != 3) {
            return uVar7;
        }
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RBP;
    uVar14 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar6 + -8) = unaff_R15;
    iVar12 = 0;
    uVar7 = in_RDX & 0xffffffff;
    if (iVar15 < iVar4) {
        do {
            uVar14 = uVar7;
            uVar9 = *(undefined8 *)(in_RCX + 0xa0);
            iVar12 = (int32_t)uVar14;
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f1fe;
            iVar8 = fcn.180222340(uVar9, uVar14);
            uVar1 = *(undefined4 *)(*(int64_t *)(in_RCX + 0x28) + 0x1c);
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f213;
            iVar5 = func_0x0001802a7e70(iVar8, uVar1, 0);
            if (iVar5 == 1) goto code_r0x00018024f3c4;
            if (iVar5 == 2) {
                if (-1 < iVar12) goto code_r0x00018024f35e;
                uVar14 = (uint64_t)*(uint32_t *)(in_RCX + 0xb4);
                goto code_r0x00018024f364;
            }
            uVar7 = (uint64_t)(iVar12 + 1U);
        } while ((int32_t)(iVar12 + 1U) < iVar4);
        if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80000) == 0) {
            return 3;
        }
    } else {
        if (iVar15 != iVar4) {
            return 3;
        }
        if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80000) == 0) {
            return 3;
        }
        uVar9 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f290;
        iVar8 = fcn.180222340(uVar9, 0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f29b;
        fcn.180229b10();
        pcVar3 = *(code **)(in_RCX + 0x80);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2aa;
        uVar9 = fcn.180238460(iVar8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2b2;
        iVar10 = (*pcVar3)(in_RCX, uVar9);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2ba;
        fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_8 + iVar6));
        if (iVar10 == 0) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2c9;
        iVar4 = fcn.180222010(iVar10);
        uVar7 = uVar14;
        uVar11 = uVar14;
        if (0 < iVar4) {
            do {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2da;
                uVar11 = fcn.180222340(iVar10, uVar7);
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2e8;
                iVar4 = func_0x000180238200(uVar11, iVar8);
                if (iVar4 == 0) break;
                uVar11 = 0;
                uVar13 = (int32_t)uVar7 + 1;
                uVar7 = (uint64_t)uVar13;
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2f9;
                iVar4 = fcn.180222010(iVar10);
            } while ((int32_t)uVar13 < iVar4);
        }
        uVar7 = uVar14;
        if (uVar11 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f312;
            iVar4 = func_0x0001802375f0(uVar11);
            uVar7 = uVar11;
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f31e;
                func_0x000180238640(iVar10);
                return 0xffffffff;
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f333;
        func_0x000180238640(iVar10);
        if (uVar11 == 0) {
            return 3;
        }
        uVar1 = *(undefined4 *)(*(int64_t *)(in_RCX + 0x28) + 0x1c);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f34d;
        iVar4 = func_0x0001802a7e70(uVar7, uVar1, 0);
        if (iVar4 == 2) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f35a;
            func_0x00018021fe80(uVar7);
code_r0x00018024f35e:
            *(int32_t *)(in_RCX + 0xb4) = iVar12;
code_r0x00018024f364:
            if (iVar8 == 0) {
                uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f377;
                iVar8 = fcn.180222340(uVar9, uVar14);
            }
            pcVar3 = *(code **)(in_RCX + 0x40);
            *(int64_t *)(in_RCX + 0xc0) = iVar8;
            *(undefined4 *)(in_RCX + 0xb8) = 0x1c;
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f397;
            iVar4 = (*pcVar3)(0, in_RCX);
            return (uint64_t)((iVar4 != 0) + 2);
        }
        uVar9 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f3b6;
        func_0x0001802221b0(uVar9, 0, uVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f3be;
        func_0x00018021fe80(iVar8);
        *(undefined4 *)(in_RCX + 0x9c) = 0;
    }
code_r0x00018024f3c4:
    if (iVar2 != 0) {
        uVar9 = *(undefined8 *)(iVar2 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f3d2;
        iVar4 = fcn.180222010(uVar9);
        if (0 < iVar4) {
            if (*(int32_t *)(iVar2 + 0x30) < 0) {
                *(int32_t *)(iVar2 + 0x30) = iVar15;
            }
            if (*(int32_t *)(iVar2 + 0x2c) < 0) {
                return 3;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18024f25e
// Address: 0x18024f25e
// Size: 406 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_1eh

uint64_t fcn.18024f170(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t in_RCX;
    uint64_t in_RDX;
    int32_t iVar12;
    uint32_t uVar13;
    undefined8 unaff_RBX;
    uint64_t uVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar15;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_28;
    int64_t var_1eh;
    
    uStack_28 = 0x18024f182;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *(int64_t *)(in_RCX + 0xf8);
    uVar9 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f19e;
    iVar4 = fcn.180222010(uVar9);
    iVar15 = (int32_t)in_RDX;
    if ((((iVar2 != 0) && ((*(uint8_t *)(iVar2 + 0x28) & 5) != 0)) && (0 < iVar15)) && (iVar15 < iVar4)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f1c2;
        uVar7 = fcn.18024de60(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8));
        if ((int32_t)uVar7 != 3) {
            return uVar7;
        }
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RBP;
    uVar14 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar6 + -8) = unaff_R15;
    iVar12 = 0;
    uVar7 = in_RDX & 0xffffffff;
    if (iVar15 < iVar4) {
        do {
            uVar14 = uVar7;
            uVar9 = *(undefined8 *)(in_RCX + 0xa0);
            iVar12 = (int32_t)uVar14;
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f1fe;
            iVar8 = fcn.180222340(uVar9, uVar14);
            uVar1 = *(undefined4 *)(*(int64_t *)(in_RCX + 0x28) + 0x1c);
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f213;
            iVar5 = func_0x0001802a7e70(iVar8, uVar1, 0);
            if (iVar5 == 1) goto code_r0x00018024f3c4;
            if (iVar5 == 2) {
                if (-1 < iVar12) goto code_r0x00018024f35e;
                uVar14 = (uint64_t)*(uint32_t *)(in_RCX + 0xb4);
                goto code_r0x00018024f364;
            }
            uVar7 = (uint64_t)(iVar12 + 1U);
        } while ((int32_t)(iVar12 + 1U) < iVar4);
        if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80000) == 0) {
            return 3;
        }
    } else {
        if (iVar15 != iVar4) {
            return 3;
        }
        if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80000) == 0) {
            return 3;
        }
        uVar9 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f290;
        iVar8 = fcn.180222340(uVar9, 0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f29b;
        fcn.180229b10();
        pcVar3 = *(code **)(in_RCX + 0x80);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2aa;
        uVar9 = fcn.180238460(iVar8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2b2;
        iVar10 = (*pcVar3)(in_RCX, uVar9);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2ba;
        fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_8 + iVar6));
        if (iVar10 == 0) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2c9;
        iVar4 = fcn.180222010(iVar10);
        uVar7 = uVar14;
        uVar11 = uVar14;
        if (0 < iVar4) {
            do {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2da;
                uVar11 = fcn.180222340(iVar10, uVar7);
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2e8;
                iVar4 = func_0x000180238200(uVar11, iVar8);
                if (iVar4 == 0) break;
                uVar11 = 0;
                uVar13 = (int32_t)uVar7 + 1;
                uVar7 = (uint64_t)uVar13;
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f2f9;
                iVar4 = fcn.180222010(iVar10);
            } while ((int32_t)uVar13 < iVar4);
        }
        uVar7 = uVar14;
        if (uVar11 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f312;
            iVar4 = func_0x0001802375f0(uVar11);
            uVar7 = uVar11;
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f31e;
                func_0x000180238640(iVar10);
                return 0xffffffff;
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f333;
        func_0x000180238640(iVar10);
        if (uVar11 == 0) {
            return 3;
        }
        uVar1 = *(undefined4 *)(*(int64_t *)(in_RCX + 0x28) + 0x1c);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f34d;
        iVar4 = func_0x0001802a7e70(uVar7, uVar1, 0);
        if (iVar4 == 2) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f35a;
            func_0x00018021fe80(uVar7);
code_r0x00018024f35e:
            *(int32_t *)(in_RCX + 0xb4) = iVar12;
code_r0x00018024f364:
            if (iVar8 == 0) {
                uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f377;
                iVar8 = fcn.180222340(uVar9, uVar14);
            }
            pcVar3 = *(code **)(in_RCX + 0x40);
            *(int64_t *)(in_RCX + 0xc0) = iVar8;
            *(undefined4 *)(in_RCX + 0xb8) = 0x1c;
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f397;
            iVar4 = (*pcVar3)(0, in_RCX);
            return (uint64_t)((iVar4 != 0) + 2);
        }
        uVar9 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f3b6;
        func_0x0001802221b0(uVar9, 0, uVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f3be;
        func_0x00018021fe80(iVar8);
        *(undefined4 *)(in_RCX + 0x9c) = 0;
    }
code_r0x00018024f3c4:
    if (iVar2 != 0) {
        uVar9 = *(undefined8 *)(iVar2 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18024f3d2;
        iVar4 = fcn.180222010(uVar9);
        if (0 < iVar4) {
            if (*(int32_t *)(iVar2 + 0x30) < 0) {
                *(int32_t *)(iVar2 + 0x30) = iVar15;
            }
            if (*(int32_t *)(iVar2 + 0x2c) < 0) {
                return 3;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18024f400
// Address: 0x18024f400
// Size: 410 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18024f400(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_80h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar5;
    undefined8 *in_R8;
    uint32_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024f424;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f43b;
    func_0x00018021eaf0(in_RDX);
    uVar4 = *(undefined8 *)(in_RCX + 0xa0);
    iVar2 = *(int32_t *)(in_RCX + 0xb4);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f450;
    iVar1 = fcn.180222010(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xa0);
    iVar5 = iVar2 + 1;
    if (iVar2 == iVar1 + -1) {
        iVar5 = iVar2;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f468;
    uVar4 = fcn.180222340(uVar4, iVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f47a;
    iVar2 = fcn.18023b870(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
    if ((iVar2 == 0) && ((*in_R9 & 0x20) != 0)) {
        *in_R9 = *in_R9 | 0x1c;
        *in_R8 = uVar4;
    } else {
        uVar4 = *(undefined8 *)(in_RCX + 0xa0);
        iVar5 = iVar5 + 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f4a4;
        iVar2 = fcn.180222010(uVar4);
        if (iVar5 < iVar2) {
            do {
                uVar4 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f4be;
                uVar4 = fcn.180222340(uVar4, iVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f4c9;
                fcn.180238460(uVar4);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f4d4;
                iVar2 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar3));
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f4e7;
                    iVar2 = fcn.18023b870(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                          *(int64_t *)((int64_t)&var_10h + iVar3));
                    if (iVar2 == 0) {
                        *in_R9 = *in_R9 | 0xc;
                        *in_R8 = uVar4;
                        return;
                    }
                }
                uVar4 = *(undefined8 *)(in_RCX + 0xa0);
                iVar5 = iVar5 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f4f9;
                iVar2 = fcn.180222010(uVar4);
            } while (iVar5 < iVar2);
        }
        if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x1000) != 0) {
            uVar4 = *(undefined8 *)(in_RCX + 0x10);
            iVar5 = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f515;
            iVar2 = fcn.180222010(uVar4);
            if (0 < iVar2) {
                do {
                    uVar4 = *(undefined8 *)(in_RCX + 0x10);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f52b;
                    uVar4 = fcn.180222340(uVar4, iVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f536;
                    fcn.180238460(uVar4);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f541;
                    iVar2 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar3));
                    if (iVar2 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f554;
                        iVar2 = fcn.18023b870(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                              *(int64_t *)((int64_t)&var_10h + iVar3));
                        if (iVar2 == 0) {
                            *in_R8 = uVar4;
                            *in_R9 = *in_R9 | 4;
                            return;
                        }
                    }
                    uVar4 = *(undefined8 *)(in_RCX + 0x10);
                    iVar5 = iVar5 + 1;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f563;
                    iVar2 = fcn.180222010(uVar4);
                } while (iVar5 < iVar2);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18024f5a0
// Address: 0x18024f5a0
// Size: 86 bytes
// ============================================================
int32_t fcn.18024f5a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                     int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t **ppiVar8;
    int32_t *piVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    undefined8 unaff_RDI;
    uint32_t uVar12;
    int32_t iVar13;
    undefined8 unaff_R12;
    int32_t iVar14;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uVar12 = (uint32_t)arg3;
    uStack_20 = 0x18024f5c1;
    var_8h = arg1;
    var_10h = arg2;
    var_18h._0_4_ = uVar12;
    var_20h = arg4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar1 = *(uint32_t *)(arg2 + 0x90);
    if ((uVar1 & 0x10) == 0) {
        if ((*(uint8_t *)(arg1 + 0xd8) & 0x10) == 0) {
            uVar1 = uVar1 & 8;
        } else {
            uVar1 = uVar1 & 4;
        }
        if (uVar1 == 0) {
            uVar2 = *(undefined4 *)(arg2 + 0x94);
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_R12;
            iVar13 = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R13;
            *(undefined4 *)arg4 = uVar2;
            uVar11 = *(undefined8 *)(arg1 + 0x100);
            *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R14;
            *(undefined8 *)((int64_t)&var_10h + iVar7) = unaff_R15;
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f624;
            iVar4 = fcn.180222010(uVar11);
            iVar14 = iVar13;
            if (0 < iVar4) {
                do {
                    uVar11 = *(undefined8 *)(arg1 + 0x100);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f63f;
                    ppiVar8 = (int32_t **)fcn.180222340(uVar11, iVar14);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f64a;
                    func_0x00018021eaf0(arg2);
                    if (ppiVar8[2] == (int32_t *)0x0) {
                        if ((uVar12 & 0x20) != 0) {
code_r0x00018024f6ab:
                            if (*(int32_t ***)(arg2 + 0x88) == (int32_t **)0x0) {
code_r0x00018024f846:
                                **(uint32_t **)((int64_t)&arg_70h + iVar7) =
                                     **(uint32_t **)((int64_t)&arg_70h + iVar7) & *(uint32_t *)(ppiVar8 + 3);
                                return 1;
                            }
                            piVar9 = *ppiVar8;
                            piVar3 = **(int32_t ***)(arg2 + 0x88);
                            if ((piVar9 == (int32_t *)0x0) || (piVar3 == (int32_t *)0x0)) goto code_r0x00018024f846;
                            if (*piVar9 == 1) {
                                if (*(int64_t *)(piVar9 + 4) != 0) {
                                    if (*piVar3 != 1) {
                                        uVar11 = *(undefined8 *)(piVar3 + 2);
code_r0x00018024f722:
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f72d;
                                        iVar5 = fcn.180222010(uVar11);
                                        iVar4 = iVar13;
                                        if (0 < iVar5) {
                                            do {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f73f;
                                                piVar9 = (int32_t *)fcn.180222340(uVar11, iVar4);
                                                if (*piVar9 == 4) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f750;
                                                    iVar5 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                                                    if (iVar5 == 0) goto code_r0x00018024f846;
                                                }
                                                iVar4 = iVar4 + 1;
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f762;
                                                iVar5 = fcn.180222010(uVar11);
                                            } while (iVar4 < iVar5);
                                        }
code_r0x00018024f7e3:
                                        arg2 = *(int64_t *)((int64_t)&arg_60h + iVar7);
                                        goto code_r0x00018024f7e8;
                                    }
                                    if (*(int64_t *)(piVar3 + 4) != 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f6f8;
                                        iVar4 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                                        if (iVar4 == 0) goto code_r0x00018024f846;
                                    }
                                }
                            } else if (*piVar3 == 1) {
                                if (*(int64_t *)(piVar3 + 4) != 0) {
                                    uVar11 = *(undefined8 *)(piVar9 + 2);
                                    goto code_r0x00018024f722;
                                }
                            } else {
                                uVar11 = *(undefined8 *)(piVar9 + 2);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f774;
                                iVar5 = fcn.180222010(uVar11);
                                iVar4 = iVar13;
                                if (0 < iVar5) {
                                    do {
                                        uVar11 = *(undefined8 *)(piVar9 + 2);
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f78b;
                                        uVar10 = fcn.180222340(uVar11, iVar4);
                                        uVar11 = *(undefined8 *)(piVar3 + 2);
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f79a;
                                        iVar6 = fcn.180222010(uVar11);
                                        iVar5 = iVar13;
                                        if (0 < iVar6) {
                                            do {
                                                uVar11 = *(undefined8 *)(piVar3 + 2);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7ab;
                                                uVar11 = fcn.180222340(uVar11, iVar5);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7b6;
                                                iVar6 = func_0x00018028f4a0(uVar10, uVar11);
                                                if (iVar6 == 0) goto code_r0x00018024f846;
                                                uVar11 = *(undefined8 *)(piVar3 + 2);
                                                iVar5 = iVar5 + 1;
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7c9;
                                                iVar6 = fcn.180222010(uVar11);
                                            } while (iVar5 < iVar6);
                                        }
                                        uVar11 = *(undefined8 *)(piVar9 + 2);
                                        iVar4 = iVar4 + 1;
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7d8;
                                        iVar5 = fcn.180222010(uVar11);
                                    } while (iVar4 < iVar5);
                                    uVar12 = *(uint32_t *)((int64_t)&arg_68h + iVar7);
                                    goto code_r0x00018024f7e3;
                                }
                            }
                            arg2 = *(int64_t *)((int64_t)&arg_60h + iVar7);
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f66a;
                        iVar5 = fcn.180222010();
                        iVar4 = iVar13;
                        if (0 < iVar5) {
                            do {
                                piVar9 = ppiVar8[2];
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f67d;
                                piVar9 = (int32_t *)fcn.180222340(piVar9, iVar4);
                                if (*piVar9 == 4) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f68e;
                                    iVar5 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                                    if (iVar5 == 0) {
                                        arg1 = *(int64_t *)((int64_t)&arg_58h + iVar7);
                                        goto code_r0x00018024f6ab;
                                    }
                                }
                                piVar9 = ppiVar8[2];
                                iVar4 = iVar4 + 1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f69d;
                                iVar5 = fcn.180222010(piVar9);
                            } while (iVar4 < iVar5);
                        }
code_r0x00018024f7e8:
                        arg1 = *(int64_t *)((int64_t)&arg_58h + iVar7);
                    }
                    uVar11 = *(undefined8 *)(arg1 + 0x100);
                    iVar14 = iVar14 + 1;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7fc;
                    iVar4 = fcn.180222010(uVar11);
                } while (iVar14 < iVar4);
            }
            if (((*(int64_t **)(arg2 + 0x88) == (int64_t *)0x0) || (**(int64_t **)(arg2 + 0x88) == 0)) &&
               ((uVar12 & 0x20) != 0)) {
                iVar13 = 1;
            }
            return iVar13;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18024f5f6
// Address: 0x18024f5f6
// Size: 592 bytes
// ============================================================
int32_t fcn.18024f5a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                     int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t **ppiVar8;
    int32_t *piVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    undefined8 unaff_RDI;
    uint32_t uVar12;
    int32_t iVar13;
    undefined8 unaff_R12;
    int32_t iVar14;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uVar12 = (uint32_t)arg3;
    uStack_20 = 0x18024f5c1;
    var_8h = arg1;
    var_10h = arg2;
    var_18h._0_4_ = uVar12;
    var_20h = arg4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar1 = *(uint32_t *)(arg2 + 0x90);
    if ((uVar1 & 0x10) == 0) {
        if ((*(uint8_t *)(arg1 + 0xd8) & 0x10) == 0) {
            uVar1 = uVar1 & 8;
        } else {
            uVar1 = uVar1 & 4;
        }
        if (uVar1 == 0) {
            uVar2 = *(undefined4 *)(arg2 + 0x94);
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_R12;
            iVar13 = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R13;
            *(undefined4 *)arg4 = uVar2;
            uVar11 = *(undefined8 *)(arg1 + 0x100);
            *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R14;
            *(undefined8 *)((int64_t)&var_10h + iVar7) = unaff_R15;
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f624;
            iVar4 = fcn.180222010(uVar11);
            iVar14 = iVar13;
            if (0 < iVar4) {
                do {
                    uVar11 = *(undefined8 *)(arg1 + 0x100);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f63f;
                    ppiVar8 = (int32_t **)fcn.180222340(uVar11, iVar14);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f64a;
                    func_0x00018021eaf0(arg2);
                    if (ppiVar8[2] == (int32_t *)0x0) {
                        if ((uVar12 & 0x20) != 0) {
code_r0x00018024f6ab:
                            if (*(int32_t ***)(arg2 + 0x88) == (int32_t **)0x0) {
code_r0x00018024f846:
                                **(uint32_t **)((int64_t)&arg_70h + iVar7) =
                                     **(uint32_t **)((int64_t)&arg_70h + iVar7) & *(uint32_t *)(ppiVar8 + 3);
                                return 1;
                            }
                            piVar9 = *ppiVar8;
                            piVar3 = **(int32_t ***)(arg2 + 0x88);
                            if ((piVar9 == (int32_t *)0x0) || (piVar3 == (int32_t *)0x0)) goto code_r0x00018024f846;
                            if (*piVar9 == 1) {
                                if (*(int64_t *)(piVar9 + 4) != 0) {
                                    if (*piVar3 != 1) {
                                        uVar11 = *(undefined8 *)(piVar3 + 2);
code_r0x00018024f722:
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f72d;
                                        iVar5 = fcn.180222010(uVar11);
                                        iVar4 = iVar13;
                                        if (0 < iVar5) {
                                            do {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f73f;
                                                piVar9 = (int32_t *)fcn.180222340(uVar11, iVar4);
                                                if (*piVar9 == 4) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f750;
                                                    iVar5 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                                                    if (iVar5 == 0) goto code_r0x00018024f846;
                                                }
                                                iVar4 = iVar4 + 1;
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f762;
                                                iVar5 = fcn.180222010(uVar11);
                                            } while (iVar4 < iVar5);
                                        }
code_r0x00018024f7e3:
                                        arg2 = *(int64_t *)((int64_t)&arg_60h + iVar7);
                                        goto code_r0x00018024f7e8;
                                    }
                                    if (*(int64_t *)(piVar3 + 4) != 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f6f8;
                                        iVar4 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                                        if (iVar4 == 0) goto code_r0x00018024f846;
                                    }
                                }
                            } else if (*piVar3 == 1) {
                                if (*(int64_t *)(piVar3 + 4) != 0) {
                                    uVar11 = *(undefined8 *)(piVar9 + 2);
                                    goto code_r0x00018024f722;
                                }
                            } else {
                                uVar11 = *(undefined8 *)(piVar9 + 2);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f774;
                                iVar5 = fcn.180222010(uVar11);
                                iVar4 = iVar13;
                                if (0 < iVar5) {
                                    do {
                                        uVar11 = *(undefined8 *)(piVar9 + 2);
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f78b;
                                        uVar10 = fcn.180222340(uVar11, iVar4);
                                        uVar11 = *(undefined8 *)(piVar3 + 2);
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f79a;
                                        iVar6 = fcn.180222010(uVar11);
                                        iVar5 = iVar13;
                                        if (0 < iVar6) {
                                            do {
                                                uVar11 = *(undefined8 *)(piVar3 + 2);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7ab;
                                                uVar11 = fcn.180222340(uVar11, iVar5);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7b6;
                                                iVar6 = func_0x00018028f4a0(uVar10, uVar11);
                                                if (iVar6 == 0) goto code_r0x00018024f846;
                                                uVar11 = *(undefined8 *)(piVar3 + 2);
                                                iVar5 = iVar5 + 1;
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7c9;
                                                iVar6 = fcn.180222010(uVar11);
                                            } while (iVar5 < iVar6);
                                        }
                                        uVar11 = *(undefined8 *)(piVar9 + 2);
                                        iVar4 = iVar4 + 1;
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7d8;
                                        iVar5 = fcn.180222010(uVar11);
                                    } while (iVar4 < iVar5);
                                    uVar12 = *(uint32_t *)((int64_t)&arg_68h + iVar7);
                                    goto code_r0x00018024f7e3;
                                }
                            }
                            arg2 = *(int64_t *)((int64_t)&arg_60h + iVar7);
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f66a;
                        iVar5 = fcn.180222010();
                        iVar4 = iVar13;
                        if (0 < iVar5) {
                            do {
                                piVar9 = ppiVar8[2];
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f67d;
                                piVar9 = (int32_t *)fcn.180222340(piVar9, iVar4);
                                if (*piVar9 == 4) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f68e;
                                    iVar5 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                                    if (iVar5 == 0) {
                                        arg1 = *(int64_t *)((int64_t)&arg_58h + iVar7);
                                        goto code_r0x00018024f6ab;
                                    }
                                }
                                piVar9 = ppiVar8[2];
                                iVar4 = iVar4 + 1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f69d;
                                iVar5 = fcn.180222010(piVar9);
                            } while (iVar4 < iVar5);
                        }
code_r0x00018024f7e8:
                        arg1 = *(int64_t *)((int64_t)&arg_58h + iVar7);
                    }
                    uVar11 = *(undefined8 *)(arg1 + 0x100);
                    iVar14 = iVar14 + 1;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7fc;
                    iVar4 = fcn.180222010(uVar11);
                } while (iVar14 < iVar4);
            }
            if (((*(int64_t **)(arg2 + 0x88) == (int64_t *)0x0) || (**(int64_t **)(arg2 + 0x88) == 0)) &&
               ((uVar12 & 0x20) != 0)) {
                iVar13 = 1;
            }
            return iVar13;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18024f846
// Address: 0x18024f846
// Size: 21 bytes
// ============================================================
int32_t fcn.18024f5a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                     int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t **ppiVar8;
    int32_t *piVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    undefined8 unaff_RDI;
    uint32_t uVar12;
    int32_t iVar13;
    undefined8 unaff_R12;
    int32_t iVar14;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uVar12 = (uint32_t)arg3;
    uStack_20 = 0x18024f5c1;
    var_8h = arg1;
    var_10h = arg2;
    var_18h._0_4_ = uVar12;
    var_20h = arg4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar1 = *(uint32_t *)(arg2 + 0x90);
    if ((uVar1 & 0x10) == 0) {
        if ((*(uint8_t *)(arg1 + 0xd8) & 0x10) == 0) {
            uVar1 = uVar1 & 8;
        } else {
            uVar1 = uVar1 & 4;
        }
        if (uVar1 == 0) {
            uVar2 = *(undefined4 *)(arg2 + 0x94);
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_R12;
            iVar13 = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R13;
            *(undefined4 *)arg4 = uVar2;
            uVar11 = *(undefined8 *)(arg1 + 0x100);
            *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R14;
            *(undefined8 *)((int64_t)&var_10h + iVar7) = unaff_R15;
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f624;
            iVar4 = fcn.180222010(uVar11);
            iVar14 = iVar13;
            if (0 < iVar4) {
                do {
                    uVar11 = *(undefined8 *)(arg1 + 0x100);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f63f;
                    ppiVar8 = (int32_t **)fcn.180222340(uVar11, iVar14);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f64a;
                    func_0x00018021eaf0(arg2);
                    if (ppiVar8[2] == (int32_t *)0x0) {
                        if ((uVar12 & 0x20) != 0) {
code_r0x00018024f6ab:
                            if (*(int32_t ***)(arg2 + 0x88) == (int32_t **)0x0) {
code_r0x00018024f846:
                                **(uint32_t **)((int64_t)&arg_70h + iVar7) =
                                     **(uint32_t **)((int64_t)&arg_70h + iVar7) & *(uint32_t *)(ppiVar8 + 3);
                                return 1;
                            }
                            piVar9 = *ppiVar8;
                            piVar3 = **(int32_t ***)(arg2 + 0x88);
                            if ((piVar9 == (int32_t *)0x0) || (piVar3 == (int32_t *)0x0)) goto code_r0x00018024f846;
                            if (*piVar9 == 1) {
                                if (*(int64_t *)(piVar9 + 4) != 0) {
                                    if (*piVar3 != 1) {
                                        uVar11 = *(undefined8 *)(piVar3 + 2);
code_r0x00018024f722:
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f72d;
                                        iVar5 = fcn.180222010(uVar11);
                                        iVar4 = iVar13;
                                        if (0 < iVar5) {
                                            do {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f73f;
                                                piVar9 = (int32_t *)fcn.180222340(uVar11, iVar4);
                                                if (*piVar9 == 4) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f750;
                                                    iVar5 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                                                    if (iVar5 == 0) goto code_r0x00018024f846;
                                                }
                                                iVar4 = iVar4 + 1;
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f762;
                                                iVar5 = fcn.180222010(uVar11);
                                            } while (iVar4 < iVar5);
                                        }
code_r0x00018024f7e3:
                                        arg2 = *(int64_t *)((int64_t)&arg_60h + iVar7);
                                        goto code_r0x00018024f7e8;
                                    }
                                    if (*(int64_t *)(piVar3 + 4) != 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f6f8;
                                        iVar4 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                                        if (iVar4 == 0) goto code_r0x00018024f846;
                                    }
                                }
                            } else if (*piVar3 == 1) {
                                if (*(int64_t *)(piVar3 + 4) != 0) {
                                    uVar11 = *(undefined8 *)(piVar9 + 2);
                                    goto code_r0x00018024f722;
                                }
                            } else {
                                uVar11 = *(undefined8 *)(piVar9 + 2);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f774;
                                iVar5 = fcn.180222010(uVar11);
                                iVar4 = iVar13;
                                if (0 < iVar5) {
                                    do {
                                        uVar11 = *(undefined8 *)(piVar9 + 2);
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f78b;
                                        uVar10 = fcn.180222340(uVar11, iVar4);
                                        uVar11 = *(undefined8 *)(piVar3 + 2);
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f79a;
                                        iVar6 = fcn.180222010(uVar11);
                                        iVar5 = iVar13;
                                        if (0 < iVar6) {
                                            do {
                                                uVar11 = *(undefined8 *)(piVar3 + 2);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7ab;
                                                uVar11 = fcn.180222340(uVar11, iVar5);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7b6;
                                                iVar6 = func_0x00018028f4a0(uVar10, uVar11);
                                                if (iVar6 == 0) goto code_r0x00018024f846;
                                                uVar11 = *(undefined8 *)(piVar3 + 2);
                                                iVar5 = iVar5 + 1;
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7c9;
                                                iVar6 = fcn.180222010(uVar11);
                                            } while (iVar5 < iVar6);
                                        }
                                        uVar11 = *(undefined8 *)(piVar9 + 2);
                                        iVar4 = iVar4 + 1;
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7d8;
                                        iVar5 = fcn.180222010(uVar11);
                                    } while (iVar4 < iVar5);
                                    uVar12 = *(uint32_t *)((int64_t)&arg_68h + iVar7);
                                    goto code_r0x00018024f7e3;
                                }
                            }
                            arg2 = *(int64_t *)((int64_t)&arg_60h + iVar7);
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f66a;
                        iVar5 = fcn.180222010();
                        iVar4 = iVar13;
                        if (0 < iVar5) {
                            do {
                                piVar9 = ppiVar8[2];
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f67d;
                                piVar9 = (int32_t *)fcn.180222340(piVar9, iVar4);
                                if (*piVar9 == 4) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f68e;
                                    iVar5 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                                    if (iVar5 == 0) {
                                        arg1 = *(int64_t *)((int64_t)&arg_58h + iVar7);
                                        goto code_r0x00018024f6ab;
                                    }
                                }
                                piVar9 = ppiVar8[2];
                                iVar4 = iVar4 + 1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f69d;
                                iVar5 = fcn.180222010(piVar9);
                            } while (iVar4 < iVar5);
                        }
code_r0x00018024f7e8:
                        arg1 = *(int64_t *)((int64_t)&arg_58h + iVar7);
                    }
                    uVar11 = *(undefined8 *)(arg1 + 0x100);
                    iVar14 = iVar14 + 1;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7fc;
                    iVar4 = fcn.180222010(uVar11);
                } while (iVar14 < iVar4);
            }
            if (((*(int64_t **)(arg2 + 0x88) == (int64_t *)0x0) || (**(int64_t **)(arg2 + 0x88) == 0)) &&
               ((uVar12 & 0x20) != 0)) {
                iVar13 = 1;
            }
            return iVar13;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18024f85b
// Address: 0x18024f85b
// Size: 10 bytes
// ============================================================
int32_t fcn.18024f5a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                     int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t **ppiVar8;
    int32_t *piVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    undefined8 unaff_RDI;
    uint32_t uVar12;
    int32_t iVar13;
    undefined8 unaff_R12;
    int32_t iVar14;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uVar12 = (uint32_t)arg3;
    uStack_20 = 0x18024f5c1;
    var_8h = arg1;
    var_10h = arg2;
    var_18h._0_4_ = uVar12;
    var_20h = arg4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar1 = *(uint32_t *)(arg2 + 0x90);
    if ((uVar1 & 0x10) == 0) {
        if ((*(uint8_t *)(arg1 + 0xd8) & 0x10) == 0) {
            uVar1 = uVar1 & 8;
        } else {
            uVar1 = uVar1 & 4;
        }
        if (uVar1 == 0) {
            uVar2 = *(undefined4 *)(arg2 + 0x94);
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_R12;
            iVar13 = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R13;
            *(undefined4 *)arg4 = uVar2;
            uVar11 = *(undefined8 *)(arg1 + 0x100);
            *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R14;
            *(undefined8 *)((int64_t)&var_10h + iVar7) = unaff_R15;
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f624;
            iVar4 = fcn.180222010(uVar11);
            iVar14 = iVar13;
            if (0 < iVar4) {
                do {
                    uVar11 = *(undefined8 *)(arg1 + 0x100);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f63f;
                    ppiVar8 = (int32_t **)fcn.180222340(uVar11, iVar14);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f64a;
                    func_0x00018021eaf0(arg2);
                    if (ppiVar8[2] == (int32_t *)0x0) {
                        if ((uVar12 & 0x20) != 0) {
code_r0x00018024f6ab:
                            if (*(int32_t ***)(arg2 + 0x88) == (int32_t **)0x0) {
code_r0x00018024f846:
                                **(uint32_t **)((int64_t)&arg_70h + iVar7) =
                                     **(uint32_t **)((int64_t)&arg_70h + iVar7) & *(uint32_t *)(ppiVar8 + 3);
                                return 1;
                            }
                            piVar9 = *ppiVar8;
                            piVar3 = **(int32_t ***)(arg2 + 0x88);
                            if ((piVar9 == (int32_t *)0x0) || (piVar3 == (int32_t *)0x0)) goto code_r0x00018024f846;
                            if (*piVar9 == 1) {
                                if (*(int64_t *)(piVar9 + 4) != 0) {
                                    if (*piVar3 != 1) {
                                        uVar11 = *(undefined8 *)(piVar3 + 2);
code_r0x00018024f722:
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f72d;
                                        iVar5 = fcn.180222010(uVar11);
                                        iVar4 = iVar13;
                                        if (0 < iVar5) {
                                            do {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f73f;
                                                piVar9 = (int32_t *)fcn.180222340(uVar11, iVar4);
                                                if (*piVar9 == 4) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f750;
                                                    iVar5 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                                                    if (iVar5 == 0) goto code_r0x00018024f846;
                                                }
                                                iVar4 = iVar4 + 1;
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f762;
                                                iVar5 = fcn.180222010(uVar11);
                                            } while (iVar4 < iVar5);
                                        }
code_r0x00018024f7e3:
                                        arg2 = *(int64_t *)((int64_t)&arg_60h + iVar7);
                                        goto code_r0x00018024f7e8;
                                    }
                                    if (*(int64_t *)(piVar3 + 4) != 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f6f8;
                                        iVar4 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                                        if (iVar4 == 0) goto code_r0x00018024f846;
                                    }
                                }
                            } else if (*piVar3 == 1) {
                                if (*(int64_t *)(piVar3 + 4) != 0) {
                                    uVar11 = *(undefined8 *)(piVar9 + 2);
                                    goto code_r0x00018024f722;
                                }
                            } else {
                                uVar11 = *(undefined8 *)(piVar9 + 2);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f774;
                                iVar5 = fcn.180222010(uVar11);
                                iVar4 = iVar13;
                                if (0 < iVar5) {
                                    do {
                                        uVar11 = *(undefined8 *)(piVar9 + 2);
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f78b;
                                        uVar10 = fcn.180222340(uVar11, iVar4);
                                        uVar11 = *(undefined8 *)(piVar3 + 2);
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f79a;
                                        iVar6 = fcn.180222010(uVar11);
                                        iVar5 = iVar13;
                                        if (0 < iVar6) {
                                            do {
                                                uVar11 = *(undefined8 *)(piVar3 + 2);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7ab;
                                                uVar11 = fcn.180222340(uVar11, iVar5);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7b6;
                                                iVar6 = func_0x00018028f4a0(uVar10, uVar11);
                                                if (iVar6 == 0) goto code_r0x00018024f846;
                                                uVar11 = *(undefined8 *)(piVar3 + 2);
                                                iVar5 = iVar5 + 1;
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7c9;
                                                iVar6 = fcn.180222010(uVar11);
                                            } while (iVar5 < iVar6);
                                        }
                                        uVar11 = *(undefined8 *)(piVar9 + 2);
                                        iVar4 = iVar4 + 1;
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7d8;
                                        iVar5 = fcn.180222010(uVar11);
                                    } while (iVar4 < iVar5);
                                    uVar12 = *(uint32_t *)((int64_t)&arg_68h + iVar7);
                                    goto code_r0x00018024f7e3;
                                }
                            }
                            arg2 = *(int64_t *)((int64_t)&arg_60h + iVar7);
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f66a;
                        iVar5 = fcn.180222010();
                        iVar4 = iVar13;
                        if (0 < iVar5) {
                            do {
                                piVar9 = ppiVar8[2];
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f67d;
                                piVar9 = (int32_t *)fcn.180222340(piVar9, iVar4);
                                if (*piVar9 == 4) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f68e;
                                    iVar5 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                                    if (iVar5 == 0) {
                                        arg1 = *(int64_t *)((int64_t)&arg_58h + iVar7);
                                        goto code_r0x00018024f6ab;
                                    }
                                }
                                piVar9 = ppiVar8[2];
                                iVar4 = iVar4 + 1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f69d;
                                iVar5 = fcn.180222010(piVar9);
                            } while (iVar4 < iVar5);
                        }
code_r0x00018024f7e8:
                        arg1 = *(int64_t *)((int64_t)&arg_58h + iVar7);
                    }
                    uVar11 = *(undefined8 *)(arg1 + 0x100);
                    iVar14 = iVar14 + 1;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18024f7fc;
                    iVar4 = fcn.180222010(uVar11);
                } while (iVar14 < iVar4);
            }
            if (((*(int64_t **)(arg2 + 0x88) == (int64_t *)0x0) || (**(int64_t **)(arg2 + 0x88) == 0)) &&
               ((uVar12 & 0x20) != 0)) {
                iVar13 = 1;
            }
            return iVar13;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18024f870
// Address: 0x18024f870
// Size: 252 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18024f870(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024f894;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f8b4;
    iVar1 = func_0x0001802393a0();
    iVar5 = iVar6;
    if (-1 < iVar1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f8c9;
        iVar2 = func_0x0001802393a0(in_RCX, in_R8 & 0xffffffff, iVar1);
        if (iVar2 != -1) {
            return false;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f8d9;
        uVar4 = func_0x000180239380(in_RCX, iVar1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f8e1;
        iVar5 = func_0x0001802ab4e0(uVar4);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f8f5;
    iVar1 = func_0x0001802393a0(in_RDX, in_R8 & 0xffffffff, 0xffffffff);
    if (-1 < iVar1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f909;
        iVar2 = func_0x0001802393a0(in_RDX, in_R8 & 0xffffffff, iVar1);
        if (iVar2 != -1) {
            return false;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f918;
        uVar4 = func_0x000180239380(in_RDX, iVar1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f920;
        iVar6 = func_0x0001802ab4e0(uVar4);
    }
    if (iVar5 != 0) {
        if (iVar6 == 0) {
            return false;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18024f942;
        iVar1 = fcn.180260b00(iVar5, iVar6);
        return iVar1 == 0;
    }
    return iVar6 == 0;
}

// ============================================================
// Function: FUN_18024f970
// Address: 0x18024f970
// Size: 843 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.18024f970(int64_t arg_28h, int64_t arg_38h, int64_t arg_78h, int64_t arg_d8h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    int64_t *piVar13;
    undefined8 uVar14;
    uint32_t uVar15;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t uVar16;
    uint64_t uVar17;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    uint64_t uVar18;
    int64_t var_4h;
    int64_t var_10h;
    uint64_t uStackX_18;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_8h;
    
    uStack_40 = 0x18024f986;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    *(uint64_t *)((int64_t)&arg_78h + iVar11) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar11)
    ;
    ppiVar3 = *(int64_t ***)(in_RCX + 0xf8);
    uVar16 = 0;
    uVar8 = 0x100;
    *(undefined8 *)((int64_t)&arg_28h + iVar11) = in_RDX;
    *(int32_t *)((int64_t)&uStackX_18 + iVar11 + -8) = in_R8D;
    *(undefined4 *)((int64_t)&var_8h + iVar11) = 0x100;
    *(undefined4 *)(&stack0x0000000c + iVar11 + -8) = 0x100;
    iVar10 = 0x100;
    *(undefined4 *)((int64_t)&var_8h + iVar11 + 4) = 0x100;
    uVar7 = 5;
    if (in_R8D == 0) {
        uVar7 = 10;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar11) = 0;
    *(undefined4 *)(&stack0x00000000 + iVar11) = 0;
    if (*(int32_t *)(in_RCX + 0x9c) <= in_R8D) {
        uVar7 = 2 - (in_R8D != 0);
    }
    uVar15 = uVar7 & 0xfffffffc;
    if (*(int32_t *)((int64_t)ppiVar3 + 0x2c) < 0) {
        uVar15 = uVar7;
    }
    *(uint32_t *)(&stack0x0000000c + iVar11) = uVar15;
    uVar12 = uVar16;
    if ((*(uint32_t *)(ppiVar3 + 5) & uVar15) != 0) {
        piVar13 = ppiVar3[1];
        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fa17;
        uVar12 = fcn.180222010(piVar13);
    }
    *(int32_t *)(&stack0x0000000c + iVar11 + -4) = (int32_t)uVar12;
    *(undefined8 *)((int64_t)&arg_d8h + iVar11) = unaff_RDI;
    uVar17 = uVar16;
    uVar18 = uVar16;
    do {
        if ((int32_t)uVar12 <= (int32_t)uVar18) {
code_r0x00018024fc78:
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fc8d;
            fcn.180224990(uVar17, 0x1804e48c8, 0xca6);
code_r0x00018024fc90:
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fca8;
            fcn.180459870(*(uint64_t *)((int64_t)&arg_78h + iVar11) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar11));
            return;
        }
        piVar13 = ppiVar3[1];
        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fa45;
        piVar13 = (int64_t *)fcn.180222340(piVar13, uVar18);
        uVar1 = *(uint8_t *)piVar13;
        if ((*(uint32_t *)(&stack0x0000000c + iVar11) >> (uVar1 & 0x1f) & 1) != 0) {
            if (uVar1 == uVar8) {
                uVar8 = *(uint32_t *)((int64_t)&var_8h + iVar11 + 4);
            } else {
                uVar2 = *(uint8_t *)((int64_t)piVar13 + 2);
                iVar10 = 0x100;
                *(uint32_t *)((int64_t)&var_8h + iVar11) = (uint32_t)uVar1;
                uVar1 = *(uint8_t *)((uint64_t)uVar2 + (*ppiVar3)[1]);
                uVar8 = (uint32_t)uVar1;
                *(uint32_t *)((int64_t)&var_8h + iVar11 + 4) = (uint32_t)uVar1;
            }
            uVar1 = *(uint8_t *)((int64_t)piVar13 + 1);
            if ((uint32_t)uVar1 != *(uint32_t *)(&stack0x0000000c + iVar11 + -8)) {
                *(uint32_t *)(&stack0x0000000c + iVar11 + -8) = (uint32_t)uVar1;
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024faaa;
                fcn.180224990(uVar17, 0x1804e48c8, 0xc64);
                *(undefined8 *)((int64_t)&uStackX_18 + iVar11) = 0;
                if (uVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fae4;
                    uVar8 = func_0x0001802200d0(*(undefined8 *)((int64_t)&arg_28h + iVar11), 
                                                (int64_t)&uStackX_18 + iVar11);
code_r0x00018024fae4:
                    uVar16 = (uint64_t)uVar8;
                    if ((-1 < (int32_t)uVar8) && (uVar17 = *(uint64_t *)((int64_t)&uStackX_18 + iVar11), uVar17 != 0)) {
                        iVar10 = 0x100;
                        uVar12 = (uint64_t)*(uint8_t *)((int64_t)piVar13 + 2);
                        *(uint32_t *)((int64_t)&var_8h + iVar11 + 4) = (uint32_t)*(uint8_t *)((*ppiVar3)[1] + uVar12);
                        goto code_r0x00018024fb36;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fbf2;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar11));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fc0a;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                                  *(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)(&stack0x00000000 + iVar11), 
                                  *(int64_t *)((int64_t)&uStackX_18 + iVar11));
                } else {
                    if (uVar1 == 1) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fac6;
                        uVar14 = func_0x0001802374f0(*(undefined8 *)((int64_t)&arg_28h + iVar11));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fad3;
                        uVar8 = func_0x000180236470(uVar14, (int64_t)&uStackX_18 + iVar11);
                        goto code_r0x00018024fae4;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fbce;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar11));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fbe6;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                                  *(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)(&stack0x00000000 + iVar11), 
                                  *(int64_t *)((int64_t)&uStackX_18 + iVar11));
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fc1c;
                fcn.1802296d0(*(int64_t *)(&stack0x0000000c + iVar11 + -4));
                goto code_r0x00018024fc90;
            }
            uVar1 = *(uint8_t *)((int64_t)piVar13 + 2);
            uVar12 = (uint64_t)uVar1;
            if ((uVar1 == 0) || (uVar8 <= *(uint8_t *)((*ppiVar3)[1] + (uint64_t)uVar1))) {
code_r0x00018024fb36:
                iVar9 = (int32_t)uVar12;
                if (iVar9 == iVar10) {
                    uVar12 = *(uint64_t *)((int64_t)&var_20h + iVar11);
code_r0x00018024fb9c:
                    uVar8 = *(uint32_t *)(&stack0x00000000 + iVar11);
                } else {
                    piVar4 = *ppiVar3;
                    *(uint64_t *)((int64_t)&var_20h + iVar11) = uVar17;
                    uVar8 = (uint32_t)uVar16;
                    iVar5 = *(int64_t *)(*piVar4 + uVar12 * 8);
                    *(uint32_t *)(&stack0x00000000 + iVar11) = uVar8;
                    uVar12 = uVar17;
                    iVar10 = iVar9;
                    if (iVar5 != 0) {
                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar11) = 0;
                        uVar12 = (int64_t)&arg_38h + iVar11;
                        *(int64_t *)((int64_t)&var_18h + iVar11) = iVar5;
                        *(uint64_t *)((int64_t)&var_20h + iVar11) = uVar12;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fb88;
                        iVar9 = func_0x000180214220(uVar17, uVar16, (int64_t)&arg_38h + iVar11, 
                                                    (int64_t)&stack0x00000000 + iVar11);
                        if (iVar9 != 0) goto code_r0x00018024fb9c;
                        goto code_r0x00018024fc78;
                    }
                }
                if ((uint64_t)uVar8 == piVar13[2]) {
                    iVar5 = piVar13[1];
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fbb5;
                    iVar9 = fcn.180497f30(uVar12, iVar5);
                    if (iVar9 == 0) {
                        if ((*(int32_t *)((int64_t)&var_8h + iVar11) - 2U < 2) ||
                           (*(int32_t *)((int64_t)ppiVar3 + 0x2c) < 0)) {
                            piVar4 = *(int64_t **)((int64_t)&arg_28h + iVar11);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fc4a;
                            iVar10 = func_0x0001802375f0(piVar4);
                            if (iVar10 != 0) {
                                piVar6 = ppiVar3[4];
                                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x18024fc68;
                                fcn.180224990(piVar6, 0x1804e48c8, 0xc9c);
                                *(undefined4 *)((int64_t)ppiVar3 + 0x2c) =
                                     *(undefined4 *)((int64_t)&uStackX_18 + iVar11 + -8);
                                ppiVar3[4] = piVar4;
                                ppiVar3[3] = piVar13;
                            }
                        }
                        goto code_r0x00018024fc78;
                    }
                }
            }
            uVar8 = *(uint32_t *)((int64_t)&var_8h + iVar11);
        }
        uVar12 = (uint64_t)*(uint32_t *)(&stack0x0000000c + iVar11 + -4);
        uVar18 = (uint64_t)((int32_t)uVar18 + 1);
    } while( true );
}

// ============================================================
// Function: FUN_18024fcc0
// Address: 0x18024fcc0
// Size: 403 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

undefined8 fcn.18024fcc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024fce0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar1 = *(int64_t *)(in_RCX + 0xf8);
    iVar8 = *(int64_t *)(in_RCX + 8);
    uVar6 = *(undefined8 *)(iVar1 + 0x20);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024fcfa;
    func_0x00018021fe80(uVar6);
    *(undefined8 *)(iVar1 + 0x2c) = 0xffffffffffffffff;
    *(undefined8 *)(iVar1 + 0x20) = 0;
    *(undefined8 *)(iVar1 + 0x18) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024fd1c;
    iVar3 = fcn.18024f970(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                          *(int64_t *)(&stack0x00000068 + iVar5), *(int64_t *)(&stack0x000000c8 + iVar5));
    if ((iVar3 == 0) && (((*(uint8_t *)(iVar1 + 0x28) & 5) != 0 || (-1 < *(int32_t *)(iVar1 + 0x2c))))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024fd36;
        uVar6 = func_0x000180250a80(in_RCX);
        return uVar6;
    }
    uVar6 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024fd49;
    iVar4 = func_0x00018024c4a0(0, uVar6);
    if (iVar4 == 0) {
        return 0xffffffff;
    }
    if (iVar3 < 1) {
        if (iVar3 < 0) {
            *(undefined4 *)(in_RCX + 0xb4) = 0;
            *(int64_t *)(in_RCX + 0xc0) = iVar8;
            *(undefined4 *)(in_RCX + 0xb8) = 0x11;
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024fdf7;
        iVar3 = fcn.18024e960(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000048 + iVar5));
        if (iVar3 == 0) {
            return 0;
        }
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (iVar8 == 0) {
            uVar6 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024fe19;
            iVar8 = fcn.180222340(uVar6, 0);
        }
        *(undefined4 *)(in_RCX + 0xb8) = 0x41;
        uVar6 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024fd6a;
        iVar3 = fcn.180237df0(*(int64_t *)(&stack0x00000050 + iVar5), *(int64_t *)(&stack0x00000068 + iVar5), 
                              *(int64_t *)(&stack0x00000070 + iVar5), *(int64_t *)(&stack0x00000078 + iVar5), 
                              *(int64_t *)(&stack0x00000080 + iVar5));
        if (iVar3 != 0) {
            *(undefined4 *)(in_RCX + 0xb4) = 0;
            iVar7 = iVar8;
            if (iVar8 == 0) {
                uVar6 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024fd8f;
                iVar7 = fcn.180222340(uVar6, 0);
            }
            *(int64_t *)(in_RCX + 0xc0) = iVar7;
            pcVar2 = *(code **)(in_RCX + 0x40);
            *(int32_t *)(in_RCX + 0xb8) = iVar3;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024fda7;
            iVar3 = (*pcVar2)(0, in_RCX);
            if (iVar3 == 0) {
                return 0;
            }
        }
        if ((*(uint8_t *)(iVar1 + 0x34) & 1) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024fdb9;
            iVar3 = fcn.18024e760(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5));
            if (iVar3 == 0) {
                return 0;
            }
        }
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        uVar6 = 1;
    }
    pcVar2 = *(code **)(in_RCX + 0x40);
    *(int64_t *)(in_RCX + 0xc0) = iVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024fe38;
    uVar6 = (*pcVar2)(uVar6, in_RCX);
    return uVar6;
}

// ============================================================
// Function: FUN_18024fe60
// Address: 0x18024fe60
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_b4h

void fcn.18024fe60(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_b0h, int64_t arg_b8h,
                  int64_t arg_c0h, int64_t arg_f8h, int64_t arg_108h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t in_RCX;
    undefined4 uVar12;
    uint32_t uVar13;
    undefined8 unaff_RDI;
    uint32_t uVar14;
    undefined8 unaff_R15;
    int64_t iVar15;
    uint32_t var_8h [2];
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18024fe77;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_68h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10)
    ;
    iVar15 = *(int64_t *)(in_RCX + 0xf8);
    uVar2 = *(undefined8 *)(iVar15 + 0x20);
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024fe9f;
    func_0x00018021fe80(uVar2);
    uVar13 = 0;
    *(undefined8 *)(iVar15 + 0x2c) = 0xffffffffffffffff;
    *(undefined8 *)(iVar15 + 0x20) = 0;
    uVar12 = 0;
    *(undefined8 *)(iVar15 + 0x18) = 0;
    ppiVar3 = *(int64_t ***)(in_RCX + 0xf8);
    uVar2 = *(undefined8 *)(in_RCX + 0x108);
    *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
    piVar11 = ppiVar3[1];
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024fed0;
    uVar6 = fcn.180222010(piVar11);
    *(undefined4 *)((int64_t)&var_10h + iVar10) = uVar6;
    *(undefined4 *)((int64_t)var_8h + iVar10 + 4) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024fee5;
    uVar7 = func_0x0001802362e0(uVar2, (int64_t)&var_18h + iVar10);
    if ((int32_t)uVar7 < 1) {
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        *(undefined4 *)(in_RCX + 0xb8) = 1;
    } else {
        *(undefined8 *)((int64_t)&arg_b0h + iVar10) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_b8h + iVar10) = unaff_R15;
        iVar15 = *(int64_t *)((int64_t)&var_18h + iVar10);
        *(uint32_t *)((int64_t)var_8h + iVar10) = uVar7;
        uVar14 = uVar13;
        if (0 < *(int32_t *)((int64_t)&var_10h + iVar10)) {
            do {
                piVar11 = ppiVar3[1];
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024ff3b;
                piVar11 = (int64_t *)fcn.180222340(piVar11, uVar13);
                if ((*(char *)piVar11 == '\x03') && (*(char *)((int64_t)piVar11 + 1) == '\x01')) {
                    uVar1 = *(uint8_t *)((int64_t)piVar11 + 2);
                    if (uVar1 == uVar14) {
code_r0x00018024ff9a:
                        uVar9 = *(uint32_t *)((int64_t)var_8h + iVar10);
                    } else {
                        uVar14 = (uint32_t)uVar1;
                        iVar4 = *(int64_t *)(**ppiVar3 + (uint64_t)(uint32_t)uVar1 * 8);
                        *(uint32_t *)((int64_t)var_8h + iVar10) = uVar7;
                        iVar15 = *(int64_t *)((int64_t)&var_18h + iVar10);
                        uVar9 = uVar7;
                        if (iVar4 != 0) {
                            *(undefined8 *)(&stack0x00000000 + iVar10) = 0;
                            *(int64_t *)(&stack0xfffffffffffffff8 + iVar10) = iVar4;
                            iVar15 = (int64_t)&arg_28h + iVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024ff96;
                            iVar8 = func_0x000180214220(*(int64_t *)((int64_t)&var_18h + iVar10), uVar7, 
                                                        (int64_t)&arg_28h + iVar10, (int64_t)var_8h + iVar10);
                            if (iVar8 != 0) goto code_r0x00018024ff9a;
                            *(undefined4 *)((int64_t)var_8h + iVar10 + 4) = 0xffffffff;
                            break;
                        }
                    }
                    if ((uint64_t)uVar9 == piVar11[2]) {
                        iVar4 = piVar11[1];
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024ffb3;
                        iVar8 = fcn.180497f30(iVar15, iVar4);
                        if (iVar8 == 0) {
                            *(undefined4 *)((int64_t)var_8h + iVar10 + 4) = 1;
                            *(undefined4 *)((int64_t)ppiVar3 + 0x2c) = 0;
                            ppiVar3[3] = piVar11;
                            break;
                        }
                    }
                }
                uVar13 = uVar13 + 1;
            } while ((int32_t)uVar13 < *(int32_t *)((int64_t)&var_10h + iVar10));
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024fff6;
        fcn.180224990(*(undefined8 *)((int64_t)&var_18h + iVar10), 0x1804e48c8, 0xd1d);
        iVar8 = *(int32_t *)((int64_t)var_8h + iVar10 + 4);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (iVar8 < 0) {
            *(undefined4 *)(in_RCX + 0xb8) = 1;
        } else {
            if (iVar8 < 1) {
                uVar12 = 0x41;
            }
            *(undefined4 *)(in_RCX + 0xb8) = uVar12;
            pcVar5 = *(code **)(in_RCX + 0x38);
            if (pcVar5 == (code *)0x0) {
                pcVar5 = *(code **)(in_RCX + 0x40);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180250059;
                (*pcVar5)(0 < iVar8, in_RCX);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180250045;
                (*pcVar5)(in_RCX);
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180250071;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_68h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_18024ff06
// Address: 0x18024ff06
// Size: 270 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_b4h

void fcn.18024fe60(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_b0h, int64_t arg_b8h,
                  int64_t arg_c0h, int64_t arg_f8h, int64_t arg_108h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t in_RCX;
    undefined4 uVar12;
    uint32_t uVar13;
    undefined8 unaff_RDI;
    uint32_t uVar14;
    undefined8 unaff_R15;
    int64_t iVar15;
    uint32_t var_8h [2];
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18024fe77;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_68h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10)
    ;
    iVar15 = *(int64_t *)(in_RCX + 0xf8);
    uVar2 = *(undefined8 *)(iVar15 + 0x20);
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024fe9f;
    func_0x00018021fe80(uVar2);
    uVar13 = 0;
    *(undefined8 *)(iVar15 + 0x2c) = 0xffffffffffffffff;
    *(undefined8 *)(iVar15 + 0x20) = 0;
    uVar12 = 0;
    *(undefined8 *)(iVar15 + 0x18) = 0;
    ppiVar3 = *(int64_t ***)(in_RCX + 0xf8);
    uVar2 = *(undefined8 *)(in_RCX + 0x108);
    *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
    piVar11 = ppiVar3[1];
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024fed0;
    uVar6 = fcn.180222010(piVar11);
    *(undefined4 *)((int64_t)&var_10h + iVar10) = uVar6;
    *(undefined4 *)((int64_t)var_8h + iVar10 + 4) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024fee5;
    uVar7 = func_0x0001802362e0(uVar2, (int64_t)&var_18h + iVar10);
    if ((int32_t)uVar7 < 1) {
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        *(undefined4 *)(in_RCX + 0xb8) = 1;
    } else {
        *(undefined8 *)((int64_t)&arg_b0h + iVar10) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_b8h + iVar10) = unaff_R15;
        iVar15 = *(int64_t *)((int64_t)&var_18h + iVar10);
        *(uint32_t *)((int64_t)var_8h + iVar10) = uVar7;
        uVar14 = uVar13;
        if (0 < *(int32_t *)((int64_t)&var_10h + iVar10)) {
            do {
                piVar11 = ppiVar3[1];
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024ff3b;
                piVar11 = (int64_t *)fcn.180222340(piVar11, uVar13);
                if ((*(char *)piVar11 == '\x03') && (*(char *)((int64_t)piVar11 + 1) == '\x01')) {
                    uVar1 = *(uint8_t *)((int64_t)piVar11 + 2);
                    if (uVar1 == uVar14) {
code_r0x00018024ff9a:
                        uVar9 = *(uint32_t *)((int64_t)var_8h + iVar10);
                    } else {
                        uVar14 = (uint32_t)uVar1;
                        iVar4 = *(int64_t *)(**ppiVar3 + (uint64_t)(uint32_t)uVar1 * 8);
                        *(uint32_t *)((int64_t)var_8h + iVar10) = uVar7;
                        iVar15 = *(int64_t *)((int64_t)&var_18h + iVar10);
                        uVar9 = uVar7;
                        if (iVar4 != 0) {
                            *(undefined8 *)(&stack0x00000000 + iVar10) = 0;
                            *(int64_t *)(&stack0xfffffffffffffff8 + iVar10) = iVar4;
                            iVar15 = (int64_t)&arg_28h + iVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024ff96;
                            iVar8 = func_0x000180214220(*(int64_t *)((int64_t)&var_18h + iVar10), uVar7, 
                                                        (int64_t)&arg_28h + iVar10, (int64_t)var_8h + iVar10);
                            if (iVar8 != 0) goto code_r0x00018024ff9a;
                            *(undefined4 *)((int64_t)var_8h + iVar10 + 4) = 0xffffffff;
                            break;
                        }
                    }
                    if ((uint64_t)uVar9 == piVar11[2]) {
                        iVar4 = piVar11[1];
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024ffb3;
                        iVar8 = fcn.180497f30(iVar15, iVar4);
                        if (iVar8 == 0) {
                            *(undefined4 *)((int64_t)var_8h + iVar10 + 4) = 1;
                            *(undefined4 *)((int64_t)ppiVar3 + 0x2c) = 0;
                            ppiVar3[3] = piVar11;
                            break;
                        }
                    }
                }
                uVar13 = uVar13 + 1;
            } while ((int32_t)uVar13 < *(int32_t *)((int64_t)&var_10h + iVar10));
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024fff6;
        fcn.180224990(*(undefined8 *)((int64_t)&var_18h + iVar10), 0x1804e48c8, 0xd1d);
        iVar8 = *(int32_t *)((int64_t)var_8h + iVar10 + 4);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (iVar8 < 0) {
            *(undefined4 *)(in_RCX + 0xb8) = 1;
        } else {
            if (iVar8 < 1) {
                uVar12 = 0x41;
            }
            *(undefined4 *)(in_RCX + 0xb8) = uVar12;
            pcVar5 = *(code **)(in_RCX + 0x38);
            if (pcVar5 == (code *)0x0) {
                pcVar5 = *(code **)(in_RCX + 0x40);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180250059;
                (*pcVar5)(0 < iVar8, in_RCX);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180250045;
                (*pcVar5)(in_RCX);
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180250071;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_68h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_180250014
// Address: 0x180250014
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_b4h

void fcn.18024fe60(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_b0h, int64_t arg_b8h,
                  int64_t arg_c0h, int64_t arg_f8h, int64_t arg_108h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t in_RCX;
    undefined4 uVar12;
    uint32_t uVar13;
    undefined8 unaff_RDI;
    uint32_t uVar14;
    undefined8 unaff_R15;
    int64_t iVar15;
    uint32_t var_8h [2];
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18024fe77;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_68h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10)
    ;
    iVar15 = *(int64_t *)(in_RCX + 0xf8);
    uVar2 = *(undefined8 *)(iVar15 + 0x20);
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024fe9f;
    func_0x00018021fe80(uVar2);
    uVar13 = 0;
    *(undefined8 *)(iVar15 + 0x2c) = 0xffffffffffffffff;
    *(undefined8 *)(iVar15 + 0x20) = 0;
    uVar12 = 0;
    *(undefined8 *)(iVar15 + 0x18) = 0;
    ppiVar3 = *(int64_t ***)(in_RCX + 0xf8);
    uVar2 = *(undefined8 *)(in_RCX + 0x108);
    *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
    piVar11 = ppiVar3[1];
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024fed0;
    uVar6 = fcn.180222010(piVar11);
    *(undefined4 *)((int64_t)&var_10h + iVar10) = uVar6;
    *(undefined4 *)((int64_t)var_8h + iVar10 + 4) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024fee5;
    uVar7 = func_0x0001802362e0(uVar2, (int64_t)&var_18h + iVar10);
    if ((int32_t)uVar7 < 1) {
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        *(undefined4 *)(in_RCX + 0xb8) = 1;
    } else {
        *(undefined8 *)((int64_t)&arg_b0h + iVar10) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_b8h + iVar10) = unaff_R15;
        iVar15 = *(int64_t *)((int64_t)&var_18h + iVar10);
        *(uint32_t *)((int64_t)var_8h + iVar10) = uVar7;
        uVar14 = uVar13;
        if (0 < *(int32_t *)((int64_t)&var_10h + iVar10)) {
            do {
                piVar11 = ppiVar3[1];
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024ff3b;
                piVar11 = (int64_t *)fcn.180222340(piVar11, uVar13);
                if ((*(char *)piVar11 == '\x03') && (*(char *)((int64_t)piVar11 + 1) == '\x01')) {
                    uVar1 = *(uint8_t *)((int64_t)piVar11 + 2);
                    if (uVar1 == uVar14) {
code_r0x00018024ff9a:
                        uVar9 = *(uint32_t *)((int64_t)var_8h + iVar10);
                    } else {
                        uVar14 = (uint32_t)uVar1;
                        iVar4 = *(int64_t *)(**ppiVar3 + (uint64_t)(uint32_t)uVar1 * 8);
                        *(uint32_t *)((int64_t)var_8h + iVar10) = uVar7;
                        iVar15 = *(int64_t *)((int64_t)&var_18h + iVar10);
                        uVar9 = uVar7;
                        if (iVar4 != 0) {
                            *(undefined8 *)(&stack0x00000000 + iVar10) = 0;
                            *(int64_t *)(&stack0xfffffffffffffff8 + iVar10) = iVar4;
                            iVar15 = (int64_t)&arg_28h + iVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024ff96;
                            iVar8 = func_0x000180214220(*(int64_t *)((int64_t)&var_18h + iVar10), uVar7, 
                                                        (int64_t)&arg_28h + iVar10, (int64_t)var_8h + iVar10);
                            if (iVar8 != 0) goto code_r0x00018024ff9a;
                            *(undefined4 *)((int64_t)var_8h + iVar10 + 4) = 0xffffffff;
                            break;
                        }
                    }
                    if ((uint64_t)uVar9 == piVar11[2]) {
                        iVar4 = piVar11[1];
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024ffb3;
                        iVar8 = fcn.180497f30(iVar15, iVar4);
                        if (iVar8 == 0) {
                            *(undefined4 *)((int64_t)var_8h + iVar10 + 4) = 1;
                            *(undefined4 *)((int64_t)ppiVar3 + 0x2c) = 0;
                            ppiVar3[3] = piVar11;
                            break;
                        }
                    }
                }
                uVar13 = uVar13 + 1;
            } while ((int32_t)uVar13 < *(int32_t *)((int64_t)&var_10h + iVar10));
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18024fff6;
        fcn.180224990(*(undefined8 *)((int64_t)&var_18h + iVar10), 0x1804e48c8, 0xd1d);
        iVar8 = *(int32_t *)((int64_t)var_8h + iVar10 + 4);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (iVar8 < 0) {
            *(undefined4 *)(in_RCX + 0xb8) = 1;
        } else {
            if (iVar8 < 1) {
                uVar12 = 0x41;
            }
            *(undefined4 *)(in_RCX + 0xb8) = uVar12;
            pcVar5 = *(code **)(in_RCX + 0x38);
            if (pcVar5 == (code *)0x0) {
                pcVar5 = *(code **)(in_RCX + 0x40);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180250059;
                (*pcVar5)(0 < iVar8, in_RCX);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180250045;
                (*pcVar5)(in_RCX);
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180250071;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_68h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_180250090
// Address: 0x180250090
// Size: 411 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h

uint32_t fcn.180250090(int64_t placeholder_0, int64_t arg2, uint32_t *placeholder_2, int64_t placeholder_3,
                      int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int64_t iVar8;
    bool bVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802500b1;
    var_10h = arg2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = *placeholder_2;
    iVar8 = 0;
    uVar7 = 0;
    *(undefined4 *)((int64_t)&arg_38h + iVar3) = 0;
    uVar2 = *(uint32_t *)(placeholder_3 + 0x90);
    if ((uVar2 & 2) != 0) {
        return 0;
    }
    if ((*(uint32_t *)(*(int64_t *)(placeholder_0 + 0x28) + 0x14) & 0x1000) == 0) {
        bVar9 = (uVar2 & 0x60) == 0;
code_r0x00018025011d:
        if (!bVar9) {
            return 0;
        }
    } else {
        if ((uVar2 & 0x40) == 0) {
            bVar9 = *(int64_t *)(placeholder_3 + 0xa0) == 0;
            goto code_r0x00018025011d;
        }
        if ((*(uint32_t *)(placeholder_3 + 0x94) & ~uVar6) == 0) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180250127;
    func_0x00018021eaf0(placeholder_3);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180250134;
    fcn.1801e3990(*(undefined8 *)((int64_t)&arg_48h + iVar3));
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025013f;
    iVar1 = fcn.1802378e0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3));
    if (iVar1 == 0) {
        uVar7 = 0x20;
        *(undefined4 *)((int64_t)&arg_38h + iVar3) = 0x20;
    } else if ((*(uint8_t *)(placeholder_3 + 0x90) & 0x20) == 0) {
        return 0;
    }
    if ((*(uint32_t *)(placeholder_3 + 0x7c) & 0x200) == 0) {
        uVar7 = uVar7 | 0x100;
        *(uint32_t *)((int64_t)&arg_38h + iVar3) = uVar7;
    }
    uVar2 = *(uint32_t *)(*(int64_t *)(placeholder_0 + 0x28) + 0x14);
    if ((uVar2 & 2) == 0) {
        if ((uVar2 >> 0x15 & 1) == 0) goto code_r0x000180250180;
    } else {
        iVar8 = *(int64_t *)(placeholder_0 + 0x28) + 8;
code_r0x000180250180:
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180250188;
        uVar4 = func_0x0001801dd170(placeholder_3);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180250193;
        uVar2 = func_0x00018024c3a0(uVar4, iVar8);
        if (uVar2 < 0x80000000) goto code_r0x0001802501cf;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802501a0;
        iVar5 = func_0x000180192480(placeholder_3);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802501ad;
            uVar4 = func_0x000180192480(placeholder_3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802501b8;
            iVar1 = func_0x00018024c3a0(uVar4, iVar8);
            if ((iVar1 == 0) || ((iVar1 < 0 && ((*(uint8_t *)(placeholder_0 + 0xd8) & 2) == 0))))
            goto code_r0x0001802501cf;
        }
    }
    *(uint32_t *)((int64_t)&arg_38h + iVar3) = uVar7 | 0x40;
code_r0x0001802501cf:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802501e4;
    fcn.18024f400(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                  *(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
    uVar2 = *(uint32_t *)((int64_t)&arg_38h + iVar3);
    if ((uVar2 & 4) == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180250206;
    iVar1 = fcn.18024f5a0(*(int64_t *)((int64_t)&arg_48h + iVar3), placeholder_3, (uint64_t)uVar2, 
                          (int64_t)&arg_38h + iVar3, *(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                          *(int64_t *)(&stack0x00000000 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
    if (iVar1 != 0) {
        if ((*(uint32_t *)((int64_t)&arg_38h + iVar3) & ~uVar6) == 0) {
            return 0;
        }
        uVar6 = uVar6 | *(uint32_t *)((int64_t)&arg_38h + iVar3);
        uVar2 = uVar2 | 0x80;
    }
    *placeholder_2 = uVar6;
    return uVar2;
}

// ============================================================
// Function: FUN_180250230
// Address: 0x180250230
// Size: 477 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

bool fcn.180250230(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_70h, int64_t arg_78h,
                  int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_120h)
{
    undefined8 uVar1;
    undefined8 placeholder_0;
    uint64_t *puVar2;
    undefined8 *puVar3;
    int32_t *piVar4;
    undefined4 *puVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t placeholder_3;
    undefined8 uVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    uint32_t uVar12;
    uint64_t uVar14;
    int32_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_48;
    undefined auStack_10 [4];
    int64_t var_ch;
    uint64_t uVar13;
    
    uStack_48 = 0x18025025a;
    var_8h = arg1;
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar9 = *(undefined8 *)(arg1 + 0xc0);
    uVar11 = 0;
    uVar1 = *(undefined8 *)((int64_t)&arg_a0h + iVar8);
    *(undefined4 *)(auStack_10 + iVar8) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar9;
    iVar15 = **(int32_t **)((int64_t)&arg_90h + iVar8);
    *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
    *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18025029e;
    iVar6 = fcn.180222010(uVar1);
    if (0 < iVar6) {
        placeholder_0 = *(undefined8 *)((int64_t)&arg_70h + iVar8);
        uVar13 = uVar11;
        uVar14 = uVar11;
        do {
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802502ba;
            placeholder_3 = fcn.180222340(uVar1, uVar13);
            *(undefined8 *)(&stack0xffffffffffffffe0 + iVar8) = uVar9;
            *(undefined4 *)(&stack0xfffffffffffffffc + iVar8 + -8) = **(undefined4 **)((int64_t)&arg_98h + iVar8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802502e5;
            iVar6 = fcn.180250090(placeholder_0, (int64_t)&var_8h + iVar8, &stack0xfffffffffffffffc + iVar8 + -8, 
                                  placeholder_3, *(int64_t *)(&stack0xffffffffffffffe0 + iVar8), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(auStack_10 + iVar8), 
                                  *(int64_t *)(&stack0xfffffffffffffffc + iVar8 + -4), 
                                  *(int64_t *)(&stack0x00000000 + iVar8));
            if ((iVar6 < iVar15) || (iVar6 == 0)) {
code_r0x000180250352:
                uVar10 = *(undefined8 *)(&stack0x00000000 + iVar8);
            } else {
                if ((iVar6 == iVar15) && (uVar14 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180250302;
                    uVar9 = func_0x0001801dd170(placeholder_3);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18025030d;
                    uVar10 = func_0x0001801dd170(uVar14);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180250322;
                    iVar7 = func_0x0001802aa2d0(&stack0xfffffffffffffffc + iVar8 + -4, &stack0xfffffffffffffffc + iVar8
                                                , uVar10, uVar9);
                    if ((iVar7 == 0) ||
                       ((*(int32_t *)(&stack0xfffffffffffffffc + iVar8 + -4) < 1 &&
                        (*(int32_t *)(&stack0xfffffffffffffffc + iVar8) < 1)))) {
                        uVar11 = (uint64_t)*(uint32_t *)(auStack_10 + iVar8);
                        goto code_r0x000180250352;
                    }
                }
                uVar12 = *(uint32_t *)(&stack0xfffffffffffffffc + iVar8 + -8);
                uVar11 = (uint64_t)uVar12;
                uVar10 = *(undefined8 *)((int64_t)&var_8h + iVar8);
                *(undefined8 *)(&stack0x00000000 + iVar8) = uVar10;
                *(uint32_t *)(auStack_10 + iVar8) = uVar12;
                uVar14 = placeholder_3;
                iVar15 = iVar6;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180250361;
            iVar6 = fcn.180222010(uVar1);
            uVar9 = *(undefined8 *)((int64_t)&var_10h + iVar8);
        } while ((int32_t)uVar12 < iVar6);
        if (uVar14 != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180250381;
            iVar6 = func_0x00018028ef00(uVar14);
            if (iVar6 == 0) {
                return false;
            }
            puVar2 = *(uint64_t **)((int64_t)&arg_78h + iVar8);
            uVar13 = *puVar2;
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180250399;
            func_0x00018028eb90(uVar13);
            puVar3 = *(undefined8 **)((int64_t)&arg_88h + iVar8);
            *puVar2 = uVar14;
            piVar4 = *(int32_t **)((int64_t)&arg_90h + iVar8);
            *puVar3 = uVar10;
            puVar5 = *(undefined4 **)((int64_t)&arg_98h + iVar8);
            *piVar4 = iVar15;
            *puVar5 = (int32_t)uVar11;
            puVar3 = *(undefined8 **)((int64_t)&arg_80h + iVar8);
            uVar9 = *puVar3;
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802503cc;
            func_0x00018028eb90(uVar9);
            uVar9 = *(undefined8 *)((int64_t)&arg_70h + iVar8);
            *puVar3 = 0;
            *(undefined8 *)(&stack0xffffffffffffffe0 + iVar8) = uVar1;
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802503ea;
            func_0x000180250410(uVar9, puVar3, piVar4, uVar14);
        }
    }
    return 0x1bf < iVar15;
}

// ============================================================
// Function: FUN_180250410
// Address: 0x180250410
// Size: 78 bytes
// ============================================================
void fcn.180250410(int64_t placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    undefined8 unaff_RBX;
    uint32_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    uint32_t *in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    uint64_t uVar9;
    
    uStack_20 = 0x180250424;
    var_10h = arg2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((*(uint32_t *)(*(int64_t *)(placeholder_0 + 0x28) + 0x14) & 0x2000) != 0) &&
       (((*(uint32_t *)(*(int64_t *)(placeholder_0 + 0xc0) + 0xd8) | *(uint32_t *)(in_R9 + 0x7c)) >> 0xc & 1) != 0)) {
        *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBP;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R14;
        uVar6 = *(undefined8 *)((int64_t)&arg_58h + iVar4);
        *(undefined8 *)((int64_t)&var_8h + iVar4) = unaff_R15;
        uVar10 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025048a;
        iVar3 = fcn.180222010(uVar6);
        uVar9 = uVar10;
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025049c;
                iVar5 = fcn.180222340(uVar6, uVar9);
                if ((*(int64_t *)(iVar5 + 0xa0) != 0) && (*(int64_t *)(in_R9 + 0x98) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504bd;
                    func_0x00018021eaf0(iVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504c8;
                    func_0x00018021eaf0(in_R9);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504d3;
                    iVar3 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar4));
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504e8;
                        iVar3 = fcn.18024f870(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504fd;
                            iVar3 = fcn.18024f870(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                            if (iVar3 != 0) {
                                uVar1 = *(undefined8 *)(in_R9 + 0x98);
                                uVar2 = *(undefined8 *)(iVar5 + 0xa0);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180250514;
                                iVar3 = fcn.18025fd70(uVar2, uVar1);
                                if (iVar3 < 1) {
                                    uVar1 = *(undefined8 *)(in_R9 + 0x98);
                                    uVar2 = *(undefined8 *)(iVar5 + 0x98);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025052b;
                                    iVar3 = fcn.18025fd70(uVar2, uVar1);
                                    if (0 < iVar3) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180250574;
                                        iVar3 = func_0x00018028ef00(iVar5);
                                        if (iVar3 != 0) {
                                            **(int64_t **)((int64_t)&arg_40h + iVar4) = iVar5;
                                            uVar8 = *(uint32_t *)(*(int64_t *)(placeholder_0 + 0x28) + 0x14);
                                            if ((uVar8 & 2) == 0) {
                                                if ((uVar8 >> 0x15 & 1) != 0) goto code_r0x0001802505e8;
                                            } else {
                                                uVar10 = *(int64_t *)(placeholder_0 + 0x28) + 8;
                                            }
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505a0;
                                            uVar6 = func_0x0001801dd170(iVar5);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505ab;
                                            uVar8 = func_0x00018024c3a0(uVar6, uVar10);
                                            if (uVar8 < 0x80000000) {
                                                return;
                                            }
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505b8;
                                            iVar7 = func_0x000180192480(iVar5);
                                            if (iVar7 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505c5;
                                                uVar6 = func_0x000180192480(iVar5);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505d0;
                                                iVar3 = func_0x00018024c3a0(uVar6, uVar10);
                                                if (iVar3 == 0) {
                                                    return;
                                                }
                                                if ((iVar3 < 0) && ((*(uint8_t *)(placeholder_0 + 0xd8) & 2) == 0)) {
                                                    return;
                                                }
                                            }
code_r0x0001802505e8:
                                            *in_R8 = *in_R8 | 2;
                                            return;
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                uVar8 = (int32_t)uVar9 + 1;
                uVar9 = (uint64_t)uVar8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180250539;
                iVar3 = fcn.180222010(uVar6);
            } while ((int32_t)uVar8 < iVar3);
        }
        **(undefined8 **)((int64_t)&arg_40h + iVar4) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18025045e
// Address: 0x18025045e
// Size: 260 bytes
// ============================================================
void fcn.180250410(int64_t placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    undefined8 unaff_RBX;
    uint32_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    uint32_t *in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    uint64_t uVar9;
    
    uStack_20 = 0x180250424;
    var_10h = arg2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((*(uint32_t *)(*(int64_t *)(placeholder_0 + 0x28) + 0x14) & 0x2000) != 0) &&
       (((*(uint32_t *)(*(int64_t *)(placeholder_0 + 0xc0) + 0xd8) | *(uint32_t *)(in_R9 + 0x7c)) >> 0xc & 1) != 0)) {
        *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBP;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R14;
        uVar6 = *(undefined8 *)((int64_t)&arg_58h + iVar4);
        *(undefined8 *)((int64_t)&var_8h + iVar4) = unaff_R15;
        uVar10 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025048a;
        iVar3 = fcn.180222010(uVar6);
        uVar9 = uVar10;
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025049c;
                iVar5 = fcn.180222340(uVar6, uVar9);
                if ((*(int64_t *)(iVar5 + 0xa0) != 0) && (*(int64_t *)(in_R9 + 0x98) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504bd;
                    func_0x00018021eaf0(iVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504c8;
                    func_0x00018021eaf0(in_R9);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504d3;
                    iVar3 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar4));
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504e8;
                        iVar3 = fcn.18024f870(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504fd;
                            iVar3 = fcn.18024f870(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                            if (iVar3 != 0) {
                                uVar1 = *(undefined8 *)(in_R9 + 0x98);
                                uVar2 = *(undefined8 *)(iVar5 + 0xa0);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180250514;
                                iVar3 = fcn.18025fd70(uVar2, uVar1);
                                if (iVar3 < 1) {
                                    uVar1 = *(undefined8 *)(in_R9 + 0x98);
                                    uVar2 = *(undefined8 *)(iVar5 + 0x98);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025052b;
                                    iVar3 = fcn.18025fd70(uVar2, uVar1);
                                    if (0 < iVar3) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180250574;
                                        iVar3 = func_0x00018028ef00(iVar5);
                                        if (iVar3 != 0) {
                                            **(int64_t **)((int64_t)&arg_40h + iVar4) = iVar5;
                                            uVar8 = *(uint32_t *)(*(int64_t *)(placeholder_0 + 0x28) + 0x14);
                                            if ((uVar8 & 2) == 0) {
                                                if ((uVar8 >> 0x15 & 1) != 0) goto code_r0x0001802505e8;
                                            } else {
                                                uVar10 = *(int64_t *)(placeholder_0 + 0x28) + 8;
                                            }
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505a0;
                                            uVar6 = func_0x0001801dd170(iVar5);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505ab;
                                            uVar8 = func_0x00018024c3a0(uVar6, uVar10);
                                            if (uVar8 < 0x80000000) {
                                                return;
                                            }
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505b8;
                                            iVar7 = func_0x000180192480(iVar5);
                                            if (iVar7 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505c5;
                                                uVar6 = func_0x000180192480(iVar5);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505d0;
                                                iVar3 = func_0x00018024c3a0(uVar6, uVar10);
                                                if (iVar3 == 0) {
                                                    return;
                                                }
                                                if ((iVar3 < 0) && ((*(uint8_t *)(placeholder_0 + 0xd8) & 2) == 0)) {
                                                    return;
                                                }
                                            }
code_r0x0001802505e8:
                                            *in_R8 = *in_R8 | 2;
                                            return;
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                uVar8 = (int32_t)uVar9 + 1;
                uVar9 = (uint64_t)uVar8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180250539;
                iVar3 = fcn.180222010(uVar6);
            } while ((int32_t)uVar8 < iVar3);
        }
        **(undefined8 **)((int64_t)&arg_40h + iVar4) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180250562
// Address: 0x180250562
// Size: 10 bytes
// ============================================================
void fcn.180250410(int64_t placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    undefined8 unaff_RBX;
    uint32_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    uint32_t *in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    uint64_t uVar9;
    
    uStack_20 = 0x180250424;
    var_10h = arg2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((*(uint32_t *)(*(int64_t *)(placeholder_0 + 0x28) + 0x14) & 0x2000) != 0) &&
       (((*(uint32_t *)(*(int64_t *)(placeholder_0 + 0xc0) + 0xd8) | *(uint32_t *)(in_R9 + 0x7c)) >> 0xc & 1) != 0)) {
        *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBP;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R14;
        uVar6 = *(undefined8 *)((int64_t)&arg_58h + iVar4);
        *(undefined8 *)((int64_t)&var_8h + iVar4) = unaff_R15;
        uVar10 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025048a;
        iVar3 = fcn.180222010(uVar6);
        uVar9 = uVar10;
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025049c;
                iVar5 = fcn.180222340(uVar6, uVar9);
                if ((*(int64_t *)(iVar5 + 0xa0) != 0) && (*(int64_t *)(in_R9 + 0x98) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504bd;
                    func_0x00018021eaf0(iVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504c8;
                    func_0x00018021eaf0(in_R9);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504d3;
                    iVar3 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar4));
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504e8;
                        iVar3 = fcn.18024f870(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504fd;
                            iVar3 = fcn.18024f870(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                            if (iVar3 != 0) {
                                uVar1 = *(undefined8 *)(in_R9 + 0x98);
                                uVar2 = *(undefined8 *)(iVar5 + 0xa0);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180250514;
                                iVar3 = fcn.18025fd70(uVar2, uVar1);
                                if (iVar3 < 1) {
                                    uVar1 = *(undefined8 *)(in_R9 + 0x98);
                                    uVar2 = *(undefined8 *)(iVar5 + 0x98);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025052b;
                                    iVar3 = fcn.18025fd70(uVar2, uVar1);
                                    if (0 < iVar3) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180250574;
                                        iVar3 = func_0x00018028ef00(iVar5);
                                        if (iVar3 != 0) {
                                            **(int64_t **)((int64_t)&arg_40h + iVar4) = iVar5;
                                            uVar8 = *(uint32_t *)(*(int64_t *)(placeholder_0 + 0x28) + 0x14);
                                            if ((uVar8 & 2) == 0) {
                                                if ((uVar8 >> 0x15 & 1) != 0) goto code_r0x0001802505e8;
                                            } else {
                                                uVar10 = *(int64_t *)(placeholder_0 + 0x28) + 8;
                                            }
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505a0;
                                            uVar6 = func_0x0001801dd170(iVar5);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505ab;
                                            uVar8 = func_0x00018024c3a0(uVar6, uVar10);
                                            if (uVar8 < 0x80000000) {
                                                return;
                                            }
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505b8;
                                            iVar7 = func_0x000180192480(iVar5);
                                            if (iVar7 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505c5;
                                                uVar6 = func_0x000180192480(iVar5);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505d0;
                                                iVar3 = func_0x00018024c3a0(uVar6, uVar10);
                                                if (iVar3 == 0) {
                                                    return;
                                                }
                                                if ((iVar3 < 0) && ((*(uint8_t *)(placeholder_0 + 0xd8) & 2) == 0)) {
                                                    return;
                                                }
                                            }
code_r0x0001802505e8:
                                            *in_R8 = *in_R8 | 2;
                                            return;
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                uVar8 = (int32_t)uVar9 + 1;
                uVar9 = (uint64_t)uVar8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180250539;
                iVar3 = fcn.180222010(uVar6);
            } while ((int32_t)uVar8 < iVar3);
        }
        **(undefined8 **)((int64_t)&arg_40h + iVar4) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18025056c
// Address: 0x18025056c
// Size: 134 bytes
// ============================================================
void fcn.180250410(int64_t placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    undefined8 unaff_RBX;
    uint32_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    uint32_t *in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    uint64_t uVar9;
    
    uStack_20 = 0x180250424;
    var_10h = arg2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((*(uint32_t *)(*(int64_t *)(placeholder_0 + 0x28) + 0x14) & 0x2000) != 0) &&
       (((*(uint32_t *)(*(int64_t *)(placeholder_0 + 0xc0) + 0xd8) | *(uint32_t *)(in_R9 + 0x7c)) >> 0xc & 1) != 0)) {
        *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBP;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R14;
        uVar6 = *(undefined8 *)((int64_t)&arg_58h + iVar4);
        *(undefined8 *)((int64_t)&var_8h + iVar4) = unaff_R15;
        uVar10 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025048a;
        iVar3 = fcn.180222010(uVar6);
        uVar9 = uVar10;
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025049c;
                iVar5 = fcn.180222340(uVar6, uVar9);
                if ((*(int64_t *)(iVar5 + 0xa0) != 0) && (*(int64_t *)(in_R9 + 0x98) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504bd;
                    func_0x00018021eaf0(iVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504c8;
                    func_0x00018021eaf0(in_R9);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504d3;
                    iVar3 = fcn.1802378e0(*(int64_t *)((int64_t)&var_8h + iVar4));
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504e8;
                        iVar3 = fcn.18024f870(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802504fd;
                            iVar3 = fcn.18024f870(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                            if (iVar3 != 0) {
                                uVar1 = *(undefined8 *)(in_R9 + 0x98);
                                uVar2 = *(undefined8 *)(iVar5 + 0xa0);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180250514;
                                iVar3 = fcn.18025fd70(uVar2, uVar1);
                                if (iVar3 < 1) {
                                    uVar1 = *(undefined8 *)(in_R9 + 0x98);
                                    uVar2 = *(undefined8 *)(iVar5 + 0x98);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025052b;
                                    iVar3 = fcn.18025fd70(uVar2, uVar1);
                                    if (0 < iVar3) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180250574;
                                        iVar3 = func_0x00018028ef00(iVar5);
                                        if (iVar3 != 0) {
                                            **(int64_t **)((int64_t)&arg_40h + iVar4) = iVar5;
                                            uVar8 = *(uint32_t *)(*(int64_t *)(placeholder_0 + 0x28) + 0x14);
                                            if ((uVar8 & 2) == 0) {
                                                if ((uVar8 >> 0x15 & 1) != 0) goto code_r0x0001802505e8;
                                            } else {
                                                uVar10 = *(int64_t *)(placeholder_0 + 0x28) + 8;
                                            }
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505a0;
                                            uVar6 = func_0x0001801dd170(iVar5);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505ab;
                                            uVar8 = func_0x00018024c3a0(uVar6, uVar10);
                                            if (uVar8 < 0x80000000) {
                                                return;
                                            }
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505b8;
                                            iVar7 = func_0x000180192480(iVar5);
                                            if (iVar7 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505c5;
                                                uVar6 = func_0x000180192480(iVar5);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802505d0;
                                                iVar3 = func_0x00018024c3a0(uVar6, uVar10);
                                                if (iVar3 == 0) {
                                                    return;
                                                }
                                                if ((iVar3 < 0) && ((*(uint8_t *)(placeholder_0 + 0xd8) & 2) == 0)) {
                                                    return;
                                                }
                                            }
code_r0x0001802505e8:
                                            *in_R8 = *in_R8 | 2;
                                            return;
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                uVar8 = (int32_t)uVar9 + 1;
                uVar9 = (uint64_t)uVar8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180250539;
                iVar3 = fcn.180222010(uVar6);
            } while ((int32_t)uVar8 < iVar3);
        }
        **(undefined8 **)((int64_t)&arg_40h + iVar4) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180250600
// Address: 0x180250600
// Size: 656 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180250600(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int32_t iVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025061e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (*(int64_t *)(in_RCX + 0x108) == 0) {
        uVar2 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025067a;
        iVar3 = fcn.180222010(uVar2);
        uVar2 = *(undefined8 *)(in_RCX + 0xa0);
        iVar8 = iVar3 + -1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025068b;
        iVar6 = fcn.180222340(uVar2, iVar8);
        *(int32_t *)(in_RCX + 0xb4) = iVar8;
        if (*(int32_t *)(in_RCX + 0x100) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802506b3;
            iVar4 = fcn.18023bda0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            iVar9 = iVar6;
            if ((iVar4 != 0) && ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80000) == 0)) {
                if (iVar8 < 1) {
                    *(undefined4 *)(in_RCX + 0xb4) = 0;
                    iVar7 = iVar6;
                    if (iVar6 == 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180250702;
                        iVar7 = fcn.180222340(uVar2, 0);
                    }
                    *(int64_t *)(in_RCX + 0xc0) = iVar7;
                    pcVar1 = *(code **)(in_RCX + 0x40);
                    *(undefined4 *)(in_RCX + 0xb8) = 0x15;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025071e;
                    iVar3 = (*pcVar1)(0, in_RCX);
                    if (iVar3 == 0) {
                        return 0;
                    }
                } else {
                    uVar2 = *(undefined8 *)(in_RCX + 0xa0);
                    iVar8 = iVar3 + -2;
                    *(int32_t *)(in_RCX + 0xb4) = iVar8;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802506de;
                    iVar6 = fcn.180222340(uVar2, iVar8);
                }
            }
        } else {
            iVar9 = 0;
        }
        if (-1 < iVar8) {
            do {
                if (iVar9 != 0) {
                    if (iVar6 != iVar9) {
                        iVar3 = (uint32_t)(iVar6 != iVar9) + iVar8;
code_r0x00018025077f:
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025078a;
                        iVar4 = func_0x00018023be60(iVar9, iVar6);
                        if (iVar4 != 0) {
                            if (-1 < iVar3) {
                                *(int32_t *)(in_RCX + 0xb4) = iVar3;
                            }
                            *(int32_t *)(in_RCX + 0xb8) = iVar4;
                            pcVar1 = *(code **)(in_RCX + 0x40);
                            *(int64_t *)(in_RCX + 0xc0) = iVar9;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802507b0;
                            iVar4 = (*pcVar1)(0, in_RCX);
                            if (iVar4 == 0) {
                                return 0;
                            }
                        }
                    } else {
                        if (((*(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x4000) == 0) ||
                           ((*(uint32_t *)(iVar9 + 0xd8) & 0x2000) == 0)) goto code_r0x00018025082f;
                        iVar3 = (uint32_t)(iVar6 != iVar9) + iVar8;
                        if ((*(uint8_t *)(iVar9 + 0xd8) & 0x10) != 0) goto code_r0x00018025077f;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802507c0;
                    iVar7 = fcn.180238400(iVar9);
                    if (iVar7 == 0) {
                        if (-1 < iVar3) {
                            *(int32_t *)(in_RCX + 0xb4) = iVar3;
                        }
                        *(int64_t *)(in_RCX + 0xc0) = iVar9;
                        *(undefined4 *)(in_RCX + 0xb8) = 6;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802507ed;
                        iVar3 = func_0x0001802405a0(iVar6, iVar7);
                        if (0 < iVar3) goto code_r0x00018025082f;
                        *(int32_t *)(in_RCX + 0xb4) = iVar8;
                        iVar7 = iVar6;
                        if (iVar6 == 0) {
                            uVar2 = *(undefined8 *)(in_RCX + 0xa0);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025080f;
                            iVar7 = fcn.180222340(uVar2, iVar8);
                        }
                        *(int64_t *)(in_RCX + 0xc0) = iVar7;
                        *(undefined4 *)(in_RCX + 0xb8) = 7;
                    }
                    pcVar1 = *(code **)(in_RCX + 0x40);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025082b;
                    iVar3 = (*pcVar1)(0, in_RCX);
                    if (iVar3 == 0) {
                        return 0;
                    }
                }
code_r0x00018025082f:
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025083d;
                iVar3 = func_0x0001802508a0(in_RCX, iVar6, iVar8);
                if (iVar3 == 0) {
                    return 0;
                }
                pcVar1 = *(code **)(in_RCX + 0x40);
                *(int64_t *)(in_RCX + 200) = iVar9;
                *(int64_t *)(in_RCX + 0xc0) = iVar6;
                *(int32_t *)(in_RCX + 0xb4) = iVar8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180250863;
                iVar3 = (*pcVar1)(1, in_RCX);
                if (iVar3 == 0) {
                    return 0;
                }
                iVar8 = iVar8 + -1;
                if (iVar8 < 0) {
                    return 1;
                }
                uVar2 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180250881;
                iVar7 = fcn.180222340(uVar2, iVar8);
                iVar9 = iVar6;
                iVar6 = iVar7;
            } while( true );
        }
    } else {
        pcVar1 = *(code **)(in_RCX + 0x40);
        iVar3 = *(int32_t *)(in_RCX + 0xb8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180250648;
        iVar3 = (*pcVar1)(iVar3 == 0, in_RCX);
        if (iVar3 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1802508a0
// Address: 0x1802508a0
// Size: 476 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.1802508a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    code *pcVar2;
    bool bVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar8;
    int64_t iVar9;
    int32_t iVar10;
    uint64_t uVar11;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802508c0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar9 = 0;
    uVar11 = in_R8 & 0xffffffff;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14);
    if ((uVar1 & 2) == 0) {
        if ((uVar1 >> 0x15 & 1) == 0) goto code_r0x0001802508ee;
code_r0x000180250a5c:
        bVar3 = true;
    } else {
        iVar9 = *(int64_t *)(in_RCX + 0x28) + 8;
code_r0x0001802508ee:
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802508f6;
        uVar6 = func_0x0001801e8e30(in_RDX);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250901;
        iVar4 = func_0x00018024c3a0(uVar6, iVar9);
        iVar10 = (int32_t)in_R8;
        if ((iVar4 < 0) || (-1 < iVar10)) {
            iVar7 = in_RDX;
            if (iVar4 == 0) {
                if (iVar10 < 0) {
                    uVar8 = (uint64_t)*(uint32_t *)(in_RCX + 0xb4);
                } else {
                    *(int32_t *)(in_RCX + 0xb4) = iVar10;
                    uVar8 = uVar11;
                }
                if (in_RDX == 0) {
                    uVar6 = *(undefined8 *)(in_RCX + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250945;
                    iVar7 = fcn.180222340(uVar6, uVar8);
                    *(undefined4 *)(in_RCX + 0xb8) = 0xd;
                } else {
                    *(undefined4 *)(in_RCX + 0xb8) = 0xd;
                }
code_r0x000180250989:
                *(int64_t *)(in_RCX + 0xc0) = iVar7;
                pcVar2 = *(code **)(in_RCX + 0x40);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025099b;
                iVar4 = (*pcVar2)(0, in_RCX);
                if (iVar4 == 0) goto code_r0x000180250a06;
            } else if (0 < iVar4) {
                if (iVar10 < 0) {
                    uVar8 = (uint64_t)*(uint32_t *)(in_RCX + 0xb4);
                } else {
                    *(int32_t *)(in_RCX + 0xb4) = iVar10;
                    uVar8 = uVar11;
                }
                if (in_RDX == 0) {
                    uVar6 = *(undefined8 *)(in_RCX + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025097f;
                    iVar7 = fcn.180222340(uVar6, uVar8);
                }
                *(undefined4 *)(in_RCX + 0xb8) = 9;
                goto code_r0x000180250989;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802509a7;
            uVar6 = func_0x000180201ea0(in_RDX);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802509b2;
            iVar4 = func_0x00018024c3a0(uVar6, iVar9);
            if (0 < iVar4) {
code_r0x000180250a0a:
                if (iVar4 < 0) {
                    if (iVar10 < 0) {
                        uVar11 = (uint64_t)*(uint32_t *)(in_RCX + 0xb4);
                    } else {
                        *(int32_t *)(in_RCX + 0xb4) = iVar10;
                    }
                    if (in_RDX == 0) {
                        uVar6 = *(undefined8 *)(in_RCX + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250a31;
                        in_RDX = fcn.180222340(uVar6, uVar11);
                    }
                    pcVar2 = *(code **)(in_RCX + 0x40);
                    *(int64_t *)(in_RCX + 0xc0) = in_RDX;
                    *(undefined4 *)(in_RCX + 0xb8) = 10;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250a51;
                    iVar4 = (*pcVar2)(0, in_RCX);
                    return iVar4 != 0;
                }
                goto code_r0x000180250a5c;
            }
            if (-1 < iVar10) {
                if (iVar4 != 0) goto code_r0x000180250a0a;
                if (iVar10 < 0) {
                    uVar11 = (uint64_t)*(uint32_t *)(in_RCX + 0xb4);
                } else {
                    *(int32_t *)(in_RCX + 0xb4) = iVar10;
                }
                if (in_RDX == 0) {
                    uVar6 = *(undefined8 *)(in_RCX + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802509e3;
                    in_RDX = fcn.180222340(uVar6, uVar11);
                }
                pcVar2 = *(code **)(in_RCX + 0x40);
                *(int64_t *)(in_RCX + 0xc0) = in_RDX;
                *(undefined4 *)(in_RCX + 0xb8) = 0xe;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250a02;
                iVar4 = (*pcVar2)(0, in_RCX);
                if (iVar4 != 0) goto code_r0x000180250a5c;
            }
        }
code_r0x000180250a06:
        bVar3 = false;
    }
    return bVar3;
}

// ============================================================
// Function: FUN_180250a80
// Address: 0x180250a80
// Size: 161 bytes
// ============================================================
uint64_t fcn.180250a80(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    uint64_t uVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180250a8c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250a97;
    uVar3 = func_0x00018024c7b0();
    if ((int32_t)uVar3 < 1) {
        return (uint64_t)uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250aa9;
    uVar3 = fcn.18024dee0(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
    if ((int32_t)uVar3 < 1) {
        return (uint64_t)uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250abb;
    uVar3 = func_0x00018024d380(in_RCX);
    if ((int32_t)uVar3 < 1) {
        return (uint64_t)uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250acd;
    uVar3 = fcn.18024e760(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
    if (0 < (int32_t)uVar3) {
        uVar6 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250ae5;
        iVar4 = func_0x00018024c4a0(0, uVar6);
        if (iVar4 == 0) {
            return 0xffffffff;
        }
        pcVar2 = *(code **)(in_RCX + 0x58);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b03;
        uVar3 = (*pcVar2)(in_RCX);
        if (0 < (int32_t)uVar3) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b34;
            iVar4 = fcn.180237df0(*(int64_t *)(&stack0x00000050 + iVar5), *(int64_t *)(&stack0x00000068 + iVar5), 
                                  *(int64_t *)(&stack0x00000070 + iVar5), *(int64_t *)(&stack0x00000078 + iVar5), 
                                  *(int64_t *)(&stack0x00000080 + iVar5));
            if (iVar4 != 0) {
                uVar1 = *(undefined4 *)(in_RCX + 0xb4);
                uVar6 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b4c;
                uVar6 = fcn.180222340(uVar6, uVar1);
                *(undefined8 *)(in_RCX + 0xc0) = uVar6;
                pcVar2 = *(code **)(in_RCX + 0x40);
                *(int32_t *)(in_RCX + 0xb8) = iVar4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b64;
                uVar7 = (*pcVar2)(0, in_RCX);
                if ((int32_t)uVar7 == 0) {
                    return uVar7;
                }
            }
            pcVar2 = *(code **)(in_RCX + 0x38);
            if (pcVar2 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b8d;
                uVar7 = fcn.180250600(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b86;
                uVar7 = (*pcVar2)(in_RCX);
            }
            if (0 < (int32_t)uVar7) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b99;
                uVar7 = fcn.18024ea10(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5));
                if (0 < (int32_t)uVar7) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250ba5;
                    uVar7 = func_0x000180292b60(in_RCX);
                    if (0 < (int32_t)uVar7) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250bb1;
                        uVar7 = func_0x000180294a10(in_RCX);
                        uVar8 = uVar7 & 0xffffffff;
                        if (0 < (int32_t)uVar7) {
                            if ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80) != 0) {
                                pcVar2 = *(code **)(in_RCX + 0x78);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250bca;
                                uVar3 = (*pcVar2)(in_RCX);
                                uVar8 = (uint64_t)uVar3;
                            }
                            return uVar8;
                        }
                    }
                }
            }
            return uVar7;
        }
        return (uint64_t)uVar3;
    }
    return (uint64_t)uVar3;
}

// ============================================================
// Function: FUN_180250b21
// Address: 0x180250b21
// Size: 87 bytes
// ============================================================
uint64_t fcn.180250a80(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    uint64_t uVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180250a8c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250a97;
    uVar3 = func_0x00018024c7b0();
    if ((int32_t)uVar3 < 1) {
        return (uint64_t)uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250aa9;
    uVar3 = fcn.18024dee0(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
    if ((int32_t)uVar3 < 1) {
        return (uint64_t)uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250abb;
    uVar3 = func_0x00018024d380(in_RCX);
    if ((int32_t)uVar3 < 1) {
        return (uint64_t)uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250acd;
    uVar3 = fcn.18024e760(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
    if (0 < (int32_t)uVar3) {
        uVar6 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250ae5;
        iVar4 = func_0x00018024c4a0(0, uVar6);
        if (iVar4 == 0) {
            return 0xffffffff;
        }
        pcVar2 = *(code **)(in_RCX + 0x58);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b03;
        uVar3 = (*pcVar2)(in_RCX);
        if (0 < (int32_t)uVar3) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b34;
            iVar4 = fcn.180237df0(*(int64_t *)(&stack0x00000050 + iVar5), *(int64_t *)(&stack0x00000068 + iVar5), 
                                  *(int64_t *)(&stack0x00000070 + iVar5), *(int64_t *)(&stack0x00000078 + iVar5), 
                                  *(int64_t *)(&stack0x00000080 + iVar5));
            if (iVar4 != 0) {
                uVar1 = *(undefined4 *)(in_RCX + 0xb4);
                uVar6 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b4c;
                uVar6 = fcn.180222340(uVar6, uVar1);
                *(undefined8 *)(in_RCX + 0xc0) = uVar6;
                pcVar2 = *(code **)(in_RCX + 0x40);
                *(int32_t *)(in_RCX + 0xb8) = iVar4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b64;
                uVar7 = (*pcVar2)(0, in_RCX);
                if ((int32_t)uVar7 == 0) {
                    return uVar7;
                }
            }
            pcVar2 = *(code **)(in_RCX + 0x38);
            if (pcVar2 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b8d;
                uVar7 = fcn.180250600(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b86;
                uVar7 = (*pcVar2)(in_RCX);
            }
            if (0 < (int32_t)uVar7) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b99;
                uVar7 = fcn.18024ea10(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5));
                if (0 < (int32_t)uVar7) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250ba5;
                    uVar7 = func_0x000180292b60(in_RCX);
                    if (0 < (int32_t)uVar7) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250bb1;
                        uVar7 = func_0x000180294a10(in_RCX);
                        uVar8 = uVar7 & 0xffffffff;
                        if (0 < (int32_t)uVar7) {
                            if ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80) != 0) {
                                pcVar2 = *(code **)(in_RCX + 0x78);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250bca;
                                uVar3 = (*pcVar2)(in_RCX);
                                uVar8 = (uint64_t)uVar3;
                            }
                            return uVar8;
                        }
                    }
                }
            }
            return uVar7;
        }
        return (uint64_t)uVar3;
    }
    return (uint64_t)uVar3;
}

// ============================================================
// Function: FUN_180250b78
// Address: 0x180250b78
// Size: 102 bytes
// ============================================================
uint64_t fcn.180250a80(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    uint64_t uVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180250a8c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250a97;
    uVar3 = func_0x00018024c7b0();
    if ((int32_t)uVar3 < 1) {
        return (uint64_t)uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250aa9;
    uVar3 = fcn.18024dee0(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
    if ((int32_t)uVar3 < 1) {
        return (uint64_t)uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250abb;
    uVar3 = func_0x00018024d380(in_RCX);
    if ((int32_t)uVar3 < 1) {
        return (uint64_t)uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250acd;
    uVar3 = fcn.18024e760(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
    if (0 < (int32_t)uVar3) {
        uVar6 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250ae5;
        iVar4 = func_0x00018024c4a0(0, uVar6);
        if (iVar4 == 0) {
            return 0xffffffff;
        }
        pcVar2 = *(code **)(in_RCX + 0x58);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b03;
        uVar3 = (*pcVar2)(in_RCX);
        if (0 < (int32_t)uVar3) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b34;
            iVar4 = fcn.180237df0(*(int64_t *)(&stack0x00000050 + iVar5), *(int64_t *)(&stack0x00000068 + iVar5), 
                                  *(int64_t *)(&stack0x00000070 + iVar5), *(int64_t *)(&stack0x00000078 + iVar5), 
                                  *(int64_t *)(&stack0x00000080 + iVar5));
            if (iVar4 != 0) {
                uVar1 = *(undefined4 *)(in_RCX + 0xb4);
                uVar6 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b4c;
                uVar6 = fcn.180222340(uVar6, uVar1);
                *(undefined8 *)(in_RCX + 0xc0) = uVar6;
                pcVar2 = *(code **)(in_RCX + 0x40);
                *(int32_t *)(in_RCX + 0xb8) = iVar4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b64;
                uVar7 = (*pcVar2)(0, in_RCX);
                if ((int32_t)uVar7 == 0) {
                    return uVar7;
                }
            }
            pcVar2 = *(code **)(in_RCX + 0x38);
            if (pcVar2 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b8d;
                uVar7 = fcn.180250600(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b86;
                uVar7 = (*pcVar2)(in_RCX);
            }
            if (0 < (int32_t)uVar7) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b99;
                uVar7 = fcn.18024ea10(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5));
                if (0 < (int32_t)uVar7) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250ba5;
                    uVar7 = func_0x000180292b60(in_RCX);
                    if (0 < (int32_t)uVar7) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250bb1;
                        uVar7 = func_0x000180294a10(in_RCX);
                        uVar8 = uVar7 & 0xffffffff;
                        if (0 < (int32_t)uVar7) {
                            if ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80) != 0) {
                                pcVar2 = *(code **)(in_RCX + 0x78);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250bca;
                                uVar3 = (*pcVar2)(in_RCX);
                                uVar8 = (uint64_t)uVar3;
                            }
                            return uVar8;
                        }
                    }
                }
            }
            return uVar7;
        }
        return (uint64_t)uVar3;
    }
    return (uint64_t)uVar3;
}

// ============================================================
// Function: FUN_180250bde
// Address: 0x180250bde
// Size: 8 bytes
// ============================================================
uint64_t fcn.180250a80(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    uint64_t uVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180250a8c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250a97;
    uVar3 = func_0x00018024c7b0();
    if ((int32_t)uVar3 < 1) {
        return (uint64_t)uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250aa9;
    uVar3 = fcn.18024dee0(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
    if ((int32_t)uVar3 < 1) {
        return (uint64_t)uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250abb;
    uVar3 = func_0x00018024d380(in_RCX);
    if ((int32_t)uVar3 < 1) {
        return (uint64_t)uVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250acd;
    uVar3 = fcn.18024e760(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
    if (0 < (int32_t)uVar3) {
        uVar6 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250ae5;
        iVar4 = func_0x00018024c4a0(0, uVar6);
        if (iVar4 == 0) {
            return 0xffffffff;
        }
        pcVar2 = *(code **)(in_RCX + 0x58);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b03;
        uVar3 = (*pcVar2)(in_RCX);
        if (0 < (int32_t)uVar3) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b34;
            iVar4 = fcn.180237df0(*(int64_t *)(&stack0x00000050 + iVar5), *(int64_t *)(&stack0x00000068 + iVar5), 
                                  *(int64_t *)(&stack0x00000070 + iVar5), *(int64_t *)(&stack0x00000078 + iVar5), 
                                  *(int64_t *)(&stack0x00000080 + iVar5));
            if (iVar4 != 0) {
                uVar1 = *(undefined4 *)(in_RCX + 0xb4);
                uVar6 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b4c;
                uVar6 = fcn.180222340(uVar6, uVar1);
                *(undefined8 *)(in_RCX + 0xc0) = uVar6;
                pcVar2 = *(code **)(in_RCX + 0x40);
                *(int32_t *)(in_RCX + 0xb8) = iVar4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b64;
                uVar7 = (*pcVar2)(0, in_RCX);
                if ((int32_t)uVar7 == 0) {
                    return uVar7;
                }
            }
            pcVar2 = *(code **)(in_RCX + 0x38);
            if (pcVar2 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b8d;
                uVar7 = fcn.180250600(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b86;
                uVar7 = (*pcVar2)(in_RCX);
            }
            if (0 < (int32_t)uVar7) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250b99;
                uVar7 = fcn.18024ea10(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5));
                if (0 < (int32_t)uVar7) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250ba5;
                    uVar7 = func_0x000180292b60(in_RCX);
                    if (0 < (int32_t)uVar7) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250bb1;
                        uVar7 = func_0x000180294a10(in_RCX);
                        uVar8 = uVar7 & 0xffffffff;
                        if (0 < (int32_t)uVar7) {
                            if ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x80) != 0) {
                                pcVar2 = *(code **)(in_RCX + 0x78);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250bca;
                                uVar3 = (*pcVar2)(in_RCX);
                                uVar8 = (uint64_t)uVar3;
                            }
                            return uVar8;
                        }
                    }
                }
            }
            return uVar7;
        }
        return (uint64_t)uVar3;
    }
    return (uint64_t)uVar3;
}

// ============================================================
// Function: FUN_180250bf0
// Address: 0x180250bf0
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_b4h

uint64_t fcn.180250bf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180250c05;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar4 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x24);
    if (0 < (int32_t)uVar4) {
        if (*(int64_t *)(in_RCX + 0x108) != 0) {
            if (5 < (int32_t)uVar4) {
                uVar4 = 5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250c33;
            iVar3 = func_0x00018022fb60();
            if (*(int32_t *)((uint64_t)uVar4 * 4 + 0x1804e4894) <= iVar3) goto code_r0x000180250c84;
        }
        uVar6 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250c54;
        uVar6 = fcn.180222340(uVar6, 0);
        *(undefined8 *)(in_RCX + 0xc0) = uVar6;
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x42;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250c70;
        uVar7 = (*pcVar1)(0, in_RCX);
        if ((int32_t)uVar7 == 0) {
            return uVar7;
        }
    }
code_r0x000180250c84:
    iVar2 = *(int64_t *)(in_RCX + 0xf8);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
    *(int32_t *)(in_RCX + 0xb8) = 0x5f;
    if (iVar2 != 0) {
        uVar6 = *(undefined8 *)(iVar2 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250cae;
        iVar3 = fcn.180222010(uVar6);
        if (0 < iVar3) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250cba;
            uVar4 = fcn.18024fe60(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar5), *(int64_t *)(&stack0x00000058 + iVar5), 
                                  *(int64_t *)(&stack0x000000a0 + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                                  *(int64_t *)(&stack0x000000b0 + iVar5), *(int64_t *)(&stack0x000000e8 + iVar5), 
                                  *(int64_t *)(&stack0x000000f8 + iVar5));
            goto code_r0x000180250cf0;
        }
    }
    pcVar1 = *(code **)(in_RCX + 0x38);
    if (pcVar1 == (code *)0x0) {
        pcVar1 = *(code **)(in_RCX + 0x40);
        iVar3 = *(int32_t *)(in_RCX + 0xb8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250ce7;
        iVar3 = (*pcVar1)(iVar3 == 0, in_RCX);
        uVar4 = (uint32_t)(iVar3 != 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250cd3;
        uVar4 = (*pcVar1)(in_RCX);
    }
code_r0x000180250cf0:
    if (((int32_t)uVar4 < 1) && (*(int32_t *)(in_RCX + 0xb8) == 0)) {
        *(int32_t *)(in_RCX + 0xb8) = 1;
    }
    return (uint64_t)uVar4;
}

// ============================================================
// Function: FUN_180250c92
// Address: 0x180250c92
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_b4h

uint64_t fcn.180250bf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180250c05;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar4 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x24);
    if (0 < (int32_t)uVar4) {
        if (*(int64_t *)(in_RCX + 0x108) != 0) {
            if (5 < (int32_t)uVar4) {
                uVar4 = 5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250c33;
            iVar3 = func_0x00018022fb60();
            if (*(int32_t *)((uint64_t)uVar4 * 4 + 0x1804e4894) <= iVar3) goto code_r0x000180250c84;
        }
        uVar6 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250c54;
        uVar6 = fcn.180222340(uVar6, 0);
        *(undefined8 *)(in_RCX + 0xc0) = uVar6;
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x42;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250c70;
        uVar7 = (*pcVar1)(0, in_RCX);
        if ((int32_t)uVar7 == 0) {
            return uVar7;
        }
    }
code_r0x000180250c84:
    iVar2 = *(int64_t *)(in_RCX + 0xf8);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
    *(int32_t *)(in_RCX + 0xb8) = 0x5f;
    if (iVar2 != 0) {
        uVar6 = *(undefined8 *)(iVar2 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250cae;
        iVar3 = fcn.180222010(uVar6);
        if (0 < iVar3) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250cba;
            uVar4 = fcn.18024fe60(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar5), *(int64_t *)(&stack0x00000058 + iVar5), 
                                  *(int64_t *)(&stack0x000000a0 + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                                  *(int64_t *)(&stack0x000000b0 + iVar5), *(int64_t *)(&stack0x000000e8 + iVar5), 
                                  *(int64_t *)(&stack0x000000f8 + iVar5));
            goto code_r0x000180250cf0;
        }
    }
    pcVar1 = *(code **)(in_RCX + 0x38);
    if (pcVar1 == (code *)0x0) {
        pcVar1 = *(code **)(in_RCX + 0x40);
        iVar3 = *(int32_t *)(in_RCX + 0xb8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250ce7;
        iVar3 = (*pcVar1)(iVar3 == 0, in_RCX);
        uVar4 = (uint32_t)(iVar3 != 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250cd3;
        uVar4 = (*pcVar1)(in_RCX);
    }
code_r0x000180250cf0:
    if (((int32_t)uVar4 < 1) && (*(int32_t *)(in_RCX + 0xb8) == 0)) {
        *(int32_t *)(in_RCX + 0xb8) = 1;
    }
    return (uint64_t)uVar4;
}

// ============================================================
// Function: FUN_180250cf9
// Address: 0x180250cf9
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_b4h

uint64_t fcn.180250bf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180250c05;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar4 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x24);
    if (0 < (int32_t)uVar4) {
        if (*(int64_t *)(in_RCX + 0x108) != 0) {
            if (5 < (int32_t)uVar4) {
                uVar4 = 5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250c33;
            iVar3 = func_0x00018022fb60();
            if (*(int32_t *)((uint64_t)uVar4 * 4 + 0x1804e4894) <= iVar3) goto code_r0x000180250c84;
        }
        uVar6 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250c54;
        uVar6 = fcn.180222340(uVar6, 0);
        *(undefined8 *)(in_RCX + 0xc0) = uVar6;
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x42;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250c70;
        uVar7 = (*pcVar1)(0, in_RCX);
        if ((int32_t)uVar7 == 0) {
            return uVar7;
        }
    }
code_r0x000180250c84:
    iVar2 = *(int64_t *)(in_RCX + 0xf8);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
    *(int32_t *)(in_RCX + 0xb8) = 0x5f;
    if (iVar2 != 0) {
        uVar6 = *(undefined8 *)(iVar2 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250cae;
        iVar3 = fcn.180222010(uVar6);
        if (0 < iVar3) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250cba;
            uVar4 = fcn.18024fe60(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar5), *(int64_t *)(&stack0x00000058 + iVar5), 
                                  *(int64_t *)(&stack0x000000a0 + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                                  *(int64_t *)(&stack0x000000b0 + iVar5), *(int64_t *)(&stack0x000000e8 + iVar5), 
                                  *(int64_t *)(&stack0x000000f8 + iVar5));
            goto code_r0x000180250cf0;
        }
    }
    pcVar1 = *(code **)(in_RCX + 0x38);
    if (pcVar1 == (code *)0x0) {
        pcVar1 = *(code **)(in_RCX + 0x40);
        iVar3 = *(int32_t *)(in_RCX + 0xb8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250ce7;
        iVar3 = (*pcVar1)(iVar3 == 0, in_RCX);
        uVar4 = (uint32_t)(iVar3 != 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180250cd3;
        uVar4 = (*pcVar1)(in_RCX);
    }
code_r0x000180250cf0:
    if (((int32_t)uVar4 < 1) && (*(int32_t *)(in_RCX + 0xb8) == 0)) {
        *(int32_t *)(in_RCX + 0xb8) = 1;
    }
    return (uint64_t)uVar4;
}

// ============================================================
// Function: FUN_180250d20
// Address: 0x180250d20
// Size: 103 bytes
// ============================================================
undefined8 fcn.180250d20(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180250d2c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(in_RCX + 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d40;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d58;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d6a;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined4 *)(in_RCX + 0xb8) = 0x45;
        return 0xffffffff;
    }
    iVar4 = *(int64_t *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d93;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250dab;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250dbd;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined4 *)(in_RCX + 0xb8) = 0x45;
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250de9;
    iVar2 = fcn.1802385a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
    if (iVar2 == 0) {
        *(undefined4 *)(in_RCX + 0xb8) = 0x11;
        return 0xffffffff;
    }
    uVar5 = *(undefined8 *)(in_RCX + 8);
    *(undefined4 *)(in_RCX + 0x9c) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e1d;
    iVar2 = fcn.18024d7d0(in_RCX, uVar5);
    if (iVar2 == 0) {
        iVar4 = *(int64_t *)(in_RCX + 8);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (iVar4 == 0) {
            uVar5 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e42;
            iVar4 = fcn.180222340(uVar5, 0);
        }
        *(int64_t *)(in_RCX + 0xc0) = iVar4;
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x42;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e5e;
        uVar5 = (*pcVar1)(0, in_RCX);
        if ((int32_t)uVar5 == 0) {
            return uVar5;
        }
    }
    if (*(int64_t *)(in_RCX + 0xf8) != 0) {
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e82;
        iVar2 = fcn.180222010(uVar5);
        if (0 < iVar2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e8e;
            uVar5 = fcn.18024fcc0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
            goto code_r0x000180250e98;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e98;
    uVar5 = fcn.180250a80(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
code_r0x000180250e98:
    if (((int32_t)uVar5 < 1) && (*(int32_t *)(in_RCX + 0xb8) == 0)) {
        *(undefined4 *)(in_RCX + 0xb8) = 1;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180250d87
// Address: 0x180250d87
// Size: 80 bytes
// ============================================================
undefined8 fcn.180250d20(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180250d2c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(in_RCX + 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d40;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d58;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d6a;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined4 *)(in_RCX + 0xb8) = 0x45;
        return 0xffffffff;
    }
    iVar4 = *(int64_t *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d93;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250dab;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250dbd;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined4 *)(in_RCX + 0xb8) = 0x45;
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250de9;
    iVar2 = fcn.1802385a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
    if (iVar2 == 0) {
        *(undefined4 *)(in_RCX + 0xb8) = 0x11;
        return 0xffffffff;
    }
    uVar5 = *(undefined8 *)(in_RCX + 8);
    *(undefined4 *)(in_RCX + 0x9c) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e1d;
    iVar2 = fcn.18024d7d0(in_RCX, uVar5);
    if (iVar2 == 0) {
        iVar4 = *(int64_t *)(in_RCX + 8);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (iVar4 == 0) {
            uVar5 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e42;
            iVar4 = fcn.180222340(uVar5, 0);
        }
        *(int64_t *)(in_RCX + 0xc0) = iVar4;
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x42;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e5e;
        uVar5 = (*pcVar1)(0, in_RCX);
        if ((int32_t)uVar5 == 0) {
            return uVar5;
        }
    }
    if (*(int64_t *)(in_RCX + 0xf8) != 0) {
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e82;
        iVar2 = fcn.180222010(uVar5);
        if (0 < iVar2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e8e;
            uVar5 = fcn.18024fcc0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
            goto code_r0x000180250e98;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e98;
    uVar5 = fcn.180250a80(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
code_r0x000180250e98:
    if (((int32_t)uVar5 < 1) && (*(int32_t *)(in_RCX + 0xb8) == 0)) {
        *(undefined4 *)(in_RCX + 0xb8) = 1;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180250dd7
// Address: 0x180250dd7
// Size: 48 bytes
// ============================================================
undefined8 fcn.180250d20(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180250d2c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(in_RCX + 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d40;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d58;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d6a;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined4 *)(in_RCX + 0xb8) = 0x45;
        return 0xffffffff;
    }
    iVar4 = *(int64_t *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d93;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250dab;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250dbd;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined4 *)(in_RCX + 0xb8) = 0x45;
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250de9;
    iVar2 = fcn.1802385a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
    if (iVar2 == 0) {
        *(undefined4 *)(in_RCX + 0xb8) = 0x11;
        return 0xffffffff;
    }
    uVar5 = *(undefined8 *)(in_RCX + 8);
    *(undefined4 *)(in_RCX + 0x9c) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e1d;
    iVar2 = fcn.18024d7d0(in_RCX, uVar5);
    if (iVar2 == 0) {
        iVar4 = *(int64_t *)(in_RCX + 8);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (iVar4 == 0) {
            uVar5 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e42;
            iVar4 = fcn.180222340(uVar5, 0);
        }
        *(int64_t *)(in_RCX + 0xc0) = iVar4;
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x42;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e5e;
        uVar5 = (*pcVar1)(0, in_RCX);
        if ((int32_t)uVar5 == 0) {
            return uVar5;
        }
    }
    if (*(int64_t *)(in_RCX + 0xf8) != 0) {
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e82;
        iVar2 = fcn.180222010(uVar5);
        if (0 < iVar2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e8e;
            uVar5 = fcn.18024fcc0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
            goto code_r0x000180250e98;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e98;
    uVar5 = fcn.180250a80(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
code_r0x000180250e98:
    if (((int32_t)uVar5 < 1) && (*(int32_t *)(in_RCX + 0xb8) == 0)) {
        *(undefined4 *)(in_RCX + 0xb8) = 1;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180250e07
// Address: 0x180250e07
// Size: 102 bytes
// ============================================================
undefined8 fcn.180250d20(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180250d2c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(in_RCX + 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d40;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d58;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d6a;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined4 *)(in_RCX + 0xb8) = 0x45;
        return 0xffffffff;
    }
    iVar4 = *(int64_t *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d93;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250dab;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250dbd;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined4 *)(in_RCX + 0xb8) = 0x45;
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250de9;
    iVar2 = fcn.1802385a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
    if (iVar2 == 0) {
        *(undefined4 *)(in_RCX + 0xb8) = 0x11;
        return 0xffffffff;
    }
    uVar5 = *(undefined8 *)(in_RCX + 8);
    *(undefined4 *)(in_RCX + 0x9c) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e1d;
    iVar2 = fcn.18024d7d0(in_RCX, uVar5);
    if (iVar2 == 0) {
        iVar4 = *(int64_t *)(in_RCX + 8);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (iVar4 == 0) {
            uVar5 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e42;
            iVar4 = fcn.180222340(uVar5, 0);
        }
        *(int64_t *)(in_RCX + 0xc0) = iVar4;
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x42;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e5e;
        uVar5 = (*pcVar1)(0, in_RCX);
        if ((int32_t)uVar5 == 0) {
            return uVar5;
        }
    }
    if (*(int64_t *)(in_RCX + 0xf8) != 0) {
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e82;
        iVar2 = fcn.180222010(uVar5);
        if (0 < iVar2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e8e;
            uVar5 = fcn.18024fcc0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
            goto code_r0x000180250e98;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e98;
    uVar5 = fcn.180250a80(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
code_r0x000180250e98:
    if (((int32_t)uVar5 < 1) && (*(int32_t *)(in_RCX + 0xb8) == 0)) {
        *(undefined4 *)(in_RCX + 0xb8) = 1;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180250e6d
// Address: 0x180250e6d
// Size: 77 bytes
// ============================================================
undefined8 fcn.180250d20(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180250d2c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(in_RCX + 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d40;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d58;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d6a;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined4 *)(in_RCX + 0xb8) = 0x45;
        return 0xffffffff;
    }
    iVar4 = *(int64_t *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250d93;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250dab;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250dbd;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined4 *)(in_RCX + 0xb8) = 0x45;
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250de9;
    iVar2 = fcn.1802385a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
    if (iVar2 == 0) {
        *(undefined4 *)(in_RCX + 0xb8) = 0x11;
        return 0xffffffff;
    }
    uVar5 = *(undefined8 *)(in_RCX + 8);
    *(undefined4 *)(in_RCX + 0x9c) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e1d;
    iVar2 = fcn.18024d7d0(in_RCX, uVar5);
    if (iVar2 == 0) {
        iVar4 = *(int64_t *)(in_RCX + 8);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        if (iVar4 == 0) {
            uVar5 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e42;
            iVar4 = fcn.180222340(uVar5, 0);
        }
        *(int64_t *)(in_RCX + 0xc0) = iVar4;
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x42;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e5e;
        uVar5 = (*pcVar1)(0, in_RCX);
        if ((int32_t)uVar5 == 0) {
            return uVar5;
        }
    }
    if (*(int64_t *)(in_RCX + 0xf8) != 0) {
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e82;
        iVar2 = fcn.180222010(uVar5);
        if (0 < iVar2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e8e;
            uVar5 = fcn.18024fcc0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
            goto code_r0x000180250e98;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180250e98;
    uVar5 = fcn.180250a80(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
code_r0x000180250e98:
    if (((int32_t)uVar5 < 1) && (*(int32_t *)(in_RCX + 0xb8) == 0)) {
        *(undefined4 *)(in_RCX + 0xb8) = 1;
    }
    return uVar5;
}

