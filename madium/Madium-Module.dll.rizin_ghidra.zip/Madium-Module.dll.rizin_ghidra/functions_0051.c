// Chunk 51 - 50 functions

// ============================================================
// Function: FUN_1800a217b
// Address: 0x1800a217b
// Size: 102 bytes
// ============================================================
undefined8
fcn.1800a217b(undefined8 placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
             int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
             undefined8 placeholder_9, undefined8 placeholder_10, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h)
{
    int64_t in_RAX;
    int64_t iVar1;
    int32_t in_R11D;
    int64_t var_20h;
    
    while ((in_R11D == -2 || ((in_RAX != arg2 && (iVar1 = func_0x0001800a0d50(), *(int32_t *)(iVar1 + 0xc) != 0))))) {
        in_R11D = in_R11D + 1;
    }
    func_0x0001800a0410();
    func_0x0001800a1c40();
    func_0x000180085bf0();
    return 1;
}

// ============================================================
// Function: FUN_1800a21e1
// Address: 0x1800a21e1
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_70h
// WARNING: Variable defined which should be unmapped: arg_48h

undefined8
fcn.1800a217b(undefined8 placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
             int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
             undefined8 placeholder_9, undefined8 placeholder_10, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h)
{
    int64_t in_RAX;
    int64_t iVar1;
    int32_t in_R11D;
    int64_t var_20h;
    
    while ((in_R11D == -2 || ((in_RAX != arg2 && (iVar1 = func_0x0001800a0d50(), *(int32_t *)(iVar1 + 0xc) != 0))))) {
        in_R11D = in_R11D + 1;
    }
    func_0x0001800a0410();
    func_0x0001800a1c40();
    func_0x000180085bf0();
    return 1;
}

// ============================================================
// Function: FUN_1800a2227
// Address: 0x1800a2227
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_70h
// WARNING: Variable defined which should be unmapped: arg_48h

undefined8
fcn.1800a217b(undefined8 placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
             int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
             undefined8 placeholder_9, undefined8 placeholder_10, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h)
{
    int64_t in_RAX;
    int64_t iVar1;
    int32_t in_R11D;
    int64_t var_20h;
    
    while ((in_R11D == -2 || ((in_RAX != arg2 && (iVar1 = func_0x0001800a0d50(), *(int32_t *)(iVar1 + 0xc) != 0))))) {
        in_R11D = in_R11D + 1;
    }
    func_0x0001800a0410();
    func_0x0001800a1c40();
    func_0x000180085bf0();
    return 1;
}

// ============================================================
// Function: FUN_1800a2233
// Address: 0x1800a2233
// Size: 20 bytes
// ============================================================
void fcn.1800a2233(void)
{
    code *pcVar1;
    
    fcn.180088470();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800a2247
// Address: 0x1800a2247
// Size: 51 bytes
// ============================================================
void fcn.1800a2247(void)
{
    code *pcVar1;
    
    fcn.180088380();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800a2280
// Address: 0x1800a2280
// Size: 274 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800a2280(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_288 [32];
    int64_t var_268h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_288;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar9 = *(int64_t **)(arg1 + 0x40);
    piVar11 = piVar10 + 2;
    piVar14 = piVar11;
    if (piVar9 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) < 1)) {
        uVar12 = 0;
        var_268h = 0x1805aadb1;
    } else {
        if (piVar9 <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar5 = func_0x0001800a8360(arg1);
            if (iVar5 == 0) goto code_r0x0001800a26fd;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar9 = *(int64_t **)(arg1 + 0x40);
            piVar11 = piVar10 + 2;
            if (piVar9 <= piVar10 + 2) {
                piVar11 = *(int64_t **)0x180782430;
            }
        }
        var_268h = *piVar11 + 0x18;
        if (var_268h == 0) {
code_r0x0001800a26fd:
            fcn.180088470(arg1, 2, 6);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar12 = (uint64_t)*(uint32_t *)(*piVar11 + 0x14);
    }
    piVar11 = piVar10;
    if (piVar9 <= piVar10) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    piVar11 = piVar10 + 4;
    if (piVar9 <= piVar10 + 4) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + 0xc) < 1)) {
        iVar5 = 1;
    } else {
        iVar5 = func_0x000180088860(arg1, 3);
    }
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar10 = piVar11 + 6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11 + 6) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) < 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        iVar6 = *(int32_t *)((int64_t)piVar11 + 0xc);
        if (iVar6 == 6) {
            iVar6 = *(int32_t *)(*piVar11 + 0x14);
        } else if (iVar6 == 7) {
            iVar6 = func_0x0001800a1110(*piVar11);
        } else if ((iVar6 == 9) || (iVar6 == 0xb)) {
            iVar6 = *(int32_t *)(*piVar11 + 4);
        } else {
            iVar6 = 0;
        }
    } else {
        iVar6 = func_0x000180088860(arg1, 4);
    }
    var_258h = (int64_t)&var_238h;
    var_250h = (int64_t)&var_38h;
    iVar1 = **(int64_t **)(arg1 + 0x28);
    var_240h = 0;
    var_248h = arg1;
    for (; iVar5 < iVar6; iVar5 = iVar5 + 1) {
        if ((iVar1 == 0) || (*(uint32_t *)(iVar1 + 8) <= iVar5 - 1U)) {
code_r0x0001800a24f4:
            iVar7 = func_0x000180086ed0(arg1, 1, iVar5);
            if ((iVar7 != 6) && (iVar7 != 3)) {
                uVar8 = func_0x000180088fa0(arg1, 0xffffffff);
                fcn.180088560(arg1, 0x18063eaf8, uVar8, iVar5);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            func_0x0001800891f0(&var_258h);
        } else {
            if (*(int32_t *)(*(int64_t *)(iVar1 + 0x20) + -4 + (int64_t)iVar5 * 0x10) != 6) goto code_r0x0001800a24f4;
            iVar2 = *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + -0x10 + (int64_t)iVar5 * 0x10);
            uVar13 = (uint64_t)*(uint32_t *)(iVar2 + 0x14);
            if ((uint64_t)(var_250h - var_258h) < uVar13) {
                func_0x0001800890e0(&var_258h, (uVar13 - var_250h) + var_258h, 0xffffffff);
            }
            func_0x000180498030(var_258h, iVar2 + 0x18, uVar13);
            var_258h = var_258h + uVar13;
        }
        if (uVar12 != 0) {
            if ((uint64_t)(var_250h - var_258h) < uVar12) {
                func_0x0001800890e0(&var_258h, uVar12 + (var_258h - var_250h), 0xffffffff);
            }
            func_0x000180498030(var_258h, var_268h, uVar12);
            var_258h = var_258h + uVar12;
        }
    }
    if (iVar5 == iVar6) {
        if ((iVar1 != 0) && (iVar5 - 1U < *(uint32_t *)(iVar1 + 8))) {
            if (*(int32_t *)(*(int64_t *)(iVar1 + 0x20) + -4 + (int64_t)iVar5 * 0x10) == 6) {
                iVar1 = *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + -0x10 + (int64_t)iVar5 * 0x10);
                uVar12 = (uint64_t)*(uint32_t *)(iVar1 + 0x14);
                if ((uint64_t)(var_250h - var_258h) < uVar12) {
                    func_0x0001800890e0(&var_258h, (uVar12 - var_250h) + var_258h, 0xffffffff);
                }
                func_0x000180498030(var_258h, iVar1 + 0x18, uVar12);
                var_258h = var_258h + uVar12;
                goto code_r0x0001800a2620;
            }
        }
        iVar6 = func_0x000180086ed0(arg1, 1, iVar5);
        if ((iVar6 != 6) && (iVar6 != 3)) {
            uVar8 = func_0x000180088fa0(arg1, 0xffffffff);
            fcn.180088560(arg1, 0x18063eaf8, uVar8, iVar5);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        func_0x0001800891f0(&var_258h);
    }
code_r0x0001800a2620:
    iVar2 = var_240h;
    iVar1 = var_248h;
    if (var_240h == 0) {
        func_0x0001800867f0(var_248h, &var_238h, (var_258h - (int64_t)&var_258h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_248h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_248h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_248h, 1);
        }
        iVar3 = *(int64_t *)(iVar1 + 0x40);
        if (var_258h == var_250h) {
            uVar8 = func_0x00018009a7e0(iVar1, iVar2);
            *(undefined8 *)(iVar3 + -0x10) = uVar8;
            *(undefined4 *)(iVar3 + -4) = 6;
        } else {
            uVar8 = func_0x00018009a8e0(iVar1, iVar2 + 0x18, (var_258h - iVar2) + -0x18);
            *(undefined8 *)(iVar3 + -0x10) = uVar8;
            *(undefined4 *)(iVar3 + -4) = 6;
        }
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStack_288);
    return;
}

// ============================================================
// Function: FUN_1800a2392
// Address: 0x1800a2392
// Size: 855 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800a2280(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_288 [32];
    int64_t var_268h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_288;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar9 = *(int64_t **)(arg1 + 0x40);
    piVar11 = piVar10 + 2;
    piVar14 = piVar11;
    if (piVar9 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) < 1)) {
        uVar12 = 0;
        var_268h = 0x1805aadb1;
    } else {
        if (piVar9 <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar5 = func_0x0001800a8360(arg1);
            if (iVar5 == 0) goto code_r0x0001800a26fd;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar9 = *(int64_t **)(arg1 + 0x40);
            piVar11 = piVar10 + 2;
            if (piVar9 <= piVar10 + 2) {
                piVar11 = *(int64_t **)0x180782430;
            }
        }
        var_268h = *piVar11 + 0x18;
        if (var_268h == 0) {
code_r0x0001800a26fd:
            fcn.180088470(arg1, 2, 6);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar12 = (uint64_t)*(uint32_t *)(*piVar11 + 0x14);
    }
    piVar11 = piVar10;
    if (piVar9 <= piVar10) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    piVar11 = piVar10 + 4;
    if (piVar9 <= piVar10 + 4) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + 0xc) < 1)) {
        iVar5 = 1;
    } else {
        iVar5 = func_0x000180088860(arg1, 3);
    }
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar10 = piVar11 + 6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11 + 6) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) < 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        iVar6 = *(int32_t *)((int64_t)piVar11 + 0xc);
        if (iVar6 == 6) {
            iVar6 = *(int32_t *)(*piVar11 + 0x14);
        } else if (iVar6 == 7) {
            iVar6 = func_0x0001800a1110(*piVar11);
        } else if ((iVar6 == 9) || (iVar6 == 0xb)) {
            iVar6 = *(int32_t *)(*piVar11 + 4);
        } else {
            iVar6 = 0;
        }
    } else {
        iVar6 = func_0x000180088860(arg1, 4);
    }
    var_258h = (int64_t)&var_238h;
    var_250h = (int64_t)&var_38h;
    iVar1 = **(int64_t **)(arg1 + 0x28);
    var_240h = 0;
    var_248h = arg1;
    for (; iVar5 < iVar6; iVar5 = iVar5 + 1) {
        if ((iVar1 == 0) || (*(uint32_t *)(iVar1 + 8) <= iVar5 - 1U)) {
code_r0x0001800a24f4:
            iVar7 = func_0x000180086ed0(arg1, 1, iVar5);
            if ((iVar7 != 6) && (iVar7 != 3)) {
                uVar8 = func_0x000180088fa0(arg1, 0xffffffff);
                fcn.180088560(arg1, 0x18063eaf8, uVar8, iVar5);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            func_0x0001800891f0(&var_258h);
        } else {
            if (*(int32_t *)(*(int64_t *)(iVar1 + 0x20) + -4 + (int64_t)iVar5 * 0x10) != 6) goto code_r0x0001800a24f4;
            iVar2 = *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + -0x10 + (int64_t)iVar5 * 0x10);
            uVar13 = (uint64_t)*(uint32_t *)(iVar2 + 0x14);
            if ((uint64_t)(var_250h - var_258h) < uVar13) {
                func_0x0001800890e0(&var_258h, (uVar13 - var_250h) + var_258h, 0xffffffff);
            }
            func_0x000180498030(var_258h, iVar2 + 0x18, uVar13);
            var_258h = var_258h + uVar13;
        }
        if (uVar12 != 0) {
            if ((uint64_t)(var_250h - var_258h) < uVar12) {
                func_0x0001800890e0(&var_258h, uVar12 + (var_258h - var_250h), 0xffffffff);
            }
            func_0x000180498030(var_258h, var_268h, uVar12);
            var_258h = var_258h + uVar12;
        }
    }
    if (iVar5 == iVar6) {
        if ((iVar1 != 0) && (iVar5 - 1U < *(uint32_t *)(iVar1 + 8))) {
            if (*(int32_t *)(*(int64_t *)(iVar1 + 0x20) + -4 + (int64_t)iVar5 * 0x10) == 6) {
                iVar1 = *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + -0x10 + (int64_t)iVar5 * 0x10);
                uVar12 = (uint64_t)*(uint32_t *)(iVar1 + 0x14);
                if ((uint64_t)(var_250h - var_258h) < uVar12) {
                    func_0x0001800890e0(&var_258h, (uVar12 - var_250h) + var_258h, 0xffffffff);
                }
                func_0x000180498030(var_258h, iVar1 + 0x18, uVar12);
                var_258h = var_258h + uVar12;
                goto code_r0x0001800a2620;
            }
        }
        iVar6 = func_0x000180086ed0(arg1, 1, iVar5);
        if ((iVar6 != 6) && (iVar6 != 3)) {
            uVar8 = func_0x000180088fa0(arg1, 0xffffffff);
            fcn.180088560(arg1, 0x18063eaf8, uVar8, iVar5);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        func_0x0001800891f0(&var_258h);
    }
code_r0x0001800a2620:
    iVar2 = var_240h;
    iVar1 = var_248h;
    if (var_240h == 0) {
        func_0x0001800867f0(var_248h, &var_238h, (var_258h - (int64_t)&var_258h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_248h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_248h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_248h, 1);
        }
        iVar3 = *(int64_t *)(iVar1 + 0x40);
        if (var_258h == var_250h) {
            uVar8 = func_0x00018009a7e0(iVar1, iVar2);
            *(undefined8 *)(iVar3 + -0x10) = uVar8;
            *(undefined4 *)(iVar3 + -4) = 6;
        } else {
            uVar8 = func_0x00018009a8e0(iVar1, iVar2 + 0x18, (var_258h - iVar2) + -0x18);
            *(undefined8 *)(iVar3 + -0x10) = uVar8;
            *(undefined4 *)(iVar3 + -4) = 6;
        }
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStack_288);
    return;
}

// ============================================================
// Function: FUN_1800a26e9
// Address: 0x1800a26e9
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800a2280(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_288 [32];
    int64_t var_268h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_288;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar9 = *(int64_t **)(arg1 + 0x40);
    piVar11 = piVar10 + 2;
    piVar14 = piVar11;
    if (piVar9 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) < 1)) {
        uVar12 = 0;
        var_268h = 0x1805aadb1;
    } else {
        if (piVar9 <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar5 = func_0x0001800a8360(arg1);
            if (iVar5 == 0) goto code_r0x0001800a26fd;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar9 = *(int64_t **)(arg1 + 0x40);
            piVar11 = piVar10 + 2;
            if (piVar9 <= piVar10 + 2) {
                piVar11 = *(int64_t **)0x180782430;
            }
        }
        var_268h = *piVar11 + 0x18;
        if (var_268h == 0) {
code_r0x0001800a26fd:
            fcn.180088470(arg1, 2, 6);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar12 = (uint64_t)*(uint32_t *)(*piVar11 + 0x14);
    }
    piVar11 = piVar10;
    if (piVar9 <= piVar10) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    piVar11 = piVar10 + 4;
    if (piVar9 <= piVar10 + 4) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + 0xc) < 1)) {
        iVar5 = 1;
    } else {
        iVar5 = func_0x000180088860(arg1, 3);
    }
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar10 = piVar11 + 6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11 + 6) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) < 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        iVar6 = *(int32_t *)((int64_t)piVar11 + 0xc);
        if (iVar6 == 6) {
            iVar6 = *(int32_t *)(*piVar11 + 0x14);
        } else if (iVar6 == 7) {
            iVar6 = func_0x0001800a1110(*piVar11);
        } else if ((iVar6 == 9) || (iVar6 == 0xb)) {
            iVar6 = *(int32_t *)(*piVar11 + 4);
        } else {
            iVar6 = 0;
        }
    } else {
        iVar6 = func_0x000180088860(arg1, 4);
    }
    var_258h = (int64_t)&var_238h;
    var_250h = (int64_t)&var_38h;
    iVar1 = **(int64_t **)(arg1 + 0x28);
    var_240h = 0;
    var_248h = arg1;
    for (; iVar5 < iVar6; iVar5 = iVar5 + 1) {
        if ((iVar1 == 0) || (*(uint32_t *)(iVar1 + 8) <= iVar5 - 1U)) {
code_r0x0001800a24f4:
            iVar7 = func_0x000180086ed0(arg1, 1, iVar5);
            if ((iVar7 != 6) && (iVar7 != 3)) {
                uVar8 = func_0x000180088fa0(arg1, 0xffffffff);
                fcn.180088560(arg1, 0x18063eaf8, uVar8, iVar5);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            func_0x0001800891f0(&var_258h);
        } else {
            if (*(int32_t *)(*(int64_t *)(iVar1 + 0x20) + -4 + (int64_t)iVar5 * 0x10) != 6) goto code_r0x0001800a24f4;
            iVar2 = *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + -0x10 + (int64_t)iVar5 * 0x10);
            uVar13 = (uint64_t)*(uint32_t *)(iVar2 + 0x14);
            if ((uint64_t)(var_250h - var_258h) < uVar13) {
                func_0x0001800890e0(&var_258h, (uVar13 - var_250h) + var_258h, 0xffffffff);
            }
            func_0x000180498030(var_258h, iVar2 + 0x18, uVar13);
            var_258h = var_258h + uVar13;
        }
        if (uVar12 != 0) {
            if ((uint64_t)(var_250h - var_258h) < uVar12) {
                func_0x0001800890e0(&var_258h, uVar12 + (var_258h - var_250h), 0xffffffff);
            }
            func_0x000180498030(var_258h, var_268h, uVar12);
            var_258h = var_258h + uVar12;
        }
    }
    if (iVar5 == iVar6) {
        if ((iVar1 != 0) && (iVar5 - 1U < *(uint32_t *)(iVar1 + 8))) {
            if (*(int32_t *)(*(int64_t *)(iVar1 + 0x20) + -4 + (int64_t)iVar5 * 0x10) == 6) {
                iVar1 = *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + -0x10 + (int64_t)iVar5 * 0x10);
                uVar12 = (uint64_t)*(uint32_t *)(iVar1 + 0x14);
                if ((uint64_t)(var_250h - var_258h) < uVar12) {
                    func_0x0001800890e0(&var_258h, (uVar12 - var_250h) + var_258h, 0xffffffff);
                }
                func_0x000180498030(var_258h, iVar1 + 0x18, uVar12);
                var_258h = var_258h + uVar12;
                goto code_r0x0001800a2620;
            }
        }
        iVar6 = func_0x000180086ed0(arg1, 1, iVar5);
        if ((iVar6 != 6) && (iVar6 != 3)) {
            uVar8 = func_0x000180088fa0(arg1, 0xffffffff);
            fcn.180088560(arg1, 0x18063eaf8, uVar8, iVar5);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        func_0x0001800891f0(&var_258h);
    }
code_r0x0001800a2620:
    iVar2 = var_240h;
    iVar1 = var_248h;
    if (var_240h == 0) {
        func_0x0001800867f0(var_248h, &var_238h, (var_258h - (int64_t)&var_258h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_248h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_248h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_248h, 1);
        }
        iVar3 = *(int64_t *)(iVar1 + 0x40);
        if (var_258h == var_250h) {
            uVar8 = func_0x00018009a7e0(iVar1, iVar2);
            *(undefined8 *)(iVar3 + -0x10) = uVar8;
            *(undefined4 *)(iVar3 + -4) = 6;
        } else {
            uVar8 = func_0x00018009a8e0(iVar1, iVar2 + 0x18, (var_258h - iVar2) + -0x18);
            *(undefined8 *)(iVar3 + -0x10) = uVar8;
            *(undefined4 *)(iVar3 + -4) = 6;
        }
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStack_288);
    return;
}

// ============================================================
// Function: FUN_1800a2711
// Address: 0x1800a2711
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800a2280(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_288 [32];
    int64_t var_268h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_288;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar9 = *(int64_t **)(arg1 + 0x40);
    piVar11 = piVar10 + 2;
    piVar14 = piVar11;
    if (piVar9 <= piVar11) {
        piVar14 = *(int64_t **)0x180782430;
    }
    if ((piVar14 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar14 + 0xc) < 1)) {
        uVar12 = 0;
        var_268h = 0x1805aadb1;
    } else {
        if (piVar9 <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar5 = func_0x0001800a8360(arg1);
            if (iVar5 == 0) goto code_r0x0001800a26fd;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar10 = *(int64_t **)(arg1 + 0x28);
            piVar9 = *(int64_t **)(arg1 + 0x40);
            piVar11 = piVar10 + 2;
            if (piVar9 <= piVar10 + 2) {
                piVar11 = *(int64_t **)0x180782430;
            }
        }
        var_268h = *piVar11 + 0x18;
        if (var_268h == 0) {
code_r0x0001800a26fd:
            fcn.180088470(arg1, 2, 6);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar12 = (uint64_t)*(uint32_t *)(*piVar11 + 0x14);
    }
    piVar11 = piVar10;
    if (piVar9 <= piVar10) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    piVar11 = piVar10 + 4;
    if (piVar9 <= piVar10 + 4) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + 0xc) < 1)) {
        iVar5 = 1;
    } else {
        iVar5 = func_0x000180088860(arg1, 3);
    }
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar10 = piVar11 + 6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar11 + 6) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) < 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        iVar6 = *(int32_t *)((int64_t)piVar11 + 0xc);
        if (iVar6 == 6) {
            iVar6 = *(int32_t *)(*piVar11 + 0x14);
        } else if (iVar6 == 7) {
            iVar6 = func_0x0001800a1110(*piVar11);
        } else if ((iVar6 == 9) || (iVar6 == 0xb)) {
            iVar6 = *(int32_t *)(*piVar11 + 4);
        } else {
            iVar6 = 0;
        }
    } else {
        iVar6 = func_0x000180088860(arg1, 4);
    }
    var_258h = (int64_t)&var_238h;
    var_250h = (int64_t)&var_38h;
    iVar1 = **(int64_t **)(arg1 + 0x28);
    var_240h = 0;
    var_248h = arg1;
    for (; iVar5 < iVar6; iVar5 = iVar5 + 1) {
        if ((iVar1 == 0) || (*(uint32_t *)(iVar1 + 8) <= iVar5 - 1U)) {
code_r0x0001800a24f4:
            iVar7 = func_0x000180086ed0(arg1, 1, iVar5);
            if ((iVar7 != 6) && (iVar7 != 3)) {
                uVar8 = func_0x000180088fa0(arg1, 0xffffffff);
                fcn.180088560(arg1, 0x18063eaf8, uVar8, iVar5);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            func_0x0001800891f0(&var_258h);
        } else {
            if (*(int32_t *)(*(int64_t *)(iVar1 + 0x20) + -4 + (int64_t)iVar5 * 0x10) != 6) goto code_r0x0001800a24f4;
            iVar2 = *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + -0x10 + (int64_t)iVar5 * 0x10);
            uVar13 = (uint64_t)*(uint32_t *)(iVar2 + 0x14);
            if ((uint64_t)(var_250h - var_258h) < uVar13) {
                func_0x0001800890e0(&var_258h, (uVar13 - var_250h) + var_258h, 0xffffffff);
            }
            func_0x000180498030(var_258h, iVar2 + 0x18, uVar13);
            var_258h = var_258h + uVar13;
        }
        if (uVar12 != 0) {
            if ((uint64_t)(var_250h - var_258h) < uVar12) {
                func_0x0001800890e0(&var_258h, uVar12 + (var_258h - var_250h), 0xffffffff);
            }
            func_0x000180498030(var_258h, var_268h, uVar12);
            var_258h = var_258h + uVar12;
        }
    }
    if (iVar5 == iVar6) {
        if ((iVar1 != 0) && (iVar5 - 1U < *(uint32_t *)(iVar1 + 8))) {
            if (*(int32_t *)(*(int64_t *)(iVar1 + 0x20) + -4 + (int64_t)iVar5 * 0x10) == 6) {
                iVar1 = *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + -0x10 + (int64_t)iVar5 * 0x10);
                uVar12 = (uint64_t)*(uint32_t *)(iVar1 + 0x14);
                if ((uint64_t)(var_250h - var_258h) < uVar12) {
                    func_0x0001800890e0(&var_258h, (uVar12 - var_250h) + var_258h, 0xffffffff);
                }
                func_0x000180498030(var_258h, iVar1 + 0x18, uVar12);
                var_258h = var_258h + uVar12;
                goto code_r0x0001800a2620;
            }
        }
        iVar6 = func_0x000180086ed0(arg1, 1, iVar5);
        if ((iVar6 != 6) && (iVar6 != 3)) {
            uVar8 = func_0x000180088fa0(arg1, 0xffffffff);
            fcn.180088560(arg1, 0x18063eaf8, uVar8, iVar5);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        func_0x0001800891f0(&var_258h);
    }
code_r0x0001800a2620:
    iVar2 = var_240h;
    iVar1 = var_248h;
    if (var_240h == 0) {
        func_0x0001800867f0(var_248h, &var_238h, (var_258h - (int64_t)&var_258h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_248h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_248h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_248h, 1);
        }
        iVar3 = *(int64_t *)(iVar1 + 0x40);
        if (var_258h == var_250h) {
            uVar8 = func_0x00018009a7e0(iVar1, iVar2);
            *(undefined8 *)(iVar3 + -0x10) = uVar8;
            *(undefined4 *)(iVar3 + -4) = 6;
        } else {
            uVar8 = func_0x00018009a8e0(iVar1, iVar2 + 0x18, (var_258h - iVar2) + -0x18);
            *(undefined8 *)(iVar3 + -0x10) = uVar8;
            *(undefined4 *)(iVar3 + -4) = 6;
        }
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStack_288);
    return;
}

// ============================================================
// Function: FUN_1800a2760
// Address: 0x1800a2760
// Size: 233 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.1800a2760(int64_t arg1, int64_t arg_28h)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    double *pdVar8;
    int32_t iVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    bool bVar12;
    undefined auStack_68 [32];
    int64_t var_48h;
    undefined4 var_3ch;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    uVar10 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    iVar9 = (int32_t)uVar10;
    func_0x000180086fd0(arg1, uVar10 & 0xffffffff);
    uVar10 = 0;
    iVar3 = *(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if (0 < iVar9) {
        do {
            uVar11 = (int32_t)uVar10 + 1;
            puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + uVar10 * 0x10);
            uVar4 = puVar1[1];
            uVar5 = puVar1[2];
            uVar6 = puVar1[3];
            puVar2 = (undefined4 *)(*(int64_t *)(iVar3 + 0x20) + uVar10 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
            uVar10 = (uint64_t)uVar11;
        } while ((int32_t)uVar11 < iVar9);
    }
    iVar7 = func_0x00018009a8e0(arg1, 0x18063eaf0, 1);
    pdVar8 = (double *)fcn.1800a0e30(iVar3, iVar7);
    bVar12 = pdVar8 == *(double **)0x180782430;
    *(undefined *)(iVar3 + 5) = 0;
    if (bVar12) {
        var_3ch = 6;
        var_48h = iVar7;
        pdVar8 = (double *)func_0x0001800a0a80(arg1, iVar3, &var_48h);
    }
    *(undefined4 *)((int64_t)pdVar8 + 0xc) = 3;
    *pdVar8 = (double)iVar9;
    func_0x000180459870(var_38h ^ (uint64_t)auStack_68);
    return;
}

// ============================================================
// Function: FUN_1800a2850
// Address: 0x1800a2850
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800a2850(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar12 = piVar13;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    iVar3 = *piVar13;
    piVar12 = piVar13 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13 + 2) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
        iVar8 = 1;
    } else {
        iVar8 = func_0x000180088860(arg1, 2);
    }
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar12 = piVar13 + 4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13 + 4) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
        iVar9 = *(int32_t *)((int64_t)piVar13 + 0xc);
        if (iVar9 == 6) {
            iVar9 = *(int32_t *)(*piVar13 + 0x14);
        } else if (iVar9 == 7) {
            iVar9 = func_0x0001800a1110(*piVar13);
        } else if ((iVar9 == 9) || (iVar9 == 0xb)) {
            iVar9 = *(int32_t *)(*piVar13 + 4);
        } else {
            iVar9 = 0;
        }
    } else {
        iVar9 = func_0x000180088860(arg1, 3);
    }
    if (iVar8 <= iVar9) {
        if ((uint32_t)(iVar9 - iVar8) < 0x7fffffff) {
            uVar14 = (iVar9 - iVar8) + 1;
            iVar10 = func_0x000180085510(arg1, uVar14);
            if (iVar10 != 0) {
                if ((iVar8 == 1) && ((int32_t)uVar14 <= *(int32_t *)(iVar3 + 8))) {
                    uVar11 = 0;
                    if (0 < (int32_t)uVar14) {
                        do {
                            uVar15 = (int32_t)uVar11 + 1;
                            puVar1 = (undefined4 *)(*(int64_t *)(iVar3 + 0x20) + uVar11 * 0x10);
                            uVar5 = puVar1[1];
                            uVar6 = puVar1[2];
                            uVar7 = puVar1[3];
                            puVar2 = (undefined4 *)(*(int64_t *)(arg1 + 0x40) + uVar11 * 0x10);
                            *puVar2 = *puVar1;
                            puVar2[1] = uVar5;
                            puVar2[2] = uVar6;
                            puVar2[3] = uVar7;
                            uVar11 = (uint64_t)uVar15;
                        } while ((int32_t)uVar15 < (int32_t)uVar14);
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + (uint64_t)uVar14 * 0x10;
                } else {
                    for (; iVar8 < iVar9; iVar8 = iVar8 + 1) {
                        func_0x000180086ed0(arg1, 1, iVar8);
                    }
                    func_0x000180086ed0(arg1, 1, iVar9);
                }
                return (uint64_t)uVar14;
            }
        }
        fcn.180088560(arg1, 0x18063ebc8);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a2889
// Address: 0x1800a2889
// Size: 183 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800a2850(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar12 = piVar13;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    iVar3 = *piVar13;
    piVar12 = piVar13 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13 + 2) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
        iVar8 = 1;
    } else {
        iVar8 = func_0x000180088860(arg1, 2);
    }
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar12 = piVar13 + 4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13 + 4) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
        iVar9 = *(int32_t *)((int64_t)piVar13 + 0xc);
        if (iVar9 == 6) {
            iVar9 = *(int32_t *)(*piVar13 + 0x14);
        } else if (iVar9 == 7) {
            iVar9 = func_0x0001800a1110(*piVar13);
        } else if ((iVar9 == 9) || (iVar9 == 0xb)) {
            iVar9 = *(int32_t *)(*piVar13 + 4);
        } else {
            iVar9 = 0;
        }
    } else {
        iVar9 = func_0x000180088860(arg1, 3);
    }
    if (iVar8 <= iVar9) {
        if ((uint32_t)(iVar9 - iVar8) < 0x7fffffff) {
            uVar14 = (iVar9 - iVar8) + 1;
            iVar10 = func_0x000180085510(arg1, uVar14);
            if (iVar10 != 0) {
                if ((iVar8 == 1) && ((int32_t)uVar14 <= *(int32_t *)(iVar3 + 8))) {
                    uVar11 = 0;
                    if (0 < (int32_t)uVar14) {
                        do {
                            uVar15 = (int32_t)uVar11 + 1;
                            puVar1 = (undefined4 *)(*(int64_t *)(iVar3 + 0x20) + uVar11 * 0x10);
                            uVar5 = puVar1[1];
                            uVar6 = puVar1[2];
                            uVar7 = puVar1[3];
                            puVar2 = (undefined4 *)(*(int64_t *)(arg1 + 0x40) + uVar11 * 0x10);
                            *puVar2 = *puVar1;
                            puVar2[1] = uVar5;
                            puVar2[2] = uVar6;
                            puVar2[3] = uVar7;
                            uVar11 = (uint64_t)uVar15;
                        } while ((int32_t)uVar15 < (int32_t)uVar14);
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + (uint64_t)uVar14 * 0x10;
                } else {
                    for (; iVar8 < iVar9; iVar8 = iVar8 + 1) {
                        func_0x000180086ed0(arg1, 1, iVar8);
                    }
                    func_0x000180086ed0(arg1, 1, iVar9);
                }
                return (uint64_t)uVar14;
            }
        }
        fcn.180088560(arg1, 0x18063ebc8);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a2940
// Address: 0x1800a2940
// Size: 157 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800a2850(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar12 = piVar13;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    iVar3 = *piVar13;
    piVar12 = piVar13 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13 + 2) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
        iVar8 = 1;
    } else {
        iVar8 = func_0x000180088860(arg1, 2);
    }
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar12 = piVar13 + 4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13 + 4) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
        iVar9 = *(int32_t *)((int64_t)piVar13 + 0xc);
        if (iVar9 == 6) {
            iVar9 = *(int32_t *)(*piVar13 + 0x14);
        } else if (iVar9 == 7) {
            iVar9 = func_0x0001800a1110(*piVar13);
        } else if ((iVar9 == 9) || (iVar9 == 0xb)) {
            iVar9 = *(int32_t *)(*piVar13 + 4);
        } else {
            iVar9 = 0;
        }
    } else {
        iVar9 = func_0x000180088860(arg1, 3);
    }
    if (iVar8 <= iVar9) {
        if ((uint32_t)(iVar9 - iVar8) < 0x7fffffff) {
            uVar14 = (iVar9 - iVar8) + 1;
            iVar10 = func_0x000180085510(arg1, uVar14);
            if (iVar10 != 0) {
                if ((iVar8 == 1) && ((int32_t)uVar14 <= *(int32_t *)(iVar3 + 8))) {
                    uVar11 = 0;
                    if (0 < (int32_t)uVar14) {
                        do {
                            uVar15 = (int32_t)uVar11 + 1;
                            puVar1 = (undefined4 *)(*(int64_t *)(iVar3 + 0x20) + uVar11 * 0x10);
                            uVar5 = puVar1[1];
                            uVar6 = puVar1[2];
                            uVar7 = puVar1[3];
                            puVar2 = (undefined4 *)(*(int64_t *)(arg1 + 0x40) + uVar11 * 0x10);
                            *puVar2 = *puVar1;
                            puVar2[1] = uVar5;
                            puVar2[2] = uVar6;
                            puVar2[3] = uVar7;
                            uVar11 = (uint64_t)uVar15;
                        } while ((int32_t)uVar15 < (int32_t)uVar14);
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + (uint64_t)uVar14 * 0x10;
                } else {
                    for (; iVar8 < iVar9; iVar8 = iVar8 + 1) {
                        func_0x000180086ed0(arg1, 1, iVar8);
                    }
                    func_0x000180086ed0(arg1, 1, iVar9);
                }
                return (uint64_t)uVar14;
            }
        }
        fcn.180088560(arg1, 0x18063ebc8);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a29dd
// Address: 0x1800a29dd
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800a2850(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar12 = piVar13;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    iVar3 = *piVar13;
    piVar12 = piVar13 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13 + 2) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
        iVar8 = 1;
    } else {
        iVar8 = func_0x000180088860(arg1, 2);
    }
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar12 = piVar13 + 4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13 + 4) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
        iVar9 = *(int32_t *)((int64_t)piVar13 + 0xc);
        if (iVar9 == 6) {
            iVar9 = *(int32_t *)(*piVar13 + 0x14);
        } else if (iVar9 == 7) {
            iVar9 = func_0x0001800a1110(*piVar13);
        } else if ((iVar9 == 9) || (iVar9 == 0xb)) {
            iVar9 = *(int32_t *)(*piVar13 + 4);
        } else {
            iVar9 = 0;
        }
    } else {
        iVar9 = func_0x000180088860(arg1, 3);
    }
    if (iVar8 <= iVar9) {
        if ((uint32_t)(iVar9 - iVar8) < 0x7fffffff) {
            uVar14 = (iVar9 - iVar8) + 1;
            iVar10 = func_0x000180085510(arg1, uVar14);
            if (iVar10 != 0) {
                if ((iVar8 == 1) && ((int32_t)uVar14 <= *(int32_t *)(iVar3 + 8))) {
                    uVar11 = 0;
                    if (0 < (int32_t)uVar14) {
                        do {
                            uVar15 = (int32_t)uVar11 + 1;
                            puVar1 = (undefined4 *)(*(int64_t *)(iVar3 + 0x20) + uVar11 * 0x10);
                            uVar5 = puVar1[1];
                            uVar6 = puVar1[2];
                            uVar7 = puVar1[3];
                            puVar2 = (undefined4 *)(*(int64_t *)(arg1 + 0x40) + uVar11 * 0x10);
                            *puVar2 = *puVar1;
                            puVar2[1] = uVar5;
                            puVar2[2] = uVar6;
                            puVar2[3] = uVar7;
                            uVar11 = (uint64_t)uVar15;
                        } while ((int32_t)uVar15 < (int32_t)uVar14);
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + (uint64_t)uVar14 * 0x10;
                } else {
                    for (; iVar8 < iVar9; iVar8 = iVar8 + 1) {
                        func_0x000180086ed0(arg1, 1, iVar8);
                    }
                    func_0x000180086ed0(arg1, 1, iVar9);
                }
                return (uint64_t)uVar14;
            }
        }
        fcn.180088560(arg1, 0x18063ebc8);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a29f2
// Address: 0x1800a29f2
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800a2850(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar12 = piVar13;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    iVar3 = *piVar13;
    piVar12 = piVar13 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13 + 2) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
        iVar8 = 1;
    } else {
        iVar8 = func_0x000180088860(arg1, 2);
    }
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar12 = piVar13 + 4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13 + 4) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
        iVar9 = *(int32_t *)((int64_t)piVar13 + 0xc);
        if (iVar9 == 6) {
            iVar9 = *(int32_t *)(*piVar13 + 0x14);
        } else if (iVar9 == 7) {
            iVar9 = func_0x0001800a1110(*piVar13);
        } else if ((iVar9 == 9) || (iVar9 == 0xb)) {
            iVar9 = *(int32_t *)(*piVar13 + 4);
        } else {
            iVar9 = 0;
        }
    } else {
        iVar9 = func_0x000180088860(arg1, 3);
    }
    if (iVar8 <= iVar9) {
        if ((uint32_t)(iVar9 - iVar8) < 0x7fffffff) {
            uVar14 = (iVar9 - iVar8) + 1;
            iVar10 = func_0x000180085510(arg1, uVar14);
            if (iVar10 != 0) {
                if ((iVar8 == 1) && ((int32_t)uVar14 <= *(int32_t *)(iVar3 + 8))) {
                    uVar11 = 0;
                    if (0 < (int32_t)uVar14) {
                        do {
                            uVar15 = (int32_t)uVar11 + 1;
                            puVar1 = (undefined4 *)(*(int64_t *)(iVar3 + 0x20) + uVar11 * 0x10);
                            uVar5 = puVar1[1];
                            uVar6 = puVar1[2];
                            uVar7 = puVar1[3];
                            puVar2 = (undefined4 *)(*(int64_t *)(arg1 + 0x40) + uVar11 * 0x10);
                            *puVar2 = *puVar1;
                            puVar2[1] = uVar5;
                            puVar2[2] = uVar6;
                            puVar2[3] = uVar7;
                            uVar11 = (uint64_t)uVar15;
                        } while ((int32_t)uVar15 < (int32_t)uVar14);
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + (uint64_t)uVar14 * 0x10;
                } else {
                    for (; iVar8 < iVar9; iVar8 = iVar8 + 1) {
                        func_0x000180086ed0(arg1, 1, iVar8);
                    }
                    func_0x000180086ed0(arg1, 1, iVar9);
                }
                return (uint64_t)uVar14;
            }
        }
        fcn.180088560(arg1, 0x18063ebc8);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a2a06
// Address: 0x1800a2a06
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800a2850(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar12 = piVar13;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    iVar3 = *piVar13;
    piVar12 = piVar13 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13 + 2) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
        iVar8 = 1;
    } else {
        iVar8 = func_0x000180088860(arg1, 2);
    }
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar12 = piVar13 + 4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13 + 4) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
        iVar9 = *(int32_t *)((int64_t)piVar13 + 0xc);
        if (iVar9 == 6) {
            iVar9 = *(int32_t *)(*piVar13 + 0x14);
        } else if (iVar9 == 7) {
            iVar9 = func_0x0001800a1110(*piVar13);
        } else if ((iVar9 == 9) || (iVar9 == 0xb)) {
            iVar9 = *(int32_t *)(*piVar13 + 4);
        } else {
            iVar9 = 0;
        }
    } else {
        iVar9 = func_0x000180088860(arg1, 3);
    }
    if (iVar8 <= iVar9) {
        if ((uint32_t)(iVar9 - iVar8) < 0x7fffffff) {
            uVar14 = (iVar9 - iVar8) + 1;
            iVar10 = func_0x000180085510(arg1, uVar14);
            if (iVar10 != 0) {
                if ((iVar8 == 1) && ((int32_t)uVar14 <= *(int32_t *)(iVar3 + 8))) {
                    uVar11 = 0;
                    if (0 < (int32_t)uVar14) {
                        do {
                            uVar15 = (int32_t)uVar11 + 1;
                            puVar1 = (undefined4 *)(*(int64_t *)(iVar3 + 0x20) + uVar11 * 0x10);
                            uVar5 = puVar1[1];
                            uVar6 = puVar1[2];
                            uVar7 = puVar1[3];
                            puVar2 = (undefined4 *)(*(int64_t *)(arg1 + 0x40) + uVar11 * 0x10);
                            *puVar2 = *puVar1;
                            puVar2[1] = uVar5;
                            puVar2[2] = uVar6;
                            puVar2[3] = uVar7;
                            uVar11 = (uint64_t)uVar15;
                        } while ((int32_t)uVar15 < (int32_t)uVar14);
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + (uint64_t)uVar14 * 0x10;
                } else {
                    for (; iVar8 < iVar9; iVar8 = iVar8 + 1) {
                        func_0x000180086ed0(arg1, 1, iVar8);
                    }
                    func_0x000180086ed0(arg1, 1, iVar9);
                }
                return (uint64_t)uVar14;
            }
        }
        fcn.180088560(arg1, 0x18063ebc8);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a2a20
// Address: 0x1800a2a20
// Size: 119 bytes
// ============================================================
undefined8 fcn.1800a2a20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    
    iVar2 = *(int64_t *)(arg1 + 0x28);
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    uVar4 = *(undefined4 *)(iVar2 + 0x14);
    uVar5 = *(undefined4 *)(iVar2 + 0x18);
    uVar6 = *(undefined4 *)(iVar2 + 0x1c);
    *puVar3 = *(undefined4 *)(iVar2 + 0x10);
    puVar3[1] = uVar4;
    puVar3[2] = uVar5;
    puVar3[3] = uVar6;
    iVar2 = *(int64_t *)(arg1 + 0x40);
    uVar4 = *(undefined4 *)(arg2 + 4);
    uVar5 = *(undefined4 *)(arg2 + 8);
    uVar6 = *(undefined4 *)(arg2 + 0xc);
    *(undefined4 *)(iVar2 + 0x10) = *(undefined4 *)arg2;
    *(undefined4 *)(iVar2 + 0x14) = uVar4;
    *(undefined4 *)(iVar2 + 0x18) = uVar5;
    *(undefined4 *)(iVar2 + 0x1c) = uVar6;
    iVar2 = *(int64_t *)(arg1 + 0x40);
    uVar4 = *(undefined4 *)arg3;
    uVar5 = *(undefined4 *)(arg3 + 4);
    uVar6 = *(undefined4 *)(arg3 + 8);
    uVar7 = *(undefined4 *)(arg3 + 0xc);
    *(undefined4 *)(iVar2 + 0x20) = uVar4;
    *(undefined4 *)(iVar2 + 0x24) = uVar5;
    *(undefined4 *)(iVar2 + 0x28) = uVar6;
    *(undefined4 *)(iVar2 + 0x2c) = uVar7;
    iVar2 = *(int64_t *)(arg1 + 0x40);
    *(int64_t *)(arg1 + 0x40) = iVar2 + 0x30;
    func_0x0001800935b0(uVar4, iVar2, 1, 0);
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    iVar1 = (*(int32_t **)(arg1 + 0x40))[3];
    if ((iVar1 != 0) && ((iVar1 != 1 || (**(int32_t **)(arg1 + 0x40) != 0)))) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a2aa0
// Address: 0x1800a2aa0
// Size: 414 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

void fcn.1800a2aa0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int32_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int32_t iVar15;
    int32_t iVar16;
    int32_t iVar17;
    int64_t iVar18;
    int64_t iVar19;
    int64_t var_1h;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    
    iVar16 = (int32_t)arg3;
    iVar14 = (int32_t)arg4 - iVar16;
    while ((int32_t)arg_30h * 2 + 2 < iVar14 + 1) {
        iVar17 = *(int32_t *)(arg2 + 8);
        iVar6 = (int32_t)arg_30h * 2;
        iVar18 = (int64_t)(iVar16 + (int32_t)arg_30h);
        iVar15 = (*(code *)arg_28h)(arg1, *(int64_t *)(arg2 + 0x20) + iVar18 * 0x10, 
                                    (int64_t)(iVar16 + 1 + iVar6) * 0x10 + *(int64_t *)(arg2 + 0x20));
        iVar3 = *(int32_t *)(arg2 + 8);
        if (iVar3 != iVar17) goto code_r0x0001800a2c2e;
        iVar17 = (int32_t)arg_30h;
        if (iVar15 != 0) {
            iVar17 = iVar6 + 1;
        }
        iVar15 = (*(code *)arg_28h)(arg1, (int64_t)(iVar17 + iVar16) * 0x10 + *(int64_t *)(arg2 + 0x20), 
                                    (int64_t)(iVar6 + 2 + iVar16) * 0x10 + *(int64_t *)(arg2 + 0x20));
        if (*(int32_t *)(arg2 + 8) != iVar3) goto code_r0x0001800a2c2e;
        if (iVar15 != 0) {
            iVar17 = iVar6 + 2;
        }
        if (iVar17 == (int32_t)arg_30h) break;
        iVar19 = *(int64_t *)(arg2 + 0x20);
        puVar1 = (undefined4 *)(iVar19 + iVar18 * 0x10);
        uVar7 = *puVar1;
        uVar8 = puVar1[1];
        uVar9 = puVar1[2];
        uVar10 = puVar1[3];
        puVar1 = (undefined4 *)(iVar19 + (int64_t)(iVar17 + iVar16) * 0x10);
        uVar11 = puVar1[1];
        uVar12 = puVar1[2];
        uVar13 = puVar1[3];
        puVar2 = (undefined4 *)(iVar19 + iVar18 * 0x10);
        *puVar2 = *puVar1;
        puVar2[1] = uVar11;
        puVar2[2] = uVar12;
        puVar2[3] = uVar13;
        puVar1 = (undefined4 *)(iVar19 + (int64_t)(iVar17 + iVar16) * 0x10);
        *puVar1 = uVar7;
        puVar1[1] = uVar8;
        puVar1[2] = uVar9;
        puVar1[3] = uVar10;
        arg_30h._0_4_ = iVar17;
    }
    iVar17 = (int32_t)arg_30h * 2 + 1;
    if (iVar17 == iVar14) {
        iVar14 = *(int32_t *)(arg2 + 8);
        iVar19 = (int64_t)(iVar17 + iVar16);
        iVar18 = (int64_t)(iVar16 + (int32_t)arg_30h) * 0x10;
        iVar16 = (*(code *)arg_28h)(arg1, *(int64_t *)(arg2 + 0x20) + iVar18, *(int64_t *)(arg2 + 0x20) + iVar19 * 0x10)
        ;
        if (*(int32_t *)(arg2 + 8) != iVar14) {
code_r0x0001800a2c2e:
            fcn.180088560(arg1, 0x18063eba8);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        if (iVar16 != 0) {
            iVar4 = *(int64_t *)(arg2 + 0x20);
            puVar1 = (undefined4 *)(iVar4 + iVar19 * 0x10);
            uVar7 = puVar1[1];
            uVar8 = puVar1[2];
            uVar9 = puVar1[3];
            puVar2 = (undefined4 *)(iVar18 + iVar4);
            uVar10 = *puVar2;
            uVar11 = puVar2[1];
            uVar12 = puVar2[2];
            uVar13 = puVar2[3];
            puVar2 = (undefined4 *)(iVar18 + iVar4);
            *puVar2 = *puVar1;
            puVar2[1] = uVar7;
            puVar2[2] = uVar8;
            puVar2[3] = uVar9;
            puVar1 = (undefined4 *)(iVar4 + iVar19 * 0x10);
            *puVar1 = uVar10;
            puVar1[1] = uVar11;
            puVar1[2] = uVar12;
            puVar1[3] = uVar13;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800a2c40
// Address: 0x1800a2c40
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

void fcn.1800a2c40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    uint32_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    uint32_t uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    uint64_t uVar14;
    int32_t iVar15;
    int32_t iVar16;
    int32_t iVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    int64_t iVar22;
    int32_t iVar23;
    uint32_t uVar24;
    uint64_t arg3_00;
    int64_t iVar25;
    int64_t iVar26;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar21;
    
    var_60h._0_4_ = (uint32_t)arg4;
    uVar21 = arg4 & 0xffffffff;
    var_68h._0_4_ = (uint32_t)arg3;
    arg3_00 = arg3 & 0xffffffff;
    if ((int32_t)(uint32_t)var_60h <= (int32_t)(uint32_t)var_68h) {
        return;
    }
code_r0x0001800a2ca0:
    iVar15 = (int32_t)arg3_00;
    iVar23 = (int32_t)uVar21;
    if ((int32_t)arg_28h == 0) {
        iVar23 = iVar23 - iVar15;
        iVar17 = (iVar23 + 1) / 2;
        while (iVar17 = iVar17 + -1, -1 < iVar17) {
            uVar14 = (uint64_t)var_80h >> 0x20;
            var_80h = CONCAT44((int32_t)uVar14, iVar17);
            fcn.1800a2aa0(arg1, arg2, arg3_00, uVar21, arg_30h, var_80h);
        }
        if (iVar23 < 1) {
            return;
        }
        do {
            iVar22 = *(int64_t *)(arg2 + 0x20);
            var_80h = var_80h & 0xffffffff00000000;
            puVar1 = (undefined4 *)(iVar22 + (int64_t)iVar15 * 0x10);
            uVar7 = *puVar1;
            uVar8 = puVar1[1];
            uVar9 = puVar1[2];
            uVar10 = puVar1[3];
            puVar1 = (undefined4 *)(iVar22 + (int64_t)(iVar23 + iVar15) * 0x10);
            uVar11 = puVar1[1];
            uVar12 = puVar1[2];
            uVar13 = puVar1[3];
            puVar2 = (undefined4 *)(iVar22 + (int64_t)iVar15 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar11;
            puVar2[2] = uVar12;
            puVar2[3] = uVar13;
            puVar1 = (undefined4 *)(iVar22 + (int64_t)(iVar23 + iVar15) * 0x10);
            *puVar1 = uVar7;
            puVar1[1] = uVar8;
            puVar1[2] = uVar9;
            puVar1[3] = uVar10;
            fcn.1800a2aa0(arg1, arg2, arg3_00, (uint64_t)(uint32_t)(iVar23 + -1 + iVar15), arg_30h, var_80h);
            iVar23 = iVar23 + -1;
        } while (0 < iVar23);
        return;
    }
    iVar17 = *(int32_t *)(arg2 + 8);
    iVar22 = (int64_t)iVar15;
    iVar25 = (int64_t)iVar23;
    iVar15 = (*(code *)arg_30h)(arg1, *(int64_t *)(arg2 + 0x20) + iVar25 * 0x10, 
                                *(int64_t *)(arg2 + 0x20) + iVar22 * 0x10);
    if (*(int32_t *)(arg2 + 8) == iVar17) {
        if (iVar15 != 0) {
            iVar26 = *(int64_t *)(arg2 + 0x20);
            puVar1 = (undefined4 *)(iVar26 + iVar22 * 0x10);
            uVar7 = puVar1[1];
            uVar8 = puVar1[2];
            uVar9 = puVar1[3];
            puVar2 = (undefined4 *)(iVar26 + iVar25 * 0x10);
            uVar10 = *puVar2;
            uVar11 = puVar2[1];
            uVar12 = puVar2[2];
            uVar13 = puVar2[3];
            puVar2 = (undefined4 *)(iVar26 + iVar25 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar7;
            puVar2[2] = uVar8;
            puVar2[3] = uVar9;
            puVar1 = (undefined4 *)(iVar26 + iVar22 * 0x10);
            *puVar1 = uVar10;
            puVar1[1] = uVar11;
            puVar1[2] = uVar12;
            puVar1[3] = uVar13;
        }
        iVar23 = iVar23 - (uint32_t)var_68h;
        if (iVar23 == 1) {
            return;
        }
        iVar15 = *(int32_t *)(arg2 + 8);
        iVar26 = (int64_t)(int32_t)((iVar23 >> 1) + (uint32_t)var_68h);
        iVar16 = (*(code *)arg_30h)(arg1, *(int64_t *)(arg2 + 0x20) + iVar26 * 0x10, 
                                    *(int64_t *)(arg2 + 0x20) + iVar22 * 0x10);
        iVar17 = *(int32_t *)(arg2 + 8);
        if (iVar17 == iVar15) {
            iVar4 = *(int64_t *)(arg2 + 0x20);
            puVar1 = (undefined4 *)(iVar4 + iVar26 * 0x10);
            if (iVar16 == 0) {
                iVar15 = (*(code *)arg_30h)(arg1, iVar4 + iVar25 * 0x10);
                if (*(int32_t *)(arg2 + 8) != iVar17) goto code_r0x0001800a300f;
                if (iVar15 != 0) {
                    iVar22 = *(int64_t *)(arg2 + 0x20);
                    puVar1 = (undefined4 *)(iVar22 + iVar25 * 0x10);
                    uVar7 = puVar1[1];
                    uVar8 = puVar1[2];
                    uVar9 = puVar1[3];
                    puVar2 = (undefined4 *)(iVar22 + iVar26 * 0x10);
                    uVar10 = *puVar2;
                    uVar11 = puVar2[1];
                    uVar12 = puVar2[2];
                    uVar13 = puVar2[3];
                    puVar2 = (undefined4 *)(iVar22 + iVar26 * 0x10);
                    *puVar2 = *puVar1;
                    puVar2[1] = uVar7;
                    puVar2[2] = uVar8;
                    puVar2[3] = uVar9;
                    puVar1 = (undefined4 *)(iVar22 + iVar25 * 0x10);
                    *puVar1 = uVar10;
                    puVar1[1] = uVar11;
                    puVar1[2] = uVar12;
                    puVar1[3] = uVar13;
                }
            } else {
                puVar2 = (undefined4 *)(iVar4 + iVar22 * 0x10);
                uVar7 = puVar2[1];
                uVar8 = puVar2[2];
                uVar9 = puVar2[3];
                uVar10 = *puVar1;
                uVar11 = puVar1[1];
                uVar12 = puVar1[2];
                uVar13 = puVar1[3];
                *puVar1 = *puVar2;
                puVar1[1] = uVar7;
                puVar1[2] = uVar8;
                puVar1[3] = uVar9;
                puVar1 = (undefined4 *)(iVar4 + iVar22 * 0x10);
                *puVar1 = uVar10;
                puVar1[1] = uVar11;
                puVar1[2] = uVar12;
                puVar1[3] = uVar13;
            }
            if (iVar23 == 2) {
                return;
            }
            iVar4 = *(int64_t *)(arg2 + 0x20);
            iVar22 = iVar25 * 0x10 + -0x10;
            arg3_00 = (uint64_t)(uint32_t)var_68h;
            puVar1 = (undefined4 *)(iVar4 + iVar26 * 0x10);
            uVar10 = *puVar1;
            uVar11 = puVar1[1];
            uVar12 = puVar1[2];
            uVar13 = puVar1[3];
            puVar1 = (undefined4 *)(iVar22 + iVar4);
            uVar7 = puVar1[1];
            uVar8 = puVar1[2];
            uVar9 = puVar1[3];
            puVar2 = (undefined4 *)(iVar4 + iVar26 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar7;
            puVar2[2] = uVar8;
            puVar2[3] = uVar9;
            iVar23 = (uint32_t)var_60h - 1;
            puVar1 = (undefined4 *)(iVar22 + iVar4);
            *puVar1 = uVar10;
            puVar1[1] = uVar11;
            puVar1[2] = uVar12;
            puVar1[3] = uVar13;
            uVar21 = arg3_00;
            do {
                while( true ) {
                    iVar15 = *(int32_t *)(arg2 + 8);
                    uVar19 = (uint32_t)uVar21;
                    uVar20 = uVar19 + 1;
                    uVar21 = (uint64_t)uVar20;
                    iVar17 = (*(code *)arg_30h)(arg1, *(int64_t *)(arg2 + 0x20) + (int64_t)(int32_t)uVar20 * 0x10, 
                                                *(int64_t *)(arg2 + 0x20) + iVar22);
                    if (*(int32_t *)(arg2 + 8) != iVar15) goto code_r0x0001800a300f;
                    iVar15 = *(int32_t *)(arg2 + 8);
                    if (iVar17 == 0) break;
                    if ((int32_t)(uint32_t)var_60h <= (int32_t)uVar20) {
code_r0x0001800a2ff8:
                        fcn.180088560(arg1, 0x18063eb80);
                        pcVar5 = (code *)swi(3);
                        (*pcVar5)();
                        return;
                    }
                }
                while( true ) {
                    iVar23 = iVar23 + -1;
                    iVar25 = (int64_t)iVar23;
                    iVar17 = (*(code *)arg_30h)(arg1, iVar22 + *(int64_t *)(arg2 + 0x20), 
                                                *(int64_t *)(arg2 + 0x20) + iVar25 * 0x10);
                    if (*(int32_t *)(arg2 + 8) != iVar15) goto code_r0x0001800a300f;
                    if (iVar17 == 0) break;
                    iVar15 = *(int32_t *)(arg2 + 8);
                    if (iVar23 <= (int32_t)(uint32_t)var_68h) goto code_r0x0001800a2ff8;
                }
                iVar26 = *(int64_t *)(arg2 + 0x20);
                puVar1 = (undefined4 *)(iVar26 + (int64_t)(int32_t)uVar20 * 0x10);
                if (iVar23 < (int32_t)uVar20) goto code_r0x0001800a2e88;
                uVar10 = *puVar1;
                uVar11 = puVar1[1];
                uVar12 = puVar1[2];
                uVar13 = puVar1[3];
                puVar2 = (undefined4 *)(iVar26 + iVar25 * 0x10);
                uVar7 = puVar2[1];
                uVar8 = puVar2[2];
                uVar9 = puVar2[3];
                *puVar1 = *puVar2;
                puVar1[1] = uVar7;
                puVar1[2] = uVar8;
                puVar1[3] = uVar9;
                puVar1 = (undefined4 *)(iVar26 + iVar25 * 0x10);
                *puVar1 = uVar10;
                puVar1[1] = uVar11;
                puVar1[2] = uVar12;
                puVar1[3] = uVar13;
            } while( true );
        }
    }
code_r0x0001800a300f:
    fcn.180088560(arg1, 0x18063eba8);
    pcVar5 = (code *)swi(3);
    (*pcVar5)();
    return;
code_r0x0001800a2e88:
    uVar7 = puVar1[1];
    uVar8 = puVar1[2];
    uVar9 = puVar1[3];
    puVar2 = (undefined4 *)(iVar22 + iVar26);
    uVar10 = *puVar2;
    uVar11 = puVar2[1];
    uVar12 = puVar2[2];
    uVar13 = puVar2[3];
    puVar2 = (undefined4 *)(iVar22 + iVar26);
    *puVar2 = *puVar1;
    puVar2[1] = uVar7;
    puVar2[2] = uVar8;
    puVar2[3] = uVar9;
    uVar18 = uVar19 + 2;
    uVar24 = ((int32_t)arg_28h >> 1) + ((int32_t)arg_28h >> 2);
    *puVar1 = uVar10;
    puVar1[1] = uVar11;
    puVar1[2] = uVar12;
    puVar1[3] = uVar13;
    uVar6 = uVar18;
    uVar3 = (uint32_t)var_60h;
    if ((int32_t)(uVar20 - (uint32_t)var_68h) < (int32_t)((uint32_t)var_60h - uVar20)) {
        arg3_00 = (uint64_t)uVar18;
        uVar6 = (uint32_t)var_68h;
        uVar3 = uVar19;
        var_68h._0_4_ = uVar18;
        uVar19 = (uint32_t)var_60h;
    }
    var_60h._0_4_ = uVar19;
    uVar21 = (uint64_t)(uint32_t)var_60h;
    var_80h = arg_30h;
    var_88h = CONCAT44(var_88h._4_4_, uVar24);
    fcn.1800a2c40(arg1, arg2, (uint64_t)uVar6, (uint64_t)uVar3, var_88h, arg_30h);
    arg_28h = (int64_t)uVar24;
    if ((int32_t)(uint32_t)var_60h <= (int32_t)arg3_00) {
        return;
    }
    goto code_r0x0001800a2ca0;
}

// ============================================================
// Function: FUN_1800a2c80
// Address: 0x1800a2c80
// Size: 875 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

void fcn.1800a2c40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    uint32_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    uint32_t uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    uint64_t uVar14;
    int32_t iVar15;
    int32_t iVar16;
    int32_t iVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    int64_t iVar22;
    int32_t iVar23;
    uint32_t uVar24;
    uint64_t arg3_00;
    int64_t iVar25;
    int64_t iVar26;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar21;
    
    var_60h._0_4_ = (uint32_t)arg4;
    uVar21 = arg4 & 0xffffffff;
    var_68h._0_4_ = (uint32_t)arg3;
    arg3_00 = arg3 & 0xffffffff;
    if ((int32_t)(uint32_t)var_60h <= (int32_t)(uint32_t)var_68h) {
        return;
    }
code_r0x0001800a2ca0:
    iVar15 = (int32_t)arg3_00;
    iVar23 = (int32_t)uVar21;
    if ((int32_t)arg_28h == 0) {
        iVar23 = iVar23 - iVar15;
        iVar17 = (iVar23 + 1) / 2;
        while (iVar17 = iVar17 + -1, -1 < iVar17) {
            uVar14 = (uint64_t)var_80h >> 0x20;
            var_80h = CONCAT44((int32_t)uVar14, iVar17);
            fcn.1800a2aa0(arg1, arg2, arg3_00, uVar21, arg_30h, var_80h);
        }
        if (iVar23 < 1) {
            return;
        }
        do {
            iVar22 = *(int64_t *)(arg2 + 0x20);
            var_80h = var_80h & 0xffffffff00000000;
            puVar1 = (undefined4 *)(iVar22 + (int64_t)iVar15 * 0x10);
            uVar7 = *puVar1;
            uVar8 = puVar1[1];
            uVar9 = puVar1[2];
            uVar10 = puVar1[3];
            puVar1 = (undefined4 *)(iVar22 + (int64_t)(iVar23 + iVar15) * 0x10);
            uVar11 = puVar1[1];
            uVar12 = puVar1[2];
            uVar13 = puVar1[3];
            puVar2 = (undefined4 *)(iVar22 + (int64_t)iVar15 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar11;
            puVar2[2] = uVar12;
            puVar2[3] = uVar13;
            puVar1 = (undefined4 *)(iVar22 + (int64_t)(iVar23 + iVar15) * 0x10);
            *puVar1 = uVar7;
            puVar1[1] = uVar8;
            puVar1[2] = uVar9;
            puVar1[3] = uVar10;
            fcn.1800a2aa0(arg1, arg2, arg3_00, (uint64_t)(uint32_t)(iVar23 + -1 + iVar15), arg_30h, var_80h);
            iVar23 = iVar23 + -1;
        } while (0 < iVar23);
        return;
    }
    iVar17 = *(int32_t *)(arg2 + 8);
    iVar22 = (int64_t)iVar15;
    iVar25 = (int64_t)iVar23;
    iVar15 = (*(code *)arg_30h)(arg1, *(int64_t *)(arg2 + 0x20) + iVar25 * 0x10, 
                                *(int64_t *)(arg2 + 0x20) + iVar22 * 0x10);
    if (*(int32_t *)(arg2 + 8) == iVar17) {
        if (iVar15 != 0) {
            iVar26 = *(int64_t *)(arg2 + 0x20);
            puVar1 = (undefined4 *)(iVar26 + iVar22 * 0x10);
            uVar7 = puVar1[1];
            uVar8 = puVar1[2];
            uVar9 = puVar1[3];
            puVar2 = (undefined4 *)(iVar26 + iVar25 * 0x10);
            uVar10 = *puVar2;
            uVar11 = puVar2[1];
            uVar12 = puVar2[2];
            uVar13 = puVar2[3];
            puVar2 = (undefined4 *)(iVar26 + iVar25 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar7;
            puVar2[2] = uVar8;
            puVar2[3] = uVar9;
            puVar1 = (undefined4 *)(iVar26 + iVar22 * 0x10);
            *puVar1 = uVar10;
            puVar1[1] = uVar11;
            puVar1[2] = uVar12;
            puVar1[3] = uVar13;
        }
        iVar23 = iVar23 - (uint32_t)var_68h;
        if (iVar23 == 1) {
            return;
        }
        iVar15 = *(int32_t *)(arg2 + 8);
        iVar26 = (int64_t)(int32_t)((iVar23 >> 1) + (uint32_t)var_68h);
        iVar16 = (*(code *)arg_30h)(arg1, *(int64_t *)(arg2 + 0x20) + iVar26 * 0x10, 
                                    *(int64_t *)(arg2 + 0x20) + iVar22 * 0x10);
        iVar17 = *(int32_t *)(arg2 + 8);
        if (iVar17 == iVar15) {
            iVar4 = *(int64_t *)(arg2 + 0x20);
            puVar1 = (undefined4 *)(iVar4 + iVar26 * 0x10);
            if (iVar16 == 0) {
                iVar15 = (*(code *)arg_30h)(arg1, iVar4 + iVar25 * 0x10);
                if (*(int32_t *)(arg2 + 8) != iVar17) goto code_r0x0001800a300f;
                if (iVar15 != 0) {
                    iVar22 = *(int64_t *)(arg2 + 0x20);
                    puVar1 = (undefined4 *)(iVar22 + iVar25 * 0x10);
                    uVar7 = puVar1[1];
                    uVar8 = puVar1[2];
                    uVar9 = puVar1[3];
                    puVar2 = (undefined4 *)(iVar22 + iVar26 * 0x10);
                    uVar10 = *puVar2;
                    uVar11 = puVar2[1];
                    uVar12 = puVar2[2];
                    uVar13 = puVar2[3];
                    puVar2 = (undefined4 *)(iVar22 + iVar26 * 0x10);
                    *puVar2 = *puVar1;
                    puVar2[1] = uVar7;
                    puVar2[2] = uVar8;
                    puVar2[3] = uVar9;
                    puVar1 = (undefined4 *)(iVar22 + iVar25 * 0x10);
                    *puVar1 = uVar10;
                    puVar1[1] = uVar11;
                    puVar1[2] = uVar12;
                    puVar1[3] = uVar13;
                }
            } else {
                puVar2 = (undefined4 *)(iVar4 + iVar22 * 0x10);
                uVar7 = puVar2[1];
                uVar8 = puVar2[2];
                uVar9 = puVar2[3];
                uVar10 = *puVar1;
                uVar11 = puVar1[1];
                uVar12 = puVar1[2];
                uVar13 = puVar1[3];
                *puVar1 = *puVar2;
                puVar1[1] = uVar7;
                puVar1[2] = uVar8;
                puVar1[3] = uVar9;
                puVar1 = (undefined4 *)(iVar4 + iVar22 * 0x10);
                *puVar1 = uVar10;
                puVar1[1] = uVar11;
                puVar1[2] = uVar12;
                puVar1[3] = uVar13;
            }
            if (iVar23 == 2) {
                return;
            }
            iVar4 = *(int64_t *)(arg2 + 0x20);
            iVar22 = iVar25 * 0x10 + -0x10;
            arg3_00 = (uint64_t)(uint32_t)var_68h;
            puVar1 = (undefined4 *)(iVar4 + iVar26 * 0x10);
            uVar10 = *puVar1;
            uVar11 = puVar1[1];
            uVar12 = puVar1[2];
            uVar13 = puVar1[3];
            puVar1 = (undefined4 *)(iVar22 + iVar4);
            uVar7 = puVar1[1];
            uVar8 = puVar1[2];
            uVar9 = puVar1[3];
            puVar2 = (undefined4 *)(iVar4 + iVar26 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar7;
            puVar2[2] = uVar8;
            puVar2[3] = uVar9;
            iVar23 = (uint32_t)var_60h - 1;
            puVar1 = (undefined4 *)(iVar22 + iVar4);
            *puVar1 = uVar10;
            puVar1[1] = uVar11;
            puVar1[2] = uVar12;
            puVar1[3] = uVar13;
            uVar21 = arg3_00;
            do {
                while( true ) {
                    iVar15 = *(int32_t *)(arg2 + 8);
                    uVar19 = (uint32_t)uVar21;
                    uVar20 = uVar19 + 1;
                    uVar21 = (uint64_t)uVar20;
                    iVar17 = (*(code *)arg_30h)(arg1, *(int64_t *)(arg2 + 0x20) + (int64_t)(int32_t)uVar20 * 0x10, 
                                                *(int64_t *)(arg2 + 0x20) + iVar22);
                    if (*(int32_t *)(arg2 + 8) != iVar15) goto code_r0x0001800a300f;
                    iVar15 = *(int32_t *)(arg2 + 8);
                    if (iVar17 == 0) break;
                    if ((int32_t)(uint32_t)var_60h <= (int32_t)uVar20) {
code_r0x0001800a2ff8:
                        fcn.180088560(arg1, 0x18063eb80);
                        pcVar5 = (code *)swi(3);
                        (*pcVar5)();
                        return;
                    }
                }
                while( true ) {
                    iVar23 = iVar23 + -1;
                    iVar25 = (int64_t)iVar23;
                    iVar17 = (*(code *)arg_30h)(arg1, iVar22 + *(int64_t *)(arg2 + 0x20), 
                                                *(int64_t *)(arg2 + 0x20) + iVar25 * 0x10);
                    if (*(int32_t *)(arg2 + 8) != iVar15) goto code_r0x0001800a300f;
                    if (iVar17 == 0) break;
                    iVar15 = *(int32_t *)(arg2 + 8);
                    if (iVar23 <= (int32_t)(uint32_t)var_68h) goto code_r0x0001800a2ff8;
                }
                iVar26 = *(int64_t *)(arg2 + 0x20);
                puVar1 = (undefined4 *)(iVar26 + (int64_t)(int32_t)uVar20 * 0x10);
                if (iVar23 < (int32_t)uVar20) goto code_r0x0001800a2e88;
                uVar10 = *puVar1;
                uVar11 = puVar1[1];
                uVar12 = puVar1[2];
                uVar13 = puVar1[3];
                puVar2 = (undefined4 *)(iVar26 + iVar25 * 0x10);
                uVar7 = puVar2[1];
                uVar8 = puVar2[2];
                uVar9 = puVar2[3];
                *puVar1 = *puVar2;
                puVar1[1] = uVar7;
                puVar1[2] = uVar8;
                puVar1[3] = uVar9;
                puVar1 = (undefined4 *)(iVar26 + iVar25 * 0x10);
                *puVar1 = uVar10;
                puVar1[1] = uVar11;
                puVar1[2] = uVar12;
                puVar1[3] = uVar13;
            } while( true );
        }
    }
code_r0x0001800a300f:
    fcn.180088560(arg1, 0x18063eba8);
    pcVar5 = (code *)swi(3);
    (*pcVar5)();
    return;
code_r0x0001800a2e88:
    uVar7 = puVar1[1];
    uVar8 = puVar1[2];
    uVar9 = puVar1[3];
    puVar2 = (undefined4 *)(iVar22 + iVar26);
    uVar10 = *puVar2;
    uVar11 = puVar2[1];
    uVar12 = puVar2[2];
    uVar13 = puVar2[3];
    puVar2 = (undefined4 *)(iVar22 + iVar26);
    *puVar2 = *puVar1;
    puVar2[1] = uVar7;
    puVar2[2] = uVar8;
    puVar2[3] = uVar9;
    uVar18 = uVar19 + 2;
    uVar24 = ((int32_t)arg_28h >> 1) + ((int32_t)arg_28h >> 2);
    *puVar1 = uVar10;
    puVar1[1] = uVar11;
    puVar1[2] = uVar12;
    puVar1[3] = uVar13;
    uVar6 = uVar18;
    uVar3 = (uint32_t)var_60h;
    if ((int32_t)(uVar20 - (uint32_t)var_68h) < (int32_t)((uint32_t)var_60h - uVar20)) {
        arg3_00 = (uint64_t)uVar18;
        uVar6 = (uint32_t)var_68h;
        uVar3 = uVar19;
        var_68h._0_4_ = uVar18;
        uVar19 = (uint32_t)var_60h;
    }
    var_60h._0_4_ = uVar19;
    uVar21 = (uint64_t)(uint32_t)var_60h;
    var_80h = arg_30h;
    var_88h = CONCAT44(var_88h._4_4_, uVar24);
    fcn.1800a2c40(arg1, arg2, (uint64_t)uVar6, (uint64_t)uVar3, var_88h, arg_30h);
    arg_28h = (int64_t)uVar24;
    if ((int32_t)(uint32_t)var_60h <= (int32_t)arg3_00) {
        return;
    }
    goto code_r0x0001800a2ca0;
}

// ============================================================
// Function: FUN_1800a2feb
// Address: 0x1800a2feb
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

void fcn.1800a2c40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    uint32_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    uint32_t uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    uint64_t uVar14;
    int32_t iVar15;
    int32_t iVar16;
    int32_t iVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    int64_t iVar22;
    int32_t iVar23;
    uint32_t uVar24;
    uint64_t arg3_00;
    int64_t iVar25;
    int64_t iVar26;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar21;
    
    var_60h._0_4_ = (uint32_t)arg4;
    uVar21 = arg4 & 0xffffffff;
    var_68h._0_4_ = (uint32_t)arg3;
    arg3_00 = arg3 & 0xffffffff;
    if ((int32_t)(uint32_t)var_60h <= (int32_t)(uint32_t)var_68h) {
        return;
    }
code_r0x0001800a2ca0:
    iVar15 = (int32_t)arg3_00;
    iVar23 = (int32_t)uVar21;
    if ((int32_t)arg_28h == 0) {
        iVar23 = iVar23 - iVar15;
        iVar17 = (iVar23 + 1) / 2;
        while (iVar17 = iVar17 + -1, -1 < iVar17) {
            uVar14 = (uint64_t)var_80h >> 0x20;
            var_80h = CONCAT44((int32_t)uVar14, iVar17);
            fcn.1800a2aa0(arg1, arg2, arg3_00, uVar21, arg_30h, var_80h);
        }
        if (iVar23 < 1) {
            return;
        }
        do {
            iVar22 = *(int64_t *)(arg2 + 0x20);
            var_80h = var_80h & 0xffffffff00000000;
            puVar1 = (undefined4 *)(iVar22 + (int64_t)iVar15 * 0x10);
            uVar7 = *puVar1;
            uVar8 = puVar1[1];
            uVar9 = puVar1[2];
            uVar10 = puVar1[3];
            puVar1 = (undefined4 *)(iVar22 + (int64_t)(iVar23 + iVar15) * 0x10);
            uVar11 = puVar1[1];
            uVar12 = puVar1[2];
            uVar13 = puVar1[3];
            puVar2 = (undefined4 *)(iVar22 + (int64_t)iVar15 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar11;
            puVar2[2] = uVar12;
            puVar2[3] = uVar13;
            puVar1 = (undefined4 *)(iVar22 + (int64_t)(iVar23 + iVar15) * 0x10);
            *puVar1 = uVar7;
            puVar1[1] = uVar8;
            puVar1[2] = uVar9;
            puVar1[3] = uVar10;
            fcn.1800a2aa0(arg1, arg2, arg3_00, (uint64_t)(uint32_t)(iVar23 + -1 + iVar15), arg_30h, var_80h);
            iVar23 = iVar23 + -1;
        } while (0 < iVar23);
        return;
    }
    iVar17 = *(int32_t *)(arg2 + 8);
    iVar22 = (int64_t)iVar15;
    iVar25 = (int64_t)iVar23;
    iVar15 = (*(code *)arg_30h)(arg1, *(int64_t *)(arg2 + 0x20) + iVar25 * 0x10, 
                                *(int64_t *)(arg2 + 0x20) + iVar22 * 0x10);
    if (*(int32_t *)(arg2 + 8) == iVar17) {
        if (iVar15 != 0) {
            iVar26 = *(int64_t *)(arg2 + 0x20);
            puVar1 = (undefined4 *)(iVar26 + iVar22 * 0x10);
            uVar7 = puVar1[1];
            uVar8 = puVar1[2];
            uVar9 = puVar1[3];
            puVar2 = (undefined4 *)(iVar26 + iVar25 * 0x10);
            uVar10 = *puVar2;
            uVar11 = puVar2[1];
            uVar12 = puVar2[2];
            uVar13 = puVar2[3];
            puVar2 = (undefined4 *)(iVar26 + iVar25 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar7;
            puVar2[2] = uVar8;
            puVar2[3] = uVar9;
            puVar1 = (undefined4 *)(iVar26 + iVar22 * 0x10);
            *puVar1 = uVar10;
            puVar1[1] = uVar11;
            puVar1[2] = uVar12;
            puVar1[3] = uVar13;
        }
        iVar23 = iVar23 - (uint32_t)var_68h;
        if (iVar23 == 1) {
            return;
        }
        iVar15 = *(int32_t *)(arg2 + 8);
        iVar26 = (int64_t)(int32_t)((iVar23 >> 1) + (uint32_t)var_68h);
        iVar16 = (*(code *)arg_30h)(arg1, *(int64_t *)(arg2 + 0x20) + iVar26 * 0x10, 
                                    *(int64_t *)(arg2 + 0x20) + iVar22 * 0x10);
        iVar17 = *(int32_t *)(arg2 + 8);
        if (iVar17 == iVar15) {
            iVar4 = *(int64_t *)(arg2 + 0x20);
            puVar1 = (undefined4 *)(iVar4 + iVar26 * 0x10);
            if (iVar16 == 0) {
                iVar15 = (*(code *)arg_30h)(arg1, iVar4 + iVar25 * 0x10);
                if (*(int32_t *)(arg2 + 8) != iVar17) goto code_r0x0001800a300f;
                if (iVar15 != 0) {
                    iVar22 = *(int64_t *)(arg2 + 0x20);
                    puVar1 = (undefined4 *)(iVar22 + iVar25 * 0x10);
                    uVar7 = puVar1[1];
                    uVar8 = puVar1[2];
                    uVar9 = puVar1[3];
                    puVar2 = (undefined4 *)(iVar22 + iVar26 * 0x10);
                    uVar10 = *puVar2;
                    uVar11 = puVar2[1];
                    uVar12 = puVar2[2];
                    uVar13 = puVar2[3];
                    puVar2 = (undefined4 *)(iVar22 + iVar26 * 0x10);
                    *puVar2 = *puVar1;
                    puVar2[1] = uVar7;
                    puVar2[2] = uVar8;
                    puVar2[3] = uVar9;
                    puVar1 = (undefined4 *)(iVar22 + iVar25 * 0x10);
                    *puVar1 = uVar10;
                    puVar1[1] = uVar11;
                    puVar1[2] = uVar12;
                    puVar1[3] = uVar13;
                }
            } else {
                puVar2 = (undefined4 *)(iVar4 + iVar22 * 0x10);
                uVar7 = puVar2[1];
                uVar8 = puVar2[2];
                uVar9 = puVar2[3];
                uVar10 = *puVar1;
                uVar11 = puVar1[1];
                uVar12 = puVar1[2];
                uVar13 = puVar1[3];
                *puVar1 = *puVar2;
                puVar1[1] = uVar7;
                puVar1[2] = uVar8;
                puVar1[3] = uVar9;
                puVar1 = (undefined4 *)(iVar4 + iVar22 * 0x10);
                *puVar1 = uVar10;
                puVar1[1] = uVar11;
                puVar1[2] = uVar12;
                puVar1[3] = uVar13;
            }
            if (iVar23 == 2) {
                return;
            }
            iVar4 = *(int64_t *)(arg2 + 0x20);
            iVar22 = iVar25 * 0x10 + -0x10;
            arg3_00 = (uint64_t)(uint32_t)var_68h;
            puVar1 = (undefined4 *)(iVar4 + iVar26 * 0x10);
            uVar10 = *puVar1;
            uVar11 = puVar1[1];
            uVar12 = puVar1[2];
            uVar13 = puVar1[3];
            puVar1 = (undefined4 *)(iVar22 + iVar4);
            uVar7 = puVar1[1];
            uVar8 = puVar1[2];
            uVar9 = puVar1[3];
            puVar2 = (undefined4 *)(iVar4 + iVar26 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar7;
            puVar2[2] = uVar8;
            puVar2[3] = uVar9;
            iVar23 = (uint32_t)var_60h - 1;
            puVar1 = (undefined4 *)(iVar22 + iVar4);
            *puVar1 = uVar10;
            puVar1[1] = uVar11;
            puVar1[2] = uVar12;
            puVar1[3] = uVar13;
            uVar21 = arg3_00;
            do {
                while( true ) {
                    iVar15 = *(int32_t *)(arg2 + 8);
                    uVar19 = (uint32_t)uVar21;
                    uVar20 = uVar19 + 1;
                    uVar21 = (uint64_t)uVar20;
                    iVar17 = (*(code *)arg_30h)(arg1, *(int64_t *)(arg2 + 0x20) + (int64_t)(int32_t)uVar20 * 0x10, 
                                                *(int64_t *)(arg2 + 0x20) + iVar22);
                    if (*(int32_t *)(arg2 + 8) != iVar15) goto code_r0x0001800a300f;
                    iVar15 = *(int32_t *)(arg2 + 8);
                    if (iVar17 == 0) break;
                    if ((int32_t)(uint32_t)var_60h <= (int32_t)uVar20) {
code_r0x0001800a2ff8:
                        fcn.180088560(arg1, 0x18063eb80);
                        pcVar5 = (code *)swi(3);
                        (*pcVar5)();
                        return;
                    }
                }
                while( true ) {
                    iVar23 = iVar23 + -1;
                    iVar25 = (int64_t)iVar23;
                    iVar17 = (*(code *)arg_30h)(arg1, iVar22 + *(int64_t *)(arg2 + 0x20), 
                                                *(int64_t *)(arg2 + 0x20) + iVar25 * 0x10);
                    if (*(int32_t *)(arg2 + 8) != iVar15) goto code_r0x0001800a300f;
                    if (iVar17 == 0) break;
                    iVar15 = *(int32_t *)(arg2 + 8);
                    if (iVar23 <= (int32_t)(uint32_t)var_68h) goto code_r0x0001800a2ff8;
                }
                iVar26 = *(int64_t *)(arg2 + 0x20);
                puVar1 = (undefined4 *)(iVar26 + (int64_t)(int32_t)uVar20 * 0x10);
                if (iVar23 < (int32_t)uVar20) goto code_r0x0001800a2e88;
                uVar10 = *puVar1;
                uVar11 = puVar1[1];
                uVar12 = puVar1[2];
                uVar13 = puVar1[3];
                puVar2 = (undefined4 *)(iVar26 + iVar25 * 0x10);
                uVar7 = puVar2[1];
                uVar8 = puVar2[2];
                uVar9 = puVar2[3];
                *puVar1 = *puVar2;
                puVar1[1] = uVar7;
                puVar1[2] = uVar8;
                puVar1[3] = uVar9;
                puVar1 = (undefined4 *)(iVar26 + iVar25 * 0x10);
                *puVar1 = uVar10;
                puVar1[1] = uVar11;
                puVar1[2] = uVar12;
                puVar1[3] = uVar13;
            } while( true );
        }
    }
code_r0x0001800a300f:
    fcn.180088560(arg1, 0x18063eba8);
    pcVar5 = (code *)swi(3);
    (*pcVar5)();
    return;
code_r0x0001800a2e88:
    uVar7 = puVar1[1];
    uVar8 = puVar1[2];
    uVar9 = puVar1[3];
    puVar2 = (undefined4 *)(iVar22 + iVar26);
    uVar10 = *puVar2;
    uVar11 = puVar2[1];
    uVar12 = puVar2[2];
    uVar13 = puVar2[3];
    puVar2 = (undefined4 *)(iVar22 + iVar26);
    *puVar2 = *puVar1;
    puVar2[1] = uVar7;
    puVar2[2] = uVar8;
    puVar2[3] = uVar9;
    uVar18 = uVar19 + 2;
    uVar24 = ((int32_t)arg_28h >> 1) + ((int32_t)arg_28h >> 2);
    *puVar1 = uVar10;
    puVar1[1] = uVar11;
    puVar1[2] = uVar12;
    puVar1[3] = uVar13;
    uVar6 = uVar18;
    uVar3 = (uint32_t)var_60h;
    if ((int32_t)(uVar20 - (uint32_t)var_68h) < (int32_t)((uint32_t)var_60h - uVar20)) {
        arg3_00 = (uint64_t)uVar18;
        uVar6 = (uint32_t)var_68h;
        uVar3 = uVar19;
        var_68h._0_4_ = uVar18;
        uVar19 = (uint32_t)var_60h;
    }
    var_60h._0_4_ = uVar19;
    uVar21 = (uint64_t)(uint32_t)var_60h;
    var_80h = arg_30h;
    var_88h = CONCAT44(var_88h._4_4_, uVar24);
    fcn.1800a2c40(arg1, arg2, (uint64_t)uVar6, (uint64_t)uVar3, var_88h, arg_30h);
    arg_28h = (int64_t)uVar24;
    if ((int32_t)(uint32_t)var_60h <= (int32_t)arg3_00) {
        return;
    }
    goto code_r0x0001800a2ca0;
}

// ============================================================
// Function: FUN_1800a2ff8
// Address: 0x1800a2ff8
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

void fcn.1800a2c40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    uint32_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    uint32_t uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    uint64_t uVar14;
    int32_t iVar15;
    int32_t iVar16;
    int32_t iVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    int64_t iVar22;
    int32_t iVar23;
    uint32_t uVar24;
    uint64_t arg3_00;
    int64_t iVar25;
    int64_t iVar26;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar21;
    
    var_60h._0_4_ = (uint32_t)arg4;
    uVar21 = arg4 & 0xffffffff;
    var_68h._0_4_ = (uint32_t)arg3;
    arg3_00 = arg3 & 0xffffffff;
    if ((int32_t)(uint32_t)var_60h <= (int32_t)(uint32_t)var_68h) {
        return;
    }
code_r0x0001800a2ca0:
    iVar15 = (int32_t)arg3_00;
    iVar23 = (int32_t)uVar21;
    if ((int32_t)arg_28h == 0) {
        iVar23 = iVar23 - iVar15;
        iVar17 = (iVar23 + 1) / 2;
        while (iVar17 = iVar17 + -1, -1 < iVar17) {
            uVar14 = (uint64_t)var_80h >> 0x20;
            var_80h = CONCAT44((int32_t)uVar14, iVar17);
            fcn.1800a2aa0(arg1, arg2, arg3_00, uVar21, arg_30h, var_80h);
        }
        if (iVar23 < 1) {
            return;
        }
        do {
            iVar22 = *(int64_t *)(arg2 + 0x20);
            var_80h = var_80h & 0xffffffff00000000;
            puVar1 = (undefined4 *)(iVar22 + (int64_t)iVar15 * 0x10);
            uVar7 = *puVar1;
            uVar8 = puVar1[1];
            uVar9 = puVar1[2];
            uVar10 = puVar1[3];
            puVar1 = (undefined4 *)(iVar22 + (int64_t)(iVar23 + iVar15) * 0x10);
            uVar11 = puVar1[1];
            uVar12 = puVar1[2];
            uVar13 = puVar1[3];
            puVar2 = (undefined4 *)(iVar22 + (int64_t)iVar15 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar11;
            puVar2[2] = uVar12;
            puVar2[3] = uVar13;
            puVar1 = (undefined4 *)(iVar22 + (int64_t)(iVar23 + iVar15) * 0x10);
            *puVar1 = uVar7;
            puVar1[1] = uVar8;
            puVar1[2] = uVar9;
            puVar1[3] = uVar10;
            fcn.1800a2aa0(arg1, arg2, arg3_00, (uint64_t)(uint32_t)(iVar23 + -1 + iVar15), arg_30h, var_80h);
            iVar23 = iVar23 + -1;
        } while (0 < iVar23);
        return;
    }
    iVar17 = *(int32_t *)(arg2 + 8);
    iVar22 = (int64_t)iVar15;
    iVar25 = (int64_t)iVar23;
    iVar15 = (*(code *)arg_30h)(arg1, *(int64_t *)(arg2 + 0x20) + iVar25 * 0x10, 
                                *(int64_t *)(arg2 + 0x20) + iVar22 * 0x10);
    if (*(int32_t *)(arg2 + 8) == iVar17) {
        if (iVar15 != 0) {
            iVar26 = *(int64_t *)(arg2 + 0x20);
            puVar1 = (undefined4 *)(iVar26 + iVar22 * 0x10);
            uVar7 = puVar1[1];
            uVar8 = puVar1[2];
            uVar9 = puVar1[3];
            puVar2 = (undefined4 *)(iVar26 + iVar25 * 0x10);
            uVar10 = *puVar2;
            uVar11 = puVar2[1];
            uVar12 = puVar2[2];
            uVar13 = puVar2[3];
            puVar2 = (undefined4 *)(iVar26 + iVar25 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar7;
            puVar2[2] = uVar8;
            puVar2[3] = uVar9;
            puVar1 = (undefined4 *)(iVar26 + iVar22 * 0x10);
            *puVar1 = uVar10;
            puVar1[1] = uVar11;
            puVar1[2] = uVar12;
            puVar1[3] = uVar13;
        }
        iVar23 = iVar23 - (uint32_t)var_68h;
        if (iVar23 == 1) {
            return;
        }
        iVar15 = *(int32_t *)(arg2 + 8);
        iVar26 = (int64_t)(int32_t)((iVar23 >> 1) + (uint32_t)var_68h);
        iVar16 = (*(code *)arg_30h)(arg1, *(int64_t *)(arg2 + 0x20) + iVar26 * 0x10, 
                                    *(int64_t *)(arg2 + 0x20) + iVar22 * 0x10);
        iVar17 = *(int32_t *)(arg2 + 8);
        if (iVar17 == iVar15) {
            iVar4 = *(int64_t *)(arg2 + 0x20);
            puVar1 = (undefined4 *)(iVar4 + iVar26 * 0x10);
            if (iVar16 == 0) {
                iVar15 = (*(code *)arg_30h)(arg1, iVar4 + iVar25 * 0x10);
                if (*(int32_t *)(arg2 + 8) != iVar17) goto code_r0x0001800a300f;
                if (iVar15 != 0) {
                    iVar22 = *(int64_t *)(arg2 + 0x20);
                    puVar1 = (undefined4 *)(iVar22 + iVar25 * 0x10);
                    uVar7 = puVar1[1];
                    uVar8 = puVar1[2];
                    uVar9 = puVar1[3];
                    puVar2 = (undefined4 *)(iVar22 + iVar26 * 0x10);
                    uVar10 = *puVar2;
                    uVar11 = puVar2[1];
                    uVar12 = puVar2[2];
                    uVar13 = puVar2[3];
                    puVar2 = (undefined4 *)(iVar22 + iVar26 * 0x10);
                    *puVar2 = *puVar1;
                    puVar2[1] = uVar7;
                    puVar2[2] = uVar8;
                    puVar2[3] = uVar9;
                    puVar1 = (undefined4 *)(iVar22 + iVar25 * 0x10);
                    *puVar1 = uVar10;
                    puVar1[1] = uVar11;
                    puVar1[2] = uVar12;
                    puVar1[3] = uVar13;
                }
            } else {
                puVar2 = (undefined4 *)(iVar4 + iVar22 * 0x10);
                uVar7 = puVar2[1];
                uVar8 = puVar2[2];
                uVar9 = puVar2[3];
                uVar10 = *puVar1;
                uVar11 = puVar1[1];
                uVar12 = puVar1[2];
                uVar13 = puVar1[3];
                *puVar1 = *puVar2;
                puVar1[1] = uVar7;
                puVar1[2] = uVar8;
                puVar1[3] = uVar9;
                puVar1 = (undefined4 *)(iVar4 + iVar22 * 0x10);
                *puVar1 = uVar10;
                puVar1[1] = uVar11;
                puVar1[2] = uVar12;
                puVar1[3] = uVar13;
            }
            if (iVar23 == 2) {
                return;
            }
            iVar4 = *(int64_t *)(arg2 + 0x20);
            iVar22 = iVar25 * 0x10 + -0x10;
            arg3_00 = (uint64_t)(uint32_t)var_68h;
            puVar1 = (undefined4 *)(iVar4 + iVar26 * 0x10);
            uVar10 = *puVar1;
            uVar11 = puVar1[1];
            uVar12 = puVar1[2];
            uVar13 = puVar1[3];
            puVar1 = (undefined4 *)(iVar22 + iVar4);
            uVar7 = puVar1[1];
            uVar8 = puVar1[2];
            uVar9 = puVar1[3];
            puVar2 = (undefined4 *)(iVar4 + iVar26 * 0x10);
            *puVar2 = *puVar1;
            puVar2[1] = uVar7;
            puVar2[2] = uVar8;
            puVar2[3] = uVar9;
            iVar23 = (uint32_t)var_60h - 1;
            puVar1 = (undefined4 *)(iVar22 + iVar4);
            *puVar1 = uVar10;
            puVar1[1] = uVar11;
            puVar1[2] = uVar12;
            puVar1[3] = uVar13;
            uVar21 = arg3_00;
            do {
                while( true ) {
                    iVar15 = *(int32_t *)(arg2 + 8);
                    uVar19 = (uint32_t)uVar21;
                    uVar20 = uVar19 + 1;
                    uVar21 = (uint64_t)uVar20;
                    iVar17 = (*(code *)arg_30h)(arg1, *(int64_t *)(arg2 + 0x20) + (int64_t)(int32_t)uVar20 * 0x10, 
                                                *(int64_t *)(arg2 + 0x20) + iVar22);
                    if (*(int32_t *)(arg2 + 8) != iVar15) goto code_r0x0001800a300f;
                    iVar15 = *(int32_t *)(arg2 + 8);
                    if (iVar17 == 0) break;
                    if ((int32_t)(uint32_t)var_60h <= (int32_t)uVar20) {
code_r0x0001800a2ff8:
                        fcn.180088560(arg1, 0x18063eb80);
                        pcVar5 = (code *)swi(3);
                        (*pcVar5)();
                        return;
                    }
                }
                while( true ) {
                    iVar23 = iVar23 + -1;
                    iVar25 = (int64_t)iVar23;
                    iVar17 = (*(code *)arg_30h)(arg1, iVar22 + *(int64_t *)(arg2 + 0x20), 
                                                *(int64_t *)(arg2 + 0x20) + iVar25 * 0x10);
                    if (*(int32_t *)(arg2 + 8) != iVar15) goto code_r0x0001800a300f;
                    if (iVar17 == 0) break;
                    iVar15 = *(int32_t *)(arg2 + 8);
                    if (iVar23 <= (int32_t)(uint32_t)var_68h) goto code_r0x0001800a2ff8;
                }
                iVar26 = *(int64_t *)(arg2 + 0x20);
                puVar1 = (undefined4 *)(iVar26 + (int64_t)(int32_t)uVar20 * 0x10);
                if (iVar23 < (int32_t)uVar20) goto code_r0x0001800a2e88;
                uVar10 = *puVar1;
                uVar11 = puVar1[1];
                uVar12 = puVar1[2];
                uVar13 = puVar1[3];
                puVar2 = (undefined4 *)(iVar26 + iVar25 * 0x10);
                uVar7 = puVar2[1];
                uVar8 = puVar2[2];
                uVar9 = puVar2[3];
                *puVar1 = *puVar2;
                puVar1[1] = uVar7;
                puVar1[2] = uVar8;
                puVar1[3] = uVar9;
                puVar1 = (undefined4 *)(iVar26 + iVar25 * 0x10);
                *puVar1 = uVar10;
                puVar1[1] = uVar11;
                puVar1[2] = uVar12;
                puVar1[3] = uVar13;
            } while( true );
        }
    }
code_r0x0001800a300f:
    fcn.180088560(arg1, 0x18063eba8);
    pcVar5 = (code *)swi(3);
    (*pcVar5)();
    return;
code_r0x0001800a2e88:
    uVar7 = puVar1[1];
    uVar8 = puVar1[2];
    uVar9 = puVar1[3];
    puVar2 = (undefined4 *)(iVar22 + iVar26);
    uVar10 = *puVar2;
    uVar11 = puVar2[1];
    uVar12 = puVar2[2];
    uVar13 = puVar2[3];
    puVar2 = (undefined4 *)(iVar22 + iVar26);
    *puVar2 = *puVar1;
    puVar2[1] = uVar7;
    puVar2[2] = uVar8;
    puVar2[3] = uVar9;
    uVar18 = uVar19 + 2;
    uVar24 = ((int32_t)arg_28h >> 1) + ((int32_t)arg_28h >> 2);
    *puVar1 = uVar10;
    puVar1[1] = uVar11;
    puVar1[2] = uVar12;
    puVar1[3] = uVar13;
    uVar6 = uVar18;
    uVar3 = (uint32_t)var_60h;
    if ((int32_t)(uVar20 - (uint32_t)var_68h) < (int32_t)((uint32_t)var_60h - uVar20)) {
        arg3_00 = (uint64_t)uVar18;
        uVar6 = (uint32_t)var_68h;
        uVar3 = uVar19;
        var_68h._0_4_ = uVar18;
        uVar19 = (uint32_t)var_60h;
    }
    var_60h._0_4_ = uVar19;
    uVar21 = (uint64_t)(uint32_t)var_60h;
    var_80h = arg_30h;
    var_88h = CONCAT44(var_88h._4_4_, uVar24);
    fcn.1800a2c40(arg1, arg2, (uint64_t)uVar6, (uint64_t)uVar3, var_88h, arg_30h);
    arg_28h = (int64_t)uVar24;
    if ((int32_t)(uint32_t)var_60h <= (int32_t)arg3_00) {
        return;
    }
    goto code_r0x0001800a2ca0;
}

// ============================================================
// Function: FUN_1800a3020
// Address: 0x1800a3020
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

undefined8 fcn.1800a3020(int64_t arg1)
{
    int64_t arg2;
    int64_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    code *pcVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined4 in_stack_ffffffffffffffec;
    
    piVar1 = *(int64_t **)0x180782430;
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar3 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar6 = (code *)swi(3);
        uVar5 = (*pcVar6)();
        return uVar5;
    }
    arg2 = *piVar4;
    iVar2 = func_0x0001800a1110(arg2);
    if (*(char *)(arg2 + 4) != '\0') {
        func_0x000180092f10(arg1);
        pcVar6 = (code *)swi(3);
        uVar5 = (*pcVar6)();
        return uVar5;
    }
    piVar4 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    pcVar6 = (code *)0x1800a8bc0;
    piVar3 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar3 = piVar1;
    }
    if ((piVar3 != piVar1) && (0 < *(int32_t *)((int64_t)piVar3 + 0xc))) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
            piVar4 = piVar1;
        }
        if ((piVar4 == piVar1) || (*(int32_t *)((int64_t)piVar4 + 0xc) != 8)) {
            fcn.180088470(arg1, 2, 8);
            pcVar6 = (code *)swi(3);
            uVar5 = (*pcVar6)();
            return uVar5;
        }
        pcVar6 = fcn.1800a2a20;
    }
    func_0x0001800858c0(arg1, 2);
    if (0 < iVar2) {
        fcn.1800a2c40(arg1, arg2, 0, (uint64_t)(iVar2 - 1), CONCAT44(in_stack_ffffffffffffffec, iVar2), (int64_t)pcVar6)
        ;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a3056
// Address: 0x1800a3056
// Size: 175 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

undefined8 fcn.1800a3020(int64_t arg1)
{
    int64_t arg2;
    int64_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    code *pcVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined4 in_stack_ffffffffffffffec;
    
    piVar1 = *(int64_t **)0x180782430;
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar3 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar6 = (code *)swi(3);
        uVar5 = (*pcVar6)();
        return uVar5;
    }
    arg2 = *piVar4;
    iVar2 = func_0x0001800a1110(arg2);
    if (*(char *)(arg2 + 4) != '\0') {
        func_0x000180092f10(arg1);
        pcVar6 = (code *)swi(3);
        uVar5 = (*pcVar6)();
        return uVar5;
    }
    piVar4 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    pcVar6 = (code *)0x1800a8bc0;
    piVar3 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar3 = piVar1;
    }
    if ((piVar3 != piVar1) && (0 < *(int32_t *)((int64_t)piVar3 + 0xc))) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
            piVar4 = piVar1;
        }
        if ((piVar4 == piVar1) || (*(int32_t *)((int64_t)piVar4 + 0xc) != 8)) {
            fcn.180088470(arg1, 2, 8);
            pcVar6 = (code *)swi(3);
            uVar5 = (*pcVar6)();
            return uVar5;
        }
        pcVar6 = fcn.1800a2a20;
    }
    func_0x0001800858c0(arg1, 2);
    if (0 < iVar2) {
        fcn.1800a2c40(arg1, arg2, 0, (uint64_t)(iVar2 - 1), CONCAT44(in_stack_ffffffffffffffec, iVar2), (int64_t)pcVar6)
        ;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a3105
// Address: 0x1800a3105
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

undefined8 fcn.1800a3020(int64_t arg1)
{
    int64_t arg2;
    int64_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    code *pcVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined4 in_stack_ffffffffffffffec;
    
    piVar1 = *(int64_t **)0x180782430;
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar3 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar6 = (code *)swi(3);
        uVar5 = (*pcVar6)();
        return uVar5;
    }
    arg2 = *piVar4;
    iVar2 = func_0x0001800a1110(arg2);
    if (*(char *)(arg2 + 4) != '\0') {
        func_0x000180092f10(arg1);
        pcVar6 = (code *)swi(3);
        uVar5 = (*pcVar6)();
        return uVar5;
    }
    piVar4 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    pcVar6 = (code *)0x1800a8bc0;
    piVar3 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar3 = piVar1;
    }
    if ((piVar3 != piVar1) && (0 < *(int32_t *)((int64_t)piVar3 + 0xc))) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
            piVar4 = piVar1;
        }
        if ((piVar4 == piVar1) || (*(int32_t *)((int64_t)piVar4 + 0xc) != 8)) {
            fcn.180088470(arg1, 2, 8);
            pcVar6 = (code *)swi(3);
            uVar5 = (*pcVar6)();
            return uVar5;
        }
        pcVar6 = fcn.1800a2a20;
    }
    func_0x0001800858c0(arg1, 2);
    if (0 < iVar2) {
        fcn.1800a2c40(arg1, arg2, 0, (uint64_t)(iVar2 - 1), CONCAT44(in_stack_ffffffffffffffec, iVar2), (int64_t)pcVar6)
        ;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a3119
// Address: 0x1800a3119
// Size: 9 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

undefined8 fcn.1800a3020(int64_t arg1)
{
    int64_t arg2;
    int64_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    code *pcVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined4 in_stack_ffffffffffffffec;
    
    piVar1 = *(int64_t **)0x180782430;
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar3 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar6 = (code *)swi(3);
        uVar5 = (*pcVar6)();
        return uVar5;
    }
    arg2 = *piVar4;
    iVar2 = func_0x0001800a1110(arg2);
    if (*(char *)(arg2 + 4) != '\0') {
        func_0x000180092f10(arg1);
        pcVar6 = (code *)swi(3);
        uVar5 = (*pcVar6)();
        return uVar5;
    }
    piVar4 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    pcVar6 = (code *)0x1800a8bc0;
    piVar3 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar3 = piVar1;
    }
    if ((piVar3 != piVar1) && (0 < *(int32_t *)((int64_t)piVar3 + 0xc))) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
            piVar4 = piVar1;
        }
        if ((piVar4 == piVar1) || (*(int32_t *)((int64_t)piVar4 + 0xc) != 8)) {
            fcn.180088470(arg1, 2, 8);
            pcVar6 = (code *)swi(3);
            uVar5 = (*pcVar6)();
            return uVar5;
        }
        pcVar6 = fcn.1800a2a20;
    }
    func_0x0001800858c0(arg1, 2);
    if (0 < iVar2) {
        fcn.1800a2c40(arg1, arg2, 0, (uint64_t)(iVar2 - 1), CONCAT44(in_stack_ffffffffffffffec, iVar2), (int64_t)pcVar6)
        ;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a3122
// Address: 0x1800a3122
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

undefined8 fcn.1800a3020(int64_t arg1)
{
    int64_t arg2;
    int64_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    code *pcVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined4 in_stack_ffffffffffffffec;
    
    piVar1 = *(int64_t **)0x180782430;
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar3 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar6 = (code *)swi(3);
        uVar5 = (*pcVar6)();
        return uVar5;
    }
    arg2 = *piVar4;
    iVar2 = func_0x0001800a1110(arg2);
    if (*(char *)(arg2 + 4) != '\0') {
        func_0x000180092f10(arg1);
        pcVar6 = (code *)swi(3);
        uVar5 = (*pcVar6)();
        return uVar5;
    }
    piVar4 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    pcVar6 = (code *)0x1800a8bc0;
    piVar3 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar3 = piVar1;
    }
    if ((piVar3 != piVar1) && (0 < *(int32_t *)((int64_t)piVar3 + 0xc))) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
            piVar4 = piVar1;
        }
        if ((piVar4 == piVar1) || (*(int32_t *)((int64_t)piVar4 + 0xc) != 8)) {
            fcn.180088470(arg1, 2, 8);
            pcVar6 = (code *)swi(3);
            uVar5 = (*pcVar6)();
            return uVar5;
        }
        pcVar6 = fcn.1800a2a20;
    }
    func_0x0001800858c0(arg1, 2);
    if (0 < iVar2) {
        fcn.1800a2c40(arg1, arg2, 0, (uint64_t)(iVar2 - 1), CONCAT44(in_stack_ffffffffffffffec, iVar2), (int64_t)pcVar6)
        ;
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a3140
// Address: 0x1800a3140
// Size: 202 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a3140(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    int64_t var_8h;
    
    iVar8 = fcn.180088860(arg1, 1);
    if (iVar8 < 0) {
        fcn.180088380(arg1, 1, 0x18063eb68);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
    uVar10 = *(int64_t *)(arg1 + 0x28) + 0x10;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar10) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar10 + 0xc) < 1)) {
        fcn.180086fd0(arg1, iVar8, 0);
    } else {
        fcn.180086fd0(arg1, iVar8, 0);
        uVar10 = 0;
        iVar2 = *(int64_t *)(arg1 + 0x28);
        iVar3 = *(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
        if (0 < iVar8) {
            do {
                uVar5 = *(undefined4 *)(iVar2 + 0x14);
                uVar6 = *(undefined4 *)(iVar2 + 0x18);
                uVar7 = *(undefined4 *)(iVar2 + 0x1c);
                uVar11 = (int32_t)uVar10 + 1;
                puVar1 = (undefined4 *)(*(int64_t *)(iVar3 + 0x20) + uVar10 * 0x10);
                *puVar1 = *(undefined4 *)(iVar2 + 0x10);
                puVar1[1] = uVar5;
                puVar1[2] = uVar6;
                puVar1[3] = uVar7;
                uVar10 = (uint64_t)uVar11;
            } while ((int32_t)uVar11 < iVar8);
            return 1;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800a3210
// Address: 0x1800a3210
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a3210(int64_t arg1)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar2 = *(uint64_t *)(arg1 + 0x40);
    uVar8 = uVar1;
    if (uVar2 <= uVar1) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    uVar8 = uVar1 + 0x10;
    if (uVar2 <= uVar1 + 0x10) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar8 + 0xc) != -1)) {
        uVar8 = uVar1 + 0x20;
        if (uVar2 <= uVar1 + 0x20) {
            uVar8 = *(uint64_t *)0x180782430;
        }
        if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) < 1)) {
            iVar4 = 1;
        } else {
            iVar4 = fcn.180088860(arg1, 3);
            if (iVar4 < 1) {
                fcn.180088380(arg1, 3, 0x1806225f0);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
        }
        uVar7 = **(undefined8 **)(arg1 + 0x28);
        iVar6 = func_0x0001800a0d50(uVar7, iVar4);
        iVar5 = *(int32_t *)(iVar6 + 0xc);
        while (iVar5 != 0) {
            if ((*(int32_t *)(*(int64_t *)(arg1 + 0x28) + 0x1c) == *(int32_t *)(iVar6 + 0xc)) &&
               (iVar5 = func_0x0001800a8c10(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, iVar6), iVar5 != 0)) {
                func_0x0001800865e0(arg1, iVar4);
                return 1;
            }
            iVar4 = iVar4 + 1;
            iVar6 = func_0x0001800a0d50(uVar7, iVar4);
            iVar5 = *(int32_t *)(iVar6 + 0xc);
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar4 = func_0x000180085510(arg1, 1), iVar4 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 2);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a3267
// Address: 0x1800a3267
// Size: 218 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a3210(int64_t arg1)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar2 = *(uint64_t *)(arg1 + 0x40);
    uVar8 = uVar1;
    if (uVar2 <= uVar1) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    uVar8 = uVar1 + 0x10;
    if (uVar2 <= uVar1 + 0x10) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar8 + 0xc) != -1)) {
        uVar8 = uVar1 + 0x20;
        if (uVar2 <= uVar1 + 0x20) {
            uVar8 = *(uint64_t *)0x180782430;
        }
        if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) < 1)) {
            iVar4 = 1;
        } else {
            iVar4 = fcn.180088860(arg1, 3);
            if (iVar4 < 1) {
                fcn.180088380(arg1, 3, 0x1806225f0);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
        }
        uVar7 = **(undefined8 **)(arg1 + 0x28);
        iVar6 = func_0x0001800a0d50(uVar7, iVar4);
        iVar5 = *(int32_t *)(iVar6 + 0xc);
        while (iVar5 != 0) {
            if ((*(int32_t *)(*(int64_t *)(arg1 + 0x28) + 0x1c) == *(int32_t *)(iVar6 + 0xc)) &&
               (iVar5 = func_0x0001800a8c10(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, iVar6), iVar5 != 0)) {
                func_0x0001800865e0(arg1, iVar4);
                return 1;
            }
            iVar4 = iVar4 + 1;
            iVar6 = func_0x0001800a0d50(uVar7, iVar4);
            iVar5 = *(int32_t *)(iVar6 + 0xc);
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar4 = func_0x000180085510(arg1, 1), iVar4 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 2);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a3341
// Address: 0x1800a3341
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a3210(int64_t arg1)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar2 = *(uint64_t *)(arg1 + 0x40);
    uVar8 = uVar1;
    if (uVar2 <= uVar1) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    uVar8 = uVar1 + 0x10;
    if (uVar2 <= uVar1 + 0x10) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar8 + 0xc) != -1)) {
        uVar8 = uVar1 + 0x20;
        if (uVar2 <= uVar1 + 0x20) {
            uVar8 = *(uint64_t *)0x180782430;
        }
        if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) < 1)) {
            iVar4 = 1;
        } else {
            iVar4 = fcn.180088860(arg1, 3);
            if (iVar4 < 1) {
                fcn.180088380(arg1, 3, 0x1806225f0);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
        }
        uVar7 = **(undefined8 **)(arg1 + 0x28);
        iVar6 = func_0x0001800a0d50(uVar7, iVar4);
        iVar5 = *(int32_t *)(iVar6 + 0xc);
        while (iVar5 != 0) {
            if ((*(int32_t *)(*(int64_t *)(arg1 + 0x28) + 0x1c) == *(int32_t *)(iVar6 + 0xc)) &&
               (iVar5 = func_0x0001800a8c10(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, iVar6), iVar5 != 0)) {
                func_0x0001800865e0(arg1, iVar4);
                return 1;
            }
            iVar4 = iVar4 + 1;
            iVar6 = func_0x0001800a0d50(uVar7, iVar4);
            iVar5 = *(int32_t *)(iVar6 + 0xc);
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar4 = func_0x000180085510(arg1, 1), iVar4 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 2);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a3353
// Address: 0x1800a3353
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a3210(int64_t arg1)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar2 = *(uint64_t *)(arg1 + 0x40);
    uVar8 = uVar1;
    if (uVar2 <= uVar1) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    uVar8 = uVar1 + 0x10;
    if (uVar2 <= uVar1 + 0x10) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar8 + 0xc) != -1)) {
        uVar8 = uVar1 + 0x20;
        if (uVar2 <= uVar1 + 0x20) {
            uVar8 = *(uint64_t *)0x180782430;
        }
        if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) < 1)) {
            iVar4 = 1;
        } else {
            iVar4 = fcn.180088860(arg1, 3);
            if (iVar4 < 1) {
                fcn.180088380(arg1, 3, 0x1806225f0);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
        }
        uVar7 = **(undefined8 **)(arg1 + 0x28);
        iVar6 = func_0x0001800a0d50(uVar7, iVar4);
        iVar5 = *(int32_t *)(iVar6 + 0xc);
        while (iVar5 != 0) {
            if ((*(int32_t *)(*(int64_t *)(arg1 + 0x28) + 0x1c) == *(int32_t *)(iVar6 + 0xc)) &&
               (iVar5 = func_0x0001800a8c10(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, iVar6), iVar5 != 0)) {
                func_0x0001800865e0(arg1, iVar4);
                return 1;
            }
            iVar4 = iVar4 + 1;
            iVar6 = func_0x0001800a0d50(uVar7, iVar4);
            iVar5 = *(int32_t *)(iVar6 + 0xc);
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar4 = func_0x000180085510(arg1, 1), iVar4 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 2);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a3367
// Address: 0x1800a3367
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a3210(int64_t arg1)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar2 = *(uint64_t *)(arg1 + 0x40);
    uVar8 = uVar1;
    if (uVar2 <= uVar1) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    uVar8 = uVar1 + 0x10;
    if (uVar2 <= uVar1 + 0x10) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar8 + 0xc) != -1)) {
        uVar8 = uVar1 + 0x20;
        if (uVar2 <= uVar1 + 0x20) {
            uVar8 = *(uint64_t *)0x180782430;
        }
        if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) < 1)) {
            iVar4 = 1;
        } else {
            iVar4 = fcn.180088860(arg1, 3);
            if (iVar4 < 1) {
                fcn.180088380(arg1, 3, 0x1806225f0);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
        }
        uVar7 = **(undefined8 **)(arg1 + 0x28);
        iVar6 = func_0x0001800a0d50(uVar7, iVar4);
        iVar5 = *(int32_t *)(iVar6 + 0xc);
        while (iVar5 != 0) {
            if ((*(int32_t *)(*(int64_t *)(arg1 + 0x28) + 0x1c) == *(int32_t *)(iVar6 + 0xc)) &&
               (iVar5 = func_0x0001800a8c10(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, iVar6), iVar5 != 0)) {
                func_0x0001800865e0(arg1, iVar4);
                return 1;
            }
            iVar4 = iVar4 + 1;
            iVar6 = func_0x0001800a0d50(uVar7, iVar4);
            iVar5 = *(int32_t *)(iVar6 + 0xc);
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar4 = func_0x000180085510(arg1, 1), iVar4 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 2);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a337c
// Address: 0x1800a337c
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a3210(int64_t arg1)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar2 = *(uint64_t *)(arg1 + 0x40);
    uVar8 = uVar1;
    if (uVar2 <= uVar1) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    uVar8 = uVar1 + 0x10;
    if (uVar2 <= uVar1 + 0x10) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar8 + 0xc) != -1)) {
        uVar8 = uVar1 + 0x20;
        if (uVar2 <= uVar1 + 0x20) {
            uVar8 = *(uint64_t *)0x180782430;
        }
        if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) < 1)) {
            iVar4 = 1;
        } else {
            iVar4 = fcn.180088860(arg1, 3);
            if (iVar4 < 1) {
                fcn.180088380(arg1, 3, 0x1806225f0);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
        }
        uVar7 = **(undefined8 **)(arg1 + 0x28);
        iVar6 = func_0x0001800a0d50(uVar7, iVar4);
        iVar5 = *(int32_t *)(iVar6 + 0xc);
        while (iVar5 != 0) {
            if ((*(int32_t *)(*(int64_t *)(arg1 + 0x28) + 0x1c) == *(int32_t *)(iVar6 + 0xc)) &&
               (iVar5 = func_0x0001800a8c10(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, iVar6), iVar5 != 0)) {
                func_0x0001800865e0(arg1, iVar4);
                return 1;
            }
            iVar4 = iVar4 + 1;
            iVar6 = func_0x0001800a0d50(uVar7, iVar4);
            iVar5 = *(int32_t *)(iVar6 + 0xc);
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar4 = func_0x000180085510(arg1, 1), iVar4 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 2);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a3394
// Address: 0x1800a3394
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a3210(int64_t arg1)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar2 = *(uint64_t *)(arg1 + 0x40);
    uVar8 = uVar1;
    if (uVar2 <= uVar1) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    uVar8 = uVar1 + 0x10;
    if (uVar2 <= uVar1 + 0x10) {
        uVar8 = *(uint64_t *)0x180782430;
    }
    if ((uVar8 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar8 + 0xc) != -1)) {
        uVar8 = uVar1 + 0x20;
        if (uVar2 <= uVar1 + 0x20) {
            uVar8 = *(uint64_t *)0x180782430;
        }
        if ((uVar8 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar8 + 0xc) < 1)) {
            iVar4 = 1;
        } else {
            iVar4 = fcn.180088860(arg1, 3);
            if (iVar4 < 1) {
                fcn.180088380(arg1, 3, 0x1806225f0);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
        }
        uVar7 = **(undefined8 **)(arg1 + 0x28);
        iVar6 = func_0x0001800a0d50(uVar7, iVar4);
        iVar5 = *(int32_t *)(iVar6 + 0xc);
        while (iVar5 != 0) {
            if ((*(int32_t *)(*(int64_t *)(arg1 + 0x28) + 0x1c) == *(int32_t *)(iVar6 + 0xc)) &&
               (iVar5 = func_0x0001800a8c10(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, iVar6), iVar5 != 0)) {
                func_0x0001800865e0(arg1, iVar4);
                return 1;
            }
            iVar4 = iVar4 + 1;
            iVar6 = func_0x0001800a0d50(uVar7, iVar4);
            iVar5 = *(int32_t *)(iVar6 + 0xc);
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar4 = func_0x000180085510(arg1, 1), iVar4 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 2);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a33b0
// Address: 0x1800a33b0
// Size: 85 bytes
// ============================================================
undefined8 fcn.1800a33b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar1;
    if (*(int64_t **)(arg1 + 0x40) <= piVar1) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 7)) {
        if (*(char *)(*piVar1 + 4) == '\0') {
            fcn.1800a13b0(*piVar1);
            return 0;
        }
        fcn.180092f10();
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a3410
// Address: 0x1800a3410
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a3410(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar9 = piVar7;
    if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(char *)(*piVar7 + 4) != '\0') {
        fcn.180088380(arg1, 1, 0x18063ec20);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    iVar6 = func_0x000180087120();
    piVar7 = *(int64_t **)0x180782430;
    if (iVar6 != 0) {
        func_0x0001800867f0(arg1, 0x1806224a0, 0xb);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar1 = *(int64_t *)(arg1 + 0x40);
        puVar8 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
        piVar7 = *(int64_t **)0x180782430;
        uVar3 = puVar8[1];
        uVar4 = puVar8[2];
        uVar5 = puVar8[3];
        *(undefined4 *)(iVar1 + -0x10) = *puVar8;
        *(undefined4 *)(iVar1 + -0xc) = uVar3;
        *(undefined4 *)(iVar1 + -8) = uVar4;
        *(undefined4 *)(iVar1 + -4) = uVar5;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        piVar9 = piVar11 + -2;
        if ((piVar9 == piVar7) || (*(int32_t *)((int64_t)piVar11 + -4) != 0)) {
            if (piVar9 < piVar11) {
                do {
                    uVar3 = *(undefined4 *)(piVar9 + 1);
                    uVar4 = *(undefined4 *)((int64_t)piVar9 + 0xc);
                    *(undefined4 *)(piVar9 + -2) = *(undefined4 *)piVar9;
                    *(undefined4 *)((int64_t)piVar9 - 0xc) = *(undefined4 *)((int64_t)piVar9 + 4);
                    *(undefined4 *)(piVar9 + -1) = uVar3;
                    *(undefined4 *)((int64_t)piVar9 - 4) = uVar4;
                    piVar11 = *(int64_t **)(arg1 + 0x40);
                    piVar9 = piVar9 + 2;
                } while (piVar9 < piVar11);
            }
            *(int64_t **)(arg1 + 0x40) = piVar11 + -2;
            fcn.180088380(arg1, 1, 0x18063ec00);
            pcVar2 = (code *)swi(3);
            uVar10 = (*pcVar2)();
            return uVar10;
        }
        *(int64_t **)(arg1 + 0x40) = piVar11 + -4;
    }
    piVar9 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar9 = piVar7;
    }
    *(undefined *)(*piVar9 + 4) = 1;
    func_0x000180085bf0(arg1, 1);
    return 1;
}

// ============================================================
// Function: FUN_1800a3474
// Address: 0x1800a3474
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a3410(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar9 = piVar7;
    if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(char *)(*piVar7 + 4) != '\0') {
        fcn.180088380(arg1, 1, 0x18063ec20);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    iVar6 = func_0x000180087120();
    piVar7 = *(int64_t **)0x180782430;
    if (iVar6 != 0) {
        func_0x0001800867f0(arg1, 0x1806224a0, 0xb);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar1 = *(int64_t *)(arg1 + 0x40);
        puVar8 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
        piVar7 = *(int64_t **)0x180782430;
        uVar3 = puVar8[1];
        uVar4 = puVar8[2];
        uVar5 = puVar8[3];
        *(undefined4 *)(iVar1 + -0x10) = *puVar8;
        *(undefined4 *)(iVar1 + -0xc) = uVar3;
        *(undefined4 *)(iVar1 + -8) = uVar4;
        *(undefined4 *)(iVar1 + -4) = uVar5;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        piVar9 = piVar11 + -2;
        if ((piVar9 == piVar7) || (*(int32_t *)((int64_t)piVar11 + -4) != 0)) {
            if (piVar9 < piVar11) {
                do {
                    uVar3 = *(undefined4 *)(piVar9 + 1);
                    uVar4 = *(undefined4 *)((int64_t)piVar9 + 0xc);
                    *(undefined4 *)(piVar9 + -2) = *(undefined4 *)piVar9;
                    *(undefined4 *)((int64_t)piVar9 - 0xc) = *(undefined4 *)((int64_t)piVar9 + 4);
                    *(undefined4 *)(piVar9 + -1) = uVar3;
                    *(undefined4 *)((int64_t)piVar9 - 4) = uVar4;
                    piVar11 = *(int64_t **)(arg1 + 0x40);
                    piVar9 = piVar9 + 2;
                } while (piVar9 < piVar11);
            }
            *(int64_t **)(arg1 + 0x40) = piVar11 + -2;
            fcn.180088380(arg1, 1, 0x18063ec00);
            pcVar2 = (code *)swi(3);
            uVar10 = (*pcVar2)();
            return uVar10;
        }
        *(int64_t **)(arg1 + 0x40) = piVar11 + -4;
    }
    piVar9 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar9 = piVar7;
    }
    *(undefined *)(*piVar9 + 4) = 1;
    func_0x000180085bf0(arg1, 1);
    return 1;
}

// ============================================================
// Function: FUN_1800a34d8
// Address: 0x1800a34d8
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a3410(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar9 = piVar7;
    if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(char *)(*piVar7 + 4) != '\0') {
        fcn.180088380(arg1, 1, 0x18063ec20);
        pcVar2 = (code *)swi(3);
        uVar10 = (*pcVar2)();
        return uVar10;
    }
    iVar6 = func_0x000180087120();
    piVar7 = *(int64_t **)0x180782430;
    if (iVar6 != 0) {
        func_0x0001800867f0(arg1, 0x1806224a0, 0xb);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar1 = *(int64_t *)(arg1 + 0x40);
        puVar8 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
        piVar7 = *(int64_t **)0x180782430;
        uVar3 = puVar8[1];
        uVar4 = puVar8[2];
        uVar5 = puVar8[3];
        *(undefined4 *)(iVar1 + -0x10) = *puVar8;
        *(undefined4 *)(iVar1 + -0xc) = uVar3;
        *(undefined4 *)(iVar1 + -8) = uVar4;
        *(undefined4 *)(iVar1 + -4) = uVar5;
        piVar11 = *(int64_t **)(arg1 + 0x40);
        piVar9 = piVar11 + -2;
        if ((piVar9 == piVar7) || (*(int32_t *)((int64_t)piVar11 + -4) != 0)) {
            if (piVar9 < piVar11) {
                do {
                    uVar3 = *(undefined4 *)(piVar9 + 1);
                    uVar4 = *(undefined4 *)((int64_t)piVar9 + 0xc);
                    *(undefined4 *)(piVar9 + -2) = *(undefined4 *)piVar9;
                    *(undefined4 *)((int64_t)piVar9 - 0xc) = *(undefined4 *)((int64_t)piVar9 + 4);
                    *(undefined4 *)(piVar9 + -1) = uVar3;
                    *(undefined4 *)((int64_t)piVar9 - 4) = uVar4;
                    piVar11 = *(int64_t **)(arg1 + 0x40);
                    piVar9 = piVar9 + 2;
                } while (piVar9 < piVar11);
            }
            *(int64_t **)(arg1 + 0x40) = piVar11 + -2;
            fcn.180088380(arg1, 1, 0x18063ec00);
            pcVar2 = (code *)swi(3);
            uVar10 = (*pcVar2)();
            return uVar10;
        }
        *(int64_t **)(arg1 + 0x40) = piVar11 + -4;
    }
    piVar9 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar9 = piVar7;
    }
    *(undefined *)(*piVar9 + 4) = 1;
    func_0x000180085bf0(arg1, 1);
    return 1;
}

// ============================================================
// Function: FUN_1800a3580
// Address: 0x1800a3580
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a3580(int64_t arg1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined4 *puVar8;
    undefined8 uVar9;
    undefined4 *puVar10;
    int64_t var_10h;
    undefined4 uStack_10;
    
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 == *(undefined4 **)0x180782430) || (puVar8[3] != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = func_0x000180087120(arg1, 1);
    if (iVar7 != 0) {
        func_0x0001800867f0(arg1, 0x1806224a0, 0xb);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar1 = *(int64_t *)(arg1 + 0x40);
        puVar8 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
        uVar4 = puVar8[1];
        uVar5 = puVar8[2];
        uVar6 = puVar8[3];
        *(undefined4 *)(iVar1 + -0x10) = *puVar8;
        *(undefined4 *)(iVar1 + -0xc) = uVar4;
        *(undefined4 *)(iVar1 + -8) = uVar5;
        *(undefined4 *)(iVar1 + -4) = uVar6;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        puVar8 = puVar10 + -4;
        if ((puVar8 == *(undefined4 **)0x180782430) || (puVar10[-1] != 0)) {
            if (puVar8 < puVar10) {
                do {
                    puVar8[-4] = *puVar8;
                    puVar8[-3] = puVar8[1];
                    puVar8[-2] = puVar8[2];
                    puVar8[-1] = puVar8[3];
                    puVar10 = *(undefined4 **)(arg1 + 0x40);
                    puVar8 = puVar8 + 4;
                } while (puVar8 < puVar10);
            }
            *(undefined4 **)(arg1 + 0x40) = puVar10 + -4;
            fcn.180088380(arg1, 1, 0x18063ec00);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        *(undefined4 **)(arg1 + 0x40) = puVar10 + -8;
    }
    uVar9 = func_0x0001800a1260(arg1, **(undefined8 **)(arg1 + 0x28));
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar7 = func_0x000180085510(arg1, 1), iVar7 == 0)) {
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    puVar2 = *(undefined8 **)(arg1 + 0x40);
    *puVar2 = uVar9;
    *(undefined4 *)(puVar2 + 1) = uStack_10;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 7;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_1800a35b5
// Address: 0x1800a35b5
// Size: 267 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a3580(int64_t arg1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined4 *puVar8;
    undefined8 uVar9;
    undefined4 *puVar10;
    int64_t var_10h;
    undefined4 uStack_10;
    
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 == *(undefined4 **)0x180782430) || (puVar8[3] != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = func_0x000180087120(arg1, 1);
    if (iVar7 != 0) {
        func_0x0001800867f0(arg1, 0x1806224a0, 0xb);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar1 = *(int64_t *)(arg1 + 0x40);
        puVar8 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
        uVar4 = puVar8[1];
        uVar5 = puVar8[2];
        uVar6 = puVar8[3];
        *(undefined4 *)(iVar1 + -0x10) = *puVar8;
        *(undefined4 *)(iVar1 + -0xc) = uVar4;
        *(undefined4 *)(iVar1 + -8) = uVar5;
        *(undefined4 *)(iVar1 + -4) = uVar6;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        puVar8 = puVar10 + -4;
        if ((puVar8 == *(undefined4 **)0x180782430) || (puVar10[-1] != 0)) {
            if (puVar8 < puVar10) {
                do {
                    puVar8[-4] = *puVar8;
                    puVar8[-3] = puVar8[1];
                    puVar8[-2] = puVar8[2];
                    puVar8[-1] = puVar8[3];
                    puVar10 = *(undefined4 **)(arg1 + 0x40);
                    puVar8 = puVar8 + 4;
                } while (puVar8 < puVar10);
            }
            *(undefined4 **)(arg1 + 0x40) = puVar10 + -4;
            fcn.180088380(arg1, 1, 0x18063ec00);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        *(undefined4 **)(arg1 + 0x40) = puVar10 + -8;
    }
    uVar9 = func_0x0001800a1260(arg1, **(undefined8 **)(arg1 + 0x28));
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar7 = func_0x000180085510(arg1, 1), iVar7 == 0)) {
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    puVar2 = *(undefined8 **)(arg1 + 0x40);
    *puVar2 = uVar9;
    *(undefined4 *)(puVar2 + 1) = uStack_10;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 7;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_1800a36c0
// Address: 0x1800a36c0
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a3580(int64_t arg1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined4 *puVar8;
    undefined8 uVar9;
    undefined4 *puVar10;
    int64_t var_10h;
    undefined4 uStack_10;
    
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 == *(undefined4 **)0x180782430) || (puVar8[3] != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = func_0x000180087120(arg1, 1);
    if (iVar7 != 0) {
        func_0x0001800867f0(arg1, 0x1806224a0, 0xb);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar1 = *(int64_t *)(arg1 + 0x40);
        puVar8 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
        uVar4 = puVar8[1];
        uVar5 = puVar8[2];
        uVar6 = puVar8[3];
        *(undefined4 *)(iVar1 + -0x10) = *puVar8;
        *(undefined4 *)(iVar1 + -0xc) = uVar4;
        *(undefined4 *)(iVar1 + -8) = uVar5;
        *(undefined4 *)(iVar1 + -4) = uVar6;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        puVar8 = puVar10 + -4;
        if ((puVar8 == *(undefined4 **)0x180782430) || (puVar10[-1] != 0)) {
            if (puVar8 < puVar10) {
                do {
                    puVar8[-4] = *puVar8;
                    puVar8[-3] = puVar8[1];
                    puVar8[-2] = puVar8[2];
                    puVar8[-1] = puVar8[3];
                    puVar10 = *(undefined4 **)(arg1 + 0x40);
                    puVar8 = puVar8 + 4;
                } while (puVar8 < puVar10);
            }
            *(undefined4 **)(arg1 + 0x40) = puVar10 + -4;
            fcn.180088380(arg1, 1, 0x18063ec00);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        *(undefined4 **)(arg1 + 0x40) = puVar10 + -8;
    }
    uVar9 = func_0x0001800a1260(arg1, **(undefined8 **)(arg1 + 0x28));
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar7 = func_0x000180085510(arg1, 1), iVar7 == 0)) {
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    puVar2 = *(undefined8 **)(arg1 + 0x40);
    *puVar2 = uVar9;
    *(undefined4 *)(puVar2 + 1) = uStack_10;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 7;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_1800a36d4
// Address: 0x1800a36d4
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a3580(int64_t arg1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined4 *puVar8;
    undefined8 uVar9;
    undefined4 *puVar10;
    int64_t var_10h;
    undefined4 uStack_10;
    
    puVar8 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar8 = *(undefined4 **)0x180782430;
    }
    if ((puVar8 == *(undefined4 **)0x180782430) || (puVar8[3] != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    iVar7 = func_0x000180087120(arg1, 1);
    if (iVar7 != 0) {
        func_0x0001800867f0(arg1, 0x1806224a0, 0xb);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar1 = *(int64_t *)(arg1 + 0x40);
        puVar8 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
        uVar4 = puVar8[1];
        uVar5 = puVar8[2];
        uVar6 = puVar8[3];
        *(undefined4 *)(iVar1 + -0x10) = *puVar8;
        *(undefined4 *)(iVar1 + -0xc) = uVar4;
        *(undefined4 *)(iVar1 + -8) = uVar5;
        *(undefined4 *)(iVar1 + -4) = uVar6;
        puVar10 = *(undefined4 **)(arg1 + 0x40);
        puVar8 = puVar10 + -4;
        if ((puVar8 == *(undefined4 **)0x180782430) || (puVar10[-1] != 0)) {
            if (puVar8 < puVar10) {
                do {
                    puVar8[-4] = *puVar8;
                    puVar8[-3] = puVar8[1];
                    puVar8[-2] = puVar8[2];
                    puVar8[-1] = puVar8[3];
                    puVar10 = *(undefined4 **)(arg1 + 0x40);
                    puVar8 = puVar8 + 4;
                } while (puVar8 < puVar10);
            }
            *(undefined4 **)(arg1 + 0x40) = puVar10 + -4;
            fcn.180088380(arg1, 1, 0x18063ec00);
            pcVar3 = (code *)swi(3);
            uVar9 = (*pcVar3)();
            return uVar9;
        }
        *(undefined4 **)(arg1 + 0x40) = puVar10 + -8;
    }
    uVar9 = func_0x0001800a1260(arg1, **(undefined8 **)(arg1 + 0x28));
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar7 = func_0x000180085510(arg1, 1), iVar7 == 0)) {
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar9 = (*pcVar3)();
        return uVar9;
    }
    puVar2 = *(undefined8 **)(arg1 + 0x40);
    *puVar2 = uVar9;
    *(undefined4 *)(puVar2 + 1) = uStack_10;
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 7;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_1800a3710
// Address: 0x1800a3710
// Size: 499 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.1800a3710(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined8 uVar5;
    undefined4 *puVar6;
    undefined8 *puVar7;
    int32_t iVar8;
    int64_t var_38h;
    
    puVar7 = (undefined8 *)0x180612b80;
    iVar8 = 0;
    piVar2 = (int64_t *)0x180612b80;
    do {
        iVar8 = iVar8 + 1;
        piVar2 = piVar2 + 2;
    } while (*piVar2 != 0);
    func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
    func_0x000180086cc0(arg1, 0xffffffff, 0x180622fb4);
    iVar3 = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((iVar3 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
        *(int64_t *)(arg1 + 0x40) = iVar3;
        iVar3 = func_0x000180088ce0(arg1, 0xffffd8ee, 0x180622fb4, iVar8);
        if (iVar3 != 0) {
            fcn.180088560(arg1, 0x18063da68, 0x180622fb4);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = func_0x000180085510(arg1, 1), iVar8 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        *puVar4 = puVar4[-4];
        puVar4[1] = puVar4[-3];
        puVar4[2] = puVar4[-2];
        puVar4[3] = puVar4[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffd, 0x180622fb4);
    }
    puVar6 = *(undefined4 **)(arg1 + 0x40);
    puVar4 = puVar6 + -4;
    if (puVar4 < puVar6) {
        do {
            puVar4[-4] = *puVar4;
            puVar4[-3] = puVar4[1];
            puVar4[-2] = puVar4[2];
            puVar4[-1] = puVar4[3];
            puVar6 = *(undefined4 **)(arg1 + 0x40);
            puVar4 = puVar4 + 4;
        } while (puVar4 < puVar6);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar6 + -4;
    iVar3 = 0x18063c304;
    do {
        func_0x0001800869f0(arg1, puVar7[1], iVar3, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, *puVar7);
        iVar3 = puVar7[2];
        puVar7 = puVar7 + 2;
    } while (iVar3 != 0);
    func_0x0001800869f0(arg1, fcn.1800a2850, 0x18062622c, 0, 0);
    func_0x000180087370(arg1, 0xffffd8ee, 0x18062622c);
    return 1;
}

// ============================================================
// Function: FUN_1800a3910
// Address: 0x1800a3910
// Size: 201 bytes
// ============================================================
undefined8 fcn.1800a3910(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar6;
    if (piVar1 <= piVar6) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    piVar3 = piVar6 + 2;
    piVar4 = piVar3;
    if (piVar1 <= piVar3) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 0xc)) {
        if (piVar1 <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (piVar6 == *(int64_t **)0x180782430) {
            piVar6 = (int64_t *)0x0;
        }
        if (piVar1 <= piVar3) {
            piVar3 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xd) {
            if (piVar3 == *(int64_t **)0x180782430) {
                piVar3 = (int64_t *)0x0;
            }
            if (*(int64_t *)(*piVar6 + 0x10) == *piVar3) {
                fcn.180086b20(arg1, 1);
                return 1;
            }
        }
        fcn.180086b20(arg1, 0);
        return 1;
    }
    fcn.180088470(arg1, 2, 0xc);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_1800a39e0
// Address: 0x1800a39e0
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a39e0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar5;
    if (piVar1 <= piVar5) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar5;
    if (piVar1 <= piVar5) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 0xd)) {
        if (piVar1 <= piVar5) {
            piVar5 = *(int64_t **)0x180782430;
        }
        if (piVar5 == *(int64_t **)0x180782430) {
            piVar5 = (int64_t *)0x0;
        }
        uVar6 = *(undefined8 *)(*piVar5 + 0x10);
        if ((*(char *)0x180777010 != '\0') && (**(int64_t ***)(arg1 + 0x18) < piVar1 + 2)) {
            iVar4 = fcn.180085510(in_stack_00000010);
            if (iVar4 == 0) {
                fcn.180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
        }
        puVar2 = *(undefined8 **)(arg1 + 0x40);
        *puVar2 = uVar6;
        *(undefined4 *)((int64_t)puVar2 + 0xc) = 0xc;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    fcn.180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_1800a3a2d
// Address: 0x1800a3a2d
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a39e0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar5;
    if (piVar1 <= piVar5) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar5;
    if (piVar1 <= piVar5) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 0xd)) {
        if (piVar1 <= piVar5) {
            piVar5 = *(int64_t **)0x180782430;
        }
        if (piVar5 == *(int64_t **)0x180782430) {
            piVar5 = (int64_t *)0x0;
        }
        uVar6 = *(undefined8 *)(*piVar5 + 0x10);
        if ((*(char *)0x180777010 != '\0') && (**(int64_t ***)(arg1 + 0x18) < piVar1 + 2)) {
            iVar4 = fcn.180085510(in_stack_00000010);
            if (iVar4 == 0) {
                fcn.180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
        }
        puVar2 = *(undefined8 **)(arg1 + 0x40);
        *puVar2 = uVar6;
        *(undefined4 *)((int64_t)puVar2 + 0xc) = 0xc;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    fcn.180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_1800a3a8f
// Address: 0x1800a3a8f
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a39e0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar5;
    if (piVar1 <= piVar5) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar5;
    if (piVar1 <= piVar5) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 0xd)) {
        if (piVar1 <= piVar5) {
            piVar5 = *(int64_t **)0x180782430;
        }
        if (piVar5 == *(int64_t **)0x180782430) {
            piVar5 = (int64_t *)0x0;
        }
        uVar6 = *(undefined8 *)(*piVar5 + 0x10);
        if ((*(char *)0x180777010 != '\0') && (**(int64_t ***)(arg1 + 0x18) < piVar1 + 2)) {
            iVar4 = fcn.180085510(in_stack_00000010);
            if (iVar4 == 0) {
                fcn.180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
        }
        puVar2 = *(undefined8 **)(arg1 + 0x40);
        *puVar2 = uVar6;
        *(undefined4 *)((int64_t)puVar2 + 0xc) = 0xc;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    fcn.180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_1800a3ab8
// Address: 0x1800a3ab8
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a39e0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar5;
    if (piVar1 <= piVar5) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar5;
    if (piVar1 <= piVar5) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 0xd)) {
        if (piVar1 <= piVar5) {
            piVar5 = *(int64_t **)0x180782430;
        }
        if (piVar5 == *(int64_t **)0x180782430) {
            piVar5 = (int64_t *)0x0;
        }
        uVar6 = *(undefined8 *)(*piVar5 + 0x10);
        if ((*(char *)0x180777010 != '\0') && (**(int64_t ***)(arg1 + 0x18) < piVar1 + 2)) {
            iVar4 = fcn.180085510(in_stack_00000010);
            if (iVar4 == 0) {
                fcn.180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
        }
        puVar2 = *(undefined8 **)(arg1 + 0x40);
        *puVar2 = uVar6;
        *(undefined4 *)((int64_t)puVar2 + 0xc) = 0xc;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
    fcn.180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_1800a3ad0
// Address: 0x1800a3ad0
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800a3ad0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t var_8h;
    
    iVar1 = fcn.1800a0e30(arg1, arg3);
    if (*(int32_t *)(iVar1 + 0xc) == 0) {
        *(uint8_t *)(arg1 + 5) = *(uint8_t *)(arg1 + 5) | (uint8_t)(1 << ((uint32_t)arg2 & 0x1f));
        iVar1 = 0;
    }
    return iVar1;
}

