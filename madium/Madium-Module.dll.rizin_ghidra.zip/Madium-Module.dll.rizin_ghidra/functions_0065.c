// Chunk 65 - 50 functions

// ============================================================
// Function: FUN_1800cfe30
// Address: 0x1800cfe30
// Size: 71 bytes
// ============================================================
void fcn.1800cfe30(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    uint32_t *puVar3;
    uint32_t **ppuVar4;
    uint64_t uVar5;
    uint32_t *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    uint32_t *puVar12;
    uint8_t in_R8B;
    int64_t iVar13;
    uint32_t in_R9D;
    uint32_t uVar14;
    uint32_t *puVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_80 [3];
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    
    ppuVar4 = (uint32_t **)(arg1 + 0x28);
    uVar14 = ((in_R9D & 0xffff) << 8 | (uint32_t)in_R8B) << 8 | (uint32_t)arg2;
    puVar8 = auStack_68;
    puVar9 = auStack_68;
    puVar15 = *(uint32_t **)(arg1 + 0x30);
    if (puVar15 != *(uint32_t **)(arg1 + 0x38)) {
        *puVar15 = uVar14;
        *(int64_t *)(arg1 + 0x30) = *(int64_t *)(arg1 + 0x30) + 4;
        return;
    }
    iVar16 = (int64_t)puVar15 - (int64_t)*ppuVar4 >> 2;
    if (iVar16 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar5 = (int64_t)*(uint32_t **)(arg1 + 0x38) - (int64_t)*ppuVar4 >> 2;
    if (uVar5 <= 0x3fffffffffffffff - (uVar5 >> 1)) {
        uVar1 = iVar16 + 1;
        uVar5 = uVar5 + (uVar5 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar5) {
            uVar10 = uVar5;
        }
        if (uVar10 < 0x4000000000000000) {
            uVar5 = uVar10 * 4;
            if (uVar5 == 0) {
                puVar12 = (uint32_t *)0x0;
                puVar9 = auStack_68;
            } else if (uVar5 < 0x1000) {
                puVar12 = (uint32_t *)fcn.180459890();
            } else {
                if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800d32fa;
                iVar13 = fcn.180459890(uVar5 + 0x27);
                if (iVar13 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar13 = (*pcVar2)(5);
                    puVar8 = auStack_60;
                }
                puVar12 = (uint32_t *)(iVar13 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -2) = iVar13;
                puVar9 = puVar8;
            }
            puVar12[iVar16] = uVar14;
            puVar3 = *ppuVar4;
            if (puVar15 == *(uint32_t **)(arg1 + 0x30)) {
                iVar13 = (int64_t)*(uint32_t **)(arg1 + 0x30) - (int64_t)puVar3;
                puVar6 = puVar12;
                puVar15 = puVar3;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x1800d32b0;
                fcn.180498030(puVar12, puVar3, (int64_t)puVar15 - (int64_t)puVar3);
                iVar13 = *(int64_t *)(arg1 + 0x30) - (int64_t)puVar15;
                puVar6 = puVar12 + iVar16 + 1;
            }
            *(undefined8 *)(puVar9 + -8) = 0x1800d32c7;
            fcn.180498030(puVar6, puVar15, iVar13);
            uVar11 = *(undefined8 *)(puVar9 + 0x28);
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar9 + 0x30);
            *(undefined8 *)(puVar9 + 0x28) = *(undefined8 *)(puVar9 + 0x40);
            *(undefined8 *)(puVar9 + 0x20) = uVar11;
            *(undefined8 *)(puVar9 + 0x18) = *(undefined8 *)(puVar9 + 0x48);
            puVar15 = *ppuVar4;
            if (puVar15 != (uint32_t *)0x0) {
                puVar3 = puVar15;
                puVar7 = puVar9 + -0x10;
                if (0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x38) - (int64_t)puVar15 >> 2) * 4)) {
                    puVar3 = *(uint32_t **)(puVar15 + -2);
                    puVar15 = (uint32_t *)((int64_t)puVar15 + (-8 - (int64_t)puVar3));
                    puVar7 = puVar9 + -0x10;
                    if ((uint32_t *)0x1f < puVar15) {
                        pcVar2 = (code *)swi(0x29);
                        puVar3 = puVar15;
                        (*pcVar2)(5);
                        puVar7 = puVar9 + -8;
                    }
                }
                *(undefined8 *)(puVar7 + -8) = 0x180030d9f;
                fcn.180459c3c(puVar3);
            }
            *ppuVar4 = puVar12;
            *(uint32_t **)(arg1 + 0x30) = puVar12 + uVar1;
            *(uint32_t **)(arg1 + 0x38) = puVar12 + uVar10;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800cfe80
// Address: 0x1800cfe80
// Size: 47 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001800cfe95: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001800cfe9a)

void fcn.1800cfe80(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    undefined4 *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t var_10h;
    undefined8 auStack_80 [3];
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    
    puVar5 = (uint64_t *)(arg1 + 0x28);
    puVar9 = auStack_68;
    puVar10 = auStack_68;
    puVar7 = *(undefined4 **)(arg1 + 0x30);
    if (puVar7 != *(undefined4 **)(arg1 + 0x38)) {
        *puVar7 = (int32_t)arg2;
        *(int64_t *)(arg1 + 0x30) = *(int64_t *)(arg1 + 0x30) + 4;
        return;
    }
    iVar15 = (int64_t)((int64_t)puVar7 - *puVar5) >> 2;
    if (iVar15 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar6 = (int64_t)((int64_t)*(undefined4 **)(arg1 + 0x38) - *puVar5) >> 2;
    if (uVar6 <= 0x3fffffffffffffff - (uVar6 >> 1)) {
        uVar1 = iVar15 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar11 = uVar1;
        if (uVar1 <= uVar6) {
            uVar11 = uVar6;
        }
        if (uVar11 < 0x4000000000000000) {
            uVar6 = uVar11 * 4;
            if (uVar6 == 0) {
                uVar6 = 0;
                puVar10 = auStack_68;
            } else if (uVar6 < 0x1000) {
                uVar6 = fcn.180459890();
            } else {
                if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800d32fa;
                iVar13 = fcn.180459890(uVar6 + 0x27);
                if (iVar13 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar13 = (*pcVar3)(5);
                    puVar9 = auStack_60;
                }
                uVar6 = iVar13 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar13;
                puVar10 = puVar9;
            }
            *(int32_t *)(uVar6 + iVar15 * 4) = (int32_t)arg2;
            puVar2 = (undefined4 *)*puVar5;
            if (puVar7 == *(undefined4 **)(arg1 + 0x30)) {
                iVar13 = (int64_t)*(undefined4 **)(arg1 + 0x30) - (int64_t)puVar2;
                uVar14 = uVar6;
                puVar7 = puVar2;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800d32b0;
                fcn.180498030(uVar6, puVar2, (int64_t)puVar7 - (int64_t)puVar2);
                iVar13 = *(int64_t *)(arg1 + 0x30) - (int64_t)puVar7;
                uVar14 = uVar6 + (iVar15 + 1) * 4;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800d32c7;
            fcn.180498030(uVar14, puVar7, iVar13);
            uVar12 = *(undefined8 *)(puVar10 + 0x28);
            *(undefined8 *)(puVar10 + 0x30) = *(undefined8 *)(puVar10 + 0x30);
            *(undefined8 *)(puVar10 + 0x28) = *(undefined8 *)(puVar10 + 0x40);
            *(undefined8 *)(puVar10 + 0x20) = uVar12;
            *(undefined8 *)(puVar10 + 0x18) = *(undefined8 *)(puVar10 + 0x48);
            uVar14 = *puVar5;
            if (uVar14 != 0) {
                uVar4 = uVar14;
                puVar8 = puVar10 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x38) - uVar14) >> 2) * 4)) {
                    uVar4 = *(uint64_t *)(uVar14 - 8);
                    uVar14 = (uVar14 - uVar4) - 8;
                    puVar8 = puVar10 + -0x10;
                    if (0x1f < uVar14) {
                        pcVar3 = (code *)swi(0x29);
                        uVar4 = uVar14;
                        (*pcVar3)(5);
                        puVar8 = puVar10 + -8;
                    }
                }
                *(undefined8 *)(puVar8 + -8) = 0x180030d9f;
                fcn.180459c3c(uVar4);
            }
            *puVar5 = uVar6;
            *(uint64_t *)(arg1 + 0x30) = uVar6 + uVar1 * 4;
            *(uint64_t *)(arg1 + 0x38) = uVar6 + uVar11 * 4;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800cfeb0
// Address: 0x1800cfeb0
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

int64_t fcn.1800cfeb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint32_t *puVar2;
    int32_t *piVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int32_t *piVar11;
    undefined *puVar12;
    int64_t iVar13;
    uint64_t unaff_RDI;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar6;
    
    iVar7 = (int32_t)arg3;
    iVar10 = (int32_t)arg2;
    uVar8 = (iVar7 - iVar10) - 1;
    if ((int32_t)(int16_t)uVar8 == uVar8) {
        puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 0x28) + arg2 * 4);
        uVar5 = uVar8 * 0x10000;
        *puVar2 = *puVar2 | uVar5;
    } else {
        uVar5 = -uVar8;
        if (0 < (int32_t)uVar8) {
            uVar5 = uVar8;
        }
        if (0x7fffff < (int32_t)uVar5) {
            return (uint64_t)(unkuint3)(uVar5 >> 8) << 8;
        }
        *(undefined *)(arg1 + 0xe8) = 1;
    }
    uVar6 = (uint64_t)uVar5;
    piVar11 = *(int32_t **)(arg1 + 0x90);
    if (piVar11 != *(int32_t **)(arg1 + 0x98)) {
        *piVar11 = iVar10;
        piVar11[1] = iVar7;
        *(int64_t *)(arg1 + 0x90) = *(int64_t *)(arg1 + 0x90) + 8;
        goto code_r0x0001800d00a0;
    }
    iVar13 = (int64_t)piVar11 - *(int64_t *)(arg1 + 0x88) >> 3;
    if (iVar13 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        iVar13 = (*pcVar4)();
        return iVar13;
    }
    uVar9 = (int64_t)*(int32_t **)(arg1 + 0x98) - *(int64_t *)(arg1 + 0x88) >> 3;
    if (0x1fffffffffffffff - (uVar9 >> 1) < uVar9) {
code_r0x0001800d00d1:
        fcn.180004720();
        pcVar4 = (code *)swi(3);
        iVar13 = (*pcVar4)();
        return iVar13;
    }
    uVar1 = iVar13 + 1;
    uVar9 = (uVar9 >> 1) + uVar9;
    uVar6 = uVar1;
    if (uVar1 <= uVar9) {
        uVar6 = uVar9;
    }
    if (0x1fffffffffffffff < uVar6) goto code_r0x0001800d00d1;
    uVar6 = uVar6 * 8;
    if (uVar6 == 0) {
        unaff_RDI = 0;
code_r0x0001800cffe6:
        *(int32_t *)(unaff_RDI + iVar13 * 8) = iVar10;
        *(int32_t *)(unaff_RDI + 4 + iVar13 * 8) = iVar7;
        piVar3 = *(int32_t **)(arg1 + 0x88);
        if (piVar11 == *(int32_t **)(arg1 + 0x90)) {
            iVar14 = (int64_t)*(int32_t **)(arg1 + 0x90) - (int64_t)piVar3;
            uVar9 = unaff_RDI;
            piVar11 = piVar3;
        } else {
            fcn.180498030(unaff_RDI, piVar3, (int64_t)piVar11 - (int64_t)piVar3);
            iVar14 = *(int64_t *)(arg1 + 0x90) - (int64_t)piVar11;
            uVar9 = unaff_RDI + (iVar13 + 1) * 8;
        }
        fcn.180498030(uVar9, piVar11, iVar14);
        iVar13 = *(int64_t *)(arg1 + 0x88);
        if (iVar13 != 0) {
            iVar14 = iVar13;
            puVar12 = auStack_48;
            if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x98) - iVar13 >> 3) * 8)) &&
               (iVar14 = *(int64_t *)(iVar13 + -8), puVar12 = auStack_48, 0x1f < (iVar13 - iVar14) - 8U))
            goto code_r0x0001800d0071;
            goto code_r0x0001800d007b;
        }
    } else {
        if (uVar6 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar6);
            goto code_r0x0001800cffe6;
        }
        if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800d00d1;
        iVar14 = fcn.180459890();
        if (iVar14 != 0) {
            unaff_RDI = iVar14 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar14;
            goto code_r0x0001800cffe6;
        }
code_r0x0001800d0071:
        iVar14 = 5;
        pcVar4 = (code *)swi(0x29);
        (*pcVar4)(5);
        puVar12 = auStack_40;
code_r0x0001800d007b:
        *(undefined8 *)(puVar12 + -8) = 0x1800d0083;
        fcn.180459c3c(iVar14);
    }
    *(uint64_t *)(arg1 + 0x88) = unaff_RDI;
    *(uint64_t *)(arg1 + 0x90) = unaff_RDI + uVar1 * 8;
    uVar6 = uVar6 + unaff_RDI;
    *(uint64_t *)(arg1 + 0x98) = uVar6;
code_r0x0001800d00a0:
    return CONCAT71((unkint7)(uVar6 >> 8), 1);
}

// ============================================================
// Function: FUN_1800cff04
// Address: 0x1800cff04
// Size: 449 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

int64_t fcn.1800cfeb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint32_t *puVar2;
    int32_t *piVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int32_t *piVar11;
    undefined *puVar12;
    int64_t iVar13;
    uint64_t unaff_RDI;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar6;
    
    iVar7 = (int32_t)arg3;
    iVar10 = (int32_t)arg2;
    uVar8 = (iVar7 - iVar10) - 1;
    if ((int32_t)(int16_t)uVar8 == uVar8) {
        puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 0x28) + arg2 * 4);
        uVar5 = uVar8 * 0x10000;
        *puVar2 = *puVar2 | uVar5;
    } else {
        uVar5 = -uVar8;
        if (0 < (int32_t)uVar8) {
            uVar5 = uVar8;
        }
        if (0x7fffff < (int32_t)uVar5) {
            return (uint64_t)(unkuint3)(uVar5 >> 8) << 8;
        }
        *(undefined *)(arg1 + 0xe8) = 1;
    }
    uVar6 = (uint64_t)uVar5;
    piVar11 = *(int32_t **)(arg1 + 0x90);
    if (piVar11 != *(int32_t **)(arg1 + 0x98)) {
        *piVar11 = iVar10;
        piVar11[1] = iVar7;
        *(int64_t *)(arg1 + 0x90) = *(int64_t *)(arg1 + 0x90) + 8;
        goto code_r0x0001800d00a0;
    }
    iVar13 = (int64_t)piVar11 - *(int64_t *)(arg1 + 0x88) >> 3;
    if (iVar13 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        iVar13 = (*pcVar4)();
        return iVar13;
    }
    uVar9 = (int64_t)*(int32_t **)(arg1 + 0x98) - *(int64_t *)(arg1 + 0x88) >> 3;
    if (0x1fffffffffffffff - (uVar9 >> 1) < uVar9) {
code_r0x0001800d00d1:
        fcn.180004720();
        pcVar4 = (code *)swi(3);
        iVar13 = (*pcVar4)();
        return iVar13;
    }
    uVar1 = iVar13 + 1;
    uVar9 = (uVar9 >> 1) + uVar9;
    uVar6 = uVar1;
    if (uVar1 <= uVar9) {
        uVar6 = uVar9;
    }
    if (0x1fffffffffffffff < uVar6) goto code_r0x0001800d00d1;
    uVar6 = uVar6 * 8;
    if (uVar6 == 0) {
        unaff_RDI = 0;
code_r0x0001800cffe6:
        *(int32_t *)(unaff_RDI + iVar13 * 8) = iVar10;
        *(int32_t *)(unaff_RDI + 4 + iVar13 * 8) = iVar7;
        piVar3 = *(int32_t **)(arg1 + 0x88);
        if (piVar11 == *(int32_t **)(arg1 + 0x90)) {
            iVar14 = (int64_t)*(int32_t **)(arg1 + 0x90) - (int64_t)piVar3;
            uVar9 = unaff_RDI;
            piVar11 = piVar3;
        } else {
            fcn.180498030(unaff_RDI, piVar3, (int64_t)piVar11 - (int64_t)piVar3);
            iVar14 = *(int64_t *)(arg1 + 0x90) - (int64_t)piVar11;
            uVar9 = unaff_RDI + (iVar13 + 1) * 8;
        }
        fcn.180498030(uVar9, piVar11, iVar14);
        iVar13 = *(int64_t *)(arg1 + 0x88);
        if (iVar13 != 0) {
            iVar14 = iVar13;
            puVar12 = auStack_48;
            if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x98) - iVar13 >> 3) * 8)) &&
               (iVar14 = *(int64_t *)(iVar13 + -8), puVar12 = auStack_48, 0x1f < (iVar13 - iVar14) - 8U))
            goto code_r0x0001800d0071;
            goto code_r0x0001800d007b;
        }
    } else {
        if (uVar6 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar6);
            goto code_r0x0001800cffe6;
        }
        if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800d00d1;
        iVar14 = fcn.180459890();
        if (iVar14 != 0) {
            unaff_RDI = iVar14 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar14;
            goto code_r0x0001800cffe6;
        }
code_r0x0001800d0071:
        iVar14 = 5;
        pcVar4 = (code *)swi(0x29);
        (*pcVar4)(5);
        puVar12 = auStack_40;
code_r0x0001800d007b:
        *(undefined8 *)(puVar12 + -8) = 0x1800d0083;
        fcn.180459c3c(iVar14);
    }
    *(uint64_t *)(arg1 + 0x88) = unaff_RDI;
    *(uint64_t *)(arg1 + 0x90) = unaff_RDI + uVar1 * 8;
    uVar6 = uVar6 + unaff_RDI;
    *(uint64_t *)(arg1 + 0x98) = uVar6;
code_r0x0001800d00a0:
    return CONCAT71((unkint7)(uVar6 >> 8), 1);
}

// ============================================================
// Function: FUN_1800d00c5
// Address: 0x1800d00c5
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

int64_t fcn.1800cfeb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint32_t *puVar2;
    int32_t *piVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int32_t *piVar11;
    undefined *puVar12;
    int64_t iVar13;
    uint64_t unaff_RDI;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar6;
    
    iVar7 = (int32_t)arg3;
    iVar10 = (int32_t)arg2;
    uVar8 = (iVar7 - iVar10) - 1;
    if ((int32_t)(int16_t)uVar8 == uVar8) {
        puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 0x28) + arg2 * 4);
        uVar5 = uVar8 * 0x10000;
        *puVar2 = *puVar2 | uVar5;
    } else {
        uVar5 = -uVar8;
        if (0 < (int32_t)uVar8) {
            uVar5 = uVar8;
        }
        if (0x7fffff < (int32_t)uVar5) {
            return (uint64_t)(unkuint3)(uVar5 >> 8) << 8;
        }
        *(undefined *)(arg1 + 0xe8) = 1;
    }
    uVar6 = (uint64_t)uVar5;
    piVar11 = *(int32_t **)(arg1 + 0x90);
    if (piVar11 != *(int32_t **)(arg1 + 0x98)) {
        *piVar11 = iVar10;
        piVar11[1] = iVar7;
        *(int64_t *)(arg1 + 0x90) = *(int64_t *)(arg1 + 0x90) + 8;
        goto code_r0x0001800d00a0;
    }
    iVar13 = (int64_t)piVar11 - *(int64_t *)(arg1 + 0x88) >> 3;
    if (iVar13 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        iVar13 = (*pcVar4)();
        return iVar13;
    }
    uVar9 = (int64_t)*(int32_t **)(arg1 + 0x98) - *(int64_t *)(arg1 + 0x88) >> 3;
    if (0x1fffffffffffffff - (uVar9 >> 1) < uVar9) {
code_r0x0001800d00d1:
        fcn.180004720();
        pcVar4 = (code *)swi(3);
        iVar13 = (*pcVar4)();
        return iVar13;
    }
    uVar1 = iVar13 + 1;
    uVar9 = (uVar9 >> 1) + uVar9;
    uVar6 = uVar1;
    if (uVar1 <= uVar9) {
        uVar6 = uVar9;
    }
    if (0x1fffffffffffffff < uVar6) goto code_r0x0001800d00d1;
    uVar6 = uVar6 * 8;
    if (uVar6 == 0) {
        unaff_RDI = 0;
code_r0x0001800cffe6:
        *(int32_t *)(unaff_RDI + iVar13 * 8) = iVar10;
        *(int32_t *)(unaff_RDI + 4 + iVar13 * 8) = iVar7;
        piVar3 = *(int32_t **)(arg1 + 0x88);
        if (piVar11 == *(int32_t **)(arg1 + 0x90)) {
            iVar14 = (int64_t)*(int32_t **)(arg1 + 0x90) - (int64_t)piVar3;
            uVar9 = unaff_RDI;
            piVar11 = piVar3;
        } else {
            fcn.180498030(unaff_RDI, piVar3, (int64_t)piVar11 - (int64_t)piVar3);
            iVar14 = *(int64_t *)(arg1 + 0x90) - (int64_t)piVar11;
            uVar9 = unaff_RDI + (iVar13 + 1) * 8;
        }
        fcn.180498030(uVar9, piVar11, iVar14);
        iVar13 = *(int64_t *)(arg1 + 0x88);
        if (iVar13 != 0) {
            iVar14 = iVar13;
            puVar12 = auStack_48;
            if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x98) - iVar13 >> 3) * 8)) &&
               (iVar14 = *(int64_t *)(iVar13 + -8), puVar12 = auStack_48, 0x1f < (iVar13 - iVar14) - 8U))
            goto code_r0x0001800d0071;
            goto code_r0x0001800d007b;
        }
    } else {
        if (uVar6 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar6);
            goto code_r0x0001800cffe6;
        }
        if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800d00d1;
        iVar14 = fcn.180459890();
        if (iVar14 != 0) {
            unaff_RDI = iVar14 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar14;
            goto code_r0x0001800cffe6;
        }
code_r0x0001800d0071:
        iVar14 = 5;
        pcVar4 = (code *)swi(0x29);
        (*pcVar4)(5);
        puVar12 = auStack_40;
code_r0x0001800d007b:
        *(undefined8 *)(puVar12 + -8) = 0x1800d0083;
        fcn.180459c3c(iVar14);
    }
    *(uint64_t *)(arg1 + 0x88) = unaff_RDI;
    *(uint64_t *)(arg1 + 0x90) = unaff_RDI + uVar1 * 8;
    uVar6 = uVar6 + unaff_RDI;
    *(uint64_t *)(arg1 + 0x98) = uVar6;
code_r0x0001800d00a0:
    return CONCAT71((unkint7)(uVar6 >> 8), 1);
}

// ============================================================
// Function: FUN_1800d00d1
// Address: 0x1800d00d1
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

int64_t fcn.1800cfeb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint32_t *puVar2;
    int32_t *piVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int32_t *piVar11;
    undefined *puVar12;
    int64_t iVar13;
    uint64_t unaff_RDI;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar6;
    
    iVar7 = (int32_t)arg3;
    iVar10 = (int32_t)arg2;
    uVar8 = (iVar7 - iVar10) - 1;
    if ((int32_t)(int16_t)uVar8 == uVar8) {
        puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 0x28) + arg2 * 4);
        uVar5 = uVar8 * 0x10000;
        *puVar2 = *puVar2 | uVar5;
    } else {
        uVar5 = -uVar8;
        if (0 < (int32_t)uVar8) {
            uVar5 = uVar8;
        }
        if (0x7fffff < (int32_t)uVar5) {
            return (uint64_t)(unkuint3)(uVar5 >> 8) << 8;
        }
        *(undefined *)(arg1 + 0xe8) = 1;
    }
    uVar6 = (uint64_t)uVar5;
    piVar11 = *(int32_t **)(arg1 + 0x90);
    if (piVar11 != *(int32_t **)(arg1 + 0x98)) {
        *piVar11 = iVar10;
        piVar11[1] = iVar7;
        *(int64_t *)(arg1 + 0x90) = *(int64_t *)(arg1 + 0x90) + 8;
        goto code_r0x0001800d00a0;
    }
    iVar13 = (int64_t)piVar11 - *(int64_t *)(arg1 + 0x88) >> 3;
    if (iVar13 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        iVar13 = (*pcVar4)();
        return iVar13;
    }
    uVar9 = (int64_t)*(int32_t **)(arg1 + 0x98) - *(int64_t *)(arg1 + 0x88) >> 3;
    if (0x1fffffffffffffff - (uVar9 >> 1) < uVar9) {
code_r0x0001800d00d1:
        fcn.180004720();
        pcVar4 = (code *)swi(3);
        iVar13 = (*pcVar4)();
        return iVar13;
    }
    uVar1 = iVar13 + 1;
    uVar9 = (uVar9 >> 1) + uVar9;
    uVar6 = uVar1;
    if (uVar1 <= uVar9) {
        uVar6 = uVar9;
    }
    if (0x1fffffffffffffff < uVar6) goto code_r0x0001800d00d1;
    uVar6 = uVar6 * 8;
    if (uVar6 == 0) {
        unaff_RDI = 0;
code_r0x0001800cffe6:
        *(int32_t *)(unaff_RDI + iVar13 * 8) = iVar10;
        *(int32_t *)(unaff_RDI + 4 + iVar13 * 8) = iVar7;
        piVar3 = *(int32_t **)(arg1 + 0x88);
        if (piVar11 == *(int32_t **)(arg1 + 0x90)) {
            iVar14 = (int64_t)*(int32_t **)(arg1 + 0x90) - (int64_t)piVar3;
            uVar9 = unaff_RDI;
            piVar11 = piVar3;
        } else {
            fcn.180498030(unaff_RDI, piVar3, (int64_t)piVar11 - (int64_t)piVar3);
            iVar14 = *(int64_t *)(arg1 + 0x90) - (int64_t)piVar11;
            uVar9 = unaff_RDI + (iVar13 + 1) * 8;
        }
        fcn.180498030(uVar9, piVar11, iVar14);
        iVar13 = *(int64_t *)(arg1 + 0x88);
        if (iVar13 != 0) {
            iVar14 = iVar13;
            puVar12 = auStack_48;
            if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x98) - iVar13 >> 3) * 8)) &&
               (iVar14 = *(int64_t *)(iVar13 + -8), puVar12 = auStack_48, 0x1f < (iVar13 - iVar14) - 8U))
            goto code_r0x0001800d0071;
            goto code_r0x0001800d007b;
        }
    } else {
        if (uVar6 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar6);
            goto code_r0x0001800cffe6;
        }
        if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800d00d1;
        iVar14 = fcn.180459890();
        if (iVar14 != 0) {
            unaff_RDI = iVar14 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar14;
            goto code_r0x0001800cffe6;
        }
code_r0x0001800d0071:
        iVar14 = 5;
        pcVar4 = (code *)swi(0x29);
        (*pcVar4)(5);
        puVar12 = auStack_40;
code_r0x0001800d007b:
        *(undefined8 *)(puVar12 + -8) = 0x1800d0083;
        fcn.180459c3c(iVar14);
    }
    *(uint64_t *)(arg1 + 0x88) = unaff_RDI;
    *(uint64_t *)(arg1 + 0x90) = unaff_RDI + uVar1 * 8;
    uVar6 = uVar6 + unaff_RDI;
    *(uint64_t *)(arg1 + 0x98) = uVar6;
code_r0x0001800d00a0:
    return CONCAT71((unkint7)(uVar6 >> 8), 1);
}

// ============================================================
// Function: FUN_1800d00e0
// Address: 0x1800d00e0
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800d00e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined4 *puVar5;
    int64_t *piVar6;
    uint64_t unaff_RSI;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    undefined auStack_50 [29];
    int64_t var_33h;
    int64_t var_28h;
    
    puVar5 = *(undefined4 **)(arg1 + 0x2b0);
    if (puVar5 != *(undefined4 **)(arg1 + 0x2b8)) {
        *(undefined2 *)((int64_t)puVar5 + 5) = (undefined2)var_33h;
        *(undefined *)((int64_t)puVar5 + 7) = var_33h._2_1_;
        puVar5[3] = (undefined4)arg_28h;
        *puVar5 = (int32_t)arg2;
        *(undefined *)(puVar5 + 1) = (undefined)placeholder_2;
        puVar5[2] = (int32_t)arg4;
        *(int64_t *)(arg1 + 0x2b0) = *(int64_t *)(arg1 + 0x2b0) + 0x10;
        return;
    }
    iVar9 = (int64_t)puVar5 - *(int64_t *)(arg1 + 0x2a8) >> 4;
    if (iVar9 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined4 **)(arg1 + 0x2b8) - *(int64_t *)(arg1 + 0x2a8) >> 4;
    if (0xfffffffffffffff - (uVar4 >> 1) < uVar4) {
code_r0x0001800d0300:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar9 + 1;
    uVar4 = (uVar4 >> 1) + uVar4;
    uVar8 = uVar1;
    if (uVar1 <= uVar4) {
        uVar8 = uVar4;
    }
    if (0xfffffffffffffff < uVar8) goto code_r0x0001800d0300;
    uVar8 = uVar8 * 0x10;
    if (uVar8 == 0) {
        unaff_RSI = 0;
code_r0x0001800d01fc:
        iVar9 = iVar9 * 0x10;
        *(undefined2 *)(iVar9 + 5 + unaff_RSI) = (undefined2)var_33h;
        *(undefined *)(iVar9 + 7 + unaff_RSI) = var_33h._2_1_;
        *(undefined4 *)(iVar9 + 0xc + unaff_RSI) = (undefined4)arg_28h;
        *(int32_t *)(iVar9 + unaff_RSI) = (int32_t)arg2;
        *(undefined *)(iVar9 + 4 + unaff_RSI) = (undefined)placeholder_2;
        *(int32_t *)(iVar9 + 8 + unaff_RSI) = (int32_t)arg4;
        puVar2 = *(undefined4 **)(arg1 + 0x2a8);
        if (puVar5 == *(undefined4 **)(arg1 + 0x2b0)) {
            iVar7 = (int64_t)*(undefined4 **)(arg1 + 0x2b0) - (int64_t)puVar2;
            uVar4 = unaff_RSI;
            puVar5 = puVar2;
        } else {
            fcn.180498030(unaff_RSI, puVar2, (int64_t)puVar5 - (int64_t)puVar2);
            iVar7 = *(int64_t *)(arg1 + 0x2b0) - (int64_t)puVar5;
            uVar4 = iVar9 + 0x10 + unaff_RSI;
        }
        fcn.180498030(uVar4, puVar5, iVar7);
        iVar9 = *(int64_t *)(arg1 + 0x2a8);
        if (iVar9 == 0) goto code_r0x0001800d02bb;
        iVar7 = iVar9;
        piVar6 = &var_58h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x2b8) - iVar9 & 0xfffffffffffffff0U)) &&
           (iVar7 = *(int64_t *)(iVar9 + -8), piVar6 = &var_58h, 0x1f < (iVar9 - iVar7) - 8U))
        goto code_r0x0001800d02ac;
    } else {
        if (uVar8 < 0x1000) {
            unaff_RSI = fcn.180459890(uVar8);
            goto code_r0x0001800d01fc;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x0001800d0300;
        iVar7 = fcn.180459890();
        if (iVar7 != 0) {
            unaff_RSI = iVar7 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar7;
            goto code_r0x0001800d01fc;
        }
code_r0x0001800d02ac:
        pcVar3 = (code *)swi(0x29);
        iVar7 = (*pcVar3)(5);
        piVar6 = (int64_t *)auStack_50;
    }
    *(undefined8 *)((int64_t)piVar6 + -8) = 0x1800d02bb;
    fcn.180459c3c(iVar7);
code_r0x0001800d02bb:
    *(uint64_t *)(arg1 + 0x2a8) = unaff_RSI;
    *(uint64_t *)(arg1 + 0x2b0) = uVar1 * 0x10 + unaff_RSI;
    *(uint64_t *)(arg1 + 0x2b8) = uVar8 + unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800d0154
// Address: 0x1800d0154
// Size: 422 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800d00e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined4 *puVar5;
    int64_t *piVar6;
    uint64_t unaff_RSI;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    undefined auStack_50 [29];
    int64_t var_33h;
    int64_t var_28h;
    
    puVar5 = *(undefined4 **)(arg1 + 0x2b0);
    if (puVar5 != *(undefined4 **)(arg1 + 0x2b8)) {
        *(undefined2 *)((int64_t)puVar5 + 5) = (undefined2)var_33h;
        *(undefined *)((int64_t)puVar5 + 7) = var_33h._2_1_;
        puVar5[3] = (undefined4)arg_28h;
        *puVar5 = (int32_t)arg2;
        *(undefined *)(puVar5 + 1) = (undefined)placeholder_2;
        puVar5[2] = (int32_t)arg4;
        *(int64_t *)(arg1 + 0x2b0) = *(int64_t *)(arg1 + 0x2b0) + 0x10;
        return;
    }
    iVar9 = (int64_t)puVar5 - *(int64_t *)(arg1 + 0x2a8) >> 4;
    if (iVar9 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined4 **)(arg1 + 0x2b8) - *(int64_t *)(arg1 + 0x2a8) >> 4;
    if (0xfffffffffffffff - (uVar4 >> 1) < uVar4) {
code_r0x0001800d0300:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar9 + 1;
    uVar4 = (uVar4 >> 1) + uVar4;
    uVar8 = uVar1;
    if (uVar1 <= uVar4) {
        uVar8 = uVar4;
    }
    if (0xfffffffffffffff < uVar8) goto code_r0x0001800d0300;
    uVar8 = uVar8 * 0x10;
    if (uVar8 == 0) {
        unaff_RSI = 0;
code_r0x0001800d01fc:
        iVar9 = iVar9 * 0x10;
        *(undefined2 *)(iVar9 + 5 + unaff_RSI) = (undefined2)var_33h;
        *(undefined *)(iVar9 + 7 + unaff_RSI) = var_33h._2_1_;
        *(undefined4 *)(iVar9 + 0xc + unaff_RSI) = (undefined4)arg_28h;
        *(int32_t *)(iVar9 + unaff_RSI) = (int32_t)arg2;
        *(undefined *)(iVar9 + 4 + unaff_RSI) = (undefined)placeholder_2;
        *(int32_t *)(iVar9 + 8 + unaff_RSI) = (int32_t)arg4;
        puVar2 = *(undefined4 **)(arg1 + 0x2a8);
        if (puVar5 == *(undefined4 **)(arg1 + 0x2b0)) {
            iVar7 = (int64_t)*(undefined4 **)(arg1 + 0x2b0) - (int64_t)puVar2;
            uVar4 = unaff_RSI;
            puVar5 = puVar2;
        } else {
            fcn.180498030(unaff_RSI, puVar2, (int64_t)puVar5 - (int64_t)puVar2);
            iVar7 = *(int64_t *)(arg1 + 0x2b0) - (int64_t)puVar5;
            uVar4 = iVar9 + 0x10 + unaff_RSI;
        }
        fcn.180498030(uVar4, puVar5, iVar7);
        iVar9 = *(int64_t *)(arg1 + 0x2a8);
        if (iVar9 == 0) goto code_r0x0001800d02bb;
        iVar7 = iVar9;
        piVar6 = &var_58h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x2b8) - iVar9 & 0xfffffffffffffff0U)) &&
           (iVar7 = *(int64_t *)(iVar9 + -8), piVar6 = &var_58h, 0x1f < (iVar9 - iVar7) - 8U))
        goto code_r0x0001800d02ac;
    } else {
        if (uVar8 < 0x1000) {
            unaff_RSI = fcn.180459890(uVar8);
            goto code_r0x0001800d01fc;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x0001800d0300;
        iVar7 = fcn.180459890();
        if (iVar7 != 0) {
            unaff_RSI = iVar7 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar7;
            goto code_r0x0001800d01fc;
        }
code_r0x0001800d02ac:
        pcVar3 = (code *)swi(0x29);
        iVar7 = (*pcVar3)(5);
        piVar6 = (int64_t *)auStack_50;
    }
    *(undefined8 *)((int64_t)piVar6 + -8) = 0x1800d02bb;
    fcn.180459c3c(iVar7);
code_r0x0001800d02bb:
    *(uint64_t *)(arg1 + 0x2a8) = unaff_RSI;
    *(uint64_t *)(arg1 + 0x2b0) = uVar1 * 0x10 + unaff_RSI;
    *(uint64_t *)(arg1 + 0x2b8) = uVar8 + unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800d02fa
// Address: 0x1800d02fa
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800d00e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined4 *puVar5;
    int64_t *piVar6;
    uint64_t unaff_RSI;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    undefined auStack_50 [29];
    int64_t var_33h;
    int64_t var_28h;
    
    puVar5 = *(undefined4 **)(arg1 + 0x2b0);
    if (puVar5 != *(undefined4 **)(arg1 + 0x2b8)) {
        *(undefined2 *)((int64_t)puVar5 + 5) = (undefined2)var_33h;
        *(undefined *)((int64_t)puVar5 + 7) = var_33h._2_1_;
        puVar5[3] = (undefined4)arg_28h;
        *puVar5 = (int32_t)arg2;
        *(undefined *)(puVar5 + 1) = (undefined)placeholder_2;
        puVar5[2] = (int32_t)arg4;
        *(int64_t *)(arg1 + 0x2b0) = *(int64_t *)(arg1 + 0x2b0) + 0x10;
        return;
    }
    iVar9 = (int64_t)puVar5 - *(int64_t *)(arg1 + 0x2a8) >> 4;
    if (iVar9 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined4 **)(arg1 + 0x2b8) - *(int64_t *)(arg1 + 0x2a8) >> 4;
    if (0xfffffffffffffff - (uVar4 >> 1) < uVar4) {
code_r0x0001800d0300:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar9 + 1;
    uVar4 = (uVar4 >> 1) + uVar4;
    uVar8 = uVar1;
    if (uVar1 <= uVar4) {
        uVar8 = uVar4;
    }
    if (0xfffffffffffffff < uVar8) goto code_r0x0001800d0300;
    uVar8 = uVar8 * 0x10;
    if (uVar8 == 0) {
        unaff_RSI = 0;
code_r0x0001800d01fc:
        iVar9 = iVar9 * 0x10;
        *(undefined2 *)(iVar9 + 5 + unaff_RSI) = (undefined2)var_33h;
        *(undefined *)(iVar9 + 7 + unaff_RSI) = var_33h._2_1_;
        *(undefined4 *)(iVar9 + 0xc + unaff_RSI) = (undefined4)arg_28h;
        *(int32_t *)(iVar9 + unaff_RSI) = (int32_t)arg2;
        *(undefined *)(iVar9 + 4 + unaff_RSI) = (undefined)placeholder_2;
        *(int32_t *)(iVar9 + 8 + unaff_RSI) = (int32_t)arg4;
        puVar2 = *(undefined4 **)(arg1 + 0x2a8);
        if (puVar5 == *(undefined4 **)(arg1 + 0x2b0)) {
            iVar7 = (int64_t)*(undefined4 **)(arg1 + 0x2b0) - (int64_t)puVar2;
            uVar4 = unaff_RSI;
            puVar5 = puVar2;
        } else {
            fcn.180498030(unaff_RSI, puVar2, (int64_t)puVar5 - (int64_t)puVar2);
            iVar7 = *(int64_t *)(arg1 + 0x2b0) - (int64_t)puVar5;
            uVar4 = iVar9 + 0x10 + unaff_RSI;
        }
        fcn.180498030(uVar4, puVar5, iVar7);
        iVar9 = *(int64_t *)(arg1 + 0x2a8);
        if (iVar9 == 0) goto code_r0x0001800d02bb;
        iVar7 = iVar9;
        piVar6 = &var_58h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x2b8) - iVar9 & 0xfffffffffffffff0U)) &&
           (iVar7 = *(int64_t *)(iVar9 + -8), piVar6 = &var_58h, 0x1f < (iVar9 - iVar7) - 8U))
        goto code_r0x0001800d02ac;
    } else {
        if (uVar8 < 0x1000) {
            unaff_RSI = fcn.180459890(uVar8);
            goto code_r0x0001800d01fc;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x0001800d0300;
        iVar7 = fcn.180459890();
        if (iVar7 != 0) {
            unaff_RSI = iVar7 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar7;
            goto code_r0x0001800d01fc;
        }
code_r0x0001800d02ac:
        pcVar3 = (code *)swi(0x29);
        iVar7 = (*pcVar3)(5);
        piVar6 = (int64_t *)auStack_50;
    }
    *(undefined8 *)((int64_t)piVar6 + -8) = 0x1800d02bb;
    fcn.180459c3c(iVar7);
code_r0x0001800d02bb:
    *(uint64_t *)(arg1 + 0x2a8) = unaff_RSI;
    *(uint64_t *)(arg1 + 0x2b0) = uVar1 * 0x10 + unaff_RSI;
    *(uint64_t *)(arg1 + 0x2b8) = uVar8 + unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800d0300
// Address: 0x1800d0300
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800d00e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined4 *puVar5;
    int64_t *piVar6;
    uint64_t unaff_RSI;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    undefined auStack_50 [29];
    int64_t var_33h;
    int64_t var_28h;
    
    puVar5 = *(undefined4 **)(arg1 + 0x2b0);
    if (puVar5 != *(undefined4 **)(arg1 + 0x2b8)) {
        *(undefined2 *)((int64_t)puVar5 + 5) = (undefined2)var_33h;
        *(undefined *)((int64_t)puVar5 + 7) = var_33h._2_1_;
        puVar5[3] = (undefined4)arg_28h;
        *puVar5 = (int32_t)arg2;
        *(undefined *)(puVar5 + 1) = (undefined)placeholder_2;
        puVar5[2] = (int32_t)arg4;
        *(int64_t *)(arg1 + 0x2b0) = *(int64_t *)(arg1 + 0x2b0) + 0x10;
        return;
    }
    iVar9 = (int64_t)puVar5 - *(int64_t *)(arg1 + 0x2a8) >> 4;
    if (iVar9 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined4 **)(arg1 + 0x2b8) - *(int64_t *)(arg1 + 0x2a8) >> 4;
    if (0xfffffffffffffff - (uVar4 >> 1) < uVar4) {
code_r0x0001800d0300:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar9 + 1;
    uVar4 = (uVar4 >> 1) + uVar4;
    uVar8 = uVar1;
    if (uVar1 <= uVar4) {
        uVar8 = uVar4;
    }
    if (0xfffffffffffffff < uVar8) goto code_r0x0001800d0300;
    uVar8 = uVar8 * 0x10;
    if (uVar8 == 0) {
        unaff_RSI = 0;
code_r0x0001800d01fc:
        iVar9 = iVar9 * 0x10;
        *(undefined2 *)(iVar9 + 5 + unaff_RSI) = (undefined2)var_33h;
        *(undefined *)(iVar9 + 7 + unaff_RSI) = var_33h._2_1_;
        *(undefined4 *)(iVar9 + 0xc + unaff_RSI) = (undefined4)arg_28h;
        *(int32_t *)(iVar9 + unaff_RSI) = (int32_t)arg2;
        *(undefined *)(iVar9 + 4 + unaff_RSI) = (undefined)placeholder_2;
        *(int32_t *)(iVar9 + 8 + unaff_RSI) = (int32_t)arg4;
        puVar2 = *(undefined4 **)(arg1 + 0x2a8);
        if (puVar5 == *(undefined4 **)(arg1 + 0x2b0)) {
            iVar7 = (int64_t)*(undefined4 **)(arg1 + 0x2b0) - (int64_t)puVar2;
            uVar4 = unaff_RSI;
            puVar5 = puVar2;
        } else {
            fcn.180498030(unaff_RSI, puVar2, (int64_t)puVar5 - (int64_t)puVar2);
            iVar7 = *(int64_t *)(arg1 + 0x2b0) - (int64_t)puVar5;
            uVar4 = iVar9 + 0x10 + unaff_RSI;
        }
        fcn.180498030(uVar4, puVar5, iVar7);
        iVar9 = *(int64_t *)(arg1 + 0x2a8);
        if (iVar9 == 0) goto code_r0x0001800d02bb;
        iVar7 = iVar9;
        piVar6 = &var_58h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x2b8) - iVar9 & 0xfffffffffffffff0U)) &&
           (iVar7 = *(int64_t *)(iVar9 + -8), piVar6 = &var_58h, 0x1f < (iVar9 - iVar7) - 8U))
        goto code_r0x0001800d02ac;
    } else {
        if (uVar8 < 0x1000) {
            unaff_RSI = fcn.180459890(uVar8);
            goto code_r0x0001800d01fc;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x0001800d0300;
        iVar7 = fcn.180459890();
        if (iVar7 != 0) {
            unaff_RSI = iVar7 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar7;
            goto code_r0x0001800d01fc;
        }
code_r0x0001800d02ac:
        pcVar3 = (code *)swi(0x29);
        iVar7 = (*pcVar3)(5);
        piVar6 = (int64_t *)auStack_50;
    }
    *(undefined8 *)((int64_t)piVar6 + -8) = 0x1800d02bb;
    fcn.180459c3c(iVar7);
code_r0x0001800d02bb:
    *(uint64_t *)(arg1 + 0x2a8) = unaff_RSI;
    *(uint64_t *)(arg1 + 0x2b0) = uVar1 * 0x10 + unaff_RSI;
    *(uint64_t *)(arg1 + 0x2b8) = uVar8 + unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800d0310
// Address: 0x1800d0310
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.1800d0310(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined4 *puVar5;
    undefined *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = *(undefined4 **)(arg1 + 0x2c8);
    if (puVar5 != *(undefined4 **)(arg1 + 0x2d0)) {
        *puVar5 = (int32_t)arg2;
        *(int64_t *)(arg1 + 0x2c8) = *(int64_t *)(arg1 + 0x2c8) + 4;
        return;
    }
    iVar7 = (int64_t)puVar5 - *(int64_t *)(arg1 + 0x2c0) >> 2;
    if (iVar7 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined4 **)(arg1 + 0x2d0) - *(int64_t *)(arg1 + 0x2c0) >> 2;
    if (0x3fffffffffffffff - (uVar4 >> 1) < uVar4) {
code_r0x0001800d04de:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar7 + 1;
    uVar4 = (uVar4 >> 1) + uVar4;
    uVar8 = uVar1;
    if (uVar1 <= uVar4) {
        uVar8 = uVar4;
    }
    if (0x3fffffffffffffff < uVar8) goto code_r0x0001800d04de;
    uVar8 = uVar8 * 4;
    if (uVar8 == 0) {
        unaff_RDI = 0;
code_r0x0001800d0405:
        *(int32_t *)(unaff_RDI + iVar7 * 4) = (int32_t)arg2;
        puVar2 = *(undefined4 **)(arg1 + 0x2c0);
        if (puVar5 == *(undefined4 **)(arg1 + 0x2c8)) {
            iVar9 = (int64_t)*(undefined4 **)(arg1 + 0x2c8) - (int64_t)puVar2;
            uVar4 = unaff_RDI;
            puVar5 = puVar2;
        } else {
            fcn.180498030(unaff_RDI, puVar2, (int64_t)puVar5 - (int64_t)puVar2);
            iVar9 = *(int64_t *)(arg1 + 0x2c8) - (int64_t)puVar5;
            uVar4 = unaff_RDI + (iVar7 + 1) * 4;
        }
        fcn.180498030(uVar4, puVar5, iVar9);
        iVar7 = *(int64_t *)(arg1 + 0x2c0);
        if (iVar7 == 0) goto code_r0x0001800d049d;
        iVar9 = iVar7;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x2d0) - iVar7 >> 2) * 4)) &&
           (iVar9 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_38, 0x1f < (iVar7 - iVar9) - 8U))
        goto code_r0x0001800d048b;
    } else {
        if (uVar8 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar8);
            goto code_r0x0001800d0405;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x0001800d04de;
        iVar9 = fcn.180459890();
        if (iVar9 != 0) {
            unaff_RDI = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar9;
            goto code_r0x0001800d0405;
        }
code_r0x0001800d048b:
        iVar9 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar6 = auStack_30;
    }
    *(undefined8 *)(puVar6 + -8) = 0x1800d049d;
    fcn.180459c3c(iVar9);
code_r0x0001800d049d:
    *(uint64_t *)(arg1 + 0x2c0) = unaff_RDI;
    *(uint64_t *)(arg1 + 0x2c8) = unaff_RDI + uVar1 * 4;
    *(uint64_t *)(arg1 + 0x2d0) = uVar8 + unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_1800d0359
// Address: 0x1800d0359
// Size: 383 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.1800d0310(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined4 *puVar5;
    undefined *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = *(undefined4 **)(arg1 + 0x2c8);
    if (puVar5 != *(undefined4 **)(arg1 + 0x2d0)) {
        *puVar5 = (int32_t)arg2;
        *(int64_t *)(arg1 + 0x2c8) = *(int64_t *)(arg1 + 0x2c8) + 4;
        return;
    }
    iVar7 = (int64_t)puVar5 - *(int64_t *)(arg1 + 0x2c0) >> 2;
    if (iVar7 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined4 **)(arg1 + 0x2d0) - *(int64_t *)(arg1 + 0x2c0) >> 2;
    if (0x3fffffffffffffff - (uVar4 >> 1) < uVar4) {
code_r0x0001800d04de:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar7 + 1;
    uVar4 = (uVar4 >> 1) + uVar4;
    uVar8 = uVar1;
    if (uVar1 <= uVar4) {
        uVar8 = uVar4;
    }
    if (0x3fffffffffffffff < uVar8) goto code_r0x0001800d04de;
    uVar8 = uVar8 * 4;
    if (uVar8 == 0) {
        unaff_RDI = 0;
code_r0x0001800d0405:
        *(int32_t *)(unaff_RDI + iVar7 * 4) = (int32_t)arg2;
        puVar2 = *(undefined4 **)(arg1 + 0x2c0);
        if (puVar5 == *(undefined4 **)(arg1 + 0x2c8)) {
            iVar9 = (int64_t)*(undefined4 **)(arg1 + 0x2c8) - (int64_t)puVar2;
            uVar4 = unaff_RDI;
            puVar5 = puVar2;
        } else {
            fcn.180498030(unaff_RDI, puVar2, (int64_t)puVar5 - (int64_t)puVar2);
            iVar9 = *(int64_t *)(arg1 + 0x2c8) - (int64_t)puVar5;
            uVar4 = unaff_RDI + (iVar7 + 1) * 4;
        }
        fcn.180498030(uVar4, puVar5, iVar9);
        iVar7 = *(int64_t *)(arg1 + 0x2c0);
        if (iVar7 == 0) goto code_r0x0001800d049d;
        iVar9 = iVar7;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x2d0) - iVar7 >> 2) * 4)) &&
           (iVar9 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_38, 0x1f < (iVar7 - iVar9) - 8U))
        goto code_r0x0001800d048b;
    } else {
        if (uVar8 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar8);
            goto code_r0x0001800d0405;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x0001800d04de;
        iVar9 = fcn.180459890();
        if (iVar9 != 0) {
            unaff_RDI = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar9;
            goto code_r0x0001800d0405;
        }
code_r0x0001800d048b:
        iVar9 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar6 = auStack_30;
    }
    *(undefined8 *)(puVar6 + -8) = 0x1800d049d;
    fcn.180459c3c(iVar9);
code_r0x0001800d049d:
    *(uint64_t *)(arg1 + 0x2c0) = unaff_RDI;
    *(uint64_t *)(arg1 + 0x2c8) = unaff_RDI + uVar1 * 4;
    *(uint64_t *)(arg1 + 0x2d0) = uVar8 + unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_1800d04d8
// Address: 0x1800d04d8
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.1800d0310(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined4 *puVar5;
    undefined *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = *(undefined4 **)(arg1 + 0x2c8);
    if (puVar5 != *(undefined4 **)(arg1 + 0x2d0)) {
        *puVar5 = (int32_t)arg2;
        *(int64_t *)(arg1 + 0x2c8) = *(int64_t *)(arg1 + 0x2c8) + 4;
        return;
    }
    iVar7 = (int64_t)puVar5 - *(int64_t *)(arg1 + 0x2c0) >> 2;
    if (iVar7 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined4 **)(arg1 + 0x2d0) - *(int64_t *)(arg1 + 0x2c0) >> 2;
    if (0x3fffffffffffffff - (uVar4 >> 1) < uVar4) {
code_r0x0001800d04de:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar7 + 1;
    uVar4 = (uVar4 >> 1) + uVar4;
    uVar8 = uVar1;
    if (uVar1 <= uVar4) {
        uVar8 = uVar4;
    }
    if (0x3fffffffffffffff < uVar8) goto code_r0x0001800d04de;
    uVar8 = uVar8 * 4;
    if (uVar8 == 0) {
        unaff_RDI = 0;
code_r0x0001800d0405:
        *(int32_t *)(unaff_RDI + iVar7 * 4) = (int32_t)arg2;
        puVar2 = *(undefined4 **)(arg1 + 0x2c0);
        if (puVar5 == *(undefined4 **)(arg1 + 0x2c8)) {
            iVar9 = (int64_t)*(undefined4 **)(arg1 + 0x2c8) - (int64_t)puVar2;
            uVar4 = unaff_RDI;
            puVar5 = puVar2;
        } else {
            fcn.180498030(unaff_RDI, puVar2, (int64_t)puVar5 - (int64_t)puVar2);
            iVar9 = *(int64_t *)(arg1 + 0x2c8) - (int64_t)puVar5;
            uVar4 = unaff_RDI + (iVar7 + 1) * 4;
        }
        fcn.180498030(uVar4, puVar5, iVar9);
        iVar7 = *(int64_t *)(arg1 + 0x2c0);
        if (iVar7 == 0) goto code_r0x0001800d049d;
        iVar9 = iVar7;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x2d0) - iVar7 >> 2) * 4)) &&
           (iVar9 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_38, 0x1f < (iVar7 - iVar9) - 8U))
        goto code_r0x0001800d048b;
    } else {
        if (uVar8 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar8);
            goto code_r0x0001800d0405;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x0001800d04de;
        iVar9 = fcn.180459890();
        if (iVar9 != 0) {
            unaff_RDI = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar9;
            goto code_r0x0001800d0405;
        }
code_r0x0001800d048b:
        iVar9 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar6 = auStack_30;
    }
    *(undefined8 *)(puVar6 + -8) = 0x1800d049d;
    fcn.180459c3c(iVar9);
code_r0x0001800d049d:
    *(uint64_t *)(arg1 + 0x2c0) = unaff_RDI;
    *(uint64_t *)(arg1 + 0x2c8) = unaff_RDI + uVar1 * 4;
    *(uint64_t *)(arg1 + 0x2d0) = uVar8 + unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_1800d04de
// Address: 0x1800d04de
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.1800d0310(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined4 *puVar5;
    undefined *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = *(undefined4 **)(arg1 + 0x2c8);
    if (puVar5 != *(undefined4 **)(arg1 + 0x2d0)) {
        *puVar5 = (int32_t)arg2;
        *(int64_t *)(arg1 + 0x2c8) = *(int64_t *)(arg1 + 0x2c8) + 4;
        return;
    }
    iVar7 = (int64_t)puVar5 - *(int64_t *)(arg1 + 0x2c0) >> 2;
    if (iVar7 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined4 **)(arg1 + 0x2d0) - *(int64_t *)(arg1 + 0x2c0) >> 2;
    if (0x3fffffffffffffff - (uVar4 >> 1) < uVar4) {
code_r0x0001800d04de:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar7 + 1;
    uVar4 = (uVar4 >> 1) + uVar4;
    uVar8 = uVar1;
    if (uVar1 <= uVar4) {
        uVar8 = uVar4;
    }
    if (0x3fffffffffffffff < uVar8) goto code_r0x0001800d04de;
    uVar8 = uVar8 * 4;
    if (uVar8 == 0) {
        unaff_RDI = 0;
code_r0x0001800d0405:
        *(int32_t *)(unaff_RDI + iVar7 * 4) = (int32_t)arg2;
        puVar2 = *(undefined4 **)(arg1 + 0x2c0);
        if (puVar5 == *(undefined4 **)(arg1 + 0x2c8)) {
            iVar9 = (int64_t)*(undefined4 **)(arg1 + 0x2c8) - (int64_t)puVar2;
            uVar4 = unaff_RDI;
            puVar5 = puVar2;
        } else {
            fcn.180498030(unaff_RDI, puVar2, (int64_t)puVar5 - (int64_t)puVar2);
            iVar9 = *(int64_t *)(arg1 + 0x2c8) - (int64_t)puVar5;
            uVar4 = unaff_RDI + (iVar7 + 1) * 4;
        }
        fcn.180498030(uVar4, puVar5, iVar9);
        iVar7 = *(int64_t *)(arg1 + 0x2c0);
        if (iVar7 == 0) goto code_r0x0001800d049d;
        iVar9 = iVar7;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x2d0) - iVar7 >> 2) * 4)) &&
           (iVar9 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_38, 0x1f < (iVar7 - iVar9) - 8U))
        goto code_r0x0001800d048b;
    } else {
        if (uVar8 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar8);
            goto code_r0x0001800d0405;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x0001800d04de;
        iVar9 = fcn.180459890();
        if (iVar9 != 0) {
            unaff_RDI = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar9;
            goto code_r0x0001800d0405;
        }
code_r0x0001800d048b:
        iVar9 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar6 = auStack_30;
    }
    *(undefined8 *)(puVar6 + -8) = 0x1800d049d;
    fcn.180459c3c(iVar9);
code_r0x0001800d049d:
    *(uint64_t *)(arg1 + 0x2c0) = unaff_RDI;
    *(uint64_t *)(arg1 + 0x2c8) = unaff_RDI + uVar1 * 4;
    *(uint64_t *)(arg1 + 0x2d0) = uVar8 + unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_1800d04f0
// Address: 0x1800d04f0
// Size: 240 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800d04f0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_18h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uStack_18;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    _var_38h = *(undefined (*) [16])arg2;
    uVar2 = func_0x0001800cf010(*(undefined4 *)arg2, &var_38h);
    *(undefined4 *)((uint64_t)*(uint32_t *)(arg1 + 0x18) * 0xa8 + 0x24 + *(int64_t *)arg1) = uVar2;
    puVar4 = auStack_58;
    if (*(int64_t *)(arg1 + 0x3f0) != 0) {
        var_28h = 0;
        _var_38h = ZEXT816(0);
        var_20h = 0;
        func_0x000180004830(&var_38h, *(undefined8 *)arg2, *(undefined8 *)(arg2 + 8));
        func_0x000180012c10((uint64_t)*(uint32_t *)(arg1 + 0x18) * 0xa8 + *(int64_t *)arg1 + 0x50, &var_38h);
        puVar4 = auStack_58;
        if (0xf < (uint64_t)var_20h) {
            iVar3 = var_38h;
            puVar4 = auStack_58;
            if ((0xfff < var_20h + 1U) &&
               (iVar3 = *(int64_t *)(var_38h + -8), puVar4 = auStack_58, 0x1f < (var_38h - iVar3) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar3 = (*pcVar1)(5);
                puVar4 = auStack_50;
            }
            *(undefined8 *)(puVar4 + -8) = 0x1800d05c8;
            fcn.180459c3c(iVar3);
        }
    }
    *(undefined8 *)(puVar4 + -8) = 0x1800d05d5;
    func_0x000180459870(*(uint64_t *)(puVar4 + 0x40) ^ (uint64_t)puVar4);
    return;
}

// ============================================================
// Function: FUN_1800d05e0
// Address: 0x1800d05e0
// Size: 136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_33h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800d05e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    int64_t *piVar7;
    uint64_t unaff_RSI;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    undefined auStack_50 [24];
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    int64_t var_28h;
    
    var_38h._0_4_ = *(undefined4 *)arg2;
    var_38h._4_4_ = *(undefined4 *)(arg2 + 4);
    uStack_30 = *(undefined4 *)(arg2 + 8);
    uStack_2c = *(undefined4 *)(arg2 + 0xc);
    uVar4 = fcn.1800cf010((undefined4)var_38h, &var_38h);
    puVar6 = *(undefined4 **)(arg1 + 0x280);
    if (puVar6 != *(undefined4 **)(arg1 + 0x288)) {
        *puVar6 = uVar4;
        *(undefined2 *)((int64_t)puVar6 + 5) = var_38h._5_2_;
        *(undefined *)((int64_t)puVar6 + 7) = var_38h._7_1_;
        puVar6[3] = (undefined4)arg_28h;
        *(undefined *)(puVar6 + 1) = (undefined)placeholder_2;
        puVar6[2] = (int32_t)arg4;
        *(int64_t *)(arg1 + 0x280) = *(int64_t *)(arg1 + 0x280) + 0x10;
        return;
    }
    iVar10 = (int64_t)puVar6 - *(int64_t *)(arg1 + 0x278) >> 4;
    if (iVar10 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined4 **)(arg1 + 0x288) - *(int64_t *)(arg1 + 0x278) >> 4;
    if (0xfffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x0001800d0814:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar10 + 1;
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar9 = uVar1;
    if (uVar1 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0xfffffffffffffff < uVar9) goto code_r0x0001800d0814;
    uVar9 = uVar9 * 0x10;
    if (uVar9 == 0) {
        unaff_RSI = 0;
code_r0x0001800d0710:
        iVar10 = iVar10 * 0x10;
        *(undefined2 *)(iVar10 + 5 + unaff_RSI) = var_38h._5_2_;
        *(undefined *)(iVar10 + 7 + unaff_RSI) = var_38h._7_1_;
        *(undefined4 *)(iVar10 + 0xc + unaff_RSI) = (undefined4)arg_28h;
        *(undefined4 *)(iVar10 + unaff_RSI) = uVar4;
        *(undefined *)(iVar10 + 4 + unaff_RSI) = (undefined)placeholder_2;
        *(int32_t *)(iVar10 + 8 + unaff_RSI) = (int32_t)arg4;
        puVar2 = *(undefined4 **)(arg1 + 0x278);
        if (puVar6 == *(undefined4 **)(arg1 + 0x280)) {
            iVar8 = (int64_t)*(undefined4 **)(arg1 + 0x280) - (int64_t)puVar2;
            uVar5 = unaff_RSI;
            puVar6 = puVar2;
        } else {
            fcn.180498030(unaff_RSI, puVar2, (int64_t)puVar6 - (int64_t)puVar2);
            iVar8 = *(int64_t *)(arg1 + 0x280) - (int64_t)puVar6;
            uVar5 = iVar10 + 0x10 + unaff_RSI;
        }
        fcn.180498030(uVar5, puVar6, iVar8);
        iVar10 = *(int64_t *)(arg1 + 0x278);
        if (iVar10 == 0) goto code_r0x0001800d07cf;
        iVar8 = iVar10;
        piVar7 = &var_58h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x288) - iVar10 & 0xfffffffffffffff0U)) &&
           (iVar8 = *(int64_t *)(iVar10 + -8), piVar7 = &var_58h, 0x1f < (iVar10 - iVar8) - 8U))
        goto code_r0x0001800d07c0;
    } else {
        if (uVar9 < 0x1000) {
            unaff_RSI = fcn.180459890(uVar9);
            goto code_r0x0001800d0710;
        }
        if (uVar9 + 0x27 <= uVar9) goto code_r0x0001800d0814;
        iVar8 = fcn.180459890();
        if (iVar8 != 0) {
            unaff_RSI = iVar8 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar8;
            goto code_r0x0001800d0710;
        }
code_r0x0001800d07c0:
        pcVar3 = (code *)swi(0x29);
        iVar8 = (*pcVar3)(5);
        piVar7 = (int64_t *)auStack_50;
    }
    *(undefined8 *)((int64_t)piVar7 + -8) = 0x1800d07cf;
    fcn.180459c3c(iVar8);
code_r0x0001800d07cf:
    *(uint64_t *)(arg1 + 0x278) = unaff_RSI;
    *(uint64_t *)(arg1 + 0x280) = uVar1 * 0x10 + unaff_RSI;
    *(uint64_t *)(arg1 + 0x288) = uVar9 + unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800d0668
// Address: 0x1800d0668
// Size: 422 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_33h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800d05e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    int64_t *piVar7;
    uint64_t unaff_RSI;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    undefined auStack_50 [24];
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    int64_t var_28h;
    
    var_38h._0_4_ = *(undefined4 *)arg2;
    var_38h._4_4_ = *(undefined4 *)(arg2 + 4);
    uStack_30 = *(undefined4 *)(arg2 + 8);
    uStack_2c = *(undefined4 *)(arg2 + 0xc);
    uVar4 = fcn.1800cf010((undefined4)var_38h, &var_38h);
    puVar6 = *(undefined4 **)(arg1 + 0x280);
    if (puVar6 != *(undefined4 **)(arg1 + 0x288)) {
        *puVar6 = uVar4;
        *(undefined2 *)((int64_t)puVar6 + 5) = var_38h._5_2_;
        *(undefined *)((int64_t)puVar6 + 7) = var_38h._7_1_;
        puVar6[3] = (undefined4)arg_28h;
        *(undefined *)(puVar6 + 1) = (undefined)placeholder_2;
        puVar6[2] = (int32_t)arg4;
        *(int64_t *)(arg1 + 0x280) = *(int64_t *)(arg1 + 0x280) + 0x10;
        return;
    }
    iVar10 = (int64_t)puVar6 - *(int64_t *)(arg1 + 0x278) >> 4;
    if (iVar10 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined4 **)(arg1 + 0x288) - *(int64_t *)(arg1 + 0x278) >> 4;
    if (0xfffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x0001800d0814:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar10 + 1;
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar9 = uVar1;
    if (uVar1 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0xfffffffffffffff < uVar9) goto code_r0x0001800d0814;
    uVar9 = uVar9 * 0x10;
    if (uVar9 == 0) {
        unaff_RSI = 0;
code_r0x0001800d0710:
        iVar10 = iVar10 * 0x10;
        *(undefined2 *)(iVar10 + 5 + unaff_RSI) = var_38h._5_2_;
        *(undefined *)(iVar10 + 7 + unaff_RSI) = var_38h._7_1_;
        *(undefined4 *)(iVar10 + 0xc + unaff_RSI) = (undefined4)arg_28h;
        *(undefined4 *)(iVar10 + unaff_RSI) = uVar4;
        *(undefined *)(iVar10 + 4 + unaff_RSI) = (undefined)placeholder_2;
        *(int32_t *)(iVar10 + 8 + unaff_RSI) = (int32_t)arg4;
        puVar2 = *(undefined4 **)(arg1 + 0x278);
        if (puVar6 == *(undefined4 **)(arg1 + 0x280)) {
            iVar8 = (int64_t)*(undefined4 **)(arg1 + 0x280) - (int64_t)puVar2;
            uVar5 = unaff_RSI;
            puVar6 = puVar2;
        } else {
            fcn.180498030(unaff_RSI, puVar2, (int64_t)puVar6 - (int64_t)puVar2);
            iVar8 = *(int64_t *)(arg1 + 0x280) - (int64_t)puVar6;
            uVar5 = iVar10 + 0x10 + unaff_RSI;
        }
        fcn.180498030(uVar5, puVar6, iVar8);
        iVar10 = *(int64_t *)(arg1 + 0x278);
        if (iVar10 == 0) goto code_r0x0001800d07cf;
        iVar8 = iVar10;
        piVar7 = &var_58h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x288) - iVar10 & 0xfffffffffffffff0U)) &&
           (iVar8 = *(int64_t *)(iVar10 + -8), piVar7 = &var_58h, 0x1f < (iVar10 - iVar8) - 8U))
        goto code_r0x0001800d07c0;
    } else {
        if (uVar9 < 0x1000) {
            unaff_RSI = fcn.180459890(uVar9);
            goto code_r0x0001800d0710;
        }
        if (uVar9 + 0x27 <= uVar9) goto code_r0x0001800d0814;
        iVar8 = fcn.180459890();
        if (iVar8 != 0) {
            unaff_RSI = iVar8 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar8;
            goto code_r0x0001800d0710;
        }
code_r0x0001800d07c0:
        pcVar3 = (code *)swi(0x29);
        iVar8 = (*pcVar3)(5);
        piVar7 = (int64_t *)auStack_50;
    }
    *(undefined8 *)((int64_t)piVar7 + -8) = 0x1800d07cf;
    fcn.180459c3c(iVar8);
code_r0x0001800d07cf:
    *(uint64_t *)(arg1 + 0x278) = unaff_RSI;
    *(uint64_t *)(arg1 + 0x280) = uVar1 * 0x10 + unaff_RSI;
    *(uint64_t *)(arg1 + 0x288) = uVar9 + unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800d080e
// Address: 0x1800d080e
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_33h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800d05e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    int64_t *piVar7;
    uint64_t unaff_RSI;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    undefined auStack_50 [24];
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    int64_t var_28h;
    
    var_38h._0_4_ = *(undefined4 *)arg2;
    var_38h._4_4_ = *(undefined4 *)(arg2 + 4);
    uStack_30 = *(undefined4 *)(arg2 + 8);
    uStack_2c = *(undefined4 *)(arg2 + 0xc);
    uVar4 = fcn.1800cf010((undefined4)var_38h, &var_38h);
    puVar6 = *(undefined4 **)(arg1 + 0x280);
    if (puVar6 != *(undefined4 **)(arg1 + 0x288)) {
        *puVar6 = uVar4;
        *(undefined2 *)((int64_t)puVar6 + 5) = var_38h._5_2_;
        *(undefined *)((int64_t)puVar6 + 7) = var_38h._7_1_;
        puVar6[3] = (undefined4)arg_28h;
        *(undefined *)(puVar6 + 1) = (undefined)placeholder_2;
        puVar6[2] = (int32_t)arg4;
        *(int64_t *)(arg1 + 0x280) = *(int64_t *)(arg1 + 0x280) + 0x10;
        return;
    }
    iVar10 = (int64_t)puVar6 - *(int64_t *)(arg1 + 0x278) >> 4;
    if (iVar10 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined4 **)(arg1 + 0x288) - *(int64_t *)(arg1 + 0x278) >> 4;
    if (0xfffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x0001800d0814:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar10 + 1;
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar9 = uVar1;
    if (uVar1 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0xfffffffffffffff < uVar9) goto code_r0x0001800d0814;
    uVar9 = uVar9 * 0x10;
    if (uVar9 == 0) {
        unaff_RSI = 0;
code_r0x0001800d0710:
        iVar10 = iVar10 * 0x10;
        *(undefined2 *)(iVar10 + 5 + unaff_RSI) = var_38h._5_2_;
        *(undefined *)(iVar10 + 7 + unaff_RSI) = var_38h._7_1_;
        *(undefined4 *)(iVar10 + 0xc + unaff_RSI) = (undefined4)arg_28h;
        *(undefined4 *)(iVar10 + unaff_RSI) = uVar4;
        *(undefined *)(iVar10 + 4 + unaff_RSI) = (undefined)placeholder_2;
        *(int32_t *)(iVar10 + 8 + unaff_RSI) = (int32_t)arg4;
        puVar2 = *(undefined4 **)(arg1 + 0x278);
        if (puVar6 == *(undefined4 **)(arg1 + 0x280)) {
            iVar8 = (int64_t)*(undefined4 **)(arg1 + 0x280) - (int64_t)puVar2;
            uVar5 = unaff_RSI;
            puVar6 = puVar2;
        } else {
            fcn.180498030(unaff_RSI, puVar2, (int64_t)puVar6 - (int64_t)puVar2);
            iVar8 = *(int64_t *)(arg1 + 0x280) - (int64_t)puVar6;
            uVar5 = iVar10 + 0x10 + unaff_RSI;
        }
        fcn.180498030(uVar5, puVar6, iVar8);
        iVar10 = *(int64_t *)(arg1 + 0x278);
        if (iVar10 == 0) goto code_r0x0001800d07cf;
        iVar8 = iVar10;
        piVar7 = &var_58h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x288) - iVar10 & 0xfffffffffffffff0U)) &&
           (iVar8 = *(int64_t *)(iVar10 + -8), piVar7 = &var_58h, 0x1f < (iVar10 - iVar8) - 8U))
        goto code_r0x0001800d07c0;
    } else {
        if (uVar9 < 0x1000) {
            unaff_RSI = fcn.180459890(uVar9);
            goto code_r0x0001800d0710;
        }
        if (uVar9 + 0x27 <= uVar9) goto code_r0x0001800d0814;
        iVar8 = fcn.180459890();
        if (iVar8 != 0) {
            unaff_RSI = iVar8 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar8;
            goto code_r0x0001800d0710;
        }
code_r0x0001800d07c0:
        pcVar3 = (code *)swi(0x29);
        iVar8 = (*pcVar3)(5);
        piVar7 = (int64_t *)auStack_50;
    }
    *(undefined8 *)((int64_t)piVar7 + -8) = 0x1800d07cf;
    fcn.180459c3c(iVar8);
code_r0x0001800d07cf:
    *(uint64_t *)(arg1 + 0x278) = unaff_RSI;
    *(uint64_t *)(arg1 + 0x280) = uVar1 * 0x10 + unaff_RSI;
    *(uint64_t *)(arg1 + 0x288) = uVar9 + unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800d0814
// Address: 0x1800d0814
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_33h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800d05e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    int64_t *piVar7;
    uint64_t unaff_RSI;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    undefined auStack_50 [24];
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    int64_t var_28h;
    
    var_38h._0_4_ = *(undefined4 *)arg2;
    var_38h._4_4_ = *(undefined4 *)(arg2 + 4);
    uStack_30 = *(undefined4 *)(arg2 + 8);
    uStack_2c = *(undefined4 *)(arg2 + 0xc);
    uVar4 = fcn.1800cf010((undefined4)var_38h, &var_38h);
    puVar6 = *(undefined4 **)(arg1 + 0x280);
    if (puVar6 != *(undefined4 **)(arg1 + 0x288)) {
        *puVar6 = uVar4;
        *(undefined2 *)((int64_t)puVar6 + 5) = var_38h._5_2_;
        *(undefined *)((int64_t)puVar6 + 7) = var_38h._7_1_;
        puVar6[3] = (undefined4)arg_28h;
        *(undefined *)(puVar6 + 1) = (undefined)placeholder_2;
        puVar6[2] = (int32_t)arg4;
        *(int64_t *)(arg1 + 0x280) = *(int64_t *)(arg1 + 0x280) + 0x10;
        return;
    }
    iVar10 = (int64_t)puVar6 - *(int64_t *)(arg1 + 0x278) >> 4;
    if (iVar10 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined4 **)(arg1 + 0x288) - *(int64_t *)(arg1 + 0x278) >> 4;
    if (0xfffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x0001800d0814:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar10 + 1;
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar9 = uVar1;
    if (uVar1 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0xfffffffffffffff < uVar9) goto code_r0x0001800d0814;
    uVar9 = uVar9 * 0x10;
    if (uVar9 == 0) {
        unaff_RSI = 0;
code_r0x0001800d0710:
        iVar10 = iVar10 * 0x10;
        *(undefined2 *)(iVar10 + 5 + unaff_RSI) = var_38h._5_2_;
        *(undefined *)(iVar10 + 7 + unaff_RSI) = var_38h._7_1_;
        *(undefined4 *)(iVar10 + 0xc + unaff_RSI) = (undefined4)arg_28h;
        *(undefined4 *)(iVar10 + unaff_RSI) = uVar4;
        *(undefined *)(iVar10 + 4 + unaff_RSI) = (undefined)placeholder_2;
        *(int32_t *)(iVar10 + 8 + unaff_RSI) = (int32_t)arg4;
        puVar2 = *(undefined4 **)(arg1 + 0x278);
        if (puVar6 == *(undefined4 **)(arg1 + 0x280)) {
            iVar8 = (int64_t)*(undefined4 **)(arg1 + 0x280) - (int64_t)puVar2;
            uVar5 = unaff_RSI;
            puVar6 = puVar2;
        } else {
            fcn.180498030(unaff_RSI, puVar2, (int64_t)puVar6 - (int64_t)puVar2);
            iVar8 = *(int64_t *)(arg1 + 0x280) - (int64_t)puVar6;
            uVar5 = iVar10 + 0x10 + unaff_RSI;
        }
        fcn.180498030(uVar5, puVar6, iVar8);
        iVar10 = *(int64_t *)(arg1 + 0x278);
        if (iVar10 == 0) goto code_r0x0001800d07cf;
        iVar8 = iVar10;
        piVar7 = &var_58h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x288) - iVar10 & 0xfffffffffffffff0U)) &&
           (iVar8 = *(int64_t *)(iVar10 + -8), piVar7 = &var_58h, 0x1f < (iVar10 - iVar8) - 8U))
        goto code_r0x0001800d07c0;
    } else {
        if (uVar9 < 0x1000) {
            unaff_RSI = fcn.180459890(uVar9);
            goto code_r0x0001800d0710;
        }
        if (uVar9 + 0x27 <= uVar9) goto code_r0x0001800d0814;
        iVar8 = fcn.180459890();
        if (iVar8 != 0) {
            unaff_RSI = iVar8 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar8;
            goto code_r0x0001800d0710;
        }
code_r0x0001800d07c0:
        pcVar3 = (code *)swi(0x29);
        iVar8 = (*pcVar3)(5);
        piVar7 = (int64_t *)auStack_50;
    }
    *(undefined8 *)((int64_t)piVar7 + -8) = 0x1800d07cf;
    fcn.180459c3c(iVar8);
code_r0x0001800d07cf:
    *(uint64_t *)(arg1 + 0x278) = unaff_RSI;
    *(uint64_t *)(arg1 + 0x280) = uVar1 * 0x10 + unaff_RSI;
    *(uint64_t *)(arg1 + 0x288) = uVar9 + unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800d0820
// Address: 0x1800d0820
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.1800d0820(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    undefined *puVar7;
    int64_t iVar8;
    uint64_t unaff_RSI;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    
    var_28h._0_4_ = *(undefined4 *)arg2;
    var_28h._4_4_ = *(undefined4 *)(arg2 + 4);
    uStack_20 = *(undefined4 *)(arg2 + 8);
    uStack_1c = *(undefined4 *)(arg2 + 0xc);
    uVar4 = fcn.1800cf010((undefined4)var_28h, &var_28h);
    puVar6 = *(undefined4 **)(arg1 + 0x298);
    if (puVar6 != *(undefined4 **)(arg1 + 0x2a0)) {
        *puVar6 = uVar4;
        *(int64_t *)(arg1 + 0x298) = *(int64_t *)(arg1 + 0x298) + 4;
        return;
    }
    iVar8 = (int64_t)puVar6 - *(int64_t *)(arg1 + 0x290) >> 2;
    if (iVar8 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined4 **)(arg1 + 0x2a0) - *(int64_t *)(arg1 + 0x290) >> 2;
    if (0x3fffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x0001800d09fc:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar8 + 1;
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar10 = uVar1;
    if (uVar1 <= uVar5) {
        uVar10 = uVar5;
    }
    if (0x3fffffffffffffff < uVar10) goto code_r0x0001800d09fc;
    uVar10 = uVar10 * 4;
    if (uVar10 == 0) {
        unaff_RSI = 0;
code_r0x0001800d0925:
        *(undefined4 *)(unaff_RSI + iVar8 * 4) = uVar4;
        puVar2 = *(undefined4 **)(arg1 + 0x290);
        if (puVar6 == *(undefined4 **)(arg1 + 0x298)) {
            iVar9 = (int64_t)*(undefined4 **)(arg1 + 0x298) - (int64_t)puVar2;
            uVar5 = unaff_RSI;
            puVar6 = puVar2;
        } else {
            fcn.180498030(unaff_RSI, puVar2, (int64_t)puVar6 - (int64_t)puVar2);
            iVar9 = *(int64_t *)(arg1 + 0x298) - (int64_t)puVar6;
            uVar5 = unaff_RSI + (iVar8 + 1) * 4;
        }
        fcn.180498030(uVar5, puVar6, iVar9);
        iVar8 = *(int64_t *)(arg1 + 0x290);
        if (iVar8 == 0) goto code_r0x0001800d09bc;
        iVar9 = iVar8;
        puVar7 = auStack_48;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x2a0) - iVar8 >> 2) * 4)) &&
           (iVar9 = *(int64_t *)(iVar8 + -8), puVar7 = auStack_48, 0x1f < (iVar8 - iVar9) - 8U))
        goto code_r0x0001800d09aa;
    } else {
        if (uVar10 < 0x1000) {
            unaff_RSI = fcn.180459890(uVar10);
            goto code_r0x0001800d0925;
        }
        if (uVar10 + 0x27 <= uVar10) goto code_r0x0001800d09fc;
        iVar9 = fcn.180459890();
        if (iVar9 != 0) {
            unaff_RSI = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar9;
            goto code_r0x0001800d0925;
        }
code_r0x0001800d09aa:
        iVar9 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar7 = auStack_40;
    }
    *(undefined8 *)(puVar7 + -8) = 0x1800d09bc;
    fcn.180459c3c(iVar9);
code_r0x0001800d09bc:
    *(uint64_t *)(arg1 + 0x290) = unaff_RSI;
    *(uint64_t *)(arg1 + 0x298) = unaff_RSI + uVar1 * 4;
    *(uint64_t *)(arg1 + 0x2a0) = uVar10 + unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800d0879
// Address: 0x1800d0879
// Size: 381 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.1800d0820(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    undefined *puVar7;
    int64_t iVar8;
    uint64_t unaff_RSI;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    
    var_28h._0_4_ = *(undefined4 *)arg2;
    var_28h._4_4_ = *(undefined4 *)(arg2 + 4);
    uStack_20 = *(undefined4 *)(arg2 + 8);
    uStack_1c = *(undefined4 *)(arg2 + 0xc);
    uVar4 = fcn.1800cf010((undefined4)var_28h, &var_28h);
    puVar6 = *(undefined4 **)(arg1 + 0x298);
    if (puVar6 != *(undefined4 **)(arg1 + 0x2a0)) {
        *puVar6 = uVar4;
        *(int64_t *)(arg1 + 0x298) = *(int64_t *)(arg1 + 0x298) + 4;
        return;
    }
    iVar8 = (int64_t)puVar6 - *(int64_t *)(arg1 + 0x290) >> 2;
    if (iVar8 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined4 **)(arg1 + 0x2a0) - *(int64_t *)(arg1 + 0x290) >> 2;
    if (0x3fffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x0001800d09fc:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar8 + 1;
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar10 = uVar1;
    if (uVar1 <= uVar5) {
        uVar10 = uVar5;
    }
    if (0x3fffffffffffffff < uVar10) goto code_r0x0001800d09fc;
    uVar10 = uVar10 * 4;
    if (uVar10 == 0) {
        unaff_RSI = 0;
code_r0x0001800d0925:
        *(undefined4 *)(unaff_RSI + iVar8 * 4) = uVar4;
        puVar2 = *(undefined4 **)(arg1 + 0x290);
        if (puVar6 == *(undefined4 **)(arg1 + 0x298)) {
            iVar9 = (int64_t)*(undefined4 **)(arg1 + 0x298) - (int64_t)puVar2;
            uVar5 = unaff_RSI;
            puVar6 = puVar2;
        } else {
            fcn.180498030(unaff_RSI, puVar2, (int64_t)puVar6 - (int64_t)puVar2);
            iVar9 = *(int64_t *)(arg1 + 0x298) - (int64_t)puVar6;
            uVar5 = unaff_RSI + (iVar8 + 1) * 4;
        }
        fcn.180498030(uVar5, puVar6, iVar9);
        iVar8 = *(int64_t *)(arg1 + 0x290);
        if (iVar8 == 0) goto code_r0x0001800d09bc;
        iVar9 = iVar8;
        puVar7 = auStack_48;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x2a0) - iVar8 >> 2) * 4)) &&
           (iVar9 = *(int64_t *)(iVar8 + -8), puVar7 = auStack_48, 0x1f < (iVar8 - iVar9) - 8U))
        goto code_r0x0001800d09aa;
    } else {
        if (uVar10 < 0x1000) {
            unaff_RSI = fcn.180459890(uVar10);
            goto code_r0x0001800d0925;
        }
        if (uVar10 + 0x27 <= uVar10) goto code_r0x0001800d09fc;
        iVar9 = fcn.180459890();
        if (iVar9 != 0) {
            unaff_RSI = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar9;
            goto code_r0x0001800d0925;
        }
code_r0x0001800d09aa:
        iVar9 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar7 = auStack_40;
    }
    *(undefined8 *)(puVar7 + -8) = 0x1800d09bc;
    fcn.180459c3c(iVar9);
code_r0x0001800d09bc:
    *(uint64_t *)(arg1 + 0x290) = unaff_RSI;
    *(uint64_t *)(arg1 + 0x298) = unaff_RSI + uVar1 * 4;
    *(uint64_t *)(arg1 + 0x2a0) = uVar10 + unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800d09f6
// Address: 0x1800d09f6
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.1800d0820(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    undefined *puVar7;
    int64_t iVar8;
    uint64_t unaff_RSI;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    
    var_28h._0_4_ = *(undefined4 *)arg2;
    var_28h._4_4_ = *(undefined4 *)(arg2 + 4);
    uStack_20 = *(undefined4 *)(arg2 + 8);
    uStack_1c = *(undefined4 *)(arg2 + 0xc);
    uVar4 = fcn.1800cf010((undefined4)var_28h, &var_28h);
    puVar6 = *(undefined4 **)(arg1 + 0x298);
    if (puVar6 != *(undefined4 **)(arg1 + 0x2a0)) {
        *puVar6 = uVar4;
        *(int64_t *)(arg1 + 0x298) = *(int64_t *)(arg1 + 0x298) + 4;
        return;
    }
    iVar8 = (int64_t)puVar6 - *(int64_t *)(arg1 + 0x290) >> 2;
    if (iVar8 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined4 **)(arg1 + 0x2a0) - *(int64_t *)(arg1 + 0x290) >> 2;
    if (0x3fffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x0001800d09fc:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar8 + 1;
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar10 = uVar1;
    if (uVar1 <= uVar5) {
        uVar10 = uVar5;
    }
    if (0x3fffffffffffffff < uVar10) goto code_r0x0001800d09fc;
    uVar10 = uVar10 * 4;
    if (uVar10 == 0) {
        unaff_RSI = 0;
code_r0x0001800d0925:
        *(undefined4 *)(unaff_RSI + iVar8 * 4) = uVar4;
        puVar2 = *(undefined4 **)(arg1 + 0x290);
        if (puVar6 == *(undefined4 **)(arg1 + 0x298)) {
            iVar9 = (int64_t)*(undefined4 **)(arg1 + 0x298) - (int64_t)puVar2;
            uVar5 = unaff_RSI;
            puVar6 = puVar2;
        } else {
            fcn.180498030(unaff_RSI, puVar2, (int64_t)puVar6 - (int64_t)puVar2);
            iVar9 = *(int64_t *)(arg1 + 0x298) - (int64_t)puVar6;
            uVar5 = unaff_RSI + (iVar8 + 1) * 4;
        }
        fcn.180498030(uVar5, puVar6, iVar9);
        iVar8 = *(int64_t *)(arg1 + 0x290);
        if (iVar8 == 0) goto code_r0x0001800d09bc;
        iVar9 = iVar8;
        puVar7 = auStack_48;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x2a0) - iVar8 >> 2) * 4)) &&
           (iVar9 = *(int64_t *)(iVar8 + -8), puVar7 = auStack_48, 0x1f < (iVar8 - iVar9) - 8U))
        goto code_r0x0001800d09aa;
    } else {
        if (uVar10 < 0x1000) {
            unaff_RSI = fcn.180459890(uVar10);
            goto code_r0x0001800d0925;
        }
        if (uVar10 + 0x27 <= uVar10) goto code_r0x0001800d09fc;
        iVar9 = fcn.180459890();
        if (iVar9 != 0) {
            unaff_RSI = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar9;
            goto code_r0x0001800d0925;
        }
code_r0x0001800d09aa:
        iVar9 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar7 = auStack_40;
    }
    *(undefined8 *)(puVar7 + -8) = 0x1800d09bc;
    fcn.180459c3c(iVar9);
code_r0x0001800d09bc:
    *(uint64_t *)(arg1 + 0x290) = unaff_RSI;
    *(uint64_t *)(arg1 + 0x298) = unaff_RSI + uVar1 * 4;
    *(uint64_t *)(arg1 + 0x2a0) = uVar10 + unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800d09fc
// Address: 0x1800d09fc
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.1800d0820(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    undefined *puVar7;
    int64_t iVar8;
    uint64_t unaff_RSI;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    
    var_28h._0_4_ = *(undefined4 *)arg2;
    var_28h._4_4_ = *(undefined4 *)(arg2 + 4);
    uStack_20 = *(undefined4 *)(arg2 + 8);
    uStack_1c = *(undefined4 *)(arg2 + 0xc);
    uVar4 = fcn.1800cf010((undefined4)var_28h, &var_28h);
    puVar6 = *(undefined4 **)(arg1 + 0x298);
    if (puVar6 != *(undefined4 **)(arg1 + 0x2a0)) {
        *puVar6 = uVar4;
        *(int64_t *)(arg1 + 0x298) = *(int64_t *)(arg1 + 0x298) + 4;
        return;
    }
    iVar8 = (int64_t)puVar6 - *(int64_t *)(arg1 + 0x290) >> 2;
    if (iVar8 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined4 **)(arg1 + 0x2a0) - *(int64_t *)(arg1 + 0x290) >> 2;
    if (0x3fffffffffffffff - (uVar5 >> 1) < uVar5) {
code_r0x0001800d09fc:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar8 + 1;
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar10 = uVar1;
    if (uVar1 <= uVar5) {
        uVar10 = uVar5;
    }
    if (0x3fffffffffffffff < uVar10) goto code_r0x0001800d09fc;
    uVar10 = uVar10 * 4;
    if (uVar10 == 0) {
        unaff_RSI = 0;
code_r0x0001800d0925:
        *(undefined4 *)(unaff_RSI + iVar8 * 4) = uVar4;
        puVar2 = *(undefined4 **)(arg1 + 0x290);
        if (puVar6 == *(undefined4 **)(arg1 + 0x298)) {
            iVar9 = (int64_t)*(undefined4 **)(arg1 + 0x298) - (int64_t)puVar2;
            uVar5 = unaff_RSI;
            puVar6 = puVar2;
        } else {
            fcn.180498030(unaff_RSI, puVar2, (int64_t)puVar6 - (int64_t)puVar2);
            iVar9 = *(int64_t *)(arg1 + 0x298) - (int64_t)puVar6;
            uVar5 = unaff_RSI + (iVar8 + 1) * 4;
        }
        fcn.180498030(uVar5, puVar6, iVar9);
        iVar8 = *(int64_t *)(arg1 + 0x290);
        if (iVar8 == 0) goto code_r0x0001800d09bc;
        iVar9 = iVar8;
        puVar7 = auStack_48;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x2a0) - iVar8 >> 2) * 4)) &&
           (iVar9 = *(int64_t *)(iVar8 + -8), puVar7 = auStack_48, 0x1f < (iVar8 - iVar9) - 8U))
        goto code_r0x0001800d09aa;
    } else {
        if (uVar10 < 0x1000) {
            unaff_RSI = fcn.180459890(uVar10);
            goto code_r0x0001800d0925;
        }
        if (uVar10 + 0x27 <= uVar10) goto code_r0x0001800d09fc;
        iVar9 = fcn.180459890();
        if (iVar9 != 0) {
            unaff_RSI = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar9;
            goto code_r0x0001800d0925;
        }
code_r0x0001800d09aa:
        iVar9 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar7 = auStack_40;
    }
    *(undefined8 *)(puVar7 + -8) = 0x1800d09bc;
    fcn.180459c3c(iVar9);
code_r0x0001800d09bc:
    *(uint64_t *)(arg1 + 0x290) = unaff_RSI;
    *(uint64_t *)(arg1 + 0x298) = unaff_RSI + uVar1 * 4;
    *(uint64_t *)(arg1 + 0x2a0) = uVar10 + unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800d0a10
// Address: 0x1800d0a10
// Size: 1159 bytes
// ============================================================
void fcn.1800d0a10(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    uint64_t *puVar5;
    undefined8 *puVar6;
    undefined4 *puVar7;
    uint64_t uVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    undefined *puVar11;
    undefined *puVar12;
    int64_t iVar13;
    uint64_t uVar14;
    uint64_t *unaff_RDI;
    uint64_t uVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    int64_t var_1h;
    int64_t iStackX_18;
    int64_t iStackX_20;
    undefined8 uStack_b0;
    undefined auStack_a8 [8];
    undefined auStack_a0 [24];
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar11 = auStack_a8;
    puVar12 = auStack_a8;
    if ((*(uint8_t *)(arg1 + 0x398) & 0x10) == 0) {
        return;
    }
    uVar16 = *(uint64_t *)(arg1 + 0x360);
    puVar17 = (undefined8 *)(arg1 + 0x350);
    iStackX_18 = arg3;
    iStackX_20 = arg4;
    func_0x0001800d4b20(puVar17, arg2, &iStackX_18);
    func_0x00018000b460(puVar17, 0);
    uVar15 = *(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x28) >> 2;
    puVar7 = *(undefined4 **)(arg1 + 0x340);
    if (puVar7 == *(undefined4 **)(arg1 + 0x348)) {
        iVar13 = (int64_t)puVar7 - *(int64_t *)(arg1 + 0x338) >> 3;
        if (iVar13 == 0x1fffffffffffffff) {
            fcn.180010010();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar10 = (int64_t)*(undefined4 **)(arg1 + 0x348) - *(int64_t *)(arg1 + 0x338) >> 3;
        if (0x1fffffffffffffff - (uVar10 >> 1) < uVar10) goto code_r0x0001800d0e8b;
        uVar10 = (uVar10 >> 1) + uVar10;
        uVar14 = iVar13 + 1U;
        if (iVar13 + 1U <= uVar10) {
            uVar14 = uVar10;
        }
        if (0x1fffffffffffffff < uVar14) goto code_r0x0001800d0e8b;
        uVar10 = uVar14 * 8;
        if (uVar10 == 0) {
            unaff_RDI = (uint64_t *)0x0;
code_r0x0001800d0b3f:
            *(int32_t *)(unaff_RDI + iVar13) = (int32_t)uVar15;
            *(int32_t *)((int64_t)unaff_RDI + iVar13 * 8 + 4) = (int32_t)uVar16;
            puVar1 = *(undefined4 **)(arg1 + 0x338);
            if (puVar7 == *(undefined4 **)(arg1 + 0x340)) {
                iVar4 = (int64_t)*(undefined4 **)(arg1 + 0x340) - (int64_t)puVar1;
                puVar5 = unaff_RDI;
                puVar7 = puVar1;
            } else {
                fcn.180498030(unaff_RDI, puVar1, (int64_t)puVar7 - (int64_t)puVar1);
                iVar4 = *(int64_t *)(arg1 + 0x340) - (int64_t)puVar7;
                puVar5 = unaff_RDI + iVar13 + 1;
            }
            fcn.180498030(puVar5, puVar7, iVar4);
            iVar4 = *(int64_t *)(arg1 + 0x338);
            if (iVar4 != 0) {
                uVar8 = (*(int64_t *)(arg1 + 0x348) - iVar4 >> 3) * 8;
                if (0xfff < uVar8) {
                    if (0x1f < (iVar4 - *(int64_t *)(iVar4 + -8)) - 8U) goto code_r0x0001800d0d29;
                    uVar8 = uVar8 + 0x27;
                    iVar4 = *(int64_t *)(iVar4 + -8);
                }
                fcn.180459c3c(iVar4, uVar8);
            }
            *(uint64_t **)(arg1 + 0x338) = unaff_RDI;
            *(uint64_t **)(arg1 + 0x340) = unaff_RDI + iVar13 + 1;
            *(uint64_t **)(arg1 + 0x348) = unaff_RDI + uVar14;
            goto code_r0x0001800d0bfa;
        }
        if (uVar10 < 0x1000) {
            unaff_RDI = (uint64_t *)fcn.180459890(uVar10);
            goto code_r0x0001800d0b3f;
        }
        if (uVar10 + 0x27 <= uVar10) goto code_r0x0001800d0e8b;
        uVar8 = fcn.180459890();
        if (uVar8 != 0) {
            unaff_RDI = (uint64_t *)(uVar8 + 0x27 & 0xffffffffffffffe0);
            unaff_RDI[-1] = uVar8;
            goto code_r0x0001800d0b3f;
        }
code_r0x0001800d0d29:
        pcVar2 = (code *)swi(0x29);
        iVar4 = (*pcVar2)(5);
        puVar11 = auStack_a0;
    } else {
        *puVar7 = (int32_t)uVar15;
        puVar7[1] = (int32_t)uVar16;
        *(int64_t *)(arg1 + 0x340) = *(int64_t *)(arg1 + 0x340) + 8;
code_r0x0001800d0bfa:
        unaff_RDI = (uint64_t *)(arg1 + 0x3b8);
        if (0xf < *(uint64_t *)(arg1 + 0x368)) {
            puVar17 = (undefined8 *)*puVar17;
        }
        iVar13 = (int64_t)puVar17 + uVar16;
        var_88h = iVar13;
        puVar17 = *(undefined8 **)(arg1 + 0x3c0);
        if (puVar17 != *(undefined8 **)(arg1 + 0x3c8)) {
            *(undefined4 *)puVar17 = *(undefined4 *)(arg1 + 0x270);
            *(undefined (*) [16])(puVar17 + 1) = ZEXT816(0);
            puVar17[3] = 0;
            puVar17[4] = 0;
            uVar3 = func_0x000180498cd0(iVar13);
            func_0x000180004830(puVar17 + 1, iVar13, uVar3);
            *(int64_t *)(arg1 + 0x3c0) = *(int64_t *)(arg1 + 0x3c0) + 0x28;
            return;
        }
        iVar13 = (int64_t)((int64_t)puVar17 - *unaff_RDI) / 0x28;
        if (iVar13 == 0x666666666666666) {
            fcn.180010010();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar15 = (int64_t)((int64_t)*(undefined8 **)(arg1 + 0x3c8) - *unaff_RDI) / 0x28;
        if (0x666666666666666 - (uVar15 >> 1) < uVar15) {
code_r0x0001800d0e8b:
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar16 = iVar13 + 1;
        uVar15 = (uVar15 >> 1) + uVar15;
        uVar10 = uVar16;
        if (uVar16 <= uVar15) {
            uVar10 = uVar15;
        }
        if (0x666666666666666 < uVar10) goto code_r0x0001800d0e8b;
        uVar15 = uVar10 * 0x28;
        if (uVar15 == 0) {
            uVar14 = 0;
            puVar12 = auStack_a8;
            goto code_r0x0001800d0d49;
        }
        if (uVar15 < 0x1000) {
            uVar14 = fcn.180459890(uVar15);
            goto code_r0x0001800d0d49;
        }
        if (uVar15 + 0x27 <= uVar15) goto code_r0x0001800d0e8b;
        iVar4 = fcn.180459890();
        if (iVar4 == 0) goto code_r0x0001800d0d29;
    }
    uVar14 = iVar4 + 0x27U & 0xffffffffffffffe0;
    *(int64_t *)(uVar14 - 8) = iVar4;
    puVar12 = puVar11;
code_r0x0001800d0d49:
    puVar1 = (undefined4 *)(uVar14 + iVar13 * 0x28);
    puVar7 = puVar1 + 10;
    *(undefined4 **)(puVar12 + 0x28) = puVar7;
    *(uint64_t **)(puVar12 + 0x30) = unaff_RDI;
    *(uint64_t *)(puVar12 + 0x38) = uVar14;
    *(uint64_t *)(puVar12 + 0x40) = uVar10;
    *(undefined4 **)(puVar12 + 0x48) = puVar7;
    *(undefined4 **)(puVar12 + 0x50) = puVar7;
    *puVar1 = *(undefined4 *)(arg1 + 0x270);
    *(undefined (*) [16])(puVar1 + 2) = ZEXT816(0);
    *(undefined8 *)(puVar1 + 6) = 0;
    *(undefined8 *)(puVar1 + 8) = 0;
    *(undefined8 *)(puVar12 + -8) = 0x1800d0da6;
    uVar3 = func_0x000180498cd0(*(undefined8 *)(puVar12 + 0x20));
    *(undefined8 *)(puVar12 + -8) = 0x1800d0db6;
    func_0x000180004830((undefined (*) [16])(puVar1 + 2), *(undefined8 *)(puVar12 + 0x20), uVar3);
    puVar9 = (undefined8 *)unaff_RDI[1];
    puVar6 = (undefined8 *)*unaff_RDI;
    uVar10 = uVar14;
    if (puVar17 != puVar9) {
        *(undefined8 *)(puVar12 + -8) = 0x1800d0dcd;
        func_0x00018007efa0(puVar6, puVar17, uVar14);
        uVar10 = *(uint64_t *)(puVar12 + 0x28);
        puVar9 = (undefined8 *)unaff_RDI[1];
        puVar6 = puVar17;
    }
    *(undefined8 *)(puVar12 + -8) = 0x1800d0dde;
    func_0x00018007efa0(puVar6, puVar9, uVar10);
    uVar10 = *unaff_RDI;
    if (uVar10 != 0) {
        uVar8 = unaff_RDI[1];
        for (; uVar10 != uVar8; uVar10 = uVar10 + 0x28) {
            *(undefined8 *)(puVar12 + -8) = 0x1800d0df9;
            func_0x000180004e40(uVar10 + 8);
        }
        uVar10 = *unaff_RDI;
        uVar8 = uVar10;
        if (0xfff < (uint64_t)(((int64_t)(unaff_RDI[2] - uVar10) / 0x28) * 0x28)) {
            uVar8 = *(uint64_t *)(uVar10 - 8);
            uVar10 = (uVar10 - uVar8) - 8;
            if (0x1f < uVar10) {
                pcVar2 = (code *)swi(0x29);
                uVar8 = uVar10;
                (*pcVar2)(5);
                puVar12 = puVar12 + 8;
            }
        }
        *(undefined8 *)(puVar12 + -8) = 0x1800d0e62;
        fcn.180459c3c(uVar8);
    }
    *unaff_RDI = uVar14;
    unaff_RDI[1] = uVar14 + uVar16 * 0x28;
    unaff_RDI[2] = uVar15 + uVar14;
    return;
}

// ============================================================
// Function: FUN_1800d0ea0
// Address: 0x1800d0ea0
// Size: 3972 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d0ea0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined uVar1;
    undefined4 uVar2;
    undefined *puVar3;
    uint32_t *puVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined uVar7;
    undefined8 *puVar8;
    int32_t *piVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    undefined *puVar13;
    uint32_t *puVar14;
    uint64_t uVar15;
    int32_t *piVar16;
    undefined4 *puVar17;
    undefined in_R9B;
    int64_t iVar18;
    uint32_t uVar19;
    int64_t iVar20;
    int64_t iVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    iVar10 = *(int64_t *)arg1;
    iVar20 = (arg3 & 0xffffffffU) * 0xa8;
    func_0x0001800cdc80(arg2, *(undefined *)(iVar20 + 0x20 + iVar10));
    func_0x0001800cdc80(arg2, *(undefined *)(iVar20 + 0x21 + iVar10));
    func_0x0001800cdc80(arg2, *(undefined *)(iVar20 + 0x22 + iVar10));
    func_0x0001800cdc80(arg2, *(undefined *)(iVar20 + 0x23 + iVar10));
    func_0x0001800cdc80(arg2, in_R9B);
    if (((*(int64_t *)(iVar20 + 0x98 + iVar10) == 0) && (*(int64_t *)(arg1 + 0x2c0) == *(int64_t *)(arg1 + 0x2c8))) &&
       (*(int64_t *)(arg1 + 0x2a8) == *(int64_t *)(arg1 + 0x2b0))) {
        func_0x0001800cdce0(arg2, 0);
    } else {
        puVar12 = (undefined8 *)(arg1 + 0x3d0);
        *(undefined8 *)(arg1 + 0x3e0) = 0;
        puVar8 = puVar12;
        if (0xf < *(uint64_t *)(arg1 + 1000)) {
            puVar8 = (undefined8 *)*puVar12;
        }
        *(undefined *)puVar8 = 0;
        func_0x0001800cdce0(puVar12, *(undefined4 *)(iVar20 + 0x98 + iVar10));
        func_0x0001800cdce0(puVar12, *(int64_t *)(arg1 + 0x2c8) - *(int64_t *)(arg1 + 0x2c0) >> 2 & 0xffffffff);
        func_0x0001800cdce0(puVar12, *(int64_t *)(arg1 + 0x2b0) - *(int64_t *)(arg1 + 0x2a8) >> 4 & 0xffffffff);
        puVar11 = (undefined8 *)(iVar10 + 0x88 + iVar20);
        puVar8 = puVar11 + 2;
        if (0xf < (uint64_t)puVar11[3]) {
            puVar11 = (undefined8 *)*puVar11;
        }
        func_0x00018000d970(puVar12, puVar11, *puVar8);
        puVar3 = *(undefined **)(arg1 + 0x2c8);
        for (puVar13 = *(undefined **)(arg1 + 0x2c0); puVar13 != puVar3; puVar13 = puVar13 + 4) {
            func_0x0001800cdc80(puVar12, *puVar13);
        }
        puVar3 = *(undefined **)(arg1 + 0x2b0);
        for (puVar13 = *(undefined **)(arg1 + 0x2a8); puVar13 != puVar3; puVar13 = puVar13 + 0x10) {
            var_18h._1_3_ = (unkuint3)((uint32_t)var_18h >> 8);
            var_18h._0_1_ = *puVar13;
            func_0x00018000d970(puVar12, &var_18h, 1);
            var_18h._0_4_ = CONCAT31(var_18h._1_3_, puVar13[4]);
            func_0x00018000d970(puVar12, &var_18h, 1);
            func_0x0001800cdce0(puVar12, *(undefined4 *)(puVar13 + 8));
            func_0x0001800cdce0(puVar12, *(int32_t *)(puVar13 + 0xc) - *(int32_t *)(puVar13 + 8));
        }
        func_0x0001800cdce0(arg2, *(undefined4 *)(arg1 + 0x3e0));
        if (0xf < *(uint64_t *)(arg1 + 1000)) {
            puVar12 = (undefined8 *)*puVar12;
        }
        func_0x00018000d970(arg2, puVar12, *(undefined8 *)(arg1 + 0x3e0));
    }
    func_0x0001800cdce0(arg2, *(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x28) >> 2 & 0xffffffff);
    puVar4 = *(uint32_t **)(arg1 + 0x30);
    puVar14 = *(uint32_t **)(arg1 + 0x28);
    if (puVar14 != puVar4) {
        uVar7 = (undefined)var_18h;
        do {
            iVar18 = *(int64_t *)(arg2 + 0x10);
            var_18h._0_4_ = *puVar14;
            if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 4) {
                func_0x00018000ee80(arg2, 4, uVar7, &var_18h, 4);
            } else {
                *(int64_t *)(arg2 + 0x10) = iVar18 + 4;
                if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                    *(uint32_t *)(iVar18 + arg2) = (uint32_t)var_18h;
                    *(undefined *)(iVar18 + 4 + arg2) = 0;
                } else {
                    iVar21 = *(int64_t *)arg2;
                    *(uint32_t *)(iVar18 + iVar21) = (uint32_t)var_18h;
                    *(undefined *)(iVar18 + 4 + iVar21) = 0;
                }
            }
            puVar14 = puVar14 + 1;
        } while (puVar14 != puVar4);
    }
    func_0x0001800cdce0(arg2, (int32_t)(*(int64_t *)(arg1 + 0x60) - *(int64_t *)(arg1 + 0x58) >> 3) * -0x55555555);
    puVar4 = *(uint32_t **)(arg1 + 0x60);
    puVar14 = *(uint32_t **)(arg1 + 0x58);
    var_8h = (int64_t)puVar14;
    if (puVar14 != puVar4) {
        uVar7 = (undefined)var_18h;
        do {
            if (*puVar14 < 10) {
                var_8h = (int64_t)puVar14;
    // switch table (10 cases) at 0x1800d1dfc
                switch(*puVar14) {
                case 0:
                    uVar15 = *(uint64_t *)(arg2 + 0x10);
                    var_18h._0_4_ = (uint32_t)var_18h & 0xffffff00;
                    if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
code_r0x0001800d11fb:
                        func_0x00018000ee80(arg2, 1, (undefined)var_18h, &var_18h, 1);
                    } else {
                        *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                        if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                            *(undefined2 *)(arg2 + uVar15) = 0;
                        } else {
                            *(undefined2 *)(*(int64_t *)arg2 + uVar15) = 0;
                        }
                    }
                    break;
                case 1:
                    uVar15 = *(uint64_t *)(arg2 + 0x10);
                    var_18h._0_1_ = 1;
                    if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                        func_0x00018000ee80(arg2, 1, 1, &var_18h, 1);
                    } else {
                        *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                        iVar18 = arg2;
                        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                            iVar18 = *(int64_t *)arg2;
                        }
                        *(undefined2 *)(iVar18 + uVar15) = 1;
                    }
                    uVar15 = *(uint64_t *)(arg2 + 0x10);
                    uVar1 = *(undefined *)(puVar14 + 2);
                    var_18h._0_4_ = CONCAT31(var_18h._1_3_, uVar1);
                    if (*(uint64_t *)(arg2 + 0x18) == uVar15) goto code_r0x0001800d11fb;
                    *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                    if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                        *(undefined *)(arg2 + uVar15) = uVar1;
                        *(undefined *)(arg2 + 1 + uVar15) = 0;
                    } else {
                        iVar18 = *(int64_t *)arg2;
                        *(undefined *)(iVar18 + uVar15) = uVar1;
                        *(undefined *)(iVar18 + 1 + uVar15) = 0;
                    }
                    break;
                case 2:
                    uVar15 = *(uint64_t *)(arg2 + 0x10);
                    var_18h._0_4_ = CONCAT31(var_18h._1_3_, 2);
                    if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                        func_0x00018000ee80(arg2, 1, 2, &var_18h, 1);
                    } else {
                        *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                        iVar18 = arg2;
                        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                            iVar18 = *(int64_t *)arg2;
                        }
                        *(undefined2 *)(iVar18 + uVar15) = 2;
                    }
                    iVar18 = *(int64_t *)(arg2 + 0x10);
                    var_8h = *(int64_t *)(puVar14 + 2);
                    if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 8) {
                        func_0x00018000ee80(arg2, 8, (undefined)var_18h, &var_8h, 8);
                    } else {
                        *(int64_t *)(arg2 + 0x10) = iVar18 + 8;
                        if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                            *(int64_t *)(arg2 + iVar18) = var_8h;
                            *(undefined *)(arg2 + 8 + iVar18) = 0;
                        } else {
                            iVar21 = *(int64_t *)arg2;
                            *(int64_t *)(iVar21 + iVar18) = var_8h;
                            *(undefined *)(iVar21 + 8 + iVar18) = 0;
                        }
                    }
                    break;
                case 3:
                    uVar15 = *(uint64_t *)(arg2 + 0x10);
                    var_18h._0_1_ = 9;
                    if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                        func_0x00018000ee80(arg2, 1, 9, &var_18h, 1);
                    } else {
                        *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                        if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                            *(undefined2 *)(arg2 + uVar15) = 9;
                        } else {
                            *(undefined2 *)(*(int64_t *)arg2 + uVar15) = 9;
                        }
                    }
                    if (*(int64_t *)(puVar14 + 2) < 0) {
                        var_18h._0_4_ = CONCAT31(var_18h._1_3_, 1);
                        func_0x00018000d970(arg2, &var_18h);
                        func_0x0001800cdce0(arg2, -*(int64_t *)(puVar14 + 2));
                    } else {
                        var_18h._0_4_ = (uint32_t)var_18h._1_3_ << 8;
                        func_0x00018000d970(arg2, &var_18h);
                        func_0x0001800cdce0(arg2, *(undefined8 *)(puVar14 + 2));
                    }
                    break;
                case 4:
                    uVar15 = *(uint64_t *)(arg2 + 0x10);
                    var_18h._0_4_ = CONCAT31(var_18h._1_3_, 7);
                    if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                        func_0x00018000ee80(arg2, 1, 7, &var_18h, 1);
                    } else {
                        *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                        iVar18 = arg2;
                        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                            iVar18 = *(int64_t *)arg2;
                        }
                        *(undefined2 *)(iVar18 + uVar15) = 7;
                    }
                    iVar18 = *(int64_t *)(arg2 + 0x10);
                    var_18h._0_4_ = puVar14[2];
                    if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 4) {
                        func_0x00018000ee80(arg2, 4, (undefined)var_18h, &var_18h, 4);
                    } else {
                        *(int64_t *)(arg2 + 0x10) = iVar18 + 4;
                        iVar21 = arg2;
                        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                            iVar21 = *(int64_t *)arg2;
                        }
                        *(uint32_t *)(iVar21 + iVar18) = (uint32_t)var_18h;
                        *(undefined *)(iVar21 + 4 + iVar18) = 0;
                    }
                    iVar18 = *(int64_t *)(arg2 + 0x10);
                    var_18h._0_4_ = puVar14[3];
                    if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 4) {
                        func_0x00018000ee80(arg2, 4, (undefined)var_18h, &var_18h, 4);
                    } else {
                        *(int64_t *)(arg2 + 0x10) = iVar18 + 4;
                        iVar21 = arg2;
                        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                            iVar21 = *(int64_t *)arg2;
                        }
                        *(uint32_t *)(iVar21 + iVar18) = (uint32_t)var_18h;
                        *(undefined *)(iVar21 + 4 + iVar18) = 0;
                    }
                    iVar18 = *(int64_t *)(arg2 + 0x10);
                    var_18h._0_4_ = puVar14[4];
                    if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 4) {
                        func_0x00018000ee80(arg2, 4, (undefined)var_18h, &var_18h, 4);
                    } else {
                        *(int64_t *)(arg2 + 0x10) = iVar18 + 4;
                        iVar21 = arg2;
                        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                            iVar21 = *(int64_t *)arg2;
                        }
                        *(uint32_t *)(iVar21 + iVar18) = (uint32_t)var_18h;
                        *(undefined *)(iVar21 + 4 + iVar18) = 0;
                    }
                    iVar18 = *(int64_t *)(arg2 + 0x10);
                    var_18h._0_4_ = puVar14[5];
                    if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 4) {
code_r0x0001800d15f3:
                        func_0x00018000ee80(arg2, 4, (undefined)var_18h, &var_18h, 4);
                    } else {
                        *(int64_t *)(arg2 + 0x10) = iVar18 + 4;
                        if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                            *(uint32_t *)(arg2 + iVar18) = (uint32_t)var_18h;
                            *(undefined *)(arg2 + 4 + iVar18) = 0;
                        } else {
                            iVar21 = *(int64_t *)arg2;
                            *(uint32_t *)(iVar21 + iVar18) = (uint32_t)var_18h;
                            *(undefined *)(iVar21 + 4 + iVar18) = 0;
                        }
                    }
                    break;
                case 5:
                    uVar15 = *(uint64_t *)(arg2 + 0x10);
                    var_18h._0_4_ = CONCAT31(var_18h._1_3_, 3);
                    if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
code_r0x0001800d166d:
                        func_0x00018000ee80(arg2, 1, (undefined)var_18h, &var_18h, 1);
                        func_0x0001800cdce0(arg2, puVar14[2]);
                    } else {
                        *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                        if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                            *(undefined2 *)(arg2 + uVar15) = 3;
                            func_0x0001800cdce0(arg2, puVar14[2]);
                        } else {
                            *(undefined2 *)(*(int64_t *)arg2 + uVar15) = 3;
                            func_0x0001800cdce0(arg2, puVar14[2]);
                        }
                    }
                    break;
                case 6:
                    uVar15 = *(uint64_t *)(arg2 + 0x10);
                    var_18h._0_4_ = CONCAT31(var_18h._1_3_, 4);
                    if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                        func_0x00018000ee80(arg2, 1, 4, &var_18h, 1);
                    } else {
                        *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                        iVar18 = arg2;
                        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                            iVar18 = *(int64_t *)arg2;
                        }
                        *(undefined2 *)(iVar18 + uVar15) = 4;
                    }
                    iVar18 = *(int64_t *)(arg2 + 0x10);
                    var_18h._0_4_ = puVar14[2];
                    if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 4) goto code_r0x0001800d15f3;
                    *(int64_t *)(arg2 + 0x10) = iVar18 + 4;
                    if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                        *(uint32_t *)(arg2 + iVar18) = (uint32_t)var_18h;
                        *(undefined *)(arg2 + 4 + iVar18) = 0;
                    } else {
                        iVar21 = *(int64_t *)arg2;
                        *(uint32_t *)(iVar21 + iVar18) = (uint32_t)var_18h;
                        *(undefined *)(iVar21 + 4 + iVar18) = 0;
                    }
                    break;
                case 7:
                    iVar18 = (uint64_t)puVar14[2] * 0x108 + *(int64_t *)(arg1 + 0xa0);
                    if ((*(char *)0x180777fb8 == '\0') || (*(char *)(iVar18 + 0x104) == '\0')) {
                        var_18h._0_4_ = CONCAT31(var_18h._1_3_, 5);
                        func_0x00018000d970(arg2, &var_18h, 1);
                        func_0x0001800cdce0(arg2, *(undefined4 *)(iVar18 + 0x100));
                        uVar15 = 0;
                        if (*(int32_t *)(iVar18 + 0x100) != 0) {
                            do {
                                func_0x0001800cdce0(arg2, (int64_t)*(int32_t *)(iVar18 + uVar15 * 4));
                                uVar19 = (int32_t)uVar15 + 1;
                                uVar15 = (uint64_t)uVar19;
                            } while (uVar19 < *(uint32_t *)(iVar18 + 0x100));
                        }
                    } else {
                        var_18h._0_4_ = CONCAT31(var_18h._1_3_, 8);
                        func_0x00018000d970(arg2, &var_18h, 1);
                        func_0x0001800cdce0(arg2, *(undefined4 *)(iVar18 + 0x100));
                        uVar15 = 0;
                        if (*(int32_t *)(iVar18 + 0x100) != 0) {
                            do {
                                func_0x0001800cdce0(arg2, (int64_t)*(int32_t *)(iVar18 + uVar15 * 4));
                                iVar21 = *(int64_t *)(arg2 + 0x10);
                                var_18h._0_4_ = *(uint32_t *)(iVar18 + 0x80 + uVar15 * 4);
                                if (*(uint64_t *)(arg2 + 0x18) - iVar21 < 4) {
                                    func_0x00018000ee80(arg2, 4, uVar7, &var_18h, 4);
                                } else {
                                    *(int64_t *)(arg2 + 0x10) = iVar21 + 4;
                                    if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                                        *(uint32_t *)(arg2 + iVar21) = (uint32_t)var_18h;
                                        *(undefined *)(arg2 + 4 + iVar21) = 0;
                                    } else {
                                        iVar5 = *(int64_t *)arg2;
                                        *(uint32_t *)(iVar5 + iVar21) = (uint32_t)var_18h;
                                        *(undefined *)(iVar5 + 4 + iVar21) = 0;
                                    }
                                }
                                uVar19 = (int32_t)uVar15 + 1;
                                uVar15 = (uint64_t)uVar19;
                            } while (uVar19 < *(uint32_t *)(iVar18 + 0x100));
                        }
                    }
                    break;
                case 8:
                    uVar15 = *(uint64_t *)(arg2 + 0x10);
                    var_18h._0_4_ = CONCAT31(var_18h._1_3_, 6);
                    if (*(uint64_t *)(arg2 + 0x18) == uVar15) goto code_r0x0001800d166d;
                    *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                    if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                        *(undefined2 *)(arg2 + uVar15) = 6;
                        func_0x0001800cdce0(arg2, puVar14[2]);
                    } else {
                        *(undefined2 *)(*(int64_t *)arg2 + uVar15) = 6;
                        func_0x0001800cdce0(arg2, puVar14[2]);
                    }
                    break;
                case 9:
                    uVar15 = *(uint64_t *)(arg2 + 0x10);
                    var_18h._0_4_ = CONCAT31(var_18h._1_3_, 10);
                    if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                        func_0x00018000ee80(arg2, 1, 10, &var_18h, 1);
                    } else {
                        *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                        if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                            *(undefined2 *)(arg2 + uVar15) = 10;
                        } else {
                            *(undefined2 *)(*(int64_t *)arg2 + uVar15) = 10;
                        }
                    }
                    iVar18 = *(int64_t *)(arg1 + 0xb8);
                    iVar21 = (uint64_t)puVar14[2] * 0x38;
                    func_0x0001800cdce0(arg2, (int64_t)*(int32_t *)(iVar21 + iVar18));
                    func_0x0001800cdce0(arg2, *(int64_t *)(iVar21 + 0x10 + iVar18) - *(int64_t *)(iVar21 + 8 + iVar18)
                                              >> 2);
                    func_0x0001800cdce0(arg2, *(int64_t *)(iVar21 + 0x28 + iVar18) -
                                              *(int64_t *)(iVar21 + 0x20 + iVar18) >> 2);
                    piVar9 = *(int32_t **)(iVar21 + 0x10 + iVar18);
                    for (piVar16 = *(int32_t **)(iVar21 + 8 + iVar18); piVar16 != piVar9; piVar16 = piVar16 + 1) {
                        func_0x0001800cdce0(arg2, (int64_t)*piVar16);
                    }
                    piVar9 = *(int32_t **)(iVar21 + 0x28 + iVar18);
                    puVar14 = (uint32_t *)var_8h;
                    for (piVar16 = *(int32_t **)(iVar21 + 0x20 + iVar18); piVar16 != piVar9; piVar16 = piVar16 + 1) {
                        var_8h = (int64_t)puVar14;
                        func_0x0001800cdce0(arg2, (int64_t)*piVar16);
                        puVar14 = (uint32_t *)var_8h;
                    }
                }
            }
            puVar14 = puVar14 + 6;
            var_8h = (int64_t)puVar14;
        } while (puVar14 != puVar4);
    }
    func_0x0001800cdce0(arg2, *(int64_t *)(arg1 + 0x78) - *(int64_t *)(arg1 + 0x70) >> 2 & 0xffffffff);
    puVar6 = *(undefined4 **)(arg1 + 0x78);
    for (puVar17 = *(undefined4 **)(arg1 + 0x70); puVar17 != puVar6; puVar17 = puVar17 + 1) {
        func_0x0001800cdce0(arg2, *puVar17);
    }
    func_0x0001800cdce0(arg2, (int64_t)*(int32_t *)(iVar20 + 0x28 + iVar10));
    func_0x0001800cdce0(arg2, *(undefined4 *)(iVar20 + 0x24 + iVar10));
    piVar9 = *(int32_t **)(arg1 + 0x40);
    do {
        if (piVar9 == *(int32_t **)(arg1 + 0x48)) {
            uVar15 = *(uint64_t *)(arg2 + 0x10);
            var_18h._0_4_ = CONCAT31(var_18h._1_3_, 1);
            if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                func_0x00018000ee80(arg2, 1, 1, &var_18h, 1);
            } else {
                *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                    *(undefined2 *)(uVar15 + arg2) = 1;
                } else {
                    *(undefined2 *)(uVar15 + *(int64_t *)arg2) = 1;
                }
            }
            func_0x0001800d1e30(arg1, arg2);
code_r0x0001800d1b38:
            if ((*(int64_t *)(arg1 + 0x278) == *(int64_t *)(arg1 + 0x280)) &&
               (*(int64_t *)(arg1 + 0x290) == *(int64_t *)(arg1 + 0x298))) {
                uVar15 = *(uint64_t *)(arg2 + 0x10);
                var_18h._0_4_ = (uint32_t)var_18h._1_3_ << 8;
                if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                    func_0x00018000ee80(arg2, 1, 0, &var_18h, 1);
                } else {
                    *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                    iVar10 = arg2;
                    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                        iVar10 = *(int64_t *)arg2;
                    }
                    *(undefined2 *)(iVar10 + uVar15) = 0;
                }
            } else {
                uVar15 = *(uint64_t *)(arg2 + 0x10);
                var_18h._0_4_ = CONCAT31(var_18h._1_3_, 1);
                if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                    func_0x00018000ee80(arg2, 1, 1, &var_18h, 1);
                } else {
                    *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                    iVar10 = arg2;
                    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                        iVar10 = *(int64_t *)arg2;
                    }
                    *(undefined2 *)(iVar10 + uVar15) = 1;
                }
                func_0x0001800cdce0(arg2, *(int64_t *)(arg1 + 0x280) - *(int64_t *)(arg1 + 0x278) >> 4 & 0xffffffff);
                puVar6 = *(undefined4 **)(arg1 + 0x280);
                puVar17 = *(undefined4 **)(arg1 + 0x278);
                if (puVar17 != puVar6) {
                    uVar7 = (undefined)var_18h;
                    do {
                        func_0x0001800cdce0(arg2, *puVar17);
                        func_0x0001800cdce0(arg2, puVar17[2]);
                        func_0x0001800cdce0(arg2, puVar17[3]);
                        uVar15 = *(uint64_t *)(arg2 + 0x10);
                        uVar1 = *(undefined *)(puVar17 + 1);
                        var_18h._0_4_ = CONCAT31(var_18h._1_3_, uVar1);
                        if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                            func_0x00018000ee80(arg2, 1, uVar7, &var_18h, 1);
                        } else {
                            *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                            if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                                *(undefined *)(arg2 + uVar15) = uVar1;
                                *(undefined *)(arg2 + 1 + uVar15) = 0;
                            } else {
                                iVar10 = *(int64_t *)arg2;
                                *(undefined *)(iVar10 + uVar15) = uVar1;
                                *(undefined *)(iVar10 + 1 + uVar15) = 0;
                            }
                        }
                        puVar17 = puVar17 + 4;
                    } while (puVar17 != puVar6);
                }
                func_0x0001800cdce0(arg2, *(int64_t *)(arg1 + 0x298) - *(int64_t *)(arg1 + 0x290) >> 2 & 0xffffffff);
                puVar6 = *(undefined4 **)(arg1 + 0x298);
                for (puVar17 = *(undefined4 **)(arg1 + 0x290); puVar17 != puVar6; puVar17 = puVar17 + 1) {
                    func_0x0001800cdce0(arg2, *puVar17);
                }
            }
            if (*(char *)0x180777e98 != '\0') {
                func_0x0001800cdce0(arg2, *(int64_t *)(arg1 + 0xd8) - *(int64_t *)(arg1 + 0xd0) >> 2);
                puVar6 = *(undefined4 **)(arg1 + 0xd8);
                puVar17 = *(undefined4 **)(arg1 + 0xd0);
                if (puVar17 != puVar6) {
                    uVar7 = (undefined)var_18h;
                    do {
                        uVar15 = *(uint64_t *)(arg2 + 0x10);
                        uVar2 = *puVar17;
                        var_18h._0_4_ = (uint32_t)var_18h & 0xffffff00;
                        if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                            func_0x00018000ee80(arg2, 1, uVar7, &var_18h, 1);
                        } else {
                            *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                            if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                                *(undefined2 *)(arg2 + uVar15) = 0;
                            } else {
                                *(undefined2 *)(*(int64_t *)arg2 + uVar15) = 0;
                            }
                        }
                        func_0x0001800cdce0(arg2, uVar2);
                        puVar17 = puVar17 + 1;
                    } while (puVar17 != puVar6);
                }
            }
            return;
        }
        if (*piVar9 == 0) {
            uVar15 = *(uint64_t *)(arg2 + 0x10);
            var_18h._0_4_ = (uint32_t)var_18h._1_3_ << 8;
            if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                func_0x00018000ee80(arg2, 1, 0, &var_18h, 1);
            } else {
                *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                    *(undefined2 *)(arg2 + uVar15) = 0;
                } else {
                    *(undefined2 *)(*(int64_t *)arg2 + uVar15) = 0;
                }
            }
            goto code_r0x0001800d1b38;
        }
        piVar9 = piVar9 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800d1e30
// Address: 0x1800d1e30
// Size: 1193 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d1e30(int64_t arg1, int64_t arg2, int64_t arg_48h, int64_t arg_98h)
{
    undefined uVar1;
    int32_t iVar2;
    code *pcVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    char cVar9;
    uint64_t uVar10;
    undefined *puVar11;
    undefined *puVar12;
    int32_t iVar13;
    int32_t iVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    char cVar17;
    undefined *puVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_90;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar12 = auStack_88;
    puVar11 = auStack_88;
    iVar7 = 0x1000000;
    uVar15 = 0;
    iVar5 = *(int64_t *)(arg1 + 0x40);
    uVar16 = *(int64_t *)(arg1 + 0x48) - iVar5 >> 2;
    if (uVar16 != 0) {
        do {
            iVar14 = *(int32_t *)(iVar5 + uVar15 * 4);
            if (uVar15 < uVar16) {
                uVar4 = uVar15;
                iVar13 = iVar14;
                do {
                    if ((int64_t)iVar7 + uVar15 <= uVar4) {
code_r0x0001800d1eb0:
                        if (uVar4 - uVar15 < (uint64_t)(int64_t)iVar7) {
                            uVar6 = 0;
                            iVar7 = (int32_t)uVar4 - (int32_t)uVar15;
                            if (1 < iVar7) {
                                do {
                                    uVar6 = uVar6 + 1;
                                } while (2 << (uVar6 & 0x1f) <= iVar7);
                            }
                            iVar7 = 1 << (uVar6 & 0x1f);
                        }
                        break;
                    }
                    iVar2 = *(int32_t *)(iVar5 + uVar4 * 4);
                    if (iVar2 < iVar14) {
                        iVar14 = iVar2;
                    }
                    if (iVar13 < iVar2) {
                        iVar13 = iVar2;
                    }
                    if (0xff < iVar13 - iVar14) goto code_r0x0001800d1eb0;
                    uVar4 = uVar4 + 1;
                } while (uVar4 < uVar16);
            }
            uVar15 = uVar15 + (int64_t)iVar7;
        } while (uVar15 < uVar16);
    }
    _var_58h = ZEXT816(0);
    var_48h = 0;
    uVar4 = (uint64_t)iVar7;
    uVar15 = (uVar16 - 1) / uVar4 + 1;
    puVar18 = auStack_88;
    if (uVar15 < 2) {
code_r0x0001800d2016:
        puVar11 = puVar18;
        puVar18 = puVar11 + 0xa0;
code_r0x0001800d201e:
        uVar16 = 0;
        iVar5 = *(int64_t *)(arg1 + 0x48);
        iVar8 = *(int64_t *)(arg1 + 0x40);
        if (iVar5 - iVar8 >> 2 != 0) {
            do {
                iVar14 = *(int32_t *)(iVar8 + uVar16 * 4);
                if (uVar16 < (uint64_t)(iVar5 - iVar8 >> 2)) {
                    uVar10 = uVar16;
                    do {
                        if (uVar16 + uVar4 <= uVar10) break;
                        if (*(int32_t *)(iVar8 + uVar10 * 4) < iVar14) {
                            iVar14 = *(int32_t *)(iVar8 + uVar10 * 4);
                        }
                        uVar10 = uVar10 + 1;
                    } while (uVar10 < (uint64_t)(iVar5 - iVar8 >> 2));
                }
                *(int32_t *)(puVar18 + (uVar16 / uVar4) * 4) = iVar14;
                uVar16 = uVar16 + uVar4;
                iVar5 = *(int64_t *)(arg1 + 0x48);
                iVar8 = *(int64_t *)(arg1 + 0x40);
            } while (uVar16 < (uint64_t)(iVar5 - iVar8 >> 2));
        }
        uVar6 = 0;
        if (1 < iVar7) {
            do {
                uVar6 = uVar6 + 1;
            } while (2 << (uVar6 & 0x1f) <= iVar7);
        }
        puVar11[0x90] = uVar6;
        uVar16 = *(uint64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x18) == uVar16) {
            *(undefined8 *)(puVar11 + 0x20) = 1;
            *(undefined8 *)(puVar11 + -8) = 0x1800d2121;
            func_0x00018000ee80(arg2, 1, puVar11[0x90], puVar11 + 0x90);
        } else {
            *(uint64_t *)(arg2 + 0x10) = uVar16 + 1;
            iVar5 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar5 = *(int64_t *)arg2;
            }
            *(uint8_t *)(uVar16 + iVar5) = uVar6;
            *(undefined *)(uVar16 + 1 + iVar5) = 0;
        }
        uVar16 = 0;
        iVar5 = *(int64_t *)(arg1 + 0x40);
        if (*(int64_t *)(arg1 + 0x48) - iVar5 >> 2 != 0) {
            uVar1 = puVar11[0x90];
            cVar9 = '\0';
            do {
                cVar17 = *(char *)(iVar5 + uVar16 * 4) - puVar18[(uVar16 >> (uVar6 & 0x3f)) * 4];
                cVar9 = cVar17 - cVar9;
                puVar11[0x90] = cVar9;
                uVar4 = *(uint64_t *)(arg2 + 0x10);
                if (*(uint64_t *)(arg2 + 0x18) == uVar4) {
                    *(undefined8 *)(puVar11 + 0x20) = 1;
                    *(undefined8 *)(puVar11 + -8) = 0x1800d21c3;
                    func_0x00018000ee80(arg2, 1, uVar1, puVar11 + 0x90);
                } else {
                    *(uint64_t *)(arg2 + 0x10) = uVar4 + 1;
                    iVar5 = arg2;
                    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                        iVar5 = *(int64_t *)arg2;
                    }
                    *(char *)(uVar4 + iVar5) = cVar9;
                    *(undefined *)(uVar4 + 1 + iVar5) = 0;
                }
                uVar16 = uVar16 + 1;
                iVar5 = *(int64_t *)(arg1 + 0x40);
                cVar9 = cVar17;
            } while (uVar16 < (uint64_t)(*(int64_t *)(arg1 + 0x48) - iVar5 >> 2));
        }
        iVar7 = 0;
        uVar16 = 0;
        if (uVar15 != 0) {
            uVar1 = puVar11[0x90];
            do {
                iVar7 = *(int32_t *)(puVar18 + uVar16 * 4) - iVar7;
                *(int32_t *)(puVar11 + 0x90) = iVar7;
                iVar5 = *(int64_t *)(arg2 + 0x10);
                if (*(uint64_t *)(arg2 + 0x18) - iVar5 < 4) {
                    *(undefined8 *)(puVar11 + 0x20) = 4;
                    *(undefined8 *)(puVar11 + -8) = 0x1800d225e;
                    func_0x00018000ee80(arg2, 4, uVar1, puVar11 + 0x90);
                } else {
                    *(int64_t *)(arg2 + 0x10) = iVar5 + 4;
                    if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                        *(int32_t *)(iVar5 + arg2) = iVar7;
                        *(undefined *)(iVar5 + 4 + arg2) = 0;
                    } else {
                        iVar8 = *(int64_t *)arg2;
                        *(int32_t *)(iVar5 + iVar8) = iVar7;
                        *(undefined *)(iVar5 + 4 + iVar8) = 0;
                    }
                }
                iVar7 = *(int32_t *)(puVar18 + uVar16 * 4);
                uVar16 = uVar16 + 1;
            } while (uVar16 < uVar15);
        }
        iVar5 = *(int64_t *)(puVar11 + 0x30);
        if (iVar5 == 0) {
            return;
        }
        uVar15 = (*(int64_t *)(puVar11 + 0x40) - iVar5 >> 2) * 4;
        iVar8 = iVar5;
        if (uVar15 < 0x1000) {
code_r0x0001800d22a9:
            *(undefined8 *)(puVar11 + -8) = 0x1800d22ae;
            fcn.180459c3c(iVar8, uVar15);
            return;
        }
        iVar8 = *(int64_t *)(iVar5 + -8);
        if ((iVar5 - iVar8) - 8U < 0x20) {
            uVar15 = uVar15 + 0x27;
            goto code_r0x0001800d22a9;
        }
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar12 = puVar11 + 8;
    } else {
        puVar18 = auStack_88;
        if (0x3fffffffffffffff < uVar15) goto code_r0x0001800d22d3;
        uVar16 = uVar15 * 4;
        if (uVar16 == 0) {
            puVar18 = (undefined *)0x0;
code_r0x0001800d1f88:
            func_0x0001804986e0(puVar18, 0, uVar15 * 4);
            fcn.180498030(puVar18);
            if (var_58h != 0) {
                uVar10 = (var_48h - var_58h >> 2) * 4;
                iVar5 = var_58h;
                if (0xfff < uVar10) {
                    iVar5 = *(int64_t *)(var_58h + -8);
                    if (0x1f < (var_58h - iVar5) - 8U) goto code_r0x0001800d200f;
                    uVar10 = uVar10 + 0x27;
                }
                fcn.180459c3c(iVar5, uVar10);
            }
            var_50h = (int64_t)(puVar18 + uVar15 * 4);
            var_58h = (int64_t)puVar18;
            var_48h = (int64_t)(puVar18 + uVar16);
            goto code_r0x0001800d201e;
        }
        if (uVar16 < 0x1000) {
            puVar18 = (undefined *)fcn.180459890(uVar16);
            goto code_r0x0001800d1f88;
        }
        if (uVar16 < uVar16 + 0x27) {
            iVar5 = fcn.180459890();
            if (iVar5 != 0) {
                puVar18 = (undefined *)(iVar5 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar18 + -8) = iVar5;
                goto code_r0x0001800d1f88;
            }
code_r0x0001800d200f:
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            puVar18 = auStack_80;
            goto code_r0x0001800d2016;
        }
    }
    *(undefined8 *)(puVar12 + -8) = 0x1800d22d2;
    fcn.180004720();
    puVar18 = puVar12;
code_r0x0001800d22d3:
    *(undefined8 *)(puVar18 + -8) = 0x1800d22d8;
    fcn.180010010();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800d22e0
// Address: 0x1800d22e0
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d22e0(int64_t arg1)
{
    int32_t *piVar1;
    uint32_t *puVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t *puVar5;
    int64_t iVar6;
    char cVar7;
    uint32_t uVar8;
    uint64_t uVar10;
    uint32_t *puVar11;
    int32_t iVar12;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    uint64_t uVar9;
    
    if (*(char *)(arg1 + 0xe8) == '\0') {
        puVar5 = *(uint32_t **)(arg1 + 0x90);
        for (puVar11 = *(uint32_t **)(arg1 + 0x88); puVar11 != puVar5; puVar11 = puVar11 + 2) {
            uVar3 = *puVar11;
            uVar10 = (uint64_t)uVar3;
            iVar6 = *(int64_t *)(arg1 + 0x28);
            iVar12 = *(int32_t *)(iVar6 + uVar10 * 4);
            piVar1 = (int32_t *)(iVar6 + uVar10 * 4);
            uVar8 = uVar3 + 1 + (iVar12 >> 0x10);
            uVar9 = (uint64_t)uVar8;
            iVar4 = *(int32_t *)(iVar6 + uVar9 * 4);
            cVar7 = (char)iVar4;
            while (cVar7 == '\x17') {
                uVar8 = (uint32_t)uVar9;
                if (iVar4 >> 0x10 < 0) break;
                uVar8 = uVar8 + 1 + (iVar4 >> 0x10);
                uVar9 = (uint64_t)uVar8;
                iVar4 = *(int32_t *)(iVar6 + uVar9 * 4);
                cVar7 = (char)iVar4;
            }
            if (((char)iVar12 == '\x17') && ((char)iVar4 == '\x16')) {
                *piVar1 = iVar4;
            } else {
                iVar12 = (uVar8 - uVar3) + -1;
                if ((int16_t)iVar12 == iVar12) {
                    *(undefined2 *)((int64_t)piVar1 + 2) = 0;
                    puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 0x28) + uVar10 * 4);
                    *puVar2 = *puVar2 | iVar12 * 0x10000;
                }
            }
            puVar11[1] = uVar8;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d22fb
// Address: 0x1800d22fb
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d22e0(int64_t arg1)
{
    int32_t *piVar1;
    uint32_t *puVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t *puVar5;
    int64_t iVar6;
    char cVar7;
    uint32_t uVar8;
    uint64_t uVar10;
    uint32_t *puVar11;
    int32_t iVar12;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    uint64_t uVar9;
    
    if (*(char *)(arg1 + 0xe8) == '\0') {
        puVar5 = *(uint32_t **)(arg1 + 0x90);
        for (puVar11 = *(uint32_t **)(arg1 + 0x88); puVar11 != puVar5; puVar11 = puVar11 + 2) {
            uVar3 = *puVar11;
            uVar10 = (uint64_t)uVar3;
            iVar6 = *(int64_t *)(arg1 + 0x28);
            iVar12 = *(int32_t *)(iVar6 + uVar10 * 4);
            piVar1 = (int32_t *)(iVar6 + uVar10 * 4);
            uVar8 = uVar3 + 1 + (iVar12 >> 0x10);
            uVar9 = (uint64_t)uVar8;
            iVar4 = *(int32_t *)(iVar6 + uVar9 * 4);
            cVar7 = (char)iVar4;
            while (cVar7 == '\x17') {
                uVar8 = (uint32_t)uVar9;
                if (iVar4 >> 0x10 < 0) break;
                uVar8 = uVar8 + 1 + (iVar4 >> 0x10);
                uVar9 = (uint64_t)uVar8;
                iVar4 = *(int32_t *)(iVar6 + uVar9 * 4);
                cVar7 = (char)iVar4;
            }
            if (((char)iVar12 == '\x17') && ((char)iVar4 == '\x16')) {
                *piVar1 = iVar4;
            } else {
                iVar12 = (uVar8 - uVar3) + -1;
                if ((int16_t)iVar12 == iVar12) {
                    *(undefined2 *)((int64_t)piVar1 + 2) = 0;
                    puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 0x28) + uVar10 * 4);
                    *puVar2 = *puVar2 | iVar12 * 0x10000;
                }
            }
            puVar11[1] = uVar8;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d2310
// Address: 0x1800d2310
// Size: 151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d22e0(int64_t arg1)
{
    int32_t *piVar1;
    uint32_t *puVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t *puVar5;
    int64_t iVar6;
    char cVar7;
    uint32_t uVar8;
    uint64_t uVar10;
    uint32_t *puVar11;
    int32_t iVar12;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    uint64_t uVar9;
    
    if (*(char *)(arg1 + 0xe8) == '\0') {
        puVar5 = *(uint32_t **)(arg1 + 0x90);
        for (puVar11 = *(uint32_t **)(arg1 + 0x88); puVar11 != puVar5; puVar11 = puVar11 + 2) {
            uVar3 = *puVar11;
            uVar10 = (uint64_t)uVar3;
            iVar6 = *(int64_t *)(arg1 + 0x28);
            iVar12 = *(int32_t *)(iVar6 + uVar10 * 4);
            piVar1 = (int32_t *)(iVar6 + uVar10 * 4);
            uVar8 = uVar3 + 1 + (iVar12 >> 0x10);
            uVar9 = (uint64_t)uVar8;
            iVar4 = *(int32_t *)(iVar6 + uVar9 * 4);
            cVar7 = (char)iVar4;
            while (cVar7 == '\x17') {
                uVar8 = (uint32_t)uVar9;
                if (iVar4 >> 0x10 < 0) break;
                uVar8 = uVar8 + 1 + (iVar4 >> 0x10);
                uVar9 = (uint64_t)uVar8;
                iVar4 = *(int32_t *)(iVar6 + uVar9 * 4);
                cVar7 = (char)iVar4;
            }
            if (((char)iVar12 == '\x17') && ((char)iVar4 == '\x16')) {
                *piVar1 = iVar4;
            } else {
                iVar12 = (uVar8 - uVar3) + -1;
                if ((int16_t)iVar12 == iVar12) {
                    *(undefined2 *)((int64_t)piVar1 + 2) = 0;
                    puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 0x28) + uVar10 * 4);
                    *puVar2 = *puVar2 | iVar12 * 0x10000;
                }
            }
            puVar11[1] = uVar8;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d23a7
// Address: 0x1800d23a7
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d22e0(int64_t arg1)
{
    int32_t *piVar1;
    uint32_t *puVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t *puVar5;
    int64_t iVar6;
    char cVar7;
    uint32_t uVar8;
    uint64_t uVar10;
    uint32_t *puVar11;
    int32_t iVar12;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    uint64_t uVar9;
    
    if (*(char *)(arg1 + 0xe8) == '\0') {
        puVar5 = *(uint32_t **)(arg1 + 0x90);
        for (puVar11 = *(uint32_t **)(arg1 + 0x88); puVar11 != puVar5; puVar11 = puVar11 + 2) {
            uVar3 = *puVar11;
            uVar10 = (uint64_t)uVar3;
            iVar6 = *(int64_t *)(arg1 + 0x28);
            iVar12 = *(int32_t *)(iVar6 + uVar10 * 4);
            piVar1 = (int32_t *)(iVar6 + uVar10 * 4);
            uVar8 = uVar3 + 1 + (iVar12 >> 0x10);
            uVar9 = (uint64_t)uVar8;
            iVar4 = *(int32_t *)(iVar6 + uVar9 * 4);
            cVar7 = (char)iVar4;
            while (cVar7 == '\x17') {
                uVar8 = (uint32_t)uVar9;
                if (iVar4 >> 0x10 < 0) break;
                uVar8 = uVar8 + 1 + (iVar4 >> 0x10);
                uVar9 = (uint64_t)uVar8;
                iVar4 = *(int32_t *)(iVar6 + uVar9 * 4);
                cVar7 = (char)iVar4;
            }
            if (((char)iVar12 == '\x17') && ((char)iVar4 == '\x16')) {
                *piVar1 = iVar4;
            } else {
                iVar12 = (uVar8 - uVar3) + -1;
                if ((int16_t)iVar12 == iVar12) {
                    *(undefined2 *)((int64_t)piVar1 + 2) = 0;
                    puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 0x28) + uVar10 * 4);
                    *puVar2 = *puVar2 | iVar12 * 0x10000;
                }
            }
            puVar11[1] = uVar8;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d23ac
// Address: 0x1800d23ac
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d22e0(int64_t arg1)
{
    int32_t *piVar1;
    uint32_t *puVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t *puVar5;
    int64_t iVar6;
    char cVar7;
    uint32_t uVar8;
    uint64_t uVar10;
    uint32_t *puVar11;
    int32_t iVar12;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    uint64_t uVar9;
    
    if (*(char *)(arg1 + 0xe8) == '\0') {
        puVar5 = *(uint32_t **)(arg1 + 0x90);
        for (puVar11 = *(uint32_t **)(arg1 + 0x88); puVar11 != puVar5; puVar11 = puVar11 + 2) {
            uVar3 = *puVar11;
            uVar10 = (uint64_t)uVar3;
            iVar6 = *(int64_t *)(arg1 + 0x28);
            iVar12 = *(int32_t *)(iVar6 + uVar10 * 4);
            piVar1 = (int32_t *)(iVar6 + uVar10 * 4);
            uVar8 = uVar3 + 1 + (iVar12 >> 0x10);
            uVar9 = (uint64_t)uVar8;
            iVar4 = *(int32_t *)(iVar6 + uVar9 * 4);
            cVar7 = (char)iVar4;
            while (cVar7 == '\x17') {
                uVar8 = (uint32_t)uVar9;
                if (iVar4 >> 0x10 < 0) break;
                uVar8 = uVar8 + 1 + (iVar4 >> 0x10);
                uVar9 = (uint64_t)uVar8;
                iVar4 = *(int32_t *)(iVar6 + uVar9 * 4);
                cVar7 = (char)iVar4;
            }
            if (((char)iVar12 == '\x17') && ((char)iVar4 == '\x16')) {
                *piVar1 = iVar4;
            } else {
                iVar12 = (uVar8 - uVar3) + -1;
                if ((int16_t)iVar12 == iVar12) {
                    *(undefined2 *)((int64_t)piVar1 + 2) = 0;
                    puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 0x28) + uVar10 * 4);
                    *puVar2 = *puVar2 | iVar12 * 0x10000;
                }
            }
            puVar11[1] = uVar8;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d23c0
// Address: 0x1800d23c0
// Size: 2186 bytes
// ============================================================
void fcn.1800d23c0(int64_t arg1)
{
    uint64_t uVar1;
    uint32_t *puVar2;
    uint32_t *puVar3;
    undefined uVar4;
    uint32_t uVar5;
    uint32_t *puVar6;
    code *pcVar7;
    undefined auVar8 [16];
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined *puVar15;
    int64_t *piVar16;
    int64_t iVar17;
    uint32_t *puVar18;
    int32_t iVar19;
    uint64_t unaff_R13;
    uint64_t uVar20;
    int64_t *piVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_e0;
    undefined auStack_d8 [8];
    undefined auStack_d0 [24];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar15 = auStack_d8;
    if (*(char *)(arg1 + 0xe8) == '\0') {
        return;
    }
    func_0x0001800d3300(*(int64_t *)(arg1 + 0x88), *(int64_t *)(arg1 + 0x90), 
                        *(int64_t *)(arg1 + 0x90) - *(int64_t *)(arg1 + 0x88) >> 3, arg1 & 0xff);
    piVar21 = (int64_t *)(arg1 + 0x28);
    uVar14 = *(int64_t *)(arg1 + 0x30) - *piVar21 >> 2;
    auVar8 = ZEXT816(0);
    var_60h = 0;
    uVar20 = 0;
    var_78h = 0;
    var_58h = 0;
    var_70h = (int64_t)piVar21;
    _var_68h = auVar8;
    if (uVar14 == 0) {
        var_68h = 0;
        uVar20 = var_68h;
code_r0x0001800d24c4:
        _var_b8h = ZEXT816(0);
        var_a8h = 0;
        _var_a0h = ZEXT816(0);
        var_90h = 0;
        func_0x0001800d30b0(&var_b8h, *(int64_t *)(arg1 + 0x30) - *piVar21 >> 2);
        func_0x0001800d30b0(&var_a0h, *(int64_t *)(arg1 + 0x30) - *piVar21 >> 2);
        var_80h = 0;
        var_20h = 0;
        iVar11 = *piVar21;
        piVar16 = (int64_t *)(arg1 + 0x40);
        puVar15 = auStack_d8;
        if (*(int64_t *)(arg1 + 0x30) - iVar11 >> 2 != 0) {
            do {
                iVar13 = var_80h;
                uVar14 = var_20h;
                uVar4 = *(undefined *)(iVar11 + var_20h * 4);
                iVar11 = *(int64_t *)(arg1 + 0x88);
                var_88h = (int64_t)piVar16;
                if (((uint64_t)var_80h < (uint64_t)(*(int64_t *)(arg1 + 0x90) - iVar11 >> 3)) &&
                   (uVar5 = *(uint32_t *)(iVar11 + var_80h * 8), (uint64_t)uVar5 == var_20h)) {
                    iVar10 = (*(int32_t *)(iVar11 + 4 + var_80h * 8) - uVar5) + -1;
                    iVar9 = -iVar10;
                    if (0 < iVar10) {
                        iVar9 = iVar10;
                    }
                    if (0x2aaa < iVar9) {
                        var_10h._0_4_ = 0x10017;
                        func_0x0001800d31a0(&var_b8h, &var_10h);
                        var_10h._0_4_ = 0x43;
                        func_0x0001800d31a0(&var_b8h, &var_10h);
                        func_0x0001800d31a0(&var_a0h, *piVar16 + uVar14 * 4);
                        func_0x0001800d31a0(&var_a0h, *piVar16 + uVar14 * 4);
                    }
                    var_80h = iVar13 + 1;
                }
    // switch table (2 cases) at 0x1800d2bf0
                switch(uVar4) {
                case 7:
                case 8:
                case 0xc:
                case 0xf:
                case 0x10:
                case 0x14:
                case 0x1b:
                case 0x1c:
                case 0x1d:
                case 0x1e:
                case 0x1f:
                case 0x20:
                case 0x35:
                case 0x37:
                case 0x3a:
                case 0x3c:
                case 0x42:
                case 0x4a:
                case 0x4b:
                case 0x4d:
                case 0x4e:
                case 0x4f:
                case 0x50:
                case 0x53:
                case 0x54:
                case 0x55:
                case 0x56:
                case 0x57:
                case 0x58:
                    var_18h._0_4_ = 2;
                    break;
                default:
                    var_18h._0_4_ = 1;
                }
                var_10h._0_4_ = 0;
                do {
                    iVar11 = var_b0h;
                    *(int32_t *)(uVar20 + uVar14 * 4) = (int32_t)(var_b0h - var_b8h >> 2);
                    piVar21 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + uVar14 * 4);
                    if (var_b0h == var_a8h) {
                        iVar13 = var_b0h - var_b8h >> 2;
                        if (iVar13 != 0x3fffffffffffffff) {
                            uVar14 = var_a8h - var_b8h >> 2;
                            if (0x3fffffffffffffff - (uVar14 >> 1) < uVar14) goto code_r0x0001800d2bea;
                            uVar1 = iVar13 + 1;
                            uVar14 = (uVar14 >> 1) + uVar14;
                            uVar12 = uVar1;
                            if (uVar1 <= uVar14) {
                                uVar12 = uVar14;
                            }
                            if (0x3fffffffffffffff < uVar12) goto code_r0x0001800d2bea;
                            piVar16 = (int64_t *)(uVar12 * 4);
                            if (piVar16 == (int64_t *)0x0) {
                                uVar14 = 0;
code_r0x0001800d26dc:
                                *(undefined4 *)(uVar14 + iVar13 * 4) = *(undefined4 *)piVar21;
                                if (iVar11 == var_b0h) {
                                    iVar17 = var_b0h - var_b8h;
                                    uVar12 = uVar14;
                                    iVar13 = var_b8h;
                                } else {
                                    fcn.180498030(uVar14, var_b8h, iVar11 - var_b8h);
                                    iVar17 = var_b0h - iVar11;
                                    uVar12 = uVar14 + (iVar13 + 1) * 4;
                                    iVar13 = iVar11;
                                }
                                fcn.180498030(uVar12, iVar13, iVar17);
                                if (var_b8h != 0) {
                                    uVar12 = (var_a8h - var_b8h >> 2) * 4;
                                    iVar13 = var_b8h;
                                    if (0xfff < uVar12) {
                                        if (0x1f < (var_b8h - *(int64_t *)(var_b8h + -8)) - 8U)
                                        goto code_r0x0001800d2927;
                                        uVar12 = uVar12 + 0x27;
                                        iVar13 = *(int64_t *)(var_b8h + -8);
                                    }
                                    fcn.180459c3c(iVar13, uVar12);
                                }
                                var_b0h = uVar14 + uVar1 * 4;
                                var_b8h = uVar14;
                                var_a8h = uVar14 + (int64_t)piVar16;
                                piVar16 = (int64_t *)var_88h;
                                uVar14 = var_20h;
                                goto code_r0x0001800d2780;
                            }
                            if (piVar16 < (int64_t *)0x1000) {
                                uVar14 = fcn.180459890(piVar16);
                                goto code_r0x0001800d26dc;
                            }
                            if ((int64_t *)((int64_t)piVar16 + 0x27U) <= piVar16) goto code_r0x0001800d2bea;
                            iVar17 = fcn.180459890();
                            if (iVar17 != 0) {
                                uVar14 = iVar17 + 0x27U & 0xffffffffffffffe0;
                                *(int64_t *)(uVar14 - 8) = iVar17;
                                goto code_r0x0001800d26dc;
                            }
code_r0x0001800d2927:
                            arg1 = iVar11;
                            pcVar7 = (code *)swi(0x29);
                            (*pcVar7)(5);
                            puVar15 = auStack_d0;
                            goto code_r0x0001800d292e;
                        }
                        fcn.180010010();
                        auVar8 = _var_68h;
                        goto code_r0x0001800d2bd8;
                    }
                    *(undefined4 *)var_b0h = *(undefined4 *)piVar21;
                    var_b0h = var_b0h + 4;
code_r0x0001800d2780:
                    piVar21 = (int64_t *)(*piVar16 + uVar14 * 4);
                    iVar11 = var_98h;
                    if (var_98h == var_90h) {
                        iVar13 = var_98h - var_a0h >> 2;
                        if (iVar13 == 0x3fffffffffffffff) goto code_r0x0001800d2be4;
                        uVar14 = var_90h - var_a0h >> 2;
                        if (0x3fffffffffffffff - (uVar14 >> 1) < uVar14) {
code_r0x0001800d2bea:
                            fcn.180004720();
                            pcVar7 = (code *)swi(3);
                            (*pcVar7)();
                            return;
                        }
                        uVar1 = iVar13 + 1;
                        uVar14 = (uVar14 >> 1) + uVar14;
                        uVar12 = uVar1;
                        if (uVar1 <= uVar14) {
                            uVar12 = uVar14;
                        }
                        if (0x3fffffffffffffff < uVar12) goto code_r0x0001800d2bea;
                        piVar16 = (int64_t *)(uVar12 * 4);
                        if (piVar16 == (int64_t *)0x0) {
                            uVar14 = 0;
                        } else if (piVar16 < (int64_t *)0x1000) {
                            uVar14 = fcn.180459890(piVar16);
                        } else {
                            if ((int64_t *)((int64_t)piVar16 + 0x27U) <= piVar16) goto code_r0x0001800d2bea;
                            iVar17 = fcn.180459890();
                            if (iVar17 == 0) goto code_r0x0001800d2927;
                            uVar14 = iVar17 + 0x27U & 0xffffffffffffffe0;
                            *(int64_t *)(uVar14 - 8) = iVar17;
                        }
                        *(undefined4 *)(uVar14 + iVar13 * 4) = *(undefined4 *)piVar21;
                        if (iVar11 == var_98h) {
                            iVar17 = var_98h - var_a0h;
                            uVar12 = uVar14;
                            iVar13 = var_a0h;
                        } else {
                            fcn.180498030(uVar14, var_a0h, iVar11 - var_a0h);
                            iVar17 = var_98h - iVar11;
                            uVar12 = uVar14 + (iVar13 + 1) * 4;
                            iVar13 = iVar11;
                        }
                        fcn.180498030(uVar12, iVar13, iVar17);
                        if (var_a0h != 0) {
                            uVar12 = (var_90h - var_a0h >> 2) * 4;
                            iVar13 = var_a0h;
                            if (0xfff < uVar12) {
                                if (0x1f < (var_a0h - *(int64_t *)(var_a0h + -8)) - 8U) goto code_r0x0001800d2927;
                                uVar12 = uVar12 + 0x27;
                                iVar13 = *(int64_t *)(var_a0h + -8);
                            }
                            fcn.180459c3c(iVar13, uVar12);
                        }
                        var_98h = uVar14 + uVar1 * 4;
                        var_a0h = uVar14;
                        var_90h = uVar14 + (int64_t)piVar16;
                        piVar16 = (int64_t *)var_88h;
                    } else {
                        *(undefined4 *)var_98h = *(undefined4 *)piVar21;
                        var_98h = var_98h + 4;
                        var_20h = uVar14;
                    }
                    uVar14 = var_20h + 1;
                    var_10h._0_4_ = (int32_t)var_10h + 1;
                    var_20h = uVar14;
                } while ((int32_t)var_10h < (int32_t)var_18h);
                iVar11 = *(int64_t *)var_70h;
                puVar15 = auStack_d8;
                piVar21 = (int64_t *)var_70h;
            } while (uVar14 < (uint64_t)(*(int64_t *)(var_70h + 8) - iVar11 >> 2));
        }
code_r0x0001800d292e:
        puVar6 = *(uint32_t **)(arg1 + 0x90);
        puVar18 = *(uint32_t **)(arg1 + 0x88);
        if (puVar18 != puVar6) {
            do {
                uVar5 = *(uint32_t *)(uVar20 + (uint64_t)*puVar18 * 4);
                iVar19 = *(int32_t *)(uVar20 + (uint64_t)puVar18[1] * 4) - uVar5;
                iVar11 = (uint64_t)uVar5 * 4;
                iVar10 = (puVar18[1] - *puVar18) + -1;
                iVar9 = -iVar10;
                if (0 < iVar10) {
                    iVar9 = iVar10;
                }
                if (iVar9 < 0x2aab) {
                    *(undefined2 *)(var_b8h + 2 + iVar11) = 0;
                    *(uint32_t *)(var_b8h + iVar11) = *(uint32_t *)(var_b8h + iVar11) | (iVar19 + -1) * 0x10000;
                } else {
                    puVar2 = (uint32_t *)(var_b8h + (uint64_t)(uVar5 - 1) * 4);
                    puVar3 = (uint32_t *)(iVar11 + var_b8h);
                    *puVar2 = iVar19 * 0x100 | (uint32_t)*(uint8_t *)puVar2;
                    *(undefined2 *)((int64_t)puVar3 + 2) = 0;
                    *puVar3 = *puVar3 | 0xfffe0000;
                }
                puVar18 = puVar18 + 2;
            } while (puVar18 != puVar6);
            piVar16 = (int64_t *)(arg1 + 0x40);
        }
        if (piVar21 != &var_b8h) {
            iVar11 = *piVar21;
            *piVar21 = var_b8h;
            iVar13 = piVar21[1];
            piVar21[1] = var_b0h;
            var_b0h = iVar13;
            var_b8h = iVar11;
            iVar11 = piVar21[2];
            piVar21[2] = var_a8h;
            var_a8h = iVar11;
        }
        if (piVar16 != &var_a0h) {
            iVar11 = *piVar16;
            *piVar16 = var_a0h;
            iVar13 = piVar16[1];
            piVar16[1] = var_98h;
            var_98h = iVar13;
            var_a0h = iVar11;
            iVar11 = piVar16[2];
            piVar16[2] = var_90h;
            var_90h = iVar11;
        }
        iVar11 = *(int64_t *)(arg1 + 0x280);
        for (iVar13 = *(int64_t *)(arg1 + 0x278); iVar13 != iVar11; iVar13 = iVar13 + 0x10) {
            uVar5 = *(uint32_t *)(iVar13 + 0xc);
            if (*(uint32_t *)(iVar13 + 8) == uVar5) {
                iVar9 = *(int32_t *)(uVar20 + (uint64_t)uVar5 * 4);
            } else {
                iVar9 = *(int32_t *)(uVar20 + (uint64_t)(uVar5 - 1) * 4) + 1;
            }
            *(int32_t *)(iVar13 + 0xc) = iVar9;
            *(undefined4 *)(iVar13 + 8) = *(undefined4 *)(uVar20 + (uint64_t)*(uint32_t *)(iVar13 + 8) * 4);
        }
        iVar11 = *(int64_t *)(arg1 + 0x2b0);
        for (iVar13 = *(int64_t *)(arg1 + 0x2a8); iVar13 != iVar11; iVar13 = iVar13 + 0x10) {
            uVar5 = *(uint32_t *)(iVar13 + 0xc);
            if (*(uint32_t *)(iVar13 + 8) == uVar5) {
                iVar9 = *(int32_t *)(uVar20 + (uint64_t)uVar5 * 4);
            } else {
                iVar9 = *(int32_t *)(uVar20 + (uint64_t)(uVar5 - 1) * 4) + 1;
            }
            *(int32_t *)(iVar13 + 0xc) = iVar9;
            *(undefined4 *)(iVar13 + 8) = *(undefined4 *)(uVar20 + (uint64_t)*(uint32_t *)(iVar13 + 8) * 4);
        }
        if (var_a0h != 0) {
            iVar11 = var_a0h;
            if ((0xfff < (uint64_t)((var_90h - var_a0h >> 2) * 4)) &&
               (iVar11 = *(int64_t *)(var_a0h + -8), 0x1f < (var_a0h - iVar11) - 8U)) {
                iVar11 = 5;
                pcVar7 = (code *)swi(0x29);
                (*pcVar7)(5);
                puVar15 = puVar15 + 8;
            }
            *(undefined8 *)(puVar15 + -8) = 0x1800d2b11;
            fcn.180459c3c(iVar11);
            _var_a0h = ZEXT816(0);
            var_90h = 0;
        }
        if (var_b8h != 0) {
            iVar11 = var_b8h;
            if ((0xfff < (uint64_t)((var_a8h - var_b8h >> 2) * 4)) &&
               (iVar11 = *(int64_t *)(var_b8h + -8), 0x1f < (var_b8h - iVar11) - 8U)) {
                iVar11 = 5;
                pcVar7 = (code *)swi(0x29);
                (*pcVar7)(5);
                puVar15 = puVar15 + 8;
            }
            *(undefined8 *)(puVar15 + -8) = 0x1800d2b6b;
            fcn.180459c3c(iVar11);
            _var_b8h = ZEXT816(0);
            var_a8h = 0;
        }
        if (uVar20 == 0) {
            return;
        }
        if ((uint64_t)(((int64_t)(var_78h - uVar20) >> 2) * 4) < 0x1000) goto code_r0x0001800d2bb9;
        unaff_R13 = (uVar20 - *(uint64_t *)(uVar20 - 8)) - 8;
        uVar20 = *(uint64_t *)(uVar20 - 8);
        if (unaff_R13 < 0x20) goto code_r0x0001800d2bb9;
    } else {
        if (0x3fffffffffffffff < uVar14) {
code_r0x0001800d2bd8:
            _var_68h = auVar8;
            fcn.180010010();
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        uVar14 = uVar14 * 4;
        if (uVar14 == 0) {
code_r0x0001800d249d:
            var_68h = uVar20;
            iVar11 = uVar14 + uVar20;
            var_78h = iVar11;
            var_58h = iVar11;
            func_0x0001804986e0(uVar20, 0, uVar14);
            var_60h = iVar11;
            goto code_r0x0001800d24c4;
        }
        if (uVar14 < 0x1000) {
            uVar20 = fcn.180459890(uVar14);
            goto code_r0x0001800d249d;
        }
        if (uVar14 + 0x27 <= uVar14) {
            fcn.180004720();
code_r0x0001800d2be4:
            fcn.180010010();
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        iVar11 = fcn.180459890();
        if (iVar11 != 0) {
            uVar20 = iVar11 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar20 - 8) = iVar11;
            goto code_r0x0001800d249d;
        }
    }
    uVar20 = unaff_R13;
    pcVar7 = (code *)swi(0x29);
    (*pcVar7)(5);
    puVar15 = puVar15 + 8;
code_r0x0001800d2bb9:
    *(undefined8 *)(puVar15 + -8) = 0x1800d2bbe;
    fcn.180459c3c(uVar20);
    return;
}

// ============================================================
// Function: FUN_1800d2c50
// Address: 0x1800d2c50
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800d2c50(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    int64_t *piVar13;
    undefined8 *unaff_RBP;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_50h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    int64_t var_20h;
    
    puVar12 = *(undefined8 **)(arg1 + 8);
    if (puVar12 != *(undefined8 **)(arg1 + 0x10)) {
        iVar6 = 2;
        do {
            puVar10 = puVar12 + 0x10;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar11 = (undefined8 *)(arg2 + 0x80);
            *(undefined4 *)puVar12 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar12 + 4) = uVar3;
            *(undefined4 *)(puVar12 + 1) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0xc) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x14);
            uVar4 = *(undefined4 *)(arg2 + 0x18);
            uVar5 = *(undefined4 *)(arg2 + 0x1c);
            *(undefined4 *)(puVar12 + 2) = *(undefined4 *)(arg2 + 0x10);
            *(undefined4 *)((int64_t)puVar12 + 0x14) = uVar3;
            *(undefined4 *)(puVar12 + 3) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x1c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x24);
            uVar4 = *(undefined4 *)(arg2 + 0x28);
            uVar5 = *(undefined4 *)(arg2 + 0x2c);
            *(undefined4 *)(puVar12 + 4) = *(undefined4 *)(arg2 + 0x20);
            *(undefined4 *)((int64_t)puVar12 + 0x24) = uVar3;
            *(undefined4 *)(puVar12 + 5) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x2c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x34);
            uVar4 = *(undefined4 *)(arg2 + 0x38);
            uVar5 = *(undefined4 *)(arg2 + 0x3c);
            *(undefined4 *)(puVar12 + 6) = *(undefined4 *)(arg2 + 0x30);
            *(undefined4 *)((int64_t)puVar12 + 0x34) = uVar3;
            *(undefined4 *)(puVar12 + 7) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x3c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x44);
            uVar4 = *(undefined4 *)(arg2 + 0x48);
            uVar5 = *(undefined4 *)(arg2 + 0x4c);
            *(undefined4 *)(puVar12 + 8) = *(undefined4 *)(arg2 + 0x40);
            *(undefined4 *)((int64_t)puVar12 + 0x44) = uVar3;
            *(undefined4 *)(puVar12 + 9) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x4c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x54);
            uVar4 = *(undefined4 *)(arg2 + 0x58);
            uVar5 = *(undefined4 *)(arg2 + 0x5c);
            *(undefined4 *)(puVar12 + 10) = *(undefined4 *)(arg2 + 0x50);
            *(undefined4 *)((int64_t)puVar12 + 0x54) = uVar3;
            *(undefined4 *)(puVar12 + 0xb) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x5c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 100);
            uVar4 = *(undefined4 *)(arg2 + 0x68);
            uVar5 = *(undefined4 *)(arg2 + 0x6c);
            *(undefined4 *)(puVar12 + 0xc) = *(undefined4 *)(arg2 + 0x60);
            *(undefined4 *)((int64_t)puVar12 + 100) = uVar3;
            *(undefined4 *)(puVar12 + 0xd) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x6c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x74);
            uVar4 = *(undefined4 *)(arg2 + 0x78);
            uVar5 = *(undefined4 *)(arg2 + 0x7c);
            *(undefined4 *)(puVar12 + 0xe) = *(undefined4 *)(arg2 + 0x70);
            *(undefined4 *)((int64_t)puVar12 + 0x74) = uVar3;
            *(undefined4 *)(puVar12 + 0xf) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x7c) = uVar5;
            iVar6 = iVar6 + -1;
            arg2 = (int64_t)puVar11;
            puVar12 = puVar10;
        } while (iVar6 != 0);
        *puVar10 = *puVar11;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x108;
        return;
    }
    iVar6 = ((int64_t)puVar12 - *(int64_t *)arg1) / 0x108;
    if (iVar6 == 0xf83e0f83e0f83e) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar14 = ((int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * 0xf83e0f83e0f83e1;
    uVar7 = 0xf83e0f83e0f83e - (uVar14 >> 1);
    if (uVar7 <= uVar14 && uVar14 - uVar7 != 0) {
code_r0x0001800d2eee:
        fcn.180004720();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar14 = uVar14 + (uVar14 >> 1);
    uVar7 = iVar6 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar14) {
        uVar9 = uVar14;
    }
    if (0xf83e0f83e0f83e < uVar9) goto code_r0x0001800d2eee;
    uVar14 = uVar9 * 0x108;
    if (uVar14 == 0) {
        unaff_RBP = (undefined8 *)0x0;
code_r0x0001800d2db7:
        iVar8 = 2;
        puVar10 = unaff_RBP + iVar6 * 0x21;
        do {
            puVar11 = puVar10 + 0x10;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar1 = (undefined8 *)(arg2 + 0x80);
            *(undefined4 *)puVar10 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar10 + 4) = uVar3;
            *(undefined4 *)(puVar10 + 1) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0xc) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x14);
            uVar4 = *(undefined4 *)(arg2 + 0x18);
            uVar5 = *(undefined4 *)(arg2 + 0x1c);
            *(undefined4 *)(puVar10 + 2) = *(undefined4 *)(arg2 + 0x10);
            *(undefined4 *)((int64_t)puVar10 + 0x14) = uVar3;
            *(undefined4 *)(puVar10 + 3) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x1c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x24);
            uVar4 = *(undefined4 *)(arg2 + 0x28);
            uVar5 = *(undefined4 *)(arg2 + 0x2c);
            *(undefined4 *)(puVar10 + 4) = *(undefined4 *)(arg2 + 0x20);
            *(undefined4 *)((int64_t)puVar10 + 0x24) = uVar3;
            *(undefined4 *)(puVar10 + 5) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x2c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x34);
            uVar4 = *(undefined4 *)(arg2 + 0x38);
            uVar5 = *(undefined4 *)(arg2 + 0x3c);
            *(undefined4 *)(puVar10 + 6) = *(undefined4 *)(arg2 + 0x30);
            *(undefined4 *)((int64_t)puVar10 + 0x34) = uVar3;
            *(undefined4 *)(puVar10 + 7) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x3c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x44);
            uVar4 = *(undefined4 *)(arg2 + 0x48);
            uVar5 = *(undefined4 *)(arg2 + 0x4c);
            *(undefined4 *)(puVar10 + 8) = *(undefined4 *)(arg2 + 0x40);
            *(undefined4 *)((int64_t)puVar10 + 0x44) = uVar3;
            *(undefined4 *)(puVar10 + 9) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x4c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x54);
            uVar4 = *(undefined4 *)(arg2 + 0x58);
            uVar5 = *(undefined4 *)(arg2 + 0x5c);
            *(undefined4 *)(puVar10 + 10) = *(undefined4 *)(arg2 + 0x50);
            *(undefined4 *)((int64_t)puVar10 + 0x54) = uVar3;
            *(undefined4 *)(puVar10 + 0xb) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x5c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 100);
            uVar4 = *(undefined4 *)(arg2 + 0x68);
            uVar5 = *(undefined4 *)(arg2 + 0x6c);
            *(undefined4 *)(puVar10 + 0xc) = *(undefined4 *)(arg2 + 0x60);
            *(undefined4 *)((int64_t)puVar10 + 100) = uVar3;
            *(undefined4 *)(puVar10 + 0xd) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x6c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x74);
            uVar4 = *(undefined4 *)(arg2 + 0x78);
            uVar5 = *(undefined4 *)(arg2 + 0x7c);
            *(undefined4 *)(puVar10 + 0xe) = *(undefined4 *)(arg2 + 0x70);
            *(undefined4 *)((int64_t)puVar10 + 0x74) = uVar3;
            *(undefined4 *)(puVar10 + 0xf) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x7c) = uVar5;
            iVar8 = iVar8 + -1;
            puVar10 = puVar11;
            arg2 = (int64_t)puVar1;
        } while (iVar8 != 0);
        *puVar11 = *puVar1;
        puVar10 = *(undefined8 **)arg1;
        if (puVar12 == *(undefined8 **)(arg1 + 8)) {
            iVar6 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar10;
            puVar11 = unaff_RBP;
            puVar12 = puVar10;
        } else {
            fcn.180498030(unaff_RBP, puVar10, (int64_t)puVar12 - (int64_t)puVar10);
            puVar11 = unaff_RBP + iVar6 * 0x21 + 0x21;
            iVar6 = *(int64_t *)(arg1 + 8) - (int64_t)puVar12;
        }
        fcn.180498030(puVar11, puVar12, iVar6);
        iVar6 = *(int64_t *)arg1;
        if (iVar6 == 0) goto code_r0x0001800d2eae;
        iVar8 = iVar6;
        piVar13 = &var_48h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar6 >> 3) * 8)) &&
           (iVar8 = *(int64_t *)(iVar6 + -8), piVar13 = &var_48h, 0x1f < (iVar6 - iVar8) - 8U))
        goto code_r0x0001800d2e9c;
    } else {
        if (uVar14 < 0x1000) {
            unaff_RBP = (undefined8 *)fcn.180459890(uVar14);
            goto code_r0x0001800d2db7;
        }
        if (uVar14 + 0x27 <= uVar14) goto code_r0x0001800d2eee;
        iVar8 = fcn.180459890();
        if (iVar8 != 0) {
            unaff_RBP = (undefined8 *)(iVar8 + 0x27U & 0xffffffffffffffe0);
            unaff_RBP[-1] = iVar8;
            goto code_r0x0001800d2db7;
        }
code_r0x0001800d2e9c:
        iVar8 = 5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        piVar13 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800d2eae;
    fcn.180459c3c(iVar8);
code_r0x0001800d2eae:
    *(undefined8 **)arg1 = unaff_RBP;
    *(undefined8 **)(arg1 + 8) = unaff_RBP + uVar7 * 0x21;
    *(undefined8 **)(arg1 + 0x10) = unaff_RBP + uVar9 * 0x21;
    return;
}

// ============================================================
// Function: FUN_1800d2cdf
// Address: 0x1800d2cdf
// Size: 521 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800d2c50(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    int64_t *piVar13;
    undefined8 *unaff_RBP;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_50h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    int64_t var_20h;
    
    puVar12 = *(undefined8 **)(arg1 + 8);
    if (puVar12 != *(undefined8 **)(arg1 + 0x10)) {
        iVar6 = 2;
        do {
            puVar10 = puVar12 + 0x10;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar11 = (undefined8 *)(arg2 + 0x80);
            *(undefined4 *)puVar12 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar12 + 4) = uVar3;
            *(undefined4 *)(puVar12 + 1) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0xc) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x14);
            uVar4 = *(undefined4 *)(arg2 + 0x18);
            uVar5 = *(undefined4 *)(arg2 + 0x1c);
            *(undefined4 *)(puVar12 + 2) = *(undefined4 *)(arg2 + 0x10);
            *(undefined4 *)((int64_t)puVar12 + 0x14) = uVar3;
            *(undefined4 *)(puVar12 + 3) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x1c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x24);
            uVar4 = *(undefined4 *)(arg2 + 0x28);
            uVar5 = *(undefined4 *)(arg2 + 0x2c);
            *(undefined4 *)(puVar12 + 4) = *(undefined4 *)(arg2 + 0x20);
            *(undefined4 *)((int64_t)puVar12 + 0x24) = uVar3;
            *(undefined4 *)(puVar12 + 5) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x2c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x34);
            uVar4 = *(undefined4 *)(arg2 + 0x38);
            uVar5 = *(undefined4 *)(arg2 + 0x3c);
            *(undefined4 *)(puVar12 + 6) = *(undefined4 *)(arg2 + 0x30);
            *(undefined4 *)((int64_t)puVar12 + 0x34) = uVar3;
            *(undefined4 *)(puVar12 + 7) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x3c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x44);
            uVar4 = *(undefined4 *)(arg2 + 0x48);
            uVar5 = *(undefined4 *)(arg2 + 0x4c);
            *(undefined4 *)(puVar12 + 8) = *(undefined4 *)(arg2 + 0x40);
            *(undefined4 *)((int64_t)puVar12 + 0x44) = uVar3;
            *(undefined4 *)(puVar12 + 9) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x4c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x54);
            uVar4 = *(undefined4 *)(arg2 + 0x58);
            uVar5 = *(undefined4 *)(arg2 + 0x5c);
            *(undefined4 *)(puVar12 + 10) = *(undefined4 *)(arg2 + 0x50);
            *(undefined4 *)((int64_t)puVar12 + 0x54) = uVar3;
            *(undefined4 *)(puVar12 + 0xb) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x5c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 100);
            uVar4 = *(undefined4 *)(arg2 + 0x68);
            uVar5 = *(undefined4 *)(arg2 + 0x6c);
            *(undefined4 *)(puVar12 + 0xc) = *(undefined4 *)(arg2 + 0x60);
            *(undefined4 *)((int64_t)puVar12 + 100) = uVar3;
            *(undefined4 *)(puVar12 + 0xd) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x6c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x74);
            uVar4 = *(undefined4 *)(arg2 + 0x78);
            uVar5 = *(undefined4 *)(arg2 + 0x7c);
            *(undefined4 *)(puVar12 + 0xe) = *(undefined4 *)(arg2 + 0x70);
            *(undefined4 *)((int64_t)puVar12 + 0x74) = uVar3;
            *(undefined4 *)(puVar12 + 0xf) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x7c) = uVar5;
            iVar6 = iVar6 + -1;
            arg2 = (int64_t)puVar11;
            puVar12 = puVar10;
        } while (iVar6 != 0);
        *puVar10 = *puVar11;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x108;
        return;
    }
    iVar6 = ((int64_t)puVar12 - *(int64_t *)arg1) / 0x108;
    if (iVar6 == 0xf83e0f83e0f83e) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar14 = ((int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * 0xf83e0f83e0f83e1;
    uVar7 = 0xf83e0f83e0f83e - (uVar14 >> 1);
    if (uVar7 <= uVar14 && uVar14 - uVar7 != 0) {
code_r0x0001800d2eee:
        fcn.180004720();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar14 = uVar14 + (uVar14 >> 1);
    uVar7 = iVar6 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar14) {
        uVar9 = uVar14;
    }
    if (0xf83e0f83e0f83e < uVar9) goto code_r0x0001800d2eee;
    uVar14 = uVar9 * 0x108;
    if (uVar14 == 0) {
        unaff_RBP = (undefined8 *)0x0;
code_r0x0001800d2db7:
        iVar8 = 2;
        puVar10 = unaff_RBP + iVar6 * 0x21;
        do {
            puVar11 = puVar10 + 0x10;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar1 = (undefined8 *)(arg2 + 0x80);
            *(undefined4 *)puVar10 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar10 + 4) = uVar3;
            *(undefined4 *)(puVar10 + 1) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0xc) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x14);
            uVar4 = *(undefined4 *)(arg2 + 0x18);
            uVar5 = *(undefined4 *)(arg2 + 0x1c);
            *(undefined4 *)(puVar10 + 2) = *(undefined4 *)(arg2 + 0x10);
            *(undefined4 *)((int64_t)puVar10 + 0x14) = uVar3;
            *(undefined4 *)(puVar10 + 3) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x1c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x24);
            uVar4 = *(undefined4 *)(arg2 + 0x28);
            uVar5 = *(undefined4 *)(arg2 + 0x2c);
            *(undefined4 *)(puVar10 + 4) = *(undefined4 *)(arg2 + 0x20);
            *(undefined4 *)((int64_t)puVar10 + 0x24) = uVar3;
            *(undefined4 *)(puVar10 + 5) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x2c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x34);
            uVar4 = *(undefined4 *)(arg2 + 0x38);
            uVar5 = *(undefined4 *)(arg2 + 0x3c);
            *(undefined4 *)(puVar10 + 6) = *(undefined4 *)(arg2 + 0x30);
            *(undefined4 *)((int64_t)puVar10 + 0x34) = uVar3;
            *(undefined4 *)(puVar10 + 7) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x3c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x44);
            uVar4 = *(undefined4 *)(arg2 + 0x48);
            uVar5 = *(undefined4 *)(arg2 + 0x4c);
            *(undefined4 *)(puVar10 + 8) = *(undefined4 *)(arg2 + 0x40);
            *(undefined4 *)((int64_t)puVar10 + 0x44) = uVar3;
            *(undefined4 *)(puVar10 + 9) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x4c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x54);
            uVar4 = *(undefined4 *)(arg2 + 0x58);
            uVar5 = *(undefined4 *)(arg2 + 0x5c);
            *(undefined4 *)(puVar10 + 10) = *(undefined4 *)(arg2 + 0x50);
            *(undefined4 *)((int64_t)puVar10 + 0x54) = uVar3;
            *(undefined4 *)(puVar10 + 0xb) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x5c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 100);
            uVar4 = *(undefined4 *)(arg2 + 0x68);
            uVar5 = *(undefined4 *)(arg2 + 0x6c);
            *(undefined4 *)(puVar10 + 0xc) = *(undefined4 *)(arg2 + 0x60);
            *(undefined4 *)((int64_t)puVar10 + 100) = uVar3;
            *(undefined4 *)(puVar10 + 0xd) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x6c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x74);
            uVar4 = *(undefined4 *)(arg2 + 0x78);
            uVar5 = *(undefined4 *)(arg2 + 0x7c);
            *(undefined4 *)(puVar10 + 0xe) = *(undefined4 *)(arg2 + 0x70);
            *(undefined4 *)((int64_t)puVar10 + 0x74) = uVar3;
            *(undefined4 *)(puVar10 + 0xf) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x7c) = uVar5;
            iVar8 = iVar8 + -1;
            puVar10 = puVar11;
            arg2 = (int64_t)puVar1;
        } while (iVar8 != 0);
        *puVar11 = *puVar1;
        puVar10 = *(undefined8 **)arg1;
        if (puVar12 == *(undefined8 **)(arg1 + 8)) {
            iVar6 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar10;
            puVar11 = unaff_RBP;
            puVar12 = puVar10;
        } else {
            fcn.180498030(unaff_RBP, puVar10, (int64_t)puVar12 - (int64_t)puVar10);
            puVar11 = unaff_RBP + iVar6 * 0x21 + 0x21;
            iVar6 = *(int64_t *)(arg1 + 8) - (int64_t)puVar12;
        }
        fcn.180498030(puVar11, puVar12, iVar6);
        iVar6 = *(int64_t *)arg1;
        if (iVar6 == 0) goto code_r0x0001800d2eae;
        iVar8 = iVar6;
        piVar13 = &var_48h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar6 >> 3) * 8)) &&
           (iVar8 = *(int64_t *)(iVar6 + -8), piVar13 = &var_48h, 0x1f < (iVar6 - iVar8) - 8U))
        goto code_r0x0001800d2e9c;
    } else {
        if (uVar14 < 0x1000) {
            unaff_RBP = (undefined8 *)fcn.180459890(uVar14);
            goto code_r0x0001800d2db7;
        }
        if (uVar14 + 0x27 <= uVar14) goto code_r0x0001800d2eee;
        iVar8 = fcn.180459890();
        if (iVar8 != 0) {
            unaff_RBP = (undefined8 *)(iVar8 + 0x27U & 0xffffffffffffffe0);
            unaff_RBP[-1] = iVar8;
            goto code_r0x0001800d2db7;
        }
code_r0x0001800d2e9c:
        iVar8 = 5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        piVar13 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800d2eae;
    fcn.180459c3c(iVar8);
code_r0x0001800d2eae:
    *(undefined8 **)arg1 = unaff_RBP;
    *(undefined8 **)(arg1 + 8) = unaff_RBP + uVar7 * 0x21;
    *(undefined8 **)(arg1 + 0x10) = unaff_RBP + uVar9 * 0x21;
    return;
}

// ============================================================
// Function: FUN_1800d2ee8
// Address: 0x1800d2ee8
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800d2c50(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    int64_t *piVar13;
    undefined8 *unaff_RBP;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_50h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    int64_t var_20h;
    
    puVar12 = *(undefined8 **)(arg1 + 8);
    if (puVar12 != *(undefined8 **)(arg1 + 0x10)) {
        iVar6 = 2;
        do {
            puVar10 = puVar12 + 0x10;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar11 = (undefined8 *)(arg2 + 0x80);
            *(undefined4 *)puVar12 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar12 + 4) = uVar3;
            *(undefined4 *)(puVar12 + 1) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0xc) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x14);
            uVar4 = *(undefined4 *)(arg2 + 0x18);
            uVar5 = *(undefined4 *)(arg2 + 0x1c);
            *(undefined4 *)(puVar12 + 2) = *(undefined4 *)(arg2 + 0x10);
            *(undefined4 *)((int64_t)puVar12 + 0x14) = uVar3;
            *(undefined4 *)(puVar12 + 3) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x1c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x24);
            uVar4 = *(undefined4 *)(arg2 + 0x28);
            uVar5 = *(undefined4 *)(arg2 + 0x2c);
            *(undefined4 *)(puVar12 + 4) = *(undefined4 *)(arg2 + 0x20);
            *(undefined4 *)((int64_t)puVar12 + 0x24) = uVar3;
            *(undefined4 *)(puVar12 + 5) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x2c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x34);
            uVar4 = *(undefined4 *)(arg2 + 0x38);
            uVar5 = *(undefined4 *)(arg2 + 0x3c);
            *(undefined4 *)(puVar12 + 6) = *(undefined4 *)(arg2 + 0x30);
            *(undefined4 *)((int64_t)puVar12 + 0x34) = uVar3;
            *(undefined4 *)(puVar12 + 7) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x3c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x44);
            uVar4 = *(undefined4 *)(arg2 + 0x48);
            uVar5 = *(undefined4 *)(arg2 + 0x4c);
            *(undefined4 *)(puVar12 + 8) = *(undefined4 *)(arg2 + 0x40);
            *(undefined4 *)((int64_t)puVar12 + 0x44) = uVar3;
            *(undefined4 *)(puVar12 + 9) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x4c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x54);
            uVar4 = *(undefined4 *)(arg2 + 0x58);
            uVar5 = *(undefined4 *)(arg2 + 0x5c);
            *(undefined4 *)(puVar12 + 10) = *(undefined4 *)(arg2 + 0x50);
            *(undefined4 *)((int64_t)puVar12 + 0x54) = uVar3;
            *(undefined4 *)(puVar12 + 0xb) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x5c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 100);
            uVar4 = *(undefined4 *)(arg2 + 0x68);
            uVar5 = *(undefined4 *)(arg2 + 0x6c);
            *(undefined4 *)(puVar12 + 0xc) = *(undefined4 *)(arg2 + 0x60);
            *(undefined4 *)((int64_t)puVar12 + 100) = uVar3;
            *(undefined4 *)(puVar12 + 0xd) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x6c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x74);
            uVar4 = *(undefined4 *)(arg2 + 0x78);
            uVar5 = *(undefined4 *)(arg2 + 0x7c);
            *(undefined4 *)(puVar12 + 0xe) = *(undefined4 *)(arg2 + 0x70);
            *(undefined4 *)((int64_t)puVar12 + 0x74) = uVar3;
            *(undefined4 *)(puVar12 + 0xf) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x7c) = uVar5;
            iVar6 = iVar6 + -1;
            arg2 = (int64_t)puVar11;
            puVar12 = puVar10;
        } while (iVar6 != 0);
        *puVar10 = *puVar11;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x108;
        return;
    }
    iVar6 = ((int64_t)puVar12 - *(int64_t *)arg1) / 0x108;
    if (iVar6 == 0xf83e0f83e0f83e) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar14 = ((int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * 0xf83e0f83e0f83e1;
    uVar7 = 0xf83e0f83e0f83e - (uVar14 >> 1);
    if (uVar7 <= uVar14 && uVar14 - uVar7 != 0) {
code_r0x0001800d2eee:
        fcn.180004720();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar14 = uVar14 + (uVar14 >> 1);
    uVar7 = iVar6 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar14) {
        uVar9 = uVar14;
    }
    if (0xf83e0f83e0f83e < uVar9) goto code_r0x0001800d2eee;
    uVar14 = uVar9 * 0x108;
    if (uVar14 == 0) {
        unaff_RBP = (undefined8 *)0x0;
code_r0x0001800d2db7:
        iVar8 = 2;
        puVar10 = unaff_RBP + iVar6 * 0x21;
        do {
            puVar11 = puVar10 + 0x10;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar1 = (undefined8 *)(arg2 + 0x80);
            *(undefined4 *)puVar10 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar10 + 4) = uVar3;
            *(undefined4 *)(puVar10 + 1) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0xc) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x14);
            uVar4 = *(undefined4 *)(arg2 + 0x18);
            uVar5 = *(undefined4 *)(arg2 + 0x1c);
            *(undefined4 *)(puVar10 + 2) = *(undefined4 *)(arg2 + 0x10);
            *(undefined4 *)((int64_t)puVar10 + 0x14) = uVar3;
            *(undefined4 *)(puVar10 + 3) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x1c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x24);
            uVar4 = *(undefined4 *)(arg2 + 0x28);
            uVar5 = *(undefined4 *)(arg2 + 0x2c);
            *(undefined4 *)(puVar10 + 4) = *(undefined4 *)(arg2 + 0x20);
            *(undefined4 *)((int64_t)puVar10 + 0x24) = uVar3;
            *(undefined4 *)(puVar10 + 5) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x2c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x34);
            uVar4 = *(undefined4 *)(arg2 + 0x38);
            uVar5 = *(undefined4 *)(arg2 + 0x3c);
            *(undefined4 *)(puVar10 + 6) = *(undefined4 *)(arg2 + 0x30);
            *(undefined4 *)((int64_t)puVar10 + 0x34) = uVar3;
            *(undefined4 *)(puVar10 + 7) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x3c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x44);
            uVar4 = *(undefined4 *)(arg2 + 0x48);
            uVar5 = *(undefined4 *)(arg2 + 0x4c);
            *(undefined4 *)(puVar10 + 8) = *(undefined4 *)(arg2 + 0x40);
            *(undefined4 *)((int64_t)puVar10 + 0x44) = uVar3;
            *(undefined4 *)(puVar10 + 9) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x4c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x54);
            uVar4 = *(undefined4 *)(arg2 + 0x58);
            uVar5 = *(undefined4 *)(arg2 + 0x5c);
            *(undefined4 *)(puVar10 + 10) = *(undefined4 *)(arg2 + 0x50);
            *(undefined4 *)((int64_t)puVar10 + 0x54) = uVar3;
            *(undefined4 *)(puVar10 + 0xb) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x5c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 100);
            uVar4 = *(undefined4 *)(arg2 + 0x68);
            uVar5 = *(undefined4 *)(arg2 + 0x6c);
            *(undefined4 *)(puVar10 + 0xc) = *(undefined4 *)(arg2 + 0x60);
            *(undefined4 *)((int64_t)puVar10 + 100) = uVar3;
            *(undefined4 *)(puVar10 + 0xd) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x6c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x74);
            uVar4 = *(undefined4 *)(arg2 + 0x78);
            uVar5 = *(undefined4 *)(arg2 + 0x7c);
            *(undefined4 *)(puVar10 + 0xe) = *(undefined4 *)(arg2 + 0x70);
            *(undefined4 *)((int64_t)puVar10 + 0x74) = uVar3;
            *(undefined4 *)(puVar10 + 0xf) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x7c) = uVar5;
            iVar8 = iVar8 + -1;
            puVar10 = puVar11;
            arg2 = (int64_t)puVar1;
        } while (iVar8 != 0);
        *puVar11 = *puVar1;
        puVar10 = *(undefined8 **)arg1;
        if (puVar12 == *(undefined8 **)(arg1 + 8)) {
            iVar6 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar10;
            puVar11 = unaff_RBP;
            puVar12 = puVar10;
        } else {
            fcn.180498030(unaff_RBP, puVar10, (int64_t)puVar12 - (int64_t)puVar10);
            puVar11 = unaff_RBP + iVar6 * 0x21 + 0x21;
            iVar6 = *(int64_t *)(arg1 + 8) - (int64_t)puVar12;
        }
        fcn.180498030(puVar11, puVar12, iVar6);
        iVar6 = *(int64_t *)arg1;
        if (iVar6 == 0) goto code_r0x0001800d2eae;
        iVar8 = iVar6;
        piVar13 = &var_48h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar6 >> 3) * 8)) &&
           (iVar8 = *(int64_t *)(iVar6 + -8), piVar13 = &var_48h, 0x1f < (iVar6 - iVar8) - 8U))
        goto code_r0x0001800d2e9c;
    } else {
        if (uVar14 < 0x1000) {
            unaff_RBP = (undefined8 *)fcn.180459890(uVar14);
            goto code_r0x0001800d2db7;
        }
        if (uVar14 + 0x27 <= uVar14) goto code_r0x0001800d2eee;
        iVar8 = fcn.180459890();
        if (iVar8 != 0) {
            unaff_RBP = (undefined8 *)(iVar8 + 0x27U & 0xffffffffffffffe0);
            unaff_RBP[-1] = iVar8;
            goto code_r0x0001800d2db7;
        }
code_r0x0001800d2e9c:
        iVar8 = 5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        piVar13 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800d2eae;
    fcn.180459c3c(iVar8);
code_r0x0001800d2eae:
    *(undefined8 **)arg1 = unaff_RBP;
    *(undefined8 **)(arg1 + 8) = unaff_RBP + uVar7 * 0x21;
    *(undefined8 **)(arg1 + 0x10) = unaff_RBP + uVar9 * 0x21;
    return;
}

// ============================================================
// Function: FUN_1800d2eee
// Address: 0x1800d2eee
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800d2c50(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    int64_t *piVar13;
    undefined8 *unaff_RBP;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_50h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    int64_t var_20h;
    
    puVar12 = *(undefined8 **)(arg1 + 8);
    if (puVar12 != *(undefined8 **)(arg1 + 0x10)) {
        iVar6 = 2;
        do {
            puVar10 = puVar12 + 0x10;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar11 = (undefined8 *)(arg2 + 0x80);
            *(undefined4 *)puVar12 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar12 + 4) = uVar3;
            *(undefined4 *)(puVar12 + 1) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0xc) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x14);
            uVar4 = *(undefined4 *)(arg2 + 0x18);
            uVar5 = *(undefined4 *)(arg2 + 0x1c);
            *(undefined4 *)(puVar12 + 2) = *(undefined4 *)(arg2 + 0x10);
            *(undefined4 *)((int64_t)puVar12 + 0x14) = uVar3;
            *(undefined4 *)(puVar12 + 3) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x1c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x24);
            uVar4 = *(undefined4 *)(arg2 + 0x28);
            uVar5 = *(undefined4 *)(arg2 + 0x2c);
            *(undefined4 *)(puVar12 + 4) = *(undefined4 *)(arg2 + 0x20);
            *(undefined4 *)((int64_t)puVar12 + 0x24) = uVar3;
            *(undefined4 *)(puVar12 + 5) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x2c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x34);
            uVar4 = *(undefined4 *)(arg2 + 0x38);
            uVar5 = *(undefined4 *)(arg2 + 0x3c);
            *(undefined4 *)(puVar12 + 6) = *(undefined4 *)(arg2 + 0x30);
            *(undefined4 *)((int64_t)puVar12 + 0x34) = uVar3;
            *(undefined4 *)(puVar12 + 7) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x3c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x44);
            uVar4 = *(undefined4 *)(arg2 + 0x48);
            uVar5 = *(undefined4 *)(arg2 + 0x4c);
            *(undefined4 *)(puVar12 + 8) = *(undefined4 *)(arg2 + 0x40);
            *(undefined4 *)((int64_t)puVar12 + 0x44) = uVar3;
            *(undefined4 *)(puVar12 + 9) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x4c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x54);
            uVar4 = *(undefined4 *)(arg2 + 0x58);
            uVar5 = *(undefined4 *)(arg2 + 0x5c);
            *(undefined4 *)(puVar12 + 10) = *(undefined4 *)(arg2 + 0x50);
            *(undefined4 *)((int64_t)puVar12 + 0x54) = uVar3;
            *(undefined4 *)(puVar12 + 0xb) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x5c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 100);
            uVar4 = *(undefined4 *)(arg2 + 0x68);
            uVar5 = *(undefined4 *)(arg2 + 0x6c);
            *(undefined4 *)(puVar12 + 0xc) = *(undefined4 *)(arg2 + 0x60);
            *(undefined4 *)((int64_t)puVar12 + 100) = uVar3;
            *(undefined4 *)(puVar12 + 0xd) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x6c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x74);
            uVar4 = *(undefined4 *)(arg2 + 0x78);
            uVar5 = *(undefined4 *)(arg2 + 0x7c);
            *(undefined4 *)(puVar12 + 0xe) = *(undefined4 *)(arg2 + 0x70);
            *(undefined4 *)((int64_t)puVar12 + 0x74) = uVar3;
            *(undefined4 *)(puVar12 + 0xf) = uVar4;
            *(undefined4 *)((int64_t)puVar12 + 0x7c) = uVar5;
            iVar6 = iVar6 + -1;
            arg2 = (int64_t)puVar11;
            puVar12 = puVar10;
        } while (iVar6 != 0);
        *puVar10 = *puVar11;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x108;
        return;
    }
    iVar6 = ((int64_t)puVar12 - *(int64_t *)arg1) / 0x108;
    if (iVar6 == 0xf83e0f83e0f83e) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar14 = ((int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * 0xf83e0f83e0f83e1;
    uVar7 = 0xf83e0f83e0f83e - (uVar14 >> 1);
    if (uVar7 <= uVar14 && uVar14 - uVar7 != 0) {
code_r0x0001800d2eee:
        fcn.180004720();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar14 = uVar14 + (uVar14 >> 1);
    uVar7 = iVar6 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar14) {
        uVar9 = uVar14;
    }
    if (0xf83e0f83e0f83e < uVar9) goto code_r0x0001800d2eee;
    uVar14 = uVar9 * 0x108;
    if (uVar14 == 0) {
        unaff_RBP = (undefined8 *)0x0;
code_r0x0001800d2db7:
        iVar8 = 2;
        puVar10 = unaff_RBP + iVar6 * 0x21;
        do {
            puVar11 = puVar10 + 0x10;
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar1 = (undefined8 *)(arg2 + 0x80);
            *(undefined4 *)puVar10 = *(undefined4 *)arg2;
            *(undefined4 *)((int64_t)puVar10 + 4) = uVar3;
            *(undefined4 *)(puVar10 + 1) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0xc) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x14);
            uVar4 = *(undefined4 *)(arg2 + 0x18);
            uVar5 = *(undefined4 *)(arg2 + 0x1c);
            *(undefined4 *)(puVar10 + 2) = *(undefined4 *)(arg2 + 0x10);
            *(undefined4 *)((int64_t)puVar10 + 0x14) = uVar3;
            *(undefined4 *)(puVar10 + 3) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x1c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x24);
            uVar4 = *(undefined4 *)(arg2 + 0x28);
            uVar5 = *(undefined4 *)(arg2 + 0x2c);
            *(undefined4 *)(puVar10 + 4) = *(undefined4 *)(arg2 + 0x20);
            *(undefined4 *)((int64_t)puVar10 + 0x24) = uVar3;
            *(undefined4 *)(puVar10 + 5) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x2c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x34);
            uVar4 = *(undefined4 *)(arg2 + 0x38);
            uVar5 = *(undefined4 *)(arg2 + 0x3c);
            *(undefined4 *)(puVar10 + 6) = *(undefined4 *)(arg2 + 0x30);
            *(undefined4 *)((int64_t)puVar10 + 0x34) = uVar3;
            *(undefined4 *)(puVar10 + 7) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x3c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x44);
            uVar4 = *(undefined4 *)(arg2 + 0x48);
            uVar5 = *(undefined4 *)(arg2 + 0x4c);
            *(undefined4 *)(puVar10 + 8) = *(undefined4 *)(arg2 + 0x40);
            *(undefined4 *)((int64_t)puVar10 + 0x44) = uVar3;
            *(undefined4 *)(puVar10 + 9) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x4c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x54);
            uVar4 = *(undefined4 *)(arg2 + 0x58);
            uVar5 = *(undefined4 *)(arg2 + 0x5c);
            *(undefined4 *)(puVar10 + 10) = *(undefined4 *)(arg2 + 0x50);
            *(undefined4 *)((int64_t)puVar10 + 0x54) = uVar3;
            *(undefined4 *)(puVar10 + 0xb) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x5c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 100);
            uVar4 = *(undefined4 *)(arg2 + 0x68);
            uVar5 = *(undefined4 *)(arg2 + 0x6c);
            *(undefined4 *)(puVar10 + 0xc) = *(undefined4 *)(arg2 + 0x60);
            *(undefined4 *)((int64_t)puVar10 + 100) = uVar3;
            *(undefined4 *)(puVar10 + 0xd) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x6c) = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x74);
            uVar4 = *(undefined4 *)(arg2 + 0x78);
            uVar5 = *(undefined4 *)(arg2 + 0x7c);
            *(undefined4 *)(puVar10 + 0xe) = *(undefined4 *)(arg2 + 0x70);
            *(undefined4 *)((int64_t)puVar10 + 0x74) = uVar3;
            *(undefined4 *)(puVar10 + 0xf) = uVar4;
            *(undefined4 *)((int64_t)puVar10 + 0x7c) = uVar5;
            iVar8 = iVar8 + -1;
            puVar10 = puVar11;
            arg2 = (int64_t)puVar1;
        } while (iVar8 != 0);
        *puVar11 = *puVar1;
        puVar10 = *(undefined8 **)arg1;
        if (puVar12 == *(undefined8 **)(arg1 + 8)) {
            iVar6 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar10;
            puVar11 = unaff_RBP;
            puVar12 = puVar10;
        } else {
            fcn.180498030(unaff_RBP, puVar10, (int64_t)puVar12 - (int64_t)puVar10);
            puVar11 = unaff_RBP + iVar6 * 0x21 + 0x21;
            iVar6 = *(int64_t *)(arg1 + 8) - (int64_t)puVar12;
        }
        fcn.180498030(puVar11, puVar12, iVar6);
        iVar6 = *(int64_t *)arg1;
        if (iVar6 == 0) goto code_r0x0001800d2eae;
        iVar8 = iVar6;
        piVar13 = &var_48h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar6 >> 3) * 8)) &&
           (iVar8 = *(int64_t *)(iVar6 + -8), piVar13 = &var_48h, 0x1f < (iVar6 - iVar8) - 8U))
        goto code_r0x0001800d2e9c;
    } else {
        if (uVar14 < 0x1000) {
            unaff_RBP = (undefined8 *)fcn.180459890(uVar14);
            goto code_r0x0001800d2db7;
        }
        if (uVar14 + 0x27 <= uVar14) goto code_r0x0001800d2eee;
        iVar8 = fcn.180459890();
        if (iVar8 != 0) {
            unaff_RBP = (undefined8 *)(iVar8 + 0x27U & 0xffffffffffffffe0);
            unaff_RBP[-1] = iVar8;
            goto code_r0x0001800d2db7;
        }
code_r0x0001800d2e9c:
        iVar8 = 5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        piVar13 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800d2eae;
    fcn.180459c3c(iVar8);
code_r0x0001800d2eae:
    *(undefined8 **)arg1 = unaff_RBP;
    *(undefined8 **)(arg1 + 8) = unaff_RBP + uVar7 * 0x21;
    *(undefined8 **)(arg1 + 0x10) = unaff_RBP + uVar9 * 0x21;
    return;
}

// ============================================================
// Function: FUN_1800d2f00
// Address: 0x1800d2f00
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800d2f00(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    undefined *puVar15;
    uint64_t uVar16;
    undefined8 uVar17;
    uint64_t uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar14 = auStack_38;
    puVar15 = auStack_38;
    puVar11 = *(undefined4 **)(arg1 + 8);
    if (puVar11 != *(undefined4 **)(arg1 + 0x10)) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *puVar11 = *(undefined4 *)arg2;
        puVar11[1] = uVar3;
        puVar11[2] = uVar4;
        puVar11[3] = uVar5;
        *(undefined8 *)(puVar11 + 4) = *(undefined8 *)(arg2 + 0x10);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x18;
        return;
    }
    iVar9 = (int64_t)puVar11 - *(int64_t *)arg1;
    iVar9 = iVar9 / 6 + (iVar9 >> 0x3f);
    iVar9 = (iVar9 >> 2) - (iVar9 >> 0x3f);
    if (iVar9 == 0xaaaaaaaaaaaaaaa) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar18 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * -0x5555555555555555;
    uVar6 = 0xaaaaaaaaaaaaaaa - (uVar18 >> 1);
    if (uVar18 < uVar6 || uVar18 - uVar6 == 0) {
        uVar6 = iVar9 + 1;
        uVar18 = uVar18 + (uVar18 >> 1);
        uVar16 = uVar6;
        if (uVar6 <= uVar18) {
            uVar16 = uVar18;
        }
        if (uVar16 < 0xaaaaaaaaaaaaaab) {
            uVar18 = uVar16 * 0x18;
            if (uVar18 == 0) {
                puVar12 = (undefined4 *)0x0;
                puVar15 = auStack_38;
            } else if (uVar18 < 0x1000) {
                puVar12 = (undefined4 *)fcn.180459890();
            } else {
                if (uVar18 + 0x27 <= uVar18) goto code_r0x0001800d30a4;
                iVar7 = fcn.180459890(uVar18 + 0x27);
                if (iVar7 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar7 = (*pcVar2)(5);
                    puVar14 = auStack_30;
                }
                puVar12 = (undefined4 *)(iVar7 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -2) = iVar7;
                puVar15 = puVar14;
            }
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar10 = puVar12 + iVar9 * 6;
            *puVar10 = *(undefined4 *)arg2;
            puVar10[1] = uVar3;
            puVar10[2] = uVar4;
            puVar10[3] = uVar5;
            *(undefined8 *)(puVar10 + 4) = *(undefined8 *)(arg2 + 0x10);
            puVar1 = *(undefined4 **)arg1;
            if (puVar11 == *(undefined4 **)(arg1 + 8)) {
                iVar9 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar1;
                puVar10 = puVar12;
                puVar11 = puVar1;
            } else {
                *(undefined8 *)(puVar15 + -8) = 0x1800d305e;
                fcn.180498030(puVar12, puVar1, (int64_t)puVar11 - (int64_t)puVar1);
                puVar10 = puVar10 + 6;
                iVar9 = *(int64_t *)(arg1 + 8) - (int64_t)puVar11;
            }
            *(undefined8 *)(puVar15 + -8) = 0x1800d3071;
            fcn.180498030(puVar10, puVar11, iVar9);
            uVar17 = *(undefined8 *)(puVar15 + 0x28);
            *(undefined8 *)(puVar15 + 0x30) = *(undefined8 *)(puVar15 + 0x40);
            *(undefined8 *)(puVar15 + 0x28) = *(undefined8 *)(puVar15 + 0x48);
            *(undefined8 *)(puVar15 + 0x20) = uVar17;
            *(undefined8 *)(puVar15 + 0x18) = *(undefined8 *)(puVar15 + 0x58);
            uVar18 = *(uint64_t *)arg1;
            if (uVar18 != 0) {
                uVar8 = uVar18;
                puVar13 = puVar15 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar18) >> 3) * 8)) {
                    uVar8 = *(uint64_t *)(uVar18 - 8);
                    uVar18 = (uVar18 - uVar8) - 8;
                    puVar13 = puVar15 + -0x10;
                    if (0x1f < uVar18) {
                        pcVar2 = (code *)swi(0x29);
                        uVar8 = uVar18;
                        (*pcVar2)(5);
                        puVar13 = puVar15 + -8;
                    }
                }
                *(undefined8 *)(puVar13 + -8) = 0x1800c7cf2;
                fcn.180459c3c(uVar8);
            }
            *(undefined4 **)arg1 = puVar12;
            *(undefined4 **)(arg1 + 8) = puVar12 + uVar6 * 6;
            *(undefined4 **)(arg1 + 0x10) = puVar12 + uVar16 * 6;
            return;
        }
    }
code_r0x0001800d30a4:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800d2f48
// Address: 0x1800d2f48
// Size: 342 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800d2f00(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    undefined *puVar15;
    uint64_t uVar16;
    undefined8 uVar17;
    uint64_t uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar14 = auStack_38;
    puVar15 = auStack_38;
    puVar11 = *(undefined4 **)(arg1 + 8);
    if (puVar11 != *(undefined4 **)(arg1 + 0x10)) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *puVar11 = *(undefined4 *)arg2;
        puVar11[1] = uVar3;
        puVar11[2] = uVar4;
        puVar11[3] = uVar5;
        *(undefined8 *)(puVar11 + 4) = *(undefined8 *)(arg2 + 0x10);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x18;
        return;
    }
    iVar9 = (int64_t)puVar11 - *(int64_t *)arg1;
    iVar9 = iVar9 / 6 + (iVar9 >> 0x3f);
    iVar9 = (iVar9 >> 2) - (iVar9 >> 0x3f);
    if (iVar9 == 0xaaaaaaaaaaaaaaa) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar18 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * -0x5555555555555555;
    uVar6 = 0xaaaaaaaaaaaaaaa - (uVar18 >> 1);
    if (uVar18 < uVar6 || uVar18 - uVar6 == 0) {
        uVar6 = iVar9 + 1;
        uVar18 = uVar18 + (uVar18 >> 1);
        uVar16 = uVar6;
        if (uVar6 <= uVar18) {
            uVar16 = uVar18;
        }
        if (uVar16 < 0xaaaaaaaaaaaaaab) {
            uVar18 = uVar16 * 0x18;
            if (uVar18 == 0) {
                puVar12 = (undefined4 *)0x0;
                puVar15 = auStack_38;
            } else if (uVar18 < 0x1000) {
                puVar12 = (undefined4 *)fcn.180459890();
            } else {
                if (uVar18 + 0x27 <= uVar18) goto code_r0x0001800d30a4;
                iVar7 = fcn.180459890(uVar18 + 0x27);
                if (iVar7 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar7 = (*pcVar2)(5);
                    puVar14 = auStack_30;
                }
                puVar12 = (undefined4 *)(iVar7 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -2) = iVar7;
                puVar15 = puVar14;
            }
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar10 = puVar12 + iVar9 * 6;
            *puVar10 = *(undefined4 *)arg2;
            puVar10[1] = uVar3;
            puVar10[2] = uVar4;
            puVar10[3] = uVar5;
            *(undefined8 *)(puVar10 + 4) = *(undefined8 *)(arg2 + 0x10);
            puVar1 = *(undefined4 **)arg1;
            if (puVar11 == *(undefined4 **)(arg1 + 8)) {
                iVar9 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar1;
                puVar10 = puVar12;
                puVar11 = puVar1;
            } else {
                *(undefined8 *)(puVar15 + -8) = 0x1800d305e;
                fcn.180498030(puVar12, puVar1, (int64_t)puVar11 - (int64_t)puVar1);
                puVar10 = puVar10 + 6;
                iVar9 = *(int64_t *)(arg1 + 8) - (int64_t)puVar11;
            }
            *(undefined8 *)(puVar15 + -8) = 0x1800d3071;
            fcn.180498030(puVar10, puVar11, iVar9);
            uVar17 = *(undefined8 *)(puVar15 + 0x28);
            *(undefined8 *)(puVar15 + 0x30) = *(undefined8 *)(puVar15 + 0x40);
            *(undefined8 *)(puVar15 + 0x28) = *(undefined8 *)(puVar15 + 0x48);
            *(undefined8 *)(puVar15 + 0x20) = uVar17;
            *(undefined8 *)(puVar15 + 0x18) = *(undefined8 *)(puVar15 + 0x58);
            uVar18 = *(uint64_t *)arg1;
            if (uVar18 != 0) {
                uVar8 = uVar18;
                puVar13 = puVar15 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar18) >> 3) * 8)) {
                    uVar8 = *(uint64_t *)(uVar18 - 8);
                    uVar18 = (uVar18 - uVar8) - 8;
                    puVar13 = puVar15 + -0x10;
                    if (0x1f < uVar18) {
                        pcVar2 = (code *)swi(0x29);
                        uVar8 = uVar18;
                        (*pcVar2)(5);
                        puVar13 = puVar15 + -8;
                    }
                }
                *(undefined8 *)(puVar13 + -8) = 0x1800c7cf2;
                fcn.180459c3c(uVar8);
            }
            *(undefined4 **)arg1 = puVar12;
            *(undefined4 **)(arg1 + 8) = puVar12 + uVar6 * 6;
            *(undefined4 **)(arg1 + 0x10) = puVar12 + uVar16 * 6;
            return;
        }
    }
code_r0x0001800d30a4:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800d309e
// Address: 0x1800d309e
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800d2f00(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    undefined *puVar15;
    uint64_t uVar16;
    undefined8 uVar17;
    uint64_t uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar14 = auStack_38;
    puVar15 = auStack_38;
    puVar11 = *(undefined4 **)(arg1 + 8);
    if (puVar11 != *(undefined4 **)(arg1 + 0x10)) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *puVar11 = *(undefined4 *)arg2;
        puVar11[1] = uVar3;
        puVar11[2] = uVar4;
        puVar11[3] = uVar5;
        *(undefined8 *)(puVar11 + 4) = *(undefined8 *)(arg2 + 0x10);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x18;
        return;
    }
    iVar9 = (int64_t)puVar11 - *(int64_t *)arg1;
    iVar9 = iVar9 / 6 + (iVar9 >> 0x3f);
    iVar9 = (iVar9 >> 2) - (iVar9 >> 0x3f);
    if (iVar9 == 0xaaaaaaaaaaaaaaa) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar18 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * -0x5555555555555555;
    uVar6 = 0xaaaaaaaaaaaaaaa - (uVar18 >> 1);
    if (uVar18 < uVar6 || uVar18 - uVar6 == 0) {
        uVar6 = iVar9 + 1;
        uVar18 = uVar18 + (uVar18 >> 1);
        uVar16 = uVar6;
        if (uVar6 <= uVar18) {
            uVar16 = uVar18;
        }
        if (uVar16 < 0xaaaaaaaaaaaaaab) {
            uVar18 = uVar16 * 0x18;
            if (uVar18 == 0) {
                puVar12 = (undefined4 *)0x0;
                puVar15 = auStack_38;
            } else if (uVar18 < 0x1000) {
                puVar12 = (undefined4 *)fcn.180459890();
            } else {
                if (uVar18 + 0x27 <= uVar18) goto code_r0x0001800d30a4;
                iVar7 = fcn.180459890(uVar18 + 0x27);
                if (iVar7 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar7 = (*pcVar2)(5);
                    puVar14 = auStack_30;
                }
                puVar12 = (undefined4 *)(iVar7 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -2) = iVar7;
                puVar15 = puVar14;
            }
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar10 = puVar12 + iVar9 * 6;
            *puVar10 = *(undefined4 *)arg2;
            puVar10[1] = uVar3;
            puVar10[2] = uVar4;
            puVar10[3] = uVar5;
            *(undefined8 *)(puVar10 + 4) = *(undefined8 *)(arg2 + 0x10);
            puVar1 = *(undefined4 **)arg1;
            if (puVar11 == *(undefined4 **)(arg1 + 8)) {
                iVar9 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar1;
                puVar10 = puVar12;
                puVar11 = puVar1;
            } else {
                *(undefined8 *)(puVar15 + -8) = 0x1800d305e;
                fcn.180498030(puVar12, puVar1, (int64_t)puVar11 - (int64_t)puVar1);
                puVar10 = puVar10 + 6;
                iVar9 = *(int64_t *)(arg1 + 8) - (int64_t)puVar11;
            }
            *(undefined8 *)(puVar15 + -8) = 0x1800d3071;
            fcn.180498030(puVar10, puVar11, iVar9);
            uVar17 = *(undefined8 *)(puVar15 + 0x28);
            *(undefined8 *)(puVar15 + 0x30) = *(undefined8 *)(puVar15 + 0x40);
            *(undefined8 *)(puVar15 + 0x28) = *(undefined8 *)(puVar15 + 0x48);
            *(undefined8 *)(puVar15 + 0x20) = uVar17;
            *(undefined8 *)(puVar15 + 0x18) = *(undefined8 *)(puVar15 + 0x58);
            uVar18 = *(uint64_t *)arg1;
            if (uVar18 != 0) {
                uVar8 = uVar18;
                puVar13 = puVar15 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar18) >> 3) * 8)) {
                    uVar8 = *(uint64_t *)(uVar18 - 8);
                    uVar18 = (uVar18 - uVar8) - 8;
                    puVar13 = puVar15 + -0x10;
                    if (0x1f < uVar18) {
                        pcVar2 = (code *)swi(0x29);
                        uVar8 = uVar18;
                        (*pcVar2)(5);
                        puVar13 = puVar15 + -8;
                    }
                }
                *(undefined8 *)(puVar13 + -8) = 0x1800c7cf2;
                fcn.180459c3c(uVar8);
            }
            *(undefined4 **)arg1 = puVar12;
            *(undefined4 **)(arg1 + 8) = puVar12 + uVar6 * 6;
            *(undefined4 **)(arg1 + 0x10) = puVar12 + uVar16 * 6;
            return;
        }
    }
code_r0x0001800d30a4:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800d30a4
// Address: 0x1800d30a4
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800d2f00(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    undefined *puVar15;
    uint64_t uVar16;
    undefined8 uVar17;
    uint64_t uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar14 = auStack_38;
    puVar15 = auStack_38;
    puVar11 = *(undefined4 **)(arg1 + 8);
    if (puVar11 != *(undefined4 **)(arg1 + 0x10)) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *puVar11 = *(undefined4 *)arg2;
        puVar11[1] = uVar3;
        puVar11[2] = uVar4;
        puVar11[3] = uVar5;
        *(undefined8 *)(puVar11 + 4) = *(undefined8 *)(arg2 + 0x10);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x18;
        return;
    }
    iVar9 = (int64_t)puVar11 - *(int64_t *)arg1;
    iVar9 = iVar9 / 6 + (iVar9 >> 0x3f);
    iVar9 = (iVar9 >> 2) - (iVar9 >> 0x3f);
    if (iVar9 == 0xaaaaaaaaaaaaaaa) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar18 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * -0x5555555555555555;
    uVar6 = 0xaaaaaaaaaaaaaaa - (uVar18 >> 1);
    if (uVar18 < uVar6 || uVar18 - uVar6 == 0) {
        uVar6 = iVar9 + 1;
        uVar18 = uVar18 + (uVar18 >> 1);
        uVar16 = uVar6;
        if (uVar6 <= uVar18) {
            uVar16 = uVar18;
        }
        if (uVar16 < 0xaaaaaaaaaaaaaab) {
            uVar18 = uVar16 * 0x18;
            if (uVar18 == 0) {
                puVar12 = (undefined4 *)0x0;
                puVar15 = auStack_38;
            } else if (uVar18 < 0x1000) {
                puVar12 = (undefined4 *)fcn.180459890();
            } else {
                if (uVar18 + 0x27 <= uVar18) goto code_r0x0001800d30a4;
                iVar7 = fcn.180459890(uVar18 + 0x27);
                if (iVar7 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar7 = (*pcVar2)(5);
                    puVar14 = auStack_30;
                }
                puVar12 = (undefined4 *)(iVar7 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -2) = iVar7;
                puVar15 = puVar14;
            }
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar10 = puVar12 + iVar9 * 6;
            *puVar10 = *(undefined4 *)arg2;
            puVar10[1] = uVar3;
            puVar10[2] = uVar4;
            puVar10[3] = uVar5;
            *(undefined8 *)(puVar10 + 4) = *(undefined8 *)(arg2 + 0x10);
            puVar1 = *(undefined4 **)arg1;
            if (puVar11 == *(undefined4 **)(arg1 + 8)) {
                iVar9 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar1;
                puVar10 = puVar12;
                puVar11 = puVar1;
            } else {
                *(undefined8 *)(puVar15 + -8) = 0x1800d305e;
                fcn.180498030(puVar12, puVar1, (int64_t)puVar11 - (int64_t)puVar1);
                puVar10 = puVar10 + 6;
                iVar9 = *(int64_t *)(arg1 + 8) - (int64_t)puVar11;
            }
            *(undefined8 *)(puVar15 + -8) = 0x1800d3071;
            fcn.180498030(puVar10, puVar11, iVar9);
            uVar17 = *(undefined8 *)(puVar15 + 0x28);
            *(undefined8 *)(puVar15 + 0x30) = *(undefined8 *)(puVar15 + 0x40);
            *(undefined8 *)(puVar15 + 0x28) = *(undefined8 *)(puVar15 + 0x48);
            *(undefined8 *)(puVar15 + 0x20) = uVar17;
            *(undefined8 *)(puVar15 + 0x18) = *(undefined8 *)(puVar15 + 0x58);
            uVar18 = *(uint64_t *)arg1;
            if (uVar18 != 0) {
                uVar8 = uVar18;
                puVar13 = puVar15 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar18) >> 3) * 8)) {
                    uVar8 = *(uint64_t *)(uVar18 - 8);
                    uVar18 = (uVar18 - uVar8) - 8;
                    puVar13 = puVar15 + -0x10;
                    if (0x1f < uVar18) {
                        pcVar2 = (code *)swi(0x29);
                        uVar8 = uVar18;
                        (*pcVar2)(5);
                        puVar13 = puVar15 + -8;
                    }
                }
                *(undefined8 *)(puVar13 + -8) = 0x1800c7cf2;
                fcn.180459c3c(uVar8);
            }
            *(undefined4 **)arg1 = puVar12;
            *(undefined4 **)(arg1 + 8) = puVar12 + uVar6 * 6;
            *(undefined4 **)(arg1 + 0x10) = puVar12 + uVar16 * 6;
            return;
        }
    }
code_r0x0001800d30a4:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800d30b0
// Address: 0x1800d30b0
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800d30b0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    puVar8 = auStack_28;
    iVar1 = *(int64_t *)arg1;
    if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar1 >> 2) < (uint64_t)arg2) {
        if (0x3fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        iVar2 = *(int64_t *)(arg1 + 8);
        uVar6 = arg2 * 4;
        if (uVar6 == 0) {
            uVar6 = 0;
            puVar8 = auStack_28;
        } else if (uVar6 < 0x1000) {
            uVar6 = fcn.180459890();
        } else {
            if (uVar6 + 0x27 <= uVar6) {
                fcn.180004720();
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            iVar5 = fcn.180459890(uVar6 + 0x27);
            if (iVar5 == 0) {
                pcVar4 = (code *)swi(0x29);
                iVar5 = (*pcVar4)(5);
                puVar7 = auStack_20;
            }
            uVar6 = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar6 - 8) = iVar5;
            puVar8 = puVar7;
        }
        iVar5 = *(int64_t *)arg1;
        iVar3 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar8 + -8) = 0x1800d3164;
        fcn.180498030(uVar6, iVar5, iVar3 - iVar5);
        *(undefined8 *)(puVar8 + -8) = 0x1800d3175;
        func_0x000180030d40(arg1, uVar6, iVar2 - iVar1 >> 2, arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d30f0
// Address: 0x1800d30f0
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800d30b0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    puVar8 = auStack_28;
    iVar1 = *(int64_t *)arg1;
    if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar1 >> 2) < (uint64_t)arg2) {
        if (0x3fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        iVar2 = *(int64_t *)(arg1 + 8);
        uVar6 = arg2 * 4;
        if (uVar6 == 0) {
            uVar6 = 0;
            puVar8 = auStack_28;
        } else if (uVar6 < 0x1000) {
            uVar6 = fcn.180459890();
        } else {
            if (uVar6 + 0x27 <= uVar6) {
                fcn.180004720();
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            iVar5 = fcn.180459890(uVar6 + 0x27);
            if (iVar5 == 0) {
                pcVar4 = (code *)swi(0x29);
                iVar5 = (*pcVar4)(5);
                puVar7 = auStack_20;
            }
            uVar6 = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar6 - 8) = iVar5;
            puVar8 = puVar7;
        }
        iVar5 = *(int64_t *)arg1;
        iVar3 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar8 + -8) = 0x1800d3164;
        fcn.180498030(uVar6, iVar5, iVar3 - iVar5);
        *(undefined8 *)(puVar8 + -8) = 0x1800d3175;
        func_0x000180030d40(arg1, uVar6, iVar2 - iVar1 >> 2, arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d317f
// Address: 0x1800d317f
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800d30b0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    puVar8 = auStack_28;
    iVar1 = *(int64_t *)arg1;
    if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar1 >> 2) < (uint64_t)arg2) {
        if (0x3fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        iVar2 = *(int64_t *)(arg1 + 8);
        uVar6 = arg2 * 4;
        if (uVar6 == 0) {
            uVar6 = 0;
            puVar8 = auStack_28;
        } else if (uVar6 < 0x1000) {
            uVar6 = fcn.180459890();
        } else {
            if (uVar6 + 0x27 <= uVar6) {
                fcn.180004720();
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            iVar5 = fcn.180459890(uVar6 + 0x27);
            if (iVar5 == 0) {
                pcVar4 = (code *)swi(0x29);
                iVar5 = (*pcVar4)(5);
                puVar7 = auStack_20;
            }
            uVar6 = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar6 - 8) = iVar5;
            puVar8 = puVar7;
        }
        iVar5 = *(int64_t *)arg1;
        iVar3 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar8 + -8) = 0x1800d3164;
        fcn.180498030(uVar6, iVar5, iVar3 - iVar5);
        *(undefined8 *)(puVar8 + -8) = 0x1800d3175;
        func_0x000180030d40(arg1, uVar6, iVar2 - iVar1 >> 2, arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d3190
// Address: 0x1800d3190
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800d30b0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    puVar8 = auStack_28;
    iVar1 = *(int64_t *)arg1;
    if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar1 >> 2) < (uint64_t)arg2) {
        if (0x3fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        iVar2 = *(int64_t *)(arg1 + 8);
        uVar6 = arg2 * 4;
        if (uVar6 == 0) {
            uVar6 = 0;
            puVar8 = auStack_28;
        } else if (uVar6 < 0x1000) {
            uVar6 = fcn.180459890();
        } else {
            if (uVar6 + 0x27 <= uVar6) {
                fcn.180004720();
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            iVar5 = fcn.180459890(uVar6 + 0x27);
            if (iVar5 == 0) {
                pcVar4 = (code *)swi(0x29);
                iVar5 = (*pcVar4)(5);
                puVar7 = auStack_20;
            }
            uVar6 = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar6 - 8) = iVar5;
            puVar8 = puVar7;
        }
        iVar5 = *(int64_t *)arg1;
        iVar3 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar8 + -8) = 0x1800d3164;
        fcn.180498030(uVar6, iVar5, iVar3 - iVar5);
        *(undefined8 *)(puVar8 + -8) = 0x1800d3175;
        func_0x000180030d40(arg1, uVar6, iVar2 - iVar1 >> 2, arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d3196
// Address: 0x1800d3196
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800d30b0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    puVar8 = auStack_28;
    iVar1 = *(int64_t *)arg1;
    if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar1 >> 2) < (uint64_t)arg2) {
        if (0x3fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        iVar2 = *(int64_t *)(arg1 + 8);
        uVar6 = arg2 * 4;
        if (uVar6 == 0) {
            uVar6 = 0;
            puVar8 = auStack_28;
        } else if (uVar6 < 0x1000) {
            uVar6 = fcn.180459890();
        } else {
            if (uVar6 + 0x27 <= uVar6) {
                fcn.180004720();
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            iVar5 = fcn.180459890(uVar6 + 0x27);
            if (iVar5 == 0) {
                pcVar4 = (code *)swi(0x29);
                iVar5 = (*pcVar4)(5);
                puVar7 = auStack_20;
            }
            uVar6 = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar6 - 8) = iVar5;
            puVar8 = puVar7;
        }
        iVar5 = *(int64_t *)arg1;
        iVar3 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar8 + -8) = 0x1800d3164;
        fcn.180498030(uVar6, iVar5, iVar3 - iVar5);
        *(undefined8 *)(puVar8 + -8) = 0x1800d3175;
        func_0x000180030d40(arg1, uVar6, iVar2 - iVar1 >> 2, arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d31a0
// Address: 0x1800d31a0
// Size: 59 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001800cfe5d: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001800cfe62)

void fcn.1800cfe30(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    uint32_t *puVar3;
    uint32_t **ppuVar4;
    uint64_t uVar5;
    uint32_t *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    uint32_t *puVar12;
    uint8_t in_R8B;
    int64_t iVar13;
    uint32_t in_R9D;
    uint32_t uVar14;
    uint32_t *puVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_80 [3];
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    
    ppuVar4 = (uint32_t **)(arg1 + 0x28);
    uVar14 = ((in_R9D & 0xffff) << 8 | (uint32_t)in_R8B) << 8 | (uint32_t)arg2;
    puVar8 = auStack_68;
    puVar9 = auStack_68;
    puVar15 = *(uint32_t **)(arg1 + 0x30);
    if (puVar15 != *(uint32_t **)(arg1 + 0x38)) {
        *puVar15 = uVar14;
        *(int64_t *)(arg1 + 0x30) = *(int64_t *)(arg1 + 0x30) + 4;
        return;
    }
    iVar16 = (int64_t)puVar15 - (int64_t)*ppuVar4 >> 2;
    if (iVar16 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar5 = (int64_t)*(uint32_t **)(arg1 + 0x38) - (int64_t)*ppuVar4 >> 2;
    if (uVar5 <= 0x3fffffffffffffff - (uVar5 >> 1)) {
        uVar1 = iVar16 + 1;
        uVar5 = uVar5 + (uVar5 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar5) {
            uVar10 = uVar5;
        }
        if (uVar10 < 0x4000000000000000) {
            uVar5 = uVar10 * 4;
            if (uVar5 == 0) {
                puVar12 = (uint32_t *)0x0;
                puVar9 = auStack_68;
            } else if (uVar5 < 0x1000) {
                puVar12 = (uint32_t *)fcn.180459890();
            } else {
                if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800d32fa;
                iVar13 = fcn.180459890(uVar5 + 0x27);
                if (iVar13 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar13 = (*pcVar2)(5);
                    puVar8 = auStack_60;
                }
                puVar12 = (uint32_t *)(iVar13 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -2) = iVar13;
                puVar9 = puVar8;
            }
            puVar12[iVar16] = uVar14;
            puVar3 = *ppuVar4;
            if (puVar15 == *(uint32_t **)(arg1 + 0x30)) {
                iVar13 = (int64_t)*(uint32_t **)(arg1 + 0x30) - (int64_t)puVar3;
                puVar6 = puVar12;
                puVar15 = puVar3;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x1800d32b0;
                fcn.180498030(puVar12, puVar3, (int64_t)puVar15 - (int64_t)puVar3);
                iVar13 = *(int64_t *)(arg1 + 0x30) - (int64_t)puVar15;
                puVar6 = puVar12 + iVar16 + 1;
            }
            *(undefined8 *)(puVar9 + -8) = 0x1800d32c7;
            fcn.180498030(puVar6, puVar15, iVar13);
            uVar11 = *(undefined8 *)(puVar9 + 0x28);
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar9 + 0x30);
            *(undefined8 *)(puVar9 + 0x28) = *(undefined8 *)(puVar9 + 0x40);
            *(undefined8 *)(puVar9 + 0x20) = uVar11;
            *(undefined8 *)(puVar9 + 0x18) = *(undefined8 *)(puVar9 + 0x48);
            puVar15 = *ppuVar4;
            if (puVar15 != (uint32_t *)0x0) {
                puVar3 = puVar15;
                puVar7 = puVar9 + -0x10;
                if (0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x38) - (int64_t)puVar15 >> 2) * 4)) {
                    puVar3 = *(uint32_t **)(puVar15 + -2);
                    puVar15 = (uint32_t *)((int64_t)puVar15 + (-8 - (int64_t)puVar3));
                    puVar7 = puVar9 + -0x10;
                    if ((uint32_t *)0x1f < puVar15) {
                        pcVar2 = (code *)swi(0x29);
                        puVar3 = puVar15;
                        (*pcVar2)(5);
                        puVar7 = puVar9 + -8;
                    }
                }
                *(undefined8 *)(puVar7 + -8) = 0x180030d9f;
                fcn.180459c3c(puVar3);
            }
            *ppuVar4 = puVar12;
            *(uint32_t **)(arg1 + 0x30) = puVar12 + uVar1;
            *(uint32_t **)(arg1 + 0x38) = puVar12 + uVar10;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800d31db
// Address: 0x1800d31db
// Size: 281 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001800cfe5d: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001800cfe62)

void fcn.1800cfe30(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    uint32_t *puVar3;
    uint32_t **ppuVar4;
    uint64_t uVar5;
    uint32_t *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    uint32_t *puVar12;
    uint8_t in_R8B;
    int64_t iVar13;
    uint32_t in_R9D;
    uint32_t uVar14;
    uint32_t *puVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_80 [3];
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    
    ppuVar4 = (uint32_t **)(arg1 + 0x28);
    uVar14 = ((in_R9D & 0xffff) << 8 | (uint32_t)in_R8B) << 8 | (uint32_t)arg2;
    puVar8 = auStack_68;
    puVar9 = auStack_68;
    puVar15 = *(uint32_t **)(arg1 + 0x30);
    if (puVar15 != *(uint32_t **)(arg1 + 0x38)) {
        *puVar15 = uVar14;
        *(int64_t *)(arg1 + 0x30) = *(int64_t *)(arg1 + 0x30) + 4;
        return;
    }
    iVar16 = (int64_t)puVar15 - (int64_t)*ppuVar4 >> 2;
    if (iVar16 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar5 = (int64_t)*(uint32_t **)(arg1 + 0x38) - (int64_t)*ppuVar4 >> 2;
    if (uVar5 <= 0x3fffffffffffffff - (uVar5 >> 1)) {
        uVar1 = iVar16 + 1;
        uVar5 = uVar5 + (uVar5 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar5) {
            uVar10 = uVar5;
        }
        if (uVar10 < 0x4000000000000000) {
            uVar5 = uVar10 * 4;
            if (uVar5 == 0) {
                puVar12 = (uint32_t *)0x0;
                puVar9 = auStack_68;
            } else if (uVar5 < 0x1000) {
                puVar12 = (uint32_t *)fcn.180459890();
            } else {
                if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800d32fa;
                iVar13 = fcn.180459890(uVar5 + 0x27);
                if (iVar13 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar13 = (*pcVar2)(5);
                    puVar8 = auStack_60;
                }
                puVar12 = (uint32_t *)(iVar13 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -2) = iVar13;
                puVar9 = puVar8;
            }
            puVar12[iVar16] = uVar14;
            puVar3 = *ppuVar4;
            if (puVar15 == *(uint32_t **)(arg1 + 0x30)) {
                iVar13 = (int64_t)*(uint32_t **)(arg1 + 0x30) - (int64_t)puVar3;
                puVar6 = puVar12;
                puVar15 = puVar3;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x1800d32b0;
                fcn.180498030(puVar12, puVar3, (int64_t)puVar15 - (int64_t)puVar3);
                iVar13 = *(int64_t *)(arg1 + 0x30) - (int64_t)puVar15;
                puVar6 = puVar12 + iVar16 + 1;
            }
            *(undefined8 *)(puVar9 + -8) = 0x1800d32c7;
            fcn.180498030(puVar6, puVar15, iVar13);
            uVar11 = *(undefined8 *)(puVar9 + 0x28);
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar9 + 0x30);
            *(undefined8 *)(puVar9 + 0x28) = *(undefined8 *)(puVar9 + 0x40);
            *(undefined8 *)(puVar9 + 0x20) = uVar11;
            *(undefined8 *)(puVar9 + 0x18) = *(undefined8 *)(puVar9 + 0x48);
            puVar15 = *ppuVar4;
            if (puVar15 != (uint32_t *)0x0) {
                puVar3 = puVar15;
                puVar7 = puVar9 + -0x10;
                if (0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x38) - (int64_t)puVar15 >> 2) * 4)) {
                    puVar3 = *(uint32_t **)(puVar15 + -2);
                    puVar15 = (uint32_t *)((int64_t)puVar15 + (-8 - (int64_t)puVar3));
                    puVar7 = puVar9 + -0x10;
                    if ((uint32_t *)0x1f < puVar15) {
                        pcVar2 = (code *)swi(0x29);
                        puVar3 = puVar15;
                        (*pcVar2)(5);
                        puVar7 = puVar9 + -8;
                    }
                }
                *(undefined8 *)(puVar7 + -8) = 0x180030d9f;
                fcn.180459c3c(puVar3);
            }
            *ppuVar4 = puVar12;
            *(uint32_t **)(arg1 + 0x30) = puVar12 + uVar1;
            *(uint32_t **)(arg1 + 0x38) = puVar12 + uVar10;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800d32f4
// Address: 0x1800d32f4
// Size: 6 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001800cfe5d: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001800cfe62)

void fcn.1800cfe30(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    uint32_t *puVar3;
    uint32_t **ppuVar4;
    uint64_t uVar5;
    uint32_t *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    uint32_t *puVar12;
    uint8_t in_R8B;
    int64_t iVar13;
    uint32_t in_R9D;
    uint32_t uVar14;
    uint32_t *puVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_80 [3];
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    
    ppuVar4 = (uint32_t **)(arg1 + 0x28);
    uVar14 = ((in_R9D & 0xffff) << 8 | (uint32_t)in_R8B) << 8 | (uint32_t)arg2;
    puVar8 = auStack_68;
    puVar9 = auStack_68;
    puVar15 = *(uint32_t **)(arg1 + 0x30);
    if (puVar15 != *(uint32_t **)(arg1 + 0x38)) {
        *puVar15 = uVar14;
        *(int64_t *)(arg1 + 0x30) = *(int64_t *)(arg1 + 0x30) + 4;
        return;
    }
    iVar16 = (int64_t)puVar15 - (int64_t)*ppuVar4 >> 2;
    if (iVar16 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar5 = (int64_t)*(uint32_t **)(arg1 + 0x38) - (int64_t)*ppuVar4 >> 2;
    if (uVar5 <= 0x3fffffffffffffff - (uVar5 >> 1)) {
        uVar1 = iVar16 + 1;
        uVar5 = uVar5 + (uVar5 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar5) {
            uVar10 = uVar5;
        }
        if (uVar10 < 0x4000000000000000) {
            uVar5 = uVar10 * 4;
            if (uVar5 == 0) {
                puVar12 = (uint32_t *)0x0;
                puVar9 = auStack_68;
            } else if (uVar5 < 0x1000) {
                puVar12 = (uint32_t *)fcn.180459890();
            } else {
                if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800d32fa;
                iVar13 = fcn.180459890(uVar5 + 0x27);
                if (iVar13 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar13 = (*pcVar2)(5);
                    puVar8 = auStack_60;
                }
                puVar12 = (uint32_t *)(iVar13 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -2) = iVar13;
                puVar9 = puVar8;
            }
            puVar12[iVar16] = uVar14;
            puVar3 = *ppuVar4;
            if (puVar15 == *(uint32_t **)(arg1 + 0x30)) {
                iVar13 = (int64_t)*(uint32_t **)(arg1 + 0x30) - (int64_t)puVar3;
                puVar6 = puVar12;
                puVar15 = puVar3;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x1800d32b0;
                fcn.180498030(puVar12, puVar3, (int64_t)puVar15 - (int64_t)puVar3);
                iVar13 = *(int64_t *)(arg1 + 0x30) - (int64_t)puVar15;
                puVar6 = puVar12 + iVar16 + 1;
            }
            *(undefined8 *)(puVar9 + -8) = 0x1800d32c7;
            fcn.180498030(puVar6, puVar15, iVar13);
            uVar11 = *(undefined8 *)(puVar9 + 0x28);
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar9 + 0x30);
            *(undefined8 *)(puVar9 + 0x28) = *(undefined8 *)(puVar9 + 0x40);
            *(undefined8 *)(puVar9 + 0x20) = uVar11;
            *(undefined8 *)(puVar9 + 0x18) = *(undefined8 *)(puVar9 + 0x48);
            puVar15 = *ppuVar4;
            if (puVar15 != (uint32_t *)0x0) {
                puVar3 = puVar15;
                puVar7 = puVar9 + -0x10;
                if (0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x38) - (int64_t)puVar15 >> 2) * 4)) {
                    puVar3 = *(uint32_t **)(puVar15 + -2);
                    puVar15 = (uint32_t *)((int64_t)puVar15 + (-8 - (int64_t)puVar3));
                    puVar7 = puVar9 + -0x10;
                    if ((uint32_t *)0x1f < puVar15) {
                        pcVar2 = (code *)swi(0x29);
                        puVar3 = puVar15;
                        (*pcVar2)(5);
                        puVar7 = puVar9 + -8;
                    }
                }
                *(undefined8 *)(puVar7 + -8) = 0x180030d9f;
                fcn.180459c3c(puVar3);
            }
            *ppuVar4 = puVar12;
            *(uint32_t **)(arg1 + 0x30) = puVar12 + uVar1;
            *(uint32_t **)(arg1 + 0x38) = puVar12 + uVar10;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800d32fa
// Address: 0x1800d32fa
// Size: 6 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001800cfe5d: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001800cfe62)

void fcn.1800cfe30(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    uint32_t *puVar3;
    uint32_t **ppuVar4;
    uint64_t uVar5;
    uint32_t *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    uint32_t *puVar12;
    uint8_t in_R8B;
    int64_t iVar13;
    uint32_t in_R9D;
    uint32_t uVar14;
    uint32_t *puVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_80 [3];
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    
    ppuVar4 = (uint32_t **)(arg1 + 0x28);
    uVar14 = ((in_R9D & 0xffff) << 8 | (uint32_t)in_R8B) << 8 | (uint32_t)arg2;
    puVar8 = auStack_68;
    puVar9 = auStack_68;
    puVar15 = *(uint32_t **)(arg1 + 0x30);
    if (puVar15 != *(uint32_t **)(arg1 + 0x38)) {
        *puVar15 = uVar14;
        *(int64_t *)(arg1 + 0x30) = *(int64_t *)(arg1 + 0x30) + 4;
        return;
    }
    iVar16 = (int64_t)puVar15 - (int64_t)*ppuVar4 >> 2;
    if (iVar16 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar5 = (int64_t)*(uint32_t **)(arg1 + 0x38) - (int64_t)*ppuVar4 >> 2;
    if (uVar5 <= 0x3fffffffffffffff - (uVar5 >> 1)) {
        uVar1 = iVar16 + 1;
        uVar5 = uVar5 + (uVar5 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar5) {
            uVar10 = uVar5;
        }
        if (uVar10 < 0x4000000000000000) {
            uVar5 = uVar10 * 4;
            if (uVar5 == 0) {
                puVar12 = (uint32_t *)0x0;
                puVar9 = auStack_68;
            } else if (uVar5 < 0x1000) {
                puVar12 = (uint32_t *)fcn.180459890();
            } else {
                if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800d32fa;
                iVar13 = fcn.180459890(uVar5 + 0x27);
                if (iVar13 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar13 = (*pcVar2)(5);
                    puVar8 = auStack_60;
                }
                puVar12 = (uint32_t *)(iVar13 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -2) = iVar13;
                puVar9 = puVar8;
            }
            puVar12[iVar16] = uVar14;
            puVar3 = *ppuVar4;
            if (puVar15 == *(uint32_t **)(arg1 + 0x30)) {
                iVar13 = (int64_t)*(uint32_t **)(arg1 + 0x30) - (int64_t)puVar3;
                puVar6 = puVar12;
                puVar15 = puVar3;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x1800d32b0;
                fcn.180498030(puVar12, puVar3, (int64_t)puVar15 - (int64_t)puVar3);
                iVar13 = *(int64_t *)(arg1 + 0x30) - (int64_t)puVar15;
                puVar6 = puVar12 + iVar16 + 1;
            }
            *(undefined8 *)(puVar9 + -8) = 0x1800d32c7;
            fcn.180498030(puVar6, puVar15, iVar13);
            uVar11 = *(undefined8 *)(puVar9 + 0x28);
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar9 + 0x30);
            *(undefined8 *)(puVar9 + 0x28) = *(undefined8 *)(puVar9 + 0x40);
            *(undefined8 *)(puVar9 + 0x20) = uVar11;
            *(undefined8 *)(puVar9 + 0x18) = *(undefined8 *)(puVar9 + 0x48);
            puVar15 = *ppuVar4;
            if (puVar15 != (uint32_t *)0x0) {
                puVar3 = puVar15;
                puVar7 = puVar9 + -0x10;
                if (0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x38) - (int64_t)puVar15 >> 2) * 4)) {
                    puVar3 = *(uint32_t **)(puVar15 + -2);
                    puVar15 = (uint32_t *)((int64_t)puVar15 + (-8 - (int64_t)puVar3));
                    puVar7 = puVar9 + -0x10;
                    if ((uint32_t *)0x1f < puVar15) {
                        pcVar2 = (code *)swi(0x29);
                        puVar3 = puVar15;
                        (*pcVar2)(5);
                        puVar7 = puVar9 + -8;
                    }
                }
                *(undefined8 *)(puVar7 + -8) = 0x180030d9f;
                fcn.180459c3c(puVar3);
            }
            *ppuVar4 = puVar12;
            *(uint32_t **)(arg1 + 0x30) = puVar12 + uVar1;
            *(uint32_t **)(arg1 + 0x38) = puVar12 + uVar10;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800d3300
// Address: 0x1800d3300
// Size: 1359 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d3300(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t var_8h;
    
    uVar4 = arg2 - arg1;
    do {
        if ((int64_t)(uVar4 & 0xfffffffffffffff8) < 0x101) {
            puVar12 = (undefined8 *)arg1;
            if (arg1 != arg2) {
                while (puVar12 = puVar12 + 1, puVar12 != (undefined8 *)arg2) {
                    uVar3 = *puVar12;
                    if ((uint32_t)uVar3 < *(uint32_t *)arg1) {
                        fcn.180498030((undefined8 *)(arg1 + 8), arg1);
                        *(undefined8 *)arg1 = uVar3;
                    } else {
                        uVar7 = *(uint32_t *)(puVar12 + -1);
                        puVar11 = puVar12 + -1;
                        puVar10 = puVar12;
                        while (puVar9 = puVar11, (uint32_t)uVar3 < uVar7) {
                            *puVar10 = *puVar9;
                            puVar11 = puVar9 + -1;
                            puVar10 = puVar9;
                            uVar7 = *(uint32_t *)(puVar9 + -1);
                        }
                        *puVar10 = uVar3;
                    }
                }
            }
            return;
        }
        iVar6 = arg2 - arg1 >> 4;
        if (arg3 < 1) {
            uVar4 = arg2 - arg1 >> 3;
            if (0 < iVar6) {
                iVar5 = (int64_t)(uVar4 - 1) >> 1;
                do {
                    uVar3 = *(undefined8 *)(arg1 + (iVar6 + -1) * 8);
                    iVar6 = iVar6 + -1;
                    iVar14 = iVar6;
                    while (iVar14 < iVar5) {
                        iVar8 = iVar14 * 2;
                        iVar13 = iVar8 + 2;
                        if (*(uint32_t *)(arg1 + (iVar8 + 2) * 8) < *(uint32_t *)(arg1 + (iVar8 + 1) * 8)) {
                            iVar13 = iVar8 + 1;
                        }
                        *(undefined8 *)(arg1 + iVar14 * 8) = *(undefined8 *)(arg1 + iVar13 * 8);
                        iVar14 = iVar13;
                    }
                    if ((iVar14 == iVar5) && ((uVar4 & 1) == 0)) {
                        *(undefined8 *)(arg1 + iVar14 * 8) = *(undefined8 *)(arg1 + (uVar4 - 1) * 8);
                        iVar14 = uVar4 - 1;
                    }
                    while ((iVar6 < iVar14 &&
                           (iVar8 = iVar14 + -1 >> 1, *(uint32_t *)(arg1 + iVar8 * 8) < (uint32_t)uVar3))) {
                        *(undefined8 *)(arg1 + iVar14 * 8) = *(undefined8 *)(arg1 + iVar8 * 8);
                        iVar14 = iVar8;
                    }
                    *(undefined8 *)(arg1 + iVar14 * 8) = uVar3;
                } while (0 < iVar6);
            }
            if ((int64_t)(arg2 - arg1 & 0xfffffffffffffff8U) < 0x10) {
                return;
            }
            do {
                if (0xf < (int64_t)(arg2 - arg1 & 0xfffffffffffffff8U)) {
                    uVar3 = *(undefined8 *)(arg2 + -8);
                    *(undefined8 *)(arg2 + -8) = *(undefined8 *)arg1;
                    iVar6 = 0;
                    uVar4 = (int64_t)(undefined8 *)(arg2 + -8) - arg1 >> 3;
                    iVar14 = (int64_t)(uVar4 - 1) >> 1;
                    iVar5 = iVar6;
                    if (0 < iVar14) {
                        do {
                            iVar8 = iVar5 * 2;
                            iVar6 = iVar8 + 2;
                            if (*(uint32_t *)(arg1 + (iVar8 + 2) * 8) < *(uint32_t *)(arg1 + (iVar8 + 1) * 8)) {
                                iVar6 = iVar8 + 1;
                            }
                            *(undefined8 *)(arg1 + iVar5 * 8) = *(undefined8 *)(arg1 + iVar6 * 8);
                            iVar5 = iVar6;
                        } while (iVar6 < iVar14);
                    }
                    if ((iVar6 == iVar14) && ((uVar4 & 1) == 0)) {
                        *(undefined8 *)(arg1 + iVar6 * 8) = *(undefined8 *)(arg1 + (uVar4 - 1) * 8);
                        iVar6 = uVar4 - 1;
                    }
                    while ((0 < iVar6 && (iVar5 = iVar6 + -1 >> 1, *(uint32_t *)(arg1 + iVar5 * 8) < (uint32_t)uVar3)))
                    {
                        *(undefined8 *)(arg1 + iVar6 * 8) = *(undefined8 *)(arg1 + iVar5 * 8);
                        iVar6 = iVar5;
                    }
                    *(undefined8 *)(arg1 + iVar6 * 8) = uVar3;
                }
                arg2 = arg2 + -8;
            } while (0xf < (int64_t)(arg2 - arg1 & 0xfffffffffffffff8U));
            return;
        }
        iVar5 = arg2 + (-8 - arg1) >> 3;
        puVar12 = (undefined8 *)(arg1 + iVar6 * 8);
        if (iVar5 < 0x29) {
            if (*(uint32_t *)puVar12 < *(uint32_t *)arg1) {
                uVar3 = *puVar12;
                *puVar12 = *(undefined8 *)arg1;
                *(undefined8 *)arg1 = uVar3;
            }
            if (*(uint32_t *)(arg2 + -8) < *(uint32_t *)puVar12) {
                uVar3 = *(undefined8 *)(arg2 + -8);
                *(undefined8 *)(arg2 + -8) = *puVar12;
                *puVar12 = uVar3;
                if ((uint32_t)uVar3 < *(uint32_t *)arg1) {
                    *puVar12 = *(undefined8 *)arg1;
                    *(undefined8 *)arg1 = uVar3;
                }
            }
        } else {
            iVar6 = iVar5 + 1 >> 3;
            if (*(uint32_t *)(arg1 + iVar6 * 8) < *(uint32_t *)arg1) {
                uVar3 = *(undefined8 *)(arg1 + iVar6 * 8);
                *(undefined8 *)(arg1 + iVar6 * 8) = *(undefined8 *)arg1;
                *(undefined8 *)arg1 = uVar3;
            }
            if (*(uint32_t *)(arg1 + iVar6 * 2 * 8) < *(uint32_t *)(arg1 + iVar6 * 8)) {
                uVar3 = *(undefined8 *)(arg1 + iVar6 * 2 * 8);
                *(undefined8 *)(arg1 + iVar6 * 2 * 8) = *(undefined8 *)(arg1 + iVar6 * 8);
                *(undefined8 *)(arg1 + iVar6 * 8) = uVar3;
                if ((uint32_t)uVar3 < *(uint32_t *)arg1) {
                    *(undefined8 *)(arg1 + iVar6 * 8) = *(undefined8 *)arg1;
                    *(undefined8 *)arg1 = uVar3;
                }
            }
            puVar10 = puVar12 + -iVar6;
            if (*(uint32_t *)puVar12 < *(uint32_t *)puVar10) {
                uVar3 = *puVar12;
                *puVar12 = *puVar10;
                *puVar10 = uVar3;
            }
            if (*(uint32_t *)(puVar12 + iVar6) < *(uint32_t *)puVar12) {
                uVar3 = puVar12[iVar6];
                puVar12[iVar6] = *puVar12;
                *puVar12 = uVar3;
                if ((uint32_t)uVar3 < *(uint32_t *)puVar10) {
                    *puVar12 = *puVar10;
                    *puVar10 = uVar3;
                }
            }
            puVar11 = (undefined8 *)(arg2 + (iVar6 * -2 + -1) * 8);
            puVar10 = (undefined8 *)(arg2 + (-1 - iVar6) * 8);
            if (*(uint32_t *)puVar10 < *(uint32_t *)puVar11) {
                uVar3 = *puVar10;
                *puVar10 = *puVar11;
                *puVar11 = uVar3;
            }
            if (*(uint32_t *)(arg2 + -8) < *(uint32_t *)puVar10) {
                uVar3 = *(undefined8 *)(arg2 + -8);
                *(undefined8 *)(arg2 + -8) = *puVar10;
                *puVar10 = uVar3;
                if ((uint32_t)uVar3 < *(uint32_t *)puVar11) {
                    *puVar10 = *puVar11;
                    *puVar11 = uVar3;
                }
            }
            if (*(uint32_t *)puVar12 < *(uint32_t *)(arg1 + iVar6 * 8)) {
                uVar3 = *puVar12;
                *puVar12 = *(undefined8 *)(arg1 + iVar6 * 8);
                *(undefined8 *)(arg1 + iVar6 * 8) = uVar3;
            }
            if (*(uint32_t *)puVar10 < *(uint32_t *)puVar12) {
                uVar3 = *puVar10;
                *puVar10 = *puVar12;
                *puVar12 = uVar3;
                if ((uint32_t)uVar3 < *(uint32_t *)(arg1 + iVar6 * 8)) {
                    *puVar12 = *(undefined8 *)(arg1 + iVar6 * 8);
                    *(undefined8 *)(arg1 + iVar6 * 8) = uVar3;
                }
            }
        }
        puVar10 = puVar12 + 1;
        if ((uint64_t)arg1 < puVar12) {
            uVar7 = *(uint32_t *)puVar12;
            do {
                uVar2 = *(uint32_t *)(puVar12 + -1);
                puVar11 = puVar12 + -1;
                if ((uVar2 < uVar7) || (uVar2 >= uVar7 && uVar2 != uVar7)) break;
                puVar12 = puVar11;
                uVar7 = uVar2;
            } while ((uint64_t)arg1 < puVar11);
        }
        puVar11 = puVar10;
        puVar9 = puVar12;
        if (puVar10 < (uint64_t)arg2) {
            uVar7 = *(uint32_t *)puVar12;
            do {
                uVar2 = *(uint32_t *)puVar10;
                puVar11 = puVar10;
                if ((uVar2 < uVar7) || (uVar2 >= uVar7 && uVar2 != uVar7)) break;
                puVar10 = puVar10 + 1;
                puVar11 = puVar10;
            } while (puVar10 < (uint64_t)arg2);
        }
joined_r0x0001800d34e8:
        puVar1 = puVar12;
        if (puVar10 < (uint64_t)arg2) {
            if (*(uint32_t *)puVar10 <= *(uint32_t *)puVar9) {
                if (*(uint32_t *)puVar10 < *(uint32_t *)puVar9) goto joined_r0x0001800d3519;
                if (puVar11 != puVar10) {
                    uVar3 = *puVar11;
                    *puVar11 = *puVar10;
                    *puVar10 = uVar3;
                }
                puVar11 = puVar11 + 1;
            }
            puVar10 = puVar10 + 1;
            goto joined_r0x0001800d34e8;
        }
joined_r0x0001800d3519:
        while (puVar12 = puVar1, (uint64_t)arg1 < puVar12) {
            puVar1 = puVar12 + -1;
            if (*(uint32_t *)puVar9 <= *(uint32_t *)puVar1) {
                if (*(uint32_t *)puVar9 < *(uint32_t *)puVar1) break;
                puVar9 = puVar9 + -1;
                if (puVar9 != puVar1) {
                    uVar3 = *puVar9;
                    *puVar9 = *puVar1;
                    *puVar1 = uVar3;
                }
            }
        }
        if (puVar12 != (undefined8 *)arg1) {
            puVar12 = puVar12 + -1;
            if (puVar10 == (undefined8 *)arg2) {
                puVar9 = puVar9 + -1;
                if (puVar12 != puVar9) {
                    uVar3 = *puVar12;
                    *puVar12 = *puVar9;
                    *puVar9 = uVar3;
                }
                uVar3 = *puVar9;
                *puVar9 = puVar11[-1];
                puVar11[-1] = uVar3;
                puVar11 = puVar11 + -1;
            } else {
                uVar3 = *puVar10;
                *puVar10 = *puVar12;
                puVar10 = puVar10 + 1;
                *puVar12 = uVar3;
            }
            goto joined_r0x0001800d34e8;
        }
        if (puVar10 != (undefined8 *)arg2) {
            if (puVar11 != puVar10) {
                uVar3 = *puVar9;
                *puVar9 = *puVar11;
                *puVar11 = uVar3;
            }
            uVar3 = *puVar9;
            *puVar9 = *puVar10;
            *puVar10 = uVar3;
            puVar10 = puVar10 + 1;
            puVar11 = puVar11 + 1;
            puVar9 = puVar9 + 1;
            goto joined_r0x0001800d34e8;
        }
        arg3 = (arg3 >> 1) + (arg3 >> 2);
        if ((int64_t)((int64_t)puVar9 - arg1 & 0xfffffffffffffff8U) <
            (int64_t)(arg2 - (int64_t)puVar11 & 0xfffffffffffffff8U)) {
            fcn.1800d3300(arg1, (int64_t)puVar9, arg3);
            puVar9 = (undefined8 *)arg2;
            arg1 = (int64_t)puVar11;
        } else {
            fcn.1800d3300((int64_t)puVar11, arg2, arg3);
        }
        uVar4 = (int64_t)puVar9 - arg1;
        arg2 = (int64_t)puVar9;
    } while( true );
}

