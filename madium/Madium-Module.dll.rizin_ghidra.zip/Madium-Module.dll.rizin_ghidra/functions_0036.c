// Chunk 36 - 50 functions

// ============================================================
// Function: FUN_18007f9f0
// Address: 0x18007f9f0
// Size: 499 bytes
// ============================================================
int64_t * fcn.18007f9f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    uint64_t uVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int64_t iVar8;
    int64_t *piVar9;
    uint64_t uVar10;
    int64_t unaff_RBX;
    int64_t *piVar11;
    int64_t *piVar12;
    undefined *puVar13;
    int64_t iVar14;
    int64_t *unaff_RDI;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_20h;
    undefined8 auStack_70 [6];
    
    iVar15 = arg3 + -1 >> 1;
    iVar8 = arg2;
    iVar14 = arg2;
    piVar9 = unaff_RDI;
    if (arg2 < iVar15) {
        do {
            iVar1 = iVar14 * 2 + 2;
            iVar8 = iVar1 * 0x20;
            auStack_70[0] = 0x18007fa4f;
            cVar7 = func_0x00018002e900(iVar8 + arg1, arg1 + -0x20 + iVar8);
            iVar8 = iVar14 * 2 + 1;
            if (-1 < cVar7) {
                iVar8 = iVar1;
            }
            piVar11 = (int64_t *)(iVar14 * 0x20 + arg1);
            unaff_RDI = (int64_t *)(iVar8 * 0x20 + arg1);
            if (piVar11 != unaff_RDI) {
                uVar2 = piVar11[3];
                if (0xf < uVar2) {
                    iVar14 = *piVar11;
                    uVar10 = uVar2 + 1;
                    if (0xfff < uVar10) {
                        if (0x1f < (iVar14 - *(int64_t *)(iVar14 + -8)) - 8U) goto code_r0x00018007fbdc;
                        uVar10 = uVar2 + 0x28;
                        iVar14 = *(int64_t *)(iVar14 + -8);
                    }
                    auStack_70[0] = 0x18007faab;
                    func_0x000180459c3c(iVar14, uVar10);
                }
                piVar11[3] = 0xf;
                piVar11[2] = 0;
                *(undefined *)piVar11 = 0;
                uVar4 = *(undefined4 *)((int64_t)unaff_RDI + 4);
                uVar5 = *(undefined4 *)(unaff_RDI + 1);
                uVar6 = *(undefined4 *)((int64_t)unaff_RDI + 0xc);
                *(undefined4 *)piVar11 = *(undefined4 *)unaff_RDI;
                *(undefined4 *)((int64_t)piVar11 + 4) = uVar4;
                *(undefined4 *)(piVar11 + 1) = uVar5;
                *(undefined4 *)((int64_t)piVar11 + 0xc) = uVar6;
                uVar4 = *(undefined4 *)((int64_t)unaff_RDI + 0x14);
                uVar5 = *(undefined4 *)(unaff_RDI + 3);
                uVar6 = *(undefined4 *)((int64_t)unaff_RDI + 0x1c);
                *(undefined4 *)(piVar11 + 2) = *(undefined4 *)(unaff_RDI + 2);
                *(undefined4 *)((int64_t)piVar11 + 0x14) = uVar4;
                *(undefined4 *)(piVar11 + 3) = uVar5;
                *(undefined4 *)((int64_t)piVar11 + 0x1c) = uVar6;
                unaff_RDI[2] = 0;
                unaff_RDI[3] = 0xf;
                *(undefined *)unaff_RDI = 0;
            }
            iVar14 = iVar8;
        } while (iVar8 < iVar15);
    }
    if ((iVar8 == iVar15) && ((arg3 & 1U) == 0)) {
        unaff_RBX = iVar8 * 0x20;
        arg4 = arg1 + -0x20 + arg3 * 0x20;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_70;
        auStack_70[0] = 0x18007fb06;
        iVar8 = unaff_RBX;
    } else {
        while (unaff_RDI = piVar9, arg2 < iVar8) {
            iVar14 = iVar8 + -1 >> 1;
            piVar11 = (int64_t *)(iVar14 * 0x20 + arg1);
            auStack_70[0] = 0x18007fb3c;
            cVar7 = func_0x00018002e900(piVar11, arg4);
            if (-1 < cVar7) break;
            piVar12 = (int64_t *)(iVar8 * 0x20 + arg1);
            iVar8 = iVar14;
            piVar9 = unaff_RDI;
            if (piVar12 != piVar11) {
                uVar2 = piVar12[3];
                if (0xf < uVar2) {
                    iVar14 = *piVar12;
                    uVar10 = uVar2 + 1;
                    if (0xfff < uVar10) {
                        if (0x1f < (iVar14 - *(int64_t *)(iVar14 + -8)) - 8U) {
code_r0x00018007fbdc:
                            pcVar3 = (code *)swi(0x29);
                            (*pcVar3)(5);
                            pcVar3 = (code *)swi(3);
                            piVar9 = (int64_t *)(*pcVar3)();
                            return piVar9;
                        }
                        uVar10 = uVar2 + 0x28;
                        iVar14 = *(int64_t *)(iVar14 + -8);
                    }
                    auStack_70[0] = 0x18007fb84;
                    func_0x000180459c3c(iVar14, uVar10);
                }
                piVar12[3] = 0xf;
                piVar12[2] = 0;
                *(undefined *)piVar12 = 0;
                uVar4 = *(undefined4 *)((int64_t)piVar11 + 4);
                uVar5 = *(undefined4 *)(piVar11 + 1);
                uVar6 = *(undefined4 *)((int64_t)piVar11 + 0xc);
                *(undefined4 *)piVar12 = *(undefined4 *)piVar11;
                *(undefined4 *)((int64_t)piVar12 + 4) = uVar4;
                *(undefined4 *)(piVar12 + 1) = uVar5;
                *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar6;
                uVar4 = *(undefined4 *)((int64_t)piVar11 + 0x14);
                uVar5 = *(undefined4 *)(piVar11 + 3);
                uVar6 = *(undefined4 *)((int64_t)piVar11 + 0x1c);
                *(undefined4 *)(piVar12 + 2) = *(undefined4 *)(piVar11 + 2);
                *(undefined4 *)((int64_t)piVar12 + 0x14) = uVar4;
                *(undefined4 *)(piVar12 + 3) = uVar5;
                *(undefined4 *)((int64_t)piVar12 + 0x1c) = uVar6;
                piVar11[2] = 0;
                piVar11[3] = 0xf;
                *(undefined *)piVar11 = 0;
                piVar9 = unaff_RDI;
            }
        }
        iVar8 = iVar8 * 0x20;
    }
    piVar9 = (int64_t *)(iVar8 + arg1);
    *(int64_t *)((int64_t)*(undefined **)0x20 + 8) = unaff_RBX;
    *(int64_t **)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
    if (piVar9 != (int64_t *)arg4) {
        if (0xf < (uint64_t)piVar9[3]) {
            iVar8 = *piVar9;
            iVar14 = iVar8;
            puVar13 = (undefined *)((int64_t)*(undefined **)0x20 + -0x28);
            if ((0xfff < piVar9[3] + 1U) &&
               (iVar14 = *(int64_t *)(iVar8 + -8), puVar13 = (undefined *)((int64_t)*(undefined **)0x20 + -0x28),
               0x1f < (iVar8 - iVar14) - 8U)) {
                pcVar3 = (code *)swi(0x29);
                iVar14 = (*pcVar3)(5);
                puVar13 = (undefined *)((int64_t)*(undefined **)0x20 + -0x20);
            }
            *(undefined8 *)(puVar13 + -8) = 0x180012c64;
            func_0x000180459c3c(iVar14);
        }
        piVar9[3] = 0xf;
        piVar9[2] = 0;
        *(undefined *)piVar9 = 0;
        uVar4 = *(undefined4 *)(arg4 + 4);
        uVar5 = *(undefined4 *)(arg4 + 8);
        uVar6 = *(undefined4 *)(arg4 + 0xc);
        *(undefined4 *)piVar9 = *(undefined4 *)arg4;
        *(undefined4 *)((int64_t)piVar9 + 4) = uVar4;
        *(undefined4 *)(piVar9 + 1) = uVar5;
        *(undefined4 *)((int64_t)piVar9 + 0xc) = uVar6;
        uVar4 = *(undefined4 *)(arg4 + 0x14);
        uVar5 = *(undefined4 *)(arg4 + 0x18);
        uVar6 = *(undefined4 *)(arg4 + 0x1c);
        *(undefined4 *)(piVar9 + 2) = *(undefined4 *)(arg4 + 0x10);
        *(undefined4 *)((int64_t)piVar9 + 0x14) = uVar4;
        *(undefined4 *)(piVar9 + 3) = uVar5;
        *(undefined4 *)((int64_t)piVar9 + 0x1c) = uVar6;
        *(int64_t *)(arg4 + 0x10) = 0;
        *(int64_t *)(arg4 + 0x18) = 0xf;
        *(undefined *)arg4 = 0;
    }
    return piVar9;
}

// ============================================================
// Function: FUN_18007fcb0
// Address: 0x18007fcb0
// Size: 169 bytes
// ============================================================
void fcn.18007fcb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    char cVar12;
    
    cVar12 = func_0x00018002e900(arg2, arg1);
    if ((cVar12 < '\0') && (arg2 != arg1)) {
        uVar1 = *(undefined4 *)(arg1 + 4);
        uVar2 = *(undefined4 *)(arg1 + 8);
        uVar3 = *(undefined4 *)(arg1 + 0xc);
        uVar4 = *(undefined4 *)arg2;
        uVar5 = *(undefined4 *)(arg2 + 4);
        uVar6 = *(undefined4 *)(arg2 + 8);
        uVar7 = *(undefined4 *)(arg2 + 0xc);
        uVar8 = *(undefined4 *)(arg2 + 0x10);
        uVar9 = *(undefined4 *)(arg2 + 0x14);
        uVar10 = *(undefined4 *)(arg2 + 0x18);
        uVar11 = *(undefined4 *)(arg2 + 0x1c);
        *(undefined4 *)arg2 = *(undefined4 *)arg1;
        *(undefined4 *)(arg2 + 4) = uVar1;
        *(undefined4 *)(arg2 + 8) = uVar2;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        uVar1 = *(undefined4 *)(arg1 + 0x14);
        uVar2 = *(undefined4 *)(arg1 + 0x18);
        uVar3 = *(undefined4 *)(arg1 + 0x1c);
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(arg1 + 0x10);
        *(undefined4 *)(arg2 + 0x14) = uVar1;
        *(undefined4 *)(arg2 + 0x18) = uVar2;
        *(undefined4 *)(arg2 + 0x1c) = uVar3;
        *(undefined4 *)arg1 = uVar4;
        *(undefined4 *)(arg1 + 4) = uVar5;
        *(undefined4 *)(arg1 + 8) = uVar6;
        *(undefined4 *)(arg1 + 0xc) = uVar7;
        *(undefined4 *)(arg1 + 0x10) = uVar8;
        *(undefined4 *)(arg1 + 0x14) = uVar9;
        *(undefined4 *)(arg1 + 0x18) = uVar10;
        *(undefined4 *)(arg1 + 0x1c) = uVar11;
    }
    cVar12 = func_0x00018002e900(arg3, arg2);
    if (cVar12 < '\0') {
        if (arg3 != arg2) {
            uVar1 = *(undefined4 *)(arg2 + 4);
            uVar2 = *(undefined4 *)(arg2 + 8);
            uVar3 = *(undefined4 *)(arg2 + 0xc);
            uVar4 = *(undefined4 *)arg3;
            uVar5 = *(undefined4 *)(arg3 + 4);
            uVar6 = *(undefined4 *)(arg3 + 8);
            uVar7 = *(undefined4 *)(arg3 + 0xc);
            uVar8 = *(undefined4 *)(arg3 + 0x10);
            uVar9 = *(undefined4 *)(arg3 + 0x14);
            uVar10 = *(undefined4 *)(arg3 + 0x18);
            uVar11 = *(undefined4 *)(arg3 + 0x1c);
            *(undefined4 *)arg3 = *(undefined4 *)arg2;
            *(undefined4 *)(arg3 + 4) = uVar1;
            *(undefined4 *)(arg3 + 8) = uVar2;
            *(undefined4 *)(arg3 + 0xc) = uVar3;
            uVar1 = *(undefined4 *)(arg2 + 0x14);
            uVar2 = *(undefined4 *)(arg2 + 0x18);
            uVar3 = *(undefined4 *)(arg2 + 0x1c);
            *(undefined4 *)(arg3 + 0x10) = *(undefined4 *)(arg2 + 0x10);
            *(undefined4 *)(arg3 + 0x14) = uVar1;
            *(undefined4 *)(arg3 + 0x18) = uVar2;
            *(undefined4 *)(arg3 + 0x1c) = uVar3;
            *(undefined4 *)arg2 = uVar4;
            *(undefined4 *)(arg2 + 4) = uVar5;
            *(undefined4 *)(arg2 + 8) = uVar6;
            *(undefined4 *)(arg2 + 0xc) = uVar7;
            *(undefined4 *)(arg2 + 0x10) = uVar8;
            *(undefined4 *)(arg2 + 0x14) = uVar9;
            *(undefined4 *)(arg2 + 0x18) = uVar10;
            *(undefined4 *)(arg2 + 0x1c) = uVar11;
        }
        cVar12 = func_0x00018002e900(arg2, arg1);
        if ((cVar12 < '\0') && (arg2 != arg1)) {
            uVar1 = *(undefined4 *)(arg1 + 4);
            uVar2 = *(undefined4 *)(arg1 + 8);
            uVar3 = *(undefined4 *)(arg1 + 0xc);
            uVar4 = *(undefined4 *)arg2;
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            uVar8 = *(undefined4 *)(arg2 + 0x10);
            uVar9 = *(undefined4 *)(arg2 + 0x14);
            uVar10 = *(undefined4 *)(arg2 + 0x18);
            uVar11 = *(undefined4 *)(arg2 + 0x1c);
            *(undefined4 *)arg2 = *(undefined4 *)arg1;
            *(undefined4 *)(arg2 + 4) = uVar1;
            *(undefined4 *)(arg2 + 8) = uVar2;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            uVar1 = *(undefined4 *)(arg1 + 0x14);
            uVar2 = *(undefined4 *)(arg1 + 0x18);
            uVar3 = *(undefined4 *)(arg1 + 0x1c);
            *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(arg1 + 0x10);
            *(undefined4 *)(arg2 + 0x14) = uVar1;
            *(undefined4 *)(arg2 + 0x18) = uVar2;
            *(undefined4 *)(arg2 + 0x1c) = uVar3;
            *(undefined4 *)arg1 = uVar4;
            *(undefined4 *)(arg1 + 4) = uVar5;
            *(undefined4 *)(arg1 + 8) = uVar6;
            *(undefined4 *)(arg1 + 0xc) = uVar7;
            *(undefined4 *)(arg1 + 0x10) = uVar8;
            *(undefined4 *)(arg1 + 0x14) = uVar9;
            *(undefined4 *)(arg1 + 0x18) = uVar10;
            *(undefined4 *)(arg1 + 0x1c) = uVar11;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18007fd60
// Address: 0x18007fd60
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 * fcn.18007fd60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int32_t *piVar2;
    undefined8 *puVar3;
    code *pcVar4;
    undefined8 *puVar5;
    uint64_t uVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    undefined8 unaff_RDI;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    puVar10 = auStack_48;
    puVar9 = auStack_48;
    iVar13 = *(int64_t *)arg1;
    iVar8 = *(int64_t *)(arg1 + 8) - iVar13 >> 4;
    if (iVar8 == 0xfffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar12 = (undefined8 *)(*pcVar4)();
        return puVar12;
    }
    uVar6 = *(int64_t *)(arg1 + 0x10) - iVar13 >> 4;
    if (uVar6 <= 0xfffffffffffffff - (uVar6 >> 1)) {
        uVar1 = iVar8 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar11 = uVar1;
        if (uVar1 <= uVar6) {
            uVar11 = uVar6;
        }
        if (uVar11 < 0x1000000000000000) {
            puVar12 = (undefined8 *)0x0;
            uVar6 = uVar11 * 0x10;
            if (uVar6 != 0) {
                if (uVar6 < 0x1000) {
                    puVar12 = (undefined8 *)func_0x000180459890();
                    puVar10 = auStack_48;
                } else {
                    if (uVar6 + 0x27 <= uVar6) goto code_r0x00018007ff75;
                    iVar8 = func_0x000180459890(uVar6 + 0x27);
                    if (iVar8 == 0) {
                        pcVar4 = (code *)swi(0x29);
                        iVar8 = (*pcVar4)(5);
                        puVar9 = auStack_40;
                    }
                    puVar12 = (undefined8 *)(iVar8 + 0x27U & 0xffffffffffffffe0);
                    puVar12[-1] = iVar8;
                    puVar10 = puVar9;
                }
            }
            *(undefined8 *)(puVar10 + 0x60) = unaff_RDI;
            iVar13 = arg2 - iVar13 >> 4;
            puVar12[iVar13 * 2] = 0;
            puVar12[iVar13 * 2 + 1] = 0;
            if (*(int64_t *)(arg3 + 8) != 0) {
                LOCK();
                piVar2 = (int32_t *)(*(int64_t *)(arg3 + 8) + 8);
                *piVar2 = *piVar2 + 1;
                UNLOCK();
            }
            puVar12[iVar13 * 2] = *(undefined8 *)arg3;
            puVar12[iVar13 * 2 + 1] = *(undefined8 *)(arg3 + 8);
            puVar3 = *(undefined8 **)(arg1 + 8);
            puVar7 = *(undefined8 **)arg1;
            puVar5 = puVar12;
            if ((undefined8 *)arg2 == puVar3) {
                for (; puVar7 != puVar3; puVar7 = puVar7 + 2) {
                    *puVar5 = 0;
                    puVar5[1] = 0;
                    *puVar5 = *puVar7;
                    puVar5[1] = puVar7[1];
                    *puVar7 = 0;
                    puVar7[1] = 0;
                    puVar5 = puVar5 + 2;
                }
            } else {
                for (; puVar7 != (undefined8 *)arg2; puVar7 = puVar7 + 2) {
                    *puVar5 = 0;
                    puVar5[1] = 0;
                    *puVar5 = *puVar7;
                    puVar5[1] = puVar7[1];
                    *puVar7 = 0;
                    puVar7[1] = 0;
                    puVar5 = puVar5 + 2;
                }
                puVar3 = *(undefined8 **)(arg1 + 8);
                puVar7 = puVar12 + iVar13 * 2 + 2;
                if ((undefined8 *)arg2 != puVar3) {
                    do {
                        *puVar7 = 0;
                        puVar7[1] = 0;
                        *puVar7 = *(undefined8 *)arg2;
                        puVar7[1] = *(undefined8 *)(arg2 + 8);
                        *(undefined8 *)arg2 = 0;
                        *(undefined8 *)(arg2 + 8) = 0;
                        arg2 = arg2 + 0x10;
                        puVar7 = puVar7 + 2;
                    } while ((undefined8 *)arg2 != puVar3);
                }
            }
            *(undefined8 *)(puVar10 + -8) = 0x18007ff4b;
            func_0x00018007ea20(arg1, puVar12, uVar1, uVar11);
            return puVar12 + iVar13 * 2;
        }
    }
code_r0x00018007ff75:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar12 = (undefined8 *)(*pcVar4)();
    return puVar12;
}

// ============================================================
// Function: FUN_18007fda0
// Address: 0x18007fda0
// Size: 463 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 * fcn.18007fd60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int32_t *piVar2;
    undefined8 *puVar3;
    code *pcVar4;
    undefined8 *puVar5;
    uint64_t uVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    undefined8 unaff_RDI;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    puVar10 = auStack_48;
    puVar9 = auStack_48;
    iVar13 = *(int64_t *)arg1;
    iVar8 = *(int64_t *)(arg1 + 8) - iVar13 >> 4;
    if (iVar8 == 0xfffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar12 = (undefined8 *)(*pcVar4)();
        return puVar12;
    }
    uVar6 = *(int64_t *)(arg1 + 0x10) - iVar13 >> 4;
    if (uVar6 <= 0xfffffffffffffff - (uVar6 >> 1)) {
        uVar1 = iVar8 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar11 = uVar1;
        if (uVar1 <= uVar6) {
            uVar11 = uVar6;
        }
        if (uVar11 < 0x1000000000000000) {
            puVar12 = (undefined8 *)0x0;
            uVar6 = uVar11 * 0x10;
            if (uVar6 != 0) {
                if (uVar6 < 0x1000) {
                    puVar12 = (undefined8 *)func_0x000180459890();
                    puVar10 = auStack_48;
                } else {
                    if (uVar6 + 0x27 <= uVar6) goto code_r0x00018007ff75;
                    iVar8 = func_0x000180459890(uVar6 + 0x27);
                    if (iVar8 == 0) {
                        pcVar4 = (code *)swi(0x29);
                        iVar8 = (*pcVar4)(5);
                        puVar9 = auStack_40;
                    }
                    puVar12 = (undefined8 *)(iVar8 + 0x27U & 0xffffffffffffffe0);
                    puVar12[-1] = iVar8;
                    puVar10 = puVar9;
                }
            }
            *(undefined8 *)(puVar10 + 0x60) = unaff_RDI;
            iVar13 = arg2 - iVar13 >> 4;
            puVar12[iVar13 * 2] = 0;
            puVar12[iVar13 * 2 + 1] = 0;
            if (*(int64_t *)(arg3 + 8) != 0) {
                LOCK();
                piVar2 = (int32_t *)(*(int64_t *)(arg3 + 8) + 8);
                *piVar2 = *piVar2 + 1;
                UNLOCK();
            }
            puVar12[iVar13 * 2] = *(undefined8 *)arg3;
            puVar12[iVar13 * 2 + 1] = *(undefined8 *)(arg3 + 8);
            puVar3 = *(undefined8 **)(arg1 + 8);
            puVar7 = *(undefined8 **)arg1;
            puVar5 = puVar12;
            if ((undefined8 *)arg2 == puVar3) {
                for (; puVar7 != puVar3; puVar7 = puVar7 + 2) {
                    *puVar5 = 0;
                    puVar5[1] = 0;
                    *puVar5 = *puVar7;
                    puVar5[1] = puVar7[1];
                    *puVar7 = 0;
                    puVar7[1] = 0;
                    puVar5 = puVar5 + 2;
                }
            } else {
                for (; puVar7 != (undefined8 *)arg2; puVar7 = puVar7 + 2) {
                    *puVar5 = 0;
                    puVar5[1] = 0;
                    *puVar5 = *puVar7;
                    puVar5[1] = puVar7[1];
                    *puVar7 = 0;
                    puVar7[1] = 0;
                    puVar5 = puVar5 + 2;
                }
                puVar3 = *(undefined8 **)(arg1 + 8);
                puVar7 = puVar12 + iVar13 * 2 + 2;
                if ((undefined8 *)arg2 != puVar3) {
                    do {
                        *puVar7 = 0;
                        puVar7[1] = 0;
                        *puVar7 = *(undefined8 *)arg2;
                        puVar7[1] = *(undefined8 *)(arg2 + 8);
                        *(undefined8 *)arg2 = 0;
                        *(undefined8 *)(arg2 + 8) = 0;
                        arg2 = arg2 + 0x10;
                        puVar7 = puVar7 + 2;
                    } while ((undefined8 *)arg2 != puVar3);
                }
            }
            *(undefined8 *)(puVar10 + -8) = 0x18007ff4b;
            func_0x00018007ea20(arg1, puVar12, uVar1, uVar11);
            return puVar12 + iVar13 * 2;
        }
    }
code_r0x00018007ff75:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar12 = (undefined8 *)(*pcVar4)();
    return puVar12;
}

// ============================================================
// Function: FUN_18007ff6f
// Address: 0x18007ff6f
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 * fcn.18007fd60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int32_t *piVar2;
    undefined8 *puVar3;
    code *pcVar4;
    undefined8 *puVar5;
    uint64_t uVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    undefined8 unaff_RDI;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    puVar10 = auStack_48;
    puVar9 = auStack_48;
    iVar13 = *(int64_t *)arg1;
    iVar8 = *(int64_t *)(arg1 + 8) - iVar13 >> 4;
    if (iVar8 == 0xfffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar12 = (undefined8 *)(*pcVar4)();
        return puVar12;
    }
    uVar6 = *(int64_t *)(arg1 + 0x10) - iVar13 >> 4;
    if (uVar6 <= 0xfffffffffffffff - (uVar6 >> 1)) {
        uVar1 = iVar8 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar11 = uVar1;
        if (uVar1 <= uVar6) {
            uVar11 = uVar6;
        }
        if (uVar11 < 0x1000000000000000) {
            puVar12 = (undefined8 *)0x0;
            uVar6 = uVar11 * 0x10;
            if (uVar6 != 0) {
                if (uVar6 < 0x1000) {
                    puVar12 = (undefined8 *)func_0x000180459890();
                    puVar10 = auStack_48;
                } else {
                    if (uVar6 + 0x27 <= uVar6) goto code_r0x00018007ff75;
                    iVar8 = func_0x000180459890(uVar6 + 0x27);
                    if (iVar8 == 0) {
                        pcVar4 = (code *)swi(0x29);
                        iVar8 = (*pcVar4)(5);
                        puVar9 = auStack_40;
                    }
                    puVar12 = (undefined8 *)(iVar8 + 0x27U & 0xffffffffffffffe0);
                    puVar12[-1] = iVar8;
                    puVar10 = puVar9;
                }
            }
            *(undefined8 *)(puVar10 + 0x60) = unaff_RDI;
            iVar13 = arg2 - iVar13 >> 4;
            puVar12[iVar13 * 2] = 0;
            puVar12[iVar13 * 2 + 1] = 0;
            if (*(int64_t *)(arg3 + 8) != 0) {
                LOCK();
                piVar2 = (int32_t *)(*(int64_t *)(arg3 + 8) + 8);
                *piVar2 = *piVar2 + 1;
                UNLOCK();
            }
            puVar12[iVar13 * 2] = *(undefined8 *)arg3;
            puVar12[iVar13 * 2 + 1] = *(undefined8 *)(arg3 + 8);
            puVar3 = *(undefined8 **)(arg1 + 8);
            puVar7 = *(undefined8 **)arg1;
            puVar5 = puVar12;
            if ((undefined8 *)arg2 == puVar3) {
                for (; puVar7 != puVar3; puVar7 = puVar7 + 2) {
                    *puVar5 = 0;
                    puVar5[1] = 0;
                    *puVar5 = *puVar7;
                    puVar5[1] = puVar7[1];
                    *puVar7 = 0;
                    puVar7[1] = 0;
                    puVar5 = puVar5 + 2;
                }
            } else {
                for (; puVar7 != (undefined8 *)arg2; puVar7 = puVar7 + 2) {
                    *puVar5 = 0;
                    puVar5[1] = 0;
                    *puVar5 = *puVar7;
                    puVar5[1] = puVar7[1];
                    *puVar7 = 0;
                    puVar7[1] = 0;
                    puVar5 = puVar5 + 2;
                }
                puVar3 = *(undefined8 **)(arg1 + 8);
                puVar7 = puVar12 + iVar13 * 2 + 2;
                if ((undefined8 *)arg2 != puVar3) {
                    do {
                        *puVar7 = 0;
                        puVar7[1] = 0;
                        *puVar7 = *(undefined8 *)arg2;
                        puVar7[1] = *(undefined8 *)(arg2 + 8);
                        *(undefined8 *)arg2 = 0;
                        *(undefined8 *)(arg2 + 8) = 0;
                        arg2 = arg2 + 0x10;
                        puVar7 = puVar7 + 2;
                    } while ((undefined8 *)arg2 != puVar3);
                }
            }
            *(undefined8 *)(puVar10 + -8) = 0x18007ff4b;
            func_0x00018007ea20(arg1, puVar12, uVar1, uVar11);
            return puVar12 + iVar13 * 2;
        }
    }
code_r0x00018007ff75:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar12 = (undefined8 *)(*pcVar4)();
    return puVar12;
}

// ============================================================
// Function: FUN_18007ff75
// Address: 0x18007ff75
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 * fcn.18007fd60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int32_t *piVar2;
    undefined8 *puVar3;
    code *pcVar4;
    undefined8 *puVar5;
    uint64_t uVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    undefined8 unaff_RDI;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    puVar10 = auStack_48;
    puVar9 = auStack_48;
    iVar13 = *(int64_t *)arg1;
    iVar8 = *(int64_t *)(arg1 + 8) - iVar13 >> 4;
    if (iVar8 == 0xfffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar12 = (undefined8 *)(*pcVar4)();
        return puVar12;
    }
    uVar6 = *(int64_t *)(arg1 + 0x10) - iVar13 >> 4;
    if (uVar6 <= 0xfffffffffffffff - (uVar6 >> 1)) {
        uVar1 = iVar8 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar11 = uVar1;
        if (uVar1 <= uVar6) {
            uVar11 = uVar6;
        }
        if (uVar11 < 0x1000000000000000) {
            puVar12 = (undefined8 *)0x0;
            uVar6 = uVar11 * 0x10;
            if (uVar6 != 0) {
                if (uVar6 < 0x1000) {
                    puVar12 = (undefined8 *)func_0x000180459890();
                    puVar10 = auStack_48;
                } else {
                    if (uVar6 + 0x27 <= uVar6) goto code_r0x00018007ff75;
                    iVar8 = func_0x000180459890(uVar6 + 0x27);
                    if (iVar8 == 0) {
                        pcVar4 = (code *)swi(0x29);
                        iVar8 = (*pcVar4)(5);
                        puVar9 = auStack_40;
                    }
                    puVar12 = (undefined8 *)(iVar8 + 0x27U & 0xffffffffffffffe0);
                    puVar12[-1] = iVar8;
                    puVar10 = puVar9;
                }
            }
            *(undefined8 *)(puVar10 + 0x60) = unaff_RDI;
            iVar13 = arg2 - iVar13 >> 4;
            puVar12[iVar13 * 2] = 0;
            puVar12[iVar13 * 2 + 1] = 0;
            if (*(int64_t *)(arg3 + 8) != 0) {
                LOCK();
                piVar2 = (int32_t *)(*(int64_t *)(arg3 + 8) + 8);
                *piVar2 = *piVar2 + 1;
                UNLOCK();
            }
            puVar12[iVar13 * 2] = *(undefined8 *)arg3;
            puVar12[iVar13 * 2 + 1] = *(undefined8 *)(arg3 + 8);
            puVar3 = *(undefined8 **)(arg1 + 8);
            puVar7 = *(undefined8 **)arg1;
            puVar5 = puVar12;
            if ((undefined8 *)arg2 == puVar3) {
                for (; puVar7 != puVar3; puVar7 = puVar7 + 2) {
                    *puVar5 = 0;
                    puVar5[1] = 0;
                    *puVar5 = *puVar7;
                    puVar5[1] = puVar7[1];
                    *puVar7 = 0;
                    puVar7[1] = 0;
                    puVar5 = puVar5 + 2;
                }
            } else {
                for (; puVar7 != (undefined8 *)arg2; puVar7 = puVar7 + 2) {
                    *puVar5 = 0;
                    puVar5[1] = 0;
                    *puVar5 = *puVar7;
                    puVar5[1] = puVar7[1];
                    *puVar7 = 0;
                    puVar7[1] = 0;
                    puVar5 = puVar5 + 2;
                }
                puVar3 = *(undefined8 **)(arg1 + 8);
                puVar7 = puVar12 + iVar13 * 2 + 2;
                if ((undefined8 *)arg2 != puVar3) {
                    do {
                        *puVar7 = 0;
                        puVar7[1] = 0;
                        *puVar7 = *(undefined8 *)arg2;
                        puVar7[1] = *(undefined8 *)(arg2 + 8);
                        *(undefined8 *)arg2 = 0;
                        *(undefined8 *)(arg2 + 8) = 0;
                        arg2 = arg2 + 0x10;
                        puVar7 = puVar7 + 2;
                    } while ((undefined8 *)arg2 != puVar3);
                }
            }
            *(undefined8 *)(puVar10 + -8) = 0x18007ff4b;
            func_0x00018007ea20(arg1, puVar12, uVar1, uVar11);
            return puVar12 + iVar13 * 2;
        }
    }
code_r0x00018007ff75:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar12 = (undefined8 *)(*pcVar4)();
    return puVar12;
}

// ============================================================
// Function: FUN_18007ff90
// Address: 0x18007ff90
// Size: 125 bytes
// ============================================================
undefined8 fcn.18007ff90(void)
{
    int64_t unaff_GS_OFFSET;
    
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x1807829e0) {
        fcn.180459d18(0x1807829e0);
        if (*(int32_t *)0x1807829e0 == -1) {
            *(undefined8 *)0x1807829d8 = fcn.180459890(1);
            fcn.180459c24(0x1804a2980);
            fcn.180459cac(0x1807829e0);
            return 0x1807829d8;
        }
    }
    return 0x1807829d8;
}

// ============================================================
// Function: FUN_180080010
// Address: 0x180080010
// Size: 200 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h

int64_t fcn.180080010(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined uVar4;
    undefined *puVar5;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_38h;
    
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    uVar1 = *(uint64_t *)(arg3 + 0x10);
    if (uVar1 == 0) {
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined *)arg2 = 0;
    } else if (uVar1 < 0x10) {
        *(uint64_t *)(arg2 + 0x10) = uVar1;
        func_0x0001804986e0(arg2, 0, uVar1);
        *(undefined *)(uVar1 + arg2) = 0;
    } else {
        func_0x00018000f2f0(arg2, uVar1, arg2 & 0xff, uVar1, 0);
    }
    puVar5 = (undefined *)arg2;
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        puVar5 = *(undefined **)arg2;
    }
    iVar2 = *(int64_t *)(arg3 + 0x10);
    iVar3 = arg3;
    if (0xf < *(uint64_t *)(arg3 + 0x18)) {
        iVar3 = *(int64_t *)arg3;
        arg3 = *(int64_t *)arg3;
    }
    for (; (undefined *)arg3 != (undefined *)(iVar2 + iVar3); arg3 = arg3 + 1) {
        uVar4 = func_0x000180460320(*(undefined *)arg3);
        *puVar5 = uVar4;
        puVar5 = puVar5 + 1;
    }
    return arg2;
}

// ============================================================
// Function: FUN_1800800e0
// Address: 0x1800800e0
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800800e0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint64_t uVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar1 = (uint64_t)(int32_t)arg4;
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0;
    if (*(uint64_t *)(arg3 + 8) < uVar1) {
        uVar1 = *(uint64_t *)(arg3 + 8);
    }
    fcn.180004830(arg2, *(undefined8 *)arg3, uVar1, (int32_t)arg4, 0);
    fcn.18000b3b0(arg2);
    return arg2;
}

// ============================================================
// Function: FUN_180080150
// Address: 0x180080150
// Size: 1192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h

void fcn.180080150(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    code *pcVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined *puVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined (*pauVar9) [16];
    int64_t iVar10;
    int64_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    undefined *puVar15;
    undefined *puVar16;
    uint64_t uVar17;
    int64_t var_8h;
    undefined8 uStackY_140;
    undefined auStackY_138 [8];
    undefined auStackY_130 [24];
    int64_t var_118h;
    int64_t var_110h;
    int32_t var_104h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined4 uStack_b8;
    undefined4 uStack_b4;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar16 = auStackY_138;
    puVar15 = auStackY_138;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_138;
    uVar14 = 0;
    var_d8h._0_4_ = 0;
    puVar4 = auStackY_138;
    var_100h = arg2;
    var_d0h = arg3;
    if ((arg_30h != 0) && (puVar4 = auStackY_138, *(int64_t *)(arg4 + 8) != 0)) {
        iVar8 = func_0x000180211490();
        var_c8h = iVar8;
        if (iVar8 == 0) {
            *(undefined (*) [16])arg2 = ZEXT816(0);
            *(undefined8 *)(arg2 + 0x10) = 0;
            *(undefined8 *)(arg2 + 0x18) = 0xf;
            *(undefined *)arg2 = 0;
            goto code_r0x0001800805ce;
        }
        uVar5 = func_0x00018020efa0(arg_30h);
        iVar11 = arg_30h;
        uVar6 = func_0x00018020ef90();
        _var_f8h = *(undefined (*) [16])arg4;
        fcn.1800800e0(iVar11, (int64_t)&var_80h, (int64_t)&var_f8h, (uint64_t)uVar5);
        if ((int32_t)uVar6 < 1) {
            var_e8h = 0;
            var_e0h = 0xf;
            stack0xffffffffffffff09 = SUB1615(ZEXT816(0), 1);
            auVar2[15] = 0;
            auVar2._0_15_ = stack0xffffffffffffff09;
            _var_f8h = auVar2 << 8;
            pauVar9 = (undefined (*) [16])&var_f8h;
            uVar14 = 4;
        } else {
            _var_f8h = *(undefined (*) [16])arg_28h;
            pauVar9 = (undefined (*) [16])fcn.1800800e0(iVar11, (int64_t)&var_60h, (int64_t)&var_f8h, (uint64_t)uVar6);
            uVar14 = 2;
        }
        _var_a0h = ZEXT816(0);
        var_90h = 0;
        var_88h = 0;
        _var_a0h = *pauVar9;
        var_90h = *(int64_t *)pauVar9[1];
        var_88h = *(int64_t *)(pauVar9[1] + 8);
        *(undefined8 *)pauVar9[1] = 0;
        *(undefined8 *)(pauVar9[1] + 8) = 0xf;
        (*pauVar9)[0] = 0;
        if (((uVar14 & 4) == 0) || (uVar14 = (uint64_t)((uint32_t)uVar14 & 0xfffffffb), (uint64_t)var_e0h < 0x10)) {
code_r0x0001800802ce:
            if ((uVar14 & 2) != 0) {
                if (0xf < (uint64_t)var_48h) {
                    iVar11 = CONCAT71(var_60h._1_7_, (undefined)var_60h);
                    uVar13 = var_48h + 1;
                    if (0xfff < uVar13) {
                        if (0x1f < (iVar11 - *(int64_t *)(iVar11 + -8)) - 8U) goto code_r0x000180080446;
                        uVar13 = var_48h + 0x28;
                        iVar11 = *(int64_t *)(iVar11 + -8);
                    }
                    func_0x000180459c3c(iVar11, uVar13);
                }
                var_50h = 0;
                var_48h = 0xf;
                var_60h._0_1_ = 0;
            }
            var_118h = (int64_t)(int64_t *)0x0;
            if ((0 < (int32_t)uVar6) && (var_118h = (int64_t)&var_a0h, 0xf < (uint64_t)var_88h)) {
                var_118h = var_a0h;
            }
            piVar12 = &var_80h;
            if (0xf < (uint64_t)var_68h) {
                piVar12 = (int64_t *)CONCAT71(var_80h._1_7_, (undefined)var_80h);
            }
            var_110h._0_4_ = (undefined4)arg_38h;
            iVar7 = func_0x000180211b70(iVar8, arg_30h, 0, piVar12);
            iVar11 = var_d0h;
            if (iVar7 == 1) {
                uVar14 = *(uint64_t *)(var_d0h + 8);
                iVar7 = func_0x00018020ef70(arg_30h);
                func_0x0001800106c0(&var_c0h, (int64_t)iVar7 + uVar14, 0);
                var_104h = 0;
                var_100h = var_100h & 0xffffffff00000000;
                piVar12 = &var_c0h;
                if (0xf < (uint64_t)var_a8h) {
                    piVar12 = (int64_t *)CONCAT44(var_c0h._4_4_, (uint32_t)var_c0h);
                }
                var_118h = CONCAT44(var_118h._4_4_, (int32_t)uVar14);
                iVar7 = func_0x000180211bb0(iVar8, piVar12, &var_104h, *(undefined8 *)iVar11);
                if (iVar7 == 1) {
                    piVar12 = &var_c0h;
                    if (0xf < (uint64_t)var_a8h) {
                        piVar12 = (int64_t *)CONCAT44(var_c0h._4_4_, (uint32_t)var_c0h);
                    }
                    iVar7 = func_0x000180211b40(iVar8, (int64_t)var_104h + (int64_t)piVar12, &var_100h);
                    if (iVar7 != 1) goto code_r0x000180080400;
                    uVar13 = (uint64_t)(var_104h + (int32_t)var_100h);
                    if ((uint64_t)var_b0h < uVar13) {
                        uVar17 = uVar13 - var_b0h;
                        if ((uint64_t)(var_a8h - var_b0h) < uVar17) {
                            var_118h = var_118h & 0xffffffffffffff00;
                            fcn.18000f2f0(var_118h);
                        } else {
                            piVar12 = &var_c0h;
                            if (0xf < (uint64_t)var_a8h) {
                                piVar12 = (int64_t *)CONCAT44(var_c0h._4_4_, (uint32_t)var_c0h);
                            }
                            uVar14 = (int64_t)piVar12 + var_b0h;
                            var_b0h = uVar13;
                            fcn.1804986e0(uVar14, 0, uVar17);
                            *(undefined *)(uVar14 + uVar17) = 0;
                        }
                    } else {
                        piVar12 = &var_c0h;
                        if (0xf < (uint64_t)var_a8h) {
                            piVar12 = (int64_t *)CONCAT44(var_c0h._4_4_, (uint32_t)var_c0h);
                        }
                        var_b0h = uVar13;
                        *(undefined *)((int64_t)piVar12 + uVar13) = 0;
                    }
                    *(uint32_t *)arg2 = (uint32_t)var_c0h;
                    *(undefined4 *)(arg2 + 4) = var_c0h._4_4_;
                    *(undefined4 *)(arg2 + 8) = uStack_b8;
                    *(undefined4 *)(arg2 + 0xc) = uStack_b4;
                    *(undefined4 *)(arg2 + 0x10) = (undefined4)var_b0h;
                    *(undefined4 *)(arg2 + 0x14) = var_b0h._4_4_;
                    *(undefined4 *)(arg2 + 0x18) = (undefined4)var_a8h;
                    *(undefined4 *)(arg2 + 0x1c) = var_a8h._4_4_;
                } else {
code_r0x000180080400:
                    *(undefined (*) [16])arg2 = ZEXT816(0);
                    *(undefined8 *)(arg2 + 0x10) = 0;
                    *(undefined8 *)(arg2 + 0x18) = 0xf;
                    *(undefined *)arg2 = 0;
                    puVar15 = auStackY_138;
                    if (0xf < (uint64_t)var_a8h) {
                        iVar11 = CONCAT44(var_c0h._4_4_, (uint32_t)var_c0h);
                        puVar15 = auStackY_138;
                        if ((0xfff < var_a8h + 1U) &&
                           (iVar10 = iVar11 - *(int64_t *)(iVar11 + -8), iVar11 = *(int64_t *)(iVar11 + -8),
                           puVar15 = auStackY_138, 0x1f < iVar10 - 8U)) goto code_r0x000180080446;
                        goto code_r0x000180080450;
                    }
                }
                goto code_r0x000180080455;
            }
            *(undefined (*) [16])arg2 = ZEXT816(0);
            *(undefined8 *)(arg2 + 0x10) = 0;
            *(undefined8 *)(arg2 + 0x18) = 0xf;
            *(undefined *)arg2 = 0;
            puVar16 = auStackY_138;
        } else {
            uVar13 = var_e0h + 1;
            iVar11 = var_f8h;
            if (uVar13 < 0x1000) {
code_r0x0001800802c9:
                func_0x000180459c3c(iVar11, uVar13);
                goto code_r0x0001800802ce;
            }
            if ((var_f8h - *(int64_t *)(var_f8h + -8)) - 8U < 0x20) {
                uVar13 = var_e0h + 0x28;
                iVar11 = *(int64_t *)(var_f8h + -8);
                goto code_r0x0001800802c9;
            }
code_r0x000180080446:
            pcVar1 = (code *)swi(0x29);
            iVar11 = (*pcVar1)(5);
            puVar15 = auStackY_130;
code_r0x000180080450:
            *(undefined8 *)(puVar15 + -8) = 0x180080455;
            func_0x000180459c3c(iVar11);
code_r0x000180080455:
            var_b0h = 0;
            var_a8h = 0xf;
            var_c0h._0_4_ = (uint32_t)var_c0h & 0xffffff00;
            puVar16 = puVar15;
        }
        if ((uint64_t)var_88h < 0x10) {
code_r0x0001800804a2:
            var_90h = 0;
            var_88h = 0xf;
            auVar3[15] = 0;
            auVar3._0_15_ = stack0xffffffffffffff61;
            _var_a0h = auVar3 << 8;
            if (0xf < (uint64_t)var_68h) {
                iVar11 = CONCAT71(var_80h._1_7_, (undefined)var_80h);
                arg2 = var_68h + 1;
                if ((undefined (*) [16])0xfff < (uint64_t)arg2) {
                    if (0x1f < (iVar11 - *(int64_t *)(iVar11 + -8)) - 8U) goto code_r0x0001800805b3;
                    arg2 = var_68h + 0x28;
                    iVar11 = *(int64_t *)(iVar11 + -8);
                }
                *(undefined8 *)(puVar16 + -8) = 0x1800804ef;
                func_0x000180459c3c(iVar11, arg2);
            }
            var_70h = 0;
            var_68h = 0xf;
            var_80h._0_1_ = 0;
            if (iVar8 != 0) {
                *(undefined8 *)(puVar16 + -8) = 0x180080510;
                func_0x000180211410(iVar8);
            }
            goto code_r0x0001800805ce;
        }
        arg2 = var_88h + 1;
        iVar11 = var_a0h;
        if ((uint64_t)arg2 < (undefined (*) [16])0x1000) {
code_r0x00018008049d:
            *(undefined8 *)(puVar16 + -8) = 0x1800804a2;
            func_0x000180459c3c(iVar11, arg2);
            goto code_r0x0001800804a2;
        }
        if ((var_a0h - *(int64_t *)(var_a0h + -8)) - 8U < 0x20) {
            arg2 = var_88h + 0x28;
            iVar11 = *(int64_t *)(var_a0h + -8);
            goto code_r0x00018008049d;
        }
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar16 = puVar16 + 8;
code_r0x0001800805b3:
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar4 = puVar16 + 8;
    }
    puVar16 = puVar4;
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(uint64_t *)*(undefined (*) [16])(arg2 + 0x10) = uVar14;
    *(undefined8 *)(*(undefined (*) [16])(arg2 + 0x10) + 8) = 0xf;
    *(undefined *)arg2 = (char)uVar14;
code_r0x0001800805ce:
    *(undefined8 *)(puVar16 + -8) = 0x1800805dd;
    func_0x000180459870(var_40h ^ (uint64_t)puVar16);
    return;
}

// ============================================================
// Function: FUN_180080600
// Address: 0x180080600
// Size: 397 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180080713)
// WARNING: Removing unreachable block (ram,0x00018008071c)

int64_t fcn.180080600(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t unaff_RBX;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_ffffffffffffffc8;
    int64_t in_stack_ffffffffffffffd0;
    
    if (*(int64_t *)(arg3 + 8) == 0) {
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
        return arg2;
    }
    fcn.1802199b0();
    iVar2 = fcn.18021a7c0(in_stack_ffffffffffffffc8, in_stack_ffffffffffffffd0, unaff_retaddr);
    fcn.18021ea20();
    iVar3 = fcn.18021a7c0(in_stack_ffffffffffffffc8, in_stack_ffffffffffffffd0, unaff_retaddr);
    if ((iVar2 != 0) && (iVar3 != 0)) {
        fcn.18021b250(iVar3, 0x100);
        fcn.18021a960(iVar3, iVar2);
        iVar1 = fcn.18021b2c0(unaff_RDI);
        if ((0 < iVar1) && (iVar1 = fcn.180219d10(unaff_RDI, unaff_RSI, unaff_RBX), 0 < iVar1)) {
            fcn.180219d10(unaff_RDI, unaff_RSI, unaff_RBX);
        }
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
        fcn.18021a070(in_stack_ffffffffffffffc8, in_stack_ffffffffffffffd0, unaff_RDI, unaff_RSI, unaff_RBX);
        return arg2;
    }
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    if (iVar3 != 0) {
        fcn.18021a070(in_stack_ffffffffffffffc8, in_stack_ffffffffffffffd0, unaff_RDI, unaff_RSI, unaff_RBX);
    }
    if (iVar2 != 0) {
        fcn.18021a070(in_stack_ffffffffffffffc8, in_stack_ffffffffffffffd0, unaff_RDI, unaff_RSI, unaff_RBX);
    }
    return arg2;
}

// ============================================================
// Function: FUN_180080790
// Address: 0x180080790
// Size: 463 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180080790(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint64_t arg_60h;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    undefined *puVar8;
    undefined *puVar9;
    int64_t var_8h;
    int64_t var_20h;
    undefined auStackY_78 [8];
    undefined auStackY_70 [24];
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_40h;
    undefined4 in_stack_ffffffffffffffc8;
    undefined4 in_stack_ffffffffffffffcc;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    
    puVar9 = auStackY_78;
    puVar8 = auStackY_78;
    arg_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_78;
    var_58h = arg2;
    uVar1 = *(uint64_t *)(arg3 + 8);
    if (uVar1 == 0) {
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
    } else {
        iVar5 = func_0x0001802198e0(*(undefined8 *)arg3, uVar1 & 0xffffffff);
        var_58h = iVar5;
        fcn.18021ea20();
        iVar6 = fcn.18021a7c0(var_58h, in_stack_ffffffffffffffb0, arg_60h);
        if ((iVar5 == 0) || (iVar6 == 0)) {
            *(undefined (*) [16])arg2 = ZEXT816(0);
            *(undefined8 *)(arg2 + 0x10) = 0;
            *(undefined8 *)(arg2 + 0x18) = 0xf;
            *(undefined *)arg2 = 0;
            puVar9 = auStackY_78;
            if (iVar6 != 0) {
                fcn.18021a070(var_58h, in_stack_ffffffffffffffb0, 
                              CONCAT44(in_stack_ffffffffffffffcc, in_stack_ffffffffffffffc8), 
                              CONCAT44(var_30h._4_4_, (undefined4)var_30h), CONCAT44(var_28h._4_4_, (undefined4)var_28h)
                             );
            }
        } else {
            fcn.18021b250(iVar6, 0x100);
            iVar5 = fcn.18021a960(iVar6, iVar5);
            var_58h = iVar5;
            func_0x0001800106c0(&var_40h, (uVar1 * 3 >> 2) + 1, 0);
            piVar7 = &var_40h;
            if (0xf < CONCAT44(var_28h._4_4_, (undefined4)var_28h)) {
                piVar7 = (int64_t *)CONCAT44(var_40h._4_4_, (undefined4)var_40h);
            }
            iVar4 = func_0x00018021ac80(iVar5, piVar7, (undefined4)var_30h);
            if (iVar4 < 0) {
                *(undefined (*) [16])arg2 = ZEXT816(0);
                *(undefined8 *)(arg2 + 0x10) = 0;
                *(undefined8 *)(arg2 + 0x18) = 0xf;
                *(undefined *)arg2 = 0;
                puVar8 = auStackY_78;
                if (0xf < CONCAT44(var_28h._4_4_, (undefined4)var_28h)) {
                    iVar3 = CONCAT44(var_40h._4_4_, (undefined4)var_40h);
                    iVar6 = iVar3;
                    puVar8 = auStackY_78;
                    if ((0xfff < CONCAT44(var_28h._4_4_, (undefined4)var_28h) + 1) &&
                       (iVar6 = *(int64_t *)(iVar3 + -8), puVar8 = auStackY_78, 0x1f < (iVar3 - iVar6) - 8U)) {
                        pcVar2 = (code *)swi(0x29);
                        iVar6 = (*pcVar2)(5);
                        puVar8 = auStackY_70;
                    }
                    *(undefined8 *)(puVar8 + -8) = 0x1800808ca;
                    func_0x000180459c3c(iVar6);
                }
            } else {
                fcn.18000b3b0(CONCAT44(var_30h._4_4_, (undefined4)var_30h));
                *(undefined4 *)arg2 = (undefined4)var_40h;
                *(undefined4 *)(arg2 + 4) = var_40h._4_4_;
                *(undefined4 *)(arg2 + 8) = in_stack_ffffffffffffffc8;
                *(undefined4 *)(arg2 + 0xc) = in_stack_ffffffffffffffcc;
                *(undefined4 *)(arg2 + 0x10) = (undefined4)var_30h;
                *(undefined4 *)(arg2 + 0x14) = var_30h._4_4_;
                *(undefined4 *)(arg2 + 0x18) = (undefined4)var_28h;
                *(undefined4 *)(arg2 + 0x1c) = var_28h._4_4_;
            }
            *(undefined8 *)(puVar8 + 0x48) = 0;
            *(undefined8 *)(puVar8 + 0x50) = 0xf;
            puVar8[0x38] = 0;
            puVar9 = puVar8;
        }
        if (iVar5 != 0) {
            *(undefined8 *)(puVar9 + -8) = 0x18008093a;
            fcn.18021a070(*(int64_t *)(puVar9 + 0x20), *(int64_t *)(puVar9 + 0x28), *(int64_t *)(puVar9 + 0x40), 
                          *(int64_t *)(puVar9 + 0x48), *(int64_t *)(puVar9 + 0x50));
        }
    }
    *(undefined8 *)(puVar9 + -8) = 0x18008094a;
    func_0x000180459870(*(uint64_t *)(puVar9 + 0x58) ^ (uint64_t)puVar9);
    return;
}

// ============================================================
// Function: FUN_180080960
// Address: 0x180080960
// Size: 234 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180080960(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg_50h)
{
    code *pcVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined *puVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_20h;
    undefined auStack_68 [8];
    undefined auStack_60 [32];
    int64_t var_40h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    int64_t var_18h;
    
    puVar6 = auStack_68;
    puVar7 = auStack_68;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    var_40h = arg2;
    func_0x0001800106c0(&var_38h, arg3, 0);
    piVar5 = &var_38h;
    if (0xf < CONCAT44(uStack_1c, uStack_20)) {
        piVar5 = (int64_t *)CONCAT44(var_38h._4_4_, (undefined4)var_38h);
    }
    iVar3 = func_0x00018021b830(piVar5, arg3 & 0xffffffff);
    if (iVar3 == 1) {
        *(undefined4 *)arg2 = (undefined4)var_38h;
        *(undefined4 *)(arg2 + 4) = var_38h._4_4_;
        *(undefined4 *)(arg2 + 8) = uStack_30;
        *(undefined4 *)(arg2 + 0xc) = uStack_2c;
        *(undefined4 *)(arg2 + 0x10) = (undefined4)var_28h;
        *(undefined4 *)(arg2 + 0x14) = var_28h._4_4_;
        *(undefined4 *)(arg2 + 0x18) = uStack_20;
        *(undefined4 *)(arg2 + 0x1c) = uStack_1c;
    } else {
        uVar2 = CONCAT44(uStack_1c, uStack_20);
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
        puVar7 = auStack_68;
        if (0xf < uVar2) {
            iVar4 = CONCAT44(var_38h._4_4_, (undefined4)var_38h);
            if (0xfff < uVar2 + 1) {
                if ((iVar4 - *(int64_t *)(iVar4 + -8)) - 8U < 0x20) {
                    func_0x000180459c3c(*(int64_t *)(iVar4 + -8), uVar2 + 0x28);
                    puVar7 = auStack_68;
                    goto code_r0x000180080a27;
                }
                pcVar1 = (code *)swi(0x29);
                iVar4 = (*pcVar1)(5);
                puVar6 = auStack_60;
            }
            *(undefined8 *)(puVar6 + -8) = 0x180080a14;
            func_0x000180459c3c(iVar4);
            puVar7 = puVar6;
        }
    }
code_r0x000180080a27:
    *(undefined8 *)(puVar7 + -8) = 0x180080a37;
    func_0x000180459870(*(uint64_t *)(puVar7 + 0x50) ^ (uint64_t)puVar7);
    return;
}

// ============================================================
// Function: FUN_180080a50
// Address: 0x180080a50
// Size: 737 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180080a50(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    undefined *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uStack_18;
    
    puVar5 = auStack_58;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    fcn.180080010(arg1, (int64_t)&var_38h, arg2);
    uVar6 = var_20h;
    uVar7 = var_38h;
    piVar3 = &var_38h;
    if (0xf < (uint64_t)var_20h) {
        piVar3 = (int64_t *)var_38h;
    }
    if ((var_28h != 7) || (iVar2 = func_0x000180497f30(piVar3, 0x18063d2c0, 7), iVar2 != 0)) {
        piVar3 = &var_38h;
        if (0xf < uVar6) {
            piVar3 = (int64_t *)uVar7;
        }
        if ((var_28h != 3) || (iVar2 = func_0x000180497f30(piVar3, 0x18063d2e0, 3), iVar2 != 0)) {
            piVar3 = &var_38h;
            if (0xf < uVar6) {
                piVar3 = (int64_t *)uVar7;
            }
            if ((var_28h != 7) || (iVar2 = func_0x000180497f30(piVar3, 0x18063d2d8, 7), iVar2 != 0)) {
                piVar3 = &var_38h;
                if (0xf < uVar6) {
                    piVar3 = (int64_t *)uVar7;
                }
                if ((var_28h != 3) || (iVar2 = func_0x000180497f30(piVar3, 0x18063d2d0, 3), iVar2 != 0)) {
                    piVar3 = &var_38h;
                    if (0xf < uVar6) {
                        piVar3 = (int64_t *)uVar7;
                    }
                    if ((var_28h != 7) || (iVar2 = func_0x000180497f30(piVar3, 0x18063d2c8, 7), iVar2 != 0)) {
                        piVar3 = &var_38h;
                        if (0xf < uVar6) {
                            piVar3 = (int64_t *)uVar7;
                        }
                        if ((var_28h != 3) || (iVar2 = func_0x000180497f30(piVar3, 0x18063d300, 3), iVar2 != 0)) {
                            piVar3 = &var_38h;
                            if (0xf < uVar6) {
                                piVar3 = (int64_t *)uVar7;
                            }
                            if ((var_28h != 7) || (iVar2 = func_0x000180497f30(piVar3, 0x18063d2f8, 7), iVar2 != 0)) {
                                piVar3 = &var_38h;
                                if (0xf < uVar6) {
                                    piVar3 = (int64_t *)uVar7;
                                }
                                if ((var_28h != 3) || (iVar2 = func_0x000180497f30(piVar3, 0x18063d2f0, 3), iVar2 != 0))
                                {
                                    piVar3 = &var_38h;
                                    if (0xf < uVar6) {
                                        piVar3 = (int64_t *)uVar7;
                                    }
                                    if ((var_28h != 7) ||
                                       (iVar2 = func_0x000180497f30(piVar3, 0x18063d2e8, 7), iVar2 != 0)) {
                                        piVar3 = &var_38h;
                                        if (0xf < uVar6) {
                                            piVar3 = (int64_t *)uVar7;
                                        }
                                        if ((var_28h != 3) ||
                                           (iVar2 = func_0x000180497f30(piVar3, 0x18063d318, 3), iVar2 != 0)) {
                                            piVar3 = &var_38h;
                                            if (0xf < uVar6) {
                                                piVar3 = (int64_t *)uVar7;
                                            }
                                            if ((var_28h != 7) ||
                                               (iVar2 = func_0x000180497f30(piVar3, 0x18063d310, 7), iVar2 != 0)) {
                                                piVar3 = &var_38h;
                                                if (0xf < uVar6) {
                                                    piVar3 = (int64_t *)uVar7;
                                                }
                                                if ((var_28h != 3) ||
                                                   (iVar2 = func_0x000180497f30(piVar3, 0x18063d30c, 3), iVar2 != 0))
                                                goto code_r0x000180080cd8;
                                            }
                                            func_0x000180218cb0();
                                            uVar6 = var_20h;
                                            uVar7 = var_38h;
                                            goto code_r0x000180080cd8;
                                        }
                                    }
                                    func_0x000180218c90();
                                    uVar6 = var_20h;
                                    uVar7 = var_38h;
                                    goto code_r0x000180080cd8;
                                }
                            }
                            func_0x000180218cd0();
                            uVar6 = var_20h;
                            uVar7 = var_38h;
                            goto code_r0x000180080cd8;
                        }
                    }
                    func_0x000180218c70();
                    uVar6 = var_20h;
                    uVar7 = var_38h;
                    goto code_r0x000180080cd8;
                }
            }
            func_0x000180218ca0();
            uVar6 = var_20h;
            uVar7 = var_38h;
            goto code_r0x000180080cd8;
        }
    }
    func_0x000180218c40();
    uVar6 = var_20h;
    uVar7 = var_38h;
code_r0x000180080cd8:
    if (0xf < uVar6) {
        uVar4 = uVar7;
        puVar5 = auStack_58;
        if (0xfff < uVar6 + 1) {
            uVar4 = *(uint64_t *)(uVar7 - 8);
            uVar7 = (uVar7 - uVar4) - 8;
            puVar5 = auStack_58;
            if (0x1f < uVar7) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                uVar4 = uVar7;
                puVar5 = auStack_50;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x180080d11;
        func_0x000180459c3c(uVar4);
    }
    *(undefined8 *)(puVar5 + -8) = 0x180080d21;
    func_0x000180459870(*(uint64_t *)(puVar5 + 0x40) ^ (uint64_t)puVar5);
    return;
}

// ============================================================
// Function: FUN_180080d40
// Address: 0x180080d40
// Size: 750 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180080d40(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined *puVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uStack_18;
    
    puVar6 = auStack_58;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    fcn.180080010(arg1, (int64_t)&var_38h, arg2);
    uVar7 = var_20h;
    uVar5 = var_38h;
    piVar3 = &var_38h;
    if (0xf < (uint64_t)var_20h) {
        piVar3 = (int64_t *)var_38h;
    }
    if ((var_28h == 4) && (iVar2 = func_0x000180497f30(piVar3, 0x18063d304, 4), iVar2 == 0)) {
        func_0x00018020e860();
        uVar5 = var_38h;
        uVar7 = var_20h;
    } else {
        piVar3 = &var_38h;
        if (0xf < uVar7) {
            piVar3 = (int64_t *)uVar5;
        }
        if ((var_28h == 6) && (iVar2 = func_0x000180497f30(piVar3, 0x18063d330, 6), iVar2 == 0)) {
            func_0x00018020e870();
            uVar5 = var_38h;
            uVar7 = var_20h;
        } else {
            piVar3 = &var_38h;
            if (0xf < uVar7) {
                piVar3 = (int64_t *)uVar5;
            }
            if ((var_28h == 6) && (iVar2 = func_0x000180497f30(piVar3, 0x1806222bc, 6), iVar2 == 0)) {
                func_0x00018020e880();
                uVar5 = var_38h;
                uVar7 = var_20h;
            } else {
                piVar3 = &var_38h;
                if (0xf < uVar7) {
                    piVar3 = (int64_t *)uVar5;
                }
                if ((var_28h == 6) && (iVar2 = func_0x000180497f30(piVar3, 0x18063d328, 6), iVar2 == 0)) {
                    func_0x00018020e890();
                    uVar5 = var_38h;
                    uVar7 = var_20h;
                } else {
                    piVar3 = &var_38h;
                    if (0xf < uVar7) {
                        piVar3 = (int64_t *)uVar5;
                    }
                    if ((var_28h == 6) && (iVar2 = func_0x000180497f30(piVar3, 0x18063d320, 6), iVar2 == 0)) {
                        func_0x00018020e8e0();
                        uVar5 = var_38h;
                        uVar7 = var_20h;
                    } else {
                        piVar3 = &var_38h;
                        if (0xf < uVar7) {
                            piVar3 = (int64_t *)uVar5;
                        }
                        if ((var_28h == 3) && (iVar2 = func_0x000180497f30(piVar3, 0x18063d31c, 3), iVar2 == 0)) {
                            func_0x00018021daa0();
                            uVar5 = var_38h;
                            uVar7 = var_20h;
                        } else {
                            piVar3 = &var_38h;
                            if (0xf < uVar7) {
                                piVar3 = (int64_t *)uVar5;
                            }
                            if ((var_28h == 8) && (iVar2 = func_0x000180497f30(piVar3, 0x18063d368, 8), iVar2 == 0)) {
                                func_0x00018020e8a0();
                                uVar5 = var_38h;
                                uVar7 = var_20h;
                            } else {
                                piVar3 = &var_38h;
                                if (0xf < uVar7) {
                                    piVar3 = (int64_t *)uVar5;
                                }
                                if ((var_28h == 8) && (iVar2 = func_0x000180497f30(piVar3, 0x18063d358, 8), iVar2 == 0))
                                {
                                    func_0x00018020e8b0();
                                    uVar5 = var_38h;
                                    uVar7 = var_20h;
                                } else {
                                    piVar3 = &var_38h;
                                    if (0xf < uVar7) {
                                        piVar3 = (int64_t *)uVar5;
                                    }
                                    if ((var_28h == 8) &&
                                       (iVar2 = func_0x000180497f30(piVar3, 0x18063d348, 8), iVar2 == 0)) {
                                        func_0x00018020e8c0();
                                        uVar5 = var_38h;
                                        uVar7 = var_20h;
                                    } else {
                                        piVar3 = &var_38h;
                                        if (0xf < uVar7) {
                                            piVar3 = (int64_t *)uVar5;
                                        }
                                        if ((var_28h == 8) &&
                                           (iVar2 = func_0x000180497f30(piVar3, 0x18063d338, 8), iVar2 == 0)) {
                                            func_0x00018020e8d0();
                                            uVar5 = var_38h;
                                            uVar7 = var_20h;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (0xf < uVar7) {
        uVar4 = uVar5;
        puVar6 = auStack_58;
        if (0xfff < uVar7 + 1) {
            uVar4 = *(uint64_t *)(uVar5 - 8);
            uVar5 = (uVar5 - uVar4) - 8;
            puVar6 = auStack_58;
            if (0x1f < uVar5) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                uVar4 = uVar5;
                puVar6 = auStack_50;
            }
        }
        *(undefined8 *)(puVar6 + -8) = 0x18008100e;
        func_0x000180459c3c(uVar4);
    }
    *(undefined8 *)(puVar6 + -8) = 0x18008101e;
    func_0x000180459870(*(uint64_t *)(puVar6 + 0x40) ^ (uint64_t)puVar6);
    return;
}

// ============================================================
// Function: FUN_180081030
// Address: 0x180081030
// Size: 571 bytes
// ============================================================
void fcn.180081030(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined *puVar7;
    undefined *puVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint64_t uVar12;
    undefined auStack_e8 [8];
    undefined auStack_e0 [24];
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined8 uStack_a8;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_48h;
    uint64_t uVar11;
    
    puVar7 = auStack_e8;
    puVar8 = auStack_e8;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    uVar11 = 0;
    var_c8h = arg2;
    if (arg4 == 0) {
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
        puVar8 = auStack_e8;
        goto code_r0x000180081244;
    }
    iVar4 = func_0x000180215470();
    var_b8h = iVar4;
    if (iVar4 == 0) {
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
        puVar8 = auStack_e8;
        goto code_r0x000180081244;
    }
    iVar3 = func_0x000180214880(iVar4, arg4, 0);
    if ((iVar3 == 1) && (iVar3 = func_0x0001802149b0(iVar4, *(undefined8 *)arg3, *(undefined8 *)(arg3 + 8)), iVar3 == 1)
       ) {
        var_c8h = var_c8h & 0xffffffff00000000;
        iVar3 = func_0x0001802146d0(iVar4, &var_88h, &var_c8h);
        if (iVar3 != 1) goto code_r0x0001800810c4;
        iVar3 = (uint32_t)var_c8h;
        uVar2 = (var_c8h & 0xffffffffU) * 2;
        _var_b0h = ZEXT816(0);
        var_a0h = uVar2;
        if (uVar2 < 0x10) {
            var_98h = 0xf;
            fcn.1804986e0(&var_b0h, 0, uVar2);
            *(undefined *)((int64_t)&var_b0h + uVar2) = 0;
            puVar8 = auStack_e8;
        } else {
            uVar9 = uVar2 | 0xf;
            if (uVar9 < 0x16) {
                uVar9 = 0x16;
            }
            if (uVar9 + 1 < 0x1000) {
                uVar12 = fcn.180459890();
            } else {
                if (uVar9 + 0x28 <= uVar9 + 1) {
                    fcn.180004720();
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                iVar5 = fcn.180459890(uVar9 + 0x28);
                if (iVar5 == 0) {
                    pcVar1 = (code *)swi(0x29);
                    iVar5 = (*pcVar1)(5);
                    puVar7 = auStack_e0;
                }
                uVar12 = iVar5 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar12 - 8) = iVar5;
                puVar8 = puVar7;
            }
            var_b0h = uVar12;
            *(undefined8 *)(puVar8 + -8) = 0x1800811ae;
            var_98h = uVar9;
            fcn.1804986e0(uVar12, 0, uVar2);
            *(undefined *)(uVar12 + uVar2) = 0;
            iVar3 = (uint32_t)var_c8h;
        }
        if (iVar3 != 0) {
            do {
                piVar6 = &var_b0h;
                if (0xf < (uint64_t)var_98h) {
                    piVar6 = (int64_t *)var_b0h;
                }
                uVar10 = (int32_t)uVar11 * 2;
                *(undefined *)((uint64_t)uVar10 + (int64_t)piVar6) =
                     *(undefined *)((uint64_t)(*(uint8_t *)((int64_t)&var_88h + uVar11) >> 4) + 0x18063d380);
                piVar6 = &var_b0h;
                if (0xf < (uint64_t)var_98h) {
                    piVar6 = (int64_t *)var_b0h;
                }
                *(undefined *)((uint64_t)(uVar10 + 1) + (int64_t)piVar6) =
                     *(undefined *)((uint64_t)(*(uint8_t *)((int64_t)&var_88h + uVar11) & 0xf) + 0x18063d380);
                uVar10 = (int32_t)uVar11 + 1;
                uVar11 = (uint64_t)uVar10;
            } while (uVar10 < (uint32_t)var_c8h);
        }
        *(undefined4 *)arg2 = (undefined4)var_b0h;
        *(undefined4 *)(arg2 + 4) = var_b0h._4_4_;
        *(undefined4 *)(arg2 + 8) = (undefined4)uStack_a8;
        *(undefined4 *)(arg2 + 0xc) = uStack_a8._4_4_;
        *(undefined4 *)(arg2 + 0x10) = (undefined4)var_a0h;
        *(undefined4 *)(arg2 + 0x14) = var_a0h._4_4_;
        *(undefined4 *)(arg2 + 0x18) = (undefined4)var_98h;
        *(undefined4 *)(arg2 + 0x1c) = var_98h._4_4_;
        if (iVar4 == 0) goto code_r0x000180081244;
    } else {
code_r0x0001800810c4:
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
        puVar8 = auStack_e8;
    }
    *(undefined8 *)(puVar8 + -8) = 0x180081244;
    func_0x000180215310(iVar4);
code_r0x000180081244:
    *(undefined8 *)(puVar8 + -8) = 0x180081253;
    func_0x000180459870(var_48h ^ (uint64_t)puVar8);
    return;
}

// ============================================================
// Function: FUN_1800812a0
// Address: 0x1800812a0
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h

void fcn.1800812a0(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t var_d8h;
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    int64_t var_c8h;
    int64_t var_a8h;
    int64_t var_18h;
    
    uVar2 = *(undefined4 *)arg2;
    uVar3 = *(undefined4 *)(arg2 + 4);
    uVar4 = *(undefined4 *)(arg2 + 8);
    uVar5 = *(undefined4 *)(arg2 + 0xc);
    fcn.1800047e0(&var_c8h, 0x18063d3b0);
    var_d8h._0_4_ = uVar2;
    var_d8h._4_4_ = uVar3;
    uStack_d0 = uVar4;
    uStack_cc = uVar5;
    fcn.180007460(&var_a8h, &var_c8h, &var_d8h);
    fcn.18045bae0(CONCAT44(var_d8h._4_4_, (undefined4)var_d8h));
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800812f0
// Address: 0x1800812f0
// Size: 344 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

int64_t fcn.1800812f0(int64_t arg1)
{
    uint32_t uVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t placeholder_0;
    uint64_t uVar5;
    undefined2 *puVar6;
    uint64_t uVar7;
    int64_t var_68h;
    undefined var_58h;
    int64_t var_54h;
    undefined8 var_48h;
    int64_t var_40h;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 7;
    *(undefined2 *)arg1 = 0;
    var_54h._0_4_ = 2;
    var_40h = arg1;
    func_0x0001800477b0(0, 0x104, var_58h, 0x104, 0);
    do {
        uVar1 = *(uint32_t *)(arg1 + 0x10);
        iVar4 = arg1;
        if (7 < *(uint64_t *)(arg1 + 0x18)) {
            iVar4 = *(int64_t *)arg1;
        }
        uVar3 = func_0x000180455094(uVar1, iVar4);
        placeholder_0 = *(uint64_t *)(arg1 + 0x10);
        uVar7 = uVar3 & 0xffffffff;
        if (placeholder_0 < uVar7) {
            uVar5 = uVar7 - placeholder_0;
            if (*(uint64_t *)(arg1 + 0x18) - placeholder_0 < uVar5) {
                placeholder_0 = arg1;
                func_0x0001800477b0(arg1, uVar5, var_58h, uVar5, 0);
            } else {
                *(uint64_t *)(arg1 + 0x10) = uVar7;
                iVar4 = arg1;
                if (7 < *(uint64_t *)(arg1 + 0x18)) {
                    iVar4 = *(int64_t *)arg1;
                }
                puVar6 = (undefined2 *)(iVar4 + placeholder_0 * 2);
                if (uVar5 != 0) {
                    for (; placeholder_0 = uVar5, uVar5 != 0; uVar5 = uVar5 - 1) {
                        *puVar6 = 0;
                        puVar6 = puVar6 + 1;
                    }
                }
                *(undefined2 *)(iVar4 + uVar7 * 2) = 0;
            }
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar7;
            if (*(uint64_t *)(arg1 + 0x18) < 8) {
                *(undefined2 *)(arg1 + uVar7 * 2) = 0;
                placeholder_0 = arg1;
            } else {
                placeholder_0 = *(uint64_t *)arg1;
                *(undefined2 *)(placeholder_0 + uVar7 * 2) = 0;
            }
        }
    } while (uVar1 <= (uint32_t)uVar3);
    var_54h._4_4_ = (int32_t)(uVar3 >> 0x20);
    var_48h = 0x1806a45e0;
    var_54h._0_4_ = 1;
    if (var_54h._4_4_ != 0) {
        fcn.1800812a0(placeholder_0, (int64_t)&var_54h + 4);
        pcVar2 = (code *)swi(3);
        iVar4 = (*pcVar2)();
        return iVar4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180081450
// Address: 0x180081450
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h

int64_t fcn.180081450(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_20h._0_4_ = 0;
    var_18h = 0x1806a45e0;
    fcn.180042ab0(0x1806a45e0);
    if ((int32_t)var_20h == 0) {
        return arg1;
    }
    fcn.180041fb0(0x18063d398, &var_20h, arg2, in_R9, 1);
    pcVar1 = (code *)swi(3);
    iVar2 = (*pcVar1)();
    return iVar2;
}

// ============================================================
// Function: FUN_1800814c0
// Address: 0x1800814c0
// Size: 645 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.1800814c0(void)
{
    int64_t arg2;
    undefined8 uVar1;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStackY_e8 [32];
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_98h;
    int64_t var_78h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_e8;
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x1807829f0) {
        fcn.180459d18(0x1807829f0);
        if (*(int32_t *)0x1807829f0 == -1) {
            arg2 = fcn.180459890(0x80);
            var_c8h = 0x18063bfb0;
            var_c0h = 9;
            fcn.1800476c0(&var_78h, &var_c8h);
            var_c8h = 0x1805ab2d0;
            var_c0h = 6;
            fcn.1800476c0(&var_98h, &var_c8h);
            uVar1 = fcn.180081750(var_c8h);
            uVar1 = fcn.180041b00(&var_58h, uVar1, &var_98h);
            fcn.180041b00(&var_b8h, uVar1, &var_78h);
            fcn.180081810();
            fcn.18000dc80(&var_58h);
            fcn.18000dc80(&var_38h);
            fcn.18000dc80(&var_98h);
            fcn.18000dc80(&var_78h);
            var_c8h = 0x18063d510;
            var_c0h = 0xb;
            fcn.1800476c0(&var_98h, &var_c8h);
            var_c8h = 0x1805ab2d0;
            var_c0h = 6;
            fcn.1800476c0(&var_78h, &var_c8h);
            uVar1 = fcn.180081750(var_c8h);
            uVar1 = fcn.180041b00(&var_38h, uVar1, &var_78h);
            fcn.180041b00(&var_b8h, uVar1, &var_98h);
            fcn.180081810();
            fcn.18000dc80(&var_38h);
            fcn.18000dc80(&var_58h);
            fcn.18000dc80(&var_78h);
            fcn.18000dc80(&var_98h);
            var_c8h = 0x18063d500;
            var_c0h = 8;
            fcn.1800476c0(&var_98h, &var_c8h);
            var_c8h = 0x18063d4f8;
            var_c0h = 7;
            fcn.1800476c0(&var_78h, &var_c8h);
            uVar1 = fcn.1800812f0((int64_t)&var_58h);
            uVar1 = fcn.180041b00(&var_38h, uVar1, &var_78h);
            fcn.180041b00(&var_b8h, uVar1, &var_98h);
            fcn.180081810();
            fcn.18000dc80(&var_38h);
            fcn.18000dc80(&var_58h);
            fcn.18000dc80(&var_78h);
            fcn.18000dc80(&var_98h);
            fcn.180081450(arg2 + 0x60, arg2);
            *(int64_t *)0x1807829e8 = arg2;
            fcn.180459c24(0x1804a29a0);
            fcn.180459cac(0x1807829f0);
        }
    }
    fcn.180459870(var_18h ^ (uint64_t)auStackY_e8);
    return;
}

// ============================================================
// Function: FUN_180081750
// Address: 0x180081750
// Size: 178 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.180081750(undefined8 placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
                  int64_t arg_28h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int64_t var_8h;
    undefined auStack_68 [32];
    int64_t var_48h;
    int64_t var_30h;
    undefined4 uStack_28;
    undefined4 uStack_24;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    var_48h = 0;
    iVar1 = (*(code *)0x69a7b8)(0x18059cb80, 0, 0, &var_48h);
    if (iVar1 < 0) {
        fcn.1800812f0(arg2);
    } else {
        uVar2 = func_0x0001804766e0(var_48h);
        var_20h = 0;
        var_18h = 0;
        _var_30h = ZEXT816(0);
        func_0x00018000d380(&var_30h, var_48h, uVar2);
        (*(code *)0x69a7ec)(var_48h);
        *(undefined4 *)arg2 = (undefined4)var_30h;
        *(undefined4 *)(arg2 + 4) = var_30h._4_4_;
        *(undefined4 *)(arg2 + 8) = uStack_28;
        *(undefined4 *)(arg2 + 0xc) = uStack_24;
        *(undefined4 *)(arg2 + 0x10) = (undefined4)var_20h;
        *(undefined4 *)(arg2 + 0x14) = var_20h._4_4_;
        *(undefined4 *)(arg2 + 0x18) = (undefined4)var_18h;
        *(undefined4 *)(arg2 + 0x1c) = var_18h._4_4_;
    }
    fcn.180459870(var_10h ^ (uint64_t)auStack_68);
    return;
}

// ============================================================
// Function: FUN_180081810
// Address: 0x180081810
// Size: 160 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180081810(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_8h;
    int64_t var_20h;
    undefined auStack_58 [40];
    int64_t var_30h;
    int64_t var_28h;
    int64_t iStack_20;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    var_30h._0_4_ = 0;
    var_28h = 0x1806a45e0;
    iStack_20 = arg3;
    fcn.180042510(arg3, &var_30h);
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0;
    uVar1 = *(undefined4 *)(arg3 + 4);
    uVar2 = *(undefined4 *)(arg3 + 8);
    uVar3 = *(undefined4 *)(arg3 + 0xc);
    *(undefined4 *)arg2 = *(undefined4 *)arg3;
    *(undefined4 *)(arg2 + 4) = uVar1;
    *(undefined4 *)(arg2 + 8) = uVar2;
    *(undefined4 *)(arg2 + 0xc) = uVar3;
    uVar1 = *(undefined4 *)(arg3 + 0x14);
    uVar2 = *(undefined4 *)(arg3 + 0x18);
    uVar3 = *(undefined4 *)(arg3 + 0x1c);
    *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(arg3 + 0x10);
    *(undefined4 *)(arg2 + 0x14) = uVar1;
    *(undefined4 *)(arg2 + 0x18) = uVar2;
    *(undefined4 *)(arg2 + 0x1c) = uVar3;
    *(undefined8 *)(arg3 + 0x18) = 7;
    *(undefined8 *)(arg3 + 0x10) = 0;
    *(undefined8 *)(arg3 + 0x18) = 7;
    *(undefined2 *)arg3 = 0;
    fcn.180459870(var_18h ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_1800818b0
// Address: 0x1800818b0
// Size: 359 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800818b0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_20h;
    undefined auStack_68 [40];
    int64_t var_40h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    int64_t var_28h;
    undefined8 uStack_20;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    var_40h = arg2;
    if (arg3 == 0) {
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
    } else {
        _var_38h = ZEXT816(0);
        var_28h = 0;
        uStack_20 = 0;
        uVar5 = fcn.180498cd0(arg3);
        fcn.180004830(&var_38h, arg3, uVar5);
        piVar7 = (int64_t *)var_38h;
        if (uStack_20 < 0x10) {
            piVar7 = &var_38h;
        }
        piVar6 = (int64_t *)(var_28h + (int64_t)piVar7);
        for (; (piVar7 != piVar6 && ((*(char *)piVar7 == '/' || (*(char *)piVar7 == '\\'))));
            piVar7 = (int64_t *)((int64_t)piVar7 + 1)) {
        }
        piVar6 = (int64_t *)var_38h;
        if (uStack_20 < 0x10) {
            piVar6 = &var_38h;
        }
        piVar1 = (int64_t *)(var_28h + (int64_t)piVar6);
        do {
            piVar2 = piVar1;
            if (piVar2 == piVar6) break;
            piVar1 = (int64_t *)((int64_t)piVar2 + -1);
        } while ((*(char *)piVar1 == '/') || (*(char *)piVar1 == '\\'));
        func_0x00018000f180(&var_38h, piVar7, (int64_t)piVar2 - (int64_t)piVar7);
        if (uStack_20 < 0x10) {
            piVar7 = &var_38h;
        } else {
            piVar7 = (int64_t *)var_38h;
        }
        piVar6 = (int64_t *)(var_28h + (int64_t)piVar7);
        iVar3 = var_28h;
        uVar4 = uStack_20;
        for (; var_28h = iVar3, uStack_20 = uVar4, piVar7 != piVar6; piVar7 = (int64_t *)((int64_t)piVar7 + 1)) {
            if (*(char *)piVar7 == '\\') {
                *(char *)piVar7 = '/';
            }
            iVar3 = var_28h;
            uVar4 = uStack_20;
        }
        *(undefined4 *)arg2 = (undefined4)var_38h;
        *(undefined4 *)(arg2 + 4) = var_38h._4_4_;
        *(undefined4 *)(arg2 + 8) = uStack_30;
        *(undefined4 *)(arg2 + 0xc) = uStack_2c;
        var_28h._0_4_ = (undefined4)iVar3;
        var_28h._4_4_ = (undefined4)((uint64_t)iVar3 >> 0x20);
        uStack_20._0_4_ = (undefined4)uVar4;
        uStack_20._4_4_ = (undefined4)(uVar4 >> 0x20);
        *(undefined4 *)(arg2 + 0x10) = (undefined4)var_28h;
        *(undefined4 *)(arg2 + 0x14) = var_28h._4_4_;
        *(undefined4 *)(arg2 + 0x18) = (undefined4)uStack_20;
        *(undefined4 *)(arg2 + 0x1c) = uStack_20._4_4_;
    }
    fcn.180459870(var_18h ^ (uint64_t)auStack_68);
    return;
}

// ============================================================
// Function: FUN_180081a20
// Address: 0x180081a20
// Size: 1175 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.180081a20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    bool bVar4;
    undefined auVar5 [16];
    int16_t *piVar6;
    int16_t *piVar7;
    undefined uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    undefined (*pauVar13) [16];
    int16_t *piVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    char cVar17;
    int64_t *piVar18;
    undefined (*pauVar19) [16];
    undefined *puVar20;
    undefined *puVar21;
    undefined8 *puVar22;
    char in_R9B;
    int16_t *piVar23;
    int64_t var_18h;
    undefined8 uStack_1a0;
    undefined auStack_198 [8];
    undefined auStack_190 [24];
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_160h;
    int64_t var_140h;
    int64_t var_120h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_80h;
    int64_t var_60h;
    int64_t var_40h;
    
    puVar21 = auStack_198;
    puVar20 = auStack_198;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_198;
    piVar11 = (int64_t *)(arg3 + 0x10);
    if (*piVar11 == 0) {
        var_178h = arg2;
        func_0x000180007340(arg2, arg1);
        goto code_r0x000180081e8d;
    }
    piVar18 = (int64_t *)(arg1 + 0x60);
    if (0xf < *(uint64_t *)(arg3 + 0x18)) {
        arg3 = *(int64_t *)arg3;
    }
    var_178h = arg3;
    var_170h = *piVar11;
    fcn.1800476c0(&var_a0h, &var_178h);
    iVar10 = fcn.180041b00(&var_80h, piVar18, &var_a0h);
    fcn.180081450((int64_t)&var_120h, iVar10);
    fcn.18000dc80(&var_80h);
    fcn.18000dc80(&var_a0h);
    if ((uint64_t)var_110h < *(uint64_t *)(arg1 + 0x70)) {
code_r0x000180081b23:
        bVar4 = false;
    } else {
        if (7 < *(uint64_t *)(arg1 + 0x78)) {
            piVar18 = (int64_t *)*piVar18;
        }
        piVar11 = &var_120h;
        if (7 < (uint64_t)var_108h) {
            piVar11 = (int64_t *)var_120h;
        }
        iVar9 = func_0x000180005b70(piVar11, piVar18);
        if (iVar9 != 0) goto code_r0x000180081b23;
        uVar16 = *(uint64_t *)(arg1 + 0x70);
        if (var_110h != uVar16) {
            piVar11 = &var_120h;
            if (7 < (uint64_t)var_108h) {
                piVar11 = (int64_t *)var_120h;
            }
            if (*(int16_t *)((int64_t)piVar11 + uVar16 * 2) != 0x5c) goto code_r0x000180081b23;
        }
        bVar4 = true;
    }
    if (bVar4) {
        puVar21 = auStack_198;
        if (in_R9B != '\0') {
            uVar12 = func_0x0001800071a0(&var_120h, &var_60h);
            pauVar13 = (undefined (*) [16])func_0x000180006eb0(uVar12, &var_160h);
            pauVar19 = pauVar13;
            if (0xf < *(uint64_t *)(pauVar13[1] + 8)) {
                pauVar19 = *(undefined (**) [16])*pauVar13;
            }
            iVar10 = *(int64_t *)pauVar13[1];
            puVar21 = *pauVar19;
            for (; pauVar19 != (undefined (*) [16])(puVar21 + iVar10); pauVar19 = (undefined (*) [16])(*pauVar19 + 1)) {
                uVar8 = func_0x000180460320((*pauVar19)[0]);
                (*pauVar19)[0] = uVar8;
            }
            _var_e0h = *pauVar13;
            var_d0h = *(int64_t *)pauVar13[1];
            var_c8h = *(int64_t *)(pauVar13[1] + 8);
            *(undefined8 *)(pauVar13[1] + 8) = 0xf;
            (*pauVar13)[0] = 0;
            *(undefined8 *)pauVar13[1] = 0;
            *(undefined8 *)(pauVar13[1] + 8) = 0xf;
            (*pauVar13)[0] = 0;
            fcn.18000dc80(&var_60h);
            piVar11 = &var_120h;
            if (7 < (uint64_t)var_108h) {
                piVar11 = (int64_t *)var_120h;
            }
            piVar1 = (int16_t *)((int64_t)piVar11 + var_110h * 2);
            piVar23 = piVar1;
            piVar14 = (int16_t *)func_0x000180006c10(piVar11, piVar1);
            if (piVar14 != piVar1) {
                do {
                    piVar7 = piVar23;
                    piVar6 = piVar1;
                    if ((*piVar14 != 0x5c) && (*piVar14 != 0x2f)) break;
                    piVar14 = piVar14 + 1;
                } while (piVar14 != piVar1);
                do {
                    piVar23 = piVar7;
                    if (piVar14 == piVar6) break;
                    piVar6 = piVar23 + -1;
                    if ((*piVar6 == 0x5c) || (piVar7 = piVar6, *piVar6 == 0x2f)) break;
                } while( true );
            }
            _var_c0h = ZEXT816(0);
            var_b0h = 0;
            var_a8h = 0;
            func_0x00018000d380(&var_c0h, piVar23, (int64_t)piVar1 - (int64_t)piVar23 >> 1);
            pauVar13 = (undefined (*) [16])func_0x000180006eb0(&var_c0h, &var_140h);
            pauVar19 = pauVar13;
            if (0xf < *(uint64_t *)(pauVar13[1] + 8)) {
                pauVar19 = *(undefined (**) [16])*pauVar13;
            }
            iVar10 = *(int64_t *)pauVar13[1];
            puVar21 = *pauVar19;
            for (; pauVar19 != (undefined (*) [16])(puVar21 + iVar10); pauVar19 = (undefined (*) [16])(*pauVar19 + 1)) {
                uVar8 = func_0x000180460320((*pauVar19)[0]);
                (*pauVar19)[0] = uVar8;
            }
            cVar17 = (char)pauVar19;
            _var_100h = *pauVar13;
            var_f0h = *(int64_t *)pauVar13[1];
            var_e8h = *(int64_t *)(pauVar13[1] + 8);
            *(undefined8 *)(pauVar13[1] + 8) = 0xf;
            (*pauVar13)[0] = 0;
            *(undefined8 *)pauVar13[1] = 0;
            *(undefined8 *)(pauVar13[1] + 8) = 0xf;
            (*pauVar13)[0] = 0;
            if ((uint64_t)var_a8h < 8) {
code_r0x000180081d34:
                iVar10 = var_d0h;
                puVar22 = (undefined8 *)0x18063d520;
                uVar16 = var_e0h;
                uVar15 = var_100h;
                do {
                    uVar12 = *puVar22;
                    iVar2 = puVar22[1];
                    if (iVar10 != 0) {
                        piVar11 = &var_e0h;
                        if (0xf < (uint64_t)var_c8h) {
                            piVar11 = (int64_t *)uVar16;
                        }
                        if ((iVar2 != iVar10) ||
                           ((iVar2 != 0 && (iVar9 = func_0x000180497f30(uVar12, piVar11, iVar2), iVar9 != 0))))
                        goto code_r0x000180081d82;
code_r0x000180081df0:
                        cVar17 = '\x01';
                        goto code_r0x000180081dc2;
                    }
code_r0x000180081d82:
                    piVar11 = &var_100h;
                    if (0xf < (uint64_t)var_e8h) {
                        piVar11 = (int64_t *)uVar15;
                    }
                    if ((iVar2 == var_f0h) &&
                       ((iVar2 == 0 || (iVar9 = func_0x000180497f30(uVar12, piVar11, iVar2), iVar9 == 0))))
                    goto code_r0x000180081df0;
                    puVar22 = puVar22 + 2;
                } while (puVar22 != (undefined8 *)0x18063d7a0);
                cVar17 = '\0';
code_r0x000180081dc2:
                if (0xf < (uint64_t)var_e8h) {
                    puVar20 = auStack_198;
                    if (0xfff < var_e8h + 1U) {
                        uVar16 = (uVar15 - *(uint64_t *)(uVar15 + -8)) - 8;
                        uVar15 = *(uint64_t *)(uVar15 + -8);
                        puVar20 = auStack_198;
                        if (0x1f < uVar16) goto code_r0x000180081df4;
                    }
                    goto code_r0x000180081dfe;
                }
            } else {
                uVar16 = var_a8h * 2 + 2;
                if (uVar16 < 0x1000) {
code_r0x000180081d2f:
                    iVar10 = var_c0h;
                    func_0x000180459c3c(iVar10, uVar16);
                    goto code_r0x000180081d34;
                }
                piVar11 = (int64_t *)(var_c0h + -8);
                iVar10 = var_c0h - *piVar11;
                uVar16 = 0;
                if (iVar10 - 8U < 0x20) {
                    uVar16 = var_a8h * 2 + 0x29;
                    var_c0h = *piVar11;
                    goto code_r0x000180081d2f;
                }
code_r0x000180081df4:
                uVar15 = uVar16;
                pcVar3 = (code *)swi(0x29);
                (*pcVar3)(5);
                puVar20 = auStack_190;
code_r0x000180081dfe:
                *(undefined8 *)(puVar20 + -8) = 0x180081e03;
                func_0x000180459c3c(uVar15);
                uVar16 = var_e0h;
            }
            var_f0h = 0;
            var_e8h = 0xf;
            auVar5[15] = 0;
            auVar5._0_15_ = stack0xffffffffffffff01;
            _var_100h = auVar5 << 8;
            if (0xf < (uint64_t)var_c8h) {
                uVar15 = uVar16;
                if (0xfff < var_c8h + 1U) {
                    uVar15 = *(uint64_t *)(uVar16 - 8);
                    uVar16 = (uVar16 - uVar15) - 8;
                    if (0x1f < uVar16) {
                        pcVar3 = (code *)swi(0x29);
                        (*pcVar3)(5);
                        puVar20 = puVar20 + 8;
                        uVar15 = uVar16;
                    }
                }
                *(undefined8 *)(puVar20 + -8) = 0x180081e56;
                func_0x000180459c3c(uVar15);
            }
            puVar21 = puVar20;
            if (cVar17 != '\0') {
                *(undefined (*) [16])(arg2 + 0x10) = ZEXT816(0);
                *(undefined (*) [16])arg2 = ZEXT816(0);
                *(undefined8 *)(arg2 + 0x10) = 0;
                *(undefined8 *)(arg2 + 0x18) = 7;
                *(undefined2 *)arg2 = 0;
                goto code_r0x000180081e83;
            }
        }
        *(undefined8 *)(puVar21 + -8) = 0x180081e82;
        func_0x000180007340(arg2, puVar21 + 0x78);
    } else {
        *(undefined (*) [16])(arg2 + 0x10) = ZEXT816(0);
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 7;
        *(undefined2 *)arg2 = 0;
        puVar21 = auStack_198;
    }
code_r0x000180081e83:
    *(undefined8 *)(puVar21 + -8) = 0x180081e8d;
    fcn.18000dc80(puVar21 + 0x78);
code_r0x000180081e8d:
    *(undefined8 *)(puVar21 + -8) = 0x180081e9c;
    fcn.180459870(var_40h ^ (uint64_t)puVar21);
    return;
}

// ============================================================
// Function: FUN_180081ec0
// Address: 0x180081ec0
// Size: 144 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

undefined8 fcn.180081ec0(undefined8 placeholder_0, int64_t arg2)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    int64_t var_18h;
    
    piVar2 = (int32_t *)fcn.1800083d0(&var_18h, arg2, 6);
    iVar1 = *piVar2;
    if (piVar2[2] == 0) {
        if (iVar1 == 4) {
            piVar2 = (int32_t *)fcn.1800083d0(&var_18h, arg2, 3);
            if (piVar2[2] == 0) {
                uVar3 = 4;
                if (*piVar2 == 3) {
                    uVar3 = 10;
                }
                return uVar3;
            }
        } else {
            if (iVar1 == 1) {
                return 1;
            }
            if (iVar1 == 2) {
                return 2;
            }
            if (iVar1 == 3) {
                return 3;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180081f50
// Address: 0x180081f50
// Size: 738 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180081f50(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    undefined auVar2 [16];
    int32_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined *puVar8;
    undefined *puVar9;
    int64_t var_8h;
    undefined auStack_1c8 [8];
    undefined auStack_1c0 [48];
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_f8h;
    int64_t var_d8h;
    int64_t var_78h;
    undefined8 uStack_70;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_38h;
    
    puVar8 = auStack_1c8;
    puVar9 = auStack_1c8;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    uVar5 = 0;
    iVar7 = arg3;
    if (7 < *(uint64_t *)(arg3 + 0x18)) {
        iVar7 = *(int64_t *)arg3;
    }
    var_190h = arg2;
    iVar3 = func_0x000180455104(iVar7, &var_58h, 9, 0xffffffff);
    if ((iVar3 != 0) || (var_50h == 0)) {
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
        goto code_r0x0001800821fd;
    }
    func_0x00018000a6a0(&var_188h, arg3);
    if (var_f8h == 0) {
        *(undefined (*) [16])arg2 = ZEXT816(0);
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
        *(undefined8 *)((int64_t)&var_188h + (int64_t)*(int32_t *)(var_188h + 4)) = 0x1805ab280;
        *(int32_t *)((int64_t)&var_190h + (int64_t)*(int32_t *)(var_188h + 4) + 4) = *(int32_t *)(var_188h + 4) + -0xb0;
        func_0x00018000c170(&var_178h);
        *(undefined8 *)((int64_t)&var_188h + (int64_t)*(int32_t *)(var_188h + 4)) = 0x1804a5600;
        *(int32_t *)((int64_t)&var_190h + (int64_t)*(int32_t *)(var_188h + 4) + 4) = *(int32_t *)(var_188h + 4) + -0x18;
        var_d8h = 0x1804a54d0;
        func_0x000180455c14(&var_d8h);
        puVar9 = auStack_1c8;
        goto code_r0x0001800821fd;
    }
    auVar2 = ZEXT816(0);
    uStack_70 = 0;
    var_68h = 0;
    var_60h = 0;
    _var_78h = auVar2;
    if (0x7fffffffffffffff < (uint64_t)var_50h) {
        fcn.1800047c0();
code_r0x00018008222c:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uint64_t)var_50h < 0x10) {
        var_68h = var_50h;
        var_60h = 0xf;
        fcn.1804986e0(&var_78h, 0, var_50h);
        *(undefined *)((int64_t)&var_78h + var_50h) = 0;
code_r0x00018008213d:
        piVar6 = &var_78h;
        if (0xf < (uint64_t)var_60h) {
            piVar6 = (int64_t *)var_78h;
        }
        piVar6 = (int64_t *)func_0x000180082840(&var_188h, piVar6, var_50h);
        if ((*(uint8_t *)((int64_t)*(int32_t *)(*piVar6 + 4) + 0x10 + (int64_t)piVar6) & 6) == 0) {
            *(undefined4 *)arg2 = (undefined4)var_78h;
            *(undefined4 *)(arg2 + 4) = var_78h._4_4_;
            *(undefined4 *)(arg2 + 8) = (undefined4)uStack_70;
            *(undefined4 *)(arg2 + 0xc) = uStack_70._4_4_;
            *(undefined4 *)(arg2 + 0x10) = (undefined4)var_68h;
            *(undefined4 *)(arg2 + 0x14) = var_68h._4_4_;
            *(undefined4 *)(arg2 + 0x18) = (undefined4)var_60h;
            *(undefined4 *)(arg2 + 0x1c) = var_60h._4_4_;
        } else {
            *(undefined (*) [16])arg2 = ZEXT816(0);
            *(undefined8 *)(arg2 + 0x10) = 0;
            *(undefined8 *)(arg2 + 0x18) = 0xf;
            *(undefined *)arg2 = 0;
            puVar8 = auStack_1c8;
            if (0xf < (uint64_t)var_60h) {
                iVar7 = var_78h;
                puVar8 = auStack_1c8;
                if ((0xfff < var_60h + 1U) &&
                   (iVar7 = *(int64_t *)(var_78h + -8), puVar8 = auStack_1c8, 0x1f < (var_78h - iVar7) - 8U))
                goto code_r0x0001800821ac;
                goto code_r0x0001800821b6;
            }
        }
    } else {
        uVar4 = var_50h | 0xf;
        if (uVar4 < 0x8000000000000000) {
            if (uVar4 < 0x16) {
                uVar4 = 0x16;
            }
            if (uVar4 != 0xffffffffffffffff) {
                if (0xfff < uVar4 + 1) {
                    uVar5 = uVar4 + 0x28;
                    if (uVar5 <= uVar4 + 1) goto code_r0x00018008222c;
                    goto code_r0x0001800820c3;
                }
                uVar5 = fcn.180459890();
            }
code_r0x00018008211f:
            var_78h = uVar5;
            var_68h = var_50h;
            var_60h = uVar4;
            fcn.1804986e0(uVar5, 0, var_50h);
            *(undefined *)(uVar5 + var_50h) = 0;
            goto code_r0x00018008213d;
        }
        uVar5 = 0x8000000000000027;
        uVar4 = 0x7fffffffffffffff;
code_r0x0001800820c3:
        iVar7 = fcn.180459890(uVar5);
        if (iVar7 != 0) {
            uVar5 = iVar7 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar7;
            goto code_r0x00018008211f;
        }
code_r0x0001800821ac:
        pcVar1 = (code *)swi(0x29);
        iVar7 = (*pcVar1)(5);
        puVar8 = auStack_1c0;
code_r0x0001800821b6:
        *(undefined8 *)(puVar8 + -8) = 0x1800821bb;
        func_0x000180459c3c(iVar7);
    }
    var_68h = 0;
    var_60h = 0xf;
    auVar2[15] = 0;
    auVar2._0_15_ = stack0xffffffffffffff89;
    _var_78h = auVar2 << 8;
    *(undefined8 *)(puVar8 + -8) = 0x1800821d5;
    func_0x00018000a290(puVar8 + 0x40);
    puVar9 = puVar8;
code_r0x0001800821fd:
    *(undefined8 *)(puVar9 + -8) = 0x18008220f;
    fcn.180459870(var_38h ^ (uint64_t)puVar9);
    return;
}

// ============================================================
// Function: FUN_180082240
// Address: 0x180082240
// Size: 978 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_174h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180082240(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int16_t *piVar1;
    int16_t iVar2;
    uint32_t uVar3;
    code *pcVar4;
    uint32_t uVar5;
    int16_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int16_t *piVar9;
    undefined8 uVar10;
    undefined *puVar11;
    uint8_t in_R9B;
    int64_t var_8h;
    undefined auStack_1b8 [8];
    undefined auStack_1b0 [24];
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_100h;
    undefined4 var_e4h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined auStack_b8 [16];
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    puVar11 = auStack_1b8;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1b8;
    var_198h._0_4_ = 0;
    iVar7 = arg2;
    if (7 < *(uint64_t *)(arg2 + 0x18)) {
        iVar7 = *(int64_t *)arg2;
    }
    piVar9 = (int16_t *)(iVar7 + *(int64_t *)(arg2 + 0x10) * 2);
    piVar6 = (int16_t *)func_0x000180006c10(iVar7);
    if (piVar6 != piVar9) {
        do {
            if ((*piVar6 != 0x5c) && (*piVar6 != 0x2f)) break;
            piVar6 = piVar6 + 1;
        } while (piVar6 != piVar9);
        do {
            if (piVar6 == piVar9) goto code_r0x00018008230c;
            iVar2 = piVar9[-1];
            piVar1 = piVar9;
        } while ((iVar2 != 0x5c) && (piVar9 = piVar9 + -1, iVar2 != 0x2f));
        do {
            piVar9 = piVar1;
            if (piVar6 == piVar9) break;
            piVar1 = piVar9 + -1;
        } while ((*piVar1 == 0x5c) || (*piVar1 == 0x2f));
    }
code_r0x00018008230c:
    _var_50h = ZEXT816(0);
    var_40h = 0;
    var_38h = 0;
    func_0x00018000d380(&var_50h, iVar7, (int64_t)piVar9 - iVar7 >> 1);
    if (var_40h == 0) {
code_r0x0001800823b3:
        if (7 < (uint64_t)var_38h) {
            iVar7 = var_50h;
            puVar11 = auStack_1b8;
            if ((0xfff < var_38h * 2 + 2U) &&
               (iVar7 = *(int64_t *)(var_50h + -8), puVar11 = auStack_1b8,
               0x1f < (var_50h - *(int64_t *)(var_50h + -8)) - 8U)) goto code_r0x0001800823ec;
            goto code_r0x0001800823f6;
        }
    } else {
        var_198h._0_4_ = 0;
        var_190h = 0x1806a45e0;
        fcn.180042510(&var_50h, &var_198h);
        if ((int32_t)var_198h == 0) goto code_r0x0001800823b3;
        puVar11 = auStack_1b8;
        if ((uint64_t)var_38h < 8) goto code_r0x00018008259d;
        if (var_38h * 2 + 2U < 0x1000) {
            func_0x000180459c3c(var_50h);
            puVar11 = auStack_1b8;
            goto code_r0x00018008259d;
        }
        if ((var_50h - *(int64_t *)(var_50h + -8)) - 8U < 0x20) {
            func_0x000180459c3c(*(int64_t *)(var_50h + -8), var_38h * 2 + 0x29);
            puVar11 = auStack_1b8;
            goto code_r0x00018008259d;
        }
code_r0x0001800823ec:
        pcVar4 = (code *)swi(0x29);
        iVar7 = (*pcVar4)(5);
        puVar11 = auStack_1b0;
code_r0x0001800823f6:
        *(undefined8 *)(puVar11 + -8) = 0x1800823fb;
        func_0x000180459c3c(iVar7);
    }
    if (7 < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    *(undefined8 *)(puVar11 + 0x30) = 0x18063d7a8;
    var_d8h = 0;
    var_d0h = 0;
    var_c8h._0_4_ = 0;
    var_c0h = 0;
    auStack_b8 = ZEXT816(0);
    _var_a8h = ZEXT816(0);
    _var_98h = ZEXT816(0);
    var_88h._0_1_ = 0;
    *(undefined4 *)(puVar11 + 0x20) = 0xf;
    var_e0h = 0x1804a54f0;
    var_e4h = 0x98;
    *(undefined8 *)(puVar11 + -8) = 0x18008246f;
    func_0x00018000fe50(&var_e0h, puVar11 + 0x38, 0);
    *(undefined8 *)(puVar11 + (int64_t)*(int32_t *)(*(int64_t *)(puVar11 + 0x30) + 4) + 0x30) = 0x18063d7a0;
    *(int32_t *)(puVar11 + (int64_t)*(int32_t *)(*(int64_t *)(puVar11 + 0x30) + 4) + 0x2c) =
         *(int32_t *)(*(int64_t *)(puVar11 + 0x30) + 4) + -0xa8;
    *(undefined8 *)(puVar11 + -8) = 0x1800824a2;
    func_0x00018000fa40(puVar11 + 0x38);
    *(undefined8 *)(puVar11 + -8) = 0x1800824b6;
    iVar7 = func_0x00018000f990(puVar11 + 0x38, arg2, (in_R9B ^ 1) * 8 + 0x28 | 2);
    if (iVar7 == 0) {
        iVar7 = (int64_t)*(int32_t *)(*(int64_t *)(puVar11 + 0x30) + 4);
        uVar5 = 6;
        if (*(int64_t *)(puVar11 + iVar7 + 0x78) != 0) {
            uVar5 = 2;
        }
        uVar3 = *(uint32_t *)(puVar11 + iVar7 + 0x40);
        *(uint32_t *)(puVar11 + iVar7 + 0x40) = uVar5 | uVar3 & 0x17;
        uVar5 = (uVar5 | uVar3 & 0x17) & *(uint32_t *)(puVar11 + iVar7 + 0x44);
        if (uVar5 != 0) {
            if ((uVar5 & 4) == 0) {
                uVar10 = 0x1805aae00;
                if ((uVar5 & 2) == 0) {
                    uVar10 = 0x1805aae18;
                }
            } else {
                uVar10 = 0x1805aade8;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800825f2;
            uVar8 = func_0x000180005e50(&var_50h, 1);
            *(undefined8 *)(puVar11 + -8) = 0x180082601;
            func_0x0001800069f0(&var_78h, uVar10, uVar8);
            *(undefined8 *)(puVar11 + -8) = 0x180082611;
            fcn.18045bae0(*(int64_t *)(puVar11 + 0x20));
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    *(undefined8 *)(puVar11 + (int64_t)*(int32_t *)(*(int64_t *)(puVar11 + 0x30) + 4) + 0x30) = 0x18063d7a0;
    *(int32_t *)(puVar11 + (int64_t)*(int32_t *)(*(int64_t *)(puVar11 + 0x30) + 4) + 0x2c) =
         *(int32_t *)(*(int64_t *)(puVar11 + 0x30) + 4) + -0xa8;
    if (var_100h == 0) {
        iVar7 = *(int64_t *)(puVar11 + 0x30);
    } else {
        uVar10 = *(undefined8 *)(arg3 + 8);
        uVar8 = *(undefined8 *)arg3;
        *(undefined8 *)(puVar11 + -8) = 0x18008252e;
        func_0x0001800826a0(puVar11 + 0x30, uVar8, uVar10);
        iVar7 = *(int64_t *)(puVar11 + 0x30);
    }
    *(undefined8 *)(puVar11 + (int64_t)*(int32_t *)(iVar7 + 4) + 0x30) = 0x18063d7a0;
    *(int32_t *)(puVar11 + (int64_t)*(int32_t *)(*(int64_t *)(puVar11 + 0x30) + 4) + 0x2c) =
         *(int32_t *)(*(int64_t *)(puVar11 + 0x30) + 4) + -0xa8;
    *(undefined8 *)(puVar11 + -8) = 0x180082565;
    func_0x00018000c170(puVar11 + 0x38);
    *(undefined8 *)(puVar11 + (int64_t)*(int32_t *)(*(int64_t *)(puVar11 + 0x30) + 4) + 0x30) = 0x1804a54f0;
    *(int32_t *)(puVar11 + (int64_t)*(int32_t *)(*(int64_t *)(puVar11 + 0x30) + 4) + 0x2c) =
         *(int32_t *)(*(int64_t *)(puVar11 + 0x30) + 4) + -0x10;
    var_e0h = 0x1804a54d0;
    *(undefined8 *)(puVar11 + -8) = 0x180082599;
    func_0x000180455c14(&var_e0h);
code_r0x00018008259d:
    *(undefined8 *)(puVar11 + -8) = 0x1800825ac;
    fcn.180459870(var_30h ^ (uint64_t)puVar11);
    return;
}

// ============================================================
// Function: FUN_180082620
// Address: 0x180082620
// Size: 116 bytes
// ============================================================
void fcn.180082620(int64_t arg1)
{
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x18063d7a0;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0xa8;
    fcn.18000c170(arg1 + 8);
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a54f0;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x10;
    *(undefined8 *)(arg1 + 0xa8) = 0x1804a54d0;
    fcn.180455c14();
    return;
}

// ============================================================
// Function: FUN_1800826a0
// Address: 0x1800826a0
// Size: 414 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800826a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    undefined8 uVar9;
    bool bVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 8))();
    }
    iVar6 = *(int64_t *)arg1;
    if (*(int32_t *)((int64_t)*(int32_t *)(iVar6 + 4) + 0x10 + arg1) == 0) {
        iVar2 = *(int64_t *)((int64_t)*(int32_t *)(iVar6 + 4) + 0x50 + arg1);
        if ((iVar2 == 0) || (iVar2 == arg1)) {
            bVar10 = true;
        } else {
            func_0x00018000fad0(iVar2);
            iVar6 = *(int64_t *)arg1;
            bVar10 = *(int32_t *)((int64_t)*(int32_t *)(iVar6 + 4) + 0x10 + arg1) == 0;
        }
    } else {
        bVar10 = false;
    }
    if (bVar10) {
        uVar8 = 0;
        if ((0 < arg3) &&
           (piVar1 = *(int64_t **)((int64_t)*(int32_t *)(iVar6 + 4) + 0x48 + arg1),
           iVar6 = (**(code **)(*piVar1 + 0x48))(piVar1, arg2, arg3), uVar8 = 0, iVar6 != arg3)) {
            uVar8 = 4;
        }
    } else {
        uVar8 = 4;
    }
    iVar6 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
    uVar7 = 4;
    if (*(int64_t *)(iVar6 + 0x48 + arg1) != 0) {
        uVar7 = 0;
    }
    uVar8 = uVar7 | *(uint32_t *)(iVar6 + 0x10 + arg1) & 0x17 | uVar8;
    *(uint32_t *)(iVar6 + 0x10 + arg1) = uVar8;
    uVar8 = uVar8 & *(uint32_t *)(iVar6 + 0x14 + arg1);
    if (uVar8 != 0) {
        if ((uVar8 & 4) == 0) {
            uVar9 = 0x1805aae00;
            if ((uVar8 & 2) == 0) {
                uVar9 = 0x1805aae18;
            }
        } else {
            uVar9 = 0x1805aade8;
        }
        uVar5 = func_0x000180005e50(&var_58h, 1);
        func_0x0001800069f0(&var_48h, uVar9, uVar5);
        fcn.18045bae0(arg1);
        pcVar3 = (code *)swi(3);
        iVar6 = (*pcVar3)();
        return iVar6;
    }
    iVar4 = func_0x0001804557c0();
    if (iVar4 == 0) {
        func_0x00018000fc20(arg1);
    }
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x10))();
    }
    return arg1;
}

// ============================================================
// Function: FUN_180082840
// Address: 0x180082840
// Size: 336 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180082840(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    code *pcVar2;
    char cVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    
    *(undefined8 *)(arg1 + 8) = 0;
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 8))();
    }
    cVar3 = func_0x00018007f7b0(arg1, 1);
    uVar5 = 0;
    if ((cVar3 != '\0') && (uVar5 = 0, 0 < arg3)) {
        piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
        iVar6 = (**(code **)(*piVar1 + 0x40))(piVar1, arg2, arg3);
        *(int64_t *)(arg1 + 8) = iVar6;
        uVar5 = 0;
        if (iVar6 != arg3) {
            uVar5 = 3;
        }
    }
    iVar6 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
    uVar4 = 4;
    if (*(int64_t *)(iVar6 + 0x48 + arg1) != 0) {
        uVar4 = 0;
    }
    uVar5 = uVar4 | uVar5 | *(uint32_t *)(iVar6 + 0x10 + arg1) & 0x17;
    *(uint32_t *)(iVar6 + 0x10 + arg1) = uVar5;
    uVar5 = uVar5 & *(uint32_t *)(iVar6 + 0x14 + arg1);
    if (uVar5 != 0) {
        if ((uVar5 & 4) == 0) {
            uVar8 = 0x1805aae00;
            if ((uVar5 & 2) == 0) {
                uVar8 = 0x1805aae18;
            }
        } else {
            uVar8 = 0x1805aade8;
        }
        uVar7 = func_0x000180005e50(&var_58h, 1);
        func_0x0001800069f0(&var_48h, uVar8, uVar7);
        fcn.18045bae0(arg1);
        pcVar2 = (code *)swi(3);
        iVar6 = (*pcVar2)();
        return iVar6;
    }
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x10))();
    }
    return arg1;
}

// ============================================================
// Function: FUN_180082990
// Address: 0x180082990
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180082990(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    arg1 = arg1 + -0xa8;
    fcn.180082620(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x108);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800829e0
// Address: 0x1800829e0
// Size: 1048 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_1f4h
// WARNING: Variable defined which should be unmapped: var_218h
// WARNING: [rz-ghidra] Detected overlap for variable var_1f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1f0h

void fcn.1800829e0(void)
{
    code *pcVar1;
    undefined auVar2 [16];
    int32_t iVar3;
    int64_t arg2;
    undefined8 uVar4;
    undefined (*pauVar5) [16];
    int64_t *piVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined *puVar9;
    int64_t unaff_GS_OFFSET;
    undefined auStackY_238 [8];
    undefined auStackY_230 [24];
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f4h;
    undefined4 uStack_1ec;
    int64_t var_1e8h;
    int64_t var_1e0h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1b8h;
    int64_t var_1b0h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_148h;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_238;
    puVar9 = auStackY_238;
    if ((*(int32_t *)0x180782a00 <=
         *(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8))
       || (fcn.180459d18(0x180782a00), puVar9 = auStackY_238, *(int32_t *)0x180782a00 != -1)) goto code_r0x000180082a2a;
    arg2 = fcn.180459890(0x20);
    var_1d0h = 0;
    var_1c8h = 0xf;
    stack0xfffffffffffffe21 = SUB1615(ZEXT816(0), 1);
    auVar2[15] = 0;
    auVar2._0_15_ = stack0xfffffffffffffe21;
    _var_1e0h = auVar2 << 8;
    var_1f4h._0_4_ = 0;
    fcn.1804986e0(&var_148h, 0, 0x104);
    iVar3 = (*(code *)0x699df2)(0x18063d7e0, &var_148h, 0x104);
    if (iVar3 == 0) {
code_r0x000180082bfb:
        fcn.180065f60(&var_198h, 0x10, 0x18063d7d0, (undefined4)var_1f4h);
        uVar7 = fcn.180498cd0(&var_198h);
        if ((uint64_t)(var_1c8h - var_1d0h) < uVar7) {
            var_218h = uVar7;
            fcn.18000ee80(uVar7);
        } else {
            piVar6 = &var_1e0h;
            if (0xf < (uint64_t)var_1c8h) {
                piVar6 = (int64_t *)var_1e0h;
            }
            iVar8 = (int64_t)piVar6 + var_1d0h;
            var_1d0h = uVar7 + var_1d0h;
            fcn.180498030(iVar8, &var_198h, uVar7);
            *(undefined *)(uVar7 + iVar8) = 0;
        }
        var_1e8h = 0;
        var_218h = (int64_t)&var_1e8h;
        iVar3 = (*(code *)0x699b66)(0xffffffff80000002, 0x18063d7b0, 0, 0x20119);
        puVar9 = auStackY_238;
        if (iVar3 == 0) {
            _var_188h = ZEXT816(0);
            _var_178h = ZEXT816(0);
            _var_168h = ZEXT816(0);
            _var_158h = ZEXT816(0);
            var_1f4h._4_4_ = 0x40;
            var_210h = (int64_t)&var_1f4h + 4;
            var_218h = (int64_t)&var_188h;
            (*(code *)0x699b76)(var_1e8h, 0x18063d7f0, 0, 0);
            (*(code *)0x699b8a)(var_1e8h);
            uVar7 = fcn.180498cd0(&var_188h);
            if ((uint64_t)(var_1c8h - var_1d0h) < uVar7) {
                var_218h = uVar7;
                fcn.18000ee80(uVar7);
            } else {
                piVar6 = &var_1e0h;
                if (0xf < (uint64_t)var_1c8h) {
                    piVar6 = (int64_t *)var_1e0h;
                }
                iVar8 = (int64_t)piVar6 + var_1d0h;
                var_1d0h = var_1d0h + uVar7;
                fcn.180498030(iVar8, &var_188h, uVar7);
                *(undefined *)(iVar8 + uVar7) = 0;
            }
        }
        fcn.18007ff90();
        iVar8 = fcn.18020e880();
        var_1b8h = (int64_t)&var_1e0h;
        if (0xf < (uint64_t)var_1c8h) {
            var_1b8h = var_1e0h;
        }
        var_1b0h = var_1d0h;
        fcn.180081030(var_1d0h, arg2, (int64_t)&var_1b8h, iVar8);
        if (0xf < (uint64_t)var_1c8h) {
            iVar8 = var_1e0h;
            puVar9 = auStackY_238;
            if ((0xfff < var_1c8h + 1U) &&
               (iVar8 = *(int64_t *)(var_1e0h + -8), puVar9 = auStackY_238,
               0x1f < (var_1e0h - *(int64_t *)(var_1e0h + -8)) - 8U)) goto code_r0x000180082de2;
            goto code_r0x000180082dec;
        }
    } else {
        _var_188h = ZEXT816(0);
        _var_178h = ZEXT816(0);
        uVar4 = fcn.180498cd0(&var_148h);
        fcn.180004830(&var_188h, &var_148h, uVar4);
        pauVar5 = (undefined (*) [16])fcn.18000d970(CONCAT44(uStack_1ec, var_1f4h._4_4_));
        _var_1b8h = *pauVar5;
        var_1a8h = *(int64_t *)pauVar5[1];
        var_1a0h = *(int64_t *)(pauVar5[1] + 8);
        *(undefined8 *)pauVar5[1] = 0;
        *(undefined8 *)(pauVar5[1] + 8) = 0xf;
        (*pauVar5)[0] = 0;
        if ((uint64_t)var_170h < 0x10) {
code_r0x000180082b8c:
            piVar6 = &var_1b8h;
            if (0xf < (uint64_t)var_1a0h) {
                piVar6 = (int64_t *)var_1b8h;
            }
            var_200h._0_4_ = 0;
            var_208h = 0;
            var_210h = 0;
            var_218h = 0;
            (*(code *)0x699e0c)(piVar6, 0, 0, &var_1f4h);
            if (0xf < (uint64_t)var_1a0h) {
                uVar7 = var_1a0h + 1;
                iVar8 = var_1b8h;
                if (0xfff < uVar7) {
                    if (0x1f < (var_1b8h - *(int64_t *)(var_1b8h + -8)) - 8U) goto code_r0x000180082de2;
                    uVar7 = var_1a0h + 0x28;
                    iVar8 = *(int64_t *)(var_1b8h + -8);
                }
                fcn.180459c3c(iVar8, uVar7);
            }
            goto code_r0x000180082bfb;
        }
        uVar7 = var_170h + 1;
        iVar8 = var_188h;
        if (uVar7 < 0x1000) {
code_r0x000180082b87:
            fcn.180459c3c(iVar8, uVar7);
            goto code_r0x000180082b8c;
        }
        if ((var_188h - *(int64_t *)(var_188h + -8)) - 8U < 0x20) {
            uVar7 = var_170h + 0x28;
            iVar8 = *(int64_t *)(var_188h + -8);
            goto code_r0x000180082b87;
        }
code_r0x000180082de2:
        pcVar1 = (code *)swi(0x29);
        iVar8 = (*pcVar1)(5);
        puVar9 = auStackY_230;
code_r0x000180082dec:
        *(undefined8 *)(puVar9 + -8) = 0x180082df1;
        fcn.180459c3c(iVar8);
    }
    *(undefined8 *)(puVar9 + -8) = 0x180082a61;
    *(int64_t *)0x1807829f8 = arg2;
    fcn.180459c24(0x1804a29f0);
    *(undefined8 *)(puVar9 + -8) = 0x180082a6d;
    fcn.180459cac(0x180782a00);
code_r0x000180082a2a:
    *(undefined8 *)(puVar9 + -8) = 0x180082a40;
    fcn.180459870(var_38h ^ (uint64_t)puVar9);
    return;
}

// ============================================================
// Function: FUN_180082e00
// Address: 0x180082e00
// Size: 156 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180082e00(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int64_t iVar11;
    undefined *puVar12;
    int64_t var_18h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    uVar3 = *(undefined4 *)arg2;
    uVar4 = *(undefined4 *)(arg2 + 4);
    uVar5 = *(undefined4 *)(arg2 + 8);
    uVar6 = *(undefined4 *)(arg2 + 0xc);
    uVar7 = *(undefined4 *)(arg2 + 0x10);
    uVar8 = *(undefined4 *)(arg2 + 0x14);
    uVar9 = *(undefined4 *)(arg2 + 0x18);
    uVar10 = *(undefined4 *)(arg2 + 0x1c);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    *(undefined4 *)(arg1 + 8) = uVar3;
    *(undefined4 *)(arg1 + 0xc) = uVar4;
    *(undefined4 *)(arg1 + 0x10) = uVar5;
    *(undefined4 *)(arg1 + 0x14) = uVar6;
    *(undefined4 *)(arg1 + 0x18) = uVar7;
    *(undefined4 *)(arg1 + 0x1c) = uVar8;
    *(undefined4 *)(arg1 + 0x20) = uVar9;
    *(undefined4 *)(arg1 + 0x24) = uVar10;
    *(undefined8 *)arg1 = 0x1804a56f0;
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        iVar1 = *(int64_t *)arg2;
        iVar11 = iVar1;
        puVar12 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg2 + 0x18) + 1) &&
           (iVar11 = *(int64_t *)(iVar1 + -8), puVar12 = auStack_28, 0x1f < (iVar1 - iVar11) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar11 = (*pcVar2)(5);
            puVar12 = auStack_20;
        }
        *(undefined8 *)(puVar12 + -8) = 0x180082e7b;
        fcn.180459c3c(iVar11);
    }
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    return arg1;
}

// ============================================================
// Function: FUN_180082ea0
// Address: 0x180082ea0
// Size: 197 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180082ece: Changing call to branch
// WARNING: Possible PIC construction at 0x000180082ee6: Changing call to branch
// WARNING: Possible PIC construction at 0x000180082efe: Changing call to branch
// WARNING: Possible PIC construction at 0x000180082f16: Changing call to branch
// WARNING: Possible PIC construction at 0x000180082f2e: Changing call to branch
// WARNING: Possible PIC construction at 0x000180082f40: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180082f33)
// WARNING: Removing unreachable block (ram,0x000180082f1b)
// WARNING: Removing unreachable block (ram,0x000180082f03)
// WARNING: Removing unreachable block (ram,0x000180082eeb)
// WARNING: Removing unreachable block (ram,0x000180082ed3)
// WARNING: Removing unreachable block (ram,0x000180082f45)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180082ea0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    
    func_0x00018016ff40(arg1 + 0x60);
    func_0x00018016ff40(arg1 + 0xa0);
    if (0xf < *(uint64_t *)(arg1 + 0x1a8)) {
        iVar1 = *(int64_t *)(arg1 + 400);
        iVar3 = iVar1;
        puVar4 = auStack_58;
        if ((0xfff < *(uint64_t *)(arg1 + 0x1a8) + 1) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_58, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_50;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180004e88;
        fcn.180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x1a0) = 0;
    *(undefined8 *)(arg1 + 0x1a8) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 400) = 0;
    return;
}

// ============================================================
// Function: FUN_180082f70
// Address: 0x180082f70
// Size: 2845 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_56h
// WARNING: [rz-ghidra] Detected overlap for variable var_1f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1f0h

void fcn.180082f70(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    bool bVar2;
    undefined8 *puVar3;
    char cVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t **ppiVar10;
    undefined8 *puVar11;
    undefined *puVar12;
    char in_R8B;
    int64_t **ppiVar13;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    puVar5 = (undefined8 *)fcn.1800829e0();
    ppiVar13 = (int64_t **)*puVar5;
    if ((int32_t)arg2 == 0) {
        var_50h = 10;
        var_48h = 0xf;
        var_58h._0_2_ = 0x746e;
        var_60h = 0x6567412d72657355;
        var_58h._2_1_ = (char)arg2;
        var_58h._3_5_ = 0;
        uVar6 = func_0x00018004a200(arg1, &var_60h);
        func_0x00018000f180(uVar6, 0x1806237b0, 0xe);
        if (0xf < (uint64_t)var_48h) {
            uVar9 = var_48h + 1;
            iVar8 = var_60h;
            if (0xfff < uVar9) {
                if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180083a65;
                uVar9 = var_48h + 0x28;
                iVar8 = *(int64_t *)(var_60h + -8);
            }
            fcn.180459c3c(iVar8, uVar9);
        }
        _var_60h = ZEXT816(0);
        var_50h = 0;
        var_48h = 0;
        puVar7 = (undefined4 *)fcn.180459890(0x20);
        var_60h = (int64_t)puVar7;
        var_50h = 0x12;
        var_48h = 0x1f;
        *puVar7 = 0x6964614d;
        puVar7[1] = 0x462d6d75;
        puVar7[2] = 0x65676e69;
        puVar7[3] = 0x69727072;
        *(undefined2 *)(puVar7 + 4) = 0x746e;
        *(undefined *)((int64_t)puVar7 + 0x12) = 0;
        puVar5 = (undefined8 *)(*(undefined8 **)arg1)[1];
        cVar4 = *(char *)((int64_t)puVar5 + 0x19);
        puVar3 = *(undefined8 **)arg1;
        while (cVar4 == '\0') {
            cVar4 = func_0x00018016b240(arg1, puVar5 + 4, &var_60h);
            if (cVar4 == '\0') {
                puVar11 = (undefined8 *)*puVar5;
            } else {
                puVar11 = (undefined8 *)puVar5[2];
                puVar5 = puVar3;
            }
            puVar3 = puVar5;
            puVar5 = puVar11;
            cVar4 = *(char *)((int64_t)puVar11 + 0x19);
        }
        if ((*(char *)((int64_t)puVar3 + 0x19) == '\0') &&
           (cVar4 = func_0x00018016b240(arg1, &var_60h, puVar3 + 4), cVar4 == '\0')) {
            bVar2 = false;
        } else {
            bVar2 = true;
        }
        if (0xf < (uint64_t)var_48h) {
            uVar9 = var_48h + 1;
            iVar8 = var_60h;
            if (0xfff < uVar9) {
                if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180083a65;
                uVar9 = var_48h + 0x28;
                iVar8 = *(int64_t *)(var_60h + -8);
            }
            fcn.180459c3c(iVar8, uVar9);
        }
        if (bVar2) {
            _var_60h = ZEXT816(0);
            var_50h = 0;
            var_48h = 0;
            puVar7 = (undefined4 *)fcn.180459890(0x20);
            var_60h = (int64_t)puVar7;
            var_50h = 0x12;
            var_48h = 0x1f;
            *puVar7 = 0x6964614d;
            puVar7[1] = 0x462d6d75;
            puVar7[2] = 0x65676e69;
            puVar7[3] = 0x69727072;
            *(undefined2 *)(puVar7 + 4) = 0x746e;
            *(undefined *)((int64_t)puVar7 + 0x12) = 0;
            iVar8 = func_0x00018004a200(arg1, &var_60h);
            if ((int64_t **)iVar8 != ppiVar13) {
                ppiVar10 = ppiVar13;
                if ((int64_t *)0xf < ppiVar13[3]) {
                    ppiVar10 = (int64_t **)*ppiVar13;
                }
                func_0x00018000f180(iVar8, ppiVar10, ppiVar13[2]);
            }
            if (0xf < (uint64_t)var_48h) {
                uVar9 = var_48h + 1;
                iVar8 = var_60h;
                if (0xfff < uVar9) {
                    if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180083a65;
                    uVar9 = var_48h + 0x28;
                    iVar8 = *(int64_t *)(var_60h + -8);
                }
                fcn.180459c3c(iVar8, uVar9);
            }
        }
        _var_60h = ZEXT816(0);
        var_50h = 0;
        var_48h = 0;
        puVar7 = (undefined4 *)fcn.180459890(0x20);
        var_60h = (int64_t)puVar7;
        var_50h = 0x16;
        var_48h = 0x1f;
        *puVar7 = 0x6964614d;
        puVar7[1] = 0x552d6d75;
        puVar7[2] = 0x2d726573;
        puVar7[3] = 0x6e656449;
        *(undefined8 *)((int64_t)puVar7 + 0xe) = 0x7265696669746e65;
        *(undefined *)((int64_t)puVar7 + 0x16) = 0;
        puVar5 = (undefined8 *)(*(undefined8 **)arg1)[1];
        cVar4 = *(char *)((int64_t)puVar5 + 0x19);
        puVar3 = *(undefined8 **)arg1;
        while (cVar4 == '\0') {
            cVar4 = func_0x00018016b240(arg1, puVar5 + 4, &var_60h);
            if (cVar4 == '\0') {
                puVar11 = (undefined8 *)*puVar5;
            } else {
                puVar11 = (undefined8 *)puVar5[2];
                puVar5 = puVar3;
            }
            puVar3 = puVar5;
            puVar5 = puVar11;
            cVar4 = *(char *)((int64_t)puVar11 + 0x19);
        }
        if ((*(char *)((int64_t)puVar3 + 0x19) == '\0') &&
           (cVar4 = func_0x00018016b240(arg1, &var_60h, puVar3 + 4), cVar4 == '\0')) {
            bVar2 = false;
        } else {
            bVar2 = true;
        }
        if (0xf < (uint64_t)var_48h) {
            uVar9 = var_48h + 1;
            iVar8 = var_60h;
            if (0xfff < uVar9) {
                if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180083a65;
                uVar9 = var_48h + 0x28;
                iVar8 = *(int64_t *)(var_60h + -8);
            }
            fcn.180459c3c(iVar8, uVar9);
        }
        puVar12 = auStack_88;
        if (!bVar2) goto code_r0x000180083a74;
        _var_60h = ZEXT816(0);
        var_50h = 0;
        var_48h = 0;
        puVar7 = (undefined4 *)fcn.180459890(0x20);
        var_60h = (int64_t)puVar7;
        var_50h = 0x16;
        var_48h = 0x1f;
        *puVar7 = 0x6964614d;
        puVar7[1] = 0x552d6d75;
        puVar7[2] = 0x2d726573;
        puVar7[3] = 0x6e656449;
        *(undefined8 *)((int64_t)puVar7 + 0xe) = 0x7265696669746e65;
        *(undefined *)((int64_t)puVar7 + 0x16) = 0;
        iVar8 = func_0x00018004a200(arg1, &var_60h);
        if ((int64_t **)iVar8 != ppiVar13) {
            ppiVar10 = ppiVar13 + 2;
            if ((int64_t *)0xf < ppiVar13[3]) {
                ppiVar13 = (int64_t **)*ppiVar13;
            }
            func_0x00018000f180(iVar8, ppiVar13, *ppiVar10);
        }
code_r0x000180083a34:
        puVar12 = auStack_88;
        if ((uint64_t)var_48h < 0x10) goto code_r0x000180083a74;
        iVar8 = var_60h;
        puVar12 = auStack_88;
        if ((0xfff < var_48h + 1U) &&
           (iVar8 = *(int64_t *)(var_60h + -8), puVar12 = auStack_88, 0x1f < (var_60h - iVar8) - 8U))
        goto code_r0x000180083a65;
    } else {
        puVar12 = auStack_88;
        if ((int32_t)arg2 != 1) goto code_r0x000180083a74;
        var_50h = 10;
        var_48h = 0xf;
        if (in_R8B != '\0') {
            var_58h = 0x746e;
            var_60h = 0x6567412d72657355;
            puVar5 = (undefined8 *)(*(undefined8 **)arg1)[1];
            cVar4 = *(char *)((int64_t)puVar5 + 0x19);
            puVar3 = *(undefined8 **)arg1;
            while (cVar4 == '\0') {
                cVar4 = func_0x00018016b240(arg1, puVar5 + 4, &var_60h);
                if (cVar4 == '\0') {
                    puVar11 = (undefined8 *)*puVar5;
                } else {
                    puVar11 = (undefined8 *)puVar5[2];
                    puVar5 = puVar3;
                }
                puVar3 = puVar5;
                puVar5 = puVar11;
                cVar4 = *(char *)((int64_t)puVar11 + 0x19);
            }
            if ((*(char *)((int64_t)puVar3 + 0x19) == '\0') &&
               (cVar4 = func_0x00018016b240(arg1, &var_60h, puVar3 + 4), cVar4 == '\0')) {
                bVar2 = false;
            } else {
                bVar2 = true;
            }
            if (0xf < (uint64_t)var_48h) {
                uVar9 = var_48h + 1;
                iVar8 = var_60h;
                if (0xfff < uVar9) {
                    if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180083a65;
                    uVar9 = var_48h + 0x28;
                    iVar8 = *(int64_t *)(var_60h + -8);
                }
                fcn.180459c3c(iVar8, uVar9);
            }
            if (bVar2) {
                var_50h = 10;
                var_48h = 0xf;
                var_58h._0_2_ = 0x746e;
                var_60h = 0x6567412d72657355;
                var_58h._2_6_ = 0;
                uVar6 = func_0x00018004a200(arg1, &var_60h);
                func_0x00018000f180(uVar6, 0x18063d850, 8);
                if (0xf < (uint64_t)var_48h) {
                    func_0x000180005a60(&var_60h, var_60h);
                }
            }
            _var_60h = ZEXT816(0);
            var_50h = 0;
            var_48h = 0;
            puVar7 = (undefined4 *)fcn.180459890(0x20);
            var_60h = (int64_t)puVar7;
            var_50h = 0x14;
            var_48h = 0x1f;
            *puVar7 = 0x696c6553;
            puVar7[1] = 0x65726177;
            puVar7[2] = 0x6e69462d;
            puVar7[3] = 0x70726567;
            puVar7[4] = 0x746e6972;
            *(undefined *)(puVar7 + 5) = 0;
            puVar5 = (undefined8 *)(*(undefined8 **)arg1)[1];
            cVar4 = *(char *)((int64_t)puVar5 + 0x19);
            puVar3 = *(undefined8 **)arg1;
            while (cVar4 == '\0') {
                cVar4 = func_0x00018016b240(arg1, puVar5 + 4, &var_60h);
                if (cVar4 == '\0') {
                    puVar11 = (undefined8 *)*puVar5;
                } else {
                    puVar11 = (undefined8 *)puVar5[2];
                    puVar5 = puVar3;
                }
                puVar3 = puVar5;
                puVar5 = puVar11;
                cVar4 = *(char *)((int64_t)puVar11 + 0x19);
            }
            if ((*(char *)((int64_t)puVar3 + 0x19) == '\0') &&
               (cVar4 = func_0x00018016b240(arg1, &var_60h, puVar3 + 4), cVar4 == '\0')) {
                bVar2 = false;
            } else {
                bVar2 = true;
            }
            if (0xf < (uint64_t)var_48h) {
                uVar9 = var_48h + 1;
                iVar8 = var_60h;
                if (0xfff < uVar9) {
                    if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180083a65;
                    uVar9 = var_48h + 0x28;
                    iVar8 = *(int64_t *)(var_60h + -8);
                }
                fcn.180459c3c(iVar8, uVar9);
            }
            if (bVar2) {
                _var_60h = ZEXT816(0);
                var_50h = 0;
                var_48h = 0;
                fcn.180004830(&var_60h, 0x18063d838, 0x14);
                uVar6 = func_0x00018004a200(arg1, &var_60h);
                func_0x000180018940(uVar6, ppiVar13);
                if (0xf < (uint64_t)var_48h) {
                    uVar9 = var_48h + 1;
                    iVar8 = var_60h;
                    if (0xfff < uVar9) {
                        if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180083a65;
                        uVar9 = var_48h + 0x28;
                        iVar8 = *(int64_t *)(var_60h + -8);
                    }
                    fcn.180459c3c(iVar8, uVar9);
                }
            }
            _var_60h = ZEXT816(0);
            var_50h = 0;
            var_48h = 0;
            puVar7 = (undefined4 *)fcn.180459890(0x20);
            var_60h = (int64_t)puVar7;
            var_50h = 0x18;
            var_48h = 0x1f;
            *puVar7 = 0x696c6553;
            puVar7[1] = 0x65726177;
            puVar7[2] = 0x6573552d;
            puVar7[3] = 0x64492d72;
            *(undefined8 *)(puVar7 + 4) = 0x7265696669746e65;
            *(undefined *)(puVar7 + 6) = 0;
            puVar5 = (undefined8 *)(*(undefined8 **)arg1)[1];
            cVar4 = *(char *)((int64_t)puVar5 + 0x19);
            puVar3 = *(undefined8 **)arg1;
            while (cVar4 == '\0') {
                cVar4 = func_0x00018016b240(arg1, puVar5 + 4, &var_60h);
                if (cVar4 == '\0') {
                    puVar11 = (undefined8 *)*puVar5;
                } else {
                    puVar11 = (undefined8 *)puVar5[2];
                    puVar5 = puVar3;
                }
                puVar3 = puVar5;
                puVar5 = puVar11;
                cVar4 = *(char *)((int64_t)puVar11 + 0x19);
            }
            if ((*(char *)((int64_t)puVar3 + 0x19) == '\0') &&
               (cVar4 = func_0x00018016b240(arg1, &var_60h, puVar3 + 4), cVar4 == '\0')) {
                bVar2 = false;
            } else {
                bVar2 = true;
            }
            if (0xf < (uint64_t)var_48h) {
                uVar9 = var_48h + 1;
                iVar8 = var_60h;
                if (0xfff < uVar9) {
                    if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180083a65;
                    uVar9 = var_48h + 0x28;
                    iVar8 = *(int64_t *)(var_60h + -8);
                }
                fcn.180459c3c(iVar8, uVar9);
            }
            puVar12 = auStack_88;
            if (bVar2) {
                _var_60h = ZEXT816(0);
                var_50h = 0;
                var_48h = 0;
                fcn.180004830(&var_60h, 0x18063d818, 0x18);
                uVar6 = func_0x00018004a200(arg1, &var_60h);
                func_0x000180018940(uVar6, ppiVar13);
                puVar12 = auStack_88;
                if (0xf < (uint64_t)var_48h) {
                    func_0x000180005a60(&var_60h, var_60h);
                    puVar12 = auStack_88;
                }
            }
            goto code_r0x000180083a74;
        }
        var_58h = 0x746e;
        var_60h = 0x6567412d72657355;
        cVar4 = func_0x0001800847f0(arg1, &var_60h);
        if ((uint64_t)var_48h < 0x10) {
code_r0x000180083795:
            if (cVar4 == '\0') {
                var_50h = 10;
                var_48h = 0xf;
                var_58h._0_2_ = 0x746e;
                var_60h = 0x6567412d72657355;
                var_58h._2_6_ = 0;
                uVar6 = func_0x00018004a200(arg1, &var_60h);
                func_0x00018000f180(uVar6, 0x1805ab2d0, 6);
                if (0xf < (uint64_t)var_48h) {
                    uVar9 = var_48h + 1;
                    iVar8 = var_60h;
                    if (0xfff < uVar9) {
                        if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180083a65;
                        uVar9 = var_48h + 0x28;
                        iVar8 = *(int64_t *)(var_60h + -8);
                    }
                    fcn.180459c3c(iVar8, uVar9);
                }
            }
            _var_60h = ZEXT816(0);
            var_50h = 0;
            var_48h = 0;
            var_68h = 0x1f;
            puVar7 = (undefined4 *)func_0x000180004930(&var_60h, &var_68h);
            var_60h = (int64_t)puVar7;
            var_50h = 0x12;
            var_48h = var_68h;
            *puVar7 = 0x6964614d;
            puVar7[1] = 0x462d6d75;
            puVar7[2] = 0x65676e69;
            puVar7[3] = 0x69727072;
            *(undefined2 *)(puVar7 + 4) = 0x746e;
            *(undefined *)((int64_t)puVar7 + 0x12) = 0;
            cVar4 = func_0x0001800847f0(arg1, &var_60h);
            if (0xf < (uint64_t)var_48h) {
                uVar9 = var_48h + 1;
                iVar8 = var_60h;
                if (0xfff < uVar9) {
                    if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180083a65;
                    uVar9 = var_48h + 0x28;
                    iVar8 = *(int64_t *)(var_60h + -8);
                }
                fcn.180459c3c(iVar8, uVar9);
            }
            if (cVar4 == '\0') {
                _var_60h = ZEXT816(0);
                var_50h = 0;
                var_48h = 0;
                fcn.180004830(&var_60h, 0x18063d800, 0x12);
                uVar6 = func_0x00018004a200(arg1, &var_60h);
                func_0x000180018940(uVar6, ppiVar13);
                if (0xf < (uint64_t)var_48h) {
                    uVar9 = var_48h + 1;
                    iVar8 = var_60h;
                    if (0xfff < uVar9) {
                        if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180083a65;
                        uVar9 = var_48h + 0x28;
                        iVar8 = *(int64_t *)(var_60h + -8);
                    }
                    fcn.180459c3c(iVar8, uVar9);
                }
            }
            _var_60h = ZEXT816(0);
            var_50h = 0;
            var_48h = 0;
            var_68h = 0x1f;
            puVar7 = (undefined4 *)func_0x000180004930(&var_60h, &var_68h);
            var_60h = (int64_t)puVar7;
            var_50h = 0x16;
            var_48h = var_68h;
            *puVar7 = 0x6964614d;
            puVar7[1] = 0x552d6d75;
            puVar7[2] = 0x2d726573;
            puVar7[3] = 0x6e656449;
            *(undefined8 *)((int64_t)puVar7 + 0xe) = 0x7265696669746e65;
            *(undefined *)((int64_t)puVar7 + 0x16) = 0;
            cVar4 = func_0x0001800847f0(arg1, &var_60h);
            if (0xf < (uint64_t)var_48h) {
                uVar9 = var_48h + 1;
                iVar8 = var_60h;
                if (0xfff < uVar9) {
                    if (0x1f < (var_60h - *(int64_t *)(var_60h + -8)) - 8U) goto code_r0x000180083a65;
                    uVar9 = var_48h + 0x28;
                    iVar8 = *(int64_t *)(var_60h + -8);
                }
                fcn.180459c3c(iVar8, uVar9);
            }
            puVar12 = auStack_88;
            if (cVar4 != '\0') goto code_r0x000180083a74;
            _var_60h = ZEXT816(0);
            var_50h = 0;
            var_48h = 0;
            fcn.180004830(&var_60h, 0x18063d860, 0x16);
            uVar6 = func_0x00018004a200(arg1, &var_60h);
            func_0x000180018940(uVar6, ppiVar13);
            goto code_r0x000180083a34;
        }
        uVar9 = var_48h + 1;
        iVar8 = var_60h;
        if (uVar9 < 0x1000) {
code_r0x00018008378d:
            fcn.180459c3c(iVar8, uVar9);
            goto code_r0x000180083795;
        }
        if ((var_60h - *(int64_t *)(var_60h + -8)) - 8U < 0x20) {
            uVar9 = var_48h + 0x28;
            iVar8 = *(int64_t *)(var_60h + -8);
            goto code_r0x00018008378d;
        }
code_r0x000180083a65:
        pcVar1 = (code *)swi(0x29);
        iVar8 = (*pcVar1)(5);
        puVar12 = auStack_80;
    }
    *(undefined8 *)(puVar12 + -8) = 0x180083a74;
    fcn.180459c3c(iVar8);
code_r0x000180083a74:
    *(undefined8 *)(puVar12 + -8) = 0x180083a80;
    fcn.180459870(var_40h ^ (uint64_t)puVar12);
    return;
}

// ============================================================
// Function: FUN_180083a90
// Address: 0x180083a90
// Size: 807 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_56h

int64_t fcn.180083a90(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                     undefined8 placeholder_6, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    uint64_t *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    code *pcVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t *piVar11;
    undefined *puVar12;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_88 [8];
    undefined auStack_80 [32];
    int64_t var_60h;
    
    puVar12 = auStack_88;
    iVar8 = func_0x00018000b4d0(&var_60h);
    fcn.180082e00(arg1, iVar8);
    *(undefined (*) [16])(arg1 + 0x30) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x40) = 0;
    *(undefined8 *)(arg1 + 0x48) = 0xf;
    *(undefined *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0x1804a5710;
    *(undefined *)(arg1 + 0x50) = *(undefined *)arg3;
    uVar2 = *(undefined8 *)(arg3 + 0x18);
    *(undefined8 *)(arg3 + 0x18) = 0;
    uVar3 = *(undefined8 *)(arg3 + 0x10);
    *(undefined8 *)(arg3 + 0x10) = 0;
    uVar4 = *(undefined8 *)(arg3 + 8);
    *(undefined8 *)(arg3 + 8) = 0;
    *(undefined8 *)(arg1 + 0x58) = uVar4;
    *(undefined8 *)(arg1 + 0x60) = uVar3;
    *(undefined8 *)(arg1 + 0x68) = uVar2;
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined8 *)(arg1 + 0x78) = 0;
    iVar8 = fcn.180459890(0x60);
    *(int64_t *)iVar8 = iVar8;
    *(int64_t *)(iVar8 + 8) = iVar8;
    *(int64_t *)(iVar8 + 0x10) = iVar8;
    *(undefined2 *)(iVar8 + 0x18) = 0x101;
    *(int64_t *)(arg1 + 0x70) = iVar8;
    *(undefined8 *)(arg1 + 0x70) = *(undefined8 *)arg4;
    *(int64_t *)arg4 = iVar8;
    uVar2 = *(undefined8 *)(arg1 + 0x78);
    *(undefined8 *)(arg1 + 0x78) = *(undefined8 *)(arg4 + 8);
    *(undefined8 *)(arg4 + 8) = uVar2;
    puVar1 = (uint64_t *)(arg2 + 0x10);
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    if (10 < *puVar1) {
        func_0x0001804581c0(arg2, arg2 + *puVar1, 0x18063d878, 0xb);
    }
    fcn.180082f70(arg1 + 0x70, arg_28h & 0xffffffff);
    piVar11 = *(int64_t **)(arg3 + 8);
    if (piVar11 != (int64_t *)0x0) {
        piVar5 = *(int64_t **)(arg3 + 0x10);
        for (; piVar11 != piVar5; piVar11 = piVar11 + 0x13) {
            uVar6 = piVar11[0x10];
            if (0xf < uVar6) {
                iVar8 = piVar11[0xd];
                uVar10 = uVar6 + 1;
                if (0xfff < uVar10) {
                    if (0x1f < (iVar8 - *(int64_t *)(iVar8 + -8)) - 8U) goto code_r0x000180083d68;
                    uVar10 = uVar6 + 0x28;
                    iVar8 = *(int64_t *)(iVar8 + -8);
                }
                fcn.180459c3c(iVar8, uVar10);
            }
            piVar11[0xf] = 0;
            piVar11[0x10] = 0xf;
            *(undefined *)(piVar11 + 0xd) = 0;
            uVar6 = piVar11[0xb];
            if (0xf < uVar6) {
                iVar8 = piVar11[8];
                uVar10 = uVar6 + 1;
                if (0xfff < uVar10) {
                    if (0x1f < (iVar8 - *(int64_t *)(iVar8 + -8)) - 8U) goto code_r0x000180083d68;
                    uVar10 = uVar6 + 0x28;
                    iVar8 = *(int64_t *)(iVar8 + -8);
                }
                fcn.180459c3c(iVar8, uVar10);
            }
            piVar11[10] = 0;
            piVar11[0xb] = 0xf;
            *(undefined *)(piVar11 + 8) = 0;
            uVar6 = piVar11[7];
            if (0xf < uVar6) {
                iVar8 = piVar11[4];
                uVar10 = uVar6 + 1;
                if (0xfff < uVar10) {
                    if (0x1f < (iVar8 - *(int64_t *)(iVar8 + -8)) - 8U) goto code_r0x000180083d68;
                    uVar10 = uVar6 + 0x28;
                    iVar8 = *(int64_t *)(iVar8 + -8);
                }
                fcn.180459c3c(iVar8, uVar10);
            }
            piVar11[6] = 0;
            piVar11[7] = 0xf;
            *(undefined *)(piVar11 + 4) = 0;
            uVar6 = piVar11[3];
            if (0xf < uVar6) {
                iVar8 = *piVar11;
                uVar10 = uVar6 + 1;
                if (0xfff < uVar10) {
                    if (0x1f < (iVar8 - *(int64_t *)(iVar8 + -8)) - 8U) goto code_r0x000180083d68;
                    uVar10 = uVar6 + 0x28;
                    iVar8 = *(int64_t *)(iVar8 + -8);
                }
                fcn.180459c3c(iVar8, uVar10);
            }
            piVar11[2] = 0;
            piVar11[3] = 0xf;
            *(undefined *)piVar11 = 0;
        }
        iVar8 = *(int64_t *)(arg3 + 8);
        iVar9 = iVar8;
        puVar12 = auStack_88;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg3 + 0x18) - iVar8 >> 3) * 8)) &&
           (iVar9 = *(int64_t *)(iVar8 + -8), puVar12 = auStack_88, 0x1f < (iVar8 - iVar9) - 8U)) {
code_r0x000180083d68:
            iVar9 = 5;
            pcVar7 = (code *)swi(0x29);
            (*pcVar7)(5);
            puVar12 = auStack_80;
        }
        *(undefined8 *)(puVar12 + -8) = 0x180083d7a;
        fcn.180459c3c(iVar9);
        *(undefined8 *)(arg3 + 8) = 0;
        *(undefined8 *)(arg3 + 0x10) = 0;
        *(undefined8 *)(arg3 + 0x18) = 0;
    }
    uVar2 = *(undefined8 *)(*(int64_t *)arg4 + 8);
    *(undefined8 *)(puVar12 + -8) = 0x180083d98;
    func_0x000180015170(arg4, arg4, uVar2);
    uVar2 = *(undefined8 *)arg4;
    *(undefined8 *)(puVar12 + -8) = 0x180083da5;
    fcn.180459c3c(uVar2, 0x60);
    return arg1;
}

// ============================================================
// Function: FUN_180083dc0
// Address: 0x180083dc0
// Size: 1214 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_56h

void fcn.180083dc0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    int64_t iVar15;
    int64_t iVar16;
    uint64_t uVar17;
    int64_t *piVar18;
    undefined *puVar19;
    undefined8 uStack_f0;
    undefined auStack_e8 [8];
    undefined auStack_e0 [32];
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar19 = auStack_e8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    var_90h = arg_28h;
    var_a0h = arg1;
    var_98h = arg4;
    var_88h = arg2;
    var_80h = arg3;
    iVar15 = func_0x00018000b4d0(&var_c0h);
    fcn.180082e00(arg1, iVar15);
    uVar7 = *(undefined4 *)arg3;
    uVar8 = *(undefined4 *)(arg3 + 4);
    uVar9 = *(undefined4 *)(arg3 + 8);
    uVar10 = *(undefined4 *)(arg3 + 0xc);
    uVar11 = *(undefined4 *)(arg3 + 0x10);
    uVar12 = *(undefined4 *)(arg3 + 0x14);
    uVar13 = *(undefined4 *)(arg3 + 0x18);
    uVar14 = *(undefined4 *)(arg3 + 0x1c);
    *(undefined8 *)(arg3 + 0x10) = 0;
    *(undefined8 *)(arg3 + 0x18) = 0xf;
    *(undefined *)arg3 = 0;
    *(undefined4 *)(arg1 + 0x30) = uVar7;
    *(undefined4 *)(arg1 + 0x34) = uVar8;
    *(undefined4 *)(arg1 + 0x38) = uVar9;
    *(undefined4 *)(arg1 + 0x3c) = uVar10;
    *(undefined4 *)(arg1 + 0x40) = uVar11;
    *(undefined4 *)(arg1 + 0x44) = uVar12;
    *(undefined4 *)(arg1 + 0x48) = uVar13;
    *(undefined4 *)(arg1 + 0x4c) = uVar14;
    *(undefined8 *)(arg1 + 0x28) = 0x1804a5710;
    *(undefined *)(arg1 + 0x50) = *(undefined *)arg4;
    uVar1 = *(undefined8 *)(arg4 + 0x18);
    *(undefined8 *)(arg4 + 0x18) = 0;
    uVar2 = *(undefined8 *)(arg4 + 0x10);
    *(undefined8 *)(arg4 + 0x10) = 0;
    uVar3 = *(undefined8 *)(arg4 + 8);
    *(undefined8 *)(arg4 + 8) = 0;
    *(undefined8 *)(arg1 + 0x58) = uVar3;
    *(undefined8 *)(arg1 + 0x60) = uVar2;
    *(undefined8 *)(arg1 + 0x68) = uVar1;
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined8 *)(arg1 + 0x78) = 0;
    iVar15 = fcn.180459890(0x60);
    *(int64_t *)iVar15 = iVar15;
    *(int64_t *)(iVar15 + 8) = iVar15;
    *(int64_t *)(iVar15 + 0x10) = iVar15;
    *(undefined2 *)(iVar15 + 0x18) = 0x101;
    *(int64_t *)(arg1 + 0x70) = iVar15;
    *(undefined8 *)(arg1 + 0x70) = *(undefined8 *)arg_28h;
    *(int64_t *)arg_28h = iVar15;
    uVar1 = *(undefined8 *)(arg1 + 0x78);
    *(undefined8 *)(arg1 + 0x78) = *(undefined8 *)(arg_28h + 8);
    *(undefined8 *)(arg_28h + 8) = uVar1;
    iVar15 = arg2;
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        iVar15 = *(int64_t *)arg2;
    }
    if (10 < *(uint64_t *)(arg2 + 0x10)) {
        func_0x0001804581c0(iVar15, *(uint64_t *)(arg2 + 0x10) + iVar15, 0x18063d878, 0xb);
    }
    fcn.180082f70(arg1 + 0x70, arg_30h & 0xffffffff);
    var_c0h._0_4_ = *(undefined4 *)arg2;
    var_c0h._4_4_ = *(undefined4 *)(arg2 + 4);
    var_b8h._0_4_ = *(undefined4 *)(arg2 + 8);
    var_b8h._4_4_ = *(undefined4 *)(arg2 + 0xc);
    _var_70h = *(undefined (*) [16])arg2;
    var_60h = *(int64_t *)(arg2 + 0x10);
    var_58h = *(int64_t *)(arg2 + 0x18);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    var_78h = 0x1804a56f0;
    func_0x000180012c10(arg1 + 8, &var_70h);
    if (0xf < (uint64_t)var_58h) {
        iVar15 = var_70h;
        puVar19 = auStack_e8;
        if ((0xfff < var_58h + 1U) &&
           (iVar15 = *(int64_t *)(var_70h + -8), puVar19 = auStack_e8, 0x1f < (var_70h - iVar15) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar15 = (*pcVar6)(5);
            puVar19 = auStack_e0;
        }
        *(undefined8 *)(puVar19 + -8) = 0x180083fd2;
        fcn.180459c3c(iVar15);
    }
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        iVar15 = *(int64_t *)arg2;
        iVar16 = iVar15;
        if ((0xfff < *(uint64_t *)(arg2 + 0x18) + 1) &&
           (iVar16 = *(int64_t *)(iVar15 + -8), 0x1f < (iVar15 - iVar16) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar16 = (*pcVar6)(5);
            puVar19 = puVar19 + 8;
        }
        *(undefined8 *)(puVar19 + -8) = 0x180084012;
        fcn.180459c3c(iVar16);
    }
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    if (0xf < *(uint64_t *)(arg3 + 0x18)) {
        iVar15 = *(int64_t *)arg3;
        iVar16 = iVar15;
        if ((0xfff < *(uint64_t *)(arg3 + 0x18) + 1) &&
           (iVar16 = *(int64_t *)(iVar15 + -8), 0x1f < (iVar15 - iVar16) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar16 = (*pcVar6)(5);
            puVar19 = puVar19 + 8;
        }
        *(undefined8 *)(puVar19 + -8) = 0x180084060;
        fcn.180459c3c(iVar16);
    }
    *(undefined8 *)(arg3 + 0x10) = 0;
    *(undefined8 *)(arg3 + 0x18) = 0xf;
    *(undefined *)arg3 = 0;
    piVar18 = *(int64_t **)(arg4 + 8);
    if (piVar18 != (int64_t *)0x0) {
        piVar4 = *(int64_t **)(arg4 + 0x10);
        for (; piVar18 != piVar4; piVar18 = piVar18 + 0x13) {
            uVar5 = piVar18[0x10];
            if (0xf < uVar5) {
                iVar15 = piVar18[0xd];
                uVar17 = uVar5 + 1;
                if (0xfff < uVar17) {
                    if (0x1f < (iVar15 - *(int64_t *)(iVar15 + -8)) - 8U) goto code_r0x000180084218;
                    uVar17 = uVar5 + 0x28;
                    iVar15 = *(int64_t *)(iVar15 + -8);
                }
                *(undefined8 *)(puVar19 + -8) = 0x1800840d0;
                fcn.180459c3c(iVar15, uVar17);
            }
            piVar18[0xf] = 0;
            piVar18[0x10] = 0xf;
            *(undefined *)(piVar18 + 0xd) = 0;
            uVar5 = piVar18[0xb];
            if (0xf < uVar5) {
                iVar15 = piVar18[8];
                uVar17 = uVar5 + 1;
                if (0xfff < uVar17) {
                    if (0x1f < (iVar15 - *(int64_t *)(iVar15 + -8)) - 8U) goto code_r0x000180084218;
                    uVar17 = uVar5 + 0x28;
                    iVar15 = *(int64_t *)(iVar15 + -8);
                }
                *(undefined8 *)(puVar19 + -8) = 0x180084120;
                fcn.180459c3c(iVar15, uVar17);
            }
            piVar18[10] = 0;
            piVar18[0xb] = 0xf;
            *(undefined *)(piVar18 + 8) = 0;
            uVar5 = piVar18[7];
            if (0xf < uVar5) {
                iVar15 = piVar18[4];
                uVar17 = uVar5 + 1;
                if (0xfff < uVar17) {
                    if (0x1f < (iVar15 - *(int64_t *)(iVar15 + -8)) - 8U) goto code_r0x000180084218;
                    uVar17 = uVar5 + 0x28;
                    iVar15 = *(int64_t *)(iVar15 + -8);
                }
                *(undefined8 *)(puVar19 + -8) = 0x18008416d;
                fcn.180459c3c(iVar15, uVar17);
            }
            piVar18[6] = 0;
            piVar18[7] = 0xf;
            *(undefined *)(piVar18 + 4) = 0;
            uVar5 = piVar18[3];
            if (0xf < uVar5) {
                iVar15 = *piVar18;
                uVar17 = uVar5 + 1;
                if (0xfff < uVar17) {
                    if (0x1f < (iVar15 - *(int64_t *)(iVar15 + -8)) - 8U) goto code_r0x000180084218;
                    uVar17 = uVar5 + 0x28;
                    iVar15 = *(int64_t *)(iVar15 + -8);
                }
                *(undefined8 *)(puVar19 + -8) = 0x1800841b5;
                fcn.180459c3c(iVar15, uVar17);
            }
            piVar18[2] = 0;
            piVar18[3] = 0xf;
            *(undefined *)piVar18 = 0;
        }
        iVar15 = *(int64_t *)(arg4 + 8);
        iVar16 = iVar15;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg4 + 0x18) - iVar15 >> 3) * 8)) &&
           (iVar16 = *(int64_t *)(iVar15 + -8), 0x1f < (iVar15 - iVar16) - 8U)) {
code_r0x000180084218:
            iVar16 = 5;
            pcVar6 = (code *)swi(0x29);
            (*pcVar6)(5);
            puVar19 = puVar19 + 8;
        }
        *(undefined8 *)(puVar19 + -8) = 0x18008422a;
        fcn.180459c3c(iVar16);
        *(undefined8 *)(arg4 + 8) = 0;
        *(undefined8 *)(arg4 + 0x10) = 0;
        *(undefined8 *)(arg4 + 0x18) = 0;
    }
    uVar1 = *(undefined8 *)(*(int64_t *)arg_28h + 8);
    *(undefined8 *)(puVar19 + -8) = 0x180084249;
    func_0x000180015170(arg_28h, arg_28h, uVar1);
    uVar1 = *(undefined8 *)arg_28h;
    *(undefined8 *)(puVar19 + -8) = 0x180084257;
    fcn.180459c3c(uVar1, 0x60);
    *(undefined8 *)(puVar19 + -8) = 0x18008426a;
    fcn.180459870(*(uint64_t *)(puVar19 + 0x98) ^ (uint64_t)puVar19);
    return;
}

// ============================================================
// Function: FUN_180084280
// Address: 0x180084280
// Size: 1380 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_298h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a0h

void fcn.180084280(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined auVar1 [16];
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined auVar4 [16];
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined auVar8 [16];
    undefined auVar9 [16];
    undefined auVar10 [16];
    undefined auVar11 [16];
    undefined auVar12 [16];
    undefined auVar13 [16];
    int64_t iVar14;
    int32_t iVar15;
    int64_t var_18h;
    undefined auStack_3d8 [48];
    int64_t var_3a8h;
    int64_t var_388h;
    int64_t var_378h;
    int64_t var_370h;
    int64_t var_368h;
    int64_t var_358h;
    int64_t var_350h;
    int64_t var_348h;
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_318h;
    int64_t var_310h;
    int64_t var_308h;
    int64_t var_2f8h;
    int64_t var_2f0h;
    int64_t var_2e8h;
    undefined8 uStack_2d8;
    int64_t var_2d0h;
    int64_t var_2c8h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    undefined var_2a0h;
    int64_t var_29ch;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1e8h;
    int64_t var_1e0h;
    int64_t var_1d8h;
    int64_t var_1c8h;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_3d8;
    var_378h = 0;
    var_370h = 0xf;
    stack0xfffffffffffffc79 = SUB1615(ZEXT816(0), 1);
    auVar1[15] = 0;
    auVar1._0_15_ = stack0xfffffffffffffc79;
    _var_388h = auVar1 << 8;
    var_358h = 0;
    var_350h = 0xf;
    stack0xfffffffffffffc99 = SUB1615(ZEXT816(0), 1);
    auVar2[15] = 0;
    auVar2._0_15_ = stack0xfffffffffffffc99;
    _var_368h = auVar2 << 8;
    var_338h = 0;
    var_330h = 0xf;
    stack0xfffffffffffffcb9 = SUB1615(ZEXT816(0), 1);
    auVar3[15] = 0;
    auVar3._0_15_ = stack0xfffffffffffffcb9;
    _var_348h = auVar3 << 8;
    var_318h = 0;
    var_310h = 0xf;
    stack0xfffffffffffffcd9 = SUB1615(ZEXT816(0), 1);
    auVar4[15] = 0;
    auVar4._0_15_ = stack0xfffffffffffffcd9;
    _var_328h = auVar4 << 8;
    var_2f8h = 0;
    var_2f0h = 0xf;
    stack0xfffffffffffffcf9 = SUB1615(ZEXT816(0), 1);
    auVar5[15] = 0;
    auVar5._0_15_ = stack0xfffffffffffffcf9;
    _var_308h = auVar5 << 8;
    uStack_2d8 = 0;
    var_2d0h = 0xf;
    stack0xfffffffffffffd19 = SUB1615(ZEXT816(0), 1);
    auVar6[15] = 0;
    auVar6._0_15_ = stack0xfffffffffffffd19;
    _var_2e8h = auVar6 << 8;
    var_2b8h = 0;
    var_2b0h = 0xf;
    stack0xfffffffffffffd39 = SUB1615(ZEXT816(0), 1);
    auVar7[15] = 0;
    auVar7._0_15_ = stack0xfffffffffffffd39;
    _var_2c8h = auVar7 << 8;
    var_2a8h = 0x10101;
    var_29ch._0_4_ = 0x10000;
    var_288h = 0;
    var_280h = 0xf;
    stack0xfffffffffffffd69 = SUB1615(ZEXT816(0), 1);
    auVar8[15] = 0;
    auVar8._0_15_ = stack0xfffffffffffffd69;
    stack0xfffffffffffffd68 = auVar8 << 8;
    var_268h = 0;
    var_260h = 0xf;
    stack0xfffffffffffffd89 = SUB1615(ZEXT816(0), 1);
    auVar9[15] = 0;
    auVar9._0_15_ = stack0xfffffffffffffd89;
    _var_278h = auVar9 << 8;
    var_248h = 0;
    var_240h = 0xf;
    stack0xfffffffffffffda9 = SUB1615(ZEXT816(0), 1);
    auVar10[15] = 0;
    auVar10._0_15_ = stack0xfffffffffffffda9;
    _var_258h = auVar10 << 8;
    var_228h = 0;
    var_220h = 0xf;
    stack0xfffffffffffffdc9 = SUB1615(ZEXT816(0), 1);
    auVar11[15] = 0;
    auVar11._0_15_ = stack0xfffffffffffffdc9;
    _var_238h = auVar11 << 8;
    var_208h = 0;
    var_200h = 0xf;
    stack0xfffffffffffffde9 = SUB1615(ZEXT816(0), 1);
    auVar12[15] = 0;
    auVar12._0_15_ = stack0xfffffffffffffde9;
    _var_218h = auVar12 << 8;
    var_1e8h = 0;
    var_1e0h = 0xf;
    stack0xfffffffffffffe09 = SUB1615(ZEXT816(0), 1);
    auVar13[15] = 0;
    auVar13._0_15_ = stack0xfffffffffffffe09;
    _var_1f8h = auVar13 << 8;
    var_1d8h._0_1_ = 1;
    var_2a0h = 1;
    iVar15 = (int32_t)arg3;
    var_3a8h = arg2;
    if (iVar15 == 1) {
        func_0x00018016c270(&var_1c8h);
        func_0x00018016d270(&var_1c8h, arg1);
        func_0x00018016d1b0(&var_1c8h, arg1 + 0x50);
        func_0x00018016cfc0(&var_1c8h, arg1 + 0x70);
        func_0x00018016cfb0(&var_1c8h, &var_388h);
        func_0x00018016ccb0(&var_1c8h, arg2);
    } else if (iVar15 == 2) {
        func_0x00018016c270(&var_1c8h);
        func_0x00018016d270(&var_1c8h, arg1);
        func_0x00018016d100(&var_1c8h, arg1 + 0x28);
        func_0x00018016d1b0(&var_1c8h, arg1 + 0x50);
        func_0x00018016cfc0(&var_1c8h, arg1 + 0x70);
        func_0x00018016cfb0(&var_1c8h, &var_388h);
        func_0x00018016ce10(&var_1c8h, arg2);
    } else if (iVar15 == 3) {
        func_0x00018016c270(&var_1c8h);
        func_0x00018016d270(&var_1c8h, arg1);
        func_0x00018016d100(&var_1c8h, arg1 + 0x28);
        func_0x00018016d1b0(&var_1c8h, arg1 + 0x50);
        func_0x00018016cfc0(&var_1c8h, arg1 + 0x70);
        func_0x00018016cfb0(&var_1c8h, &var_388h);
        func_0x00018016cd80(&var_1c8h, arg2);
    } else if (iVar15 == 4) {
        func_0x00018016c270(&var_1c8h);
        func_0x00018016d270(&var_1c8h, arg1);
        func_0x00018016d100(&var_1c8h, arg1 + 0x28);
        func_0x00018016d1b0(&var_1c8h, arg1 + 0x50);
        func_0x00018016cfc0(&var_1c8h, arg1 + 0x70);
        func_0x00018016cfb0(&var_1c8h, &var_388h);
        func_0x00018016cee0(&var_1c8h, arg2);
    } else {
        if (iVar15 != 5) {
            fcn.1804986e0(arg2, 0, 0x138);
            *(undefined8 *)arg2 = 0;
            *(undefined8 *)(arg2 + 8) = 0;
            *(undefined4 *)(arg2 + 0x10) = 0;
            *(undefined (*) [16])(arg2 + 0x18) = ZEXT816(0);
            *(undefined8 *)(arg2 + 0x28) = 0;
            *(undefined8 *)(arg2 + 0x30) = 0xf;
            *(undefined *)(arg2 + 0x18) = 0;
            *(undefined8 *)(arg2 + 0x38) = 0;
            *(undefined8 *)(arg2 + 0x40) = 0;
            iVar14 = fcn.180459890(0x60);
            *(int64_t *)iVar14 = iVar14;
            *(int64_t *)(iVar14 + 8) = iVar14;
            *(int64_t *)(iVar14 + 0x10) = iVar14;
            *(undefined2 *)(iVar14 + 0x18) = 0x101;
            *(int64_t *)(arg2 + 0x38) = iVar14;
            *(undefined (*) [16])(arg2 + 0x50) = ZEXT816(0);
            *(undefined8 *)(arg2 + 0x60) = 0;
            *(undefined8 *)(arg2 + 0x68) = 0xf;
            *(undefined *)(arg2 + 0x50) = 0;
            *(undefined8 *)(arg2 + 0x48) = 0x1804a56f0;
            *(undefined8 *)(arg2 + 0x70) = 0;
            *(undefined *)(arg2 + 0x78) = 1;
            *(undefined8 *)(arg2 + 0x80) = 0;
            *(undefined8 *)(arg2 + 0x88) = 0;
            *(undefined8 *)(arg2 + 0x90) = 0;
            *(undefined8 *)(arg2 + 0x98) = 0;
            *(undefined (*) [16])(arg2 + 0xa0) = ZEXT816(0);
            *(undefined8 *)(arg2 + 0xb0) = 0;
            *(undefined8 *)(arg2 + 0xb8) = 0xf;
            *(undefined *)(arg2 + 0xa0) = 0;
            *(undefined (*) [16])(arg2 + 0xc0) = ZEXT816(0);
            *(undefined8 *)(arg2 + 0xd0) = 0;
            *(undefined8 *)(arg2 + 0xd8) = 0xf;
            *(undefined *)(arg2 + 0xc0) = 0;
            *(undefined (*) [16])(arg2 + 0xe0) = ZEXT816(0);
            *(undefined8 *)(arg2 + 0xf0) = 0;
            *(undefined8 *)(arg2 + 0xf8) = 0xf;
            *(undefined *)(arg2 + 0xe0) = 0;
            *(undefined (*) [16])(arg2 + 0x100) = ZEXT816(0);
            *(undefined8 *)(arg2 + 0x110) = 0;
            *(undefined8 *)(arg2 + 0x118) = 0xf;
            *(undefined *)(arg2 + 0x100) = 0;
            *(undefined8 *)(arg2 + 0x120) = 0;
            *(undefined8 *)(arg2 + 0x128) = 0;
            *(undefined4 *)(arg2 + 0x130) = 0;
            goto code_r0x0001800847b1;
        }
        func_0x00018016c270(&var_1c8h);
        func_0x00018016d270(&var_1c8h, arg1);
        func_0x00018016d100(&var_1c8h, arg1 + 0x28);
        func_0x00018016d1b0(&var_1c8h, arg1 + 0x50);
        func_0x00018016cfc0(&var_1c8h, arg1 + 0x70);
        func_0x00018016cfb0(&var_1c8h, &var_388h);
        func_0x00018016cb40(&var_1c8h, arg2);
    }
    func_0x000180084870(&var_1c8h);
code_r0x0001800847b1:
    fcn.180082ea0((int64_t)&var_388h);
    fcn.180459870(var_38h ^ (uint64_t)auStack_3d8);
    return;
}

// ============================================================
// Function: FUN_1800847f0
// Address: 0x1800847f0
// Size: 123 bytes
// ============================================================
undefined fcn.1800847f0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    char cVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    
    piVar1 = (int64_t *)(*(int64_t **)arg1)[1];
    cVar2 = *(char *)((int64_t)piVar1 + 0x19);
    piVar4 = *(int64_t **)arg1;
    while (cVar2 == '\0') {
        cVar2 = func_0x00018016b240(arg1, piVar1 + 4, arg2);
        piVar3 = piVar1;
        if (cVar2 != '\0') {
            piVar3 = piVar4;
        }
        piVar4 = piVar1 + 2;
        if (cVar2 == '\0') {
            piVar4 = piVar1;
        }
        piVar1 = (int64_t *)*piVar4;
        piVar4 = piVar3;
        cVar2 = *(char *)((int64_t)piVar1 + 0x19);
    }
    if ((*(char *)((int64_t)piVar4 + 0x19) == '\0') &&
       (cVar2 = func_0x00018016b240(arg1, arg2, piVar4 + 4), cVar2 == '\0')) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180084870
// Address: 0x180084870
// Size: 740 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180084870(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    char cVar4;
    int64_t *piVar5;
    code *pcVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined *puVar10;
    undefined *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar10 = auStack_38;
    func_0x000180063a10(arg1 + 0x160);
    func_0x000180004e40(arg1 + 0x140);
    func_0x000180004e40(arg1 + 0x120);
    iVar9 = *(int64_t *)(arg1 + 0x110);
    if (iVar9 != 0) {
        piVar5 = *(int64_t **)(iVar9 + 0x178);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar5 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        piVar5 = *(int64_t **)(iVar9 + 0x168);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0x130));
            *(undefined8 *)(iVar9 + 0x168) = 0;
        }
        piVar5 = *(int64_t **)(iVar9 + 0x120);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0xe8));
            *(undefined8 *)(iVar9 + 0x120) = 0;
        }
        piVar5 = *(int64_t **)(iVar9 + 0xd8);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0xa0));
            *(undefined8 *)(iVar9 + 0xd8) = 0;
        }
        piVar5 = *(int64_t **)(iVar9 + 0x90);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0x58));
            *(undefined8 *)(iVar9 + 0x90) = 0;
        }
        piVar5 = *(int64_t **)(iVar9 + 0x48);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0x10));
            *(undefined8 *)(iVar9 + 0x48) = 0;
        }
        fcn.180459c3c(iVar9, 400);
    }
    func_0x00018000ace0(arg1 + 0xe8);
    func_0x00018001f220(arg1 + 0xd8);
    func_0x000180015170(arg1 + 0xc0, arg1 + 0xc0, *(undefined8 *)(*(int64_t *)(arg1 + 0xc0) + 8));
    fcn.180459c3c(*(undefined8 *)(arg1 + 0xc0), 0x60);
    func_0x000180084f60(arg1 + 0xb0, arg1 + 0xb0, *(undefined8 *)(*(int64_t *)(arg1 + 0xb0) + 8));
    fcn.180459c3c(*(undefined8 *)(arg1 + 0xb0), 0x88);
    func_0x000180015170(arg1 + 0xa0, arg1 + 0xa0, *(undefined8 *)(*(int64_t *)(arg1 + 0xa0) + 8));
    fcn.180459c3c(*(undefined8 *)(arg1 + 0xa0), 0x60);
    iVar9 = *(int64_t *)(arg1 + 0x88);
    if (iVar9 == 0) {
code_r0x000180084ad0:
        func_0x000180004e40(arg1 + 0x60);
        piVar5 = *(int64_t **)(arg1 + 0x50);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar5 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        cVar4 = *(char *)(arg1 + 0x40);
        puVar11 = auStack_38;
        if ((cVar4 == -1) || (puVar11 = auStack_38, cVar4 == '\0')) goto code_r0x000180084bcb;
        if (cVar4 != '\x01') {
            if (cVar4 == '\x02') {
                (***(code ***)(arg1 + 0x18))(arg1 + 0x18, 0);
                puVar11 = auStack_38;
            } else {
                func_0x000180084ff0();
                puVar11 = auStack_38;
            }
            goto code_r0x000180084bcb;
        }
        iVar9 = *(int64_t *)(arg1 + 0x20);
        puVar11 = auStack_38;
        if (iVar9 == 0) goto code_r0x000180084bcb;
        iVar7 = *(int64_t *)(arg1 + 0x28);
        for (; iVar9 != iVar7; iVar9 = iVar9 + 0x40) {
            func_0x000180004e40(iVar9 + 0x20);
            func_0x000180004e40(iVar9);
        }
        iVar9 = *(int64_t *)(arg1 + 0x20);
        if ((0xfff < (*(int64_t *)(arg1 + 0x30) - iVar9 & 0xffffffffffffffc0U)) &&
           (iVar7 = iVar9 - *(int64_t *)(iVar9 + -8), iVar9 = *(int64_t *)(iVar9 + -8), puVar10 = auStack_38,
           0x1f < iVar7 - 8U)) goto code_r0x000180084bb0;
    } else {
        iVar7 = *(int64_t *)(arg1 + 0x90);
        for (; iVar9 != iVar7; iVar9 = iVar9 + 0x40) {
            func_0x000180004e40(iVar9 + 0x20);
            func_0x000180004e40(iVar9);
        }
        iVar9 = *(int64_t *)(arg1 + 0x88);
        uVar8 = *(int64_t *)(arg1 + 0x98) - iVar9 & 0xffffffffffffffc0;
        if (uVar8 < 0x1000) {
code_r0x000180084ab6:
            fcn.180459c3c(iVar9, uVar8);
            *(undefined8 *)(arg1 + 0x88) = 0;
            *(undefined8 *)(arg1 + 0x90) = 0;
            *(undefined8 *)(arg1 + 0x98) = 0;
            goto code_r0x000180084ad0;
        }
        if ((iVar9 - *(int64_t *)(iVar9 + -8)) - 8U < 0x20) {
            uVar8 = uVar8 + 0x27;
            iVar9 = *(int64_t *)(iVar9 + -8);
            goto code_r0x000180084ab6;
        }
code_r0x000180084bb0:
        pcVar6 = (code *)swi(0x29);
        iVar9 = (*pcVar6)(5);
        puVar10 = auStack_30;
    }
    *(undefined8 *)(puVar10 + -8) = 0x180084bbf;
    fcn.180459c3c(iVar9);
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    puVar11 = puVar10;
code_r0x000180084bcb:
    piVar5 = *(int64_t **)(arg1 + 8);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            pcVar6 = *(code **)(*piVar5 + 8);
            *(undefined8 *)(puVar11 + -8) = 0x180084be4;
            (*pcVar6)();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180084b54
// Address: 0x180084b54
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180084870(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    char cVar4;
    int64_t *piVar5;
    code *pcVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined *puVar10;
    undefined *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar10 = auStack_38;
    func_0x000180063a10(arg1 + 0x160);
    func_0x000180004e40(arg1 + 0x140);
    func_0x000180004e40(arg1 + 0x120);
    iVar9 = *(int64_t *)(arg1 + 0x110);
    if (iVar9 != 0) {
        piVar5 = *(int64_t **)(iVar9 + 0x178);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar5 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        piVar5 = *(int64_t **)(iVar9 + 0x168);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0x130));
            *(undefined8 *)(iVar9 + 0x168) = 0;
        }
        piVar5 = *(int64_t **)(iVar9 + 0x120);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0xe8));
            *(undefined8 *)(iVar9 + 0x120) = 0;
        }
        piVar5 = *(int64_t **)(iVar9 + 0xd8);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0xa0));
            *(undefined8 *)(iVar9 + 0xd8) = 0;
        }
        piVar5 = *(int64_t **)(iVar9 + 0x90);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0x58));
            *(undefined8 *)(iVar9 + 0x90) = 0;
        }
        piVar5 = *(int64_t **)(iVar9 + 0x48);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0x10));
            *(undefined8 *)(iVar9 + 0x48) = 0;
        }
        fcn.180459c3c(iVar9, 400);
    }
    func_0x00018000ace0(arg1 + 0xe8);
    func_0x00018001f220(arg1 + 0xd8);
    func_0x000180015170(arg1 + 0xc0, arg1 + 0xc0, *(undefined8 *)(*(int64_t *)(arg1 + 0xc0) + 8));
    fcn.180459c3c(*(undefined8 *)(arg1 + 0xc0), 0x60);
    func_0x000180084f60(arg1 + 0xb0, arg1 + 0xb0, *(undefined8 *)(*(int64_t *)(arg1 + 0xb0) + 8));
    fcn.180459c3c(*(undefined8 *)(arg1 + 0xb0), 0x88);
    func_0x000180015170(arg1 + 0xa0, arg1 + 0xa0, *(undefined8 *)(*(int64_t *)(arg1 + 0xa0) + 8));
    fcn.180459c3c(*(undefined8 *)(arg1 + 0xa0), 0x60);
    iVar9 = *(int64_t *)(arg1 + 0x88);
    if (iVar9 == 0) {
code_r0x000180084ad0:
        func_0x000180004e40(arg1 + 0x60);
        piVar5 = *(int64_t **)(arg1 + 0x50);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar5 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        cVar4 = *(char *)(arg1 + 0x40);
        puVar11 = auStack_38;
        if ((cVar4 == -1) || (puVar11 = auStack_38, cVar4 == '\0')) goto code_r0x000180084bcb;
        if (cVar4 != '\x01') {
            if (cVar4 == '\x02') {
                (***(code ***)(arg1 + 0x18))(arg1 + 0x18, 0);
                puVar11 = auStack_38;
            } else {
                func_0x000180084ff0();
                puVar11 = auStack_38;
            }
            goto code_r0x000180084bcb;
        }
        iVar9 = *(int64_t *)(arg1 + 0x20);
        puVar11 = auStack_38;
        if (iVar9 == 0) goto code_r0x000180084bcb;
        iVar7 = *(int64_t *)(arg1 + 0x28);
        for (; iVar9 != iVar7; iVar9 = iVar9 + 0x40) {
            func_0x000180004e40(iVar9 + 0x20);
            func_0x000180004e40(iVar9);
        }
        iVar9 = *(int64_t *)(arg1 + 0x20);
        if ((0xfff < (*(int64_t *)(arg1 + 0x30) - iVar9 & 0xffffffffffffffc0U)) &&
           (iVar7 = iVar9 - *(int64_t *)(iVar9 + -8), iVar9 = *(int64_t *)(iVar9 + -8), puVar10 = auStack_38,
           0x1f < iVar7 - 8U)) goto code_r0x000180084bb0;
    } else {
        iVar7 = *(int64_t *)(arg1 + 0x90);
        for (; iVar9 != iVar7; iVar9 = iVar9 + 0x40) {
            func_0x000180004e40(iVar9 + 0x20);
            func_0x000180004e40(iVar9);
        }
        iVar9 = *(int64_t *)(arg1 + 0x88);
        uVar8 = *(int64_t *)(arg1 + 0x98) - iVar9 & 0xffffffffffffffc0;
        if (uVar8 < 0x1000) {
code_r0x000180084ab6:
            fcn.180459c3c(iVar9, uVar8);
            *(undefined8 *)(arg1 + 0x88) = 0;
            *(undefined8 *)(arg1 + 0x90) = 0;
            *(undefined8 *)(arg1 + 0x98) = 0;
            goto code_r0x000180084ad0;
        }
        if ((iVar9 - *(int64_t *)(iVar9 + -8)) - 8U < 0x20) {
            uVar8 = uVar8 + 0x27;
            iVar9 = *(int64_t *)(iVar9 + -8);
            goto code_r0x000180084ab6;
        }
code_r0x000180084bb0:
        pcVar6 = (code *)swi(0x29);
        iVar9 = (*pcVar6)(5);
        puVar10 = auStack_30;
    }
    *(undefined8 *)(puVar10 + -8) = 0x180084bbf;
    fcn.180459c3c(iVar9);
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    puVar11 = puVar10;
code_r0x000180084bcb:
    piVar5 = *(int64_t **)(arg1 + 8);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            pcVar6 = *(code **)(*piVar5 + 8);
            *(undefined8 *)(puVar11 + -8) = 0x180084be4;
            (*pcVar6)();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180084b99
// Address: 0x180084b99
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180084870(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    char cVar4;
    int64_t *piVar5;
    code *pcVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined *puVar10;
    undefined *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar10 = auStack_38;
    func_0x000180063a10(arg1 + 0x160);
    func_0x000180004e40(arg1 + 0x140);
    func_0x000180004e40(arg1 + 0x120);
    iVar9 = *(int64_t *)(arg1 + 0x110);
    if (iVar9 != 0) {
        piVar5 = *(int64_t **)(iVar9 + 0x178);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar5 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        piVar5 = *(int64_t **)(iVar9 + 0x168);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0x130));
            *(undefined8 *)(iVar9 + 0x168) = 0;
        }
        piVar5 = *(int64_t **)(iVar9 + 0x120);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0xe8));
            *(undefined8 *)(iVar9 + 0x120) = 0;
        }
        piVar5 = *(int64_t **)(iVar9 + 0xd8);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0xa0));
            *(undefined8 *)(iVar9 + 0xd8) = 0;
        }
        piVar5 = *(int64_t **)(iVar9 + 0x90);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0x58));
            *(undefined8 *)(iVar9 + 0x90) = 0;
        }
        piVar5 = *(int64_t **)(iVar9 + 0x48);
        if (piVar5 != (int64_t *)0x0) {
            (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar9 + 0x10));
            *(undefined8 *)(iVar9 + 0x48) = 0;
        }
        fcn.180459c3c(iVar9, 400);
    }
    func_0x00018000ace0(arg1 + 0xe8);
    func_0x00018001f220(arg1 + 0xd8);
    func_0x000180015170(arg1 + 0xc0, arg1 + 0xc0, *(undefined8 *)(*(int64_t *)(arg1 + 0xc0) + 8));
    fcn.180459c3c(*(undefined8 *)(arg1 + 0xc0), 0x60);
    func_0x000180084f60(arg1 + 0xb0, arg1 + 0xb0, *(undefined8 *)(*(int64_t *)(arg1 + 0xb0) + 8));
    fcn.180459c3c(*(undefined8 *)(arg1 + 0xb0), 0x88);
    func_0x000180015170(arg1 + 0xa0, arg1 + 0xa0, *(undefined8 *)(*(int64_t *)(arg1 + 0xa0) + 8));
    fcn.180459c3c(*(undefined8 *)(arg1 + 0xa0), 0x60);
    iVar9 = *(int64_t *)(arg1 + 0x88);
    if (iVar9 == 0) {
code_r0x000180084ad0:
        func_0x000180004e40(arg1 + 0x60);
        piVar5 = *(int64_t **)(arg1 + 0x50);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar5 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        cVar4 = *(char *)(arg1 + 0x40);
        puVar11 = auStack_38;
        if ((cVar4 == -1) || (puVar11 = auStack_38, cVar4 == '\0')) goto code_r0x000180084bcb;
        if (cVar4 != '\x01') {
            if (cVar4 == '\x02') {
                (***(code ***)(arg1 + 0x18))(arg1 + 0x18, 0);
                puVar11 = auStack_38;
            } else {
                func_0x000180084ff0();
                puVar11 = auStack_38;
            }
            goto code_r0x000180084bcb;
        }
        iVar9 = *(int64_t *)(arg1 + 0x20);
        puVar11 = auStack_38;
        if (iVar9 == 0) goto code_r0x000180084bcb;
        iVar7 = *(int64_t *)(arg1 + 0x28);
        for (; iVar9 != iVar7; iVar9 = iVar9 + 0x40) {
            func_0x000180004e40(iVar9 + 0x20);
            func_0x000180004e40(iVar9);
        }
        iVar9 = *(int64_t *)(arg1 + 0x20);
        if ((0xfff < (*(int64_t *)(arg1 + 0x30) - iVar9 & 0xffffffffffffffc0U)) &&
           (iVar7 = iVar9 - *(int64_t *)(iVar9 + -8), iVar9 = *(int64_t *)(iVar9 + -8), puVar10 = auStack_38,
           0x1f < iVar7 - 8U)) goto code_r0x000180084bb0;
    } else {
        iVar7 = *(int64_t *)(arg1 + 0x90);
        for (; iVar9 != iVar7; iVar9 = iVar9 + 0x40) {
            func_0x000180004e40(iVar9 + 0x20);
            func_0x000180004e40(iVar9);
        }
        iVar9 = *(int64_t *)(arg1 + 0x88);
        uVar8 = *(int64_t *)(arg1 + 0x98) - iVar9 & 0xffffffffffffffc0;
        if (uVar8 < 0x1000) {
code_r0x000180084ab6:
            fcn.180459c3c(iVar9, uVar8);
            *(undefined8 *)(arg1 + 0x88) = 0;
            *(undefined8 *)(arg1 + 0x90) = 0;
            *(undefined8 *)(arg1 + 0x98) = 0;
            goto code_r0x000180084ad0;
        }
        if ((iVar9 - *(int64_t *)(iVar9 + -8)) - 8U < 0x20) {
            uVar8 = uVar8 + 0x27;
            iVar9 = *(int64_t *)(iVar9 + -8);
            goto code_r0x000180084ab6;
        }
code_r0x000180084bb0:
        pcVar6 = (code *)swi(0x29);
        iVar9 = (*pcVar6)(5);
        puVar10 = auStack_30;
    }
    *(undefined8 *)(puVar10 + -8) = 0x180084bbf;
    fcn.180459c3c(iVar9);
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    puVar11 = puVar10;
code_r0x000180084bcb:
    piVar5 = *(int64_t **)(arg1 + 8);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            pcVar6 = *(code **)(*piVar5 + 8);
            *(undefined8 *)(puVar11 + -8) = 0x180084be4;
            (*pcVar6)();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180084c00
// Address: 0x180084c00
// Size: 69 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180085131)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180084c00(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined *puVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    undefined auStack_20 [8];
    
    iVar3 = (int64_t)*(char *)(arg1 + 0x28);
    iVar7 = iVar3 + 1;
    if ((iVar3 + 1 != 0) && (iVar7 = iVar3, iVar3 != 0)) {
        if (iVar3 != 1) {
            if (iVar3 == 2) {
    // WARNING: Could not recover jumptable at 0x000180084c42. Too many branches
    // WARNING: Treating indirect jump as call
                iVar7 = (***(code ***)arg1)();
                return iVar7;
            }
            iVar7 = *(int64_t *)arg1;
            if (iVar7 != 0) {
                iVar3 = *(int64_t *)(arg1 + 8);
                for (; iVar7 != iVar3; iVar7 = iVar7 + 0x90) {
                    iVar5 = *(int64_t *)(iVar7 + 0x78);
                    if (iVar5 != 0) {
                        iVar1 = *(int64_t *)(iVar7 + 0x80);
                        for (; iVar5 != iVar1; iVar5 = iVar5 + 0x40) {
                            func_0x000180004e40(iVar5 + 0x20);
                            func_0x000180004e40(iVar5);
                        }
                        iVar5 = *(int64_t *)(iVar7 + 0x78);
                        uVar4 = *(int64_t *)(iVar7 + 0x88) - iVar5 & 0xffffffffffffffc0;
                        if (0xfff < uVar4) {
                            if (0x1f < (iVar5 - *(int64_t *)(iVar5 + -8)) - 8U) goto code_r0x00018008510e;
                            uVar4 = uVar4 + 0x27;
                            iVar5 = *(int64_t *)(iVar5 + -8);
                        }
                        fcn.180459c3c(iVar5, uVar4);
                        *(undefined8 *)(iVar7 + 0x78) = 0;
                        *(undefined8 *)(iVar7 + 0x80) = 0;
                        *(undefined8 *)(iVar7 + 0x88) = 0;
                    }
                    func_0x000180004e40(iVar7 + 0x40);
                    func_0x000180004e40(iVar7 + 0x20);
                    func_0x000180004e40(iVar7);
                }
                iVar7 = *(int64_t *)arg1;
                iVar3 = iVar7;
                puVar6 = auStack_58;
                if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 4) << 4)) &&
                   (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_58, 0x1f < (iVar7 - iVar3) - 8U)) {
code_r0x00018008510e:
                    iVar3 = 5;
                    pcVar2 = (code *)swi(0x29);
                    (*pcVar2)(5);
                    puVar6 = auStack_50;
                }
                *(undefined8 *)(puVar6 + -8) = 0x180085120;
                fcn.180459c3c(iVar3);
                *(undefined8 *)arg1 = 0;
                *(undefined8 *)(arg1 + 8) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
            }
            return arg1;
        }
        iVar7 = *(int64_t *)(arg1 + 8);
        if (iVar7 != 0) {
            iVar3 = *(int64_t *)(arg1 + 0x10);
            for (; iVar7 != iVar3; iVar7 = iVar7 + 0x40) {
                func_0x000180004e40(iVar7 + 0x20);
                func_0x000180004e40(iVar7);
            }
            iVar7 = *(int64_t *)(arg1 + 8);
            iVar3 = iVar7;
            puVar6 = &stack0xffffffffffffffd8;
            if ((0xfff < (*(int64_t *)(arg1 + 0x18) - iVar7 & 0xffffffffffffffc0U)) &&
               (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = &stack0xffffffffffffffd8, 0x1f < (iVar7 - iVar3) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar6 = auStack_20;
            }
            *(undefined8 *)(puVar6 + -8) = 0x180084cc2;
            fcn.180459c3c(iVar3);
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(undefined8 *)(arg1 + 0x18) = 0;
        }
        iVar7 = 0;
    }
    return iVar7;
}

// ============================================================
// Function: FUN_180084c45
// Address: 0x180084c45
// Size: 18 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180085131)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180084c00(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined *puVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    undefined auStack_20 [8];
    
    iVar3 = (int64_t)*(char *)(arg1 + 0x28);
    iVar7 = iVar3 + 1;
    if ((iVar3 + 1 != 0) && (iVar7 = iVar3, iVar3 != 0)) {
        if (iVar3 != 1) {
            if (iVar3 == 2) {
    // WARNING: Could not recover jumptable at 0x000180084c42. Too many branches
    // WARNING: Treating indirect jump as call
                iVar7 = (***(code ***)arg1)();
                return iVar7;
            }
            iVar7 = *(int64_t *)arg1;
            if (iVar7 != 0) {
                iVar3 = *(int64_t *)(arg1 + 8);
                for (; iVar7 != iVar3; iVar7 = iVar7 + 0x90) {
                    iVar5 = *(int64_t *)(iVar7 + 0x78);
                    if (iVar5 != 0) {
                        iVar1 = *(int64_t *)(iVar7 + 0x80);
                        for (; iVar5 != iVar1; iVar5 = iVar5 + 0x40) {
                            func_0x000180004e40(iVar5 + 0x20);
                            func_0x000180004e40(iVar5);
                        }
                        iVar5 = *(int64_t *)(iVar7 + 0x78);
                        uVar4 = *(int64_t *)(iVar7 + 0x88) - iVar5 & 0xffffffffffffffc0;
                        if (0xfff < uVar4) {
                            if (0x1f < (iVar5 - *(int64_t *)(iVar5 + -8)) - 8U) goto code_r0x00018008510e;
                            uVar4 = uVar4 + 0x27;
                            iVar5 = *(int64_t *)(iVar5 + -8);
                        }
                        fcn.180459c3c(iVar5, uVar4);
                        *(undefined8 *)(iVar7 + 0x78) = 0;
                        *(undefined8 *)(iVar7 + 0x80) = 0;
                        *(undefined8 *)(iVar7 + 0x88) = 0;
                    }
                    func_0x000180004e40(iVar7 + 0x40);
                    func_0x000180004e40(iVar7 + 0x20);
                    func_0x000180004e40(iVar7);
                }
                iVar7 = *(int64_t *)arg1;
                iVar3 = iVar7;
                puVar6 = auStack_58;
                if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 4) << 4)) &&
                   (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_58, 0x1f < (iVar7 - iVar3) - 8U)) {
code_r0x00018008510e:
                    iVar3 = 5;
                    pcVar2 = (code *)swi(0x29);
                    (*pcVar2)(5);
                    puVar6 = auStack_50;
                }
                *(undefined8 *)(puVar6 + -8) = 0x180085120;
                fcn.180459c3c(iVar3);
                *(undefined8 *)arg1 = 0;
                *(undefined8 *)(arg1 + 8) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
            }
            return arg1;
        }
        iVar7 = *(int64_t *)(arg1 + 8);
        if (iVar7 != 0) {
            iVar3 = *(int64_t *)(arg1 + 0x10);
            for (; iVar7 != iVar3; iVar7 = iVar7 + 0x40) {
                func_0x000180004e40(iVar7 + 0x20);
                func_0x000180004e40(iVar7);
            }
            iVar7 = *(int64_t *)(arg1 + 8);
            iVar3 = iVar7;
            puVar6 = &stack0xffffffffffffffd8;
            if ((0xfff < (*(int64_t *)(arg1 + 0x18) - iVar7 & 0xffffffffffffffc0U)) &&
               (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = &stack0xffffffffffffffd8, 0x1f < (iVar7 - iVar3) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar6 = auStack_20;
            }
            *(undefined8 *)(puVar6 + -8) = 0x180084cc2;
            fcn.180459c3c(iVar3);
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(undefined8 *)(arg1 + 0x18) = 0;
        }
        iVar7 = 0;
    }
    return iVar7;
}

// ============================================================
// Function: FUN_180084c57
// Address: 0x180084c57
// Size: 69 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180085131)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180084c00(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined *puVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    undefined auStack_20 [8];
    
    iVar3 = (int64_t)*(char *)(arg1 + 0x28);
    iVar7 = iVar3 + 1;
    if ((iVar3 + 1 != 0) && (iVar7 = iVar3, iVar3 != 0)) {
        if (iVar3 != 1) {
            if (iVar3 == 2) {
    // WARNING: Could not recover jumptable at 0x000180084c42. Too many branches
    // WARNING: Treating indirect jump as call
                iVar7 = (***(code ***)arg1)();
                return iVar7;
            }
            iVar7 = *(int64_t *)arg1;
            if (iVar7 != 0) {
                iVar3 = *(int64_t *)(arg1 + 8);
                for (; iVar7 != iVar3; iVar7 = iVar7 + 0x90) {
                    iVar5 = *(int64_t *)(iVar7 + 0x78);
                    if (iVar5 != 0) {
                        iVar1 = *(int64_t *)(iVar7 + 0x80);
                        for (; iVar5 != iVar1; iVar5 = iVar5 + 0x40) {
                            func_0x000180004e40(iVar5 + 0x20);
                            func_0x000180004e40(iVar5);
                        }
                        iVar5 = *(int64_t *)(iVar7 + 0x78);
                        uVar4 = *(int64_t *)(iVar7 + 0x88) - iVar5 & 0xffffffffffffffc0;
                        if (0xfff < uVar4) {
                            if (0x1f < (iVar5 - *(int64_t *)(iVar5 + -8)) - 8U) goto code_r0x00018008510e;
                            uVar4 = uVar4 + 0x27;
                            iVar5 = *(int64_t *)(iVar5 + -8);
                        }
                        fcn.180459c3c(iVar5, uVar4);
                        *(undefined8 *)(iVar7 + 0x78) = 0;
                        *(undefined8 *)(iVar7 + 0x80) = 0;
                        *(undefined8 *)(iVar7 + 0x88) = 0;
                    }
                    func_0x000180004e40(iVar7 + 0x40);
                    func_0x000180004e40(iVar7 + 0x20);
                    func_0x000180004e40(iVar7);
                }
                iVar7 = *(int64_t *)arg1;
                iVar3 = iVar7;
                puVar6 = auStack_58;
                if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 4) << 4)) &&
                   (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_58, 0x1f < (iVar7 - iVar3) - 8U)) {
code_r0x00018008510e:
                    iVar3 = 5;
                    pcVar2 = (code *)swi(0x29);
                    (*pcVar2)(5);
                    puVar6 = auStack_50;
                }
                *(undefined8 *)(puVar6 + -8) = 0x180085120;
                fcn.180459c3c(iVar3);
                *(undefined8 *)arg1 = 0;
                *(undefined8 *)(arg1 + 8) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
            }
            return arg1;
        }
        iVar7 = *(int64_t *)(arg1 + 8);
        if (iVar7 != 0) {
            iVar3 = *(int64_t *)(arg1 + 0x10);
            for (; iVar7 != iVar3; iVar7 = iVar7 + 0x40) {
                func_0x000180004e40(iVar7 + 0x20);
                func_0x000180004e40(iVar7);
            }
            iVar7 = *(int64_t *)(arg1 + 8);
            iVar3 = iVar7;
            puVar6 = &stack0xffffffffffffffd8;
            if ((0xfff < (*(int64_t *)(arg1 + 0x18) - iVar7 & 0xffffffffffffffc0U)) &&
               (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = &stack0xffffffffffffffd8, 0x1f < (iVar7 - iVar3) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar6 = auStack_20;
            }
            *(undefined8 *)(puVar6 + -8) = 0x180084cc2;
            fcn.180459c3c(iVar3);
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(undefined8 *)(arg1 + 0x18) = 0;
        }
        iVar7 = 0;
    }
    return iVar7;
}

// ============================================================
// Function: FUN_180084c9c
// Address: 0x180084c9c
// Size: 57 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180085131)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180084c00(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined *puVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    undefined auStack_20 [8];
    
    iVar3 = (int64_t)*(char *)(arg1 + 0x28);
    iVar7 = iVar3 + 1;
    if ((iVar3 + 1 != 0) && (iVar7 = iVar3, iVar3 != 0)) {
        if (iVar3 != 1) {
            if (iVar3 == 2) {
    // WARNING: Could not recover jumptable at 0x000180084c42. Too many branches
    // WARNING: Treating indirect jump as call
                iVar7 = (***(code ***)arg1)();
                return iVar7;
            }
            iVar7 = *(int64_t *)arg1;
            if (iVar7 != 0) {
                iVar3 = *(int64_t *)(arg1 + 8);
                for (; iVar7 != iVar3; iVar7 = iVar7 + 0x90) {
                    iVar5 = *(int64_t *)(iVar7 + 0x78);
                    if (iVar5 != 0) {
                        iVar1 = *(int64_t *)(iVar7 + 0x80);
                        for (; iVar5 != iVar1; iVar5 = iVar5 + 0x40) {
                            func_0x000180004e40(iVar5 + 0x20);
                            func_0x000180004e40(iVar5);
                        }
                        iVar5 = *(int64_t *)(iVar7 + 0x78);
                        uVar4 = *(int64_t *)(iVar7 + 0x88) - iVar5 & 0xffffffffffffffc0;
                        if (0xfff < uVar4) {
                            if (0x1f < (iVar5 - *(int64_t *)(iVar5 + -8)) - 8U) goto code_r0x00018008510e;
                            uVar4 = uVar4 + 0x27;
                            iVar5 = *(int64_t *)(iVar5 + -8);
                        }
                        fcn.180459c3c(iVar5, uVar4);
                        *(undefined8 *)(iVar7 + 0x78) = 0;
                        *(undefined8 *)(iVar7 + 0x80) = 0;
                        *(undefined8 *)(iVar7 + 0x88) = 0;
                    }
                    func_0x000180004e40(iVar7 + 0x40);
                    func_0x000180004e40(iVar7 + 0x20);
                    func_0x000180004e40(iVar7);
                }
                iVar7 = *(int64_t *)arg1;
                iVar3 = iVar7;
                puVar6 = auStack_58;
                if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 4) << 4)) &&
                   (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_58, 0x1f < (iVar7 - iVar3) - 8U)) {
code_r0x00018008510e:
                    iVar3 = 5;
                    pcVar2 = (code *)swi(0x29);
                    (*pcVar2)(5);
                    puVar6 = auStack_50;
                }
                *(undefined8 *)(puVar6 + -8) = 0x180085120;
                fcn.180459c3c(iVar3);
                *(undefined8 *)arg1 = 0;
                *(undefined8 *)(arg1 + 8) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
            }
            return arg1;
        }
        iVar7 = *(int64_t *)(arg1 + 8);
        if (iVar7 != 0) {
            iVar3 = *(int64_t *)(arg1 + 0x10);
            for (; iVar7 != iVar3; iVar7 = iVar7 + 0x40) {
                func_0x000180004e40(iVar7 + 0x20);
                func_0x000180004e40(iVar7);
            }
            iVar7 = *(int64_t *)(arg1 + 8);
            iVar3 = iVar7;
            puVar6 = &stack0xffffffffffffffd8;
            if ((0xfff < (*(int64_t *)(arg1 + 0x18) - iVar7 & 0xffffffffffffffc0U)) &&
               (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = &stack0xffffffffffffffd8, 0x1f < (iVar7 - iVar3) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar6 = auStack_20;
            }
            *(undefined8 *)(puVar6 + -8) = 0x180084cc2;
            fcn.180459c3c(iVar3);
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(undefined8 *)(arg1 + 0x18) = 0;
        }
        iVar7 = 0;
    }
    return iVar7;
}

// ============================================================
// Function: FUN_180084cd5
// Address: 0x180084cd5
// Size: 6 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180085131)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180084c00(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined *puVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    undefined auStack_20 [8];
    
    iVar3 = (int64_t)*(char *)(arg1 + 0x28);
    iVar7 = iVar3 + 1;
    if ((iVar3 + 1 != 0) && (iVar7 = iVar3, iVar3 != 0)) {
        if (iVar3 != 1) {
            if (iVar3 == 2) {
    // WARNING: Could not recover jumptable at 0x000180084c42. Too many branches
    // WARNING: Treating indirect jump as call
                iVar7 = (***(code ***)arg1)();
                return iVar7;
            }
            iVar7 = *(int64_t *)arg1;
            if (iVar7 != 0) {
                iVar3 = *(int64_t *)(arg1 + 8);
                for (; iVar7 != iVar3; iVar7 = iVar7 + 0x90) {
                    iVar5 = *(int64_t *)(iVar7 + 0x78);
                    if (iVar5 != 0) {
                        iVar1 = *(int64_t *)(iVar7 + 0x80);
                        for (; iVar5 != iVar1; iVar5 = iVar5 + 0x40) {
                            func_0x000180004e40(iVar5 + 0x20);
                            func_0x000180004e40(iVar5);
                        }
                        iVar5 = *(int64_t *)(iVar7 + 0x78);
                        uVar4 = *(int64_t *)(iVar7 + 0x88) - iVar5 & 0xffffffffffffffc0;
                        if (0xfff < uVar4) {
                            if (0x1f < (iVar5 - *(int64_t *)(iVar5 + -8)) - 8U) goto code_r0x00018008510e;
                            uVar4 = uVar4 + 0x27;
                            iVar5 = *(int64_t *)(iVar5 + -8);
                        }
                        fcn.180459c3c(iVar5, uVar4);
                        *(undefined8 *)(iVar7 + 0x78) = 0;
                        *(undefined8 *)(iVar7 + 0x80) = 0;
                        *(undefined8 *)(iVar7 + 0x88) = 0;
                    }
                    func_0x000180004e40(iVar7 + 0x40);
                    func_0x000180004e40(iVar7 + 0x20);
                    func_0x000180004e40(iVar7);
                }
                iVar7 = *(int64_t *)arg1;
                iVar3 = iVar7;
                puVar6 = auStack_58;
                if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 4) << 4)) &&
                   (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_58, 0x1f < (iVar7 - iVar3) - 8U)) {
code_r0x00018008510e:
                    iVar3 = 5;
                    pcVar2 = (code *)swi(0x29);
                    (*pcVar2)(5);
                    puVar6 = auStack_50;
                }
                *(undefined8 *)(puVar6 + -8) = 0x180085120;
                fcn.180459c3c(iVar3);
                *(undefined8 *)arg1 = 0;
                *(undefined8 *)(arg1 + 8) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
            }
            return arg1;
        }
        iVar7 = *(int64_t *)(arg1 + 8);
        if (iVar7 != 0) {
            iVar3 = *(int64_t *)(arg1 + 0x10);
            for (; iVar7 != iVar3; iVar7 = iVar7 + 0x40) {
                func_0x000180004e40(iVar7 + 0x20);
                func_0x000180004e40(iVar7);
            }
            iVar7 = *(int64_t *)(arg1 + 8);
            iVar3 = iVar7;
            puVar6 = &stack0xffffffffffffffd8;
            if ((0xfff < (*(int64_t *)(arg1 + 0x18) - iVar7 & 0xffffffffffffffc0U)) &&
               (iVar3 = *(int64_t *)(iVar7 + -8), puVar6 = &stack0xffffffffffffffd8, 0x1f < (iVar7 - iVar3) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar6 = auStack_20;
            }
            *(undefined8 *)(puVar6 + -8) = 0x180084cc2;
            fcn.180459c3c(iVar3);
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(undefined8 *)(arg1 + 0x18) = 0;
        }
        iVar7 = 0;
    }
    return iVar7;
}

// ============================================================
// Function: FUN_180084ce0
// Address: 0x180084ce0
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180084ce0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 0x10);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x40) {
            func_0x000180004e40(iVar3 + 0x20);
            func_0x000180004e40(iVar3);
        }
        iVar3 = *(int64_t *)(arg1 + 8);
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x18) - iVar3 & 0xffffffffffffffc0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180084d61;
        fcn.180459c3c(iVar2);
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180084cf6
// Address: 0x180084cf6
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180084ce0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 0x10);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x40) {
            func_0x000180004e40(iVar3 + 0x20);
            func_0x000180004e40(iVar3);
        }
        iVar3 = *(int64_t *)(arg1 + 8);
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x18) - iVar3 & 0xffffffffffffffc0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180084d61;
        fcn.180459c3c(iVar2);
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180084d3b
// Address: 0x180084d3b
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180084ce0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 0x10);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x40) {
            func_0x000180004e40(iVar3 + 0x20);
            func_0x000180004e40(iVar3);
        }
        iVar3 = *(int64_t *)(arg1 + 8);
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x18) - iVar3 & 0xffffffffffffffc0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180084d61;
        fcn.180459c3c(iVar2);
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    return;
}

