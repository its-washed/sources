// Chunk 175 - 50 functions

// ============================================================
// Function: FUN_180230607
// Address: 0x180230607
// Size: 380 bytes
// ============================================================
undefined8
fcn.180230607(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined4 *puVar3;
    undefined8 *unaff_RBX;
    int64_t unaff_RBP;
    undefined4 uVar4;
    int64_t var_20h;
    
    uVar4 = 0xffffffff;
    if (var_20h == 0) {
        uVar1 = 0xffffffff;
    } else {
        uVar1 = func_0x000180498cd0(var_20h);
    }
    puVar3 = (undefined4 *)0x0;
    arg_70h = 0;
    if (unaff_RBX != (undefined8 *)0x0) {
        if ((unaff_RBX[4] != 0) || (unaff_RBX[0xd] != 0)) {
            func_0x000180231190();
        }
        if (((*(int32_t *)unaff_RBX != 0) && (*(int32_t *)((int64_t)unaff_RBX + 4) == 0)) && (unaff_RBX[1] != 0)) {
            return 1;
        }
        func_0x00018026aee0(unaff_RBX[2]);
        unaff_RBX[2] = 0;
        func_0x00018026aee0(unaff_RBX[3]);
        unaff_RBX[3] = 0;
    }
    if (var_20h != 0) {
        puVar3 = (undefined4 *)func_0x0001802479a0(&arg_70h, var_20h, uVar1);
    }
    if (unaff_RBX == (undefined8 *)0x0) {
        func_0x00018026aee0(arg_70h);
    }
    if ((puVar3 == (undefined4 *)0x0) && (unaff_RBP == 0)) {
        func_0x000180229480();
        func_0x0001802295a0(0x1804e1cf0, 0x644, 0x1804e1e08);
        func_0x0001802296d0(6, 0x9c, 0);
        return 0;
    }
    if (unaff_RBX != (undefined8 *)0x0) {
        if ((unaff_RBP != 0) && (iVar2 = func_0x000180257ae0(), iVar2 == 0)) {
            func_0x000180229480();
            func_0x0001802295a0(0x1804e1cf0, 0x64a, 0x1804e1e08);
            func_0x0001802296d0(6, 0xc0103, 0);
            return 0;
        }
        unaff_RBX[0xc] = unaff_RBP;
        *unaff_RBX = 0;
        if (unaff_RBP == 0) {
            unaff_RBX[1] = puVar3;
        }
        if (puVar3 != (undefined4 *)0x0) {
            uVar4 = *puVar3;
        }
        unaff_RBX[2] = arg_70h;
        *(undefined4 *)unaff_RBX = uVar4;
    }
    return 1;
}

// ============================================================
// Function: FUN_180230783
// Address: 0x180230783
// Size: 56 bytes
// ============================================================
undefined8 fcn.180230783(void)
{
    int64_t in_stack_00000020;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000038;
    int64_t in_stack_00000040;
    int64_t in_stack_00000050;
    
    fcn.180229480(in_stack_00000020, in_stack_00000028);
    fcn.1802295a0(in_stack_00000020, in_stack_00000028, in_stack_00000030, in_stack_00000038, in_stack_00000050);
    fcn.1802296d0(in_stack_00000040);
    return 0;
}

// ============================================================
// Function: FUN_1802307c0
// Address: 0x1802307c0
// Size: 265 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1802307c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    undefined8 *in_RCX;
    int64_t in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    
    uStack_20 = 0x1802307d8;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar3 = (undefined4 *)0x0;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0;
    if (in_RCX != (undefined8 *)0x0) {
        if ((in_RCX[4] != 0) || (in_RCX[0xd] != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180230805;
            func_0x000180231190();
        }
        if (((*(int32_t *)in_RCX != 0) && (*(int32_t *)((int64_t)in_RCX + 4) == 0)) && (in_RCX[1] != 0)) {
            return 1;
        }
        uVar1 = in_RCX[2];
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180230823;
        func_0x00018026aee0(uVar1);
        uVar1 = in_RCX[3];
        in_RCX[2] = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180230830;
        func_0x00018026aee0(uVar1);
        in_RCX[3] = 0;
    }
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180230849;
        puVar3 = (undefined4 *)func_0x0001802479a0((int64_t)&arg_40h + iVar2, in_RDX, in_R8 & 0xffffffff);
    }
    if (in_RCX == (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023085b;
        func_0x00018026aee0(*(undefined8 *)((int64_t)&arg_40h + iVar2));
    }
    if (puVar3 != (undefined4 *)0x0) {
        if (in_RCX != (undefined8 *)0x0) {
            *in_RCX = 0;
            in_RCX[0xc] = 0;
            in_RCX[1] = puVar3;
            *(undefined4 *)in_RCX = *puVar3;
            in_RCX[2] = *(undefined8 *)((int64_t)&arg_40h + iVar2);
        }
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180230865;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023087d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)(&stack0x00000038 + iVar2));
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18023088f;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1802308f0
// Address: 0x1802308f0
// Size: 102 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_59h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Removing arg arg_29h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_65h
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_67h
// WARNING: [rz-ghidra] Removing arg arg_49h because it doesn't fit into ProtoModel

void fcn.1802308f0(int64_t arg_68h, int64_t arg_78h, int64_t arg_80h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802308ff;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_68h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4);
    if (*(int64_t *)(in_RCX + 8) == 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x60);
        if ((iVar1 != 0) && (in_EDX == 3)) {
            uVar5 = *(undefined8 *)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_RDI;
            *(undefined8 *)(&stack0x00000059 + iVar4) = 0;
            *(undefined (*) [16])((int64_t)&var_18h + iVar4 + 1) = ZEXT816(0);
            *(undefined4 *)(&stack0x00000061 + iVar4) = 0;
            *(undefined (*) [16])(&stack0x00000029 + iVar4) = ZEXT816(0);
            *(undefined2 *)(&stack0x00000065 + iVar4) = 0;
            *(undefined (*) [16])(&stack0x00000039 + iVar4) = ZEXT816(0);
            (&stack0x00000067)[iVar4] = 0;
            *(undefined (*) [16])(&stack0x00000049 + iVar4) = ZEXT816(0);
            *(undefined *)((int64_t)&var_18h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023099e;
            iVar3 = func_0x00018029ee90(iVar1, uVar5, (int64_t)&var_18h + iVar4, 0x50);
            if (0 < iVar3) {
                uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x60) + 0x20);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309b1;
                uVar5 = func_0x00018027f1e0(uVar5);
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309bf;
                func_0x000180229b10();
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309cf;
                uVar6 = func_0x000180215540(uVar5, (int64_t)&var_18h + iVar4, 0);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309d7;
                func_0x0001802299d0();
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309df;
                uVar5 = func_0x000180299670(uVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309ea;
                func_0x000180215590(uVar6);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309f7;
                iVar3 = func_0x0001802993f0(uVar5, (int64_t)&var_18h + iVar4);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230a11;
                    iVar3 = func_0x000180299310(uVar5, iVar3, 0x180231830, (int64_t)&var_8h + iVar4);
                    if (iVar3 != 0) {
                        *in_R9 = *(undefined4 *)((int64_t)&var_8h + iVar4);
                    }
                }
            }
        }
    } else {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 8) + 0xb0);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230a47;
            (*pcVar2)();
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230a57;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_180230956
// Address: 0x180230956
// Size: 220 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_59h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Removing arg arg_29h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_65h
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_67h
// WARNING: [rz-ghidra] Removing arg arg_49h because it doesn't fit into ProtoModel

void fcn.1802308f0(int64_t arg_68h, int64_t arg_78h, int64_t arg_80h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802308ff;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_68h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4);
    if (*(int64_t *)(in_RCX + 8) == 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x60);
        if ((iVar1 != 0) && (in_EDX == 3)) {
            uVar5 = *(undefined8 *)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_RDI;
            *(undefined8 *)(&stack0x00000059 + iVar4) = 0;
            *(undefined (*) [16])((int64_t)&var_18h + iVar4 + 1) = ZEXT816(0);
            *(undefined4 *)(&stack0x00000061 + iVar4) = 0;
            *(undefined (*) [16])(&stack0x00000029 + iVar4) = ZEXT816(0);
            *(undefined2 *)(&stack0x00000065 + iVar4) = 0;
            *(undefined (*) [16])(&stack0x00000039 + iVar4) = ZEXT816(0);
            (&stack0x00000067)[iVar4] = 0;
            *(undefined (*) [16])(&stack0x00000049 + iVar4) = ZEXT816(0);
            *(undefined *)((int64_t)&var_18h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023099e;
            iVar3 = func_0x00018029ee90(iVar1, uVar5, (int64_t)&var_18h + iVar4, 0x50);
            if (0 < iVar3) {
                uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x60) + 0x20);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309b1;
                uVar5 = func_0x00018027f1e0(uVar5);
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309bf;
                func_0x000180229b10();
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309cf;
                uVar6 = func_0x000180215540(uVar5, (int64_t)&var_18h + iVar4, 0);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309d7;
                func_0x0001802299d0();
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309df;
                uVar5 = func_0x000180299670(uVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309ea;
                func_0x000180215590(uVar6);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309f7;
                iVar3 = func_0x0001802993f0(uVar5, (int64_t)&var_18h + iVar4);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230a11;
                    iVar3 = func_0x000180299310(uVar5, iVar3, 0x180231830, (int64_t)&var_8h + iVar4);
                    if (iVar3 != 0) {
                        *in_R9 = *(undefined4 *)((int64_t)&var_8h + iVar4);
                    }
                }
            }
        }
    } else {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 8) + 0xb0);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230a47;
            (*pcVar2)();
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230a57;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_180230a32
// Address: 0x180230a32
// Size: 49 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_59h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Removing arg arg_29h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_65h
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_67h
// WARNING: [rz-ghidra] Removing arg arg_49h because it doesn't fit into ProtoModel

void fcn.1802308f0(int64_t arg_68h, int64_t arg_78h, int64_t arg_80h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802308ff;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_68h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4);
    if (*(int64_t *)(in_RCX + 8) == 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x60);
        if ((iVar1 != 0) && (in_EDX == 3)) {
            uVar5 = *(undefined8 *)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_RDI;
            *(undefined8 *)(&stack0x00000059 + iVar4) = 0;
            *(undefined (*) [16])((int64_t)&var_18h + iVar4 + 1) = ZEXT816(0);
            *(undefined4 *)(&stack0x00000061 + iVar4) = 0;
            *(undefined (*) [16])(&stack0x00000029 + iVar4) = ZEXT816(0);
            *(undefined2 *)(&stack0x00000065 + iVar4) = 0;
            *(undefined (*) [16])(&stack0x00000039 + iVar4) = ZEXT816(0);
            (&stack0x00000067)[iVar4] = 0;
            *(undefined (*) [16])(&stack0x00000049 + iVar4) = ZEXT816(0);
            *(undefined *)((int64_t)&var_18h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023099e;
            iVar3 = func_0x00018029ee90(iVar1, uVar5, (int64_t)&var_18h + iVar4, 0x50);
            if (0 < iVar3) {
                uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x60) + 0x20);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309b1;
                uVar5 = func_0x00018027f1e0(uVar5);
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309bf;
                func_0x000180229b10();
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309cf;
                uVar6 = func_0x000180215540(uVar5, (int64_t)&var_18h + iVar4, 0);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309d7;
                func_0x0001802299d0();
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309df;
                uVar5 = func_0x000180299670(uVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309ea;
                func_0x000180215590(uVar6);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802309f7;
                iVar3 = func_0x0001802993f0(uVar5, (int64_t)&var_18h + iVar4);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230a11;
                    iVar3 = func_0x000180299310(uVar5, iVar3, 0x180231830, (int64_t)&var_8h + iVar4);
                    if (iVar3 != 0) {
                        *in_R9 = *(undefined4 *)((int64_t)&var_8h + iVar4);
                    }
                }
            }
        }
    } else {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 8) + 0xb0);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230a47;
            (*pcVar2)();
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230a57;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_180230a70
// Address: 0x180230a70
// Size: 347 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180230a70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_98h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    int32_t *in_RDX;
    int64_t iVar8;
    uint64_t in_R8;
    int64_t iVar9;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180230a8c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        if (*(int64_t *)(in_RDX + 0x18) == 0) {
            return 0xfffffffe;
        }
    } else if (*(int64_t *)(in_RDX + 0x18) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180230abc;
        uVar4 = func_0x00018029f120();
        return uVar4;
    }
    if ((*in_RCX != 0) && (*(int64_t *)(in_RCX + 0x18) == 0)) {
        uVar4 = *(undefined8 *)(in_RDX + 0x18);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180230ad5;
        uVar5 = func_0x00018022ccf0();
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180230ae0;
        iVar2 = func_0x000180257a60(uVar4, uVar5);
        if (iVar2 == 0) {
            return 0xffffffff;
        }
    }
    if ((*in_RDX != 0) && (*(int64_t *)(in_RDX + 0x18) == 0)) {
        uVar4 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180230afa;
        uVar5 = func_0x00018022ccf0();
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180230b05;
        iVar2 = func_0x000180257a60(uVar4, uVar5);
        if (iVar2 == 0) {
            return 0xffffffff;
        }
    }
    iVar6 = *(int64_t *)(in_RDX + 0x18);
    iVar8 = *(int64_t *)(in_RCX + 0x18);
    iVar9 = *(int64_t *)(in_RCX + 0x1a);
    iVar1 = *(int64_t *)(in_RDX + 0x1a);
    *(int64_t *)((int64_t)&arg_40h + iVar3) = iVar8;
    *(int64_t *)((int64_t)&arg_28h + iVar3) = iVar6;
    if ((iVar6 != 0) && (*(int64_t *)(iVar6 + 0xc0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180230b4e;
        iVar6 = func_0x000180230ea0(in_RCX, 0, (int64_t)&arg_28h + iVar3, 0);
        if (iVar6 != 0) {
            iVar8 = *(int64_t *)((int64_t)&arg_28h + iVar3);
            iVar9 = iVar6;
            iVar7 = iVar1;
            goto code_r0x000180230b97;
        }
        iVar6 = *(int64_t *)((int64_t)&arg_28h + iVar3);
    }
    if ((iVar8 != 0) && (*(int64_t *)(iVar8 + 0xc0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180230b83;
        iVar7 = func_0x000180230ea0(in_RDX, 0, (int64_t)&arg_40h + iVar3, 0);
        iVar8 = *(int64_t *)((int64_t)&arg_40h + iVar3);
        if (iVar7 != 0) goto code_r0x000180230b97;
    }
    iVar7 = iVar1;
    if (iVar8 != iVar6) {
        return 0xfffffffe;
    }
code_r0x000180230b97:
    if (iVar8 == 0) {
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180230bad;
    uVar4 = func_0x000180257f70(iVar8, iVar9, iVar7, in_R8 & 0xffffffff);
    return uVar4;
}

// ============================================================
// Function: FUN_180230bd0
// Address: 0x180230bd0
// Size: 706 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180230bd0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t *in_RCX;
    int32_t *in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180230bee;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar8 = 0;
    if ((in_RCX != (int64_t *)0x0) &&
       (((*(int64_t *)(in_RDX + 8) != 0 || (*(int64_t *)(in_RDX + 0x1a) != 0)) &&
        (iVar2 = *(int64_t *)(in_RDX + 0x18), iVar2 != 0)))) {
        iVar3 = *(int64_t *)(in_RDX + 0x1a);
        iVar6 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230c2a;
        func_0x0001801dd6c0(iVar2);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230c36;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230c4e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230c67;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        } else {
            if (iVar6 != -1) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230c78;
                func_0x00018022ccf0(iVar6);
            }
            if (*in_RCX == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230c88;
                iVar8 = func_0x00018022fd80();
                *in_RCX = iVar8;
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230c98;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230cb0;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230cc2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                    return 0;
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230ccc;
                func_0x000180231190();
            }
            iVar10 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230cd6;
            iVar6 = func_0x0001802304b0(iVar10, iVar6);
            if (iVar6 != 0) {
                if (iVar3 == 0) {
                    return 1;
                }
                if (*(int64_t *)(*(int64_t *)(*in_RCX + 8) + 0x128) == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230cfd;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230d15;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230d2e;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                } else {
                    uVar9 = *(undefined8 *)(iVar2 + 0x20);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230d39;
                    uVar9 = func_0x00018027f1e0(uVar9);
                    iVar10 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230d47;
                    iVar10 = func_0x000180259210(uVar9, iVar10, 0);
                    if (iVar10 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230d58;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230d70;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230d82;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                    } else {
                        iVar4 = *in_RCX;
                        *(int64_t *)((int64_t)&var_8h + iVar7) = iVar10;
                        uVar9 = *(undefined8 *)(*(int64_t *)(iVar4 + 8) + 0x128);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230e61;
                        iVar6 = func_0x000180257b20(iVar2, iVar3, 0x87, uVar9);
                        if (iVar6 != 0) {
                            iVar8 = *in_RCX;
                            pcVar5 = *(code **)(*(int64_t *)(iVar8 + 8) + 0x118);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230e7c;
                            uVar9 = (*pcVar5)();
                            *(undefined8 *)(iVar8 + 0x80) = uVar9;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230e8b;
                            func_0x000180258be0(iVar10);
                            return 1;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230d8a;
                    func_0x000180258be0(iVar10);
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230d8f;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230da7;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230dc0;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
            }
            if (iVar8 != 0) {
                LOCK();
                piVar1 = (int32_t *)(iVar8 + 0x30);
                iVar6 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar6 < 2) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230ddc;
                    func_0x000180231190(iVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230ded;
                    func_0x000180223fb0(0x11, iVar8, iVar8 + 0x50);
                    uVar9 = *(undefined8 *)(iVar8 + 0x38);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230df6;
                    func_0x0001802227d0(uVar9);
                    uVar9 = *(undefined8 *)(iVar8 + 0x40);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230e06;
                    func_0x000180222050(uVar9, 0x18029aca0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180230e1b;
                    func_0x000180224990(iVar8, 0x1804e1cf0, 0x73e);
                }
                *in_RCX = 0;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180230ea0
// Address: 0x180230ea0
// Size: 739 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180230ea0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_b0h)
{
    undefined4 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    undefined4 *in_RCX;
    undefined8 in_RDX;
    int64_t iVar11;
    int64_t *in_R8;
    undefined8 in_R9;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180230ec4;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar11 = 0;
    iVar8 = 0;
    if (in_RCX == (undefined4 *)0x0) {
        return 0;
    }
    if (*(int64_t *)(in_RCX + 8) == 0) {
        iVar12 = *(int64_t *)(in_RCX + 0x1a);
    } else {
        if (*(int64_t *)(*(int64_t *)(in_RCX + 2) + 0x118) == 0) {
            return 0;
        }
        iVar12 = *(int64_t *)(*(int64_t *)(in_RCX + 2) + 0x120);
    }
    if (iVar12 == 0) {
        return 0;
    }
    iVar12 = 0;
    if (in_R8 == (int64_t *)0x0) {
code_r0x000180230f1d:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230f2b;
        iVar5 = func_0x000180259210(in_RDX, in_RCX, in_R9);
        if (iVar5 == 0) goto code_r0x00018023113c;
        iVar11 = *(int64_t *)(iVar5 + 0x20);
        *(undefined8 *)(iVar5 + 0x20) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230f47;
        func_0x000180258be0(iVar5);
        iVar12 = iVar11;
        if (iVar11 == 0) goto code_r0x00018023113c;
    } else {
        iVar11 = *in_R8;
        *in_R8 = 0;
        if (iVar11 == 0) goto code_r0x000180230f1d;
    }
    if (*(int64_t *)(in_RCX + 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180231139;
        iVar8 = func_0x00018029e9c0(in_RCX, iVar11, 0x87);
        goto code_r0x00018023113c;
    }
    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x118);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230f6a;
    iVar5 = (*pcVar2)();
    if (iVar5 == *(int64_t *)(in_RCX + 0x20)) {
        uVar7 = *(undefined8 *)(in_RCX + 0xe);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230f7c;
        iVar3 = func_0x000180222850(uVar7);
        if (iVar3 == 0) goto code_r0x00018023113c;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230f95;
        piVar6 = (int64_t *)func_0x00018029ec40(in_RCX, iVar11, 0x87);
        if ((piVar6 != (int64_t *)0x0) && (*piVar6 != 0)) {
            uVar7 = *(undefined8 *)(in_RCX + 0xe);
            iVar8 = piVar6[1];
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230fac;
            func_0x000180222910(uVar7);
            goto code_r0x00018023113c;
        }
        uVar7 = *(undefined8 *)(in_RCX + 0xe);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230fba;
        func_0x000180222910(uVar7);
    }
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230fc1;
    uVar7 = func_0x00018022ccf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230fcc;
    iVar3 = func_0x000180257a60(iVar11, uVar7);
    iVar8 = 0;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180230fdc;
        iVar8 = func_0x000180257fb0(iVar11);
        if (iVar8 != 0) {
            iVar5 = *(int64_t *)(in_RCX + 2);
            uVar7 = *(undefined8 *)(iVar11 + 200);
            *(undefined8 *)((int64_t)&var_8h + iVar4) = in_R9;
            pcVar2 = *(code **)(iVar5 + 0x120);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023100b;
            iVar3 = (*pcVar2)(in_RCX, iVar8, uVar7, in_RDX);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023101a;
                func_0x000180257c10(iVar11, iVar8);
                iVar8 = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180231026;
                iVar3 = func_0x000180257ae0(iVar11);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180231035;
                    func_0x000180257c10(iVar11, iVar8);
                    iVar8 = 0;
                } else {
                    uVar7 = *(undefined8 *)(in_RCX + 0xe);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180231045;
                    iVar3 = func_0x000180222950(uVar7);
                    if (iVar3 != 0) {
                        iVar5 = *(int64_t *)(in_RCX + 0x20);
                        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x118);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180231064;
                        iVar9 = (*pcVar2)(in_RCX);
                        if (iVar9 != iVar5) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180231071;
                            iVar3 = func_0x00018029e7c0(in_RCX);
                            if (iVar3 == 0) {
                                uVar7 = *(undefined8 *)(in_RCX + 0xe);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023107e;
                                func_0x000180222910(uVar7);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180231089;
                                func_0x000180257c10(iVar11, iVar8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180231093;
                                func_0x000180257a00(iVar11);
                                iVar8 = 0;
                                goto code_r0x00018023113c;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802310a0;
                        func_0x000180257a00(iVar11);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802310b1;
                        piVar6 = (int64_t *)func_0x00018029ec40(in_RCX, iVar11, 0x87);
                        if ((piVar6 == (int64_t *)0x0) || (*piVar6 == 0)) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802310ed;
                            iVar3 = func_0x00018029e550(in_RCX, iVar11, iVar8, 0x87);
                            if (iVar3 == 0) {
                                uVar7 = *(undefined8 *)(in_RCX + 0xe);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802310fa;
                                func_0x000180222910(uVar7);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180231105;
                                func_0x000180257c10(iVar11, iVar8);
                                iVar8 = 0;
                            } else {
                                pcVar2 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x118);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180231119;
                                uVar10 = (*pcVar2)(in_RCX);
                                uVar7 = *(undefined8 *)(in_RCX + 0xe);
                                *(undefined8 *)(in_RCX + 0x20) = uVar10;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180231129;
                                func_0x000180222910(uVar7);
                            }
                        } else {
                            uVar7 = *(undefined8 *)(in_RCX + 0xe);
                            iVar5 = piVar6[1];
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802310c9;
                            func_0x000180222910(uVar7);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802310d4;
                            func_0x000180257c10(iVar11, iVar8);
                            iVar8 = iVar5;
                        }
                    }
                }
            }
        }
    }
code_r0x00018023113c:
    iVar5 = 0;
    if (iVar8 != 0) {
        iVar5 = iVar11;
    }
    if ((in_R8 != (int64_t *)0x0) && (iVar5 != 0)) {
        *in_R8 = iVar5;
        iVar12 = 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023115d;
    func_0x000180257a00(iVar12);
    return iVar8;
}

// ============================================================
// Function: FUN_180231190
// Address: 0x180231190
// Size: 198 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180231190(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *in_RCX;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802311a5;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802311b0;
    func_0x00018029e7c0();
    iVar5 = *(int64_t *)(in_RCX + 2);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
    if (iVar5 == 0) {
        if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802311fd;
        uVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802311d2;
        iVar5 = func_0x000180247890((int64_t)&arg_28h + iVar4, uVar1);
        if (iVar5 == 0) goto code_r0x0001802311fd;
    }
    if (*(int64_t *)(in_RCX + 10) != 0) {
        *(int64_t *)(in_RCX + 8) = *(int64_t *)(in_RCX + 10);
        *(undefined8 *)(in_RCX + 10) = 0;
    }
    pcVar2 = *(code **)(iVar5 + 0xa8);
    if (pcVar2 != (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802311f9;
        (*pcVar2)(in_RCX);
    }
    *(undefined8 *)(in_RCX + 8) = 0;
code_r0x0001802311fd:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180231207;
    func_0x00018026aee0(*(undefined8 *)((int64_t)&arg_28h + iVar4));
    uVar3 = *(undefined8 *)(in_RCX + 4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180231210;
    func_0x00018026aee0(uVar3);
    uVar3 = *(undefined8 *)(in_RCX + 6);
    *(undefined8 *)(in_RCX + 4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023121d;
    func_0x00018026aee0(uVar3);
    iVar5 = *(int64_t *)(in_RCX + 0x18);
    *(undefined8 *)(in_RCX + 6) = 0;
    if (iVar5 != 0) {
        uVar3 = *(undefined8 *)(in_RCX + 0x1a);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180231233;
        func_0x000180257c10(iVar5, uVar3);
        uVar3 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023123c;
        func_0x000180257a00(uVar3);
        *(undefined8 *)(in_RCX + 0x18) = 0;
        *(undefined8 *)(in_RCX + 0x1a) = 0;
    }
    *in_RCX = 0;
    return;
}

// ============================================================
// Function: FUN_180231260
// Address: 0x180231260
// Size: 156 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180231260(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *in_RCX;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180231275;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = *(int64_t *)(in_RCX + 2);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
    if (iVar5 == 0) {
        if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802312c8;
        uVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023129d;
        iVar5 = func_0x000180247890((int64_t)&arg_28h + iVar4, uVar1);
        if (iVar5 == 0) goto code_r0x0001802312c8;
    }
    if (*(int64_t *)(in_RCX + 10) != 0) {
        *(int64_t *)(in_RCX + 8) = *(int64_t *)(in_RCX + 10);
        *(undefined8 *)(in_RCX + 10) = 0;
    }
    pcVar2 = *(code **)(iVar5 + 0xa8);
    if (pcVar2 != (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802312c4;
        (*pcVar2)(in_RCX);
    }
    *(undefined8 *)(in_RCX + 8) = 0;
code_r0x0001802312c8:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802312d2;
    func_0x00018026aee0(*(undefined8 *)((int64_t)&arg_28h + iVar4));
    uVar3 = *(undefined8 *)(in_RCX + 4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802312db;
    func_0x00018026aee0(uVar3);
    uVar3 = *(undefined8 *)(in_RCX + 6);
    *(undefined8 *)(in_RCX + 4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802312e8;
    func_0x00018026aee0(uVar3);
    *(undefined8 *)(in_RCX + 6) = 0;
    return;
}

// ============================================================
// Function: FUN_180231300
// Address: 0x180231300
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180231300(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180231310;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023131f;
    iVar1 = fcn.180299e80(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000050 + iVar2));
    if (iVar1 == in_EDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180231369;
        iVar3 = fcn.180231390(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180231379;
            iVar1 = fcn.18029e530(iVar3);
            if (iVar1 == 0) {
                iVar3 = 0;
            }
        }
        return iVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180231328;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180231340;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180231352;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_180231390
// Address: 0x180231390
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180231390(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t iVar6;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1802313a5;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
    if ((in_RCX != 0) && ((*(int64_t *)(in_RCX + 0x20) != 0 || (*(int64_t *)(in_RCX + 0x68) != 0)))) {
        if (*(int64_t *)(in_RCX + 0x60) == 0) {
            return *(int64_t *)(in_RCX + 0x20);
        }
        uVar2 = *(undefined8 *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802313e1;
        iVar4 = func_0x000180222850(uVar2);
        if (iVar4 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x38);
            iVar3 = *(int64_t *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802313f6;
            iVar4 = fcn.180222910(uVar2);
            if (iVar4 != 0) {
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180231428;
                    iVar4 = fcn.180230bd0(*(int64_t *)((int64_t)&arg_28h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar5));
                    iVar3 = *(int64_t *)((int64_t)&arg_28h + iVar5);
                    iVar6 = 0;
                    if (iVar4 != 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x38);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023143a;
                        iVar4 = fcn.180222950(uVar2);
                        if (iVar4 != 0) {
                            iVar6 = *(int64_t *)(in_RCX + 0x28);
                            if (iVar6 == 0) {
                                iVar6 = *(int64_t *)(iVar3 + 0x20);
                                *(int64_t *)(in_RCX + 0x28) = iVar6;
                                *(undefined8 *)(iVar3 + 0x20) = 0;
                            }
                            uVar2 = *(undefined8 *)(in_RCX + 0x38);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023145c;
                            iVar4 = fcn.180222910(uVar2);
                            if (iVar4 == 0) {
                                iVar6 = 0;
                            }
                        }
                    }
                    if (iVar3 != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar3 + 0x30);
                        iVar4 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar4 < 2) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023147e;
                            fcn.180231190(*(int64_t *)((int64_t)&var_18h + iVar5), 
                                          *(int64_t *)((int64_t)&var_20h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023148f;
                            fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar5), *(int64_t *)(&stack0x00000100 + iVar5)
                                         );
                            uVar2 = *(undefined8 *)(iVar3 + 0x38);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180231498;
                            func_0x0001802227d0(uVar2);
                            uVar2 = *(undefined8 *)(iVar3 + 0x40);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802314a8;
                            func_0x000180222050(uVar2, 0x18029aca0);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802314bd;
                            fcn.180224990(iVar3, 0x1804e1cf0, 0x73e);
                        }
                    }
                    return iVar6;
                }
                return iVar3;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180231419
// Address: 0x180231419
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180231390(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t iVar6;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1802313a5;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
    if ((in_RCX != 0) && ((*(int64_t *)(in_RCX + 0x20) != 0 || (*(int64_t *)(in_RCX + 0x68) != 0)))) {
        if (*(int64_t *)(in_RCX + 0x60) == 0) {
            return *(int64_t *)(in_RCX + 0x20);
        }
        uVar2 = *(undefined8 *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802313e1;
        iVar4 = func_0x000180222850(uVar2);
        if (iVar4 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x38);
            iVar3 = *(int64_t *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802313f6;
            iVar4 = fcn.180222910(uVar2);
            if (iVar4 != 0) {
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180231428;
                    iVar4 = fcn.180230bd0(*(int64_t *)((int64_t)&arg_28h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar5));
                    iVar3 = *(int64_t *)((int64_t)&arg_28h + iVar5);
                    iVar6 = 0;
                    if (iVar4 != 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x38);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023143a;
                        iVar4 = fcn.180222950(uVar2);
                        if (iVar4 != 0) {
                            iVar6 = *(int64_t *)(in_RCX + 0x28);
                            if (iVar6 == 0) {
                                iVar6 = *(int64_t *)(iVar3 + 0x20);
                                *(int64_t *)(in_RCX + 0x28) = iVar6;
                                *(undefined8 *)(iVar3 + 0x20) = 0;
                            }
                            uVar2 = *(undefined8 *)(in_RCX + 0x38);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023145c;
                            iVar4 = fcn.180222910(uVar2);
                            if (iVar4 == 0) {
                                iVar6 = 0;
                            }
                        }
                    }
                    if (iVar3 != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar3 + 0x30);
                        iVar4 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar4 < 2) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023147e;
                            fcn.180231190(*(int64_t *)((int64_t)&var_18h + iVar5), 
                                          *(int64_t *)((int64_t)&var_20h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023148f;
                            fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar5), *(int64_t *)(&stack0x00000100 + iVar5)
                                         );
                            uVar2 = *(undefined8 *)(iVar3 + 0x38);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180231498;
                            func_0x0001802227d0(uVar2);
                            uVar2 = *(undefined8 *)(iVar3 + 0x40);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802314a8;
                            func_0x000180222050(uVar2, 0x18029aca0);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802314bd;
                            fcn.180224990(iVar3, 0x1804e1cf0, 0x73e);
                        }
                    }
                    return iVar6;
                }
                return iVar3;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802314d5
// Address: 0x1802314d5
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180231390(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t iVar6;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1802313a5;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
    if ((in_RCX != 0) && ((*(int64_t *)(in_RCX + 0x20) != 0 || (*(int64_t *)(in_RCX + 0x68) != 0)))) {
        if (*(int64_t *)(in_RCX + 0x60) == 0) {
            return *(int64_t *)(in_RCX + 0x20);
        }
        uVar2 = *(undefined8 *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802313e1;
        iVar4 = func_0x000180222850(uVar2);
        if (iVar4 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x38);
            iVar3 = *(int64_t *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802313f6;
            iVar4 = fcn.180222910(uVar2);
            if (iVar4 != 0) {
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180231428;
                    iVar4 = fcn.180230bd0(*(int64_t *)((int64_t)&arg_28h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar5));
                    iVar3 = *(int64_t *)((int64_t)&arg_28h + iVar5);
                    iVar6 = 0;
                    if (iVar4 != 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0x38);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023143a;
                        iVar4 = fcn.180222950(uVar2);
                        if (iVar4 != 0) {
                            iVar6 = *(int64_t *)(in_RCX + 0x28);
                            if (iVar6 == 0) {
                                iVar6 = *(int64_t *)(iVar3 + 0x20);
                                *(int64_t *)(in_RCX + 0x28) = iVar6;
                                *(undefined8 *)(iVar3 + 0x20) = 0;
                            }
                            uVar2 = *(undefined8 *)(in_RCX + 0x38);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023145c;
                            iVar4 = fcn.180222910(uVar2);
                            if (iVar4 == 0) {
                                iVar6 = 0;
                            }
                        }
                    }
                    if (iVar3 != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar3 + 0x30);
                        iVar4 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar4 < 2) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023147e;
                            fcn.180231190(*(int64_t *)((int64_t)&var_18h + iVar5), 
                                          *(int64_t *)((int64_t)&var_20h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023148f;
                            fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar5), *(int64_t *)(&stack0x00000100 + iVar5)
                                         );
                            uVar2 = *(undefined8 *)(iVar3 + 0x38);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180231498;
                            func_0x0001802227d0(uVar2);
                            uVar2 = *(undefined8 *)(iVar3 + 0x40);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802314a8;
                            func_0x000180222050(uVar2, 0x18029aca0);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802314bd;
                            fcn.180224990(iVar3, 0x1804e1cf0, 0x73e);
                        }
                    }
                    return iVar6;
                }
                return iVar3;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802314f0
// Address: 0x1802314f0
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1802314f0(int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint32_t *puVar7;
    undefined8 in_RCX;
    uint64_t uVar8;
    undefined8 *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180231505;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar9 = (undefined8 *)0x1804e1c18;
    uVar8 = 0;
    do {
        uVar2 = *puVar9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023151f;
        iVar3 = func_0x000180223670(in_RCX, uVar2);
        if (iVar3 == 0) {
            return (uint64_t)*(uint32_t *)(uVar8 * 0x10 + 0x1804e1c10);
        }
        uVar8 = uVar8 + 1;
        puVar9 = puVar9 + 2;
    } while (uVar8 < 0xc);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180231538;
    func_0x00018022d080(in_RCX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023153f;
    uVar8 = fcn.180299e80(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), *(int64_t *)(&stack0x00000050 + iVar5));
    if ((int32_t)uVar8 != 0) {
        return uVar8;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18023154b;
    uVar4 = func_0x00018022ca40(in_RCX);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = 0x180299e8c;
    iVar6 = fcn.18045a350(uVar4);
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5 + -8) = 0x180299e9b;
    puVar7 = (uint32_t *)
             fcn.180247890(*(int64_t *)(&stack0x00000170 + iVar6 + iVar5), 
                           *(int64_t *)(&stack0x00000190 + iVar6 + iVar5), 
                           *(int64_t *)(&stack0x00000198 + iVar6 + iVar5), 
                           *(int64_t *)(&stack0x000001b8 + iVar6 + iVar5));
    if (puVar7 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5 + -8) = 0x180299ec0;
        fcn.18026aee0(*(int64_t *)(&stack0x00000040 + iVar6 + iVar5));
        return 0;
    }
    uVar1 = *puVar7;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5 + -8) = 0x180299eac;
    fcn.18026aee0(*(int64_t *)(&stack0x00000040 + iVar6 + iVar5));
    return (uint64_t)uVar1;
}

// ============================================================
// Function: FUN_180231580
// Address: 0x180231580
// Size: 71 bytes
// ============================================================
undefined8 fcn.180231580(int32_t param_1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int32_t *piVar5;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = 0;
    piVar5 = (int32_t *)0x1804e1c10;
    do {
        if (param_1 == *piVar5) {
            return *(undefined8 *)(uVar4 * 0x10 + 0x1804e1c18);
        }
        uVar4 = uVar4 + 1;
        piVar5 = piVar5 + 4;
    } while (uVar4 < 0xc);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022ccfa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x18022cd02;
    puVar2 = (undefined8 *)
             fcn.18022cba0(*(int64_t *)(&stack0x00000048 + iVar1 + iVar3), 
                           *(int64_t *)(&stack0x00000050 + iVar1 + iVar3), 
                           *(int64_t *)(&stack0x00000060 + iVar1 + iVar3), 
                           *(int64_t *)(&stack0x00000080 + iVar1 + iVar3));
    if (puVar2 == (undefined8 *)0x0) {
        return 0;
    }
    return *puVar2;
}

// ============================================================
// Function: FUN_1802315d0
// Address: 0x1802315d0
// Size: 182 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1802315d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t *piVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t var_8h;
    undefined8 uStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802315e5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802315f3;
    func_0x000180229b10();
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802315fb;
    uVar5 = func_0x000180498cd0();
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = 0;
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180231619;
        iVar8 = func_0x0001802479a0((int64_t)&arg_30h + iVar7, in_RCX, uVar5);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180231626;
    fcn.18026aee0(*(int64_t *)((int64_t)&iStackX_20 + iVar7));
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180231630;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180231648;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023165a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
    } else if (*in_RDX == 0) {
        *in_RDX = in_RCX;
    } else if (in_RDX[1] == 0) {
        in_RDX[1] = in_RCX;
    }
    uVar3 = *(undefined8 *)((int64_t)&arg_38h + iVar7);
    uVar11 = *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + -8);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + -8) = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar7) = 0x1802299dc;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar8 + iVar7) = 0x1802299e4;
    iVar6 = func_0x000180221280();
    if (iVar6 != 0) {
        iVar9 = *(int32_t *)(iVar6 + 0x344);
        iVar4 = *(int32_t *)(iVar6 + 0x340);
        if (iVar9 != iVar4) {
            *(undefined8 *)((int64_t)&arg_48h + iVar8 + iVar7) = uVar3;
            *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = uVar11;
            do {
                iVar10 = (int64_t)iVar4;
                if (*(int32_t *)(iVar6 + 0x40 + iVar10 * 4) != 0) break;
                if ((*(uint8_t *)(iVar6 + 0x1c0 + iVar10 * 4) & 1) == 0) {
                    *(undefined8 *)(iVar6 + 0xc0 + iVar10 * 8) = 0;
                    *(undefined8 *)(iVar6 + 0x140 + iVar10 * 8) = 0;
                    *(undefined4 *)(iVar6 + 0x1c0 + iVar10 * 4) = 0;
                } else {
                    puVar2 = *(undefined **)(iVar6 + 0xc0 + iVar10 * 8);
                    if (puVar2 != (undefined *)0x0) {
                        *puVar2 = 0;
                        *(undefined4 *)(iVar6 + 0x1c0 + iVar10 * 4) = 1;
                    }
                }
                *(undefined4 *)(iVar6 + 0x40 + iVar10 * 4) = 0;
                *(undefined4 *)(iVar6 + iVar10 * 4) = 0;
                *(undefined4 *)(iVar6 + 0x80 + iVar10 * 4) = 0;
                *(undefined4 *)(iVar6 + 0x280 + iVar10 * 4) = 0xffffffff;
                uVar3 = *(undefined8 *)(iVar6 + 0x200 + iVar10 * 8);
                *(undefined8 *)((int64_t)&uStackX_10 + iVar8 + iVar7) = 0x180229a8e;
                fcn.180224990(uVar3, 0x1804bf6a0, 0x5b);
                uVar3 = *(undefined8 *)(iVar6 + 0x2c0 + iVar10 * 8);
                *(undefined8 *)(iVar6 + 0x200 + iVar10 * 8) = 0;
                *(undefined8 *)((int64_t)&uStackX_10 + iVar8 + iVar7) = 0x180229ab0;
                fcn.180224990(uVar3, 0x1804bf6a0, 0x5d);
                *(undefined8 *)(iVar6 + 0x2c0 + iVar10 * 8) = 0;
                if (*(int32_t *)(iVar6 + 0x340) < 1) {
                    iVar4 = 0xf;
                } else {
                    iVar4 = *(int32_t *)(iVar6 + 0x340) + -1;
                }
                *(int32_t *)(iVar6 + 0x340) = iVar4;
                iVar9 = *(int32_t *)(iVar6 + 0x344);
            } while (iVar9 != iVar4);
            if (iVar9 != iVar4) {
                piVar1 = (int32_t *)(iVar6 + 0x40 + (int64_t)iVar4 * 4);
                *piVar1 = *piVar1 + -1;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180231690
// Address: 0x180231690
// Size: 403 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_59h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Detected overlap for variable arg_65h
// WARNING: [rz-ghidra] Detected overlap for variable arg_67h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Removing arg arg_29h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_49h because it doesn't fit into ProtoModel

void fcn.180231690(int64_t arg_68h, int64_t arg_a0h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802316a3;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_68h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *(int64_t *)(in_RCX + 0x60);
    if ((iVar1 != 0) && (in_EDX == 3)) {
        *(undefined *)((int64_t)&var_18h + iVar5) = 0;
        *(undefined8 *)(&stack0x00000059 + iVar5) = 0;
        *(undefined4 *)(&stack0x00000061 + iVar5) = 0;
        *(undefined2 *)(&stack0x00000065 + iVar5) = 0;
        (&stack0x00000067)[iVar5] = 0;
        iVar2 = *(int64_t *)(in_RCX + 8);
        *(undefined (*) [16])((int64_t)&var_18h + iVar5 + 1) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00000029 + iVar5) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00000039 + iVar5) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00000049 + iVar5) = ZEXT816(0);
        if (iVar2 == 0) {
            uVar6 = *(undefined8 *)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180231727;
            iVar4 = func_0x00018029ee90(iVar1, uVar6, (int64_t)&var_18h + iVar5, 0x50);
        } else {
            *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
            pcVar3 = *(code **)(iVar2 + 0xb0);
            if (pcVar3 == (code *)0x0) {
                iVar4 = -2;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180231759;
                iVar4 = (*pcVar3)(in_RCX, 3, 0, (int64_t)&var_8h + iVar5);
                if (0 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180231768;
                    uVar6 = func_0x00018022ccf0(*(undefined4 *)((int64_t)&var_8h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023177b;
                    func_0x000180223790((int64_t)&var_18h + iVar5, uVar6, 0x50);
                }
            }
        }
        if (0 < iVar4) {
            uVar6 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x60) + 0x20);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023178c;
            uVar6 = func_0x00018027f1e0(uVar6);
            *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023179c;
            func_0x000180229b10();
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802317ac;
            uVar7 = func_0x000180215540(uVar6, (int64_t)&var_18h + iVar5, 0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802317b4;
            func_0x0001802299d0();
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802317bc;
            uVar6 = func_0x000180299670(uVar6);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802317c7;
            func_0x000180215590(uVar7);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802317d4;
            iVar4 = func_0x0001802993f0(uVar6, (int64_t)&var_18h + iVar5);
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802317ee;
                iVar4 = func_0x000180299310(uVar6, iVar4, 0x180231830, (int64_t)&var_8h + iVar5);
                if (iVar4 != 0) {
                    *in_R9 = *(undefined4 *)((int64_t)&var_8h + iVar5);
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023180f;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_180231830
// Address: 0x180231830
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180231830(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180231840;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180231853;
        iVar1 = fcn.18022d080(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
        *in_RDX = iVar1;
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180231861;
            iVar1 = fcn.18022ca40(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar2));
            *in_RDX = iVar1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180231870
// Address: 0x180231870
// Size: 1082 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180231870(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_88h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 uVar10;
    undefined8 in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180231897;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    var_b8h = 0;
    iVar3 = (int32_t)in_R9;
    iVar6 = 0;
    if (arg_28h == 0) {
        var_b0h = 0;
        if (in_RDX == 0) {
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802318e7;
                iVar5 = fcn.180247890(*(int64_t *)(&stack0x00000130 + iVar4), *(int64_t *)(&stack0x00000150 + iVar4), 
                                      *(int64_t *)(&stack0x00000158 + iVar4), *(int64_t *)(&stack0x00000178 + iVar4));
                goto code_r0x0001802318e7;
            }
code_r0x000180231903:
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231908;
            fcn.18026aee0(*(int64_t *)(&stack0x00000000 + iVar4));
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802318d6;
            iVar5 = func_0x0001802479a0(&var_b0h);
code_r0x0001802318e7:
            if (var_b0h == 0) goto code_r0x000180231903;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802318f8;
            fcn.18026aee0(*(int64_t *)(&stack0x00000000 + iVar4));
            iVar6 = 0;
            if (iVar5 != 0) goto code_r0x000180231a0d;
        }
        iVar6 = in_RDX;
        if (in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231919;
            iVar6 = func_0x00018022ccf0(in_R9 & 0xffffffff);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231927;
        iVar6 = func_0x0001802591e0(in_RCX, iVar6, in_R8);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231938;
            func_0x000180229b10();
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231940;
            iVar2 = func_0x00018025a8a0();
            if (iVar2 != 1) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231a0d;
                func_0x0001802299d0();
                goto code_r0x000180231a0d;
            }
            var_a8h = 0;
            var_a0h._0_4_ = 0;
            var_98h = 0;
            var_90h = 0;
            var_88h = 0;
            var_80h = 0;
            var_78h._0_4_ = 0;
            var_70h = 0;
            var_68h = 0;
            var_60h = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231976;
            func_0x000180229900();
            uVar10 = 0x1804afebc;
            if ((int32_t)arg_40h != 0) {
                uVar10 = 0x1804e1d44;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18023199c;
            piVar7 = (int64_t *)func_0x000180229c70(&var_58h, uVar10, arg_30h, arg_38h);
            var_a8h = *piVar7;
            var_a0h._0_4_ = *(undefined4 *)(piVar7 + 1);
            var_a0h._4_4_ = *(undefined4 *)((int64_t)piVar7 + 0xc);
            var_98h = piVar7[2];
            var_90h = piVar7[3];
            var_88h = piVar7[4];
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802319cb;
            iVar3 = func_0x00018025a780(iVar6, &var_b8h, 0x87, &var_a8h);
            if (iVar3 == 1) goto code_r0x000180231c7d;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802319d9;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802319f1;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231a03;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
        }
    } else {
code_r0x000180231a0d:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231a12;
        piVar8 = (int32_t *)func_0x00018022fd80();
        var_b8h = (int64_t)piVar8;
        if (piVar8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231a23;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231a3b;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4));
        } else {
            piVar9 = (int64_t *)0x0;
            piVar7 = &arg_28h;
            if (arg_28h != 0) {
                piVar7 = piVar9;
            }
            if ((*(int64_t *)(piVar8 + 8) != 0) || (*(int64_t *)(piVar8 + 0x1a) != 0)) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231a70;
                fcn.180231190(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&var_8h + iVar4));
            }
            if (((*piVar8 == 0) || (iVar3 != piVar8[1])) || (*(int64_t *)(piVar8 + 2) == 0)) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231a8c;
                fcn.18026aee0(*(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)(piVar8 + 4) = 0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231a99;
                fcn.18026aee0(*(int64_t *)(&stack0x00000000 + iVar4));
                *(undefined8 *)(piVar8 + 6) = 0;
                if (in_RDX == 0) {
                    if (iVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231ac2;
                        piVar9 = (int64_t *)
                                 fcn.180247890(*(int64_t *)(&stack0x00000130 + iVar4), 
                                               *(int64_t *)(&stack0x00000150 + iVar4), 
                                               *(int64_t *)(&stack0x00000158 + iVar4), 
                                               *(int64_t *)(&stack0x00000178 + iVar4));
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231ab2;
                    piVar9 = (int64_t *)func_0x0001802479a0(piVar7, in_RDX, 0xffffffff);
                }
                if (piVar9 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231bf1;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4)
                                 );
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231c09;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4)
                                  , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4));
                    goto code_r0x000180231c0e;
                }
                *(undefined8 *)(piVar8 + 0x18) = 0;
                piVar8[1] = iVar3;
                *piVar8 = iVar3;
                *(int64_t **)(piVar8 + 2) = piVar9;
                if (iVar3 == 0) {
                    *piVar8 = *(int32_t *)piVar9;
                }
                if ((piVar7 == (int64_t *)0x0) && (arg_28h != 0)) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231afb;
                    iVar3 = func_0x00018026b010(arg_28h);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231b04;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)(&stack0x00000000 + iVar4));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231b1c;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                      *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
                        goto code_r0x000180231c0e;
                    }
                }
                *(int64_t *)(piVar8 + 4) = arg_28h;
            }
            iVar5 = *(int64_t *)(var_b8h + 8);
            if (iVar5 == 0) goto code_r0x000180231c1d;
            if ((int32_t)arg_40h == 0) {
                pcVar1 = *(code **)(iVar5 + 0x100);
                if (pcVar1 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231bd8;
                    iVar3 = (*pcVar1)(var_b8h, arg_30h, arg_38h);
                    if (iVar3 != 0) goto code_r0x000180231c7d;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231be5;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4)
                                 );
                    goto code_r0x000180231b98;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231bc3;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            } else {
                pcVar1 = *(code **)(iVar5 + 0xf8);
                if (pcVar1 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231b86;
                    iVar3 = (*pcVar1)(var_b8h, arg_30h, arg_38h);
                    if (iVar3 != 0) goto code_r0x000180231c7d;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231b93;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4)
                                 );
code_r0x000180231b98:
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231bab;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4)
                                  , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4));
                    goto code_r0x000180231c0e;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231b56;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231b6e;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4));
        }
code_r0x000180231c0e:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231c1b;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
    }
code_r0x000180231c1d:
    iVar5 = var_b8h;
    if (var_b8h != 0) {
        LOCK();
        piVar8 = (int32_t *)(var_b8h + 0x30);
        iVar3 = *piVar8;
        *piVar8 = *piVar8 + -1;
        UNLOCK();
        if (iVar3 < 2) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231c3a;
            fcn.180231190(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_8h + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231c4b;
            fcn.180223fb0(*(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x000000e0 + iVar4));
            uVar10 = *(undefined8 *)(iVar5 + 0x38);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231c54;
            func_0x0001802227d0(uVar10);
            uVar10 = *(undefined8 *)(iVar5 + 0x40);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231c64;
            func_0x000180222050(uVar10, 0x18029aca0);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231c79;
            fcn.180224990(iVar5, 0x1804e1cf0, 0x73e);
        }
    }
    var_b8h = 0;
code_r0x000180231c7d:
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180231c85;
    func_0x000180258be0(iVar6);
    return var_b8h;
}

// ============================================================
// Function: FUN_180231cb0
// Address: 0x180231cb0
// Size: 27 bytes
// ============================================================
int64_t fcn.180231cb0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = 0x43f;
    *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180231310;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x18023131f;
    iVar1 = fcn.180299e80(*(int64_t *)(&stack0x00000048 + iVar2 + iVar4), *(int64_t *)(&stack0x00000078 + iVar2 + iVar4)
                         );
    if (iVar1 == iVar5) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231369;
        iVar3 = fcn.180231390(*(int64_t *)(&stack0x00000040 + iVar2 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar2 + iVar4), 
                              *(int64_t *)(&stack0x00000050 + iVar2 + iVar4), 
                              *(int64_t *)(&stack0x00000058 + iVar2 + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231379;
            iVar1 = fcn.18029e530(iVar3);
            if (iVar1 == 0) {
                iVar3 = 0;
            }
        }
        return iVar3;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231328;
    fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar2 + iVar4), *(int64_t *)(&stack0x00000048 + iVar2 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231340;
    fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar4), *(int64_t *)(&stack0x00000048 + iVar2 + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar2 + iVar4), *(int64_t *)(&stack0x00000058 + iVar2 + iVar4), 
                  *(int64_t *)(&stack0x00000070 + iVar2 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231352;
    fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar2 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180231cd0
// Address: 0x180231cd0
// Size: 27 bytes
// ============================================================
int64_t fcn.180231cd0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = 0x440;
    *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180231310;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x18023131f;
    iVar1 = fcn.180299e80(*(int64_t *)(&stack0x00000048 + iVar2 + iVar4), *(int64_t *)(&stack0x00000078 + iVar2 + iVar4)
                         );
    if (iVar1 == iVar5) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231369;
        iVar3 = fcn.180231390(*(int64_t *)(&stack0x00000040 + iVar2 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar2 + iVar4), 
                              *(int64_t *)(&stack0x00000050 + iVar2 + iVar4), 
                              *(int64_t *)(&stack0x00000058 + iVar2 + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231379;
            iVar1 = fcn.18029e530(iVar3);
            if (iVar1 == 0) {
                iVar3 = 0;
            }
        }
        return iVar3;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231328;
    fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar2 + iVar4), *(int64_t *)(&stack0x00000048 + iVar2 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231340;
    fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar4), *(int64_t *)(&stack0x00000048 + iVar2 + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar2 + iVar4), *(int64_t *)(&stack0x00000058 + iVar2 + iVar4), 
                  *(int64_t *)(&stack0x00000070 + iVar2 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231352;
    fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar2 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180231cf0
// Address: 0x180231cf0
// Size: 27 bytes
// ============================================================
int64_t fcn.180231cf0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = 0x40a;
    *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180231310;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x18023131f;
    iVar1 = fcn.180299e80(*(int64_t *)(&stack0x00000048 + iVar2 + iVar4), *(int64_t *)(&stack0x00000078 + iVar2 + iVar4)
                         );
    if (iVar1 == iVar5) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231369;
        iVar3 = fcn.180231390(*(int64_t *)(&stack0x00000040 + iVar2 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar2 + iVar4), 
                              *(int64_t *)(&stack0x00000050 + iVar2 + iVar4), 
                              *(int64_t *)(&stack0x00000058 + iVar2 + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231379;
            iVar1 = fcn.18029e530(iVar3);
            if (iVar1 == 0) {
                iVar3 = 0;
            }
        }
        return iVar3;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231328;
    fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar2 + iVar4), *(int64_t *)(&stack0x00000048 + iVar2 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231340;
    fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar4), *(int64_t *)(&stack0x00000048 + iVar2 + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar2 + iVar4), *(int64_t *)(&stack0x00000058 + iVar2 + iVar4), 
                  *(int64_t *)(&stack0x00000070 + iVar2 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231352;
    fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar2 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180231d10
// Address: 0x180231d10
// Size: 27 bytes
// ============================================================
int64_t fcn.180231d10(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = 0x40b;
    *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180231310;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x18023131f;
    iVar1 = fcn.180299e80(*(int64_t *)(&stack0x00000048 + iVar2 + iVar4), *(int64_t *)(&stack0x00000078 + iVar2 + iVar4)
                         );
    if (iVar1 == iVar5) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231369;
        iVar3 = fcn.180231390(*(int64_t *)(&stack0x00000040 + iVar2 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar2 + iVar4), 
                              *(int64_t *)(&stack0x00000050 + iVar2 + iVar4), 
                              *(int64_t *)(&stack0x00000058 + iVar2 + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231379;
            iVar1 = fcn.18029e530(iVar3);
            if (iVar1 == 0) {
                iVar3 = 0;
            }
        }
        return iVar3;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231328;
    fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar2 + iVar4), *(int64_t *)(&stack0x00000048 + iVar2 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231340;
    fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar4), *(int64_t *)(&stack0x00000048 + iVar2 + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar2 + iVar4), *(int64_t *)(&stack0x00000058 + iVar2 + iVar4), 
                  *(int64_t *)(&stack0x00000070 + iVar2 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar4) = 0x180231352;
    fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar2 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180231d30
// Address: 0x180231d30
// Size: 474 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180231d30(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_68h,
                     int64_t arg_c0h)
{
    undefined4 uVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined4 *in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180231d52;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar5 = -2;
    bVar2 = false;
    iVar3 = 0;
    if (0 < (int32_t)in_R8) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231d8b;
        iVar3 = func_0x000180219d10(in_RDX, 0x51, 0, 0);
        if (iVar3 < 0) {
            iVar3 = 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231da6;
        iVar4 = func_0x000180219d10(in_RDX, 0x50, in_R8 & 0xffffffff, 0);
        if (iVar4 < 1) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231daf;
            uVar7 = func_0x000180299e70();
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231db7;
            iVar8 = func_0x00018021a7c0(uVar7);
            if (iVar8 == 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231dc7;
            in_RDX = func_0x00018021a960(iVar8, in_RDX);
            bVar2 = true;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231de3;
        iVar4 = func_0x000180219d10(in_RDX, 0x50, in_R8 & 0xffffffff, 0);
        if (iVar4 < 1) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231dfa;
            func_0x000180219d10(in_RDX, 0x50, iVar3, 0);
            if (bVar2) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231e07;
                func_0x00018021a8e0(in_RDX);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231e0f;
                func_0x000180219f80(in_RDX);
            }
            return 0;
        }
    }
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = *(undefined8 *)((int64_t)&arg_58h + iVar6);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231e38;
    uVar7 = func_0x00018029d9e0(in_RCX, in_R9 & 0xffffffff, 0x1804e1dd0, 0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231e43;
    iVar4 = func_0x0001802705e0(uVar7);
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231e52;
        iVar5 = func_0x00018029ca20(uVar7, in_RDX);
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231e5c;
    func_0x00018029b870(uVar7);
    if (iVar5 == -2) {
        if (*(code **)(&stack0x00000060 + iVar6) == (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231e92;
            iVar5 = func_0x00018021a4a0(in_RDX, 0, 0x80);
            if (iVar5 != 0) {
                uVar1 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231e9e;
                uVar7 = func_0x00018022cb70(uVar1);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231eb7;
                iVar4 = func_0x000180245e70(in_RDX, 0x1804e1db0, 0x1804e1dd8, uVar7);
                iVar5 = 1;
                if (0 < iVar4) goto code_r0x000180231ec3;
            }
            iVar5 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231e81;
            iVar5 = (**(code **)(&stack0x00000060 + iVar6))
                              (in_RDX, in_RCX, 0, *(undefined8 *)((int64_t)&arg_68h + iVar6));
        }
    }
code_r0x000180231ec3:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231ed6;
    func_0x000180219d10(in_RDX, 0x50, iVar3, 0);
    if (bVar2) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231ee3;
        func_0x00018021a8e0(in_RDX);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180231eeb;
        func_0x000180219f80(in_RDX);
    }
    return iVar5;
}

// ============================================================
// Function: FUN_180231f10
// Address: 0x180231f10
// Size: 161 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180231f54: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180231f59)
// WARNING: Removing unreachable block (ram,0x000180231f5f)
// WARNING: Removing unreachable block (ram,0x000180231f8e)

undefined8 fcn.180231f10(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t in_RCX;
    int64_t iVar8;
    int32_t in_EDX;
    int32_t iVar9;
    int64_t iVar10;
    undefined *puVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    char *in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    char *pcVar12;
    char *pcVar13;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iStackX_18;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x180231f1c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RCX + 0x10);
    if (in_EDX != 2) {
        return 0;
    }
    if (in_R9D == 3) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f36;
        uVar4 = func_0x0001802a7350();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f3e;
        in_R8 = (char *)func_0x000180275160(uVar4);
        if (in_R8 == (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f48;
            in_R8 = (char *)func_0x0001802a7320();
        }
        in_R9D = 1;
        puVar11 = (undefined *)((int64_t)&uStack_10 + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f59;
        iVar10 = iVar8;
    } else {
        iVar10 = *(int64_t *)((int64_t)&iStackX_18 + iVar3);
        puVar11 = auStackX_20 + iVar3;
    }
    *(undefined8 *)(puVar11 + -8) = unaff_RDI;
    *(undefined8 *)(puVar11 + -0x10) = unaff_R12;
    *(undefined8 *)(puVar11 + -0x18) = unaff_R13;
    *(undefined8 *)(puVar11 + -0x20) = 0x180232680;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_R8 == (char *)0x0) || (cVar1 = *in_R8, cVar1 == '\0')) {
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232878;
        fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232890;
        fcn.1802295a0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10), 
                      *(int64_t *)(puVar11 + iVar3 + 0x18), *(int64_t *)(puVar11 + iVar3 + 0x20), 
                      *(int64_t *)(puVar11 + iVar3 + 0x38));
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802328a2;
        fcn.1802296d0(*(int64_t *)(puVar11 + iVar3 + 0x28));
        return 0;
    }
    *(int64_t *)(puVar11 + iVar3 + 0x38) = iVar10;
    *(undefined8 *)(puVar11 + iVar3 + 0x40) = unaff_RBP;
    *(undefined8 *)(puVar11 + iVar3 + 0x48) = unaff_RSI;
    *(undefined8 *)(puVar11 + iVar3 + 0x10) = unaff_R14;
    *(undefined8 *)(puVar11 + iVar3 + 8) = unaff_R15;
    pcVar12 = in_R8;
    do {
        if ((cVar1 == ';') || (pcVar13 = pcVar12, *in_R8 == '\0')) {
            pcVar13 = in_R8 + 1;
            iVar10 = (int64_t)in_R8 - (int64_t)pcVar12;
            if (iVar10 != 0) {
                uVar4 = *(undefined8 *)(iVar8 + 8);
                iVar9 = 0;
                *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802326ec;
                iVar2 = func_0x000180222010(uVar4);
                if (0 < iVar2) {
                    do {
                        uVar4 = *(undefined8 *)(iVar8 + 8);
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802326fb;
                        puVar5 = (undefined8 *)func_0x000180222340(uVar4, iVar9);
                        uVar4 = *puVar5;
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232706;
                        iVar6 = func_0x000180498cd0(uVar4);
                        if (iVar6 == iVar10) {
                            *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232719;
                            iVar2 = func_0x000180498f90(uVar4, pcVar12, iVar10);
                            if (iVar2 == 0) break;
                        }
                        uVar4 = *(undefined8 *)(iVar8 + 8);
                        iVar9 = iVar9 + 1;
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232728;
                        iVar2 = func_0x000180222010(uVar4);
                    } while (iVar9 < iVar2);
                }
                uVar4 = *(undefined8 *)(iVar8 + 8);
                *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232735;
                iVar2 = func_0x000180222010(uVar4);
                if (iVar2 <= iVar9) {
                    if (*(int64_t *)(iVar8 + 8) == 0) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232749;
                        iVar6 = func_0x000180221f20();
                        *(int64_t *)(iVar8 + 8) = iVar6;
                        if (iVar6 == 0) {
                            *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327f8;
                            fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
                            goto code_r0x000180232804;
                        }
                    }
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023276d;
                    piVar7 = (int64_t *)func_0x0001802248d0(0x18, 0x1804e1f78, 0xca);
                    if (piVar7 == (int64_t *)0x0) {
                        return 0;
                    }
                    *(int32_t *)(piVar7 + 1) = in_R9D;
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232789;
                    uVar4 = func_0x000180221ee0(0x180232910);
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232798;
                    iVar6 = func_0x000180222290(uVar4, 0x180196ec0);
                    piVar7[2] = iVar6;
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327b4;
                    iVar10 = func_0x000180223270(pcVar12, iVar10, 0x1804e1f78, 0xcf);
                    *piVar7 = iVar10;
                    if ((iVar10 == 0) || (piVar7[2] == 0)) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023286a;
                        func_0x0001802328b0(piVar7);
                        return 0;
                    }
                    uVar4 = *(undefined8 *)(iVar8 + 8);
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327d7;
                    iVar2 = func_0x000180222110(uVar4, piVar7);
                    if (iVar2 == 0) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023284f;
                        func_0x0001802328b0(piVar7);
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232854;
                        fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
code_r0x000180232804:
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232810;
                        fcn.1802295a0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10), 
                                      *(int64_t *)(puVar11 + iVar3 + 0x18), *(int64_t *)(puVar11 + iVar3 + 0x20), 
                                      *(int64_t *)(puVar11 + iVar3 + 0x38));
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232822;
                        fcn.1802296d0(*(int64_t *)(puVar11 + iVar3 + 0x28));
                        return 0;
                    }
                }
            }
        }
        cVar1 = *in_R8;
        in_R8 = in_R8 + 1;
        if (cVar1 == '\0') {
            return 1;
        }
        cVar1 = *in_R8;
        pcVar12 = pcVar13;
    } while( true );
}

// ============================================================
// Function: FUN_180231fc0
// Address: 0x180231fc0
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180231fc0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180231fd0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180231fed;
    piVar2 = (int64_t *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (piVar2 == (int64_t *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023200a;
    iVar3 = fcn.180226610();
    *piVar2 = iVar3;
    if (iVar3 != 0) {
        piVar2[1] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023202b;
        iVar3 = fcn.180222800();
        piVar2[2] = iVar3;
        if (iVar3 != 0) {
            *(int64_t **)(in_RCX + 0x10) = piVar2;
            return 1;
        }
        iVar3 = *piVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023203c;
        fcn.180226310(iVar3);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023204b;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180232060;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023206f;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180232084;
    fcn.180224990(piVar2, 0x1804e1f78, 0x82);
    return 0;
}

// ============================================================
// Function: FUN_180232000
// Address: 0x180232000
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180231fc0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180231fd0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180231fed;
    piVar2 = (int64_t *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (piVar2 == (int64_t *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023200a;
    iVar3 = fcn.180226610();
    *piVar2 = iVar3;
    if (iVar3 != 0) {
        piVar2[1] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023202b;
        iVar3 = fcn.180222800();
        piVar2[2] = iVar3;
        if (iVar3 != 0) {
            *(int64_t **)(in_RCX + 0x10) = piVar2;
            return 1;
        }
        iVar3 = *piVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023203c;
        fcn.180226310(iVar3);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023204b;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180232060;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023206f;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180232084;
    fcn.180224990(piVar2, 0x1804e1f78, 0x82);
    return 0;
}

// ============================================================
// Function: FUN_180232096
// Address: 0x180232096
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180231fc0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180231fd0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180231fed;
    piVar2 = (int64_t *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (piVar2 == (int64_t *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023200a;
    iVar3 = fcn.180226610();
    *piVar2 = iVar3;
    if (iVar3 != 0) {
        piVar2[1] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023202b;
        iVar3 = fcn.180222800();
        piVar2[2] = iVar3;
        if (iVar3 != 0) {
            *(int64_t **)(in_RCX + 0x10) = piVar2;
            return 1;
        }
        iVar3 = *piVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023203c;
        fcn.180226310(iVar3);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023204b;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180232060;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023206f;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180232084;
    fcn.180224990(piVar2, 0x1804e1f78, 0x82);
    return 0;
}

// ============================================================
// Function: FUN_1802320b0
// Address: 0x1802320b0
// Size: 93 bytes
// ============================================================
void fcn.1802320b0(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined4 *puVar6;
    undefined8 *puVar7;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802320bc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    puVar7 = *(undefined8 **)(param_1 + 0x10);
    uVar5 = puVar7[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802320d3;
    uVar5 = func_0x000180222290(uVar5, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802320e2;
    func_0x000180222050(uVar5, 0x1802328b0);
    uVar5 = *puVar7;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802320ea;
    fcn.180226310(uVar5);
    uVar5 = puVar7[2];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802320f3;
    func_0x0001802227d0(uVar5);
    uVar5 = *(undefined8 *)((int64_t)auStackX_18 + iVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x18022499a;
    iVar3 = fcn.18045a350(puVar7, 0x1804e1f78, 0xa3);
    iVar3 = -iVar3;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (puVar7 != (undefined8 *)0x0) {
            *(undefined8 *)(&stack0x00000040 + iVar3 + iVar4) = uVar5;
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar7);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x18047ca54;
                puVar6 = (undefined4 *)fcn.18046b77c();
                *puVar6 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_180232110
// Address: 0x180232110
// Size: 35 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180232110(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023211a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18023212e;
    fcn.180232140(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000090 + iVar1), 
                  *(int64_t *)(&stack0x000001b8 + iVar1), *(int64_t *)(&stack0x000001e8 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180232140
// Address: 0x180232140
// Size: 1300 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_278h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180232140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_68h, int64_t arg_98h, int64_t arg_1c0h, int64_t arg_1f0h)
{
    int32_t *piVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    int64_t iVar13;
    int64_t iVar14;
    undefined4 *puVar15;
    undefined4 *puVar16;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t iVar17;
    int64_t iVar18;
    int64_t in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 auStackX_20 [2];
    undefined8 uStack_48;
    int64_t var_20h;
    
    uStack_48 = 0x180232157;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    *(uint64_t *)((int64_t)&arg_1f0h + iVar11) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar11);
    uVar3 = *(undefined8 *)(&stack0x00000270 + iVar11);
    uVar4 = *(undefined8 *)(&stack0x00000278 + iVar11);
    *(undefined8 *)((int64_t)&arg_38h + iVar11) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar11) = uVar3;
    *(undefined8 *)((int64_t)&arg_30h + iVar11) = uVar4;
    *(undefined8 *)((int64_t)&var_10h + iVar11) = 0x1805aadb1;
    iVar17 = 0;
    if (in_R8 == 0) goto code_r0x000180232630;
    *(int32_t *)((int64_t)&arg_40h + iVar11) = in_EDX;
    if (in_EDX == 1) {
        *(int64_t *)((int64_t)&arg_98h + iVar11) = in_R8;
        *(int64_t *)((int64_t)&arg_48h + iVar11) = (int64_t)&arg_50h + iVar11;
code_r0x000180232208:
        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023220d;
        iVar17 = fcn.180226610();
        if (iVar17 == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023221a;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar11), *(int64_t *)(&stack0xffffffffffffffe8 + iVar11));
code_r0x00018023221f:
            *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232232;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar11), *(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
            goto code_r0x0001802325e4;
        }
        iVar18 = *(int64_t *)(in_RCX + 0x10);
        *(int64_t *)((int64_t)&var_8h + iVar11) = iVar18;
        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232258;
        uVar8 = func_0x0001802379c0(in_R8, uVar3, uVar4, (int64_t)auStackX_20 + iVar11 + -0x20);
        *(undefined4 *)((int64_t)auStackX_20 + iVar11 + -0x1c) = uVar8;
        if (*(int32_t *)((int64_t)auStackX_20 + iVar11 + -0x20) != 0) {
            *(undefined4 *)((int64_t)auStackX_20 + iVar11 + -0x20) = 0;
            uVar3 = *(undefined8 *)(iVar18 + 8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232278;
            iVar9 = func_0x000180222010(uVar3);
            iVar10 = *(int32_t *)((int64_t)auStackX_20 + iVar11 + -0x20);
            if (iVar10 < iVar9) {
                while( true ) {
                    iVar14 = 0;
                    uVar3 = *(undefined8 *)(iVar18 + 8);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023228f;
                    puVar12 = (undefined8 *)func_0x000180222340(uVar3, iVar10);
                    uVar3 = *puVar12;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023229a;
                    iVar10 = func_0x000180498cd0(uVar3);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802322a8;
                    iVar13 = func_0x000180226380(iVar17, (int64_t)(iVar10 + 0x11));
                    if (iVar13 == 0) break;
                    iVar10 = 0;
                    if ((in_EDX == 2) && (puVar12[2] != 0)) {
                        uVar3 = *(undefined8 *)(iVar18 + 0x10);
                        *(undefined4 *)((int64_t)auStackX_20 + iVar11) = uVar8;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802322cc;
                        iVar9 = fcn.180222850(uVar3);
                        if (iVar9 == 0) goto code_r0x0001802325f1;
                        uVar3 = puVar12[2];
                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802322e2;
                        iVar9 = func_0x000180221a50(uVar3, (int64_t)auStackX_20 + iVar11);
                        if (-1 < iVar9) {
                            uVar3 = puVar12[2];
                            *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802322f1;
                            iVar14 = func_0x000180222340(uVar3, iVar9);
                            iVar10 = *(int32_t *)(iVar14 + 4);
                        }
                        iVar18 = *(int64_t *)((int64_t)&var_8h + iVar11);
                        *(int64_t *)((int64_t)auStackX_20 + iVar11 + -8) = iVar14;
                        uVar3 = *(undefined8 *)(iVar18 + 0x10);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232312;
                        fcn.180222910(uVar3);
                    } else {
                        *(undefined8 *)((int64_t)auStackX_20 + iVar11 + -8) = 0;
                    }
                    uVar3 = *puVar12;
                    uVar4 = *(undefined8 *)(iVar17 + 0x10);
                    uVar5 = *(undefined8 *)(iVar17 + 8);
                    *(int32_t *)(&stack0xfffffffffffffff8 + iVar11) = iVar10;
                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar11) = *(undefined8 *)((int64_t)&var_10h + iVar11);
                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar11) = uVar8;
                    *(undefined4 *)((int64_t)&var_20h + iVar11) = 0x2f;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232351;
                    func_0x000180245f70(uVar5, uVar4, 0x1804e1fc0, uVar3);
                    uVar3 = *(undefined8 *)(iVar17 + 8);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232362;
                    iVar9 = func_0x000180472e30(uVar3, (int64_t)&arg_1c0h + iVar11);
                    if (-1 < iVar9) {
                        uVar3 = *(undefined8 *)((int64_t)&var_10h + iVar11);
                        uVar4 = *(undefined8 *)((int64_t)&arg_28h + iVar11);
                        do {
                            if (in_EDX == 1) {
                                uVar2 = *(undefined4 *)(puVar12 + 1);
                                uVar5 = *(undefined8 *)(iVar17 + 8);
                                *(undefined8 *)((int64_t)&var_20h + iVar11) =
                                     *(undefined8 *)((int64_t)&arg_30h + iVar11);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232397;
                                iVar9 = func_0x000180232d50(in_RCX, uVar5, uVar2, uVar4);
code_r0x0001802323af:
                                if (iVar9 == 0) break;
                            } else if (in_EDX == 2) {
                                uVar2 = *(undefined4 *)(puVar12 + 1);
                                uVar5 = *(undefined8 *)(iVar17 + 8);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802323af;
                                iVar9 = func_0x000180233030(in_RCX, uVar5, uVar2);
                                goto code_r0x0001802323af;
                            }
                            uVar5 = *puVar12;
                            uVar6 = *(undefined8 *)(iVar17 + 0x10);
                            iVar10 = iVar10 + 1;
                            uVar7 = *(undefined8 *)(iVar17 + 8);
                            *(int32_t *)(&stack0xfffffffffffffff8 + iVar11) = iVar10;
                            *(undefined8 *)(&stack0xfffffffffffffff0 + iVar11) = uVar3;
                            *(undefined4 *)(&stack0xffffffffffffffe8 + iVar11) = uVar8;
                            *(undefined4 *)((int64_t)&var_20h + iVar11) = 0x2f;
                            *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802323e2;
                            func_0x000180245f70(uVar7, uVar6, 0x1804e1fc0, uVar5);
                            uVar5 = *(undefined8 *)(iVar17 + 8);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802323f3;
                            iVar9 = func_0x000180472e30(uVar5, (int64_t)&arg_1c0h + iVar11);
                        } while (-1 < iVar9);
                        iVar14 = *(int64_t *)((int64_t)auStackX_20 + iVar11 + -8);
                    }
                    if (iVar10 < 1) {
                        puVar15 = (undefined4 *)0x0;
                    } else {
                        uVar3 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232410;
                        iVar9 = func_0x00018021f3b0(uVar3);
                        if (iVar9 == 0) goto code_r0x0001802325f1;
                        uVar3 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 8);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023242d;
                        uVar8 = func_0x000180221a50(uVar3, (int64_t)&arg_40h + iVar11);
                        uVar3 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 8);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023243c;
                        puVar15 = (undefined4 *)func_0x000180222340(uVar3, uVar8);
                        uVar3 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232448;
                        func_0x00018021f590(uVar3);
                    }
                    if ((in_EDX == 2) && (0 < iVar10)) {
                        uVar3 = *(undefined8 *)(*(int64_t *)((int64_t)&var_8h + iVar11) + 0x10);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023246d;
                        iVar9 = fcn.180222950(uVar3);
                        if (iVar9 == 0) goto code_r0x0001802325f1;
                        if (iVar14 == 0) {
                            *(undefined4 *)((int64_t)auStackX_20 + iVar11) =
                                 *(undefined4 *)((int64_t)auStackX_20 + iVar11 + -0x1c);
                            uVar3 = puVar12[2];
                            *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232490;
                            uVar8 = func_0x000180221a50(uVar3, (int64_t)auStackX_20 + iVar11);
                            uVar3 = puVar12[2];
                            *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023249b;
                            iVar14 = func_0x000180222340(uVar3, uVar8);
                            if (iVar14 == 0) {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802324ba;
                                puVar16 = (undefined4 *)
                                          fcn.1802248d0(*(int64_t *)((int64_t)&var_20h + iVar11), 
                                                        *(int64_t *)(&stack0xffffffffffffffe8 + iVar11));
                                if (puVar16 != (undefined4 *)0x0) {
                                    *puVar16 = *(undefined4 *)((int64_t)auStackX_20 + iVar11 + -0x1c);
                                    puVar16[1] = iVar10;
                                    uVar3 = puVar12[2];
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802324db;
                                    iVar10 = func_0x000180222110(uVar3, puVar16);
                                    if (iVar10 != 0) {
                                        uVar3 = puVar12[2];
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802324e8;
                                        func_0x0001802222d0(uVar3);
                                        iVar18 = *(int64_t *)((int64_t)&var_8h + iVar11);
                                        uVar3 = *(undefined8 *)(iVar18 + 0x10);
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802324f6;
                                        fcn.180222910(uVar3);
                                        goto code_r0x000180232515;
                                    }
                                    uVar3 = *(undefined8 *)(*(int64_t *)((int64_t)&var_8h + iVar11) + 0x10);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023254b;
                                    fcn.180222910(uVar3);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232560;
                                    fcn.180224990(puVar16, 0x1804e1f78, 0x184);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232565;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar11), 
                                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar11));
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023257d;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar11), 
                                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar11));
                                    goto code_r0x0001802325e4;
                                }
                                uVar3 = *(undefined8 *)(*(int64_t *)((int64_t)&var_8h + iVar11) + 0x10);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232592;
                                fcn.180222910(uVar3);
                                goto code_r0x0001802325f1;
                            }
                        }
                        if (*(int32_t *)(iVar14 + 4) < iVar10) {
                            *(int32_t *)(iVar14 + 4) = iVar10;
                        }
                        iVar18 = *(int64_t *)((int64_t)&var_8h + iVar11);
                        uVar3 = *(undefined8 *)(iVar18 + 0x10);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023250e;
                        fcn.180222910(uVar3);
                    } else {
                        iVar18 = *(int64_t *)((int64_t)&var_8h + iVar11);
                    }
code_r0x000180232515:
                    if (puVar15 != (undefined4 *)0x0) {
                        puVar16 = *(undefined4 **)((int64_t)&arg_38h + iVar11);
                        *puVar16 = *puVar15;
                        *(undefined8 *)(puVar16 + 2) = *(undefined8 *)(puVar15 + 2);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802325b1;
                        func_0x0001802203d0();
                        goto code_r0x0001802325f1;
                    }
                    piVar1 = (int32_t *)((int64_t)auStackX_20 + iVar11 + -0x20);
                    *piVar1 = *piVar1 + 1;
                    uVar3 = *(undefined8 *)(iVar18 + 8);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232527;
                    iVar9 = func_0x000180222010(uVar3);
                    iVar10 = *(int32_t *)((int64_t)auStackX_20 + iVar11 + -0x20);
                    if (iVar9 <= iVar10) goto code_r0x0001802325f1;
                    uVar8 = *(undefined4 *)((int64_t)auStackX_20 + iVar11 + -0x1c);
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802325b8;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar11), *(int64_t *)(&stack0xffffffffffffffe8 + iVar11))
                ;
                goto code_r0x00018023221f;
            }
        }
    } else {
        if (in_EDX == 2) {
            *(int64_t *)((int64_t)&arg_68h + iVar11) = in_R8;
            *(int64_t *)((int64_t)&arg_48h + iVar11) = (int64_t)&arg_50h + iVar11;
            *(undefined8 *)((int64_t)&var_10h + iVar11) = 0x1804a59ec;
            goto code_r0x000180232208;
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802325c7;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar11), *(int64_t *)(&stack0xffffffffffffffe8 + iVar11));
        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802325df;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar11), *(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), 
                      *(int64_t *)((int64_t)&var_10h + iVar11));
code_r0x0001802325e4:
        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802325f1;
        fcn.1802296d0(*(int64_t *)((int64_t)auStackX_20 + iVar11 + -0x20));
    }
code_r0x0001802325f1:
    uVar3 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1802325fa;
    iVar10 = func_0x00018021f3b0(uVar3);
    if (iVar10 != 0) {
        uVar3 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 8);
        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023260b;
        iVar10 = func_0x000180221ed0(uVar3);
        if (iVar10 == 0) {
            uVar3 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023261c;
            func_0x0001802222d0(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232625;
        func_0x00018021f590(uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x18023262d;
    fcn.180226310(iVar17);
code_r0x000180232630:
    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x180232640;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_1f0h + iVar11) ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar11));
    return;
}

// ============================================================
// Function: FUN_180232670
// Address: 0x180232670
// Size: 48 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180231f54: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180231f59)
// WARNING: Removing unreachable block (ram,0x000180231f5f)
// WARNING: Removing unreachable block (ram,0x000180231f8e)

undefined8 fcn.180231f10(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t in_RCX;
    int64_t iVar8;
    int32_t in_EDX;
    int32_t iVar9;
    int64_t iVar10;
    undefined *puVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    char *in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    char *pcVar12;
    char *pcVar13;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iStackX_18;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x180231f1c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RCX + 0x10);
    if (in_EDX != 2) {
        return 0;
    }
    if (in_R9D == 3) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f36;
        uVar4 = func_0x0001802a7350();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f3e;
        in_R8 = (char *)func_0x000180275160(uVar4);
        if (in_R8 == (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f48;
            in_R8 = (char *)func_0x0001802a7320();
        }
        in_R9D = 1;
        puVar11 = (undefined *)((int64_t)&uStack_10 + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f59;
        iVar10 = iVar8;
    } else {
        iVar10 = *(int64_t *)((int64_t)&iStackX_18 + iVar3);
        puVar11 = auStackX_20 + iVar3;
    }
    *(undefined8 *)(puVar11 + -8) = unaff_RDI;
    *(undefined8 *)(puVar11 + -0x10) = unaff_R12;
    *(undefined8 *)(puVar11 + -0x18) = unaff_R13;
    *(undefined8 *)(puVar11 + -0x20) = 0x180232680;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_R8 == (char *)0x0) || (cVar1 = *in_R8, cVar1 == '\0')) {
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232878;
        fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232890;
        fcn.1802295a0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10), 
                      *(int64_t *)(puVar11 + iVar3 + 0x18), *(int64_t *)(puVar11 + iVar3 + 0x20), 
                      *(int64_t *)(puVar11 + iVar3 + 0x38));
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802328a2;
        fcn.1802296d0(*(int64_t *)(puVar11 + iVar3 + 0x28));
        return 0;
    }
    *(int64_t *)(puVar11 + iVar3 + 0x38) = iVar10;
    *(undefined8 *)(puVar11 + iVar3 + 0x40) = unaff_RBP;
    *(undefined8 *)(puVar11 + iVar3 + 0x48) = unaff_RSI;
    *(undefined8 *)(puVar11 + iVar3 + 0x10) = unaff_R14;
    *(undefined8 *)(puVar11 + iVar3 + 8) = unaff_R15;
    pcVar12 = in_R8;
    do {
        if ((cVar1 == ';') || (pcVar13 = pcVar12, *in_R8 == '\0')) {
            pcVar13 = in_R8 + 1;
            iVar10 = (int64_t)in_R8 - (int64_t)pcVar12;
            if (iVar10 != 0) {
                uVar4 = *(undefined8 *)(iVar8 + 8);
                iVar9 = 0;
                *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802326ec;
                iVar2 = func_0x000180222010(uVar4);
                if (0 < iVar2) {
                    do {
                        uVar4 = *(undefined8 *)(iVar8 + 8);
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802326fb;
                        puVar5 = (undefined8 *)func_0x000180222340(uVar4, iVar9);
                        uVar4 = *puVar5;
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232706;
                        iVar6 = func_0x000180498cd0(uVar4);
                        if (iVar6 == iVar10) {
                            *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232719;
                            iVar2 = func_0x000180498f90(uVar4, pcVar12, iVar10);
                            if (iVar2 == 0) break;
                        }
                        uVar4 = *(undefined8 *)(iVar8 + 8);
                        iVar9 = iVar9 + 1;
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232728;
                        iVar2 = func_0x000180222010(uVar4);
                    } while (iVar9 < iVar2);
                }
                uVar4 = *(undefined8 *)(iVar8 + 8);
                *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232735;
                iVar2 = func_0x000180222010(uVar4);
                if (iVar2 <= iVar9) {
                    if (*(int64_t *)(iVar8 + 8) == 0) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232749;
                        iVar6 = func_0x000180221f20();
                        *(int64_t *)(iVar8 + 8) = iVar6;
                        if (iVar6 == 0) {
                            *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327f8;
                            fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
                            goto code_r0x000180232804;
                        }
                    }
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023276d;
                    piVar7 = (int64_t *)
                             fcn.1802248d0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
                    if (piVar7 == (int64_t *)0x0) {
                        return 0;
                    }
                    *(int32_t *)(piVar7 + 1) = in_R9D;
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232789;
                    uVar4 = func_0x000180221ee0(0x180232910);
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232798;
                    iVar6 = func_0x000180222290(uVar4, 0x180196ec0);
                    piVar7[2] = iVar6;
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327b4;
                    iVar10 = func_0x000180223270(pcVar12, iVar10, 0x1804e1f78, 0xcf);
                    *piVar7 = iVar10;
                    if ((iVar10 == 0) || (piVar7[2] == 0)) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023286a;
                        func_0x0001802328b0(piVar7);
                        return 0;
                    }
                    uVar4 = *(undefined8 *)(iVar8 + 8);
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327d7;
                    iVar2 = func_0x000180222110(uVar4, piVar7);
                    if (iVar2 == 0) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023284f;
                        func_0x0001802328b0(piVar7);
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232854;
                        fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
code_r0x000180232804:
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232810;
                        fcn.1802295a0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10), 
                                      *(int64_t *)(puVar11 + iVar3 + 0x18), *(int64_t *)(puVar11 + iVar3 + 0x20), 
                                      *(int64_t *)(puVar11 + iVar3 + 0x38));
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232822;
                        fcn.1802296d0(*(int64_t *)(puVar11 + iVar3 + 0x28));
                        return 0;
                    }
                }
            }
        }
        cVar1 = *in_R8;
        in_R8 = in_R8 + 1;
        if (cVar1 == '\0') {
            return 1;
        }
        cVar1 = *in_R8;
        pcVar12 = pcVar13;
    } while( true );
}

// ============================================================
// Function: FUN_1802326a0
// Address: 0x1802326a0
// Size: 423 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180231f54: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180231f59)
// WARNING: Removing unreachable block (ram,0x000180231f5f)
// WARNING: Removing unreachable block (ram,0x000180231f8e)

undefined8 fcn.180231f10(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t in_RCX;
    int64_t iVar8;
    int32_t in_EDX;
    int32_t iVar9;
    int64_t iVar10;
    undefined *puVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    char *in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    char *pcVar12;
    char *pcVar13;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iStackX_18;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x180231f1c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RCX + 0x10);
    if (in_EDX != 2) {
        return 0;
    }
    if (in_R9D == 3) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f36;
        uVar4 = func_0x0001802a7350();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f3e;
        in_R8 = (char *)func_0x000180275160(uVar4);
        if (in_R8 == (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f48;
            in_R8 = (char *)func_0x0001802a7320();
        }
        in_R9D = 1;
        puVar11 = (undefined *)((int64_t)&uStack_10 + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f59;
        iVar10 = iVar8;
    } else {
        iVar10 = *(int64_t *)((int64_t)&iStackX_18 + iVar3);
        puVar11 = auStackX_20 + iVar3;
    }
    *(undefined8 *)(puVar11 + -8) = unaff_RDI;
    *(undefined8 *)(puVar11 + -0x10) = unaff_R12;
    *(undefined8 *)(puVar11 + -0x18) = unaff_R13;
    *(undefined8 *)(puVar11 + -0x20) = 0x180232680;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_R8 == (char *)0x0) || (cVar1 = *in_R8, cVar1 == '\0')) {
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232878;
        fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232890;
        fcn.1802295a0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10), 
                      *(int64_t *)(puVar11 + iVar3 + 0x18), *(int64_t *)(puVar11 + iVar3 + 0x20), 
                      *(int64_t *)(puVar11 + iVar3 + 0x38));
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802328a2;
        fcn.1802296d0(*(int64_t *)(puVar11 + iVar3 + 0x28));
        return 0;
    }
    *(int64_t *)(puVar11 + iVar3 + 0x38) = iVar10;
    *(undefined8 *)(puVar11 + iVar3 + 0x40) = unaff_RBP;
    *(undefined8 *)(puVar11 + iVar3 + 0x48) = unaff_RSI;
    *(undefined8 *)(puVar11 + iVar3 + 0x10) = unaff_R14;
    *(undefined8 *)(puVar11 + iVar3 + 8) = unaff_R15;
    pcVar12 = in_R8;
    do {
        if ((cVar1 == ';') || (pcVar13 = pcVar12, *in_R8 == '\0')) {
            pcVar13 = in_R8 + 1;
            iVar10 = (int64_t)in_R8 - (int64_t)pcVar12;
            if (iVar10 != 0) {
                uVar4 = *(undefined8 *)(iVar8 + 8);
                iVar9 = 0;
                *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802326ec;
                iVar2 = func_0x000180222010(uVar4);
                if (0 < iVar2) {
                    do {
                        uVar4 = *(undefined8 *)(iVar8 + 8);
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802326fb;
                        puVar5 = (undefined8 *)func_0x000180222340(uVar4, iVar9);
                        uVar4 = *puVar5;
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232706;
                        iVar6 = func_0x000180498cd0(uVar4);
                        if (iVar6 == iVar10) {
                            *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232719;
                            iVar2 = func_0x000180498f90(uVar4, pcVar12, iVar10);
                            if (iVar2 == 0) break;
                        }
                        uVar4 = *(undefined8 *)(iVar8 + 8);
                        iVar9 = iVar9 + 1;
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232728;
                        iVar2 = func_0x000180222010(uVar4);
                    } while (iVar9 < iVar2);
                }
                uVar4 = *(undefined8 *)(iVar8 + 8);
                *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232735;
                iVar2 = func_0x000180222010(uVar4);
                if (iVar2 <= iVar9) {
                    if (*(int64_t *)(iVar8 + 8) == 0) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232749;
                        iVar6 = func_0x000180221f20();
                        *(int64_t *)(iVar8 + 8) = iVar6;
                        if (iVar6 == 0) {
                            *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327f8;
                            fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
                            goto code_r0x000180232804;
                        }
                    }
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023276d;
                    piVar7 = (int64_t *)
                             fcn.1802248d0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
                    if (piVar7 == (int64_t *)0x0) {
                        return 0;
                    }
                    *(int32_t *)(piVar7 + 1) = in_R9D;
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232789;
                    uVar4 = func_0x000180221ee0(0x180232910);
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232798;
                    iVar6 = func_0x000180222290(uVar4, 0x180196ec0);
                    piVar7[2] = iVar6;
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327b4;
                    iVar10 = func_0x000180223270(pcVar12, iVar10, 0x1804e1f78, 0xcf);
                    *piVar7 = iVar10;
                    if ((iVar10 == 0) || (piVar7[2] == 0)) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023286a;
                        func_0x0001802328b0(piVar7);
                        return 0;
                    }
                    uVar4 = *(undefined8 *)(iVar8 + 8);
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327d7;
                    iVar2 = func_0x000180222110(uVar4, piVar7);
                    if (iVar2 == 0) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023284f;
                        func_0x0001802328b0(piVar7);
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232854;
                        fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
code_r0x000180232804:
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232810;
                        fcn.1802295a0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10), 
                                      *(int64_t *)(puVar11 + iVar3 + 0x18), *(int64_t *)(puVar11 + iVar3 + 0x20), 
                                      *(int64_t *)(puVar11 + iVar3 + 0x38));
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232822;
                        fcn.1802296d0(*(int64_t *)(puVar11 + iVar3 + 0x28));
                        return 0;
                    }
                }
            }
        }
        cVar1 = *in_R8;
        in_R8 = in_R8 + 1;
        if (cVar1 == '\0') {
            return 1;
        }
        cVar1 = *in_R8;
        pcVar12 = pcVar13;
    } while( true );
}

// ============================================================
// Function: FUN_180232847
// Address: 0x180232847
// Size: 44 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180231f54: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180231f59)
// WARNING: Removing unreachable block (ram,0x000180231f5f)
// WARNING: Removing unreachable block (ram,0x000180231f8e)

undefined8 fcn.180231f10(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t in_RCX;
    int64_t iVar8;
    int32_t in_EDX;
    int32_t iVar9;
    int64_t iVar10;
    undefined *puVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    char *in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    char *pcVar12;
    char *pcVar13;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iStackX_18;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x180231f1c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RCX + 0x10);
    if (in_EDX != 2) {
        return 0;
    }
    if (in_R9D == 3) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f36;
        uVar4 = func_0x0001802a7350();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f3e;
        in_R8 = (char *)func_0x000180275160(uVar4);
        if (in_R8 == (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f48;
            in_R8 = (char *)func_0x0001802a7320();
        }
        in_R9D = 1;
        puVar11 = (undefined *)((int64_t)&uStack_10 + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f59;
        iVar10 = iVar8;
    } else {
        iVar10 = *(int64_t *)((int64_t)&iStackX_18 + iVar3);
        puVar11 = auStackX_20 + iVar3;
    }
    *(undefined8 *)(puVar11 + -8) = unaff_RDI;
    *(undefined8 *)(puVar11 + -0x10) = unaff_R12;
    *(undefined8 *)(puVar11 + -0x18) = unaff_R13;
    *(undefined8 *)(puVar11 + -0x20) = 0x180232680;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_R8 == (char *)0x0) || (cVar1 = *in_R8, cVar1 == '\0')) {
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232878;
        fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232890;
        fcn.1802295a0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10), 
                      *(int64_t *)(puVar11 + iVar3 + 0x18), *(int64_t *)(puVar11 + iVar3 + 0x20), 
                      *(int64_t *)(puVar11 + iVar3 + 0x38));
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802328a2;
        fcn.1802296d0(*(int64_t *)(puVar11 + iVar3 + 0x28));
        return 0;
    }
    *(int64_t *)(puVar11 + iVar3 + 0x38) = iVar10;
    *(undefined8 *)(puVar11 + iVar3 + 0x40) = unaff_RBP;
    *(undefined8 *)(puVar11 + iVar3 + 0x48) = unaff_RSI;
    *(undefined8 *)(puVar11 + iVar3 + 0x10) = unaff_R14;
    *(undefined8 *)(puVar11 + iVar3 + 8) = unaff_R15;
    pcVar12 = in_R8;
    do {
        if ((cVar1 == ';') || (pcVar13 = pcVar12, *in_R8 == '\0')) {
            pcVar13 = in_R8 + 1;
            iVar10 = (int64_t)in_R8 - (int64_t)pcVar12;
            if (iVar10 != 0) {
                uVar4 = *(undefined8 *)(iVar8 + 8);
                iVar9 = 0;
                *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802326ec;
                iVar2 = func_0x000180222010(uVar4);
                if (0 < iVar2) {
                    do {
                        uVar4 = *(undefined8 *)(iVar8 + 8);
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802326fb;
                        puVar5 = (undefined8 *)func_0x000180222340(uVar4, iVar9);
                        uVar4 = *puVar5;
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232706;
                        iVar6 = func_0x000180498cd0(uVar4);
                        if (iVar6 == iVar10) {
                            *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232719;
                            iVar2 = func_0x000180498f90(uVar4, pcVar12, iVar10);
                            if (iVar2 == 0) break;
                        }
                        uVar4 = *(undefined8 *)(iVar8 + 8);
                        iVar9 = iVar9 + 1;
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232728;
                        iVar2 = func_0x000180222010(uVar4);
                    } while (iVar9 < iVar2);
                }
                uVar4 = *(undefined8 *)(iVar8 + 8);
                *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232735;
                iVar2 = func_0x000180222010(uVar4);
                if (iVar2 <= iVar9) {
                    if (*(int64_t *)(iVar8 + 8) == 0) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232749;
                        iVar6 = func_0x000180221f20();
                        *(int64_t *)(iVar8 + 8) = iVar6;
                        if (iVar6 == 0) {
                            *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327f8;
                            fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
                            goto code_r0x000180232804;
                        }
                    }
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023276d;
                    piVar7 = (int64_t *)
                             fcn.1802248d0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
                    if (piVar7 == (int64_t *)0x0) {
                        return 0;
                    }
                    *(int32_t *)(piVar7 + 1) = in_R9D;
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232789;
                    uVar4 = func_0x000180221ee0(0x180232910);
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232798;
                    iVar6 = func_0x000180222290(uVar4, 0x180196ec0);
                    piVar7[2] = iVar6;
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327b4;
                    iVar10 = func_0x000180223270(pcVar12, iVar10, 0x1804e1f78, 0xcf);
                    *piVar7 = iVar10;
                    if ((iVar10 == 0) || (piVar7[2] == 0)) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023286a;
                        func_0x0001802328b0(piVar7);
                        return 0;
                    }
                    uVar4 = *(undefined8 *)(iVar8 + 8);
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327d7;
                    iVar2 = func_0x000180222110(uVar4, piVar7);
                    if (iVar2 == 0) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023284f;
                        func_0x0001802328b0(piVar7);
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232854;
                        fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
code_r0x000180232804:
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232810;
                        fcn.1802295a0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10), 
                                      *(int64_t *)(puVar11 + iVar3 + 0x18), *(int64_t *)(puVar11 + iVar3 + 0x20), 
                                      *(int64_t *)(puVar11 + iVar3 + 0x38));
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232822;
                        fcn.1802296d0(*(int64_t *)(puVar11 + iVar3 + 0x28));
                        return 0;
                    }
                }
            }
        }
        cVar1 = *in_R8;
        in_R8 = in_R8 + 1;
        if (cVar1 == '\0') {
            return 1;
        }
        cVar1 = *in_R8;
        pcVar12 = pcVar13;
    } while( true );
}

// ============================================================
// Function: FUN_180232873
// Address: 0x180232873
// Size: 59 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180231f54: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180231f59)
// WARNING: Removing unreachable block (ram,0x000180231f5f)
// WARNING: Removing unreachable block (ram,0x000180231f8e)

undefined8 fcn.180231f10(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t in_RCX;
    int64_t iVar8;
    int32_t in_EDX;
    int32_t iVar9;
    int64_t iVar10;
    undefined *puVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    char *in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    char *pcVar12;
    char *pcVar13;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iStackX_18;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x180231f1c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = *(int64_t *)(in_RCX + 0x10);
    if (in_EDX != 2) {
        return 0;
    }
    if (in_R9D == 3) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f36;
        uVar4 = func_0x0001802a7350();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f3e;
        in_R8 = (char *)func_0x000180275160(uVar4);
        if (in_R8 == (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f48;
            in_R8 = (char *)func_0x0001802a7320();
        }
        in_R9D = 1;
        puVar11 = (undefined *)((int64_t)&uStack_10 + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180231f59;
        iVar10 = iVar8;
    } else {
        iVar10 = *(int64_t *)((int64_t)&iStackX_18 + iVar3);
        puVar11 = auStackX_20 + iVar3;
    }
    *(undefined8 *)(puVar11 + -8) = unaff_RDI;
    *(undefined8 *)(puVar11 + -0x10) = unaff_R12;
    *(undefined8 *)(puVar11 + -0x18) = unaff_R13;
    *(undefined8 *)(puVar11 + -0x20) = 0x180232680;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_R8 == (char *)0x0) || (cVar1 = *in_R8, cVar1 == '\0')) {
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232878;
        fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232890;
        fcn.1802295a0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10), 
                      *(int64_t *)(puVar11 + iVar3 + 0x18), *(int64_t *)(puVar11 + iVar3 + 0x20), 
                      *(int64_t *)(puVar11 + iVar3 + 0x38));
        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802328a2;
        fcn.1802296d0(*(int64_t *)(puVar11 + iVar3 + 0x28));
        return 0;
    }
    *(int64_t *)(puVar11 + iVar3 + 0x38) = iVar10;
    *(undefined8 *)(puVar11 + iVar3 + 0x40) = unaff_RBP;
    *(undefined8 *)(puVar11 + iVar3 + 0x48) = unaff_RSI;
    *(undefined8 *)(puVar11 + iVar3 + 0x10) = unaff_R14;
    *(undefined8 *)(puVar11 + iVar3 + 8) = unaff_R15;
    pcVar12 = in_R8;
    do {
        if ((cVar1 == ';') || (pcVar13 = pcVar12, *in_R8 == '\0')) {
            pcVar13 = in_R8 + 1;
            iVar10 = (int64_t)in_R8 - (int64_t)pcVar12;
            if (iVar10 != 0) {
                uVar4 = *(undefined8 *)(iVar8 + 8);
                iVar9 = 0;
                *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802326ec;
                iVar2 = func_0x000180222010(uVar4);
                if (0 < iVar2) {
                    do {
                        uVar4 = *(undefined8 *)(iVar8 + 8);
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802326fb;
                        puVar5 = (undefined8 *)func_0x000180222340(uVar4, iVar9);
                        uVar4 = *puVar5;
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232706;
                        iVar6 = func_0x000180498cd0(uVar4);
                        if (iVar6 == iVar10) {
                            *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232719;
                            iVar2 = func_0x000180498f90(uVar4, pcVar12, iVar10);
                            if (iVar2 == 0) break;
                        }
                        uVar4 = *(undefined8 *)(iVar8 + 8);
                        iVar9 = iVar9 + 1;
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232728;
                        iVar2 = func_0x000180222010(uVar4);
                    } while (iVar9 < iVar2);
                }
                uVar4 = *(undefined8 *)(iVar8 + 8);
                *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232735;
                iVar2 = func_0x000180222010(uVar4);
                if (iVar2 <= iVar9) {
                    if (*(int64_t *)(iVar8 + 8) == 0) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232749;
                        iVar6 = func_0x000180221f20();
                        *(int64_t *)(iVar8 + 8) = iVar6;
                        if (iVar6 == 0) {
                            *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327f8;
                            fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
                            goto code_r0x000180232804;
                        }
                    }
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023276d;
                    piVar7 = (int64_t *)
                             fcn.1802248d0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
                    if (piVar7 == (int64_t *)0x0) {
                        return 0;
                    }
                    *(int32_t *)(piVar7 + 1) = in_R9D;
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232789;
                    uVar4 = func_0x000180221ee0(0x180232910);
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232798;
                    iVar6 = func_0x000180222290(uVar4, 0x180196ec0);
                    piVar7[2] = iVar6;
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327b4;
                    iVar10 = func_0x000180223270(pcVar12, iVar10, 0x1804e1f78, 0xcf);
                    *piVar7 = iVar10;
                    if ((iVar10 == 0) || (piVar7[2] == 0)) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023286a;
                        func_0x0001802328b0(piVar7);
                        return 0;
                    }
                    uVar4 = *(undefined8 *)(iVar8 + 8);
                    *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x1802327d7;
                    iVar2 = func_0x000180222110(uVar4, piVar7);
                    if (iVar2 == 0) {
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x18023284f;
                        func_0x0001802328b0(piVar7);
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232854;
                        fcn.180229480(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10));
code_r0x000180232804:
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232810;
                        fcn.1802295a0(*(int64_t *)(puVar11 + iVar3 + 8), *(int64_t *)(puVar11 + iVar3 + 0x10), 
                                      *(int64_t *)(puVar11 + iVar3 + 0x18), *(int64_t *)(puVar11 + iVar3 + 0x20), 
                                      *(int64_t *)(puVar11 + iVar3 + 0x38));
                        *(undefined8 *)(puVar11 + iVar3 + -0x20) = 0x180232822;
                        fcn.1802296d0(*(int64_t *)(puVar11 + iVar3 + 0x28));
                        return 0;
                    }
                }
            }
        }
        cVar1 = *in_R8;
        in_R8 = in_R8 + 1;
        if (cVar1 == '\0') {
            return 1;
        }
        cVar1 = *in_R8;
        pcVar12 = pcVar13;
    } while( true );
}

// ============================================================
// Function: FUN_1802328b0
// Address: 0x1802328b0
// Size: 96 bytes
// ============================================================
void fcn.1802328b0(undefined8 *param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined4 *puVar6;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802328bc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = *param_1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802328d7;
    fcn.180224990(uVar5, 0x1804e1f78, 0x97);
    uVar5 = param_1[2];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802328e7;
    uVar5 = func_0x000180222290(uVar5, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802328f6;
    func_0x000180222050(uVar5, 0x180232930);
    uVar5 = *(undefined8 *)((int64_t)auStackX_18 + iVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x18022499a;
    iVar3 = fcn.18045a350(param_1, 0x1804e1f78, 0x99);
    iVar3 = -iVar3;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != (undefined8 *)0x0) {
            *(undefined8 *)(&stack0x00000040 + iVar3 + iVar4) = uVar5;
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x18047ca54;
                puVar6 = (undefined4 *)fcn.18046b77c();
                *puVar6 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_180232930
// Address: 0x180232930
// Size: 35 bytes
// ============================================================
void fcn.180232930(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4) = 0x18022499a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar3 + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_180232960
// Address: 0x180232960
// Size: 231 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.180232960(int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    int32_t in_EDX;
    int32_t in_R9D;
    bool bVar5;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180232970;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    bVar5 = false;
    if (in_EDX == 1) {
        if (in_R9D == 3) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180232992;
            uVar3 = func_0x0001802a7390();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023299a;
            iVar4 = func_0x000180275160(uVar3);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802329a4;
                iVar4 = func_0x0001802a7360();
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802329bd;
            iVar1 = func_0x000180232b80(in_RCX, iVar4, 1, 0);
            bVar5 = iVar1 != 0;
            if (!bVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802329cb;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802329e3;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                              *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802329f5;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                return bVar5;
            }
        } else {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0;
            if (in_R9D == 1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180232a1b;
                iVar1 = func_0x000180232b80();
                return iVar1 != 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180232a35;
            iVar1 = func_0x000180232d50();
            bVar5 = iVar1 != 0;
        }
    }
    return bVar5;
}

// ============================================================
// Function: FUN_180232a50
// Address: 0x180232a50
// Size: 281 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.180232a50(int64_t arg_38h, int64_t arg_60h, int64_t arg_68h, int64_t arg_a8h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    int32_t in_EDX;
    undefined8 in_R8;
    uint64_t in_R9;
    bool bVar5;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180232a60;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    bVar5 = false;
    if (in_EDX == 1) {
        if ((int32_t)in_R9 == 3) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180232a86;
            uVar3 = func_0x0001802a7390();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180232a8e;
            iVar4 = func_0x000180275160(uVar3);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180232aa7;
                iVar4 = func_0x0001802a7360();
                *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = *(undefined8 *)((int64_t)&arg_68h + iVar2);
            } else {
                *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = *(undefined8 *)((int64_t)&arg_68h + iVar2);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180232ac7;
            iVar1 = func_0x000180232b80(in_RCX, iVar4, 1, *(undefined8 *)((int64_t)&arg_60h + iVar2));
            bVar5 = iVar1 != 0;
            if (!bVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180232ad9;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180232af1;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                              *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180232b03;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                return bVar5;
            }
        } else {
            uVar3 = *(undefined8 *)((int64_t)&arg_60h + iVar2);
            if ((int32_t)in_R9 == 1) {
                *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = *(undefined8 *)((int64_t)&arg_68h + iVar2);
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180232b30;
                iVar1 = func_0x000180232b80();
                return iVar1 != 0;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = *(undefined8 *)((int64_t)&arg_68h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180232b57;
            iVar1 = func_0x000180232d50(in_RCX, in_R8, in_R9 & 0xffffffff, uVar3);
            bVar5 = iVar1 != 0;
        }
    }
    return bVar5;
}

// ============================================================
// Function: FUN_180232b80
// Address: 0x180232b80
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180232b80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_68h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBP;
    int32_t iVar11;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    int64_t var_18h;
    
    uStack_20 = 0x180232b8f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar10 = 0;
    if (in_R8D == 1) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bc4;
        iVar7 = func_0x00018023f8e0(in_RDX, 0x180625030);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bd1;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232be9;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bfb;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar5);
        *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R9;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c33;
        iVar8 = func_0x0001802a7650(iVar7, 0, 0, 0x1805aadb1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c3e;
        func_0x000180219f80(iVar7);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c48;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c60;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c72;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        iVar11 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c88;
        iVar3 = func_0x000180222010(iVar8);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c9a;
                piVar6 = (int64_t *)func_0x000180222340(iVar8, iVar11);
                if (*piVar6 != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cad;
                    iVar3 = func_0x00018021f070(uVar12);
                    if (iVar3 != 0) {
                        iVar10 = iVar10 + 1;
                        goto code_r0x000180232cb7;
                    }
code_r0x000180232d3e:
                    iVar10 = 0;
                    goto code_r0x000180232d15;
                }
code_r0x000180232cb7:
                if (piVar6[1] != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cc8;
                    iVar3 = func_0x00018021f0d0(uVar12);
                    if (iVar3 == 0) goto code_r0x000180232d3e;
                    iVar10 = iVar10 + 1;
                }
                iVar11 = iVar11 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cde;
                iVar3 = func_0x000180222010(iVar8);
            } while (iVar11 < iVar3);
            if (iVar10 != 0) goto code_r0x000180232d15;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232ceb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d03;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d15;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
code_r0x000180232d15:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d24;
        func_0x000180222050(iVar8, 0x1802a7580);
        return iVar10;
    }
    uVar12 = *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = *(undefined8 *)(&stack0x00000028 + iVar5);
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = uVar12;
    *(undefined8 *)(&stack0x00000028 + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = *(undefined8 *)((int64_t)aiStackX_18 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = 0x180232d6e;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar10 = 0;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232d90;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232da8;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    } else {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232db7;
        uVar12 = func_0x00018023faa0();
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232dbf;
        iVar8 = func_0x00018021a7c0(uVar12);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232de1;
            iVar3 = func_0x000180219d10(iVar8, 0x6c, 3, in_RDX);
            if (0 < iVar3) {
                uVar12 = *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar5);
                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232df9;
                iVar9 = func_0x00018021ff10(in_R9, uVar12);
                *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e08;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e20;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                } else {
                    if (in_R8D == 1) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e39;
                        func_0x000180229b10();
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e50;
                        iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        while (iVar9 != 0) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e5a;
                            func_0x000180229900();
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar2 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e68;
                            iVar3 = func_0x00018021f070(uVar2, uVar1);
                            if (iVar3 == 0) goto code_r0x000180232f5b;
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e7a;
                            func_0x00018021fe80(uVar1);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e85;
                            iVar9 = func_0x00018021ff10(in_R9, uVar12);
                            *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                            if (iVar9 == 0) {
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ee2;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232efa;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f0c;
                                fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
                                iVar10 = 0;
                                goto code_r0x000180233003;
                            }
                            iVar10 = iVar10 + 1;
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e96;
                            func_0x000180229b10();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ead;
                            iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232eb7;
                        uVar4 = func_0x000180220a00();
                        if (((((int32_t)uVar4 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar4) == 0x6c) && (0 < iVar10)) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ed8;
                            func_0x0001802299d0();
                        } else {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f18;
                            func_0x000180229900();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f1d;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f3f;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f5b;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180232f5b:
                            iVar10 = 0;
                        }
                        goto code_r0x000180233003;
                    }
                    if (in_R8D == 2) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f75;
                        iVar9 = func_0x000180240760(iVar8, (int64_t)&arg_38h + iVar7 + iVar5);
                        if (iVar9 != 0) {
                            uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar1 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fac;
                            iVar10 = func_0x00018021f070(uVar1, uVar12);
                            goto code_r0x000180233003;
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f7f;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f97;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    } else {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fb5;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fcd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    }
                }
                goto code_r0x000180232ff6;
            }
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fd9;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ff1;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    }
code_r0x000180232ff6:
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233003;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180233003:
    uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x18023300d;
    func_0x00018021fe80(uVar12);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233015;
    func_0x000180219f80(iVar8);
    return iVar10;
}

// ============================================================
// Function: FUN_180232bb7
// Address: 0x180232bb7
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180232b80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_68h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBP;
    int32_t iVar11;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    int64_t var_18h;
    
    uStack_20 = 0x180232b8f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar10 = 0;
    if (in_R8D == 1) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bc4;
        iVar7 = func_0x00018023f8e0(in_RDX, 0x180625030);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bd1;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232be9;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bfb;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar5);
        *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R9;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c33;
        iVar8 = func_0x0001802a7650(iVar7, 0, 0, 0x1805aadb1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c3e;
        func_0x000180219f80(iVar7);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c48;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c60;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c72;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        iVar11 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c88;
        iVar3 = func_0x000180222010(iVar8);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c9a;
                piVar6 = (int64_t *)func_0x000180222340(iVar8, iVar11);
                if (*piVar6 != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cad;
                    iVar3 = func_0x00018021f070(uVar12);
                    if (iVar3 != 0) {
                        iVar10 = iVar10 + 1;
                        goto code_r0x000180232cb7;
                    }
code_r0x000180232d3e:
                    iVar10 = 0;
                    goto code_r0x000180232d15;
                }
code_r0x000180232cb7:
                if (piVar6[1] != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cc8;
                    iVar3 = func_0x00018021f0d0(uVar12);
                    if (iVar3 == 0) goto code_r0x000180232d3e;
                    iVar10 = iVar10 + 1;
                }
                iVar11 = iVar11 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cde;
                iVar3 = func_0x000180222010(iVar8);
            } while (iVar11 < iVar3);
            if (iVar10 != 0) goto code_r0x000180232d15;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232ceb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d03;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d15;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
code_r0x000180232d15:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d24;
        func_0x000180222050(iVar8, 0x1802a7580);
        return iVar10;
    }
    uVar12 = *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = *(undefined8 *)(&stack0x00000028 + iVar5);
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = uVar12;
    *(undefined8 *)(&stack0x00000028 + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = *(undefined8 *)((int64_t)aiStackX_18 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = 0x180232d6e;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar10 = 0;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232d90;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232da8;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    } else {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232db7;
        uVar12 = func_0x00018023faa0();
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232dbf;
        iVar8 = func_0x00018021a7c0(uVar12);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232de1;
            iVar3 = func_0x000180219d10(iVar8, 0x6c, 3, in_RDX);
            if (0 < iVar3) {
                uVar12 = *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar5);
                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232df9;
                iVar9 = func_0x00018021ff10(in_R9, uVar12);
                *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e08;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e20;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                } else {
                    if (in_R8D == 1) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e39;
                        func_0x000180229b10();
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e50;
                        iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        while (iVar9 != 0) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e5a;
                            func_0x000180229900();
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar2 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e68;
                            iVar3 = func_0x00018021f070(uVar2, uVar1);
                            if (iVar3 == 0) goto code_r0x000180232f5b;
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e7a;
                            func_0x00018021fe80(uVar1);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e85;
                            iVar9 = func_0x00018021ff10(in_R9, uVar12);
                            *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                            if (iVar9 == 0) {
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ee2;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232efa;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f0c;
                                fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
                                iVar10 = 0;
                                goto code_r0x000180233003;
                            }
                            iVar10 = iVar10 + 1;
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e96;
                            func_0x000180229b10();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ead;
                            iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232eb7;
                        uVar4 = func_0x000180220a00();
                        if (((((int32_t)uVar4 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar4) == 0x6c) && (0 < iVar10)) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ed8;
                            func_0x0001802299d0();
                        } else {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f18;
                            func_0x000180229900();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f1d;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f3f;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f5b;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180232f5b:
                            iVar10 = 0;
                        }
                        goto code_r0x000180233003;
                    }
                    if (in_R8D == 2) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f75;
                        iVar9 = func_0x000180240760(iVar8, (int64_t)&arg_38h + iVar7 + iVar5);
                        if (iVar9 != 0) {
                            uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar1 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fac;
                            iVar10 = func_0x00018021f070(uVar1, uVar12);
                            goto code_r0x000180233003;
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f7f;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f97;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    } else {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fb5;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fcd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    }
                }
                goto code_r0x000180232ff6;
            }
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fd9;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ff1;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    }
code_r0x000180232ff6:
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233003;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180233003:
    uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x18023300d;
    func_0x00018021fe80(uVar12);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233015;
    func_0x000180219f80(iVar8);
    return iVar10;
}

// ============================================================
// Function: FUN_180232c0b
// Address: 0x180232c0b
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180232b80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_68h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBP;
    int32_t iVar11;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    int64_t var_18h;
    
    uStack_20 = 0x180232b8f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar10 = 0;
    if (in_R8D == 1) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bc4;
        iVar7 = func_0x00018023f8e0(in_RDX, 0x180625030);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bd1;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232be9;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bfb;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar5);
        *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R9;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c33;
        iVar8 = func_0x0001802a7650(iVar7, 0, 0, 0x1805aadb1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c3e;
        func_0x000180219f80(iVar7);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c48;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c60;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c72;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        iVar11 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c88;
        iVar3 = func_0x000180222010(iVar8);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c9a;
                piVar6 = (int64_t *)func_0x000180222340(iVar8, iVar11);
                if (*piVar6 != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cad;
                    iVar3 = func_0x00018021f070(uVar12);
                    if (iVar3 != 0) {
                        iVar10 = iVar10 + 1;
                        goto code_r0x000180232cb7;
                    }
code_r0x000180232d3e:
                    iVar10 = 0;
                    goto code_r0x000180232d15;
                }
code_r0x000180232cb7:
                if (piVar6[1] != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cc8;
                    iVar3 = func_0x00018021f0d0(uVar12);
                    if (iVar3 == 0) goto code_r0x000180232d3e;
                    iVar10 = iVar10 + 1;
                }
                iVar11 = iVar11 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cde;
                iVar3 = func_0x000180222010(iVar8);
            } while (iVar11 < iVar3);
            if (iVar10 != 0) goto code_r0x000180232d15;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232ceb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d03;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d15;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
code_r0x000180232d15:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d24;
        func_0x000180222050(iVar8, 0x1802a7580);
        return iVar10;
    }
    uVar12 = *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = *(undefined8 *)(&stack0x00000028 + iVar5);
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = uVar12;
    *(undefined8 *)(&stack0x00000028 + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = *(undefined8 *)((int64_t)aiStackX_18 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = 0x180232d6e;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar10 = 0;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232d90;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232da8;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    } else {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232db7;
        uVar12 = func_0x00018023faa0();
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232dbf;
        iVar8 = func_0x00018021a7c0(uVar12);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232de1;
            iVar3 = func_0x000180219d10(iVar8, 0x6c, 3, in_RDX);
            if (0 < iVar3) {
                uVar12 = *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar5);
                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232df9;
                iVar9 = func_0x00018021ff10(in_R9, uVar12);
                *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e08;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e20;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                } else {
                    if (in_R8D == 1) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e39;
                        func_0x000180229b10();
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e50;
                        iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        while (iVar9 != 0) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e5a;
                            func_0x000180229900();
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar2 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e68;
                            iVar3 = func_0x00018021f070(uVar2, uVar1);
                            if (iVar3 == 0) goto code_r0x000180232f5b;
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e7a;
                            func_0x00018021fe80(uVar1);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e85;
                            iVar9 = func_0x00018021ff10(in_R9, uVar12);
                            *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                            if (iVar9 == 0) {
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ee2;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232efa;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f0c;
                                fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
                                iVar10 = 0;
                                goto code_r0x000180233003;
                            }
                            iVar10 = iVar10 + 1;
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e96;
                            func_0x000180229b10();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ead;
                            iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232eb7;
                        uVar4 = func_0x000180220a00();
                        if (((((int32_t)uVar4 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar4) == 0x6c) && (0 < iVar10)) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ed8;
                            func_0x0001802299d0();
                        } else {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f18;
                            func_0x000180229900();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f1d;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f3f;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f5b;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180232f5b:
                            iVar10 = 0;
                        }
                        goto code_r0x000180233003;
                    }
                    if (in_R8D == 2) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f75;
                        iVar9 = func_0x000180240760(iVar8, (int64_t)&arg_38h + iVar7 + iVar5);
                        if (iVar9 != 0) {
                            uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar1 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fac;
                            iVar10 = func_0x00018021f070(uVar1, uVar12);
                            goto code_r0x000180233003;
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f7f;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f97;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    } else {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fb5;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fcd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    }
                }
                goto code_r0x000180232ff6;
            }
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fd9;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ff1;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    }
code_r0x000180232ff6:
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233003;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180233003:
    uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x18023300d;
    func_0x00018021fe80(uVar12);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233015;
    func_0x000180219f80(iVar8);
    return iVar10;
}

// ============================================================
// Function: FUN_180232c7c
// Address: 0x180232c7c
// Size: 175 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180232b80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_68h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBP;
    int32_t iVar11;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    int64_t var_18h;
    
    uStack_20 = 0x180232b8f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar10 = 0;
    if (in_R8D == 1) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bc4;
        iVar7 = func_0x00018023f8e0(in_RDX, 0x180625030);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bd1;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232be9;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bfb;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar5);
        *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R9;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c33;
        iVar8 = func_0x0001802a7650(iVar7, 0, 0, 0x1805aadb1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c3e;
        func_0x000180219f80(iVar7);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c48;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c60;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c72;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        iVar11 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c88;
        iVar3 = func_0x000180222010(iVar8);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c9a;
                piVar6 = (int64_t *)func_0x000180222340(iVar8, iVar11);
                if (*piVar6 != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cad;
                    iVar3 = func_0x00018021f070(uVar12);
                    if (iVar3 != 0) {
                        iVar10 = iVar10 + 1;
                        goto code_r0x000180232cb7;
                    }
code_r0x000180232d3e:
                    iVar10 = 0;
                    goto code_r0x000180232d15;
                }
code_r0x000180232cb7:
                if (piVar6[1] != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cc8;
                    iVar3 = func_0x00018021f0d0(uVar12);
                    if (iVar3 == 0) goto code_r0x000180232d3e;
                    iVar10 = iVar10 + 1;
                }
                iVar11 = iVar11 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cde;
                iVar3 = func_0x000180222010(iVar8);
            } while (iVar11 < iVar3);
            if (iVar10 != 0) goto code_r0x000180232d15;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232ceb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d03;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d15;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
code_r0x000180232d15:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d24;
        func_0x000180222050(iVar8, 0x1802a7580);
        return iVar10;
    }
    uVar12 = *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = *(undefined8 *)(&stack0x00000028 + iVar5);
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = uVar12;
    *(undefined8 *)(&stack0x00000028 + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = *(undefined8 *)((int64_t)aiStackX_18 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = 0x180232d6e;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar10 = 0;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232d90;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232da8;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    } else {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232db7;
        uVar12 = func_0x00018023faa0();
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232dbf;
        iVar8 = func_0x00018021a7c0(uVar12);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232de1;
            iVar3 = func_0x000180219d10(iVar8, 0x6c, 3, in_RDX);
            if (0 < iVar3) {
                uVar12 = *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar5);
                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232df9;
                iVar9 = func_0x00018021ff10(in_R9, uVar12);
                *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e08;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e20;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                } else {
                    if (in_R8D == 1) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e39;
                        func_0x000180229b10();
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e50;
                        iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        while (iVar9 != 0) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e5a;
                            func_0x000180229900();
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar2 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e68;
                            iVar3 = func_0x00018021f070(uVar2, uVar1);
                            if (iVar3 == 0) goto code_r0x000180232f5b;
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e7a;
                            func_0x00018021fe80(uVar1);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e85;
                            iVar9 = func_0x00018021ff10(in_R9, uVar12);
                            *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                            if (iVar9 == 0) {
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ee2;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232efa;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f0c;
                                fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
                                iVar10 = 0;
                                goto code_r0x000180233003;
                            }
                            iVar10 = iVar10 + 1;
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e96;
                            func_0x000180229b10();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ead;
                            iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232eb7;
                        uVar4 = func_0x000180220a00();
                        if (((((int32_t)uVar4 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar4) == 0x6c) && (0 < iVar10)) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ed8;
                            func_0x0001802299d0();
                        } else {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f18;
                            func_0x000180229900();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f1d;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f3f;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f5b;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180232f5b:
                            iVar10 = 0;
                        }
                        goto code_r0x000180233003;
                    }
                    if (in_R8D == 2) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f75;
                        iVar9 = func_0x000180240760(iVar8, (int64_t)&arg_38h + iVar7 + iVar5);
                        if (iVar9 != 0) {
                            uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar1 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fac;
                            iVar10 = func_0x00018021f070(uVar1, uVar12);
                            goto code_r0x000180233003;
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f7f;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f97;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    } else {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fb5;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fcd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    }
                }
                goto code_r0x000180232ff6;
            }
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fd9;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ff1;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    }
code_r0x000180232ff6:
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233003;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180233003:
    uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x18023300d;
    func_0x00018021fe80(uVar12);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233015;
    func_0x000180219f80(iVar8);
    return iVar10;
}

// ============================================================
// Function: FUN_180232d2b
// Address: 0x180232d2b
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180232b80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_68h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBP;
    int32_t iVar11;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    int64_t var_18h;
    
    uStack_20 = 0x180232b8f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar10 = 0;
    if (in_R8D == 1) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bc4;
        iVar7 = func_0x00018023f8e0(in_RDX, 0x180625030);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bd1;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232be9;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bfb;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar5);
        *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R9;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c33;
        iVar8 = func_0x0001802a7650(iVar7, 0, 0, 0x1805aadb1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c3e;
        func_0x000180219f80(iVar7);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c48;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c60;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c72;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        iVar11 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c88;
        iVar3 = func_0x000180222010(iVar8);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c9a;
                piVar6 = (int64_t *)func_0x000180222340(iVar8, iVar11);
                if (*piVar6 != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cad;
                    iVar3 = func_0x00018021f070(uVar12);
                    if (iVar3 != 0) {
                        iVar10 = iVar10 + 1;
                        goto code_r0x000180232cb7;
                    }
code_r0x000180232d3e:
                    iVar10 = 0;
                    goto code_r0x000180232d15;
                }
code_r0x000180232cb7:
                if (piVar6[1] != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cc8;
                    iVar3 = func_0x00018021f0d0(uVar12);
                    if (iVar3 == 0) goto code_r0x000180232d3e;
                    iVar10 = iVar10 + 1;
                }
                iVar11 = iVar11 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cde;
                iVar3 = func_0x000180222010(iVar8);
            } while (iVar11 < iVar3);
            if (iVar10 != 0) goto code_r0x000180232d15;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232ceb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d03;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d15;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
code_r0x000180232d15:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d24;
        func_0x000180222050(iVar8, 0x1802a7580);
        return iVar10;
    }
    uVar12 = *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = *(undefined8 *)(&stack0x00000028 + iVar5);
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = uVar12;
    *(undefined8 *)(&stack0x00000028 + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = *(undefined8 *)((int64_t)aiStackX_18 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = 0x180232d6e;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar10 = 0;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232d90;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232da8;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    } else {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232db7;
        uVar12 = func_0x00018023faa0();
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232dbf;
        iVar8 = func_0x00018021a7c0(uVar12);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232de1;
            iVar3 = func_0x000180219d10(iVar8, 0x6c, 3, in_RDX);
            if (0 < iVar3) {
                uVar12 = *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar5);
                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232df9;
                iVar9 = func_0x00018021ff10(in_R9, uVar12);
                *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e08;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e20;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                } else {
                    if (in_R8D == 1) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e39;
                        func_0x000180229b10();
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e50;
                        iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        while (iVar9 != 0) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e5a;
                            func_0x000180229900();
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar2 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e68;
                            iVar3 = func_0x00018021f070(uVar2, uVar1);
                            if (iVar3 == 0) goto code_r0x000180232f5b;
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e7a;
                            func_0x00018021fe80(uVar1);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e85;
                            iVar9 = func_0x00018021ff10(in_R9, uVar12);
                            *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                            if (iVar9 == 0) {
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ee2;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232efa;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f0c;
                                fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
                                iVar10 = 0;
                                goto code_r0x000180233003;
                            }
                            iVar10 = iVar10 + 1;
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e96;
                            func_0x000180229b10();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ead;
                            iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232eb7;
                        uVar4 = func_0x000180220a00();
                        if (((((int32_t)uVar4 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar4) == 0x6c) && (0 < iVar10)) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ed8;
                            func_0x0001802299d0();
                        } else {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f18;
                            func_0x000180229900();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f1d;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f3f;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f5b;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180232f5b:
                            iVar10 = 0;
                        }
                        goto code_r0x000180233003;
                    }
                    if (in_R8D == 2) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f75;
                        iVar9 = func_0x000180240760(iVar8, (int64_t)&arg_38h + iVar7 + iVar5);
                        if (iVar9 != 0) {
                            uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar1 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fac;
                            iVar10 = func_0x00018021f070(uVar1, uVar12);
                            goto code_r0x000180233003;
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f7f;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f97;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    } else {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fb5;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fcd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    }
                }
                goto code_r0x000180232ff6;
            }
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fd9;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ff1;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    }
code_r0x000180232ff6:
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233003;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180233003:
    uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x18023300d;
    func_0x00018021fe80(uVar12);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233015;
    func_0x000180219f80(iVar8);
    return iVar10;
}

// ============================================================
// Function: FUN_180232d3e
// Address: 0x180232d3e
// Size: 4 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180232b80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_68h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBP;
    int32_t iVar11;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    int64_t var_18h;
    
    uStack_20 = 0x180232b8f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar10 = 0;
    if (in_R8D == 1) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bc4;
        iVar7 = func_0x00018023f8e0(in_RDX, 0x180625030);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bd1;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232be9;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bfb;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar5);
        *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R9;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c33;
        iVar8 = func_0x0001802a7650(iVar7, 0, 0, 0x1805aadb1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c3e;
        func_0x000180219f80(iVar7);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c48;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c60;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c72;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        iVar11 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c88;
        iVar3 = func_0x000180222010(iVar8);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c9a;
                piVar6 = (int64_t *)func_0x000180222340(iVar8, iVar11);
                if (*piVar6 != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cad;
                    iVar3 = func_0x00018021f070(uVar12);
                    if (iVar3 != 0) {
                        iVar10 = iVar10 + 1;
                        goto code_r0x000180232cb7;
                    }
code_r0x000180232d3e:
                    iVar10 = 0;
                    goto code_r0x000180232d15;
                }
code_r0x000180232cb7:
                if (piVar6[1] != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cc8;
                    iVar3 = func_0x00018021f0d0(uVar12);
                    if (iVar3 == 0) goto code_r0x000180232d3e;
                    iVar10 = iVar10 + 1;
                }
                iVar11 = iVar11 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cde;
                iVar3 = func_0x000180222010(iVar8);
            } while (iVar11 < iVar3);
            if (iVar10 != 0) goto code_r0x000180232d15;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232ceb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d03;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d15;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
code_r0x000180232d15:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d24;
        func_0x000180222050(iVar8, 0x1802a7580);
        return iVar10;
    }
    uVar12 = *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = *(undefined8 *)(&stack0x00000028 + iVar5);
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = uVar12;
    *(undefined8 *)(&stack0x00000028 + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = *(undefined8 *)((int64_t)aiStackX_18 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = 0x180232d6e;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar10 = 0;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232d90;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232da8;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    } else {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232db7;
        uVar12 = func_0x00018023faa0();
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232dbf;
        iVar8 = func_0x00018021a7c0(uVar12);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232de1;
            iVar3 = func_0x000180219d10(iVar8, 0x6c, 3, in_RDX);
            if (0 < iVar3) {
                uVar12 = *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar5);
                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232df9;
                iVar9 = func_0x00018021ff10(in_R9, uVar12);
                *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e08;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e20;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                } else {
                    if (in_R8D == 1) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e39;
                        func_0x000180229b10();
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e50;
                        iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        while (iVar9 != 0) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e5a;
                            func_0x000180229900();
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar2 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e68;
                            iVar3 = func_0x00018021f070(uVar2, uVar1);
                            if (iVar3 == 0) goto code_r0x000180232f5b;
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e7a;
                            func_0x00018021fe80(uVar1);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e85;
                            iVar9 = func_0x00018021ff10(in_R9, uVar12);
                            *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                            if (iVar9 == 0) {
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ee2;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232efa;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f0c;
                                fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
                                iVar10 = 0;
                                goto code_r0x000180233003;
                            }
                            iVar10 = iVar10 + 1;
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e96;
                            func_0x000180229b10();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ead;
                            iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232eb7;
                        uVar4 = func_0x000180220a00();
                        if (((((int32_t)uVar4 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar4) == 0x6c) && (0 < iVar10)) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ed8;
                            func_0x0001802299d0();
                        } else {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f18;
                            func_0x000180229900();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f1d;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f3f;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f5b;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180232f5b:
                            iVar10 = 0;
                        }
                        goto code_r0x000180233003;
                    }
                    if (in_R8D == 2) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f75;
                        iVar9 = func_0x000180240760(iVar8, (int64_t)&arg_38h + iVar7 + iVar5);
                        if (iVar9 != 0) {
                            uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar1 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fac;
                            iVar10 = func_0x00018021f070(uVar1, uVar12);
                            goto code_r0x000180233003;
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f7f;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f97;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    } else {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fb5;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fcd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    }
                }
                goto code_r0x000180232ff6;
            }
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fd9;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ff1;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    }
code_r0x000180232ff6:
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233003;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180233003:
    uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x18023300d;
    func_0x00018021fe80(uVar12);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233015;
    func_0x000180219f80(iVar8);
    return iVar10;
}

// ============================================================
// Function: FUN_180232d50
// Address: 0x180232d50
// Size: 736 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180232b80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_68h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBP;
    int32_t iVar11;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    int64_t var_18h;
    
    uStack_20 = 0x180232b8f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar10 = 0;
    if (in_R8D == 1) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bc4;
        iVar7 = func_0x00018023f8e0(in_RDX, 0x180625030);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bd1;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232be9;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232bfb;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar5);
        *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R9;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c33;
        iVar8 = func_0x0001802a7650(iVar7, 0, 0, 0x1805aadb1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c3e;
        func_0x000180219f80(iVar7);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c48;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c60;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c72;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        iVar11 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c88;
        iVar3 = func_0x000180222010(iVar8);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232c9a;
                piVar6 = (int64_t *)func_0x000180222340(iVar8, iVar11);
                if (*piVar6 != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cad;
                    iVar3 = func_0x00018021f070(uVar12);
                    if (iVar3 != 0) {
                        iVar10 = iVar10 + 1;
                        goto code_r0x000180232cb7;
                    }
code_r0x000180232d3e:
                    iVar10 = 0;
                    goto code_r0x000180232d15;
                }
code_r0x000180232cb7:
                if (piVar6[1] != 0) {
                    uVar12 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cc8;
                    iVar3 = func_0x00018021f0d0(uVar12);
                    if (iVar3 == 0) goto code_r0x000180232d3e;
                    iVar10 = iVar10 + 1;
                }
                iVar11 = iVar11 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232cde;
                iVar3 = func_0x000180222010(iVar8);
            } while (iVar11 < iVar3);
            if (iVar10 != 0) goto code_r0x000180232d15;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232ceb;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d03;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d15;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
code_r0x000180232d15:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180232d24;
        func_0x000180222050(iVar8, 0x1802a7580);
        return iVar10;
    }
    uVar12 = *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = *(undefined8 *)(&stack0x00000028 + iVar5);
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = uVar12;
    *(undefined8 *)(&stack0x00000028 + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = *(undefined8 *)((int64_t)aiStackX_18 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = 0x180232d6e;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar10 = 0;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232d90;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232da8;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    } else {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232db7;
        uVar12 = func_0x00018023faa0();
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232dbf;
        iVar8 = func_0x00018021a7c0(uVar12);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232de1;
            iVar3 = func_0x000180219d10(iVar8, 0x6c, 3, in_RDX);
            if (0 < iVar3) {
                uVar12 = *(undefined8 *)((int64_t)&arg_88h + iVar7 + iVar5);
                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232df9;
                iVar9 = func_0x00018021ff10(in_R9, uVar12);
                *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e08;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e20;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                } else {
                    if (in_R8D == 1) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e39;
                        func_0x000180229b10();
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e50;
                        iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        while (iVar9 != 0) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e5a;
                            func_0x000180229900();
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar2 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e68;
                            iVar3 = func_0x00018021f070(uVar2, uVar1);
                            if (iVar3 == 0) goto code_r0x000180232f5b;
                            uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e7a;
                            func_0x00018021fe80(uVar1);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e85;
                            iVar9 = func_0x00018021ff10(in_R9, uVar12);
                            *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5) = iVar9;
                            if (iVar9 == 0) {
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ee2;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232efa;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                                *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f0c;
                                fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
                                iVar10 = 0;
                                goto code_r0x000180233003;
                            }
                            iVar10 = iVar10 + 1;
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232e96;
                            func_0x000180229b10();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ead;
                            iVar9 = func_0x000180242c60(iVar8, (int64_t)&arg_38h + iVar7 + iVar5, 0, 0x1805aadb1);
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232eb7;
                        uVar4 = func_0x000180220a00();
                        if (((((int32_t)uVar4 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar4) == 0x6c) && (0 < iVar10)) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ed8;
                            func_0x0001802299d0();
                        } else {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f18;
                            func_0x000180229900();
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f1d;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f3f;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f5b;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180232f5b:
                            iVar10 = 0;
                        }
                        goto code_r0x000180233003;
                    }
                    if (in_R8D == 2) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f75;
                        iVar9 = func_0x000180240760(iVar8, (int64_t)&arg_38h + iVar7 + iVar5);
                        if (iVar9 != 0) {
                            uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
                            uVar1 = *(undefined8 *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fac;
                            iVar10 = func_0x00018021f070(uVar1, uVar12);
                            goto code_r0x000180233003;
                        }
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f7f;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232f97;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    } else {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fb5;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fcd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
                    }
                }
                goto code_r0x000180232ff6;
            }
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232fd9;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180232ff1;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar5));
    }
code_r0x000180232ff6:
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233003;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar7 + iVar5));
code_r0x000180233003:
    uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x18023300d;
    func_0x00018021fe80(uVar12);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar7 + iVar5 + -8) = 0x180233015;
    func_0x000180219f80(iVar8);
    return iVar10;
}

// ============================================================
// Function: FUN_180233030
// Address: 0x180233030
// Size: 569 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.180233030(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar6;
    int32_t iVar7;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023304e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar5 = 0;
    iVar7 = 0;
    iVar6 = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023306a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180233082;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
        iVar6 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180233091;
        uVar4 = func_0x00018023faa0();
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180233099;
        iVar5 = func_0x00018021a7c0(uVar4);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802330bb;
            iVar1 = func_0x000180219d10(iVar5, 0x6c, 3, in_RDX);
            if (0 < iVar1) {
                if (in_R8D == 1) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802330e1;
                    iVar6 = func_0x0001802a7bb0(iVar5, 0, 0, 0x1805aadb1);
                    while (iVar6 != 0) {
                        uVar4 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802330fc;
                        iVar1 = func_0x00018021f0d0(uVar4, iVar6);
                        if (iVar1 == 0) goto code_r0x000180233198;
                        iVar7 = iVar7 + 1;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023310e;
                        func_0x00018028eb90(iVar6);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180233122;
                        iVar6 = func_0x0001802a7bb0(iVar5, 0, 0, 0x1805aadb1);
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023312f;
                    uVar2 = func_0x000180220a00();
                    if (((((int32_t)uVar2 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar2) == 0x6c) && (0 < iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180233150;
                        func_0x0001802203d0();
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023315a;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023317c;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar3));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180233198;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
code_r0x000180233198:
                        iVar7 = 0;
                    }
                    goto code_r0x00018023323e;
                }
                if (in_R8D == 2) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802331af;
                    iVar6 = func_0x000180240720(iVar5, 0);
                    if (iVar6 != 0) {
                        uVar4 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802331e7;
                        iVar7 = func_0x00018021f0d0(uVar4, iVar6);
                        goto code_r0x00018023323e;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802331bc;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802331d4;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802331f0;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180233208;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
                    iVar6 = 0;
                }
                goto code_r0x000180233231;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180233214;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023322c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
    }
code_r0x000180233231:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023323e;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
code_r0x00018023323e:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180233246;
    func_0x00018028eb90(iVar6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023324e;
    func_0x000180219f80(iVar5);
    return iVar7;
}

// ============================================================
// Function: FUN_180233270
// Address: 0x180233270
// Size: 52 bytes
// ============================================================
void fcn.180233270(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_88h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int32_t *piVar6;
    code *pcVar7;
    int32_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar9;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 auStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x18023327a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180233282;
    uVar5 = func_0x0001801dd6c0();
    *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180233291;
    piVar6 = (int32_t *)func_0x000180222290(uVar5, 0x180196ec0);
    pcVar7 = (code *)0x180233830;
    if (piVar6 != (int32_t *)0x0) {
        *(undefined8 *)(&stack0x00000048 + iVar4) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RSI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180222069;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_50h + iVar3 + iVar4) = unaff_RBX;
        iVar8 = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar3 + iVar4) = unaff_R14;
        if (0 < *piVar6) {
            *(undefined8 *)((int64_t)&arg_58h + iVar3 + iVar4) = unaff_RDI;
            iVar9 = 0;
            do {
                iVar1 = *(int64_t *)(iVar9 + *(int64_t *)(piVar6 + 2));
                if (iVar1 != 0) {
                    pcVar2 = *(code **)(piVar6 + 8);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x1802220b2;
                        (*pcVar7)();
                    } else {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x1802220ae;
                        (*pcVar2)(pcVar7, iVar1);
                    }
                }
                iVar8 = iVar8 + 1;
                iVar9 = iVar9 + 8;
            } while (iVar8 < *piVar6);
        }
        uVar5 = *(undefined8 *)(piVar6 + 2);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x1802220d7;
        fcn.180224990(uVar5, 0x1804bf768, 0x1ce);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x1802220ec;
        fcn.180224990(piVar6, 0x1804bf768, 0x1cf);
    }
    return;
}

