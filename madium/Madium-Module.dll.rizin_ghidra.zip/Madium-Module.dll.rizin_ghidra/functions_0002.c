// Chunk 2 - 50 functions

// ============================================================
// Function: FUN_1800029c0
// Address: 0x1800029c0
// Size: 362 bytes
// ============================================================
void fcn.1800029c0(void)
{
    undefined auStack_118 [32];
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    var_e8h._0_4_ = 0;
    var_d0h = 8;
    var_c8h = 0xf;
    var_e0h = 0x797469746e656469;
    var_d8h = 0;
    var_c0h._0_4_ = 1;
    var_a8h = 7;
    var_a0h = 0xf;
    _var_b8h = ZEXT716(0x6574616c666564);
    var_98h._0_4_ = 2;
    var_80h = 4;
    var_78h = 0xf;
    stack0xffffffffffffff75 = SUB1611(ZEXT816(0), 5);
    var_90h._0_5_ = 0x62696c7a;
    var_70h._0_4_ = 3;
    var_58h = 4;
    var_50h = 0xf;
    stack0xffffffffffffff9d = SUB1611(ZEXT816(0), 5);
    var_68h._0_5_ = 0x70697a67;
    var_48h._0_4_ = 4;
    var_30h = 8;
    var_28h = 0xf;
    var_40h = 0x64656c6261736964;
    var_38h = 0;
    var_f8h = (int64_t)&var_e8h;
    var_f0h = (int64_t)&var_20h;
    fcn.18003e070(0x180781f88, &var_f8h);
    fcn.180459d94(&var_e8h, 0x28, 5, 0x1800131a0);
    fcn.180459c24(0x1804a2a30);
    fcn.180459870(var_18h ^ (uint64_t)auStack_118);
    return;
}

// ============================================================
// Function: FUN_180002b90
// Address: 0x180002b90
// Size: 145 bytes
// ============================================================
// WARNING: Control flow encountered bad instruction data
// WARNING: Removing unreachable block (ram,0x00018049879a)
// WARNING: Removing unreachable block (ram,0x000180002bef)
// WARNING: Removing unreachable block (ram,0x000180002bc9)
// WARNING: Removing unreachable block (ram,0x000180002b9d)
// WARNING: Removing unreachable block (ram,0x000180498710)

undefined8 fcn.180002b90(void)
{
    undefined auVar1 [32];
    undefined (*pauVar2) [16];
    undefined8 uVar3;
    int64_t iVar4;
    undefined (*pauVar5) [32];
    undefined (*pauVar6) [32];
    undefined (*pauVar7) [16];
    char *unaff_RBX;
    undefined *puVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    undefined in_YMM0 [32];
    undefined auVar13 [32];
    
    iVar4 = cpuid_Version_info(1);
    *(undefined8 *)0x180777088 = 0x18008da70;
    if ((*(uint32_t *)(iVar4 + 0xc) >> 0x13 & 1) != 0) {
        *(undefined8 *)0x180777088 = 0x180090d70;
    }
    iVar4 = cpuid_Version_info(1);
    *(undefined8 *)0x1807770b0 = 0x18008dc10;
    if ((*(uint32_t *)(iVar4 + 0xc) >> 0x13 & 1) != 0) {
        *(undefined8 *)0x1807770b0 = 0x180090d30;
    }
    iVar4 = cpuid_Version_info(1);
    *(undefined8 *)0x1807771d0 = 0x18008ed00;
    if ((*(uint32_t *)(iVar4 + 0xc) >> 0x13 & 1) != 0) {
        *(undefined8 *)0x1807771d0 = 0x180090db0;
    }
    uVar3 = 0x180777678;
    auVar13._16_16_ = in_YMM0._16_16_;
    auVar13._0_16_ = ZEXT816(0);
    if (2 < *(uint32_t *)0x1806a3990) {
        if (((0x1d7 < *(uint64_t *)0x1806a3998) || (*(uint64_t *)0x1806a39a0 < 0x1d8)) ||
           ((*(uint8_t *)0x18078131c & 2) == 0)) {
            auVar13 = vinsertf128_avx(auVar13, auVar13._0_16_, 1);
            pauVar6 = (undefined (*) [32])0x180777680;
            uVar10 = 0x1d0;
            if (0x1cf < *(uint64_t *)0x1806a39a0) {
                do {
                    uVar9 = uVar10;
                    pauVar5 = pauVar6;
                    *pauVar5 = auVar13;
                    pauVar5[1] = auVar13;
                    pauVar5[2] = auVar13;
                    pauVar5[3] = auVar13;
                    pauVar5[4] = auVar13;
                    pauVar5[5] = auVar13;
                    pauVar5[6] = auVar13;
                    pauVar5[7] = auVar13;
                    pauVar6 = pauVar5 + 8;
                    uVar10 = uVar9 - 0x100;
                } while (0xff < uVar10);
                uVar12 = uVar9 - 0xe1 & 0xffffffffffffffe0;
    // WARNING: Could not find normalized switch variable to match jumptable
    // switch table (27 cases) at 0x180650a50
                switch(uVar9) {
                case 0xf0:
    // WARNING: This code block may not be properly labeled as switch case
                    auVar1 = vmovdqu_avx(auVar13);
                    *(undefined (*) [32])(*pauVar5 + uVar12) = auVar1;
                case 0xd0:
                case 0xe0:
    // WARNING: This code block may not be properly labeled as switch case
                    auVar1 = vmovdqu_avx(auVar13);
                    *(undefined (*) [32])(pauVar5[1] + uVar12) = auVar1;
                case 0xb0:
                case 0xc0:
    // WARNING: This code block may not be properly labeled as switch case
                    auVar1 = vmovdqu_avx(auVar13);
                    *(undefined (*) [32])(pauVar5[2] + uVar12) = auVar1;
                case 0x90:
                case 0xa0:
    // WARNING: This code block may not be properly labeled as switch case
                    auVar1 = vmovdqu_avx(auVar13);
                    *(undefined (*) [32])(pauVar5[3] + uVar12) = auVar1;
                case 0x70:
                case 0x80:
    // WARNING: This code block may not be properly labeled as switch case
                    auVar1 = vmovdqu_avx(auVar13);
                    *(undefined (*) [32])(pauVar5[4] + uVar12) = auVar1;
                case 0x50:
                case 0x60:
    // WARNING: This code block may not be properly labeled as switch case
                    auVar1 = vmovdqu_avx(auVar13);
                    *(undefined (*) [32])(pauVar5[5] + uVar12) = auVar1;
                case 0x30:
                case 0x40:
    // WARNING: This code block may not be properly labeled as switch case
                    auVar1 = vmovdqu_avx(auVar13);
                    *(undefined (*) [32])(pauVar5[6] + uVar12) = auVar1;
                default:
    // WARNING: This code block may not be properly labeled as switch case
                    auVar1 = vmovdqu_avx(auVar13);
                    *(undefined (*) [32])(pauVar5[-1] + uVar9) = auVar1;
                case 0:
    // WARNING: This code block may not be properly labeled as switch case
                    *(undefined (*) [32])0x180777678 = vmovdqu_avx(auVar13);
                    return uVar3;
                case 0xbad1abe1:
                    goto code_r0x00018049894b;
                }
            }
            do {
                uVar9 = uVar10;
                pauVar5 = pauVar6;
                auVar1 = vmovntdq_avx(auVar13);
                *pauVar5 = auVar1;
                auVar1 = vmovntdq_avx(auVar13);
                pauVar5[1] = auVar1;
                auVar1 = vmovntdq_avx(auVar13);
                pauVar5[2] = auVar1;
                auVar1 = vmovntdq_avx(auVar13);
                pauVar5[3] = auVar1;
                auVar1 = vmovntdq_avx(auVar13);
                pauVar5[4] = auVar1;
                auVar1 = vmovntdq_avx(auVar13);
                pauVar5[5] = auVar1;
                auVar1 = vmovntdq_avx(auVar13);
                pauVar5[6] = auVar1;
                auVar1 = vmovntdq_avx(auVar13);
                pauVar5[7] = auVar1;
                pauVar6 = pauVar5 + 8;
                uVar10 = uVar9 - 0x100;
            } while (0xff < uVar10);
            uVar12 = uVar9 - 0xe1 & 0xffffffffffffffe0;
    // switch table (18 cases) at 0x180650a74
            switch(uVar9) {
            case 0x1f0:
                auVar1 = vmovntdq_avx(auVar13);
                *(undefined (*) [32])(*pauVar5 + uVar12) = auVar1;
            case 0x1d0:
            case 0x1e0:
                auVar1 = vmovntdq_avx(auVar13);
                *(undefined (*) [32])(pauVar5[1] + uVar12) = auVar1;
            case 0x1b0:
            case 0x1c0:
code_r0x00018049894b:
                auVar1 = vmovntdq_avx(auVar13);
                *(undefined (*) [32])(pauVar6[-6] + uVar12) = auVar1;
            case 400:
            case 0x1a0:
                auVar1 = vmovntdq_avx(auVar13);
                *(undefined (*) [32])(pauVar6[-5] + uVar12) = auVar1;
            case 0x170:
            case 0x180:
                auVar1 = vmovntdq_avx(auVar13);
                *(undefined (*) [32])(pauVar6[-4] + uVar12) = auVar1;
            case 0x150:
            case 0x160:
                auVar1 = vmovntdq_avx(auVar13);
                *(undefined (*) [32])(pauVar6[-3] + uVar12) = auVar1;
            case 0x130:
            case 0x140:
                auVar1 = vmovntdq_avx(auVar13);
                *(undefined (*) [32])(pauVar6[-2] + uVar12) = auVar1;
            default:
                auVar1 = vmovdqu_avx(auVar13);
                *(undefined (*) [32])(pauVar6[-1] + uVar10) = auVar1;
            case 0x100:
                *(undefined (*) [32])0x180777678 = vmovdqu_avx(auVar13);
                return uVar3;
            }
        }
code_r0x0001804986d0:
        puVar8 = (undefined *)0x180777678;
        for (iVar4 = 0x1d8; iVar4 != 0; iVar4 = iVar4 + -1) {
            *puVar8 = 0;
            puVar8 = puVar8 + 1;
        }
        return 0x180777678;
    }
    if ((*(uint64_t *)0x1806a3998 < 0x1d8) && ((*(uint8_t *)0x18078131c & 2) != 0)) goto code_r0x0001804986d0;
    pauVar2 = (undefined (*) [16])0x180777680;
    iVar4 = 0x1d0;
    iVar11 = iVar4;
    pauVar7 = pauVar2;
    *pauVar7 = auVar13._0_16_;
    pauVar7[1] = auVar13._0_16_;
    pauVar7[2] = auVar13._0_16_;
    pauVar7[3] = auVar13._0_16_;
    pauVar7[4] = auVar13._0_16_;
    pauVar7[5] = auVar13._0_16_;
    pauVar7[6] = auVar13._0_16_;
    pauVar7[7] = auVar13._0_16_;
    pauVar2 = pauVar7 + 8;
    iVar4 = iVar11 + -0x80;
    // WARNING: Could not find normalized switch variable to match jumptable
    // switch table (9 cases) at 0x180650a98
    switch(iVar11) {
    case 0:
        goto code_r0x000180498a63;
    case 0x70:
    // WARNING: This code block may not be properly labeled as switch case
        *(undefined (*) [16])(pauVar7[-7] + iVar11) = auVar13._0_16_;
    case 0x60:
    // WARNING: This code block may not be properly labeled as switch case
        *(undefined (*) [16])(pauVar7[-6] + iVar11) = auVar13._0_16_;
    case 0x50:
    // WARNING: This code block may not be properly labeled as switch case
        *(undefined (*) [16])(pauVar7[-5] + iVar11) = auVar13._0_16_;
    case 0x40:
    // WARNING: This code block may not be properly labeled as switch case
        *(undefined (*) [16])(pauVar7[-4] + iVar11) = auVar13._0_16_;
    case 0x30:
    // WARNING: This code block may not be properly labeled as switch case
        *(undefined (*) [16])(pauVar7[-3] + iVar11) = auVar13._0_16_;
    case 0x20:
    // WARNING: This code block may not be properly labeled as switch case
        *(undefined (*) [16])(pauVar7[-2] + iVar11) = auVar13._0_16_;
    case 0x10:
    // WARNING: This code block may not be properly labeled as switch case
        *(undefined (*) [16])(pauVar7[-1] + iVar11) = auVar13._0_16_;
code_r0x000180498a63:
    // WARNING: This code block may not be properly labeled as switch case
        *(undefined (*) [16])0x180777678 = auVar13._0_16_;
        return uVar3;
    case 0xbad1abe1:
        *unaff_RBX = *unaff_RBX + 'x';
        *(char *)0x300eeecf0 = *(char *)0x300eeecf0 + 'x';
        *(undefined *)0x180777678 = *(char *)0x180777678 + -0x10;
    // WARNING: Bad instruction - Truncating control flow here
        halt_baddata();
    }
}

// ============================================================
// Function: FUN_180002e50
// Address: 0x180002e50
// Size: 122 bytes
// ============================================================
void fcn.180002e50(void)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    
    iVar4 = *(int64_t *)0x1807824f0;
    iVar2 = *(int64_t *)0x1807824f8;
    if (*(int64_t *)0x1807824f0 != 0) {
        do {
            iVar3 = func_0x000180498f10(*(undefined8 *)(iVar4 + 8), 0x18063eec8);
            if (iVar3 == 0) {
                *(undefined4 *)(iVar4 + 0x18) = 2;
            }
            piVar1 = (int64_t *)(iVar4 + 0x10);
            iVar4 = *piVar1;
            iVar2 = *(int64_t *)0x1807824f8;
        } while (*piVar1 != 0);
    }
    for (; iVar2 != 0; iVar2 = *(int64_t *)(iVar2 + 0x10)) {
        iVar3 = func_0x000180498f10(*(undefined8 *)(iVar2 + 8), 0x18063eec8);
        if (iVar3 == 0) {
            *(undefined4 *)(iVar2 + 0x18) = 2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180003750
// Address: 0x180003750
// Size: 122 bytes
// ============================================================
void fcn.180003750(void)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    
    iVar4 = *(int64_t *)0x1807824f0;
    iVar2 = *(int64_t *)0x1807824f8;
    if (*(int64_t *)0x1807824f0 != 0) {
        do {
            iVar3 = func_0x000180498f10(*(undefined8 *)(iVar4 + 8), 0x1806426f8);
            if (iVar3 == 0) {
                *(undefined4 *)(iVar4 + 0x18) = 3;
            }
            piVar1 = (int64_t *)(iVar4 + 0x10);
            iVar4 = *piVar1;
            iVar2 = *(int64_t *)0x1807824f8;
        } while (*piVar1 != 0);
    }
    for (; iVar2 != 0; iVar2 = *(int64_t *)(iVar2 + 0x10)) {
        iVar3 = func_0x000180498f10(*(undefined8 *)(iVar2 + 8), 0x1806426f8);
        if (iVar3 == 0) {
            *(undefined4 *)(iVar2 + 0x18) = 3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800038d0
// Address: 0x1800038d0
// Size: 26 bytes
// ============================================================
int32_t fcn.1800038d0(void)
{
    int64_t iVar1;
    
    iVar1 = fcn.180459be8(0x1804a2c50);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_1800038f0
// Address: 0x1800038f0
// Size: 927 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_224h
// WARNING: [rz-ghidra] Detected overlap for variable var_214h
// WARNING: [rz-ghidra] Detected overlap for variable var_212h
// WARNING: [rz-ghidra] Detected overlap for variable var_1d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1d3h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b3h
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_193h
// WARNING: [rz-ghidra] Detected overlap for variable var_174h
// WARNING: [rz-ghidra] Detected overlap for variable var_173h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_153h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_133h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_eeh
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_72h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_53h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_32h
// WARNING: [rz-ghidra] Detected overlap for variable var_228h

void fcn.1800038f0(void)
{
    undefined auStackY_248 [32];
    undefined4 var_228h;
    int64_t var_224h;
    int64_t var_218h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1e8h;
    int64_t var_1e0h;
    int64_t var_1d8h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b8h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    undefined8 uStack_148;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_248;
    var_208h = 6;
    var_200h = 0xf;
    stack0xfffffffffffffdef = SUB169(ZEXT816(0), 7);
    var_218h._0_7_ = 0x6c6c61635f5f;
    var_1e8h = 8;
    var_1e0h = 0xf;
    var_1f8h = 0x7461636e6f635f5f;
    var_1f0h = 0;
    var_1c8h = 5;
    var_1c0h = 0xf;
    stack0xfffffffffffffe2e = SUB1610(ZEXT816(0), 6);
    var_1d8h._0_6_ = 0x6d6e755f5f;
    var_1a8h = 5;
    var_1a0h = 0xf;
    stack0xfffffffffffffe4e = SUB1610(ZEXT816(0), 6);
    var_1b8h._0_6_ = 0x6464615f5f;
    var_188h = 5;
    var_180h = 0xf;
    stack0xfffffffffffffe6e = SUB1610(ZEXT816(0), 6);
    var_198h._0_6_ = 0x6275735f5f;
    var_168h = 5;
    var_160h = 0xf;
    stack0xfffffffffffffe8e = SUB1610(ZEXT816(0), 6);
    var_178h._0_6_ = 0x6c756d5f5f;
    uStack_148 = 5;
    var_140h = 0xf;
    stack0xfffffffffffffeae = SUB1610(ZEXT816(0), 6);
    var_158h._0_6_ = 0x7669645f5f;
    var_128h = 5;
    var_120h = 0xf;
    stack0xfffffffffffffece = SUB1610(ZEXT816(0), 6);
    var_138h._0_6_ = 0x646f6d5f5f;
    var_108h = 5;
    var_100h = 0xf;
    stack0xfffffffffffffeee = SUB1610(ZEXT816(0), 6);
    var_118h._0_6_ = 0x776f705f5f;
    var_e8h = 10;
    var_e0h = 0xf;
    var_f0h._0_2_ = 0x676e;
    var_f8h = 0x697274736f745f5f;
    var_f0h._2_6_ = 0;
    var_c8h = 4;
    var_c0h = 0xf;
    stack0xffffffffffffff2d = SUB1611(ZEXT816(0), 5);
    var_d8h._0_5_ = 0x71655f5f;
    var_a8h = 4;
    var_a0h = 0xf;
    stack0xffffffffffffff4d = SUB1611(ZEXT816(0), 5);
    var_b8h._0_5_ = 0x746c5f5f;
    var_88h = 4;
    var_80h = 0xf;
    stack0xffffffffffffff6d = SUB1611(ZEXT816(0), 5);
    var_98h._0_5_ = 0x656c5f5f;
    var_68h = 6;
    var_60h = 0xf;
    stack0xffffffffffffff8f = SUB169(ZEXT816(0), 7);
    var_78h._0_7_ = 0x726574695f5f;
    var_48h = 5;
    var_40h = 0xf;
    stack0xffffffffffffffae = SUB1610(ZEXT816(0), 6);
    var_58h._0_6_ = 0x6e656c5f5f;
    var_28h = 6;
    var_20h = 0xf;
    stack0xffffffffffffffcf = SUB169(ZEXT816(0), 7);
    var_38h._0_7_ = 0x766964695f5f;
    var_224h._0_4_ = 0;
    fcn.18001f430(0x180781fa0, &var_224h, &var_228h);
    fcn.18001f7a0(CONCAT44((undefined4)var_224h, var_228h));
    fcn.180459d94(&var_218h, 0x20, 0x10, 0x180004dd0);
    fcn.180459c24(0x1804a2c70);
    fcn.180459870(var_18h ^ (uint64_t)auStackY_248);
    return;
}

// ============================================================
// Function: FUN_180003c90
// Address: 0x180003c90
// Size: 454 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_b2h
// WARNING: [rz-ghidra] Detected overlap for variable var_b1h
// WARNING: [rz-ghidra] Detected overlap for variable var_8eh
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_72h
// WARNING: [rz-ghidra] Detected overlap for variable var_51h
// WARNING: [rz-ghidra] Detected overlap for variable var_4dh
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_32h

void fcn.180003c90(void)
{
    undefined auStackY_d8 [32];
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    unkbyte5 var_4dh;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_d8;
    var_a8h = 7;
    var_a0h = 0xf;
    _var_b8h = ZEXT716(0x7865646e695f5f);
    var_88h = 10;
    var_80h = 0xf;
    var_90h._0_2_ = 0x7865;
    var_98h = 0x646e6977656e5f5f;
    var_90h._2_6_ = 0;
    var_68h = 6;
    var_60h = 0xf;
    stack0xffffffffffffff8f = SUB169(ZEXT816(0), 7);
    var_78h._0_7_ = 0x65646f6d5f5f;
    var_48h = 0xb;
    var_40h = 0xf;
    _var_58h = ZEXT816(0x61746174656d5f5f);
    stack0xffffffffffffffaf = 0x656c6261;
    var_4dh = 0;
    var_28h = 6;
    var_20h = 0xf;
    stack0xffffffffffffffcf = SUB169(ZEXT816(0), 7);
    var_38h._0_7_ = 0x657079745f5f;
    *(int64_t *)0x180782348 = fcn.180459890(0x30);
    *(int64_t *)*(int64_t *)0x180782348 = *(int64_t *)0x180782348;
    *(int64_t *)(*(int64_t *)0x180782348 + 8) = *(int64_t *)0x180782348;
    *(undefined8 *)0x180782358 = 0;
    *(undefined (*) [16])0x180782360 = ZEXT816(0);
    *(undefined8 *)0x180782370 = 7;
    *(undefined8 *)0x180782378 = 8;
    *(undefined4 *)0x180782340 = 0x3f800000;
    fcn.18000f7e0(0x180782358, 0x10, *(int64_t *)0x180782348);
    fcn.18001f7a0(var_b8h);
    fcn.180459d94(&var_b8h, 0x20, 5, 0x180004dd0);
    fcn.180459c24(0x1804a2c90);
    fcn.180459870(var_18h ^ (uint64_t)auStackY_d8);
    return;
}

// ============================================================
// Function: FUN_180003e70
// Address: 0x180003e70
// Size: 592 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_102h
// WARNING: [rz-ghidra] Detected overlap for variable var_101h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_28ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28ah
// WARNING: [rz-ghidra] Detected overlap for variable var_289h
// WARNING: [rz-ghidra] Detected overlap for variable var_264h
// WARNING: [rz-ghidra] Detected overlap for variable var_23ch

uint64_t fcn.180003e70(void)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *unaff_RSI;
    int64_t unaff_RDI;
    undefined auStack_310 [32];
    int64_t var_2f0h;
    int64_t var_2e8h;
    int64_t var_2e0h;
    undefined4 uStack_2d8;
    undefined4 uStack_2d4;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_268h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    undefined8 uStack_210;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1e0h;
    undefined4 uStack_1d8;
    undefined4 uStack_1d4;
    undefined8 uStack_1c8;
    int64_t iStack_1c0;
    undefined8 uStack_1b8;
    undefined8 uStack_1b0;
    int64_t iStack_1a8;
    int64_t *piStack_1a0;
    int64_t *piStack_198;
    undefined8 *puStack_190;
    undefined auStack_188 [32];
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    undefined4 uStack_150;
    undefined4 uStack_14c;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    undefined8 uStack_88;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    var_68h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_188;
    var_138h._0_4_ = 0;
    var_120h = 8;
    var_118h = 0xf;
    var_130h = 0x797469746e656469;
    var_128h = 0;
    var_110h._0_4_ = 1;
    var_f8h = 7;
    var_f0h = 0xf;
    _var_108h = ZEXT716(0x6574616c666564);
    var_e8h._0_4_ = 2;
    var_d0h = 4;
    var_c8h = 0xf;
    stack0xffffffffffffff25 = SUB1611(ZEXT816(0), 5);
    var_e0h._0_5_ = 0x62696c7a;
    var_c0h._0_4_ = 3;
    var_a8h = 4;
    var_a0h = 0xf;
    stack0xffffffffffffff4d = SUB1611(ZEXT816(0), 5);
    var_b8h._0_5_ = 0x70697a67;
    var_98h._0_4_ = 4;
    var_80h = 8;
    var_78h = 0xf;
    var_90h = 0x64656c6261736964;
    uStack_88 = 0;
    puStack_190 = (undefined8 *)0x180003f95;
    iVar6 = fcn.180459890(0x48);
    *(int64_t *)iVar6 = iVar6;
    *(int64_t *)(iVar6 + 8) = iVar6;
    *(int64_t *)(iVar6 + 0x10) = iVar6;
    *(undefined2 *)(iVar6 + 0x18) = 0x101;
    piVar10 = &var_138h;
    *(int64_t *)0x18077e088 = iVar6;
    do {
        puStack_190 = (undefined8 *)0x180003fe3;
        puVar7 = (undefined4 *)func_0x00018003f0d0(0x18077e088, &var_158h, iVar6, piVar10);
        iVar5 = *(int64_t *)0x18077e088;
        uVar1 = *puVar7;
        uVar2 = puVar7[1];
        uVar3 = puVar7[2];
        uVar4 = puVar7[3];
        if (*(char *)(puVar7 + 4) == '\0') {
            if (*(int64_t *)0x18077e090 == 0x38e38e38e38e38e) {
                puStack_190 = (undefined8 *)0x1800040bf;
                func_0x000180013c00();
                uStack_1b0 = 0;
                uStack_1b8 = 0x38e38e38e38e38e;
                uStack_1c8 = 0x18077e088;
                var_1f0h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_310;
                var_2c0h._0_4_ = 0;
                var_2a8h = 8;
                var_2a0h = 0xf;
                var_2b8h = 0x797469746e656469;
                var_2b0h = 0;
                var_298h._0_4_ = 1;
                var_280h = 7;
                var_278h = 0xf;
                _var_290h = ZEXT716(0x6574616c666564);
                var_270h._0_4_ = 2;
                var_258h = 4;
                var_250h = 0xf;
                stack0xfffffffffffffd9d = SUB1611(ZEXT816(0), 5);
                var_268h._0_5_ = 0x62696c7a;
                var_248h._0_4_ = 3;
                var_230h = 4;
                var_228h = 0xf;
                stack0xfffffffffffffdc5 = SUB1611(ZEXT816(0), 5);
                var_240h._0_5_ = 0x70697a67;
                var_220h._0_4_ = 4;
                var_208h = 8;
                var_200h = 0xf;
                var_218h = 0x64656c6261736964;
                uStack_210 = 0;
                var_1e0h._0_4_ = uVar1;
                var_1e0h._4_4_ = uVar2;
                uStack_1d8 = uVar3;
                uStack_1d4 = uVar4;
                iStack_1c0 = iVar6;
                iStack_1a8 = unaff_RDI;
                piStack_1a0 = unaff_RSI;
                piStack_198 = piVar10;
                puStack_190 = &uStack_88;
                iVar6 = fcn.180459890(0x48);
                *(int64_t *)iVar6 = iVar6;
                *(int64_t *)(iVar6 + 8) = iVar6;
                *(int64_t *)(iVar6 + 0x10) = iVar6;
                *(undefined2 *)(iVar6 + 0x18) = 0x101;
                piVar10 = &var_2c0h;
                *(int64_t *)0x18077e098 = iVar6;
                do {
                    puVar7 = (undefined4 *)func_0x00018003f0d0(0x18077e098, &var_2e0h, iVar6, piVar10);
                    iVar5 = *(int64_t *)0x18077e098;
                    uVar1 = *puVar7;
                    uVar2 = puVar7[1];
                    uVar3 = puVar7[2];
                    uVar4 = puVar7[3];
                    if (*(char *)(puVar7 + 4) == '\0') {
                        if (*(int64_t *)0x18077e0a0 == 0x38e38e38e38e38e) {
                            func_0x000180013c00();
                            *(int64_t *)0x18077e0e0 = fcn.180459890(0x60);
                            *(int64_t *)*(int64_t *)0x18077e0e0 = *(int64_t *)0x18077e0e0;
                            *(int64_t *)(*(int64_t *)0x18077e0e0 + 8) = *(int64_t *)0x18077e0e0;
                            *(int64_t *)(*(int64_t *)0x18077e0e0 + 0x10) = *(int64_t *)0x18077e0e0;
                            *(undefined2 *)(*(int64_t *)0x18077e0e0 + 0x18) = 0x101;
                            iVar6 = fcn.180459be8(0x1804a2f80);
                            return (uint64_t)((iVar6 != 0) - 1);
                        }
                        var_2f0h = 0x18077e098;
                        var_2e8h = 0;
                        piVar9 = (int64_t *)fcn.180459890(0x48);
                        *(undefined4 *)(piVar9 + 4) = *(undefined4 *)piVar10;
                        var_2e8h = (int64_t)piVar9;
                        func_0x00018000b4d0(piVar9 + 5, piVar10 + 1);
                        *piVar9 = iVar5;
                        piVar9[1] = iVar5;
                        piVar9[2] = iVar5;
                        *(undefined2 *)(piVar9 + 3) = 0;
                        var_2e8h = 0;
                        var_2e0h._0_4_ = uVar1;
                        var_2e0h._4_4_ = uVar2;
                        uStack_2d8 = uVar3;
                        uStack_2d4 = uVar4;
                        func_0x0001800156d0(0x18077e098, &var_2e0h, piVar9);
                    }
                    piVar10 = piVar10 + 5;
                } while (piVar10 != &var_1f8h);
                fcn.180459d94(&var_2c0h, 0x28, 5, 0x1800131a0);
                fcn.180459c24(0x1804a2f00);
                uVar8 = fcn.180459870(var_1f0h ^ (uint64_t)auStack_310);
                return uVar8;
            }
            var_168h = 0x18077e088;
            var_160h = 0;
            puStack_190 = (undefined8 *)0x180004014;
            unaff_RSI = (int64_t *)fcn.180459890(0x48);
            var_160h = (int64_t)unaff_RSI;
            *(undefined4 *)(unaff_RSI + 4) = *(undefined4 *)piVar10;
            puStack_190 = (undefined8 *)0x18000402e;
            func_0x00018000b4d0(unaff_RSI + 5, piVar10 + 1);
            *unaff_RSI = iVar5;
            unaff_RSI[1] = iVar5;
            unaff_RSI[2] = iVar5;
            *(undefined2 *)(unaff_RSI + 3) = 0;
            var_160h = 0;
            puStack_190 = (undefined8 *)0x180004059;
            var_158h._0_4_ = uVar1;
            var_158h._4_4_ = uVar2;
            uStack_150 = uVar3;
            uStack_14c = uVar4;
            func_0x0001800156d0(0x18077e088, &var_158h, unaff_RSI);
            unaff_RDI = iVar5;
        }
        piVar10 = piVar10 + 5;
    } while (piVar10 != &var_70h);
    puStack_190 = (undefined8 *)0x180004086;
    fcn.180459d94(&var_138h, 0x28, 5, 0x1800131a0);
    puStack_190 = (undefined8 *)0x180004092;
    fcn.180459c24(0x1804a2e80);
    puStack_190 = (undefined8 *)0x18000409e;
    uVar8 = fcn.180459870(var_68h ^ (uint64_t)auStack_188);
    return uVar8;
}

// ============================================================
// Function: FUN_1800040c0
// Address: 0x1800040c0
// Size: 592 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_102h
// WARNING: [rz-ghidra] Detected overlap for variable var_101h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_28ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28ah
// WARNING: [rz-ghidra] Detected overlap for variable var_289h
// WARNING: [rz-ghidra] Detected overlap for variable var_264h
// WARNING: [rz-ghidra] Detected overlap for variable var_23ch

uint64_t fcn.180003e70(void)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *unaff_RSI;
    int64_t unaff_RDI;
    undefined auStack_310 [32];
    int64_t var_2f0h;
    int64_t var_2e8h;
    int64_t var_2e0h;
    undefined4 uStack_2d8;
    undefined4 uStack_2d4;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_268h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    undefined8 uStack_210;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1e0h;
    undefined4 uStack_1d8;
    undefined4 uStack_1d4;
    undefined8 uStack_1c8;
    int64_t iStack_1c0;
    undefined8 uStack_1b8;
    undefined8 uStack_1b0;
    int64_t iStack_1a8;
    int64_t *piStack_1a0;
    int64_t *piStack_198;
    undefined8 *puStack_190;
    undefined auStack_188 [32];
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    undefined4 uStack_150;
    undefined4 uStack_14c;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    undefined8 uStack_88;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    var_68h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_188;
    var_138h._0_4_ = 0;
    var_120h = 8;
    var_118h = 0xf;
    var_130h = 0x797469746e656469;
    var_128h = 0;
    var_110h._0_4_ = 1;
    var_f8h = 7;
    var_f0h = 0xf;
    _var_108h = ZEXT716(0x6574616c666564);
    var_e8h._0_4_ = 2;
    var_d0h = 4;
    var_c8h = 0xf;
    stack0xffffffffffffff25 = SUB1611(ZEXT816(0), 5);
    var_e0h._0_5_ = 0x62696c7a;
    var_c0h._0_4_ = 3;
    var_a8h = 4;
    var_a0h = 0xf;
    stack0xffffffffffffff4d = SUB1611(ZEXT816(0), 5);
    var_b8h._0_5_ = 0x70697a67;
    var_98h._0_4_ = 4;
    var_80h = 8;
    var_78h = 0xf;
    var_90h = 0x64656c6261736964;
    uStack_88 = 0;
    puStack_190 = (undefined8 *)0x180003f95;
    iVar6 = fcn.180459890(0x48);
    *(int64_t *)iVar6 = iVar6;
    *(int64_t *)(iVar6 + 8) = iVar6;
    *(int64_t *)(iVar6 + 0x10) = iVar6;
    *(undefined2 *)(iVar6 + 0x18) = 0x101;
    piVar10 = &var_138h;
    *(int64_t *)0x18077e088 = iVar6;
    do {
        puStack_190 = (undefined8 *)0x180003fe3;
        puVar7 = (undefined4 *)func_0x00018003f0d0(0x18077e088, &var_158h, iVar6, piVar10);
        iVar5 = *(int64_t *)0x18077e088;
        uVar1 = *puVar7;
        uVar2 = puVar7[1];
        uVar3 = puVar7[2];
        uVar4 = puVar7[3];
        if (*(char *)(puVar7 + 4) == '\0') {
            if (*(int64_t *)0x18077e090 == 0x38e38e38e38e38e) {
                puStack_190 = (undefined8 *)0x1800040bf;
                func_0x000180013c00();
                uStack_1b0 = 0;
                uStack_1b8 = 0x38e38e38e38e38e;
                uStack_1c8 = 0x18077e088;
                var_1f0h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_310;
                var_2c0h._0_4_ = 0;
                var_2a8h = 8;
                var_2a0h = 0xf;
                var_2b8h = 0x797469746e656469;
                var_2b0h = 0;
                var_298h._0_4_ = 1;
                var_280h = 7;
                var_278h = 0xf;
                _var_290h = ZEXT716(0x6574616c666564);
                var_270h._0_4_ = 2;
                var_258h = 4;
                var_250h = 0xf;
                stack0xfffffffffffffd9d = SUB1611(ZEXT816(0), 5);
                var_268h._0_5_ = 0x62696c7a;
                var_248h._0_4_ = 3;
                var_230h = 4;
                var_228h = 0xf;
                stack0xfffffffffffffdc5 = SUB1611(ZEXT816(0), 5);
                var_240h._0_5_ = 0x70697a67;
                var_220h._0_4_ = 4;
                var_208h = 8;
                var_200h = 0xf;
                var_218h = 0x64656c6261736964;
                uStack_210 = 0;
                var_1e0h._0_4_ = uVar1;
                var_1e0h._4_4_ = uVar2;
                uStack_1d8 = uVar3;
                uStack_1d4 = uVar4;
                iStack_1c0 = iVar6;
                iStack_1a8 = unaff_RDI;
                piStack_1a0 = unaff_RSI;
                piStack_198 = piVar10;
                puStack_190 = &uStack_88;
                iVar6 = fcn.180459890(0x48);
                *(int64_t *)iVar6 = iVar6;
                *(int64_t *)(iVar6 + 8) = iVar6;
                *(int64_t *)(iVar6 + 0x10) = iVar6;
                *(undefined2 *)(iVar6 + 0x18) = 0x101;
                piVar10 = &var_2c0h;
                *(int64_t *)0x18077e098 = iVar6;
                do {
                    puVar7 = (undefined4 *)func_0x00018003f0d0(0x18077e098, &var_2e0h, iVar6, piVar10);
                    iVar5 = *(int64_t *)0x18077e098;
                    uVar1 = *puVar7;
                    uVar2 = puVar7[1];
                    uVar3 = puVar7[2];
                    uVar4 = puVar7[3];
                    if (*(char *)(puVar7 + 4) == '\0') {
                        if (*(int64_t *)0x18077e0a0 == 0x38e38e38e38e38e) {
                            func_0x000180013c00();
                            *(int64_t *)0x18077e0e0 = fcn.180459890(0x60);
                            *(int64_t *)*(int64_t *)0x18077e0e0 = *(int64_t *)0x18077e0e0;
                            *(int64_t *)(*(int64_t *)0x18077e0e0 + 8) = *(int64_t *)0x18077e0e0;
                            *(int64_t *)(*(int64_t *)0x18077e0e0 + 0x10) = *(int64_t *)0x18077e0e0;
                            *(undefined2 *)(*(int64_t *)0x18077e0e0 + 0x18) = 0x101;
                            iVar6 = fcn.180459be8(0x1804a2f80);
                            return (uint64_t)((iVar6 != 0) - 1);
                        }
                        var_2f0h = 0x18077e098;
                        var_2e8h = 0;
                        piVar9 = (int64_t *)fcn.180459890(0x48);
                        *(undefined4 *)(piVar9 + 4) = *(undefined4 *)piVar10;
                        var_2e8h = (int64_t)piVar9;
                        func_0x00018000b4d0(piVar9 + 5, piVar10 + 1);
                        *piVar9 = iVar5;
                        piVar9[1] = iVar5;
                        piVar9[2] = iVar5;
                        *(undefined2 *)(piVar9 + 3) = 0;
                        var_2e8h = 0;
                        var_2e0h._0_4_ = uVar1;
                        var_2e0h._4_4_ = uVar2;
                        uStack_2d8 = uVar3;
                        uStack_2d4 = uVar4;
                        func_0x0001800156d0(0x18077e098, &var_2e0h, piVar9);
                    }
                    piVar10 = piVar10 + 5;
                } while (piVar10 != &var_1f8h);
                fcn.180459d94(&var_2c0h, 0x28, 5, 0x1800131a0);
                fcn.180459c24(0x1804a2f00);
                uVar8 = fcn.180459870(var_1f0h ^ (uint64_t)auStack_310);
                return uVar8;
            }
            var_168h = 0x18077e088;
            var_160h = 0;
            puStack_190 = (undefined8 *)0x180004014;
            unaff_RSI = (int64_t *)fcn.180459890(0x48);
            var_160h = (int64_t)unaff_RSI;
            *(undefined4 *)(unaff_RSI + 4) = *(undefined4 *)piVar10;
            puStack_190 = (undefined8 *)0x18000402e;
            func_0x00018000b4d0(unaff_RSI + 5, piVar10 + 1);
            *unaff_RSI = iVar5;
            unaff_RSI[1] = iVar5;
            unaff_RSI[2] = iVar5;
            *(undefined2 *)(unaff_RSI + 3) = 0;
            var_160h = 0;
            puStack_190 = (undefined8 *)0x180004059;
            var_158h._0_4_ = uVar1;
            var_158h._4_4_ = uVar2;
            uStack_150 = uVar3;
            uStack_14c = uVar4;
            func_0x0001800156d0(0x18077e088, &var_158h, unaff_RSI);
            unaff_RDI = iVar5;
        }
        piVar10 = piVar10 + 5;
    } while (piVar10 != &var_70h);
    puStack_190 = (undefined8 *)0x180004086;
    fcn.180459d94(&var_138h, 0x28, 5, 0x1800131a0);
    puStack_190 = (undefined8 *)0x180004092;
    fcn.180459c24(0x1804a2e80);
    puStack_190 = (undefined8 *)0x18000409e;
    uVar8 = fcn.180459870(var_68h ^ (uint64_t)auStack_188);
    return uVar8;
}

// ============================================================
// Function: FUN_180004310
// Address: 0x180004310
// Size: 54 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_102h
// WARNING: [rz-ghidra] Detected overlap for variable var_101h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_28ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28ah
// WARNING: [rz-ghidra] Detected overlap for variable var_289h
// WARNING: [rz-ghidra] Detected overlap for variable var_264h
// WARNING: [rz-ghidra] Detected overlap for variable var_23ch

uint64_t fcn.180003e70(void)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *unaff_RSI;
    int64_t unaff_RDI;
    undefined auStack_310 [32];
    int64_t var_2f0h;
    int64_t var_2e8h;
    int64_t var_2e0h;
    undefined4 uStack_2d8;
    undefined4 uStack_2d4;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_268h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    undefined8 uStack_210;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1e0h;
    undefined4 uStack_1d8;
    undefined4 uStack_1d4;
    undefined8 uStack_1c8;
    int64_t iStack_1c0;
    undefined8 uStack_1b8;
    undefined8 uStack_1b0;
    int64_t iStack_1a8;
    int64_t *piStack_1a0;
    int64_t *piStack_198;
    undefined8 *puStack_190;
    undefined auStack_188 [32];
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    undefined4 uStack_150;
    undefined4 uStack_14c;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    undefined8 uStack_88;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    var_68h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_188;
    var_138h._0_4_ = 0;
    var_120h = 8;
    var_118h = 0xf;
    var_130h = 0x797469746e656469;
    var_128h = 0;
    var_110h._0_4_ = 1;
    var_f8h = 7;
    var_f0h = 0xf;
    _var_108h = ZEXT716(0x6574616c666564);
    var_e8h._0_4_ = 2;
    var_d0h = 4;
    var_c8h = 0xf;
    stack0xffffffffffffff25 = SUB1611(ZEXT816(0), 5);
    var_e0h._0_5_ = 0x62696c7a;
    var_c0h._0_4_ = 3;
    var_a8h = 4;
    var_a0h = 0xf;
    stack0xffffffffffffff4d = SUB1611(ZEXT816(0), 5);
    var_b8h._0_5_ = 0x70697a67;
    var_98h._0_4_ = 4;
    var_80h = 8;
    var_78h = 0xf;
    var_90h = 0x64656c6261736964;
    uStack_88 = 0;
    puStack_190 = (undefined8 *)0x180003f95;
    iVar6 = fcn.180459890(0x48);
    *(int64_t *)iVar6 = iVar6;
    *(int64_t *)(iVar6 + 8) = iVar6;
    *(int64_t *)(iVar6 + 0x10) = iVar6;
    *(undefined2 *)(iVar6 + 0x18) = 0x101;
    piVar10 = &var_138h;
    *(int64_t *)0x18077e088 = iVar6;
    do {
        puStack_190 = (undefined8 *)0x180003fe3;
        puVar7 = (undefined4 *)func_0x00018003f0d0(0x18077e088, &var_158h, iVar6, piVar10);
        iVar5 = *(int64_t *)0x18077e088;
        uVar1 = *puVar7;
        uVar2 = puVar7[1];
        uVar3 = puVar7[2];
        uVar4 = puVar7[3];
        if (*(char *)(puVar7 + 4) == '\0') {
            if (*(int64_t *)0x18077e090 == 0x38e38e38e38e38e) {
                puStack_190 = (undefined8 *)0x1800040bf;
                func_0x000180013c00();
                uStack_1b0 = 0;
                uStack_1b8 = 0x38e38e38e38e38e;
                uStack_1c8 = 0x18077e088;
                var_1f0h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_310;
                var_2c0h._0_4_ = 0;
                var_2a8h = 8;
                var_2a0h = 0xf;
                var_2b8h = 0x797469746e656469;
                var_2b0h = 0;
                var_298h._0_4_ = 1;
                var_280h = 7;
                var_278h = 0xf;
                _var_290h = ZEXT716(0x6574616c666564);
                var_270h._0_4_ = 2;
                var_258h = 4;
                var_250h = 0xf;
                stack0xfffffffffffffd9d = SUB1611(ZEXT816(0), 5);
                var_268h._0_5_ = 0x62696c7a;
                var_248h._0_4_ = 3;
                var_230h = 4;
                var_228h = 0xf;
                stack0xfffffffffffffdc5 = SUB1611(ZEXT816(0), 5);
                var_240h._0_5_ = 0x70697a67;
                var_220h._0_4_ = 4;
                var_208h = 8;
                var_200h = 0xf;
                var_218h = 0x64656c6261736964;
                uStack_210 = 0;
                var_1e0h._0_4_ = uVar1;
                var_1e0h._4_4_ = uVar2;
                uStack_1d8 = uVar3;
                uStack_1d4 = uVar4;
                iStack_1c0 = iVar6;
                iStack_1a8 = unaff_RDI;
                piStack_1a0 = unaff_RSI;
                piStack_198 = piVar10;
                puStack_190 = &uStack_88;
                iVar6 = fcn.180459890(0x48);
                *(int64_t *)iVar6 = iVar6;
                *(int64_t *)(iVar6 + 8) = iVar6;
                *(int64_t *)(iVar6 + 0x10) = iVar6;
                *(undefined2 *)(iVar6 + 0x18) = 0x101;
                piVar10 = &var_2c0h;
                *(int64_t *)0x18077e098 = iVar6;
                do {
                    puVar7 = (undefined4 *)func_0x00018003f0d0(0x18077e098, &var_2e0h, iVar6, piVar10);
                    iVar5 = *(int64_t *)0x18077e098;
                    uVar1 = *puVar7;
                    uVar2 = puVar7[1];
                    uVar3 = puVar7[2];
                    uVar4 = puVar7[3];
                    if (*(char *)(puVar7 + 4) == '\0') {
                        if (*(int64_t *)0x18077e0a0 == 0x38e38e38e38e38e) {
                            func_0x000180013c00();
                            *(int64_t *)0x18077e0e0 = fcn.180459890(0x60);
                            *(int64_t *)*(int64_t *)0x18077e0e0 = *(int64_t *)0x18077e0e0;
                            *(int64_t *)(*(int64_t *)0x18077e0e0 + 8) = *(int64_t *)0x18077e0e0;
                            *(int64_t *)(*(int64_t *)0x18077e0e0 + 0x10) = *(int64_t *)0x18077e0e0;
                            *(undefined2 *)(*(int64_t *)0x18077e0e0 + 0x18) = 0x101;
                            iVar6 = fcn.180459be8(0x1804a2f80);
                            return (uint64_t)((iVar6 != 0) - 1);
                        }
                        var_2f0h = 0x18077e098;
                        var_2e8h = 0;
                        piVar9 = (int64_t *)fcn.180459890(0x48);
                        *(undefined4 *)(piVar9 + 4) = *(undefined4 *)piVar10;
                        var_2e8h = (int64_t)piVar9;
                        func_0x00018000b4d0(piVar9 + 5, piVar10 + 1);
                        *piVar9 = iVar5;
                        piVar9[1] = iVar5;
                        piVar9[2] = iVar5;
                        *(undefined2 *)(piVar9 + 3) = 0;
                        var_2e8h = 0;
                        var_2e0h._0_4_ = uVar1;
                        var_2e0h._4_4_ = uVar2;
                        uStack_2d8 = uVar3;
                        uStack_2d4 = uVar4;
                        func_0x0001800156d0(0x18077e098, &var_2e0h, piVar9);
                    }
                    piVar10 = piVar10 + 5;
                } while (piVar10 != &var_1f8h);
                fcn.180459d94(&var_2c0h, 0x28, 5, 0x1800131a0);
                fcn.180459c24(0x1804a2f00);
                uVar8 = fcn.180459870(var_1f0h ^ (uint64_t)auStack_310);
                return uVar8;
            }
            var_168h = 0x18077e088;
            var_160h = 0;
            puStack_190 = (undefined8 *)0x180004014;
            unaff_RSI = (int64_t *)fcn.180459890(0x48);
            var_160h = (int64_t)unaff_RSI;
            *(undefined4 *)(unaff_RSI + 4) = *(undefined4 *)piVar10;
            puStack_190 = (undefined8 *)0x18000402e;
            func_0x00018000b4d0(unaff_RSI + 5, piVar10 + 1);
            *unaff_RSI = iVar5;
            unaff_RSI[1] = iVar5;
            unaff_RSI[2] = iVar5;
            *(undefined2 *)(unaff_RSI + 3) = 0;
            var_160h = 0;
            puStack_190 = (undefined8 *)0x180004059;
            var_158h._0_4_ = uVar1;
            var_158h._4_4_ = uVar2;
            uStack_150 = uVar3;
            uStack_14c = uVar4;
            func_0x0001800156d0(0x18077e088, &var_158h, unaff_RSI);
            unaff_RDI = iVar5;
        }
        piVar10 = piVar10 + 5;
    } while (piVar10 != &var_70h);
    puStack_190 = (undefined8 *)0x180004086;
    fcn.180459d94(&var_138h, 0x28, 5, 0x1800131a0);
    puStack_190 = (undefined8 *)0x180004092;
    fcn.180459c24(0x1804a2e80);
    puStack_190 = (undefined8 *)0x18000409e;
    uVar8 = fcn.180459870(var_68h ^ (uint64_t)auStack_188);
    return uVar8;
}

// ============================================================
// Function: FUN_180004360
// Address: 0x180004360
// Size: 76 bytes
// ============================================================
int32_t fcn.180004360(void)
{
    int64_t iVar1;
    
    *(int64_t *)0x18069c180 = fcn.180459890(0x60);
    *(int64_t *)*(int64_t *)0x18069c180 = *(int64_t *)0x18069c180;
    *(int64_t *)(*(int64_t *)0x18069c180 + 8) = *(int64_t *)0x18069c180;
    *(int64_t *)(*(int64_t *)0x18069c180 + 0x10) = *(int64_t *)0x18069c180;
    *(undefined2 *)(*(int64_t *)0x18069c180 + 0x18) = 0x101;
    *(undefined4 *)0x18069c170 = 0;
    *(undefined2 *)0x18069c174 = 0;
    *(undefined8 *)0x18069c178 = 0;
    iVar1 = fcn.180459be8(0x1804a3030);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_1800043b0
// Address: 0x1800043b0
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1800043b0(void)
{
    int64_t iVar1;
    int64_t var_18h;
    
    func_0x000180459e74(0x18077e110, 4, 0x10, 0x180182e80, 0x180182ea0);
    iVar1 = fcn.180459be8(0x1804a30b0);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_1800043f0
// Address: 0x1800043f0
// Size: 54 bytes
// ============================================================
int32_t fcn.1800043f0(void)
{
    int64_t iVar1;
    
    *(int64_t *)0x18077e1f0 = fcn.180459890(0x60);
    *(int64_t *)*(int64_t *)0x18077e1f0 = *(int64_t *)0x18077e1f0;
    *(int64_t *)(*(int64_t *)0x18077e1f0 + 8) = *(int64_t *)0x18077e1f0;
    *(int64_t *)(*(int64_t *)0x18077e1f0 + 0x10) = *(int64_t *)0x18077e1f0;
    *(undefined2 *)(*(int64_t *)0x18077e1f0 + 0x18) = 0x101;
    iVar1 = fcn.180459be8(0x1804a30d0);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_18000443c
// Address: 0x18000443c
// Size: 32 bytes
// ============================================================
int32_t fcn.18000443c(void)
{
    int64_t iVar1;
    
    func_0x0001804556d0(0x180780de0);
    iVar1 = fcn.180459be8(0x1804a317c);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_180004474
// Address: 0x180004474
// Size: 78 bytes
// ============================================================
int32_t fcn.180004474(void)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)0x1806a38e8 = 0x1804a5370;
    func_0x000180458ec8(0x1806a3850, 0x1806a38e8, 0x180698860);
    iVar1 = fcn.180459be8(0x1804a3220);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_1800044c4
// Address: 0x1800044c4
// Size: 78 bytes
// ============================================================
int32_t fcn.1800044c4(void)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)0x1806a3828 = 0x1805a07e8;
    func_0x000180458ec8(0x1806a3790, 0x1806a3828, 0x180698a30);
    iVar1 = fcn.180459be8(0x1804a3224);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_180004514
// Address: 0x180004514
// Size: 48 bytes
// ============================================================
int32_t fcn.180004514(void)
{
    int64_t iVar1;
    
    func_0x00018000e040(0x180781030, 0x1807810a0, 0, 1);
    iVar1 = fcn.180459be8(0x1804a3228);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_180004544
// Address: 0x180004544
// Size: 80 bytes
// ============================================================
int32_t fcn.180004544(void)
{
    undefined8 uVar1;
    int64_t iVar2;
    
    uVar1 = func_0x0001804605f8(2);
    func_0x00018000fd90(0x1807810a0);
    *(undefined8 *)0x1807810a0 = 0x1805a0888;
    func_0x00018000df00(0x1807810a0, uVar1, 0);
    iVar2 = fcn.180459be8(0x1804a327c);
    return (iVar2 != 0) - 1;
}

// ============================================================
// Function: FUN_1800045cc
// Address: 0x1800045cc
// Size: 32 bytes
// ============================================================
int32_t fcn.1800045cc(void)
{
    int64_t iVar1;
    
    func_0x0001804556d0(0x180781020);
    iVar1 = fcn.180459be8(0x1804a3288);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_1800045f8
// Address: 0x1800045f8
// Size: 32 bytes
// ============================================================
int32_t fcn.1800045f8(void)
{
    int64_t iVar1;
    
    func_0x0001804556d0(0x180781180);
    iVar1 = fcn.180459be8(0x1804a32d4);
    return (iVar1 != 0) - 1;
}

// ============================================================
// Function: FUN_180004620
// Address: 0x180004620
// Size: 50 bytes
// ============================================================
int64_t fcn.180004620(int64_t arg1, int64_t arg2)
{
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    return arg1;
}

// ============================================================
// Function: FUN_1800046a0
// Address: 0x1800046a0
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800046a0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a5358;
    fcn.18045b56c(arg1 + 8);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x18);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180004720
// Address: 0x180004720
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180004720(void)
{
    code *pcVar1;
    int64_t var_28h;
    
    fcn.1800046f0(&var_28h);
    fcn.18045bae0(var_28h);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180004740
// Address: 0x180004740
// Size: 60 bytes
// ============================================================
int64_t fcn.180004740(int64_t arg1, int64_t arg2)
{
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a5388;
    return arg1;
}

// ============================================================
// Function: FUN_180004780
// Address: 0x180004780
// Size: 60 bytes
// ============================================================
int64_t fcn.180004780(int64_t arg1, int64_t arg2)
{
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a5370;
    return arg1;
}

// ============================================================
// Function: FUN_1800047c0
// Address: 0x1800047c0
// Size: 17 bytes
// ============================================================
void fcn.1800047c0(void)
{
    code *pcVar1;
    
    fcn.1804546d4(0x1805aad58);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800047e0
// Address: 0x1800047e0
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800047e0(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int64_t var_8h;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    uVar1 = fcn.180498cd0(arg2);
    fcn.180004830(arg1, arg2, uVar1);
    return arg1;
}

// ============================================================
// Function: FUN_180004830
// Address: 0x180004830
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180004830(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    int64_t var_8h;
    undefined8 uStack_50;
    undefined auStack_48 [40];
    
    puVar5 = auStack_48;
    if (0x7fffffffffffffff < (uint64_t)arg3) {
        fcn.1800047c0();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uint64_t)arg3 < 0x10) {
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(undefined8 *)(arg1 + 0x18) = 0xf;
        fcn.180498030();
        *(undefined *)(arg3 + arg1) = 0;
        return;
    }
    uVar2 = arg3 | 0xf;
    if (uVar2 < 0x8000000000000000) goto code_r0x0001800048ab;
    uVar3 = 0x8000000000000027;
    puVar5 = auStack_48;
    uVar2 = 0x7fffffffffffffff;
    do {
        *(undefined8 *)(puVar5 + -8) = 0x18000489f;
        iVar4 = fcn.180459890(uVar3);
        if (iVar4 != 0) {
            uVar3 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar3 - 8) = iVar4;
code_r0x0001800048f1:
            *(uint64_t *)arg1 = uVar3;
            *(int64_t *)(arg1 + 0x10) = arg3;
            *(uint64_t *)(arg1 + 0x18) = uVar2;
            *(undefined8 *)(puVar5 + -8) = 0x18000490a;
            fcn.180498030(uVar3, arg2, arg3);
            *(undefined *)(uVar3 + arg3) = 0;
            return;
        }
        pcVar1 = (code *)swi(0x29);
        uVar2 = (*pcVar1)(5);
        puVar5 = puVar5 + 8;
code_r0x0001800048ab:
        if (uVar2 < 0x16) {
            uVar2 = 0x16;
        }
        if (uVar2 == 0xffffffffffffffff) {
            uVar3 = 0;
            goto code_r0x0001800048f1;
        }
        if (uVar2 + 1 < 0x1000) {
            *(undefined8 *)(puVar5 + -8) = 0x1800048ee;
            uVar3 = fcn.180459890();
            goto code_r0x0001800048f1;
        }
        uVar3 = uVar2 + 0x28;
        if (uVar3 <= uVar2 + 1) {
            *(undefined8 *)(puVar5 + -8) = 0x180004928;
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_18000487f
// Address: 0x18000487f
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180004830(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    int64_t var_8h;
    undefined8 uStack_50;
    undefined auStack_48 [40];
    
    puVar5 = auStack_48;
    if (0x7fffffffffffffff < (uint64_t)arg3) {
        fcn.1800047c0();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uint64_t)arg3 < 0x10) {
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(undefined8 *)(arg1 + 0x18) = 0xf;
        fcn.180498030();
        *(undefined *)(arg3 + arg1) = 0;
        return;
    }
    uVar2 = arg3 | 0xf;
    if (uVar2 < 0x8000000000000000) goto code_r0x0001800048ab;
    uVar3 = 0x8000000000000027;
    puVar5 = auStack_48;
    uVar2 = 0x7fffffffffffffff;
    do {
        *(undefined8 *)(puVar5 + -8) = 0x18000489f;
        iVar4 = fcn.180459890(uVar3);
        if (iVar4 != 0) {
            uVar3 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar3 - 8) = iVar4;
code_r0x0001800048f1:
            *(uint64_t *)arg1 = uVar3;
            *(int64_t *)(arg1 + 0x10) = arg3;
            *(uint64_t *)(arg1 + 0x18) = uVar2;
            *(undefined8 *)(puVar5 + -8) = 0x18000490a;
            fcn.180498030(uVar3, arg2, arg3);
            *(undefined *)(uVar3 + arg3) = 0;
            return;
        }
        pcVar1 = (code *)swi(0x29);
        uVar2 = (*pcVar1)(5);
        puVar5 = puVar5 + 8;
code_r0x0001800048ab:
        if (uVar2 < 0x16) {
            uVar2 = 0x16;
        }
        if (uVar2 == 0xffffffffffffffff) {
            uVar3 = 0;
            goto code_r0x0001800048f1;
        }
        if (uVar2 + 1 < 0x1000) {
            *(undefined8 *)(puVar5 + -8) = 0x1800048ee;
            uVar3 = fcn.180459890();
            goto code_r0x0001800048f1;
        }
        uVar3 = uVar2 + 0x28;
        if (uVar3 <= uVar2 + 1) {
            *(undefined8 *)(puVar5 + -8) = 0x180004928;
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_18000491d
// Address: 0x18000491d
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180004830(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    int64_t var_8h;
    undefined8 uStack_50;
    undefined auStack_48 [40];
    
    puVar5 = auStack_48;
    if (0x7fffffffffffffff < (uint64_t)arg3) {
        fcn.1800047c0();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uint64_t)arg3 < 0x10) {
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(undefined8 *)(arg1 + 0x18) = 0xf;
        fcn.180498030();
        *(undefined *)(arg3 + arg1) = 0;
        return;
    }
    uVar2 = arg3 | 0xf;
    if (uVar2 < 0x8000000000000000) goto code_r0x0001800048ab;
    uVar3 = 0x8000000000000027;
    puVar5 = auStack_48;
    uVar2 = 0x7fffffffffffffff;
    do {
        *(undefined8 *)(puVar5 + -8) = 0x18000489f;
        iVar4 = fcn.180459890(uVar3);
        if (iVar4 != 0) {
            uVar3 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar3 - 8) = iVar4;
code_r0x0001800048f1:
            *(uint64_t *)arg1 = uVar3;
            *(int64_t *)(arg1 + 0x10) = arg3;
            *(uint64_t *)(arg1 + 0x18) = uVar2;
            *(undefined8 *)(puVar5 + -8) = 0x18000490a;
            fcn.180498030(uVar3, arg2, arg3);
            *(undefined *)(uVar3 + arg3) = 0;
            return;
        }
        pcVar1 = (code *)swi(0x29);
        uVar2 = (*pcVar1)(5);
        puVar5 = puVar5 + 8;
code_r0x0001800048ab:
        if (uVar2 < 0x16) {
            uVar2 = 0x16;
        }
        if (uVar2 == 0xffffffffffffffff) {
            uVar3 = 0;
            goto code_r0x0001800048f1;
        }
        if (uVar2 + 1 < 0x1000) {
            *(undefined8 *)(puVar5 + -8) = 0x1800048ee;
            uVar3 = fcn.180459890();
            goto code_r0x0001800048f1;
        }
        uVar3 = uVar2 + 0x28;
        if (uVar3 <= uVar2 + 1) {
            *(undefined8 *)(puVar5 + -8) = 0x180004928;
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180004923
// Address: 0x180004923
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180004830(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    int64_t var_8h;
    undefined8 uStack_50;
    undefined auStack_48 [40];
    
    puVar5 = auStack_48;
    if (0x7fffffffffffffff < (uint64_t)arg3) {
        fcn.1800047c0();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if ((uint64_t)arg3 < 0x10) {
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(undefined8 *)(arg1 + 0x18) = 0xf;
        fcn.180498030();
        *(undefined *)(arg3 + arg1) = 0;
        return;
    }
    uVar2 = arg3 | 0xf;
    if (uVar2 < 0x8000000000000000) goto code_r0x0001800048ab;
    uVar3 = 0x8000000000000027;
    puVar5 = auStack_48;
    uVar2 = 0x7fffffffffffffff;
    do {
        *(undefined8 *)(puVar5 + -8) = 0x18000489f;
        iVar4 = fcn.180459890(uVar3);
        if (iVar4 != 0) {
            uVar3 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar3 - 8) = iVar4;
code_r0x0001800048f1:
            *(uint64_t *)arg1 = uVar3;
            *(int64_t *)(arg1 + 0x10) = arg3;
            *(uint64_t *)(arg1 + 0x18) = uVar2;
            *(undefined8 *)(puVar5 + -8) = 0x18000490a;
            fcn.180498030(uVar3, arg2, arg3);
            *(undefined *)(uVar3 + arg3) = 0;
            return;
        }
        pcVar1 = (code *)swi(0x29);
        uVar2 = (*pcVar1)(5);
        puVar5 = puVar5 + 8;
code_r0x0001800048ab:
        if (uVar2 < 0x16) {
            uVar2 = 0x16;
        }
        if (uVar2 == 0xffffffffffffffff) {
            uVar3 = 0;
            goto code_r0x0001800048f1;
        }
        if (uVar2 + 1 < 0x1000) {
            *(undefined8 *)(puVar5 + -8) = 0x1800048ee;
            uVar3 = fcn.180459890();
            goto code_r0x0001800048f1;
        }
        uVar3 = uVar2 + 0x28;
        if (uVar3 <= uVar2 + 1) {
            *(undefined8 *)(puVar5 + -8) = 0x180004928;
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180004930
// Address: 0x180004930
// Size: 111 bytes
// ============================================================
uint64_t fcn.180004930(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    
    *(int64_t *)arg2 = *(int64_t *)arg2 + 1;
    uVar3 = *(uint64_t *)arg2;
    if (*(int64_t *)arg2 == 0) {
        *(int64_t *)arg2 = *(int64_t *)arg2 + -1;
        return 0;
    }
    if (0xfff < uVar3) {
        if (uVar3 < uVar3 + 0x27) {
            iVar2 = fcn.180459890(uVar3 + 0x27);
            iVar4 = iVar2;
            if (iVar2 == 0) {
                iVar4 = 5;
                pcVar1 = (code *)swi(0x29);
                iVar2 = (*pcVar1)();
            }
            uVar3 = iVar2 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar3 - 8) = iVar4;
            *(int64_t *)arg2 = *(int64_t *)arg2 + -1;
            return uVar3;
        }
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    uVar3 = fcn.180459890();
    *(int64_t *)arg2 = *(int64_t *)arg2 + -1;
    return uVar3;
}

// ============================================================
// Function: FUN_1800049a0
// Address: 0x1800049a0
// Size: 57 bytes
// ============================================================
int64_t fcn.1800049a0(int64_t arg1)
{
    undefined4 *puVar1;
    
    puVar1 = (undefined4 *)fcn.180459890();
    *puVar1 = 1;
    puVar1[1] = 2;
    *(undefined8 *)(puVar1 + 2) = 0;
    *(undefined8 *)(puVar1 + 4) = 0;
    puVar1[6] = 0;
    *(undefined4 **)arg1 = puVar1;
    return arg1;
}

// ============================================================
// Function: FUN_180004a20
// Address: 0x180004a20
// Size: 21 bytes
// ============================================================
void fcn.180004a20(int64_t arg1)
{
    code *pcVar1;
    
    if (*(int32_t *)(arg1 + 8) == 0) {
        return;
    }
    fcn.18045f7d4();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180004a40
// Address: 0x180004a40
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180004a40(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t var_8h;
    int64_t var_18h;
    undefined4 uStack_10;
    undefined4 uStack_c;
    
    if (*(int32_t *)(arg1 + 8) == 0) {
        fcn.1804542e8(1);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    iVar3 = *(int32_t *)(arg1 + 8);
    iVar2 = sub.KERNEL32.dll_GetCurrentThreadId();
    if (iVar3 != iVar2) {
        var_18h._0_4_ = *(undefined4 *)arg1;
        var_18h._4_4_ = *(undefined4 *)(arg1 + 4);
        uStack_10 = *(undefined4 *)(arg1 + 8);
        uStack_c = *(undefined4 *)(arg1 + 0xc);
        iVar3 = fcn.180454a30(&var_18h, 0);
        if (iVar3 == 0) {
            *(undefined (*) [16])arg1 = ZEXT816(0);
            return;
        }
        fcn.1804542e8(2);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    fcn.1804542e8(5);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180004a4f
// Address: 0x180004a4f
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180004a40(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t var_8h;
    int64_t var_18h;
    undefined4 uStack_10;
    undefined4 uStack_c;
    
    if (*(int32_t *)(arg1 + 8) == 0) {
        fcn.1804542e8(1);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    iVar3 = *(int32_t *)(arg1 + 8);
    iVar2 = sub.KERNEL32.dll_GetCurrentThreadId();
    if (iVar3 != iVar2) {
        var_18h._0_4_ = *(undefined4 *)arg1;
        var_18h._4_4_ = *(undefined4 *)(arg1 + 4);
        uStack_10 = *(undefined4 *)(arg1 + 8);
        uStack_c = *(undefined4 *)(arg1 + 0xc);
        iVar3 = fcn.180454a30(&var_18h, 0);
        if (iVar3 == 0) {
            *(undefined (*) [16])arg1 = ZEXT816(0);
            return;
        }
        fcn.1804542e8(2);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    fcn.1804542e8(5);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180004a65
// Address: 0x180004a65
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180004a40(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t var_8h;
    int64_t var_18h;
    undefined4 uStack_10;
    undefined4 uStack_c;
    
    if (*(int32_t *)(arg1 + 8) == 0) {
        fcn.1804542e8(1);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    iVar3 = *(int32_t *)(arg1 + 8);
    iVar2 = sub.KERNEL32.dll_GetCurrentThreadId();
    if (iVar3 != iVar2) {
        var_18h._0_4_ = *(undefined4 *)arg1;
        var_18h._4_4_ = *(undefined4 *)(arg1 + 4);
        uStack_10 = *(undefined4 *)(arg1 + 8);
        uStack_c = *(undefined4 *)(arg1 + 0xc);
        iVar3 = fcn.180454a30(&var_18h, 0);
        if (iVar3 == 0) {
            *(undefined (*) [16])arg1 = ZEXT816(0);
            return;
        }
        fcn.1804542e8(2);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    fcn.1804542e8(5);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180004ab0
// Address: 0x180004ab0
// Size: 399 bytes
// ============================================================
void fcn.180004ab0(int64_t arg1)
{
    uint32_t *puVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    code *pcVar9;
    undefined4 uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined *puVar14;
    undefined *puVar15;
    uint64_t uVar16;
    bool bVar17;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_60;
    undefined auStack_58 [40];
    
    puVar15 = auStack_58;
    puVar14 = auStack_58;
    if (*(int32_t *)(arg1 + 8) != 0) {
        iVar6 = *(int64_t *)(arg1 + 0x10);
        puVar15 = auStack_58;
        if (iVar6 != 0) {
            uVar11 = *(uint32_t *)(iVar6 + 4);
            do {
                LOCK();
                uVar2 = *(uint32_t *)(iVar6 + 4);
                bVar17 = uVar11 == uVar2;
                if (bVar17) {
                    *(uint32_t *)(iVar6 + 4) = uVar11 | 1;
                    uVar2 = uVar11;
                }
                uVar11 = uVar2;
                UNLOCK();
            } while (!bVar17);
            puVar15 = auStack_58;
            if ((uVar11 & 1) == 0) {
                uVar10 = sub.KERNEL32.dll_GetCurrentThreadId();
                *(undefined4 *)(iVar6 + 0x18) = uVar10;
code_r0x000180004b00:
                do {
                    uVar12 = *(uint64_t *)(iVar6 + 8);
                    do {
                        while (uVar16 = uVar12, uVar11 = (uint32_t)uVar16 & 3, (uVar16 & 3) == 0) {
                            LOCK();
                            uVar12 = *(uint64_t *)(iVar6 + 8);
                            bVar17 = uVar16 == uVar12;
                            if (bVar17) {
                                *(uint64_t *)(iVar6 + 8) = uVar16 | 1;
                                uVar12 = uVar16;
                            }
                            UNLOCK();
                            if (bVar17) {
                                *(uint64_t *)(iVar6 + 0x10) = uVar16;
                                *(undefined8 *)(puVar14 + -8) = 0x180004b9f;
                                func_0x0001804541b0();
                                if (uVar16 == 0) {
                                    LOCK();
                                    uVar5 = *(undefined8 *)(iVar6 + 8);
                                    *(undefined8 *)(iVar6 + 8) = 0;
                                    UNLOCK();
                                    puVar15 = puVar14;
                                    if (((uint8_t)uVar5 & 3) == 2) {
                                        *(undefined8 *)(puVar14 + -8) = 0x180004be9;
                                        func_0x0001804541b0(iVar6 + 8);
                                    }
                                    goto code_r0x000180004bea;
                                }
                                iVar7 = *(int64_t *)(uVar16 + 8);
                                *(undefined8 *)(uVar16 + 8) = 0;
                                if (iVar7 != 0) {
                                    *(undefined8 *)(iVar7 + 0x10) = 0;
                                }
                                LOCK();
                                iVar4 = *(int64_t *)(iVar6 + 8);
                                *(int64_t *)(iVar6 + 8) = iVar7;
                                UNLOCK();
                                if (((uint8_t)iVar4 & 3) == 2) {
                                    *(undefined8 *)(puVar14 + -8) = 0x180004bc8;
                                    func_0x0001804541b0(iVar6 + 8);
                                }
                                pcVar9 = *(code **)(uVar16 + 0x18);
                                *(undefined8 *)(puVar14 + -8) = 0x180004bce;
                                (*pcVar9)(uVar16);
                                goto code_r0x000180004b00;
                            }
                        }
                        if (uVar11 != 1) {
                            uVar13 = uVar16;
                            if (uVar11 == 2) break;
                            pcVar9 = (code *)swi(0x29);
                            (*pcVar9)(5);
                            puVar14 = puVar14 + 8;
                        }
                        uVar13 = uVar16 & 0xfffffffffffffffe | 2;
                        LOCK();
                        uVar12 = *(uint64_t *)(iVar6 + 8);
                        bVar17 = uVar16 == uVar12;
                        if (bVar17) {
                            *(uint64_t *)(iVar6 + 8) = uVar13;
                            uVar12 = uVar16;
                        }
                        UNLOCK();
                    } while (!bVar17);
                    *(uint64_t *)(puVar14 + 0x60) = uVar13;
                    if (*(int64_t *)(puVar14 + 0x60) == *(int64_t *)(iVar6 + 8)) {
                        do {
                            *(undefined8 *)(puVar14 + -8) = 0x180004b6a;
                            func_0x0001804541b8(iVar6 + 8, puVar14 + 0x60, 8, 0xffffffff);
                        } while (*(int64_t *)(puVar14 + 0x60) == *(int64_t *)(iVar6 + 8));
                    }
                } while( true );
            }
        }
code_r0x000180004bea:
        *(undefined8 *)(puVar15 + -8) = 0x180004bf2;
        fcn.180004a40(arg1);
    }
    piVar8 = *(int32_t **)(arg1 + 0x10);
    if (piVar8 != (int32_t *)0x0) {
        LOCK();
        puVar1 = (uint32_t *)(piVar8 + 1);
        uVar11 = *puVar1;
        *puVar1 = *puVar1 - 2;
        UNLOCK();
        if ((uVar11 & 0xfffffffe) == 2) {
            LOCK();
            iVar3 = *piVar8;
            *piVar8 = *piVar8 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                *(undefined8 *)(puVar15 + -8) = 0x180004c26;
                fcn.180459c3c(piVar8, 0x20);
            }
        }
    }
    if (*(int32_t *)(arg1 + 8) != 0) {
        *(undefined8 *)(puVar15 + -8) = 0x180004c3e;
        fcn.18045f7d4();
        pcVar9 = (code *)swi(3);
        (*pcVar9)();
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180004c40
// Address: 0x180004c40
// Size: 60 bytes
// ============================================================
void fcn.180004c40(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t var_18h;
    undefined4 uStack_10;
    undefined4 uStack_c;
    
    if (*(int32_t *)(arg1 + 8) != 0) {
        var_18h._0_4_ = *(undefined4 *)arg1;
        var_18h._4_4_ = *(undefined4 *)(arg1 + 4);
        uStack_10 = *(undefined4 *)(arg1 + 8);
        uStack_c = *(undefined4 *)(arg1 + 0xc);
        iVar2 = fcn.180454a0c(&var_18h);
        if (iVar2 == 0) {
            *(undefined (*) [16])arg1 = ZEXT816(0);
            return;
        }
    }
    fcn.1804542e8(1);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180004c80
// Address: 0x180004c80
// Size: 325 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

undefined8 fcn.180004c80(int64_t arg1, int64_t arg2)
{
    uint32_t *puVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined auVar4 [16];
    undefined auVar5 [16];
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined8 uStack_20;
    int64_t var_18h;
    
    if ((int32_t)arg2 != 1) {
        return 1;
    }
    _var_28h = ZEXT816(0);
    var_18h = fcn.180459890();
    *(undefined4 *)var_18h = 1;
    *(undefined4 *)(var_18h + 4) = 2;
    *(undefined8 *)(var_18h + 8) = 0;
    *(undefined8 *)(var_18h + 0x10) = 0;
    *(undefined4 *)(var_18h + 0x18) = 0;
    piVar7 = (int64_t *)fcn.180459890(8);
    *piVar7 = arg1;
    iVar8 = fcn.18045f6e8((uint64_t)var_48h._4_4_ << 0x20, (int64_t)&uStack_20, var_18h);
    auVar4 = _var_28h;
    var_28h = iVar8;
    auVar5 = _var_28h;
    if (iVar8 == 0) goto code_r0x000180004db6;
    uStack_20._0_4_ = auVar4._8_4_;
    if ((int32_t)uStack_20 == 0) {
code_r0x000180004da5:
        _var_28h = auVar5;
        fcn.1804542e8(1);
    } else {
        var_30h._0_4_ = (int32_t)uStack_20;
        var_38h = iVar8;
        uStack_20._4_4_ = auVar4._12_4_;
        var_30h._4_4_ = uStack_20._4_4_;
        _var_28h = auVar5;
        iVar6 = fcn.180454a0c(&var_38h);
        auVar5 = _var_28h;
        if (iVar6 != 0) goto code_r0x000180004da5;
        _var_38h = ZEXT816(0);
        _var_28h = ZEXT812(0);
        uStack_20._4_4_ = 0;
        if (var_18h != 0) {
            LOCK();
            puVar1 = (uint32_t *)(var_18h + 4);
            uVar2 = *puVar1;
            *puVar1 = *puVar1 - 2;
            UNLOCK();
            if ((uVar2 & 0xfffffffe) == 2) {
                LOCK();
                iVar6 = *(int32_t *)var_18h;
                *(int32_t *)var_18h = *(int32_t *)var_18h + -1;
                UNLOCK();
                if (iVar6 == 1) {
                    fcn.180459c3c(var_18h, 0x20);
                }
            }
        }
        if ((int32_t)uStack_20 == 0) {
            return 1;
        }
    }
    fcn.18045f7d4();
code_r0x000180004db6:
    uStack_20._0_4_ = 0;
    fcn.1804542e8(6);
    pcVar3 = (code *)swi(3);
    uVar9 = (*pcVar3)();
    return uVar9;
}

// ============================================================
// Function: FUN_180004de0
// Address: 0x180004de0
// Size: 89 bytes
// ============================================================
uint64_t fcn.180004de0(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    
    if (arg1 == 0) {
        return 0;
    }
    if (0xfff < (uint64_t)arg1) {
        if (arg1 + 0x27U <= (uint64_t)arg1) {
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            uVar4 = (*pcVar1)();
            return uVar4;
        }
        iVar3 = fcn.180459890(arg1 + 0x27U);
        iVar5 = iVar3;
        if (iVar3 == 0) {
            iVar5 = 5;
            pcVar1 = (code *)swi(0x29);
            iVar3 = (*pcVar1)();
        }
        uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar4 - 8) = iVar5;
        return uVar4;
    }
    do {
        uVar4 = fcn.18046d050(arg1);
        if (uVar4 != 0) {
            return uVar4;
        }
        iVar2 = fcn.18047a460(arg1);
    } while (iVar2 != 0);
    if (arg1 == -1) {
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        uVar4 = (*pcVar1)();
        return uVar4;
    }
    fcn.180454670();
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_180004e40
// Address: 0x180004e40
// Size: 97 bytes
// ============================================================
void fcn.180004e40(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar1 = *(int64_t *)arg1;
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x18) + 1) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180004e88;
        fcn.180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    return;
}

// ============================================================
// Function: FUN_180004eb0
// Address: 0x180004eb0
// Size: 2957 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_63h
// WARNING: [rz-ghidra] Detected overlap for variable var_b6h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

void fcn.180004eb0(int64_t arg1, int64_t arg_58h)
{
    int32_t iVar1;
    char cVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined auVar9 [16];
    undefined auVar10 [16];
    int32_t iVar11;
    undefined8 uVar12;
    int64_t *piVar13;
    undefined4 *puVar14;
    undefined8 *puVar15;
    undefined8 *puVar16;
    undefined4 *puVar17;
    int64_t **ppiVar18;
    int64_t **ppiVar19;
    undefined4 *puVar20;
    undefined8 *puVar21;
    int64_t iVar22;
    int64_t **ppiVar23;
    uint32_t uVar24;
    uint64_t uVar25;
    int64_t *piVar26;
    int64_t *piVar27;
    undefined *puVar28;
    int64_t iVar29;
    int64_t *piVar30;
    char *pcVar31;
    int64_t iVar32;
    int64_t **ppiVar33;
    int32_t *piVar34;
    uint32_t uVar35;
    int64_t unaff_GS_OFFSET;
    bool bVar36;
    undefined auStack_178 [8];
    undefined auStack_170 [24];
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    undefined var_128h [4];
    int64_t var_124h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_88h;
    undefined4 var_78h;
    int64_t var_74h;
    undefined4 var_6ch;
    int64_t var_68h;
    int64_t var_58h;
    
    puVar28 = auStack_178;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_178;
    *(undefined8 *)0x180781ed0 = *(undefined8 *)arg1;
    var_108h = arg1;
    func_0x000180172540();
    uVar12 = func_0x0001801723e0();
    iVar32 = 6;
    func_0x000180173570(uVar12, 6);
    piVar13 = (int64_t *)func_0x000180008740();
    iVar22 = *piVar13;
    var_110h = iVar22;
    func_0x000180010330();
    piVar13 = (int64_t *)func_0x000180013d30();
    var_100h = 0x1805ab250;
    var_f8h = iVar22;
    var_c8h = (int64_t)&var_100h;
    iVar22 = *piVar13;
    piVar26 = (int64_t *)(iVar22 + 0x2a8);
    if (piVar26 != &var_100h) {
        piVar30 = *(int64_t **)(iVar22 + 0x2e0);
        if (piVar30 != (int64_t *)0x0) {
            (**(code **)(*piVar30 + 0x20))(piVar30, piVar30 != piVar26);
            *(undefined8 *)(iVar22 + 0x2e0) = 0;
        }
        func_0x000180014de0(piVar26, &var_100h);
    }
    if (var_c8h != 0) {
        (**(code **)(*(int64_t *)var_c8h + 0x20))(var_c8h, (int64_t *)var_c8h != &var_100h);
    }
    iVar22 = *piVar13;
    var_74h._0_4_ = 5000;
    var_74h._4_4_ = 0;
    var_68h._0_4_ = 0xffffffff;
    uVar35 = 0;
    var_68h._4_4_ = 0;
    var_78h = 1000;
    var_6ch = 2;
    puVar14 = *(undefined4 **)(iVar22 + 0x68);
    if (puVar14 == (undefined4 *)0x0) {
        puVar14 = (undefined4 *)func_0x0001801813b0(0x18);
        *(undefined4 **)(iVar22 + 0x68) = puVar14;
    }
    *puVar14 = var_78h;
    puVar14[1] = (undefined4)var_74h;
    puVar14[2] = var_74h._4_4_;
    puVar14[3] = var_6ch;
    *(uint64_t *)(puVar14 + 4) = CONCAT44(var_68h._4_4_, (undefined4)var_68h);
    _var_158h = ZEXT816(0);
    puVar15 = (undefined8 *)fcn.180459890(0x60);
    *puVar15 = puVar15;
    puVar15[1] = puVar15;
    puVar15[2] = puVar15;
    *(undefined2 *)(puVar15 + 3) = 0x101;
    var_158h = (int64_t)puVar15;
    puVar21 = *(undefined8 **)(*(int64_t *)0x18077e0e0 + 8);
    puVar16 = puVar15;
    if (*(char *)((int64_t)puVar21 + 0x19) == '\0') {
        puVar16 = (undefined8 *)func_0x000180016a70(&var_158h, puVar15, puVar21 + 4);
        puVar16[1] = puVar15;
        *(undefined *)(puVar16 + 3) = *(undefined *)(puVar21 + 3);
        uVar12 = func_0x000180015950(&var_158h, *puVar21, puVar16);
        *puVar16 = uVar12;
        uVar12 = func_0x000180015950(&var_158h, puVar21[2], puVar16);
        puVar16[2] = uVar12;
        puVar15 = puVar16;
        puVar16 = (undefined8 *)var_158h;
    }
    var_158h = (int64_t)puVar16;
    iVar29 = var_158h;
    *(undefined8 **)(var_158h + 8) = puVar15;
    var_150h = *(undefined8 *)0x18077e0e8;
    ppiVar19 = *(int64_t ***)(iVar29 + 8);
    if (*(char *)((int64_t)ppiVar19 + 0x19) == '\0') {
        cVar2 = *(char *)((int64_t)*ppiVar19 + 0x19);
        ppiVar23 = (int64_t **)*ppiVar19;
        while (cVar2 == '\0') {
            cVar2 = *(char *)((int64_t)*ppiVar23 + 0x19);
            ppiVar19 = ppiVar23;
            ppiVar23 = (int64_t **)*ppiVar23;
        }
        *(int64_t ***)iVar29 = ppiVar19;
        iVar3 = *(int64_t *)(iVar29 + 8);
        cVar2 = *(char *)(*(int64_t *)(iVar3 + 0x10) + 0x19);
        while (cVar2 == '\0') {
            iVar3 = *(int64_t *)(iVar3 + 0x10);
            cVar2 = *(char *)(*(int64_t *)(iVar3 + 0x10) + 0x19);
        }
        *(int64_t *)(iVar29 + 0x10) = iVar3;
    } else {
        *(int64_t *)iVar29 = iVar29;
        *(int64_t *)(iVar29 + 0x10) = iVar29;
    }
    pcVar31 = (char *)((int64_t)&var_68h + 5);
    uVar24 = *(uint32_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x30) + 0x40);
    do {
        pcVar31 = pcVar31 + -1;
        *pcVar31 = (char)uVar24 + (char)((uint64_t)uVar24 / 10) * -10 + '0';
        uVar24 = (uint32_t)((uint64_t)uVar24 / 10);
    } while (uVar24 != 0);
    func_0x000180014b30(&var_a0h, pcVar31, (int64_t)&var_68h + 5, &var_148h);
    var_b0h = 10;
    var_a8h = 0xf;
    var_b8h._0_2_ = 0x6449;
    var_c0h = 0x2d737365636f7250;
    var_b8h._2_6_ = 0;
    puVar21 = *(undefined8 **)(var_158h + 8);
    puVar15 = puVar21;
    puVar16 = (undefined8 *)var_158h;
    if (*(char *)((int64_t)puVar21 + 0x19) == '\0') {
        do {
            puVar21 = puVar15;
            piVar13 = puVar21 + 4;
            piVar26 = &var_c0h;
            if (0xf < (uint64_t)var_a8h) {
                piVar26 = (int64_t *)var_c0h;
            }
            if (0xf < (uint64_t)puVar21[7]) {
                piVar13 = (int64_t *)*piVar13;
            }
            iVar11 = func_0x00018047b6d0(piVar13, piVar26);
            if (-1 < iVar11) {
                puVar15 = (undefined8 *)*puVar21;
                puVar16 = puVar21;
            } else {
                puVar15 = (undefined8 *)puVar21[2];
            }
            uVar35 = (uint32_t)(-1 < iVar11);
        } while (*(char *)((int64_t)puVar15 + 0x19) == '\0');
    }
    iVar29 = var_158h;
    if (*(char *)((int64_t)puVar16 + 0x19) == '\0') {
        piVar13 = puVar16 + 4;
        if (0xf < (uint64_t)puVar16[7]) {
            piVar13 = (int64_t *)*piVar13;
        }
        piVar26 = &var_c0h;
        if (0xf < (uint64_t)var_a8h) {
            piVar26 = (int64_t *)var_c0h;
        }
        iVar11 = func_0x00018047b6d0(piVar26, piVar13);
        if (iVar11 < 0) {
            iVar29 = var_158h;
            goto code_r0x000180005204;
        }
    } else {
code_r0x000180005204:
        if (var_150h == 0x2aaaaaaaaaaaaaa) {
            func_0x000180013c00();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        piVar13 = (int64_t *)fcn.180459890(0x60);
        *(undefined4 *)(piVar13 + 4) = (undefined4)var_c0h;
        *(undefined4 *)((int64_t)piVar13 + 0x24) = var_c0h._4_4_;
        *(undefined4 *)(piVar13 + 5) = (undefined4)var_b8h;
        *(undefined4 *)((int64_t)piVar13 + 0x2c) = var_b8h._4_4_;
        *(undefined4 *)(piVar13 + 6) = (undefined4)var_b0h;
        *(undefined4 *)((int64_t)piVar13 + 0x34) = var_b0h._4_4_;
        *(undefined4 *)(piVar13 + 7) = (undefined4)var_a8h;
        *(undefined4 *)((int64_t)piVar13 + 0x3c) = var_a8h._4_4_;
        var_b0h = 0;
        var_a8h = 0xf;
        auVar9[15] = 0;
        auVar9._0_15_ = stack0xffffffffffffff41;
        _var_c0h = auVar9 << 8;
        *(undefined (*) [16])(piVar13 + 8) = ZEXT816(0);
        piVar13[10] = 0;
        piVar13[0xb] = 0xf;
        *(undefined *)(piVar13 + 8) = 0;
        *piVar13 = iVar29;
        piVar13[1] = iVar29;
        piVar13[2] = iVar29;
        *(undefined2 *)(piVar13 + 3) = 0;
        var_78h = SUB84(puVar21, 0);
        var_74h._0_4_ = (undefined4)((uint64_t)puVar21 >> 0x20);
        var_6ch = (undefined4)var_124h;
        var_74h._4_4_ = uVar35;
        puVar16 = (undefined8 *)func_0x0001800156d0(&var_158h, &var_78h);
    }
    func_0x000180012c10(puVar16 + 8, &var_a0h);
    if (0xf < (uint64_t)var_a8h) {
        uVar25 = var_a8h + 1;
        iVar29 = var_c0h;
        if (0xfff < uVar25) {
            if (0x1f < (var_c0h - *(int64_t *)(var_c0h + -8)) - 8U) goto code_r0x0001800059d6;
            uVar25 = var_a8h + 0x28;
            iVar29 = *(int64_t *)(var_c0h + -8);
        }
        fcn.180459c3c(iVar29, uVar25);
    }
    var_b0h = 0;
    var_a8h = 0xf;
    auVar10[15] = 0;
    auVar10._0_15_ = stack0xffffffffffffff41;
    _var_c0h = auVar10 << 8;
    if (0xf < (uint64_t)var_88h) {
        uVar25 = var_88h + 1;
        if (0xfff < uVar25) {
            if (0x1f < (var_a0h - *(int64_t *)(var_a0h + -8)) - 8U) goto code_r0x0001800059d6;
            uVar25 = var_88h + 0x28;
            var_a0h = *(int64_t *)(var_a0h + -8);
        }
        fcn.180459c3c(var_a0h, uVar25);
    }
    func_0x00018017fc00(iVar22, 0x18061feb0, &var_158h);
    func_0x000180015170(&var_158h, &var_158h, *(undefined8 *)(var_158h + 8));
    fcn.180459c3c(var_158h, 0x60);
    if (((**(int64_t **)0x1807825b0 == 0) || (iVar22 = *(int64_t *)(**(int64_t **)0x1807825b0 + 0x98), iVar22 == 0)) ||
       (*(undefined8 **)0x1807821e0 = *(undefined8 **)(iVar22 + 200), *(undefined8 **)0x1807821e0 == (undefined8 *)0x0))
    {
        (*(code *)0x69a3d8)(0, 0x18063d120, 0x1805ab2d0, 0);
        func_0x00018046df68(0);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    puVar14 = (undefined4 *)**(undefined8 **)0x1807821e0;
    puVar17 = (undefined4 *)(*(code *)0x699dcc)(0, 0x300, 0x3000, 4);
    puVar20 = puVar17;
    if (puVar17 != (undefined4 *)0x0) {
        do {
            uVar5 = puVar14[1];
            uVar6 = puVar14[2];
            uVar7 = puVar14[3];
            *puVar20 = *puVar14;
            puVar20[1] = uVar5;
            puVar20[2] = uVar6;
            puVar20[3] = uVar7;
            uVar5 = puVar14[5];
            uVar6 = puVar14[6];
            uVar7 = puVar14[7];
            puVar20[4] = puVar14[4];
            puVar20[5] = uVar5;
            puVar20[6] = uVar6;
            puVar20[7] = uVar7;
            uVar5 = puVar14[9];
            uVar6 = puVar14[10];
            uVar7 = puVar14[0xb];
            puVar20[8] = puVar14[8];
            puVar20[9] = uVar5;
            puVar20[10] = uVar6;
            puVar20[0xb] = uVar7;
            uVar5 = puVar14[0xd];
            uVar6 = puVar14[0xe];
            uVar7 = puVar14[0xf];
            puVar20[0xc] = puVar14[0xc];
            puVar20[0xd] = uVar5;
            puVar20[0xe] = uVar6;
            puVar20[0xf] = uVar7;
            uVar5 = puVar14[0x11];
            uVar6 = puVar14[0x12];
            uVar7 = puVar14[0x13];
            puVar20[0x10] = puVar14[0x10];
            puVar20[0x11] = uVar5;
            puVar20[0x12] = uVar6;
            puVar20[0x13] = uVar7;
            uVar5 = puVar14[0x15];
            uVar6 = puVar14[0x16];
            uVar7 = puVar14[0x17];
            puVar20[0x14] = puVar14[0x14];
            puVar20[0x15] = uVar5;
            puVar20[0x16] = uVar6;
            puVar20[0x17] = uVar7;
            uVar5 = puVar14[0x19];
            uVar6 = puVar14[0x1a];
            uVar7 = puVar14[0x1b];
            puVar20[0x18] = puVar14[0x18];
            puVar20[0x19] = uVar5;
            puVar20[0x1a] = uVar6;
            puVar20[0x1b] = uVar7;
            uVar5 = puVar14[0x1d];
            uVar6 = puVar14[0x1e];
            uVar7 = puVar14[0x1f];
            puVar20[0x1c] = puVar14[0x1c];
            puVar20[0x1d] = uVar5;
            puVar20[0x1e] = uVar6;
            puVar20[0x1f] = uVar7;
            puVar14 = puVar14 + 0x20;
            iVar32 = iVar32 + -1;
            puVar20 = puVar20 + 0x20;
        } while (iVar32 != 0);
        *(undefined8 *)0x1807821a8 = *(undefined8 *)(puVar17 + 0x10);
        *(undefined8 *)0x1807821d8 = *(undefined8 *)(puVar17 + 0x1a);
        *(undefined8 *)(puVar17 + 0x10) = 0x180079ec0;
        *(undefined8 *)(puVar17 + 0x1a) = 0x18007c330;
        **(undefined8 **)0x1807821e0 = puVar17;
    }
    *(undefined8 *)0x180782430 = *(undefined8 *)0x1807825c0;
    *(undefined4 *)0x180782410 = **(undefined4 **)0x180782638;
    *(undefined4 *)0x180782414 = (*(undefined4 **)0x180782638)[1];
    *(undefined4 *)0x180782418 = (*(undefined4 **)0x180782638)[2];
    *(undefined4 *)0x18078241c = (*(undefined4 **)0x180782638)[3];
    *(undefined4 *)0x180782420 = (*(undefined4 **)0x180782638)[4];
    *(undefined4 *)0x180782424 = (*(undefined4 **)0x180782638)[5];
    *(undefined4 *)0x180782428 = (*(undefined4 **)0x180782638)[6];
    *(undefined4 *)0x18078242c = (*(undefined4 **)0x180782638)[7];
    *(undefined4 **)0x1807823c8 = *(undefined4 **)0x180782638;
    *(undefined8 *)0x180782438 = 0x180005d40;
    var_158h._0_4_ = *(undefined4 *)(*(int64_t *)(unaff_GS_OFFSET + 0x30) + 0x40);
    var_150h = 0;
    (*(code *)0x69a39c)(0x180008b00, &var_158h);
    iVar22 = var_110h;
    *(int64_t *)(var_110h + 8) = var_150h;
    func_0x000180018f70();
    iVar32 = func_0x00018001c4a0();
    ppiVar19 = *(int64_t ***)(iVar32 + 8);
    var_158h = (int64_t)ppiVar19;
    ppiVar23 = (int64_t **)*ppiVar19;
    var_118h = (int64_t)ppiVar23;
    if (ppiVar23 != ppiVar19) {
        do {
            if (ppiVar23[5] < (int64_t *)0x10) {
                ppiVar33 = ppiVar23 + 2;
            } else {
                ppiVar33 = (int64_t **)ppiVar23[2];
            }
            var_118h = (int64_t)ppiVar23;
            ppiVar18 = (int64_t **)(**(code **)0x180782538)();
            piVar13 = *ppiVar18;
            piVar26 = ppiVar18[1];
            while( true ) {
                iVar22 = var_110h;
                if (piVar13 == piVar26) goto code_r0x00018000574a;
                iVar32 = *piVar13;
                piVar27 = *(int64_t **)(iVar32 + 8);
                uVar12 = fcn.180498cd0(ppiVar33);
                piVar30 = piVar27 + 2;
                if (0xf < (uint64_t)piVar27[3]) {
                    piVar27 = (int64_t *)*piVar27;
                }
                iVar11 = func_0x00018001f3d0(piVar27, *piVar30, ppiVar33, uVar12);
                if (iVar11 == 0) break;
                piVar13 = piVar13 + 1;
            }
            iVar22 = var_110h;
            if (iVar32 == 0) break;
            ppiVar33 = (int64_t **)ppiVar23[7];
            ppiVar18 = (int64_t **)*ppiVar33;
            if (ppiVar18 != ppiVar33) {
                piVar34 = (int32_t *)(iVar32 + 0x250);
                var_140h = (int64_t)piVar34;
                do {
                    var_138h = (int64_t)(ppiVar18 + 2);
                    if ((int64_t *)0xf < ppiVar18[5]) {
                        var_138h = *(int64_t *)var_138h;
                    }
                    iVar22 = **(int64_t **)0x180782608;
                    if (iVar22 == 0) {
                        iVar22 = (**(code **)0x180782578)();
                    }
                    piVar13 = (int64_t *)(**(code **)0x180782660)(iVar22 + 0x50, &var_138h);
                    if (piVar13 == (int64_t *)0x0) {
                        iVar22 = iVar22 + 0x80;
                    } else {
                        iVar22 = *piVar13;
                    }
                    var_78h = (undefined4)iVar22;
                    var_74h._0_4_ = (undefined4)((uint64_t)iVar22 >> 0x20);
                    if (((*piVar34 != 0) &&
                        (ppiVar19 = (int64_t **)(**(code **)0x180782580)(piVar34, &var_78h), ppiVar19 != (int64_t **)0x0
                        )) && (piVar13 = *ppiVar19, piVar34 = (int32_t *)var_140h, piVar13 != (int64_t *)0x0)) {
                        ppiVar19 = (int64_t **)piVar13[5];
                        piVar26 = ppiVar19[2];
                        ppiVar23 = ppiVar19;
                        if ((int64_t *)0xf < ppiVar19[3]) {
                            ppiVar23 = (int64_t **)*ppiVar19;
                        }
                        piVar30 = piVar26;
                        if ((int64_t *)0xd < piVar26) {
                            piVar30 = (int64_t *)0xd;
                        }
                        iVar11 = func_0x000180497f30(ppiVar23, 0x180621788, piVar30);
                        if ((iVar11 == 0) && (piVar26 == (int64_t *)0xd)) {
                            puVar14 = (undefined4 *)*piVar13;
                            var_138h = (int64_t)piVar13;
                            puVar20 = (undefined4 *)fcn.18046d050(0x20);
                            piVar34 = (int32_t *)var_140h;
                            if (puVar20 != (undefined4 *)0x0) {
                                uVar5 = *puVar14;
                                uVar6 = puVar14[1];
                                uVar7 = puVar14[2];
                                uVar8 = puVar14[3];
                                *puVar20 = uVar5;
                                puVar20[1] = uVar6;
                                puVar20[2] = uVar7;
                                puVar20[3] = uVar8;
                                uVar6 = puVar14[5];
                                uVar7 = puVar14[6];
                                uVar8 = puVar14[7];
                                puVar20[4] = puVar14[4];
                                puVar20[5] = uVar6;
                                puVar20[6] = uVar7;
                                puVar20[7] = uVar8;
                                uVar12 = *(undefined8 *)(puVar20 + 2);
                                puVar21 = (undefined8 *)func_0x00018001eda0(uVar5, &var_138h);
                                *puVar21 = uVar12;
                                func_0x0001800852c0();
                                *(undefined8 *)(puVar20 + 2) = 0x18001ec00;
code_r0x00018000570e:
                                *(undefined4 **)var_138h = puVar20;
                                piVar34 = (int32_t *)var_140h;
                            }
                        } else {
                            if ((int64_t *)0xf < ppiVar19[3]) {
                                ppiVar19 = (int64_t **)*ppiVar19;
                            }
                            piVar30 = piVar26;
                            if ((int64_t *)0x8 < piVar26) {
                                piVar30 = (int64_t *)0x8;
                            }
                            iVar11 = func_0x000180497f30(ppiVar19, 0x180621798, piVar30);
                            piVar34 = (int32_t *)var_140h;
                            if ((iVar11 == 0) && (piVar26 == (int64_t *)0x8)) {
                                puVar14 = (undefined4 *)*piVar13;
                                var_138h = (int64_t)piVar13;
                                puVar20 = (undefined4 *)fcn.18046d050(0x20);
                                piVar34 = (int32_t *)var_140h;
                                if (puVar20 != (undefined4 *)0x0) {
                                    uVar5 = *puVar14;
                                    uVar6 = puVar14[1];
                                    uVar7 = puVar14[2];
                                    uVar8 = puVar14[3];
                                    *puVar20 = uVar5;
                                    puVar20[1] = uVar6;
                                    puVar20[2] = uVar7;
                                    puVar20[3] = uVar8;
                                    uVar6 = puVar14[5];
                                    uVar7 = puVar14[6];
                                    uVar8 = puVar14[7];
                                    puVar20[4] = puVar14[4];
                                    puVar20[5] = uVar6;
                                    puVar20[6] = uVar7;
                                    puVar20[7] = uVar8;
                                    uVar12 = *(undefined8 *)(puVar20 + 4);
                                    puVar21 = (undefined8 *)func_0x00018001eda0(uVar5, &var_138h);
                                    *puVar21 = uVar12;
                                    func_0x0001800852c0();
                                    *(undefined8 *)(puVar20 + 4) = 0x18001eb90;
                                    goto code_r0x00018000570e;
                                }
                            }
                        }
                    }
                    ppiVar18 = (int64_t **)*ppiVar18;
                } while (ppiVar18 != ppiVar33);
                ppiVar23 = (int64_t **)var_118h;
                ppiVar19 = (int64_t **)var_158h;
            }
            ppiVar23 = (int64_t **)*ppiVar23;
            iVar22 = var_110h;
            var_118h = (int64_t)ppiVar23;
        } while (ppiVar23 != ppiVar19);
    }
code_r0x00018000574a:
    _var_130h = ZEXT816(0);
    stack0xfffffffffffffee0 = (undefined8 *)0x0;
    puVar16 = (undefined8 *)fcn.180459890(4000);
    puVar21 = puVar16;
    for (puVar15 = (undefined8 *)var_130h; puVar15 != _var_128h; puVar15 = puVar15 + 2) {
        *puVar21 = 0;
        puVar21[1] = 0;
        *puVar21 = *puVar15;
        puVar21[1] = puVar15[1];
        *puVar15 = 0;
        puVar15[1] = 0;
        puVar21 = puVar21 + 2;
    }
    func_0x00018000d5d0(puVar21, puVar21);
    iVar32 = (int64_t)_var_128h;
    if (var_130h == 0) goto code_r0x00018000584d;
    iVar29 = var_130h;
    if ((int64_t *)var_130h != _var_128h) {
        do {
            piVar13 = *(int64_t **)(iVar29 + 8);
            if (piVar13 != (int64_t *)0x0) {
                LOCK();
                piVar26 = piVar13 + 1;
                iVar11 = *(int32_t *)piVar26;
                *(int32_t *)piVar26 = *(int32_t *)piVar26 + -1;
                UNLOCK();
                if (iVar11 == 1) {
                    (**(code **)*piVar13)(piVar13);
                    LOCK();
                    piVar34 = (int32_t *)((int64_t)piVar13 + 0xc);
                    iVar11 = *piVar34;
                    *piVar34 = *piVar34 + -1;
                    UNLOCK();
                    if (iVar11 == 1) {
                        (**(code **)(*piVar13 + 8))(piVar13);
                    }
                }
            }
            iVar29 = iVar29 + 0x10;
        } while (iVar29 != iVar32);
        iVar29 = var_130h;
    }
    uVar25 = (int64_t)stack0xfffffffffffffee0 - iVar29 & 0xfffffffffffffff0;
    if (0xfff < uVar25) {
        if (0x1f < (iVar29 - *(int64_t *)(iVar29 + -8)) - 8U) goto code_r0x0001800059d6;
        uVar25 = uVar25 + 0x27;
        iVar29 = *(int64_t *)(iVar29 + -8);
    }
    fcn.180459c3c(iVar29, uVar25);
code_r0x00018000584d:
    _var_128h = puVar16;
    var_130h = (int64_t)puVar16;
    unique0x00003200 = puVar16 + 500;
    puVar21 = puVar16;
    do {
        if (puVar21 != puVar16) {
            func_0x00018000d5d0(puVar21);
            _var_128h = (int64_t *)var_130h;
        }
        (**(code **)0x180782648)(&var_130h);
        piVar26 = _var_128h;
        for (piVar13 = (int64_t *)var_130h; piVar13 != piVar26; piVar13 = piVar13 + 2) {
            iVar32 = *piVar13;
            if (((iVar32 != 0) && (*(char *)(iVar32 + 0x108) != '\0')) &&
               (iVar11 = func_0x000180498f10((char *)(iVar32 + 0x108), 0x1805aaea8), iVar11 == 0)) {
                LOCK();
                UNLOCK();
                piVar13 = *(int64_t **)(*(int64_t *)(iVar32 + 0x1b0) + 0x10);
                *(int64_t *)0x180781ee0 = iVar32;
                if (piVar13 != (int64_t *)0x0) {
                    uVar12 = *(undefined8 *)(*(int64_t *)(iVar32 + 0x1b0) + 8);
                    LOCK();
                    *(int32_t *)((int64_t)piVar13 + 0xc) = *(int32_t *)((int64_t)piVar13 + 0xc) + 1;
                    UNLOCK();
                    _var_158h = ZEXT816(0);
                    iVar11 = *(int32_t *)(piVar13 + 1);
                    if (iVar11 == 0) goto code_r0x000180005935;
                    goto code_r0x000180005910;
                }
                _var_158h = ZEXT816(0);
                piVar13 = (int64_t *)0x0;
                goto code_r0x000180005935;
            }
        }
        (*(code *)0x699d32)(200);
        puVar16 = _var_128h;
        puVar21 = (undefined8 *)var_130h;
    } while( true );
    while (iVar11 != 0) {
code_r0x000180005910:
        LOCK();
        iVar1 = *(int32_t *)(piVar13 + 1);
        bVar36 = iVar11 == iVar1;
        if (bVar36) {
            *(int32_t *)(piVar13 + 1) = iVar11 + 1;
            iVar1 = iVar11;
        }
        iVar11 = iVar1;
        UNLOCK();
        if (bVar36) {
            var_150h = (int64_t)piVar13;
            var_158h = uVar12;
            break;
        }
    }
code_r0x000180005935:
    func_0x000180008bb0(iVar22, &var_158h);
    iVar22 = var_150h;
    if (var_150h != 0) {
        LOCK();
        piVar34 = (int32_t *)(var_150h + 8);
        iVar11 = *piVar34;
        *piVar34 = *piVar34 + -1;
        UNLOCK();
        if (iVar11 == 1) {
            (***(code ***)var_150h)(var_150h);
            LOCK();
            piVar34 = (int32_t *)(iVar22 + 0xc);
            iVar11 = *piVar34;
            *piVar34 = *piVar34 + -1;
            UNLOCK();
            if (iVar11 == 1) {
                (**(code **)(*(int64_t *)iVar22 + 8))(iVar22);
            }
        }
    }
    if (piVar13 != (int64_t *)0x0) {
        LOCK();
        piVar34 = (int32_t *)((int64_t)piVar13 + 0xc);
        iVar11 = *piVar34;
        *piVar34 = *piVar34 + -1;
        UNLOCK();
        if (iVar11 == 1) {
            (**(code **)(*piVar13 + 8))(piVar13);
        }
    }
    if (var_130h == 0) goto code_r0x0001800059e5;
    func_0x00018000d5d0(var_130h, _var_128h);
    iVar22 = var_130h;
    puVar28 = auStack_178;
    if ((0xfff < ((int64_t)stack0xfffffffffffffee0 - var_130h & 0xfffffffffffffff0U)) &&
       (iVar22 = *(int64_t *)(var_130h + -8), puVar28 = auStack_178, 0x1f < (var_130h - iVar22) - 8U)) {
code_r0x0001800059d6:
        pcVar4 = (code *)swi(0x29);
        iVar22 = (*pcVar4)(5);
        puVar28 = auStack_170;
    }
    *(undefined8 *)(puVar28 + -8) = 0x1800059e5;
    fcn.180459c3c(iVar22);
code_r0x0001800059e5:
    *(undefined8 *)(puVar28 + -8) = 0x1800059ea;
    func_0x00018045476c();
    *(undefined8 *)(puVar28 + -8) = 0x1800059f4;
    func_0x000180005a40(puVar28 + 0x70);
    *(undefined8 *)(puVar28 + -8) = 0x180005a02;
    fcn.180459870(var_58h ^ (uint64_t)puVar28);
    return;
}

// ============================================================
// Function: FUN_180005b10
// Address: 0x180005b10
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180005b10(void)
{
    code *pcVar1;
    int64_t var_28h;
    
    fcn.180005ae0(&var_28h);
    fcn.18045bae0(var_28h);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180005b30
// Address: 0x180005b30
// Size: 60 bytes
// ============================================================
int64_t fcn.180005b30(int64_t arg1, int64_t arg2)
{
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a5420;
    return arg1;
}

// ============================================================
// Function: FUN_180005b70
// Address: 0x180005b70
// Size: 384 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180005b70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint16_t uVar1;
    uint16_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    undefined8 uVar8;
    undefined (*pauVar9) [32];
    undefined (*pauVar10) [32];
    undefined auVar11 [16];
    undefined auVar12 [32];
    int64_t var_10h;
    
    uVar4 = 0;
    pauVar9 = (undefined (*) [32])arg1;
    pauVar10 = (undefined (*) [32])arg2;
    if ((*(int32_t *)0x180781ecc != 0) && (uVar3 = uVar4, 0xf < (uint64_t)arg3)) {
        do {
            auVar12 = vmovdqu_avx(*pauVar9);
            auVar12 = vpcmpeqw_avx2(auVar12, *pauVar10);
            uVar5 = (uint32_t)(SUB321(auVar12 >> 7, 0) & 1) | (uint32_t)(SUB321(auVar12 >> 0xf, 0) & 1) << 1 |
                    (uint32_t)(SUB321(auVar12 >> 0x17, 0) & 1) << 2 | (uint32_t)(SUB321(auVar12 >> 0x1f, 0) & 1) << 3 |
                    (uint32_t)(SUB321(auVar12 >> 0x27, 0) & 1) << 4 | (uint32_t)(SUB321(auVar12 >> 0x2f, 0) & 1) << 5 |
                    (uint32_t)(SUB321(auVar12 >> 0x37, 0) & 1) << 6 | (uint32_t)(SUB321(auVar12 >> 0x3f, 0) & 1) << 7 |
                    (uint32_t)(SUB321(auVar12 >> 0x47, 0) & 1) << 8 | (uint32_t)(SUB321(auVar12 >> 0x4f, 0) & 1) << 9 |
                    (uint32_t)(SUB321(auVar12 >> 0x57, 0) & 1) << 10 | (uint32_t)(SUB321(auVar12 >> 0x5f, 0) & 1) << 0xb
                    | (uint32_t)(SUB321(auVar12 >> 0x67, 0) & 1) << 0xc |
                    (uint32_t)(SUB321(auVar12 >> 0x6f, 0) & 1) << 0xd |
                    (uint32_t)(SUB321(auVar12 >> 0x77, 0) & 1) << 0xe | (uint32_t)SUB321(auVar12 >> 0x7f, 0) << 0xf |
                    (uint32_t)(SUB321(auVar12 >> 0x87, 0) & 1) << 0x10 |
                    (uint32_t)(SUB321(auVar12 >> 0x8f, 0) & 1) << 0x11 |
                    (uint32_t)(SUB321(auVar12 >> 0x97, 0) & 1) << 0x12 |
                    (uint32_t)(SUB321(auVar12 >> 0x9f, 0) & 1) << 0x13 |
                    (uint32_t)(SUB321(auVar12 >> 0xa7, 0) & 1) << 0x14 |
                    (uint32_t)(SUB321(auVar12 >> 0xaf, 0) & 1) << 0x15 |
                    (uint32_t)(SUB321(auVar12 >> 0xb7, 0) & 1) << 0x16 | (uint32_t)SUB321(auVar12 >> 0xbf, 0) << 0x17 |
                    (uint32_t)(SUB321(auVar12 >> 199, 0) & 1) << 0x18 |
                    (uint32_t)(SUB321(auVar12 >> 0xcf, 0) & 1) << 0x19 |
                    (uint32_t)(SUB321(auVar12 >> 0xd7, 0) & 1) << 0x1a |
                    (uint32_t)(SUB321(auVar12 >> 0xdf, 0) & 1) << 0x1b |
                    (uint32_t)(SUB321(auVar12 >> 0xe7, 0) & 1) << 0x1c |
                    (uint32_t)(SUB321(auVar12 >> 0xef, 0) & 1) << 0x1d |
                    (uint32_t)(SUB321(auVar12 >> 0xf7, 0) & 1) << 0x1e | (uint32_t)(uint8_t)(auVar12[31] >> 7) << 0x1f;
            if (uVar5 != 0xffffffff) {
                uVar5 = ~uVar5;
                uVar6 = 0;
                if (uVar5 != 0) {
                    for (; (uVar5 >> uVar6 & 1) == 0; uVar6 = uVar6 + 1) {
                    }
                }
                uVar8 = 1;
                if (*(uint16_t *)(arg1 + ((uVar6 >> 1) + uVar3) * 2) < *(uint16_t *)(arg2 + (uVar3 + (uVar6 >> 1)) * 2))
                {
                    uVar8 = 0xffffffff;
                }
                return uVar8;
            }
            uVar4 = uVar3 + 0x10;
            pauVar9 = pauVar9 + 1;
            pauVar10 = pauVar10 + 1;
            uVar7 = uVar3 + 0x20;
            uVar3 = uVar4;
        } while (uVar7 <= (uint64_t)arg3);
    }
    uVar3 = uVar4 + 8;
    while (uVar3 <= (uint64_t)arg3) {
        auVar11._0_2_ = -(uint16_t)(*(int16_t *)*pauVar10 == *(int16_t *)*pauVar9);
        auVar11._2_2_ = -(uint16_t)(*(int16_t *)(*pauVar10 + 2) == *(int16_t *)(*pauVar9 + 2));
        auVar11._4_2_ = -(uint16_t)(*(int16_t *)(*pauVar10 + 4) == *(int16_t *)(*pauVar9 + 4));
        auVar11._6_2_ = -(uint16_t)(*(int16_t *)(*pauVar10 + 6) == *(int16_t *)(*pauVar9 + 6));
        auVar11._8_2_ = -(uint16_t)(*(int16_t *)(*pauVar10 + 8) == *(int16_t *)(*pauVar9 + 8));
        auVar11._10_2_ = -(uint16_t)(*(int16_t *)(*pauVar10 + 10) == *(int16_t *)(*pauVar9 + 10));
        auVar11._12_2_ = -(uint16_t)(*(int16_t *)(*pauVar10 + 0xc) == *(int16_t *)(*pauVar9 + 0xc));
        auVar11._14_2_ = -(uint16_t)(*(int16_t *)(*pauVar10 + 0xe) == *(int16_t *)(*pauVar9 + 0xe));
        uVar2 = (uint16_t)(SUB161(auVar11 >> 7, 0) & 1) | (uint16_t)(SUB161(auVar11 >> 0xf, 0) & 1) << 1 |
                (uint16_t)(SUB161(auVar11 >> 0x17, 0) & 1) << 2 | (uint16_t)(SUB161(auVar11 >> 0x1f, 0) & 1) << 3 |
                (uint16_t)(SUB161(auVar11 >> 0x27, 0) & 1) << 4 | (uint16_t)(SUB161(auVar11 >> 0x2f, 0) & 1) << 5 |
                (uint16_t)(SUB161(auVar11 >> 0x37, 0) & 1) << 6 | (uint16_t)(SUB161(auVar11 >> 0x3f, 0) & 1) << 7 |
                (uint16_t)(SUB161(auVar11 >> 0x47, 0) & 1) << 8 | (uint16_t)(SUB161(auVar11 >> 0x4f, 0) & 1) << 9 |
                (uint16_t)(SUB161(auVar11 >> 0x57, 0) & 1) << 10 | (uint16_t)(SUB161(auVar11 >> 0x5f, 0) & 1) << 0xb |
                (uint16_t)(SUB161(auVar11 >> 0x67, 0) & 1) << 0xc | (uint16_t)(SUB161(auVar11 >> 0x6f, 0) & 1) << 0xd |
                (uint16_t)((uint8_t)(auVar11._14_2_ >> 7) & 1) << 0xe | auVar11._14_2_ & 0x8000;
        if (uVar2 != 0xffff) {
            uVar6 = ~(uint32_t)uVar2;
            uVar5 = 0;
            if (uVar6 != 0) {
                for (; (uVar6 >> uVar5 & 1) == 0; uVar5 = uVar5 + 1) {
                }
            }
            uVar8 = 1;
            if (*(uint16_t *)(arg1 + ((uVar5 >> 1) + uVar4) * 2) < *(uint16_t *)(arg2 + (uVar4 + (uVar5 >> 1)) * 2)) {
                uVar8 = 0xffffffff;
            }
            return uVar8;
        }
        pauVar9 = (undefined (*) [32])(*pauVar9 + 0x10);
        pauVar10 = (undefined (*) [32])(*pauVar10 + 0x10);
        uVar3 = uVar4 + 0x10;
        uVar4 = uVar4 + 8;
    }
    uVar3 = uVar4;
    if (uVar4 + 4 <= (uint64_t)arg3) {
        uVar3 = uVar4 + 4;
        if (*(uint64_t *)*pauVar9 != *(uint64_t *)*pauVar10) {
            uVar7 = *(uint64_t *)*pauVar10 ^ *(uint64_t *)*pauVar9;
            uVar3 = 0;
            if (uVar7 != 0) {
                for (; (uVar7 >> uVar3 & 1) == 0; uVar3 = uVar3 + 1) {
                }
            }
            uVar8 = 1;
            if (*(uint16_t *)(arg1 + ((uVar3 >> 4) + uVar4) * 2) < *(uint16_t *)(arg2 + (uVar4 + (uVar3 >> 4)) * 2)) {
                uVar8 = 0xffffffff;
            }
            return uVar8;
        }
    }
    while( true ) {
        if ((uint64_t)arg3 <= uVar3) {
            return 0;
        }
        uVar1 = *(uint16_t *)(arg1 + uVar3 * 2);
        uVar2 = *(uint16_t *)(arg2 + uVar3 * 2);
        if (uVar1 != uVar2) break;
        uVar3 = uVar3 + 1;
    }
    uVar8 = 1;
    if (uVar1 < uVar2) {
        uVar8 = 0xffffffff;
    }
    return uVar8;
}

// ============================================================
// Function: FUN_180005cf0
// Address: 0x180005cf0
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180005cf0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t var_8h;
    
    LOCK();
    piVar1 = (int32_t *)(arg1 + 8);
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
        (***(code ***)arg1)();
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0xc);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
            (**(code **)(*(int64_t *)arg1 + 8))(arg1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180005d50
// Address: 0x180005d50
// Size: 33 bytes
// ============================================================
int64_t fcn.180005d50(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    
    *(int64_t *)arg1 = arg2;
    uVar1 = fcn.180498cd0(arg2);
    *(undefined8 *)(arg1 + 8) = uVar1;
    return arg1;
}

// ============================================================
// Function: FUN_180005d80
// Address: 0x180005d80
// Size: 60 bytes
// ============================================================
int64_t fcn.180005d80(int64_t arg1, int64_t arg2)
{
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a53a0;
    return arg1;
}

// ============================================================
// Function: FUN_180005dd0
// Address: 0x180005dd0
// Size: 63 bytes
// ============================================================
undefined8 fcn.180005dd0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int64_t var_18h;
    
    piVar1 = (int32_t *)(**(code **)(*(int64_t *)arg1 + 0x18))(arg1, &var_18h, arg2 & 0xffffffff);
    if ((*(int64_t *)(*(int64_t *)(piVar1 + 2) + 8) == *(int64_t *)(*(int64_t *)(arg3 + 8) + 8)) &&
       (*piVar1 == *(int32_t *)arg3)) {
        return 1;
    }
    return 0;
}

