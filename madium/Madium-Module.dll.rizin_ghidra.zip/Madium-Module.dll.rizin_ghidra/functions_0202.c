// Chunk 202 - 50 functions

// ============================================================
// Function: FUN_18026ec10
// Address: 0x18026ec10
// Size: 233 bytes
// ============================================================
undefined8 fcn.18026ec10(int64_t arg_28h)
{
    int32_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    code *UNRECOVERED_JUMPTABLE;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026ec20;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar1 = *(int32_t **)(in_RCX + 0x88);
    if (piVar1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ec37;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ec4f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ec61;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ec7b;
    uVar3 = fcn.18026edf0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if ((int32_t)uVar3 == -1) {
        if ((*piVar1 != 0) &&
           ((UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(in_RCX + 0x78) + 0xf0),
            UNRECOVERED_JUMPTABLE != (code *)0x0 ||
            ((*(int64_t *)(piVar1 + 2) != 0 &&
             (UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(piVar1 + 2) + 0xf0), UNRECOVERED_JUMPTABLE != (code *)0x0)
             ))))) {
    // WARNING: Could not recover jumptable at 0x00018026eca2. Too many branches
    // WARNING: Treating indirect jump as call
            uVar3 = (*UNRECOVERED_JUMPTABLE)(piVar1);
            return uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ecbf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ecd7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ece9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        uVar3 = 0xfffffffe;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18026ed00
// Address: 0x18026ed00
// Size: 233 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18026ed00(int64_t arg_28h)
{
    int32_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    code *UNRECOVERED_JUMPTABLE;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026ed10;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar1 = *(int32_t **)(in_RCX + 0x88);
    if (piVar1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ed27;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ed3f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ed51;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ed6b;
    uVar3 = fcn.18026edf0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    if ((int32_t)uVar3 == -1) {
        if ((*piVar1 != 0) &&
           ((UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(in_RCX + 0x78) + 0xe8),
            UNRECOVERED_JUMPTABLE != (code *)0x0 ||
            ((*(int64_t *)(piVar1 + 2) != 0 &&
             (UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(piVar1 + 2) + 0xe8), UNRECOVERED_JUMPTABLE != (code *)0x0)
             ))))) {
    // WARNING: Could not recover jumptable at 0x00018026ed92. Too many branches
    // WARNING: Treating indirect jump as call
            uVar3 = (*UNRECOVERED_JUMPTABLE)(piVar1);
            return uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026edaf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026edc7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026edd9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        uVar3 = 0xfffffffe;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18026edf0
// Address: 0x18026edf0
// Size: 174 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18026edf0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint64_t in_R8;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026ee00;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int64_t *)(in_RCX + 0x20) == 0) {
        return 0xffffffff;
    }
    *(int64_t *)((int64_t)&arg_28h + iVar1) = *(int64_t *)(in_RCX + 0x20);
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026ee3f;
    iVar2 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                          *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                          *(int64_t *)(&stack0x000000a0 + iVar1));
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026ee49;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026ee61;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026ee73;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026ee93;
    uVar3 = fcn.180258020(*(undefined8 *)((int64_t)&arg_28h + iVar1), iVar2, in_RDX & 0xffffffff, in_R8 & 0xffffffff);
    return uVar3;
}

// ============================================================
// Function: FUN_18026eea0
// Address: 0x18026eea0
// Size: 60 bytes
// ============================================================
bool fcn.18026eea0(int64_t *param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026eeac;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x18026eec9;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + -iVar1));
    *param_1 = iVar1;
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_18026eee0
// Address: 0x18026eee0
// Size: 52 bytes
// ============================================================
void fcn.18026eee0(undefined8 *param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026eeec;
    iVar2 = fcn.18045a350();
    uVar1 = *param_1;
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x18026ef07;
    fcn.180224990(uVar1, 0x1804e7910, 0x26);
    *param_1 = 0;
    return;
}

// ============================================================
// Function: FUN_18026ef30
// Address: 0x18026ef30
// Size: 78 bytes
// ============================================================
undefined8 fcn.18026ef30(int64_t arg_48h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    uint64_t **in_RCX;
    undefined8 in_RDX;
    uint64_t uVar5;
    undefined8 uVar6;
    int64_t in_R9;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 0;
    uVar5 = **in_RCX;
    if (((*(uint32_t *)(in_R9 + 0x20) & 1) != 0) && (uVar5 == 0)) {
        return 0xffffffff;
    }
    if (((*(uint32_t *)(in_R9 + 0x20) & 2) != 0) && ((int64_t)uVar5 < 0)) {
        uVar5 = -uVar5;
        uVar6 = 1;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x180260a9a;
    iVar1 = fcn.18045a350(in_RDX, uVar5, uVar6);
    iVar1 = -iVar1;
    *(uint64_t *)((int64_t)&arg_58h + iVar1 + iVar3) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000028 + iVar1 + iVar3);
    *(undefined8 *)((int64_t)&arg_48h + iVar1 + iVar3) = in_RDX;
    iVar2 = 8;
    puVar4 = (undefined *)((int64_t)&arg_58h + iVar1 + iVar3);
    do {
        puVar4 = puVar4 + -1;
        iVar2 = iVar2 + -1;
        *puVar4 = (char)uVar5;
        uVar5 = uVar5 >> 8;
    } while (uVar5 != 0);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x180260ae1;
    fcn.180260680(puVar4, 8 - iVar2);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x180260aee;
    uVar6 = fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar1 + iVar3) ^
                          (uint64_t)(&stack0x00000028 + iVar1 + iVar3));
    return uVar6;
}

// ============================================================
// Function: FUN_18026ef80
// Address: 0x18026ef80
// Size: 337 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18026ef80(uint64_t **placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h
             , int64_t arg_78h, int64_t arg_a0h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t *puVar3;
    uint64_t uVar4;
    uint64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026ef9a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar3 = *placeholder_0;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
    *(undefined4 *)((int64_t)&arg_38h + iVar2) = 0;
    if (puVar3 == (uint64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026efcd;
        puVar3 = (uint64_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar2));
        *placeholder_0 = puVar3;
        if (puVar3 == (uint64_t *)0x0) {
            return 0;
        }
        uVar4 = *(uint64_t *)((int64_t)&var_18h + iVar2);
    }
    if ((int32_t)in_R8 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026effc;
        iVar1 = func_0x000180260910((int64_t)&var_18h + iVar2, (int64_t)&arg_38h + iVar2, (int64_t)&arg_40h + iVar2, 
                                    in_R8 & 0xffffffff);
        if (iVar1 == 0) {
            return 0;
        }
        if ((*(uint8_t *)(*(int64_t *)(&stack0x00000060 + iVar2) + 0x20) & 2) == 0) {
            if (*(int32_t *)((int64_t)&arg_38h + iVar2) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f017;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f02f;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f041;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                return 0;
            }
            uVar4 = *(uint64_t *)((int64_t)&var_18h + iVar2);
        } else {
            uVar4 = *(uint64_t *)((int64_t)&var_18h + iVar2);
            if (*(int32_t *)((int64_t)&arg_38h + iVar2) == 0) {
                if (0x7fffffffffffffff < uVar4) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f07a;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f092;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                  *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar2));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f0a4;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                    return 0;
                }
            } else {
                uVar4 = -uVar4;
            }
        }
    }
    *puVar3 = uVar4;
    return 1;
}

// ============================================================
// Function: FUN_18026f0e0
// Address: 0x18026f0e0
// Size: 49 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_890h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8c0h because it doesn't fit into ProtoModel

void fcn.18026f0e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_90h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 in_RCX;
    undefined8 *in_RDX;
    undefined8 uVar7;
    undefined8 unaff_RBX;
    int64_t in_R8;
    undefined8 in_R9;
    undefined8 uStackX_18;
    undefined8 uStackX_20;
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar7 = 0x1804e7934;
    uVar3 = *(undefined8 *)*in_RDX;
    if ((*(uint8_t *)(in_R8 + 0x20) & 2) == 0) {
        uVar7 = 0x1804e793c;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = uVar7;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = uVar3;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = in_R9;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6) = 0x180245e8a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)(&stack0x00000890 + iVar5 + iVar6) = *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_20 + iVar5 + iVar6;
    *(undefined8 *)((int64_t)&arg_78h + iVar5 + iVar6) = 0x800;
    *(undefined8 *)((int64_t)&arg_60h + iVar5 + iVar6) = 0;
    *(undefined **)((int64_t)&arg_50h + iVar5 + iVar6) = &stack0x000008c0 + iVar5 + iVar6;
    *(undefined8 *)((int64_t)&arg_48h + iVar5 + iVar6) = uVar7;
    *(int64_t *)((int64_t)&arg_80h + iVar5 + iVar6) = (int64_t)&arg_90h + iVar5 + iVar6;
    *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar6) = (int64_t)&arg_70h + iVar5 + iVar6;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + iVar6) = 0x180245ef3;
    iVar4 = func_0x000180246150((int64_t)&arg_80h + iVar5 + iVar6, (int64_t)&arg_60h + iVar5 + iVar6, 
                                (int64_t)&arg_78h + iVar5 + iVar6, (int64_t)&arg_68h + iVar5 + iVar6);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + iVar6) = 0x180245f0e;
        fcn.180224990(*(undefined8 *)((int64_t)&arg_60h + iVar5 + iVar6), 0x1804e4250, 0x435);
    } else {
        iVar2 = *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar6);
        uVar1 = *(undefined4 *)((int64_t)&arg_68h + iVar5 + iVar6);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + iVar6) = 0x180245f51;
            func_0x00018021b2c0(in_RCX, (int64_t)&arg_90h + iVar5 + iVar6, uVar1);
        } else {
            *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + iVar6) = 0x180245f2c;
            func_0x00018021b2c0(in_RCX, iVar2, uVar1);
            *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + iVar6) = 0x180245f45;
            fcn.180224990(*(undefined8 *)((int64_t)&arg_60h + iVar5 + iVar6), 0x1804e4250, 0x43a);
        }
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + iVar6) = 0x180245f65;
    fcn.180459870(*(uint64_t *)(&stack0x00000890 + iVar5 + iVar6) ^ (int64_t)&uStackX_20 + iVar5 + iVar6);
    return;
}

// ============================================================
// Function: FUN_18026f120
// Address: 0x18026f120
// Size: 60 bytes
// ============================================================
bool fcn.18026f120(int64_t *param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026f12c;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x18026f149;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + -iVar1));
    *param_1 = iVar1;
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_18026f160
// Address: 0x18026f160
// Size: 52 bytes
// ============================================================
void fcn.18026f160(undefined8 *param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026f16c;
    iVar2 = fcn.18045a350();
    uVar1 = *param_1;
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x18026f187;
    fcn.180224990(uVar1, 0x1804e7910, 0x83);
    *param_1 = 0;
    return;
}

// ============================================================
// Function: FUN_18026f1b0
// Address: 0x18026f1b0
// Size: 76 bytes
// ============================================================
undefined8 fcn.18026f1b0(uint32_t **param_1, undefined8 param_2, undefined8 param_3, int64_t param_4)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    undefined *puVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar7 = 0;
    uVar4 = **param_1;
    if (((*(uint32_t *)(param_4 + 0x20) & 1) != 0) && (uVar4 == 0)) {
        return 0xffffffff;
    }
    if (((*(uint32_t *)(param_4 + 0x20) & 2) != 0) && ((int32_t)uVar4 < 0)) {
        uVar4 = -uVar4;
        uVar7 = 1;
    }
    uVar6 = (uint64_t)uVar4;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x180260a9a;
    iVar1 = fcn.18045a350(param_2, uVar6, uVar7);
    iVar1 = -iVar1;
    *(uint64_t *)(&stack0x00000058 + iVar1 + iVar3) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000028 + iVar1 + iVar3);
    *(undefined8 *)(&stack0x00000048 + iVar1 + iVar3) = param_2;
    iVar2 = 8;
    puVar5 = &stack0x00000058 + iVar1 + iVar3;
    do {
        puVar5 = puVar5 + -1;
        iVar2 = iVar2 + -1;
        *puVar5 = (char)uVar6;
        uVar6 = uVar6 >> 8;
    } while (uVar6 != 0);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x180260ae1;
    fcn.180260680(puVar5, 8 - iVar2);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x180260aee;
    uVar7 = fcn.180459870(*(uint64_t *)(&stack0x00000058 + iVar1 + iVar3) ^ (uint64_t)(&stack0x00000028 + iVar1 + iVar3)
                         );
    return uVar7;
}

// ============================================================
// Function: FUN_18026f200
// Address: 0x18026f200
// Size: 412 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18026f200(int32_t **placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_78h, int64_t arg_a0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    uint64_t uVar4;
    uint64_t in_R8;
    bool bVar5;
    bool bVar6;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026f21a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar3 = *placeholder_0;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
    iVar1 = 0;
    *(undefined4 *)((int64_t)&arg_38h + iVar2) = 0;
    if (piVar3 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f24d;
        piVar3 = (int32_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar2));
        *placeholder_0 = piVar3;
        if (piVar3 == (int32_t *)0x0) {
            return 0;
        }
        iVar1 = (int32_t)*(undefined8 *)((int64_t)&var_18h + iVar2);
    }
    if ((int32_t)in_R8 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f27c;
        iVar1 = func_0x000180260910((int64_t)&var_18h + iVar2, (int64_t)&arg_38h + iVar2, (int64_t)&arg_40h + iVar2, 
                                    in_R8 & 0xffffffff);
        if (iVar1 == 0) {
            return 0;
        }
        if ((*(uint8_t *)(*(int64_t *)(&stack0x00000060 + iVar2) + 0x20) & 2) == 0) {
            if (*(int32_t *)((int64_t)&arg_38h + iVar2) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f297;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f2af;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f2c1;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                return 0;
            }
            uVar4 = *(uint64_t *)((int64_t)&var_18h + iVar2);
            bVar5 = uVar4 < 0xffffffff;
            bVar6 = uVar4 == 0xffffffff;
        } else {
            uVar4 = *(uint64_t *)((int64_t)&var_18h + iVar2);
            if (*(int32_t *)((int64_t)&arg_38h + iVar2) != 0) {
                if (0x80000000 < uVar4) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f2fd;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f315;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                  *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar2));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f327;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                    return 0;
                }
                iVar1 = -(int32_t)uVar4;
                goto code_r0x00018026f33c;
            }
            bVar5 = uVar4 < 0x7fffffff;
            bVar6 = uVar4 == 0x7fffffff;
        }
        iVar1 = (int32_t)uVar4;
        if (!bVar5 && !bVar6) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f360;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f378;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)((int64_t)&arg_48h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f38a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
            return 0;
        }
    }
code_r0x00018026f33c:
    *piVar3 = iVar1;
    return 1;
}

// ============================================================
// Function: FUN_18026f3a0
// Address: 0x18026f3a0
// Size: 49 bytes
// ============================================================
void fcn.18026f3a0(undefined8 param_1, uint32_t **param_2, int64_t param_3, undefined8 param_4)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_18;
    undefined8 uStackX_20;
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = 0x1804e7954;
    uVar1 = **param_2;
    if ((*(uint8_t *)(param_3 + 0x20) & 2) == 0) {
        uVar5 = 0x1804e7958;
    }
    *(undefined8 *)(&stack0x00000038 + iVar4) = uVar5;
    *(uint64_t *)(&stack0x00000040 + iVar4) = (uint64_t)uVar1;
    *(undefined8 *)(&stack0x00000048 + iVar4) = param_4;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar4) = 0x180245e8a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000890 + iVar3 + iVar4) = *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_20 + iVar3 + iVar4;
    *(undefined8 *)(&stack0x00000078 + iVar3 + iVar4) = 0x800;
    *(undefined8 *)(&stack0x00000060 + iVar3 + iVar4) = 0;
    *(undefined **)(&stack0x00000050 + iVar3 + iVar4) = &stack0x000008c0 + iVar3 + iVar4;
    *(undefined8 *)(&stack0x00000048 + iVar3 + iVar4) = uVar5;
    *(undefined **)(&stack0x00000080 + iVar3 + iVar4) = &stack0x00000090 + iVar3 + iVar4;
    *(undefined **)(&stack0x00000040 + iVar3 + iVar4) = &stack0x00000070 + iVar3 + iVar4;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar4) = 0x180245ef3;
    iVar2 = func_0x000180246150(&stack0x00000080 + iVar3 + iVar4, &stack0x00000060 + iVar3 + iVar4, 
                                &stack0x00000078 + iVar3 + iVar4, &stack0x00000068 + iVar3 + iVar4);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar4) = 0x180245f0e;
        fcn.180224990(*(undefined8 *)(&stack0x00000060 + iVar3 + iVar4), 0x1804e4250, 0x435);
    } else if (*(int64_t *)(&stack0x00000060 + iVar3 + iVar4) == 0) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar4) = 0x180245f51;
        func_0x00018021b2c0(param_1, &stack0x00000090 + iVar3 + iVar4, *(undefined4 *)(&stack0x00000068 + iVar3 + iVar4)
                           );
    } else {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar4) = 0x180245f2c;
        func_0x00018021b2c0(param_1, *(int64_t *)(&stack0x00000060 + iVar3 + iVar4), 
                            *(undefined4 *)(&stack0x00000068 + iVar3 + iVar4));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar4) = 0x180245f45;
        fcn.180224990(*(undefined8 *)(&stack0x00000060 + iVar3 + iVar4), 0x1804e4250, 0x43a);
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar4) = 0x180245f65;
    fcn.180459870(*(uint64_t *)(&stack0x00000890 + iVar3 + iVar4) ^ (int64_t)&uStackX_20 + iVar3 + iVar4);
    return;
}

// ============================================================
// Function: FUN_18026f440
// Address: 0x18026f440
// Size: 104 bytes
// ============================================================
void fcn.18026f440(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18026f450;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        pcVar1 = *(code **)(arg1 + 0x28);
        if (pcVar1 != (code *)0x0) {
            uVar2 = *(undefined8 *)(arg1 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026f465;
            (*pcVar1)(uVar2);
        }
        uVar2 = *(undefined8 *)(arg1 + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026f475;
        fcn.180222290(uVar2, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026f484;
        fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026f48d;
        fcn.1802b4460(arg1 + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026f4a2;
        fcn.180224990(arg1, 0x1804e7960, 0x2a8);
    }
    return;
}

// ============================================================
// Function: FUN_18026f4b0
// Address: 0x18026f4b0
// Size: 40 bytes
// ============================================================
int64_t fcn.18026f4b0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = 0x70;
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x180224d70;
    iVar1 = fcn.18045a350(0x70, 0x1804e7960, 0x27c);
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224d7b;
    iVar2 = fcn.1802248d0(*(int64_t *)(&stack0x00000040 + iVar1 + iVar3), *(int64_t *)(&stack0x00000048 + iVar1 + iVar3)
                         );
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224d90;
        fcn.1804986e0(iVar2, 0, uVar4);
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18026f4e0
// Address: 0x18026f4e0
// Size: 105 bytes
// ============================================================
undefined8 fcn.18026f4e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_88h, int64_t arg_98h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar9;
    undefined8 unaff_RDI;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    
    uStack_20 = 0x18026f4f0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 1;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f55d;
            iVar2 = fcn.1802705e0();
            iVar8 = 0;
            if (0 < iVar2) {
                *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
                *(undefined8 *)((int64_t)&var_8h + iVar4) = unaff_R14;
                do {
                    uVar5 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f57e;
                    uVar5 = fcn.180222340(uVar5, iVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f589;
                    iVar6 = fcn.18020e940(uVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f594;
                    iVar7 = fcn.180247880(uVar5);
                    if ((iVar7 != 0) && (pcVar1 = *(code **)(iVar6 + 0x50), pcVar1 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f5aa;
                        iVar3 = (*pcVar1)(iVar7, in_RDX);
                        if (iVar3 == 0) {
                            uVar9 = 0;
                        }
                    }
                    iVar8 = iVar8 + 1;
                } while (iVar8 < iVar2);
            }
        }
        return uVar9;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f508;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f520;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f532;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18026f549
// Address: 0x18026f549
// Size: 32 bytes
// ============================================================
undefined8 fcn.18026f4e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_88h, int64_t arg_98h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar9;
    undefined8 unaff_RDI;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    
    uStack_20 = 0x18026f4f0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 1;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f55d;
            iVar2 = fcn.1802705e0();
            iVar8 = 0;
            if (0 < iVar2) {
                *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
                *(undefined8 *)((int64_t)&var_8h + iVar4) = unaff_R14;
                do {
                    uVar5 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f57e;
                    uVar5 = fcn.180222340(uVar5, iVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f589;
                    iVar6 = fcn.18020e940(uVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f594;
                    iVar7 = fcn.180247880(uVar5);
                    if ((iVar7 != 0) && (pcVar1 = *(code **)(iVar6 + 0x50), pcVar1 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f5aa;
                        iVar3 = (*pcVar1)(iVar7, in_RDX);
                        if (iVar3 == 0) {
                            uVar9 = 0;
                        }
                    }
                    iVar8 = iVar8 + 1;
                } while (iVar8 < iVar2);
            }
        }
        return uVar9;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f508;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f520;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f532;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18026f569
// Address: 0x18026f569
// Size: 87 bytes
// ============================================================
undefined8 fcn.18026f4e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_88h, int64_t arg_98h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar9;
    undefined8 unaff_RDI;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    
    uStack_20 = 0x18026f4f0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 1;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f55d;
            iVar2 = fcn.1802705e0();
            iVar8 = 0;
            if (0 < iVar2) {
                *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
                *(undefined8 *)((int64_t)&var_8h + iVar4) = unaff_R14;
                do {
                    uVar5 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f57e;
                    uVar5 = fcn.180222340(uVar5, iVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f589;
                    iVar6 = fcn.18020e940(uVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f594;
                    iVar7 = fcn.180247880(uVar5);
                    if ((iVar7 != 0) && (pcVar1 = *(code **)(iVar6 + 0x50), pcVar1 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f5aa;
                        iVar3 = (*pcVar1)(iVar7, in_RDX);
                        if (iVar3 == 0) {
                            uVar9 = 0;
                        }
                    }
                    iVar8 = iVar8 + 1;
                } while (iVar8 < iVar2);
            }
        }
        return uVar9;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f508;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f520;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f532;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18026f5c0
// Address: 0x18026f5c0
// Size: 15 bytes
// ============================================================
undefined8 fcn.18026f4e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_88h, int64_t arg_98h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar9;
    undefined8 unaff_RDI;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    
    uStack_20 = 0x18026f4f0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 1;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f55d;
            iVar2 = fcn.1802705e0();
            iVar8 = 0;
            if (0 < iVar2) {
                *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
                *(undefined8 *)((int64_t)&var_8h + iVar4) = unaff_R14;
                do {
                    uVar5 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f57e;
                    uVar5 = fcn.180222340(uVar5, iVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f589;
                    iVar6 = fcn.18020e940(uVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f594;
                    iVar7 = fcn.180247880(uVar5);
                    if ((iVar7 != 0) && (pcVar1 = *(code **)(iVar6 + 0x50), pcVar1 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f5aa;
                        iVar3 = (*pcVar1)(iVar7, in_RDX);
                        if (iVar3 == 0) {
                            uVar9 = 0;
                        }
                    }
                    iVar8 = iVar8 + 1;
                } while (iVar8 < iVar2);
            }
        }
        return uVar9;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f508;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f520;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f532;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18026f5cf
// Address: 0x18026f5cf
// Size: 12 bytes
// ============================================================
undefined8 fcn.18026f4e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_88h, int64_t arg_98h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar9;
    undefined8 unaff_RDI;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    
    uStack_20 = 0x18026f4f0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 1;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f55d;
            iVar2 = fcn.1802705e0();
            iVar8 = 0;
            if (0 < iVar2) {
                *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
                *(undefined8 *)((int64_t)&var_8h + iVar4) = unaff_R14;
                do {
                    uVar5 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f57e;
                    uVar5 = fcn.180222340(uVar5, iVar8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f589;
                    iVar6 = fcn.18020e940(uVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f594;
                    iVar7 = fcn.180247880(uVar5);
                    if ((iVar7 != 0) && (pcVar1 = *(code **)(iVar6 + 0x50), pcVar1 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f5aa;
                        iVar3 = (*pcVar1)(iVar7, in_RDX);
                        if (iVar3 == 0) {
                            uVar9 = 0;
                        }
                    }
                    iVar8 = iVar8 + 1;
                } while (iVar8 < iVar2);
            }
        }
        return uVar9;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f508;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f520;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f532;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18026f5e0
// Address: 0x18026f5e0
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18026f5e0(int64_t arg_28h, int64_t arg_48h, int64_t arg_68h, int64_t arg_70h, int64_t arg_88h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026f5f5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026f61e;
    func_0x00018026fa20((int64_t)&arg_28h + iVar1, 0, 0);
    *(undefined8 *)((int64_t)&var_18h + iVar1) = in_RDX;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R8;
    if (*(int64_t *)((int64_t)&arg_48h + iVar1) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026f643;
        func_0x0001802bd670(*(int64_t *)((int64_t)&arg_48h + iVar1), 0x18026f8f0, (int64_t)&var_18h + iVar1);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026f650;
    uVar2 = func_0x000180245b40(in_RCX, 0xb);
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026f664;
    func_0x0001802bd670(uVar2, 0x18026f8f0, (int64_t)&var_18h + iVar1);
    if (*(int64_t *)((int64_t)&arg_48h + iVar1) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026f673;
        func_0x0001802bda10();
    }
    return;
}

// ============================================================
// Function: FUN_18026f690
// Address: 0x18026f690
// Size: 103 bytes
// ============================================================
void fcn.18026f690(int64_t arg1)
{
    undefined8 *puVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18026f6a0;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        puVar1 = (undefined8 *)(arg1 + 0x28);
        iVar2 = *(int32_t *)puVar1;
        *(int32_t *)puVar1 = *(int32_t *)puVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026f6cb;
            fcn.180224990(uVar3, 0x1804e7960, 0x46);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026f6d4;
            fcn.1802bb640(uVar3);
            uVar3 = *(undefined8 *)arg1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026f6dc;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026f6f1;
            fcn.180224990(arg1, 0x1804e7960, 0x4a);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18026f700
// Address: 0x18026f700
// Size: 85 bytes
// ============================================================
undefined8 fcn.18026f700(int64_t param_1)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026f70a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026f717;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026f72f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026f741;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    return *(undefined8 *)(*(int64_t *)(param_1 + 0x18) + 8);
}

// ============================================================
// Function: FUN_18026f760
// Address: 0x18026f760
// Size: 80 bytes
// ============================================================
undefined8 fcn.18026f760(undefined8 *param_1)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026f76a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026f777;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026f78f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026f7a1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    return *param_1;
}

// ============================================================
// Function: FUN_18026f7b0
// Address: 0x18026f7b0
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18026f7b0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026f7c0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*in_RCX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f7d6;
        fcn.18027f1e0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f7de;
        fcn.180299670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x000000a8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026f7e9;
        iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
        return iVar1 == *(int32_t *)(in_RCX + 1);
    }
    return false;
}

// ============================================================
// Function: FUN_18026f810
// Address: 0x18026f810
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18026f810(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026f825;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026f839;
    fcn.18027f1e0(in_RDX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026f841;
    uVar4 = fcn.180299670(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3), 
                          *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar3));
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026f851;
    iVar2 = func_0x0001802990b0(uVar4, 0, uVar1, 0x3a);
    iVar5 = 0;
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026f864;
        iVar5 = func_0x00018026fd90(iVar2, in_RCX, in_RDX);
        if (iVar5 != 0) {
            return iVar5;
        }
    }
    *(uint32_t *)(in_R8 + 0x28) = *(uint32_t *)(in_R8 + 0x28) | 1;
    return iVar5;
}

// ============================================================
// Function: FUN_18026f880
// Address: 0x18026f880
// Size: 103 bytes
// ============================================================
void fcn.18026f880(int64_t arg1)
{
    undefined8 *puVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18026f890;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        puVar1 = (undefined8 *)(arg1 + 0x28);
        iVar2 = *(int32_t *)puVar1;
        *(int32_t *)puVar1 = *(int32_t *)puVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026f8bb;
            fcn.180224990(uVar3, 0x1804e7960, 0x46);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026f8c4;
            fcn.1802bb640(uVar3);
            uVar3 = *(undefined8 *)arg1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026f8cc;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026f8e1;
            fcn.180224990(arg1, 0x1804e7960, 0x4a);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18026f8f0
// Address: 0x18026f8f0
// Size: 30 bytes
// ============================================================
void fcn.18026f8f0(undefined8 param_1, undefined8 param_2, code **param_3)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x00018026f90b. Too many branches
    // WARNING: Treating indirect jump as call
    (**param_3)(param_2, param_3[1]);
    return;
}

// ============================================================
// Function: FUN_18026f910
// Address: 0x18026f910
// Size: 220 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18026f910(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    
    uStack_20 = 0x18026f928;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar3 = *(int32_t *)(in_R8 + 1);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
    if (iVar3 == 0) {
        if (in_R8[2] == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f958;
        iVar5 = fcn.180299670(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)((int64_t)&arg_38h + iVar4), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4), 
                              *(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)(&stack0x00000098 + iVar4));
        iVar1 = in_R8[2];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f96c;
        iVar6 = func_0x00018045b928(iVar1, 0x3a);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f979;
            iVar6 = func_0x000180498cd0(iVar1);
        } else {
            iVar6 = iVar6 - iVar1;
        }
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f991;
        iVar3 = func_0x0001802994d0(iVar5, iVar1, iVar6);
        if (iVar3 == 0) {
            return 0;
        }
    }
    if (in_RCX == 0) {
        uVar2 = *in_R8;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f9a9;
        in_RCX = fcn.180245b40(uVar2, 0xb);
        if (in_RCX == 0) {
            return 0;
        }
    }
    uVar2 = in_R8[3];
    *(int64_t *)((int64_t)&var_8h + iVar4) = (int64_t)&arg_48h + iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026f9cc;
    iVar3 = func_0x0001802bd7a0(in_RCX, iVar3, uVar2, in_RDX);
    if (iVar3 == 0) {
        return 0;
    }
    return *(undefined8 *)((int64_t)&arg_48h + iVar4);
}

// ============================================================
// Function: FUN_18026f9f0
// Address: 0x18026f9f0
// Size: 45 bytes
// ============================================================
void fcn.18026f9f0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026f9fc;
    iVar1 = fcn.18045a350();
    if (*(int64_t *)(param_1 + 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x18026fa13;
        uVar2 = fcn.1802bda80(*(int64_t *)((int64_t)aiStackX_18 + -iVar1));
        *(undefined8 *)(param_1 + 0x20) = uVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18026fa20
// Address: 0x18026fa20
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18026fa20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t in_R8;
    int64_t iVar8;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_8h;
    
    uStack_38 = 0x18026fa35;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fa4e;
    iVar5 = fcn.180245b40(uVar1, 0xb);
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fa59;
    iVar6 = fcn.180299670(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000080 + iVar4));
    *(undefined8 *)((int64_t)&arg_a0h + iVar4) = 0;
    iVar8 = 0x1805aadb1;
    if (in_R8 != 0) {
        iVar8 = in_R8;
    }
    if ((iVar5 == 0) || (iVar6 == 0)) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fca2;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fcba;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&iStackX_8 + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fccc;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RDI;
    if (in_RDX == 0) {
        iVar2 = 0;
code_r0x00018026fade:
        uVar1 = *in_RCX;
        *(uint32_t *)(in_RCX + 5) = *(uint32_t *)(in_RCX + 5) & 0xfffffffe;
        *(code **)((int64_t)&var_10h + iVar4) = fcn.18026f9f0;
        *(undefined8 **)((int64_t)&var_8h + iVar4) = in_RCX;
        *(undefined8 *)((int64_t)&var_18h + iVar4) = 0x1802702b0;
        *(undefined8 *)((int64_t)&arg_90h + iVar4) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar4) = 0x1802702f0;
        *(code **)((int64_t)&arg_28h + iVar4) = fcn.18026f910;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0x1802701c0;
        *(code **)((int64_t)&arg_38h + iVar4) = fcn.18026f810;
        *(code **)((int64_t)&arg_40h + iVar4) = fcn.18026f880;
        *(int64_t *)(&stack0xfffffffffffffff0 + iVar4) = (int64_t)&var_10h + iVar4;
        *(int32_t *)(in_RCX + 1) = iVar2;
        in_RCX[2] = in_RDX;
        in_RCX[3] = iVar8;
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fb76;
        iVar7 = func_0x0001802e19f0(uVar1, 0x15, (int64_t)&arg_90h + iVar4, 0);
        *(int64_t *)((int64_t)&arg_a0h + iVar4) = iVar7;
        if (iVar7 != 0) {
            if (iVar2 == 0) {
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fb97;
                    iVar2 = fcn.1802993f0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                          *(int64_t *)(&stack0x00000000 + iVar4), 
                                          *(int64_t *)((int64_t)&var_10h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000058 + iVar4));
                    if (iVar2 != 0) goto code_r0x00018026fb9d;
                }
            } else {
code_r0x00018026fb9d:
                *(code **)(&stack0x00000000 + iVar4) = fcn.18026f880;
                *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x180257ae0;
                *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4) = *(undefined8 *)((int64_t)&arg_a0h + iVar4);
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fbd8;
                func_0x0001802bd400(iVar5, *(undefined8 *)((int64_t)&arg_90h + iVar4), iVar2, iVar8);
            }
        }
        if ((iVar2 == 0) && (in_RDX == 0)) goto code_r0x00018026fc73;
    } else {
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026faa8;
        iVar2 = fcn.1802993f0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) goto code_r0x00018026fade;
        *(int64_t *)(&stack0xfffffffffffffff0 + iVar4) = (int64_t)&arg_a0h + iVar4;
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fad3;
        iVar3 = func_0x0001802bd330(iVar5, 0, iVar2, iVar8);
        if (iVar3 == 0) goto code_r0x00018026fade;
    }
    if (*(int64_t *)((int64_t)&arg_a0h + iVar4) == 0) {
        if (in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc0e;
            in_RDX = func_0x0001802995f0(iVar6, iVar2, 0);
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc16;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc2e;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&iStackX_8 + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        uVar1 = *in_RCX;
        if (in_R8 == 0) {
            in_R8 = 0x1804e79c4;
        }
        if (in_RDX == 0) {
            in_RDX = 0x1804e79c4;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc4b;
        func_0x000180245ce0(uVar1);
        *(int64_t *)(&stack0x00000000 + iVar4) = in_R8;
        *(int32_t *)((int64_t)&var_8h + iVar4) = iVar2;
        *(int64_t *)(&stack0xfffffffffffffff0 + iVar4) = in_RDX;
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc73;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar4));
    }
code_r0x00018026fc73:
    return *(undefined8 *)((int64_t)&arg_a0h + iVar4);
}

// ============================================================
// Function: FUN_18026fa88
// Address: 0x18026fa88
// Size: 533 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18026fa20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t in_R8;
    int64_t iVar8;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_8h;
    
    uStack_38 = 0x18026fa35;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fa4e;
    iVar5 = fcn.180245b40(uVar1, 0xb);
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fa59;
    iVar6 = fcn.180299670(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000080 + iVar4));
    *(undefined8 *)((int64_t)&arg_a0h + iVar4) = 0;
    iVar8 = 0x1805aadb1;
    if (in_R8 != 0) {
        iVar8 = in_R8;
    }
    if ((iVar5 == 0) || (iVar6 == 0)) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fca2;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fcba;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&iStackX_8 + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fccc;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RDI;
    if (in_RDX == 0) {
        iVar2 = 0;
code_r0x00018026fade:
        uVar1 = *in_RCX;
        *(uint32_t *)(in_RCX + 5) = *(uint32_t *)(in_RCX + 5) & 0xfffffffe;
        *(code **)((int64_t)&var_10h + iVar4) = fcn.18026f9f0;
        *(undefined8 **)((int64_t)&var_8h + iVar4) = in_RCX;
        *(undefined8 *)((int64_t)&var_18h + iVar4) = 0x1802702b0;
        *(undefined8 *)((int64_t)&arg_90h + iVar4) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar4) = 0x1802702f0;
        *(code **)((int64_t)&arg_28h + iVar4) = fcn.18026f910;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0x1802701c0;
        *(code **)((int64_t)&arg_38h + iVar4) = fcn.18026f810;
        *(code **)((int64_t)&arg_40h + iVar4) = fcn.18026f880;
        *(int64_t *)(&stack0xfffffffffffffff0 + iVar4) = (int64_t)&var_10h + iVar4;
        *(int32_t *)(in_RCX + 1) = iVar2;
        in_RCX[2] = in_RDX;
        in_RCX[3] = iVar8;
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fb76;
        iVar7 = func_0x0001802e19f0(uVar1, 0x15, (int64_t)&arg_90h + iVar4, 0);
        *(int64_t *)((int64_t)&arg_a0h + iVar4) = iVar7;
        if (iVar7 != 0) {
            if (iVar2 == 0) {
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fb97;
                    iVar2 = fcn.1802993f0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                          *(int64_t *)(&stack0x00000000 + iVar4), 
                                          *(int64_t *)((int64_t)&var_10h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000058 + iVar4));
                    if (iVar2 != 0) goto code_r0x00018026fb9d;
                }
            } else {
code_r0x00018026fb9d:
                *(code **)(&stack0x00000000 + iVar4) = fcn.18026f880;
                *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x180257ae0;
                *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4) = *(undefined8 *)((int64_t)&arg_a0h + iVar4);
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fbd8;
                func_0x0001802bd400(iVar5, *(undefined8 *)((int64_t)&arg_90h + iVar4), iVar2, iVar8);
            }
        }
        if ((iVar2 == 0) && (in_RDX == 0)) goto code_r0x00018026fc73;
    } else {
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026faa8;
        iVar2 = fcn.1802993f0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) goto code_r0x00018026fade;
        *(int64_t *)(&stack0xfffffffffffffff0 + iVar4) = (int64_t)&arg_a0h + iVar4;
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fad3;
        iVar3 = func_0x0001802bd330(iVar5, 0, iVar2, iVar8);
        if (iVar3 == 0) goto code_r0x00018026fade;
    }
    if (*(int64_t *)((int64_t)&arg_a0h + iVar4) == 0) {
        if (in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc0e;
            in_RDX = func_0x0001802995f0(iVar6, iVar2, 0);
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc16;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc2e;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&iStackX_8 + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        uVar1 = *in_RCX;
        if (in_R8 == 0) {
            in_R8 = 0x1804e79c4;
        }
        if (in_RDX == 0) {
            in_RDX = 0x1804e79c4;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc4b;
        func_0x000180245ce0(uVar1);
        *(int64_t *)(&stack0x00000000 + iVar4) = in_R8;
        *(int32_t *)((int64_t)&var_8h + iVar4) = iVar2;
        *(int64_t *)(&stack0xfffffffffffffff0 + iVar4) = in_RDX;
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc73;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar4));
    }
code_r0x00018026fc73:
    return *(undefined8 *)((int64_t)&arg_a0h + iVar4);
}

// ============================================================
// Function: FUN_18026fc9d
// Address: 0x18026fc9d
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18026fa20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t in_R8;
    int64_t iVar8;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_8h;
    
    uStack_38 = 0x18026fa35;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fa4e;
    iVar5 = fcn.180245b40(uVar1, 0xb);
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fa59;
    iVar6 = fcn.180299670(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000080 + iVar4));
    *(undefined8 *)((int64_t)&arg_a0h + iVar4) = 0;
    iVar8 = 0x1805aadb1;
    if (in_R8 != 0) {
        iVar8 = in_R8;
    }
    if ((iVar5 == 0) || (iVar6 == 0)) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fca2;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fcba;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&iStackX_8 + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fccc;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RDI;
    if (in_RDX == 0) {
        iVar2 = 0;
code_r0x00018026fade:
        uVar1 = *in_RCX;
        *(uint32_t *)(in_RCX + 5) = *(uint32_t *)(in_RCX + 5) & 0xfffffffe;
        *(code **)((int64_t)&var_10h + iVar4) = fcn.18026f9f0;
        *(undefined8 **)((int64_t)&var_8h + iVar4) = in_RCX;
        *(undefined8 *)((int64_t)&var_18h + iVar4) = 0x1802702b0;
        *(undefined8 *)((int64_t)&arg_90h + iVar4) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar4) = 0x1802702f0;
        *(code **)((int64_t)&arg_28h + iVar4) = fcn.18026f910;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0x1802701c0;
        *(code **)((int64_t)&arg_38h + iVar4) = fcn.18026f810;
        *(code **)((int64_t)&arg_40h + iVar4) = fcn.18026f880;
        *(int64_t *)(&stack0xfffffffffffffff0 + iVar4) = (int64_t)&var_10h + iVar4;
        *(int32_t *)(in_RCX + 1) = iVar2;
        in_RCX[2] = in_RDX;
        in_RCX[3] = iVar8;
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fb76;
        iVar7 = func_0x0001802e19f0(uVar1, 0x15, (int64_t)&arg_90h + iVar4, 0);
        *(int64_t *)((int64_t)&arg_a0h + iVar4) = iVar7;
        if (iVar7 != 0) {
            if (iVar2 == 0) {
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fb97;
                    iVar2 = fcn.1802993f0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                          *(int64_t *)(&stack0x00000000 + iVar4), 
                                          *(int64_t *)((int64_t)&var_10h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000058 + iVar4));
                    if (iVar2 != 0) goto code_r0x00018026fb9d;
                }
            } else {
code_r0x00018026fb9d:
                *(code **)(&stack0x00000000 + iVar4) = fcn.18026f880;
                *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x180257ae0;
                *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4) = *(undefined8 *)((int64_t)&arg_a0h + iVar4);
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fbd8;
                func_0x0001802bd400(iVar5, *(undefined8 *)((int64_t)&arg_90h + iVar4), iVar2, iVar8);
            }
        }
        if ((iVar2 == 0) && (in_RDX == 0)) goto code_r0x00018026fc73;
    } else {
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026faa8;
        iVar2 = fcn.1802993f0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) goto code_r0x00018026fade;
        *(int64_t *)(&stack0xfffffffffffffff0 + iVar4) = (int64_t)&arg_a0h + iVar4;
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fad3;
        iVar3 = func_0x0001802bd330(iVar5, 0, iVar2, iVar8);
        if (iVar3 == 0) goto code_r0x00018026fade;
    }
    if (*(int64_t *)((int64_t)&arg_a0h + iVar4) == 0) {
        if (in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc0e;
            in_RDX = func_0x0001802995f0(iVar6, iVar2, 0);
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc16;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4));
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc2e;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&iStackX_8 + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4));
        uVar1 = *in_RCX;
        if (in_R8 == 0) {
            in_R8 = 0x1804e79c4;
        }
        if (in_RDX == 0) {
            in_RDX = 0x1804e79c4;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc4b;
        func_0x000180245ce0(uVar1);
        *(int64_t *)(&stack0x00000000 + iVar4) = in_R8;
        *(int32_t *)((int64_t)&var_8h + iVar4) = iVar2;
        *(int64_t *)(&stack0xfffffffffffffff0 + iVar4) = in_RDX;
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18026fc73;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar4));
    }
code_r0x00018026fc73:
    return *(undefined8 *)((int64_t)&arg_a0h + iVar4);
}

// ============================================================
// Function: FUN_18026fce0
// Address: 0x18026fce0
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18026fce0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 *in_RCX;
    int32_t *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026fcfa;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar2 = *in_R8;
    if (iVar2 < 1) {
        uVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026fd15;
        fcn.18027f1e0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026fd1d;
        fcn.180299670(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                      *(int64_t *)(&stack0x00000060 + iVar4), *(int64_t *)(&stack0x000000a8 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026fd28;
        iVar2 = fcn.1802993f0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                              *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4));
        *in_R8 = iVar2;
        if (iVar2 < 1) {
            return 0;
        }
    }
    if (in_RCX == (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026fd3a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026fd52;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026fd64;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        iVar3 = 0;
    } else {
        iVar3 = *(int32_t *)(in_RCX + 1);
    }
    if (iVar3 != iVar2) {
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_18026fd90
// Address: 0x18026fd90
// Size: 832 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t * fcn.18026fd90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined4 in_ECX;
    int64_t in_RDX;
    int64_t *piVar8;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18026fdae;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar1 = *(int32_t **)(in_RDX + 0x10);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026fdc5;
    uVar5 = fcn.18027f1e0(in_R8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026fddf;
    piVar6 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_8h + iVar4));
    if (piVar6 == (int64_t *)0x0) {
        return (int64_t *)0x0;
    }
    *(undefined4 *)(piVar6 + 5) = 1;
    *(undefined4 *)(piVar6 + 1) = in_ECX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026fdfd;
    iVar7 = func_0x000180282210(in_RDX);
    piVar6[2] = iVar7;
    if (iVar7 == 0) {
code_r0x00018026fe1f:
        LOCK();
        piVar8 = piVar6 + 5;
        iVar3 = *(int32_t *)piVar8;
        *(int32_t *)piVar8 = *(int32_t *)piVar8 + -1;
        UNLOCK();
        if (iVar3 < 2) {
            iVar7 = piVar6[2];
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026fe48;
            fcn.180224990(iVar7, 0x1804e7960, 0x46);
            iVar7 = piVar6[4];
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026fe51;
            fcn.1802bb640(iVar7);
            iVar7 = *piVar6;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026fe59;
            fcn.18027edb0(iVar7);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026fe6e;
            fcn.180224990(piVar6, 0x1804e7960, 0x4a);
        }
        return (int64_t *)0x0;
    }
    piVar6[3] = in_RDX;
    uVar2 = *(undefined8 *)(in_RDX + 8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026fe16;
    iVar7 = func_0x0001802bafa0(uVar5, uVar2);
    piVar6[4] = iVar7;
    if (iVar7 == 0) goto code_r0x00018026fe1f;
    iVar3 = *piVar1;
    if (iVar3 != 0) {
        piVar8 = (int64_t *)(piVar1 + 2);
        do {
    // switch table (20 cases) at 0x180270080
            switch(iVar3) {
            case 1:
                if (piVar6[6] == 0) {
                    piVar6[6] = *piVar8;
                }
                break;
            case 2:
                if (piVar6[7] == 0) {
                    piVar6[7] = *piVar8;
                }
                break;
            case 3:
                if (piVar6[8] == 0) {
                    piVar6[8] = *piVar8;
                }
                break;
            case 4:
                if (piVar6[9] == 0) {
                    piVar6[9] = *piVar8;
                }
                break;
            case 5:
                if (piVar6[10] == 0) {
                    piVar6[10] = *piVar8;
                }
                break;
            case 6:
                if (piVar6[0xb] == 0) {
                    piVar6[0xb] = *piVar8;
                }
                break;
            case 10:
                if (piVar6[0xc] == 0) {
                    piVar6[0xc] = *piVar8;
                }
                break;
            case 0xb:
                if (piVar6[0xd] == 0) {
                    piVar6[0xd] = *piVar8;
                }
                break;
            case 0x14:
                if (piVar6[0xe] == 0) {
                    piVar6[0xe] = *piVar8;
                }
            }
            iVar3 = *(int32_t *)(piVar8 + 1);
            piVar8 = piVar8 + 2;
        } while (iVar3 != 0);
    }
    if (piVar6[6] == 0) {
        if (piVar6[7] != 0) goto code_r0x00018026ff68;
    } else if (piVar6[7] == 0) goto code_r0x00018026ff68;
    if (piVar6[0xd] != 0) {
        if (in_R8 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18027001e;
            iVar3 = func_0x00018027fb30(in_R8);
            if (iVar3 == 0) {
                LOCK();
                piVar8 = piVar6 + 5;
                iVar3 = *(int32_t *)piVar8;
                *(int32_t *)piVar8 = *(int32_t *)piVar8 + -1;
                UNLOCK();
                if (1 < iVar3) {
                    return (int64_t *)0x0;
                }
                iVar7 = piVar6[2];
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180270047;
                fcn.180224990(iVar7, 0x1804e7960, 0x46);
                iVar7 = piVar6[4];
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180270050;
                fcn.1802bb640(iVar7);
                iVar7 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180270058;
                fcn.18027edb0(iVar7);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18027006d;
                fcn.180224990(piVar6, 0x1804e7960, 0x4a);
                return (int64_t *)0x0;
            }
        }
        *piVar6 = in_R8;
        return piVar6;
    }
code_r0x00018026ff68:
    LOCK();
    piVar8 = piVar6 + 5;
    iVar3 = *(int32_t *)piVar8;
    *(int32_t *)piVar8 = *(int32_t *)piVar8 + -1;
    UNLOCK();
    if (iVar3 < 2) {
        iVar7 = piVar6[2];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026ff8d;
        fcn.180224990(iVar7, 0x1804e7960, 0x46);
        iVar7 = piVar6[4];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026ff96;
        fcn.1802bb640(iVar7);
        iVar7 = *piVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026ff9e;
        fcn.18027edb0(iVar7);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026ffb3;
        fcn.180224990(piVar6, 0x1804e7960, 0x4a);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026ffb8;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026ffd0;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18026ffe2;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_1802700d0
// Address: 0x1802700d0
// Size: 81 bytes
// ============================================================
undefined8 fcn.1802700d0(int64_t param_1)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802700da;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802700e7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802700ff;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180270111;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    return *(undefined8 *)(param_1 + 0x20);
}

// ============================================================
// Function: FUN_180270130
// Address: 0x180270130
// Size: 50 bytes
// ============================================================
undefined8 fcn.180270130(void)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x18027013a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180270147;
    iVar4 = fcn.180245b40();
    if (iVar4 == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802bd2dc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (iVar4 != 0) {
        uVar1 = *(undefined8 *)(iVar4 + 0x10);
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3) = 0x1802bd2f0;
        iVar2 = fcn.180222950(uVar1);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3) = 0x1802bd304;
            fcn.1802e2f70(*(int64_t *)(&stack0x00000048 + iVar5 + iVar3));
            uVar1 = *(undefined8 *)(iVar4 + 0x10);
            *(undefined8 *)(iVar4 + 0x20) = 0;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3) = 0x1802bd315;
            fcn.180222910(uVar1);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180270170
// Address: 0x180270170
// Size: 68 bytes
// ============================================================
undefined8 fcn.180270170(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 in_RCX;
    undefined8 unaff_RDI;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18027017c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180270187;
    uVar3 = fcn.18027f1e0();
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180270194;
    iVar4 = fcn.180245b40(uVar3, 0xb);
    if (iVar4 == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = 0x1802bdb60;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (iVar4 != 0) {
        uVar3 = *(undefined8 *)(iVar4 + 0x10);
        *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar2) = 0x1802bdb77;
        iVar1 = fcn.180222950(uVar3);
        if (iVar1 != 0) {
            uVar3 = *(undefined8 *)(iVar4 + 8);
            *(undefined8 *)((int64_t)&arg_40h + iVar5 + iVar2) = in_RCX;
            *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar2) = iVar4;
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar2) = 0x1802bdb9a;
            fcn.1802e2fa0(uVar3, 0x1802bcb80, (int64_t)&arg_38h + iVar5 + iVar2);
            uVar3 = *(undefined8 *)(iVar4 + 0x10);
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar2) = 0x1802bdba3;
            fcn.180222910(uVar3);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802701c0
// Address: 0x1802701c0
// Size: 236 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1802701c0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802701de;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = 0;
    if (in_R9 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180270201;
        iVar4 = func_0x00018045b928(in_R9, 0x3a);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180270211;
            iVar4 = func_0x000180498cd0(in_R9);
        } else {
            iVar4 = iVar4 - in_R9;
        }
    }
    puVar1 = *(undefined8 **)((int64_t)&arg_70h + iVar3);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180270229;
    iVar5 = fcn.180299670(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                          *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                          *(int64_t *)((int64_t)&arg_50h + iVar3), *(int64_t *)(&stack0x00000098 + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18027023c;
        iVar2 = func_0x0001802994d0(iVar5, in_R9, iVar4);
        if (iVar2 != 0) {
            if (in_RCX == 0) {
                uVar6 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180270254;
                in_RCX = fcn.180245b40(uVar6, 0xb);
                if (in_RCX == 0) {
                    return 0;
                }
            }
            uVar6 = *(undefined8 *)((int64_t)&arg_68h + iVar3);
            *(code **)((int64_t)&iStackX_20 + iVar3 + -8) = fcn.18026f880;
            *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x180257ae0;
            *(undefined8 *)((int64_t)&var_8h + iVar3) = in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18027028f;
            uVar6 = func_0x0001802bcfd0(in_RCX, in_R8, iVar2, uVar6);
            return uVar6;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802702b0
// Address: 0x1802702b0
// Size: 59 bytes
// ============================================================
undefined8 fcn.1802702b0(int64_t param_1, undefined8 *param_2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802702ba;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == 0) {
        uVar1 = *param_2;
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802702d5;
        param_1 = fcn.180245b40(uVar1, 0xb);
        if (param_1 == 0) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802bcfaa;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_1 != 0) {
        iVar5 = *(int64_t *)(param_1 + 0x18);
        *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
        *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = 0x18022295c;
        iVar2 = fcn.18045a350();
        *(undefined8 *)(&stack0x00000040 + ((iVar4 + iVar3) - iVar2)) = 0x180222968;
        (*(code *)0x69a094)();
        *(undefined4 *)(iVar5 + 8) = 1;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1802702f0
// Address: 0x1802702f0
// Size: 59 bytes
// ============================================================
undefined8 fcn.1802702f0(int64_t param_1, undefined8 *param_2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802702fa;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == 0) {
        uVar1 = *param_2;
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180270315;
        param_1 = fcn.180245b40(uVar1, 0xb);
        if (param_1 == 0) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802bdbca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_1 != 0) {
        iVar5 = *(int64_t *)(param_1 + 0x18);
        *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = 0x18022291a;
        iVar2 = fcn.18045a350();
        if (*(int32_t *)(iVar5 + 8) != 0) {
            *(undefined4 *)(iVar5 + 8) = 0;
            *(undefined8 *)(&stack0x00000048 + -iVar2 + iVar4 + iVar3 + 0x20 + -0x20) = 0x180222930;
            (*(code *)0x69a062)();
            return 1;
        }
        *(undefined8 *)(&stack0x00000048 + -iVar2 + iVar4 + iVar3 + 0x20 + -0x20) = 0x180222940;
        (*(code *)0x69a07c)();
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180270330
// Address: 0x180270330
// Size: 206 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

undefined8 fcn.180270330(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar11;
    int64_t in_R8;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    undefined var_18h [4];
    int64_t var_1ch;
    undefined8 uStack_30;
    
    uStack_30 = 0x180270343;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar13 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027035f;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270377;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270389;
        fcn.1802296d0(*(int64_t *)(var_18h + iVar5));
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703bd;
    iVar6 = fcn.180221f20();
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703ca;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703e2;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703f4;
        fcn.1802296d0(*(int64_t *)(var_18h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270415;
    fcn.18026f5e0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(var_18h + iVar5), 
                  *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                  *(int64_t *)((int64_t)&arg_58h + iVar5));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027041d;
    iVar2 = fcn.180222010(iVar6);
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027042e;
        iVar7 = fcn.1802bce20(in_RDX, 0);
        if (iVar7 == 0) goto code_r0x000180270491;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_68h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270444;
    iVar3 = fcn.180222010(uVar8);
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270456;
    uVar8 = fcn.180222270(uVar8, 0x180271290);
    uVar12 = uVar13;
    if (0 < iVar3) {
        do {
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027046b;
            iVar7 = fcn.180222340(uVar1, uVar12);
            *(int32_t *)(iVar7 + 0x24) = (int32_t)uVar12;
            uVar10 = (int32_t)uVar12 + 1;
            uVar12 = (uint64_t)uVar10;
        } while ((int32_t)uVar10 < iVar3);
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027047d;
    fcn.1802222d0(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270489;
    fcn.180222270(uVar1, uVar8);
code_r0x000180270491:
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)(&stack0x00000000 + iVar5) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
    *(undefined8 *)(var_18h + iVar5 + -8) = 0;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802704ae;
    iVar3 = fcn.180222010(uVar8);
    *(int32_t *)(var_18h + iVar5 + -4) = iVar3;
    uVar12 = uVar13;
    do {
        *(int32_t *)((int64_t)&var_1ch + iVar5) = iVar3;
        *(undefined4 *)((int64_t)&var_8h + iVar5 + 4) = 0;
        *(int32_t *)(var_18h + iVar5) = iVar3;
        uVar9 = uVar13;
        do {
            iVar4 = (int32_t)uVar9;
            iVar11 = *(int32_t *)(var_18h + iVar5 + -8);
            if (iVar11 < iVar3) {
                do {
                    uVar8 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802704eb;
                    iVar7 = fcn.180222340(uVar8, iVar11);
                    uVar9 = uVar13;
                    if (iVar7 != 0) {
                        uVar9 = *(uint64_t *)(iVar7 + 0x10);
                    }
                    *(uint64_t *)(&stack0x00000000 + iVar5) = uVar9;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
                    uVar9 = uVar13;
                    if (0 < iVar2) {
                        do {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027051a;
                            fcn.180222340(iVar6, uVar9);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270527;
                            fcn.180270c10(*(int64_t *)(var_18h + iVar5), *(int64_t *)((int64_t)&var_1ch + iVar5 + 4), 
                                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5)
                                          , *(int64_t *)(&stack0x00000038 + iVar5), 
                                          *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000048 + iVar5)
                                          , *(int64_t *)(&stack0x00000050 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar5), 
                                          *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5)
                                          , *(int64_t *)(&stack0x00000088 + iVar5), 
                                          *(int64_t *)(&stack0x00000090 + iVar5));
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                        } while ((int32_t)uVar10 < iVar2);
                    }
                    iVar3 = *(int32_t *)(var_18h + iVar5 + -4);
                    iVar11 = iVar11 + 1;
                } while (iVar11 < iVar3);
                iVar4 = *(int32_t *)((int64_t)&var_8h + iVar5 + 4);
            }
            uVar10 = iVar4 + 1;
            uVar9 = (uint64_t)uVar10;
            *(uint32_t *)((int64_t)&var_8h + iVar5 + 4) = uVar10;
        } while ((int32_t)uVar10 < 2);
        uVar12 = uVar12 + 1;
        iVar3 = *(int32_t *)((int64_t)&var_1ch + iVar5);
        *(int32_t *)(var_18h + iVar5 + -8) = *(int32_t *)(var_18h + iVar5);
        *(int32_t *)(var_18h + iVar5 + -4) = iVar3;
    } while ((iVar3 != *(int32_t *)(var_18h + iVar5)) && (uVar12 < 0xb));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270576;
    fcn.180222290(iVar6, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270585;
    fcn.180222050(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                  *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                  *(int64_t *)(&stack0x00000030 + iVar5));
    return 1;
}

// ============================================================
// Function: FUN_1802703fe
// Address: 0x1802703fe
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

undefined8 fcn.180270330(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar11;
    int64_t in_R8;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    undefined var_18h [4];
    int64_t var_1ch;
    undefined8 uStack_30;
    
    uStack_30 = 0x180270343;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar13 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027035f;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270377;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270389;
        fcn.1802296d0(*(int64_t *)(var_18h + iVar5));
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703bd;
    iVar6 = fcn.180221f20();
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703ca;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703e2;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703f4;
        fcn.1802296d0(*(int64_t *)(var_18h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270415;
    fcn.18026f5e0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(var_18h + iVar5), 
                  *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                  *(int64_t *)((int64_t)&arg_58h + iVar5));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027041d;
    iVar2 = fcn.180222010(iVar6);
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027042e;
        iVar7 = fcn.1802bce20(in_RDX, 0);
        if (iVar7 == 0) goto code_r0x000180270491;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_68h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270444;
    iVar3 = fcn.180222010(uVar8);
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270456;
    uVar8 = fcn.180222270(uVar8, 0x180271290);
    uVar12 = uVar13;
    if (0 < iVar3) {
        do {
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027046b;
            iVar7 = fcn.180222340(uVar1, uVar12);
            *(int32_t *)(iVar7 + 0x24) = (int32_t)uVar12;
            uVar10 = (int32_t)uVar12 + 1;
            uVar12 = (uint64_t)uVar10;
        } while ((int32_t)uVar10 < iVar3);
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027047d;
    fcn.1802222d0(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270489;
    fcn.180222270(uVar1, uVar8);
code_r0x000180270491:
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)(&stack0x00000000 + iVar5) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
    *(undefined8 *)(var_18h + iVar5 + -8) = 0;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802704ae;
    iVar3 = fcn.180222010(uVar8);
    *(int32_t *)(var_18h + iVar5 + -4) = iVar3;
    uVar12 = uVar13;
    do {
        *(int32_t *)((int64_t)&var_1ch + iVar5) = iVar3;
        *(undefined4 *)((int64_t)&var_8h + iVar5 + 4) = 0;
        *(int32_t *)(var_18h + iVar5) = iVar3;
        uVar9 = uVar13;
        do {
            iVar4 = (int32_t)uVar9;
            iVar11 = *(int32_t *)(var_18h + iVar5 + -8);
            if (iVar11 < iVar3) {
                do {
                    uVar8 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802704eb;
                    iVar7 = fcn.180222340(uVar8, iVar11);
                    uVar9 = uVar13;
                    if (iVar7 != 0) {
                        uVar9 = *(uint64_t *)(iVar7 + 0x10);
                    }
                    *(uint64_t *)(&stack0x00000000 + iVar5) = uVar9;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
                    uVar9 = uVar13;
                    if (0 < iVar2) {
                        do {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027051a;
                            fcn.180222340(iVar6, uVar9);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270527;
                            fcn.180270c10(*(int64_t *)(var_18h + iVar5), *(int64_t *)((int64_t)&var_1ch + iVar5 + 4), 
                                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5)
                                          , *(int64_t *)(&stack0x00000038 + iVar5), 
                                          *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000048 + iVar5)
                                          , *(int64_t *)(&stack0x00000050 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar5), 
                                          *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5)
                                          , *(int64_t *)(&stack0x00000088 + iVar5), 
                                          *(int64_t *)(&stack0x00000090 + iVar5));
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                        } while ((int32_t)uVar10 < iVar2);
                    }
                    iVar3 = *(int32_t *)(var_18h + iVar5 + -4);
                    iVar11 = iVar11 + 1;
                } while (iVar11 < iVar3);
                iVar4 = *(int32_t *)((int64_t)&var_8h + iVar5 + 4);
            }
            uVar10 = iVar4 + 1;
            uVar9 = (uint64_t)uVar10;
            *(uint32_t *)((int64_t)&var_8h + iVar5 + 4) = uVar10;
        } while ((int32_t)uVar10 < 2);
        uVar12 = uVar12 + 1;
        iVar3 = *(int32_t *)((int64_t)&var_1ch + iVar5);
        *(int32_t *)(var_18h + iVar5 + -8) = *(int32_t *)(var_18h + iVar5);
        *(int32_t *)(var_18h + iVar5 + -4) = iVar3;
    } while ((iVar3 != *(int32_t *)(var_18h + iVar5)) && (uVar12 < 0xb));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270576;
    fcn.180222290(iVar6, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270585;
    fcn.180222050(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                  *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                  *(int64_t *)(&stack0x00000030 + iVar5));
    return 1;
}

// ============================================================
// Function: FUN_180270437
// Address: 0x180270437
// Size: 90 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

undefined8 fcn.180270330(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar11;
    int64_t in_R8;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    undefined var_18h [4];
    int64_t var_1ch;
    undefined8 uStack_30;
    
    uStack_30 = 0x180270343;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar13 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027035f;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270377;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270389;
        fcn.1802296d0(*(int64_t *)(var_18h + iVar5));
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703bd;
    iVar6 = fcn.180221f20();
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703ca;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703e2;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703f4;
        fcn.1802296d0(*(int64_t *)(var_18h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270415;
    fcn.18026f5e0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(var_18h + iVar5), 
                  *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                  *(int64_t *)((int64_t)&arg_58h + iVar5));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027041d;
    iVar2 = fcn.180222010(iVar6);
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027042e;
        iVar7 = fcn.1802bce20(in_RDX, 0);
        if (iVar7 == 0) goto code_r0x000180270491;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_68h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270444;
    iVar3 = fcn.180222010(uVar8);
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270456;
    uVar8 = fcn.180222270(uVar8, 0x180271290);
    uVar12 = uVar13;
    if (0 < iVar3) {
        do {
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027046b;
            iVar7 = fcn.180222340(uVar1, uVar12);
            *(int32_t *)(iVar7 + 0x24) = (int32_t)uVar12;
            uVar10 = (int32_t)uVar12 + 1;
            uVar12 = (uint64_t)uVar10;
        } while ((int32_t)uVar10 < iVar3);
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027047d;
    fcn.1802222d0(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270489;
    fcn.180222270(uVar1, uVar8);
code_r0x000180270491:
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)(&stack0x00000000 + iVar5) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
    *(undefined8 *)(var_18h + iVar5 + -8) = 0;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802704ae;
    iVar3 = fcn.180222010(uVar8);
    *(int32_t *)(var_18h + iVar5 + -4) = iVar3;
    uVar12 = uVar13;
    do {
        *(int32_t *)((int64_t)&var_1ch + iVar5) = iVar3;
        *(undefined4 *)((int64_t)&var_8h + iVar5 + 4) = 0;
        *(int32_t *)(var_18h + iVar5) = iVar3;
        uVar9 = uVar13;
        do {
            iVar4 = (int32_t)uVar9;
            iVar11 = *(int32_t *)(var_18h + iVar5 + -8);
            if (iVar11 < iVar3) {
                do {
                    uVar8 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802704eb;
                    iVar7 = fcn.180222340(uVar8, iVar11);
                    uVar9 = uVar13;
                    if (iVar7 != 0) {
                        uVar9 = *(uint64_t *)(iVar7 + 0x10);
                    }
                    *(uint64_t *)(&stack0x00000000 + iVar5) = uVar9;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
                    uVar9 = uVar13;
                    if (0 < iVar2) {
                        do {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027051a;
                            fcn.180222340(iVar6, uVar9);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270527;
                            fcn.180270c10(*(int64_t *)(var_18h + iVar5), *(int64_t *)((int64_t)&var_1ch + iVar5 + 4), 
                                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5)
                                          , *(int64_t *)(&stack0x00000038 + iVar5), 
                                          *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000048 + iVar5)
                                          , *(int64_t *)(&stack0x00000050 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar5), 
                                          *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5)
                                          , *(int64_t *)(&stack0x00000088 + iVar5), 
                                          *(int64_t *)(&stack0x00000090 + iVar5));
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                        } while ((int32_t)uVar10 < iVar2);
                    }
                    iVar3 = *(int32_t *)(var_18h + iVar5 + -4);
                    iVar11 = iVar11 + 1;
                } while (iVar11 < iVar3);
                iVar4 = *(int32_t *)((int64_t)&var_8h + iVar5 + 4);
            }
            uVar10 = iVar4 + 1;
            uVar9 = (uint64_t)uVar10;
            *(uint32_t *)((int64_t)&var_8h + iVar5 + 4) = uVar10;
        } while ((int32_t)uVar10 < 2);
        uVar12 = uVar12 + 1;
        iVar3 = *(int32_t *)((int64_t)&var_1ch + iVar5);
        *(int32_t *)(var_18h + iVar5 + -8) = *(int32_t *)(var_18h + iVar5);
        *(int32_t *)(var_18h + iVar5 + -4) = iVar3;
    } while ((iVar3 != *(int32_t *)(var_18h + iVar5)) && (uVar12 < 0xb));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270576;
    fcn.180222290(iVar6, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270585;
    fcn.180222050(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                  *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                  *(int64_t *)(&stack0x00000030 + iVar5));
    return 1;
}

// ============================================================
// Function: FUN_180270491
// Address: 0x180270491
// Size: 257 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

undefined8 fcn.180270330(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar11;
    int64_t in_R8;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    undefined var_18h [4];
    int64_t var_1ch;
    undefined8 uStack_30;
    
    uStack_30 = 0x180270343;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar13 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027035f;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270377;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270389;
        fcn.1802296d0(*(int64_t *)(var_18h + iVar5));
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703bd;
    iVar6 = fcn.180221f20();
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703ca;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703e2;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703f4;
        fcn.1802296d0(*(int64_t *)(var_18h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270415;
    fcn.18026f5e0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(var_18h + iVar5), 
                  *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                  *(int64_t *)((int64_t)&arg_58h + iVar5));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027041d;
    iVar2 = fcn.180222010(iVar6);
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027042e;
        iVar7 = fcn.1802bce20(in_RDX, 0);
        if (iVar7 == 0) goto code_r0x000180270491;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_68h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270444;
    iVar3 = fcn.180222010(uVar8);
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270456;
    uVar8 = fcn.180222270(uVar8, 0x180271290);
    uVar12 = uVar13;
    if (0 < iVar3) {
        do {
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027046b;
            iVar7 = fcn.180222340(uVar1, uVar12);
            *(int32_t *)(iVar7 + 0x24) = (int32_t)uVar12;
            uVar10 = (int32_t)uVar12 + 1;
            uVar12 = (uint64_t)uVar10;
        } while ((int32_t)uVar10 < iVar3);
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027047d;
    fcn.1802222d0(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270489;
    fcn.180222270(uVar1, uVar8);
code_r0x000180270491:
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)(&stack0x00000000 + iVar5) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
    *(undefined8 *)(var_18h + iVar5 + -8) = 0;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802704ae;
    iVar3 = fcn.180222010(uVar8);
    *(int32_t *)(var_18h + iVar5 + -4) = iVar3;
    uVar12 = uVar13;
    do {
        *(int32_t *)((int64_t)&var_1ch + iVar5) = iVar3;
        *(undefined4 *)((int64_t)&var_8h + iVar5 + 4) = 0;
        *(int32_t *)(var_18h + iVar5) = iVar3;
        uVar9 = uVar13;
        do {
            iVar4 = (int32_t)uVar9;
            iVar11 = *(int32_t *)(var_18h + iVar5 + -8);
            if (iVar11 < iVar3) {
                do {
                    uVar8 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802704eb;
                    iVar7 = fcn.180222340(uVar8, iVar11);
                    uVar9 = uVar13;
                    if (iVar7 != 0) {
                        uVar9 = *(uint64_t *)(iVar7 + 0x10);
                    }
                    *(uint64_t *)(&stack0x00000000 + iVar5) = uVar9;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
                    uVar9 = uVar13;
                    if (0 < iVar2) {
                        do {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027051a;
                            fcn.180222340(iVar6, uVar9);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270527;
                            fcn.180270c10(*(int64_t *)(var_18h + iVar5), *(int64_t *)((int64_t)&var_1ch + iVar5 + 4), 
                                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5)
                                          , *(int64_t *)(&stack0x00000038 + iVar5), 
                                          *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000048 + iVar5)
                                          , *(int64_t *)(&stack0x00000050 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar5), 
                                          *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5)
                                          , *(int64_t *)(&stack0x00000088 + iVar5), 
                                          *(int64_t *)(&stack0x00000090 + iVar5));
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                        } while ((int32_t)uVar10 < iVar2);
                    }
                    iVar3 = *(int32_t *)(var_18h + iVar5 + -4);
                    iVar11 = iVar11 + 1;
                } while (iVar11 < iVar3);
                iVar4 = *(int32_t *)((int64_t)&var_8h + iVar5 + 4);
            }
            uVar10 = iVar4 + 1;
            uVar9 = (uint64_t)uVar10;
            *(uint32_t *)((int64_t)&var_8h + iVar5 + 4) = uVar10;
        } while ((int32_t)uVar10 < 2);
        uVar12 = uVar12 + 1;
        iVar3 = *(int32_t *)((int64_t)&var_1ch + iVar5);
        *(int32_t *)(var_18h + iVar5 + -8) = *(int32_t *)(var_18h + iVar5);
        *(int32_t *)(var_18h + iVar5 + -4) = iVar3;
    } while ((iVar3 != *(int32_t *)(var_18h + iVar5)) && (uVar12 < 0xb));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270576;
    fcn.180222290(iVar6, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270585;
    fcn.180222050(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                  *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                  *(int64_t *)(&stack0x00000030 + iVar5));
    return 1;
}

// ============================================================
// Function: FUN_180270592
// Address: 0x180270592
// Size: 21 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

undefined8 fcn.180270330(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar11;
    int64_t in_R8;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    undefined var_18h [4];
    int64_t var_1ch;
    undefined8 uStack_30;
    
    uStack_30 = 0x180270343;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar13 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027035f;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270377;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270389;
        fcn.1802296d0(*(int64_t *)(var_18h + iVar5));
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703bd;
    iVar6 = fcn.180221f20();
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703ca;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703e2;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802703f4;
        fcn.1802296d0(*(int64_t *)(var_18h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270415;
    fcn.18026f5e0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(var_18h + iVar5), 
                  *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                  *(int64_t *)((int64_t)&arg_58h + iVar5));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027041d;
    iVar2 = fcn.180222010(iVar6);
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027042e;
        iVar7 = fcn.1802bce20(in_RDX, 0);
        if (iVar7 == 0) goto code_r0x000180270491;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_68h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270444;
    iVar3 = fcn.180222010(uVar8);
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270456;
    uVar8 = fcn.180222270(uVar8, 0x180271290);
    uVar12 = uVar13;
    if (0 < iVar3) {
        do {
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027046b;
            iVar7 = fcn.180222340(uVar1, uVar12);
            *(int32_t *)(iVar7 + 0x24) = (int32_t)uVar12;
            uVar10 = (int32_t)uVar12 + 1;
            uVar12 = (uint64_t)uVar10;
        } while ((int32_t)uVar10 < iVar3);
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027047d;
    fcn.1802222d0(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270489;
    fcn.180222270(uVar1, uVar8);
code_r0x000180270491:
    uVar8 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)(&stack0x00000000 + iVar5) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
    *(undefined8 *)(var_18h + iVar5 + -8) = 0;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802704ae;
    iVar3 = fcn.180222010(uVar8);
    *(int32_t *)(var_18h + iVar5 + -4) = iVar3;
    uVar12 = uVar13;
    do {
        *(int32_t *)((int64_t)&var_1ch + iVar5) = iVar3;
        *(undefined4 *)((int64_t)&var_8h + iVar5 + 4) = 0;
        *(int32_t *)(var_18h + iVar5) = iVar3;
        uVar9 = uVar13;
        do {
            iVar4 = (int32_t)uVar9;
            iVar11 = *(int32_t *)(var_18h + iVar5 + -8);
            if (iVar11 < iVar3) {
                do {
                    uVar8 = *(undefined8 *)(in_RCX + 0x18);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802704eb;
                    iVar7 = fcn.180222340(uVar8, iVar11);
                    uVar9 = uVar13;
                    if (iVar7 != 0) {
                        uVar9 = *(uint64_t *)(iVar7 + 0x10);
                    }
                    *(uint64_t *)(&stack0x00000000 + iVar5) = uVar9;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
                    uVar9 = uVar13;
                    if (0 < iVar2) {
                        do {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18027051a;
                            fcn.180222340(iVar6, uVar9);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270527;
                            fcn.180270c10(*(int64_t *)(var_18h + iVar5), *(int64_t *)((int64_t)&var_1ch + iVar5 + 4), 
                                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5)
                                          , *(int64_t *)(&stack0x00000038 + iVar5), 
                                          *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000048 + iVar5)
                                          , *(int64_t *)(&stack0x00000050 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar5), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar5), 
                                          *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5)
                                          , *(int64_t *)(&stack0x00000088 + iVar5), 
                                          *(int64_t *)(&stack0x00000090 + iVar5));
                            uVar10 = (int32_t)uVar9 + 1;
                            uVar9 = (uint64_t)uVar10;
                        } while ((int32_t)uVar10 < iVar2);
                    }
                    iVar3 = *(int32_t *)(var_18h + iVar5 + -4);
                    iVar11 = iVar11 + 1;
                } while (iVar11 < iVar3);
                iVar4 = *(int32_t *)((int64_t)&var_8h + iVar5 + 4);
            }
            uVar10 = iVar4 + 1;
            uVar9 = (uint64_t)uVar10;
            *(uint32_t *)((int64_t)&var_8h + iVar5 + 4) = uVar10;
        } while ((int32_t)uVar10 < 2);
        uVar12 = uVar12 + 1;
        iVar3 = *(int32_t *)((int64_t)&var_1ch + iVar5);
        *(int32_t *)(var_18h + iVar5 + -8) = *(int32_t *)(var_18h + iVar5);
        *(int32_t *)(var_18h + iVar5 + -4) = iVar3;
    } while ((iVar3 != *(int32_t *)(var_18h + iVar5)) && (uVar12 < 0xb));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270576;
    fcn.180222290(iVar6, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180270585;
    fcn.180222050(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                  *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(var_18h + iVar5 + -8), 
                  *(int64_t *)(&stack0x00000030 + iVar5));
    return 1;
}

// ============================================================
// Function: FUN_1802705e0
// Address: 0x1802705e0
// Size: 43 bytes
// ============================================================
undefined4 fcn.1802705e0(int64_t param_1)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    
    fcn.18045a350();
    if ((param_1 != 0) && (puVar1 = *(undefined4 **)(param_1 + 0x18), puVar1 != (undefined4 *)0x0)) {
        uVar2 = 0xffffffff;
        if (puVar1 != (undefined4 *)0x0) {
            uVar2 = *puVar1;
        }
        return uVar2;
    }
    return 0;
}

// ============================================================
// Function: FUN_180270610
// Address: 0x180270610
// Size: 86 bytes
// ============================================================
undefined8 fcn.180270610(int64_t param_1, undefined8 param_2)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18027061a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180270627;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18027063f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180270651;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    *(undefined8 *)(param_1 + 0x28) = param_2;
    return 1;
}

// ============================================================
// Function: FUN_180270670
// Address: 0x180270670
// Size: 86 bytes
// ============================================================
undefined8 fcn.180270670(int64_t param_1, undefined8 param_2)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18027067a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180270687;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18027069f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802706b1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    *(undefined8 *)(param_1 + 0x20) = param_2;
    return 1;
}

// ============================================================
// Function: FUN_1802706d0
// Address: 0x1802706d0
// Size: 86 bytes
// ============================================================
undefined8 fcn.1802706d0(int64_t param_1, undefined8 param_2)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802706da;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802706e7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802706ff;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180270711;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    *(undefined8 *)(param_1 + 0x30) = param_2;
    return 1;
}

