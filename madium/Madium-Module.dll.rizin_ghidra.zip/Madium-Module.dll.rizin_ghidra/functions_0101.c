// Chunk 101 - 50 functions

// ============================================================
// Function: FUN_1801601a8
// Address: 0x1801601a8
// Size: 119 bytes
// ============================================================
void fcn.1801601a8(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int32_t iVar2;
    bool bVar3;
    int16_t *piVar4;
    int16_t *unaff_RBX;
    int32_t iVar5;
    int32_t iVar6;
    int64_t in_R10;
    int16_t **unaff_R14;
    bool bVar7;
    bool bVar8;
    int64_t var_18h;
    int64_t var_20h;
    int32_t in_stack_0000002c;
    int32_t in_stack_00000034;
    
    iVar6 = (int32_t)arg4;
    iVar5 = (int32_t)arg3;
    piVar4 = (int16_t *)(in_R10 + 0x1c);
    bVar3 = false;
    do {
        if ((unaff_RBX <= piVar4) || (bVar3)) {
            return;
        }
        if (*(int32_t *)(in_R10 + 0x18) < *(int32_t *)(piVar4 + 0xc)) {
            if ((*(int32_t *)(piVar4 + 0xc) == *(int32_t *)(in_R10 + 0x18) + 1) && (*piVar4 == 0x7b)) {
                iVar1 = *(int32_t *)(piVar4 + 2);
                bVar8 = SBORROW4(iVar1, iVar5);
                iVar2 = iVar1 - iVar5;
                bVar7 = iVar1 == iVar5;
                if (bVar7) {
                    iVar1 = *(int32_t *)(piVar4 + 4);
                    bVar8 = SBORROW4(iVar1, in_stack_0000002c);
                    iVar2 = iVar1 - in_stack_0000002c;
                    bVar7 = iVar1 == in_stack_0000002c;
                }
                if (!bVar7 && bVar8 == iVar2 < 0) {
                    iVar1 = *(int32_t *)(piVar4 + 8);
                    bVar7 = SBORROW4(iVar1, iVar6);
                    iVar2 = iVar1 - iVar6;
                    if (iVar1 == iVar6) {
                        bVar7 = SBORROW4(*(int32_t *)(piVar4 + 10), in_stack_00000034);
                        iVar2 = *(int32_t *)(piVar4 + 10) - in_stack_00000034;
                    }
                    if (bVar7 != iVar2 < 0) {
                        *unaff_R14 = piVar4;
                        goto code_r0x000180160205;
                    }
                }
            }
        } else {
code_r0x000180160205:
            bVar3 = true;
        }
        piVar4 = piVar4 + 0xe;
    } while( true );
}

// ============================================================
// Function: FUN_18016021f
// Address: 0x18016021f
// Size: 7 bytes
// ============================================================
void fcn.18016021f(void)
{
    return;
}

// ============================================================
// Function: FUN_180160230
// Address: 0x180160230
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

undefined fcn.180160230(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined auVar1 [16];
    int64_t iVar2;
    char cVar3;
    undefined uVar4;
    int64_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    undefined4 uStack_28;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    uVar4 = 0;
    var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
    uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
    uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
    uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
    var_38h._0_4_ = 0x15;
    if (*(char *)arg2 == '\0') {
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar2 + 0x20bc) != 0x15) {
            *(undefined4 *)(iVar2 + 0x1020) = *(undefined4 *)(iVar2 + 0x11e0);
            *(undefined4 *)(iVar2 + 0x1024) = *(undefined4 *)(iVar2 + 0x11e4);
            *(undefined4 *)(iVar2 + 0x1028) = *(undefined4 *)(iVar2 + 0x11e8);
            *(undefined4 *)(iVar2 + 0x102c) = *(undefined4 *)(iVar2 + 0x11ec);
        }
        iVar5 = *(int64_t *)0x180781f28;
        var_38h._0_4_ = 0x16;
        var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1030);
        uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1034);
        uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1038);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x103c);
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar5 + 0x20bc) != 0x16) {
            uVar6 = *(undefined4 *)(iVar2 + 0x11e4);
            uVar7 = *(undefined4 *)(iVar2 + 0x11e8);
            uVar8 = *(undefined4 *)(iVar2 + 0x11ec);
            *(undefined4 *)(iVar5 + 0x1030) = *(undefined4 *)(iVar2 + 0x11e0);
            *(undefined4 *)(iVar5 + 0x1034) = uVar6;
            *(undefined4 *)(iVar5 + 0x1038) = uVar7;
            *(undefined4 *)(iVar5 + 0x103c) = uVar8;
        }
        iVar5 = *(int64_t *)0x180781f28;
        var_38h._0_4_ = 0x17;
        var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1040);
        uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1044);
        uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1048);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x104c);
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar5 + 0x20bc) == 0x17) goto code_r0x0001801603cd;
        uVar6 = *(undefined4 *)(iVar2 + 0x1040);
        uVar7 = *(undefined4 *)(iVar2 + 0x1044);
        uVar8 = *(undefined4 *)(iVar2 + 0x1048);
        uVar9 = *(undefined4 *)(iVar2 + 0x104c);
    } else {
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar2 + 0x20bc) != 0x15) {
            *(undefined4 *)(iVar2 + 0x1020) = *(undefined4 *)(iVar2 + 0x1040);
            *(undefined4 *)(iVar2 + 0x1024) = *(undefined4 *)(iVar2 + 0x1044);
            *(undefined4 *)(iVar2 + 0x1028) = *(undefined4 *)(iVar2 + 0x1048);
            *(undefined4 *)(iVar2 + 0x102c) = *(undefined4 *)(iVar2 + 0x104c);
        }
        iVar5 = *(int64_t *)0x180781f28;
        var_38h._0_4_ = 0x16;
        var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1030);
        uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1034);
        uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1038);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x103c);
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar5 + 0x20bc) != 0x16) {
            uVar6 = *(undefined4 *)(iVar2 + 0x1044);
            uVar7 = *(undefined4 *)(iVar2 + 0x1048);
            uVar8 = *(undefined4 *)(iVar2 + 0x104c);
            *(undefined4 *)(iVar5 + 0x1030) = *(undefined4 *)(iVar2 + 0x1040);
            *(undefined4 *)(iVar5 + 0x1034) = uVar6;
            *(undefined4 *)(iVar5 + 0x1038) = uVar7;
            *(undefined4 *)(iVar5 + 0x103c) = uVar8;
        }
        iVar5 = *(int64_t *)0x180781f28;
        var_38h._0_4_ = 0x17;
        var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1040);
        uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1044);
        uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1048);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x104c);
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar5 + 0x20bc) == 0x17) goto code_r0x0001801603cd;
        uVar6 = *(undefined4 *)(iVar2 + 0x11e0);
        uVar7 = *(undefined4 *)(iVar2 + 0x11e4);
        uVar8 = *(undefined4 *)(iVar2 + 0x11e8);
        uVar9 = *(undefined4 *)(iVar2 + 0x11ec);
    }
    auVar1._4_4_ = uVar7;
    auVar1._0_4_ = uVar6;
    auVar1._8_4_ = uVar8;
    auVar1._12_4_ = uVar9;
    *(undefined (*) [16])(iVar5 + 0x1040) = auVar1;
code_r0x0001801603cd:
    func_0x00018013a5c0(arg1, arg3, 0);
    cVar3 = func_0x000180107ff0(0, 0, 0);
    if (cVar3 != '\0') {
        cVar3 = func_0x0001800fa150(0);
        if (cVar3 != '\0') {
            uVar4 = 1;
            *(bool *)arg2 = *(char *)arg2 == '\0';
        }
    }
    func_0x0001800f6770(3);
    return uVar4;
}

// ============================================================
// Function: FUN_18016023a
// Address: 0x18016023a
// Size: 458 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

undefined fcn.180160230(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined auVar1 [16];
    int64_t iVar2;
    char cVar3;
    undefined uVar4;
    int64_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    undefined4 uStack_28;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    uVar4 = 0;
    var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
    uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
    uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
    uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
    var_38h._0_4_ = 0x15;
    if (*(char *)arg2 == '\0') {
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar2 + 0x20bc) != 0x15) {
            *(undefined4 *)(iVar2 + 0x1020) = *(undefined4 *)(iVar2 + 0x11e0);
            *(undefined4 *)(iVar2 + 0x1024) = *(undefined4 *)(iVar2 + 0x11e4);
            *(undefined4 *)(iVar2 + 0x1028) = *(undefined4 *)(iVar2 + 0x11e8);
            *(undefined4 *)(iVar2 + 0x102c) = *(undefined4 *)(iVar2 + 0x11ec);
        }
        iVar5 = *(int64_t *)0x180781f28;
        var_38h._0_4_ = 0x16;
        var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1030);
        uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1034);
        uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1038);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x103c);
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar5 + 0x20bc) != 0x16) {
            uVar6 = *(undefined4 *)(iVar2 + 0x11e4);
            uVar7 = *(undefined4 *)(iVar2 + 0x11e8);
            uVar8 = *(undefined4 *)(iVar2 + 0x11ec);
            *(undefined4 *)(iVar5 + 0x1030) = *(undefined4 *)(iVar2 + 0x11e0);
            *(undefined4 *)(iVar5 + 0x1034) = uVar6;
            *(undefined4 *)(iVar5 + 0x1038) = uVar7;
            *(undefined4 *)(iVar5 + 0x103c) = uVar8;
        }
        iVar5 = *(int64_t *)0x180781f28;
        var_38h._0_4_ = 0x17;
        var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1040);
        uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1044);
        uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1048);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x104c);
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar5 + 0x20bc) == 0x17) goto code_r0x0001801603cd;
        uVar6 = *(undefined4 *)(iVar2 + 0x1040);
        uVar7 = *(undefined4 *)(iVar2 + 0x1044);
        uVar8 = *(undefined4 *)(iVar2 + 0x1048);
        uVar9 = *(undefined4 *)(iVar2 + 0x104c);
    } else {
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar2 + 0x20bc) != 0x15) {
            *(undefined4 *)(iVar2 + 0x1020) = *(undefined4 *)(iVar2 + 0x1040);
            *(undefined4 *)(iVar2 + 0x1024) = *(undefined4 *)(iVar2 + 0x1044);
            *(undefined4 *)(iVar2 + 0x1028) = *(undefined4 *)(iVar2 + 0x1048);
            *(undefined4 *)(iVar2 + 0x102c) = *(undefined4 *)(iVar2 + 0x104c);
        }
        iVar5 = *(int64_t *)0x180781f28;
        var_38h._0_4_ = 0x16;
        var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1030);
        uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1034);
        uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1038);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x103c);
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar5 + 0x20bc) != 0x16) {
            uVar6 = *(undefined4 *)(iVar2 + 0x1044);
            uVar7 = *(undefined4 *)(iVar2 + 0x1048);
            uVar8 = *(undefined4 *)(iVar2 + 0x104c);
            *(undefined4 *)(iVar5 + 0x1030) = *(undefined4 *)(iVar2 + 0x1040);
            *(undefined4 *)(iVar5 + 0x1034) = uVar6;
            *(undefined4 *)(iVar5 + 0x1038) = uVar7;
            *(undefined4 *)(iVar5 + 0x103c) = uVar8;
        }
        iVar5 = *(int64_t *)0x180781f28;
        var_38h._0_4_ = 0x17;
        var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1040);
        uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1044);
        uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1048);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x104c);
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar5 + 0x20bc) == 0x17) goto code_r0x0001801603cd;
        uVar6 = *(undefined4 *)(iVar2 + 0x11e0);
        uVar7 = *(undefined4 *)(iVar2 + 0x11e4);
        uVar8 = *(undefined4 *)(iVar2 + 0x11e8);
        uVar9 = *(undefined4 *)(iVar2 + 0x11ec);
    }
    auVar1._4_4_ = uVar7;
    auVar1._0_4_ = uVar6;
    auVar1._8_4_ = uVar8;
    auVar1._12_4_ = uVar9;
    *(undefined (*) [16])(iVar5 + 0x1040) = auVar1;
code_r0x0001801603cd:
    func_0x00018013a5c0(arg1, arg3, 0);
    cVar3 = func_0x000180107ff0(0, 0, 0);
    if (cVar3 != '\0') {
        cVar3 = func_0x0001800fa150(0);
        if (cVar3 != '\0') {
            uVar4 = 1;
            *(bool *)arg2 = *(char *)arg2 == '\0';
        }
    }
    func_0x0001800f6770(3);
    return uVar4;
}

// ============================================================
// Function: FUN_180160404
// Address: 0x180160404
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

undefined fcn.180160230(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined auVar1 [16];
    int64_t iVar2;
    char cVar3;
    undefined uVar4;
    int64_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    undefined4 uStack_28;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    uVar4 = 0;
    var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
    uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
    uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
    uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
    var_38h._0_4_ = 0x15;
    if (*(char *)arg2 == '\0') {
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar2 + 0x20bc) != 0x15) {
            *(undefined4 *)(iVar2 + 0x1020) = *(undefined4 *)(iVar2 + 0x11e0);
            *(undefined4 *)(iVar2 + 0x1024) = *(undefined4 *)(iVar2 + 0x11e4);
            *(undefined4 *)(iVar2 + 0x1028) = *(undefined4 *)(iVar2 + 0x11e8);
            *(undefined4 *)(iVar2 + 0x102c) = *(undefined4 *)(iVar2 + 0x11ec);
        }
        iVar5 = *(int64_t *)0x180781f28;
        var_38h._0_4_ = 0x16;
        var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1030);
        uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1034);
        uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1038);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x103c);
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar5 + 0x20bc) != 0x16) {
            uVar6 = *(undefined4 *)(iVar2 + 0x11e4);
            uVar7 = *(undefined4 *)(iVar2 + 0x11e8);
            uVar8 = *(undefined4 *)(iVar2 + 0x11ec);
            *(undefined4 *)(iVar5 + 0x1030) = *(undefined4 *)(iVar2 + 0x11e0);
            *(undefined4 *)(iVar5 + 0x1034) = uVar6;
            *(undefined4 *)(iVar5 + 0x1038) = uVar7;
            *(undefined4 *)(iVar5 + 0x103c) = uVar8;
        }
        iVar5 = *(int64_t *)0x180781f28;
        var_38h._0_4_ = 0x17;
        var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1040);
        uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1044);
        uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1048);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x104c);
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar5 + 0x20bc) == 0x17) goto code_r0x0001801603cd;
        uVar6 = *(undefined4 *)(iVar2 + 0x1040);
        uVar7 = *(undefined4 *)(iVar2 + 0x1044);
        uVar8 = *(undefined4 *)(iVar2 + 0x1048);
        uVar9 = *(undefined4 *)(iVar2 + 0x104c);
    } else {
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar2 + 0x20bc) != 0x15) {
            *(undefined4 *)(iVar2 + 0x1020) = *(undefined4 *)(iVar2 + 0x1040);
            *(undefined4 *)(iVar2 + 0x1024) = *(undefined4 *)(iVar2 + 0x1044);
            *(undefined4 *)(iVar2 + 0x1028) = *(undefined4 *)(iVar2 + 0x1048);
            *(undefined4 *)(iVar2 + 0x102c) = *(undefined4 *)(iVar2 + 0x104c);
        }
        iVar5 = *(int64_t *)0x180781f28;
        var_38h._0_4_ = 0x16;
        var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1030);
        uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1034);
        uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1038);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x103c);
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar5 + 0x20bc) != 0x16) {
            uVar6 = *(undefined4 *)(iVar2 + 0x1044);
            uVar7 = *(undefined4 *)(iVar2 + 0x1048);
            uVar8 = *(undefined4 *)(iVar2 + 0x104c);
            *(undefined4 *)(iVar5 + 0x1030) = *(undefined4 *)(iVar2 + 0x1040);
            *(undefined4 *)(iVar5 + 0x1034) = uVar6;
            *(undefined4 *)(iVar5 + 0x1038) = uVar7;
            *(undefined4 *)(iVar5 + 0x103c) = uVar8;
        }
        iVar5 = *(int64_t *)0x180781f28;
        var_38h._0_4_ = 0x17;
        var_38h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1040);
        uStack_30 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1044);
        uStack_2c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1048);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x104c);
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_38h);
        if (*(int32_t *)(iVar5 + 0x20bc) == 0x17) goto code_r0x0001801603cd;
        uVar6 = *(undefined4 *)(iVar2 + 0x11e0);
        uVar7 = *(undefined4 *)(iVar2 + 0x11e4);
        uVar8 = *(undefined4 *)(iVar2 + 0x11e8);
        uVar9 = *(undefined4 *)(iVar2 + 0x11ec);
    }
    auVar1._4_4_ = uVar7;
    auVar1._0_4_ = uVar6;
    auVar1._8_4_ = uVar8;
    auVar1._12_4_ = uVar9;
    *(undefined (*) [16])(iVar5 + 0x1040) = auVar1;
code_r0x0001801603cd:
    func_0x00018013a5c0(arg1, arg3, 0);
    cVar3 = func_0x000180107ff0(0, 0, 0);
    if (cVar3 != '\0') {
        cVar3 = func_0x0001800fa150(0);
        if (cVar3 != '\0') {
            uVar4 = 1;
            *(bool *)arg2 = *(char *)arg2 == '\0';
        }
    }
    func_0x0001800f6770(3);
    return uVar4;
}

// ============================================================
// Function: FUN_180160440
// Address: 0x180160440
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180160440(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    undefined8 auStackX_10 [3];
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    iVar1 = arg2;
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        iVar1 = *(int64_t *)arg2;
    }
    auStackX_10[0] = 0;
    func_0x0001801431e0(placeholder_0, 0, iVar1, (int32_t)*(uint64_t *)(arg2 + 0x18) + 1, auStackX_10, 
                        (uint32_t)arg3 | 0x410000, 0x1801604a0, arg2);
    return;
}

// ============================================================
// Function: FUN_1801604a0
// Address: 0x1801604a0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801604a0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t var_8h;
    int64_t in_stack_00000020;
    
    if (*(int32_t *)(arg1 + 8) == 0x400000) {
        piVar1 = *(int64_t **)(arg1 + 0x10);
        fcn.18000b3b0(in_stack_00000020);
        if (0xf < (uint64_t)piVar1[3]) {
            piVar1 = (int64_t *)*piVar1;
        }
        *(int64_t **)(arg1 + 0x28) = piVar1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801604b9
// Address: 0x1801604b9
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801604a0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t var_8h;
    int64_t in_stack_00000020;
    
    if (*(int32_t *)(arg1 + 8) == 0x400000) {
        piVar1 = *(int64_t **)(arg1 + 0x10);
        fcn.18000b3b0(in_stack_00000020);
        if (0xf < (uint64_t)piVar1[3]) {
            piVar1 = (int64_t *)*piVar1;
        }
        *(int64_t **)(arg1 + 0x28) = piVar1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801604dd
// Address: 0x1801604dd
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801604a0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t var_8h;
    int64_t in_stack_00000020;
    
    if (*(int32_t *)(arg1 + 8) == 0x400000) {
        piVar1 = *(int64_t **)(arg1 + 0x10);
        fcn.18000b3b0(in_stack_00000020);
        if (0xf < (uint64_t)piVar1[3]) {
            piVar1 = (int64_t *)*piVar1;
        }
        *(int64_t **)(arg1 + 0x28) = piVar1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801604f0
// Address: 0x1801604f0
// Size: 308 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.1801604f0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined8 *puVar4;
    bool bVar5;
    code *pcVar6;
    char cVar7;
    undefined8 *puVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    undefined in_R9B;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    undefined8 uStack_30;
    
    var_38h = 0;
    uVar11 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
    var_8h = 0;
    if (uVar11 < *(uint64_t *)(arg1 + 0x20) || uVar11 - *(uint64_t *)(arg1 + 0x20) == 0) {
        uVar10 = *(uint64_t *)(arg1 + 0x18);
        if (uVar11 <= *(uint64_t *)(arg1 + 0x18)) {
            uVar10 = 0;
        }
        *(uint64_t *)(arg1 + 0x20) = uVar10;
        if (uVar11 < uVar10 || uVar11 - uVar10 == 0) {
            fcn.180060370();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    cVar7 = fcn.18015df90(CONCAT71(var_58h._1_7_, in_R9B), (int64_t)&var_38h, (int64_t)&var_8h, 0);
    if (cVar7 == '\0') {
        uVar11 = *(uint64_t *)arg1;
        while (uVar10 = uVar11, uVar10 < *(uint64_t *)(arg1 + 8)) {
            uVar11 = uVar10 + 0x14;
            if (*(char *)(uVar10 + 0x10) == '\0') {
                uStack_30 = 0x18015c393;
                fcn.180498030(uVar10, uVar11, *(uint64_t *)(arg1 + 8) - uVar11);
                *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -0x14;
                uVar11 = uVar10;
            }
        }
        *(undefined8 *)(arg1 + 0x18) = 0;
        *(undefined8 *)(arg1 + 0x20) = 0;
        *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
        puVar4 = *(undefined8 **)arg1;
        iVar2 = *(int32_t *)(puVar4 + 1);
        puVar1 = puVar4 + 1;
        iVar3 = *(int32_t *)puVar4;
        if (iVar3 == iVar2) {
            bVar5 = *(int32_t *)((int64_t)puVar4 + 0xc) < *(int32_t *)((int64_t)puVar4 + 4);
            puVar8 = puVar4;
            if (*(int32_t *)((int64_t)puVar4 + 4) <= *(int32_t *)((int64_t)puVar4 + 0xc)) {
                puVar8 = puVar1;
            }
            uVar9 = *puVar8;
        } else {
            bVar5 = iVar3 != iVar2 && iVar2 <= iVar3;
            puVar8 = puVar4;
            if (iVar3 <= iVar2) {
                puVar8 = puVar1;
            }
            uVar9 = *puVar8;
        }
        puVar8 = puVar4;
        if (!bVar5) {
            puVar8 = puVar1;
        }
        *puVar4 = *puVar8;
        *puVar1 = uVar9;
        *(undefined *)((int64_t)puVar4 + 0x12) = 1;
        return;
    }
    if (*(int64_t *)arg1 != *(int64_t *)(arg1 + 8)) {
        *(int64_t *)(arg1 + 8) = *(int64_t *)arg1;
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    fcn.180163690(arg1, &var_38h, &var_8h);
    *(undefined *)(*(int64_t *)arg1 + 0x10) = 1;
    *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
    *(undefined *)(arg1 + 0x2c8) = 1;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    return;
}

// ============================================================
// Function: FUN_180160630
// Address: 0x180160630
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180160630(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    char cVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_48h = 0;
    var_8h = 0;
    var_40h = 0;
    cVar5 = fcn.18015df90(CONCAT71(var_68h._1_7_, in_R9B), (int64_t)&var_48h, (int64_t)&var_8h, 0);
    if (cVar5 == '\0') {
        func_0x00018015c350(arg1, 1);
        return;
    }
    var_40h = var_8h;
    var_38h = var_48h;
    if (*(int64_t *)arg1 != *(int64_t *)(arg1 + 8)) {
        *(int64_t *)(arg1 + 8) = *(int64_t *)arg1;
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    fcn.180163690(arg1, &var_38h, &var_40h);
    iVar4 = var_48h._4_4_;
    iVar3 = var_8h._4_4_;
    iVar2 = (int32_t)var_8h;
    *(undefined *)(*(int64_t *)arg1 + 0x10) = 1;
    *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
    do {
        var_40h = 0;
        uVar7 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
        var_8h = 0;
        if (uVar7 < *(uint64_t *)(arg1 + 0x20) || uVar7 - *(uint64_t *)(arg1 + 0x20) == 0) {
            uVar6 = *(uint64_t *)(arg1 + 0x18);
            if (uVar7 <= *(uint64_t *)(arg1 + 0x18)) {
                uVar6 = 0;
            }
            *(uint64_t *)(arg1 + 0x20) = uVar6;
            if (uVar7 < uVar6 || uVar7 - uVar6 == 0) {
code_r0x000180160862:
                fcn.180060370();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
        }
        fcn.18015df90(CONCAT71(var_68h._1_7_, in_R9B), (int64_t)&var_40h, (int64_t)&var_8h, var_48h);
        if (((((int32_t)var_40h == (int32_t)var_48h) && (var_40h._4_4_ == iVar4)) && ((int32_t)var_8h == iVar2)) &&
           (var_8h._4_4_ == iVar3)) {
            *(undefined *)(arg1 + 0x2c8) = 1;
            *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
            return;
        }
        uVar7 = *(uint64_t *)(arg1 + 0x20);
        var_38h = var_8h;
        var_30h = var_40h;
        uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
        if (uVar6 < uVar7 || uVar6 - uVar7 == 0) goto code_r0x000180160862;
        *(undefined *)(*(int64_t *)arg1 + 0x11 + uVar7 * 0x14) = 0;
        fcn.180163690(arg1, &var_30h, &var_38h);
        *(undefined *)(*(int64_t *)(arg1 + 8) + -3) = 1;
        *(int64_t *)(arg1 + 0x20) = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333 + -1;
    } while( true );
}

// ============================================================
// Function: FUN_1801606a4
// Address: 0x1801606a4
// Size: 413 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180160630(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    char cVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_48h = 0;
    var_8h = 0;
    var_40h = 0;
    cVar5 = fcn.18015df90(CONCAT71(var_68h._1_7_, in_R9B), (int64_t)&var_48h, (int64_t)&var_8h, 0);
    if (cVar5 == '\0') {
        func_0x00018015c350(arg1, 1);
        return;
    }
    var_40h = var_8h;
    var_38h = var_48h;
    if (*(int64_t *)arg1 != *(int64_t *)(arg1 + 8)) {
        *(int64_t *)(arg1 + 8) = *(int64_t *)arg1;
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    fcn.180163690(arg1, &var_38h, &var_40h);
    iVar4 = var_48h._4_4_;
    iVar3 = var_8h._4_4_;
    iVar2 = (int32_t)var_8h;
    *(undefined *)(*(int64_t *)arg1 + 0x10) = 1;
    *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
    do {
        var_40h = 0;
        uVar7 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
        var_8h = 0;
        if (uVar7 < *(uint64_t *)(arg1 + 0x20) || uVar7 - *(uint64_t *)(arg1 + 0x20) == 0) {
            uVar6 = *(uint64_t *)(arg1 + 0x18);
            if (uVar7 <= *(uint64_t *)(arg1 + 0x18)) {
                uVar6 = 0;
            }
            *(uint64_t *)(arg1 + 0x20) = uVar6;
            if (uVar7 < uVar6 || uVar7 - uVar6 == 0) {
code_r0x000180160862:
                fcn.180060370();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
        }
        fcn.18015df90(CONCAT71(var_68h._1_7_, in_R9B), (int64_t)&var_40h, (int64_t)&var_8h, var_48h);
        if (((((int32_t)var_40h == (int32_t)var_48h) && (var_40h._4_4_ == iVar4)) && ((int32_t)var_8h == iVar2)) &&
           (var_8h._4_4_ == iVar3)) {
            *(undefined *)(arg1 + 0x2c8) = 1;
            *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
            return;
        }
        uVar7 = *(uint64_t *)(arg1 + 0x20);
        var_38h = var_8h;
        var_30h = var_40h;
        uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
        if (uVar6 < uVar7 || uVar6 - uVar7 == 0) goto code_r0x000180160862;
        *(undefined *)(*(int64_t *)arg1 + 0x11 + uVar7 * 0x14) = 0;
        fcn.180163690(arg1, &var_30h, &var_38h);
        *(undefined *)(*(int64_t *)(arg1 + 8) + -3) = 1;
        *(int64_t *)(arg1 + 0x20) = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333 + -1;
    } while( true );
}

// ============================================================
// Function: FUN_180160841
// Address: 0x180160841
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180160630(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    char cVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_48h = 0;
    var_8h = 0;
    var_40h = 0;
    cVar5 = fcn.18015df90(CONCAT71(var_68h._1_7_, in_R9B), (int64_t)&var_48h, (int64_t)&var_8h, 0);
    if (cVar5 == '\0') {
        func_0x00018015c350(arg1, 1);
        return;
    }
    var_40h = var_8h;
    var_38h = var_48h;
    if (*(int64_t *)arg1 != *(int64_t *)(arg1 + 8)) {
        *(int64_t *)(arg1 + 8) = *(int64_t *)arg1;
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    fcn.180163690(arg1, &var_38h, &var_40h);
    iVar4 = var_48h._4_4_;
    iVar3 = var_8h._4_4_;
    iVar2 = (int32_t)var_8h;
    *(undefined *)(*(int64_t *)arg1 + 0x10) = 1;
    *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
    do {
        var_40h = 0;
        uVar7 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
        var_8h = 0;
        if (uVar7 < *(uint64_t *)(arg1 + 0x20) || uVar7 - *(uint64_t *)(arg1 + 0x20) == 0) {
            uVar6 = *(uint64_t *)(arg1 + 0x18);
            if (uVar7 <= *(uint64_t *)(arg1 + 0x18)) {
                uVar6 = 0;
            }
            *(uint64_t *)(arg1 + 0x20) = uVar6;
            if (uVar7 < uVar6 || uVar7 - uVar6 == 0) {
code_r0x000180160862:
                fcn.180060370();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
        }
        fcn.18015df90(CONCAT71(var_68h._1_7_, in_R9B), (int64_t)&var_40h, (int64_t)&var_8h, var_48h);
        if (((((int32_t)var_40h == (int32_t)var_48h) && (var_40h._4_4_ == iVar4)) && ((int32_t)var_8h == iVar2)) &&
           (var_8h._4_4_ == iVar3)) {
            *(undefined *)(arg1 + 0x2c8) = 1;
            *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
            return;
        }
        uVar7 = *(uint64_t *)(arg1 + 0x20);
        var_38h = var_8h;
        var_30h = var_40h;
        uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
        if (uVar6 < uVar7 || uVar6 - uVar7 == 0) goto code_r0x000180160862;
        *(undefined *)(*(int64_t *)arg1 + 0x11 + uVar7 * 0x14) = 0;
        fcn.180163690(arg1, &var_30h, &var_38h);
        *(undefined *)(*(int64_t *)(arg1 + 8) + -3) = 1;
        *(int64_t *)(arg1 + 0x20) = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333 + -1;
    } while( true );
}

// ============================================================
// Function: FUN_180160862
// Address: 0x180160862
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180160630(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    char cVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_48h = 0;
    var_8h = 0;
    var_40h = 0;
    cVar5 = fcn.18015df90(CONCAT71(var_68h._1_7_, in_R9B), (int64_t)&var_48h, (int64_t)&var_8h, 0);
    if (cVar5 == '\0') {
        func_0x00018015c350(arg1, 1);
        return;
    }
    var_40h = var_8h;
    var_38h = var_48h;
    if (*(int64_t *)arg1 != *(int64_t *)(arg1 + 8)) {
        *(int64_t *)(arg1 + 8) = *(int64_t *)arg1;
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    fcn.180163690(arg1, &var_38h, &var_40h);
    iVar4 = var_48h._4_4_;
    iVar3 = var_8h._4_4_;
    iVar2 = (int32_t)var_8h;
    *(undefined *)(*(int64_t *)arg1 + 0x10) = 1;
    *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
    do {
        var_40h = 0;
        uVar7 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
        var_8h = 0;
        if (uVar7 < *(uint64_t *)(arg1 + 0x20) || uVar7 - *(uint64_t *)(arg1 + 0x20) == 0) {
            uVar6 = *(uint64_t *)(arg1 + 0x18);
            if (uVar7 <= *(uint64_t *)(arg1 + 0x18)) {
                uVar6 = 0;
            }
            *(uint64_t *)(arg1 + 0x20) = uVar6;
            if (uVar7 < uVar6 || uVar7 - uVar6 == 0) {
code_r0x000180160862:
                fcn.180060370();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
        }
        fcn.18015df90(CONCAT71(var_68h._1_7_, in_R9B), (int64_t)&var_40h, (int64_t)&var_8h, var_48h);
        if (((((int32_t)var_40h == (int32_t)var_48h) && (var_40h._4_4_ == iVar4)) && ((int32_t)var_8h == iVar2)) &&
           (var_8h._4_4_ == iVar3)) {
            *(undefined *)(arg1 + 0x2c8) = 1;
            *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
            return;
        }
        uVar7 = *(uint64_t *)(arg1 + 0x20);
        var_38h = var_8h;
        var_30h = var_40h;
        uVar6 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
        if (uVar6 < uVar7 || uVar6 - uVar7 == 0) goto code_r0x000180160862;
        *(undefined *)(*(int64_t *)arg1 + 0x11 + uVar7 * 0x14) = 0;
        fcn.180163690(arg1, &var_30h, &var_38h);
        *(undefined *)(*(int64_t *)(arg1 + 8) + -3) = 1;
        *(int64_t *)(arg1 + 0x20) = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333 + -1;
    } while( true );
}

// ============================================================
// Function: FUN_180160870
// Address: 0x180160870
// Size: 497 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180160870(int64_t arg1, int64_t arg_70h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    code *pcVar6;
    char cVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    undefined *puVar11;
    int64_t iVar12;
    bool bVar13;
    undefined auStackY_d8 [8];
    undefined auStackY_d0 [24];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar11 = auStackY_d8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_d8;
    iVar8 = *(int64_t *)arg1;
    uVar10 = (*(int64_t *)(arg1 + 8) - iVar8 >> 2) * -0x3333333333333333;
    uVar9 = *(uint64_t *)(arg1 + 0x20);
    if (uVar10 < uVar9 || uVar10 - uVar9 == 0) {
        uVar9 = *(uint64_t *)(arg1 + 0x18);
        if (uVar10 <= *(uint64_t *)(arg1 + 0x18)) {
            uVar9 = 0;
        }
        *(uint64_t *)(arg1 + 0x20) = uVar9;
        if (uVar10 < uVar9 || uVar10 - uVar9 == 0) {
            fcn.180060370();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    iVar1 = *(int32_t *)(iVar8 + uVar9 * 0x14);
    iVar2 = *(int32_t *)(iVar8 + 4 + uVar9 * 0x14);
    var_88h = CONCAT44(iVar2, iVar1);
    iVar3 = *(int32_t *)(iVar8 + 8 + uVar9 * 0x14);
    iVar4 = *(int32_t *)(iVar8 + 0xc + uVar9 * 0x14);
    var_80h = CONCAT44(iVar4, iVar3);
    bVar13 = SBORROW4(iVar1, iVar3);
    iVar5 = iVar1 - iVar3;
    if (iVar1 == iVar3) {
        bVar13 = SBORROW4(iVar2, iVar4);
        iVar5 = iVar2 - iVar4;
    }
    iVar8 = var_80h;
    if ((iVar1 != iVar3 || iVar2 != iVar4) && bVar13 == iVar5 < 0) {
        iVar8 = var_88h;
    }
    bVar13 = SBORROW4(iVar1, iVar3);
    iVar5 = iVar1 - iVar3;
    if (iVar1 == iVar3) {
        bVar13 = SBORROW4(iVar2, iVar4);
        iVar5 = iVar2 - iVar4;
    }
    iVar12 = var_80h;
    if (bVar13 != iVar5 < 0) {
        iVar12 = var_88h;
    }
    fcn.18015d450(arg1 + 0x40, &var_70h, iVar12, iVar8);
    var_90h = 0;
    var_98h = 0;
    var_88h = var_70h;
    if ((uint64_t)var_58h < 0x10) {
        var_88h = (int64_t)&var_70h;
    }
    var_80h = var_60h;
    var_a8h = (int64_t)&var_98h;
    var_b0h = (int64_t)&var_90h;
    var_b8h._0_1_ = 0;
    cVar7 = fcn.18015df90((uint64_t)var_b8h._1_7_ << 8, var_b0h, var_a8h, 0);
    if (cVar7 != '\0') {
        fcn.18015c0d0(arg1, var_90h, var_98h);
    }
    if (0xf < (uint64_t)var_58h) {
        iVar8 = var_70h;
        puVar11 = auStackY_d8;
        if ((0xfff < var_58h + 1U) &&
           (iVar8 = *(int64_t *)(var_70h + -8), puVar11 = auStackY_d8, 0x1f < (var_70h - iVar8) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar8 = (*pcVar6)(5);
            puVar11 = auStackY_d0;
        }
        *(undefined8 *)(puVar11 + -8) = 0x180160a37;
        fcn.180459c3c(iVar8);
    }
    *(undefined8 *)(puVar11 + -8) = 0x180160a47;
    fcn.180459870(*(uint64_t *)(puVar11 + 0x88) ^ (uint64_t)puVar11);
    return;
}

// ============================================================
// Function: FUN_180160a70
// Address: 0x180160a70
// Size: 549 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180160a70(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined (*pauVar1) [16];
    int32_t *piVar2;
    int64_t *piVar3;
    int32_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    code *pcVar7;
    char cVar8;
    undefined (*pauVar9) [16];
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    if (*(char *)(arg1 + 0x131) != '\0') {
        *(undefined *)(arg1 + 0x133) = 1;
    }
    pauVar9 = (undefined (*) [16])func_0x000180459890(0x78);
    *pauVar9 = ZEXT816(0);
    *(undefined4 *)(*pauVar9 + 8) = 1;
    *(undefined4 *)(*pauVar9 + 0xc) = 1;
    *(undefined8 *)*pauVar9 = 0x180645d88;
    pauVar1 = pauVar9 + 1;
    *pauVar1 = ZEXT816(0);
    pauVar9[2] = ZEXT816(0);
    pauVar9[3] = ZEXT816(0);
    pauVar9[4] = ZEXT816(0);
    pauVar9[5] = ZEXT816(0);
    pauVar9[6] = ZEXT816(0);
    *(undefined8 *)pauVar9[7] = 0;
    var_10h = (int64_t)pauVar9;
    func_0x0001801655b0(pauVar1);
    var_48h = (int64_t)pauVar1;
    var_40h = (int64_t)pauVar9;
    func_0x000180150230(pauVar9[2] + 8, arg1);
    uVar5 = *(undefined8 *)arg3;
    uVar6 = *(undefined8 *)arg2;
    LOCK();
    *(int32_t *)(*pauVar9 + 8) = *(int32_t *)(*pauVar9 + 8) + 1;
    UNLOCK();
    var_50h = (int64_t)pauVar9;
    var_58h = (int64_t)pauVar1;
    func_0x00018015bca0(arg1, &var_58h, uVar6, uVar5);
    uVar5 = *(undefined8 *)arg2;
    LOCK();
    *(int32_t *)(*pauVar9 + 8) = *(int32_t *)(*pauVar9 + 8) + 1;
    UNLOCK();
    func_0x00018015bbd0(arg1, &var_10h, &var_58h, uVar5, arg4);
    uVar11 = *(uint64_t *)arg1;
    while( true ) {
        uVar12 = uVar11;
        uVar10 = *(uint64_t *)(arg1 + 8);
        if (uVar12 == uVar10) break;
        cVar8 = -1;
        if (uVar10 <= uVar12) {
            cVar8 = '\x01';
        }
        if (-1 < cVar8) break;
        uVar11 = uVar12 + 0x14;
        if (*(char *)(uVar12 + 0x10) == '\0') {
            fcn.180498030(uVar12, uVar11, uVar10 - uVar11);
            *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -0x14;
            uVar11 = uVar12;
        }
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
    uVar10 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
    uVar11 = *(uint64_t *)(arg1 + 0x18);
    if ((uVar10 < uVar11 || uVar10 - uVar11 == 0) && (*(undefined8 *)(arg1 + 0x18) = 0, uVar11 = 0, uVar10 == 0)) {
        fcn.180060370();
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    piVar3 = (int64_t *)(*(int64_t *)arg1 + uVar11 * 0x14);
    *piVar3 = var_10h;
    piVar3[1] = var_10h;
    *(undefined *)((int64_t)piVar3 + 0x12) = 1;
    LOCK();
    *(int32_t *)(*pauVar9 + 8) = *(int32_t *)(*pauVar9 + 8) + 1;
    UNLOCK();
    func_0x00018015af60(arg1, &var_58h);
    LOCK();
    piVar2 = (int32_t *)(*pauVar9 + 8);
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
        (***(code ***)*pauVar9)(pauVar9);
        LOCK();
        piVar2 = (int32_t *)(*pauVar9 + 0xc);
        iVar4 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar4 == 1) {
            (**(code **)(*(int64_t *)*pauVar9 + 8))(pauVar9);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180160ca0
// Address: 0x180160ca0
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah

void fcn.180160ca0(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    code *pcVar6;
    int32_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    undefined *puVar14;
    undefined *puVar15;
    undefined8 uVar16;
    bool bVar17;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int32_t var_50h;
    int64_t var_4ch;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    puVar14 = auStack_88;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar11 = *(int64_t *)arg1;
    uVar8 = (*(int64_t *)(arg1 + 8) - iVar11 >> 2) * -0x3333333333333333;
    uVar12 = *(uint64_t *)(arg1 + 0x18);
    if (uVar8 < uVar12 || uVar8 - uVar12 == 0) {
        uVar12 = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
        if (uVar8 == 0) {
            fcn.180060370();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    iVar1 = *(int32_t *)(iVar11 + uVar12 * 0x14);
    iVar2 = *(int32_t *)(iVar11 + 4 + uVar12 * 0x14);
    iVar3 = *(int32_t *)(iVar11 + 8 + uVar12 * 0x14);
    iVar4 = *(int32_t *)(iVar11 + 0xc + uVar12 * 0x14);
    bVar17 = SBORROW4(iVar1, iVar3);
    iVar5 = iVar1 - iVar3;
    var_58h._0_4_ = iVar1;
    var_58h._4_4_ = iVar2;
    var_50h = iVar3;
    var_4ch._0_4_ = iVar4;
    if (iVar1 == iVar3) {
        bVar17 = SBORROW4(iVar2, iVar4);
        iVar5 = iVar2 - iVar4;
        if (iVar2 != iVar4) goto code_r0x000180160e22;
        uVar9 = CONCAT44(iVar4, iVar3);
        uVar16 = uVar9;
        if (iVar2 < iVar4) {
            uVar16 = CONCAT44(iVar2, iVar1);
        }
        fcn.18015db90(arg1 + 0x40, &var_60h, uVar16, 1);
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        if (bVar17 != iVar5 < 0) {
            uVar9 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        }
        fcn.18015dd90(arg1 + 0x40, &var_68h, uVar9, 1);
        if (((int32_t)var_60h == (int32_t)var_68h) && (puVar15 = auStack_88, var_60h._4_4_ == var_68h._4_4_))
        goto code_r0x000180160f04;
        uVar9 = fcn.18015d450(arg1 + 0x40, &var_58h);
        fcn.180012c10(arg1 + 0x430, uVar9);
        puVar15 = auStack_88;
        if ((uint64_t)var_40h < 0x10) goto code_r0x000180160f04;
        iVar11 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        puVar14 = auStack_88;
        if (0xfff < var_40h + 1U) {
            iVar10 = iVar11 - *(int64_t *)(iVar11 + -8);
            iVar11 = *(int64_t *)(iVar11 + -8);
            goto joined_r0x000180160eed;
        }
    } else {
code_r0x000180160e22:
        uVar16 = CONCAT44(iVar4, iVar3);
        uVar9 = CONCAT44(iVar2, iVar1);
        uVar13 = uVar16;
        if (bVar17 != iVar5 < 0) {
            uVar13 = uVar9;
        }
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        iVar7 = iVar3;
        if ((iVar1 != iVar3 || iVar2 != iVar4) && bVar17 == iVar5 < 0) {
            iVar7 = iVar1;
        }
        puVar15 = auStack_88;
        if ((int32_t)uVar13 != iVar7) goto code_r0x000180160f04;
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        uVar13 = uVar16;
        if ((iVar1 != iVar3 || iVar2 != iVar4) && bVar17 == iVar5 < 0) {
            uVar13 = uVar9;
        }
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        if (bVar17 != iVar5 < 0) {
            uVar16 = uVar9;
        }
        uVar9 = fcn.18015d450(arg1 + 0x40, &var_58h, uVar16, uVar13);
        fcn.180012c10(arg1 + 0x430, uVar9);
        puVar15 = auStack_88;
        if ((uint64_t)var_40h < 0x10) goto code_r0x000180160f04;
        iVar11 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        if (0xfff < var_40h + 1U) {
            iVar10 = iVar11 - *(int64_t *)(iVar11 + -8);
            iVar11 = *(int64_t *)(iVar11 + -8);
joined_r0x000180160eed:
            puVar14 = auStack_88;
            if (0x1f < iVar10 - 8U) {
                pcVar6 = (code *)swi(0x29);
                iVar11 = (*pcVar6)(5);
                puVar14 = auStack_80;
            }
        }
    }
    *(undefined8 *)(puVar14 + -8) = 0x180160f04;
    fcn.180459c3c(iVar11);
    puVar15 = puVar14;
code_r0x000180160f04:
    *(undefined *)(arg1 + 0x428) = 1;
    *(undefined *)(arg1 + 0x42a) = 1;
    *(undefined8 *)(puVar15 + -8) = 0x180160f3b;
    fcn.180459870(*(uint64_t *)(puVar15 + 0x50) ^ (uint64_t)puVar15);
    return;
}

// ============================================================
// Function: FUN_180160cf2
// Address: 0x180160cf2
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah

void fcn.180160ca0(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    code *pcVar6;
    int32_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    undefined *puVar14;
    undefined *puVar15;
    undefined8 uVar16;
    bool bVar17;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int32_t var_50h;
    int64_t var_4ch;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    puVar14 = auStack_88;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar11 = *(int64_t *)arg1;
    uVar8 = (*(int64_t *)(arg1 + 8) - iVar11 >> 2) * -0x3333333333333333;
    uVar12 = *(uint64_t *)(arg1 + 0x18);
    if (uVar8 < uVar12 || uVar8 - uVar12 == 0) {
        uVar12 = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
        if (uVar8 == 0) {
            fcn.180060370();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    iVar1 = *(int32_t *)(iVar11 + uVar12 * 0x14);
    iVar2 = *(int32_t *)(iVar11 + 4 + uVar12 * 0x14);
    iVar3 = *(int32_t *)(iVar11 + 8 + uVar12 * 0x14);
    iVar4 = *(int32_t *)(iVar11 + 0xc + uVar12 * 0x14);
    bVar17 = SBORROW4(iVar1, iVar3);
    iVar5 = iVar1 - iVar3;
    var_58h._0_4_ = iVar1;
    var_58h._4_4_ = iVar2;
    var_50h = iVar3;
    var_4ch._0_4_ = iVar4;
    if (iVar1 == iVar3) {
        bVar17 = SBORROW4(iVar2, iVar4);
        iVar5 = iVar2 - iVar4;
        if (iVar2 != iVar4) goto code_r0x000180160e22;
        uVar9 = CONCAT44(iVar4, iVar3);
        uVar16 = uVar9;
        if (iVar2 < iVar4) {
            uVar16 = CONCAT44(iVar2, iVar1);
        }
        fcn.18015db90(arg1 + 0x40, &var_60h, uVar16, 1);
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        if (bVar17 != iVar5 < 0) {
            uVar9 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        }
        fcn.18015dd90(arg1 + 0x40, &var_68h, uVar9, 1);
        if (((int32_t)var_60h == (int32_t)var_68h) && (puVar15 = auStack_88, var_60h._4_4_ == var_68h._4_4_))
        goto code_r0x000180160f04;
        uVar9 = fcn.18015d450(arg1 + 0x40, &var_58h);
        fcn.180012c10(arg1 + 0x430, uVar9);
        puVar15 = auStack_88;
        if ((uint64_t)var_40h < 0x10) goto code_r0x000180160f04;
        iVar11 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        puVar14 = auStack_88;
        if (0xfff < var_40h + 1U) {
            iVar10 = iVar11 - *(int64_t *)(iVar11 + -8);
            iVar11 = *(int64_t *)(iVar11 + -8);
            goto joined_r0x000180160eed;
        }
    } else {
code_r0x000180160e22:
        uVar16 = CONCAT44(iVar4, iVar3);
        uVar9 = CONCAT44(iVar2, iVar1);
        uVar13 = uVar16;
        if (bVar17 != iVar5 < 0) {
            uVar13 = uVar9;
        }
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        iVar7 = iVar3;
        if ((iVar1 != iVar3 || iVar2 != iVar4) && bVar17 == iVar5 < 0) {
            iVar7 = iVar1;
        }
        puVar15 = auStack_88;
        if ((int32_t)uVar13 != iVar7) goto code_r0x000180160f04;
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        uVar13 = uVar16;
        if ((iVar1 != iVar3 || iVar2 != iVar4) && bVar17 == iVar5 < 0) {
            uVar13 = uVar9;
        }
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        if (bVar17 != iVar5 < 0) {
            uVar16 = uVar9;
        }
        uVar9 = fcn.18015d450(arg1 + 0x40, &var_58h, uVar16, uVar13);
        fcn.180012c10(arg1 + 0x430, uVar9);
        puVar15 = auStack_88;
        if ((uint64_t)var_40h < 0x10) goto code_r0x000180160f04;
        iVar11 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        if (0xfff < var_40h + 1U) {
            iVar10 = iVar11 - *(int64_t *)(iVar11 + -8);
            iVar11 = *(int64_t *)(iVar11 + -8);
joined_r0x000180160eed:
            puVar14 = auStack_88;
            if (0x1f < iVar10 - 8U) {
                pcVar6 = (code *)swi(0x29);
                iVar11 = (*pcVar6)(5);
                puVar14 = auStack_80;
            }
        }
    }
    *(undefined8 *)(puVar14 + -8) = 0x180160f04;
    fcn.180459c3c(iVar11);
    puVar15 = puVar14;
code_r0x000180160f04:
    *(undefined *)(arg1 + 0x428) = 1;
    *(undefined *)(arg1 + 0x42a) = 1;
    *(undefined8 *)(puVar15 + -8) = 0x180160f3b;
    fcn.180459870(*(uint64_t *)(puVar15 + 0x50) ^ (uint64_t)puVar15);
    return;
}

// ============================================================
// Function: FUN_180160d3f
// Address: 0x180160d3f
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah

void fcn.180160ca0(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    code *pcVar6;
    int32_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    undefined *puVar14;
    undefined *puVar15;
    undefined8 uVar16;
    bool bVar17;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int32_t var_50h;
    int64_t var_4ch;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    puVar14 = auStack_88;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar11 = *(int64_t *)arg1;
    uVar8 = (*(int64_t *)(arg1 + 8) - iVar11 >> 2) * -0x3333333333333333;
    uVar12 = *(uint64_t *)(arg1 + 0x18);
    if (uVar8 < uVar12 || uVar8 - uVar12 == 0) {
        uVar12 = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
        if (uVar8 == 0) {
            fcn.180060370();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    iVar1 = *(int32_t *)(iVar11 + uVar12 * 0x14);
    iVar2 = *(int32_t *)(iVar11 + 4 + uVar12 * 0x14);
    iVar3 = *(int32_t *)(iVar11 + 8 + uVar12 * 0x14);
    iVar4 = *(int32_t *)(iVar11 + 0xc + uVar12 * 0x14);
    bVar17 = SBORROW4(iVar1, iVar3);
    iVar5 = iVar1 - iVar3;
    var_58h._0_4_ = iVar1;
    var_58h._4_4_ = iVar2;
    var_50h = iVar3;
    var_4ch._0_4_ = iVar4;
    if (iVar1 == iVar3) {
        bVar17 = SBORROW4(iVar2, iVar4);
        iVar5 = iVar2 - iVar4;
        if (iVar2 != iVar4) goto code_r0x000180160e22;
        uVar9 = CONCAT44(iVar4, iVar3);
        uVar16 = uVar9;
        if (iVar2 < iVar4) {
            uVar16 = CONCAT44(iVar2, iVar1);
        }
        fcn.18015db90(arg1 + 0x40, &var_60h, uVar16, 1);
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        if (bVar17 != iVar5 < 0) {
            uVar9 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        }
        fcn.18015dd90(arg1 + 0x40, &var_68h, uVar9, 1);
        if (((int32_t)var_60h == (int32_t)var_68h) && (puVar15 = auStack_88, var_60h._4_4_ == var_68h._4_4_))
        goto code_r0x000180160f04;
        uVar9 = fcn.18015d450(arg1 + 0x40, &var_58h);
        fcn.180012c10(arg1 + 0x430, uVar9);
        puVar15 = auStack_88;
        if ((uint64_t)var_40h < 0x10) goto code_r0x000180160f04;
        iVar11 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        puVar14 = auStack_88;
        if (0xfff < var_40h + 1U) {
            iVar10 = iVar11 - *(int64_t *)(iVar11 + -8);
            iVar11 = *(int64_t *)(iVar11 + -8);
            goto joined_r0x000180160eed;
        }
    } else {
code_r0x000180160e22:
        uVar16 = CONCAT44(iVar4, iVar3);
        uVar9 = CONCAT44(iVar2, iVar1);
        uVar13 = uVar16;
        if (bVar17 != iVar5 < 0) {
            uVar13 = uVar9;
        }
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        iVar7 = iVar3;
        if ((iVar1 != iVar3 || iVar2 != iVar4) && bVar17 == iVar5 < 0) {
            iVar7 = iVar1;
        }
        puVar15 = auStack_88;
        if ((int32_t)uVar13 != iVar7) goto code_r0x000180160f04;
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        uVar13 = uVar16;
        if ((iVar1 != iVar3 || iVar2 != iVar4) && bVar17 == iVar5 < 0) {
            uVar13 = uVar9;
        }
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        if (bVar17 != iVar5 < 0) {
            uVar16 = uVar9;
        }
        uVar9 = fcn.18015d450(arg1 + 0x40, &var_58h, uVar16, uVar13);
        fcn.180012c10(arg1 + 0x430, uVar9);
        puVar15 = auStack_88;
        if ((uint64_t)var_40h < 0x10) goto code_r0x000180160f04;
        iVar11 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        if (0xfff < var_40h + 1U) {
            iVar10 = iVar11 - *(int64_t *)(iVar11 + -8);
            iVar11 = *(int64_t *)(iVar11 + -8);
joined_r0x000180160eed:
            puVar14 = auStack_88;
            if (0x1f < iVar10 - 8U) {
                pcVar6 = (code *)swi(0x29);
                iVar11 = (*pcVar6)(5);
                puVar14 = auStack_80;
            }
        }
    }
    *(undefined8 *)(puVar14 + -8) = 0x180160f04;
    fcn.180459c3c(iVar11);
    puVar15 = puVar14;
code_r0x000180160f04:
    *(undefined *)(arg1 + 0x428) = 1;
    *(undefined *)(arg1 + 0x42a) = 1;
    *(undefined8 *)(puVar15 + -8) = 0x180160f3b;
    fcn.180459870(*(uint64_t *)(puVar15 + 0x50) ^ (uint64_t)puVar15);
    return;
}

// ============================================================
// Function: FUN_180160db5
// Address: 0x180160db5
// Size: 398 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah

void fcn.180160ca0(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    code *pcVar6;
    int32_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    undefined *puVar14;
    undefined *puVar15;
    undefined8 uVar16;
    bool bVar17;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int32_t var_50h;
    int64_t var_4ch;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    puVar14 = auStack_88;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar11 = *(int64_t *)arg1;
    uVar8 = (*(int64_t *)(arg1 + 8) - iVar11 >> 2) * -0x3333333333333333;
    uVar12 = *(uint64_t *)(arg1 + 0x18);
    if (uVar8 < uVar12 || uVar8 - uVar12 == 0) {
        uVar12 = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
        if (uVar8 == 0) {
            fcn.180060370();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    iVar1 = *(int32_t *)(iVar11 + uVar12 * 0x14);
    iVar2 = *(int32_t *)(iVar11 + 4 + uVar12 * 0x14);
    iVar3 = *(int32_t *)(iVar11 + 8 + uVar12 * 0x14);
    iVar4 = *(int32_t *)(iVar11 + 0xc + uVar12 * 0x14);
    bVar17 = SBORROW4(iVar1, iVar3);
    iVar5 = iVar1 - iVar3;
    var_58h._0_4_ = iVar1;
    var_58h._4_4_ = iVar2;
    var_50h = iVar3;
    var_4ch._0_4_ = iVar4;
    if (iVar1 == iVar3) {
        bVar17 = SBORROW4(iVar2, iVar4);
        iVar5 = iVar2 - iVar4;
        if (iVar2 != iVar4) goto code_r0x000180160e22;
        uVar9 = CONCAT44(iVar4, iVar3);
        uVar16 = uVar9;
        if (iVar2 < iVar4) {
            uVar16 = CONCAT44(iVar2, iVar1);
        }
        fcn.18015db90(arg1 + 0x40, &var_60h, uVar16, 1);
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        if (bVar17 != iVar5 < 0) {
            uVar9 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        }
        fcn.18015dd90(arg1 + 0x40, &var_68h, uVar9, 1);
        if (((int32_t)var_60h == (int32_t)var_68h) && (puVar15 = auStack_88, var_60h._4_4_ == var_68h._4_4_))
        goto code_r0x000180160f04;
        uVar9 = fcn.18015d450(arg1 + 0x40, &var_58h);
        fcn.180012c10(arg1 + 0x430, uVar9);
        puVar15 = auStack_88;
        if ((uint64_t)var_40h < 0x10) goto code_r0x000180160f04;
        iVar11 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        puVar14 = auStack_88;
        if (0xfff < var_40h + 1U) {
            iVar10 = iVar11 - *(int64_t *)(iVar11 + -8);
            iVar11 = *(int64_t *)(iVar11 + -8);
            goto joined_r0x000180160eed;
        }
    } else {
code_r0x000180160e22:
        uVar16 = CONCAT44(iVar4, iVar3);
        uVar9 = CONCAT44(iVar2, iVar1);
        uVar13 = uVar16;
        if (bVar17 != iVar5 < 0) {
            uVar13 = uVar9;
        }
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        iVar7 = iVar3;
        if ((iVar1 != iVar3 || iVar2 != iVar4) && bVar17 == iVar5 < 0) {
            iVar7 = iVar1;
        }
        puVar15 = auStack_88;
        if ((int32_t)uVar13 != iVar7) goto code_r0x000180160f04;
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        uVar13 = uVar16;
        if ((iVar1 != iVar3 || iVar2 != iVar4) && bVar17 == iVar5 < 0) {
            uVar13 = uVar9;
        }
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        if (bVar17 != iVar5 < 0) {
            uVar16 = uVar9;
        }
        uVar9 = fcn.18015d450(arg1 + 0x40, &var_58h, uVar16, uVar13);
        fcn.180012c10(arg1 + 0x430, uVar9);
        puVar15 = auStack_88;
        if ((uint64_t)var_40h < 0x10) goto code_r0x000180160f04;
        iVar11 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        if (0xfff < var_40h + 1U) {
            iVar10 = iVar11 - *(int64_t *)(iVar11 + -8);
            iVar11 = *(int64_t *)(iVar11 + -8);
joined_r0x000180160eed:
            puVar14 = auStack_88;
            if (0x1f < iVar10 - 8U) {
                pcVar6 = (code *)swi(0x29);
                iVar11 = (*pcVar6)(5);
                puVar14 = auStack_80;
            }
        }
    }
    *(undefined8 *)(puVar14 + -8) = 0x180160f04;
    fcn.180459c3c(iVar11);
    puVar15 = puVar14;
code_r0x000180160f04:
    *(undefined *)(arg1 + 0x428) = 1;
    *(undefined *)(arg1 + 0x42a) = 1;
    *(undefined8 *)(puVar15 + -8) = 0x180160f3b;
    fcn.180459870(*(uint64_t *)(puVar15 + 0x50) ^ (uint64_t)puVar15);
    return;
}

// ============================================================
// Function: FUN_180160f43
// Address: 0x180160f43
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah

void fcn.180160ca0(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    code *pcVar6;
    int32_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    undefined *puVar14;
    undefined *puVar15;
    undefined8 uVar16;
    bool bVar17;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int32_t var_50h;
    int64_t var_4ch;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    puVar14 = auStack_88;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar11 = *(int64_t *)arg1;
    uVar8 = (*(int64_t *)(arg1 + 8) - iVar11 >> 2) * -0x3333333333333333;
    uVar12 = *(uint64_t *)(arg1 + 0x18);
    if (uVar8 < uVar12 || uVar8 - uVar12 == 0) {
        uVar12 = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
        if (uVar8 == 0) {
            fcn.180060370();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    iVar1 = *(int32_t *)(iVar11 + uVar12 * 0x14);
    iVar2 = *(int32_t *)(iVar11 + 4 + uVar12 * 0x14);
    iVar3 = *(int32_t *)(iVar11 + 8 + uVar12 * 0x14);
    iVar4 = *(int32_t *)(iVar11 + 0xc + uVar12 * 0x14);
    bVar17 = SBORROW4(iVar1, iVar3);
    iVar5 = iVar1 - iVar3;
    var_58h._0_4_ = iVar1;
    var_58h._4_4_ = iVar2;
    var_50h = iVar3;
    var_4ch._0_4_ = iVar4;
    if (iVar1 == iVar3) {
        bVar17 = SBORROW4(iVar2, iVar4);
        iVar5 = iVar2 - iVar4;
        if (iVar2 != iVar4) goto code_r0x000180160e22;
        uVar9 = CONCAT44(iVar4, iVar3);
        uVar16 = uVar9;
        if (iVar2 < iVar4) {
            uVar16 = CONCAT44(iVar2, iVar1);
        }
        fcn.18015db90(arg1 + 0x40, &var_60h, uVar16, 1);
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        if (bVar17 != iVar5 < 0) {
            uVar9 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        }
        fcn.18015dd90(arg1 + 0x40, &var_68h, uVar9, 1);
        if (((int32_t)var_60h == (int32_t)var_68h) && (puVar15 = auStack_88, var_60h._4_4_ == var_68h._4_4_))
        goto code_r0x000180160f04;
        uVar9 = fcn.18015d450(arg1 + 0x40, &var_58h);
        fcn.180012c10(arg1 + 0x430, uVar9);
        puVar15 = auStack_88;
        if ((uint64_t)var_40h < 0x10) goto code_r0x000180160f04;
        iVar11 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        puVar14 = auStack_88;
        if (0xfff < var_40h + 1U) {
            iVar10 = iVar11 - *(int64_t *)(iVar11 + -8);
            iVar11 = *(int64_t *)(iVar11 + -8);
            goto joined_r0x000180160eed;
        }
    } else {
code_r0x000180160e22:
        uVar16 = CONCAT44(iVar4, iVar3);
        uVar9 = CONCAT44(iVar2, iVar1);
        uVar13 = uVar16;
        if (bVar17 != iVar5 < 0) {
            uVar13 = uVar9;
        }
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        iVar7 = iVar3;
        if ((iVar1 != iVar3 || iVar2 != iVar4) && bVar17 == iVar5 < 0) {
            iVar7 = iVar1;
        }
        puVar15 = auStack_88;
        if ((int32_t)uVar13 != iVar7) goto code_r0x000180160f04;
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        uVar13 = uVar16;
        if ((iVar1 != iVar3 || iVar2 != iVar4) && bVar17 == iVar5 < 0) {
            uVar13 = uVar9;
        }
        bVar17 = SBORROW4(iVar1, iVar3);
        iVar5 = iVar1 - iVar3;
        if (iVar1 == iVar3) {
            bVar17 = SBORROW4(iVar2, iVar4);
            iVar5 = iVar2 - iVar4;
        }
        if (bVar17 != iVar5 < 0) {
            uVar16 = uVar9;
        }
        uVar9 = fcn.18015d450(arg1 + 0x40, &var_58h, uVar16, uVar13);
        fcn.180012c10(arg1 + 0x430, uVar9);
        puVar15 = auStack_88;
        if ((uint64_t)var_40h < 0x10) goto code_r0x000180160f04;
        iVar11 = CONCAT44(var_58h._4_4_, (int32_t)var_58h);
        if (0xfff < var_40h + 1U) {
            iVar10 = iVar11 - *(int64_t *)(iVar11 + -8);
            iVar11 = *(int64_t *)(iVar11 + -8);
joined_r0x000180160eed:
            puVar14 = auStack_88;
            if (0x1f < iVar10 - 8U) {
                pcVar6 = (code *)swi(0x29);
                iVar11 = (*pcVar6)(5);
                puVar14 = auStack_80;
            }
        }
    }
    *(undefined8 *)(puVar14 + -8) = 0x180160f04;
    fcn.180459c3c(iVar11);
    puVar15 = puVar14;
code_r0x000180160f04:
    *(undefined *)(arg1 + 0x428) = 1;
    *(undefined *)(arg1 + 0x42a) = 1;
    *(undefined8 *)(puVar15 + -8) = 0x180160f3b;
    fcn.180459870(*(uint64_t *)(puVar15 + 0x50) ^ (uint64_t)puVar15);
    return;
}

// ============================================================
// Function: FUN_180160f50
// Address: 0x180160f50
// Size: 92 bytes
// ============================================================
void fcn.180160f50(int64_t arg1)
{
    int64_t in_stack_00000018;
    int64_t var_18h;
    int64_t var_10h;
    
    var_10h = *(int64_t *)(arg1 + 0x440);
    if (var_10h != 0) {
        var_18h = arg1 + 0x430;
        if (0xf < *(uint64_t *)(arg1 + 0x448)) {
            var_18h = *(int64_t *)var_18h;
        }
        fcn.1801604f0(arg1, (int64_t)&var_18h, in_stack_00000018);
        *(undefined2 *)(arg1 + 0x429) = 1;
    }
    return;
}

// ============================================================
// Function: FUN_180160fb0
// Address: 0x180160fb0
// Size: 92 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.180160fb0(int64_t arg1)
{
    int64_t var_18h;
    int64_t var_10h;
    
    var_10h = *(int64_t *)(arg1 + 0x440);
    if (var_10h != 0) {
        var_18h = arg1 + 0x430;
        if (0xf < *(uint64_t *)(arg1 + 0x448)) {
            var_18h = *(int64_t *)var_18h;
        }
        fcn.180160630(arg1, (int64_t)&var_18h);
        *(undefined2 *)(arg1 + 0x429) = 1;
    }
    return;
}

// ============================================================
// Function: FUN_180161010
// Address: 0x180161010
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.180161010(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    uint64_t uVar8;
    bool bVar9;
    bool bVar10;
    
    *(undefined *)(arg1 + 2) = 1;
    uVar8 = (*(int64_t *)(arg2 + 8) - *(int64_t *)arg2 >> 2) * -0x3333333333333333;
    uVar5 = *(uint64_t *)(arg2 + 0x18);
    if (uVar8 < uVar5 || uVar8 - uVar5 == 0) {
        uVar5 = 0;
        *(undefined8 *)(arg2 + 0x18) = 0;
        if (uVar8 == 0) {
            fcn.180060370();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
    }
    puVar7 = (undefined8 *)(*(int64_t *)arg2 + uVar5 * 0x14);
    iVar1 = *(int32_t *)(puVar7 + 1);
    iVar2 = *(int32_t *)puVar7;
    bVar10 = SBORROW4(iVar2, iVar1);
    iVar3 = iVar2 - iVar1;
    bVar9 = iVar2 == iVar1;
    if (bVar9) {
        iVar1 = *(int32_t *)((int64_t)puVar7 + 0xc);
        iVar2 = *(int32_t *)((int64_t)puVar7 + 4);
        bVar10 = SBORROW4(iVar2, iVar1);
        iVar3 = iVar2 - iVar1;
        bVar9 = iVar2 == iVar1;
    }
    if (bVar9 || bVar10 != iVar3 < 0) {
        puVar7 = puVar7 + 1;
    }
    *(undefined8 *)(arg1 + 4) = *puVar7;
    iVar6 = fcn.18045838c();
    *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x30) * 10000 + iVar6;
    return;
}

// ============================================================
// Function: FUN_1801610a0
// Address: 0x1801610a0
// Size: 137 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah

void fcn.1801610a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    code *pcVar2;
    undefined uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    char cVar7;
    uint64_t uVar8;
    undefined8 unaff_RBX;
    int64_t *piVar9;
    undefined *puVar10;
    undefined8 unaff_R14;
    bool bVar11;
    bool bVar12;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_28h;
    int64_t var_20h;
    
    puVar10 = auStack_68;
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    uVar4 = fcn.18015d450(arg2, &var_40h, *(undefined8 *)(arg1 + 0xc), *(undefined8 *)(arg1 + 4));
    fcn.180012c10(arg1 + 0xa0, uVar4);
    if (0xf < (uint64_t)var_28h) {
        iVar5 = var_40h;
        puVar10 = auStack_68;
        if ((0xfff < var_28h + 1U) &&
           (iVar5 = *(int64_t *)(var_40h + -8), puVar10 = auStack_68, 0x1f < (var_40h - iVar5) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar10 = auStack_60;
        }
        *(undefined8 *)(puVar10 + -8) = 0x180161126;
        fcn.180459c3c(iVar5);
    }
    iVar1 = *(int32_t *)(arg1 + 8);
    *(undefined8 *)(puVar10 + 0x88) = unaff_R14;
    if (iVar1 == 0) {
        *(undefined2 *)(arg1 + 0xe8) = 0;
        cVar7 = *(char *)((int64_t)*(int32_t *)(arg1 + 4) * 0x38 + 0x18 + *(int64_t *)arg2);
        bVar11 = cVar7 == '\x01';
        bVar12 = (uint8_t)(cVar7 - 2U) < 4;
    } else {
        iVar5 = *(int64_t *)arg2;
        uVar8 = (uint64_t)*(int32_t *)(arg1 + 4);
        uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
        if (uVar6 < uVar8 || uVar6 - uVar8 == 0) goto code_r0x0001801612d8;
        *(undefined8 *)(puVar10 + 0x80) = unaff_RBX;
        piVar9 = (int64_t *)(uVar8 * 0x38 + iVar5);
        *(undefined8 *)(puVar10 + -8) = 0x1801611a7;
        uVar6 = fcn.18015d7b0(arg2, piVar9, iVar1 + -1);
        if (uVar6 < (uint64_t)(piVar9[1] - *piVar9 >> 2)) {
            cVar7 = *(char *)(*piVar9 + 2 + uVar6 * 4);
            if (1 < (uint8_t)(cVar7 - 7U)) goto code_r0x0001801611d4;
            uVar3 = 1;
        } else {
            cVar7 = '\0';
code_r0x0001801611d4:
            uVar3 = 0;
        }
        *(undefined *)(arg1 + 0xe8) = uVar3;
        bVar11 = cVar7 == '\t';
        *(bool *)(arg1 + 0xe9) = cVar7 == '\x03';
        bVar12 = cVar7 == '\x04';
    }
    *(bool *)(arg1 + 0xea) = bVar11;
    *(bool *)(arg1 + 0xeb) = bVar12;
    *(int64_t *)(arg1 + 0xc0) = (int64_t)*(int32_t *)(arg1 + 4);
    *(int64_t *)(arg1 + 200) = (int64_t)*(int32_t *)(arg1 + 0x10);
    iVar5 = *(int64_t *)arg2;
    uVar8 = (uint64_t)(int32_t)*(undefined8 *)(arg1 + 0xc);
    *(undefined8 *)(puVar10 + 0x20) = *(undefined8 *)(arg1 + 0xc);
    uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
    if (uVar8 <= uVar6 && uVar6 - uVar8 != 0) {
        *(undefined8 *)(puVar10 + -8) = 0x180161256;
        uVar4 = fcn.18015d7b0(arg2, uVar8 * 0x38 + iVar5, *(undefined4 *)(puVar10 + 0x24));
        *(undefined8 *)(arg1 + 0xd0) = uVar4;
        *(int64_t *)(arg1 + 0xd8) = (int64_t)*(int32_t *)(arg1 + 8);
        iVar5 = *(int64_t *)arg2;
        uVar8 = (uint64_t)(int32_t)*(undefined8 *)(arg1 + 4);
        *(undefined8 *)(puVar10 + 0x20) = *(undefined8 *)(arg1 + 4);
        uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
        if (uVar8 <= uVar6 && uVar6 - uVar8 != 0) {
            *(undefined8 *)(puVar10 + -8) = 0x18016129f;
            uVar4 = fcn.18015d7b0(arg2, uVar8 * 0x38 + iVar5, *(undefined4 *)(puVar10 + 0x24));
            *(undefined8 *)(arg1 + 0xe0) = uVar4;
            *(undefined8 *)(arg1 + 0xf8) = *(undefined8 *)(arg1 + 0x98);
            *(int64_t *)(arg1 + 0xf0) = arg3;
            *(undefined8 *)(puVar10 + -8) = 0x1801612d0;
            fcn.180459870(*(uint64_t *)(puVar10 + 0x48) ^ (uint64_t)puVar10);
            return;
        }
    }
code_r0x0001801612d8:
    *(undefined8 *)(puVar10 + -8) = 0x1801612dd;
    fcn.180060370();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180161129
// Address: 0x180161129
// Size: 100 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah

void fcn.1801610a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    code *pcVar2;
    undefined uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    char cVar7;
    uint64_t uVar8;
    undefined8 unaff_RBX;
    int64_t *piVar9;
    undefined *puVar10;
    undefined8 unaff_R14;
    bool bVar11;
    bool bVar12;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_28h;
    int64_t var_20h;
    
    puVar10 = auStack_68;
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    uVar4 = fcn.18015d450(arg2, &var_40h, *(undefined8 *)(arg1 + 0xc), *(undefined8 *)(arg1 + 4));
    fcn.180012c10(arg1 + 0xa0, uVar4);
    if (0xf < (uint64_t)var_28h) {
        iVar5 = var_40h;
        puVar10 = auStack_68;
        if ((0xfff < var_28h + 1U) &&
           (iVar5 = *(int64_t *)(var_40h + -8), puVar10 = auStack_68, 0x1f < (var_40h - iVar5) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar10 = auStack_60;
        }
        *(undefined8 *)(puVar10 + -8) = 0x180161126;
        fcn.180459c3c(iVar5);
    }
    iVar1 = *(int32_t *)(arg1 + 8);
    *(undefined8 *)(puVar10 + 0x88) = unaff_R14;
    if (iVar1 == 0) {
        *(undefined2 *)(arg1 + 0xe8) = 0;
        cVar7 = *(char *)((int64_t)*(int32_t *)(arg1 + 4) * 0x38 + 0x18 + *(int64_t *)arg2);
        bVar11 = cVar7 == '\x01';
        bVar12 = (uint8_t)(cVar7 - 2U) < 4;
    } else {
        iVar5 = *(int64_t *)arg2;
        uVar8 = (uint64_t)*(int32_t *)(arg1 + 4);
        uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
        if (uVar6 < uVar8 || uVar6 - uVar8 == 0) goto code_r0x0001801612d8;
        *(undefined8 *)(puVar10 + 0x80) = unaff_RBX;
        piVar9 = (int64_t *)(uVar8 * 0x38 + iVar5);
        *(undefined8 *)(puVar10 + -8) = 0x1801611a7;
        uVar6 = fcn.18015d7b0(arg2, piVar9, iVar1 + -1);
        if (uVar6 < (uint64_t)(piVar9[1] - *piVar9 >> 2)) {
            cVar7 = *(char *)(*piVar9 + 2 + uVar6 * 4);
            if (1 < (uint8_t)(cVar7 - 7U)) goto code_r0x0001801611d4;
            uVar3 = 1;
        } else {
            cVar7 = '\0';
code_r0x0001801611d4:
            uVar3 = 0;
        }
        *(undefined *)(arg1 + 0xe8) = uVar3;
        bVar11 = cVar7 == '\t';
        *(bool *)(arg1 + 0xe9) = cVar7 == '\x03';
        bVar12 = cVar7 == '\x04';
    }
    *(bool *)(arg1 + 0xea) = bVar11;
    *(bool *)(arg1 + 0xeb) = bVar12;
    *(int64_t *)(arg1 + 0xc0) = (int64_t)*(int32_t *)(arg1 + 4);
    *(int64_t *)(arg1 + 200) = (int64_t)*(int32_t *)(arg1 + 0x10);
    iVar5 = *(int64_t *)arg2;
    uVar8 = (uint64_t)(int32_t)*(undefined8 *)(arg1 + 0xc);
    *(undefined8 *)(puVar10 + 0x20) = *(undefined8 *)(arg1 + 0xc);
    uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
    if (uVar8 <= uVar6 && uVar6 - uVar8 != 0) {
        *(undefined8 *)(puVar10 + -8) = 0x180161256;
        uVar4 = fcn.18015d7b0(arg2, uVar8 * 0x38 + iVar5, *(undefined4 *)(puVar10 + 0x24));
        *(undefined8 *)(arg1 + 0xd0) = uVar4;
        *(int64_t *)(arg1 + 0xd8) = (int64_t)*(int32_t *)(arg1 + 8);
        iVar5 = *(int64_t *)arg2;
        uVar8 = (uint64_t)(int32_t)*(undefined8 *)(arg1 + 4);
        *(undefined8 *)(puVar10 + 0x20) = *(undefined8 *)(arg1 + 4);
        uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
        if (uVar8 <= uVar6 && uVar6 - uVar8 != 0) {
            *(undefined8 *)(puVar10 + -8) = 0x18016129f;
            uVar4 = fcn.18015d7b0(arg2, uVar8 * 0x38 + iVar5, *(undefined4 *)(puVar10 + 0x24));
            *(undefined8 *)(arg1 + 0xe0) = uVar4;
            *(undefined8 *)(arg1 + 0xf8) = *(undefined8 *)(arg1 + 0x98);
            *(int64_t *)(arg1 + 0xf0) = arg3;
            *(undefined8 *)(puVar10 + -8) = 0x1801612d0;
            fcn.180459870(*(uint64_t *)(puVar10 + 0x48) ^ (uint64_t)puVar10);
            return;
        }
    }
code_r0x0001801612d8:
    *(undefined8 *)(puVar10 + -8) = 0x1801612dd;
    fcn.180060370();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_18016118d
// Address: 0x18016118d
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah

void fcn.1801610a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    code *pcVar2;
    undefined uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    char cVar7;
    uint64_t uVar8;
    undefined8 unaff_RBX;
    int64_t *piVar9;
    undefined *puVar10;
    undefined8 unaff_R14;
    bool bVar11;
    bool bVar12;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_28h;
    int64_t var_20h;
    
    puVar10 = auStack_68;
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    uVar4 = fcn.18015d450(arg2, &var_40h, *(undefined8 *)(arg1 + 0xc), *(undefined8 *)(arg1 + 4));
    fcn.180012c10(arg1 + 0xa0, uVar4);
    if (0xf < (uint64_t)var_28h) {
        iVar5 = var_40h;
        puVar10 = auStack_68;
        if ((0xfff < var_28h + 1U) &&
           (iVar5 = *(int64_t *)(var_40h + -8), puVar10 = auStack_68, 0x1f < (var_40h - iVar5) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar10 = auStack_60;
        }
        *(undefined8 *)(puVar10 + -8) = 0x180161126;
        fcn.180459c3c(iVar5);
    }
    iVar1 = *(int32_t *)(arg1 + 8);
    *(undefined8 *)(puVar10 + 0x88) = unaff_R14;
    if (iVar1 == 0) {
        *(undefined2 *)(arg1 + 0xe8) = 0;
        cVar7 = *(char *)((int64_t)*(int32_t *)(arg1 + 4) * 0x38 + 0x18 + *(int64_t *)arg2);
        bVar11 = cVar7 == '\x01';
        bVar12 = (uint8_t)(cVar7 - 2U) < 4;
    } else {
        iVar5 = *(int64_t *)arg2;
        uVar8 = (uint64_t)*(int32_t *)(arg1 + 4);
        uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
        if (uVar6 < uVar8 || uVar6 - uVar8 == 0) goto code_r0x0001801612d8;
        *(undefined8 *)(puVar10 + 0x80) = unaff_RBX;
        piVar9 = (int64_t *)(uVar8 * 0x38 + iVar5);
        *(undefined8 *)(puVar10 + -8) = 0x1801611a7;
        uVar6 = fcn.18015d7b0(arg2, piVar9, iVar1 + -1);
        if (uVar6 < (uint64_t)(piVar9[1] - *piVar9 >> 2)) {
            cVar7 = *(char *)(*piVar9 + 2 + uVar6 * 4);
            if (1 < (uint8_t)(cVar7 - 7U)) goto code_r0x0001801611d4;
            uVar3 = 1;
        } else {
            cVar7 = '\0';
code_r0x0001801611d4:
            uVar3 = 0;
        }
        *(undefined *)(arg1 + 0xe8) = uVar3;
        bVar11 = cVar7 == '\t';
        *(bool *)(arg1 + 0xe9) = cVar7 == '\x03';
        bVar12 = cVar7 == '\x04';
    }
    *(bool *)(arg1 + 0xea) = bVar11;
    *(bool *)(arg1 + 0xeb) = bVar12;
    *(int64_t *)(arg1 + 0xc0) = (int64_t)*(int32_t *)(arg1 + 4);
    *(int64_t *)(arg1 + 200) = (int64_t)*(int32_t *)(arg1 + 0x10);
    iVar5 = *(int64_t *)arg2;
    uVar8 = (uint64_t)(int32_t)*(undefined8 *)(arg1 + 0xc);
    *(undefined8 *)(puVar10 + 0x20) = *(undefined8 *)(arg1 + 0xc);
    uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
    if (uVar8 <= uVar6 && uVar6 - uVar8 != 0) {
        *(undefined8 *)(puVar10 + -8) = 0x180161256;
        uVar4 = fcn.18015d7b0(arg2, uVar8 * 0x38 + iVar5, *(undefined4 *)(puVar10 + 0x24));
        *(undefined8 *)(arg1 + 0xd0) = uVar4;
        *(int64_t *)(arg1 + 0xd8) = (int64_t)*(int32_t *)(arg1 + 8);
        iVar5 = *(int64_t *)arg2;
        uVar8 = (uint64_t)(int32_t)*(undefined8 *)(arg1 + 4);
        *(undefined8 *)(puVar10 + 0x20) = *(undefined8 *)(arg1 + 4);
        uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
        if (uVar8 <= uVar6 && uVar6 - uVar8 != 0) {
            *(undefined8 *)(puVar10 + -8) = 0x18016129f;
            uVar4 = fcn.18015d7b0(arg2, uVar8 * 0x38 + iVar5, *(undefined4 *)(puVar10 + 0x24));
            *(undefined8 *)(arg1 + 0xe0) = uVar4;
            *(undefined8 *)(arg1 + 0xf8) = *(undefined8 *)(arg1 + 0x98);
            *(int64_t *)(arg1 + 0xf0) = arg3;
            *(undefined8 *)(puVar10 + -8) = 0x1801612d0;
            fcn.180459870(*(uint64_t *)(puVar10 + 0x48) ^ (uint64_t)puVar10);
            return;
        }
    }
code_r0x0001801612d8:
    *(undefined8 *)(puVar10 + -8) = 0x1801612dd;
    fcn.180060370();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1801611c2
// Address: 0x1801611c2
// Size: 278 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah

void fcn.1801610a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    code *pcVar2;
    undefined uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    char cVar7;
    uint64_t uVar8;
    undefined8 unaff_RBX;
    int64_t *piVar9;
    undefined *puVar10;
    undefined8 unaff_R14;
    bool bVar11;
    bool bVar12;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_28h;
    int64_t var_20h;
    
    puVar10 = auStack_68;
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    uVar4 = fcn.18015d450(arg2, &var_40h, *(undefined8 *)(arg1 + 0xc), *(undefined8 *)(arg1 + 4));
    fcn.180012c10(arg1 + 0xa0, uVar4);
    if (0xf < (uint64_t)var_28h) {
        iVar5 = var_40h;
        puVar10 = auStack_68;
        if ((0xfff < var_28h + 1U) &&
           (iVar5 = *(int64_t *)(var_40h + -8), puVar10 = auStack_68, 0x1f < (var_40h - iVar5) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar10 = auStack_60;
        }
        *(undefined8 *)(puVar10 + -8) = 0x180161126;
        fcn.180459c3c(iVar5);
    }
    iVar1 = *(int32_t *)(arg1 + 8);
    *(undefined8 *)(puVar10 + 0x88) = unaff_R14;
    if (iVar1 == 0) {
        *(undefined2 *)(arg1 + 0xe8) = 0;
        cVar7 = *(char *)((int64_t)*(int32_t *)(arg1 + 4) * 0x38 + 0x18 + *(int64_t *)arg2);
        bVar11 = cVar7 == '\x01';
        bVar12 = (uint8_t)(cVar7 - 2U) < 4;
    } else {
        iVar5 = *(int64_t *)arg2;
        uVar8 = (uint64_t)*(int32_t *)(arg1 + 4);
        uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
        if (uVar6 < uVar8 || uVar6 - uVar8 == 0) goto code_r0x0001801612d8;
        *(undefined8 *)(puVar10 + 0x80) = unaff_RBX;
        piVar9 = (int64_t *)(uVar8 * 0x38 + iVar5);
        *(undefined8 *)(puVar10 + -8) = 0x1801611a7;
        uVar6 = fcn.18015d7b0(arg2, piVar9, iVar1 + -1);
        if (uVar6 < (uint64_t)(piVar9[1] - *piVar9 >> 2)) {
            cVar7 = *(char *)(*piVar9 + 2 + uVar6 * 4);
            if (1 < (uint8_t)(cVar7 - 7U)) goto code_r0x0001801611d4;
            uVar3 = 1;
        } else {
            cVar7 = '\0';
code_r0x0001801611d4:
            uVar3 = 0;
        }
        *(undefined *)(arg1 + 0xe8) = uVar3;
        bVar11 = cVar7 == '\t';
        *(bool *)(arg1 + 0xe9) = cVar7 == '\x03';
        bVar12 = cVar7 == '\x04';
    }
    *(bool *)(arg1 + 0xea) = bVar11;
    *(bool *)(arg1 + 0xeb) = bVar12;
    *(int64_t *)(arg1 + 0xc0) = (int64_t)*(int32_t *)(arg1 + 4);
    *(int64_t *)(arg1 + 200) = (int64_t)*(int32_t *)(arg1 + 0x10);
    iVar5 = *(int64_t *)arg2;
    uVar8 = (uint64_t)(int32_t)*(undefined8 *)(arg1 + 0xc);
    *(undefined8 *)(puVar10 + 0x20) = *(undefined8 *)(arg1 + 0xc);
    uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
    if (uVar8 <= uVar6 && uVar6 - uVar8 != 0) {
        *(undefined8 *)(puVar10 + -8) = 0x180161256;
        uVar4 = fcn.18015d7b0(arg2, uVar8 * 0x38 + iVar5, *(undefined4 *)(puVar10 + 0x24));
        *(undefined8 *)(arg1 + 0xd0) = uVar4;
        *(int64_t *)(arg1 + 0xd8) = (int64_t)*(int32_t *)(arg1 + 8);
        iVar5 = *(int64_t *)arg2;
        uVar8 = (uint64_t)(int32_t)*(undefined8 *)(arg1 + 4);
        *(undefined8 *)(puVar10 + 0x20) = *(undefined8 *)(arg1 + 4);
        uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
        if (uVar8 <= uVar6 && uVar6 - uVar8 != 0) {
            *(undefined8 *)(puVar10 + -8) = 0x18016129f;
            uVar4 = fcn.18015d7b0(arg2, uVar8 * 0x38 + iVar5, *(undefined4 *)(puVar10 + 0x24));
            *(undefined8 *)(arg1 + 0xe0) = uVar4;
            *(undefined8 *)(arg1 + 0xf8) = *(undefined8 *)(arg1 + 0x98);
            *(int64_t *)(arg1 + 0xf0) = arg3;
            *(undefined8 *)(puVar10 + -8) = 0x1801612d0;
            fcn.180459870(*(uint64_t *)(puVar10 + 0x48) ^ (uint64_t)puVar10);
            return;
        }
    }
code_r0x0001801612d8:
    *(undefined8 *)(puVar10 + -8) = 0x1801612dd;
    fcn.180060370();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1801612d8
// Address: 0x1801612d8
// Size: 6 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah

void fcn.1801610a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    code *pcVar2;
    undefined uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    char cVar7;
    uint64_t uVar8;
    undefined8 unaff_RBX;
    int64_t *piVar9;
    undefined *puVar10;
    undefined8 unaff_R14;
    bool bVar11;
    bool bVar12;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_28h;
    int64_t var_20h;
    
    puVar10 = auStack_68;
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    uVar4 = fcn.18015d450(arg2, &var_40h, *(undefined8 *)(arg1 + 0xc), *(undefined8 *)(arg1 + 4));
    fcn.180012c10(arg1 + 0xa0, uVar4);
    if (0xf < (uint64_t)var_28h) {
        iVar5 = var_40h;
        puVar10 = auStack_68;
        if ((0xfff < var_28h + 1U) &&
           (iVar5 = *(int64_t *)(var_40h + -8), puVar10 = auStack_68, 0x1f < (var_40h - iVar5) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar10 = auStack_60;
        }
        *(undefined8 *)(puVar10 + -8) = 0x180161126;
        fcn.180459c3c(iVar5);
    }
    iVar1 = *(int32_t *)(arg1 + 8);
    *(undefined8 *)(puVar10 + 0x88) = unaff_R14;
    if (iVar1 == 0) {
        *(undefined2 *)(arg1 + 0xe8) = 0;
        cVar7 = *(char *)((int64_t)*(int32_t *)(arg1 + 4) * 0x38 + 0x18 + *(int64_t *)arg2);
        bVar11 = cVar7 == '\x01';
        bVar12 = (uint8_t)(cVar7 - 2U) < 4;
    } else {
        iVar5 = *(int64_t *)arg2;
        uVar8 = (uint64_t)*(int32_t *)(arg1 + 4);
        uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
        if (uVar6 < uVar8 || uVar6 - uVar8 == 0) goto code_r0x0001801612d8;
        *(undefined8 *)(puVar10 + 0x80) = unaff_RBX;
        piVar9 = (int64_t *)(uVar8 * 0x38 + iVar5);
        *(undefined8 *)(puVar10 + -8) = 0x1801611a7;
        uVar6 = fcn.18015d7b0(arg2, piVar9, iVar1 + -1);
        if (uVar6 < (uint64_t)(piVar9[1] - *piVar9 >> 2)) {
            cVar7 = *(char *)(*piVar9 + 2 + uVar6 * 4);
            if (1 < (uint8_t)(cVar7 - 7U)) goto code_r0x0001801611d4;
            uVar3 = 1;
        } else {
            cVar7 = '\0';
code_r0x0001801611d4:
            uVar3 = 0;
        }
        *(undefined *)(arg1 + 0xe8) = uVar3;
        bVar11 = cVar7 == '\t';
        *(bool *)(arg1 + 0xe9) = cVar7 == '\x03';
        bVar12 = cVar7 == '\x04';
    }
    *(bool *)(arg1 + 0xea) = bVar11;
    *(bool *)(arg1 + 0xeb) = bVar12;
    *(int64_t *)(arg1 + 0xc0) = (int64_t)*(int32_t *)(arg1 + 4);
    *(int64_t *)(arg1 + 200) = (int64_t)*(int32_t *)(arg1 + 0x10);
    iVar5 = *(int64_t *)arg2;
    uVar8 = (uint64_t)(int32_t)*(undefined8 *)(arg1 + 0xc);
    *(undefined8 *)(puVar10 + 0x20) = *(undefined8 *)(arg1 + 0xc);
    uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
    if (uVar8 <= uVar6 && uVar6 - uVar8 != 0) {
        *(undefined8 *)(puVar10 + -8) = 0x180161256;
        uVar4 = fcn.18015d7b0(arg2, uVar8 * 0x38 + iVar5, *(undefined4 *)(puVar10 + 0x24));
        *(undefined8 *)(arg1 + 0xd0) = uVar4;
        *(int64_t *)(arg1 + 0xd8) = (int64_t)*(int32_t *)(arg1 + 8);
        iVar5 = *(int64_t *)arg2;
        uVar8 = (uint64_t)(int32_t)*(undefined8 *)(arg1 + 4);
        *(undefined8 *)(puVar10 + 0x20) = *(undefined8 *)(arg1 + 4);
        uVar6 = (*(int64_t *)(arg2 + 8) - iVar5 >> 3) * 0x6db6db6db6db6db7;
        if (uVar8 <= uVar6 && uVar6 - uVar8 != 0) {
            *(undefined8 *)(puVar10 + -8) = 0x18016129f;
            uVar4 = fcn.18015d7b0(arg2, uVar8 * 0x38 + iVar5, *(undefined4 *)(puVar10 + 0x24));
            *(undefined8 *)(arg1 + 0xe0) = uVar4;
            *(undefined8 *)(arg1 + 0xf8) = *(undefined8 *)(arg1 + 0x98);
            *(int64_t *)(arg1 + 0xf0) = arg3;
            *(undefined8 *)(puVar10 + -8) = 0x1801612d0;
            fcn.180459870(*(uint64_t *)(puVar10 + 0x48) ^ (uint64_t)puVar10);
            return;
        }
    }
code_r0x0001801612d8:
    *(undefined8 *)(puVar10 + -8) = 0x1801612dd;
    fcn.180060370();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1801612e0
// Address: 0x1801612e0
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801612e0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(arg1 + 0x90);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x10))(piVar1, arg1 + 0xa0);
        *(undefined8 *)(arg1 + 0x128) = 0;
        return;
    }
    iVar3 = *(int64_t *)(arg1 + 0x100);
    iVar2 = *(int64_t *)(arg1 + 0x108);
    if (iVar3 != iVar2) {
        do {
            fcn.180004e40(iVar3);
            iVar3 = iVar3 + 0x20;
        } while (iVar3 != iVar2);
        *(undefined8 *)(arg1 + 0x108) = *(undefined8 *)(arg1 + 0x100);
    }
    *(undefined8 *)(arg1 + 0x128) = 0;
    return;
}

// ============================================================
// Function: FUN_180161370
// Address: 0x180161370
// Size: 744 bytes
// ============================================================
void fcn.180161370(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    uint8_t *puVar1;
    uint8_t *puVar2;
    int16_t iVar3;
    undefined (*pauVar4) [16];
    char cVar5;
    undefined (*pauVar6) [16];
    int64_t iVar7;
    undefined (**ppauVar8) [16];
    int64_t *piVar9;
    uint8_t *puVar10;
    uint8_t *puVar11;
    uint64_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    arg1 = *(int64_t *)arg1;
    puVar10 = *(uint8_t **)arg2;
    puVar2 = puVar10 + *(int64_t *)(arg2 + 8);
    var_10h = arg2;
    if ((((2 < *(int64_t *)(arg2 + 8)) && (*puVar10 == 0xef)) && (puVar10[1] == 0xbb)) && (puVar10[2] == 0xbf)) {
        puVar10 = puVar10 + 3;
    }
    while (puVar10 != puVar2) {
        cVar5 = -1;
        if (puVar2 <= puVar10) {
            cVar5 = '\x01';
        }
        if (-1 < cVar5) break;
        cVar5 = -1;
        if (puVar2 <= puVar10) {
            cVar5 = '\x01';
        }
        if ((cVar5 < '\0') && (uVar12 = (uint64_t)(uint32_t)(int32_t)(char)*puVar10, -1 < (char)*puVar10)) {
            puVar11 = puVar10 + 1;
        } else {
            puVar11 = puVar10 + 1;
            if (puVar11 != puVar2) {
                cVar5 = -1;
                if (puVar2 <= puVar11) {
                    cVar5 = '\x01';
                }
                if ((cVar5 < '\0') && ((*puVar10 & 0xe0) == 0xc0)) {
                    uVar12 = (uint64_t)(uint16_t)((uint16_t)(*puVar10 & 0x1f) << 6 | (uint16_t)(*puVar11 & 0x3f));
                    puVar11 = puVar10 + 2;
                    goto code_r0x0001801614c3;
                }
            }
            puVar1 = puVar10 + 2;
            if (puVar1 != puVar2) {
                cVar5 = -1;
                if (puVar2 <= puVar1) {
                    cVar5 = '\x01';
                }
                if ((cVar5 < '\0') && ((*puVar10 & 0xf0) == 0xe0)) {
                    uVar12 = (uint64_t)
                             (uint16_t)
                             (((uint16_t)(*puVar10 & 0xf) << 6 | (uint16_t)(*puVar11 & 0x3f)) << 6 |
                             (uint16_t)(*puVar1 & 0x3f));
                    puVar11 = puVar10 + 3;
                    goto code_r0x0001801614c3;
                }
            }
            if (puVar10 + 3 != puVar2) {
                cVar5 = -1;
                if (puVar2 <= puVar10 + 3) {
                    cVar5 = '\x01';
                }
                if ((cVar5 < '\0') && ((*puVar10 & 0xf8) == 0xf0)) {
                    uVar12 = 0xfffd;
                    puVar11 = puVar10 + 4;
                    goto code_r0x0001801614c3;
                }
            }
            uVar12 = 0xfffd;
        }
code_r0x0001801614c3:
        var_8h._0_2_ = (int16_t)uVar12;
        uVar12 = ((uVar12 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uVar12 & 0xffff) >> 8) * 0x100000001b3 &
                 *(uint64_t *)(arg1 + 0x30);
        iVar7 = *(int64_t *)(*(int64_t *)(arg1 + 0x18) + 8 + uVar12 * 0x10);
        if (iVar7 == *(int64_t *)(arg1 + 8)) {
code_r0x000180161521:
            iVar7 = 0;
        } else {
            iVar3 = *(int16_t *)(iVar7 + 0x10);
            while ((int16_t)var_8h != iVar3) {
                if (iVar7 == *(int64_t *)(*(int64_t *)(arg1 + 0x18) + uVar12 * 0x10)) goto code_r0x000180161521;
                iVar7 = *(int64_t *)(iVar7 + 8);
                iVar3 = *(int16_t *)(iVar7 + 0x10);
            }
        }
        if ((iVar7 == 0) || (iVar7 == *(int64_t *)(arg1 + 8))) {
            pauVar6 = (undefined (*) [16])func_0x000180459890(0x60);
            *pauVar6 = ZEXT816(0);
            pauVar6[1] = ZEXT816(0);
            pauVar6[2] = ZEXT816(0);
            pauVar6[3] = ZEXT816(0);
            pauVar6[4] = ZEXT816(0);
            pauVar6[5] = ZEXT816(0);
            *(undefined4 *)*pauVar6 = 0;
            *(undefined8 *)(*pauVar6 + 8) = 0;
            *(undefined8 *)pauVar6[1] = 0;
            var_18h = (int64_t)pauVar6;
            var_20h = (int64_t)pauVar6;
            iVar7 = func_0x000180459890(0x20);
            *(int64_t *)iVar7 = iVar7;
            *(int64_t *)(iVar7 + 8) = iVar7;
            *(int64_t *)(*pauVar6 + 8) = iVar7;
            *(undefined8 *)(pauVar6[1] + 8) = 0;
            *(undefined8 *)pauVar6[2] = 0;
            *(undefined8 *)(pauVar6[2] + 8) = 0;
            *(undefined8 *)pauVar6[3] = 7;
            *(undefined8 *)(pauVar6[3] + 8) = 8;
            *(undefined4 *)*pauVar6 = 0x3f800000;
            func_0x00018000f7e0(pauVar6[1] + 8, 0x10, *(undefined8 *)(*pauVar6 + 8));
            pauVar6[4] = ZEXT816(0);
            *(undefined8 *)pauVar6[5] = 0;
            *(undefined8 *)(pauVar6[5] + 8) = 0xf;
            pauVar6[4][0] = 0;
            var_20h = (int64_t)pauVar6;
            ppauVar8 = (undefined (**) [16])func_0x000180163b50(arg1, &var_8h);
            pauVar4 = *ppauVar8;
            *ppauVar8 = pauVar6;
            if (pauVar4 != (undefined (*) [16])0x0) {
                fcn.180004e40(pauVar4 + 4);
                func_0x00018000ace0(pauVar4[1] + 8);
                func_0x00018007d750(*pauVar4 + 8);
                fcn.180459c3c(pauVar4, 0x60);
            }
        }
        piVar9 = (int64_t *)func_0x000180163b50(arg1, &var_8h);
        arg1 = *piVar9;
        puVar10 = puVar11;
    }
    func_0x00018000f180(arg1 + 0x40, *(undefined8 *)var_10h, *(undefined8 *)(var_10h + 8));
    return;
}

// ============================================================
// Function: FUN_180161660
// Address: 0x180161660
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.180161660(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    uint16_t **ppuVar1;
    uint8_t *puVar2;
    uint8_t *puVar3;
    uint16_t *puVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    int64_t iVar7;
    code *pcVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    char cVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint16_t *puVar17;
    int64_t *piVar18;
    int64_t iVar19;
    uint8_t *puVar20;
    uint8_t *puVar21;
    undefined *puVar22;
    uint16_t uVar23;
    int64_t iVar24;
    int64_t *piVar25;
    int64_t *piVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined var_68h;
    int64_t var_67h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    *(int64_t *)(arg1 + 8) = arg_28h;
    iVar19 = *(int64_t *)arg2;
    iVar24 = *(int64_t *)(arg2 + 8);
    if (iVar19 != iVar24) {
        do {
            fcn.180004e40(iVar19);
            iVar19 = iVar19 + 0x20;
        } while (iVar19 != iVar24);
        *(undefined8 *)(arg2 + 8) = *(undefined8 *)arg2;
    }
    if (*(int64_t *)(arg3 + 8) == 0) {
        return;
    }
    ppuVar1 = (uint16_t **)(arg1 + 0x10);
    if (*(int64_t *)(arg1 + 0x10) != *(int64_t *)(arg1 + 0x18)) {
        *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x10);
    }
    puVar20 = *(uint8_t **)arg3;
    puVar3 = puVar20 + *(int64_t *)(arg3 + 8);
    if ((((2 < *(int64_t *)(arg3 + 8)) && (*puVar20 == 0xef)) && (puVar20[1] == 0xbb)) && (puVar20[2] == 0xbf)) {
        puVar20 = puVar20 + 3;
    }
    while (puVar22 = &var_68h, puVar20 != puVar3) {
        cVar12 = -1;
        if (puVar3 <= puVar20) {
            cVar12 = '\x01';
        }
        puVar22 = &var_68h;
        if (-1 < cVar12) break;
        cVar12 = -1;
        if (puVar3 <= puVar20) {
            cVar12 = '\x01';
        }
        if ((cVar12 < '\0') && (uVar23 = (uint16_t)(char)*puVar20, -1 < (char)*puVar20)) {
            puVar21 = puVar20 + 1;
        } else {
            puVar21 = puVar20 + 1;
            if (puVar21 != puVar3) {
                cVar12 = -1;
                if (puVar3 <= puVar21) {
                    cVar12 = '\x01';
                }
                if ((cVar12 < '\0') && ((*puVar20 & 0xe0) == 0xc0)) {
                    uVar23 = (uint16_t)(*puVar20 & 0x1f) << 6 | (uint16_t)(*puVar21 & 0x3f);
                    puVar21 = puVar20 + 2;
                    goto code_r0x000180161815;
                }
            }
            puVar2 = puVar20 + 2;
            if (puVar2 != puVar3) {
                cVar12 = -1;
                if (puVar3 <= puVar2) {
                    cVar12 = '\x01';
                }
                if ((cVar12 < '\0') && ((*puVar20 & 0xf0) == 0xe0)) {
                    uVar23 = ((uint16_t)(*puVar21 & 0x3f) | (int16_t)(char)*puVar20 << 6) << 6 |
                             (uint16_t)(*puVar2 & 0x3f);
                    puVar21 = puVar20 + 3;
                    goto code_r0x000180161815;
                }
            }
            if (puVar20 + 3 != puVar3) {
                cVar12 = -1;
                if (puVar3 <= puVar20 + 3) {
                    cVar12 = '\x01';
                }
                if ((cVar12 < '\0') && ((*puVar20 & 0xf8) == 0xf0)) {
                    uVar23 = 0xfffd;
                    puVar21 = puVar20 + 4;
                    goto code_r0x000180161815;
                }
            }
            uVar23 = 0xfffd;
        }
code_r0x000180161815:
        puVar17 = *(uint16_t **)(arg1 + 0x18);
        puVar20 = puVar21;
        if (puVar17 == *(uint16_t **)(arg1 + 0x20)) {
            iVar19 = (int64_t)puVar17 - (int64_t)*ppuVar1 >> 1;
            if (iVar19 == 0x7fffffffffffffff) {
                func_0x000180010010();
                pcVar8 = (code *)swi(3);
                (*pcVar8)();
                return;
            }
            uVar15 = (int64_t)*(uint16_t **)(arg1 + 0x20) - (int64_t)*ppuVar1 >> 1;
            if (0x7fffffffffffffff - (uVar15 >> 1) < uVar15) {
code_r0x000180161a66:
                func_0x000180004720();
                pcVar8 = (code *)swi(3);
                (*pcVar8)();
                return;
            }
            uVar15 = (uVar15 >> 1) + uVar15;
            uVar14 = iVar19 + 1U;
            if (iVar19 + 1U <= uVar15) {
                uVar14 = uVar15;
            }
            if (0x7fffffffffffffff < uVar14) goto code_r0x000180161a66;
            uVar15 = uVar14 * 2;
            if (uVar15 == 0) {
                uVar15 = 0;
            } else if (uVar15 < 0x1000) {
                uVar15 = func_0x000180459890();
            } else {
                if (uVar15 + 0x27 <= uVar15) goto code_r0x000180161a66;
                iVar24 = func_0x000180459890(uVar15 + 0x27);
                if (iVar24 == 0) {
                    pcVar8 = (code *)swi(0x29);
                    (*pcVar8)(5);
                    puVar22 = (undefined *)((int64_t)&var_67h + 7);
                    break;
                }
                uVar15 = iVar24 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar15 - 8) = iVar24;
            }
            *(uint16_t *)(uVar15 + iVar19 * 2) = uVar23;
            puVar4 = *ppuVar1;
            if (puVar17 == *(uint16_t **)(arg1 + 0x18)) {
                iVar24 = (int64_t)*(uint16_t **)(arg1 + 0x18) - (int64_t)puVar4;
                uVar16 = uVar15;
                puVar17 = puVar4;
            } else {
                fcn.180498030(uVar15, puVar4, (int64_t)puVar17 - (int64_t)puVar4);
                iVar24 = *(int64_t *)(arg1 + 0x18) - (int64_t)puVar17;
                uVar16 = uVar15 + (iVar19 + 1) * 2;
            }
            fcn.180498030(uVar16, puVar17, iVar24);
            func_0x0001800d4aa0(ppuVar1, uVar15, iVar19 + 1, uVar14);
        } else {
            *puVar17 = uVar23;
            *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x18) + 2;
        }
    }
    puVar5 = *(undefined8 **)(puVar22 + 0x70);
    if (puVar5[5] != puVar5[6]) {
        puVar5[6] = puVar5[5];
    }
    uVar6 = *puVar5;
    *(undefined8 *)(puVar22 + 0x20) = puVar5[1];
    *(undefined8 *)(puVar22 + -8) = 0x180161953;
    func_0x000180161a70(puVar5, uVar6, 0, 0);
    iVar19 = puVar5[5];
    iVar24 = puVar5[6];
    if (iVar24 == iVar19) {
        return;
    }
    *(undefined8 *)(puVar22 + -8) = 0x180161979;
    func_0x000180164fa0(iVar19, iVar24, iVar24 - iVar19 >> 4, 0);
    piVar13 = (int64_t *)puVar5[6];
    piVar25 = (int64_t *)puVar5[5];
    if ((piVar25 != piVar13) && (piVar25 + 2 != piVar13)) {
        piVar18 = piVar25 + 2;
        iVar19 = *piVar25;
        do {
            piVar26 = piVar18;
            piVar18 = piVar26 + 2;
            if (iVar19 == *piVar26) goto joined_r0x0001801619b1;
            piVar25 = piVar26;
            iVar19 = *piVar26;
        } while (piVar18 != piVar13);
    }
code_r0x0001801619d3:
    if (piVar13 != (int64_t *)puVar5[6]) {
        puVar5[6] = piVar13;
    }
    uVar14 = (int64_t)(puVar5[6] - puVar5[5]) >> 4;
    uVar15 = 0x1e;
    if (uVar14 < 0x1e) {
        uVar15 = uVar14;
    }
    uVar14 = 0;
    if (uVar15 != 0) {
        iVar19 = *(int64_t *)(puVar22 + 0x78);
        do {
            iVar24 = *(int64_t *)(puVar5[5] + uVar14 * 0x10);
            iVar7 = *(int64_t *)(iVar19 + 8);
            if (iVar7 == *(int64_t *)(iVar19 + 0x10)) {
                *(undefined8 *)(puVar22 + -8) = 0x180161a3a;
                func_0x00018007e850(iVar19, iVar7);
            } else {
                *(undefined8 *)(puVar22 + -8) = 0x180161a28;
                func_0x00018000b4d0(iVar7, iVar24 + 0x40);
                *(int64_t *)(iVar19 + 8) = *(int64_t *)(iVar19 + 8) + 0x20;
            }
            uVar14 = uVar14 + 1;
        } while (uVar14 < uVar15);
    }
    return;
joined_r0x0001801619b1:
    for (; piVar18 != piVar13; piVar18 = piVar18 + 2) {
        piVar26 = piVar25;
        if (*piVar25 != *piVar18) {
            uVar9 = *(undefined4 *)((int64_t)piVar18 + 4);
            uVar10 = *(undefined4 *)(piVar18 + 1);
            uVar11 = *(undefined4 *)((int64_t)piVar18 + 0xc);
            piVar26 = piVar25 + 2;
            *(undefined4 *)piVar26 = *(undefined4 *)piVar18;
            *(undefined4 *)((int64_t)piVar25 + 0x14) = uVar9;
            *(undefined4 *)(piVar25 + 3) = uVar10;
            *(undefined4 *)((int64_t)piVar25 + 0x1c) = uVar11;
        }
        piVar25 = piVar26;
    }
    piVar13 = piVar25 + 2;
    goto code_r0x0001801619d3;
}

// ============================================================
// Function: FUN_1801616c1
// Address: 0x1801616c1
// Size: 915 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.180161660(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    uint16_t **ppuVar1;
    uint8_t *puVar2;
    uint8_t *puVar3;
    uint16_t *puVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    int64_t iVar7;
    code *pcVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    char cVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint16_t *puVar17;
    int64_t *piVar18;
    int64_t iVar19;
    uint8_t *puVar20;
    uint8_t *puVar21;
    undefined *puVar22;
    uint16_t uVar23;
    int64_t iVar24;
    int64_t *piVar25;
    int64_t *piVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined var_68h;
    int64_t var_67h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    *(int64_t *)(arg1 + 8) = arg_28h;
    iVar19 = *(int64_t *)arg2;
    iVar24 = *(int64_t *)(arg2 + 8);
    if (iVar19 != iVar24) {
        do {
            fcn.180004e40(iVar19);
            iVar19 = iVar19 + 0x20;
        } while (iVar19 != iVar24);
        *(undefined8 *)(arg2 + 8) = *(undefined8 *)arg2;
    }
    if (*(int64_t *)(arg3 + 8) == 0) {
        return;
    }
    ppuVar1 = (uint16_t **)(arg1 + 0x10);
    if (*(int64_t *)(arg1 + 0x10) != *(int64_t *)(arg1 + 0x18)) {
        *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x10);
    }
    puVar20 = *(uint8_t **)arg3;
    puVar3 = puVar20 + *(int64_t *)(arg3 + 8);
    if ((((2 < *(int64_t *)(arg3 + 8)) && (*puVar20 == 0xef)) && (puVar20[1] == 0xbb)) && (puVar20[2] == 0xbf)) {
        puVar20 = puVar20 + 3;
    }
    while (puVar22 = &var_68h, puVar20 != puVar3) {
        cVar12 = -1;
        if (puVar3 <= puVar20) {
            cVar12 = '\x01';
        }
        puVar22 = &var_68h;
        if (-1 < cVar12) break;
        cVar12 = -1;
        if (puVar3 <= puVar20) {
            cVar12 = '\x01';
        }
        if ((cVar12 < '\0') && (uVar23 = (uint16_t)(char)*puVar20, -1 < (char)*puVar20)) {
            puVar21 = puVar20 + 1;
        } else {
            puVar21 = puVar20 + 1;
            if (puVar21 != puVar3) {
                cVar12 = -1;
                if (puVar3 <= puVar21) {
                    cVar12 = '\x01';
                }
                if ((cVar12 < '\0') && ((*puVar20 & 0xe0) == 0xc0)) {
                    uVar23 = (uint16_t)(*puVar20 & 0x1f) << 6 | (uint16_t)(*puVar21 & 0x3f);
                    puVar21 = puVar20 + 2;
                    goto code_r0x000180161815;
                }
            }
            puVar2 = puVar20 + 2;
            if (puVar2 != puVar3) {
                cVar12 = -1;
                if (puVar3 <= puVar2) {
                    cVar12 = '\x01';
                }
                if ((cVar12 < '\0') && ((*puVar20 & 0xf0) == 0xe0)) {
                    uVar23 = ((uint16_t)(*puVar21 & 0x3f) | (int16_t)(char)*puVar20 << 6) << 6 |
                             (uint16_t)(*puVar2 & 0x3f);
                    puVar21 = puVar20 + 3;
                    goto code_r0x000180161815;
                }
            }
            if (puVar20 + 3 != puVar3) {
                cVar12 = -1;
                if (puVar3 <= puVar20 + 3) {
                    cVar12 = '\x01';
                }
                if ((cVar12 < '\0') && ((*puVar20 & 0xf8) == 0xf0)) {
                    uVar23 = 0xfffd;
                    puVar21 = puVar20 + 4;
                    goto code_r0x000180161815;
                }
            }
            uVar23 = 0xfffd;
        }
code_r0x000180161815:
        puVar17 = *(uint16_t **)(arg1 + 0x18);
        puVar20 = puVar21;
        if (puVar17 == *(uint16_t **)(arg1 + 0x20)) {
            iVar19 = (int64_t)puVar17 - (int64_t)*ppuVar1 >> 1;
            if (iVar19 == 0x7fffffffffffffff) {
                func_0x000180010010();
                pcVar8 = (code *)swi(3);
                (*pcVar8)();
                return;
            }
            uVar15 = (int64_t)*(uint16_t **)(arg1 + 0x20) - (int64_t)*ppuVar1 >> 1;
            if (0x7fffffffffffffff - (uVar15 >> 1) < uVar15) {
code_r0x000180161a66:
                func_0x000180004720();
                pcVar8 = (code *)swi(3);
                (*pcVar8)();
                return;
            }
            uVar15 = (uVar15 >> 1) + uVar15;
            uVar14 = iVar19 + 1U;
            if (iVar19 + 1U <= uVar15) {
                uVar14 = uVar15;
            }
            if (0x7fffffffffffffff < uVar14) goto code_r0x000180161a66;
            uVar15 = uVar14 * 2;
            if (uVar15 == 0) {
                uVar15 = 0;
            } else if (uVar15 < 0x1000) {
                uVar15 = func_0x000180459890();
            } else {
                if (uVar15 + 0x27 <= uVar15) goto code_r0x000180161a66;
                iVar24 = func_0x000180459890(uVar15 + 0x27);
                if (iVar24 == 0) {
                    pcVar8 = (code *)swi(0x29);
                    (*pcVar8)(5);
                    puVar22 = (undefined *)((int64_t)&var_67h + 7);
                    break;
                }
                uVar15 = iVar24 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar15 - 8) = iVar24;
            }
            *(uint16_t *)(uVar15 + iVar19 * 2) = uVar23;
            puVar4 = *ppuVar1;
            if (puVar17 == *(uint16_t **)(arg1 + 0x18)) {
                iVar24 = (int64_t)*(uint16_t **)(arg1 + 0x18) - (int64_t)puVar4;
                uVar16 = uVar15;
                puVar17 = puVar4;
            } else {
                fcn.180498030(uVar15, puVar4, (int64_t)puVar17 - (int64_t)puVar4);
                iVar24 = *(int64_t *)(arg1 + 0x18) - (int64_t)puVar17;
                uVar16 = uVar15 + (iVar19 + 1) * 2;
            }
            fcn.180498030(uVar16, puVar17, iVar24);
            func_0x0001800d4aa0(ppuVar1, uVar15, iVar19 + 1, uVar14);
        } else {
            *puVar17 = uVar23;
            *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x18) + 2;
        }
    }
    puVar5 = *(undefined8 **)(puVar22 + 0x70);
    if (puVar5[5] != puVar5[6]) {
        puVar5[6] = puVar5[5];
    }
    uVar6 = *puVar5;
    *(undefined8 *)(puVar22 + 0x20) = puVar5[1];
    *(undefined8 *)(puVar22 + -8) = 0x180161953;
    func_0x000180161a70(puVar5, uVar6, 0, 0);
    iVar19 = puVar5[5];
    iVar24 = puVar5[6];
    if (iVar24 == iVar19) {
        return;
    }
    *(undefined8 *)(puVar22 + -8) = 0x180161979;
    func_0x000180164fa0(iVar19, iVar24, iVar24 - iVar19 >> 4, 0);
    piVar13 = (int64_t *)puVar5[6];
    piVar25 = (int64_t *)puVar5[5];
    if ((piVar25 != piVar13) && (piVar25 + 2 != piVar13)) {
        piVar18 = piVar25 + 2;
        iVar19 = *piVar25;
        do {
            piVar26 = piVar18;
            piVar18 = piVar26 + 2;
            if (iVar19 == *piVar26) goto joined_r0x0001801619b1;
            piVar25 = piVar26;
            iVar19 = *piVar26;
        } while (piVar18 != piVar13);
    }
code_r0x0001801619d3:
    if (piVar13 != (int64_t *)puVar5[6]) {
        puVar5[6] = piVar13;
    }
    uVar14 = (int64_t)(puVar5[6] - puVar5[5]) >> 4;
    uVar15 = 0x1e;
    if (uVar14 < 0x1e) {
        uVar15 = uVar14;
    }
    uVar14 = 0;
    if (uVar15 != 0) {
        iVar19 = *(int64_t *)(puVar22 + 0x78);
        do {
            iVar24 = *(int64_t *)(puVar5[5] + uVar14 * 0x10);
            iVar7 = *(int64_t *)(iVar19 + 8);
            if (iVar7 == *(int64_t *)(iVar19 + 0x10)) {
                *(undefined8 *)(puVar22 + -8) = 0x180161a3a;
                func_0x00018007e850(iVar19, iVar7);
            } else {
                *(undefined8 *)(puVar22 + -8) = 0x180161a28;
                func_0x00018000b4d0(iVar7, iVar24 + 0x40);
                *(int64_t *)(iVar19 + 8) = *(int64_t *)(iVar19 + 8) + 0x20;
            }
            uVar14 = uVar14 + 1;
        } while (uVar14 < uVar15);
    }
    return;
joined_r0x0001801619b1:
    for (; piVar18 != piVar13; piVar18 = piVar18 + 2) {
        piVar26 = piVar25;
        if (*piVar25 != *piVar18) {
            uVar9 = *(undefined4 *)((int64_t)piVar18 + 4);
            uVar10 = *(undefined4 *)(piVar18 + 1);
            uVar11 = *(undefined4 *)((int64_t)piVar18 + 0xc);
            piVar26 = piVar25 + 2;
            *(undefined4 *)piVar26 = *(undefined4 *)piVar18;
            *(undefined4 *)((int64_t)piVar25 + 0x14) = uVar9;
            *(undefined4 *)(piVar25 + 3) = uVar10;
            *(undefined4 *)((int64_t)piVar25 + 0x1c) = uVar11;
        }
        piVar25 = piVar26;
    }
    piVar13 = piVar25 + 2;
    goto code_r0x0001801619d3;
}

// ============================================================
// Function: FUN_180161a54
// Address: 0x180161a54
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.180161660(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    uint16_t **ppuVar1;
    uint8_t *puVar2;
    uint8_t *puVar3;
    uint16_t *puVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    int64_t iVar7;
    code *pcVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    char cVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint16_t *puVar17;
    int64_t *piVar18;
    int64_t iVar19;
    uint8_t *puVar20;
    uint8_t *puVar21;
    undefined *puVar22;
    uint16_t uVar23;
    int64_t iVar24;
    int64_t *piVar25;
    int64_t *piVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined var_68h;
    int64_t var_67h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    *(int64_t *)(arg1 + 8) = arg_28h;
    iVar19 = *(int64_t *)arg2;
    iVar24 = *(int64_t *)(arg2 + 8);
    if (iVar19 != iVar24) {
        do {
            fcn.180004e40(iVar19);
            iVar19 = iVar19 + 0x20;
        } while (iVar19 != iVar24);
        *(undefined8 *)(arg2 + 8) = *(undefined8 *)arg2;
    }
    if (*(int64_t *)(arg3 + 8) == 0) {
        return;
    }
    ppuVar1 = (uint16_t **)(arg1 + 0x10);
    if (*(int64_t *)(arg1 + 0x10) != *(int64_t *)(arg1 + 0x18)) {
        *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x10);
    }
    puVar20 = *(uint8_t **)arg3;
    puVar3 = puVar20 + *(int64_t *)(arg3 + 8);
    if ((((2 < *(int64_t *)(arg3 + 8)) && (*puVar20 == 0xef)) && (puVar20[1] == 0xbb)) && (puVar20[2] == 0xbf)) {
        puVar20 = puVar20 + 3;
    }
    while (puVar22 = &var_68h, puVar20 != puVar3) {
        cVar12 = -1;
        if (puVar3 <= puVar20) {
            cVar12 = '\x01';
        }
        puVar22 = &var_68h;
        if (-1 < cVar12) break;
        cVar12 = -1;
        if (puVar3 <= puVar20) {
            cVar12 = '\x01';
        }
        if ((cVar12 < '\0') && (uVar23 = (uint16_t)(char)*puVar20, -1 < (char)*puVar20)) {
            puVar21 = puVar20 + 1;
        } else {
            puVar21 = puVar20 + 1;
            if (puVar21 != puVar3) {
                cVar12 = -1;
                if (puVar3 <= puVar21) {
                    cVar12 = '\x01';
                }
                if ((cVar12 < '\0') && ((*puVar20 & 0xe0) == 0xc0)) {
                    uVar23 = (uint16_t)(*puVar20 & 0x1f) << 6 | (uint16_t)(*puVar21 & 0x3f);
                    puVar21 = puVar20 + 2;
                    goto code_r0x000180161815;
                }
            }
            puVar2 = puVar20 + 2;
            if (puVar2 != puVar3) {
                cVar12 = -1;
                if (puVar3 <= puVar2) {
                    cVar12 = '\x01';
                }
                if ((cVar12 < '\0') && ((*puVar20 & 0xf0) == 0xe0)) {
                    uVar23 = ((uint16_t)(*puVar21 & 0x3f) | (int16_t)(char)*puVar20 << 6) << 6 |
                             (uint16_t)(*puVar2 & 0x3f);
                    puVar21 = puVar20 + 3;
                    goto code_r0x000180161815;
                }
            }
            if (puVar20 + 3 != puVar3) {
                cVar12 = -1;
                if (puVar3 <= puVar20 + 3) {
                    cVar12 = '\x01';
                }
                if ((cVar12 < '\0') && ((*puVar20 & 0xf8) == 0xf0)) {
                    uVar23 = 0xfffd;
                    puVar21 = puVar20 + 4;
                    goto code_r0x000180161815;
                }
            }
            uVar23 = 0xfffd;
        }
code_r0x000180161815:
        puVar17 = *(uint16_t **)(arg1 + 0x18);
        puVar20 = puVar21;
        if (puVar17 == *(uint16_t **)(arg1 + 0x20)) {
            iVar19 = (int64_t)puVar17 - (int64_t)*ppuVar1 >> 1;
            if (iVar19 == 0x7fffffffffffffff) {
                func_0x000180010010();
                pcVar8 = (code *)swi(3);
                (*pcVar8)();
                return;
            }
            uVar15 = (int64_t)*(uint16_t **)(arg1 + 0x20) - (int64_t)*ppuVar1 >> 1;
            if (0x7fffffffffffffff - (uVar15 >> 1) < uVar15) {
code_r0x000180161a66:
                func_0x000180004720();
                pcVar8 = (code *)swi(3);
                (*pcVar8)();
                return;
            }
            uVar15 = (uVar15 >> 1) + uVar15;
            uVar14 = iVar19 + 1U;
            if (iVar19 + 1U <= uVar15) {
                uVar14 = uVar15;
            }
            if (0x7fffffffffffffff < uVar14) goto code_r0x000180161a66;
            uVar15 = uVar14 * 2;
            if (uVar15 == 0) {
                uVar15 = 0;
            } else if (uVar15 < 0x1000) {
                uVar15 = func_0x000180459890();
            } else {
                if (uVar15 + 0x27 <= uVar15) goto code_r0x000180161a66;
                iVar24 = func_0x000180459890(uVar15 + 0x27);
                if (iVar24 == 0) {
                    pcVar8 = (code *)swi(0x29);
                    (*pcVar8)(5);
                    puVar22 = (undefined *)((int64_t)&var_67h + 7);
                    break;
                }
                uVar15 = iVar24 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar15 - 8) = iVar24;
            }
            *(uint16_t *)(uVar15 + iVar19 * 2) = uVar23;
            puVar4 = *ppuVar1;
            if (puVar17 == *(uint16_t **)(arg1 + 0x18)) {
                iVar24 = (int64_t)*(uint16_t **)(arg1 + 0x18) - (int64_t)puVar4;
                uVar16 = uVar15;
                puVar17 = puVar4;
            } else {
                fcn.180498030(uVar15, puVar4, (int64_t)puVar17 - (int64_t)puVar4);
                iVar24 = *(int64_t *)(arg1 + 0x18) - (int64_t)puVar17;
                uVar16 = uVar15 + (iVar19 + 1) * 2;
            }
            fcn.180498030(uVar16, puVar17, iVar24);
            func_0x0001800d4aa0(ppuVar1, uVar15, iVar19 + 1, uVar14);
        } else {
            *puVar17 = uVar23;
            *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x18) + 2;
        }
    }
    puVar5 = *(undefined8 **)(puVar22 + 0x70);
    if (puVar5[5] != puVar5[6]) {
        puVar5[6] = puVar5[5];
    }
    uVar6 = *puVar5;
    *(undefined8 *)(puVar22 + 0x20) = puVar5[1];
    *(undefined8 *)(puVar22 + -8) = 0x180161953;
    func_0x000180161a70(puVar5, uVar6, 0, 0);
    iVar19 = puVar5[5];
    iVar24 = puVar5[6];
    if (iVar24 == iVar19) {
        return;
    }
    *(undefined8 *)(puVar22 + -8) = 0x180161979;
    func_0x000180164fa0(iVar19, iVar24, iVar24 - iVar19 >> 4, 0);
    piVar13 = (int64_t *)puVar5[6];
    piVar25 = (int64_t *)puVar5[5];
    if ((piVar25 != piVar13) && (piVar25 + 2 != piVar13)) {
        piVar18 = piVar25 + 2;
        iVar19 = *piVar25;
        do {
            piVar26 = piVar18;
            piVar18 = piVar26 + 2;
            if (iVar19 == *piVar26) goto joined_r0x0001801619b1;
            piVar25 = piVar26;
            iVar19 = *piVar26;
        } while (piVar18 != piVar13);
    }
code_r0x0001801619d3:
    if (piVar13 != (int64_t *)puVar5[6]) {
        puVar5[6] = piVar13;
    }
    uVar14 = (int64_t)(puVar5[6] - puVar5[5]) >> 4;
    uVar15 = 0x1e;
    if (uVar14 < 0x1e) {
        uVar15 = uVar14;
    }
    uVar14 = 0;
    if (uVar15 != 0) {
        iVar19 = *(int64_t *)(puVar22 + 0x78);
        do {
            iVar24 = *(int64_t *)(puVar5[5] + uVar14 * 0x10);
            iVar7 = *(int64_t *)(iVar19 + 8);
            if (iVar7 == *(int64_t *)(iVar19 + 0x10)) {
                *(undefined8 *)(puVar22 + -8) = 0x180161a3a;
                func_0x00018007e850(iVar19, iVar7);
            } else {
                *(undefined8 *)(puVar22 + -8) = 0x180161a28;
                func_0x00018000b4d0(iVar7, iVar24 + 0x40);
                *(int64_t *)(iVar19 + 8) = *(int64_t *)(iVar19 + 8) + 0x20;
            }
            uVar14 = uVar14 + 1;
        } while (uVar14 < uVar15);
    }
    return;
joined_r0x0001801619b1:
    for (; piVar18 != piVar13; piVar18 = piVar18 + 2) {
        piVar26 = piVar25;
        if (*piVar25 != *piVar18) {
            uVar9 = *(undefined4 *)((int64_t)piVar18 + 4);
            uVar10 = *(undefined4 *)(piVar18 + 1);
            uVar11 = *(undefined4 *)((int64_t)piVar18 + 0xc);
            piVar26 = piVar25 + 2;
            *(undefined4 *)piVar26 = *(undefined4 *)piVar18;
            *(undefined4 *)((int64_t)piVar25 + 0x14) = uVar9;
            *(undefined4 *)(piVar25 + 3) = uVar10;
            *(undefined4 *)((int64_t)piVar25 + 0x1c) = uVar11;
        }
        piVar25 = piVar26;
    }
    piVar13 = piVar25 + 2;
    goto code_r0x0001801619d3;
}

// ============================================================
// Function: FUN_180161a60
// Address: 0x180161a60
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.180161660(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    uint16_t **ppuVar1;
    uint8_t *puVar2;
    uint8_t *puVar3;
    uint16_t *puVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    int64_t iVar7;
    code *pcVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    char cVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint16_t *puVar17;
    int64_t *piVar18;
    int64_t iVar19;
    uint8_t *puVar20;
    uint8_t *puVar21;
    undefined *puVar22;
    uint16_t uVar23;
    int64_t iVar24;
    int64_t *piVar25;
    int64_t *piVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined var_68h;
    int64_t var_67h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    *(int64_t *)(arg1 + 8) = arg_28h;
    iVar19 = *(int64_t *)arg2;
    iVar24 = *(int64_t *)(arg2 + 8);
    if (iVar19 != iVar24) {
        do {
            fcn.180004e40(iVar19);
            iVar19 = iVar19 + 0x20;
        } while (iVar19 != iVar24);
        *(undefined8 *)(arg2 + 8) = *(undefined8 *)arg2;
    }
    if (*(int64_t *)(arg3 + 8) == 0) {
        return;
    }
    ppuVar1 = (uint16_t **)(arg1 + 0x10);
    if (*(int64_t *)(arg1 + 0x10) != *(int64_t *)(arg1 + 0x18)) {
        *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x10);
    }
    puVar20 = *(uint8_t **)arg3;
    puVar3 = puVar20 + *(int64_t *)(arg3 + 8);
    if ((((2 < *(int64_t *)(arg3 + 8)) && (*puVar20 == 0xef)) && (puVar20[1] == 0xbb)) && (puVar20[2] == 0xbf)) {
        puVar20 = puVar20 + 3;
    }
    while (puVar22 = &var_68h, puVar20 != puVar3) {
        cVar12 = -1;
        if (puVar3 <= puVar20) {
            cVar12 = '\x01';
        }
        puVar22 = &var_68h;
        if (-1 < cVar12) break;
        cVar12 = -1;
        if (puVar3 <= puVar20) {
            cVar12 = '\x01';
        }
        if ((cVar12 < '\0') && (uVar23 = (uint16_t)(char)*puVar20, -1 < (char)*puVar20)) {
            puVar21 = puVar20 + 1;
        } else {
            puVar21 = puVar20 + 1;
            if (puVar21 != puVar3) {
                cVar12 = -1;
                if (puVar3 <= puVar21) {
                    cVar12 = '\x01';
                }
                if ((cVar12 < '\0') && ((*puVar20 & 0xe0) == 0xc0)) {
                    uVar23 = (uint16_t)(*puVar20 & 0x1f) << 6 | (uint16_t)(*puVar21 & 0x3f);
                    puVar21 = puVar20 + 2;
                    goto code_r0x000180161815;
                }
            }
            puVar2 = puVar20 + 2;
            if (puVar2 != puVar3) {
                cVar12 = -1;
                if (puVar3 <= puVar2) {
                    cVar12 = '\x01';
                }
                if ((cVar12 < '\0') && ((*puVar20 & 0xf0) == 0xe0)) {
                    uVar23 = ((uint16_t)(*puVar21 & 0x3f) | (int16_t)(char)*puVar20 << 6) << 6 |
                             (uint16_t)(*puVar2 & 0x3f);
                    puVar21 = puVar20 + 3;
                    goto code_r0x000180161815;
                }
            }
            if (puVar20 + 3 != puVar3) {
                cVar12 = -1;
                if (puVar3 <= puVar20 + 3) {
                    cVar12 = '\x01';
                }
                if ((cVar12 < '\0') && ((*puVar20 & 0xf8) == 0xf0)) {
                    uVar23 = 0xfffd;
                    puVar21 = puVar20 + 4;
                    goto code_r0x000180161815;
                }
            }
            uVar23 = 0xfffd;
        }
code_r0x000180161815:
        puVar17 = *(uint16_t **)(arg1 + 0x18);
        puVar20 = puVar21;
        if (puVar17 == *(uint16_t **)(arg1 + 0x20)) {
            iVar19 = (int64_t)puVar17 - (int64_t)*ppuVar1 >> 1;
            if (iVar19 == 0x7fffffffffffffff) {
                func_0x000180010010();
                pcVar8 = (code *)swi(3);
                (*pcVar8)();
                return;
            }
            uVar15 = (int64_t)*(uint16_t **)(arg1 + 0x20) - (int64_t)*ppuVar1 >> 1;
            if (0x7fffffffffffffff - (uVar15 >> 1) < uVar15) {
code_r0x000180161a66:
                func_0x000180004720();
                pcVar8 = (code *)swi(3);
                (*pcVar8)();
                return;
            }
            uVar15 = (uVar15 >> 1) + uVar15;
            uVar14 = iVar19 + 1U;
            if (iVar19 + 1U <= uVar15) {
                uVar14 = uVar15;
            }
            if (0x7fffffffffffffff < uVar14) goto code_r0x000180161a66;
            uVar15 = uVar14 * 2;
            if (uVar15 == 0) {
                uVar15 = 0;
            } else if (uVar15 < 0x1000) {
                uVar15 = func_0x000180459890();
            } else {
                if (uVar15 + 0x27 <= uVar15) goto code_r0x000180161a66;
                iVar24 = func_0x000180459890(uVar15 + 0x27);
                if (iVar24 == 0) {
                    pcVar8 = (code *)swi(0x29);
                    (*pcVar8)(5);
                    puVar22 = (undefined *)((int64_t)&var_67h + 7);
                    break;
                }
                uVar15 = iVar24 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar15 - 8) = iVar24;
            }
            *(uint16_t *)(uVar15 + iVar19 * 2) = uVar23;
            puVar4 = *ppuVar1;
            if (puVar17 == *(uint16_t **)(arg1 + 0x18)) {
                iVar24 = (int64_t)*(uint16_t **)(arg1 + 0x18) - (int64_t)puVar4;
                uVar16 = uVar15;
                puVar17 = puVar4;
            } else {
                fcn.180498030(uVar15, puVar4, (int64_t)puVar17 - (int64_t)puVar4);
                iVar24 = *(int64_t *)(arg1 + 0x18) - (int64_t)puVar17;
                uVar16 = uVar15 + (iVar19 + 1) * 2;
            }
            fcn.180498030(uVar16, puVar17, iVar24);
            func_0x0001800d4aa0(ppuVar1, uVar15, iVar19 + 1, uVar14);
        } else {
            *puVar17 = uVar23;
            *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x18) + 2;
        }
    }
    puVar5 = *(undefined8 **)(puVar22 + 0x70);
    if (puVar5[5] != puVar5[6]) {
        puVar5[6] = puVar5[5];
    }
    uVar6 = *puVar5;
    *(undefined8 *)(puVar22 + 0x20) = puVar5[1];
    *(undefined8 *)(puVar22 + -8) = 0x180161953;
    func_0x000180161a70(puVar5, uVar6, 0, 0);
    iVar19 = puVar5[5];
    iVar24 = puVar5[6];
    if (iVar24 == iVar19) {
        return;
    }
    *(undefined8 *)(puVar22 + -8) = 0x180161979;
    func_0x000180164fa0(iVar19, iVar24, iVar24 - iVar19 >> 4, 0);
    piVar13 = (int64_t *)puVar5[6];
    piVar25 = (int64_t *)puVar5[5];
    if ((piVar25 != piVar13) && (piVar25 + 2 != piVar13)) {
        piVar18 = piVar25 + 2;
        iVar19 = *piVar25;
        do {
            piVar26 = piVar18;
            piVar18 = piVar26 + 2;
            if (iVar19 == *piVar26) goto joined_r0x0001801619b1;
            piVar25 = piVar26;
            iVar19 = *piVar26;
        } while (piVar18 != piVar13);
    }
code_r0x0001801619d3:
    if (piVar13 != (int64_t *)puVar5[6]) {
        puVar5[6] = piVar13;
    }
    uVar14 = (int64_t)(puVar5[6] - puVar5[5]) >> 4;
    uVar15 = 0x1e;
    if (uVar14 < 0x1e) {
        uVar15 = uVar14;
    }
    uVar14 = 0;
    if (uVar15 != 0) {
        iVar19 = *(int64_t *)(puVar22 + 0x78);
        do {
            iVar24 = *(int64_t *)(puVar5[5] + uVar14 * 0x10);
            iVar7 = *(int64_t *)(iVar19 + 8);
            if (iVar7 == *(int64_t *)(iVar19 + 0x10)) {
                *(undefined8 *)(puVar22 + -8) = 0x180161a3a;
                func_0x00018007e850(iVar19, iVar7);
            } else {
                *(undefined8 *)(puVar22 + -8) = 0x180161a28;
                func_0x00018000b4d0(iVar7, iVar24 + 0x40);
                *(int64_t *)(iVar19 + 8) = *(int64_t *)(iVar19 + 8) + 0x20;
            }
            uVar14 = uVar14 + 1;
        } while (uVar14 < uVar15);
    }
    return;
joined_r0x0001801619b1:
    for (; piVar18 != piVar13; piVar18 = piVar18 + 2) {
        piVar26 = piVar25;
        if (*piVar25 != *piVar18) {
            uVar9 = *(undefined4 *)((int64_t)piVar18 + 4);
            uVar10 = *(undefined4 *)(piVar18 + 1);
            uVar11 = *(undefined4 *)((int64_t)piVar18 + 0xc);
            piVar26 = piVar25 + 2;
            *(undefined4 *)piVar26 = *(undefined4 *)piVar18;
            *(undefined4 *)((int64_t)piVar25 + 0x14) = uVar9;
            *(undefined4 *)(piVar25 + 3) = uVar10;
            *(undefined4 *)((int64_t)piVar25 + 0x1c) = uVar11;
        }
        piVar25 = piVar26;
    }
    piVar13 = piVar25 + 2;
    goto code_r0x0001801619d3;
}

// ============================================================
// Function: FUN_180161a70
// Address: 0x180161a70
// Size: 847 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_9h

void fcn.180161a70(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_80h)
{
    int16_t iVar1;
    uint16_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    code *pcVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t arg2_00;
    int64_t arg2_01;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    
    iVar4 = *(int64_t *)(arg1 + 0x10);
    uVar2 = *(uint16_t *)(iVar4 + arg3 * 2);
    uVar11 = (uint64_t)uVar2;
    uVar12 = uVar11;
    if (uVar2 < 0x7f) {
        uVar12 = uVar11 | 0x20;
        if (0x19 < uVar2 - 0x41) {
            uVar12 = uVar11;
        }
    } else {
        iVar10 = func_0x000180164c60(arg1, uVar11);
        if ((iVar10 != 0) && (iVar3 = *(int32_t *)(iVar10 + 8), iVar3 != 0)) {
            if (iVar3 == 0xffff) {
                uVar12 = uVar11 | 1;
            } else {
                uVar12 = (uint64_t)(uint16_t)((int16_t)iVar3 + uVar2);
            }
        }
    }
    iVar10 = *(int64_t *)(arg2 + 0x18);
    iVar5 = *(int64_t *)(arg2 + 8);
    arg2_01 = 0;
    uVar11 = ((uVar12 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ uVar12 >> 8) * 0x100000001b3 &
             *(uint64_t *)(arg2 + 0x30);
    iVar9 = *(int64_t *)(iVar10 + 8 + uVar11 * 0x10);
    if (iVar9 == iVar5) {
code_r0x000180161b58:
        iVar9 = 0;
    } else {
        iVar1 = *(int16_t *)(iVar9 + 0x10);
        while ((int16_t)uVar12 != iVar1) {
            if (iVar9 == *(int64_t *)(iVar10 + uVar11 * 0x10)) goto code_r0x000180161b58;
            iVar9 = *(int64_t *)(iVar9 + 8);
            iVar1 = *(int16_t *)(iVar9 + 0x10);
        }
    }
    if ((iVar9 != 0) && (iVar9 != iVar5)) {
        uVar11 = ((uVar12 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ uVar12 >> 8) * 0x100000001b3 &
                 *(uint64_t *)(arg2 + 0x30);
        iVar9 = *(int64_t *)(iVar10 + 8 + uVar11 * 0x10);
        if (iVar9 == iVar5) goto code_r0x000180161db2;
        iVar1 = *(int16_t *)(iVar9 + 0x10);
        while ((int16_t)uVar12 != iVar1) {
            if (iVar9 == *(int64_t *)(iVar10 + uVar11 * 0x10)) goto code_r0x000180161db2;
            iVar9 = *(int64_t *)(iVar9 + 8);
            iVar1 = *(int16_t *)(iVar9 + 0x10);
        }
        arg2_01 = *(int64_t *)(iVar9 + 0x18);
        if (arg3 == (*(int64_t *)(arg1 + 0x18) - iVar4 >> 1) + -1) {
            func_0x000180161dc0(arg1, arg2_01, arg4);
        } else {
            fcn.180161a70(arg1, arg2_01, arg3 + 1, arg4, *(int64_t *)(arg1 + 8), arg2);
        }
    }
    iVar4 = *(int64_t *)(arg1 + 0x10);
    uVar2 = *(uint16_t *)(iVar4 + arg3 * 2);
    if (uVar2 < 0x7f) {
        uVar12 = (uint64_t)uVar2 & 0xffffffffffff005f;
        if (0x19 < uVar2 - 0x61) {
            uVar12 = (uint64_t)uVar2;
        }
    } else {
        iVar10 = func_0x000180164c60();
        if ((iVar10 == 0) || (iVar3 = *(int32_t *)(iVar10 + 4), iVar3 == 0)) {
            uVar12 = (uint64_t)uVar2;
        } else if (iVar3 == 0xffff) {
            uVar12 = (uint64_t)(uVar2 & 0xfffe);
        } else {
            uVar12 = (uint64_t)(uint16_t)((int16_t)iVar3 + uVar2);
        }
    }
    iVar10 = *(int64_t *)(arg2 + 0x18);
    iVar5 = *(int64_t *)(arg2 + 8);
    arg2_00 = 0;
    uVar11 = ((uVar12 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ uVar12 >> 8) * 0x100000001b3 &
             *(uint64_t *)(arg2 + 0x30);
    iVar9 = *(int64_t *)(iVar10 + 8 + uVar11 * 0x10);
    if (iVar9 == iVar5) {
code_r0x000180161cb8:
        iVar9 = 0;
    } else {
        iVar1 = *(int16_t *)(iVar9 + 0x10);
        while ((int16_t)uVar12 != iVar1) {
            if (iVar9 == *(int64_t *)(iVar10 + uVar11 * 0x10)) goto code_r0x000180161cb8;
            iVar9 = *(int64_t *)(iVar9 + 8);
            iVar1 = *(int16_t *)(iVar9 + 0x10);
        }
    }
    if ((iVar9 != 0) && (iVar9 != iVar5)) {
        uVar11 = ((uVar12 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ uVar12 >> 8) * 0x100000001b3 &
                 *(uint64_t *)(arg2 + 0x30);
        iVar9 = *(int64_t *)(iVar10 + 8 + uVar11 * 0x10);
        if (iVar9 == iVar5) {
code_r0x000180161db2:
            fcn.1804546f8(0x180645d60);
            pcVar8 = (code *)swi(3);
            (*pcVar8)();
            return;
        }
        iVar1 = *(int16_t *)(iVar9 + 0x10);
        while ((int16_t)uVar12 != iVar1) {
            if (iVar9 == *(int64_t *)(iVar10 + uVar11 * 0x10)) goto code_r0x000180161db2;
            iVar9 = *(int64_t *)(iVar9 + 8);
            iVar1 = *(int16_t *)(iVar9 + 0x10);
        }
        arg2_00 = *(int64_t *)(iVar9 + 0x18);
        if (arg3 == (*(int64_t *)(arg1 + 0x18) - iVar4 >> 1) + -1) {
            func_0x000180161dc0(arg1, arg2_00, arg4);
        } else {
            fcn.180161a70(arg1, arg2_00, arg3 + 1, arg4, *(int64_t *)(arg1 + 8), arg2);
        }
    }
    if (arg_28h != 0) {
        puVar6 = *(undefined8 **)(arg2 + 8);
        for (puVar7 = (undefined8 *)*puVar6; puVar7 != puVar6; puVar7 = (undefined8 *)*puVar7) {
            iVar4 = puVar7[3];
            if ((iVar4 != arg2_01) && (iVar4 != arg2_00)) {
                fcn.180161a70(arg1, iVar4, arg3, arg4 + 1, arg_28h + -1, arg2);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180161dc0
// Address: 0x180161dc0
// Size: 458 bytes
// ============================================================
void fcn.180161dc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    int64_t *piVar4;
    code *pcVar5;
    uint64_t uVar6;
    int64_t *piVar7;
    uint64_t unaff_RBX;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined auStack_68 [8];
    undefined auStack_60 [32];
    
    puVar9 = auStack_68;
    puVar8 = auStack_68;
    if (*(int64_t *)(arg2 + 0x50) == 0) goto code_r0x000180161dfa;
    piVar7 = *(int64_t **)(arg1 + 0x30);
    if (piVar7 != *(int64_t **)(arg1 + 0x38)) {
        *piVar7 = arg2;
        piVar7[1] = arg3;
        *(int64_t *)(arg1 + 0x30) = *(int64_t *)(arg1 + 0x30) + 0x10;
        puVar8 = auStack_68;
        goto code_r0x000180161dfa;
    }
    iVar12 = (int64_t)piVar7 - *(int64_t *)(arg1 + 0x28) >> 4;
    if (iVar12 == 0xfffffffffffffff) {
        func_0x000180010010();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar6 = (int64_t)*(int64_t **)(arg1 + 0x38) - *(int64_t *)(arg1 + 0x28) >> 4;
    if (0xfffffffffffffff - (uVar6 >> 1) < uVar6) {
code_r0x000180161f84:
        func_0x000180004720();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar1 = iVar12 + 1;
    uVar6 = (uVar6 >> 1) + uVar6;
    uVar10 = uVar1;
    if (uVar1 <= uVar6) {
        uVar10 = uVar6;
    }
    if (0xfffffffffffffff < uVar10) goto code_r0x000180161f84;
    uVar10 = uVar10 * 0x10;
    if (uVar10 == 0) {
        unaff_RBX = 0;
code_r0x000180161edc:
        iVar12 = iVar12 * 0x10;
        *(int64_t *)(iVar12 + unaff_RBX) = arg2;
        *(int64_t *)(iVar12 + 8 + unaff_RBX) = arg3;
        piVar4 = *(int64_t **)(arg1 + 0x28);
        if (piVar7 == *(int64_t **)(arg1 + 0x30)) {
            iVar11 = (int64_t)*(int64_t **)(arg1 + 0x30) - (int64_t)piVar4;
            uVar6 = unaff_RBX;
            piVar7 = piVar4;
        } else {
            fcn.180498030(unaff_RBX, piVar4, (int64_t)piVar7 - (int64_t)piVar4);
            iVar11 = *(int64_t *)(arg1 + 0x30) - (int64_t)piVar7;
            uVar6 = iVar12 + 0x10 + unaff_RBX;
        }
        fcn.180498030(uVar6, piVar7, iVar11);
        iVar12 = *(int64_t *)(arg1 + 0x28);
        if (iVar12 != 0) {
            iVar11 = iVar12;
            puVar9 = auStack_68;
            if ((0xfff < (*(int64_t *)(arg1 + 0x38) - iVar12 & 0xfffffffffffffff0U)) &&
               (iVar11 = *(int64_t *)(iVar12 + -8), puVar9 = auStack_68, 0x1f < (iVar12 - iVar11) - 8U))
            goto code_r0x000180161f53;
            goto code_r0x000180161f5d;
        }
    } else {
        if (uVar10 < 0x1000) {
            unaff_RBX = func_0x000180459890(uVar10);
            goto code_r0x000180161edc;
        }
        if (uVar10 + 0x27 <= uVar10) goto code_r0x000180161f84;
        iVar11 = func_0x000180459890();
        if (iVar11 != 0) {
            unaff_RBX = iVar11 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RBX - 8) = iVar11;
            goto code_r0x000180161edc;
        }
code_r0x000180161f53:
        pcVar5 = (code *)swi(0x29);
        iVar11 = (*pcVar5)(5);
        puVar9 = auStack_60;
code_r0x000180161f5d:
        *(undefined8 *)(puVar9 + -8) = 0x180161f62;
        fcn.180459c3c(iVar11);
    }
    *(uint64_t *)(arg1 + 0x28) = unaff_RBX;
    *(uint64_t *)(arg1 + 0x30) = uVar1 * 0x10 + unaff_RBX;
    *(uint64_t *)(arg1 + 0x38) = unaff_RBX + uVar10;
    puVar8 = puVar9;
code_r0x000180161dfa:
    puVar2 = *(undefined8 **)(arg2 + 8);
    for (puVar3 = (undefined8 *)*puVar2; puVar3 != puVar2; puVar3 = (undefined8 *)*puVar3) {
        iVar12 = puVar3[3];
        *(undefined8 *)(puVar8 + -8) = 0x180161e21;
        fcn.180161dc0(arg1, iVar12, arg3 + 1);
    }
    return;
}

// ============================================================
// Function: FUN_180161fc0
// Address: 0x180161fc0
// Size: 211 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180161fc0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint8_t uVar1;
    uint8_t *puVar2;
    uint16_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    if (((uint64_t)arg2 < (uint64_t)arg3) && (uVar3 = (uint16_t)*(char *)arg2, -1 < *(char *)arg2)) {
        puVar2 = (uint8_t *)(arg2 + 1);
    } else {
        puVar2 = (uint8_t *)(arg2 + 1);
        if ((puVar2 < (uint64_t)arg3) && ((*(uint8_t *)arg2 & 0xe0) == 0xc0)) {
            uVar1 = *puVar2;
            puVar2 = (uint8_t *)(arg2 + 2);
            uVar3 = (uint16_t)(*(uint8_t *)arg2 & 0x1f) << 6 | (uint16_t)(uVar1 & 0x3f);
        } else if (((uint8_t *)(arg2 + 2U) < (uint64_t)arg3) && ((*(uint8_t *)arg2 & 0xf0) == 0xe0)) {
            uVar1 = *puVar2;
            puVar2 = (uint8_t *)(arg2 + 3);
            uVar3 = ((uint16_t)(uVar1 & 0x3f) | (int16_t)(char)*(uint8_t *)arg2 << 6) << 6 |
                    (uint16_t)(*(uint8_t *)(arg2 + 2U) & 0x3f);
        } else {
            if ((arg2 + 3U < (uint64_t)arg3) && ((*(uint8_t *)arg2 & 0xf8) == 0xf0)) {
                puVar2 = (uint8_t *)(arg2 + 4);
            }
            uVar3 = 0xfffd;
        }
    }
    *(uint16_t *)arg4 = uVar3;
    *(uint8_t **)arg1 = puVar2;
    return arg1;
}

// ============================================================
// Function: FUN_1801620a0
// Address: 0x1801620a0
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1801620a0(int64_t arg1)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    uint16_t in_DX;
    uint8_t uVar3;
    int64_t var_8h;
    
    puVar1 = (uint8_t *)(arg1 + 1);
    if (in_DX < 0x80) {
        *(uint8_t *)arg1 = (uint8_t)in_DX;
        return (int64_t)puVar1 - arg1;
    }
    uVar3 = (uint8_t)in_DX & 0x3f | 0x80;
    uVar2 = (uint8_t)(in_DX >> 6);
    if (in_DX < 0x800) {
        *(uint8_t *)arg1 = uVar2 & 0x1f | 0xc0;
        *puVar1 = uVar3;
        return 2;
    }
    *(uint8_t *)arg1 = (uint8_t)(in_DX >> 0xc) | 0xe0;
    *puVar1 = uVar2 & 0x3f | 0x80;
    *(uint8_t *)(arg1 + 2) = uVar3;
    return 3;
}

// ============================================================
// Function: FUN_1801620c4
// Address: 0x1801620c4
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1801620a0(int64_t arg1)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    uint16_t in_DX;
    uint8_t uVar3;
    int64_t var_8h;
    
    puVar1 = (uint8_t *)(arg1 + 1);
    if (in_DX < 0x80) {
        *(uint8_t *)arg1 = (uint8_t)in_DX;
        return (int64_t)puVar1 - arg1;
    }
    uVar3 = (uint8_t)in_DX & 0x3f | 0x80;
    uVar2 = (uint8_t)(in_DX >> 6);
    if (in_DX < 0x800) {
        *(uint8_t *)arg1 = uVar2 & 0x1f | 0xc0;
        *puVar1 = uVar3;
        return 2;
    }
    *(uint8_t *)arg1 = (uint8_t)(in_DX >> 0xc) | 0xe0;
    *puVar1 = uVar2 & 0x3f | 0x80;
    *(uint8_t *)(arg1 + 2) = uVar3;
    return 3;
}

// ============================================================
// Function: FUN_1801620e8
// Address: 0x1801620e8
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1801620a0(int64_t arg1)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    uint16_t in_DX;
    uint8_t uVar3;
    int64_t var_8h;
    
    puVar1 = (uint8_t *)(arg1 + 1);
    if (in_DX < 0x80) {
        *(uint8_t *)arg1 = (uint8_t)in_DX;
        return (int64_t)puVar1 - arg1;
    }
    uVar3 = (uint8_t)in_DX & 0x3f | 0x80;
    uVar2 = (uint8_t)(in_DX >> 6);
    if (in_DX < 0x800) {
        *(uint8_t *)arg1 = uVar2 & 0x1f | 0xc0;
        *puVar1 = uVar3;
        return 2;
    }
    *(uint8_t *)arg1 = (uint8_t)(in_DX >> 0xc) | 0xe0;
    *puVar1 = uVar2 & 0x3f | 0x80;
    *(uint8_t *)(arg1 + 2) = uVar3;
    return 3;
}

// ============================================================
// Function: FUN_1801621e0
// Address: 0x1801621e0
// Size: 80 bytes
// ============================================================
undefined8 fcn.1801621e0(uint16_t param_1)
{
    char cVar1;
    
    if (param_1 < 0x7f) {
        if (((0x19 < (param_1 | 0x20) - 0x61) && (9 < param_1 - 0x30)) && (param_1 != 0x5f)) {
            return 0;
        }
    } else {
        cVar1 = func_0x000180163840(param_1, param_1);
        if ((cVar1 == '\0') && (cVar1 = func_0x0001801638d0(), cVar1 == '\0')) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180162230
// Address: 0x180162230
// Size: 88 bytes
// ============================================================
uint64_t fcn.180162230(uint64_t param_1)
{
    int32_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    
    uVar2 = param_1 & 0xffff;
    if ((uint32_t)uVar2 < 0x7f) {
        if ((uint32_t)uVar2 - 0x41 < 0x1a) {
            uVar2 = uVar2 | 0x20;
        }
        return uVar2;
    }
    iVar3 = fcn.180164c60(param_1, uVar2);
    if ((iVar3 != 0) && (iVar1 = *(int32_t *)(iVar3 + 8), iVar1 != 0)) {
        if (iVar1 == 0xffff) {
            return (uint64_t)(uint16_t)((uint16_t)param_1 | 1);
        }
        uVar2 = (uint64_t)(uint16_t)((uint16_t)param_1 + (int16_t)iVar1);
    }
    return uVar2;
}

// ============================================================
// Function: FUN_180162290
// Address: 0x180162290
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180162290(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    int64_t iVar4;
    bool bVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((uint64_t)arg2 < (uint64_t)arg3) {
        uVar2 = *(uint16_t *)arg2;
        if (0x7e < uVar2) {
            uVar6 = 0x180779cc0;
            uVar7 = 0x18077a51e;
            do {
                iVar4 = (int64_t)(uVar7 - uVar6) / 0xc;
                iVar1 = uVar6 + iVar4 * 6;
                uVar3 = *(uint16_t *)(uVar6 + iVar4 * 6);
                if (uVar2 < uVar3) {
                    uVar7 = iVar1 - 6;
                } else {
                    if (uVar2 <= *(uint16_t *)(iVar1 + 2)) {
                        if ((*(uint16_t *)(iVar1 + 4) == 1) ||
                           ((int32_t)((uint32_t)uVar2 - (uint32_t)uVar3) % (int32_t)(uint32_t)*(uint16_t *)(iVar1 + 4)
                            == 0)) {
                            bVar5 = true;
                        } else {
                            bVar5 = false;
                        }
                        if (!bVar5) goto code_r0x000180162443;
                        goto code_r0x000180162368;
                    }
                    uVar6 = iVar1 + 6;
                }
                if (uVar7 < uVar6) {
                    *(int64_t *)arg1 = arg2;
                    return arg1;
                }
            } while( true );
        }
        if ((uVar2 == 0x5f) || ((uVar2 | 0x20) - 0x61 < 0x1a)) {
code_r0x000180162368:
            arg2 = arg2 + 4;
            if ((uint64_t)arg2 < (uint64_t)arg3) {
code_r0x000180162390:
                uVar2 = *(uint16_t *)arg2;
                if (0x7e < uVar2) {
                    uVar6 = 0x1807785c0;
                    uVar7 = 0x180778f68;
                    do {
                        iVar1 = (int64_t)(uVar7 - uVar6) / 0xc;
                        uVar3 = *(uint16_t *)(uVar6 + iVar1 * 6);
                        iVar1 = uVar6 + iVar1 * 6;
                        if (uVar2 < uVar3) {
                            uVar7 = iVar1 - 6;
                        } else {
                            if (uVar2 <= *(uint16_t *)(iVar1 + 2)) goto code_r0x000180162402;
                            uVar6 = iVar1 + 6;
                        }
                        if (uVar7 < uVar6) goto code_r0x000180162443;
                    } while( true );
                }
                if (((uVar2 == 0x5f) || ((uVar2 | 0x20) - 0x61 < 0x1a)) || (uVar2 - 0x30 < 10))
                goto code_r0x000180162422;
            }
        }
    }
code_r0x000180162443:
    *(int64_t *)arg1 = arg2;
    return arg1;
code_r0x000180162402:
    if ((*(uint16_t *)(iVar1 + 4) == 1) ||
       ((int32_t)((uint32_t)uVar2 - (uint32_t)uVar3) % (int32_t)(uint32_t)*(uint16_t *)(iVar1 + 4) == 0)) {
        bVar5 = true;
    } else {
        bVar5 = false;
    }
    if (!bVar5) goto code_r0x000180162443;
code_r0x000180162422:
    arg2 = arg2 + 4;
    if ((uint64_t)arg3 <= (uint64_t)arg2) goto code_r0x000180162443;
    goto code_r0x000180162390;
}

// ============================================================
// Function: FUN_1801622a1
// Address: 0x1801622a1
// Size: 161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180162290(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    int64_t iVar4;
    bool bVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((uint64_t)arg2 < (uint64_t)arg3) {
        uVar2 = *(uint16_t *)arg2;
        if (0x7e < uVar2) {
            uVar6 = 0x180779cc0;
            uVar7 = 0x18077a51e;
            do {
                iVar4 = (int64_t)(uVar7 - uVar6) / 0xc;
                iVar1 = uVar6 + iVar4 * 6;
                uVar3 = *(uint16_t *)(uVar6 + iVar4 * 6);
                if (uVar2 < uVar3) {
                    uVar7 = iVar1 - 6;
                } else {
                    if (uVar2 <= *(uint16_t *)(iVar1 + 2)) {
                        if ((*(uint16_t *)(iVar1 + 4) == 1) ||
                           ((int32_t)((uint32_t)uVar2 - (uint32_t)uVar3) % (int32_t)(uint32_t)*(uint16_t *)(iVar1 + 4)
                            == 0)) {
                            bVar5 = true;
                        } else {
                            bVar5 = false;
                        }
                        if (!bVar5) goto code_r0x000180162443;
                        goto code_r0x000180162368;
                    }
                    uVar6 = iVar1 + 6;
                }
                if (uVar7 < uVar6) {
                    *(int64_t *)arg1 = arg2;
                    return arg1;
                }
            } while( true );
        }
        if ((uVar2 == 0x5f) || ((uVar2 | 0x20) - 0x61 < 0x1a)) {
code_r0x000180162368:
            arg2 = arg2 + 4;
            if ((uint64_t)arg2 < (uint64_t)arg3) {
code_r0x000180162390:
                uVar2 = *(uint16_t *)arg2;
                if (0x7e < uVar2) {
                    uVar6 = 0x1807785c0;
                    uVar7 = 0x180778f68;
                    do {
                        iVar1 = (int64_t)(uVar7 - uVar6) / 0xc;
                        uVar3 = *(uint16_t *)(uVar6 + iVar1 * 6);
                        iVar1 = uVar6 + iVar1 * 6;
                        if (uVar2 < uVar3) {
                            uVar7 = iVar1 - 6;
                        } else {
                            if (uVar2 <= *(uint16_t *)(iVar1 + 2)) goto code_r0x000180162402;
                            uVar6 = iVar1 + 6;
                        }
                        if (uVar7 < uVar6) goto code_r0x000180162443;
                    } while( true );
                }
                if (((uVar2 == 0x5f) || ((uVar2 | 0x20) - 0x61 < 0x1a)) || (uVar2 - 0x30 < 10))
                goto code_r0x000180162422;
            }
        }
    }
code_r0x000180162443:
    *(int64_t *)arg1 = arg2;
    return arg1;
code_r0x000180162402:
    if ((*(uint16_t *)(iVar1 + 4) == 1) ||
       ((int32_t)((uint32_t)uVar2 - (uint32_t)uVar3) % (int32_t)(uint32_t)*(uint16_t *)(iVar1 + 4) == 0)) {
        bVar5 = true;
    } else {
        bVar5 = false;
    }
    if (!bVar5) goto code_r0x000180162443;
code_r0x000180162422:
    arg2 = arg2 + 4;
    if ((uint64_t)arg3 <= (uint64_t)arg2) goto code_r0x000180162443;
    goto code_r0x000180162390;
}

// ============================================================
// Function: FUN_180162342
// Address: 0x180162342
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180162290(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    int64_t iVar4;
    bool bVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((uint64_t)arg2 < (uint64_t)arg3) {
        uVar2 = *(uint16_t *)arg2;
        if (0x7e < uVar2) {
            uVar6 = 0x180779cc0;
            uVar7 = 0x18077a51e;
            do {
                iVar4 = (int64_t)(uVar7 - uVar6) / 0xc;
                iVar1 = uVar6 + iVar4 * 6;
                uVar3 = *(uint16_t *)(uVar6 + iVar4 * 6);
                if (uVar2 < uVar3) {
                    uVar7 = iVar1 - 6;
                } else {
                    if (uVar2 <= *(uint16_t *)(iVar1 + 2)) {
                        if ((*(uint16_t *)(iVar1 + 4) == 1) ||
                           ((int32_t)((uint32_t)uVar2 - (uint32_t)uVar3) % (int32_t)(uint32_t)*(uint16_t *)(iVar1 + 4)
                            == 0)) {
                            bVar5 = true;
                        } else {
                            bVar5 = false;
                        }
                        if (!bVar5) goto code_r0x000180162443;
                        goto code_r0x000180162368;
                    }
                    uVar6 = iVar1 + 6;
                }
                if (uVar7 < uVar6) {
                    *(int64_t *)arg1 = arg2;
                    return arg1;
                }
            } while( true );
        }
        if ((uVar2 == 0x5f) || ((uVar2 | 0x20) - 0x61 < 0x1a)) {
code_r0x000180162368:
            arg2 = arg2 + 4;
            if ((uint64_t)arg2 < (uint64_t)arg3) {
code_r0x000180162390:
                uVar2 = *(uint16_t *)arg2;
                if (0x7e < uVar2) {
                    uVar6 = 0x1807785c0;
                    uVar7 = 0x180778f68;
                    do {
                        iVar1 = (int64_t)(uVar7 - uVar6) / 0xc;
                        uVar3 = *(uint16_t *)(uVar6 + iVar1 * 6);
                        iVar1 = uVar6 + iVar1 * 6;
                        if (uVar2 < uVar3) {
                            uVar7 = iVar1 - 6;
                        } else {
                            if (uVar2 <= *(uint16_t *)(iVar1 + 2)) goto code_r0x000180162402;
                            uVar6 = iVar1 + 6;
                        }
                        if (uVar7 < uVar6) goto code_r0x000180162443;
                    } while( true );
                }
                if (((uVar2 == 0x5f) || ((uVar2 | 0x20) - 0x61 < 0x1a)) || (uVar2 - 0x30 < 10))
                goto code_r0x000180162422;
            }
        }
    }
code_r0x000180162443:
    *(int64_t *)arg1 = arg2;
    return arg1;
code_r0x000180162402:
    if ((*(uint16_t *)(iVar1 + 4) == 1) ||
       ((int32_t)((uint32_t)uVar2 - (uint32_t)uVar3) % (int32_t)(uint32_t)*(uint16_t *)(iVar1 + 4) == 0)) {
        bVar5 = true;
    } else {
        bVar5 = false;
    }
    if (!bVar5) goto code_r0x000180162443;
code_r0x000180162422:
    arg2 = arg2 + 4;
    if ((uint64_t)arg3 <= (uint64_t)arg2) goto code_r0x000180162443;
    goto code_r0x000180162390;
}

// ============================================================
// Function: FUN_180162375
// Address: 0x180162375
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180162290(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    int64_t iVar4;
    bool bVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((uint64_t)arg2 < (uint64_t)arg3) {
        uVar2 = *(uint16_t *)arg2;
        if (0x7e < uVar2) {
            uVar6 = 0x180779cc0;
            uVar7 = 0x18077a51e;
            do {
                iVar4 = (int64_t)(uVar7 - uVar6) / 0xc;
                iVar1 = uVar6 + iVar4 * 6;
                uVar3 = *(uint16_t *)(uVar6 + iVar4 * 6);
                if (uVar2 < uVar3) {
                    uVar7 = iVar1 - 6;
                } else {
                    if (uVar2 <= *(uint16_t *)(iVar1 + 2)) {
                        if ((*(uint16_t *)(iVar1 + 4) == 1) ||
                           ((int32_t)((uint32_t)uVar2 - (uint32_t)uVar3) % (int32_t)(uint32_t)*(uint16_t *)(iVar1 + 4)
                            == 0)) {
                            bVar5 = true;
                        } else {
                            bVar5 = false;
                        }
                        if (!bVar5) goto code_r0x000180162443;
                        goto code_r0x000180162368;
                    }
                    uVar6 = iVar1 + 6;
                }
                if (uVar7 < uVar6) {
                    *(int64_t *)arg1 = arg2;
                    return arg1;
                }
            } while( true );
        }
        if ((uVar2 == 0x5f) || ((uVar2 | 0x20) - 0x61 < 0x1a)) {
code_r0x000180162368:
            arg2 = arg2 + 4;
            if ((uint64_t)arg2 < (uint64_t)arg3) {
code_r0x000180162390:
                uVar2 = *(uint16_t *)arg2;
                if (0x7e < uVar2) {
                    uVar6 = 0x1807785c0;
                    uVar7 = 0x180778f68;
                    do {
                        iVar1 = (int64_t)(uVar7 - uVar6) / 0xc;
                        uVar3 = *(uint16_t *)(uVar6 + iVar1 * 6);
                        iVar1 = uVar6 + iVar1 * 6;
                        if (uVar2 < uVar3) {
                            uVar7 = iVar1 - 6;
                        } else {
                            if (uVar2 <= *(uint16_t *)(iVar1 + 2)) goto code_r0x000180162402;
                            uVar6 = iVar1 + 6;
                        }
                        if (uVar7 < uVar6) goto code_r0x000180162443;
                    } while( true );
                }
                if (((uVar2 == 0x5f) || ((uVar2 | 0x20) - 0x61 < 0x1a)) || (uVar2 - 0x30 < 10))
                goto code_r0x000180162422;
            }
        }
    }
code_r0x000180162443:
    *(int64_t *)arg1 = arg2;
    return arg1;
code_r0x000180162402:
    if ((*(uint16_t *)(iVar1 + 4) == 1) ||
       ((int32_t)((uint32_t)uVar2 - (uint32_t)uVar3) % (int32_t)(uint32_t)*(uint16_t *)(iVar1 + 4) == 0)) {
        bVar5 = true;
    } else {
        bVar5 = false;
    }
    if (!bVar5) goto code_r0x000180162443;
code_r0x000180162422:
    arg2 = arg2 + 4;
    if ((uint64_t)arg3 <= (uint64_t)arg2) goto code_r0x000180162443;
    goto code_r0x000180162390;
}

// ============================================================
// Function: FUN_180162439
// Address: 0x180162439
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180162290(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    int64_t iVar4;
    bool bVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((uint64_t)arg2 < (uint64_t)arg3) {
        uVar2 = *(uint16_t *)arg2;
        if (0x7e < uVar2) {
            uVar6 = 0x180779cc0;
            uVar7 = 0x18077a51e;
            do {
                iVar4 = (int64_t)(uVar7 - uVar6) / 0xc;
                iVar1 = uVar6 + iVar4 * 6;
                uVar3 = *(uint16_t *)(uVar6 + iVar4 * 6);
                if (uVar2 < uVar3) {
                    uVar7 = iVar1 - 6;
                } else {
                    if (uVar2 <= *(uint16_t *)(iVar1 + 2)) {
                        if ((*(uint16_t *)(iVar1 + 4) == 1) ||
                           ((int32_t)((uint32_t)uVar2 - (uint32_t)uVar3) % (int32_t)(uint32_t)*(uint16_t *)(iVar1 + 4)
                            == 0)) {
                            bVar5 = true;
                        } else {
                            bVar5 = false;
                        }
                        if (!bVar5) goto code_r0x000180162443;
                        goto code_r0x000180162368;
                    }
                    uVar6 = iVar1 + 6;
                }
                if (uVar7 < uVar6) {
                    *(int64_t *)arg1 = arg2;
                    return arg1;
                }
            } while( true );
        }
        if ((uVar2 == 0x5f) || ((uVar2 | 0x20) - 0x61 < 0x1a)) {
code_r0x000180162368:
            arg2 = arg2 + 4;
            if ((uint64_t)arg2 < (uint64_t)arg3) {
code_r0x000180162390:
                uVar2 = *(uint16_t *)arg2;
                if (0x7e < uVar2) {
                    uVar6 = 0x1807785c0;
                    uVar7 = 0x180778f68;
                    do {
                        iVar1 = (int64_t)(uVar7 - uVar6) / 0xc;
                        uVar3 = *(uint16_t *)(uVar6 + iVar1 * 6);
                        iVar1 = uVar6 + iVar1 * 6;
                        if (uVar2 < uVar3) {
                            uVar7 = iVar1 - 6;
                        } else {
                            if (uVar2 <= *(uint16_t *)(iVar1 + 2)) goto code_r0x000180162402;
                            uVar6 = iVar1 + 6;
                        }
                        if (uVar7 < uVar6) goto code_r0x000180162443;
                    } while( true );
                }
                if (((uVar2 == 0x5f) || ((uVar2 | 0x20) - 0x61 < 0x1a)) || (uVar2 - 0x30 < 10))
                goto code_r0x000180162422;
            }
        }
    }
code_r0x000180162443:
    *(int64_t *)arg1 = arg2;
    return arg1;
code_r0x000180162402:
    if ((*(uint16_t *)(iVar1 + 4) == 1) ||
       ((int32_t)((uint32_t)uVar2 - (uint32_t)uVar3) % (int32_t)(uint32_t)*(uint16_t *)(iVar1 + 4) == 0)) {
        bVar5 = true;
    } else {
        bVar5 = false;
    }
    if (!bVar5) goto code_r0x000180162443;
code_r0x000180162422:
    arg2 = arg2 + 4;
    if ((uint64_t)arg3 <= (uint64_t)arg2) goto code_r0x000180162443;
    goto code_r0x000180162390;
}

// ============================================================
// Function: FUN_180162443
// Address: 0x180162443
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180162290(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    int64_t iVar4;
    bool bVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((uint64_t)arg2 < (uint64_t)arg3) {
        uVar2 = *(uint16_t *)arg2;
        if (0x7e < uVar2) {
            uVar6 = 0x180779cc0;
            uVar7 = 0x18077a51e;
            do {
                iVar4 = (int64_t)(uVar7 - uVar6) / 0xc;
                iVar1 = uVar6 + iVar4 * 6;
                uVar3 = *(uint16_t *)(uVar6 + iVar4 * 6);
                if (uVar2 < uVar3) {
                    uVar7 = iVar1 - 6;
                } else {
                    if (uVar2 <= *(uint16_t *)(iVar1 + 2)) {
                        if ((*(uint16_t *)(iVar1 + 4) == 1) ||
                           ((int32_t)((uint32_t)uVar2 - (uint32_t)uVar3) % (int32_t)(uint32_t)*(uint16_t *)(iVar1 + 4)
                            == 0)) {
                            bVar5 = true;
                        } else {
                            bVar5 = false;
                        }
                        if (!bVar5) goto code_r0x000180162443;
                        goto code_r0x000180162368;
                    }
                    uVar6 = iVar1 + 6;
                }
                if (uVar7 < uVar6) {
                    *(int64_t *)arg1 = arg2;
                    return arg1;
                }
            } while( true );
        }
        if ((uVar2 == 0x5f) || ((uVar2 | 0x20) - 0x61 < 0x1a)) {
code_r0x000180162368:
            arg2 = arg2 + 4;
            if ((uint64_t)arg2 < (uint64_t)arg3) {
code_r0x000180162390:
                uVar2 = *(uint16_t *)arg2;
                if (0x7e < uVar2) {
                    uVar6 = 0x1807785c0;
                    uVar7 = 0x180778f68;
                    do {
                        iVar1 = (int64_t)(uVar7 - uVar6) / 0xc;
                        uVar3 = *(uint16_t *)(uVar6 + iVar1 * 6);
                        iVar1 = uVar6 + iVar1 * 6;
                        if (uVar2 < uVar3) {
                            uVar7 = iVar1 - 6;
                        } else {
                            if (uVar2 <= *(uint16_t *)(iVar1 + 2)) goto code_r0x000180162402;
                            uVar6 = iVar1 + 6;
                        }
                        if (uVar7 < uVar6) goto code_r0x000180162443;
                    } while( true );
                }
                if (((uVar2 == 0x5f) || ((uVar2 | 0x20) - 0x61 < 0x1a)) || (uVar2 - 0x30 < 10))
                goto code_r0x000180162422;
            }
        }
    }
code_r0x000180162443:
    *(int64_t *)arg1 = arg2;
    return arg1;
code_r0x000180162402:
    if ((*(uint16_t *)(iVar1 + 4) == 1) ||
       ((int32_t)((uint32_t)uVar2 - (uint32_t)uVar3) % (int32_t)(uint32_t)*(uint16_t *)(iVar1 + 4) == 0)) {
        bVar5 = true;
    } else {
        bVar5 = false;
    }
    if (!bVar5) goto code_r0x000180162443;
code_r0x000180162422:
    arg2 = arg2 + 4;
    if ((uint64_t)arg3 <= (uint64_t)arg2) goto code_r0x000180162443;
    goto code_r0x000180162390;
}

// ============================================================
// Function: FUN_1801628d0
// Address: 0x1801628d0
// Size: 2817 bytes
// ============================================================
void fcn.1801628d0(void)
{
    int64_t **ppiVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    undefined2 *puVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    undefined2 *puVar9;
    undefined4 *puVar10;
    int64_t iVar11;
    undefined *puVar12;
    int64_t iVar13;
    undefined4 *puVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    uint64_t uVar18;
    undefined8 *puVar19;
    int64_t unaff_GS_OFFSET;
    float fVar20;
    float fVar21;
    undefined auStack_158 [8];
    undefined auStack_150 [24];
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_100h;
    undefined4 uStack_f8;
    undefined4 uStack_f4;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar12 = auStack_158;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_158;
    puVar14 = (undefined4 *)0x0;
    if ((*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
         *(int32_t *)0x180782b38) && (func_0x000180459d18(0x180782b38), *(int32_t *)0x180782b38 == -1)) {
        var_130h = var_130h & 0xffffffff00000000;
        func_0x00018001f430(0x18077b148, &var_130h, &var_138h);
        var_130h = var_130h & 0xffffffff00000000;
        func_0x00018001f430(0x18077b188, &var_130h, &var_138h);
        var_130h = var_130h & 0xffffffff00000000;
        func_0x00018001f430(0x18077b1c8, &var_130h, &var_138h);
        *(int64_t *)0x18077b240 = 0;
        *(undefined8 *)0x18077b280 = 0;
        *(undefined8 *)0x18077b2c0 = 0;
        *(undefined8 *)0x18077b300 = 0;
        func_0x000180459c24(0x1804a2d20);
        func_0x000180459cac(0x180782b38);
    }
    uVar17 = *(uint64_t *)0x18077b028;
    if (*(char *)0x180782508 != '\0') goto code_r0x0001801632ec;
    uVar18 = 0x8000000000000027;
    if (*(uint64_t *)0x18077b028 < 3) {
        if (*(uint64_t *)0x18077b028 <= 0x7fffffffffffffff - (*(uint64_t *)0x18077b028 >> 1)) {
            uVar16 = (*(uint64_t *)0x18077b028 >> 1) + *(uint64_t *)0x18077b028;
            uVar15 = 0xf;
            if (0xf < uVar16) {
                uVar15 = uVar16;
            }
            puVar10 = puVar14;
            if (uVar15 != 0xffffffffffffffff) {
                if (0xfff < uVar15 + 1) {
                    uVar16 = uVar15 + 0x28;
                    if (uVar16 <= uVar15 + 1) goto code_r0x000180163320;
                    goto code_r0x0001801629e0;
                }
                puVar10 = (undefined4 *)func_0x000180459890();
            }
code_r0x000180162a07:
            *(undefined8 *)0x18077b020 = 3;
            *(uint64_t *)0x18077b028 = uVar15;
            *(undefined2 *)puVar10 = 0x754c;
            *(undefined *)((int64_t)puVar10 + 2) = 0x61;
            *(undefined *)((int64_t)puVar10 + 3) = 0;
            if (0xf < uVar17) {
                uVar16 = uVar17 + 1;
                puVar8 = *(undefined4 **)0x18077b010;
                if (0xfff < uVar16) {
                    puVar8 = *(undefined4 **)(*(undefined4 **)0x18077b010 + -2);
                    if (0x1f < (uint64_t)((int64_t)*(undefined4 **)0x18077b010 + (-8 - (int64_t)puVar8)))
                    goto code_r0x000180163297;
                    uVar16 = uVar17 + 0x28;
                }
                fcn.180459c3c(puVar8, uVar16);
            }
            goto code_r0x000180162a72;
        }
        uVar15 = 0x7fffffffffffffff;
        uVar16 = 0x8000000000000027;
code_r0x0001801629e0:
        iVar11 = func_0x000180459890(uVar16);
        if (iVar11 != 0) {
            puVar10 = (undefined4 *)(iVar11 + 0x27U & 0xffffffffffffffe0);
            *(int64_t *)(puVar10 + -2) = iVar11;
            goto code_r0x000180162a07;
        }
code_r0x000180163297:
        iVar11 = 5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)();
        puVar12 = auStack_150;
    } else {
        puVar10 = (undefined4 *)0x18077b010;
        if (0xf < *(uint64_t *)0x18077b028) {
            puVar10 = *(undefined4 **)0x18077b010;
        }
        *(undefined8 *)0x18077b020 = 3;
        fcn.180498030(puVar10, 0x18063de74, 3);
        *(undefined *)((int64_t)puVar10 + 3) = 0;
        puVar10 = *(undefined4 **)0x18077b010;
code_r0x000180162a72:
        *(undefined4 **)0x18077b010 = puVar10;
        uVar17 = *(uint64_t *)0x18077b050;
        if (*(uint64_t *)0x18077b050 < 2) {
            if (0x7fffffffffffffff - (*(uint64_t *)0x18077b050 >> 1) < *(uint64_t *)0x18077b050) {
                uVar15 = 0x7fffffffffffffff;
                uVar16 = 0x8000000000000027;
code_r0x000180162afe:
                iVar11 = func_0x000180459890(uVar16);
                if (iVar11 == 0) goto code_r0x000180163297;
                puVar10 = (undefined4 *)(iVar11 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar10 + -2) = iVar11;
            } else {
                uVar16 = (*(uint64_t *)0x18077b050 >> 1) + *(uint64_t *)0x18077b050;
                uVar15 = 0xf;
                if (0xf < uVar16) {
                    uVar15 = uVar16;
                }
                puVar10 = puVar14;
                if (uVar15 != 0xffffffffffffffff) {
                    if (0xfff < uVar15 + 1) {
                        uVar16 = uVar15 + 0x28;
                        if (uVar16 <= uVar15 + 1) goto code_r0x000180163320;
                        goto code_r0x000180162afe;
                    }
                    puVar10 = (undefined4 *)func_0x000180459890();
                }
            }
            *(undefined8 *)0x18077b048 = 2;
            *(uint64_t *)0x18077b050 = uVar15;
            *(undefined2 *)puVar10 = 0x2d2d;
            *(undefined *)((int64_t)puVar10 + 2) = 0;
            if (0xf < uVar17) {
                uVar16 = uVar17 + 1;
                puVar8 = *(undefined4 **)0x18077b038;
                if (0xfff < uVar16) {
                    puVar8 = *(undefined4 **)(*(undefined4 **)0x18077b038 + -2);
                    if (0x1f < (uint64_t)((int64_t)*(undefined4 **)0x18077b038 + (-8 - (int64_t)puVar8)))
                    goto code_r0x000180163297;
                    uVar16 = uVar17 + 0x28;
                }
                fcn.180459c3c(puVar8, uVar16);
            }
        } else {
            puVar10 = (undefined4 *)0x18077b038;
            if (0xf < *(uint64_t *)0x18077b050) {
                puVar10 = *(undefined4 **)0x18077b038;
            }
            *(undefined8 *)0x18077b048 = 2;
            *(undefined2 *)puVar10 = 0x2d2d;
            *(undefined *)((int64_t)puVar10 + 2) = 0;
            puVar10 = *(undefined4 **)0x18077b038;
        }
        *(undefined4 **)0x18077b038 = puVar10;
        uVar17 = *(uint64_t *)0x18077b090;
        if (*(uint64_t *)0x18077b090 < 4) {
            if (0x7fffffffffffffff - (*(uint64_t *)0x18077b090 >> 1) < *(uint64_t *)0x18077b090) {
                uVar15 = 0x7fffffffffffffff;
                uVar16 = 0x8000000000000027;
code_r0x000180162c11:
                iVar11 = func_0x000180459890(uVar16);
                if (iVar11 == 0) goto code_r0x000180163297;
                puVar10 = (undefined4 *)(iVar11 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar10 + -2) = iVar11;
            } else {
                uVar16 = *(uint64_t *)0x18077b090 + (*(uint64_t *)0x18077b090 >> 1);
                uVar15 = 0xf;
                if (0xf < uVar16) {
                    uVar15 = uVar16;
                }
                puVar10 = puVar14;
                if (uVar15 != 0xffffffffffffffff) {
                    if (0xfff < uVar15 + 1) {
                        uVar16 = uVar15 + 0x28;
                        if (uVar16 <= uVar15 + 1) goto code_r0x000180163320;
                        goto code_r0x000180162c11;
                    }
                    puVar10 = (undefined4 *)func_0x000180459890();
                }
            }
            *(undefined8 *)0x18077b088 = 4;
            *(uint64_t *)0x18077b090 = uVar15;
            *puVar10 = 0x5b5b2d2d;
            *(undefined *)(puVar10 + 1) = 0;
            if (0xf < uVar17) {
                uVar16 = uVar17 + 1;
                puVar8 = *(undefined4 **)0x18077b078;
                if (0xfff < uVar16) {
                    puVar8 = *(undefined4 **)(*(undefined4 **)0x18077b078 + -2);
                    if (0x1f < (uint64_t)((int64_t)*(undefined4 **)0x18077b078 + (-8 - (int64_t)puVar8)))
                    goto code_r0x000180163297;
                    uVar16 = uVar17 + 0x28;
                }
                fcn.180459c3c(puVar8, uVar16);
            }
        } else {
            puVar10 = (undefined4 *)0x18077b078;
            if (0xf < *(uint64_t *)0x18077b090) {
                puVar10 = *(undefined4 **)0x18077b078;
            }
            *(undefined8 *)0x18077b088 = 4;
            *puVar10 = 0x5b5b2d2d;
            *(undefined *)(puVar10 + 1) = 0;
            puVar10 = *(undefined4 **)0x18077b078;
        }
        *(undefined4 **)0x18077b078 = puVar10;
        uVar17 = *(uint64_t *)0x18077b0b0;
        if (*(uint64_t *)0x18077b0b0 < 2) {
            if (0x7fffffffffffffff - (*(uint64_t *)0x18077b0b0 >> 1) < *(uint64_t *)0x18077b0b0) {
                uVar15 = 0x7fffffffffffffff;
                uVar16 = 0x8000000000000027;
code_r0x000180162d24:
                iVar11 = func_0x000180459890(uVar16);
                if (iVar11 == 0) goto code_r0x000180163297;
                puVar10 = (undefined4 *)(iVar11 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar10 + -2) = iVar11;
            } else {
                uVar16 = *(uint64_t *)0x18077b0b0 + (*(uint64_t *)0x18077b0b0 >> 1);
                uVar15 = 0xf;
                if (0xf < uVar16) {
                    uVar15 = uVar16;
                }
                puVar10 = puVar14;
                if (uVar15 != 0xffffffffffffffff) {
                    if (0xfff < uVar15 + 1) {
                        uVar16 = uVar15 + 0x28;
                        if (uVar16 <= uVar15 + 1) goto code_r0x000180163320;
                        goto code_r0x000180162d24;
                    }
                    puVar10 = (undefined4 *)func_0x000180459890();
                }
            }
            *(undefined8 *)0x18077b0a8 = 2;
            *(uint64_t *)0x18077b0b0 = uVar15;
            *(undefined2 *)puVar10 = 0x5d5d;
            *(undefined *)((int64_t)puVar10 + 2) = 0;
            if (0xf < uVar17) {
                uVar16 = uVar17 + 1;
                puVar8 = *(undefined4 **)0x18077b098;
                if (0xfff < uVar16) {
                    puVar8 = *(undefined4 **)(*(undefined4 **)0x18077b098 + -2);
                    if (0x1f < (uint64_t)((int64_t)*(undefined4 **)0x18077b098 + (-8 - (int64_t)puVar8)))
                    goto code_r0x000180163297;
                    uVar16 = uVar17 + 0x28;
                }
                fcn.180459c3c(puVar8, uVar16);
            }
        } else {
            puVar10 = (undefined4 *)0x18077b098;
            if (0xf < *(uint64_t *)0x18077b0b0) {
                puVar10 = *(undefined4 **)0x18077b098;
            }
            *(undefined8 *)0x18077b0a8 = 2;
            *(undefined2 *)puVar10 = 0x5d5d;
            *(undefined *)((int64_t)puVar10 + 2) = 0;
            puVar10 = *(undefined4 **)0x18077b098;
        }
        *(undefined4 **)0x18077b098 = puVar10;
        uVar17 = *(uint64_t *)0x18077b0d8;
        *(undefined2 *)0x18077b0b8 = 0x101;
        if (*(uint64_t *)0x18077b0d8 < 2) {
            if (0x7fffffffffffffff - (*(uint64_t *)0x18077b0d8 >> 1) < *(uint64_t *)0x18077b0d8) {
                uVar16 = 0x7fffffffffffffff;
code_r0x000180162e08:
                iVar11 = func_0x000180459890(uVar18);
                if (iVar11 == 0) goto code_r0x000180163297;
                puVar10 = (undefined4 *)(iVar11 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar10 + -2) = iVar11;
            } else {
                uVar18 = (*(uint64_t *)0x18077b0d8 >> 1) + *(uint64_t *)0x18077b0d8;
                uVar16 = 0xf;
                if (0xf < uVar18) {
                    uVar16 = uVar18;
                }
                puVar10 = puVar14;
                if (uVar16 != 0xffffffffffffffff) {
                    if (0xfff < uVar16 + 1) {
                        uVar18 = uVar16 + 0x28;
                        if (uVar18 <= uVar16 + 1) {
code_r0x000180163320:
                            func_0x000180004720();
                            pcVar2 = (code *)swi(3);
                            (*pcVar2)();
                            return;
                        }
                        goto code_r0x000180162e08;
                    }
                    puVar10 = (undefined4 *)func_0x000180459890();
                }
            }
            *(undefined8 *)0x18077b0d0 = 2;
            *(uint64_t *)0x18077b0d8 = uVar16;
            *(undefined2 *)puVar10 = 0x5b5b;
            *(undefined *)((int64_t)puVar10 + 2) = 0;
            if (0xf < uVar17) {
                uVar18 = uVar17 + 1;
                puVar8 = *(undefined4 **)0x18077b0c0;
                if (0xfff < uVar18) {
                    puVar8 = *(undefined4 **)(*(undefined4 **)0x18077b0c0 + -2);
                    if (0x1f < (uint64_t)((int64_t)*(undefined4 **)0x18077b0c0 + (-8 - (int64_t)puVar8)))
                    goto code_r0x000180163297;
                    uVar18 = uVar17 + 0x28;
                }
                fcn.180459c3c(puVar8, uVar18);
            }
        } else {
            puVar10 = (undefined4 *)0x18077b0c0;
            if (0xf < *(uint64_t *)0x18077b0d8) {
                puVar10 = *(undefined4 **)0x18077b0c0;
            }
            *(undefined8 *)0x18077b0d0 = 2;
            *(undefined2 *)puVar10 = 0x5b5b;
            *(undefined *)((int64_t)puVar10 + 2) = 0;
            puVar10 = *(undefined4 **)0x18077b0c0;
        }
        *(undefined4 **)0x18077b0c0 = puVar10;
        uVar17 = *(uint64_t *)0x18077b0f8;
        if (*(uint64_t *)0x18077b0f8 < 2) {
            var_130h = 0x7fffffffffffffff;
            if (*(uint64_t *)0x18077b0f8 <= 0x7fffffffffffffff - (*(uint64_t *)0x18077b0f8 >> 1)) {
                uVar18 = (*(uint64_t *)0x18077b0f8 >> 1) + *(uint64_t *)0x18077b0f8;
                var_130h = 0xf;
                if (0xf < uVar18) {
                    var_130h = uVar18;
                }
            }
            puVar5 = (undefined2 *)func_0x000180004930(0x18077b0e0, &var_130h);
            *(undefined8 *)0x18077b0f0 = 2;
            *(uint64_t *)0x18077b0f8 = var_130h;
            *puVar5 = 0x5d5d;
            *(undefined *)(puVar5 + 1) = 0;
            if (0xf < uVar17) {
                uVar18 = uVar17 + 1;
                puVar9 = *(undefined2 **)0x18077b0e0;
                if (0xfff < uVar18) {
                    puVar9 = *(undefined2 **)(*(undefined2 **)0x18077b0e0 + -4);
                    if (0x1f < (uint64_t)((int64_t)*(undefined2 **)0x18077b0e0 + (-8 - (int64_t)puVar9)))
                    goto code_r0x000180163297;
                    uVar18 = uVar17 + 0x28;
                }
                fcn.180459c3c(puVar9, uVar18);
            }
        } else {
            puVar5 = (undefined2 *)0x18077b0e0;
            if (0xf < *(uint64_t *)0x18077b0f8) {
                puVar5 = *(undefined2 **)0x18077b0e0;
            }
            *(undefined8 *)0x18077b0f0 = 2;
            *puVar5 = 0x5d5d;
            *(undefined *)(puVar5 + 1) = 0;
            puVar5 = *(undefined2 **)0x18077b0e0;
        }
        *(undefined2 **)0x18077b0e0 = puVar5;
        *(undefined2 *)0x18077b140 = 0x5c;
        puVar19 = (undefined8 *)0x180645db0;
        do {
            _var_100h = ZEXT816(0);
            var_f0h = 0;
            var_e8h = 0;
            uVar6 = func_0x000180498cd0(*puVar19);
            func_0x000180004830(&var_100h, *puVar19, uVar6);
            uVar17 = var_e8h;
            iVar11 = var_100h;
            piVar7 = &var_100h;
            if (0xf < (uint64_t)var_e8h) {
                piVar7 = (int64_t *)var_100h;
            }
            uVar18 = 0xcbf29ce484222325;
            puVar10 = puVar14;
            if (var_f0h != 0) {
                do {
                    uVar18 = (uVar18 ^ *(uint8_t *)((int64_t)piVar7 + (int64_t)puVar10)) * 0x100000001b3;
                    puVar10 = (undefined4 *)((int64_t)puVar10 + 1);
                } while (puVar10 < (uint64_t)var_f0h);
            }
            func_0x00018001fd20(0x18077b148, &var_120h, &var_100h, uVar18);
            if (CONCAT44(var_118h._4_4_, (undefined4)var_118h) == 0) {
                if (*(int64_t *)0x18077b158 == 0x555555555555555) {
                    func_0x0001804546d4(0x180620428);
                    goto code_r0x000180163320;
                }
                var_130h = 0x18077b150;
                var_128h = 0;
                piVar7 = (int64_t *)func_0x00018001ff60(0x18077b150, 1);
                *(undefined4 *)(piVar7 + 2) = (undefined4)var_100h;
                *(undefined4 *)((int64_t)piVar7 + 0x14) = var_100h._4_4_;
                *(undefined4 *)(piVar7 + 3) = uStack_f8;
                *(undefined4 *)((int64_t)piVar7 + 0x1c) = uStack_f4;
                *(undefined4 *)(piVar7 + 4) = (undefined4)var_f0h;
                *(undefined4 *)((int64_t)piVar7 + 0x24) = var_f0h._4_4_;
                *(undefined4 *)(piVar7 + 5) = (undefined4)var_e8h;
                *(undefined4 *)((int64_t)piVar7 + 0x2c) = var_e8h._4_4_;
                var_f0h = 0;
                uVar17 = 0xf;
                var_e8h = 0xf;
                auVar3[15] = 0;
                auVar3._0_15_ = stack0xffffffffffffff01;
                _var_100h = auVar3 << 8;
                uVar16 = *(int64_t *)0x18077b158 + 1;
                if ((int64_t)uVar16 < 0) {
                    fVar20 = (float)(uVar16 >> 1 | (uint64_t)((uint32_t)uVar16 & 1));
                    fVar20 = fVar20 + fVar20;
                } else {
                    fVar20 = (float)uVar16;
                }
                if ((int64_t)*(uint64_t *)0x18077b180 < 0) {
                    fVar21 = (float)(*(uint64_t *)0x18077b180 >> 1 | (uint64_t)((uint32_t)*(uint64_t *)0x18077b180 & 1))
                    ;
                    fVar21 = fVar21 + fVar21;
                } else {
                    fVar21 = (float)*(uint64_t *)0x18077b180;
                }
                if (*(float *)0x18077b148 < fVar20 / fVar21) {
                    var_128h = (int64_t)piVar7;
                    func_0x00018001ffd0(0x18077b148);
                    puVar10 = (undefined4 *)func_0x00018001fd20(0x18077b148, &var_110h, piVar7 + 2, uVar18);
                    var_120h._0_4_ = *puVar10;
                    var_120h._4_4_ = puVar10[1];
                    var_118h._0_4_ = puVar10[2];
                    var_118h._4_4_ = puVar10[3];
                }
                var_128h = 0;
                iVar13 = CONCAT44(var_120h._4_4_, (undefined4)var_120h);
                ppiVar1 = *(int64_t ***)(iVar13 + 8);
                *(int64_t *)0x18077b158 = *(int64_t *)0x18077b158 + 1;
                *piVar7 = iVar13;
                piVar7[1] = (int64_t)ppiVar1;
                *ppiVar1 = piVar7;
                *(int64_t **)(iVar13 + 8) = piVar7;
                iVar4 = *(int64_t *)0x18077b160;
                uVar18 = uVar18 & *(uint64_t *)0x18077b178;
                iVar11 = *(int64_t *)(*(int64_t *)0x18077b160 + uVar18 * 0x10);
                if (iVar11 == *(int64_t *)0x18077b150) {
                    *(int64_t **)(*(int64_t *)0x18077b160 + uVar18 * 0x10) = piVar7;
code_r0x0001801631c2:
                    *(int64_t **)(iVar4 + 8 + uVar18 * 0x10) = piVar7;
                } else if (iVar11 == iVar13) {
                    *(int64_t **)(*(int64_t *)0x18077b160 + uVar18 * 0x10) = piVar7;
                } else if (*(int64_t ***)(*(int64_t *)0x18077b160 + 8 + uVar18 * 0x10) == ppiVar1)
                goto code_r0x0001801631c2;
                iVar11 = var_100h;
            }
            if (0xf < uVar17) {
                uVar18 = uVar17 + 1;
                iVar13 = iVar11;
                if (0xfff < uVar18) {
                    iVar13 = *(int64_t *)(iVar11 + -8);
                    if (0x1f < (iVar11 - iVar13) - 8U) goto code_r0x000180163297;
                    uVar18 = uVar17 + 0x28;
                }
                fcn.180459c3c(iVar13, uVar18);
            }
            puVar19 = puVar19 + 1;
        } while (puVar19 != (undefined8 *)0x180645e60);
        var_d8h = 0x180645f88;
        var_d0h = 0x1801628b0;
        var_a0h = (int64_t)&var_d8h;
        var_60h = 0;
        func_0x000180014de0(&var_98h, &var_d8h);
        func_0x000180014de0(&var_d8h, 0x18077b208);
        puVar12 = auStack_158;
        iVar11 = *(int64_t *)0x18077b240;
        if ((var_60h != 0) && (puVar12 = auStack_158, iVar11 = var_60h, (int64_t *)var_60h == &var_98h)) {
            *(int64_t *)0x18077b240 = (**(code **)(*(int64_t *)var_60h + 8))(var_60h, 0x18077b208);
            puVar12 = auStack_158;
            iVar11 = *(int64_t *)0x18077b240;
            if (var_60h != 0) {
                (**(code **)(*(int64_t *)var_60h + 0x20))
                          (var_60h, CONCAT71((unkint7)((uint64_t)&var_98h >> 8), (int64_t *)var_60h != &var_98h));
                puVar12 = auStack_158;
                iVar11 = *(int64_t *)0x18077b240;
            }
        }
    }
    *(int64_t *)0x18077b240 = iVar11;
    if (var_a0h != 0) {
        pcVar2 = *(code **)(*(int64_t *)var_a0h + 0x20);
        *(undefined8 *)(puVar12 + -8) = 0x1801632bf;
        (*pcVar2)(var_a0h, (int64_t *)var_a0h != &var_d8h);
    }
    *(undefined8 *)(puVar12 + -8) = 0x1801632d2;
    func_0x000180163960(0x18077b248, fcn.180162290);
    *(undefined8 *)(puVar12 + -8) = 0x1801632e5;
    func_0x000180163960(0x18077b288, 0x180162450);
    *(char *)0x180782508 = '\x01';
code_r0x0001801632ec:
    *(undefined8 *)(puVar12 + -8) = 0x1801632ff;
    fcn.180459870(var_58h ^ (uint64_t)puVar12);
    return;
}

