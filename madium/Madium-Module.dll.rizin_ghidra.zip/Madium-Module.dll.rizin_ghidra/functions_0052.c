// Chunk 52 - 50 functions

// ============================================================
// Function: FUN_1800a3b90
// Address: 0x1800a3b90
// Size: 134 bytes
// ============================================================
int64_t fcn.1800a3b90(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    iVar1 = *(int32_t *)(arg2 + 0xc);
    if (iVar1 == 9) {
        arg2 = *(int64_t *)arg2;
        if ((*(char *)(arg2 + 3) != -0x7f) && (arg2 + 8 + *(int64_t *)(arg2 + 8) != 0)) {
            iVar2 = *(int64_t *)(arg1 + 0x20);
            piVar4 = (int64_t *)fcn.1800a0e30(*(int64_t *)(arg2 + 8) + arg2 + 8, *(undefined8 *)(iVar2 + 0x3c0));
            if (*(int32_t *)((int64_t)piVar4 + 0xc) != 6) {
                return *(int64_t *)(iVar2 + 0x418);
            }
            return *piVar4;
        }
    } else if (((iVar1 == 2) && (*(uint32_t *)(arg2 + 8) < 0x80)) &&
              (iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x3c30 + (int64_t)(int32_t)*(uint32_t *)(arg2 + 8) * 8),
              iVar2 != 0)) {
        return iVar2;
    }
    iVar2 = *(int64_t *)(arg1 + 0x20);
    iVar3 = *(int64_t *)(iVar2 + 0x440 + (int64_t)iVar1 * 8);
    if ((iVar3 != 0) &&
       (piVar4 = (int64_t *)fcn.1800a0e30(iVar3, *(undefined8 *)(iVar2 + 0x3c0)),
       *(int32_t *)((int64_t)piVar4 + 0xc) == 6)) {
        return *piVar4;
    }
    return *(int64_t *)(iVar2 + 0x3d0 + (int64_t)iVar1 * 8);
}

// ============================================================
// Function: FUN_1800a3c16
// Address: 0x1800a3c16
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800a3b90(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    iVar1 = *(int32_t *)(arg2 + 0xc);
    if (iVar1 == 9) {
        arg2 = *(int64_t *)arg2;
        if ((*(char *)(arg2 + 3) != -0x7f) && (arg2 + 8 + *(int64_t *)(arg2 + 8) != 0)) {
            iVar2 = *(int64_t *)(arg1 + 0x20);
            piVar4 = (int64_t *)fcn.1800a0e30(*(int64_t *)(arg2 + 8) + arg2 + 8, *(undefined8 *)(iVar2 + 0x3c0));
            if (*(int32_t *)((int64_t)piVar4 + 0xc) != 6) {
                return *(int64_t *)(iVar2 + 0x418);
            }
            return *piVar4;
        }
    } else if (((iVar1 == 2) && (*(uint32_t *)(arg2 + 8) < 0x80)) &&
              (iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x3c30 + (int64_t)(int32_t)*(uint32_t *)(arg2 + 8) * 8),
              iVar2 != 0)) {
        return iVar2;
    }
    iVar2 = *(int64_t *)(arg1 + 0x20);
    iVar3 = *(int64_t *)(iVar2 + 0x440 + (int64_t)iVar1 * 8);
    if ((iVar3 != 0) &&
       (piVar4 = (int64_t *)fcn.1800a0e30(iVar3, *(undefined8 *)(iVar2 + 0x3c0)),
       *(int32_t *)((int64_t)piVar4 + 0xc) == 6)) {
        return *piVar4;
    }
    return *(int64_t *)(iVar2 + 0x3d0 + (int64_t)iVar1 * 8);
}

// ============================================================
// Function: FUN_1800a3c4b
// Address: 0x1800a3c4b
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800a3b90(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    iVar1 = *(int32_t *)(arg2 + 0xc);
    if (iVar1 == 9) {
        arg2 = *(int64_t *)arg2;
        if ((*(char *)(arg2 + 3) != -0x7f) && (arg2 + 8 + *(int64_t *)(arg2 + 8) != 0)) {
            iVar2 = *(int64_t *)(arg1 + 0x20);
            piVar4 = (int64_t *)fcn.1800a0e30(*(int64_t *)(arg2 + 8) + arg2 + 8, *(undefined8 *)(iVar2 + 0x3c0));
            if (*(int32_t *)((int64_t)piVar4 + 0xc) != 6) {
                return *(int64_t *)(iVar2 + 0x418);
            }
            return *piVar4;
        }
    } else if (((iVar1 == 2) && (*(uint32_t *)(arg2 + 8) < 0x80)) &&
              (iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x3c30 + (int64_t)(int32_t)*(uint32_t *)(arg2 + 8) * 8),
              iVar2 != 0)) {
        return iVar2;
    }
    iVar2 = *(int64_t *)(arg1 + 0x20);
    iVar3 = *(int64_t *)(iVar2 + 0x440 + (int64_t)iVar1 * 8);
    if ((iVar3 != 0) &&
       (piVar4 = (int64_t *)fcn.1800a0e30(iVar3, *(undefined8 *)(iVar2 + 0x3c0)),
       *(int32_t *)((int64_t)piVar4 + 0xc) == 6)) {
        return *piVar4;
    }
    return *(int64_t *)(iVar2 + 0x3d0 + (int64_t)iVar1 * 8);
}

// ============================================================
// Function: FUN_1800a3c58
// Address: 0x1800a3c58
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800a3b90(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    iVar1 = *(int32_t *)(arg2 + 0xc);
    if (iVar1 == 9) {
        arg2 = *(int64_t *)arg2;
        if ((*(char *)(arg2 + 3) != -0x7f) && (arg2 + 8 + *(int64_t *)(arg2 + 8) != 0)) {
            iVar2 = *(int64_t *)(arg1 + 0x20);
            piVar4 = (int64_t *)fcn.1800a0e30(*(int64_t *)(arg2 + 8) + arg2 + 8, *(undefined8 *)(iVar2 + 0x3c0));
            if (*(int32_t *)((int64_t)piVar4 + 0xc) != 6) {
                return *(int64_t *)(iVar2 + 0x418);
            }
            return *piVar4;
        }
    } else if (((iVar1 == 2) && (*(uint32_t *)(arg2 + 8) < 0x80)) &&
              (iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x3c30 + (int64_t)(int32_t)*(uint32_t *)(arg2 + 8) * 8),
              iVar2 != 0)) {
        return iVar2;
    }
    iVar2 = *(int64_t *)(arg1 + 0x20);
    iVar3 = *(int64_t *)(iVar2 + 0x440 + (int64_t)iVar1 * 8);
    if ((iVar3 != 0) &&
       (piVar4 = (int64_t *)fcn.1800a0e30(iVar3, *(undefined8 *)(iVar2 + 0x3c0)),
       *(int32_t *)((int64_t)piVar4 + 0xc) == 6)) {
        return *piVar4;
    }
    return *(int64_t *)(iVar2 + 0x3d0 + (int64_t)iVar1 * 8);
}

// ============================================================
// Function: FUN_1800a3c60
// Address: 0x1800a3c60
// Size: 18 bytes
// ============================================================
int64_t fcn.1800a3c60(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    
    iVar1 = fcn.1800a3b90(arg1, arg2);
    return iVar1 + 0x18;
}

// ============================================================
// Function: FUN_1800a3c80
// Address: 0x1800a3c80
// Size: 125 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800a3c80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    code *pcVar2;
    undefined *puVar3;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    if ((uint64_t)arg2 < 0x7fffffe8) {
        uVar4 = arg2;
        if (0x10 < (uint64_t)arg2) {
            uVar4 = arg2 + 0xfU & 0xfffffffffffffff0;
        }
        puVar3 = (undefined *)fcn.180098710(arg1, uVar4 + 0x10, *(undefined *)(arg1 + 4));
        uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
        puVar3[2] = 9;
        puVar3[1] = uVar1 & 3;
        *puVar3 = *(undefined *)(arg1 + 4);
        *(int32_t *)(puVar3 + 4) = (int32_t)arg2;
        puVar3[3] = (char)arg3;
        *(int64_t *)(puVar3 + 8) = -(int64_t)(puVar3 + 8);
        return;
    }
    fcn.180098420();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800a3d00
// Address: 0x1800a3d00
// Size: 155 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800a3d00(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint8_t *puVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar13 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a3f6f;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar12;
        if (piVar13 <= piVar12) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar7 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a3f6f:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    uVar8 = *(uint32_t *)(*piVar7 + 0x14);
    uVar10 = (uint64_t)uVar8;
    piVar7 = piVar12 + 2;
    if (piVar13 <= piVar12 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar4 = 1;
    } else {
        iVar4 = func_0x000180088860(arg1, 2);
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        if (iVar4 < 0) {
            if ((uint64_t)-(int64_t)iVar4 < uVar10 || -uVar10 == (int64_t)iVar4) {
                iVar4 = iVar4 + 1 + uVar8;
            } else {
                iVar4 = 0;
            }
        }
    }
    piVar7 = piVar12 + 4;
    if (piVar13 <= piVar12 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar5 = -1;
    } else {
        iVar5 = func_0x000180088860(arg1, 3);
        if (-1 < iVar5) goto code_r0x0001800a3e3f;
    }
    if ((uint64_t)-(int64_t)iVar5 < uVar10 || -uVar10 == (int64_t)iVar5) {
        iVar5 = iVar5 + 1 + uVar8;
    } else {
        iVar5 = 0;
    }
code_r0x0001800a3e3f:
    if ((iVar4 < 1) || (iVar4 = iVar4 + -1, (int32_t)uVar8 < iVar4)) {
        func_0x000180088380(arg1, 2, 0x18063e9c8);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    if ((int32_t)uVar8 <= iVar5 + -1) {
        func_0x000180088380(arg1, 3, 0x18063ed58);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    iVar16 = 0;
    while( true ) {
        if (iVar5 + -1 < iVar4) {
            func_0x0001800865e0(arg1, iVar16);
            return 1;
        }
        puVar14 = (uint8_t *)(iVar4 + iVar1);
        uVar2 = *puVar14;
        uVar8 = (uint32_t)uVar2;
        if (0x7f < uVar2) {
            uVar15 = 0;
            iVar11 = 0;
            uVar9 = (uint32_t)uVar2;
            if ((uVar2 & 0x40) != 0) {
                do {
                    iVar11 = iVar11 + 1;
                    if ((puVar14[iVar11] & 0xc0) != 0x80) goto code_r0x0001800a3f40;
                    uVar15 = puVar14[iVar11] & 0x3f | uVar15 << 6;
                    uVar8 = uVar9 * 2;
                    uVar9 = uVar8;
                } while ((uVar8 & 0x40) != 0);
                if (3 < iVar11) break;
            }
            uVar15 = (uVar8 & 0x7f) << ((char)iVar11 * '\x05' & 0x1fU) | uVar15;
            if (((0x10ffff < uVar15) || (uVar15 <= *(uint32_t *)((int64_t)iVar11 * 4 + 0x18063eda0))) ||
               (uVar15 - 0xd800 < 0x800)) break;
            puVar14 = puVar14 + iVar11;
        }
        if (puVar14 + 1 == (uint8_t *)0x0) break;
        iVar16 = iVar16 + 1;
        iVar4 = (int32_t)(puVar14 + 1) - (int32_t)iVar1;
    }
code_r0x0001800a3f40:
    func_0x000180086510(arg1);
    func_0x0001800865e0(arg1, iVar4 + 1);
    return 2;
}

// ============================================================
// Function: FUN_1800a3d9b
// Address: 0x1800a3d9b
// Size: 421 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800a3d00(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint8_t *puVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar13 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a3f6f;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar12;
        if (piVar13 <= piVar12) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar7 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a3f6f:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    uVar8 = *(uint32_t *)(*piVar7 + 0x14);
    uVar10 = (uint64_t)uVar8;
    piVar7 = piVar12 + 2;
    if (piVar13 <= piVar12 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar4 = 1;
    } else {
        iVar4 = func_0x000180088860(arg1, 2);
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        if (iVar4 < 0) {
            if ((uint64_t)-(int64_t)iVar4 < uVar10 || -uVar10 == (int64_t)iVar4) {
                iVar4 = iVar4 + 1 + uVar8;
            } else {
                iVar4 = 0;
            }
        }
    }
    piVar7 = piVar12 + 4;
    if (piVar13 <= piVar12 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar5 = -1;
    } else {
        iVar5 = func_0x000180088860(arg1, 3);
        if (-1 < iVar5) goto code_r0x0001800a3e3f;
    }
    if ((uint64_t)-(int64_t)iVar5 < uVar10 || -uVar10 == (int64_t)iVar5) {
        iVar5 = iVar5 + 1 + uVar8;
    } else {
        iVar5 = 0;
    }
code_r0x0001800a3e3f:
    if ((iVar4 < 1) || (iVar4 = iVar4 + -1, (int32_t)uVar8 < iVar4)) {
        func_0x000180088380(arg1, 2, 0x18063e9c8);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    if ((int32_t)uVar8 <= iVar5 + -1) {
        func_0x000180088380(arg1, 3, 0x18063ed58);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    iVar16 = 0;
    while( true ) {
        if (iVar5 + -1 < iVar4) {
            func_0x0001800865e0(arg1, iVar16);
            return 1;
        }
        puVar14 = (uint8_t *)(iVar4 + iVar1);
        uVar2 = *puVar14;
        uVar8 = (uint32_t)uVar2;
        if (0x7f < uVar2) {
            uVar15 = 0;
            iVar11 = 0;
            uVar9 = (uint32_t)uVar2;
            if ((uVar2 & 0x40) != 0) {
                do {
                    iVar11 = iVar11 + 1;
                    if ((puVar14[iVar11] & 0xc0) != 0x80) goto code_r0x0001800a3f40;
                    uVar15 = puVar14[iVar11] & 0x3f | uVar15 << 6;
                    uVar8 = uVar9 * 2;
                    uVar9 = uVar8;
                } while ((uVar8 & 0x40) != 0);
                if (3 < iVar11) break;
            }
            uVar15 = (uVar8 & 0x7f) << ((char)iVar11 * '\x05' & 0x1fU) | uVar15;
            if (((0x10ffff < uVar15) || (uVar15 <= *(uint32_t *)((int64_t)iVar11 * 4 + 0x18063eda0))) ||
               (uVar15 - 0xd800 < 0x800)) break;
            puVar14 = puVar14 + iVar11;
        }
        if (puVar14 + 1 == (uint8_t *)0x0) break;
        iVar16 = iVar16 + 1;
        iVar4 = (int32_t)(puVar14 + 1) - (int32_t)iVar1;
    }
code_r0x0001800a3f40:
    func_0x000180086510(arg1);
    func_0x0001800865e0(arg1, iVar4 + 1);
    return 2;
}

// ============================================================
// Function: FUN_1800a3f40
// Address: 0x1800a3f40
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800a3d00(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint8_t *puVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar13 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a3f6f;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar12;
        if (piVar13 <= piVar12) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar7 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a3f6f:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    uVar8 = *(uint32_t *)(*piVar7 + 0x14);
    uVar10 = (uint64_t)uVar8;
    piVar7 = piVar12 + 2;
    if (piVar13 <= piVar12 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar4 = 1;
    } else {
        iVar4 = func_0x000180088860(arg1, 2);
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        if (iVar4 < 0) {
            if ((uint64_t)-(int64_t)iVar4 < uVar10 || -uVar10 == (int64_t)iVar4) {
                iVar4 = iVar4 + 1 + uVar8;
            } else {
                iVar4 = 0;
            }
        }
    }
    piVar7 = piVar12 + 4;
    if (piVar13 <= piVar12 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar5 = -1;
    } else {
        iVar5 = func_0x000180088860(arg1, 3);
        if (-1 < iVar5) goto code_r0x0001800a3e3f;
    }
    if ((uint64_t)-(int64_t)iVar5 < uVar10 || -uVar10 == (int64_t)iVar5) {
        iVar5 = iVar5 + 1 + uVar8;
    } else {
        iVar5 = 0;
    }
code_r0x0001800a3e3f:
    if ((iVar4 < 1) || (iVar4 = iVar4 + -1, (int32_t)uVar8 < iVar4)) {
        func_0x000180088380(arg1, 2, 0x18063e9c8);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    if ((int32_t)uVar8 <= iVar5 + -1) {
        func_0x000180088380(arg1, 3, 0x18063ed58);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    iVar16 = 0;
    while( true ) {
        if (iVar5 + -1 < iVar4) {
            func_0x0001800865e0(arg1, iVar16);
            return 1;
        }
        puVar14 = (uint8_t *)(iVar4 + iVar1);
        uVar2 = *puVar14;
        uVar8 = (uint32_t)uVar2;
        if (0x7f < uVar2) {
            uVar15 = 0;
            iVar11 = 0;
            uVar9 = (uint32_t)uVar2;
            if ((uVar2 & 0x40) != 0) {
                do {
                    iVar11 = iVar11 + 1;
                    if ((puVar14[iVar11] & 0xc0) != 0x80) goto code_r0x0001800a3f40;
                    uVar15 = puVar14[iVar11] & 0x3f | uVar15 << 6;
                    uVar8 = uVar9 * 2;
                    uVar9 = uVar8;
                } while ((uVar8 & 0x40) != 0);
                if (3 < iVar11) break;
            }
            uVar15 = (uVar8 & 0x7f) << ((char)iVar11 * '\x05' & 0x1fU) | uVar15;
            if (((0x10ffff < uVar15) || (uVar15 <= *(uint32_t *)((int64_t)iVar11 * 4 + 0x18063eda0))) ||
               (uVar15 - 0xd800 < 0x800)) break;
            puVar14 = puVar14 + iVar11;
        }
        if (puVar14 + 1 == (uint8_t *)0x0) break;
        iVar16 = iVar16 + 1;
        iVar4 = (int32_t)(puVar14 + 1) - (int32_t)iVar1;
    }
code_r0x0001800a3f40:
    func_0x000180086510(arg1);
    func_0x0001800865e0(arg1, iVar4 + 1);
    return 2;
}

// ============================================================
// Function: FUN_1800a3f5a
// Address: 0x1800a3f5a
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800a3d00(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint8_t *puVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar13 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a3f6f;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar12;
        if (piVar13 <= piVar12) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar7 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a3f6f:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    uVar8 = *(uint32_t *)(*piVar7 + 0x14);
    uVar10 = (uint64_t)uVar8;
    piVar7 = piVar12 + 2;
    if (piVar13 <= piVar12 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar4 = 1;
    } else {
        iVar4 = func_0x000180088860(arg1, 2);
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        if (iVar4 < 0) {
            if ((uint64_t)-(int64_t)iVar4 < uVar10 || -uVar10 == (int64_t)iVar4) {
                iVar4 = iVar4 + 1 + uVar8;
            } else {
                iVar4 = 0;
            }
        }
    }
    piVar7 = piVar12 + 4;
    if (piVar13 <= piVar12 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar5 = -1;
    } else {
        iVar5 = func_0x000180088860(arg1, 3);
        if (-1 < iVar5) goto code_r0x0001800a3e3f;
    }
    if ((uint64_t)-(int64_t)iVar5 < uVar10 || -uVar10 == (int64_t)iVar5) {
        iVar5 = iVar5 + 1 + uVar8;
    } else {
        iVar5 = 0;
    }
code_r0x0001800a3e3f:
    if ((iVar4 < 1) || (iVar4 = iVar4 + -1, (int32_t)uVar8 < iVar4)) {
        func_0x000180088380(arg1, 2, 0x18063e9c8);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    if ((int32_t)uVar8 <= iVar5 + -1) {
        func_0x000180088380(arg1, 3, 0x18063ed58);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    iVar16 = 0;
    while( true ) {
        if (iVar5 + -1 < iVar4) {
            func_0x0001800865e0(arg1, iVar16);
            return 1;
        }
        puVar14 = (uint8_t *)(iVar4 + iVar1);
        uVar2 = *puVar14;
        uVar8 = (uint32_t)uVar2;
        if (0x7f < uVar2) {
            uVar15 = 0;
            iVar11 = 0;
            uVar9 = (uint32_t)uVar2;
            if ((uVar2 & 0x40) != 0) {
                do {
                    iVar11 = iVar11 + 1;
                    if ((puVar14[iVar11] & 0xc0) != 0x80) goto code_r0x0001800a3f40;
                    uVar15 = puVar14[iVar11] & 0x3f | uVar15 << 6;
                    uVar8 = uVar9 * 2;
                    uVar9 = uVar8;
                } while ((uVar8 & 0x40) != 0);
                if (3 < iVar11) break;
            }
            uVar15 = (uVar8 & 0x7f) << ((char)iVar11 * '\x05' & 0x1fU) | uVar15;
            if (((0x10ffff < uVar15) || (uVar15 <= *(uint32_t *)((int64_t)iVar11 * 4 + 0x18063eda0))) ||
               (uVar15 - 0xd800 < 0x800)) break;
            puVar14 = puVar14 + iVar11;
        }
        if (puVar14 + 1 == (uint8_t *)0x0) break;
        iVar16 = iVar16 + 1;
        iVar4 = (int32_t)(puVar14 + 1) - (int32_t)iVar1;
    }
code_r0x0001800a3f40:
    func_0x000180086510(arg1);
    func_0x0001800865e0(arg1, iVar4 + 1);
    return 2;
}

// ============================================================
// Function: FUN_1800a3f6f
// Address: 0x1800a3f6f
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800a3d00(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint8_t *puVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar13 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a3f6f;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar12;
        if (piVar13 <= piVar12) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar7 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a3f6f:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    uVar8 = *(uint32_t *)(*piVar7 + 0x14);
    uVar10 = (uint64_t)uVar8;
    piVar7 = piVar12 + 2;
    if (piVar13 <= piVar12 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar4 = 1;
    } else {
        iVar4 = func_0x000180088860(arg1, 2);
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        if (iVar4 < 0) {
            if ((uint64_t)-(int64_t)iVar4 < uVar10 || -uVar10 == (int64_t)iVar4) {
                iVar4 = iVar4 + 1 + uVar8;
            } else {
                iVar4 = 0;
            }
        }
    }
    piVar7 = piVar12 + 4;
    if (piVar13 <= piVar12 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar5 = -1;
    } else {
        iVar5 = func_0x000180088860(arg1, 3);
        if (-1 < iVar5) goto code_r0x0001800a3e3f;
    }
    if ((uint64_t)-(int64_t)iVar5 < uVar10 || -uVar10 == (int64_t)iVar5) {
        iVar5 = iVar5 + 1 + uVar8;
    } else {
        iVar5 = 0;
    }
code_r0x0001800a3e3f:
    if ((iVar4 < 1) || (iVar4 = iVar4 + -1, (int32_t)uVar8 < iVar4)) {
        func_0x000180088380(arg1, 2, 0x18063e9c8);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    if ((int32_t)uVar8 <= iVar5 + -1) {
        func_0x000180088380(arg1, 3, 0x18063ed58);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    iVar16 = 0;
    while( true ) {
        if (iVar5 + -1 < iVar4) {
            func_0x0001800865e0(arg1, iVar16);
            return 1;
        }
        puVar14 = (uint8_t *)(iVar4 + iVar1);
        uVar2 = *puVar14;
        uVar8 = (uint32_t)uVar2;
        if (0x7f < uVar2) {
            uVar15 = 0;
            iVar11 = 0;
            uVar9 = (uint32_t)uVar2;
            if ((uVar2 & 0x40) != 0) {
                do {
                    iVar11 = iVar11 + 1;
                    if ((puVar14[iVar11] & 0xc0) != 0x80) goto code_r0x0001800a3f40;
                    uVar15 = puVar14[iVar11] & 0x3f | uVar15 << 6;
                    uVar8 = uVar9 * 2;
                    uVar9 = uVar8;
                } while ((uVar8 & 0x40) != 0);
                if (3 < iVar11) break;
            }
            uVar15 = (uVar8 & 0x7f) << ((char)iVar11 * '\x05' & 0x1fU) | uVar15;
            if (((0x10ffff < uVar15) || (uVar15 <= *(uint32_t *)((int64_t)iVar11 * 4 + 0x18063eda0))) ||
               (uVar15 - 0xd800 < 0x800)) break;
            puVar14 = puVar14 + iVar11;
        }
        if (puVar14 + 1 == (uint8_t *)0x0) break;
        iVar16 = iVar16 + 1;
        iVar4 = (int32_t)(puVar14 + 1) - (int32_t)iVar1;
    }
code_r0x0001800a3f40:
    func_0x000180086510(arg1);
    func_0x0001800865e0(arg1, iVar4 + 1);
    return 2;
}

// ============================================================
// Function: FUN_1800a3f83
// Address: 0x1800a3f83
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800a3d00(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint8_t *puVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar12;
    if (piVar13 <= piVar12) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a3f6f;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar12;
        if (piVar13 <= piVar12) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar7 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a3f6f:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    uVar8 = *(uint32_t *)(*piVar7 + 0x14);
    uVar10 = (uint64_t)uVar8;
    piVar7 = piVar12 + 2;
    if (piVar13 <= piVar12 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar4 = 1;
    } else {
        iVar4 = func_0x000180088860(arg1, 2);
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        if (iVar4 < 0) {
            if ((uint64_t)-(int64_t)iVar4 < uVar10 || -uVar10 == (int64_t)iVar4) {
                iVar4 = iVar4 + 1 + uVar8;
            } else {
                iVar4 = 0;
            }
        }
    }
    piVar7 = piVar12 + 4;
    if (piVar13 <= piVar12 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar5 = -1;
    } else {
        iVar5 = func_0x000180088860(arg1, 3);
        if (-1 < iVar5) goto code_r0x0001800a3e3f;
    }
    if ((uint64_t)-(int64_t)iVar5 < uVar10 || -uVar10 == (int64_t)iVar5) {
        iVar5 = iVar5 + 1 + uVar8;
    } else {
        iVar5 = 0;
    }
code_r0x0001800a3e3f:
    if ((iVar4 < 1) || (iVar4 = iVar4 + -1, (int32_t)uVar8 < iVar4)) {
        func_0x000180088380(arg1, 2, 0x18063e9c8);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    if ((int32_t)uVar8 <= iVar5 + -1) {
        func_0x000180088380(arg1, 3, 0x18063ed58);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    iVar16 = 0;
    while( true ) {
        if (iVar5 + -1 < iVar4) {
            func_0x0001800865e0(arg1, iVar16);
            return 1;
        }
        puVar14 = (uint8_t *)(iVar4 + iVar1);
        uVar2 = *puVar14;
        uVar8 = (uint32_t)uVar2;
        if (0x7f < uVar2) {
            uVar15 = 0;
            iVar11 = 0;
            uVar9 = (uint32_t)uVar2;
            if ((uVar2 & 0x40) != 0) {
                do {
                    iVar11 = iVar11 + 1;
                    if ((puVar14[iVar11] & 0xc0) != 0x80) goto code_r0x0001800a3f40;
                    uVar15 = puVar14[iVar11] & 0x3f | uVar15 << 6;
                    uVar8 = uVar9 * 2;
                    uVar9 = uVar8;
                } while ((uVar8 & 0x40) != 0);
                if (3 < iVar11) break;
            }
            uVar15 = (uVar8 & 0x7f) << ((char)iVar11 * '\x05' & 0x1fU) | uVar15;
            if (((0x10ffff < uVar15) || (uVar15 <= *(uint32_t *)((int64_t)iVar11 * 4 + 0x18063eda0))) ||
               (uVar15 - 0xd800 < 0x800)) break;
            puVar14 = puVar14 + iVar11;
        }
        if (puVar14 + 1 == (uint8_t *)0x0) break;
        iVar16 = iVar16 + 1;
        iVar4 = (int32_t)(puVar14 + 1) - (int32_t)iVar1;
    }
code_r0x0001800a3f40:
    func_0x000180086510(arg1);
    func_0x0001800865e0(arg1, iVar4 + 1);
    return 2;
}

// ============================================================
// Function: FUN_1800a3fa0
// Address: 0x1800a3fa0
// Size: 161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800a3fa0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    uint32_t uVar9;
    uint8_t *puVar11;
    uint32_t uVar12;
    int64_t *piVar13;
    uint32_t uVar14;
    int64_t *piVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint32_t uVar10;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar13;
    if (piVar15 <= piVar13) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a421c;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar8 = piVar13;
        if (piVar15 <= piVar13) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar8 + 0x18;
    if (iVar1 != 0) {
        uVar12 = *(uint32_t *)(*piVar8 + 0x14);
        uVar7 = (uint64_t)uVar12;
        piVar8 = piVar13 + 2;
        if (piVar15 <= piVar13 + 2) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
            iVar4 = 1;
        } else {
            iVar4 = func_0x000180088860(arg1, 2);
            piVar13 = *(int64_t **)(arg1 + 0x28);
            piVar15 = *(int64_t **)(arg1 + 0x40);
            if (iVar4 < 0) {
                if ((uint64_t)-(int64_t)iVar4 < uVar7 || -uVar7 == (int64_t)iVar4) {
                    iVar4 = iVar4 + 1 + uVar12;
                } else {
                    iVar4 = 0;
                }
            }
        }
        piVar8 = piVar13 + 4;
        if (piVar15 <= piVar13 + 4) {
            piVar8 = *(int64_t **)0x180782430;
        }
        iVar5 = iVar4;
        if ((piVar8 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar8 + 0xc))) {
            iVar5 = func_0x000180088860(arg1, 3);
        }
        if (iVar5 < 0) {
            if ((uint64_t)-(int64_t)iVar5 < uVar7 || -uVar7 == (int64_t)iVar5) {
                iVar5 = iVar5 + 1 + uVar12;
            } else {
                iVar5 = 0;
            }
        }
        if (iVar4 < 1) {
            func_0x000180088380(arg1, 2, 0x18063ed78);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        if ((int32_t)uVar12 < iVar5) {
            func_0x000180088380(arg1, 3, 0x18063ed78);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        if (iVar5 < iVar4) {
            uVar7 = 0;
        } else {
            if (0x7ffffffe < iVar5 - iVar4) {
                func_0x000180088560(arg1, 0x18063e570);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            iVar6 = func_0x000180085510(arg1, (iVar5 - iVar4) + 1);
            if (iVar6 == 0) {
                func_0x000180088560(arg1, 0x18063da38, 0x18063e570);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            uVar12 = 0;
            puVar11 = (uint8_t *)((iVar4 + -1) + iVar1);
            while (puVar11 < (uint8_t *)(iVar5 + iVar1)) {
                uVar2 = *puVar11;
                uVar9 = (uint32_t)uVar2;
                uVar10 = (uint32_t)uVar2;
                if (0x7f < uVar2) {
                    uVar14 = 0;
                    iVar4 = 0;
                    if ((uVar2 & 0x40) != 0) {
                        do {
                            iVar4 = iVar4 + 1;
                            if ((puVar11[iVar4] & 0xc0) != 0x80) goto code_r0x0001800a4254;
                            uVar14 = puVar11[iVar4] & 0x3f | uVar14 << 6;
                            uVar10 = uVar9 * 2;
                            uVar9 = uVar10;
                        } while ((uVar10 & 0x40) != 0);
                        if (3 < iVar4) goto code_r0x0001800a4254;
                    }
                    uVar14 = (uVar10 & 0x7f) << ((char)iVar4 * '\x05' & 0x1fU) | uVar14;
                    if (((0x10ffff < uVar14) || (uVar14 <= *(uint32_t *)((int64_t)iVar4 * 4 + 0x18063eda0))) ||
                       (uVar14 - 0xd800 < 0x800)) goto code_r0x0001800a4254;
                    puVar11 = puVar11 + iVar4;
                }
                puVar11 = puVar11 + 1;
                if (puVar11 == (uint8_t *)0x0) {
code_r0x0001800a4254:
                    func_0x000180088560(arg1, 0x18063ed88);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                func_0x0001800865e0(arg1);
                uVar12 = uVar12 + 1;
            }
            uVar7 = (uint64_t)uVar12;
        }
        return uVar7;
    }
code_r0x0001800a421c:
    func_0x000180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a4041
// Address: 0x1800a4041
// Size: 211 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800a3fa0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    uint32_t uVar9;
    uint8_t *puVar11;
    uint32_t uVar12;
    int64_t *piVar13;
    uint32_t uVar14;
    int64_t *piVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint32_t uVar10;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar13;
    if (piVar15 <= piVar13) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a421c;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar8 = piVar13;
        if (piVar15 <= piVar13) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar8 + 0x18;
    if (iVar1 != 0) {
        uVar12 = *(uint32_t *)(*piVar8 + 0x14);
        uVar7 = (uint64_t)uVar12;
        piVar8 = piVar13 + 2;
        if (piVar15 <= piVar13 + 2) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
            iVar4 = 1;
        } else {
            iVar4 = func_0x000180088860(arg1, 2);
            piVar13 = *(int64_t **)(arg1 + 0x28);
            piVar15 = *(int64_t **)(arg1 + 0x40);
            if (iVar4 < 0) {
                if ((uint64_t)-(int64_t)iVar4 < uVar7 || -uVar7 == (int64_t)iVar4) {
                    iVar4 = iVar4 + 1 + uVar12;
                } else {
                    iVar4 = 0;
                }
            }
        }
        piVar8 = piVar13 + 4;
        if (piVar15 <= piVar13 + 4) {
            piVar8 = *(int64_t **)0x180782430;
        }
        iVar5 = iVar4;
        if ((piVar8 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar8 + 0xc))) {
            iVar5 = func_0x000180088860(arg1, 3);
        }
        if (iVar5 < 0) {
            if ((uint64_t)-(int64_t)iVar5 < uVar7 || -uVar7 == (int64_t)iVar5) {
                iVar5 = iVar5 + 1 + uVar12;
            } else {
                iVar5 = 0;
            }
        }
        if (iVar4 < 1) {
            func_0x000180088380(arg1, 2, 0x18063ed78);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        if ((int32_t)uVar12 < iVar5) {
            func_0x000180088380(arg1, 3, 0x18063ed78);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        if (iVar5 < iVar4) {
            uVar7 = 0;
        } else {
            if (0x7ffffffe < iVar5 - iVar4) {
                func_0x000180088560(arg1, 0x18063e570);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            iVar6 = func_0x000180085510(arg1, (iVar5 - iVar4) + 1);
            if (iVar6 == 0) {
                func_0x000180088560(arg1, 0x18063da38, 0x18063e570);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            uVar12 = 0;
            puVar11 = (uint8_t *)((iVar4 + -1) + iVar1);
            while (puVar11 < (uint8_t *)(iVar5 + iVar1)) {
                uVar2 = *puVar11;
                uVar9 = (uint32_t)uVar2;
                uVar10 = (uint32_t)uVar2;
                if (0x7f < uVar2) {
                    uVar14 = 0;
                    iVar4 = 0;
                    if ((uVar2 & 0x40) != 0) {
                        do {
                            iVar4 = iVar4 + 1;
                            if ((puVar11[iVar4] & 0xc0) != 0x80) goto code_r0x0001800a4254;
                            uVar14 = puVar11[iVar4] & 0x3f | uVar14 << 6;
                            uVar10 = uVar9 * 2;
                            uVar9 = uVar10;
                        } while ((uVar10 & 0x40) != 0);
                        if (3 < iVar4) goto code_r0x0001800a4254;
                    }
                    uVar14 = (uVar10 & 0x7f) << ((char)iVar4 * '\x05' & 0x1fU) | uVar14;
                    if (((0x10ffff < uVar14) || (uVar14 <= *(uint32_t *)((int64_t)iVar4 * 4 + 0x18063eda0))) ||
                       (uVar14 - 0xd800 < 0x800)) goto code_r0x0001800a4254;
                    puVar11 = puVar11 + iVar4;
                }
                puVar11 = puVar11 + 1;
                if (puVar11 == (uint8_t *)0x0) {
code_r0x0001800a4254:
                    func_0x000180088560(arg1, 0x18063ed88);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                func_0x0001800865e0(arg1);
                uVar12 = uVar12 + 1;
            }
            uVar7 = (uint64_t)uVar12;
        }
        return uVar7;
    }
code_r0x0001800a421c:
    func_0x000180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a4114
// Address: 0x1800a4114
// Size: 264 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800a3fa0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    uint32_t uVar9;
    uint8_t *puVar11;
    uint32_t uVar12;
    int64_t *piVar13;
    uint32_t uVar14;
    int64_t *piVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint32_t uVar10;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar13;
    if (piVar15 <= piVar13) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a421c;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar8 = piVar13;
        if (piVar15 <= piVar13) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar8 + 0x18;
    if (iVar1 != 0) {
        uVar12 = *(uint32_t *)(*piVar8 + 0x14);
        uVar7 = (uint64_t)uVar12;
        piVar8 = piVar13 + 2;
        if (piVar15 <= piVar13 + 2) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
            iVar4 = 1;
        } else {
            iVar4 = func_0x000180088860(arg1, 2);
            piVar13 = *(int64_t **)(arg1 + 0x28);
            piVar15 = *(int64_t **)(arg1 + 0x40);
            if (iVar4 < 0) {
                if ((uint64_t)-(int64_t)iVar4 < uVar7 || -uVar7 == (int64_t)iVar4) {
                    iVar4 = iVar4 + 1 + uVar12;
                } else {
                    iVar4 = 0;
                }
            }
        }
        piVar8 = piVar13 + 4;
        if (piVar15 <= piVar13 + 4) {
            piVar8 = *(int64_t **)0x180782430;
        }
        iVar5 = iVar4;
        if ((piVar8 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar8 + 0xc))) {
            iVar5 = func_0x000180088860(arg1, 3);
        }
        if (iVar5 < 0) {
            if ((uint64_t)-(int64_t)iVar5 < uVar7 || -uVar7 == (int64_t)iVar5) {
                iVar5 = iVar5 + 1 + uVar12;
            } else {
                iVar5 = 0;
            }
        }
        if (iVar4 < 1) {
            func_0x000180088380(arg1, 2, 0x18063ed78);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        if ((int32_t)uVar12 < iVar5) {
            func_0x000180088380(arg1, 3, 0x18063ed78);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        if (iVar5 < iVar4) {
            uVar7 = 0;
        } else {
            if (0x7ffffffe < iVar5 - iVar4) {
                func_0x000180088560(arg1, 0x18063e570);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            iVar6 = func_0x000180085510(arg1, (iVar5 - iVar4) + 1);
            if (iVar6 == 0) {
                func_0x000180088560(arg1, 0x18063da38, 0x18063e570);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            uVar12 = 0;
            puVar11 = (uint8_t *)((iVar4 + -1) + iVar1);
            while (puVar11 < (uint8_t *)(iVar5 + iVar1)) {
                uVar2 = *puVar11;
                uVar9 = (uint32_t)uVar2;
                uVar10 = (uint32_t)uVar2;
                if (0x7f < uVar2) {
                    uVar14 = 0;
                    iVar4 = 0;
                    if ((uVar2 & 0x40) != 0) {
                        do {
                            iVar4 = iVar4 + 1;
                            if ((puVar11[iVar4] & 0xc0) != 0x80) goto code_r0x0001800a4254;
                            uVar14 = puVar11[iVar4] & 0x3f | uVar14 << 6;
                            uVar10 = uVar9 * 2;
                            uVar9 = uVar10;
                        } while ((uVar10 & 0x40) != 0);
                        if (3 < iVar4) goto code_r0x0001800a4254;
                    }
                    uVar14 = (uVar10 & 0x7f) << ((char)iVar4 * '\x05' & 0x1fU) | uVar14;
                    if (((0x10ffff < uVar14) || (uVar14 <= *(uint32_t *)((int64_t)iVar4 * 4 + 0x18063eda0))) ||
                       (uVar14 - 0xd800 < 0x800)) goto code_r0x0001800a4254;
                    puVar11 = puVar11 + iVar4;
                }
                puVar11 = puVar11 + 1;
                if (puVar11 == (uint8_t *)0x0) {
code_r0x0001800a4254:
                    func_0x000180088560(arg1, 0x18063ed88);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                func_0x0001800865e0(arg1);
                uVar12 = uVar12 + 1;
            }
            uVar7 = (uint64_t)uVar12;
        }
        return uVar7;
    }
code_r0x0001800a421c:
    func_0x000180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a421c
// Address: 0x1800a421c
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800a3fa0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    uint32_t uVar9;
    uint8_t *puVar11;
    uint32_t uVar12;
    int64_t *piVar13;
    uint32_t uVar14;
    int64_t *piVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint32_t uVar10;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar13;
    if (piVar15 <= piVar13) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a421c;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar8 = piVar13;
        if (piVar15 <= piVar13) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar8 + 0x18;
    if (iVar1 != 0) {
        uVar12 = *(uint32_t *)(*piVar8 + 0x14);
        uVar7 = (uint64_t)uVar12;
        piVar8 = piVar13 + 2;
        if (piVar15 <= piVar13 + 2) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
            iVar4 = 1;
        } else {
            iVar4 = func_0x000180088860(arg1, 2);
            piVar13 = *(int64_t **)(arg1 + 0x28);
            piVar15 = *(int64_t **)(arg1 + 0x40);
            if (iVar4 < 0) {
                if ((uint64_t)-(int64_t)iVar4 < uVar7 || -uVar7 == (int64_t)iVar4) {
                    iVar4 = iVar4 + 1 + uVar12;
                } else {
                    iVar4 = 0;
                }
            }
        }
        piVar8 = piVar13 + 4;
        if (piVar15 <= piVar13 + 4) {
            piVar8 = *(int64_t **)0x180782430;
        }
        iVar5 = iVar4;
        if ((piVar8 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar8 + 0xc))) {
            iVar5 = func_0x000180088860(arg1, 3);
        }
        if (iVar5 < 0) {
            if ((uint64_t)-(int64_t)iVar5 < uVar7 || -uVar7 == (int64_t)iVar5) {
                iVar5 = iVar5 + 1 + uVar12;
            } else {
                iVar5 = 0;
            }
        }
        if (iVar4 < 1) {
            func_0x000180088380(arg1, 2, 0x18063ed78);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        if ((int32_t)uVar12 < iVar5) {
            func_0x000180088380(arg1, 3, 0x18063ed78);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        if (iVar5 < iVar4) {
            uVar7 = 0;
        } else {
            if (0x7ffffffe < iVar5 - iVar4) {
                func_0x000180088560(arg1, 0x18063e570);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            iVar6 = func_0x000180085510(arg1, (iVar5 - iVar4) + 1);
            if (iVar6 == 0) {
                func_0x000180088560(arg1, 0x18063da38, 0x18063e570);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            uVar12 = 0;
            puVar11 = (uint8_t *)((iVar4 + -1) + iVar1);
            while (puVar11 < (uint8_t *)(iVar5 + iVar1)) {
                uVar2 = *puVar11;
                uVar9 = (uint32_t)uVar2;
                uVar10 = (uint32_t)uVar2;
                if (0x7f < uVar2) {
                    uVar14 = 0;
                    iVar4 = 0;
                    if ((uVar2 & 0x40) != 0) {
                        do {
                            iVar4 = iVar4 + 1;
                            if ((puVar11[iVar4] & 0xc0) != 0x80) goto code_r0x0001800a4254;
                            uVar14 = puVar11[iVar4] & 0x3f | uVar14 << 6;
                            uVar10 = uVar9 * 2;
                            uVar9 = uVar10;
                        } while ((uVar10 & 0x40) != 0);
                        if (3 < iVar4) goto code_r0x0001800a4254;
                    }
                    uVar14 = (uVar10 & 0x7f) << ((char)iVar4 * '\x05' & 0x1fU) | uVar14;
                    if (((0x10ffff < uVar14) || (uVar14 <= *(uint32_t *)((int64_t)iVar4 * 4 + 0x18063eda0))) ||
                       (uVar14 - 0xd800 < 0x800)) goto code_r0x0001800a4254;
                    puVar11 = puVar11 + iVar4;
                }
                puVar11 = puVar11 + 1;
                if (puVar11 == (uint8_t *)0x0) {
code_r0x0001800a4254:
                    func_0x000180088560(arg1, 0x18063ed88);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                func_0x0001800865e0(arg1);
                uVar12 = uVar12 + 1;
            }
            uVar7 = (uint64_t)uVar12;
        }
        return uVar7;
    }
code_r0x0001800a421c:
    func_0x000180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a4230
// Address: 0x1800a4230
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800a3fa0(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    uint32_t uVar9;
    uint8_t *puVar11;
    uint32_t uVar12;
    int64_t *piVar13;
    uint32_t uVar14;
    int64_t *piVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint32_t uVar10;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar13;
    if (piVar15 <= piVar13) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a421c;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar8 = piVar13;
        if (piVar15 <= piVar13) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar8 + 0x18;
    if (iVar1 != 0) {
        uVar12 = *(uint32_t *)(*piVar8 + 0x14);
        uVar7 = (uint64_t)uVar12;
        piVar8 = piVar13 + 2;
        if (piVar15 <= piVar13 + 2) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
            iVar4 = 1;
        } else {
            iVar4 = func_0x000180088860(arg1, 2);
            piVar13 = *(int64_t **)(arg1 + 0x28);
            piVar15 = *(int64_t **)(arg1 + 0x40);
            if (iVar4 < 0) {
                if ((uint64_t)-(int64_t)iVar4 < uVar7 || -uVar7 == (int64_t)iVar4) {
                    iVar4 = iVar4 + 1 + uVar12;
                } else {
                    iVar4 = 0;
                }
            }
        }
        piVar8 = piVar13 + 4;
        if (piVar15 <= piVar13 + 4) {
            piVar8 = *(int64_t **)0x180782430;
        }
        iVar5 = iVar4;
        if ((piVar8 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar8 + 0xc))) {
            iVar5 = func_0x000180088860(arg1, 3);
        }
        if (iVar5 < 0) {
            if ((uint64_t)-(int64_t)iVar5 < uVar7 || -uVar7 == (int64_t)iVar5) {
                iVar5 = iVar5 + 1 + uVar12;
            } else {
                iVar5 = 0;
            }
        }
        if (iVar4 < 1) {
            func_0x000180088380(arg1, 2, 0x18063ed78);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        if ((int32_t)uVar12 < iVar5) {
            func_0x000180088380(arg1, 3, 0x18063ed78);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        if (iVar5 < iVar4) {
            uVar7 = 0;
        } else {
            if (0x7ffffffe < iVar5 - iVar4) {
                func_0x000180088560(arg1, 0x18063e570);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            iVar6 = func_0x000180085510(arg1, (iVar5 - iVar4) + 1);
            if (iVar6 == 0) {
                func_0x000180088560(arg1, 0x18063da38, 0x18063e570);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            uVar12 = 0;
            puVar11 = (uint8_t *)((iVar4 + -1) + iVar1);
            while (puVar11 < (uint8_t *)(iVar5 + iVar1)) {
                uVar2 = *puVar11;
                uVar9 = (uint32_t)uVar2;
                uVar10 = (uint32_t)uVar2;
                if (0x7f < uVar2) {
                    uVar14 = 0;
                    iVar4 = 0;
                    if ((uVar2 & 0x40) != 0) {
                        do {
                            iVar4 = iVar4 + 1;
                            if ((puVar11[iVar4] & 0xc0) != 0x80) goto code_r0x0001800a4254;
                            uVar14 = puVar11[iVar4] & 0x3f | uVar14 << 6;
                            uVar10 = uVar9 * 2;
                            uVar9 = uVar10;
                        } while ((uVar10 & 0x40) != 0);
                        if (3 < iVar4) goto code_r0x0001800a4254;
                    }
                    uVar14 = (uVar10 & 0x7f) << ((char)iVar4 * '\x05' & 0x1fU) | uVar14;
                    if (((0x10ffff < uVar14) || (uVar14 <= *(uint32_t *)((int64_t)iVar4 * 4 + 0x18063eda0))) ||
                       (uVar14 - 0xd800 < 0x800)) goto code_r0x0001800a4254;
                    puVar11 = puVar11 + iVar4;
                }
                puVar11 = puVar11 + 1;
                if (puVar11 == (uint8_t *)0x0) {
code_r0x0001800a4254:
                    func_0x000180088560(arg1, 0x18063ed88);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                func_0x0001800865e0(arg1);
                uVar12 = uVar12 + 1;
            }
            uVar7 = (uint64_t)uVar12;
        }
        return uVar7;
    }
code_r0x0001800a421c:
    func_0x000180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a4280
// Address: 0x1800a4280
// Size: 698 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800a4280(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint8_t uVar4;
    uint32_t uVar5;
    undefined8 uVar6;
    int32_t iVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    int32_t iVar10;
    uint32_t uVar11;
    int64_t iVar12;
    int32_t iVar13;
    uint64_t uVar14;
    int32_t iVar15;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_278 [32];
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_278;
    uVar14 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    iVar10 = (int32_t)uVar14;
    if (iVar10 == 1) {
        uVar5 = func_0x000180088860(arg1, uVar14 & 0xffffffff);
        uVar8 = (uint64_t)uVar5;
        if (0x10ffff < uVar5) {
            func_0x000180088380(arg1, 1, 0x18063ecf0);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar14 = uVar14 & 0xffffffff;
        if (uVar5 < 0x80) {
            iVar12 = 1;
            piVar9 = (int64_t *)((int64_t)&var_38h + 7);
            var_38h._7_1_ = (undefined)uVar5;
        } else {
            uVar5 = 0x3f;
            do {
                uVar5 = uVar5 >> 1;
                iVar10 = (int32_t)uVar14;
                uVar4 = (uint8_t)uVar8;
                uVar8 = uVar8 >> 6;
                uVar11 = iVar10 + 1;
                uVar14 = (uint64_t)uVar11;
                *(uint8_t *)((int64_t)&var_38h + (int64_t)(8 - iVar10)) = uVar4 & 0x3f | 0x80;
            } while (uVar5 < (uint32_t)uVar8);
            iVar12 = (int64_t)(int32_t)uVar11;
            piVar9 = (int64_t *)((int64_t)&var_30h - iVar12);
            *(uint8_t *)((int64_t)&var_38h + (int64_t)(int32_t)(8 - uVar11)) = ~(uint8_t)uVar5 * '\x02' | (uint8_t)uVar8
            ;
        }
    } else {
        iVar15 = 1;
        var_240h = 0;
        var_258h = (int64_t)&var_238h;
        var_250h = (int64_t)&var_38h;
        var_248h = arg1;
        if (0 < iVar10) {
            do {
                uVar14 = func_0x000180088860(arg1, iVar15);
                if (0x10ffff < (uint32_t)uVar14) {
                    func_0x000180088380(arg1, iVar15, 0x18063ecf0);
                    pcVar2 = (code *)swi(3);
                    (*pcVar2)();
                    return;
                }
                iVar13 = 1;
                if ((uint32_t)uVar14 < 0x80) {
                    var_38h._7_1_ = (undefined)uVar14;
                } else {
                    uVar5 = 0x3f;
                    do {
                        uVar5 = uVar5 >> 1;
                        iVar7 = 8 - iVar13;
                        uVar4 = (uint8_t)uVar14;
                        uVar14 = uVar14 >> 6 & 0x3ffffff;
                        iVar13 = iVar13 + 1;
                        *(uint8_t *)((int64_t)&var_38h + (int64_t)iVar7) = uVar4 & 0x3f | 0x80;
                    } while (uVar5 < (uint32_t)uVar14);
                    *(uint8_t *)((int64_t)&var_38h + (int64_t)(8 - iVar13)) = ~(uint8_t)uVar5 * '\x02' | (uint8_t)uVar14
                    ;
                }
                uVar14 = (uint64_t)iVar13;
                if ((uint64_t)(var_250h - var_258h) < uVar14) {
                    func_0x0001800890e0(&var_258h, (uVar14 - var_250h) + var_258h, 0xffffffff);
                }
                func_0x000180498030(var_258h, (int64_t)&var_30h - uVar14, uVar14);
                iVar15 = iVar15 + 1;
                var_258h = var_258h + uVar14;
            } while (iVar15 <= iVar10);
        }
        iVar3 = var_240h;
        iVar12 = var_248h;
        if (var_240h != 0) {
            if (*(uint64_t *)(*(int64_t *)(var_248h + 0x20) + 0x28) <=
                *(uint64_t *)(*(int64_t *)(var_248h + 0x20) + 0x30)) {
                (**(code **)0x180782658)(var_248h, 1);
            }
            iVar1 = *(int64_t *)(iVar12 + 0x40);
            if (var_258h == var_250h) {
                uVar6 = func_0x00018009a7e0(iVar12, iVar3);
                *(undefined8 *)(iVar1 + -0x10) = uVar6;
                *(undefined4 *)(iVar1 + -4) = 6;
            } else {
                uVar6 = func_0x00018009a8e0(iVar12, iVar3 + 0x18, (var_258h - iVar3) + -0x18);
                *(undefined8 *)(iVar1 + -0x10) = uVar6;
                *(undefined4 *)(iVar1 + -4) = 6;
            }
            goto code_r0x0001800a44e2;
        }
        piVar9 = &var_238h;
        iVar12 = var_258h + (-0x20 - (int64_t)&var_258h);
        arg1 = var_248h;
    }
    func_0x0001800867f0(arg1, piVar9, iVar12);
code_r0x0001800a44e2:
    func_0x000180459870(var_30h ^ (uint64_t)auStack_278);
    return;
}

// ============================================================
// Function: FUN_1800a4540
// Address: 0x1800a4540
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.1800a4540(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uVar10;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a472e;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a472e:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    uVar9 = *(uint32_t *)(*piVar6 + 0x14);
    iVar4 = func_0x000180088860(arg1, 2);
    iVar5 = 1;
    if (iVar4 < 0) {
        iVar5 = uVar9 + 1;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar6 + 0xc))) {
        iVar5 = func_0x000180088860(arg1, 3);
    }
    if (iVar5 < 0) {
        if ((uint64_t)uVar9 <= (uint64_t)-(int64_t)iVar5 && -(uint64_t)uVar9 != (int64_t)iVar5)
        goto code_r0x0001800a4719;
        iVar5 = iVar5 + 1 + uVar9;
    }
    if (0 < iVar5) {
        uVar8 = iVar5 - 1;
        uVar10 = (uint64_t)uVar8;
        if ((int32_t)uVar8 <= (int32_t)uVar9) {
            if (iVar4 == 0) {
                uVar11 = uVar10;
                if (0 < (int32_t)uVar8) {
                    while (uVar10 = uVar11, (*(uint8_t *)(uVar10 + iVar1) & 0xc0) == 0x80) {
                        uVar9 = (int32_t)uVar10 - 1;
                        uVar11 = (uint64_t)uVar9;
                        if ((int32_t)uVar9 < 1) {
                            func_0x0001800865e0(arg1, uVar10);
                            return 1;
                        }
                    }
                }
            } else {
                if ((*(uint8_t *)((int32_t)uVar8 + iVar1) & 0xc0) == 0x80) {
                    func_0x000180088560(arg1, 0x18063ed20);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                if (iVar4 < 0) {
                    do {
                        uVar11 = uVar10;
                        if ((int32_t)uVar10 < 1) goto code_r0x0001800a46f7;
                        do {
                            uVar9 = (int32_t)uVar11 - 1;
                            uVar10 = (uint64_t)uVar9;
                            if ((int32_t)uVar9 < 1) break;
                            iVar2 = uVar11 - 1;
                            uVar11 = uVar10;
                        } while ((*(uint8_t *)(iVar2 + iVar1) & 0xc0) == 0x80);
                        iVar4 = iVar4 + 1;
                    } while (iVar4 < 0);
                } else {
                    while (iVar4 = iVar4 + -1, 0 < iVar4) {
                        if ((int32_t)uVar9 <= (int32_t)uVar10) goto code_r0x0001800a46f7;
                        do {
                            uVar8 = (int32_t)uVar10 + 1;
                            uVar10 = (uint64_t)uVar8;
                        } while ((*(uint8_t *)((int32_t)uVar8 + iVar1) & 0xc0) == 0x80);
                    }
                }
                if (iVar4 != 0) {
code_r0x0001800a46f7:
                    func_0x000180086510(arg1);
                    return 1;
                }
            }
            func_0x0001800865e0(arg1, (int32_t)uVar10 + 1);
            return 1;
        }
    }
code_r0x0001800a4719:
    func_0x000180088380(arg1, 3, 0x18063ed08);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a45d9
// Address: 0x1800a45d9
// Size: 320 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.1800a4540(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uVar10;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a472e;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a472e:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    uVar9 = *(uint32_t *)(*piVar6 + 0x14);
    iVar4 = func_0x000180088860(arg1, 2);
    iVar5 = 1;
    if (iVar4 < 0) {
        iVar5 = uVar9 + 1;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar6 + 0xc))) {
        iVar5 = func_0x000180088860(arg1, 3);
    }
    if (iVar5 < 0) {
        if ((uint64_t)uVar9 <= (uint64_t)-(int64_t)iVar5 && -(uint64_t)uVar9 != (int64_t)iVar5)
        goto code_r0x0001800a4719;
        iVar5 = iVar5 + 1 + uVar9;
    }
    if (0 < iVar5) {
        uVar8 = iVar5 - 1;
        uVar10 = (uint64_t)uVar8;
        if ((int32_t)uVar8 <= (int32_t)uVar9) {
            if (iVar4 == 0) {
                uVar11 = uVar10;
                if (0 < (int32_t)uVar8) {
                    while (uVar10 = uVar11, (*(uint8_t *)(uVar10 + iVar1) & 0xc0) == 0x80) {
                        uVar9 = (int32_t)uVar10 - 1;
                        uVar11 = (uint64_t)uVar9;
                        if ((int32_t)uVar9 < 1) {
                            func_0x0001800865e0(arg1, uVar10);
                            return 1;
                        }
                    }
                }
            } else {
                if ((*(uint8_t *)((int32_t)uVar8 + iVar1) & 0xc0) == 0x80) {
                    func_0x000180088560(arg1, 0x18063ed20);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                if (iVar4 < 0) {
                    do {
                        uVar11 = uVar10;
                        if ((int32_t)uVar10 < 1) goto code_r0x0001800a46f7;
                        do {
                            uVar9 = (int32_t)uVar11 - 1;
                            uVar10 = (uint64_t)uVar9;
                            if ((int32_t)uVar9 < 1) break;
                            iVar2 = uVar11 - 1;
                            uVar11 = uVar10;
                        } while ((*(uint8_t *)(iVar2 + iVar1) & 0xc0) == 0x80);
                        iVar4 = iVar4 + 1;
                    } while (iVar4 < 0);
                } else {
                    while (iVar4 = iVar4 + -1, 0 < iVar4) {
                        if ((int32_t)uVar9 <= (int32_t)uVar10) goto code_r0x0001800a46f7;
                        do {
                            uVar8 = (int32_t)uVar10 + 1;
                            uVar10 = (uint64_t)uVar8;
                        } while ((*(uint8_t *)((int32_t)uVar8 + iVar1) & 0xc0) == 0x80);
                    }
                }
                if (iVar4 != 0) {
code_r0x0001800a46f7:
                    func_0x000180086510(arg1);
                    return 1;
                }
            }
            func_0x0001800865e0(arg1, (int32_t)uVar10 + 1);
            return 1;
        }
    }
code_r0x0001800a4719:
    func_0x000180088380(arg1, 3, 0x18063ed08);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a4719
// Address: 0x1800a4719
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.1800a4540(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uVar10;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a472e;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a472e:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    uVar9 = *(uint32_t *)(*piVar6 + 0x14);
    iVar4 = func_0x000180088860(arg1, 2);
    iVar5 = 1;
    if (iVar4 < 0) {
        iVar5 = uVar9 + 1;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar6 + 0xc))) {
        iVar5 = func_0x000180088860(arg1, 3);
    }
    if (iVar5 < 0) {
        if ((uint64_t)uVar9 <= (uint64_t)-(int64_t)iVar5 && -(uint64_t)uVar9 != (int64_t)iVar5)
        goto code_r0x0001800a4719;
        iVar5 = iVar5 + 1 + uVar9;
    }
    if (0 < iVar5) {
        uVar8 = iVar5 - 1;
        uVar10 = (uint64_t)uVar8;
        if ((int32_t)uVar8 <= (int32_t)uVar9) {
            if (iVar4 == 0) {
                uVar11 = uVar10;
                if (0 < (int32_t)uVar8) {
                    while (uVar10 = uVar11, (*(uint8_t *)(uVar10 + iVar1) & 0xc0) == 0x80) {
                        uVar9 = (int32_t)uVar10 - 1;
                        uVar11 = (uint64_t)uVar9;
                        if ((int32_t)uVar9 < 1) {
                            func_0x0001800865e0(arg1, uVar10);
                            return 1;
                        }
                    }
                }
            } else {
                if ((*(uint8_t *)((int32_t)uVar8 + iVar1) & 0xc0) == 0x80) {
                    func_0x000180088560(arg1, 0x18063ed20);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                if (iVar4 < 0) {
                    do {
                        uVar11 = uVar10;
                        if ((int32_t)uVar10 < 1) goto code_r0x0001800a46f7;
                        do {
                            uVar9 = (int32_t)uVar11 - 1;
                            uVar10 = (uint64_t)uVar9;
                            if ((int32_t)uVar9 < 1) break;
                            iVar2 = uVar11 - 1;
                            uVar11 = uVar10;
                        } while ((*(uint8_t *)(iVar2 + iVar1) & 0xc0) == 0x80);
                        iVar4 = iVar4 + 1;
                    } while (iVar4 < 0);
                } else {
                    while (iVar4 = iVar4 + -1, 0 < iVar4) {
                        if ((int32_t)uVar9 <= (int32_t)uVar10) goto code_r0x0001800a46f7;
                        do {
                            uVar8 = (int32_t)uVar10 + 1;
                            uVar10 = (uint64_t)uVar8;
                        } while ((*(uint8_t *)((int32_t)uVar8 + iVar1) & 0xc0) == 0x80);
                    }
                }
                if (iVar4 != 0) {
code_r0x0001800a46f7:
                    func_0x000180086510(arg1);
                    return 1;
                }
            }
            func_0x0001800865e0(arg1, (int32_t)uVar10 + 1);
            return 1;
        }
    }
code_r0x0001800a4719:
    func_0x000180088380(arg1, 3, 0x18063ed08);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a472e
// Address: 0x1800a472e
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.1800a4540(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uVar10;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a472e;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a472e:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    uVar9 = *(uint32_t *)(*piVar6 + 0x14);
    iVar4 = func_0x000180088860(arg1, 2);
    iVar5 = 1;
    if (iVar4 < 0) {
        iVar5 = uVar9 + 1;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar6 + 0xc))) {
        iVar5 = func_0x000180088860(arg1, 3);
    }
    if (iVar5 < 0) {
        if ((uint64_t)uVar9 <= (uint64_t)-(int64_t)iVar5 && -(uint64_t)uVar9 != (int64_t)iVar5)
        goto code_r0x0001800a4719;
        iVar5 = iVar5 + 1 + uVar9;
    }
    if (0 < iVar5) {
        uVar8 = iVar5 - 1;
        uVar10 = (uint64_t)uVar8;
        if ((int32_t)uVar8 <= (int32_t)uVar9) {
            if (iVar4 == 0) {
                uVar11 = uVar10;
                if (0 < (int32_t)uVar8) {
                    while (uVar10 = uVar11, (*(uint8_t *)(uVar10 + iVar1) & 0xc0) == 0x80) {
                        uVar9 = (int32_t)uVar10 - 1;
                        uVar11 = (uint64_t)uVar9;
                        if ((int32_t)uVar9 < 1) {
                            func_0x0001800865e0(arg1, uVar10);
                            return 1;
                        }
                    }
                }
            } else {
                if ((*(uint8_t *)((int32_t)uVar8 + iVar1) & 0xc0) == 0x80) {
                    func_0x000180088560(arg1, 0x18063ed20);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                if (iVar4 < 0) {
                    do {
                        uVar11 = uVar10;
                        if ((int32_t)uVar10 < 1) goto code_r0x0001800a46f7;
                        do {
                            uVar9 = (int32_t)uVar11 - 1;
                            uVar10 = (uint64_t)uVar9;
                            if ((int32_t)uVar9 < 1) break;
                            iVar2 = uVar11 - 1;
                            uVar11 = uVar10;
                        } while ((*(uint8_t *)(iVar2 + iVar1) & 0xc0) == 0x80);
                        iVar4 = iVar4 + 1;
                    } while (iVar4 < 0);
                } else {
                    while (iVar4 = iVar4 + -1, 0 < iVar4) {
                        if ((int32_t)uVar9 <= (int32_t)uVar10) goto code_r0x0001800a46f7;
                        do {
                            uVar8 = (int32_t)uVar10 + 1;
                            uVar10 = (uint64_t)uVar8;
                        } while ((*(uint8_t *)((int32_t)uVar8 + iVar1) & 0xc0) == 0x80);
                    }
                }
                if (iVar4 != 0) {
code_r0x0001800a46f7:
                    func_0x000180086510(arg1);
                    return 1;
                }
            }
            func_0x0001800865e0(arg1, (int32_t)uVar10 + 1);
            return 1;
        }
    }
code_r0x0001800a4719:
    func_0x000180088380(arg1, 3, 0x18063ed08);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a4742
// Address: 0x1800a4742
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.1800a4540(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uVar10;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a472e;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a472e:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    uVar9 = *(uint32_t *)(*piVar6 + 0x14);
    iVar4 = func_0x000180088860(arg1, 2);
    iVar5 = 1;
    if (iVar4 < 0) {
        iVar5 = uVar9 + 1;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar6 + 0xc))) {
        iVar5 = func_0x000180088860(arg1, 3);
    }
    if (iVar5 < 0) {
        if ((uint64_t)uVar9 <= (uint64_t)-(int64_t)iVar5 && -(uint64_t)uVar9 != (int64_t)iVar5)
        goto code_r0x0001800a4719;
        iVar5 = iVar5 + 1 + uVar9;
    }
    if (0 < iVar5) {
        uVar8 = iVar5 - 1;
        uVar10 = (uint64_t)uVar8;
        if ((int32_t)uVar8 <= (int32_t)uVar9) {
            if (iVar4 == 0) {
                uVar11 = uVar10;
                if (0 < (int32_t)uVar8) {
                    while (uVar10 = uVar11, (*(uint8_t *)(uVar10 + iVar1) & 0xc0) == 0x80) {
                        uVar9 = (int32_t)uVar10 - 1;
                        uVar11 = (uint64_t)uVar9;
                        if ((int32_t)uVar9 < 1) {
                            func_0x0001800865e0(arg1, uVar10);
                            return 1;
                        }
                    }
                }
            } else {
                if ((*(uint8_t *)((int32_t)uVar8 + iVar1) & 0xc0) == 0x80) {
                    func_0x000180088560(arg1, 0x18063ed20);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                if (iVar4 < 0) {
                    do {
                        uVar11 = uVar10;
                        if ((int32_t)uVar10 < 1) goto code_r0x0001800a46f7;
                        do {
                            uVar9 = (int32_t)uVar11 - 1;
                            uVar10 = (uint64_t)uVar9;
                            if ((int32_t)uVar9 < 1) break;
                            iVar2 = uVar11 - 1;
                            uVar11 = uVar10;
                        } while ((*(uint8_t *)(iVar2 + iVar1) & 0xc0) == 0x80);
                        iVar4 = iVar4 + 1;
                    } while (iVar4 < 0);
                } else {
                    while (iVar4 = iVar4 + -1, 0 < iVar4) {
                        if ((int32_t)uVar9 <= (int32_t)uVar10) goto code_r0x0001800a46f7;
                        do {
                            uVar8 = (int32_t)uVar10 + 1;
                            uVar10 = (uint64_t)uVar8;
                        } while ((*(uint8_t *)((int32_t)uVar8 + iVar1) & 0xc0) == 0x80);
                    }
                }
                if (iVar4 != 0) {
code_r0x0001800a46f7:
                    func_0x000180086510(arg1);
                    return 1;
                }
            }
            func_0x0001800865e0(arg1, (int32_t)uVar10 + 1);
            return 1;
        }
    }
code_r0x0001800a4719:
    func_0x000180088380(arg1, 3, 0x18063ed08);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_1800a4760
// Address: 0x1800a4760
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a4760(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    uint32_t uVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint8_t *puVar11;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a492e;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar7 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a492e:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    iVar4 = *(int32_t *)(*piVar7 + 0x14);
    uVar5 = func_0x000180085f50(arg1, 2);
    uVar8 = (uint64_t)(int32_t)uVar5;
    if ((int32_t)(uVar5 - 1) < 0) {
        uVar5 = 0;
    } else {
        if (iVar4 <= (int32_t)(uVar5 - 1)) {
            return 0;
        }
        uVar2 = *(uint8_t *)(uVar8 + iVar1);
        while ((uVar2 & 0xc0) == 0x80) {
            uVar5 = (int32_t)uVar8 + 1;
            uVar8 = (uint64_t)uVar5;
            uVar2 = *(uint8_t *)((int32_t)uVar5 + iVar1);
        }
    }
    if (iVar4 <= (int32_t)uVar5) {
        return 0;
    }
    puVar11 = (uint8_t *)((int32_t)uVar5 + iVar1);
    uVar2 = *puVar11;
    uVar10 = (uint32_t)uVar2;
    uVar9 = (uint32_t)uVar2;
    if (0x7f < uVar2) {
        uVar12 = 0;
        iVar4 = 0;
        if ((uVar2 & 0x40) != 0) {
            do {
                iVar4 = iVar4 + 1;
                if ((puVar11[iVar4] & 0xc0) != 0x80) goto code_r0x0001800a4942;
                uVar12 = puVar11[iVar4] & 0x3f | uVar12 << 6;
                uVar9 = uVar10 * 2;
                uVar10 = uVar9;
            } while ((uVar9 & 0x40) != 0);
            if (3 < iVar4) goto code_r0x0001800a4942;
        }
        uVar10 = (uVar9 & 0x7f) << ((char)iVar4 * '\x05' & 0x1fU) | uVar12;
        if (((0x10ffff < uVar10) || (uVar10 <= *(uint32_t *)((int64_t)iVar4 * 4 + 0x18063eda0))) ||
           (uVar10 - 0xd800 < 0x800)) goto code_r0x0001800a4942;
        puVar11 = puVar11 + iVar4;
    }
    if ((puVar11 + 1 != (uint8_t *)0x0) && ((puVar11[1] & 0xc0) != 0x80)) {
        func_0x0001800865e0(arg1, uVar5 + 1);
        func_0x0001800865e0(arg1, uVar10);
        return 2;
    }
code_r0x0001800a4942:
    func_0x000180088560(arg1, 0x18063ed88);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_1800a47e9
// Address: 0x1800a47e9
// Size: 307 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a4760(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    uint32_t uVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint8_t *puVar11;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a492e;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar7 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a492e:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    iVar4 = *(int32_t *)(*piVar7 + 0x14);
    uVar5 = func_0x000180085f50(arg1, 2);
    uVar8 = (uint64_t)(int32_t)uVar5;
    if ((int32_t)(uVar5 - 1) < 0) {
        uVar5 = 0;
    } else {
        if (iVar4 <= (int32_t)(uVar5 - 1)) {
            return 0;
        }
        uVar2 = *(uint8_t *)(uVar8 + iVar1);
        while ((uVar2 & 0xc0) == 0x80) {
            uVar5 = (int32_t)uVar8 + 1;
            uVar8 = (uint64_t)uVar5;
            uVar2 = *(uint8_t *)((int32_t)uVar5 + iVar1);
        }
    }
    if (iVar4 <= (int32_t)uVar5) {
        return 0;
    }
    puVar11 = (uint8_t *)((int32_t)uVar5 + iVar1);
    uVar2 = *puVar11;
    uVar10 = (uint32_t)uVar2;
    uVar9 = (uint32_t)uVar2;
    if (0x7f < uVar2) {
        uVar12 = 0;
        iVar4 = 0;
        if ((uVar2 & 0x40) != 0) {
            do {
                iVar4 = iVar4 + 1;
                if ((puVar11[iVar4] & 0xc0) != 0x80) goto code_r0x0001800a4942;
                uVar12 = puVar11[iVar4] & 0x3f | uVar12 << 6;
                uVar9 = uVar10 * 2;
                uVar10 = uVar9;
            } while ((uVar9 & 0x40) != 0);
            if (3 < iVar4) goto code_r0x0001800a4942;
        }
        uVar10 = (uVar9 & 0x7f) << ((char)iVar4 * '\x05' & 0x1fU) | uVar12;
        if (((0x10ffff < uVar10) || (uVar10 <= *(uint32_t *)((int64_t)iVar4 * 4 + 0x18063eda0))) ||
           (uVar10 - 0xd800 < 0x800)) goto code_r0x0001800a4942;
        puVar11 = puVar11 + iVar4;
    }
    if ((puVar11 + 1 != (uint8_t *)0x0) && ((puVar11[1] & 0xc0) != 0x80)) {
        func_0x0001800865e0(arg1, uVar5 + 1);
        func_0x0001800865e0(arg1, uVar10);
        return 2;
    }
code_r0x0001800a4942:
    func_0x000180088560(arg1, 0x18063ed88);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_1800a491c
// Address: 0x1800a491c
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a4760(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    uint32_t uVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint8_t *puVar11;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a492e;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar7 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a492e:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    iVar4 = *(int32_t *)(*piVar7 + 0x14);
    uVar5 = func_0x000180085f50(arg1, 2);
    uVar8 = (uint64_t)(int32_t)uVar5;
    if ((int32_t)(uVar5 - 1) < 0) {
        uVar5 = 0;
    } else {
        if (iVar4 <= (int32_t)(uVar5 - 1)) {
            return 0;
        }
        uVar2 = *(uint8_t *)(uVar8 + iVar1);
        while ((uVar2 & 0xc0) == 0x80) {
            uVar5 = (int32_t)uVar8 + 1;
            uVar8 = (uint64_t)uVar5;
            uVar2 = *(uint8_t *)((int32_t)uVar5 + iVar1);
        }
    }
    if (iVar4 <= (int32_t)uVar5) {
        return 0;
    }
    puVar11 = (uint8_t *)((int32_t)uVar5 + iVar1);
    uVar2 = *puVar11;
    uVar10 = (uint32_t)uVar2;
    uVar9 = (uint32_t)uVar2;
    if (0x7f < uVar2) {
        uVar12 = 0;
        iVar4 = 0;
        if ((uVar2 & 0x40) != 0) {
            do {
                iVar4 = iVar4 + 1;
                if ((puVar11[iVar4] & 0xc0) != 0x80) goto code_r0x0001800a4942;
                uVar12 = puVar11[iVar4] & 0x3f | uVar12 << 6;
                uVar9 = uVar10 * 2;
                uVar10 = uVar9;
            } while ((uVar9 & 0x40) != 0);
            if (3 < iVar4) goto code_r0x0001800a4942;
        }
        uVar10 = (uVar9 & 0x7f) << ((char)iVar4 * '\x05' & 0x1fU) | uVar12;
        if (((0x10ffff < uVar10) || (uVar10 <= *(uint32_t *)((int64_t)iVar4 * 4 + 0x18063eda0))) ||
           (uVar10 - 0xd800 < 0x800)) goto code_r0x0001800a4942;
        puVar11 = puVar11 + iVar4;
    }
    if ((puVar11 + 1 != (uint8_t *)0x0) && ((puVar11[1] & 0xc0) != 0x80)) {
        func_0x0001800865e0(arg1, uVar5 + 1);
        func_0x0001800865e0(arg1, uVar10);
        return 2;
    }
code_r0x0001800a4942:
    func_0x000180088560(arg1, 0x18063ed88);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_1800a492e
// Address: 0x1800a492e
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a4760(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    uint32_t uVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint8_t *puVar11;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a492e;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar7 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a492e:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    iVar4 = *(int32_t *)(*piVar7 + 0x14);
    uVar5 = func_0x000180085f50(arg1, 2);
    uVar8 = (uint64_t)(int32_t)uVar5;
    if ((int32_t)(uVar5 - 1) < 0) {
        uVar5 = 0;
    } else {
        if (iVar4 <= (int32_t)(uVar5 - 1)) {
            return 0;
        }
        uVar2 = *(uint8_t *)(uVar8 + iVar1);
        while ((uVar2 & 0xc0) == 0x80) {
            uVar5 = (int32_t)uVar8 + 1;
            uVar8 = (uint64_t)uVar5;
            uVar2 = *(uint8_t *)((int32_t)uVar5 + iVar1);
        }
    }
    if (iVar4 <= (int32_t)uVar5) {
        return 0;
    }
    puVar11 = (uint8_t *)((int32_t)uVar5 + iVar1);
    uVar2 = *puVar11;
    uVar10 = (uint32_t)uVar2;
    uVar9 = (uint32_t)uVar2;
    if (0x7f < uVar2) {
        uVar12 = 0;
        iVar4 = 0;
        if ((uVar2 & 0x40) != 0) {
            do {
                iVar4 = iVar4 + 1;
                if ((puVar11[iVar4] & 0xc0) != 0x80) goto code_r0x0001800a4942;
                uVar12 = puVar11[iVar4] & 0x3f | uVar12 << 6;
                uVar9 = uVar10 * 2;
                uVar10 = uVar9;
            } while ((uVar9 & 0x40) != 0);
            if (3 < iVar4) goto code_r0x0001800a4942;
        }
        uVar10 = (uVar9 & 0x7f) << ((char)iVar4 * '\x05' & 0x1fU) | uVar12;
        if (((0x10ffff < uVar10) || (uVar10 <= *(uint32_t *)((int64_t)iVar4 * 4 + 0x18063eda0))) ||
           (uVar10 - 0xd800 < 0x800)) goto code_r0x0001800a4942;
        puVar11 = puVar11 + iVar4;
    }
    if ((puVar11 + 1 != (uint8_t *)0x0) && ((puVar11[1] & 0xc0) != 0x80)) {
        func_0x0001800865e0(arg1, uVar5 + 1);
        func_0x0001800865e0(arg1, uVar10);
        return 2;
    }
code_r0x0001800a4942:
    func_0x000180088560(arg1, 0x18063ed88);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_1800a4942
// Address: 0x1800a4942
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a4760(int64_t arg1)
{
    int64_t iVar1;
    uint8_t uVar2;
    code *pcVar3;
    int32_t iVar4;
    uint32_t uVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint8_t *puVar11;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a492e;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar7 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800a492e:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    iVar4 = *(int32_t *)(*piVar7 + 0x14);
    uVar5 = func_0x000180085f50(arg1, 2);
    uVar8 = (uint64_t)(int32_t)uVar5;
    if ((int32_t)(uVar5 - 1) < 0) {
        uVar5 = 0;
    } else {
        if (iVar4 <= (int32_t)(uVar5 - 1)) {
            return 0;
        }
        uVar2 = *(uint8_t *)(uVar8 + iVar1);
        while ((uVar2 & 0xc0) == 0x80) {
            uVar5 = (int32_t)uVar8 + 1;
            uVar8 = (uint64_t)uVar5;
            uVar2 = *(uint8_t *)((int32_t)uVar5 + iVar1);
        }
    }
    if (iVar4 <= (int32_t)uVar5) {
        return 0;
    }
    puVar11 = (uint8_t *)((int32_t)uVar5 + iVar1);
    uVar2 = *puVar11;
    uVar10 = (uint32_t)uVar2;
    uVar9 = (uint32_t)uVar2;
    if (0x7f < uVar2) {
        uVar12 = 0;
        iVar4 = 0;
        if ((uVar2 & 0x40) != 0) {
            do {
                iVar4 = iVar4 + 1;
                if ((puVar11[iVar4] & 0xc0) != 0x80) goto code_r0x0001800a4942;
                uVar12 = puVar11[iVar4] & 0x3f | uVar12 << 6;
                uVar9 = uVar10 * 2;
                uVar10 = uVar9;
            } while ((uVar9 & 0x40) != 0);
            if (3 < iVar4) goto code_r0x0001800a4942;
        }
        uVar10 = (uVar9 & 0x7f) << ((char)iVar4 * '\x05' & 0x1fU) | uVar12;
        if (((0x10ffff < uVar10) || (uVar10 <= *(uint32_t *)((int64_t)iVar4 * 4 + 0x18063eda0))) ||
           (uVar10 - 0xd800 < 0x800)) goto code_r0x0001800a4942;
        puVar11 = puVar11 + iVar4;
    }
    if ((puVar11 + 1 != (uint8_t *)0x0) && ((puVar11[1] & 0xc0) != 0x80)) {
        func_0x0001800865e0(arg1, uVar5 + 1);
        func_0x0001800865e0(arg1, uVar10);
        return 2;
    }
code_r0x0001800a4942:
    func_0x000180088560(arg1, 0x18063ed88);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_1800a4960
// Address: 0x1800a4960
// Size: 206 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800a4960(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    int64_t var_18h;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar4 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x0001800a4a1a;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar4 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar4 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar4 != -0x18) {
        func_0x0001800869f0(arg1, fcn.1800a4760, 0, 0, 0);
        func_0x000180085bf0(arg1, 1);
        func_0x0001800865e0(arg1, 0);
        return 3;
    }
code_r0x0001800a4a1a:
    func_0x000180088470(arg1, 1, 6);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a4a30
// Address: 0x1800a4a30
// Size: 490 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.1800a4a30(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined8 uVar5;
    undefined4 *puVar6;
    undefined8 *puVar7;
    int32_t iVar8;
    int64_t var_38h;
    
    puVar7 = (undefined8 *)0x180612df0;
    iVar8 = 0;
    piVar2 = (int64_t *)0x180612df0;
    do {
        iVar8 = iVar8 + 1;
        piVar2 = piVar2 + 2;
    } while (*piVar2 != 0);
    func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
    func_0x000180086cc0(arg1, 0xffffffff, 0x18062628c);
    iVar3 = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((iVar3 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
        *(int64_t *)(arg1 + 0x40) = iVar3;
        iVar3 = func_0x000180088ce0(arg1, 0xffffd8ee, 0x18062628c, iVar8);
        if (iVar3 != 0) {
            func_0x000180088560(arg1, 0x18063da68, 0x18062628c);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = func_0x000180085510(arg1, 1), iVar8 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            func_0x000180087960(arg1);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        *puVar4 = puVar4[-4];
        puVar4[1] = puVar4[-3];
        puVar4[2] = puVar4[-2];
        puVar4[3] = puVar4[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffd, 0x18062628c);
    }
    puVar6 = *(undefined4 **)(arg1 + 0x40);
    puVar4 = puVar6 + -4;
    if (puVar4 < puVar6) {
        do {
            puVar4[-4] = *puVar4;
            puVar4[-3] = puVar4[1];
            puVar4[-2] = puVar4[2];
            puVar4[-1] = puVar4[3];
            puVar6 = *(undefined4 **)(arg1 + 0x40);
            puVar4 = puVar4 + 4;
        } while (puVar4 < puVar6);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar6 + -4;
    iVar3 = 0x18063c880;
    do {
        func_0x0001800869f0(arg1, puVar7[1], iVar3, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, *puVar7);
        iVar3 = puVar7[2];
        puVar7 = puVar7 + 2;
    } while (iVar3 != 0);
    func_0x0001800867f0(arg1, 0x18063ed48, 0xe);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063c2b0);
    return 1;
}

// ============================================================
// Function: FUN_1800a4c20
// Address: 0x1800a4c20
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800a4c20(int64_t arg1, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    double dVar4;
    double dVar5;
    undefined8 uVar6;
    double dVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar1 = *(int64_t *)(arg1 + 0x40);
    iVar2 = *(int64_t *)(arg1 + 0x28);
    dVar5 = (double)func_0x000180085ea0(arg1, 1, &var_8h);
    if ((int32_t)var_8h == 0) {
        func_0x000180088470(arg1, 1, 3);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    dVar4 = (double)func_0x000180085ea0(arg1, 2, &var_8h);
    if ((int32_t)var_8h == 0) {
        func_0x000180088470(arg1, 2, 3);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    if ((int32_t)(iVar1 - iVar2 >> 4) < 3) {
        dVar7 = 0.0;
    } else {
        dVar7 = (double)func_0x000180085ea0(arg1, 3, &var_8h);
        if ((int32_t)var_8h == 0) {
            func_0x000180088470(arg1, 3, 3);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    func_0x000180086750(arg1, (float)dVar5, (float)dVar4, (float)dVar7);
    return 1;
}

// ============================================================
// Function: FUN_1800a4c64
// Address: 0x1800a4c64
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800a4c20(int64_t arg1, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    double dVar4;
    double dVar5;
    undefined8 uVar6;
    double dVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar1 = *(int64_t *)(arg1 + 0x40);
    iVar2 = *(int64_t *)(arg1 + 0x28);
    dVar5 = (double)func_0x000180085ea0(arg1, 1, &var_8h);
    if ((int32_t)var_8h == 0) {
        func_0x000180088470(arg1, 1, 3);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    dVar4 = (double)func_0x000180085ea0(arg1, 2, &var_8h);
    if ((int32_t)var_8h == 0) {
        func_0x000180088470(arg1, 2, 3);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    if ((int32_t)(iVar1 - iVar2 >> 4) < 3) {
        dVar7 = 0.0;
    } else {
        dVar7 = (double)func_0x000180085ea0(arg1, 3, &var_8h);
        if ((int32_t)var_8h == 0) {
            func_0x000180088470(arg1, 3, 3);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    func_0x000180086750(arg1, (float)dVar5, (float)dVar4, (float)dVar7);
    return 1;
}

// ============================================================
// Function: FUN_1800a4ce3
// Address: 0x1800a4ce3
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800a4c20(int64_t arg1, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    double dVar4;
    double dVar5;
    undefined8 uVar6;
    double dVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar1 = *(int64_t *)(arg1 + 0x40);
    iVar2 = *(int64_t *)(arg1 + 0x28);
    dVar5 = (double)func_0x000180085ea0(arg1, 1, &var_8h);
    if ((int32_t)var_8h == 0) {
        func_0x000180088470(arg1, 1, 3);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    dVar4 = (double)func_0x000180085ea0(arg1, 2, &var_8h);
    if ((int32_t)var_8h == 0) {
        func_0x000180088470(arg1, 2, 3);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    if ((int32_t)(iVar1 - iVar2 >> 4) < 3) {
        dVar7 = 0.0;
    } else {
        dVar7 = (double)func_0x000180085ea0(arg1, 3, &var_8h);
        if ((int32_t)var_8h == 0) {
            func_0x000180088470(arg1, 3, 3);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    func_0x000180086750(arg1, (float)dVar5, (float)dVar4, (float)dVar7);
    return 1;
}

// ============================================================
// Function: FUN_1800a4cf4
// Address: 0x1800a4cf4
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800a4c20(int64_t arg1, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    double dVar4;
    double dVar5;
    undefined8 uVar6;
    double dVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar1 = *(int64_t *)(arg1 + 0x40);
    iVar2 = *(int64_t *)(arg1 + 0x28);
    dVar5 = (double)func_0x000180085ea0(arg1, 1, &var_8h);
    if ((int32_t)var_8h == 0) {
        func_0x000180088470(arg1, 1, 3);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    dVar4 = (double)func_0x000180085ea0(arg1, 2, &var_8h);
    if ((int32_t)var_8h == 0) {
        func_0x000180088470(arg1, 2, 3);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    if ((int32_t)(iVar1 - iVar2 >> 4) < 3) {
        dVar7 = 0.0;
    } else {
        dVar7 = (double)func_0x000180085ea0(arg1, 3, &var_8h);
        if ((int32_t)var_8h == 0) {
            func_0x000180088470(arg1, 3, 3);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    func_0x000180086750(arg1, (float)dVar5, (float)dVar4, (float)dVar7);
    return 1;
}

// ============================================================
// Function: FUN_1800a4d20
// Address: 0x1800a4d20
// Size: 145 bytes
// ============================================================
undefined8 fcn.1800a4d20(int64_t arg1)
{
    code *pcVar1;
    float *pfVar2;
    undefined8 uVar3;
    float *pfVar4;
    float fVar5;
    
    pfVar2 = *(float **)(arg1 + 0x28);
    if (*(float **)(arg1 + 0x40) <= *(float **)(arg1 + 0x28)) {
        pfVar2 = *(float **)0x180782430;
    }
    pfVar4 = (float *)0x0;
    if (pfVar2[3] == 7.006492e-45) {
        pfVar4 = pfVar2;
    }
    if (pfVar4 != (float *)0x0) {
        fVar5 = *pfVar4 * *pfVar4 + pfVar4[1] * pfVar4[1] + pfVar4[2] * pfVar4[2];
        if (fVar5 < 0.0) {
            fVar5 = (float)func_0x000180494560(fVar5);
        } else {
            fVar5 = SQRT(fVar5);
        }
        func_0x000180086570(arg1, (double)fVar5);
        return 1;
    }
    func_0x000180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a4dc0
// Address: 0x1800a4dc0
// Size: 44 bytes
// ============================================================
undefined8 fcn.1800a4dc0(int64_t arg1)
{
    float fVar1;
    float fVar2;
    float fVar3;
    code *pcVar4;
    float *pfVar5;
    undefined8 uVar6;
    float *pfVar7;
    float fVar8;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    pfVar5 = *(float **)(arg1 + 0x28);
    if (*(float **)(arg1 + 0x40) <= *(float **)(arg1 + 0x28)) {
        pfVar5 = *(float **)0x180782430;
    }
    pfVar7 = (float *)0x0;
    if (pfVar5[3] == 7.006492e-45) {
        pfVar7 = pfVar5;
    }
    if (pfVar7 != (float *)0x0) {
        fVar1 = pfVar7[1];
        fVar2 = *pfVar7;
        fVar3 = pfVar7[2];
        fVar8 = fVar2 * fVar2 + fVar1 * fVar1 + fVar3 * fVar3;
        if (fVar8 < 0.0) {
            fVar8 = (float)func_0x000180494560(fVar8);
        } else {
            fVar8 = SQRT(fVar8);
        }
        fVar8 = 1.0 / fVar8;
        func_0x000180086750(arg1, fVar8 * fVar2, fVar8 * fVar1, fVar8 * fVar3);
        return 1;
    }
    func_0x000180088470(arg1, 1, 5);
    pcVar4 = (code *)swi(3);
    uVar6 = (*pcVar4)();
    return uVar6;
}

// ============================================================
// Function: FUN_1800a4dec
// Address: 0x1800a4dec
// Size: 153 bytes
// ============================================================
undefined8 fcn.1800a4dc0(int64_t arg1)
{
    float fVar1;
    float fVar2;
    float fVar3;
    code *pcVar4;
    float *pfVar5;
    undefined8 uVar6;
    float *pfVar7;
    float fVar8;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    pfVar5 = *(float **)(arg1 + 0x28);
    if (*(float **)(arg1 + 0x40) <= *(float **)(arg1 + 0x28)) {
        pfVar5 = *(float **)0x180782430;
    }
    pfVar7 = (float *)0x0;
    if (pfVar5[3] == 7.006492e-45) {
        pfVar7 = pfVar5;
    }
    if (pfVar7 != (float *)0x0) {
        fVar1 = pfVar7[1];
        fVar2 = *pfVar7;
        fVar3 = pfVar7[2];
        fVar8 = fVar2 * fVar2 + fVar1 * fVar1 + fVar3 * fVar3;
        if (fVar8 < 0.0) {
            fVar8 = (float)func_0x000180494560(fVar8);
        } else {
            fVar8 = SQRT(fVar8);
        }
        fVar8 = 1.0 / fVar8;
        func_0x000180086750(arg1, fVar8 * fVar2, fVar8 * fVar1, fVar8 * fVar3);
        return 1;
    }
    func_0x000180088470(arg1, 1, 5);
    pcVar4 = (code *)swi(3);
    uVar6 = (*pcVar4)();
    return uVar6;
}

// ============================================================
// Function: FUN_1800a4e85
// Address: 0x1800a4e85
// Size: 17 bytes
// ============================================================
undefined8 fcn.1800a4dc0(int64_t arg1)
{
    float fVar1;
    float fVar2;
    float fVar3;
    code *pcVar4;
    float *pfVar5;
    undefined8 uVar6;
    float *pfVar7;
    float fVar8;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    pfVar5 = *(float **)(arg1 + 0x28);
    if (*(float **)(arg1 + 0x40) <= *(float **)(arg1 + 0x28)) {
        pfVar5 = *(float **)0x180782430;
    }
    pfVar7 = (float *)0x0;
    if (pfVar5[3] == 7.006492e-45) {
        pfVar7 = pfVar5;
    }
    if (pfVar7 != (float *)0x0) {
        fVar1 = pfVar7[1];
        fVar2 = *pfVar7;
        fVar3 = pfVar7[2];
        fVar8 = fVar2 * fVar2 + fVar1 * fVar1 + fVar3 * fVar3;
        if (fVar8 < 0.0) {
            fVar8 = (float)func_0x000180494560(fVar8);
        } else {
            fVar8 = SQRT(fVar8);
        }
        fVar8 = 1.0 / fVar8;
        func_0x000180086750(arg1, fVar8 * fVar2, fVar8 * fVar1, fVar8 * fVar3);
        return 1;
    }
    func_0x000180088470(arg1, 1, 5);
    pcVar4 = (code *)swi(3);
    uVar6 = (*pcVar4)();
    return uVar6;
}

// ============================================================
// Function: FUN_1800a4ea0
// Address: 0x1800a4ea0
// Size: 103 bytes
// ============================================================
undefined8 fcn.1800a4ea0(int64_t arg1)
{
    code *pcVar1;
    float *pfVar2;
    undefined8 uVar3;
    float *pfVar4;
    float *pfVar5;
    float fVar6;
    int64_t var_18h;
    
    pfVar5 = *(float **)(arg1 + 0x28);
    pfVar2 = pfVar5;
    if (*(float **)(arg1 + 0x40) <= pfVar5) {
        pfVar2 = *(float **)0x180782430;
    }
    pfVar4 = (float *)0x0;
    if (pfVar2[3] == 7.006492e-45) {
        pfVar4 = pfVar2;
    }
    if (pfVar4 != (float *)0x0) {
        pfVar2 = pfVar5 + 4;
        if (*(float **)(arg1 + 0x40) <= pfVar5 + 4) {
            pfVar2 = *(float **)0x180782430;
        }
        pfVar5 = (float *)0x0;
        if (pfVar2[3] == 7.006492e-45) {
            pfVar5 = pfVar2;
        }
        if (pfVar5 != (float *)0x0) {
            fVar6 = pfVar5[2] * *pfVar4;
            fcn.180086750(fVar6, pfVar5[2] * pfVar4[1] - pfVar4[2] * pfVar5[1], pfVar4[2] * *pfVar5 - fVar6, 
                          *pfVar4 * pfVar5[1] - *pfVar5 * pfVar4[1]);
            return 1;
        }
        fcn.180088470(arg1, 2, 5);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a4f07
// Address: 0x1800a4f07
// Size: 67 bytes
// ============================================================
undefined8 fcn.1800a4ea0(int64_t arg1)
{
    code *pcVar1;
    float *pfVar2;
    undefined8 uVar3;
    float *pfVar4;
    float *pfVar5;
    float fVar6;
    int64_t var_18h;
    
    pfVar5 = *(float **)(arg1 + 0x28);
    pfVar2 = pfVar5;
    if (*(float **)(arg1 + 0x40) <= pfVar5) {
        pfVar2 = *(float **)0x180782430;
    }
    pfVar4 = (float *)0x0;
    if (pfVar2[3] == 7.006492e-45) {
        pfVar4 = pfVar2;
    }
    if (pfVar4 != (float *)0x0) {
        pfVar2 = pfVar5 + 4;
        if (*(float **)(arg1 + 0x40) <= pfVar5 + 4) {
            pfVar2 = *(float **)0x180782430;
        }
        pfVar5 = (float *)0x0;
        if (pfVar2[3] == 7.006492e-45) {
            pfVar5 = pfVar2;
        }
        if (pfVar5 != (float *)0x0) {
            fVar6 = pfVar5[2] * *pfVar4;
            fcn.180086750(fVar6, pfVar5[2] * pfVar4[1] - pfVar4[2] * pfVar5[1], pfVar4[2] * *pfVar5 - fVar6, 
                          *pfVar4 * pfVar5[1] - *pfVar5 * pfVar4[1]);
            return 1;
        }
        fcn.180088470(arg1, 2, 5);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a4f4a
// Address: 0x1800a4f4a
// Size: 34 bytes
// ============================================================
undefined8 fcn.1800a4ea0(int64_t arg1)
{
    code *pcVar1;
    float *pfVar2;
    undefined8 uVar3;
    float *pfVar4;
    float *pfVar5;
    float fVar6;
    int64_t var_18h;
    
    pfVar5 = *(float **)(arg1 + 0x28);
    pfVar2 = pfVar5;
    if (*(float **)(arg1 + 0x40) <= pfVar5) {
        pfVar2 = *(float **)0x180782430;
    }
    pfVar4 = (float *)0x0;
    if (pfVar2[3] == 7.006492e-45) {
        pfVar4 = pfVar2;
    }
    if (pfVar4 != (float *)0x0) {
        pfVar2 = pfVar5 + 4;
        if (*(float **)(arg1 + 0x40) <= pfVar5 + 4) {
            pfVar2 = *(float **)0x180782430;
        }
        pfVar5 = (float *)0x0;
        if (pfVar2[3] == 7.006492e-45) {
            pfVar5 = pfVar2;
        }
        if (pfVar5 != (float *)0x0) {
            fVar6 = pfVar5[2] * *pfVar4;
            fcn.180086750(fVar6, pfVar5[2] * pfVar4[1] - pfVar4[2] * pfVar5[1], pfVar4[2] * *pfVar5 - fVar6, 
                          *pfVar4 * pfVar5[1] - *pfVar5 * pfVar4[1]);
            return 1;
        }
        fcn.180088470(arg1, 2, 5);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a4f70
// Address: 0x1800a4f70
// Size: 162 bytes
// ============================================================
undefined8 fcn.1800a4f70(int64_t arg1)
{
    code *pcVar1;
    float *pfVar2;
    undefined8 uVar3;
    float *pfVar4;
    float *pfVar5;
    
    pfVar5 = *(float **)(arg1 + 0x28);
    pfVar2 = pfVar5;
    if (*(float **)(arg1 + 0x40) <= pfVar5) {
        pfVar2 = *(float **)0x180782430;
    }
    pfVar4 = (float *)0x0;
    if (pfVar2[3] == 7.006492e-45) {
        pfVar4 = pfVar2;
    }
    if (pfVar4 != (float *)0x0) {
        pfVar2 = pfVar5 + 4;
        if (*(float **)(arg1 + 0x40) <= pfVar5 + 4) {
            pfVar2 = *(float **)0x180782430;
        }
        pfVar5 = (float *)0x0;
        if (pfVar2[3] == 7.006492e-45) {
            pfVar5 = pfVar2;
        }
        if (pfVar5 != (float *)0x0) {
            fcn.180086570(*pfVar4 * *pfVar5, (double)(pfVar5[1] * pfVar4[1] + *pfVar4 * *pfVar5 + pfVar5[2] * pfVar4[2])
                         );
            return 1;
        }
        fcn.180088470(arg1, 2, 5);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a5020
// Address: 0x1800a5020
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a5020(int64_t arg1)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    code *pcVar7;
    float *pfVar8;
    float *pfVar9;
    undefined8 uVar10;
    float *pfVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    pfVar9 = *(float **)(arg1 + 0x28);
    pfVar11 = *(float **)(arg1 + 0x40);
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar12 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar12 = pfVar8;
    }
    if (pfVar12 == (float *)0x0) {
        fcn.180088470(arg1, 1, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar8 = pfVar9 + 4;
    if (pfVar11 <= pfVar9 + 4) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar13 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar13 = pfVar8;
    }
    if (pfVar13 == (float *)0x0) {
        fcn.180088470(arg1, 2, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar9 = pfVar9 + 8;
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    if ((pfVar8 == *(float **)0x180782430) || ((int32_t)pfVar8[3] < 1)) {
        pfVar11 = (float *)0x0;
    } else {
        if (pfVar11 <= pfVar9) {
            pfVar9 = *(float **)0x180782430;
        }
        pfVar11 = (float *)0x0;
        if (pfVar9[3] == 7.006492e-45) {
            pfVar11 = pfVar9;
        }
        if (pfVar11 == (float *)0x0) {
            fcn.180088470(arg1, 3, 5);
            pcVar7 = (code *)swi(3);
            uVar10 = (*pcVar7)();
            return uVar10;
        }
    }
    fVar1 = *pfVar12;
    fVar2 = pfVar13[1];
    fVar3 = pfVar12[2];
    fVar4 = pfVar13[2];
    fVar5 = pfVar12[1];
    fVar6 = *pfVar13;
    fVar17 = fVar5 * fVar4 - fVar3 * fVar2;
    fVar16 = fVar6 * fVar3 - fVar1 * fVar4;
    fVar18 = fVar1 * fVar2 - fVar6 * fVar5;
    fVar15 = fVar16 * fVar16 + fVar17 * fVar17 + fVar18 * fVar18;
    if (fVar15 < 0.0) {
        fVar15 = (float)func_0x000180494560(fVar15);
    } else {
        fVar15 = SQRT(fVar15);
    }
    uVar14 = func_0x00018048f110((double)fVar15, (double)(fVar1 * fVar6 + fVar2 * fVar5 + fVar3 * fVar4));
    if ((pfVar11 != (float *)0x0) && (fVar16 * pfVar11[1] + fVar17 * *pfVar11 + fVar18 * pfVar11[2] < 0.0)) {
        uVar14 = uVar14 ^ 0x8000000000000000;
    }
    fcn.180086570(arg1, uVar14);
    return 1;
}

// ============================================================
// Function: FUN_1800a507c
// Address: 0x1800a507c
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a5020(int64_t arg1)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    code *pcVar7;
    float *pfVar8;
    float *pfVar9;
    undefined8 uVar10;
    float *pfVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    pfVar9 = *(float **)(arg1 + 0x28);
    pfVar11 = *(float **)(arg1 + 0x40);
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar12 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar12 = pfVar8;
    }
    if (pfVar12 == (float *)0x0) {
        fcn.180088470(arg1, 1, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar8 = pfVar9 + 4;
    if (pfVar11 <= pfVar9 + 4) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar13 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar13 = pfVar8;
    }
    if (pfVar13 == (float *)0x0) {
        fcn.180088470(arg1, 2, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar9 = pfVar9 + 8;
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    if ((pfVar8 == *(float **)0x180782430) || ((int32_t)pfVar8[3] < 1)) {
        pfVar11 = (float *)0x0;
    } else {
        if (pfVar11 <= pfVar9) {
            pfVar9 = *(float **)0x180782430;
        }
        pfVar11 = (float *)0x0;
        if (pfVar9[3] == 7.006492e-45) {
            pfVar11 = pfVar9;
        }
        if (pfVar11 == (float *)0x0) {
            fcn.180088470(arg1, 3, 5);
            pcVar7 = (code *)swi(3);
            uVar10 = (*pcVar7)();
            return uVar10;
        }
    }
    fVar1 = *pfVar12;
    fVar2 = pfVar13[1];
    fVar3 = pfVar12[2];
    fVar4 = pfVar13[2];
    fVar5 = pfVar12[1];
    fVar6 = *pfVar13;
    fVar17 = fVar5 * fVar4 - fVar3 * fVar2;
    fVar16 = fVar6 * fVar3 - fVar1 * fVar4;
    fVar18 = fVar1 * fVar2 - fVar6 * fVar5;
    fVar15 = fVar16 * fVar16 + fVar17 * fVar17 + fVar18 * fVar18;
    if (fVar15 < 0.0) {
        fVar15 = (float)func_0x000180494560(fVar15);
    } else {
        fVar15 = SQRT(fVar15);
    }
    uVar14 = func_0x00018048f110((double)fVar15, (double)(fVar1 * fVar6 + fVar2 * fVar5 + fVar3 * fVar4));
    if ((pfVar11 != (float *)0x0) && (fVar16 * pfVar11[1] + fVar17 * *pfVar11 + fVar18 * pfVar11[2] < 0.0)) {
        uVar14 = uVar14 ^ 0x8000000000000000;
    }
    fcn.180086570(arg1, uVar14);
    return 1;
}

// ============================================================
// Function: FUN_1800a50bf
// Address: 0x1800a50bf
// Size: 295 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a5020(int64_t arg1)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    code *pcVar7;
    float *pfVar8;
    float *pfVar9;
    undefined8 uVar10;
    float *pfVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    pfVar9 = *(float **)(arg1 + 0x28);
    pfVar11 = *(float **)(arg1 + 0x40);
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar12 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar12 = pfVar8;
    }
    if (pfVar12 == (float *)0x0) {
        fcn.180088470(arg1, 1, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar8 = pfVar9 + 4;
    if (pfVar11 <= pfVar9 + 4) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar13 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar13 = pfVar8;
    }
    if (pfVar13 == (float *)0x0) {
        fcn.180088470(arg1, 2, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar9 = pfVar9 + 8;
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    if ((pfVar8 == *(float **)0x180782430) || ((int32_t)pfVar8[3] < 1)) {
        pfVar11 = (float *)0x0;
    } else {
        if (pfVar11 <= pfVar9) {
            pfVar9 = *(float **)0x180782430;
        }
        pfVar11 = (float *)0x0;
        if (pfVar9[3] == 7.006492e-45) {
            pfVar11 = pfVar9;
        }
        if (pfVar11 == (float *)0x0) {
            fcn.180088470(arg1, 3, 5);
            pcVar7 = (code *)swi(3);
            uVar10 = (*pcVar7)();
            return uVar10;
        }
    }
    fVar1 = *pfVar12;
    fVar2 = pfVar13[1];
    fVar3 = pfVar12[2];
    fVar4 = pfVar13[2];
    fVar5 = pfVar12[1];
    fVar6 = *pfVar13;
    fVar17 = fVar5 * fVar4 - fVar3 * fVar2;
    fVar16 = fVar6 * fVar3 - fVar1 * fVar4;
    fVar18 = fVar1 * fVar2 - fVar6 * fVar5;
    fVar15 = fVar16 * fVar16 + fVar17 * fVar17 + fVar18 * fVar18;
    if (fVar15 < 0.0) {
        fVar15 = (float)func_0x000180494560(fVar15);
    } else {
        fVar15 = SQRT(fVar15);
    }
    uVar14 = func_0x00018048f110((double)fVar15, (double)(fVar1 * fVar6 + fVar2 * fVar5 + fVar3 * fVar4));
    if ((pfVar11 != (float *)0x0) && (fVar16 * pfVar11[1] + fVar17 * *pfVar11 + fVar18 * pfVar11[2] < 0.0)) {
        uVar14 = uVar14 ^ 0x8000000000000000;
    }
    fcn.180086570(arg1, uVar14);
    return 1;
}

// ============================================================
// Function: FUN_1800a51e6
// Address: 0x1800a51e6
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a5020(int64_t arg1)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    code *pcVar7;
    float *pfVar8;
    float *pfVar9;
    undefined8 uVar10;
    float *pfVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    pfVar9 = *(float **)(arg1 + 0x28);
    pfVar11 = *(float **)(arg1 + 0x40);
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar12 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar12 = pfVar8;
    }
    if (pfVar12 == (float *)0x0) {
        fcn.180088470(arg1, 1, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar8 = pfVar9 + 4;
    if (pfVar11 <= pfVar9 + 4) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar13 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar13 = pfVar8;
    }
    if (pfVar13 == (float *)0x0) {
        fcn.180088470(arg1, 2, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar9 = pfVar9 + 8;
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    if ((pfVar8 == *(float **)0x180782430) || ((int32_t)pfVar8[3] < 1)) {
        pfVar11 = (float *)0x0;
    } else {
        if (pfVar11 <= pfVar9) {
            pfVar9 = *(float **)0x180782430;
        }
        pfVar11 = (float *)0x0;
        if (pfVar9[3] == 7.006492e-45) {
            pfVar11 = pfVar9;
        }
        if (pfVar11 == (float *)0x0) {
            fcn.180088470(arg1, 3, 5);
            pcVar7 = (code *)swi(3);
            uVar10 = (*pcVar7)();
            return uVar10;
        }
    }
    fVar1 = *pfVar12;
    fVar2 = pfVar13[1];
    fVar3 = pfVar12[2];
    fVar4 = pfVar13[2];
    fVar5 = pfVar12[1];
    fVar6 = *pfVar13;
    fVar17 = fVar5 * fVar4 - fVar3 * fVar2;
    fVar16 = fVar6 * fVar3 - fVar1 * fVar4;
    fVar18 = fVar1 * fVar2 - fVar6 * fVar5;
    fVar15 = fVar16 * fVar16 + fVar17 * fVar17 + fVar18 * fVar18;
    if (fVar15 < 0.0) {
        fVar15 = (float)func_0x000180494560(fVar15);
    } else {
        fVar15 = SQRT(fVar15);
    }
    uVar14 = func_0x00018048f110((double)fVar15, (double)(fVar1 * fVar6 + fVar2 * fVar5 + fVar3 * fVar4));
    if ((pfVar11 != (float *)0x0) && (fVar16 * pfVar11[1] + fVar17 * *pfVar11 + fVar18 * pfVar11[2] < 0.0)) {
        uVar14 = uVar14 ^ 0x8000000000000000;
    }
    fcn.180086570(arg1, uVar14);
    return 1;
}

// ============================================================
// Function: FUN_1800a5244
// Address: 0x1800a5244
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a5020(int64_t arg1)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    code *pcVar7;
    float *pfVar8;
    float *pfVar9;
    undefined8 uVar10;
    float *pfVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    pfVar9 = *(float **)(arg1 + 0x28);
    pfVar11 = *(float **)(arg1 + 0x40);
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar12 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar12 = pfVar8;
    }
    if (pfVar12 == (float *)0x0) {
        fcn.180088470(arg1, 1, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar8 = pfVar9 + 4;
    if (pfVar11 <= pfVar9 + 4) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar13 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar13 = pfVar8;
    }
    if (pfVar13 == (float *)0x0) {
        fcn.180088470(arg1, 2, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar9 = pfVar9 + 8;
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    if ((pfVar8 == *(float **)0x180782430) || ((int32_t)pfVar8[3] < 1)) {
        pfVar11 = (float *)0x0;
    } else {
        if (pfVar11 <= pfVar9) {
            pfVar9 = *(float **)0x180782430;
        }
        pfVar11 = (float *)0x0;
        if (pfVar9[3] == 7.006492e-45) {
            pfVar11 = pfVar9;
        }
        if (pfVar11 == (float *)0x0) {
            fcn.180088470(arg1, 3, 5);
            pcVar7 = (code *)swi(3);
            uVar10 = (*pcVar7)();
            return uVar10;
        }
    }
    fVar1 = *pfVar12;
    fVar2 = pfVar13[1];
    fVar3 = pfVar12[2];
    fVar4 = pfVar13[2];
    fVar5 = pfVar12[1];
    fVar6 = *pfVar13;
    fVar17 = fVar5 * fVar4 - fVar3 * fVar2;
    fVar16 = fVar6 * fVar3 - fVar1 * fVar4;
    fVar18 = fVar1 * fVar2 - fVar6 * fVar5;
    fVar15 = fVar16 * fVar16 + fVar17 * fVar17 + fVar18 * fVar18;
    if (fVar15 < 0.0) {
        fVar15 = (float)func_0x000180494560(fVar15);
    } else {
        fVar15 = SQRT(fVar15);
    }
    uVar14 = func_0x00018048f110((double)fVar15, (double)(fVar1 * fVar6 + fVar2 * fVar5 + fVar3 * fVar4));
    if ((pfVar11 != (float *)0x0) && (fVar16 * pfVar11[1] + fVar17 * *pfVar11 + fVar18 * pfVar11[2] < 0.0)) {
        uVar14 = uVar14 ^ 0x8000000000000000;
    }
    fcn.180086570(arg1, uVar14);
    return 1;
}

// ============================================================
// Function: FUN_1800a5258
// Address: 0x1800a5258
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a5020(int64_t arg1)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    code *pcVar7;
    float *pfVar8;
    float *pfVar9;
    undefined8 uVar10;
    float *pfVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    pfVar9 = *(float **)(arg1 + 0x28);
    pfVar11 = *(float **)(arg1 + 0x40);
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar12 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar12 = pfVar8;
    }
    if (pfVar12 == (float *)0x0) {
        fcn.180088470(arg1, 1, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar8 = pfVar9 + 4;
    if (pfVar11 <= pfVar9 + 4) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar13 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar13 = pfVar8;
    }
    if (pfVar13 == (float *)0x0) {
        fcn.180088470(arg1, 2, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar9 = pfVar9 + 8;
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    if ((pfVar8 == *(float **)0x180782430) || ((int32_t)pfVar8[3] < 1)) {
        pfVar11 = (float *)0x0;
    } else {
        if (pfVar11 <= pfVar9) {
            pfVar9 = *(float **)0x180782430;
        }
        pfVar11 = (float *)0x0;
        if (pfVar9[3] == 7.006492e-45) {
            pfVar11 = pfVar9;
        }
        if (pfVar11 == (float *)0x0) {
            fcn.180088470(arg1, 3, 5);
            pcVar7 = (code *)swi(3);
            uVar10 = (*pcVar7)();
            return uVar10;
        }
    }
    fVar1 = *pfVar12;
    fVar2 = pfVar13[1];
    fVar3 = pfVar12[2];
    fVar4 = pfVar13[2];
    fVar5 = pfVar12[1];
    fVar6 = *pfVar13;
    fVar17 = fVar5 * fVar4 - fVar3 * fVar2;
    fVar16 = fVar6 * fVar3 - fVar1 * fVar4;
    fVar18 = fVar1 * fVar2 - fVar6 * fVar5;
    fVar15 = fVar16 * fVar16 + fVar17 * fVar17 + fVar18 * fVar18;
    if (fVar15 < 0.0) {
        fVar15 = (float)func_0x000180494560(fVar15);
    } else {
        fVar15 = SQRT(fVar15);
    }
    uVar14 = func_0x00018048f110((double)fVar15, (double)(fVar1 * fVar6 + fVar2 * fVar5 + fVar3 * fVar4));
    if ((pfVar11 != (float *)0x0) && (fVar16 * pfVar11[1] + fVar17 * *pfVar11 + fVar18 * pfVar11[2] < 0.0)) {
        uVar14 = uVar14 ^ 0x8000000000000000;
    }
    fcn.180086570(arg1, uVar14);
    return 1;
}

// ============================================================
// Function: FUN_1800a526c
// Address: 0x1800a526c
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a5020(int64_t arg1)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    code *pcVar7;
    float *pfVar8;
    float *pfVar9;
    undefined8 uVar10;
    float *pfVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    pfVar9 = *(float **)(arg1 + 0x28);
    pfVar11 = *(float **)(arg1 + 0x40);
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar12 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar12 = pfVar8;
    }
    if (pfVar12 == (float *)0x0) {
        fcn.180088470(arg1, 1, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar8 = pfVar9 + 4;
    if (pfVar11 <= pfVar9 + 4) {
        pfVar8 = *(float **)0x180782430;
    }
    pfVar13 = (float *)0x0;
    if (pfVar8[3] == 7.006492e-45) {
        pfVar13 = pfVar8;
    }
    if (pfVar13 == (float *)0x0) {
        fcn.180088470(arg1, 2, 5);
        pcVar7 = (code *)swi(3);
        uVar10 = (*pcVar7)();
        return uVar10;
    }
    pfVar9 = pfVar9 + 8;
    pfVar8 = pfVar9;
    if (pfVar11 <= pfVar9) {
        pfVar8 = *(float **)0x180782430;
    }
    if ((pfVar8 == *(float **)0x180782430) || ((int32_t)pfVar8[3] < 1)) {
        pfVar11 = (float *)0x0;
    } else {
        if (pfVar11 <= pfVar9) {
            pfVar9 = *(float **)0x180782430;
        }
        pfVar11 = (float *)0x0;
        if (pfVar9[3] == 7.006492e-45) {
            pfVar11 = pfVar9;
        }
        if (pfVar11 == (float *)0x0) {
            fcn.180088470(arg1, 3, 5);
            pcVar7 = (code *)swi(3);
            uVar10 = (*pcVar7)();
            return uVar10;
        }
    }
    fVar1 = *pfVar12;
    fVar2 = pfVar13[1];
    fVar3 = pfVar12[2];
    fVar4 = pfVar13[2];
    fVar5 = pfVar12[1];
    fVar6 = *pfVar13;
    fVar17 = fVar5 * fVar4 - fVar3 * fVar2;
    fVar16 = fVar6 * fVar3 - fVar1 * fVar4;
    fVar18 = fVar1 * fVar2 - fVar6 * fVar5;
    fVar15 = fVar16 * fVar16 + fVar17 * fVar17 + fVar18 * fVar18;
    if (fVar15 < 0.0) {
        fVar15 = (float)func_0x000180494560(fVar15);
    } else {
        fVar15 = SQRT(fVar15);
    }
    uVar14 = func_0x00018048f110((double)fVar15, (double)(fVar1 * fVar6 + fVar2 * fVar5 + fVar3 * fVar4));
    if ((pfVar11 != (float *)0x0) && (fVar16 * pfVar11[1] + fVar17 * *pfVar11 + fVar18 * pfVar11[2] < 0.0)) {
        uVar14 = uVar14 ^ 0x8000000000000000;
    }
    fcn.180086570(arg1, uVar14);
    return 1;
}

// ============================================================
// Function: FUN_1800a5280
// Address: 0x1800a5280
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a5280(int64_t arg1)
{
    code *pcVar1;
    undefined4 *puVar2;
    undefined8 uVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    
    puVar2 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar2 = *(undefined4 **)0x180782430;
    }
    puVar4 = (undefined4 *)0x0;
    if (puVar2[3] == 5) {
        puVar4 = puVar2;
    }
    if (puVar4 != (undefined4 *)0x0) {
        uVar5 = fcn.180490aa0(puVar4[2]);
        uVar6 = fcn.180490aa0(puVar4[1]);
        uVar7 = fcn.180490aa0(*puVar4);
        fcn.180086750(arg1, uVar7, uVar6, uVar5);
        return 1;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

