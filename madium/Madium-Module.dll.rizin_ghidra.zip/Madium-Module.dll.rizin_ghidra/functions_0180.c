// Chunk 180 - 50 functions

// ============================================================
// Function: FUN_18023b15c
// Address: 0x18023b15c
// Size: 61 bytes
// ============================================================
undefined8 fcn.18023b15c(int64_t arg_48h)
{
    int64_t in_stack_00000020;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000038;
    int64_t in_stack_00000040;
    int64_t in_stack_00000050;
    
    fcn.180229480(in_stack_00000020, in_stack_00000028);
    fcn.1802295a0(in_stack_00000020, in_stack_00000028, in_stack_00000030, in_stack_00000038, in_stack_00000050);
    fcn.1802296d0(in_stack_00000040);
    return 0;
}

// ============================================================
// Function: FUN_18023b1a0
// Address: 0x18023b1a0
// Size: 87 bytes
// ============================================================
void fcn.18023b1a0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18023b1b0;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar1 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b1cc;
        fcn.180224990(uVar1, 0x1804e2da8, 0x86);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b1dc;
        fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b1f1;
        fcn.180224990(arg1, 0x1804e2da8, 0x88);
    }
    return;
}

// ============================================================
// Function: FUN_18023b200
// Address: 0x18023b200
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18023b200(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar5;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023b220;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)(in_RCX + 0x10);
    iVar5 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b237;
    iVar2 = func_0x000180222010(uVar1);
    if (0 < iVar2) {
        do {
            uVar1 = *(undefined8 *)(in_RCX + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b24b;
            iVar4 = func_0x000180222340(uVar1, iVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b25d;
            iVar2 = func_0x000180497f30(iVar4 + 0x18, in_RDX, in_R8);
            if (iVar2 == 0) {
                return iVar4;
            }
            uVar1 = *(undefined8 *)(in_RCX + 0x10);
            iVar5 = iVar5 + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b26c;
            iVar2 = func_0x000180222010(uVar1);
        } while (iVar5 < iVar2);
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b2a0
// Address: 0x18023b2a0
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.18023b2a0(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023b2b5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b2d5;
    puVar3 = (undefined8 *)func_0x000180224d60(0x18, 0x1804e2da8, 0x66);
    if (puVar3 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *puVar3 = in_RCX;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b2fe;
        iVar4 = func_0x0001802231e0(in_RDX, 0x1804e2da8, 0x6d);
        puVar3[1] = iVar4;
        if (iVar4 == 0) goto code_r0x00018023b344;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b30c;
    iVar4 = func_0x000180221f20();
    puVar3[2] = iVar4;
    if (iVar4 != 0) {
        return puVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b31a;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b332;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b344;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
code_r0x00018023b344:
    uVar1 = puVar3[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b35a;
    fcn.180224990(uVar1, 0x1804e2da8, 0x86);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b36a;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000050 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b37f;
    fcn.180224990(puVar3, 0x1804e2da8, 0x88);
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18023b3b0
// Address: 0x18023b3b0
// Size: 102 bytes
// ============================================================
void fcn.18023b3b0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18023b3c0;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar1 = *(undefined8 *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b3dc;
        fcn.180224990(uVar1, 0x1804e2da8, 0x127);
        uVar1 = *(undefined8 *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b3e5;
        fcn.18022ecc0(uVar1);
        uVar1 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b3fb;
        fcn.180224990(uVar1, 0x1804e2da8, 0x129);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b410;
        fcn.180224990(arg1, 0x1804e2da8, 0x12a);
    }
    return;
}

// ============================================================
// Function: FUN_18023b420
// Address: 0x18023b420
// Size: 100 bytes
// ============================================================
uint32_t fcn.18023b420(undefined8 param_1, int64_t param_2, int32_t param_3)
{
    uint32_t uVar1;
    
    fcn.18045a350();
    uVar1 = *(uint32_t *)(param_2 + 0xd8);
    if (((uVar1 & 4) != 0) && ((*(uint8_t *)(param_2 + 0xe0) & 2) == 0)) {
        return 0;
    }
    if (param_3 == 0) {
        if (((uVar1 & 2) != 0) && ((*(uint8_t *)(param_2 + 0xdc) & 0x88) == 0)) {
            return 0;
        }
        if ((uVar1 & 8) != 0) {
            return *(uint32_t *)(param_2 + 0xe4) >> 7 & 1;
        }
        return 1;
    }
    uVar1 = *(uint32_t *)(param_2 + 0xd8);
    if (((uVar1 & 2) == 0) || ((*(uint8_t *)(param_2 + 0xdc) & 4) != 0)) {
        if ((uVar1 & 1) == 0) {
            if ((uVar1 & 0x2040) == 0x2040) {
                return 1;
            }
            if ((uVar1 & 2) != 0) {
                return 1;
            }
            if ((uVar1 & 8) == 0) {
                return 0;
            }
            if ((*(uint8_t *)(param_2 + 0xe4) & 7) == 0) {
                return 0;
            }
        } else {
            if ((uVar1 & 0x10) == 0) {
                return 0;
            }
            if (((uint8_t)uVar1 & 0x10) != 0x50) {
                return 1;
            }
        }
        if ((*(uint8_t *)(param_2 + 0xe4) & 4) != 0) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b490
// Address: 0x18023b490
// Size: 103 bytes
// ============================================================
bool fcn.18023b490(undefined8 param_1, int64_t param_2, int32_t param_3)
{
    uint32_t uVar1;
    
    fcn.18045a350();
    uVar1 = *(uint32_t *)(param_2 + 0xd8);
    if (((uVar1 & 4) != 0) && ((*(uint8_t *)(param_2 + 0xe0) & 0x11) == 0)) {
        return false;
    }
    if (param_3 == 0) {
        if (((uVar1 & 8) != 0) && ((*(uint8_t *)(param_2 + 0xe4) & 0x40) == 0)) {
            return false;
        }
        if ((uVar1 & 2) != 0) {
            return (*(uint8_t *)(param_2 + 0xdc) & 0xa8) != 0;
        }
        return true;
    }
    uVar1 = *(uint32_t *)(param_2 + 0xd8);
    if (((uVar1 & 2) == 0) || ((*(uint8_t *)(param_2 + 0xdc) & 4) != 0)) {
        if ((uVar1 & 1) == 0) {
            if ((uVar1 & 0x2040) == 0x2040) {
                return true;
            }
            if ((uVar1 & 2) != 0) {
                return true;
            }
            if ((uVar1 & 8) == 0) {
                return false;
            }
            if ((*(uint8_t *)(param_2 + 0xe4) & 7) == 0) {
                return false;
            }
        } else {
            if ((uVar1 & 0x10) == 0) {
                return false;
            }
            if (((uint8_t)uVar1 & 0x10) != 0x50) {
                return true;
            }
        }
        if ((*(uint8_t *)(param_2 + 0xe4) & 4) != 0) {
            return true;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_18023b500
// Address: 0x18023b500
// Size: 106 bytes
// ============================================================
undefined8 fcn.18023b500(undefined8 param_1, int64_t param_2, int32_t param_3)
{
    uint32_t uVar1;
    
    fcn.18045a350();
    uVar1 = *(uint32_t *)(param_2 + 0xd8);
    if (((uVar1 & 4) != 0) && ((*(uint8_t *)(param_2 + 0xe0) & 0x11) == 0)) {
        return 0;
    }
    if (param_3 == 0) {
        if (((uVar1 & 8) != 0) && ((*(uint8_t *)(param_2 + 0xe4) & 0x40) == 0)) {
            return 0;
        }
        if (((uVar1 & 2) != 0) && ((*(uint8_t *)(param_2 + 0xdc) & 0xa8) == 0)) {
            return 0;
        }
        if (((uVar1 & 2) != 0) && ((*(uint8_t *)(param_2 + 0xdc) & 0x20) == 0)) {
            return 0;
        }
        return 1;
    }
    uVar1 = *(uint32_t *)(param_2 + 0xd8);
    if (((uVar1 & 2) == 0) || ((*(uint8_t *)(param_2 + 0xdc) & 4) != 0)) {
        if ((uVar1 & 1) == 0) {
            if ((uVar1 & 0x2040) == 0x2040) {
                return 1;
            }
            if ((uVar1 & 2) != 0) {
                return 1;
            }
            if ((uVar1 & 8) == 0) {
                return 0;
            }
            if ((*(uint8_t *)(param_2 + 0xe4) & 7) == 0) {
                return 0;
            }
        } else {
            if ((uVar1 & 0x10) == 0) {
                return 0;
            }
            if (((uint8_t)uVar1 & 0x10) != 0x50) {
                return 1;
            }
        }
        if ((*(uint8_t *)(param_2 + 0xe4) & 4) != 0) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b570
// Address: 0x18023b570
// Size: 68 bytes
// ============================================================
undefined8 fcn.18023b570(undefined8 param_1, int64_t param_2, int32_t param_3)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023b57c;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18023b590;
    uVar2 = fcn.18023c640(param_2, param_3);
    if (((((int32_t)uVar2 != 0) && (param_3 == 0)) && ((*(uint8_t *)(param_2 + 0xd8) & 2) != 0)) &&
       ((*(uint8_t *)(param_2 + 0xdc) & 0xc0) == 0)) {
        uVar2 = 0;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_18023b5c0
// Address: 0x18023b5c0
// Size: 68 bytes
// ============================================================
undefined8 fcn.18023b5c0(undefined8 param_1, int64_t param_2, int32_t param_3)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023b5cc;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18023b5e0;
    uVar2 = fcn.18023c640(param_2, param_3);
    if (((((int32_t)uVar2 != 0) && (param_3 == 0)) && ((*(uint8_t *)(param_2 + 0xd8) & 2) != 0)) &&
       ((*(uint8_t *)(param_2 + 0xdc) & 0x20) == 0)) {
        uVar2 = 0;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_18023b610
// Address: 0x18023b610
// Size: 78 bytes
// ============================================================
int32_t fcn.18023b610(undefined8 param_1, int64_t param_2, int32_t param_3)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023b61a;
    iVar2 = fcn.18045a350();
    if (param_3 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x18023b62a;
        iVar1 = fcn.18023bc30(param_2);
        if (iVar1 == 2) {
            iVar1 = 0;
        }
        return iVar1;
    }
    if (((*(uint8_t *)(param_2 + 0xd8) & 2) != 0) && ((*(uint8_t *)(param_2 + 0xdc) & 2) == 0)) {
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_18023b660
// Address: 0x18023b660
// Size: 142 bytes
// ============================================================
uint32_t fcn.18023b660(undefined8 param_1, int64_t param_2, int32_t param_3)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023b66c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_3 == 0) {
        if (((((*(uint32_t *)(param_2 + 0xd8) & 2) == 0) ||
             (((*(uint32_t *)(param_2 + 0xdc) & 0xffffff3f) == 0 && ((*(uint32_t *)(param_2 + 0xdc) & 0xc0) != 0)))) &&
            ((*(uint32_t *)(param_2 + 0xd8) & 4) != 0)) && (*(int32_t *)(param_2 + 0xe0) == 0x40)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b6c1;
            iVar2 = func_0x000180239480(param_2, 0x7e, 0xffffffff);
            if (-1 < iVar2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b6cf;
                uVar4 = func_0x000180239460(param_2, iVar2);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b6d7;
                iVar2 = func_0x0001802ab4d0(uVar4);
                if (iVar2 == 0) {
                    return 0;
                }
            }
            return 1;
        }
        return 0;
    }
    uVar1 = *(uint32_t *)(param_2 + 0xd8);
    if (((uVar1 & 2) == 0) || ((*(uint8_t *)(param_2 + 0xdc) & 4) != 0)) {
        if ((uVar1 & 1) != 0) {
            return uVar1 >> 4 & 1;
        }
        if ((uVar1 & 0x2040) == 0x2040) {
            return 3;
        }
        if ((uVar1 & 2) != 0) {
            return 4;
        }
        if ((uVar1 & 8) != 0) {
            return -(uint32_t)((*(uint32_t *)(param_2 + 0xe4) & 7) != 0) & 5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b6f0
// Address: 0x18023b6f0
// Size: 150 bytes
// ============================================================
uint32_t fcn.18023b6f0(undefined8 param_1, int64_t param_2, int32_t param_3)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023b6fc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_3 == 0) {
        if ((((*(uint8_t *)(param_2 + 0xd8) & 2) != 0) && ((char)*(uint32_t *)(param_2 + 0xdc) < '\0')) &&
           ((*(uint32_t *)(param_2 + 0xdc) & 6) == 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b73e;
            iVar2 = func_0x000180239480(param_2, 0x53, 0xffffffff);
            if (-1 < iVar2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b74c;
                uVar4 = func_0x000180239460(param_2, iVar2);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b754;
                iVar2 = func_0x0001802ab4d0(uVar4);
                if (((iVar2 != 0) && ((*(uint8_t *)(param_2 + 0xd8) & 4) != 0)) &&
                   ((*(uint32_t *)(param_2 + 0xe0) & 8) != 0)) {
                    return (uint32_t)((*(uint32_t *)(param_2 + 0xe0) & 0x101) == 0);
                }
            }
        }
        return 0;
    }
    uVar1 = *(uint32_t *)(param_2 + 0xd8);
    if (((uVar1 & 2) == 0) || ((*(uint8_t *)(param_2 + 0xdc) & 4) != 0)) {
        if ((uVar1 & 1) != 0) {
            return uVar1 >> 4 & 1;
        }
        if ((uVar1 & 0x2040) == 0x2040) {
            return 3;
        }
        if ((uVar1 & 2) != 0) {
            return 4;
        }
        if ((uVar1 & 8) != 0) {
            return -(uint32_t)((*(uint32_t *)(param_2 + 0xe4) & 7) != 0) & 5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b790
// Address: 0x18023b790
// Size: 40 bytes
// ============================================================
uint32_t fcn.18023b790(undefined8 param_1, int64_t param_2, int32_t param_3)
{
    uint32_t uVar1;
    
    fcn.18045a350();
    if (param_3 == 0) {
        return 1;
    }
    uVar1 = *(uint32_t *)(param_2 + 0xd8);
    if (((uVar1 & 2) == 0) || ((*(uint8_t *)(param_2 + 0xdc) & 4) != 0)) {
        if ((uVar1 & 1) != 0) {
            return uVar1 >> 4 & 1;
        }
        if ((uVar1 & 0x2040) == 0x2040) {
            return 3;
        }
        if ((uVar1 & 2) != 0) {
            return 4;
        }
        if ((uVar1 & 8) != 0) {
            return -(uint32_t)((*(uint32_t *)(param_2 + 0xe4) & 7) != 0) & 5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b7c0
// Address: 0x18023b7c0
// Size: 74 bytes
// ============================================================
int64_t fcn.18023b7c0(int32_t param_1)
{
    fcn.18045a350();
    if (param_1 < 0) {
        return 0;
    }
    if (param_1 < 10) {
        return (int64_t)param_1 * 0x30 + 0x1806a0160;
    }
    param_1 = param_1 + -10;
    if (((*(int32_t **)0x18077e4c0 != (int32_t *)0x0) && (-1 < param_1)) && (param_1 < **(int32_t **)0x18077e4c0)) {
        return *(int64_t *)(*(int64_t *)(*(int32_t **)0x18077e4c0 + 2) + (int64_t)param_1 * 8);
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b810
// Address: 0x18023b810
// Size: 79 bytes
// ============================================================
uint32_t fcn.18023b810(int64_t arg_80h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t in_ECX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023b81a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = in_ECX - 1;
    if (9 < uVar1) {
        if (*(int64_t *)0x18077e4c0 != 0) {
            *(int32_t *)((int64_t)&var_20h + iVar3) = in_ECX;
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023b841;
            iVar2 = fcn.180221a50(*(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
            uVar1 = iVar2 + 10;
            if (iVar2 < 0) {
                uVar1 = 0xffffffff;
            }
            return uVar1;
        }
        uVar1 = 0xffffffff;
    }
    return uVar1;
}

// ============================================================
// Function: FUN_18023b870
// Address: 0x18023b870
// Size: 263 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint8_t fcn.18023b870(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t *piVar5;
    int64_t in_RCX;
    int64_t *in_RDX;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023b885;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RDX != (int64_t *)0x0) {
        if ((*in_RDX != 0) && (*(int64_t *)(in_RCX + 0xe8) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b8b0;
            iVar2 = fcn.180260b00();
            if (iVar2 != 0) {
                return 0x1e;
            }
        }
        iVar1 = in_RDX[2];
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b8da;
            uVar4 = fcn.18000f490(in_RCX);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b8e5;
            iVar2 = fcn.18025fd70(uVar4, iVar1);
            if (iVar2 != 0) {
                return 0x1f;
            }
        }
        iVar1 = in_RDX[1];
        if (iVar1 != 0) {
            iVar6 = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b911;
            iVar2 = fcn.180222010(iVar1);
            if (0 < iVar2) {
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b91f;
                    piVar5 = (int32_t *)fcn.180222340(iVar1, iVar6);
                    if (*piVar5 == 4) {
                        if (*(int64_t *)(piVar5 + 2) == 0) {
                            return 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b955;
                        fcn.1801e3990(in_RCX);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b960;
                        iVar2 = fcn.1802378e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                        return -(iVar2 != 0) & 0x1f;
                    }
                    iVar6 = iVar6 + 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b92e;
                    iVar2 = fcn.180222010(iVar1);
                } while (iVar6 < iVar2);
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b980
// Address: 0x18023b980
// Size: 46 bytes
// ============================================================
uint64_t fcn.18023b980(int64_t param_1)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023b98c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b997;
    uVar3 = fcn.18023bea0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if ((int32_t)uVar3 == 0) {
        return uVar3;
    }
    uVar1 = *(uint32_t *)(param_1 + 0xd8);
    if (((uVar1 & 2) == 0) || ((*(uint8_t *)(param_1 + 0xdc) & 4) != 0)) {
        if ((uVar1 & 1) != 0) {
            return (uint64_t)(uVar1 >> 4 & 1);
        }
        if ((uVar1 & 0x2040) == 0x2040) {
            return 3;
        }
        if ((uVar1 & 2) != 0) {
            return 4;
        }
        if ((uVar1 & 8) != 0) {
            return (uint64_t)(-(uint32_t)((*(uint32_t *)(param_1 + 0xe4) & 7) != 0) & 5);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b9b0
// Address: 0x18023b9b0
// Size: 286 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18023b9b0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023b9c5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b9d6;
    fcn.1801e3990(in_RDX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b9e1;
    fcn.180238460(in_RCX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023b9ec;
    iVar1 = fcn.1802378e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar1 != 0) {
        return 0x1d;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023ba0d;
    iVar1 = fcn.18023bea0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023ba1d;
        iVar1 = fcn.18023bea0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000050 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023ba34;
            uVar3 = fcn.18023b870(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            if ((int32_t)uVar3 != 0) {
                return uVar3;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023ba44;
            fcn.180238400(in_RCX);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023ba4f;
            uVar3 = fcn.18023bc90(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
            if ((int32_t)uVar3 != 0) {
                return uVar3;
            }
            if ((*(uint8_t *)(in_RCX + 0xd8) & 2) != 0) {
                if ((*(uint32_t *)(in_RDX + 0xd8) & 0x400) == 0) {
                    if ((*(uint8_t *)(in_RCX + 0xdc) & 4) == 0) {
                        return 0x20;
                    }
                } else if ((*(uint8_t *)(in_RCX + 0xdc) & 0x80) == 0) {
                    return 0x27;
                }
            }
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18023bad0
// Address: 0x18023bad0
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18023bad0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 in_RCX;
    int32_t in_EDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023bae5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023baf5;
    iVar1 = fcn.18023bea0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (iVar1 != 0) {
        if (in_EDX == -1) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023bb1a;
        iVar1 = fcn.18023b810(*(int64_t *)(&stack0x00000070 + iVar2));
        if (iVar1 != -1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023bb26;
            iVar2 = fcn.18023b7c0(iVar1);
    // WARNING: Could not recover jumptable at 0x00018023bb42. Too many branches
    // WARNING: Treating indirect jump as call
            uVar3 = (**(code **)(iVar2 + 0x10))(iVar2, in_RCX, in_R8 & 0xffffffff, *(code **)(iVar2 + 0x10));
            return uVar3;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18023bb60
// Address: 0x18023bb60
// Size: 65 bytes
// ============================================================
uint64_t fcn.18023bb60(int64_t param_1)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023bb6c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023bb77;
    uVar2 = fcn.18023bea0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar1));
    if ((int32_t)uVar2 == 0) {
        return uVar2;
    }
    if ((*(uint8_t *)(param_1 + 0xd8) & 4) != 0) {
        return (uint64_t)*(uint32_t *)(param_1 + 0xe0);
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18023bbb0
// Address: 0x18023bbb0
// Size: 35 bytes
// ============================================================
undefined4 fcn.18023bbb0(int64_t param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023bbbc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023bbc7;
    fcn.18023bea0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    return *(undefined4 *)(param_1 + 0xd8);
}

// ============================================================
// Function: FUN_18023bbe0
// Address: 0x18023bbe0
// Size: 65 bytes
// ============================================================
uint64_t fcn.18023bbe0(int64_t param_1)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023bbec;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023bbf7;
    uVar2 = fcn.18023bea0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar1));
    if ((int32_t)uVar2 == 0) {
        return uVar2;
    }
    if ((*(uint8_t *)(param_1 + 0xd8) & 2) != 0) {
        return (uint64_t)*(uint32_t *)(param_1 + 0xdc);
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18023bc90
// Address: 0x18023bc90
// Size: 158 bytes
// ============================================================
undefined8 fcn.18023bc90(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023bc9c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX == 0) {
        return 0x18;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023bcbb;
    fcn.18022cd20(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023bcc9;
    iVar1 = fcn.1802567e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000088 + iVar2), *(int64_t *)(&stack0x000000a0 + iVar2));
    if (iVar1 == 0) {
        return 0x4c;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023bce1;
    fcn.18022ccf0(*(undefined4 *)((int64_t)&arg_28h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023bcec;
    iVar1 = fcn.18022fc40(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000070 + iVar2));
    if (iVar1 != 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023bcff;
    iVar1 = fcn.18022fc40(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000070 + iVar2));
    if (iVar1 != 0) {
        uVar3 = 0;
        if (*(int32_t *)((int64_t)&arg_28h + iVar2) != 0x390) {
            uVar3 = 0x4d;
        }
        return uVar3;
    }
    return 0x4d;
}

// ============================================================
// Function: FUN_18023bda0
// Address: 0x18023bda0
// Size: 183 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18023bda0(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023bdb5;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023bdc6;
    fcn.1801e3990(in_RDX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023bdd1;
    fcn.180238460(in_RCX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023bddc;
    iVar2 = fcn.1802378e0(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (iVar2 != 0) {
        return 0x1d;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023bdfd;
    iVar2 = fcn.18023bea0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar4));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023be09;
        iVar2 = fcn.18023bea0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                              , *(int64_t *)(&stack0x00000050 + iVar4));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023be1c;
            uVar5 = fcn.18023b870(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            if ((int32_t)uVar5 != 0) {
                return uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023be28;
            iVar6 = fcn.180238400(in_RCX);
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x18023bc9c;
            iVar3 = fcn.18045a350();
            iVar3 = -iVar3;
            if (iVar6 == 0) {
                return 0x18;
            }
            *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar4 + -8) = 0x18023bcbb;
            fcn.18022cd20(*(int64_t *)(&stack0x00000040 + iVar3 + iVar4), *(int64_t *)(&stack0x00000050 + iVar3 + iVar4)
                          , *(int64_t *)(&stack0x00000058 + iVar3 + iVar4), 
                          *(int64_t *)(&stack0x00000060 + iVar3 + iVar4), *(int64_t *)(&stack0x00000068 + iVar3 + iVar4)
                          , *(int64_t *)(&stack0x00000080 + iVar3 + iVar4));
            *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar4 + -8) = 0x18023bcc9;
            iVar2 = fcn.1802567e0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x000000a8 + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x000000c0 + iVar3 + iVar4));
            if (iVar2 == 0) {
                return 0x4c;
            }
            uVar1 = *(undefined4 *)(&stack0x00000048 + iVar3 + iVar4);
            *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar4 + -8) = 0x18023bce1;
            fcn.18022ccf0(uVar1);
            *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar4 + -8) = 0x18023bcec;
            iVar2 = fcn.18022fc40(*(int64_t *)(&stack0x00000038 + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x00000048 + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar4), 
                                  *(int64_t *)(&stack0x00000090 + iVar3 + iVar4));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar4 + -8) = 0x18023bcff;
                iVar2 = fcn.18022fc40(*(int64_t *)(&stack0x00000038 + iVar3 + iVar4), 
                                      *(int64_t *)(&stack0x00000040 + iVar3 + iVar4), 
                                      *(int64_t *)(&stack0x00000048 + iVar3 + iVar4), 
                                      *(int64_t *)(&stack0x00000050 + iVar3 + iVar4), 
                                      *(int64_t *)(&stack0x00000090 + iVar3 + iVar4));
                if (iVar2 == 0) {
                    return 0x4d;
                }
                uVar5 = 0;
                if (*(int32_t *)(&stack0x00000048 + iVar3 + iVar4) != 0x390) {
                    uVar5 = 0x4d;
                }
                return uVar5;
            }
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18023bea0
// Address: 0x18023bea0
// Size: 76 bytes
// ============================================================
uint64_t fcn.18023bea0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    uint8_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    uint32_t *puVar13;
    uint32_t *puVar14;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18023beb0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(in_RCX + 0x150) != 0) {
        return (uint64_t)(~(*(uint32_t *)(in_RCX + 0xd8) >> 7) & 1);
    }
    uVar11 = *(undefined8 *)(in_RCX + 0x148);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bee1;
    uVar7 = fcn.180222950(uVar11);
    if ((int32_t)uVar7 == 0) {
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    if ((*puVar14 & 0x100) != 0) {
        uVar11 = *(undefined8 *)(in_RCX + 0x148);
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf0c;
        fcn.180222910(uVar11);
        return (uint64_t)(~(*puVar14 >> 7) & 1);
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf36;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf3b;
    fcn.18020e860();
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf50;
    iVar2 = fcn.180240450(*(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                          *(int64_t *)(&stack0x00000040 + iVar6));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x100000;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf6e;
    iVar2 = fcn.180237590(in_RCX);
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x40;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    uVar4 = 0xffffffff;
    *(undefined4 *)(in_RCX + 0xd0) = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bfa2;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if (*piVar8 != 0) {
            *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x10;
        }
        puVar13 = (uint32_t *)(in_RCX + 0xd8);
        if (*(int64_t *)(piVar8 + 2) != 0) {
            if (*(int32_t *)(*(int64_t *)(piVar8 + 2) + 4) == 0x102) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bfd9;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bff1;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c003;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
                *puVar14 = *puVar14 | 0x80;
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c011;
                fcn.1802ac5d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
                *puVar13 = *puVar13 | 1;
                goto code_r0x00018023c03d;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c01b;
            uVar3 = fcn.18025fde0(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
            *(undefined4 *)(in_RCX + 0xd0) = uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c029;
        fcn.1802ac5d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
        *puVar13 = *puVar13 | 1;
    }
code_r0x00018023c03d:
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c051;
    piVar9 = (int64_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar9 == (int64_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if ((*(uint8_t *)puVar14 & 0x10) == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c06e;
            iVar2 = fcn.180239480(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (-1 < iVar2) goto code_r0x00018023c086;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c082;
            iVar2 = fcn.180239480(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (-1 < iVar2) goto code_r0x00018023c086;
        } else {
code_r0x00018023c086:
            *puVar14 = *puVar14 | 0x80;
        }
        if (*piVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0a0;
            uVar4 = fcn.18025fde0(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
        }
        *(undefined4 *)(in_RCX + 0xd4) = uVar4;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0b2;
        fcn.1802ac3b0(piVar9);
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x400;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0da;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h == -1) goto code_r0x00018023c178;
    } else {
        *(undefined4 *)(in_RCX + 0xdc) = 0;
        if (0 < *piVar8) {
            uVar1 = **(uint8_t **)(piVar8 + 2);
            *(uint32_t *)(in_RCX + 0xdc) = (uint32_t)uVar1;
            if (1 < *piVar8) {
                *(uint32_t *)(in_RCX + 0xdc) = (uint32_t)CONCAT11(*(undefined *)(*(int64_t *)(piVar8 + 2) + 1), uVar1);
            }
        }
        *puVar14 = *puVar14 | 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c132;
        fcn.180228780(*(int64_t *)(&stack0x00000038 + iVar6));
        if (*(int32_t *)(in_RCX + 0xdc) != 0) goto code_r0x00018023c178;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c140;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c158;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)(&stack0x00000040 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c16a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    }
    *puVar14 = *puVar14 | 0x80;
code_r0x00018023c178:
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined4 *)(in_RCX + 0xe0) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c193;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (iVar10 == 0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        *puVar14 = *puVar14 | 4;
        var_8h._0_4_ = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1ae;
        iVar2 = fcn.180222010(iVar10);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1ca;
                fcn.180222340(iVar10, (int32_t)var_8h);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1d2;
                iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                      *(int64_t *)(&stack0x00000058 + iVar6));
                if (iVar2 < 0xb5) {
                    if (iVar2 == 0xb4) {
                        *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x20;
                    } else {
    // switch table (11 cases) at 0x18023c614
                        switch(iVar2) {
                        case 0x81:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 1;
                            break;
                        case 0x82:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 2;
                            break;
                        case 0x83:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 8;
                            break;
                        case 0x84:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 4;
                            break;
                        case 0x85:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x40;
                            break;
                        case 0x89:
                        case 0x8b:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x10;
                        }
                    }
                } else if (iVar2 == 0x129) {
                    *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x80;
                } else if (iVar2 == 0x38e) {
                    *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x100;
                }
                var_8h._0_4_ = (int32_t)var_8h + 1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c261;
                iVar2 = fcn.180222010(iVar10);
            } while ((int32_t)var_8h < iVar2);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c282;
        fcn.180222050(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2a4;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if (*piVar8 < 1) {
            uVar12 = 0;
        } else {
            uVar12 = (uint32_t)**(uint8_t **)(piVar8 + 2);
        }
        *(uint32_t *)(in_RCX + 0xe4) = uVar12;
        *puVar14 = *puVar14 | 8;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2cb;
        fcn.180228780(*(int64_t *)(&stack0x00000038 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2f7;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0xe8) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c32d;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0xf0) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c356;
    fcn.1801e3990(in_RCX);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c361;
    fcn.180238460(in_RCX);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c36c;
    iVar2 = fcn.1802378e0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x20;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c382;
        iVar2 = fcn.18023b870(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6));
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c38e;
            fcn.180238400(in_RCX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c399;
            iVar2 = fcn.18023bc90(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8));
            if (iVar2 == 0) {
                *puVar14 = *puVar14 | 0x2000;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c3be;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x108) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c3f4;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x110) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c41b;
    iVar2 = fcn.18023c6b0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c445;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x118) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c477;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x120) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    var_8h._0_4_ = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c49b;
    iVar2 = fcn.1802394a0(in_RCX);
    if (0 < iVar2) {
        do {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4ba;
            uVar11 = fcn.180239460(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4c5;
            fcn.18020e940(uVar11);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4cd;
            iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
            if (iVar2 == 0x359) {
                *puVar14 = *puVar14 | 0x1000;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4e4;
            iVar5 = fcn.1802ab4d0(uVar11);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4f0;
                fcn.18020e940(uVar11);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4f8;
                var_10h._0_4_ =
                     fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                   *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                   *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
                if ((int32_t)var_10h != 0) {
                    *(undefined8 *)((int64_t)&iStackX_18 + iVar6 + -8) = 0x18023bd90;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c520;
                    iVar10 = fcn.18022c840(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                                           *(int64_t *)(&stack0x00000048 + iVar6));
                    if (iVar10 != 0) {
                        if (iVar2 == 0x52) {
                            *puVar14 = *puVar14 | 0x40000;
                        } else if (iVar2 == 0x55) {
                            *puVar14 = *puVar14 | 0x80000;
                        } else if (iVar2 == 0x57) {
                            *puVar14 = *puVar14 | 0x10000;
                        } else if (iVar2 == 0x5a) {
                            *puVar14 = *puVar14 | 0x20000;
                        }
                        goto code_r0x00018023c557;
                    }
                }
                *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x200;
                break;
            }
code_r0x00018023c557:
            var_8h._0_4_ = (int32_t)var_8h + 1;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c562;
            iVar2 = fcn.1802394a0(in_RCX);
        } while ((int32_t)var_8h < iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c581;
    fcn.180237610(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                  *(int64_t *)(&stack0x00000078 + iVar6));
    *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x100;
    *(undefined4 *)(in_RCX + 0x150) = 1;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c59a;
    fcn.1802299d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
    uVar11 = *(undefined8 *)(in_RCX + 0x148);
    if ((*(uint8_t *)(in_RCX + 0xd8) & 0x80) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5be;
        fcn.180222910(uVar11);
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5d4;
    fcn.180222910(uVar11);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5d9;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5f1;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                  *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                  *(int64_t *)(&stack0x00000040 + iVar6));
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c603;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_18023beec
// Address: 0x18023beec
// Size: 54 bytes
// ============================================================
uint64_t fcn.18023bea0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    uint8_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    uint32_t *puVar13;
    uint32_t *puVar14;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18023beb0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(in_RCX + 0x150) != 0) {
        return (uint64_t)(~(*(uint32_t *)(in_RCX + 0xd8) >> 7) & 1);
    }
    uVar11 = *(undefined8 *)(in_RCX + 0x148);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bee1;
    uVar7 = fcn.180222950(uVar11);
    if ((int32_t)uVar7 == 0) {
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    if ((*puVar14 & 0x100) != 0) {
        uVar11 = *(undefined8 *)(in_RCX + 0x148);
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf0c;
        fcn.180222910(uVar11);
        return (uint64_t)(~(*puVar14 >> 7) & 1);
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf36;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf3b;
    fcn.18020e860();
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf50;
    iVar2 = fcn.180240450(*(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                          *(int64_t *)(&stack0x00000040 + iVar6));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x100000;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf6e;
    iVar2 = fcn.180237590(in_RCX);
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x40;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    uVar4 = 0xffffffff;
    *(undefined4 *)(in_RCX + 0xd0) = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bfa2;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if (*piVar8 != 0) {
            *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x10;
        }
        puVar13 = (uint32_t *)(in_RCX + 0xd8);
        if (*(int64_t *)(piVar8 + 2) != 0) {
            if (*(int32_t *)(*(int64_t *)(piVar8 + 2) + 4) == 0x102) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bfd9;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bff1;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c003;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
                *puVar14 = *puVar14 | 0x80;
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c011;
                fcn.1802ac5d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
                *puVar13 = *puVar13 | 1;
                goto code_r0x00018023c03d;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c01b;
            uVar3 = fcn.18025fde0(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
            *(undefined4 *)(in_RCX + 0xd0) = uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c029;
        fcn.1802ac5d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
        *puVar13 = *puVar13 | 1;
    }
code_r0x00018023c03d:
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c051;
    piVar9 = (int64_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar9 == (int64_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if ((*(uint8_t *)puVar14 & 0x10) == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c06e;
            iVar2 = fcn.180239480(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (-1 < iVar2) goto code_r0x00018023c086;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c082;
            iVar2 = fcn.180239480(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (-1 < iVar2) goto code_r0x00018023c086;
        } else {
code_r0x00018023c086:
            *puVar14 = *puVar14 | 0x80;
        }
        if (*piVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0a0;
            uVar4 = fcn.18025fde0(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
        }
        *(undefined4 *)(in_RCX + 0xd4) = uVar4;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0b2;
        fcn.1802ac3b0(piVar9);
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x400;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0da;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h == -1) goto code_r0x00018023c178;
    } else {
        *(undefined4 *)(in_RCX + 0xdc) = 0;
        if (0 < *piVar8) {
            uVar1 = **(uint8_t **)(piVar8 + 2);
            *(uint32_t *)(in_RCX + 0xdc) = (uint32_t)uVar1;
            if (1 < *piVar8) {
                *(uint32_t *)(in_RCX + 0xdc) = (uint32_t)CONCAT11(*(undefined *)(*(int64_t *)(piVar8 + 2) + 1), uVar1);
            }
        }
        *puVar14 = *puVar14 | 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c132;
        fcn.180228780(*(int64_t *)(&stack0x00000038 + iVar6));
        if (*(int32_t *)(in_RCX + 0xdc) != 0) goto code_r0x00018023c178;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c140;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c158;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)(&stack0x00000040 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c16a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    }
    *puVar14 = *puVar14 | 0x80;
code_r0x00018023c178:
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined4 *)(in_RCX + 0xe0) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c193;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (iVar10 == 0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        *puVar14 = *puVar14 | 4;
        var_8h._0_4_ = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1ae;
        iVar2 = fcn.180222010(iVar10);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1ca;
                fcn.180222340(iVar10, (int32_t)var_8h);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1d2;
                iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                      *(int64_t *)(&stack0x00000058 + iVar6));
                if (iVar2 < 0xb5) {
                    if (iVar2 == 0xb4) {
                        *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x20;
                    } else {
    // switch table (11 cases) at 0x18023c614
                        switch(iVar2) {
                        case 0x81:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 1;
                            break;
                        case 0x82:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 2;
                            break;
                        case 0x83:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 8;
                            break;
                        case 0x84:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 4;
                            break;
                        case 0x85:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x40;
                            break;
                        case 0x89:
                        case 0x8b:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x10;
                        }
                    }
                } else if (iVar2 == 0x129) {
                    *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x80;
                } else if (iVar2 == 0x38e) {
                    *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x100;
                }
                var_8h._0_4_ = (int32_t)var_8h + 1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c261;
                iVar2 = fcn.180222010(iVar10);
            } while ((int32_t)var_8h < iVar2);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c282;
        fcn.180222050(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2a4;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if (*piVar8 < 1) {
            uVar12 = 0;
        } else {
            uVar12 = (uint32_t)**(uint8_t **)(piVar8 + 2);
        }
        *(uint32_t *)(in_RCX + 0xe4) = uVar12;
        *puVar14 = *puVar14 | 8;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2cb;
        fcn.180228780(*(int64_t *)(&stack0x00000038 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2f7;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0xe8) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c32d;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0xf0) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c356;
    fcn.1801e3990(in_RCX);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c361;
    fcn.180238460(in_RCX);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c36c;
    iVar2 = fcn.1802378e0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x20;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c382;
        iVar2 = fcn.18023b870(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6));
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c38e;
            fcn.180238400(in_RCX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c399;
            iVar2 = fcn.18023bc90(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8));
            if (iVar2 == 0) {
                *puVar14 = *puVar14 | 0x2000;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c3be;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x108) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c3f4;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x110) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c41b;
    iVar2 = fcn.18023c6b0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c445;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x118) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c477;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x120) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    var_8h._0_4_ = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c49b;
    iVar2 = fcn.1802394a0(in_RCX);
    if (0 < iVar2) {
        do {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4ba;
            uVar11 = fcn.180239460(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4c5;
            fcn.18020e940(uVar11);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4cd;
            iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
            if (iVar2 == 0x359) {
                *puVar14 = *puVar14 | 0x1000;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4e4;
            iVar5 = fcn.1802ab4d0(uVar11);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4f0;
                fcn.18020e940(uVar11);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4f8;
                var_10h._0_4_ =
                     fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                   *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                   *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
                if ((int32_t)var_10h != 0) {
                    *(undefined8 *)((int64_t)&iStackX_18 + iVar6 + -8) = 0x18023bd90;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c520;
                    iVar10 = fcn.18022c840(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                                           *(int64_t *)(&stack0x00000048 + iVar6));
                    if (iVar10 != 0) {
                        if (iVar2 == 0x52) {
                            *puVar14 = *puVar14 | 0x40000;
                        } else if (iVar2 == 0x55) {
                            *puVar14 = *puVar14 | 0x80000;
                        } else if (iVar2 == 0x57) {
                            *puVar14 = *puVar14 | 0x10000;
                        } else if (iVar2 == 0x5a) {
                            *puVar14 = *puVar14 | 0x20000;
                        }
                        goto code_r0x00018023c557;
                    }
                }
                *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x200;
                break;
            }
code_r0x00018023c557:
            var_8h._0_4_ = (int32_t)var_8h + 1;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c562;
            iVar2 = fcn.1802394a0(in_RCX);
        } while ((int32_t)var_8h < iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c581;
    fcn.180237610(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                  *(int64_t *)(&stack0x00000078 + iVar6));
    *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x100;
    *(undefined4 *)(in_RCX + 0x150) = 1;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c59a;
    fcn.1802299d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
    uVar11 = *(undefined8 *)(in_RCX + 0x148);
    if ((*(uint8_t *)(in_RCX + 0xd8) & 0x80) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5be;
        fcn.180222910(uVar11);
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5d4;
    fcn.180222910(uVar11);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5d9;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5f1;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                  *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                  *(int64_t *)(&stack0x00000040 + iVar6));
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c603;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_18023bf22
// Address: 0x18023bf22
// Size: 1687 bytes
// ============================================================
uint64_t fcn.18023bea0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    uint8_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    uint32_t *puVar13;
    uint32_t *puVar14;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18023beb0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(in_RCX + 0x150) != 0) {
        return (uint64_t)(~(*(uint32_t *)(in_RCX + 0xd8) >> 7) & 1);
    }
    uVar11 = *(undefined8 *)(in_RCX + 0x148);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bee1;
    uVar7 = fcn.180222950(uVar11);
    if ((int32_t)uVar7 == 0) {
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    if ((*puVar14 & 0x100) != 0) {
        uVar11 = *(undefined8 *)(in_RCX + 0x148);
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf0c;
        fcn.180222910(uVar11);
        return (uint64_t)(~(*puVar14 >> 7) & 1);
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf36;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf3b;
    fcn.18020e860();
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf50;
    iVar2 = fcn.180240450(*(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                          *(int64_t *)(&stack0x00000040 + iVar6));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x100000;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf6e;
    iVar2 = fcn.180237590(in_RCX);
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x40;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    uVar4 = 0xffffffff;
    *(undefined4 *)(in_RCX + 0xd0) = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bfa2;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if (*piVar8 != 0) {
            *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x10;
        }
        puVar13 = (uint32_t *)(in_RCX + 0xd8);
        if (*(int64_t *)(piVar8 + 2) != 0) {
            if (*(int32_t *)(*(int64_t *)(piVar8 + 2) + 4) == 0x102) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bfd9;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bff1;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c003;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
                *puVar14 = *puVar14 | 0x80;
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c011;
                fcn.1802ac5d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
                *puVar13 = *puVar13 | 1;
                goto code_r0x00018023c03d;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c01b;
            uVar3 = fcn.18025fde0(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
            *(undefined4 *)(in_RCX + 0xd0) = uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c029;
        fcn.1802ac5d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
        *puVar13 = *puVar13 | 1;
    }
code_r0x00018023c03d:
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c051;
    piVar9 = (int64_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar9 == (int64_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if ((*(uint8_t *)puVar14 & 0x10) == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c06e;
            iVar2 = fcn.180239480(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (-1 < iVar2) goto code_r0x00018023c086;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c082;
            iVar2 = fcn.180239480(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (-1 < iVar2) goto code_r0x00018023c086;
        } else {
code_r0x00018023c086:
            *puVar14 = *puVar14 | 0x80;
        }
        if (*piVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0a0;
            uVar4 = fcn.18025fde0(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
        }
        *(undefined4 *)(in_RCX + 0xd4) = uVar4;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0b2;
        fcn.1802ac3b0(piVar9);
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x400;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0da;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h == -1) goto code_r0x00018023c178;
    } else {
        *(undefined4 *)(in_RCX + 0xdc) = 0;
        if (0 < *piVar8) {
            uVar1 = **(uint8_t **)(piVar8 + 2);
            *(uint32_t *)(in_RCX + 0xdc) = (uint32_t)uVar1;
            if (1 < *piVar8) {
                *(uint32_t *)(in_RCX + 0xdc) = (uint32_t)CONCAT11(*(undefined *)(*(int64_t *)(piVar8 + 2) + 1), uVar1);
            }
        }
        *puVar14 = *puVar14 | 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c132;
        fcn.180228780(*(int64_t *)(&stack0x00000038 + iVar6));
        if (*(int32_t *)(in_RCX + 0xdc) != 0) goto code_r0x00018023c178;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c140;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c158;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)(&stack0x00000040 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c16a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    }
    *puVar14 = *puVar14 | 0x80;
code_r0x00018023c178:
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined4 *)(in_RCX + 0xe0) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c193;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (iVar10 == 0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        *puVar14 = *puVar14 | 4;
        var_8h._0_4_ = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1ae;
        iVar2 = fcn.180222010(iVar10);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1ca;
                fcn.180222340(iVar10, (int32_t)var_8h);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1d2;
                iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                      *(int64_t *)(&stack0x00000058 + iVar6));
                if (iVar2 < 0xb5) {
                    if (iVar2 == 0xb4) {
                        *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x20;
                    } else {
    // switch table (11 cases) at 0x18023c614
                        switch(iVar2) {
                        case 0x81:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 1;
                            break;
                        case 0x82:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 2;
                            break;
                        case 0x83:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 8;
                            break;
                        case 0x84:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 4;
                            break;
                        case 0x85:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x40;
                            break;
                        case 0x89:
                        case 0x8b:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x10;
                        }
                    }
                } else if (iVar2 == 0x129) {
                    *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x80;
                } else if (iVar2 == 0x38e) {
                    *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x100;
                }
                var_8h._0_4_ = (int32_t)var_8h + 1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c261;
                iVar2 = fcn.180222010(iVar10);
            } while ((int32_t)var_8h < iVar2);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c282;
        fcn.180222050(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2a4;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if (*piVar8 < 1) {
            uVar12 = 0;
        } else {
            uVar12 = (uint32_t)**(uint8_t **)(piVar8 + 2);
        }
        *(uint32_t *)(in_RCX + 0xe4) = uVar12;
        *puVar14 = *puVar14 | 8;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2cb;
        fcn.180228780(*(int64_t *)(&stack0x00000038 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2f7;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0xe8) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c32d;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0xf0) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c356;
    fcn.1801e3990(in_RCX);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c361;
    fcn.180238460(in_RCX);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c36c;
    iVar2 = fcn.1802378e0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x20;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c382;
        iVar2 = fcn.18023b870(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6));
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c38e;
            fcn.180238400(in_RCX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c399;
            iVar2 = fcn.18023bc90(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8));
            if (iVar2 == 0) {
                *puVar14 = *puVar14 | 0x2000;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c3be;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x108) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c3f4;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x110) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c41b;
    iVar2 = fcn.18023c6b0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c445;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x118) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c477;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x120) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    var_8h._0_4_ = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c49b;
    iVar2 = fcn.1802394a0(in_RCX);
    if (0 < iVar2) {
        do {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4ba;
            uVar11 = fcn.180239460(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4c5;
            fcn.18020e940(uVar11);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4cd;
            iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
            if (iVar2 == 0x359) {
                *puVar14 = *puVar14 | 0x1000;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4e4;
            iVar5 = fcn.1802ab4d0(uVar11);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4f0;
                fcn.18020e940(uVar11);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4f8;
                var_10h._0_4_ =
                     fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                   *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                   *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
                if ((int32_t)var_10h != 0) {
                    *(undefined8 *)((int64_t)&iStackX_18 + iVar6 + -8) = 0x18023bd90;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c520;
                    iVar10 = fcn.18022c840(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                                           *(int64_t *)(&stack0x00000048 + iVar6));
                    if (iVar10 != 0) {
                        if (iVar2 == 0x52) {
                            *puVar14 = *puVar14 | 0x40000;
                        } else if (iVar2 == 0x55) {
                            *puVar14 = *puVar14 | 0x80000;
                        } else if (iVar2 == 0x57) {
                            *puVar14 = *puVar14 | 0x10000;
                        } else if (iVar2 == 0x5a) {
                            *puVar14 = *puVar14 | 0x20000;
                        }
                        goto code_r0x00018023c557;
                    }
                }
                *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x200;
                break;
            }
code_r0x00018023c557:
            var_8h._0_4_ = (int32_t)var_8h + 1;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c562;
            iVar2 = fcn.1802394a0(in_RCX);
        } while ((int32_t)var_8h < iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c581;
    fcn.180237610(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                  *(int64_t *)(&stack0x00000078 + iVar6));
    *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x100;
    *(undefined4 *)(in_RCX + 0x150) = 1;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c59a;
    fcn.1802299d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
    uVar11 = *(undefined8 *)(in_RCX + 0x148);
    if ((*(uint8_t *)(in_RCX + 0xd8) & 0x80) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5be;
        fcn.180222910(uVar11);
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5d4;
    fcn.180222910(uVar11);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5d9;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5f1;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                  *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                  *(int64_t *)(&stack0x00000040 + iVar6));
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c603;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_18023c5b9
// Address: 0x18023c5b9
// Size: 22 bytes
// ============================================================
uint64_t fcn.18023bea0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    uint8_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    uint32_t *puVar13;
    uint32_t *puVar14;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18023beb0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(in_RCX + 0x150) != 0) {
        return (uint64_t)(~(*(uint32_t *)(in_RCX + 0xd8) >> 7) & 1);
    }
    uVar11 = *(undefined8 *)(in_RCX + 0x148);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bee1;
    uVar7 = fcn.180222950(uVar11);
    if ((int32_t)uVar7 == 0) {
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    if ((*puVar14 & 0x100) != 0) {
        uVar11 = *(undefined8 *)(in_RCX + 0x148);
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf0c;
        fcn.180222910(uVar11);
        return (uint64_t)(~(*puVar14 >> 7) & 1);
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf36;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf3b;
    fcn.18020e860();
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf50;
    iVar2 = fcn.180240450(*(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                          *(int64_t *)(&stack0x00000040 + iVar6));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x100000;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf6e;
    iVar2 = fcn.180237590(in_RCX);
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x40;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    uVar4 = 0xffffffff;
    *(undefined4 *)(in_RCX + 0xd0) = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bfa2;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if (*piVar8 != 0) {
            *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x10;
        }
        puVar13 = (uint32_t *)(in_RCX + 0xd8);
        if (*(int64_t *)(piVar8 + 2) != 0) {
            if (*(int32_t *)(*(int64_t *)(piVar8 + 2) + 4) == 0x102) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bfd9;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bff1;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c003;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
                *puVar14 = *puVar14 | 0x80;
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c011;
                fcn.1802ac5d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
                *puVar13 = *puVar13 | 1;
                goto code_r0x00018023c03d;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c01b;
            uVar3 = fcn.18025fde0(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
            *(undefined4 *)(in_RCX + 0xd0) = uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c029;
        fcn.1802ac5d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
        *puVar13 = *puVar13 | 1;
    }
code_r0x00018023c03d:
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c051;
    piVar9 = (int64_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar9 == (int64_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if ((*(uint8_t *)puVar14 & 0x10) == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c06e;
            iVar2 = fcn.180239480(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (-1 < iVar2) goto code_r0x00018023c086;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c082;
            iVar2 = fcn.180239480(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (-1 < iVar2) goto code_r0x00018023c086;
        } else {
code_r0x00018023c086:
            *puVar14 = *puVar14 | 0x80;
        }
        if (*piVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0a0;
            uVar4 = fcn.18025fde0(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
        }
        *(undefined4 *)(in_RCX + 0xd4) = uVar4;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0b2;
        fcn.1802ac3b0(piVar9);
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x400;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0da;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h == -1) goto code_r0x00018023c178;
    } else {
        *(undefined4 *)(in_RCX + 0xdc) = 0;
        if (0 < *piVar8) {
            uVar1 = **(uint8_t **)(piVar8 + 2);
            *(uint32_t *)(in_RCX + 0xdc) = (uint32_t)uVar1;
            if (1 < *piVar8) {
                *(uint32_t *)(in_RCX + 0xdc) = (uint32_t)CONCAT11(*(undefined *)(*(int64_t *)(piVar8 + 2) + 1), uVar1);
            }
        }
        *puVar14 = *puVar14 | 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c132;
        fcn.180228780(*(int64_t *)(&stack0x00000038 + iVar6));
        if (*(int32_t *)(in_RCX + 0xdc) != 0) goto code_r0x00018023c178;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c140;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c158;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)(&stack0x00000040 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c16a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    }
    *puVar14 = *puVar14 | 0x80;
code_r0x00018023c178:
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined4 *)(in_RCX + 0xe0) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c193;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (iVar10 == 0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        *puVar14 = *puVar14 | 4;
        var_8h._0_4_ = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1ae;
        iVar2 = fcn.180222010(iVar10);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1ca;
                fcn.180222340(iVar10, (int32_t)var_8h);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1d2;
                iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                      *(int64_t *)(&stack0x00000058 + iVar6));
                if (iVar2 < 0xb5) {
                    if (iVar2 == 0xb4) {
                        *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x20;
                    } else {
    // switch table (11 cases) at 0x18023c614
                        switch(iVar2) {
                        case 0x81:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 1;
                            break;
                        case 0x82:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 2;
                            break;
                        case 0x83:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 8;
                            break;
                        case 0x84:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 4;
                            break;
                        case 0x85:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x40;
                            break;
                        case 0x89:
                        case 0x8b:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x10;
                        }
                    }
                } else if (iVar2 == 0x129) {
                    *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x80;
                } else if (iVar2 == 0x38e) {
                    *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x100;
                }
                var_8h._0_4_ = (int32_t)var_8h + 1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c261;
                iVar2 = fcn.180222010(iVar10);
            } while ((int32_t)var_8h < iVar2);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c282;
        fcn.180222050(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2a4;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if (*piVar8 < 1) {
            uVar12 = 0;
        } else {
            uVar12 = (uint32_t)**(uint8_t **)(piVar8 + 2);
        }
        *(uint32_t *)(in_RCX + 0xe4) = uVar12;
        *puVar14 = *puVar14 | 8;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2cb;
        fcn.180228780(*(int64_t *)(&stack0x00000038 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2f7;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0xe8) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c32d;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0xf0) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c356;
    fcn.1801e3990(in_RCX);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c361;
    fcn.180238460(in_RCX);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c36c;
    iVar2 = fcn.1802378e0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x20;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c382;
        iVar2 = fcn.18023b870(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6));
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c38e;
            fcn.180238400(in_RCX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c399;
            iVar2 = fcn.18023bc90(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8));
            if (iVar2 == 0) {
                *puVar14 = *puVar14 | 0x2000;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c3be;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x108) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c3f4;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x110) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c41b;
    iVar2 = fcn.18023c6b0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c445;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x118) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c477;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x120) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    var_8h._0_4_ = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c49b;
    iVar2 = fcn.1802394a0(in_RCX);
    if (0 < iVar2) {
        do {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4ba;
            uVar11 = fcn.180239460(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4c5;
            fcn.18020e940(uVar11);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4cd;
            iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
            if (iVar2 == 0x359) {
                *puVar14 = *puVar14 | 0x1000;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4e4;
            iVar5 = fcn.1802ab4d0(uVar11);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4f0;
                fcn.18020e940(uVar11);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4f8;
                var_10h._0_4_ =
                     fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                   *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                   *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
                if ((int32_t)var_10h != 0) {
                    *(undefined8 *)((int64_t)&iStackX_18 + iVar6 + -8) = 0x18023bd90;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c520;
                    iVar10 = fcn.18022c840(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                                           *(int64_t *)(&stack0x00000048 + iVar6));
                    if (iVar10 != 0) {
                        if (iVar2 == 0x52) {
                            *puVar14 = *puVar14 | 0x40000;
                        } else if (iVar2 == 0x55) {
                            *puVar14 = *puVar14 | 0x80000;
                        } else if (iVar2 == 0x57) {
                            *puVar14 = *puVar14 | 0x10000;
                        } else if (iVar2 == 0x5a) {
                            *puVar14 = *puVar14 | 0x20000;
                        }
                        goto code_r0x00018023c557;
                    }
                }
                *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x200;
                break;
            }
code_r0x00018023c557:
            var_8h._0_4_ = (int32_t)var_8h + 1;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c562;
            iVar2 = fcn.1802394a0(in_RCX);
        } while ((int32_t)var_8h < iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c581;
    fcn.180237610(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                  *(int64_t *)(&stack0x00000078 + iVar6));
    *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x100;
    *(undefined4 *)(in_RCX + 0x150) = 1;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c59a;
    fcn.1802299d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
    uVar11 = *(undefined8 *)(in_RCX + 0x148);
    if ((*(uint8_t *)(in_RCX + 0xd8) & 0x80) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5be;
        fcn.180222910(uVar11);
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5d4;
    fcn.180222910(uVar11);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5d9;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5f1;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                  *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                  *(int64_t *)(&stack0x00000040 + iVar6));
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c603;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_18023c5cf
// Address: 0x18023c5cf
// Size: 69 bytes
// ============================================================
uint64_t fcn.18023bea0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    uint8_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int32_t *piVar8;
    int64_t *piVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    uint32_t *puVar13;
    uint32_t *puVar14;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18023beb0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(in_RCX + 0x150) != 0) {
        return (uint64_t)(~(*(uint32_t *)(in_RCX + 0xd8) >> 7) & 1);
    }
    uVar11 = *(undefined8 *)(in_RCX + 0x148);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bee1;
    uVar7 = fcn.180222950(uVar11);
    if ((int32_t)uVar7 == 0) {
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    if ((*puVar14 & 0x100) != 0) {
        uVar11 = *(undefined8 *)(in_RCX + 0x148);
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf0c;
        fcn.180222910(uVar11);
        return (uint64_t)(~(*puVar14 >> 7) & 1);
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf36;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf3b;
    fcn.18020e860();
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf50;
    iVar2 = fcn.180240450(*(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                          *(int64_t *)(&stack0x00000040 + iVar6));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x100000;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bf6e;
    iVar2 = fcn.180237590(in_RCX);
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x40;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    uVar4 = 0xffffffff;
    *(undefined4 *)(in_RCX + 0xd0) = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bfa2;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if (*piVar8 != 0) {
            *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x10;
        }
        puVar13 = (uint32_t *)(in_RCX + 0xd8);
        if (*(int64_t *)(piVar8 + 2) != 0) {
            if (*(int32_t *)(*(int64_t *)(piVar8 + 2) + 4) == 0x102) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bfd9;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023bff1;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c003;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
                *puVar14 = *puVar14 | 0x80;
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c011;
                fcn.1802ac5d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
                *puVar13 = *puVar13 | 1;
                goto code_r0x00018023c03d;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c01b;
            uVar3 = fcn.18025fde0(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
            *(undefined4 *)(in_RCX + 0xd0) = uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c029;
        fcn.1802ac5d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
        *puVar13 = *puVar13 | 1;
    }
code_r0x00018023c03d:
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c051;
    piVar9 = (int64_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar9 == (int64_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if ((*(uint8_t *)puVar14 & 0x10) == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c06e;
            iVar2 = fcn.180239480(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (-1 < iVar2) goto code_r0x00018023c086;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c082;
            iVar2 = fcn.180239480(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
            if (-1 < iVar2) goto code_r0x00018023c086;
        } else {
code_r0x00018023c086:
            *puVar14 = *puVar14 | 0x80;
        }
        if (*piVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0a0;
            uVar4 = fcn.18025fde0(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
        }
        *(undefined4 *)(in_RCX + 0xd4) = uVar4;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0b2;
        fcn.1802ac3b0(piVar9);
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x400;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c0da;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h == -1) goto code_r0x00018023c178;
    } else {
        *(undefined4 *)(in_RCX + 0xdc) = 0;
        if (0 < *piVar8) {
            uVar1 = **(uint8_t **)(piVar8 + 2);
            *(uint32_t *)(in_RCX + 0xdc) = (uint32_t)uVar1;
            if (1 < *piVar8) {
                *(uint32_t *)(in_RCX + 0xdc) = (uint32_t)CONCAT11(*(undefined *)(*(int64_t *)(piVar8 + 2) + 1), uVar1);
            }
        }
        *puVar14 = *puVar14 | 2;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c132;
        fcn.180228780(*(int64_t *)(&stack0x00000038 + iVar6));
        if (*(int32_t *)(in_RCX + 0xdc) != 0) goto code_r0x00018023c178;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c140;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c158;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)(&stack0x00000040 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c16a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    }
    *puVar14 = *puVar14 | 0x80;
code_r0x00018023c178:
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined4 *)(in_RCX + 0xe0) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c193;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (iVar10 == 0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        *puVar14 = *puVar14 | 4;
        var_8h._0_4_ = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1ae;
        iVar2 = fcn.180222010(iVar10);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1ca;
                fcn.180222340(iVar10, (int32_t)var_8h);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c1d2;
                iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                      *(int64_t *)(&stack0x00000058 + iVar6));
                if (iVar2 < 0xb5) {
                    if (iVar2 == 0xb4) {
                        *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x20;
                    } else {
    // switch table (11 cases) at 0x18023c614
                        switch(iVar2) {
                        case 0x81:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 1;
                            break;
                        case 0x82:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 2;
                            break;
                        case 0x83:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 8;
                            break;
                        case 0x84:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 4;
                            break;
                        case 0x85:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x40;
                            break;
                        case 0x89:
                        case 0x8b:
                            *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x10;
                        }
                    }
                } else if (iVar2 == 0x129) {
                    *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x80;
                } else if (iVar2 == 0x38e) {
                    *(uint32_t *)(in_RCX + 0xe0) = *(uint32_t *)(in_RCX + 0xe0) | 0x100;
                }
                var_8h._0_4_ = (int32_t)var_8h + 1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c261;
                iVar2 = fcn.180222010(iVar10);
            } while ((int32_t)var_8h < iVar2);
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c282;
        fcn.180222050(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2a4;
    piVar8 = (int32_t *)
             fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    if (piVar8 == (int32_t *)0x0) {
        if ((int32_t)var_8h != -1) {
            *puVar14 = *puVar14 | 0x80;
        }
    } else {
        if (*piVar8 < 1) {
            uVar12 = 0;
        } else {
            uVar12 = (uint32_t)**(uint8_t **)(piVar8 + 2);
        }
        *(uint32_t *)(in_RCX + 0xe4) = uVar12;
        *puVar14 = *puVar14 | 8;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2cb;
        fcn.180228780(*(int64_t *)(&stack0x00000038 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c2f7;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0xe8) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c32d;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0xf0) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c356;
    fcn.1801e3990(in_RCX);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c361;
    fcn.180238460(in_RCX);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c36c;
    iVar2 = fcn.1802378e0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x20;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c382;
        iVar2 = fcn.18023b870(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6));
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c38e;
            fcn.180238400(in_RCX);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c399;
            iVar2 = fcn.18023bc90(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8));
            if (iVar2 == 0) {
                *puVar14 = *puVar14 | 0x2000;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c3be;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x108) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c3f4;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x110) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c41b;
    iVar2 = fcn.18023c6b0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
    if (iVar2 == 0) {
        *puVar14 = *puVar14 | 0x80;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c445;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x118) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    puVar14 = (uint32_t *)(in_RCX + 0xd8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c477;
    iVar10 = fcn.1802394c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                           *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                           *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                           *(int64_t *)(&stack0x00000050 + iVar6));
    *(int64_t *)(in_RCX + 0x120) = iVar10;
    if ((iVar10 == 0) && ((int32_t)var_8h != -1)) {
        *puVar14 = *puVar14 | 0x80;
    }
    var_8h._0_4_ = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c49b;
    iVar2 = fcn.1802394a0(in_RCX);
    if (0 < iVar2) {
        do {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4ba;
            uVar11 = fcn.180239460(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4c5;
            fcn.18020e940(uVar11);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4cd;
            iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
            if (iVar2 == 0x359) {
                *puVar14 = *puVar14 | 0x1000;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4e4;
            iVar5 = fcn.1802ab4d0(uVar11);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4f0;
                fcn.18020e940(uVar11);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c4f8;
                var_10h._0_4_ =
                     fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                   *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000038 + iVar6), 
                                   *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
                if ((int32_t)var_10h != 0) {
                    *(undefined8 *)((int64_t)&iStackX_18 + iVar6 + -8) = 0x18023bd90;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c520;
                    iVar10 = fcn.18022c840(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                                           *(int64_t *)(&stack0x00000048 + iVar6));
                    if (iVar10 != 0) {
                        if (iVar2 == 0x52) {
                            *puVar14 = *puVar14 | 0x40000;
                        } else if (iVar2 == 0x55) {
                            *puVar14 = *puVar14 | 0x80000;
                        } else if (iVar2 == 0x57) {
                            *puVar14 = *puVar14 | 0x10000;
                        } else if (iVar2 == 0x5a) {
                            *puVar14 = *puVar14 | 0x20000;
                        }
                        goto code_r0x00018023c557;
                    }
                }
                *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x200;
                break;
            }
code_r0x00018023c557:
            var_8h._0_4_ = (int32_t)var_8h + 1;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c562;
            iVar2 = fcn.1802394a0(in_RCX);
        } while ((int32_t)var_8h < iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c581;
    fcn.180237610(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                  *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                  *(int64_t *)(&stack0x00000078 + iVar6));
    *(uint32_t *)(in_RCX + 0xd8) = *(uint32_t *)(in_RCX + 0xd8) | 0x100;
    *(undefined4 *)(in_RCX + 0x150) = 1;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c59a;
    fcn.1802299d0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
    uVar11 = *(undefined8 *)(in_RCX + 0x148);
    if ((*(uint8_t *)(in_RCX + 0xd8) & 0x80) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5be;
        fcn.180222910(uVar11);
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5d4;
    fcn.180222910(uVar11);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5d9;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c5f1;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                  *(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                  *(int64_t *)(&stack0x00000040 + iVar6));
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x18023c603;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_18023c614
// Address: 0x18023c614
// Size: 44 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18023c640
// Address: 0x18023c640
// Size: 112 bytes
// ============================================================
uint64_t fcn.18023c640(int64_t param_1, int32_t param_2)
{
    int64_t iVar1;
    uint64_t uVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023c64a;
    iVar1 = fcn.18045a350();
    if (((*(uint32_t *)(param_1 + 0xd8) & 4) != 0) && ((*(uint8_t *)(param_1 + 0xe0) & 4) == 0)) {
        return 0;
    }
    if (param_2 == 0) {
        if (((*(uint32_t *)(param_1 + 0xd8) & 8) != 0) && ((*(uint32_t *)(param_1 + 0xe4) & 0x20) == 0)) {
            return (uint64_t)(*(uint32_t *)(param_1 + 0xe4) >> 6 & 2);
        }
        uVar2 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18023c669;
        uVar2 = fcn.18023bc30();
        if ((int32_t)uVar2 == 0) {
            return 0;
        }
        if ((int32_t)uVar2 == 5) {
            uVar2 = uVar2 & 0xffffffff;
            if ((*(uint8_t *)(param_1 + 0xe4) & 2) == 0) {
                uVar2 = 0;
            }
            return uVar2;
        }
    }
    return uVar2;
}

// ============================================================
// Function: FUN_18023c6b0
// Address: 0x18023c6b0
// Size: 61 bytes
// ============================================================
undefined8 fcn.18023c6b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t **ppiVar6;
    int32_t *piVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023c6bc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c6d4;
    iVar5 = fcn.1802394c0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4), *(int64_t *)(&stack0x00000050 + iVar4), 
                          *(int64_t *)(&stack0x00000058 + iVar4));
    *(int64_t *)(in_RCX + 0x100) = iVar5;
    if ((iVar5 == 0) && (*(int32_t *)((int64_t)&arg_28h + iVar4) != -1)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RDI;
    *(undefined4 *)((int64_t)&arg_28h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c70c;
    iVar2 = fcn.180222010(iVar5);
    iVar3 = *(int32_t *)((int64_t)&arg_28h + iVar4);
    if (iVar3 < iVar2) {
        do {
            uVar1 = *(undefined8 *)(in_RCX + 0x100);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c72e;
            ppiVar6 = (int32_t **)fcn.180222340(uVar1, iVar3);
            if (*ppiVar6 == (int32_t *)0x0) {
                piVar7 = ppiVar6[2];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c740;
                iVar3 = fcn.180222010(piVar7);
                if (iVar3 < 1) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c821;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c839;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)(&stack0x00000048 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c84b;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    return 0;
                }
            }
            piVar7 = ppiVar6[1];
            if (piVar7 == (int32_t *)0x0) {
                *(undefined4 *)(ppiVar6 + 3) = 0x807f;
            } else {
                if (0 < *piVar7) {
                    *(uint32_t *)(ppiVar6 + 3) = (uint32_t)**(uint8_t **)(piVar7 + 2);
                }
                if (1 < *piVar7) {
                    *(uint32_t *)(ppiVar6 + 3) =
                         *(uint32_t *)(ppiVar6 + 3) | (uint32_t)*(uint8_t *)(*(int64_t *)(piVar7 + 2) + 1) << 8;
                }
                *(uint32_t *)(ppiVar6 + 3) = *(uint32_t *)(ppiVar6 + 3) & 0x807f;
            }
            if ((*ppiVar6 != (int32_t *)0x0) && (**ppiVar6 == 1)) {
                piVar7 = ppiVar6[2];
                iVar2 = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c799;
                iVar3 = fcn.180222010(piVar7);
                if (0 < iVar3) {
                    do {
                        piVar7 = ppiVar6[2];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7ab;
                        piVar7 = (int32_t *)fcn.180222340(piVar7, iVar2);
                        if (*piVar7 == 4) {
                            if (*(int64_t *)(piVar7 + 2) != 0) goto code_r0x00018023c7d2;
                            break;
                        }
                        piVar7 = ppiVar6[2];
                        iVar2 = iVar2 + 1;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7bb;
                        iVar3 = fcn.180222010(piVar7);
                    } while (iVar2 < iVar3);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7d2;
                fcn.1801e3990(in_RCX);
code_r0x00018023c7d2:
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7dd;
                iVar3 = fcn.1802903b0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                if (iVar3 == 0) {
                    return 0xffffffff;
                }
            }
            uVar1 = *(undefined8 *)(in_RCX + 0x100);
            *(int32_t *)((int64_t)&arg_28h + iVar4) = *(int32_t *)((int64_t)&arg_28h + iVar4) + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7f9;
            iVar2 = fcn.180222010(uVar1);
            iVar3 = *(int32_t *)((int64_t)&arg_28h + iVar4);
        } while (iVar3 < iVar2);
    }
    return 1;
}

// ============================================================
// Function: FUN_18023c6ed
// Address: 0x18023c6ed
// Size: 303 bytes
// ============================================================
undefined8 fcn.18023c6b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t **ppiVar6;
    int32_t *piVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023c6bc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c6d4;
    iVar5 = fcn.1802394c0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4), *(int64_t *)(&stack0x00000050 + iVar4), 
                          *(int64_t *)(&stack0x00000058 + iVar4));
    *(int64_t *)(in_RCX + 0x100) = iVar5;
    if ((iVar5 == 0) && (*(int32_t *)((int64_t)&arg_28h + iVar4) != -1)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RDI;
    *(undefined4 *)((int64_t)&arg_28h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c70c;
    iVar2 = fcn.180222010(iVar5);
    iVar3 = *(int32_t *)((int64_t)&arg_28h + iVar4);
    if (iVar3 < iVar2) {
        do {
            uVar1 = *(undefined8 *)(in_RCX + 0x100);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c72e;
            ppiVar6 = (int32_t **)fcn.180222340(uVar1, iVar3);
            if (*ppiVar6 == (int32_t *)0x0) {
                piVar7 = ppiVar6[2];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c740;
                iVar3 = fcn.180222010(piVar7);
                if (iVar3 < 1) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c821;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c839;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)(&stack0x00000048 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c84b;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    return 0;
                }
            }
            piVar7 = ppiVar6[1];
            if (piVar7 == (int32_t *)0x0) {
                *(undefined4 *)(ppiVar6 + 3) = 0x807f;
            } else {
                if (0 < *piVar7) {
                    *(uint32_t *)(ppiVar6 + 3) = (uint32_t)**(uint8_t **)(piVar7 + 2);
                }
                if (1 < *piVar7) {
                    *(uint32_t *)(ppiVar6 + 3) =
                         *(uint32_t *)(ppiVar6 + 3) | (uint32_t)*(uint8_t *)(*(int64_t *)(piVar7 + 2) + 1) << 8;
                }
                *(uint32_t *)(ppiVar6 + 3) = *(uint32_t *)(ppiVar6 + 3) & 0x807f;
            }
            if ((*ppiVar6 != (int32_t *)0x0) && (**ppiVar6 == 1)) {
                piVar7 = ppiVar6[2];
                iVar2 = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c799;
                iVar3 = fcn.180222010(piVar7);
                if (0 < iVar3) {
                    do {
                        piVar7 = ppiVar6[2];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7ab;
                        piVar7 = (int32_t *)fcn.180222340(piVar7, iVar2);
                        if (*piVar7 == 4) {
                            if (*(int64_t *)(piVar7 + 2) != 0) goto code_r0x00018023c7d2;
                            break;
                        }
                        piVar7 = ppiVar6[2];
                        iVar2 = iVar2 + 1;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7bb;
                        iVar3 = fcn.180222010(piVar7);
                    } while (iVar2 < iVar3);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7d2;
                fcn.1801e3990(in_RCX);
code_r0x00018023c7d2:
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7dd;
                iVar3 = fcn.1802903b0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                if (iVar3 == 0) {
                    return 0xffffffff;
                }
            }
            uVar1 = *(undefined8 *)(in_RCX + 0x100);
            *(int32_t *)((int64_t)&arg_28h + iVar4) = *(int32_t *)((int64_t)&arg_28h + iVar4) + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7f9;
            iVar2 = fcn.180222010(uVar1);
            iVar3 = *(int32_t *)((int64_t)&arg_28h + iVar4);
        } while (iVar3 < iVar2);
    }
    return 1;
}

// ============================================================
// Function: FUN_18023c81c
// Address: 0x18023c81c
// Size: 53 bytes
// ============================================================
undefined8 fcn.18023c6b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t **ppiVar6;
    int32_t *piVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023c6bc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c6d4;
    iVar5 = fcn.1802394c0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4), *(int64_t *)(&stack0x00000050 + iVar4), 
                          *(int64_t *)(&stack0x00000058 + iVar4));
    *(int64_t *)(in_RCX + 0x100) = iVar5;
    if ((iVar5 == 0) && (*(int32_t *)((int64_t)&arg_28h + iVar4) != -1)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RDI;
    *(undefined4 *)((int64_t)&arg_28h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c70c;
    iVar2 = fcn.180222010(iVar5);
    iVar3 = *(int32_t *)((int64_t)&arg_28h + iVar4);
    if (iVar3 < iVar2) {
        do {
            uVar1 = *(undefined8 *)(in_RCX + 0x100);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c72e;
            ppiVar6 = (int32_t **)fcn.180222340(uVar1, iVar3);
            if (*ppiVar6 == (int32_t *)0x0) {
                piVar7 = ppiVar6[2];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c740;
                iVar3 = fcn.180222010(piVar7);
                if (iVar3 < 1) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c821;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c839;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)(&stack0x00000048 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c84b;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    return 0;
                }
            }
            piVar7 = ppiVar6[1];
            if (piVar7 == (int32_t *)0x0) {
                *(undefined4 *)(ppiVar6 + 3) = 0x807f;
            } else {
                if (0 < *piVar7) {
                    *(uint32_t *)(ppiVar6 + 3) = (uint32_t)**(uint8_t **)(piVar7 + 2);
                }
                if (1 < *piVar7) {
                    *(uint32_t *)(ppiVar6 + 3) =
                         *(uint32_t *)(ppiVar6 + 3) | (uint32_t)*(uint8_t *)(*(int64_t *)(piVar7 + 2) + 1) << 8;
                }
                *(uint32_t *)(ppiVar6 + 3) = *(uint32_t *)(ppiVar6 + 3) & 0x807f;
            }
            if ((*ppiVar6 != (int32_t *)0x0) && (**ppiVar6 == 1)) {
                piVar7 = ppiVar6[2];
                iVar2 = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c799;
                iVar3 = fcn.180222010(piVar7);
                if (0 < iVar3) {
                    do {
                        piVar7 = ppiVar6[2];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7ab;
                        piVar7 = (int32_t *)fcn.180222340(piVar7, iVar2);
                        if (*piVar7 == 4) {
                            if (*(int64_t *)(piVar7 + 2) != 0) goto code_r0x00018023c7d2;
                            break;
                        }
                        piVar7 = ppiVar6[2];
                        iVar2 = iVar2 + 1;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7bb;
                        iVar3 = fcn.180222010(piVar7);
                    } while (iVar2 < iVar3);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7d2;
                fcn.1801e3990(in_RCX);
code_r0x00018023c7d2:
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7dd;
                iVar3 = fcn.1802903b0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
                if (iVar3 == 0) {
                    return 0xffffffff;
                }
            }
            uVar1 = *(undefined8 *)(in_RCX + 0x100);
            *(int32_t *)((int64_t)&arg_28h + iVar4) = *(int32_t *)((int64_t)&arg_28h + iVar4) + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c7f9;
            iVar2 = fcn.180222010(uVar1);
            iVar3 = *(int32_t *)((int64_t)&arg_28h + iVar4);
        } while (iVar3 < iVar2);
    }
    return 1;
}

// ============================================================
// Function: FUN_18023c860
// Address: 0x18023c860
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_6h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.18023c860(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int32_t iVar4;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023c87a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar4 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023c890;
    iVar1 = fcn.180222010(in_RDX);
    if (0 < iVar1) {
        do {
            if (0 < iVar4) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023c8a7;
                func_0x00018021a9d0(in_RCX, 0x1805ab2a0);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023c8c1;
            func_0x000180245e70(in_RCX, 0x18064534c, in_R8D + 2, 0x1805aadb1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023c8cb;
            uVar3 = fcn.180222340(in_RDX, iVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023c8d6;
            func_0x0001802acff0(in_RCX, uVar3);
            iVar4 = iVar4 + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023c8e0;
            iVar1 = fcn.180222010(in_RDX);
        } while (iVar4 < iVar1);
    }
    return 1;
}

// ============================================================
// Function: FUN_18023c900
// Address: 0x18023c900
// Size: 266 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18023c900(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint8_t *puVar7;
    int32_t iVar8;
    uint64_t in_R8;
    uint8_t *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023c920;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
code_r0x00018023c9ed:
        uVar6 = 0;
    } else {
        iVar8 = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c93f;
        iVar3 = fcn.180222010(in_RDX);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c95b;
                iVar5 = fcn.180222340(in_RDX, iVar8);
                puVar9 = *(uint8_t **)(iVar5 + 8);
                uVar2 = *puVar9;
                puVar7 = puVar9;
                while (uVar2 != 0) {
                    if ((uVar2 < 0x3b) && ((0x400500000000000U >> ((uint64_t)uVar2 & 0x3f) & 1) != 0)) {
                        if (puVar7[1] != 0) {
                            puVar9 = puVar7 + 1;
                        }
                        break;
                    }
                    puVar1 = puVar7 + 1;
                    puVar7 = puVar7 + 1;
                    uVar2 = *puVar1;
                }
                uVar2 = *puVar9;
                if (uVar2 == 0x2b) {
                    puVar9 = puVar9 + 1;
                }
                uVar6 = *(undefined8 *)(iVar5 + 0x10);
                *(uint32_t *)((int64_t)&arg_28h + iVar4) = (uVar2 != 0x2b) - 1;
                *(undefined4 *)((int64_t)&var_20h + iVar4) = 0xffffffff;
                *(undefined4 *)((int64_t)&var_18h + iVar4) = 0xffffffff;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c9d0;
                iVar3 = func_0x0001802ac8d0(in_RCX, puVar9, in_R8 & 0xffffffff, uVar6);
                if (iVar3 == 0) goto code_r0x00018023c9ed;
                iVar8 = iVar8 + 1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023c9de;
                iVar3 = fcn.180222010(in_RDX);
            } while (iVar8 < iVar3);
        }
        uVar6 = 1;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18023ca10
// Address: 0x18023ca10
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.18023ca10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int64_t *in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023ca25;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == 0) {
        uVar5 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023ca3e;
        uVar5 = func_0x000180498cd0(in_RDX);
    }
    uVar1 = *(undefined8 *)((int64_t)&arg_30h + iVar4);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = uVar1;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = *(undefined8 *)((int64_t)auStackX_18 + iVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + -0x18) = 0x18023eb14;
    iVar6 = fcn.18045a350(in_RCX, in_RDX, uVar5);
    iVar6 = -iVar6;
    iVar2 = *in_R8;
    puVar10 = (undefined8 *)0x0;
    iVar7 = 0;
    iVar9 = 0;
    if (in_RCX == 0) {
code_r0x00018023eb4e:
        if (in_RDX != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023eb60;
            iVar8 = func_0x000180498a80(in_RDX, 0, uVar5);
            if (iVar8 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023eb81;
                iVar9 = func_0x000180223270(in_RDX, uVar5, 0x1804e2fa0, 0x35);
                if (iVar9 != 0) goto code_r0x00018023eb8d;
            }
            goto code_r0x00018023ec14;
        }
code_r0x00018023eb8d:
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023eba4;
        puVar10 = (undefined8 *)
                  fcn.1802248d0(*(int64_t *)((int64_t)&arg_28h + iVar6 + iVar4), 
                                *(int64_t *)((int64_t)&arg_30h + iVar6 + iVar4));
        if (puVar10 == (undefined8 *)0x0) goto code_r0x00018023ec14;
        if (iVar2 != 0) {
code_r0x00018023ebef:
            *puVar10 = 0;
            puVar10[1] = iVar7;
            puVar10[2] = iVar9;
            iVar8 = *in_R8;
            *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023ec09;
            iVar3 = func_0x000180222110(iVar8, puVar10);
            if (iVar3 != 0) {
                return 1;
            }
            goto code_r0x00018023ec14;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023ebb6;
        iVar8 = func_0x000180221f20();
        *in_R8 = iVar8;
        if (iVar8 != 0) goto code_r0x00018023ebef;
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023ebc3;
        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar6 + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar6 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023ebdb;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar6 + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar6 + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar4), 
                      *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023ebed;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar6 + iVar4));
    } else {
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023eb42;
        iVar7 = func_0x0001802231e0();
        if (iVar7 != 0) goto code_r0x00018023eb4e;
code_r0x00018023ec14:
        if (iVar2 != 0) goto code_r0x00018023ec28;
    }
    iVar2 = *in_R8;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023ec21;
    func_0x000180221d50(iVar2);
    *in_R8 = 0;
code_r0x00018023ec28:
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023ec3d;
    fcn.180224990(puVar10, 0x1804e2fa0, 0x4a);
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023ec52;
    fcn.180224990(iVar7, 0x1804e2fa0, 0x4b);
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4 + -0x18) = 0x18023ec67;
    fcn.180224990(iVar9, 0x1804e2fa0, 0x4c);
    return 0;
}

// ============================================================
// Function: FUN_18023ca70
// Address: 0x18023ca70
// Size: 64 bytes
// ============================================================
undefined8 fcn.18023ca70(int64_t param_1, int32_t param_2, int64_t *param_3)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar10;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_2 == 0) {
        uVar10 = 5;
        iVar9 = 0x1804e2fd8;
    } else {
        uVar10 = 4;
        iVar9 = 0x1804e2fd0;
    }
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_RSI;
    *(undefined8 *)(&stack0x00000048 + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 0x18) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 0x10) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar3) = 0x18023eb14;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = *param_3;
    puVar8 = (undefined8 *)0x0;
    iVar5 = 0;
    iVar7 = 0;
    if (param_1 == 0) {
code_r0x00018023eb4e:
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023eb60;
            iVar6 = func_0x000180498a80(iVar9, 0, uVar10);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023eb81;
                iVar7 = func_0x000180223270(iVar9, uVar10, 0x1804e2fa0, 0x35);
                if (iVar7 != 0) goto code_r0x00018023eb8d;
            }
            goto code_r0x00018023ec14;
        }
code_r0x00018023eb8d:
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023eba4;
        puVar8 = (undefined8 *)
                 fcn.1802248d0(*(int64_t *)(&stack0x00000030 + iVar4 + iVar3), 
                               *(int64_t *)(&stack0x00000038 + iVar4 + iVar3));
        if (puVar8 == (undefined8 *)0x0) goto code_r0x00018023ec14;
        if (iVar1 != 0) {
code_r0x00018023ebef:
            *puVar8 = 0;
            puVar8[1] = iVar5;
            puVar8[2] = iVar7;
            iVar9 = *param_3;
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023ec09;
            iVar2 = func_0x000180222110(iVar9, puVar8);
            if (iVar2 != 0) {
                return 1;
            }
            goto code_r0x00018023ec14;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023ebb6;
        iVar9 = func_0x000180221f20();
        *param_3 = iVar9;
        if (iVar9 != 0) goto code_r0x00018023ebef;
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023ebc3;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar4 + iVar3), *(int64_t *)(&stack0x00000038 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023ebdb;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar4 + iVar3), *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023ebed;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
    } else {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023eb42;
        iVar5 = func_0x0001802231e0();
        if (iVar5 != 0) goto code_r0x00018023eb4e;
code_r0x00018023ec14:
        if (iVar1 != 0) goto code_r0x00018023ec28;
    }
    iVar9 = *param_3;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023ec21;
    func_0x000180221d50(iVar9);
    *param_3 = 0;
code_r0x00018023ec28:
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023ec3d;
    fcn.180224990(puVar8, 0x1804e2fa0, 0x4a);
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023ec52;
    fcn.180224990(iVar5, 0x1804e2fa0, 0x4b);
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar3) = 0x18023ec67;
    fcn.180224990(iVar7, 0x1804e2fa0, 0x4c);
    return 0;
}

// ============================================================
// Function: FUN_18023cab0
// Address: 0x18023cab0
// Size: 282 bytes
// ============================================================
undefined4 fcn.18023cab0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x18023cabd;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RDX == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -8) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18023cafd;
    iVar3 = fcn.18025ff60(*(int64_t *)((int64_t)&arg_38h + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18023cb1b;
        iVar4 = fcn.18023d9b0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2), 
                              *(int64_t *)((int64_t)&arg_40h + iVar2));
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18023cb78;
            fcn.180255290(iVar3);
            *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18023cb80;
            fcn.180498cd0(iVar4);
            *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18023cb91;
            uVar1 = fcn.18023eaf0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2)
                                  , *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2));
            *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18023cba8;
            fcn.180224990(iVar4, 0x1804e2fa0, 0x106);
            return uVar1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18023cb49;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2));
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18023cb57;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2), 
                  *(int64_t *)((int64_t)&arg_40h + iVar2));
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18023cb64;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar2));
    *(undefined8 *)((int64_t)&uStack_18 + iVar2) = 0x18023cb6c;
    fcn.180255290(iVar3);
    return 0;
}

// ============================================================
// Function: FUN_18023cbd0
// Address: 0x18023cbd0
// Size: 114 bytes
// ============================================================
void fcn.18023cbd0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18023cbe0;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar1 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023cbfc;
        fcn.180224990(uVar1, 0x1804e2fa0, 0x6c);
        uVar1 = *(undefined8 *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023cc12;
        fcn.180224990(uVar1, 0x1804e2fa0, 0x6d);
        uVar1 = *(undefined8 *)arg1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023cc27;
        fcn.180224990(uVar1, 0x1804e2fa0, 0x6e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023cc3c;
        fcn.180224990(arg1, 0x1804e2fa0, 0x6f);
    }
    return;
}

// ============================================================
// Function: FUN_18023cc50
// Address: 0x18023cc50
// Size: 451 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18023cc50(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined4 *in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023cc65;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = *(int64_t *)(in_RCX + 0x10);
    if (iVar1 == 0) {
code_r0x00018023cdad:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cdb2;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cdca;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cddc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar2 = *(undefined8 *)(in_RCX + 8);
        *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + -8) = *(undefined8 *)(in_RCX + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023ce01;
        func_0x000180220250(4, 0x1804e305c, uVar2, 0x1804e3050);
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cc8a;
    iVar3 = func_0x000180498f10(iVar1, 0x1804e2fd0);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cca1;
        iVar3 = func_0x000180498f10(iVar1, 0x1805ab294);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023ccb8;
            iVar3 = func_0x000180498f10(iVar1, 0x18063c188);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cccf;
                iVar3 = func_0x000180498f10(iVar1, 0x180640a18);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cce6;
                    iVar3 = func_0x000180498f10(iVar1, 0x1804e302c);
                    if (iVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023ccfd;
                        iVar3 = func_0x000180498f10(iVar1, 0x1804a7420);
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cd14;
                            iVar3 = func_0x000180498f10(iVar1, 0x1804e2fd8);
                            if (iVar3 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cd27;
                                iVar3 = func_0x000180498f10(iVar1, 0x1805ab28c);
                                if (iVar3 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cd3a;
                                    iVar3 = func_0x000180498f10(iVar1, 0x18064481c);
                                    if (iVar3 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cd4d;
                                        iVar3 = func_0x000180498f10(iVar1, 0x18063eaf0);
                                        if (iVar3 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cd60;
                                            iVar3 = func_0x000180498f10(iVar1, 0x1804e3030);
                                            if (iVar3 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18023cd73;
                                                iVar3 = func_0x000180498f10(iVar1, 0x1804e3034);
                                                if (iVar3 != 0) goto code_r0x00018023cdad;
                                            }
                                        }
                                    }
                                }
                            }
                            *in_RDX = 0;
                            return 1;
                        }
                    }
                }
            }
        }
    }
    *in_RDX = 0xff;
    return 1;
}

// ============================================================
// Function: FUN_18023ce20
// Address: 0x18023ce20
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18023ce20(int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023ce30;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023ce44;
    iVar2 = fcn.18023e720(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar1), 
                          *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1));
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&iStackX_20 + iVar1 + -8) = *(undefined8 *)(in_RCX + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023ce6e;
        fcn.180220250(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000070 + iVar1));
        return 0;
    }
    *in_RDX = iVar2;
    return 1;
}

// ============================================================
// Function: FUN_18023ce90
// Address: 0x18023ce90
// Size: 632 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18023ce90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    char *pcVar4;
    int64_t iVar5;
    char cVar6;
    char *pcVar7;
    char *pcVar8;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023cea8;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023cec6;
    pcVar4 = (char *)func_0x0001802231e0();
    if (pcVar4 == (char *)0x0) goto code_r0x00018023d04b;
    cVar6 = *pcVar4;
    iVar1 = 1;
    pcVar7 = pcVar4;
    pcVar8 = pcVar4;
    if (cVar6 == '\0') {
code_r0x00018023d0ac:
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023d0b4;
        iVar5 = func_0x00018023e8e0(pcVar8);
        if (iVar5 != 0) {
code_r0x00018023d0d7:
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023d0e1;
            iVar1 = fcn.18023eaf0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023d0fe;
                fcn.180224990(pcVar4, 0x1804e2fa0, 0x18c);
                return *(undefined8 *)((int64_t)&arg_30h + iVar3);
            }
            goto code_r0x00018023d04b;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023d0be;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar3));
code_r0x00018023d02d:
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023d039;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
    } else {
        do {
            if ((cVar6 == '\r') || (cVar6 == '\n')) break;
            if (iVar1 == 1) {
                if (cVar6 == ':') {
                    *pcVar7 = '\0';
                    iVar1 = 2;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023cf74;
                    iVar5 = func_0x00018023e8e0(pcVar8);
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023d021;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar3));
                        goto code_r0x00018023d02d;
                    }
                    pcVar8 = pcVar7 + 1;
                } else if (cVar6 == ',') {
                    *pcVar7 = '\0';
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023cf96;
                    iVar5 = func_0x00018023e8e0(pcVar8);
                    pcVar8 = pcVar7 + 1;
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023d08b;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar3));
                        goto code_r0x00018023d02d;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023cfb8;
                    iVar2 = fcn.18023eaf0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                          *(int64_t *)(&stack0x00000040 + iVar3));
                    if (iVar2 == 0) goto code_r0x00018023d04b;
                }
            } else if ((iVar1 == 2) && (cVar6 == ',')) {
                *pcVar7 = '\0';
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023cf28;
                iVar5 = func_0x00018023e8e0(pcVar8);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023cffd;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3));
                    goto code_r0x00018023d002;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023cf3c;
                fcn.180498cd0(iVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023cf4f;
                iVar1 = fcn.18023eaf0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3));
                if (iVar1 == 0) goto code_r0x00018023d04b;
                pcVar8 = pcVar7 + 1;
                iVar1 = 1;
            }
            cVar6 = pcVar7[1];
            pcVar7 = pcVar7 + 1;
        } while (cVar6 != '\0');
        if (iVar1 != 2) goto code_r0x00018023d0ac;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023cfe0;
        iVar5 = func_0x00018023e8e0(pcVar8);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023d0a1;
            fcn.180498cd0(iVar5);
            goto code_r0x00018023d0d7;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023cff1;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar3));
code_r0x00018023d002:
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023d015;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023d04b;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
code_r0x00018023d04b:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023d060;
    fcn.180224990(pcVar4, 0x1804e2fa0, 400);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18023d071;
    fcn.180222050(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                  *(int64_t *)(&stack0x00000040 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_18023d110
// Address: 0x18023d110
// Size: 90 bytes
// ============================================================
int32_t fcn.18023d110(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar8;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint64_t uVar9;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 uVar10;
    uint32_t uVar11;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18023d125;
    var_8h = arg1;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == 0) {
        return -2;
    }
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d14a;
        in_R8 = fcn.180498cd0();
    } else {
        uVar9 = in_R8 - 1;
        if (in_R8 < 2) {
            uVar9 = in_R8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d161;
        iVar5 = func_0x000180498a80(in_RDX, 0, uVar9);
        if (iVar5 != 0) {
            return -2;
        }
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R14;
    if ((1 < in_R8) && (*(char *)(in_RDX + -1 + in_R8) == '\0')) {
        in_R8 = in_R8 - 1;
    }
    iVar2 = 0;
    iVar3 = 0;
    uVar11 = (uint32_t)in_R9 & 0xffff7fff;
    *(undefined4 *)((int64_t)&arg_68h + iVar4) = 0;
    uVar10 = 0x16;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1b5;
        in_R8 = fcn.180498cd0(in_RDX);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1cb;
    iVar5 = fcn.1802394c0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
    if (iVar5 != 0) {
        iVar8 = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1dd;
        iVar1 = fcn.180222010(iVar5);
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1eb;
                piVar6 = (int32_t *)fcn.180222340(iVar5, iVar8);
                if (*piVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d334;
                    iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                          *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000048 + iVar4));
                    if ((iVar2 == 0x4b8) && (**(int32_t **)(*(int64_t *)(piVar6 + 2) + 8) == 0xc)) {
                        uVar7 = *(undefined8 *)(*(int32_t **)(*(int64_t *)(piVar6 + 2) + 8) + 2);
                        uVar10 = 0;
                        goto code_r0x00018023d357;
                    }
code_r0x00018023d204:
                    iVar2 = *(int32_t *)((int64_t)&arg_68h + iVar4);
                } else {
                    if (*piVar6 != 1) goto code_r0x00018023d204;
                    uVar7 = *(undefined8 *)(piVar6 + 2);
code_r0x00018023d357:
                    *(undefined8 *)((int64_t)&iStackX_18 + iVar4 + -8) = 0;
                    iVar2 = 1;
                    *(uint64_t *)((int64_t)&var_8h + iVar4) = in_R8;
                    *(undefined4 *)((int64_t)&arg_68h + iVar4) = 1;
                    *(int64_t *)(&stack0x00000000 + iVar4) = in_RDX;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d388;
                    iVar3 = func_0x00018023dac0(uVar7, uVar10, 0x18023dcd0, uVar11);
                    if (iVar3 != 0) break;
                }
                iVar8 = iVar8 + 1;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d215;
                iVar1 = fcn.180222010(iVar5);
            } while (iVar8 < iVar1);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d221;
        func_0x00018028f450(iVar5);
        if (iVar3 != 0) {
            return iVar3;
        }
        if ((iVar2 != 0) && ((in_R9 & 1) == 0)) {
            return 0;
        }
        arg1 = *(int64_t *)((int64_t)&arg_60h + iVar4);
    }
    if ((in_R9 & 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d251;
        uVar10 = fcn.180238460(arg1);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d267;
        for (iVar2 = func_0x0001802acaa0(uVar10, 0x30, 0xffffffff); -1 < iVar2;
            iVar2 = func_0x0001802acaa0(uVar10, 0x30, iVar2)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d27b;
            uVar7 = func_0x0001802aca50(uVar10, iVar2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d283;
            piVar6 = (int32_t *)func_0x000180247880(uVar7);
            if ((*(int64_t *)(piVar6 + 2) != 0) && (*piVar6 != 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d29f;
                iVar3 = func_0x0001802a7f60((int64_t)&arg_68h + iVar4, piVar6);
                if (iVar3 < 0) {
                    return -1;
                }
                *(uint32_t *)(&stack0x00000000 + iVar4) = uVar11;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d2c2;
                iVar3 = func_0x00018023dcd0(*(undefined8 *)((int64_t)&arg_68h + iVar4), (int64_t)iVar3, in_RDX, in_R8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d2de;
                fcn.180224990(*(undefined8 *)((int64_t)&arg_68h + iVar4), 0x1804e2fa0, 0x368);
                if (iVar3 != 0) {
                    return iVar3;
                }
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d2f2;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023d16a
// Address: 0x18023d16a
// Size: 440 bytes
// ============================================================
int32_t fcn.18023d110(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar8;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint64_t uVar9;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 uVar10;
    uint32_t uVar11;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18023d125;
    var_8h = arg1;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == 0) {
        return -2;
    }
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d14a;
        in_R8 = fcn.180498cd0();
    } else {
        uVar9 = in_R8 - 1;
        if (in_R8 < 2) {
            uVar9 = in_R8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d161;
        iVar5 = func_0x000180498a80(in_RDX, 0, uVar9);
        if (iVar5 != 0) {
            return -2;
        }
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R14;
    if ((1 < in_R8) && (*(char *)(in_RDX + -1 + in_R8) == '\0')) {
        in_R8 = in_R8 - 1;
    }
    iVar2 = 0;
    iVar3 = 0;
    uVar11 = (uint32_t)in_R9 & 0xffff7fff;
    *(undefined4 *)((int64_t)&arg_68h + iVar4) = 0;
    uVar10 = 0x16;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1b5;
        in_R8 = fcn.180498cd0(in_RDX);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1cb;
    iVar5 = fcn.1802394c0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
    if (iVar5 != 0) {
        iVar8 = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1dd;
        iVar1 = fcn.180222010(iVar5);
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1eb;
                piVar6 = (int32_t *)fcn.180222340(iVar5, iVar8);
                if (*piVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d334;
                    iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                          *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000048 + iVar4));
                    if ((iVar2 == 0x4b8) && (**(int32_t **)(*(int64_t *)(piVar6 + 2) + 8) == 0xc)) {
                        uVar7 = *(undefined8 *)(*(int32_t **)(*(int64_t *)(piVar6 + 2) + 8) + 2);
                        uVar10 = 0;
                        goto code_r0x00018023d357;
                    }
code_r0x00018023d204:
                    iVar2 = *(int32_t *)((int64_t)&arg_68h + iVar4);
                } else {
                    if (*piVar6 != 1) goto code_r0x00018023d204;
                    uVar7 = *(undefined8 *)(piVar6 + 2);
code_r0x00018023d357:
                    *(undefined8 *)((int64_t)&iStackX_18 + iVar4 + -8) = 0;
                    iVar2 = 1;
                    *(uint64_t *)((int64_t)&var_8h + iVar4) = in_R8;
                    *(undefined4 *)((int64_t)&arg_68h + iVar4) = 1;
                    *(int64_t *)(&stack0x00000000 + iVar4) = in_RDX;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d388;
                    iVar3 = func_0x00018023dac0(uVar7, uVar10, 0x18023dcd0, uVar11);
                    if (iVar3 != 0) break;
                }
                iVar8 = iVar8 + 1;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d215;
                iVar1 = fcn.180222010(iVar5);
            } while (iVar8 < iVar1);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d221;
        func_0x00018028f450(iVar5);
        if (iVar3 != 0) {
            return iVar3;
        }
        if ((iVar2 != 0) && ((in_R9 & 1) == 0)) {
            return 0;
        }
        arg1 = *(int64_t *)((int64_t)&arg_60h + iVar4);
    }
    if ((in_R9 & 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d251;
        uVar10 = fcn.180238460(arg1);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d267;
        for (iVar2 = func_0x0001802acaa0(uVar10, 0x30, 0xffffffff); -1 < iVar2;
            iVar2 = func_0x0001802acaa0(uVar10, 0x30, iVar2)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d27b;
            uVar7 = func_0x0001802aca50(uVar10, iVar2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d283;
            piVar6 = (int32_t *)func_0x000180247880(uVar7);
            if ((*(int64_t *)(piVar6 + 2) != 0) && (*piVar6 != 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d29f;
                iVar3 = func_0x0001802a7f60((int64_t)&arg_68h + iVar4, piVar6);
                if (iVar3 < 0) {
                    return -1;
                }
                *(uint32_t *)(&stack0x00000000 + iVar4) = uVar11;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d2c2;
                iVar3 = func_0x00018023dcd0(*(undefined8 *)((int64_t)&arg_68h + iVar4), (int64_t)iVar3, in_RDX, in_R8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d2de;
                fcn.180224990(*(undefined8 *)((int64_t)&arg_68h + iVar4), 0x1804e2fa0, 0x368);
                if (iVar3 != 0) {
                    return iVar3;
                }
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d2f2;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023d322
// Address: 0x18023d322
// Size: 127 bytes
// ============================================================
int32_t fcn.18023d110(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar8;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint64_t uVar9;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 uVar10;
    uint32_t uVar11;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18023d125;
    var_8h = arg1;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == 0) {
        return -2;
    }
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d14a;
        in_R8 = fcn.180498cd0();
    } else {
        uVar9 = in_R8 - 1;
        if (in_R8 < 2) {
            uVar9 = in_R8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d161;
        iVar5 = func_0x000180498a80(in_RDX, 0, uVar9);
        if (iVar5 != 0) {
            return -2;
        }
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R14;
    if ((1 < in_R8) && (*(char *)(in_RDX + -1 + in_R8) == '\0')) {
        in_R8 = in_R8 - 1;
    }
    iVar2 = 0;
    iVar3 = 0;
    uVar11 = (uint32_t)in_R9 & 0xffff7fff;
    *(undefined4 *)((int64_t)&arg_68h + iVar4) = 0;
    uVar10 = 0x16;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1b5;
        in_R8 = fcn.180498cd0(in_RDX);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1cb;
    iVar5 = fcn.1802394c0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
    if (iVar5 != 0) {
        iVar8 = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1dd;
        iVar1 = fcn.180222010(iVar5);
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1eb;
                piVar6 = (int32_t *)fcn.180222340(iVar5, iVar8);
                if (*piVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d334;
                    iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                          *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000048 + iVar4));
                    if ((iVar2 == 0x4b8) && (**(int32_t **)(*(int64_t *)(piVar6 + 2) + 8) == 0xc)) {
                        uVar7 = *(undefined8 *)(*(int32_t **)(*(int64_t *)(piVar6 + 2) + 8) + 2);
                        uVar10 = 0;
                        goto code_r0x00018023d357;
                    }
code_r0x00018023d204:
                    iVar2 = *(int32_t *)((int64_t)&arg_68h + iVar4);
                } else {
                    if (*piVar6 != 1) goto code_r0x00018023d204;
                    uVar7 = *(undefined8 *)(piVar6 + 2);
code_r0x00018023d357:
                    *(undefined8 *)((int64_t)&iStackX_18 + iVar4 + -8) = 0;
                    iVar2 = 1;
                    *(uint64_t *)((int64_t)&var_8h + iVar4) = in_R8;
                    *(undefined4 *)((int64_t)&arg_68h + iVar4) = 1;
                    *(int64_t *)(&stack0x00000000 + iVar4) = in_RDX;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d388;
                    iVar3 = func_0x00018023dac0(uVar7, uVar10, 0x18023dcd0, uVar11);
                    if (iVar3 != 0) break;
                }
                iVar8 = iVar8 + 1;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d215;
                iVar1 = fcn.180222010(iVar5);
            } while (iVar8 < iVar1);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d221;
        func_0x00018028f450(iVar5);
        if (iVar3 != 0) {
            return iVar3;
        }
        if ((iVar2 != 0) && ((in_R9 & 1) == 0)) {
            return 0;
        }
        arg1 = *(int64_t *)((int64_t)&arg_60h + iVar4);
    }
    if ((in_R9 & 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d251;
        uVar10 = fcn.180238460(arg1);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d267;
        for (iVar2 = func_0x0001802acaa0(uVar10, 0x30, 0xffffffff); -1 < iVar2;
            iVar2 = func_0x0001802acaa0(uVar10, 0x30, iVar2)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d27b;
            uVar7 = func_0x0001802aca50(uVar10, iVar2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d283;
            piVar6 = (int32_t *)func_0x000180247880(uVar7);
            if ((*(int64_t *)(piVar6 + 2) != 0) && (*piVar6 != 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d29f;
                iVar3 = func_0x0001802a7f60((int64_t)&arg_68h + iVar4, piVar6);
                if (iVar3 < 0) {
                    return -1;
                }
                *(uint32_t *)(&stack0x00000000 + iVar4) = uVar11;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d2c2;
                iVar3 = func_0x00018023dcd0(*(undefined8 *)((int64_t)&arg_68h + iVar4), (int64_t)iVar3, in_RDX, in_R8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d2de;
                fcn.180224990(*(undefined8 *)((int64_t)&arg_68h + iVar4), 0x1804e2fa0, 0x368);
                if (iVar3 != 0) {
                    return iVar3;
                }
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d2f2;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023d3a1
// Address: 0x18023d3a1
// Size: 16 bytes
// ============================================================
int32_t fcn.18023d110(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar8;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint64_t uVar9;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 uVar10;
    uint32_t uVar11;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18023d125;
    var_8h = arg1;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == 0) {
        return -2;
    }
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d14a;
        in_R8 = fcn.180498cd0();
    } else {
        uVar9 = in_R8 - 1;
        if (in_R8 < 2) {
            uVar9 = in_R8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d161;
        iVar5 = func_0x000180498a80(in_RDX, 0, uVar9);
        if (iVar5 != 0) {
            return -2;
        }
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R14;
    if ((1 < in_R8) && (*(char *)(in_RDX + -1 + in_R8) == '\0')) {
        in_R8 = in_R8 - 1;
    }
    iVar2 = 0;
    iVar3 = 0;
    uVar11 = (uint32_t)in_R9 & 0xffff7fff;
    *(undefined4 *)((int64_t)&arg_68h + iVar4) = 0;
    uVar10 = 0x16;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1b5;
        in_R8 = fcn.180498cd0(in_RDX);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1cb;
    iVar5 = fcn.1802394c0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
    if (iVar5 != 0) {
        iVar8 = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1dd;
        iVar1 = fcn.180222010(iVar5);
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d1eb;
                piVar6 = (int32_t *)fcn.180222340(iVar5, iVar8);
                if (*piVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d334;
                    iVar2 = fcn.18022cd20(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                          *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000048 + iVar4));
                    if ((iVar2 == 0x4b8) && (**(int32_t **)(*(int64_t *)(piVar6 + 2) + 8) == 0xc)) {
                        uVar7 = *(undefined8 *)(*(int32_t **)(*(int64_t *)(piVar6 + 2) + 8) + 2);
                        uVar10 = 0;
                        goto code_r0x00018023d357;
                    }
code_r0x00018023d204:
                    iVar2 = *(int32_t *)((int64_t)&arg_68h + iVar4);
                } else {
                    if (*piVar6 != 1) goto code_r0x00018023d204;
                    uVar7 = *(undefined8 *)(piVar6 + 2);
code_r0x00018023d357:
                    *(undefined8 *)((int64_t)&iStackX_18 + iVar4 + -8) = 0;
                    iVar2 = 1;
                    *(uint64_t *)((int64_t)&var_8h + iVar4) = in_R8;
                    *(undefined4 *)((int64_t)&arg_68h + iVar4) = 1;
                    *(int64_t *)(&stack0x00000000 + iVar4) = in_RDX;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d388;
                    iVar3 = func_0x00018023dac0(uVar7, uVar10, 0x18023dcd0, uVar11);
                    if (iVar3 != 0) break;
                }
                iVar8 = iVar8 + 1;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d215;
                iVar1 = fcn.180222010(iVar5);
            } while (iVar8 < iVar1);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d221;
        func_0x00018028f450(iVar5);
        if (iVar3 != 0) {
            return iVar3;
        }
        if ((iVar2 != 0) && ((in_R9 & 1) == 0)) {
            return 0;
        }
        arg1 = *(int64_t *)((int64_t)&arg_60h + iVar4);
    }
    if ((in_R9 & 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d251;
        uVar10 = fcn.180238460(arg1);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d267;
        for (iVar2 = func_0x0001802acaa0(uVar10, 0x30, 0xffffffff); -1 < iVar2;
            iVar2 = func_0x0001802acaa0(uVar10, 0x30, iVar2)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d27b;
            uVar7 = func_0x0001802aca50(uVar10, iVar2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d283;
            piVar6 = (int32_t *)func_0x000180247880(uVar7);
            if ((*(int64_t *)(piVar6 + 2) != 0) && (*piVar6 != 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d29f;
                iVar3 = func_0x0001802a7f60((int64_t)&arg_68h + iVar4, piVar6);
                if (iVar3 < 0) {
                    return -1;
                }
                *(uint32_t *)(&stack0x00000000 + iVar4) = uVar11;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d2c2;
                iVar3 = func_0x00018023dcd0(*(undefined8 *)((int64_t)&arg_68h + iVar4), (int64_t)iVar3, in_RDX, in_R8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d2de;
                fcn.180224990(*(undefined8 *)((int64_t)&arg_68h + iVar4), 0x1804e2fa0, 0x368);
                if (iVar3 != 0) {
                    return iVar3;
                }
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d2f2;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023d3c0
// Address: 0x18023d3c0
// Size: 90 bytes
// ============================================================
int32_t fcn.18023d3c0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                     int64_t arg_80h)
{
    bool bVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    char *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar9;
    uint64_t in_R8;
    uint64_t uVar10;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    code *pcVar11;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18023d3d5;
    var_8h = arg1;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == (char *)0x0) {
        return -2;
    }
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d3fa;
        in_R8 = fcn.180498cd0();
    } else {
        uVar10 = in_R8 - 1;
        if (in_R8 < 2) {
            uVar10 = in_R8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d411;
        iVar5 = func_0x000180498a80(in_RDX, 0, uVar10);
        if (iVar5 != 0) {
            return -2;
        }
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
    if ((1 < in_R8) && (in_RDX[in_R8 - 1] == '\0')) {
        in_R8 = in_R8 - 1;
    }
    bVar1 = false;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R13;
    iVar3 = 0;
    uVar12 = (uint32_t)in_R9 & 0xffff7fff;
    if ((in_R8 < 2) || (*in_RDX != '.')) {
        pcVar11 = (code *)0x18023dda0;
        if ((in_R9 & 2) == 0) {
            pcVar11 = (code *)0x18023de50;
        }
        if (in_R8 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d498;
            in_R8 = fcn.180498cd0(in_RDX);
        }
    } else {
        uVar12 = uVar12 | 0x8000;
        pcVar11 = (code *)0x18023dda0;
        if ((in_R9 & 2) == 0) {
            pcVar11 = (code *)0x18023de50;
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d4ae;
    iVar5 = fcn.1802394c0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
    if (iVar5 != 0) {
        iVar9 = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d4c4;
        iVar2 = fcn.180222010(iVar5);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d4da;
                piVar6 = (int32_t *)fcn.180222340(iVar5, iVar9);
                iVar2 = *piVar6;
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d52c;
                    fcn.18022cd20(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
                } else if ((iVar2 != 1) && (iVar2 == 2)) {
                    *(undefined8 *)((int64_t)&iStackX_18 + iVar4 + -8) = *(undefined8 *)((int64_t)&arg_80h + iVar4);
                    uVar7 = *(undefined8 *)(piVar6 + 2);
                    *(uint64_t *)((int64_t)&var_8h + iVar4) = in_R8;
                    *(char **)(&stack0x00000000 + iVar4) = in_RDX;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d518;
                    iVar3 = func_0x00018023dac0(uVar7, 0x16, pcVar11, uVar12);
                    bVar1 = true;
                    if (iVar3 != 0) break;
                }
                iVar9 = iVar9 + 1;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d536;
                iVar2 = fcn.180222010(iVar5);
            } while (iVar9 < iVar2);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d542;
        func_0x00018028f450(iVar5);
        if (iVar3 != 0) {
            return iVar3;
        }
        if ((bVar1) && ((uVar12 & 1) == 0)) {
            return 0;
        }
        arg1 = *(int64_t *)((int64_t)&arg_60h + iVar4);
    }
    if ((uVar12 & 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d573;
        uVar7 = fcn.180238460(arg1);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d589;
        for (iVar3 = func_0x0001802acaa0(uVar7, 0xd, 0xffffffff); -1 < iVar3;
            iVar3 = func_0x0001802acaa0(uVar7, 0xd, iVar3)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d59d;
            uVar8 = func_0x0001802aca50(uVar7, iVar3);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d5a5;
            piVar6 = (int32_t *)func_0x000180247880(uVar8);
            if ((*(int64_t *)(piVar6 + 2) != 0) && (*piVar6 != 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d5c9;
                iVar2 = func_0x0001802a7f60((int64_t)&arg_68h + iVar4, piVar6);
                if (iVar2 < 0) {
                    return -1;
                }
                *(uint32_t *)(&stack0x00000000 + iVar4) = uVar12;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d5ed;
                iVar9 = (*pcVar11)(*(undefined8 *)((int64_t)&arg_68h + iVar4), (int64_t)iVar2, in_RDX, in_R8);
                if ((0 < iVar9) && (*(int64_t *)((int64_t)&arg_80h + iVar4) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d61b;
                    iVar5 = func_0x000180223270(*(undefined8 *)((int64_t)&arg_68h + iVar4), (int64_t)iVar2, 0x1804e2fa0
                                                , 0x362);
                    **(int64_t **)((int64_t)&arg_80h + iVar4) = iVar5;
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d6a3;
                        fcn.180224990(*(undefined8 *)((int64_t)&arg_68h + iVar4), 0x1804e2fa0, 0x364);
                        return -1;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d645;
                fcn.180224990(*(undefined8 *)((int64_t)&arg_68h + iVar4), 0x1804e2fa0, 0x368);
                if (iVar9 != 0) {
                    return iVar9;
                }
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d659;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023d41a
// Address: 0x18023d41a
// Size: 623 bytes
// ============================================================
int32_t fcn.18023d3c0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                     int64_t arg_80h)
{
    bool bVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    char *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar9;
    uint64_t in_R8;
    uint64_t uVar10;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    code *pcVar11;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18023d3d5;
    var_8h = arg1;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == (char *)0x0) {
        return -2;
    }
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d3fa;
        in_R8 = fcn.180498cd0();
    } else {
        uVar10 = in_R8 - 1;
        if (in_R8 < 2) {
            uVar10 = in_R8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d411;
        iVar5 = func_0x000180498a80(in_RDX, 0, uVar10);
        if (iVar5 != 0) {
            return -2;
        }
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
    if ((1 < in_R8) && (in_RDX[in_R8 - 1] == '\0')) {
        in_R8 = in_R8 - 1;
    }
    bVar1 = false;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R13;
    iVar3 = 0;
    uVar12 = (uint32_t)in_R9 & 0xffff7fff;
    if ((in_R8 < 2) || (*in_RDX != '.')) {
        pcVar11 = (code *)0x18023dda0;
        if ((in_R9 & 2) == 0) {
            pcVar11 = (code *)0x18023de50;
        }
        if (in_R8 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d498;
            in_R8 = fcn.180498cd0(in_RDX);
        }
    } else {
        uVar12 = uVar12 | 0x8000;
        pcVar11 = (code *)0x18023dda0;
        if ((in_R9 & 2) == 0) {
            pcVar11 = (code *)0x18023de50;
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d4ae;
    iVar5 = fcn.1802394c0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                          *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
    if (iVar5 != 0) {
        iVar9 = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d4c4;
        iVar2 = fcn.180222010(iVar5);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d4da;
                piVar6 = (int32_t *)fcn.180222340(iVar5, iVar9);
                iVar2 = *piVar6;
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d52c;
                    fcn.18022cd20(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
                } else if ((iVar2 != 1) && (iVar2 == 2)) {
                    *(undefined8 *)((int64_t)&iStackX_18 + iVar4 + -8) = *(undefined8 *)((int64_t)&arg_80h + iVar4);
                    uVar7 = *(undefined8 *)(piVar6 + 2);
                    *(uint64_t *)((int64_t)&var_8h + iVar4) = in_R8;
                    *(char **)(&stack0x00000000 + iVar4) = in_RDX;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d518;
                    iVar3 = func_0x00018023dac0(uVar7, 0x16, pcVar11, uVar12);
                    bVar1 = true;
                    if (iVar3 != 0) break;
                }
                iVar9 = iVar9 + 1;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d536;
                iVar2 = fcn.180222010(iVar5);
            } while (iVar9 < iVar2);
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d542;
        func_0x00018028f450(iVar5);
        if (iVar3 != 0) {
            return iVar3;
        }
        if ((bVar1) && ((uVar12 & 1) == 0)) {
            return 0;
        }
        arg1 = *(int64_t *)((int64_t)&arg_60h + iVar4);
    }
    if ((uVar12 & 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d573;
        uVar7 = fcn.180238460(arg1);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d589;
        for (iVar3 = func_0x0001802acaa0(uVar7, 0xd, 0xffffffff); -1 < iVar3;
            iVar3 = func_0x0001802acaa0(uVar7, 0xd, iVar3)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d59d;
            uVar8 = func_0x0001802aca50(uVar7, iVar3);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d5a5;
            piVar6 = (int32_t *)func_0x000180247880(uVar8);
            if ((*(int64_t *)(piVar6 + 2) != 0) && (*piVar6 != 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d5c9;
                iVar2 = func_0x0001802a7f60((int64_t)&arg_68h + iVar4, piVar6);
                if (iVar2 < 0) {
                    return -1;
                }
                *(uint32_t *)(&stack0x00000000 + iVar4) = uVar12;
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d5ed;
                iVar9 = (*pcVar11)(*(undefined8 *)((int64_t)&arg_68h + iVar4), (int64_t)iVar2, in_RDX, in_R8);
                if ((0 < iVar9) && (*(int64_t *)((int64_t)&arg_80h + iVar4) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d61b;
                    iVar5 = func_0x000180223270(*(undefined8 *)((int64_t)&arg_68h + iVar4), (int64_t)iVar2, 0x1804e2fa0
                                                , 0x362);
                    **(int64_t **)((int64_t)&arg_80h + iVar4) = iVar5;
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d6a3;
                        fcn.180224990(*(undefined8 *)((int64_t)&arg_68h + iVar4), 0x1804e2fa0, 0x364);
                        return -1;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d645;
                fcn.180224990(*(undefined8 *)((int64_t)&arg_68h + iVar4), 0x1804e2fa0, 0x368);
                if (iVar9 != 0) {
                    return iVar9;
                }
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18023d659;
        }
    }
    return 0;
}

