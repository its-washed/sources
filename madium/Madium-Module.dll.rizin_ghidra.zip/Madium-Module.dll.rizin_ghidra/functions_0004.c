// Chunk 4 - 50 functions

// ============================================================
// Function: FUN_180008300
// Address: 0x180008300
// Size: 15 bytes
// ============================================================
void fcn.180008300(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000830f
// Address: 0x18000830f
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180008300(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180008345
// Address: 0x180008345
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180008300(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180008350
// Address: 0x180008350
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180008350(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    piVar4 = *(int64_t **)(arg2 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
        return arg1;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000836f
// Address: 0x18000836f
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180008350(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    piVar4 = *(int64_t **)(arg2 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
        return arg1;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800083b3
// Address: 0x1800083b3
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180008350(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    piVar4 = *(int64_t **)(arg2 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
        return arg1;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800083d0
// Address: 0x1800083d0
// Size: 236 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.1800083d0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    undefined4 uVar2;
    undefined8 in_R8;
    bool bVar3;
    int64_t var_8h;
    undefined auStack_58 [32];
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 0xffff;
    if (7 < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    uVar1 = func_0x000180455104(arg2, &var_38h, in_R8, 0xffffffff);
    *(uint32_t *)(arg1 + 8) = uVar1;
    if (uVar1 == 0) {
        uVar2 = 0x16d;
        if (((uint32_t)var_28h & 1) == 0) {
            uVar2 = 0x1ff;
        }
        *(undefined4 *)(arg1 + 4) = uVar2;
        if (((uint32_t)var_28h >> 10 & 1) != 0) {
            if (var_28h._4_4_ == -0x5ffffff4) {
                *(undefined4 *)arg1 = 4;
                goto code_r0x0001800084a1;
            }
            if (var_28h._4_4_ == -0x5ffffffd) {
                *(undefined4 *)arg1 = 10;
                goto code_r0x0001800084a1;
            }
        }
        uVar1 = ((uint32_t)var_28h & 0x10 | 0x20) >> 4;
    } else {
        *(undefined4 *)(arg1 + 4) = 0xffff;
        if (uVar1 < 0x41) {
            if (((uVar1 != 0x40) && (uVar1 != 2)) && (uVar1 != 3)) {
                bVar3 = uVar1 == 0x35;
code_r0x000180008494:
                if (!bVar3) {
                    uVar1 = 0;
                    goto code_r0x00018000849f;
                }
            }
        } else if ((uVar1 != 0x7b) && (uVar1 != 0xa1)) {
            bVar3 = uVar1 == 0x10b;
            goto code_r0x000180008494;
        }
        uVar1 = 1;
    }
code_r0x00018000849f:
    *(uint32_t *)arg1 = uVar1;
code_r0x0001800084a1:
    func_0x000180459870(var_18h ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_1800084c0
// Address: 0x1800084c0
// Size: 556 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800084c0(int64_t arg1)
{
    int64_t iVar1;
    uint64_t uVar2;
    char cVar3;
    int64_t *piVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined4 *puVar7;
    undefined8 *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    piVar4 = (int64_t *)func_0x000180008740();
    if (*(int64_t *)(*piVar4 + 0x18) == *(int64_t *)(arg1 + 0x30)) {
        iVar1 = *(int64_t *)(*piVar4 + 0x10);
        iVar5 = func_0x000180085760(iVar1);
        if (iVar5 != 0) {
            piVar4 = (int64_t *)(iVar1 + 0x40);
            *piVar4 = *piVar4 + -0x10;
            func_0x000180012f50();
            func_0x000180013530();
            *(uint8_t *)(iVar5 + 1) = *(uint8_t *)(iVar5 + 1) | 0x40;
            iVar1 = *(int64_t *)(iVar5 + 0x50);
            *(undefined4 *)(iVar1 + 0x88) = 8;
            *(undefined8 *)(iVar1 + 0x78) = 0x203fffffffffff3f;
            puVar6 = (undefined4 *)(**(code **)0x180782558)(**(undefined8 **)0x180782610);
            if (puVar6 != (undefined4 *)0x0) {
                uVar2 = *(uint64_t *)(iVar1 + 0x78);
                *puVar6 = 8;
                *(uint64_t *)(puVar6 + 10) = uVar2 | 0x200000000000003f;
                *(int64_t *)(puVar6 + 6) = iVar5;
            }
            func_0x000180086fd0(iVar5, 0, 0);
            func_0x000180086fd0(iVar5, 0, 0);
            func_0x000180086cc0(iVar5, 0xffffd8f0, 0x1805aae80);
            func_0x000180087370(iVar5, 0xfffffffe, 0x1805aae90);
            *(undefined *)(*(int64_t *)(*(int64_t *)(iVar5 + 0x40) + -0x10) + 4) = 1;
            func_0x000180087650(iVar5, 0xfffffffe);
            if ((*(uint8_t *)(iVar5 + 1) & 4) != 0) {
                *(uint8_t *)(iVar5 + 1) = *(uint8_t *)(iVar5 + 1) & 0xfb;
                *(undefined8 *)(iVar5 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar5 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(iVar5 + 0x20) + 0x18) = iVar5;
            }
            func_0x000180085370(iVar5, 0xffffd8ee);
            puVar8 = (undefined8 *)(*(int64_t *)(iVar5 + 0x40) + -0x10);
            *(undefined8 *)(iVar5 + 0x58) = *puVar8;
            *(undefined8 **)(iVar5 + 0x40) = puVar8;
            piVar4 = (int64_t *)func_0x000180085370(iVar5, 0xffffd8ee);
            iVar1 = *piVar4;
            *(undefined *)(iVar1 + 6) = 0;
            var_28h = var_28h & 0xffffffff00000000;
            cVar3 = func_0x0001800131b0(iVar1, iVar5, arg1 + 0x10, 0x1805aae98, var_28h);
            if (cVar3 == '\0') {
                if ((*(int64_t *)(iVar5 + 0x40) + -0x10 != *(int64_t *)0x180782430) &&
                   (*(int32_t *)(*(int64_t *)(iVar5 + 0x40) + -4) == 6)) {
                    func_0x0001800869f0(iVar5, *(undefined8 *)0x1807823e0, 0, 0, 0);
                    func_0x000180085bf0(iVar5, 0xfffffffe);
                    puVar7 = *(undefined4 **)(iVar5 + 0x40);
                    puVar6 = puVar7 + -8;
                    if (puVar6 < puVar7) {
                        do {
                            puVar6[-4] = *puVar6;
                            puVar6[-3] = puVar6[1];
                            puVar6[-2] = puVar6[2];
                            puVar6[-1] = puVar6[3];
                            puVar6 = puVar6 + 4;
                            puVar7 = *(undefined4 **)(iVar5 + 0x40);
                        } while (puVar6 < puVar7);
                    }
                    *(undefined4 **)(iVar5 + 0x40) = puVar7 + -4;
                    func_0x0001800878a0(iVar5, 1, 0);
                }
                return 2;
            }
            (**(code **)0x1807823e8)(iVar5);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180008700
// Address: 0x180008700
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180008700(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.180004e40(arg1 + 0x10);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x40);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180008740
// Address: 0x180008740
// Size: 141 bytes
// ============================================================
undefined8 fcn.180008740(void)
{
    int64_t unaff_GS_OFFSET;
    
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x180782764) {
        fcn.180459d18(0x180782764);
        if (*(int32_t *)0x180782764 == -1) {
            *(undefined (**) [16])0x180782770 = (undefined (*) [16])fcn.180459890(0x28);
            **(undefined (**) [16])0x180782770 = ZEXT816(0);
            (*(undefined (**) [16])0x180782770)[1] = ZEXT816(0);
            *(undefined8 *)(*(undefined (**) [16])0x180782770)[2] = 0;
            fcn.180459c24(0x1804a1fd0);
            fcn.180459cac(0x180782764);
            return 0x180782770;
        }
    }
    return 0x180782770;
}

// ============================================================
// Function: FUN_1800087d0
// Address: 0x1800087d0
// Size: 810 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800087d0(int64_t arg_b0h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t **ppiVar4;
    code *pcVar5;
    bool bVar6;
    uint8_t uVar7;
    bool bVar8;
    uint8_t uVar9;
    bool bVar10;
    int32_t iVar11;
    char **ppcVar12;
    int64_t *piVar13;
    undefined8 uVar14;
    int64_t *piVar15;
    int64_t *piVar16;
    int64_t *piVar17;
    int64_t *piVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    bVar8 = false;
    bVar6 = false;
    ppcVar12 = (char **)fcn.180008740();
    if (**ppcVar12 != '\0') {
        piVar13 = (int64_t *)func_0x0001800137d0();
        iVar3 = *piVar13;
        iVar11 = func_0x000180456008(iVar3 + 0x28);
        if (iVar11 != 0) {
            func_0x0001804542e8(5);
            pcVar5 = (code *)swi(3);
            uVar14 = (*pcVar5)();
            return uVar14;
        }
        if (*(int32_t *)(iVar3 + 0x74) == 0x7fffffff) {
            *(undefined4 *)(iVar3 + 0x74) = 0x7ffffffe;
            func_0x0001804542e8(6);
            pcVar5 = (code *)swi(3);
            uVar14 = (*pcVar5)();
            return uVar14;
        }
        var_20h = *(int64_t *)(iVar3 + 0x20);
        func_0x000180456010(iVar3 + 0x28);
        var_18h._0_4_ = 0;
        piVar18 = (int64_t *)var_58h;
        if (var_20h != 0) {
            for (; (int32_t)var_18h != 10; var_18h._0_4_ = (int32_t)var_18h + 1) {
                iVar3 = *piVar13;
                iVar11 = func_0x000180456008(iVar3 + 0x28);
                if (iVar11 != 0) {
                    func_0x0001804542e8(5);
                    pcVar5 = (code *)swi(3);
                    uVar14 = (*pcVar5)();
                    return uVar14;
                }
                if (*(int32_t *)(iVar3 + 0x74) == 0x7fffffff) {
                    *(undefined4 *)(iVar3 + 0x74) = 0x7ffffffe;
                    func_0x0001804542e8(6);
                    pcVar5 = (code *)swi(3);
                    uVar14 = (*pcVar5)();
                    return uVar14;
                }
                if (*(int64_t *)(iVar3 + 0x20) == 0) {
                    bVar10 = false;
                    piVar15 = (int64_t *)var_48h;
                    piVar17 = (int64_t *)var_50h;
                } else {
                    ppiVar4 = *(int64_t ***)
                               (*(int64_t *)(iVar3 + 8) +
                               (*(int64_t *)(iVar3 + 0x10) - 1U & *(uint64_t *)(iVar3 + 0x18)) * 8);
                    piVar17 = *ppiVar4;
                    piVar15 = ppiVar4[1];
                    *ppiVar4 = (int64_t *)0x0;
                    ppiVar4[1] = (int64_t *)0x0;
                    func_0x00018000d070(*(undefined8 *)
                                         (*(int64_t *)(iVar3 + 8) +
                                         (*(int64_t *)(iVar3 + 0x10) - 1U & *(uint64_t *)(iVar3 + 0x18)) * 8));
                    piVar16 = (int64_t *)(iVar3 + 0x20);
                    *piVar16 = *piVar16 + -1;
                    if (*piVar16 == 0) {
                        *(undefined8 *)(iVar3 + 0x18) = 0;
                    } else {
                        *(int64_t *)(iVar3 + 0x18) = *(int64_t *)(iVar3 + 0x18) + 1;
                    }
                    bVar10 = true;
                }
                func_0x000180456010(iVar3 + 0x28);
                if (bVar10) {
                    if (piVar15 != (int64_t *)0x0) {
                        LOCK();
                        *(int32_t *)(piVar15 + 1) = *(int32_t *)(piVar15 + 1) + 1;
                        UNLOCK();
                    }
                    uVar9 = 1;
                    uVar7 = 0;
                    piVar16 = piVar15;
                    piVar18 = piVar15;
                    if (piVar15 != (int64_t *)0x0) {
                        LOCK();
                        *(int32_t *)(piVar15 + 1) = *(int32_t *)(piVar15 + 1) + 1;
                        UNLOCK();
                    }
                } else {
                    var_58h = 0;
                    piVar17 = (int64_t *)0x0;
                    uVar9 = 0;
                    uVar7 = 1;
                    piVar16 = (int64_t *)0x0;
                }
                bVar8 = (bool)(bVar8 | uVar9);
                bVar6 = (bool)(bVar6 | uVar7);
                if ((bVar6) && (bVar6 = false, (int64_t *)var_58h != (int64_t *)0x0)) {
                    LOCK();
                    piVar1 = (int64_t *)(var_58h + 8);
                    iVar11 = *(int32_t *)piVar1;
                    *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                    UNLOCK();
                    if (iVar11 == 1) {
                        (***(code ***)var_58h)(var_58h);
                        LOCK();
                        piVar2 = (int32_t *)(var_58h + 0xc);
                        iVar11 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar11 == 1) {
                            (**(code **)(*(int64_t *)var_58h + 8))(var_58h);
                        }
                    }
                }
                if ((bVar8) && (bVar8 = false, piVar18 != (int64_t *)0x0)) {
                    LOCK();
                    piVar1 = piVar18 + 1;
                    iVar11 = *(int32_t *)piVar1;
                    *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                    UNLOCK();
                    if (iVar11 == 1) {
                        (**(code **)*piVar18)(piVar18);
                        LOCK();
                        piVar2 = (int32_t *)((int64_t)piVar18 + 0xc);
                        iVar11 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar11 == 1) {
                            (**(code **)(*piVar18 + 8))(piVar18);
                        }
                    }
                }
                if ((bVar10) && (piVar15 != (int64_t *)0x0)) {
                    LOCK();
                    piVar1 = piVar15 + 1;
                    iVar11 = *(int32_t *)piVar1;
                    *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                    UNLOCK();
                    if (iVar11 == 1) {
                        (**(code **)*piVar15)(piVar15);
                        LOCK();
                        piVar2 = (int32_t *)((int64_t)piVar15 + 0xc);
                        iVar11 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar11 == 1) {
                            (**(code **)(*piVar15 + 8))(piVar15);
                        }
                    }
                }
                if (piVar17 == (int64_t *)0x0) {
                    if (piVar16 == (int64_t *)0x0) {
                        return 0;
                    }
                    LOCK();
                    piVar13 = piVar16 + 1;
                    iVar11 = *(int32_t *)piVar13;
                    *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
                    UNLOCK();
                    if (iVar11 != 1) {
                        return 0;
                    }
                    (**(code **)*piVar16)(piVar16);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar16 + 0xc);
                    iVar11 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar11 != 1) {
                        return 0;
                    }
                    (**(code **)(*piVar16 + 8))(piVar16);
                    return 0;
                }
                var_20h = var_20h + -1;
                iVar11 = (**(code **)(*piVar17 + 8))(piVar17);
                if (iVar11 == 1) {
                    (**(code **)*piVar17)(piVar17);
                }
                if (piVar16 != (int64_t *)0x0) {
                    LOCK();
                    piVar17 = piVar16 + 1;
                    iVar11 = *(int32_t *)piVar17;
                    *(int32_t *)piVar17 = *(int32_t *)piVar17 + -1;
                    UNLOCK();
                    if (iVar11 == 1) {
                        (**(code **)*piVar16)(piVar16);
                        LOCK();
                        piVar2 = (int32_t *)((int64_t)piVar16 + 0xc);
                        iVar11 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar11 == 1) {
                            (**(code **)(*piVar16 + 8))(piVar16);
                        }
                    }
                }
                if (var_20h == 0) {
                    return 0;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180008b00
// Address: 0x180008b00
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180008b00(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_18h;
    undefined auStack_158 [32];
    int64_t var_138h;
    int64_t var_128h;
    uint64_t uStack_18;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_158;
    var_138h._0_4_ = 0;
    (*(code *)0x69a3bc)(arg1, &var_138h);
    (*(code *)0x69a3aa)(arg1, &var_128h, 0x104);
    if (*(int32_t *)arg2 == (int32_t)var_138h) {
        iVar1 = 0;
        do {
            iVar2 = iVar1 + 1;
            if (*(char *)((int64_t)&var_128h + iVar1) != *(char *)(iVar1 + 0x1805aae9c)) goto code_r0x000180008b83;
            iVar1 = iVar2;
        } while (iVar2 != 7);
        *(int64_t *)(arg2 + 8) = arg1;
    }
code_r0x000180008b83:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_158);
    return;
}

// ============================================================
// Function: FUN_180008bb0
// Address: 0x180008bb0
// Size: 5801 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_354h
// WARNING: [rz-ghidra] Detected overlap for variable var_350h
// WARNING: [rz-ghidra] Detected overlap for variable var_23ch
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_2d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_38ch

void fcn.180008bb0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    uint32_t uVar3;
    int64_t *piVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined auVar9 [16];
    undefined auVar10 [16];
    int16_t *piVar11;
    undefined uVar12;
    char cVar13;
    int32_t iVar14;
    undefined8 uVar15;
    int64_t iVar16;
    undefined8 *puVar17;
    undefined8 uVar18;
    undefined (*pauVar19) [16];
    int64_t *piVar20;
    int16_t *piVar21;
    int16_t *piVar22;
    int64_t iVar23;
    undefined (*pauVar24) [16];
    undefined8 uVar25;
    uint32_t uVar26;
    undefined *puVar27;
    uint8_t uVar28;
    uint64_t uVar29;
    int16_t *piVar30;
    undefined *puVar31;
    undefined4 *puVar32;
    undefined8 *puVar33;
    undefined *puVar34;
    undefined *puVar35;
    undefined8 *puVar36;
    undefined *puVar37;
    undefined4 *puVar38;
    uint32_t uVar39;
    uint64_t uVar40;
    undefined4 *puVar41;
    uint64_t uVar42;
    undefined4 uVar43;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 extraout_XMM0_Da_02;
    int64_t var_10h;
    undefined8 uStack_3d0;
    undefined auStack_3c8 [8];
    undefined auStack_3c0 [24];
    int64_t var_3a8h;
    int64_t var_398h;
    int64_t var_390h;
    int64_t var_388h;
    int64_t var_380h;
    int64_t var_378h;
    int64_t var_370h;
    int64_t var_368h;
    int64_t var_360h;
    int64_t var_358h;
    int64_t var_348h;
    int64_t var_340h;
    undefined4 auStack_338 [2];
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_320h;
    undefined8 uStack_318;
    int64_t var_310h;
    int64_t var_308h;
    int64_t var_300h;
    int64_t var_2f8h;
    int64_t var_2e8h;
    int64_t var_2e0h;
    int64_t var_2d8h;
    undefined4 var_23ch;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_208h;
    int64_t var_1f8h;
    int64_t var_1e8h;
    int64_t var_1e0h;
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1b8h;
    int64_t var_1b0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_180h;
    int64_t var_168h;
    int64_t var_160h;
    undefined4 var_154h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_118h;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar34 = auStack_3c8;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_3c8;
    var_398h._0_4_ = 0;
    *(undefined8 *)(arg1 + 0x20) = *(undefined8 *)arg2;
    *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)(*(int64_t *)arg2 + 0x70);
    LOCK();
    *(undefined *)arg1 = 1;
    UNLOCK();
    auStack_338[0] = 0;
    uStack_318 = 0;
    uVar15 = (**(code **)0x180782570)(*(undefined8 *)(arg1 + 0x20), auStack_338, &uStack_318);
    iVar16 = func_0x000180085760(uVar15);
    var_360h = iVar16;
    func_0x0001800882f0(uVar15);
    func_0x0001800858c0(uVar15, 0xfffffffe);
    *(int64_t *)(arg1 + 0x10) = iVar16;
    uVar43 = func_0x000180013530();
    func_0x000180013600(uVar43, iVar16, 1);
    func_0x000180013740();
    func_0x000180086cc0(iVar16, 0xffffd8ee, 0x1805aaed0);
    *(undefined4 *)0x1807823dc = func_0x0001800863e0(iVar16, 0xffffffff);
    func_0x000180086cc0(iVar16, 0xffffffff, 0x1805aaed8);
    *(undefined4 *)0x1807823d4 = func_0x0001800863e0(iVar16, 0xffffffff);
    func_0x0001800858c0(iVar16, 0xfffffffd);
    func_0x000180086cc0(iVar16, 0xffffd8ee, 0x1805aaee4);
    func_0x000180086cc0(iVar16, 0xffffffff, 0x1805aaeec);
    func_0x000180086570(iVar16, 0);
    func_0x000180086570(iVar16, 0);
    func_0x000180086570(iVar16, 0);
    func_0x0001800878a0(iVar16, 3, 1);
    *(undefined4 *)0x1807823d8 = func_0x0001800863e0(iVar16, 0xffffffff);
    func_0x0001800858c0(iVar16, 0xfffffffd);
    func_0x000180086cc0(iVar16, 0xffffd8ee, 0x1805aaef0);
    func_0x000180086cc0(iVar16, 0xffffffff, 0x1805aaeec);
    func_0x000180086570(iVar16, 0);
    func_0x000180086570(iVar16, 0);
    func_0x0001800878a0(iVar16, 2, 1);
    *(undefined4 *)0x1807823d0 = func_0x0001800863e0(iVar16, 0xffffffff);
    func_0x0001800858c0(iVar16, 0xfffffffd);
    func_0x000180086cc0(iVar16, 0xffffd8ee, 0x1805aaef8);
    func_0x000180086cc0(iVar16, 0xffffffff, 0x1805aaeec);
    *(undefined8 *)0x1807823f0 = func_0x000180086280(iVar16);
    func_0x0001800858c0(extraout_XMM0_Da, 0xfffffffd);
    func_0x000180086cc0(iVar16, 0xffffd8ee, 0x1805aaf04);
    func_0x000180086cc0(iVar16, 0xffffffff, 0x1805aaf0c);
    *(undefined8 *)0x1807823e8 = func_0x000180086280(iVar16);
    func_0x0001800858c0(extraout_XMM0_Da_00, 0xfffffffd);
    func_0x000180086cc0(iVar16, 0xffffd8ee, 0x1805aaf14);
    *(undefined8 *)0x1807823e0 = func_0x000180086280(iVar16);
    func_0x0001800858c0(extraout_XMM0_Da_01, 0xfffffffe);
    *(undefined8 *)0x180781ee8 = *(undefined8 *)(*(int64_t *)(iVar16 + 0x20) + 0x550);
    *(undefined8 *)(*(int64_t *)(iVar16 + 0x20) + 0x550) = 0x1800135b0;
    uVar43 = func_0x000180018f70();
    func_0x000180019a70(uVar43, iVar16);
    func_0x0001800858c0(iVar16, 0);
    func_0x000180086cc0(iVar16, 0xffffd8ee, 0x1805aaed0);
    func_0x000180086cc0(iVar16, 0xffffffff, 0x1805aaf20);
    func_0x0001800859a0(iVar16, 0xfffffffe);
    func_0x0001800868c0(iVar16, 0x1805aaf30);
    func_0x0001800878a0(iVar16, 2, 1);
    func_0x000180086cc0(iVar16, 0xffffffff, 0x1805aaf40);
    func_0x000180086cc0(iVar16, 0xffffffff, 0x1805aaf48);
    func_0x0001800859a0(iVar16, 0xfffffffe);
    var_3a8h = 0;
    func_0x0001800869f0(iVar16, fcn.1800087d0, 0, 0);
    func_0x0001800878a0(iVar16, 2, 0);
    func_0x0001800858c0(iVar16, 0);
    var_68h = 0;
    var_60h = 0xf;
    stack0xffffffffffffff89 = SUB1615(ZEXT816(0), 1);
    auVar9[15] = 0;
    auVar9._0_15_ = stack0xffffffffffffff89;
    _var_78h = auVar9 << 8;
    _var_c0h = ZEXT816(0);
    var_b0h = 0;
    var_a8h = 0;
    func_0x000180004830(&var_c0h, 0x1805aaf50, 0x1c);
    var_348h = 4;
    var_340h = 0xf;
    stack0xfffffffffffffcad = SUB1611(ZEXT816(0), 5);
    var_358h._0_5_ = 0x6f666e49;
    func_0x0001800758f0(&var_358h, &var_c0h, 5, &var_78h);
    if (0xf < (uint64_t)var_340h) {
        func_0x000180005a60(&var_358h, var_358h);
    }
    if (0xf < (uint64_t)var_a8h) {
        func_0x000180005a60(&var_c0h, var_c0h);
    }
    var_b0h = 0;
    var_a8h = 0xf;
    auVar10[15] = 0;
    auVar10._0_15_ = stack0xffffffffffffff41;
    _var_c0h = auVar10 << 8;
    if (0xf < (uint64_t)var_60h) {
        iVar16 = var_78h;
        puVar34 = auStack_3c8;
        if ((0xfff < var_60h + 1U) &&
           (iVar16 = *(int64_t *)(var_78h + -8), puVar34 = auStack_3c8, 0x1f < (var_78h - iVar16) - 8U)) {
            pcVar5 = (code *)swi(0x29);
            iVar16 = (*pcVar5)(5);
            puVar34 = auStack_3c0;
        }
        *(undefined8 *)(puVar34 + -8) = 0x1800090c5;
        fcn.180459c3c(iVar16);
    }
    *(undefined8 *)(puVar34 + -8) = 0x1800090ca;
    puVar17 = (undefined8 *)func_0x0001800137d0();
    *(undefined8 **)(puVar34 + 0x68) = puVar17;
    uVar15 = *puVar17;
    uVar25 = *(undefined8 *)(*(int64_t *)arg2 + 0x70);
    *(undefined8 *)(puVar34 + -8) = 0x1800090de;
    uVar18 = func_0x00018045838c();
    *(undefined8 *)(puVar34 + -8) = 0x1800090eb;
    pauVar19 = (undefined (*) [16])fcn.180459890(0x50);
    *(undefined (**) [16])(puVar34 + 0x38) = pauVar19;
    *pauVar19 = ZEXT816(0);
    *(undefined4 *)(*pauVar19 + 8) = 1;
    *(undefined4 *)(*pauVar19 + 0xc) = 1;
    *(undefined8 *)*pauVar19 = 0x1805ab1a0;
    *(undefined (*) [16])(puVar34 + 0x308) = ZEXT816(0);
    *(undefined8 *)(puVar34 + 0x318) = 0;
    *(undefined8 *)(puVar34 + 800) = 0;
    *(undefined8 *)(puVar34 + -8) = 0x180009147;
    func_0x000180004830(puVar34 + 0x308, 0x1805aaf80, 0x195);
    *(undefined8 *)pauVar19[1] = 0x1805ab1c8;
    uVar43 = *(undefined4 *)(puVar34 + 0x30c);
    uVar6 = *(undefined4 *)(puVar34 + 0x310);
    uVar7 = *(undefined4 *)(puVar34 + 0x314);
    *(undefined4 *)pauVar19[2] = *(undefined4 *)(puVar34 + 0x308);
    *(undefined4 *)(pauVar19[2] + 4) = uVar43;
    *(undefined4 *)(pauVar19[2] + 8) = uVar6;
    *(undefined4 *)(pauVar19[2] + 0xc) = uVar7;
    uVar43 = *(undefined4 *)(puVar34 + 0x31c);
    uVar6 = *(undefined4 *)(puVar34 + 800);
    uVar7 = *(undefined4 *)(puVar34 + 0x324);
    *(undefined4 *)pauVar19[3] = *(undefined4 *)(puVar34 + 0x318);
    *(undefined4 *)(pauVar19[3] + 4) = uVar43;
    *(undefined4 *)(pauVar19[3] + 8) = uVar6;
    *(undefined4 *)(pauVar19[3] + 0xc) = uVar7;
    *(undefined8 *)pauVar19[4] = uVar25;
    *(undefined8 *)(pauVar19[4] + 8) = uVar18;
    *(undefined4 *)(pauVar19[1] + 8) = 0;
    uVar39 = 0x8000;
    *(undefined (**) [16])(puVar34 + 0x98) = pauVar19 + 1;
    *(undefined (**) [16])(puVar34 + 0xa0) = pauVar19;
    *(undefined8 *)(puVar34 + -8) = 0x18000919d;
    func_0x0001800082d0(puVar34 + 0x58, puVar34 + 0x98);
    *(undefined8 *)(puVar34 + -8) = 0x1800091ab;
    func_0x00018000a9d0(uVar15, puVar34 + 0x58);
    *(undefined8 *)(puVar34 + -8) = 0x1800091b6;
    fcn.180008300((int64_t)(puVar34 + 0x58), *(int64_t *)(puVar34 + 0x30));
    *(undefined8 *)(puVar34 + -8) = 0x1800091c4;
    fcn.180008300((int64_t)(puVar34 + 0x98), *(int64_t *)(puVar34 + 0x30));
    *(undefined8 *)(puVar34 + -8) = 0x1800091c9;
    piVar20 = (int64_t *)func_0x0001800814c0();
    iVar16 = *piVar20;
    *(undefined8 *)(puVar34 + -8) = 0x1800091dd;
    func_0x000180007340(puVar34 + 0x370, iVar16 + 0x20);
    *(undefined (*) [16])(puVar34 + 0x40) = ZEXT816(0);
    *(undefined8 *)(puVar34 + 0x50) = 0;
    *(undefined4 *)(puVar34 + 0xb8) = 0;
    *(undefined8 *)(puVar34 + 0xc0) = 0x1806a45e0;
    *(undefined8 *)(puVar34 + -8) = 0x18000921d;
    func_0x000180007fb0(puVar34 + 0x58, puVar34 + 0x370, puVar34 + 0xb8);
    *(undefined8 *)(puVar34 + -8) = 0x180009230;
    uVar15 = func_0x00018000a260(puVar34 + 0x350, puVar34 + 0x58);
    *(undefined8 *)(puVar34 + -8) = 0x180009240;
    func_0x0001800082d0(puVar34 + 200, uVar15);
    *(undefined8 *)(puVar34 + -8) = 0x180009250;
    iVar16 = func_0x00018000a260(puVar34 + 0x70, puVar34 + 0x58);
    *(undefined8 *)(puVar34 + -8) = 0x180009260;
    fcn.180008350((int64_t)(puVar34 + 0x350), iVar16, *(int64_t *)(puVar34 + 0x30));
    while (iVar16 = *(int64_t *)(puVar34 + 200), iVar16 != *(int64_t *)(puVar34 + 0x350)) {
        if (*(int32_t *)(puVar34 + 0xb8) == 0) {
            *(undefined8 *)(puVar34 + -8) = 0x1800092aa;
            func_0x000180007ac0(iVar16, puVar34 + 0x98, 3);
            if ((*(int32_t *)(puVar34 + 0xa0) != 0) &&
               (uVar26 = (int32_t)*(undefined8 *)(puVar34 + 0x98) - 1, (uVar26 & 0xfffffff7) != 0)) {
                *(undefined8 *)(puVar34 + -8) = 0x18000a1da;
                func_0x000180007a50(uVar26, *(int32_t *)(puVar34 + 0xa0), iVar16 + 0x20);
                goto code_r0x00018000a1db;
            }
            if ((int32_t)*(undefined8 *)(puVar34 + 0x98) != 2) goto code_r0x00018000986d;
            puVar17 = (undefined8 *)(iVar16 + 0x20);
            *(undefined8 **)(puVar34 + 0xa8) = puVar17;
            if (7 < *(uint64_t *)(iVar16 + 0x38)) {
                puVar17 = (undefined8 *)*puVar17;
            }
            piVar30 = (int16_t *)((int64_t)puVar17 + *(int64_t *)(iVar16 + 0x30) * 2);
            *(undefined8 *)(puVar34 + -8) = 0x180009300;
            piVar22 = piVar30;
            piVar21 = (int16_t *)func_0x000180006c10();
            if (piVar21 != piVar22) {
                do {
                    piVar11 = piVar30;
                    if ((*piVar21 != 0x5c) && (*piVar21 != 0x2f)) break;
                    piVar21 = piVar21 + 1;
                } while (piVar21 != piVar22);
                do {
                    piVar30 = piVar11;
                    if (piVar21 == piVar22) break;
                    piVar22 = piVar30 + -1;
                    if ((*piVar22 == 0x5c) || (piVar11 = piVar22, *piVar22 == 0x2f)) break;
                } while( true );
            }
            *(undefined8 *)(puVar34 + -8) = 0x18000934c;
            piVar22 = (int16_t *)func_0x000180458100(piVar30);
            if ((piVar30 == piVar22) || (piVar21 = piVar22 + -1, piVar30 == piVar21)) {
code_r0x00018000938f:
                piVar21 = piVar22;
            } else {
                if (*piVar21 != 0x2e) {
                    for (piVar21 = piVar22 + -2; piVar30 != piVar21; piVar21 = piVar21 + -1) {
                        if (*piVar21 == 0x2e) goto code_r0x000180009392;
                    }
                    goto code_r0x00018000938f;
                }
                if ((piVar30 == piVar22 + -2) && (piVar22[-2] == 0x2e)) goto code_r0x00018000938f;
            }
code_r0x000180009392:
            *(undefined (*) [16])(puVar34 + 0x308) = ZEXT816(0);
            *(undefined8 *)(puVar34 + 0x318) = 0;
            *(undefined8 *)(puVar34 + 800) = 0;
            *(undefined8 *)(puVar34 + -8) = 0x1800093c3;
            func_0x00018000d380(puVar34 + 0x308, piVar21, (int64_t)piVar22 - (int64_t)piVar21 >> 1);
            puVar27 = puVar34 + 0x308;
            if (7 < *(uint64_t *)(puVar34 + 800)) {
                puVar27 = *(undefined **)(puVar34 + 0x308);
            }
            uVar29 = *(uint64_t *)(puVar34 + 0x318);
            *(undefined8 *)(puVar34 + -8) = 0x1800093f1;
            uVar43 = func_0x000180454ce0();
            *(undefined (*) [16])(puVar34 + 0x330) = ZEXT816(0);
            *(undefined8 *)(puVar34 + 0x340) = 0;
            uVar42 = 0xf;
            *(undefined8 *)(puVar34 + 0x348) = 0xf;
            puVar34[0x330] = 0;
            *(uint32_t *)(puVar34 + 0x30) = uVar39 | 0x7800;
            if (uVar29 != 0) {
                if (0x7fffffff < uVar29) {
                    *(undefined8 *)(puVar34 + -8) = 0x18000a1f4;
                    func_0x000180006180();
                    goto code_r0x00018000a1f5;
                }
                *(undefined4 *)(puVar34 + 0x20) = 0;
                *(undefined8 *)(puVar34 + -8) = 0x180009452;
                uVar15 = func_0x000180454d50(uVar43, puVar27, uVar29 & 0xffffffff, 0);
                *(undefined8 *)(puVar34 + 0x38) = uVar15;
                if ((int32_t)((uint64_t)uVar15 >> 0x20) != 0) {
                    *(undefined8 *)(puVar34 + -8) = 0x18000a1ee;
                    func_0x000180006560(*(undefined4 *)(puVar34 + 0x3c));
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                *(undefined8 *)(puVar34 + -8) = 0x180009479;
                func_0x00018000b3b0(puVar34 + 0x330, (int64_t)(int32_t)uVar15, 0);
                puVar35 = puVar34 + 0x330;
                if (0xf < *(uint64_t *)(puVar34 + 0x348)) {
                    puVar35 = *(undefined **)(puVar34 + 0x330);
                }
                *(int32_t *)(puVar34 + 0x20) = (int32_t)uVar15;
                *(undefined8 *)(puVar34 + -8) = 0x1800094a4;
                uVar15 = func_0x000180454d50(uVar43, puVar27, uVar29 & 0xffffffff, puVar35);
                *(undefined8 *)(puVar34 + 0x38) = uVar15;
                if ((int32_t)((uint64_t)uVar15 >> 0x20) != 0) {
code_r0x00018000a1db:
                    *(undefined8 *)(puVar34 + -8) = 0x18000a1e4;
                    func_0x000180006560(*(undefined4 *)(puVar34 + 0x3c));
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                uVar42 = *(uint64_t *)(puVar34 + 0x348);
            }
            *(uint32_t *)(puVar34 + 0x30) = uVar39 | 0x7000;
            uVar39 = uVar39 | 0x7700;
            if (7 < *(uint64_t *)(puVar34 + 800)) {
                *(undefined8 *)(puVar34 + -8) = 0x1800094f1;
                func_0x00018000f950(puVar34 + 0x308, *(undefined8 *)(puVar34 + 0x308));
                uVar42 = *(uint64_t *)(puVar34 + 0x348);
            }
            *(undefined8 *)(puVar34 + 0x318) = 0;
            *(undefined8 *)(puVar34 + 800) = 7;
            *(undefined2 *)(puVar34 + 0x308) = 0;
            puVar35 = *(undefined **)(puVar34 + 0x330);
            puVar27 = puVar34 + 0x330;
            if (0xf < uVar42) {
                puVar27 = puVar35;
            }
            puVar31 = puVar34 + 0x330;
            if (0xf < uVar42) {
                puVar31 = puVar35;
            }
            iVar16 = *(int64_t *)(puVar34 + 0x340);
            puVar37 = puVar34 + 0x330;
            if (0xf < uVar42) {
                puVar37 = puVar35;
            }
            if (puVar37 != puVar31 + iVar16) {
                do {
                    uVar12 = *puVar37;
                    *(undefined8 *)(puVar34 + -8) = 0x18000955f;
                    uVar12 = func_0x000180460320(uVar12);
                    *puVar27 = uVar12;
                    puVar27 = puVar27 + 1;
                    puVar37 = puVar37 + 1;
                } while (puVar37 != puVar31 + iVar16);
                uVar42 = *(uint64_t *)(puVar34 + 0x348);
                puVar35 = *(undefined **)(puVar34 + 0x330);
            }
            puVar27 = puVar34 + 0x330;
            if (0xf < uVar42) {
                puVar27 = puVar35;
            }
            if (*(int64_t *)(puVar34 + 0x340) == 4) {
                uVar28 = 0x18;
                *(undefined8 *)(puVar34 + -8) = 0x1800095a8;
                iVar14 = func_0x000180497f30(puVar27);
                if (iVar14 != 0) goto code_r0x0001800095ac;
code_r0x0001800095e0:
                puVar38 = *(undefined4 **)(puVar34 + 0x48);
                if (puVar38 == *(undefined4 **)(puVar34 + 0x50)) {
                    iVar16 = (int64_t)puVar38 - *(int64_t *)(puVar34 + 0x40) >> 5;
                    if (iVar16 == 0x7ffffffffffffff) {
                        *(undefined8 *)(puVar34 + -8) = 0x18000a200;
                        uVar26 = func_0x000180010010();
                        goto code_r0x00018000a201;
                    }
                    uVar29 = iVar16 + 1;
                    uVar42 = (int64_t)*(undefined4 **)(puVar34 + 0x50) - *(int64_t *)(puVar34 + 0x40) >> 5;
                    if (0x7ffffffffffffff - (uVar42 >> 1) < uVar42) {
                        uVar40 = 0x7ffffffffffffff;
                    } else {
                        uVar42 = (uVar42 >> 1) + uVar42;
                        uVar40 = uVar29;
                        if (uVar29 <= uVar42) {
                            uVar40 = uVar42;
                        }
                        if (0x7ffffffffffffff < uVar40) {
code_r0x00018000a1f5:
                            *(undefined8 *)(puVar34 + -8) = 0x18000a1fa;
                            fcn.180004720();
                            pcVar5 = (code *)swi(3);
                            (*pcVar5)();
                            return;
                        }
                    }
                    *(uint64_t *)(puVar34 + 0x38) = uVar40 << 5;
                    *(undefined8 *)(puVar34 + -8) = 0x180009678;
                    iVar23 = func_0x000180004de0(uVar40 << 5);
                    *(int64_t *)(puVar34 + 0x30) = iVar23;
                    iVar16 = iVar16 * 0x20 + iVar23;
                    pauVar19 = (undefined (*) [16])(iVar16 + 0x20);
                    *(undefined **)(puVar34 + 0x308) = puVar34 + 0x40;
                    *(int64_t *)(puVar34 + 0x310) = iVar23;
                    *(uint64_t *)(puVar34 + 0x318) = uVar40;
                    *(undefined (**) [16])(puVar34 + 800) = pauVar19;
                    *(undefined (**) [16])(puVar34 + 0x328) = pauVar19;
                    *(undefined8 *)(puVar34 + -8) = 0x1800096c3;
                    uVar43 = func_0x000180007340(iVar16, *(undefined8 *)(puVar34 + 0xa8));
                    puVar41 = *(undefined4 **)(puVar34 + 0x48);
                    puVar32 = *(undefined4 **)(puVar34 + 0x40);
                    if (puVar38 == puVar41) {
                        pauVar19 = *(undefined (**) [16])(puVar34 + 0x30);
                        pauVar24 = pauVar19;
                        if (puVar32 != puVar41) {
                            do {
                                *pauVar24 = ZEXT816(0);
                                *(undefined8 *)pauVar24[1] = 0;
                                *(undefined8 *)(pauVar24[1] + 8) = 0;
                                uVar43 = *puVar32;
                                uVar6 = puVar32[1];
                                uVar7 = puVar32[2];
                                uVar8 = puVar32[3];
                                *(undefined4 *)*pauVar24 = uVar43;
                                *(undefined4 *)(*pauVar24 + 4) = uVar6;
                                *(undefined4 *)(*pauVar24 + 8) = uVar7;
                                *(undefined4 *)(*pauVar24 + 0xc) = uVar8;
                                uVar6 = puVar32[5];
                                uVar7 = puVar32[6];
                                uVar8 = puVar32[7];
                                *(undefined4 *)pauVar24[1] = puVar32[4];
                                *(undefined4 *)(pauVar24[1] + 4) = uVar6;
                                *(undefined4 *)(pauVar24[1] + 8) = uVar7;
                                *(undefined4 *)(pauVar24[1] + 0xc) = uVar8;
                                *(undefined8 *)(puVar32 + 4) = 0;
                                *(undefined8 *)(puVar32 + 6) = 7;
                                *(undefined2 *)puVar32 = 0;
                                puVar32 = puVar32 + 8;
                                pauVar24 = pauVar24 + 2;
                            } while (puVar32 != puVar41);
                            puVar41 = *(undefined4 **)(puVar34 + 0x48);
                            puVar32 = *(undefined4 **)(puVar34 + 0x40);
                        }
                    } else {
                        pauVar24 = *(undefined (**) [16])(puVar34 + 0x30);
                        if (puVar32 != puVar38) {
                            do {
                                *pauVar24 = ZEXT816(0);
                                *(undefined8 *)pauVar24[1] = 0;
                                *(undefined8 *)(pauVar24[1] + 8) = 0;
                                uVar43 = *puVar32;
                                uVar6 = puVar32[1];
                                uVar7 = puVar32[2];
                                uVar8 = puVar32[3];
                                *(undefined4 *)*pauVar24 = uVar43;
                                *(undefined4 *)(*pauVar24 + 4) = uVar6;
                                *(undefined4 *)(*pauVar24 + 8) = uVar7;
                                *(undefined4 *)(*pauVar24 + 0xc) = uVar8;
                                uVar6 = puVar32[5];
                                uVar7 = puVar32[6];
                                uVar8 = puVar32[7];
                                *(undefined4 *)pauVar24[1] = puVar32[4];
                                *(undefined4 *)(pauVar24[1] + 4) = uVar6;
                                *(undefined4 *)(pauVar24[1] + 8) = uVar7;
                                *(undefined4 *)(pauVar24[1] + 0xc) = uVar8;
                                *(undefined8 *)(puVar32 + 4) = 0;
                                *(undefined8 *)(puVar32 + 6) = 7;
                                *(undefined2 *)puVar32 = 0;
                                pauVar24 = pauVar24 + 2;
                                puVar32 = puVar32 + 8;
                            } while (puVar32 != puVar38);
                            puVar41 = *(undefined4 **)(puVar34 + 0x48);
                            puVar32 = *(undefined4 **)(puVar34 + 0x40);
                        }
                        if (puVar38 != puVar41) {
                            do {
                                *pauVar19 = ZEXT816(0);
                                *(undefined8 *)pauVar19[1] = 0;
                                *(undefined8 *)(pauVar19[1] + 8) = 0;
                                uVar43 = *puVar38;
                                uVar6 = puVar38[1];
                                uVar7 = puVar38[2];
                                uVar8 = puVar38[3];
                                *(undefined4 *)*pauVar19 = uVar43;
                                *(undefined4 *)(*pauVar19 + 4) = uVar6;
                                *(undefined4 *)(*pauVar19 + 8) = uVar7;
                                *(undefined4 *)(*pauVar19 + 0xc) = uVar8;
                                uVar6 = puVar38[5];
                                uVar7 = puVar38[6];
                                uVar8 = puVar38[7];
                                *(undefined4 *)pauVar19[1] = puVar38[4];
                                *(undefined4 *)(pauVar19[1] + 4) = uVar6;
                                *(undefined4 *)(pauVar19[1] + 8) = uVar7;
                                *(undefined4 *)(pauVar19[1] + 0xc) = uVar8;
                                *(undefined8 *)(puVar38 + 4) = 0;
                                *(undefined8 *)(puVar38 + 6) = 7;
                                *(undefined2 *)puVar38 = 0;
                                pauVar19 = pauVar19 + 2;
                                puVar38 = puVar38 + 8;
                            } while (puVar38 != puVar41);
                            puVar41 = *(undefined4 **)(puVar34 + 0x48);
                            puVar32 = *(undefined4 **)(puVar34 + 0x40);
                        }
                        pauVar19 = *(undefined (**) [16])(puVar34 + 0x30);
                    }
                    if (puVar32 != (undefined4 *)0x0) {
                        if (puVar32 != puVar41) {
                            do {
                                *(undefined8 *)(puVar34 + -8) = 0x1800097ea;
                                uVar43 = func_0x00018000dc80(puVar32);
                                puVar32 = puVar32 + 8;
                            } while (puVar32 != puVar41);
                            puVar32 = *(undefined4 **)(puVar34 + 0x40);
                        }
                        *(undefined8 *)(puVar34 + -8) = 0x18000980c;
                        func_0x00018000f770(uVar43, puVar32, *(int64_t *)(puVar34 + 0x50) - (int64_t)puVar32 >> 5);
                    }
                    *(undefined (**) [16])(puVar34 + 0x40) = pauVar19;
                    *(undefined (**) [16])(puVar34 + 0x48) = pauVar19 + uVar29 * 2;
                    *(undefined **)(puVar34 + 0x50) = *pauVar19 + *(int64_t *)(puVar34 + 0x38);
                } else {
                    *(undefined8 *)(puVar34 + -8) = 0x1800095ff;
                    func_0x000180007340(puVar38, *(undefined8 *)(puVar34 + 0xa8));
                    *(int64_t *)(puVar34 + 0x48) = *(int64_t *)(puVar34 + 0x48) + 0x20;
                }
                puVar35 = *(undefined **)(puVar34 + 0x330);
                uVar42 = *(uint64_t *)(puVar34 + 0x348);
            } else {
code_r0x0001800095ac:
                uVar28 = 0x20;
                *(undefined8 *)(puVar34 + -8) = 0x1800095c0;
                cVar13 = func_0x00018000a630(puVar34 + 0x330);
                if (cVar13 != '\0') goto code_r0x0001800095e0;
                uVar28 = 0x28;
                *(undefined8 *)(puVar34 + -8) = 0x1800095d8;
                cVar13 = func_0x00018000a630(puVar34 + 0x330);
                if (cVar13 != '\0') goto code_r0x0001800095e0;
            }
            if (0xf < uVar42) {
                uVar29 = uVar42 + 1;
                puVar27 = puVar35;
                if (0xfff < uVar29) {
                    puVar27 = *(undefined **)(puVar35 + -8);
                    if ((undefined *)0x1f < puVar35 + (-8 - (int64_t)puVar27)) {
                        pcVar5 = (code *)swi(0x29);
                        (*pcVar5)(5);
                        puVar34 = puVar34 + 8;
                        break;
                    }
                    uVar29 = uVar42 + 0x28;
                }
                *(undefined8 *)(puVar34 + -8) = 0x18000986d;
                fcn.180459c3c(puVar27, uVar29);
            }
        }
code_r0x00018000986d:
        *(undefined8 *)(puVar34 + -8) = 0x18000987a;
        iVar14 = func_0x000180007c30(puVar34 + 200);
        if (iVar14 != 0) {
            *(undefined8 *)(puVar34 + -8) = 0x18000a1d0;
            func_0x000180007960(extraout_XMM0_Da_02, iVar14);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
    }
    piVar20 = *(int64_t **)(puVar34 + 0x358);
    if (piVar20 != (int64_t *)0x0) {
        LOCK();
        piVar4 = piVar20 + 1;
        iVar14 = *(int32_t *)piVar4;
        *(int32_t *)piVar4 = *(int32_t *)piVar4 + -1;
        UNLOCK();
        if (iVar14 == 1) {
            pcVar5 = *(code **)*piVar20;
            *(undefined8 *)(puVar34 + -8) = 0x1800098b2;
            (*pcVar5)(piVar20);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar20 + 0xc);
            iVar14 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar14 == 1) {
                pcVar5 = *(code **)(*piVar20 + 8);
                *(undefined8 *)(puVar34 + -8) = 0x1800098ca;
                (*pcVar5)(piVar20);
            }
        }
    }
    piVar20 = *(int64_t **)(puVar34 + 0xd0);
    if (piVar20 != (int64_t *)0x0) {
        LOCK();
        piVar4 = piVar20 + 1;
        iVar14 = *(int32_t *)piVar4;
        *(int32_t *)piVar4 = *(int32_t *)piVar4 + -1;
        UNLOCK();
        if (iVar14 == 1) {
            pcVar5 = *(code **)*piVar20;
            *(undefined8 *)(puVar34 + -8) = 0x1800098ef;
            (*pcVar5)(piVar20);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar20 + 0xc);
            iVar14 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar14 == 1) {
                pcVar5 = *(code **)(*piVar20 + 8);
                *(undefined8 *)(puVar34 + -8) = 0x180009907;
                (*pcVar5)(piVar20);
            }
        }
    }
    piVar20 = *(int64_t **)(puVar34 + 0x60);
    if (piVar20 != (int64_t *)0x0) {
        LOCK();
        piVar4 = piVar20 + 1;
        iVar14 = *(int32_t *)piVar4;
        *(int32_t *)piVar4 = *(int32_t *)piVar4 + -1;
        UNLOCK();
        if (iVar14 == 1) {
            pcVar5 = *(code **)*piVar20;
            *(undefined8 *)(puVar34 + -8) = 0x180009929;
            (*pcVar5)(piVar20);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar20 + 0xc);
            iVar14 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar14 == 1) {
                pcVar5 = *(code **)(*piVar20 + 8);
                *(undefined8 *)(puVar34 + -8) = 0x180009941;
                (*pcVar5)(piVar20);
            }
        }
    }
    *(undefined8 *)(puVar34 + -8) = 0x18000995d;
    func_0x00018000e3a0(*(int64_t *)(puVar34 + 0x40), *(int64_t *)(puVar34 + 0x48), 
                        *(int64_t *)(puVar34 + 0x48) - *(int64_t *)(puVar34 + 0x40) >> 5, 0);
    puVar36 = *(undefined8 **)(puVar34 + 0x40);
    puVar17 = *(undefined8 **)(puVar34 + 0x48);
    if (puVar36 != puVar17) {
        do {
            puVar33 = puVar36;
            if (7 < (uint64_t)puVar36[3]) {
                puVar33 = (undefined8 *)*puVar36;
            }
            *(undefined8 *)(puVar34 + 0xe0) = 0x1805ab198;
            *(undefined8 *)(puVar34 + 0x198) = 0;
            *(undefined8 *)(puVar34 + 0x1a0) = 0;
            *(undefined4 *)(puVar34 + 0x1a8) = 0;
            *(undefined (*) [16])(puVar34 + 0x1b0) = ZEXT816(0);
            *(undefined (*) [16])(puVar34 + 0x1c0) = ZEXT816(0);
            *(undefined (*) [16])(puVar34 + 0x1d0) = ZEXT816(0);
            *(undefined8 *)(puVar34 + 0x1e0) = 0;
            puVar34[0x1e8] = 0;
            *(uint32_t *)(puVar34 + 0x30) = uVar39 | 2;
            *(undefined8 *)(puVar34 + 400) = 0x1804a5600;
            *(undefined4 *)(puVar34 + 0x18c) = 0x98;
            *(undefined8 *)(puVar34 + 0xe8) = 0;
            *(undefined8 *)(puVar34 + -8) = 0x180009a2c;
            func_0x00018000fe50(puVar34 + 400, puVar34 + 0xf0, 0);
            *(undefined8 *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xe0) = 0x1805ab280;
            *(int32_t *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xdc) =
                 *(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + -0xb0;
            *(undefined8 *)(puVar34 + -8) = 0x180009a69;
            func_0x00018000fa40(puVar34 + 0xf0);
            *(undefined8 *)(puVar34 + -8) = 0x180009a80;
            iVar16 = func_0x00018000f990(puVar34 + 0xf0, puVar33);
            if (iVar16 == 0) {
                iVar16 = (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4);
                uVar28 = 2;
                uVar26 = 6;
                if (*(int64_t *)(puVar34 + iVar16 + 0x128) != 0) {
                    uVar26 = 2;
                }
                uVar3 = *(uint32_t *)(puVar34 + iVar16 + 0xf0);
                *(uint32_t *)(puVar34 + iVar16 + 0xf0) = uVar26 | uVar3 & 0x17;
                uVar26 = (uVar26 | uVar3 & 0x17) & *(uint32_t *)(puVar34 + iVar16 + 0xf4);
                if (uVar26 != 0) {
code_r0x00018000a201:
                    if ((uVar26 & 4) == 0) {
                        uVar15 = 0x1805aae00;
                        if ((uVar28 & (uint8_t)uVar26) == 0) {
                            uVar15 = 0x1805aae18;
                        }
                    } else {
                        uVar15 = 0x1805aade8;
                    }
                    *(undefined8 *)(puVar34 + -8) = 0x18000a231;
                    uVar25 = func_0x000180005e50(puVar34 + 0x70, 1);
                    *(undefined8 *)(puVar34 + -8) = 0x18000a244;
                    func_0x0001800069f0(puVar34 + 0x2e0, uVar15, uVar25);
                    *(undefined8 *)(puVar34 + -8) = 0x18000a258;
                    fcn.18045bae0(*(int64_t *)(puVar34 + 0x20));
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
            }
            *(undefined8 *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xe0) = 0x1805ab280;
            *(int32_t *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xdc) =
                 *(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + -0xb0;
            if ((puVar34[(int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xf0] & 6) == 0) {
                *(undefined8 *)(puVar34 + 0x1f0) = 0x1805ab1e0;
                *(undefined8 *)(puVar34 + 0x280) = 0;
                *(undefined8 *)(puVar34 + 0x288) = 0;
                *(undefined4 *)(puVar34 + 0x290) = 0;
                *(undefined8 *)(puVar34 + 0x298) = 0;
                *(undefined (*) [16])(puVar34 + 0x2a0) = ZEXT816(0);
                *(undefined (*) [16])(puVar34 + 0x2b0) = ZEXT816(0);
                *(undefined (*) [16])(puVar34 + 0x2c0) = ZEXT816(0);
                puVar34[0x2d0] = 0;
                *(uint32_t *)(puVar34 + 0x30) = uVar39 | 0x12;
                *(undefined8 *)(puVar34 + 0x278) = 0x1804a54f0;
                *(undefined4 *)(puVar34 + 0x274) = 0x78;
                *(undefined8 *)(puVar34 + -8) = 0x180009c20;
                func_0x00018000fe50(puVar34 + 0x278, puVar34 + 0x1f8, 0);
                *(undefined8 *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0x1f0) + 4) + 0x1f0) =
                     0x1804a6448;
                *(int32_t *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0x1f0) + 4) + 0x1ec) =
                     *(int32_t *)(*(int64_t *)(puVar34 + 0x1f0) + 4) + -0x88;
                *(undefined8 *)(puVar34 + -8) = 0x180009c62;
                func_0x00018000fd90(puVar34 + 0x1f8);
                *(undefined8 *)(puVar34 + 0x1f8) = 0x1804a5580;
                *(undefined8 *)(puVar34 + 0x260) = 0;
                *(undefined4 *)(puVar34 + 0x268) = 4;
                *(undefined8 *)(puVar34 + -8) = 0x180009c99;
                func_0x00018000ca80(puVar34 + 0x1f0, puVar34 + 0xf0);
                uVar15 = **(undefined8 **)(puVar34 + 0x68);
                *(undefined (*) [16])(puVar34 + 0x308) = ZEXT816(0);
                *(undefined8 *)(puVar34 + 0x318) = 0;
                *(undefined8 *)(puVar34 + 800) = 0xf;
                puVar34[0x308] = 0;
                *(uint32_t *)(puVar34 + 0x30) = uVar39 | 0x92;
                *(undefined (*) [16])(puVar34 + 0x70) = ZEXT816(0);
                *(undefined8 *)(puVar34 + 0x80) = 0;
                iVar16 = 0;
                if ((((uint8_t)*(uint32_t *)(puVar34 + 0x268) & 0x22) == 2) || (**(int64_t **)(puVar34 + 0x238) == 0)) {
                    if ((*(uint32_t *)(puVar34 + 0x268) & 4) == 0) {
                        if (**(int64_t **)(puVar34 + 0x230) == 0) {
                            iVar23 = *(int64_t *)(puVar34 + 0x70);
                        } else {
                            iVar16 = **(int64_t **)(puVar34 + 0x210);
                            iVar23 = iVar16;
                        }
                        goto code_r0x000180009d67;
                    }
                } else {
                    iVar16 = **(int64_t **)(puVar34 + 0x218);
                    iVar23 = iVar16;
code_r0x000180009d67:
                    if (iVar16 != 0) {
                        *(undefined8 *)(puVar34 + -8) = 0x180009d79;
                        func_0x00018000f180(puVar34 + 0x308, iVar23);
                    }
                }
                *(uint32_t *)(puVar34 + 0x30) = uVar39 | 0x52;
                uVar25 = *(undefined8 *)(**(int64_t **)(puVar34 + 0x3d8) + 0x70);
                *(undefined8 *)(puVar34 + -8) = 0x180009d9b;
                uVar18 = func_0x00018045838c();
                *(undefined8 *)(puVar34 + -8) = 0x180009da8;
                pauVar19 = (undefined (*) [16])fcn.180459890(0x50);
                *(undefined (**) [16])(puVar34 + 0x38) = pauVar19;
                *pauVar19 = ZEXT816(0);
                *(undefined4 *)(*pauVar19 + 8) = 1;
                *(undefined4 *)(*pauVar19 + 0xc) = 1;
                *(undefined8 *)*pauVar19 = 0x1805ab1a0;
                *(undefined8 *)pauVar19[1] = 0x1805ab1c8;
                uVar43 = *(undefined4 *)(puVar34 + 0x30c);
                uVar6 = *(undefined4 *)(puVar34 + 0x310);
                uVar7 = *(undefined4 *)(puVar34 + 0x314);
                *(undefined4 *)pauVar19[2] = *(undefined4 *)(puVar34 + 0x308);
                *(undefined4 *)(pauVar19[2] + 4) = uVar43;
                *(undefined4 *)(pauVar19[2] + 8) = uVar6;
                *(undefined4 *)(pauVar19[2] + 0xc) = uVar7;
                uVar43 = *(undefined4 *)(puVar34 + 0x31c);
                uVar6 = *(undefined4 *)(puVar34 + 800);
                uVar7 = *(undefined4 *)(puVar34 + 0x324);
                *(undefined4 *)pauVar19[3] = *(undefined4 *)(puVar34 + 0x318);
                *(undefined4 *)(pauVar19[3] + 4) = uVar43;
                *(undefined4 *)(pauVar19[3] + 8) = uVar6;
                *(undefined4 *)(pauVar19[3] + 0xc) = uVar7;
                *(undefined8 *)(puVar34 + 0x318) = 0;
                *(undefined8 *)(puVar34 + 800) = 0xf;
                puVar34[0x308] = 0;
                *(undefined8 *)pauVar19[4] = uVar25;
                *(undefined8 *)(pauVar19[4] + 8) = uVar18;
                *(undefined4 *)(pauVar19[1] + 8) = 0;
                uVar39 = uVar39 | 0x5a;
                *(undefined (**) [16])(puVar34 + 0x58) = pauVar19 + 1;
                *(undefined (**) [16])(puVar34 + 0x60) = pauVar19;
                *(undefined (*) [16])(puVar34 + 0x70) = ZEXT816(0);
                *(undefined8 *)(puVar34 + -8) = 0x180009e3d;
                func_0x00018000a9d0(uVar15, puVar34 + 0x58);
                piVar20 = *(int64_t **)(puVar34 + 0x60);
                if (piVar20 != (int64_t *)0x0) {
                    LOCK();
                    piVar4 = piVar20 + 1;
                    iVar14 = *(int32_t *)piVar4;
                    *(int32_t *)piVar4 = *(int32_t *)piVar4 + -1;
                    UNLOCK();
                    if (iVar14 == 1) {
                        pcVar5 = *(code **)*piVar20;
                        *(undefined8 *)(puVar34 + -8) = 0x180009e5f;
                        (*pcVar5)(piVar20);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar20 + 0xc);
                        iVar14 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar14 == 1) {
                            pcVar5 = *(code **)(*piVar20 + 8);
                            *(undefined8 *)(puVar34 + -8) = 0x180009e77;
                            (*pcVar5)(piVar20);
                        }
                    }
                }
                *(undefined8 *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0x1f0) + 4) + 0x1f0) =
                     0x1804a6448;
                *(int32_t *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0x1f0) + 4) + 0x1ec) =
                     *(int32_t *)(*(int64_t *)(puVar34 + 0x1f0) + 4) + -0x88;
                *(undefined8 *)(puVar34 + -8) = 0x180009eb9;
                func_0x00018000c970(puVar34 + 0x1f8);
                *(undefined8 *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0x1f0) + 4) + 0x1f0) =
                     0x1804a54f0;
                *(int32_t *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0x1f0) + 4) + 0x1ec) =
                     *(int32_t *)(*(int64_t *)(puVar34 + 0x1f0) + 4) + -0x10;
                *(undefined8 *)(puVar34 + 0x278) = 0x1804a54d0;
                *(undefined8 *)(puVar34 + -8) = 0x180009f06;
                func_0x000180455c14(puVar34 + 0x278);
                *(undefined8 *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xe0) = 0x1805ab280;
                *(int32_t *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xdc) =
                     *(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + -0xb0;
                *(undefined8 *)(puVar34 + -8) = 0x180009f48;
                func_0x00018000c170(puVar34 + 0xf0);
                *(undefined8 *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xe0) = 0x1804a5600;
                *(int32_t *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xdc) =
                     *(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + -0x18;
                *(undefined8 *)(puVar34 + 400) = 0x1804a54d0;
                *(undefined8 *)(puVar34 + -8) = 0x180009f8e;
                func_0x000180455c14(puVar34 + 400);
            } else {
                *(undefined8 *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xe0) = 0x1805ab280;
                *(int32_t *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xdc) =
                     *(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + -0xb0;
                *(undefined8 *)(puVar34 + -8) = 0x180009b36;
                func_0x00018000c170(puVar34 + 0xf0);
                *(undefined8 *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xe0) = 0x1804a5600;
                *(int32_t *)(puVar34 + (int64_t)*(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + 0xdc) =
                     *(int32_t *)(*(int64_t *)(puVar34 + 0xe0) + 4) + -0x18;
                *(undefined8 *)(puVar34 + 400) = 0x1804a54d0;
                *(undefined8 *)(puVar34 + -8) = 0x180009b7c;
                func_0x000180455c14(puVar34 + 400);
                uVar39 = uVar39 | 2;
            }
            puVar36 = puVar36 + 4;
        } while (puVar36 != puVar17);
        puVar36 = *(undefined8 **)(puVar34 + 0x40);
    }
    piVar20 = *(int64_t **)(puVar34 + 0x68);
    iVar16 = *piVar20;
    if (*(int64_t *)(iVar16 + 0xe0) != 0) {
        do {
            puVar38 = *(undefined4 **)
                       (*(int64_t *)(iVar16 + 200) +
                       (*(int64_t *)(iVar16 + 0xd0) - 1U & *(uint64_t *)(iVar16 + 0xd8)) * 8);
            uVar15 = *(undefined8 *)(**(int64_t **)(puVar34 + 0x3d8) + 0x70);
            *(undefined8 *)(puVar34 + -8) = 0x180009ff0;
            uVar25 = func_0x00018045838c();
            *(undefined8 *)(puVar34 + -8) = 0x180009ffd;
            pauVar19 = (undefined (*) [16])fcn.180459890(0x50);
            *(undefined (**) [16])(puVar34 + 0x38) = pauVar19;
            *pauVar19 = ZEXT816(0);
            *(undefined4 *)(*pauVar19 + 8) = 1;
            *(undefined4 *)(*pauVar19 + 0xc) = 1;
            *(undefined8 *)*pauVar19 = 0x1805ab1a0;
            *(undefined4 *)(pauVar19[1] + 8) = 2;
            *(undefined8 *)pauVar19[1] = 0x1805ab1c8;
            pauVar19[2] = ZEXT816(0);
            *(undefined8 *)pauVar19[3] = 0;
            *(undefined8 *)(pauVar19[3] + 8) = 0;
            uVar43 = puVar38[1];
            uVar6 = puVar38[2];
            uVar7 = puVar38[3];
            *(undefined4 *)pauVar19[2] = *puVar38;
            *(undefined4 *)(pauVar19[2] + 4) = uVar43;
            *(undefined4 *)(pauVar19[2] + 8) = uVar6;
            *(undefined4 *)(pauVar19[2] + 0xc) = uVar7;
            uVar43 = puVar38[5];
            uVar6 = puVar38[6];
            uVar7 = puVar38[7];
            *(undefined4 *)pauVar19[3] = puVar38[4];
            *(undefined4 *)(pauVar19[3] + 4) = uVar43;
            *(undefined4 *)(pauVar19[3] + 8) = uVar6;
            *(undefined4 *)(pauVar19[3] + 0xc) = uVar7;
            *(undefined8 *)(puVar38 + 4) = 0;
            *(undefined8 *)(puVar38 + 6) = 0xf;
            *(undefined *)puVar38 = 0;
            *(undefined8 *)pauVar19[4] = uVar15;
            *(undefined8 *)(pauVar19[4] + 8) = uVar25;
            *(undefined4 *)(pauVar19[1] + 8) = 0;
            *(undefined (**) [16])(puVar34 + 0x58) = pauVar19 + 1;
            *(undefined (**) [16])(puVar34 + 0x60) = pauVar19;
            *(undefined (*) [16])(puVar34 + 0x70) = ZEXT816(0);
            *(undefined8 *)(puVar34 + -8) = 0x18000a08f;
            func_0x00018000a9d0(iVar16, puVar34 + 0x58);
            piVar4 = *(int64_t **)(puVar34 + 0x60);
            if (piVar4 != (int64_t *)0x0) {
                LOCK();
                piVar2 = piVar4 + 1;
                iVar14 = *(int32_t *)piVar2;
                *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
                UNLOCK();
                if (iVar14 == 1) {
                    pcVar5 = *(code **)*piVar4;
                    *(undefined8 *)(puVar34 + -8) = 0x18000a0b1;
                    (*pcVar5)(piVar4);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
                    iVar14 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar14 == 1) {
                        pcVar5 = *(code **)(*piVar4 + 8);
                        *(undefined8 *)(puVar34 + -8) = 0x18000a0c9;
                        (*pcVar5)(piVar4);
                    }
                }
            }
            iVar16 = *piVar20;
            uVar15 = *(undefined8 *)
                      (*(int64_t *)(iVar16 + 200) +
                      (*(int64_t *)(iVar16 + 0xd0) - 1U & *(uint64_t *)(iVar16 + 0xd8)) * 8);
            *(undefined8 *)(puVar34 + -8) = 0x18000a0ee;
            fcn.180004e40(uVar15);
            piVar4 = (int64_t *)(iVar16 + 0xe0);
            *piVar4 = *piVar4 + -1;
            if (*piVar4 == 0) {
                *(undefined8 *)(iVar16 + 0xd8) = 0;
            } else {
                *(int64_t *)(iVar16 + 0xd8) = *(int64_t *)(iVar16 + 0xd8) + 1;
            }
            iVar16 = *piVar20;
        } while (*(int64_t *)(iVar16 + 0xe0) != 0);
        puVar36 = *(undefined8 **)(puVar34 + 0x40);
    }
    if (puVar36 != (undefined8 *)0x0) {
        puVar17 = *(undefined8 **)(puVar34 + 0x48);
        if (puVar36 != puVar17) {
            do {
                *(undefined8 *)(puVar34 + -8) = 0x18000a138;
                func_0x00018000dc80(puVar36);
                puVar36 = puVar36 + 4;
            } while (puVar36 != puVar17);
            puVar36 = *(undefined8 **)(puVar34 + 0x40);
        }
        puVar17 = puVar36;
        if (0xfff < (*(int64_t *)(puVar34 + 0x50) - (int64_t)puVar36 & 0xffffffffffffffe0U)) {
            puVar17 = (undefined8 *)puVar36[-1];
            puVar36 = (undefined8 *)((int64_t)puVar36 + (-8 - (int64_t)puVar17));
            if ((undefined8 *)0x1f < puVar36) {
                pcVar5 = (code *)swi(0x29);
                (*pcVar5)(5);
                puVar34 = puVar34 + 8;
                puVar17 = puVar36;
            }
        }
        *(undefined8 *)(puVar34 + -8) = 0x18000a181;
        fcn.180459c3c(puVar17);
        *(undefined (*) [16])(puVar34 + 0x40) = ZEXT816(0);
        *(undefined8 *)(puVar34 + 0x50) = 0;
    }
    *(undefined8 *)(puVar34 + -8) = 0x18000a19c;
    func_0x00018000dc80(puVar34 + 0x370);
    *(undefined8 *)(puVar34 + -8) = 0x18000a1ac;
    func_0x000180459870(*(uint64_t *)(puVar34 + 0x398) ^ (uint64_t)puVar34);
    return;
}

// ============================================================
// Function: FUN_18000a290
// Address: 0x18000a290
// Size: 116 bytes
// ============================================================
void fcn.18000a290(int64_t arg1)
{
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1805ab280;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0xb0;
    fcn.18000c170(arg1 + 0x10);
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a5600;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x18;
    *(undefined8 *)(arg1 + 0xb0) = 0x1804a54d0;
    fcn.180455c14();
    return;
}

// ============================================================
// Function: FUN_18000a310
// Address: 0x18000a310
// Size: 116 bytes
// ============================================================
void fcn.18000a310(int64_t arg1)
{
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a6448;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x88;
    fcn.18000c970(arg1 + 8);
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a54f0;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x10;
    *(undefined8 *)(arg1 + 0x88) = 0x1804a54d0;
    fcn.180455c14();
    return;
}

// ============================================================
// Function: FUN_18000a390
// Address: 0x18000a390
// Size: 271 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18000a390(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    func_0x000180455714(&var_10h, 0);
    iVar5 = *(int64_t *)0x180782408;
    var_18h = *(int64_t *)0x180782408;
    if (*(uint64_t *)0x180780f48 == 0) {
        func_0x000180455714(&var_8h, 0);
        if (*(uint64_t *)0x180780f48 == 0) {
            *(int32_t *)0x180780f30 = *(int32_t *)0x180780f30 + 1;
            *(uint64_t *)0x180780f48 = (uint64_t)*(int32_t *)0x180780f30;
        }
        func_0x00018045578c();
    }
    uVar3 = *(uint64_t *)0x180780f48;
    iVar4 = *(int64_t *)(arg1 + 8);
    iVar1 = *(uint64_t *)0x180780f48 * 8;
    if (*(uint64_t *)0x180780f48 < *(uint64_t *)(iVar4 + 0x18)) {
        iVar6 = *(int64_t *)(iVar1 + *(int64_t *)(iVar4 + 0x10));
        if (iVar6 != 0) goto code_r0x00018000a423;
    } else {
        iVar6 = 0;
    }
    if (*(char *)(iVar4 + 0x24) == '\0') {
code_r0x00018000a458:
        if (iVar6 != 0) goto code_r0x00018000a423;
    } else {
        iVar4 = func_0x0001804558e0();
        if (uVar3 < *(uint64_t *)(iVar4 + 0x18)) {
            iVar6 = *(int64_t *)(iVar1 + *(int64_t *)(iVar4 + 0x10));
            goto code_r0x00018000a458;
        }
    }
    iVar6 = iVar5;
    if (iVar5 == 0) {
        iVar5 = func_0x0001800066e0(&var_18h, arg1);
        iVar6 = var_18h;
        if (iVar5 == -1) {
            func_0x000180005b10();
            pcVar2 = (code *)swi(3);
            iVar5 = (*pcVar2)();
            return iVar5;
        }
        iVar5 = var_18h;
        var_8h = var_18h;
        func_0x0001804558a4(var_18h);
        (**(code **)(*(int64_t *)iVar6 + 8))(iVar6);
        *(int64_t *)0x180782408 = iVar5;
    }
code_r0x00018000a423:
    func_0x00018045578c(&var_10h);
    return iVar6;
}

// ============================================================
// Function: FUN_18000a4a0
// Address: 0x18000a4a0
// Size: 174 bytes
// ============================================================
void fcn.18000a4a0(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined *puVar3;
    undefined auStack_58 [8];
    undefined auStack_50 [32];
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    puVar3 = auStack_58;
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    _var_30h = ZEXT816(0);
    var_20h = 0;
    var_18h = 0;
    func_0x00018000d380(&var_30h, *(undefined8 *)arg2, *(undefined8 *)(arg2 + 8));
    func_0x000180006d80(arg1, &var_30h);
    if (7 < (uint64_t)var_18h) {
        puVar3 = auStack_58;
        iVar2 = var_30h;
        if ((0xfff < var_18h * 2 + 2U) &&
           (iVar2 = *(int64_t *)(var_30h + -8), puVar3 = auStack_58, 0x1f < (var_30h - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar3 = auStack_50;
        }
        *(undefined8 *)(puVar3 + -8) = 0x18000a538;
        fcn.180459c3c(iVar2);
    }
    *(undefined8 *)(puVar3 + -8) = 0x18000a548;
    func_0x000180459870(*(uint64_t *)(puVar3 + 0x48) ^ (uint64_t)puVar3);
    return;
}

// ============================================================
// Function: FUN_18000a550
// Address: 0x18000a550
// Size: 223 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18000a550(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    undefined8 uVar2;
    code *pcVar3;
    uint64_t uVar4;
    int32_t extraout_var;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_28h;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    uVar1 = *(uint64_t *)(arg3 + 8);
    if (uVar1 != 0) {
        if (0x7fffffff < uVar1) {
            func_0x000180006180();
            pcVar3 = (code *)swi(3);
            iVar5 = (*pcVar3)();
            return iVar5;
        }
        uVar2 = *(undefined8 *)arg3;
        uVar4 = func_0x000180454e8c(arg2 & 0xffffffff, uVar2, uVar1 & 0xffffffff, 0, 0);
        if ((int32_t)(uVar4 >> 0x20) != 0) {
            func_0x000180006560(uVar4 >> 0x20);
            pcVar3 = (code *)swi(3);
            iVar5 = (*pcVar3)();
            return iVar5;
        }
        func_0x00018000b3b0(arg1, (int64_t)(int32_t)uVar4, 0);
        iVar5 = arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            iVar5 = *(int64_t *)arg1;
        }
        func_0x000180454e8c(arg2 & 0xffffffff, uVar2, uVar1 & 0xffffffff, iVar5, (int32_t)uVar4);
        if (extraout_var != 0) {
            func_0x000180006560(extraout_var);
            pcVar3 = (code *)swi(3);
            iVar5 = (*pcVar3)();
            return iVar5;
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000a630
// Address: 0x18000a630
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18000a630(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    
    iVar3 = func_0x000180498cd0(arg2);
    piVar1 = (int64_t *)(arg1 + 0x10);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    if (*piVar1 != iVar3) {
        return false;
    }
    if (*piVar1 == 0) {
        return true;
    }
    iVar2 = func_0x000180497f30(arg1, arg2);
    return iVar2 == 0;
}

// ============================================================
// Function: FUN_18000a6a0
// Address: 0x18000a6a0
// Size: 465 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18000a6a0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint32_t uVar4;
    undefined8 uVar5;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_18h;
    
    if (7 < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    *(undefined8 *)arg1 = 0x1805ab198;
    *(undefined8 *)(arg1 + 0xb8) = 0;
    *(undefined8 *)(arg1 + 0xc0) = 0;
    *(undefined4 *)(arg1 + 200) = 0;
    *(undefined8 *)(arg1 + 0xd0) = 0;
    *(undefined8 *)(arg1 + 0xd8) = 0;
    *(undefined8 *)(arg1 + 0xe0) = 0;
    *(undefined8 *)(arg1 + 0xe8) = 0;
    *(undefined8 *)(arg1 + 0xf0) = 0;
    *(undefined8 *)(arg1 + 0xb0) = 0x1804a54e0;
    *(undefined8 *)(arg1 + 0xf8) = 0;
    *(undefined8 *)(arg1 + 0x100) = 0;
    *(undefined *)(arg1 + 0x108) = 0;
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a5600;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x18;
    *(undefined8 *)(arg1 + 8) = 0;
    func_0x00018000fe50(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1, arg1 + 0x10, 0);
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1805ab280;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0xb0;
    func_0x00018000fa40(arg1 + 0x10);
    iVar2 = func_0x00018000f990(arg1 + 0x10, arg2, 0x21);
    if (iVar2 == 0) {
        iVar2 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
        uVar4 = 4;
        if (*(int64_t *)(iVar2 + 0x48 + arg1) != 0) {
            uVar4 = 0;
        }
        uVar4 = uVar4 | *(uint32_t *)(iVar2 + 0x10 + arg1) & 0x15 | 2;
        *(uint32_t *)(iVar2 + 0x10 + arg1) = uVar4;
        uVar4 = uVar4 & *(uint32_t *)(iVar2 + 0x14 + arg1);
        if (uVar4 != 0) {
            if ((uVar4 & 4) == 0) {
                uVar5 = 0x1805aae00;
                if ((uVar4 & 2) == 0) {
                    uVar5 = 0x1805aae18;
                }
            } else {
                uVar5 = 0x1805aade8;
            }
            uVar3 = func_0x000180005e50(&var_58h, 1);
            func_0x0001800069f0(&var_48h, uVar5, uVar3);
            fcn.18045bae0(var_58h);
            pcVar1 = (code *)swi(3);
            iVar2 = (*pcVar1)();
            return iVar2;
        }
    }
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1805ab280;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0xb0;
    return arg1;
}

// ============================================================
// Function: FUN_18000a880
// Address: 0x18000a880
// Size: 191 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18000a880(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined (*pauVar6) [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    pauVar6 = (undefined (*) [16])fcn.180459890(0x50);
    *pauVar6 = ZEXT816(0);
    *(undefined4 *)(*pauVar6 + 8) = 1;
    *(undefined4 *)(*pauVar6 + 0xc) = 1;
    *(undefined8 *)*pauVar6 = 0x1805ab1a0;
    uVar1 = *(undefined8 *)arg3;
    uVar2 = *(undefined8 *)arg2;
    *(undefined4 *)(pauVar6[1] + 8) = 2;
    *(undefined8 *)pauVar6[1] = 0x1805ab1c8;
    pauVar6[2] = ZEXT816(0);
    *(undefined8 *)pauVar6[3] = 0;
    *(undefined8 *)(pauVar6[3] + 8) = 0;
    uVar3 = *(undefined4 *)(arg4 + 4);
    uVar4 = *(undefined4 *)(arg4 + 8);
    uVar5 = *(undefined4 *)(arg4 + 0xc);
    *(undefined4 *)pauVar6[2] = *(undefined4 *)arg4;
    *(undefined4 *)(pauVar6[2] + 4) = uVar3;
    *(undefined4 *)(pauVar6[2] + 8) = uVar4;
    *(undefined4 *)(pauVar6[2] + 0xc) = uVar5;
    uVar3 = *(undefined4 *)(arg4 + 0x14);
    uVar4 = *(undefined4 *)(arg4 + 0x18);
    uVar5 = *(undefined4 *)(arg4 + 0x1c);
    *(undefined4 *)pauVar6[3] = *(undefined4 *)(arg4 + 0x10);
    *(undefined4 *)(pauVar6[3] + 4) = uVar3;
    *(undefined4 *)(pauVar6[3] + 8) = uVar4;
    *(undefined4 *)(pauVar6[3] + 0xc) = uVar5;
    *(undefined8 *)(arg4 + 0x10) = 0;
    *(undefined *)arg4 = 0;
    *(undefined8 *)(arg4 + 0x18) = 0xf;
    *(undefined4 *)(pauVar6[1] + 8) = 0;
    *(undefined8 *)pauVar6[4] = uVar1;
    *(undefined8 *)(pauVar6[4] + 8) = uVar2;
    *(undefined (**) [16])(arg1 + 8) = pauVar6;
    *(undefined (**) [16])arg1 = pauVar6 + 1;
    return arg1;
}

// ============================================================
// Function: FUN_18000a940
// Address: 0x18000a940
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000a940(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x20) {
            func_0x00018000dc80(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffe0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18000a9b6;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18000a955
// Address: 0x18000a955
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000a940(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x20) {
            func_0x00018000dc80(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffe0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18000a9b6;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18000a990
// Address: 0x18000a990
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000a940(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x20) {
            func_0x00018000dc80(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffe0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18000a9b6;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18000a9d0
// Address: 0x18000a9d0
// Size: 736 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18000a9d0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t *piVar7;
    undefined8 uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    undefined *puVar11;
    undefined *puVar12;
    int64_t iVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t *piVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    
    puVar11 = auStack_58;
    puVar12 = auStack_58;
    iVar4 = func_0x000180456008(arg1 + 0x28);
    if (iVar4 == 0) {
        if (*(int32_t *)(arg1 + 0x74) == 0x7fffffff) {
            *(undefined4 *)(arg1 + 0x74) = 0x7ffffffe;
            func_0x0001804542e8(6);
code_r0x00018000acaa:
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            uVar8 = (*pcVar3)();
            return uVar8;
        }
        piVar7 = (int64_t *)(arg1 + 0x20);
        uVar10 = *(uint64_t *)(arg1 + 0x10);
        piVar16 = (int64_t *)0x0;
        if (*piVar7 + 1U < uVar10) {
code_r0x00018000abf7:
            piVar7 = (int64_t *)(arg1 + 0x20);
            *(uint64_t *)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x18) & uVar10 - 1;
            uVar14 = *(int64_t *)(arg1 + 0x18) + *piVar7;
            iVar5 = (uVar14 & uVar10 - 1) * 8;
            if (*(int64_t *)(iVar5 + *(int64_t *)(arg1 + 8)) == 0) {
                *(undefined8 *)(puVar12 + -8) = 0x18000ac28;
                uVar8 = fcn.180459890(0x10);
                *(undefined8 *)(iVar5 + *(int64_t *)(arg1 + 8)) = uVar8;
            }
            puVar2 = *(undefined8 **)(*(int64_t *)(arg1 + 8) + (*(int64_t *)(arg1 + 0x10) - 1U & uVar14) * 8);
            *puVar2 = 0;
            puVar2[1] = 0;
            *puVar2 = *(undefined8 *)arg2;
            puVar2[1] = *(undefined8 *)(arg2 + 8);
            *(undefined8 *)arg2 = 0;
            *(undefined8 *)(arg2 + 8) = 0;
            *piVar7 = *piVar7 + 1;
            *(undefined8 *)(puVar12 + -8) = 0x18000ac6c;
            func_0x000180454ab0(arg1 + 0x78);
            piVar1 = (int32_t *)(arg1 + 0x74);
            *piVar1 = *piVar1 + -1;
            if (*piVar1 == 0) {
                *(undefined4 *)(arg1 + 0x70) = 0xffffffff;
                *(undefined8 *)(puVar12 + 0x28) = 0x18045602b;
                (*(code *)0x69a062)(arg1 + 0x38);
            }
            return 0;
        }
        uVar14 = 1;
        if (uVar10 != 0) {
            uVar14 = uVar10;
        }
        do {
            if ((uVar14 != uVar10) && (7 < uVar14)) {
                uVar10 = *(uint64_t *)(arg1 + 0x18);
                if (0x1fffffffffffffff < uVar14) goto code_r0x00018000acaa;
                uVar6 = uVar14 * 8;
                if (uVar6 != 0) {
                    if (uVar6 < 0x1000) {
                        piVar16 = (int64_t *)fcn.180459890();
                    } else {
                        if (uVar6 + 0x27 <= uVar6) goto code_r0x00018000acaa;
                        iVar5 = fcn.180459890(uVar6 + 0x27);
                        if (iVar5 == 0) goto code_r0x00018000abc4;
                        piVar16 = (int64_t *)(iVar5 + 0x27U & 0xffffffffffffffe0);
                        piVar16[-1] = iVar5;
                    }
                }
                iVar5 = uVar10 * 8;
                uVar6 = uVar14 >> 1;
                for (; uVar14 <= uVar6; uVar14 = uVar14 * 2) {
                }
                uVar14 = uVar14 - *(int64_t *)(arg1 + 0x10);
                iVar9 = *(int64_t *)(arg1 + 8) + iVar5;
                iVar13 = (*(int64_t *)(arg1 + 0x10) * 8 - iVar9) + *(int64_t *)(arg1 + 8);
                func_0x000180498030(piVar16 + uVar10, iVar9, iVar13);
                iVar13 = iVar13 + (int64_t)(piVar16 + uVar10);
                if (uVar14 < uVar10) {
                    iVar15 = uVar14 * 8;
                    func_0x000180498030(iVar13, *(undefined8 *)(arg1 + 8), iVar15);
                    iVar9 = *(int64_t *)(arg1 + 8) + iVar15;
                    iVar5 = (*(int64_t *)(arg1 + 8) - iVar9) + iVar5;
                    func_0x000180498030(piVar16, iVar9, iVar5);
                    piVar7 = (int64_t *)((int64_t)piVar16 + iVar5);
                } else {
                    func_0x000180498030(iVar13, *(undefined8 *)(arg1 + 8), iVar5);
                    func_0x0001804986e0(iVar13 + iVar5, 0, (uVar14 - uVar10) * 8);
                    piVar7 = piVar16;
                    iVar15 = iVar5;
                }
                func_0x0001804986e0(piVar7, 0, iVar15);
                iVar5 = *(int64_t *)(arg1 + 8);
                if (iVar5 != 0) {
                    iVar9 = iVar5;
                    puVar11 = auStack_58;
                    if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
                       (iVar9 = *(int64_t *)(iVar5 + -8), puVar11 = auStack_58, piVar7 = piVar16,
                       0x1f < (iVar5 - iVar9) - 8U)) {
code_r0x00018000abc4:
                        iVar9 = 5;
                        pcVar3 = (code *)swi(0x29);
                        (*pcVar3)(5);
                        puVar11 = auStack_50;
                        piVar16 = piVar7;
                    }
                    *(undefined8 *)(puVar11 + -8) = 0x18000abd6;
                    fcn.180459c3c(iVar9);
                }
                *(int64_t **)(arg1 + 8) = piVar16;
                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + uVar14;
                uVar10 = *(uint64_t *)(arg1 + 0x10);
                arg2 = *(int64_t *)(puVar11 + 0x68);
                puVar12 = puVar11;
                goto code_r0x00018000abf7;
            }
            if (0xfffffffffffffff - uVar14 < uVar14) goto code_r0x00018000ac89;
            uVar14 = uVar14 * 2;
        } while( true );
    }
code_r0x00018000ac8f:
    func_0x0001804542e8(5);
    pcVar3 = (code *)swi(3);
    uVar8 = (*pcVar3)();
    return uVar8;
code_r0x00018000ac89:
    func_0x000180010270();
    goto code_r0x00018000ac8f;
}

// ============================================================
// Function: FUN_18000acb0
// Address: 0x18000acb0
// Size: 35 bytes
// ============================================================
void fcn.18000acb0(int64_t arg1)
{
    if (*(int64_t *)arg1 != 0) {
        fcn.180460d90();
    }
    *(undefined8 *)arg1 = 0;
    return;
}

// ============================================================
// Function: FUN_18000ace0
// Address: 0x18000ace0
// Size: 104 bytes
// ============================================================
void fcn.18000ace0(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 3) * 8;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                pcVar2 = (code *)swi(0x29);
                uVar3 = (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18000ad35;
        fcn.180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18000ad50
// Address: 0x18000ad50
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000ad50(int64_t arg1, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)arg1;
    *(undefined8 *)puVar1[1] = 0;
    puVar1 = (undefined8 *)*puVar1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar2 = (undefined8 *)*puVar1;
        func_0x00018000d070(puVar1 + 2);
        fcn.180459c3c(puVar1, 0x20);
        puVar1 = puVar2;
    }
    if ((*(int64_t *)arg1 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18000ad73
// Address: 0x18000ad73
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000ad50(int64_t arg1, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)arg1;
    *(undefined8 *)puVar1[1] = 0;
    puVar1 = (undefined8 *)*puVar1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar2 = (undefined8 *)*puVar1;
        func_0x00018000d070(puVar1 + 2);
        fcn.180459c3c(puVar1, 0x20);
        puVar1 = puVar2;
    }
    if ((*(int64_t *)arg1 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18000ada6
// Address: 0x18000ada6
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000ad50(int64_t arg1, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)arg1;
    *(undefined8 *)puVar1[1] = 0;
    puVar1 = (undefined8 *)*puVar1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar2 = (undefined8 *)*puVar1;
        func_0x00018000d070(puVar1 + 2);
        fcn.180459c3c(puVar1, 0x20);
        puVar1 = puVar2;
    }
    if ((*(int64_t *)arg1 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18000adc0
// Address: 0x18000adc0
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.18000adc0(int64_t arg1, int64_t arg_30h, int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    uint64_t uVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar1 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar2 = (int64_t **)*ppiVar1;
            if (ppiVar2 != ppiVar1) {
                uVar3 = (uint64_t)ppiVar2[2];
                var_20h = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar2[1];
                var_10h = (((((((((uVar3 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar3 >> 8 & 0xffU) *
                                 0x100000001b3 ^ (int64_t)uVar3 >> 0x10 & 0xffU) * 0x100000001b3 ^
                               (int64_t)uVar3 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x20 & 0xffU) *
                              0x100000001b3 ^ (int64_t)uVar3 >> 0x28 & 0xffU) * 0x100000001b3 ^
                            (int64_t)uVar3 >> 0x30 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x38 & 0xffU) *
                           0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
                var_18h = var_20h + 8 + var_10h;
                var_10h = var_10h + var_20h;
                ppiVar6 = *(int64_t ***)var_18h;
                var_8h = *(int64_t *)var_10h;
                ppiVar8 = ppiVar2;
                do {
                    ppiVar7 = (int64_t **)*ppiVar8;
                    fcn.18000d070(unaff_R14);
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar6) {
                        ppiVar6 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar2) {
                            *(int64_t ***)var_10h = ppiVar1;
                            ppiVar6 = ppiVar1;
                        }
                        *(int64_t ***)var_18h = ppiVar6;
                        while (ppiVar7 != ppiVar1) {
                            piVar5 = ppiVar7[2];
                            var_8h = ((((((((((uint64_t)piVar5 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                            (int64_t)piVar5 >> 8 & 0xffU) * 0x100000001b3 ^
                                           (int64_t)piVar5 >> 0x10 & 0xffU) * 0x100000001b3 ^
                                          (int64_t)piVar5 >> 0x18 & 0xffU) * 0x100000001b3 ^
                                         (int64_t)piVar5 >> 0x20 & 0xffU) * 0x100000001b3 ^
                                        (int64_t)piVar5 >> 0x28 & 0xffU) * 0x100000001b3 ^
                                       (int64_t)piVar5 >> 0x30 & 0xffU) * 0x100000001b3 ^
                                      (int64_t)piVar5 >> 0x38 & 0xffU) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                                     0x10;
                            ppiVar2 = (int64_t **)(var_8h + var_20h);
                            var_8h = var_20h + 8 + var_8h;
                            ppiVar6 = *(int64_t ***)var_8h;
                            ppiVar8 = ppiVar7;
                            while( true ) {
                                ppiVar7 = (int64_t **)*ppiVar8;
                                fcn.18000d070(unaff_R14);
                                fcn.180459c3c(ppiVar8, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar8 == ppiVar6) break;
                                ppiVar8 = ppiVar7;
                                if (ppiVar7 == ppiVar1) {
                                    *ppiVar2 = (int64_t *)ppiVar7;
                                    goto code_r0x00018000af2c;
                                }
                            }
                            *ppiVar2 = (int64_t *)ppiVar1;
                            *(int64_t ***)var_8h = ppiVar1;
                        }
                        goto code_r0x00018000af2c;
                    }
                    ppiVar8 = ppiVar7;
                } while (ppiVar7 != ppiVar1);
                if ((int64_t **)var_8h == ppiVar2) {
                    *(int64_t ***)var_10h = ppiVar7;
                }
code_r0x00018000af2c:
                *ppiVar4 = (int64_t *)ppiVar7;
                ppiVar7[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar1[1] = 0;
            ppiVar1 = (int64_t **)*ppiVar1;
            while (ppiVar1 != (int64_t **)0x0) {
                ppiVar2 = (int64_t **)*ppiVar1;
                fcn.18000d070(unaff_R14);
                fcn.180459c3c(ppiVar1, 0x20);
                ppiVar1 = ppiVar2;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000addc
// Address: 0x18000addc
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.18000adc0(int64_t arg1, int64_t arg_30h, int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    uint64_t uVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar1 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar2 = (int64_t **)*ppiVar1;
            if (ppiVar2 != ppiVar1) {
                uVar3 = (uint64_t)ppiVar2[2];
                var_20h = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar2[1];
                var_10h = (((((((((uVar3 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar3 >> 8 & 0xffU) *
                                 0x100000001b3 ^ (int64_t)uVar3 >> 0x10 & 0xffU) * 0x100000001b3 ^
                               (int64_t)uVar3 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x20 & 0xffU) *
                              0x100000001b3 ^ (int64_t)uVar3 >> 0x28 & 0xffU) * 0x100000001b3 ^
                            (int64_t)uVar3 >> 0x30 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x38 & 0xffU) *
                           0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
                var_18h = var_20h + 8 + var_10h;
                var_10h = var_10h + var_20h;
                ppiVar6 = *(int64_t ***)var_18h;
                var_8h = *(int64_t *)var_10h;
                ppiVar8 = ppiVar2;
                do {
                    ppiVar7 = (int64_t **)*ppiVar8;
                    fcn.18000d070(unaff_R14);
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar6) {
                        ppiVar6 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar2) {
                            *(int64_t ***)var_10h = ppiVar1;
                            ppiVar6 = ppiVar1;
                        }
                        *(int64_t ***)var_18h = ppiVar6;
                        while (ppiVar7 != ppiVar1) {
                            piVar5 = ppiVar7[2];
                            var_8h = ((((((((((uint64_t)piVar5 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                            (int64_t)piVar5 >> 8 & 0xffU) * 0x100000001b3 ^
                                           (int64_t)piVar5 >> 0x10 & 0xffU) * 0x100000001b3 ^
                                          (int64_t)piVar5 >> 0x18 & 0xffU) * 0x100000001b3 ^
                                         (int64_t)piVar5 >> 0x20 & 0xffU) * 0x100000001b3 ^
                                        (int64_t)piVar5 >> 0x28 & 0xffU) * 0x100000001b3 ^
                                       (int64_t)piVar5 >> 0x30 & 0xffU) * 0x100000001b3 ^
                                      (int64_t)piVar5 >> 0x38 & 0xffU) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                                     0x10;
                            ppiVar2 = (int64_t **)(var_8h + var_20h);
                            var_8h = var_20h + 8 + var_8h;
                            ppiVar6 = *(int64_t ***)var_8h;
                            ppiVar8 = ppiVar7;
                            while( true ) {
                                ppiVar7 = (int64_t **)*ppiVar8;
                                fcn.18000d070(unaff_R14);
                                fcn.180459c3c(ppiVar8, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar8 == ppiVar6) break;
                                ppiVar8 = ppiVar7;
                                if (ppiVar7 == ppiVar1) {
                                    *ppiVar2 = (int64_t *)ppiVar7;
                                    goto code_r0x00018000af2c;
                                }
                            }
                            *ppiVar2 = (int64_t *)ppiVar1;
                            *(int64_t ***)var_8h = ppiVar1;
                        }
                        goto code_r0x00018000af2c;
                    }
                    ppiVar8 = ppiVar7;
                } while (ppiVar7 != ppiVar1);
                if ((int64_t **)var_8h == ppiVar2) {
                    *(int64_t ***)var_10h = ppiVar7;
                }
code_r0x00018000af2c:
                *ppiVar4 = (int64_t *)ppiVar7;
                ppiVar7[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar1[1] = 0;
            ppiVar1 = (int64_t **)*ppiVar1;
            while (ppiVar1 != (int64_t **)0x0) {
                ppiVar2 = (int64_t **)*ppiVar1;
                fcn.18000d070(unaff_R14);
                fcn.180459c3c(ppiVar1, 0x20);
                ppiVar1 = ppiVar2;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000adfd
// Address: 0x18000adfd
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.18000adc0(int64_t arg1, int64_t arg_30h, int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    uint64_t uVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar1 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar2 = (int64_t **)*ppiVar1;
            if (ppiVar2 != ppiVar1) {
                uVar3 = (uint64_t)ppiVar2[2];
                var_20h = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar2[1];
                var_10h = (((((((((uVar3 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar3 >> 8 & 0xffU) *
                                 0x100000001b3 ^ (int64_t)uVar3 >> 0x10 & 0xffU) * 0x100000001b3 ^
                               (int64_t)uVar3 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x20 & 0xffU) *
                              0x100000001b3 ^ (int64_t)uVar3 >> 0x28 & 0xffU) * 0x100000001b3 ^
                            (int64_t)uVar3 >> 0x30 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x38 & 0xffU) *
                           0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
                var_18h = var_20h + 8 + var_10h;
                var_10h = var_10h + var_20h;
                ppiVar6 = *(int64_t ***)var_18h;
                var_8h = *(int64_t *)var_10h;
                ppiVar8 = ppiVar2;
                do {
                    ppiVar7 = (int64_t **)*ppiVar8;
                    fcn.18000d070(unaff_R14);
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar6) {
                        ppiVar6 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar2) {
                            *(int64_t ***)var_10h = ppiVar1;
                            ppiVar6 = ppiVar1;
                        }
                        *(int64_t ***)var_18h = ppiVar6;
                        while (ppiVar7 != ppiVar1) {
                            piVar5 = ppiVar7[2];
                            var_8h = ((((((((((uint64_t)piVar5 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                            (int64_t)piVar5 >> 8 & 0xffU) * 0x100000001b3 ^
                                           (int64_t)piVar5 >> 0x10 & 0xffU) * 0x100000001b3 ^
                                          (int64_t)piVar5 >> 0x18 & 0xffU) * 0x100000001b3 ^
                                         (int64_t)piVar5 >> 0x20 & 0xffU) * 0x100000001b3 ^
                                        (int64_t)piVar5 >> 0x28 & 0xffU) * 0x100000001b3 ^
                                       (int64_t)piVar5 >> 0x30 & 0xffU) * 0x100000001b3 ^
                                      (int64_t)piVar5 >> 0x38 & 0xffU) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                                     0x10;
                            ppiVar2 = (int64_t **)(var_8h + var_20h);
                            var_8h = var_20h + 8 + var_8h;
                            ppiVar6 = *(int64_t ***)var_8h;
                            ppiVar8 = ppiVar7;
                            while( true ) {
                                ppiVar7 = (int64_t **)*ppiVar8;
                                fcn.18000d070(unaff_R14);
                                fcn.180459c3c(ppiVar8, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar8 == ppiVar6) break;
                                ppiVar8 = ppiVar7;
                                if (ppiVar7 == ppiVar1) {
                                    *ppiVar2 = (int64_t *)ppiVar7;
                                    goto code_r0x00018000af2c;
                                }
                            }
                            *ppiVar2 = (int64_t *)ppiVar1;
                            *(int64_t ***)var_8h = ppiVar1;
                        }
                        goto code_r0x00018000af2c;
                    }
                    ppiVar8 = ppiVar7;
                } while (ppiVar7 != ppiVar1);
                if ((int64_t **)var_8h == ppiVar2) {
                    *(int64_t ***)var_10h = ppiVar7;
                }
code_r0x00018000af2c:
                *ppiVar4 = (int64_t *)ppiVar7;
                ppiVar7[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar1[1] = 0;
            ppiVar1 = (int64_t **)*ppiVar1;
            while (ppiVar1 != (int64_t **)0x0) {
                ppiVar2 = (int64_t **)*ppiVar1;
                fcn.18000d070(unaff_R14);
                fcn.180459c3c(ppiVar1, 0x20);
                ppiVar1 = ppiVar2;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000ae33
// Address: 0x18000ae33
// Size: 267 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.18000adc0(int64_t arg1, int64_t arg_30h, int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    uint64_t uVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar1 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar2 = (int64_t **)*ppiVar1;
            if (ppiVar2 != ppiVar1) {
                uVar3 = (uint64_t)ppiVar2[2];
                var_20h = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar2[1];
                var_10h = (((((((((uVar3 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar3 >> 8 & 0xffU) *
                                 0x100000001b3 ^ (int64_t)uVar3 >> 0x10 & 0xffU) * 0x100000001b3 ^
                               (int64_t)uVar3 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x20 & 0xffU) *
                              0x100000001b3 ^ (int64_t)uVar3 >> 0x28 & 0xffU) * 0x100000001b3 ^
                            (int64_t)uVar3 >> 0x30 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x38 & 0xffU) *
                           0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
                var_18h = var_20h + 8 + var_10h;
                var_10h = var_10h + var_20h;
                ppiVar6 = *(int64_t ***)var_18h;
                var_8h = *(int64_t *)var_10h;
                ppiVar8 = ppiVar2;
                do {
                    ppiVar7 = (int64_t **)*ppiVar8;
                    fcn.18000d070(unaff_R14);
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar6) {
                        ppiVar6 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar2) {
                            *(int64_t ***)var_10h = ppiVar1;
                            ppiVar6 = ppiVar1;
                        }
                        *(int64_t ***)var_18h = ppiVar6;
                        while (ppiVar7 != ppiVar1) {
                            piVar5 = ppiVar7[2];
                            var_8h = ((((((((((uint64_t)piVar5 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                            (int64_t)piVar5 >> 8 & 0xffU) * 0x100000001b3 ^
                                           (int64_t)piVar5 >> 0x10 & 0xffU) * 0x100000001b3 ^
                                          (int64_t)piVar5 >> 0x18 & 0xffU) * 0x100000001b3 ^
                                         (int64_t)piVar5 >> 0x20 & 0xffU) * 0x100000001b3 ^
                                        (int64_t)piVar5 >> 0x28 & 0xffU) * 0x100000001b3 ^
                                       (int64_t)piVar5 >> 0x30 & 0xffU) * 0x100000001b3 ^
                                      (int64_t)piVar5 >> 0x38 & 0xffU) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                                     0x10;
                            ppiVar2 = (int64_t **)(var_8h + var_20h);
                            var_8h = var_20h + 8 + var_8h;
                            ppiVar6 = *(int64_t ***)var_8h;
                            ppiVar8 = ppiVar7;
                            while( true ) {
                                ppiVar7 = (int64_t **)*ppiVar8;
                                fcn.18000d070(unaff_R14);
                                fcn.180459c3c(ppiVar8, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar8 == ppiVar6) break;
                                ppiVar8 = ppiVar7;
                                if (ppiVar7 == ppiVar1) {
                                    *ppiVar2 = (int64_t *)ppiVar7;
                                    goto code_r0x00018000af2c;
                                }
                            }
                            *ppiVar2 = (int64_t *)ppiVar1;
                            *(int64_t ***)var_8h = ppiVar1;
                        }
                        goto code_r0x00018000af2c;
                    }
                    ppiVar8 = ppiVar7;
                } while (ppiVar7 != ppiVar1);
                if ((int64_t **)var_8h == ppiVar2) {
                    *(int64_t ***)var_10h = ppiVar7;
                }
code_r0x00018000af2c:
                *ppiVar4 = (int64_t *)ppiVar7;
                ppiVar7[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar1[1] = 0;
            ppiVar1 = (int64_t **)*ppiVar1;
            while (ppiVar1 != (int64_t **)0x0) {
                ppiVar2 = (int64_t **)*ppiVar1;
                fcn.18000d070(unaff_R14);
                fcn.180459c3c(ppiVar1, 0x20);
                ppiVar1 = ppiVar2;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000af3e
// Address: 0x18000af3e
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.18000adc0(int64_t arg1, int64_t arg_30h, int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    uint64_t uVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar1 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar2 = (int64_t **)*ppiVar1;
            if (ppiVar2 != ppiVar1) {
                uVar3 = (uint64_t)ppiVar2[2];
                var_20h = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar2[1];
                var_10h = (((((((((uVar3 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar3 >> 8 & 0xffU) *
                                 0x100000001b3 ^ (int64_t)uVar3 >> 0x10 & 0xffU) * 0x100000001b3 ^
                               (int64_t)uVar3 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x20 & 0xffU) *
                              0x100000001b3 ^ (int64_t)uVar3 >> 0x28 & 0xffU) * 0x100000001b3 ^
                            (int64_t)uVar3 >> 0x30 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x38 & 0xffU) *
                           0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
                var_18h = var_20h + 8 + var_10h;
                var_10h = var_10h + var_20h;
                ppiVar6 = *(int64_t ***)var_18h;
                var_8h = *(int64_t *)var_10h;
                ppiVar8 = ppiVar2;
                do {
                    ppiVar7 = (int64_t **)*ppiVar8;
                    fcn.18000d070(unaff_R14);
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar6) {
                        ppiVar6 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar2) {
                            *(int64_t ***)var_10h = ppiVar1;
                            ppiVar6 = ppiVar1;
                        }
                        *(int64_t ***)var_18h = ppiVar6;
                        while (ppiVar7 != ppiVar1) {
                            piVar5 = ppiVar7[2];
                            var_8h = ((((((((((uint64_t)piVar5 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                            (int64_t)piVar5 >> 8 & 0xffU) * 0x100000001b3 ^
                                           (int64_t)piVar5 >> 0x10 & 0xffU) * 0x100000001b3 ^
                                          (int64_t)piVar5 >> 0x18 & 0xffU) * 0x100000001b3 ^
                                         (int64_t)piVar5 >> 0x20 & 0xffU) * 0x100000001b3 ^
                                        (int64_t)piVar5 >> 0x28 & 0xffU) * 0x100000001b3 ^
                                       (int64_t)piVar5 >> 0x30 & 0xffU) * 0x100000001b3 ^
                                      (int64_t)piVar5 >> 0x38 & 0xffU) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                                     0x10;
                            ppiVar2 = (int64_t **)(var_8h + var_20h);
                            var_8h = var_20h + 8 + var_8h;
                            ppiVar6 = *(int64_t ***)var_8h;
                            ppiVar8 = ppiVar7;
                            while( true ) {
                                ppiVar7 = (int64_t **)*ppiVar8;
                                fcn.18000d070(unaff_R14);
                                fcn.180459c3c(ppiVar8, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar8 == ppiVar6) break;
                                ppiVar8 = ppiVar7;
                                if (ppiVar7 == ppiVar1) {
                                    *ppiVar2 = (int64_t *)ppiVar7;
                                    goto code_r0x00018000af2c;
                                }
                            }
                            *ppiVar2 = (int64_t *)ppiVar1;
                            *(int64_t ***)var_8h = ppiVar1;
                        }
                        goto code_r0x00018000af2c;
                    }
                    ppiVar8 = ppiVar7;
                } while (ppiVar7 != ppiVar1);
                if ((int64_t **)var_8h == ppiVar2) {
                    *(int64_t ***)var_10h = ppiVar7;
                }
code_r0x00018000af2c:
                *ppiVar4 = (int64_t *)ppiVar7;
                ppiVar7[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar1[1] = 0;
            ppiVar1 = (int64_t **)*ppiVar1;
            while (ppiVar1 != (int64_t **)0x0) {
                ppiVar2 = (int64_t **)*ppiVar1;
                fcn.18000d070(unaff_R14);
                fcn.180459c3c(ppiVar1, 0x20);
                ppiVar1 = ppiVar2;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000af43
// Address: 0x18000af43
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.18000adc0(int64_t arg1, int64_t arg_30h, int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    uint64_t uVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar1 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar2 = (int64_t **)*ppiVar1;
            if (ppiVar2 != ppiVar1) {
                uVar3 = (uint64_t)ppiVar2[2];
                var_20h = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar2[1];
                var_10h = (((((((((uVar3 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar3 >> 8 & 0xffU) *
                                 0x100000001b3 ^ (int64_t)uVar3 >> 0x10 & 0xffU) * 0x100000001b3 ^
                               (int64_t)uVar3 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x20 & 0xffU) *
                              0x100000001b3 ^ (int64_t)uVar3 >> 0x28 & 0xffU) * 0x100000001b3 ^
                            (int64_t)uVar3 >> 0x30 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x38 & 0xffU) *
                           0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
                var_18h = var_20h + 8 + var_10h;
                var_10h = var_10h + var_20h;
                ppiVar6 = *(int64_t ***)var_18h;
                var_8h = *(int64_t *)var_10h;
                ppiVar8 = ppiVar2;
                do {
                    ppiVar7 = (int64_t **)*ppiVar8;
                    fcn.18000d070(unaff_R14);
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar6) {
                        ppiVar6 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar2) {
                            *(int64_t ***)var_10h = ppiVar1;
                            ppiVar6 = ppiVar1;
                        }
                        *(int64_t ***)var_18h = ppiVar6;
                        while (ppiVar7 != ppiVar1) {
                            piVar5 = ppiVar7[2];
                            var_8h = ((((((((((uint64_t)piVar5 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                            (int64_t)piVar5 >> 8 & 0xffU) * 0x100000001b3 ^
                                           (int64_t)piVar5 >> 0x10 & 0xffU) * 0x100000001b3 ^
                                          (int64_t)piVar5 >> 0x18 & 0xffU) * 0x100000001b3 ^
                                         (int64_t)piVar5 >> 0x20 & 0xffU) * 0x100000001b3 ^
                                        (int64_t)piVar5 >> 0x28 & 0xffU) * 0x100000001b3 ^
                                       (int64_t)piVar5 >> 0x30 & 0xffU) * 0x100000001b3 ^
                                      (int64_t)piVar5 >> 0x38 & 0xffU) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                                     0x10;
                            ppiVar2 = (int64_t **)(var_8h + var_20h);
                            var_8h = var_20h + 8 + var_8h;
                            ppiVar6 = *(int64_t ***)var_8h;
                            ppiVar8 = ppiVar7;
                            while( true ) {
                                ppiVar7 = (int64_t **)*ppiVar8;
                                fcn.18000d070(unaff_R14);
                                fcn.180459c3c(ppiVar8, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar8 == ppiVar6) break;
                                ppiVar8 = ppiVar7;
                                if (ppiVar7 == ppiVar1) {
                                    *ppiVar2 = (int64_t *)ppiVar7;
                                    goto code_r0x00018000af2c;
                                }
                            }
                            *ppiVar2 = (int64_t *)ppiVar1;
                            *(int64_t ***)var_8h = ppiVar1;
                        }
                        goto code_r0x00018000af2c;
                    }
                    ppiVar8 = ppiVar7;
                } while (ppiVar7 != ppiVar1);
                if ((int64_t **)var_8h == ppiVar2) {
                    *(int64_t ***)var_10h = ppiVar7;
                }
code_r0x00018000af2c:
                *ppiVar4 = (int64_t *)ppiVar7;
                ppiVar7[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar1[1] = 0;
            ppiVar1 = (int64_t **)*ppiVar1;
            while (ppiVar1 != (int64_t **)0x0) {
                ppiVar2 = (int64_t **)*ppiVar1;
                fcn.18000d070(unaff_R14);
                fcn.180459c3c(ppiVar1, 0x20);
                ppiVar1 = ppiVar2;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000af57
// Address: 0x18000af57
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.18000adc0(int64_t arg1, int64_t arg_30h, int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    uint64_t uVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar1 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar2 = (int64_t **)*ppiVar1;
            if (ppiVar2 != ppiVar1) {
                uVar3 = (uint64_t)ppiVar2[2];
                var_20h = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar2[1];
                var_10h = (((((((((uVar3 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar3 >> 8 & 0xffU) *
                                 0x100000001b3 ^ (int64_t)uVar3 >> 0x10 & 0xffU) * 0x100000001b3 ^
                               (int64_t)uVar3 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x20 & 0xffU) *
                              0x100000001b3 ^ (int64_t)uVar3 >> 0x28 & 0xffU) * 0x100000001b3 ^
                            (int64_t)uVar3 >> 0x30 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x38 & 0xffU) *
                           0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
                var_18h = var_20h + 8 + var_10h;
                var_10h = var_10h + var_20h;
                ppiVar6 = *(int64_t ***)var_18h;
                var_8h = *(int64_t *)var_10h;
                ppiVar8 = ppiVar2;
                do {
                    ppiVar7 = (int64_t **)*ppiVar8;
                    fcn.18000d070(unaff_R14);
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar6) {
                        ppiVar6 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar2) {
                            *(int64_t ***)var_10h = ppiVar1;
                            ppiVar6 = ppiVar1;
                        }
                        *(int64_t ***)var_18h = ppiVar6;
                        while (ppiVar7 != ppiVar1) {
                            piVar5 = ppiVar7[2];
                            var_8h = ((((((((((uint64_t)piVar5 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                            (int64_t)piVar5 >> 8 & 0xffU) * 0x100000001b3 ^
                                           (int64_t)piVar5 >> 0x10 & 0xffU) * 0x100000001b3 ^
                                          (int64_t)piVar5 >> 0x18 & 0xffU) * 0x100000001b3 ^
                                         (int64_t)piVar5 >> 0x20 & 0xffU) * 0x100000001b3 ^
                                        (int64_t)piVar5 >> 0x28 & 0xffU) * 0x100000001b3 ^
                                       (int64_t)piVar5 >> 0x30 & 0xffU) * 0x100000001b3 ^
                                      (int64_t)piVar5 >> 0x38 & 0xffU) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                                     0x10;
                            ppiVar2 = (int64_t **)(var_8h + var_20h);
                            var_8h = var_20h + 8 + var_8h;
                            ppiVar6 = *(int64_t ***)var_8h;
                            ppiVar8 = ppiVar7;
                            while( true ) {
                                ppiVar7 = (int64_t **)*ppiVar8;
                                fcn.18000d070(unaff_R14);
                                fcn.180459c3c(ppiVar8, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar8 == ppiVar6) break;
                                ppiVar8 = ppiVar7;
                                if (ppiVar7 == ppiVar1) {
                                    *ppiVar2 = (int64_t *)ppiVar7;
                                    goto code_r0x00018000af2c;
                                }
                            }
                            *ppiVar2 = (int64_t *)ppiVar1;
                            *(int64_t ***)var_8h = ppiVar1;
                        }
                        goto code_r0x00018000af2c;
                    }
                    ppiVar8 = ppiVar7;
                } while (ppiVar7 != ppiVar1);
                if ((int64_t **)var_8h == ppiVar2) {
                    *(int64_t ***)var_10h = ppiVar7;
                }
code_r0x00018000af2c:
                *ppiVar4 = (int64_t *)ppiVar7;
                ppiVar7[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar1[1] = 0;
            ppiVar1 = (int64_t **)*ppiVar1;
            while (ppiVar1 != (int64_t **)0x0) {
                ppiVar2 = (int64_t **)*ppiVar1;
                fcn.18000d070(unaff_R14);
                fcn.180459c3c(ppiVar1, 0x20);
                ppiVar1 = ppiVar2;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000af5d
// Address: 0x18000af5d
// Size: 323 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.18000adc0(int64_t arg1, int64_t arg_30h, int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    uint64_t uVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar1 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar2 = (int64_t **)*ppiVar1;
            if (ppiVar2 != ppiVar1) {
                uVar3 = (uint64_t)ppiVar2[2];
                var_20h = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar2[1];
                var_10h = (((((((((uVar3 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar3 >> 8 & 0xffU) *
                                 0x100000001b3 ^ (int64_t)uVar3 >> 0x10 & 0xffU) * 0x100000001b3 ^
                               (int64_t)uVar3 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x20 & 0xffU) *
                              0x100000001b3 ^ (int64_t)uVar3 >> 0x28 & 0xffU) * 0x100000001b3 ^
                            (int64_t)uVar3 >> 0x30 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x38 & 0xffU) *
                           0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
                var_18h = var_20h + 8 + var_10h;
                var_10h = var_10h + var_20h;
                ppiVar6 = *(int64_t ***)var_18h;
                var_8h = *(int64_t *)var_10h;
                ppiVar8 = ppiVar2;
                do {
                    ppiVar7 = (int64_t **)*ppiVar8;
                    fcn.18000d070(unaff_R14);
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar6) {
                        ppiVar6 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar2) {
                            *(int64_t ***)var_10h = ppiVar1;
                            ppiVar6 = ppiVar1;
                        }
                        *(int64_t ***)var_18h = ppiVar6;
                        while (ppiVar7 != ppiVar1) {
                            piVar5 = ppiVar7[2];
                            var_8h = ((((((((((uint64_t)piVar5 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                            (int64_t)piVar5 >> 8 & 0xffU) * 0x100000001b3 ^
                                           (int64_t)piVar5 >> 0x10 & 0xffU) * 0x100000001b3 ^
                                          (int64_t)piVar5 >> 0x18 & 0xffU) * 0x100000001b3 ^
                                         (int64_t)piVar5 >> 0x20 & 0xffU) * 0x100000001b3 ^
                                        (int64_t)piVar5 >> 0x28 & 0xffU) * 0x100000001b3 ^
                                       (int64_t)piVar5 >> 0x30 & 0xffU) * 0x100000001b3 ^
                                      (int64_t)piVar5 >> 0x38 & 0xffU) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                                     0x10;
                            ppiVar2 = (int64_t **)(var_8h + var_20h);
                            var_8h = var_20h + 8 + var_8h;
                            ppiVar6 = *(int64_t ***)var_8h;
                            ppiVar8 = ppiVar7;
                            while( true ) {
                                ppiVar7 = (int64_t **)*ppiVar8;
                                fcn.18000d070(unaff_R14);
                                fcn.180459c3c(ppiVar8, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar8 == ppiVar6) break;
                                ppiVar8 = ppiVar7;
                                if (ppiVar7 == ppiVar1) {
                                    *ppiVar2 = (int64_t *)ppiVar7;
                                    goto code_r0x00018000af2c;
                                }
                            }
                            *ppiVar2 = (int64_t *)ppiVar1;
                            *(int64_t ***)var_8h = ppiVar1;
                        }
                        goto code_r0x00018000af2c;
                    }
                    ppiVar8 = ppiVar7;
                } while (ppiVar7 != ppiVar1);
                if ((int64_t **)var_8h == ppiVar2) {
                    *(int64_t ***)var_10h = ppiVar7;
                }
code_r0x00018000af2c:
                *ppiVar4 = (int64_t *)ppiVar7;
                ppiVar7[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar1[1] = 0;
            ppiVar1 = (int64_t **)*ppiVar1;
            while (ppiVar1 != (int64_t **)0x0) {
                ppiVar2 = (int64_t **)*ppiVar1;
                fcn.18000d070(unaff_R14);
                fcn.180459c3c(ppiVar1, 0x20);
                ppiVar1 = ppiVar2;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000b0a0
// Address: 0x18000b0a0
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.18000adc0(int64_t arg1, int64_t arg_30h, int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    uint64_t uVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar1 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar2 = (int64_t **)*ppiVar1;
            if (ppiVar2 != ppiVar1) {
                uVar3 = (uint64_t)ppiVar2[2];
                var_20h = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar2[1];
                var_10h = (((((((((uVar3 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar3 >> 8 & 0xffU) *
                                 0x100000001b3 ^ (int64_t)uVar3 >> 0x10 & 0xffU) * 0x100000001b3 ^
                               (int64_t)uVar3 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x20 & 0xffU) *
                              0x100000001b3 ^ (int64_t)uVar3 >> 0x28 & 0xffU) * 0x100000001b3 ^
                            (int64_t)uVar3 >> 0x30 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x38 & 0xffU) *
                           0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
                var_18h = var_20h + 8 + var_10h;
                var_10h = var_10h + var_20h;
                ppiVar6 = *(int64_t ***)var_18h;
                var_8h = *(int64_t *)var_10h;
                ppiVar8 = ppiVar2;
                do {
                    ppiVar7 = (int64_t **)*ppiVar8;
                    fcn.18000d070(unaff_R14);
                    fcn.180459c3c(ppiVar8, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar6) {
                        ppiVar6 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar2) {
                            *(int64_t ***)var_10h = ppiVar1;
                            ppiVar6 = ppiVar1;
                        }
                        *(int64_t ***)var_18h = ppiVar6;
                        while (ppiVar7 != ppiVar1) {
                            piVar5 = ppiVar7[2];
                            var_8h = ((((((((((uint64_t)piVar5 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                            (int64_t)piVar5 >> 8 & 0xffU) * 0x100000001b3 ^
                                           (int64_t)piVar5 >> 0x10 & 0xffU) * 0x100000001b3 ^
                                          (int64_t)piVar5 >> 0x18 & 0xffU) * 0x100000001b3 ^
                                         (int64_t)piVar5 >> 0x20 & 0xffU) * 0x100000001b3 ^
                                        (int64_t)piVar5 >> 0x28 & 0xffU) * 0x100000001b3 ^
                                       (int64_t)piVar5 >> 0x30 & 0xffU) * 0x100000001b3 ^
                                      (int64_t)piVar5 >> 0x38 & 0xffU) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                                     0x10;
                            ppiVar2 = (int64_t **)(var_8h + var_20h);
                            var_8h = var_20h + 8 + var_8h;
                            ppiVar6 = *(int64_t ***)var_8h;
                            ppiVar8 = ppiVar7;
                            while( true ) {
                                ppiVar7 = (int64_t **)*ppiVar8;
                                fcn.18000d070(unaff_R14);
                                fcn.180459c3c(ppiVar8, 0x20);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar8 == ppiVar6) break;
                                ppiVar8 = ppiVar7;
                                if (ppiVar7 == ppiVar1) {
                                    *ppiVar2 = (int64_t *)ppiVar7;
                                    goto code_r0x00018000af2c;
                                }
                            }
                            *ppiVar2 = (int64_t *)ppiVar1;
                            *(int64_t ***)var_8h = ppiVar1;
                        }
                        goto code_r0x00018000af2c;
                    }
                    ppiVar8 = ppiVar7;
                } while (ppiVar7 != ppiVar1);
                if ((int64_t **)var_8h == ppiVar2) {
                    *(int64_t ***)var_10h = ppiVar7;
                }
code_r0x00018000af2c:
                *ppiVar4 = (int64_t *)ppiVar7;
                ppiVar7[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar1[1] = 0;
            ppiVar1 = (int64_t **)*ppiVar1;
            while (ppiVar1 != (int64_t **)0x0) {
                ppiVar2 = (int64_t **)*ppiVar1;
                fcn.18000d070(unaff_R14);
                fcn.180459c3c(ppiVar1, 0x20);
                ppiVar1 = ppiVar2;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000b160
// Address: 0x18000b160
// Size: 62 bytes
// ============================================================
int64_t fcn.18000b160(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    
    if (*(uint64_t *)(arg1 + 0x10) < (uint64_t)arg2) {
        fcn.18000f930();
        pcVar1 = (code *)swi(3);
        iVar2 = (*pcVar1)();
        return iVar2;
    }
    *(int64_t *)(arg1 + 0x10) = arg2;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        *(undefined2 *)(*(int64_t *)arg1 + arg2 * 2) = 0;
        return arg1;
    }
    *(undefined2 *)(arg1 + arg2 * 2) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18000b1a0
// Address: 0x18000b1a0
// Size: 149 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000b1a0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined *puVar5;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    if (arg1 != arg2) {
        if (7 < *(uint64_t *)(arg1 + 0x18)) {
            puVar5 = auStack_28;
            if ((0xfff < *(uint64_t *)(arg1 + 0x18) * 2 + 2) &&
               (puVar5 = auStack_28, 0x1f < (*(int64_t *)arg1 - *(int64_t *)(*(int64_t *)arg1 + -8)) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar5 = auStack_20;
            }
            *(undefined8 *)(puVar5 + -8) = 0x18000b1f9;
            fcn.180459c3c();
        }
        *(undefined8 *)(arg1 + 0x18) = 7;
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined2 *)arg1 = 0;
        uVar2 = *(undefined4 *)(arg2 + 4);
        uVar3 = *(undefined4 *)(arg2 + 8);
        uVar4 = *(undefined4 *)(arg2 + 0xc);
        *(undefined4 *)arg1 = *(undefined4 *)arg2;
        *(undefined4 *)(arg1 + 4) = uVar2;
        *(undefined4 *)(arg1 + 8) = uVar3;
        *(undefined4 *)(arg1 + 0xc) = uVar4;
        uVar2 = *(undefined4 *)(arg2 + 0x14);
        uVar3 = *(undefined4 *)(arg2 + 0x18);
        uVar4 = *(undefined4 *)(arg2 + 0x1c);
        *(undefined4 *)(arg1 + 0x10) = *(undefined4 *)(arg2 + 0x10);
        *(undefined4 *)(arg1 + 0x14) = uVar2;
        *(undefined4 *)(arg1 + 0x18) = uVar3;
        *(undefined4 *)(arg1 + 0x1c) = uVar4;
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 7;
        *(undefined2 *)arg2 = 0;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000b240
// Address: 0x18000b240
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.18000b240(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    if ((uint64_t)arg2 <= uVar3) {
        return;
    }
    uVar8 = 0x7fffffffffffffff;
    iVar4 = *(int64_t *)(arg1 + 0x10);
    if (0x7fffffffffffffffU - iVar4 < (uint64_t)(arg2 - iVar4)) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar7 = arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar3 <= 0x7fffffffffffffff - (uVar3 >> 1))) {
        uVar2 = (uVar3 >> 1) + uVar3;
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RSI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000b2ec;
            }
            unaff_RSI = fcn.180459890(uVar2);
        }
code_r0x00018000b30f:
        *(int64_t *)(arg1 + 0x10) = arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar3 < 0x10) {
            func_0x000180498030(unaff_RSI, arg1, iVar4 + 1);
            goto code_r0x00018000b371;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RSI, uVar8, iVar4 + 1);
        if (0xfff < uVar3 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar3 + 0x28);
                goto code_r0x00018000b371;
            }
            goto code_r0x00018000b358;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000b2ec:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RSI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar6;
            goto code_r0x00018000b30f;
        }
code_r0x00018000b358:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000b367;
    fcn.180459c3c(uVar8);
code_r0x00018000b371:
    *(uint64_t *)arg1 = unaff_RSI;
    *(int64_t *)(arg1 + 0x10) = iVar4;
    return;
}

// ============================================================
// Function: FUN_18000b25c
// Address: 0x18000b25c
// Size: 304 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.18000b240(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    if ((uint64_t)arg2 <= uVar3) {
        return;
    }
    uVar8 = 0x7fffffffffffffff;
    iVar4 = *(int64_t *)(arg1 + 0x10);
    if (0x7fffffffffffffffU - iVar4 < (uint64_t)(arg2 - iVar4)) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar7 = arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar3 <= 0x7fffffffffffffff - (uVar3 >> 1))) {
        uVar2 = (uVar3 >> 1) + uVar3;
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RSI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000b2ec;
            }
            unaff_RSI = fcn.180459890(uVar2);
        }
code_r0x00018000b30f:
        *(int64_t *)(arg1 + 0x10) = arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar3 < 0x10) {
            func_0x000180498030(unaff_RSI, arg1, iVar4 + 1);
            goto code_r0x00018000b371;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RSI, uVar8, iVar4 + 1);
        if (0xfff < uVar3 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar3 + 0x28);
                goto code_r0x00018000b371;
            }
            goto code_r0x00018000b358;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000b2ec:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RSI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar6;
            goto code_r0x00018000b30f;
        }
code_r0x00018000b358:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000b367;
    fcn.180459c3c(uVar8);
code_r0x00018000b371:
    *(uint64_t *)arg1 = unaff_RSI;
    *(int64_t *)(arg1 + 0x10) = iVar4;
    return;
}

// ============================================================
// Function: FUN_18000b38c
// Address: 0x18000b38c
// Size: 9 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.18000b240(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    if ((uint64_t)arg2 <= uVar3) {
        return;
    }
    uVar8 = 0x7fffffffffffffff;
    iVar4 = *(int64_t *)(arg1 + 0x10);
    if (0x7fffffffffffffffU - iVar4 < (uint64_t)(arg2 - iVar4)) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar7 = arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar3 <= 0x7fffffffffffffff - (uVar3 >> 1))) {
        uVar2 = (uVar3 >> 1) + uVar3;
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RSI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000b2ec;
            }
            unaff_RSI = fcn.180459890(uVar2);
        }
code_r0x00018000b30f:
        *(int64_t *)(arg1 + 0x10) = arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar3 < 0x10) {
            func_0x000180498030(unaff_RSI, arg1, iVar4 + 1);
            goto code_r0x00018000b371;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RSI, uVar8, iVar4 + 1);
        if (0xfff < uVar3 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar3 + 0x28);
                goto code_r0x00018000b371;
            }
            goto code_r0x00018000b358;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000b2ec:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RSI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar6;
            goto code_r0x00018000b30f;
        }
code_r0x00018000b358:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000b367;
    fcn.180459c3c(uVar8);
code_r0x00018000b371:
    *(uint64_t *)arg1 = unaff_RSI;
    *(int64_t *)(arg1 + 0x10) = iVar4;
    return;
}

// ============================================================
// Function: FUN_18000b395
// Address: 0x18000b395
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.18000b240(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    if ((uint64_t)arg2 <= uVar3) {
        return;
    }
    uVar8 = 0x7fffffffffffffff;
    iVar4 = *(int64_t *)(arg1 + 0x10);
    if (0x7fffffffffffffffU - iVar4 < (uint64_t)(arg2 - iVar4)) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar7 = arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar3 <= 0x7fffffffffffffff - (uVar3 >> 1))) {
        uVar2 = (uVar3 >> 1) + uVar3;
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RSI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000b2ec;
            }
            unaff_RSI = fcn.180459890(uVar2);
        }
code_r0x00018000b30f:
        *(int64_t *)(arg1 + 0x10) = arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar3 < 0x10) {
            func_0x000180498030(unaff_RSI, arg1, iVar4 + 1);
            goto code_r0x00018000b371;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RSI, uVar8, iVar4 + 1);
        if (0xfff < uVar3 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar3 + 0x28);
                goto code_r0x00018000b371;
            }
            goto code_r0x00018000b358;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000b2ec:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RSI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar6;
            goto code_r0x00018000b30f;
        }
code_r0x00018000b358:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000b367;
    fcn.180459c3c(uVar8);
code_r0x00018000b371:
    *(uint64_t *)arg1 = unaff_RSI;
    *(int64_t *)(arg1 + 0x10) = iVar4;
    return;
}

// ============================================================
// Function: FUN_18000b39b
// Address: 0x18000b39b
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.18000b240(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    if ((uint64_t)arg2 <= uVar3) {
        return;
    }
    uVar8 = 0x7fffffffffffffff;
    iVar4 = *(int64_t *)(arg1 + 0x10);
    if (0x7fffffffffffffffU - iVar4 < (uint64_t)(arg2 - iVar4)) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar7 = arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar3 <= 0x7fffffffffffffff - (uVar3 >> 1))) {
        uVar2 = (uVar3 >> 1) + uVar3;
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RSI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000b2ec;
            }
            unaff_RSI = fcn.180459890(uVar2);
        }
code_r0x00018000b30f:
        *(int64_t *)(arg1 + 0x10) = arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar3 < 0x10) {
            func_0x000180498030(unaff_RSI, arg1, iVar4 + 1);
            goto code_r0x00018000b371;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RSI, uVar8, iVar4 + 1);
        if (0xfff < uVar3 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar3 + 0x28);
                goto code_r0x00018000b371;
            }
            goto code_r0x00018000b358;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000b2ec:
        iVar6 = fcn.180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RSI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar6;
            goto code_r0x00018000b30f;
        }
code_r0x00018000b358:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000b367;
    fcn.180459c3c(uVar8);
code_r0x00018000b371:
    *(uint64_t *)arg1 = unaff_RSI;
    *(int64_t *)(arg1 + 0x10) = iVar4;
    return;
}

// ============================================================
// Function: FUN_18000b3b0
// Address: 0x18000b3b0
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000b3b0(int64_t arg1, int64_t arg2, int64_t arg_50h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    char in_R8B;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if ((uint64_t)arg2 <= uVar1) {
        *(int64_t *)(arg1 + 0x10) = arg2;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        *(undefined *)(arg1 + arg2) = 0;
        return;
    }
    uVar2 = arg2 - uVar1;
    if (uVar2 <= *(uint64_t *)(arg1 + 0x18) - uVar1) {
        *(int64_t *)(arg1 + 0x10) = arg2;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        fcn.1804986e0(uVar1 + arg1, (int32_t)in_R8B, uVar2);
        *(undefined *)(uVar1 + arg1 + uVar2) = 0;
        return;
    }
    fcn.18000f2f0(CONCAT71(var_18h._1_7_, in_R8B));
    return;
}

// ============================================================
// Function: FUN_18000b3dc
// Address: 0x18000b3dc
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000b3b0(int64_t arg1, int64_t arg2, int64_t arg_50h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    char in_R8B;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if ((uint64_t)arg2 <= uVar1) {
        *(int64_t *)(arg1 + 0x10) = arg2;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        *(undefined *)(arg1 + arg2) = 0;
        return;
    }
    uVar2 = arg2 - uVar1;
    if (uVar2 <= *(uint64_t *)(arg1 + 0x18) - uVar1) {
        *(int64_t *)(arg1 + 0x10) = arg2;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        fcn.1804986e0(uVar1 + arg1, (int32_t)in_R8B, uVar2);
        *(undefined *)(uVar1 + arg1 + uVar2) = 0;
        return;
    }
    fcn.18000f2f0(CONCAT71(var_18h._1_7_, in_R8B));
    return;
}

// ============================================================
// Function: FUN_18000b429
// Address: 0x18000b429
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18000b3b0(int64_t arg1, int64_t arg2, int64_t arg_50h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    char in_R8B;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_8h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if ((uint64_t)arg2 <= uVar1) {
        *(int64_t *)(arg1 + 0x10) = arg2;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        *(undefined *)(arg1 + arg2) = 0;
        return;
    }
    uVar2 = arg2 - uVar1;
    if (uVar2 <= *(uint64_t *)(arg1 + 0x18) - uVar1) {
        *(int64_t *)(arg1 + 0x10) = arg2;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        fcn.1804986e0(uVar1 + arg1, (int32_t)in_R8B, uVar2);
        *(undefined *)(uVar1 + arg1 + uVar2) = 0;
        return;
    }
    fcn.18000f2f0(CONCAT71(var_18h._1_7_, in_R8B));
    return;
}

// ============================================================
// Function: FUN_18000b460
// Address: 0x18000b460
// Size: 105 bytes
// ============================================================
int64_t fcn.18000b460(int64_t arg1)
{
    uint64_t uVar1;
    int64_t iVar2;
    undefined in_DL;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) <= uVar1) {
        fcn.18000f010(arg1, 1, (undefined)var_10h, in_DL);
        return arg1;
    }
    *(uint64_t *)(arg1 + 0x10) = uVar1 + 1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar2 = *(int64_t *)arg1;
        *(undefined *)(uVar1 + iVar2) = in_DL;
        *(undefined *)(uVar1 + 1 + iVar2) = 0;
        return arg1;
    }
    *(undefined *)(uVar1 + arg1) = in_DL;
    *(undefined *)(uVar1 + 1 + arg1) = 0;
    return arg1;
}

