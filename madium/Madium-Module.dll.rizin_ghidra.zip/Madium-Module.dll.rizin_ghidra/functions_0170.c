// Chunk 170 - 50 functions

// ============================================================
// Function: FUN_18022783e
// Address: 0x18022783e
// Size: 56 bytes
// ============================================================
int32_t fcn.18022783e(int64_t arg_28h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t var_20h;
    
    fcn.180184b50();
    iVar1 = *(int32_t *)(unaff_RSI + 0x38);
    fcn.18000ce10();
    iVar1 = (*(code *)0x8000000000000014)((int64_t)iVar1);
    fcn.180219ce0();
    if (iVar1 < 1) {
        iVar2 = fcn.180228650(iVar1);
        if (iVar2 != 0) {
            fcn.18021b250();
            uVar3 = (*(code *)0x800000000000006f)();
            *(undefined4 *)(unaff_RBP + 0x3c) = uVar3;
        }
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180227876
// Address: 0x180227876
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_50h
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel

int32_t fcn.18022783e(int64_t arg_28h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t var_20h;
    
    fcn.180184b50();
    iVar1 = *(int32_t *)(unaff_RSI + 0x38);
    fcn.18000ce10();
    iVar1 = (*(code *)0x8000000000000014)((int64_t)iVar1);
    fcn.180219ce0();
    if (iVar1 < 1) {
        iVar2 = fcn.180228650(iVar1);
        if (iVar2 != 0) {
            fcn.18021b250();
            uVar3 = (*(code *)0x800000000000006f)();
            *(undefined4 *)(unaff_RBP + 0x3c) = uVar3;
        }
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180227893
// Address: 0x180227893
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_50h
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel

int32_t fcn.18022783e(int64_t arg_28h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t var_20h;
    
    fcn.180184b50();
    iVar1 = *(int32_t *)(unaff_RSI + 0x38);
    fcn.18000ce10();
    iVar1 = (*(code *)0x8000000000000014)((int64_t)iVar1);
    fcn.180219ce0();
    if (iVar1 < 1) {
        iVar2 = fcn.180228650(iVar1);
        if (iVar2 != 0) {
            fcn.18021b250();
            uVar3 = (*(code *)0x800000000000006f)();
            *(undefined4 *)(unaff_RBP + 0x3c) = uVar3;
        }
    }
    return iVar1;
}

// ============================================================
// Function: FUN_1802278c0
// Address: 0x1802278c0
// Size: 65 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.1802278c0(int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_110h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int32_t iVar5;
    undefined4 uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int64_t var_8h;
    int32_t var_10h;
    undefined4 var_14h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1802278d1;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_40h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7);
    iVar2 = *(int64_t *)(in_RCX + 0x40);
    *(undefined4 *)((int64_t)&var_18h + iVar7) = 0x1c;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_R12;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022791b;
        (*(code *)0x8000000000000070)(0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227925;
        func_0x00018026be30((int64_t)&var_20h + iVar7);
        iVar3 = *(int64_t *)(in_RCX + 0x40);
        if (*(int64_t *)(iVar3 + 0x48) != 0) {
            iVar5 = *(int32_t *)(in_RCX + 0x38);
            *(int64_t *)(&stack0x00000000 + iVar7) = (int64_t)&var_14h + iVar7;
            *(undefined4 *)((int64_t)&var_14h + iVar7) = 4;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022796a;
            iVar5 = (*(code *)0x8000000000000007)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_10h + iVar7);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227973;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022798b;
                func_0x0001802295a0(0x1804bfff0, 0x13e, 0x1804c0008);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227991;
                uVar6 = (*(code *)0x800000000000006f)();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802279a4;
                func_0x0001802296d0(2, uVar6, 0x1804c0028);
            } else {
                *(int64_t *)(iVar3 + 0x50) = (int64_t)*(int32_t *)((int64_t)&var_10h + iVar7) * 1000000;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802279bb;
            uVar8 = func_0x0001802450c0();
            if ((*(uint64_t *)(iVar3 + 0x48) < uVar8) || (uVar8 = *(uint64_t *)(iVar3 + 0x48) - uVar8, uVar8 < 1000)) {
                uVar8 = 1000;
            }
            uVar4 = *(uint64_t *)(iVar3 + 0x50);
            if (((uVar4 == 0) || (uVar8 < uVar4)) || (uVar8 <= uVar4)) {
                *(undefined4 *)(&stack0x00000000 + iVar7) = 4;
                iVar5 = *(int32_t *)(in_RCX + 0x38);
                *(int32_t *)((int64_t)&var_10h + iVar7) = (int32_t)(uVar8 / 1000000);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a15;
                iVar5 = (*(code *)0x8000000000000015)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_10h + iVar7);
                if (iVar5 < 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a1e;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a36;
                    func_0x0001802295a0(0x1804bfff0, 0x15c, 0x1804c0008);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a3c;
                    uVar6 = (*(code *)0x800000000000006f)();
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a4f;
                    func_0x0001802296d0(2, uVar6, 0x1804b8760);
                }
            }
        }
        iVar5 = *(int32_t *)(iVar2 + 0x58);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a64;
        uVar9 = fcn.18000ce10((int64_t)&var_20h + iVar7);
        iVar1 = *(int32_t *)(in_RCX + 0x38);
        *(int64_t *)((int64_t)&var_10h + iVar7 + -8) = (int64_t)&var_18h + iVar7;
        *(undefined8 *)(&stack0x00000000 + iVar7) = uVar9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a86;
        iVar5 = (*(code *)0x8000000000000011)((int64_t)iVar1, in_RDX, in_R8 & 0xffffffff, -(iVar5 != 0) & 2);
        if ((*(int32_t *)(iVar2 + 0x38) == 0) && (-1 < iVar5)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aad;
            func_0x000180219d10(in_RCX, 0x2c, 0, (int64_t)&var_20h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aba;
            fcn.180219ce0(in_RCX, 0xf);
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ac9;
            fcn.180219ce0(in_RCX, 0xf);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ad4;
                iVar5 = fcn.180228650(iVar5);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ae5;
                    fcn.18021b250(in_RCX, 9);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aeb;
                    uVar6 = (*(code *)0x800000000000006f)();
                    *(undefined4 *)(iVar2 + 0x3c) = uVar6;
                }
            }
        }
        iVar2 = *(int64_t *)(in_RCX + 0x40);
        if (*(int64_t *)(iVar2 + 0x48) != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar7) = 4;
            iVar5 = *(int32_t *)(in_RCX + 0x38);
            *(int32_t *)((int64_t)&var_14h + iVar7) = (int32_t)(*(uint64_t *)(iVar2 + 0x50) / 1000000);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b2b;
            iVar5 = (*(code *)0x8000000000000015)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_14h + iVar7);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b34;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b4c;
                func_0x0001802295a0(0x1804bfff0, 0x18b, 0x1804c0040);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b52;
                uVar6 = (*(code *)0x800000000000006f)();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b65;
                func_0x0001802296d0(2, uVar6, 0x1804b8760);
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b81;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_40h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_180227901
// Address: 0x180227901
// Size: 10 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.1802278c0(int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_110h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int32_t iVar5;
    undefined4 uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int64_t var_8h;
    int32_t var_10h;
    undefined4 var_14h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1802278d1;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_40h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7);
    iVar2 = *(int64_t *)(in_RCX + 0x40);
    *(undefined4 *)((int64_t)&var_18h + iVar7) = 0x1c;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_R12;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022791b;
        (*(code *)0x8000000000000070)(0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227925;
        func_0x00018026be30((int64_t)&var_20h + iVar7);
        iVar3 = *(int64_t *)(in_RCX + 0x40);
        if (*(int64_t *)(iVar3 + 0x48) != 0) {
            iVar5 = *(int32_t *)(in_RCX + 0x38);
            *(int64_t *)(&stack0x00000000 + iVar7) = (int64_t)&var_14h + iVar7;
            *(undefined4 *)((int64_t)&var_14h + iVar7) = 4;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022796a;
            iVar5 = (*(code *)0x8000000000000007)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_10h + iVar7);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227973;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022798b;
                func_0x0001802295a0(0x1804bfff0, 0x13e, 0x1804c0008);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227991;
                uVar6 = (*(code *)0x800000000000006f)();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802279a4;
                func_0x0001802296d0(2, uVar6, 0x1804c0028);
            } else {
                *(int64_t *)(iVar3 + 0x50) = (int64_t)*(int32_t *)((int64_t)&var_10h + iVar7) * 1000000;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802279bb;
            uVar8 = func_0x0001802450c0();
            if ((*(uint64_t *)(iVar3 + 0x48) < uVar8) || (uVar8 = *(uint64_t *)(iVar3 + 0x48) - uVar8, uVar8 < 1000)) {
                uVar8 = 1000;
            }
            uVar4 = *(uint64_t *)(iVar3 + 0x50);
            if (((uVar4 == 0) || (uVar8 < uVar4)) || (uVar8 <= uVar4)) {
                *(undefined4 *)(&stack0x00000000 + iVar7) = 4;
                iVar5 = *(int32_t *)(in_RCX + 0x38);
                *(int32_t *)((int64_t)&var_10h + iVar7) = (int32_t)(uVar8 / 1000000);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a15;
                iVar5 = (*(code *)0x8000000000000015)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_10h + iVar7);
                if (iVar5 < 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a1e;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a36;
                    func_0x0001802295a0(0x1804bfff0, 0x15c, 0x1804c0008);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a3c;
                    uVar6 = (*(code *)0x800000000000006f)();
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a4f;
                    func_0x0001802296d0(2, uVar6, 0x1804b8760);
                }
            }
        }
        iVar5 = *(int32_t *)(iVar2 + 0x58);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a64;
        uVar9 = fcn.18000ce10((int64_t)&var_20h + iVar7);
        iVar1 = *(int32_t *)(in_RCX + 0x38);
        *(int64_t *)((int64_t)&var_10h + iVar7 + -8) = (int64_t)&var_18h + iVar7;
        *(undefined8 *)(&stack0x00000000 + iVar7) = uVar9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a86;
        iVar5 = (*(code *)0x8000000000000011)((int64_t)iVar1, in_RDX, in_R8 & 0xffffffff, -(iVar5 != 0) & 2);
        if ((*(int32_t *)(iVar2 + 0x38) == 0) && (-1 < iVar5)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aad;
            func_0x000180219d10(in_RCX, 0x2c, 0, (int64_t)&var_20h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aba;
            fcn.180219ce0(in_RCX, 0xf);
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ac9;
            fcn.180219ce0(in_RCX, 0xf);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ad4;
                iVar5 = fcn.180228650(iVar5);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ae5;
                    fcn.18021b250(in_RCX, 9);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aeb;
                    uVar6 = (*(code *)0x800000000000006f)();
                    *(undefined4 *)(iVar2 + 0x3c) = uVar6;
                }
            }
        }
        iVar2 = *(int64_t *)(in_RCX + 0x40);
        if (*(int64_t *)(iVar2 + 0x48) != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar7) = 4;
            iVar5 = *(int32_t *)(in_RCX + 0x38);
            *(int32_t *)((int64_t)&var_14h + iVar7) = (int32_t)(*(uint64_t *)(iVar2 + 0x50) / 1000000);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b2b;
            iVar5 = (*(code *)0x8000000000000015)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_14h + iVar7);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b34;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b4c;
                func_0x0001802295a0(0x1804bfff0, 0x18b, 0x1804c0040);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b52;
                uVar6 = (*(code *)0x800000000000006f)();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b65;
                func_0x0001802296d0(2, uVar6, 0x1804b8760);
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b81;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_40h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18022790b
// Address: 0x18022790b
// Size: 393 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.1802278c0(int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_110h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int32_t iVar5;
    undefined4 uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int64_t var_8h;
    int32_t var_10h;
    undefined4 var_14h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1802278d1;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_40h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7);
    iVar2 = *(int64_t *)(in_RCX + 0x40);
    *(undefined4 *)((int64_t)&var_18h + iVar7) = 0x1c;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_R12;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022791b;
        (*(code *)0x8000000000000070)(0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227925;
        func_0x00018026be30((int64_t)&var_20h + iVar7);
        iVar3 = *(int64_t *)(in_RCX + 0x40);
        if (*(int64_t *)(iVar3 + 0x48) != 0) {
            iVar5 = *(int32_t *)(in_RCX + 0x38);
            *(int64_t *)(&stack0x00000000 + iVar7) = (int64_t)&var_14h + iVar7;
            *(undefined4 *)((int64_t)&var_14h + iVar7) = 4;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022796a;
            iVar5 = (*(code *)0x8000000000000007)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_10h + iVar7);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227973;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022798b;
                func_0x0001802295a0(0x1804bfff0, 0x13e, 0x1804c0008);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227991;
                uVar6 = (*(code *)0x800000000000006f)();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802279a4;
                func_0x0001802296d0(2, uVar6, 0x1804c0028);
            } else {
                *(int64_t *)(iVar3 + 0x50) = (int64_t)*(int32_t *)((int64_t)&var_10h + iVar7) * 1000000;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802279bb;
            uVar8 = func_0x0001802450c0();
            if ((*(uint64_t *)(iVar3 + 0x48) < uVar8) || (uVar8 = *(uint64_t *)(iVar3 + 0x48) - uVar8, uVar8 < 1000)) {
                uVar8 = 1000;
            }
            uVar4 = *(uint64_t *)(iVar3 + 0x50);
            if (((uVar4 == 0) || (uVar8 < uVar4)) || (uVar8 <= uVar4)) {
                *(undefined4 *)(&stack0x00000000 + iVar7) = 4;
                iVar5 = *(int32_t *)(in_RCX + 0x38);
                *(int32_t *)((int64_t)&var_10h + iVar7) = (int32_t)(uVar8 / 1000000);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a15;
                iVar5 = (*(code *)0x8000000000000015)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_10h + iVar7);
                if (iVar5 < 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a1e;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a36;
                    func_0x0001802295a0(0x1804bfff0, 0x15c, 0x1804c0008);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a3c;
                    uVar6 = (*(code *)0x800000000000006f)();
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a4f;
                    func_0x0001802296d0(2, uVar6, 0x1804b8760);
                }
            }
        }
        iVar5 = *(int32_t *)(iVar2 + 0x58);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a64;
        uVar9 = fcn.18000ce10((int64_t)&var_20h + iVar7);
        iVar1 = *(int32_t *)(in_RCX + 0x38);
        *(int64_t *)((int64_t)&var_10h + iVar7 + -8) = (int64_t)&var_18h + iVar7;
        *(undefined8 *)(&stack0x00000000 + iVar7) = uVar9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a86;
        iVar5 = (*(code *)0x8000000000000011)((int64_t)iVar1, in_RDX, in_R8 & 0xffffffff, -(iVar5 != 0) & 2);
        if ((*(int32_t *)(iVar2 + 0x38) == 0) && (-1 < iVar5)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aad;
            func_0x000180219d10(in_RCX, 0x2c, 0, (int64_t)&var_20h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aba;
            fcn.180219ce0(in_RCX, 0xf);
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ac9;
            fcn.180219ce0(in_RCX, 0xf);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ad4;
                iVar5 = fcn.180228650(iVar5);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ae5;
                    fcn.18021b250(in_RCX, 9);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aeb;
                    uVar6 = (*(code *)0x800000000000006f)();
                    *(undefined4 *)(iVar2 + 0x3c) = uVar6;
                }
            }
        }
        iVar2 = *(int64_t *)(in_RCX + 0x40);
        if (*(int64_t *)(iVar2 + 0x48) != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar7) = 4;
            iVar5 = *(int32_t *)(in_RCX + 0x38);
            *(int32_t *)((int64_t)&var_14h + iVar7) = (int32_t)(*(uint64_t *)(iVar2 + 0x50) / 1000000);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b2b;
            iVar5 = (*(code *)0x8000000000000015)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_14h + iVar7);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b34;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b4c;
                func_0x0001802295a0(0x1804bfff0, 0x18b, 0x1804c0040);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b52;
                uVar6 = (*(code *)0x800000000000006f)();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b65;
                func_0x0001802296d0(2, uVar6, 0x1804b8760);
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b81;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_40h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_180227a94
// Address: 0x180227a94
// Size: 224 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.1802278c0(int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_110h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int32_t iVar5;
    undefined4 uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int64_t var_8h;
    int32_t var_10h;
    undefined4 var_14h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1802278d1;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_40h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7);
    iVar2 = *(int64_t *)(in_RCX + 0x40);
    *(undefined4 *)((int64_t)&var_18h + iVar7) = 0x1c;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_R12;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022791b;
        (*(code *)0x8000000000000070)(0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227925;
        func_0x00018026be30((int64_t)&var_20h + iVar7);
        iVar3 = *(int64_t *)(in_RCX + 0x40);
        if (*(int64_t *)(iVar3 + 0x48) != 0) {
            iVar5 = *(int32_t *)(in_RCX + 0x38);
            *(int64_t *)(&stack0x00000000 + iVar7) = (int64_t)&var_14h + iVar7;
            *(undefined4 *)((int64_t)&var_14h + iVar7) = 4;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022796a;
            iVar5 = (*(code *)0x8000000000000007)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_10h + iVar7);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227973;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022798b;
                func_0x0001802295a0(0x1804bfff0, 0x13e, 0x1804c0008);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227991;
                uVar6 = (*(code *)0x800000000000006f)();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802279a4;
                func_0x0001802296d0(2, uVar6, 0x1804c0028);
            } else {
                *(int64_t *)(iVar3 + 0x50) = (int64_t)*(int32_t *)((int64_t)&var_10h + iVar7) * 1000000;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802279bb;
            uVar8 = func_0x0001802450c0();
            if ((*(uint64_t *)(iVar3 + 0x48) < uVar8) || (uVar8 = *(uint64_t *)(iVar3 + 0x48) - uVar8, uVar8 < 1000)) {
                uVar8 = 1000;
            }
            uVar4 = *(uint64_t *)(iVar3 + 0x50);
            if (((uVar4 == 0) || (uVar8 < uVar4)) || (uVar8 <= uVar4)) {
                *(undefined4 *)(&stack0x00000000 + iVar7) = 4;
                iVar5 = *(int32_t *)(in_RCX + 0x38);
                *(int32_t *)((int64_t)&var_10h + iVar7) = (int32_t)(uVar8 / 1000000);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a15;
                iVar5 = (*(code *)0x8000000000000015)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_10h + iVar7);
                if (iVar5 < 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a1e;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a36;
                    func_0x0001802295a0(0x1804bfff0, 0x15c, 0x1804c0008);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a3c;
                    uVar6 = (*(code *)0x800000000000006f)();
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a4f;
                    func_0x0001802296d0(2, uVar6, 0x1804b8760);
                }
            }
        }
        iVar5 = *(int32_t *)(iVar2 + 0x58);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a64;
        uVar9 = fcn.18000ce10((int64_t)&var_20h + iVar7);
        iVar1 = *(int32_t *)(in_RCX + 0x38);
        *(int64_t *)((int64_t)&var_10h + iVar7 + -8) = (int64_t)&var_18h + iVar7;
        *(undefined8 *)(&stack0x00000000 + iVar7) = uVar9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a86;
        iVar5 = (*(code *)0x8000000000000011)((int64_t)iVar1, in_RDX, in_R8 & 0xffffffff, -(iVar5 != 0) & 2);
        if ((*(int32_t *)(iVar2 + 0x38) == 0) && (-1 < iVar5)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aad;
            func_0x000180219d10(in_RCX, 0x2c, 0, (int64_t)&var_20h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aba;
            fcn.180219ce0(in_RCX, 0xf);
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ac9;
            fcn.180219ce0(in_RCX, 0xf);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ad4;
                iVar5 = fcn.180228650(iVar5);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ae5;
                    fcn.18021b250(in_RCX, 9);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aeb;
                    uVar6 = (*(code *)0x800000000000006f)();
                    *(undefined4 *)(iVar2 + 0x3c) = uVar6;
                }
            }
        }
        iVar2 = *(int64_t *)(in_RCX + 0x40);
        if (*(int64_t *)(iVar2 + 0x48) != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar7) = 4;
            iVar5 = *(int32_t *)(in_RCX + 0x38);
            *(int32_t *)((int64_t)&var_14h + iVar7) = (int32_t)(*(uint64_t *)(iVar2 + 0x50) / 1000000);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b2b;
            iVar5 = (*(code *)0x8000000000000015)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_14h + iVar7);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b34;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b4c;
                func_0x0001802295a0(0x1804bfff0, 0x18b, 0x1804c0040);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b52;
                uVar6 = (*(code *)0x800000000000006f)();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b65;
                func_0x0001802296d0(2, uVar6, 0x1804b8760);
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b81;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_40h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_180227b74
// Address: 0x180227b74
// Size: 31 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.1802278c0(int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_110h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int32_t iVar5;
    undefined4 uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int64_t var_8h;
    int32_t var_10h;
    undefined4 var_14h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1802278d1;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_40h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7);
    iVar2 = *(int64_t *)(in_RCX + 0x40);
    *(undefined4 *)((int64_t)&var_18h + iVar7) = 0x1c;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_R12;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022791b;
        (*(code *)0x8000000000000070)(0);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227925;
        func_0x00018026be30((int64_t)&var_20h + iVar7);
        iVar3 = *(int64_t *)(in_RCX + 0x40);
        if (*(int64_t *)(iVar3 + 0x48) != 0) {
            iVar5 = *(int32_t *)(in_RCX + 0x38);
            *(int64_t *)(&stack0x00000000 + iVar7) = (int64_t)&var_14h + iVar7;
            *(undefined4 *)((int64_t)&var_14h + iVar7) = 4;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022796a;
            iVar5 = (*(code *)0x8000000000000007)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_10h + iVar7);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227973;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18022798b;
                func_0x0001802295a0(0x1804bfff0, 0x13e, 0x1804c0008);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227991;
                uVar6 = (*(code *)0x800000000000006f)();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802279a4;
                func_0x0001802296d0(2, uVar6, 0x1804c0028);
            } else {
                *(int64_t *)(iVar3 + 0x50) = (int64_t)*(int32_t *)((int64_t)&var_10h + iVar7) * 1000000;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802279bb;
            uVar8 = func_0x0001802450c0();
            if ((*(uint64_t *)(iVar3 + 0x48) < uVar8) || (uVar8 = *(uint64_t *)(iVar3 + 0x48) - uVar8, uVar8 < 1000)) {
                uVar8 = 1000;
            }
            uVar4 = *(uint64_t *)(iVar3 + 0x50);
            if (((uVar4 == 0) || (uVar8 < uVar4)) || (uVar8 <= uVar4)) {
                *(undefined4 *)(&stack0x00000000 + iVar7) = 4;
                iVar5 = *(int32_t *)(in_RCX + 0x38);
                *(int32_t *)((int64_t)&var_10h + iVar7) = (int32_t)(uVar8 / 1000000);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a15;
                iVar5 = (*(code *)0x8000000000000015)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_10h + iVar7);
                if (iVar5 < 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a1e;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a36;
                    func_0x0001802295a0(0x1804bfff0, 0x15c, 0x1804c0008);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a3c;
                    uVar6 = (*(code *)0x800000000000006f)();
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a4f;
                    func_0x0001802296d0(2, uVar6, 0x1804b8760);
                }
            }
        }
        iVar5 = *(int32_t *)(iVar2 + 0x58);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a64;
        uVar9 = fcn.18000ce10((int64_t)&var_20h + iVar7);
        iVar1 = *(int32_t *)(in_RCX + 0x38);
        *(int64_t *)((int64_t)&var_10h + iVar7 + -8) = (int64_t)&var_18h + iVar7;
        *(undefined8 *)(&stack0x00000000 + iVar7) = uVar9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227a86;
        iVar5 = (*(code *)0x8000000000000011)((int64_t)iVar1, in_RDX, in_R8 & 0xffffffff, -(iVar5 != 0) & 2);
        if ((*(int32_t *)(iVar2 + 0x38) == 0) && (-1 < iVar5)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aad;
            func_0x000180219d10(in_RCX, 0x2c, 0, (int64_t)&var_20h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aba;
            fcn.180219ce0(in_RCX, 0xf);
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ac9;
            fcn.180219ce0(in_RCX, 0xf);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ad4;
                iVar5 = fcn.180228650(iVar5);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227ae5;
                    fcn.18021b250(in_RCX, 9);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227aeb;
                    uVar6 = (*(code *)0x800000000000006f)();
                    *(undefined4 *)(iVar2 + 0x3c) = uVar6;
                }
            }
        }
        iVar2 = *(int64_t *)(in_RCX + 0x40);
        if (*(int64_t *)(iVar2 + 0x48) != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar7) = 4;
            iVar5 = *(int32_t *)(in_RCX + 0x38);
            *(int32_t *)((int64_t)&var_14h + iVar7) = (int32_t)(*(uint64_t *)(iVar2 + 0x50) / 1000000);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b2b;
            iVar5 = (*(code *)0x8000000000000015)((int64_t)iVar5, 0xffff, 0x1006, (int64_t)&var_14h + iVar7);
            if (iVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b34;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b4c;
                func_0x0001802295a0(0x1804bfff0, 0x18b, 0x1804c0040);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b52;
                uVar6 = (*(code *)0x800000000000006f)();
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b65;
                func_0x0001802296d0(2, uVar6, 0x1804b8760);
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180227b81;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_40h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_180227ba0
// Address: 0x180227ba0
// Size: 111 bytes
// ============================================================
int32_t fcn.180227ba0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_24h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180227bb0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227bc1;
    uVar6 = fcn.180498cd0(in_RDX);
    if (0x7fffffff < uVar6) {
        return -1;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    iVar1 = *(int64_t *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227bf1;
    (*(code *)0x8000000000000070)(0);
    if (*(int32_t *)(iVar1 + 0x38) == 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c19;
        uVar4 = fcn.180184b50(iVar1);
        iVar2 = *(int32_t *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c27;
        uVar7 = fcn.18000ce10(iVar1);
        *(undefined4 *)((int64_t)&var_10h + iVar5) = uVar4;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar7;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c42;
        iVar2 = (*(code *)0x8000000000000014)((int64_t)iVar2, in_RDX, uVar6 & 0xffffffff, 0);
    } else {
        iVar2 = *(int32_t *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c0a;
        iVar2 = (*(code *)0x8000000000000013)((int64_t)iVar2, in_RDX, uVar6 & 0xffffffff, 0);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c56;
    fcn.180219ce0(in_RCX, 0xf);
    if (iVar2 < 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c61;
        iVar3 = fcn.180228650(iVar2);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c72;
            fcn.18021b250(in_RCX, 10);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c78;
            uVar4 = (*(code *)0x800000000000006f)();
            *(undefined4 *)(iVar1 + 0x3c) = uVar4;
        }
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180227c0f
// Address: 0x180227c0f
// Size: 56 bytes
// ============================================================
int32_t fcn.180227ba0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_24h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180227bb0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227bc1;
    uVar6 = fcn.180498cd0(in_RDX);
    if (0x7fffffff < uVar6) {
        return -1;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    iVar1 = *(int64_t *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227bf1;
    (*(code *)0x8000000000000070)(0);
    if (*(int32_t *)(iVar1 + 0x38) == 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c19;
        uVar4 = fcn.180184b50(iVar1);
        iVar2 = *(int32_t *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c27;
        uVar7 = fcn.18000ce10(iVar1);
        *(undefined4 *)((int64_t)&var_10h + iVar5) = uVar4;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar7;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c42;
        iVar2 = (*(code *)0x8000000000000014)((int64_t)iVar2, in_RDX, uVar6 & 0xffffffff, 0);
    } else {
        iVar2 = *(int32_t *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c0a;
        iVar2 = (*(code *)0x8000000000000013)((int64_t)iVar2, in_RDX, uVar6 & 0xffffffff, 0);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c56;
    fcn.180219ce0(in_RCX, 0xf);
    if (iVar2 < 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c61;
        iVar3 = fcn.180228650(iVar2);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c72;
            fcn.18021b250(in_RCX, 10);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c78;
            uVar4 = (*(code *)0x800000000000006f)();
            *(undefined4 *)(iVar1 + 0x3c) = uVar4;
        }
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180227c47
// Address: 0x180227c47
// Size: 74 bytes
// ============================================================
int32_t fcn.180227ba0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_24h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180227bb0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227bc1;
    uVar6 = fcn.180498cd0(in_RDX);
    if (0x7fffffff < uVar6) {
        return -1;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    iVar1 = *(int64_t *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227bf1;
    (*(code *)0x8000000000000070)(0);
    if (*(int32_t *)(iVar1 + 0x38) == 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c19;
        uVar4 = fcn.180184b50(iVar1);
        iVar2 = *(int32_t *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c27;
        uVar7 = fcn.18000ce10(iVar1);
        *(undefined4 *)((int64_t)&var_10h + iVar5) = uVar4;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar7;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c42;
        iVar2 = (*(code *)0x8000000000000014)((int64_t)iVar2, in_RDX, uVar6 & 0xffffffff, 0);
    } else {
        iVar2 = *(int32_t *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c0a;
        iVar2 = (*(code *)0x8000000000000013)((int64_t)iVar2, in_RDX, uVar6 & 0xffffffff, 0);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c56;
    fcn.180219ce0(in_RCX, 0xf);
    if (iVar2 < 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c61;
        iVar3 = fcn.180228650(iVar2);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c72;
            fcn.18021b250(in_RCX, 10);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227c78;
            uVar4 = (*(code *)0x800000000000006f)();
            *(undefined4 *)(iVar1 + 0x3c) = uVar4;
        }
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180227ca0
// Address: 0x180227ca0
// Size: 1693 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180227ca0(int64_t param_1, undefined4 param_2, int32_t param_3, undefined8 *param_4)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int16_t *piVar6;
    int16_t *piVar7;
    int64_t var_4h;
    int64_t var_c8h;
    int64_t var_48h;
    code *pcStack_40;
    int64_t var_18h;
    int64_t var_8h;
    
    pcStack_40 = (code *)0x180227cba;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar4);
    piVar7 = *(int16_t **)(param_1 + 0x40);
    *(undefined4 *)((int64_t)&var_4h + iVar4) = 0x80;
    // switch table (105 cases) at 0x180228260
    switch(param_2) {
    case 8:
        break;
    case 9:
        *(int32_t *)(param_1 + 0x2c) = param_3;
        break;
    case 0x1f:
    case 0x2c:
        goto code_r0x000180227e28;
    case 0x20:
        if (param_4 == (undefined8 *)0x0) {
            *(undefined4 *)(piVar7 + 0x1c) = 0;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227e4d;
            func_0x00018026be30(piVar7);
            break;
        }
        *(undefined4 *)(piVar7 + 0x1c) = 1;
code_r0x000180227e28:
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227e30;
        uVar5 = fcn.18000ce10(param_4);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227e3b;
        func_0x00018026bf20(piVar7, uVar5);
        break;
    case 0x21:
        iVar2 = *(int32_t *)(param_1 + 0x38);
        iVar1 = *(int32_t *)((int64_t)param_4 + 4);
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 4;
        *(int32_t *)((int64_t)&var_8h + iVar4) = iVar1 / 1000 + *(int32_t *)param_4 * 1000;
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227f8a;
        iVar2 = (*(code *)0x8000000000000015)((int64_t)iVar2, 0xffff, 0x1006, (int64_t)&var_8h + iVar4);
        if (-1 < iVar2) break;
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227f99;
        func_0x000180229480();
        uVar5 = 0x310;
        goto code_r0x000180227fa5;
    case 0x22:
        iVar2 = *(int32_t *)(param_1 + 0x38);
        *(int64_t *)((int64_t)&var_18h + iVar4) = (int64_t)&var_8h + iVar4;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 4;
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180228000;
        iVar2 = (*(code *)0x8000000000000007)((int64_t)iVar2, 0xffff, 0x1006, (int64_t)&var_8h + iVar4 + 4);
        if (-1 < iVar2) {
            iVar2 = *(int32_t *)((int64_t)&var_8h + iVar4 + 4);
code_r0x000180228034:
            *(int32_t *)param_4 = iVar2 / 1000;
            *(int32_t *)((int64_t)param_4 + 4) = (iVar2 % 1000) * 1000;
            break;
        }
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180228009;
        func_0x000180229480();
        uVar5 = 0x324;
        goto code_r0x00018022800e;
    case 0x23:
        iVar2 = *(int32_t *)(param_1 + 0x38);
        iVar1 = *(int32_t *)((int64_t)param_4 + 4);
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 4;
        *(int32_t *)((int64_t)&var_8h + iVar4 + 4) = iVar1 / 1000 + *(int32_t *)param_4 * 1000;
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x1802280a8;
        iVar2 = (*(code *)0x8000000000000015)((int64_t)iVar2, 0xffff, 0x1005, (int64_t)&var_8h + iVar4 + 4);
        if (-1 < iVar2) break;
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x1802280b7;
        func_0x000180229480();
        uVar5 = 0x342;
code_r0x000180227fa5:
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227fb1;
        func_0x0001802295a0(0x1804bfff0, uVar5, 0x1804c0058);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227fb7;
        uVar3 = (*(code *)0x800000000000006f)();
        uVar5 = 0x1804b8760;
code_r0x000180227fbe:
        *(code **)((int64_t)&pcStack_40 + iVar4) = case.0x180227d0c.39;
        func_0x0001802296d0(2, uVar3, uVar5);
        break;
    case 0x24:
        iVar2 = *(int32_t *)(param_1 + 0x38);
        *(int64_t *)((int64_t)&var_18h + iVar4) = (int64_t)&var_8h + iVar4 + 4;
        *(undefined4 *)((int64_t)&var_8h + iVar4 + 4) = 4;
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x1802280f4;
        iVar2 = (*(code *)0x8000000000000007)((int64_t)iVar2, 0xffff, 0x1005, (int64_t)&var_8h + iVar4);
        if (-1 < iVar2) {
            iVar2 = *(int32_t *)((int64_t)&var_8h + iVar4);
            goto code_r0x000180228034;
        }
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x1802280fd;
        func_0x000180229480();
        uVar5 = 0x356;
code_r0x00018022800e:
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180228021;
        func_0x0001802295a0(0x1804bfff0, uVar5, 0x1804c0058);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180228027;
        uVar3 = (*(code *)0x800000000000006f)();
        uVar5 = 0x1804c0028;
        goto code_r0x000180227fbe;
    case 0x25:
    case 0x26:
        if (*(int32_t *)(piVar7 + 0x1e) == 0x274c) {
            *(undefined4 *)(piVar7 + 0x1e) = 0;
        }
        break;
    case 0x29:
        break;
    case 0x2a:
        *(int32_t *)(piVar7 + 0x20) = param_3;
        break;
    case 0x2b:
        if (*(int32_t *)(piVar7 + 0x1e) == 0x73) {
            *(undefined4 *)(piVar7 + 0x1e) = 0;
        }
        break;
    case 0x2d:
        iVar2 = (int32_t)*param_4;
        if (iVar2 < 0) {
            *(undefined8 *)(piVar7 + 0x24) = 0;
        } else {
            *(int64_t *)(piVar7 + 0x24) =
                 ((int64_t)(int32_t)((uint64_t)*param_4 >> 0x20) + (int64_t)iVar2 * 1000000) * 1000;
        }
        break;
    case 0x2e:
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227e5a;
        iVar2 = fcn.180184b50(piVar7);
        if ((param_3 == 0) || (iVar2 < param_3)) {
            param_3 = iVar2;
        }
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227e78;
        func_0x000180498030(param_4, piVar7, (int64_t)param_3);
        break;
    case 0x2f:
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227de0;
        func_0x000180228730(piVar7);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227dea;
        func_0x00018026bea0(piVar7);
        break;
    case 0x30:
        if (*piVar7 == 2) {
            iVar2 = *(int32_t *)(param_1 + 0x38);
            *(undefined4 *)((int64_t)&var_18h + iVar4) = 4;
            *(uint32_t *)(&stack0x00000000 + iVar4) = (uint32_t)(param_3 != 0);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x1802281bd;
            iVar2 = (*(code *)0x8000000000000015)((int64_t)iVar2, 0, 0xe, (int64_t)&stack0x00000000 + iVar4);
            if (-1 < iVar2) break;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x1802281c8;
            func_0x000180229480();
            uVar5 = 0x397;
        } else {
            if (*piVar7 != 0x17) break;
            iVar2 = *(int32_t *)(param_1 + 0x38);
            *(undefined4 *)((int64_t)&var_18h + iVar4) = 4;
            *(uint32_t *)(&stack0x00000000 + iVar4) = (uint32_t)(param_3 != 0);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x18022817c;
            iVar2 = (*(code *)0x8000000000000015)((int64_t)iVar2, 0x29, 0xe, (int64_t)&stack0x00000000 + iVar4);
            if (-1 < iVar2) break;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x18022818b;
            func_0x000180229480();
            uVar5 = 0x3a4;
        }
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x1802281e0;
        func_0x0001802295a0(0x1804bfff0, uVar5, 0x1804c0058);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x1802281eb;
        uVar3 = (*(code *)0x800000000000006f)();
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x1802281fb;
        func_0x0001802296d0(2, uVar3, 0x1804b8760);
        break;
    case 0x31:
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x18022820a;
        func_0x000180228730(piVar7);
        break;
    case 0x32:
    case 0x47:
        *(int32_t *)(piVar7 + 0x2c) = param_3;
        break;
    case 0x53:
        *(int32_t *)param_4 = (int32_t)*(char *)(piVar7 + 0x2e);
        break;
    case 0x55:
        break;
    case 0x5b:
    case 0x5c:
        *(int32_t *)param_4 = 1;
        *(int32_t *)(param_4 + 1) = *(int32_t *)(param_1 + 0x38);
        break;
    case 0x5d:
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x10;
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227e8d;
        iVar2 = func_0x00018026bea0(piVar7);
        if (iVar2 == 0) {
            iVar2 = *(int32_t *)(param_1 + 0x38);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227ea5;
            iVar2 = (*(code *)0x8000000000000005)
                              ((int64_t)iVar2, (int64_t)&var_4h + iVar4 + 4, (int64_t)&var_8h + iVar4);
            if (iVar2 != 0) break;
            *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227eb7;
            iVar2 = func_0x00018026bea0((int64_t)&var_4h + iVar4 + 4);
            if (iVar2 == 0) break;
            piVar7 = (int16_t *)((int64_t)&var_4h + iVar4 + 4);
        }
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227ecc;
        iVar2 = fcn.180184b50(piVar7);
        if ((param_3 == 0) || (iVar2 < param_3)) {
            param_3 = iVar2;
        }
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227eea;
        func_0x000180498030(param_4, piVar7, (int64_t)param_3);
        break;
    case 0x66:
        uVar3 = *(undefined4 *)(param_1 + 0x38);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227f02;
        func_0x0001802749c0(uVar3, param_3 != 0);
        break;
    case 0x68:
        piVar6 = piVar7;
        if (*(int32_t *)(param_1 + 0x2c) != 0) {
            if (*(int32_t *)(param_1 + 0x28) != 0) {
                uVar3 = *(undefined4 *)(param_1 + 0x38);
                *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227d28;
                func_0x000180274b10(uVar3);
                piVar6 = *(int16_t **)(param_1 + 0x40);
            }
            *(undefined4 *)(param_1 + 0x28) = 0;
            *(undefined4 *)(param_1 + 0x30) = 0;
        }
        iVar2 = *(int32_t *)param_4;
        *(int32_t *)(param_1 + 0x38) = iVar2;
        *(int32_t *)(param_1 + 0x2c) = param_3;
        *(undefined4 *)(param_1 + 0x28) = 1;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1c;
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227d63;
        iVar2 = (*(code *)0x8000000000000006)((int64_t)iVar2, piVar6 + 0xe, (int64_t)&var_8h + iVar4);
        if (iVar2 < 0) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227d6f;
            func_0x00018026be30(piVar6 + 0xe);
        }
        iVar2 = *(int32_t *)(param_1 + 0x38);
        *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227d82;
        iVar2 = (*(code *)0x8000000000000005)((int64_t)iVar2, &var_c8h, (int64_t)&var_4h + iVar4);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227d93;
            uVar5 = fcn.18000ce10(&var_c8h);
            *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x180227d9e;
            func_0x00018026bf20(piVar7, uVar5);
            *(undefined4 *)(piVar7 + 0x1c) = 1;
        }
        break;
    case 0x69:
        if ((*(int32_t *)(param_1 + 0x28) != 0) && (param_4 != (undefined8 *)0x0)) {
            *(int32_t *)param_4 = *(int32_t *)(param_1 + 0x38);
        }
    }
    *(undefined8 *)((int64_t)&pcStack_40 + iVar4) = 0x18022824c;
    func_0x000180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_180228340
// Address: 0x180228340
// Size: 67 bytes
// ============================================================
undefined8 fcn.180228340(int64_t param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022834c;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180228369;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + -iVar1));
    if (iVar1 == 0) {
        return 0;
    }
    *(int64_t *)(param_1 + 0x40) = iVar1;
    return 1;
}

// ============================================================
// Function: FUN_180228390
// Address: 0x180228390
// Size: 92 bytes
// ============================================================
undefined8 fcn.180228390(int64_t param_1)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022839c;
    iVar3 = fcn.18045a350();
    if (param_1 == 0) {
        return 0;
    }
    if (*(int32_t *)(param_1 + 0x2c) != 0) {
        if (*(int32_t *)(param_1 + 0x28) != 0) {
            uVar1 = *(undefined4 *)(param_1 + 0x38);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1802283c3;
            fcn.180274b10(uVar1);
        }
        *(undefined4 *)(param_1 + 0x28) = 0;
        *(undefined4 *)(param_1 + 0x30) = 0;
    }
    uVar2 = *(undefined8 *)(param_1 + 0x40);
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1802283e1;
    fcn.180224990(uVar2, 0x1804bfff0, 0x11c);
    return 1;
}

// ============================================================
// Function: FUN_1802283f0
// Address: 0x1802283f0
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1802283f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_a0h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RSI;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180228400;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_R9 == 0) {
        **(undefined8 **)((int64_t)&arg_60h + iVar7) = 0;
        return 1;
    }
    if (in_RDX[3] == 0) {
        iVar2 = in_RDX[2];
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RSI;
        if (iVar2 == 0) {
            uVar5 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180228488;
            uVar5 = fcn.180184b50();
        }
        if (in_RDX[2] == 0) {
            uVar8 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022849c;
            uVar8 = fcn.18000ce10();
        }
        iVar6 = *(int32_t *)(in_RCX + 0x38);
        uVar1 = *(undefined4 *)(in_RDX + 1);
        uVar3 = *in_RDX;
        *(undefined4 *)((int64_t)&var_20h + iVar7) = uVar5;
        *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar8;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802284bd;
        iVar6 = (*(code *)0x8000000000000014)((int64_t)iVar6, uVar3, uVar1, 0);
        if (0 < iVar6) {
            in_RDX[1] = (int64_t)iVar6;
            puVar4 = *(undefined8 **)((int64_t)&arg_60h + iVar7);
            in_RDX[4] = 0;
            *puVar4 = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802284cb;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802284e3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802284e9;
        (*(code *)0x800000000000006f)();
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180228432;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022844a;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022845c;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
    **(undefined8 **)((int64_t)&arg_60h + iVar7) = 0;
    return 0;
}

// ============================================================
// Function: FUN_180228479
// Address: 0x180228479
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1802283f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_a0h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RSI;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180228400;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_R9 == 0) {
        **(undefined8 **)((int64_t)&arg_60h + iVar7) = 0;
        return 1;
    }
    if (in_RDX[3] == 0) {
        iVar2 = in_RDX[2];
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RSI;
        if (iVar2 == 0) {
            uVar5 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180228488;
            uVar5 = fcn.180184b50();
        }
        if (in_RDX[2] == 0) {
            uVar8 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022849c;
            uVar8 = fcn.18000ce10();
        }
        iVar6 = *(int32_t *)(in_RCX + 0x38);
        uVar1 = *(undefined4 *)(in_RDX + 1);
        uVar3 = *in_RDX;
        *(undefined4 *)((int64_t)&var_20h + iVar7) = uVar5;
        *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar8;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802284bd;
        iVar6 = (*(code *)0x8000000000000014)((int64_t)iVar6, uVar3, uVar1, 0);
        if (0 < iVar6) {
            in_RDX[1] = (int64_t)iVar6;
            puVar4 = *(undefined8 **)((int64_t)&arg_60h + iVar7);
            in_RDX[4] = 0;
            *puVar4 = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802284cb;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802284e3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802284e9;
        (*(code *)0x800000000000006f)();
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180228432;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022844a;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022845c;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
    **(undefined8 **)((int64_t)&arg_60h + iVar7) = 0;
    return 0;
}

// ============================================================
// Function: FUN_1802284c6
// Address: 0x1802284c6
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1802283f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_a0h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RSI;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180228400;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_R9 == 0) {
        **(undefined8 **)((int64_t)&arg_60h + iVar7) = 0;
        return 1;
    }
    if (in_RDX[3] == 0) {
        iVar2 = in_RDX[2];
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RSI;
        if (iVar2 == 0) {
            uVar5 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180228488;
            uVar5 = fcn.180184b50();
        }
        if (in_RDX[2] == 0) {
            uVar8 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022849c;
            uVar8 = fcn.18000ce10();
        }
        iVar6 = *(int32_t *)(in_RCX + 0x38);
        uVar1 = *(undefined4 *)(in_RDX + 1);
        uVar3 = *in_RDX;
        *(undefined4 *)((int64_t)&var_20h + iVar7) = uVar5;
        *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar8;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802284bd;
        iVar6 = (*(code *)0x8000000000000014)((int64_t)iVar6, uVar3, uVar1, 0);
        if (0 < iVar6) {
            in_RDX[1] = (int64_t)iVar6;
            puVar4 = *(undefined8 **)((int64_t)&arg_60h + iVar7);
            in_RDX[4] = 0;
            *puVar4 = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802284cb;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802284e3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802284e9;
        (*(code *)0x800000000000006f)();
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180228432;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022844a;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022845c;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
    **(undefined8 **)((int64_t)&arg_60h + iVar7) = 0;
    return 0;
}

// ============================================================
// Function: FUN_180228520
// Address: 0x180228520
// Size: 291 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180228520(int64_t arg_38h, int64_t arg_50h, int64_t arg_60h, int64_t arg_a0h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 *in_RDX;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180228530;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_R9 == 0) {
        **(undefined8 **)((int64_t)&arg_60h + iVar6) = 0;
        return 1;
    }
    if (in_RDX[3] != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228561;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228579;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022858b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        **(undefined8 **)((int64_t)&arg_60h + iVar6) = 0;
        return 0;
    }
    iVar2 = in_RDX[2];
    iVar5 = *(int32_t *)(in_RCX + 0x38);
    uVar1 = *(undefined4 *)(in_RDX + 1);
    *(undefined4 *)((int64_t)&arg_50h + iVar6) = 0x1c;
    iVar7 = (int64_t)&arg_50h + iVar6;
    if (iVar2 == 0) {
        iVar7 = 0;
    }
    *(int64_t *)((int64_t)&var_20h + iVar6) = iVar7;
    *(int64_t *)((int64_t)&var_18h + iVar6) = iVar2;
    uVar3 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802285da;
    iVar5 = (*(code *)0x8000000000000011)((int64_t)iVar5, uVar3, uVar1, 0);
    if (iVar5 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802285e3;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802285fb;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228601;
        (*(code *)0x800000000000006f)();
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228610;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0;
    }
    in_RDX[1] = (int64_t)iVar5;
    puVar4 = *(undefined8 **)((int64_t)&arg_60h + iVar6);
    in_RDX[4] = 0;
    *puVar4 = 1;
    return 1;
}

// ============================================================
// Function: FUN_180228650
// Address: 0x180228650
// Size: 89 bytes
// ============================================================
undefined8 fcn.180228650(int32_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    bool bVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022865a;
    iVar2 = fcn.18045a350();
    if (param_1 + 1U < 2) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x18022866b;
        iVar1 = (*(code *)0x800000000000006f)();
        if (iVar1 < 0x71) {
            if (iVar1 == 0x70) {
                return 1;
            }
            if (iVar1 == 4) {
                return 1;
            }
            if (iVar1 == 0xb) {
                return 1;
            }
            bVar3 = iVar1 == 0x67;
        } else {
            if (iVar1 == 0x86) {
                return 1;
            }
            if (iVar1 == 0x8c) {
                return 1;
            }
            bVar3 = iVar1 == 0x2733;
        }
        if (bVar3) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802286b0
// Address: 0x1802286b0
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1802286b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802286c5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802286d8;
    iVar2 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar1));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180228703;
    fcn.18021a790(*(int64_t *)(&stack0x00000038 + iVar1));
    return iVar2;
}

// ============================================================
// Function: FUN_180228730
// Address: 0x180228730
// Size: 56 bytes
// ============================================================
undefined8 fcn.180228730(void)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022873a;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x180228742;
    iVar1 = fcn.18026bea0();
    if (iVar1 != 2) {
        uVar3 = 0x30;
        if (iVar1 != 0x17) {
            uVar3 = 0x1c;
        }
        return uVar3;
    }
    return 0x1c;
}

// ============================================================
// Function: FUN_180228780
// Address: 0x180228780
// Size: 22 bytes
// ============================================================
void fcn.180228780(int64_t arg_50h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x180296850;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        uVar1 = *(uint32_t *)(in_RCX + 0x10);
        *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3) = unaff_RDI;
        if ((uVar1 & 0x10) == 0) {
            uVar2 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180296880;
            fcn.180224990(uVar2, 0x1804ed9c0, 0x16f);
        }
        if ((uVar1 & 0x80) == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18029689e;
            fcn.180224990(in_RCX, 0x1804ed9c0, 0x171);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802287b0
// Address: 0x1802287b0
// Size: 27 bytes
// ============================================================
void fcn.1802287b0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar3 = 3;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x180296a4c;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)auStackX_18 + -iVar2 + iVar1) = 0x180296a68;
    iVar1 = fcn.180224d60(*(int64_t *)(&stack0x00000040 + -iVar2 + iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined4 *)(iVar1 + 4) = uVar3;
    return;
}

// ============================================================
// Function: FUN_180228800
// Address: 0x180228800
// Size: 27 bytes
// ============================================================
void fcn.180228800(void)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar3 = 0x18;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x180296a4c;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)auStackX_18 + -iVar2 + iVar1) = 0x180296a68;
    iVar1 = fcn.180224d60(*(int64_t *)(&stack0x00000040 + -iVar2 + iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined4 *)(iVar1 + 4) = uVar3;
    return;
}

// ============================================================
// Function: FUN_180228830
// Address: 0x180228830
// Size: 27 bytes
// ============================================================
void fcn.180228830(void)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar3 = 0x16;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x180296a4c;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)auStackX_18 + -iVar2 + iVar1) = 0x180296a68;
    iVar1 = fcn.180224d60(*(int64_t *)(&stack0x00000040 + -iVar2 + iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined4 *)(iVar1 + 4) = uVar3;
    return;
}

// ============================================================
// Function: FUN_180228860
// Address: 0x180228860
// Size: 27 bytes
// ============================================================
void fcn.180228860(void)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar3 = 2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x180296a4c;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)auStackX_18 + -iVar2 + iVar1) = 0x180296a68;
    iVar1 = fcn.180224d60(*(int64_t *)(&stack0x00000040 + -iVar2 + iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined4 *)(iVar1 + 4) = uVar3;
    return;
}

// ============================================================
// Function: FUN_180228890
// Address: 0x180228890
// Size: 29 bytes
// ============================================================
undefined8 fcn.180228890(int64_t arg_40h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 uVar4;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x180260b4c;
    iVar3 = fcn.18045a350(0x1804c0328);
    iVar3 = -iVar3;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar3 + iVar2) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3 + iVar2) = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180260b6e;
    iVar1 = fcn.180260bc0(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2)
                          , *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
    if (0 < iVar1) {
        uVar4 = *(undefined8 *)((int64_t)&arg_68h + iVar3 + iVar2);
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1802288e0
// Address: 0x1802288e0
// Size: 27 bytes
// ============================================================
void fcn.1802288e0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar3 = 4;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x180296a4c;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)auStackX_18 + -iVar2 + iVar1) = 0x180296a68;
    iVar1 = fcn.180224d60(*(int64_t *)(&stack0x00000040 + -iVar2 + iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined4 *)(iVar1 + 4) = uVar3;
    return;
}

// ============================================================
// Function: FUN_180228940
// Address: 0x180228940
// Size: 29 bytes
// ============================================================
void fcn.180228940(int64_t arg_30h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802612bf;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802612cf;
    fcn.1802612e0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar1), *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), 
                  *(int64_t *)((int64_t)&arg_58h + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180228960
// Address: 0x180228960
// Size: 29 bytes
// ============================================================
undefined8 fcn.180228960(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 uVar4;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x180260b4c;
    iVar3 = fcn.18045a350(0x1804c0388);
    iVar3 = -iVar3;
    uVar4 = 0;
    *(undefined8 *)(&stack0x00000068 + iVar3 + iVar2) = 0;
    *(undefined8 *)(&stack0x00000040 + iVar3 + iVar2) = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180260b6e;
    iVar1 = fcn.180260bc0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2)
                          , *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
    if (0 < iVar1) {
        uVar4 = *(undefined8 *)(&stack0x00000068 + iVar3 + iVar2);
    }
    return uVar4;
}

// ============================================================
// Function: FUN_180228990
// Address: 0x180228990
// Size: 27 bytes
// ============================================================
void fcn.180228990(void)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar3 = 0xc;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x180296a4c;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)auStackX_18 + -iVar2 + iVar1) = 0x180296a68;
    iVar1 = fcn.180224d60(*(int64_t *)(&stack0x00000040 + -iVar2 + iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined4 *)(iVar1 + 4) = uVar3;
    return;
}

// ============================================================
// Function: FUN_1802289d0
// Address: 0x1802289d0
// Size: 29 bytes
// ============================================================
void fcn.1802289d0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_90h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t iVar4;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar5;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0x1804c00e8;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 0x10) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar2) = 0x18026177e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_90h + iVar3 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar3 + iVar2;
    *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar2) = 0;
    *(undefined *)((int64_t)&arg_78h + iVar3 + iVar2) = 0;
    iVar4 = (int64_t)&arg_70h + iVar3 + iVar2;
    if (in_RCX != 0) {
        iVar4 = in_RCX;
    }
    if ((iVar4 == 0) || (iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261804;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026181c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar3 + iVar2), 
                      *(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                      *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026182e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2));
    } else {
        *(undefined8 *)((int64_t)&arg_60h + iVar3 + iVar2) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_50h + iVar3 + iVar2) = 0;
        *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2) = (int64_t)&arg_78h + iVar3 + iVar2;
        *(undefined *)((int64_t)&arg_40h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617e9;
        iVar1 = func_0x0001802629a0(iVar4);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617f8;
            func_0x000180261290(iVar4, iVar5);
        }
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261841;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar3 + iVar2) ^ (int64_t)auStackX_10 + iVar3 + iVar2);
    return;
}

// ============================================================
// Function: FUN_1802289f0
// Address: 0x1802289f0
// Size: 29 bytes
// ============================================================
void fcn.1802289f0(undefined *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined *puVar4;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar5;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0x1804c00b8;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 0x10) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar2) = 0x18026177e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar3 + iVar2;
    *(undefined8 *)(&stack0x00000070 + iVar3 + iVar2) = 0;
    (&stack0x00000078)[iVar3 + iVar2] = 0;
    puVar4 = &stack0x00000070 + iVar3 + iVar2;
    if (param_1 != (undefined *)0x0) {
        puVar4 = param_1;
    }
    if ((puVar4 == (undefined *)0x0) || (iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261804;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026181c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026182e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
    } else {
        *(undefined8 *)(&stack0x00000060 + iVar3 + iVar2) = 0;
        *(undefined8 *)(&stack0x00000058 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000050 + iVar3 + iVar2) = 0;
        *(undefined **)(&stack0x00000048 + iVar3 + iVar2) = &stack0x00000078 + iVar3 + iVar2;
        (&stack0x00000040)[iVar3 + iVar2] = 0;
        *(undefined4 *)(&stack0x00000038 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000030 + iVar3 + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617e9;
        iVar1 = func_0x0001802629a0(puVar4);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617f8;
            func_0x000180261290(puVar4, iVar5);
        }
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261841;
    func_0x000180459870(*(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) ^ (int64_t)auStackX_10 + iVar3 + iVar2);
    return;
}

// ============================================================
// Function: FUN_180228a10
// Address: 0x180228a10
// Size: 29 bytes
// ============================================================
void fcn.180228a10(undefined *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined *puVar4;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar5;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0x1804c0088;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 0x10) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar2) = 0x18026177e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar3 + iVar2;
    *(undefined8 *)(&stack0x00000070 + iVar3 + iVar2) = 0;
    (&stack0x00000078)[iVar3 + iVar2] = 0;
    puVar4 = &stack0x00000070 + iVar3 + iVar2;
    if (param_1 != (undefined *)0x0) {
        puVar4 = param_1;
    }
    if ((puVar4 == (undefined *)0x0) || (iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261804;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026181c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026182e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
    } else {
        *(undefined8 *)(&stack0x00000060 + iVar3 + iVar2) = 0;
        *(undefined8 *)(&stack0x00000058 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000050 + iVar3 + iVar2) = 0;
        *(undefined **)(&stack0x00000048 + iVar3 + iVar2) = &stack0x00000078 + iVar3 + iVar2;
        (&stack0x00000040)[iVar3 + iVar2] = 0;
        *(undefined4 *)(&stack0x00000038 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000030 + iVar3 + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617e9;
        iVar1 = func_0x0001802629a0(puVar4);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617f8;
            func_0x000180261290(puVar4, iVar5);
        }
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261841;
    func_0x000180459870(*(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) ^ (int64_t)auStackX_10 + iVar3 + iVar2);
    return;
}

// ============================================================
// Function: FUN_180228a30
// Address: 0x180228a30
// Size: 29 bytes
// ============================================================
void fcn.180228a30(undefined *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined *puVar4;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar5;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0x1804c0558;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 0x10) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar2) = 0x18026177e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar3 + iVar2;
    *(undefined8 *)(&stack0x00000070 + iVar3 + iVar2) = 0;
    (&stack0x00000078)[iVar3 + iVar2] = 0;
    puVar4 = &stack0x00000070 + iVar3 + iVar2;
    if (param_1 != (undefined *)0x0) {
        puVar4 = param_1;
    }
    if ((puVar4 == (undefined *)0x0) || (iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261804;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026181c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026182e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
    } else {
        *(undefined8 *)(&stack0x00000060 + iVar3 + iVar2) = 0;
        *(undefined8 *)(&stack0x00000058 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000050 + iVar3 + iVar2) = 0;
        *(undefined **)(&stack0x00000048 + iVar3 + iVar2) = &stack0x00000078 + iVar3 + iVar2;
        (&stack0x00000040)[iVar3 + iVar2] = 0;
        *(undefined4 *)(&stack0x00000038 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000030 + iVar3 + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617e9;
        iVar1 = func_0x0001802629a0(puVar4);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617f8;
            func_0x000180261290(puVar4, iVar5);
        }
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261841;
    func_0x000180459870(*(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) ^ (int64_t)auStackX_10 + iVar3 + iVar2);
    return;
}

// ============================================================
// Function: FUN_180228a50
// Address: 0x180228a50
// Size: 29 bytes
// ============================================================
void fcn.180228a50(undefined *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined *puVar4;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar5;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0x1804c0388;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 0x10) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar2) = 0x18026177e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar3 + iVar2;
    *(undefined8 *)(&stack0x00000070 + iVar3 + iVar2) = 0;
    (&stack0x00000078)[iVar3 + iVar2] = 0;
    puVar4 = &stack0x00000070 + iVar3 + iVar2;
    if (param_1 != (undefined *)0x0) {
        puVar4 = param_1;
    }
    if ((puVar4 == (undefined *)0x0) || (iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261804;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026181c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026182e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
    } else {
        *(undefined8 *)(&stack0x00000060 + iVar3 + iVar2) = 0;
        *(undefined8 *)(&stack0x00000058 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000050 + iVar3 + iVar2) = 0;
        *(undefined **)(&stack0x00000048 + iVar3 + iVar2) = &stack0x00000078 + iVar3 + iVar2;
        (&stack0x00000040)[iVar3 + iVar2] = 0;
        *(undefined4 *)(&stack0x00000038 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000030 + iVar3 + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617e9;
        iVar1 = func_0x0001802629a0(puVar4);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617f8;
            func_0x000180261290(puVar4, iVar5);
        }
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261841;
    func_0x000180459870(*(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) ^ (int64_t)auStackX_10 + iVar3 + iVar2);
    return;
}

// ============================================================
// Function: FUN_180228a70
// Address: 0x180228a70
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180228a70(int64_t arg_58h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802642ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3) = in_RCX;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != (int64_t *)0x0) && (*in_RDX == 0)) {
        *(undefined4 *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20) = uVar6;
        *(undefined8 *)((int64_t)&arg_98h + iVar3 + iVar1 + -0x20) = unaff_RDI;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026461d;
        uVar2 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
        *(undefined8 *)((int64_t)&arg_a0h + iVar3 + iVar1 + -0x20) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar1 + -0x20));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20) = iVar4;
            *(undefined4 *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20) = uVar6;
            *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
            uVar5 = (uint64_t)uVar2;
            *in_RDX = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20) = uVar6;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
    return uVar5;
}

// ============================================================
// Function: FUN_180228a90
// Address: 0x180228a90
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180228a90(undefined8 param_1, int64_t *param_2)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802642ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    uVar6 = 0;
    *(undefined8 *)(&stack0x00000058 + iVar4 + iVar3) = param_1;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((param_2 != (int64_t *)0x0) && (*param_2 == 0)) {
        *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
        *(undefined8 *)(&stack0x00000098 + iVar3 + iVar1 + -0x20) = unaff_RDI;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026461d;
        uVar2 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
        *(undefined8 *)(&stack0x000000a0 + iVar3 + iVar1 + -0x20) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar1 + -0x20));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20) = iVar4;
            *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
            *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
            uVar5 = (uint64_t)uVar2;
            *param_2 = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
    return uVar5;
}

// ============================================================
// Function: FUN_180228ab0
// Address: 0x180228ab0
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180228ab0(undefined8 param_1, int64_t *param_2)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802642ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    uVar6 = 0;
    *(undefined8 *)(&stack0x00000058 + iVar4 + iVar3) = param_1;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((param_2 != (int64_t *)0x0) && (*param_2 == 0)) {
        *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
        *(undefined8 *)(&stack0x00000098 + iVar3 + iVar1 + -0x20) = unaff_RDI;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026461d;
        uVar2 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
        *(undefined8 *)(&stack0x000000a0 + iVar3 + iVar1 + -0x20) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar1 + -0x20));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20) = iVar4;
            *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
            *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
            uVar5 = (uint64_t)uVar2;
            *param_2 = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
    return uVar5;
}

// ============================================================
// Function: FUN_180228ad0
// Address: 0x180228ad0
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180228ad0(undefined8 param_1, int64_t *param_2)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802642ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    uVar6 = 0;
    *(undefined8 *)(&stack0x00000058 + iVar4 + iVar3) = param_1;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((param_2 != (int64_t *)0x0) && (*param_2 == 0)) {
        *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
        *(undefined8 *)(&stack0x00000098 + iVar3 + iVar1 + -0x20) = unaff_RDI;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026461d;
        uVar2 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
        *(undefined8 *)(&stack0x000000a0 + iVar3 + iVar1 + -0x20) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar1 + -0x20));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20) = iVar4;
            *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
            *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
            uVar5 = (uint64_t)uVar2;
            *param_2 = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
    return uVar5;
}

// ============================================================
// Function: FUN_180228af0
// Address: 0x180228af0
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180228af0(undefined8 param_1, int64_t *param_2)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802642ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    uVar6 = 0;
    *(undefined8 *)(&stack0x00000058 + iVar4 + iVar3) = param_1;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((param_2 != (int64_t *)0x0) && (*param_2 == 0)) {
        *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
        *(undefined8 *)(&stack0x00000098 + iVar3 + iVar1 + -0x20) = unaff_RDI;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026461d;
        uVar2 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
        *(undefined8 *)(&stack0x000000a0 + iVar3 + iVar1 + -0x20) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar1 + -0x20));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20) = iVar4;
            *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
            *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
            uVar5 = (uint64_t)uVar2;
            *param_2 = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
    return uVar5;
}

// ============================================================
// Function: FUN_180228b10
// Address: 0x180228b10
// Size: 74 bytes
// ============================================================
undefined8 fcn.180228b10(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t *in_RCX;
    uint64_t uVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180228b1c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x54) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228b33;
    piVar7 = (int64_t *)
             fcn.180229330(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                           *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6));
    puVar1 = (undefined8 *)*piVar7;
    if (puVar1 == (undefined8 *)0x0) {
        return 0;
    }
    *piVar7 = puVar1[1];
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    uVar2 = *puVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228b67;
    fcn.180224990(puVar1, 0x1804c07c8, 0xa2);
    iVar5 = *(int32_t *)(in_RCX + 10);
    *(int32_t *)(in_RCX + 10) = iVar5 + -1;
    if ((0x10 < *(uint32_t *)(in_RCX + 7)) &&
       ((uint32_t)((iVar5 + -1) * 0x100) / *(uint32_t *)(in_RCX + 7) <= *(uint32_t *)((int64_t)in_RCX + 0x4c))) {
        uVar8 = (uint64_t)(uint32_t)(*(int32_t *)(in_RCX + 8) + *(int32_t *)((int64_t)in_RCX + 0x44) + -1);
        *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RDI;
        uVar3 = *(undefined8 *)(*in_RCX + uVar8 * 8);
        *(undefined8 *)(*in_RCX + uVar8 * 8) = 0;
        iVar5 = *(int32_t *)(in_RCX + 8);
        if (iVar5 == 0) {
            *(undefined4 *)((int64_t)&iStackX_20 + iVar6 + -8) = 0x126;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228bd0;
            iVar6 = fcn.180224f60(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6), *(int64_t *)(&stack0x00000068 + iVar6));
            if (iVar6 == 0) {
                *(int32_t *)((int64_t)in_RCX + 0x54) = *(int32_t *)((int64_t)in_RCX + 0x54) + 1;
            } else {
                *in_RCX = iVar6;
            }
            *(uint32_t *)((int64_t)in_RCX + 0x3c) = *(uint32_t *)((int64_t)in_RCX + 0x3c) >> 1;
            *(uint32_t *)((int64_t)in_RCX + 0x44) = *(uint32_t *)((int64_t)in_RCX + 0x44) >> 1;
            iVar5 = *(int32_t *)((int64_t)in_RCX + 0x44);
        }
        iVar5 = iVar5 + -1;
        *(int32_t *)(in_RCX + 8) = iVar5;
        *(int32_t *)(in_RCX + 7) = *(int32_t *)(in_RCX + 7) + -1;
        iVar6 = *(int64_t *)(*in_RCX + (int64_t)iVar5 * 8);
        if (iVar6 == 0) {
            *(undefined8 *)(*in_RCX + (int64_t)iVar5 * 8) = uVar3;
            return uVar2;
        }
        for (iVar4 = *(int64_t *)(iVar6 + 8); iVar4 != 0; iVar4 = *(int64_t *)(iVar4 + 8)) {
            iVar6 = iVar4;
        }
        *(undefined8 *)(iVar6 + 8) = uVar3;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_180228b5a
// Address: 0x180228b5a
// Size: 189 bytes
// ============================================================
undefined8 fcn.180228b10(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t *in_RCX;
    uint64_t uVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180228b1c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x54) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228b33;
    piVar7 = (int64_t *)
             fcn.180229330(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                           *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6));
    puVar1 = (undefined8 *)*piVar7;
    if (puVar1 == (undefined8 *)0x0) {
        return 0;
    }
    *piVar7 = puVar1[1];
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    uVar2 = *puVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228b67;
    fcn.180224990(puVar1, 0x1804c07c8, 0xa2);
    iVar5 = *(int32_t *)(in_RCX + 10);
    *(int32_t *)(in_RCX + 10) = iVar5 + -1;
    if ((0x10 < *(uint32_t *)(in_RCX + 7)) &&
       ((uint32_t)((iVar5 + -1) * 0x100) / *(uint32_t *)(in_RCX + 7) <= *(uint32_t *)((int64_t)in_RCX + 0x4c))) {
        uVar8 = (uint64_t)(uint32_t)(*(int32_t *)(in_RCX + 8) + *(int32_t *)((int64_t)in_RCX + 0x44) + -1);
        *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RDI;
        uVar3 = *(undefined8 *)(*in_RCX + uVar8 * 8);
        *(undefined8 *)(*in_RCX + uVar8 * 8) = 0;
        iVar5 = *(int32_t *)(in_RCX + 8);
        if (iVar5 == 0) {
            *(undefined4 *)((int64_t)&iStackX_20 + iVar6 + -8) = 0x126;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228bd0;
            iVar6 = fcn.180224f60(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6), *(int64_t *)(&stack0x00000068 + iVar6));
            if (iVar6 == 0) {
                *(int32_t *)((int64_t)in_RCX + 0x54) = *(int32_t *)((int64_t)in_RCX + 0x54) + 1;
            } else {
                *in_RCX = iVar6;
            }
            *(uint32_t *)((int64_t)in_RCX + 0x3c) = *(uint32_t *)((int64_t)in_RCX + 0x3c) >> 1;
            *(uint32_t *)((int64_t)in_RCX + 0x44) = *(uint32_t *)((int64_t)in_RCX + 0x44) >> 1;
            iVar5 = *(int32_t *)((int64_t)in_RCX + 0x44);
        }
        iVar5 = iVar5 + -1;
        *(int32_t *)(in_RCX + 8) = iVar5;
        *(int32_t *)(in_RCX + 7) = *(int32_t *)(in_RCX + 7) + -1;
        iVar6 = *(int64_t *)(*in_RCX + (int64_t)iVar5 * 8);
        if (iVar6 == 0) {
            *(undefined8 *)(*in_RCX + (int64_t)iVar5 * 8) = uVar3;
            return uVar2;
        }
        for (iVar4 = *(int64_t *)(iVar6 + 8); iVar4 != 0; iVar4 = *(int64_t *)(iVar4 + 8)) {
            iVar6 = iVar4;
        }
        *(undefined8 *)(iVar6 + 8) = uVar3;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_180228c17
// Address: 0x180228c17
// Size: 33 bytes
// ============================================================
undefined8 fcn.180228b10(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t *in_RCX;
    uint64_t uVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180228b1c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x54) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228b33;
    piVar7 = (int64_t *)
             fcn.180229330(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                           *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6));
    puVar1 = (undefined8 *)*piVar7;
    if (puVar1 == (undefined8 *)0x0) {
        return 0;
    }
    *piVar7 = puVar1[1];
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    uVar2 = *puVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228b67;
    fcn.180224990(puVar1, 0x1804c07c8, 0xa2);
    iVar5 = *(int32_t *)(in_RCX + 10);
    *(int32_t *)(in_RCX + 10) = iVar5 + -1;
    if ((0x10 < *(uint32_t *)(in_RCX + 7)) &&
       ((uint32_t)((iVar5 + -1) * 0x100) / *(uint32_t *)(in_RCX + 7) <= *(uint32_t *)((int64_t)in_RCX + 0x4c))) {
        uVar8 = (uint64_t)(uint32_t)(*(int32_t *)(in_RCX + 8) + *(int32_t *)((int64_t)in_RCX + 0x44) + -1);
        *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RDI;
        uVar3 = *(undefined8 *)(*in_RCX + uVar8 * 8);
        *(undefined8 *)(*in_RCX + uVar8 * 8) = 0;
        iVar5 = *(int32_t *)(in_RCX + 8);
        if (iVar5 == 0) {
            *(undefined4 *)((int64_t)&iStackX_20 + iVar6 + -8) = 0x126;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228bd0;
            iVar6 = fcn.180224f60(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6), *(int64_t *)(&stack0x00000068 + iVar6));
            if (iVar6 == 0) {
                *(int32_t *)((int64_t)in_RCX + 0x54) = *(int32_t *)((int64_t)in_RCX + 0x54) + 1;
            } else {
                *in_RCX = iVar6;
            }
            *(uint32_t *)((int64_t)in_RCX + 0x3c) = *(uint32_t *)((int64_t)in_RCX + 0x3c) >> 1;
            *(uint32_t *)((int64_t)in_RCX + 0x44) = *(uint32_t *)((int64_t)in_RCX + 0x44) >> 1;
            iVar5 = *(int32_t *)((int64_t)in_RCX + 0x44);
        }
        iVar5 = iVar5 + -1;
        *(int32_t *)(in_RCX + 8) = iVar5;
        *(int32_t *)(in_RCX + 7) = *(int32_t *)(in_RCX + 7) + -1;
        iVar6 = *(int64_t *)(*in_RCX + (int64_t)iVar5 * 8);
        if (iVar6 == 0) {
            *(undefined8 *)(*in_RCX + (int64_t)iVar5 * 8) = uVar3;
            return uVar2;
        }
        for (iVar4 = *(int64_t *)(iVar6 + 8); iVar4 != 0; iVar4 = *(int64_t *)(iVar4 + 8)) {
            iVar6 = iVar4;
        }
        *(undefined8 *)(iVar6 + 8) = uVar3;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_180228c38
// Address: 0x180228c38
// Size: 14 bytes
// ============================================================
undefined8 fcn.180228b10(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t *in_RCX;
    uint64_t uVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180228b1c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined4 *)((int64_t)in_RCX + 0x54) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228b33;
    piVar7 = (int64_t *)
             fcn.180229330(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                           *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6));
    puVar1 = (undefined8 *)*piVar7;
    if (puVar1 == (undefined8 *)0x0) {
        return 0;
    }
    *piVar7 = puVar1[1];
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    uVar2 = *puVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228b67;
    fcn.180224990(puVar1, 0x1804c07c8, 0xa2);
    iVar5 = *(int32_t *)(in_RCX + 10);
    *(int32_t *)(in_RCX + 10) = iVar5 + -1;
    if ((0x10 < *(uint32_t *)(in_RCX + 7)) &&
       ((uint32_t)((iVar5 + -1) * 0x100) / *(uint32_t *)(in_RCX + 7) <= *(uint32_t *)((int64_t)in_RCX + 0x4c))) {
        uVar8 = (uint64_t)(uint32_t)(*(int32_t *)(in_RCX + 8) + *(int32_t *)((int64_t)in_RCX + 0x44) + -1);
        *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RDI;
        uVar3 = *(undefined8 *)(*in_RCX + uVar8 * 8);
        *(undefined8 *)(*in_RCX + uVar8 * 8) = 0;
        iVar5 = *(int32_t *)(in_RCX + 8);
        if (iVar5 == 0) {
            *(undefined4 *)((int64_t)&iStackX_20 + iVar6 + -8) = 0x126;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228bd0;
            iVar6 = fcn.180224f60(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6), *(int64_t *)(&stack0x00000068 + iVar6));
            if (iVar6 == 0) {
                *(int32_t *)((int64_t)in_RCX + 0x54) = *(int32_t *)((int64_t)in_RCX + 0x54) + 1;
            } else {
                *in_RCX = iVar6;
            }
            *(uint32_t *)((int64_t)in_RCX + 0x3c) = *(uint32_t *)((int64_t)in_RCX + 0x3c) >> 1;
            *(uint32_t *)((int64_t)in_RCX + 0x44) = *(uint32_t *)((int64_t)in_RCX + 0x44) >> 1;
            iVar5 = *(int32_t *)((int64_t)in_RCX + 0x44);
        }
        iVar5 = iVar5 + -1;
        *(int32_t *)(in_RCX + 8) = iVar5;
        *(int32_t *)(in_RCX + 7) = *(int32_t *)(in_RCX + 7) + -1;
        iVar6 = *(int64_t *)(*in_RCX + (int64_t)iVar5 * 8);
        if (iVar6 == 0) {
            *(undefined8 *)(*in_RCX + (int64_t)iVar5 * 8) = uVar3;
            return uVar2;
        }
        for (iVar4 = *(int64_t *)(iVar6 + 8); iVar4 != 0; iVar4 = *(int64_t *)(iVar4 + 8)) {
            iVar6 = iVar4;
        }
        *(undefined8 *)(iVar6 + 8) = uVar3;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_180228c50
// Address: 0x180228c50
// Size: 31 bytes
// ============================================================
void fcn.180228c50(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228c66;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBP;
        pcVar2 = *(code **)(arg1 + 0x28);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        iVar7 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            do {
                puVar5 = *(undefined8 **)(*(int64_t *)arg1 + iVar7 * 8);
                while (puVar5 != (undefined8 *)0x0) {
                    puVar3 = (undefined8 *)puVar5[1];
                    uVar4 = *puVar5;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228cac;
                    (*pcVar2)(uVar4, in_RDX);
                    puVar5 = puVar3;
                }
                iVar7 = iVar7 + -1;
            } while (-1 < iVar7);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228c6f
// Address: 0x180228c6f
// Size: 25 bytes
// ============================================================
void fcn.180228c50(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228c66;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBP;
        pcVar2 = *(code **)(arg1 + 0x28);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        iVar7 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            do {
                puVar5 = *(undefined8 **)(*(int64_t *)arg1 + iVar7 * 8);
                while (puVar5 != (undefined8 *)0x0) {
                    puVar3 = (undefined8 *)puVar5[1];
                    uVar4 = *puVar5;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228cac;
                    (*pcVar2)(uVar4, in_RDX);
                    puVar5 = puVar3;
                }
                iVar7 = iVar7 + -1;
            } while (-1 < iVar7);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228c88
// Address: 0x180228c88
// Size: 55 bytes
// ============================================================
void fcn.180228c50(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228c66;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBP;
        pcVar2 = *(code **)(arg1 + 0x28);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        iVar7 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            do {
                puVar5 = *(undefined8 **)(*(int64_t *)arg1 + iVar7 * 8);
                while (puVar5 != (undefined8 *)0x0) {
                    puVar3 = (undefined8 *)puVar5[1];
                    uVar4 = *puVar5;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228cac;
                    (*pcVar2)(uVar4, in_RDX);
                    puVar5 = puVar3;
                }
                iVar7 = iVar7 + -1;
            } while (-1 < iVar7);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228cbf
// Address: 0x180228cbf
// Size: 21 bytes
// ============================================================
void fcn.180228c50(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228c66;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBP;
        pcVar2 = *(code **)(arg1 + 0x28);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        iVar7 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            do {
                puVar5 = *(undefined8 **)(*(int64_t *)arg1 + iVar7 * 8);
                while (puVar5 != (undefined8 *)0x0) {
                    puVar3 = (undefined8 *)puVar5[1];
                    uVar4 = *puVar5;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228cac;
                    (*pcVar2)(uVar4, in_RDX);
                    puVar5 = puVar3;
                }
                iVar7 = iVar7 + -1;
            } while (-1 < iVar7);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228cd4
// Address: 0x180228cd4
// Size: 1 bytes
// ============================================================
void fcn.180228c50(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228c66;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBP;
        pcVar2 = *(code **)(arg1 + 0x28);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        iVar7 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            do {
                puVar5 = *(undefined8 **)(*(int64_t *)arg1 + iVar7 * 8);
                while (puVar5 != (undefined8 *)0x0) {
                    puVar3 = (undefined8 *)puVar5[1];
                    uVar4 = *puVar5;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180228cac;
                    (*pcVar2)(uVar4, in_RDX);
                    puVar5 = puVar3;
                }
                iVar7 = iVar7 + -1;
            } while (-1 < iVar7);
        }
    }
    return;
}

