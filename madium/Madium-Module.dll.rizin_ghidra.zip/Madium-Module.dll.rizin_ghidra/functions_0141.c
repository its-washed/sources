// Chunk 141 - 50 functions

// ============================================================
// Function: FUN_1801e3930
// Address: 0x1801e3930
// Size: 54 bytes
// ============================================================
void fcn.1801e3930(int64_t arg1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801e3940;
        iVar1 = fcn.18045a350();
        iVar1 = -iVar1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e394b;
        fcn.1801de360(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e3960;
        fcn.180224990(arg1, 0x1804b6360, 500);
    }
    return;
}

// ============================================================
// Function: FUN_1801e3970
// Address: 0x1801e3970
// Size: 25 bytes
// ============================================================
undefined8 fcn.1801e3970(undefined8 *param_1)
{
    fcn.18045a350();
    return *(undefined8 *)*param_1;
}

// ============================================================
// Function: FUN_1801e39a0
// Address: 0x1801e39a0
// Size: 25 bytes
// ============================================================
undefined8 fcn.1801e39a0(int64_t **param_1)
{
    int64_t iVar1;
    int64_t *piVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    piVar2 = *param_1;
    *(undefined8 *)((int64_t)&uStackX_20 - iVar1) = 0x1801e8dfa;
    fcn.18045a350();
    return *(undefined8 *)(*piVar2 + 0x10);
}

// ============================================================
// Function: FUN_1801e39d0
// Address: 0x1801e39d0
// Size: 25 bytes
// ============================================================
int64_t fcn.1801e39d0(int64_t **param_1)
{
    int64_t iVar1;
    int64_t *piVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    piVar2 = *param_1;
    *(undefined8 *)((int64_t)&uStackX_20 - iVar1) = 0x1801e8e1a;
    fcn.18045a350();
    return *piVar2 + 0x28;
}

// ============================================================
// Function: FUN_1801e3a00
// Address: 0x1801e3a00
// Size: 67 bytes
// ============================================================
undefined8 fcn.1801e3a00(int64_t *param_1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e3a0c;
    iVar3 = fcn.18045a350();
    uVar4 = *(undefined8 *)(*param_1 + 0x40);
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801e3a1e;
    iVar2 = fcn.1801de050(uVar4);
    if (iVar2 == 0) {
        iVar1 = param_1[0x7b];
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801e3a2e;
        uVar4 = fcn.180205520(iVar1);
        if ((int32_t)uVar4 == 0) {
            return uVar4;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801e3a50
// Address: 0x1801e3a50
// Size: 22 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_d7h
// WARNING: [rz-ghidra] Detected overlap for variable var_ebh
// WARNING: [rz-ghidra] Detected overlap for variable var_184h

void fcn.1801e3a50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t *piVar14;
    undefined8 unaff_RSI;
    uint32_t uVar15;
    uint32_t uVar16;
    uint64_t uVar17;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_20h;
    int64_t var_1b0h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_140h;
    int64_t var_138h;
    undefined auStack_130 [16];
    int64_t var_120h;
    int64_t var_110h;
    int64_t var_100h;
    undefined4 auStack_f8 [2];
    int64_t var_f0h;
    undefined4 auStack_e7 [3];
    int64_t var_dbh;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_10h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e3a5a;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    *(undefined8 *)((int64_t)&arg_38h + iVar13) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar13) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar13) = unaff_RDI;
    *(undefined8 *)((int64_t)&var_20h + iVar13) = unaff_RBP;
    *(undefined8 *)(&stack0x00000018 + iVar13) = unaff_R12;
    *(undefined8 *)(&stack0x00000010 + iVar13) = unaff_R13;
    *(undefined8 *)(&stack0x00000008 + iVar13) = unaff_R14;
    *(undefined8 *)(&stack0x00000000 + iVar13) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_8 + iVar13) = 0x1801df02a;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    *(uint64_t *)((int64_t)&var_10h + iVar13) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000000 + iVar11 + iVar13);
    *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df052;
    func_0x0001804986e0((int64_t)auStack_f8 + iVar13 + -8, 0, 0xe8);
    iVar12 = *in_RCX;
    *(undefined8 *)((int64_t)&var_110h + iVar13) = 0;
    *(undefined (*) [16])((int64_t)&var_180h + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_170h + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_160h + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_150h + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_140h + iVar13) = ZEXT816(0);
    *(undefined (*) [16])(auStack_130 + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_120h + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_30h + iVar11 + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_40h + iVar11 + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_50h + iVar11 + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_60h + iVar11 + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_70h + iVar11 + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_1b0h + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_1a0h + iVar13) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_190h + iVar13) = ZEXT816(0);
    if (((iVar12 != 0) && (in_RCX[7] != 0)) && (in_RCX[8] != 0)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df0c4;
        iVar9 = func_0x0001801e8e40();
        iVar12 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df0cf;
        iVar10 = func_0x0001801e8e70(iVar12);
        if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) {
            uVar2 = **(undefined8 **)*in_RCX;
            *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df0f3;
            iVar10 = func_0x0001801f99a0(uVar2, (int64_t)iVar10, in_RCX + 0x85);
            if (iVar10 == 0) goto code_r0x0001801df6f4;
        }
        *(undefined8 *)((int64_t)&var_180h + iVar13) = **(undefined8 **)*in_RCX;
        *(undefined8 *)((int64_t)&var_160h + iVar13) = 0x1801defe0;
        *(int64_t **)((int64_t)&var_158h + iVar13) = in_RCX;
        *(undefined8 *)((int64_t)&var_168h + iVar13) = 0x4b0;
        in_RCX[0xa6] = 0x4b0;
        in_RCX[0xb5] = -1;
        *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df13e;
        iVar12 = func_0x0001801fb810((int64_t)&var_180h + iVar13);
        in_RCX[0x7a] = iVar12;
        if (iVar12 != 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df153;
            iVar12 = func_0x000180203ae0();
            in_RCX[0x12] = iVar12;
            if (iVar12 != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df168;
                iVar12 = func_0x000180202050();
                in_RCX[0x13] = iVar12;
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df189;
                    iVar10 = func_0x0001801e5c50(in_RCX + 0x14, 0);
                    if (iVar10 != 0) {
                        *(int64_t **)((int64_t)&arg_28h + iVar11 + iVar13) = in_RCX;
                        in_RCX[0x97] = 0x80000;
                        in_RCX[0x98] = 0x80000;
                        in_RCX[0x99] = 0x80000;
                        *(undefined8 *)((int64_t)&var_20h + iVar11 + iVar13) = 0x1801e36e0;
                        *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df1e0;
                        iVar10 = func_0x0001801e59b0(in_RCX + 0x18, 0, 0xc0000, 0xf00000);
                        if (iVar10 != 0) {
                            uVar17 = 0;
                            do {
                                *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df211;
                                iVar10 = func_0x0001801e5a00(in_RCX + (uVar17 + 3) * 0xc, 0x4000, 0x1801e36e0, in_RCX);
                                if (iVar10 == 0) goto code_r0x0001801df6f4;
                                uVar15 = (int32_t)uVar17 + 1;
                                uVar17 = (uint64_t)uVar15;
                            } while (uVar15 < 3);
                            piVar14 = in_RCX + 0x48;
                            *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df23a;
                            iVar10 = func_0x0001801e5a00(piVar14, 100, 0x1801e36e0, in_RCX);
                            if (iVar10 != 0) {
                                piVar1 = in_RCX + 0x54;
                                *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df260;
                                iVar10 = func_0x0001801e5a00(piVar1, 100, 0x1801e36e0, in_RCX);
                                if (iVar10 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df274;
                                    iVar10 = func_0x0001801de240(in_RCX + 0x72);
                                    if (iVar10 != 0) {
                                        *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x1000;
                                        in_RCX[0x78] = 0x1804ba130;
                                        *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df2a7;
                                        iVar12 = (*(code *)0x18020a610)(0x1801e36e0, in_RCX);
                                        in_RCX[0x77] = iVar12;
                                        if (iVar12 != 0) {
                                            iVar3 = in_RCX[0x78];
                                            *(uint32_t *)((int64_t)&arg_28h + iVar11 + iVar13) =
                                                 *(uint32_t *)(in_RCX + 0xba) >> 0x19 & 1;
                                            *(int64_t *)((int64_t)&var_20h + iVar11 + iVar13) = iVar12;
                                            *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df2e9;
                                            iVar12 = func_0x000180202ae0(0x1801e36e0, in_RCX, in_RCX + 0x72, iVar3);
                                            in_RCX[0x79] = iVar12;
                                            if (iVar12 != 0) {
                                                *(int64_t **)((int64_t)&arg_28h + iVar11 + iVar13) = in_RCX;
                                                *(int64_t **)((int64_t)&var_20h + iVar11 + iVar13) = piVar1;
                                                *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df31f;
                                                iVar10 = func_0x0001801e78a0(in_RCX + 0x60, 0x1801e36c0, in_RCX, piVar14
                                                                            );
                                                if (iVar10 != 0) {
                                                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x2000
                                                    ;
                                                    if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) {
                                                        iVar12 = in_RCX[7];
                                                        *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) =
                                                             0x1801df350;
                                                        iVar10 = func_0x000180200eb0(iVar12, in_RCX, 
                                                                                     (int64_t)in_RCX + 0x452);
                                                        if (iVar10 == 0) goto code_r0x0001801df6f4;
                                                    }
                                                    uVar5 = *(undefined4 *)((int64_t)in_RCX + 0x452);
                                                    uVar6 = *(undefined4 *)((int64_t)in_RCX + 0x456);
                                                    uVar7 = *(undefined4 *)((int64_t)in_RCX + 0x45a);
                                                    uVar8 = *(undefined4 *)((int64_t)in_RCX + 0x45e);
                                                    *(undefined4 *)((int64_t)&var_f0h + iVar13) =
                                                         *(undefined4 *)((int64_t)in_RCX + 0x462);
                                                    *(undefined *)((int64_t)&var_f0h + iVar13 + 4) =
                                                         *(undefined *)((int64_t)in_RCX + 0x466);
                                                    *(undefined4 *)((int64_t)&var_dbh + iVar13) =
                                                         *(undefined4 *)(in_RCX + 0x87);
                                                    *(undefined *)((int64_t)&var_dbh + iVar13 + 4) =
                                                         *(undefined *)((int64_t)in_RCX + 0x43c);
                                                    *(int64_t *)((int64_t)&var_b0h + iVar13) = in_RCX[0x7a];
                                                    *(int64_t *)((int64_t)&var_a8h + iVar13) = in_RCX[0x12];
                                                    *(int64_t *)((int64_t)&var_a0h + iVar13) = in_RCX[0x13];
                                                    *(int64_t *)((int64_t)&var_98h + iVar13) = in_RCX[0x79];
                                                    *(int64_t *)((int64_t)&var_68h + iVar13) = in_RCX[0x78];
                                                    *(int64_t *)((int64_t)&var_60h + iVar13) = in_RCX[0x77];
                                                    *(undefined8 *)((int64_t)&var_58h + iVar13) = 0x1801e36e0;
                                                    *(int64_t **)((int64_t)&var_78h + iVar13) = piVar14;
                                                    *(undefined4 *)((int64_t)auStack_f8 + iVar13 + -8) = uVar5;
                                                    *(undefined4 *)((int64_t)auStack_f8 + iVar13 + -4) = uVar6;
                                                    *(undefined4 *)((int64_t)auStack_f8 + iVar13) = uVar7;
                                                    *(undefined4 *)((int64_t)auStack_f8 + iVar13 + 4) = uVar8;
                                                    uVar5 = *(undefined4 *)(in_RCX + 0x85);
                                                    uVar6 = *(undefined4 *)((int64_t)in_RCX + 0x42c);
                                                    uVar7 = *(undefined4 *)(in_RCX + 0x86);
                                                    uVar8 = *(undefined4 *)((int64_t)in_RCX + 0x434);
                                                    *(undefined8 *)((int64_t)&var_48h + iVar13) = 0x1801defe0;
                                                    *(int64_t **)((int64_t)&var_88h + iVar13) = in_RCX + 0x14;
                                                    uVar16 = 0;
                                                    *(int64_t **)((int64_t)&var_90h + iVar13) = in_RCX + 0x60;
                                                    *(int64_t **)((int64_t)&var_70h + iVar13) = piVar1;
                                                    piVar14 = (int64_t *)((int64_t)&var_30h + iVar13);
                                                    *(undefined4 *)((int64_t)&var_f0h + iVar13 + 5) = uVar5;
                                                    *(undefined4 *)((int64_t)auStack_e7 + iVar13) = uVar6;
                                                    *(undefined4 *)((int64_t)auStack_e7 + iVar13 + 4) = uVar7;
                                                    *(undefined4 *)((int64_t)auStack_e7 + iVar13 + 8) = uVar8;
                                                    *(undefined4 *)((int64_t)&var_b8h + iVar13) = 3;
                                                    *(int64_t **)((int64_t)&var_80h + iVar13) = in_RCX + 0x18;
                                                    *(int64_t **)((int64_t)&var_50h + iVar13) = in_RCX;
                                                    *(int64_t **)((int64_t)&var_40h + iVar13) = in_RCX;
                                                    *(undefined4 *)((int64_t)&var_38h + iVar13) = 1;
                                                    uVar15 = uVar16;
                                                    do {
                                                        *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) =
                                                             0x1801df46a;
                                                        iVar12 = func_0x0001801e66a0(0x4000);
                                                        *(int64_t *)
                                                         ((int64_t)in_RCX + (0x3f8 - ((int64_t)&var_30h + iVar13)) +
                                                         (int64_t)piVar14) = iVar12;
                                                        if (iVar12 == 0) goto code_r0x0001801df6f4;
                                                        *piVar14 = iVar12;
                                                        uVar15 = uVar15 + 1;
                                                        piVar14 = piVar14 + 1;
                                                    } while (uVar15 < 3);
                                                    *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df492;
                                                    iVar12 = func_0x000180207c40((int64_t)auStack_f8 + iVar13 + -8);
                                                    in_RCX[0x11] = iVar12;
                                                    if (iVar12 != 0) {
                                                        if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) {
                                                            *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) =
                                                                 0x1801df4b6;
                                                            func_0x000180208210(iVar12);
                                                        }
                                                        iVar12 = in_RCX[0x11];
                                                        *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) =
                                                             0x1801df4cc;
                                                        func_0x000180207fe0(iVar12, 0x1801e1a30, in_RCX);
                                                        iVar12 = in_RCX[0x7b];
                                                        if (iVar12 == 0) {
                                                            if ((*(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0x400) == 0) {
                                                                puVar4 = (undefined8 *)*in_RCX;
                                                                *(undefined8 *)((int64_t)&var_150h + iVar13) =
                                                                     *(undefined8 *)*puVar4;
                                                                *(undefined8 *)((int64_t)&var_140h + iVar13) = puVar4[8]
                                                                ;
                                                                *(int64_t *)(auStack_130 + iVar13 + -8) = (int64_t)iVar9
                                                                ;
                                                                *(undefined8 *)
                                                                 *(undefined (*) [16])(auStack_130 + iVar13) = 0x20;
                                                                *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) =
                                                                     0x1801df50e;
                                                                iVar12 = func_0x000180205410((int64_t)&var_150h + iVar13
                                                                                            );
                                                                in_RCX[0x7b] = iVar12;
                                                                if (iVar12 == 0) goto code_r0x0001801df6f4;
                                                                goto code_r0x0001801df51e;
                                                            }
code_r0x0001801df556:
                                                            piVar14 = in_RCX + 0x82;
                                                            do {
                                                                *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) =
                                                                     0x1801df56c;
                                                                iVar12 = func_0x0001801e6c90(0, 0, 0);
                                                                *piVar14 = iVar12;
                                                                if (iVar12 == 0) goto code_r0x0001801df6f4;
                                                                uVar16 = uVar16 + 1;
                                                                piVar14 = piVar14 + 1;
                                                            } while (uVar16 < 3);
                                                            *(int64_t *)((int64_t)&arg_30h + iVar11 + iVar13) =
                                                                 in_RCX[6];
                                                            *(undefined8 *)((int64_t)&arg_38h + iVar11 + iVar13) =
                                                                 0x1801dfc30;
                                                            *(undefined8 *)((int64_t)&arg_48h + iVar11 + iVar13) =
                                                                 0x1801df8c0;
                                                            *(undefined8 *)((int64_t)&arg_58h + iVar11 + iVar13) =
                                                                 0x1801dfb70;
                                                            *(undefined8 *)((int64_t)&arg_68h + iVar11 + iVar13) =
                                                                 0x1801e03b0;
                                                            *(undefined8 *)((int64_t)&arg_78h + iVar11 + iVar13) =
                                                                 0x1801e0890;
                                                            *(undefined8 *)((int64_t)&var_1a8h + iVar13) = 0x1801e0050;
                                                            *(undefined8 *)((int64_t)&var_198h + iVar13) = 0x1801dfc90;
                                                            uVar15 = *(uint32_t *)(in_RCX + 0xba);
                                                            *(int64_t **)((int64_t)&arg_40h + iVar11 + iVar13) = in_RCX;
                                                            *(uint32_t *)((int64_t)&var_188h + iVar13) =
                                                                 uVar15 >> 0x19 & 1;
                                                            *(int64_t **)((int64_t)&arg_50h + iVar11 + iVar13) = in_RCX;
                                                            *(int64_t **)((int64_t)&arg_60h + iVar11 + iVar13) = in_RCX;
                                                            *(int64_t **)((int64_t)&arg_70h + iVar11 + iVar13) = in_RCX;
                                                            *(int64_t **)((int64_t)&var_1b0h + iVar13) = in_RCX;
                                                            *(int64_t **)((int64_t)&var_1a0h + iVar13) = in_RCX;
                                                            *(int64_t **)((int64_t)&var_190h + iVar13) = in_RCX;
                                                            *(undefined4 *)((int64_t)&var_188h + iVar13 + 4) = 1;
                                                            *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) =
                                                                 0x1801df61e;
                                                            iVar12 = func_0x0001801a6180((int64_t)&arg_30h +
                                                                                         iVar11 + iVar13);
                                                            in_RCX[5] = iVar12;
                                                            if (iVar12 != 0) {
                                                                iVar12 = in_RCX[0x79];
                                                                *(uint32_t *)(in_RCX + 0xba) =
                                                                     *(uint32_t *)(in_RCX + 0xba) & 0xfff03fff;
                                                                in_RCX[0x9a] = 0x19;
                                                                in_RCX[0x9e] = 0x19;
                                                                *(undefined *)(in_RCX + 0x9f) = 3;
                                                                in_RCX[0xa7] = 2;
                                                                in_RCX[0xad] = -1;
                                                                in_RCX[0xa3] = 30000;
                                                                in_RCX[0xa4] = 0;
                                                                in_RCX[0xa5] = 30000;
                                                                *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) =
                                                                     0x1801df696;
                                                                func_0x0001802038a0(iVar12, 25000000);
                                                                iVar12 = in_RCX[0x9e];
                                                                iVar3 = in_RCX[0x79];
                                                                *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) =
                                                                     0x1801df6ad;
                                                                func_0x000180203890(iVar3, iVar12 * 1000000);
                                                                *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) =
                                                                     0x1801df6b5;
                                                                func_0x0001801e3460(in_RCX);
                                                                iVar12 = *in_RCX;
                                                                if (*(int64_t *)(iVar12 + 0x50) != 0) {
                                                                    *(int64_t **)(*(int64_t *)(iVar12 + 0x50) + 8) =
                                                                         in_RCX;
                                                                }
                                                                in_RCX[2] = *(int64_t *)(iVar12 + 0x50);
                                                                in_RCX[1] = 0;
                                                                *(int64_t **)(iVar12 + 0x50) = in_RCX;
                                                                if (*(int64_t *)(iVar12 + 0x48) == 0) {
                                                                    *(int64_t **)(iVar12 + 0x48) = in_RCX;
                                                                }
                                                                *(int64_t *)(iVar12 + 0x58) =
                                                                     *(int64_t *)(iVar12 + 0x58) + 1;
                                                                *(uint32_t *)((int64_t)in_RCX + 0x5d4) =
                                                                     *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x100;
                                                                goto code_r0x0001801df6fe;
                                                            }
                                                        } else {
code_r0x0001801df51e:
                                                            *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) =
                                                                 0x1801df530;
                                                            iVar9 = func_0x000180205740(iVar12, 0x1801e55f0, in_RCX);
                                                            if (iVar9 != 0) {
                                                                iVar12 = in_RCX[0x7b];
                                                                *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) =
                                                                     0x1801df54e;
                                                                iVar9 = func_0x000180205720(iVar12, 0x1801e5620, in_RCX)
                                                                ;
                                                                if (iVar9 != 0) goto code_r0x0001801df556;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x0001801df6f4:
    *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df6fc;
    fcn.1801de360(*(int64_t *)((int64_t)&var_20h + iVar11 + iVar13), *(int64_t *)((int64_t)&arg_28h + iVar11 + iVar13));
code_r0x0001801df6fe:
    uVar17 = *(uint64_t *)((int64_t)&var_10h + iVar13);
    *(undefined8 *)((int64_t)&uStack_8 + iVar11 + iVar13) = 0x1801df70d;
    func_0x000180459870(uVar17 ^ (uint64_t)(&stack0x00000000 + iVar11 + iVar13));
    return;
}

// ============================================================
// Function: FUN_1801e3a70
// Address: 0x1801e3a70
// Size: 29 bytes
// ============================================================
void fcn.1801e3a70(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t iVar4;
    undefined8 *in_RDX;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar4 = *(int64_t *)(in_RCX + 0x3d8);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x1802052da;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    in_RDX[4] = 0;
    in_RDX[5] = 0;
    *(undefined *)(in_RDX + 0xf) = 0;
    if (*(undefined8 **)(iVar4 + 0x38) != (undefined8 *)0x0) {
        **(undefined8 **)(iVar4 + 0x38) = in_RDX;
    }
    in_RDX[1] = *(undefined8 *)(iVar4 + 0x38);
    *in_RDX = 0;
    *(undefined8 **)(iVar4 + 0x38) = in_RDX;
    if (*(int64_t *)(iVar4 + 0x30) == 0) {
        *(undefined8 **)(iVar4 + 0x30) = in_RDX;
    }
    *(int64_t *)(iVar4 + 0x40) = *(int64_t *)(iVar4 + 0x40) + 1;
    pcVar1 = *(code **)(iVar4 + 0x428);
    if (pcVar1 != (code *)0x0) {
        *(undefined8 *)((int64_t)&arg_58h + iVar3 + iVar2) = *(undefined8 *)(iVar4 + 0x430);
        *(undefined8 *)((int64_t)&arg_50h + iVar3 + iVar2) = *(undefined8 *)(iVar4 + 0x438);
        *(undefined8 *)((int64_t)&arg_48h + iVar3 + iVar2) = in_RDX[2];
        *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar2) = 0x180205359;
        (*pcVar1)(0, 1, 0x200, in_RDX + 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_1801e3a90
// Address: 0x1801e3a90
// Size: 29 bytes
// ============================================================
void fcn.1801e3a90(int64_t param_1, int64_t param_2)
{
    int64_t iVar1;
    
    fcn.18045a350();
    iVar1 = *(int64_t *)(param_1 + 0x3d8);
    if (param_2 != 0) {
        *(int64_t *)(param_2 + 0x68) = *(int64_t *)(param_2 + 0x68) + -1;
    }
    if (*(int64_t *)(param_2 + 0x68) == 0) {
        if (*(int64_t *)(iVar1 + 0x80) != 0) {
            *(int64_t *)(*(int64_t *)(iVar1 + 0x80) + 0x48) = param_2;
        }
        *(undefined8 *)(param_2 + 0x50) = *(undefined8 *)(iVar1 + 0x80);
        *(undefined8 *)(param_2 + 0x48) = 0;
        *(int64_t *)(iVar1 + 0x80) = param_2;
        if (*(int64_t *)(iVar1 + 0x78) == 0) {
            *(int64_t *)(iVar1 + 0x78) = param_2;
        }
        *(int64_t *)(iVar1 + 0x88) = *(int64_t *)(iVar1 + 0x88) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_1801e3b00
// Address: 0x1801e3b00
// Size: 55 bytes
// ============================================================
bool fcn.1801e3b00(int64_t param_1, uint64_t param_2)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = param_2 & 0xffffffff;
    iVar6 = 0x548;
    if ((int32_t)param_2 == 0) {
        iVar6 = 0x540;
    }
    iVar5 = param_1 + 0x300;
    uVar7 = *(uint64_t *)(iVar6 + param_1);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801e799c;
    iVar6 = fcn.18045a350(iVar5, uVar7);
    pcVar1 = *(code **)(iVar5 + 0x70);
    if (pcVar1 == (code *)0x0) {
        return true;
    }
    uVar2 = *(undefined8 *)(iVar5 + 0x78);
    *(undefined8 *)((int64_t)auStackX_18 + (iVar3 - iVar6)) = 0x1801e79bf;
    uVar4 = (*pcVar1)(uVar4 & 0xffffffff, uVar2);
    return uVar7 < uVar4;
}

// ============================================================
// Function: FUN_1801e3b90
// Address: 0x1801e3b90
// Size: 116 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel

void fcn.1801e3b90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e3b9c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = 0;
    *(undefined4 *)((int64_t)&arg_38h + iVar2 + 4) = 0;
    uVar1 = *(uint32_t *)(in_RCX + 0x5d0) & 7;
    if ((uVar1 != 2) && (1 < uVar1 - 3)) {
        *(undefined4 *)((int64_t)&arg_38h + iVar2) = 1;
        *(undefined8 *)((int64_t)&var_18h + iVar2) = in_RDX;
        *(int64_t *)((int64_t)&arg_28h + iVar2) = in_R8;
        if (in_R8 == 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar2) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e3be2;
            uVar3 = func_0x000180498cd0(in_R8);
            *(undefined8 *)((int64_t)&arg_30h + iVar2) = uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e3bfe;
        func_0x0001801e2d20(in_RCX, (int64_t)&var_18h + iVar2, 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801e3c20
// Address: 0x1801e3c20
// Size: 210 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1801e3c20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint64_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t iVar5;
    undefined8 unaff_RDI;
    uint32_t uVar6;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e3c35;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = *(uint32_t *)(in_RCX + 0x5d0) >> 0x19 & 1;
    iVar5 = 0x548;
    if (in_EDX == 0) {
        iVar5 = 0x540;
    } else {
        uVar6 = uVar6 | 2;
    }
    uVar1 = *(uint64_t *)(iVar5 + in_RCX);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R14;
    if (uVar1 < 0x4000000000000000) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3c98;
        iVar4 = func_0x0001801e7640(in_RCX + 0x300, uVar1 * 4 | (uint64_t)uVar6);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3cba;
            iVar2 = func_0x0001801df730(in_RCX, iVar4, 1, in_EDX == 0);
            if (iVar2 != 0) {
                *(int64_t *)(iVar5 + in_RCX) = *(int64_t *)(iVar5 + in_RCX) + 1;
                return iVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3ccd;
            func_0x0001801e7c50(in_RCX + 0x300, iVar4);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e3d00
// Address: 0x1801e3d00
// Size: 224 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_5c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_558h because it doesn't fit into ProtoModel

int64_t fcn.1801e3d00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    uint8_t in_DL;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e3d1a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((((uint8_t)~(uint8_t)((uint32_t)*(undefined4 *)(in_RCX + 0x5d0) >> 0x18) >> 1 ^ in_DL) & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3d4b;
        iVar4 = fcn.1801e7640(*(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000118 + iVar3));
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3d6f;
            iVar2 = fcn.1801df730(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3));
            if (iVar2 != 0) {
                if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x40000000) != 0) {
                    uVar1 = *(undefined8 *)(in_RCX + 0x560);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3dad;
                    fcn.1801e7f00(in_RCX + 0x300, iVar4, uVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3dbf;
                    fcn.1801e7da0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(uint32_t *)(iVar4 + 0x104) = *(uint32_t *)(iVar4 + 0x104) | 0x20;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3dd1;
                    fcn.1801e7fb0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                                  *(int64_t *)(&stack0x00000058 + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                                  *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3), 
                                  *(int64_t *)(&stack0x00000080 + iVar3), *(int64_t *)(&stack0x00000088 + iVar3), 
                                  *(int64_t *)(&stack0x00000090 + iVar3));
                    return iVar4;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3ddb;
                fcn.1801e7c20(in_RCX + 0x300, iVar4);
                return iVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3d7e;
            fcn.1801e7c50(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e3de0
// Address: 0x1801e3de0
// Size: 238 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801e3de0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e3df5;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e3e0e;
    func_0x0001801e1a70();
    uVar2 = in_RCX[0x79];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e3e1a;
    uVar5 = func_0x000180202870(uVar2);
    iVar7 = -1;
    uVar8 = 0xffffffffffffffff;
    if (uVar5 < 0x5555555555555556) {
        uVar8 = uVar5 * 3;
    }
    uVar2 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e3e3f;
    iVar6 = func_0x0001801e8e50(uVar2);
    if (uVar8 <= -iVar6 - 1U) {
        iVar7 = iVar6 + uVar8;
    }
    uVar1 = *(uint32_t *)(in_RCX + 0xb2);
    in_RCX[0xb3] = iVar7;
    if ((uVar1 & 2) == 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RCX[0xae];
        uVar2 = in_RCX[0xaf];
        *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = uVar2;
        uVar2 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = in_RCX[0xb0];
        uVar3 = in_RCX[0xb1];
        *(uint32_t *)((int64_t)&var_18h + iVar4) = uVar1 & 1;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = uVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e3eb4;
        func_0x000180207f00(uVar2, (int64_t)&var_18h + iVar4);
        *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x1000000;
    }
    return;
}

// ============================================================
// Function: FUN_1801e3ed0
// Address: 0x1801e3ed0
// Size: 45 bytes
// ============================================================
undefined8
fcn.1801e3ed0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h,
             int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h,
             int64_t arg_180h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 uVar9;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e3edc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(uint32_t *)(in_RCX + 0x5d0);
    if ((uVar1 >> 10 & 1) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_b8h + iVar3) = unaff_RBX;
    if ((uVar1 >> 9 & 1) != 0) {
        if ((uVar1 >> 0x16 & 1) == 0) {
            uVar7 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e40fa;
            fcn.180207270(uVar7, 2);
            uVar7 = *(undefined8 *)(in_RCX + 0x3d8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e410b;
            fcn.180205130(uVar7, 2);
            uVar7 = *(undefined8 *)(in_RCX + 0x3d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e411c;
            fcn.1801fb350(uVar7, 2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e412d;
            fcn.180202d20(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3));
            if ((*(int64_t *)(in_RCX + 0x400) != 0) && (*(int64_t *)(in_RCX + 0x418) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4148;
                fcn.1801e6180();
                *(undefined8 *)(in_RCX + 0x400) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e415d;
                fcn.1801e6b30(*(int64_t *)((int64_t)&var_18h + iVar3));
                *(undefined8 *)(in_RCX + 0x418) = 0;
                *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x400000;
            }
        }
        *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x400;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e418c;
        fcn.1801e1a70(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
        uVar7 = *(undefined8 *)(in_RCX + 0x3c8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4198;
        fcn.180202cf0(uVar7);
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3f23;
    iVar4 = fcn.1801fca50(10);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_c8h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_98h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_R14;
    uVar9 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_88h + iVar3) = unaff_R15;
    uVar7 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar7 = 0x1805ab2bc;
    }
    uVar8 = 0x1805aadb1;
    iVar2 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
        iVar2 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3f98;
    iVar5 = fcn.1801fcb70(0x1e);
    iVar4 = 0x1805aadb1;
    if (iVar5 != 0) {
        iVar4 = iVar5;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3faa;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3fc2;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    uVar6 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0x1804b7200;
    if (iVar5 != 0) {
        uVar6 = 0x1805ab2bc;
        uVar9 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar6;
    *(int64_t *)((int64_t)&arg_40h + iVar3) = iVar4;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = uVar9;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0x1e;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = uVar7;
    *(int64_t *)((int64_t)&var_20h + iVar3) = iVar2;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4026;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e403e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e407f;
        iVar4 = fcn.1802542f0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3));
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 == 0) goto code_r0x0001801e4093;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4093;
    fcn.180254600(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
code_r0x0001801e4093:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_58h + iVar3) = 10;
    *(undefined8 *)((int64_t)&arg_60h + iVar3) = 0x1e;
    *(undefined8 *)((int64_t)&arg_68h + iVar3) = 0x1804b7200;
    *(undefined8 *)((int64_t)&arg_70h + iVar3) = 0x34;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e40cb;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                  *(int64_t *)((int64_t)&arg_50h + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801e3efd
// Address: 0x1801e3efd
// Size: 52 bytes
// ============================================================
undefined8
fcn.1801e3ed0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h,
             int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h,
             int64_t arg_180h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 uVar9;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e3edc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(uint32_t *)(in_RCX + 0x5d0);
    if ((uVar1 >> 10 & 1) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_b8h + iVar3) = unaff_RBX;
    if ((uVar1 >> 9 & 1) != 0) {
        if ((uVar1 >> 0x16 & 1) == 0) {
            uVar7 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e40fa;
            fcn.180207270(uVar7, 2);
            uVar7 = *(undefined8 *)(in_RCX + 0x3d8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e410b;
            fcn.180205130(uVar7, 2);
            uVar7 = *(undefined8 *)(in_RCX + 0x3d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e411c;
            fcn.1801fb350(uVar7, 2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e412d;
            fcn.180202d20(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3));
            if ((*(int64_t *)(in_RCX + 0x400) != 0) && (*(int64_t *)(in_RCX + 0x418) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4148;
                fcn.1801e6180();
                *(undefined8 *)(in_RCX + 0x400) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e415d;
                fcn.1801e6b30(*(int64_t *)((int64_t)&var_18h + iVar3));
                *(undefined8 *)(in_RCX + 0x418) = 0;
                *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x400000;
            }
        }
        *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x400;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e418c;
        fcn.1801e1a70(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
        uVar7 = *(undefined8 *)(in_RCX + 0x3c8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4198;
        fcn.180202cf0(uVar7);
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3f23;
    iVar4 = fcn.1801fca50(10);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_c8h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_98h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_R14;
    uVar9 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_88h + iVar3) = unaff_R15;
    uVar7 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar7 = 0x1805ab2bc;
    }
    uVar8 = 0x1805aadb1;
    iVar2 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
        iVar2 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3f98;
    iVar5 = fcn.1801fcb70(0x1e);
    iVar4 = 0x1805aadb1;
    if (iVar5 != 0) {
        iVar4 = iVar5;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3faa;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3fc2;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    uVar6 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0x1804b7200;
    if (iVar5 != 0) {
        uVar6 = 0x1805ab2bc;
        uVar9 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar6;
    *(int64_t *)((int64_t)&arg_40h + iVar3) = iVar4;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = uVar9;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0x1e;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = uVar7;
    *(int64_t *)((int64_t)&var_20h + iVar3) = iVar2;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4026;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e403e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e407f;
        iVar4 = fcn.1802542f0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3));
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 == 0) goto code_r0x0001801e4093;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4093;
    fcn.180254600(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
code_r0x0001801e4093:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_58h + iVar3) = 10;
    *(undefined8 *)((int64_t)&arg_60h + iVar3) = 0x1e;
    *(undefined8 *)((int64_t)&arg_68h + iVar3) = 0x1804b7200;
    *(undefined8 *)((int64_t)&arg_70h + iVar3) = 0x34;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e40cb;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                  *(int64_t *)((int64_t)&arg_50h + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801e3f31
// Address: 0x1801e3f31
// Size: 329 bytes
// ============================================================
undefined8
fcn.1801e3ed0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h,
             int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h,
             int64_t arg_180h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 uVar9;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e3edc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(uint32_t *)(in_RCX + 0x5d0);
    if ((uVar1 >> 10 & 1) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_b8h + iVar3) = unaff_RBX;
    if ((uVar1 >> 9 & 1) != 0) {
        if ((uVar1 >> 0x16 & 1) == 0) {
            uVar7 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e40fa;
            fcn.180207270(uVar7, 2);
            uVar7 = *(undefined8 *)(in_RCX + 0x3d8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e410b;
            fcn.180205130(uVar7, 2);
            uVar7 = *(undefined8 *)(in_RCX + 0x3d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e411c;
            fcn.1801fb350(uVar7, 2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e412d;
            fcn.180202d20(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3));
            if ((*(int64_t *)(in_RCX + 0x400) != 0) && (*(int64_t *)(in_RCX + 0x418) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4148;
                fcn.1801e6180();
                *(undefined8 *)(in_RCX + 0x400) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e415d;
                fcn.1801e6b30(*(int64_t *)((int64_t)&var_18h + iVar3));
                *(undefined8 *)(in_RCX + 0x418) = 0;
                *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x400000;
            }
        }
        *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x400;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e418c;
        fcn.1801e1a70(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
        uVar7 = *(undefined8 *)(in_RCX + 0x3c8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4198;
        fcn.180202cf0(uVar7);
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3f23;
    iVar4 = fcn.1801fca50(10);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_c8h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_98h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_R14;
    uVar9 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_88h + iVar3) = unaff_R15;
    uVar7 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar7 = 0x1805ab2bc;
    }
    uVar8 = 0x1805aadb1;
    iVar2 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
        iVar2 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3f98;
    iVar5 = fcn.1801fcb70(0x1e);
    iVar4 = 0x1805aadb1;
    if (iVar5 != 0) {
        iVar4 = iVar5;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3faa;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3fc2;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    uVar6 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0x1804b7200;
    if (iVar5 != 0) {
        uVar6 = 0x1805ab2bc;
        uVar9 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar6;
    *(int64_t *)((int64_t)&arg_40h + iVar3) = iVar4;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = uVar9;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0x1e;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = uVar7;
    *(int64_t *)((int64_t)&var_20h + iVar3) = iVar2;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4026;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e403e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e407f;
        iVar4 = fcn.1802542f0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3));
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 == 0) goto code_r0x0001801e4093;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4093;
    fcn.180254600(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
code_r0x0001801e4093:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_58h + iVar3) = 10;
    *(undefined8 *)((int64_t)&arg_60h + iVar3) = 0x1e;
    *(undefined8 *)((int64_t)&arg_68h + iVar3) = 0x1804b7200;
    *(undefined8 *)((int64_t)&arg_70h + iVar3) = 0x34;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e40cb;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                  *(int64_t *)((int64_t)&arg_50h + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801e407a
// Address: 0x1801e407a
// Size: 101 bytes
// ============================================================
undefined8
fcn.1801e3ed0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h,
             int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h,
             int64_t arg_180h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 uVar9;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e3edc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(uint32_t *)(in_RCX + 0x5d0);
    if ((uVar1 >> 10 & 1) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_b8h + iVar3) = unaff_RBX;
    if ((uVar1 >> 9 & 1) != 0) {
        if ((uVar1 >> 0x16 & 1) == 0) {
            uVar7 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e40fa;
            fcn.180207270(uVar7, 2);
            uVar7 = *(undefined8 *)(in_RCX + 0x3d8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e410b;
            fcn.180205130(uVar7, 2);
            uVar7 = *(undefined8 *)(in_RCX + 0x3d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e411c;
            fcn.1801fb350(uVar7, 2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e412d;
            fcn.180202d20(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3));
            if ((*(int64_t *)(in_RCX + 0x400) != 0) && (*(int64_t *)(in_RCX + 0x418) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4148;
                fcn.1801e6180();
                *(undefined8 *)(in_RCX + 0x400) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e415d;
                fcn.1801e6b30(*(int64_t *)((int64_t)&var_18h + iVar3));
                *(undefined8 *)(in_RCX + 0x418) = 0;
                *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x400000;
            }
        }
        *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x400;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e418c;
        fcn.1801e1a70(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
        uVar7 = *(undefined8 *)(in_RCX + 0x3c8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4198;
        fcn.180202cf0(uVar7);
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3f23;
    iVar4 = fcn.1801fca50(10);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_c8h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_98h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_R14;
    uVar9 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_88h + iVar3) = unaff_R15;
    uVar7 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar7 = 0x1805ab2bc;
    }
    uVar8 = 0x1805aadb1;
    iVar2 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
        iVar2 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3f98;
    iVar5 = fcn.1801fcb70(0x1e);
    iVar4 = 0x1805aadb1;
    if (iVar5 != 0) {
        iVar4 = iVar5;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3faa;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3fc2;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    uVar6 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0x1804b7200;
    if (iVar5 != 0) {
        uVar6 = 0x1805ab2bc;
        uVar9 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar6;
    *(int64_t *)((int64_t)&arg_40h + iVar3) = iVar4;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = uVar9;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0x1e;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = uVar7;
    *(int64_t *)((int64_t)&var_20h + iVar3) = iVar2;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4026;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e403e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e407f;
        iVar4 = fcn.1802542f0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3));
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 == 0) goto code_r0x0001801e4093;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4093;
    fcn.180254600(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
code_r0x0001801e4093:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_58h + iVar3) = 10;
    *(undefined8 *)((int64_t)&arg_60h + iVar3) = 0x1e;
    *(undefined8 *)((int64_t)&arg_68h + iVar3) = 0x1804b7200;
    *(undefined8 *)((int64_t)&arg_70h + iVar3) = 0x34;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e40cb;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                  *(int64_t *)((int64_t)&arg_50h + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801e40df
// Address: 0x1801e40df
// Size: 208 bytes
// ============================================================
undefined8
fcn.1801e3ed0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h,
             int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h,
             int64_t arg_180h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 uVar9;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e3edc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(uint32_t *)(in_RCX + 0x5d0);
    if ((uVar1 >> 10 & 1) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_b8h + iVar3) = unaff_RBX;
    if ((uVar1 >> 9 & 1) != 0) {
        if ((uVar1 >> 0x16 & 1) == 0) {
            uVar7 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e40fa;
            fcn.180207270(uVar7, 2);
            uVar7 = *(undefined8 *)(in_RCX + 0x3d8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e410b;
            fcn.180205130(uVar7, 2);
            uVar7 = *(undefined8 *)(in_RCX + 0x3d0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e411c;
            fcn.1801fb350(uVar7, 2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e412d;
            fcn.180202d20(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3));
            if ((*(int64_t *)(in_RCX + 0x400) != 0) && (*(int64_t *)(in_RCX + 0x418) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4148;
                fcn.1801e6180();
                *(undefined8 *)(in_RCX + 0x400) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e415d;
                fcn.1801e6b30(*(int64_t *)((int64_t)&var_18h + iVar3));
                *(undefined8 *)(in_RCX + 0x418) = 0;
                *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x400000;
            }
        }
        *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x400;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e418c;
        fcn.1801e1a70(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3));
        uVar7 = *(undefined8 *)(in_RCX + 0x3c8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4198;
        fcn.180202cf0(uVar7);
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3f23;
    iVar4 = fcn.1801fca50(10);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_c8h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_98h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_R14;
    uVar9 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_88h + iVar3) = unaff_R15;
    uVar7 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar7 = 0x1805ab2bc;
    }
    uVar8 = 0x1805aadb1;
    iVar2 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
        iVar2 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3f98;
    iVar5 = fcn.1801fcb70(0x1e);
    iVar4 = 0x1805aadb1;
    if (iVar5 != 0) {
        iVar4 = iVar5;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3faa;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e3fc2;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    uVar6 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0x1804b7200;
    if (iVar5 != 0) {
        uVar6 = 0x1805ab2bc;
        uVar9 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar6;
    *(int64_t *)((int64_t)&arg_40h + iVar3) = iVar4;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = uVar9;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0x1e;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = uVar7;
    *(int64_t *)((int64_t)&var_20h + iVar3) = iVar2;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4026;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e403e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e407f;
        iVar4 = fcn.1802542f0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3));
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 == 0) goto code_r0x0001801e4093;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e4093;
    fcn.180254600(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
code_r0x0001801e4093:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_58h + iVar3) = 10;
    *(undefined8 *)((int64_t)&arg_60h + iVar3) = 0x1e;
    *(undefined8 *)((int64_t)&arg_68h + iVar3) = 0x1804b7200;
    *(undefined8 *)((int64_t)&arg_70h + iVar3) = 0x34;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e40cb;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                  *(int64_t *)((int64_t)&arg_50h + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801e41b0
// Address: 0x1801e41b0
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801e41b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e41ca;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x2000007) == 0x2000000) {
        uVar3 = *(undefined8 *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e41fe;
        iVar1 = func_0x000180200eb0(uVar3, in_RCX, in_RCX + 0x47c);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e421c;
            uVar3 = func_0x0001801e06e0(in_RCX, in_RDX, in_R8, in_R9);
            return uVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e4240
// Address: 0x1801e4240
// Size: 66 bytes
// ============================================================
void fcn.1801e4240(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h)
{
    char cVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    uint64_t *in_RDX;
    undefined8 unaff_RSI;
    uint64_t uVar12;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    undefined8 unaff_R12;
    int64_t iVar14;
    undefined8 unaff_R13;
    undefined8 uVar15;
    undefined8 uVar16;
    undefined8 unaff_R15;
    undefined8 uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e4254;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar2 = *(uint64_t *)(in_RCX + 0x4a8);
    uVar3 = *(uint64_t *)(in_RCX + 0x4b0);
    if (((uint8_t)*(undefined4 *)(in_RCX + 0x5d0) & 7) != 1) {
        return;
    }
    cVar1 = *(char *)(in_RCX + 0x491);
    *(undefined8 *)((int64_t)&arg_78h + iVar8) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_a8h + iVar8) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_b0h + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_b8h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_80h + iVar8) = unaff_R13;
    if (cVar1 == '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e42c2;
        iVar9 = fcn.1801fca50(10);
        if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
            return;
        }
        uVar15 = 0x1805aadb1;
        uVar17 = 0x1805aadb1;
        if (iVar9 != 0) {
            uVar17 = 0x1805ab2bc;
        }
        uVar16 = 0x1805aadb1;
        iVar14 = 0x1805aadb1;
        if (iVar9 != 0) {
            uVar16 = 0x1805ab2cc;
            iVar14 = iVar9;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4306;
        iVar10 = fcn.1801fcb70(0x18);
        iVar9 = 0x1805aadb1;
        if (iVar10 != 0) {
            iVar9 = iVar10;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4318;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4330;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        uVar11 = 0x1805aadb1;
        *(undefined8 *)((int64_t)&arg_40h + iVar8) = 0x1804b72b0;
        if (iVar10 != 0) {
            uVar11 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&arg_38h + iVar8) = uVar11;
        *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar9;
        if (iVar10 != 0) {
            uVar15 = 0x1805ab2cc;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar8) = uVar15;
        *(undefined8 *)((int64_t)&var_20h + iVar8) = 0x18;
        *(undefined8 *)((int64_t)&var_18h + iVar8) = uVar17;
        *(int64_t *)((int64_t)&var_10h + iVar8) = iVar14;
        *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar16;
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e439b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e43b3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e43c4;
            iVar9 = fcn.1802542f0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8));
            *(int64_t *)(in_RCX + 0x5d8) = iVar9;
            if (iVar9 == 0) goto code_r0x0001801e47a8;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e43d8;
        fcn.180254600(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
    } else {
        uVar12 = *in_RDX;
        if (*in_RDX <= uVar2) {
            uVar12 = uVar2;
        }
        uVar13 = in_RDX[1];
        if (in_RDX[1] <= uVar3) {
            uVar13 = uVar3;
        }
        if (uVar12 - uVar13 < 2) {
            if (uVar13 - uVar3 < 0xb) {
                if (uVar12 <= uVar2) {
code_r0x0001801e4807:
                    uVar2 = *(uint64_t *)(in_RCX + 0x4b0);
                    while( true ) {
                        if (uVar13 <= uVar2) {
                            return;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e481e;
                        iVar7 = func_0x0001801de6f0(in_RCX, uVar2);
                        if (iVar7 == 0) break;
                        *(int64_t *)(in_RCX + 0x4b0) = *(int64_t *)(in_RCX + 0x4b0) + 1;
                        uVar2 = *(uint64_t *)(in_RCX + 0x4b0);
                    }
                    return;
                }
                uVar15 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4668;
                iVar7 = func_0x000180201190(uVar15, in_RCX, uVar12, (int64_t)in_RDX + 0x25);
                if (iVar7 != 0) {
                    uVar15 = *(undefined8 *)(in_RCX + 0x88);
                    *(uint64_t *)(in_RCX + 0x4a8) = uVar12;
                    uVar4 = *(undefined4 *)((int64_t)in_RDX + 0x14);
                    uVar5 = *(undefined4 *)(in_RDX + 3);
                    uVar6 = *(undefined4 *)((int64_t)in_RDX + 0x1c);
                    *(undefined4 *)(in_RCX + 0x491) = *(undefined4 *)(in_RDX + 2);
                    *(undefined4 *)(in_RCX + 0x495) = uVar4;
                    *(undefined4 *)(in_RCX + 0x499) = uVar5;
                    *(undefined4 *)(in_RCX + 0x49d) = uVar6;
                    *(undefined4 *)(in_RCX + 0x4a1) = *(undefined4 *)(in_RDX + 4);
                    *(undefined *)(in_RCX + 0x4a5) = *(undefined *)((int64_t)in_RDX + 0x24);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4807;
                    func_0x000180207ff0(uVar15, in_RCX + 0x491);
                    goto code_r0x0001801e4807;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4682;
                iVar9 = fcn.1801fca50(9);
                if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar15 = 0x1805aadb1;
                uVar17 = 0x1805aadb1;
                if (iVar9 != 0) {
                    uVar17 = 0x1805ab2bc;
                }
                uVar16 = 0x1805aadb1;
                iVar14 = 0x1805aadb1;
                if (iVar9 != 0) {
                    uVar16 = 0x1805ab2cc;
                    iVar14 = iVar9;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e46c6;
                iVar10 = fcn.1801fcb70(0x18);
                iVar9 = 0x1805aadb1;
                if (iVar10 != 0) {
                    iVar9 = iVar10;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e46d8;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e46f0;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                              *(int64_t *)((int64_t)&arg_38h + iVar8));
                uVar11 = 0x1805aadb1;
                *(undefined8 *)((int64_t)&arg_40h + iVar8) = 0x1804b7328;
                if (iVar10 != 0) {
                    uVar11 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&arg_38h + iVar8) = uVar11;
                *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar9;
                if (iVar10 != 0) {
                    uVar15 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&arg_28h + iVar8) = uVar15;
                *(undefined8 *)((int64_t)&var_20h + iVar8) = 0x18;
                *(undefined8 *)((int64_t)&var_18h + iVar8) = uVar17;
                *(int64_t *)((int64_t)&var_10h + iVar8) = iVar14;
                *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar16;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e475b;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4569;
                iVar9 = fcn.1801fca50(9);
                if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar15 = 0x1805aadb1;
                uVar17 = 0x1805aadb1;
                if (iVar9 != 0) {
                    uVar17 = 0x1805ab2bc;
                }
                uVar16 = 0x1805aadb1;
                iVar14 = 0x1805aadb1;
                if (iVar9 != 0) {
                    uVar16 = 0x1805ab2cc;
                    iVar14 = iVar9;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e45ad;
                iVar10 = fcn.1801fcb70(0x18);
                iVar9 = 0x1805aadb1;
                if (iVar10 != 0) {
                    iVar9 = iVar10;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e45bf;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e45d7;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                              *(int64_t *)((int64_t)&arg_38h + iVar8));
                uVar11 = 0x1805aadb1;
                *(undefined8 *)((int64_t)&arg_40h + iVar8) = 0x1804b7300;
                if (iVar10 != 0) {
                    uVar11 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&arg_38h + iVar8) = uVar11;
                *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar9;
                if (iVar10 != 0) {
                    uVar15 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&arg_28h + iVar8) = uVar15;
                *(undefined8 *)((int64_t)&var_20h + iVar8) = 0x18;
                *(undefined8 *)((int64_t)&var_18h + iVar8) = uVar17;
                *(int64_t *)((int64_t)&var_10h + iVar8) = iVar14;
                *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar16;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4642;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar8));
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4773;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4784;
                iVar9 = fcn.1802542f0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8));
                *(int64_t *)(in_RCX + 0x5d8) = iVar9;
                if (iVar9 == 0) goto code_r0x0001801e47a8;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4798;
            fcn.180254600(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4424;
            iVar9 = fcn.1801fca50(9);
            if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                return;
            }
            uVar15 = 0x1805aadb1;
            uVar17 = 0x1805aadb1;
            if (iVar9 != 0) {
                uVar17 = 0x1805ab2bc;
            }
            uVar16 = 0x1805aadb1;
            iVar14 = 0x1805aadb1;
            if (iVar9 != 0) {
                uVar16 = 0x1805ab2cc;
                iVar14 = iVar9;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4468;
            iVar10 = fcn.1801fcb70(0x18);
            iVar9 = 0x1805aadb1;
            if (iVar10 != 0) {
                iVar9 = iVar10;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e447a;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4492;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            uVar11 = 0x1805aadb1;
            *(undefined8 *)((int64_t)&arg_40h + iVar8) = 0x1804b72d8;
            if (iVar10 != 0) {
                uVar11 = 0x1805ab2bc;
            }
            *(undefined8 *)((int64_t)&arg_38h + iVar8) = uVar11;
            *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar9;
            if (iVar10 != 0) {
                uVar15 = 0x1805ab2cc;
            }
            *(undefined8 *)((int64_t)&arg_28h + iVar8) = uVar15;
            *(undefined8 *)((int64_t)&var_20h + iVar8) = 0x18;
            *(undefined8 *)((int64_t)&var_18h + iVar8) = uVar17;
            *(int64_t *)((int64_t)&var_10h + iVar8) = iVar14;
            *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar16;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e44fd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4515;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4526;
                iVar9 = fcn.1802542f0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8));
                *(int64_t *)(in_RCX + 0x5d8) = iVar9;
                if (iVar9 == 0) goto code_r0x0001801e47a8;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e453a;
            fcn.180254600(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
        }
    }
code_r0x0001801e47a8:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e47ca;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8), 
                  *(int64_t *)((int64_t)&arg_40h + iVar8), *(int64_t *)(&stack0x00000048 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801e4282
// Address: 0x1801e4282
// Size: 1499 bytes
// ============================================================
void fcn.1801e4240(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h)
{
    char cVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    uint64_t *in_RDX;
    undefined8 unaff_RSI;
    uint64_t uVar12;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    undefined8 unaff_R12;
    int64_t iVar14;
    undefined8 unaff_R13;
    undefined8 uVar15;
    undefined8 uVar16;
    undefined8 unaff_R15;
    undefined8 uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e4254;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar2 = *(uint64_t *)(in_RCX + 0x4a8);
    uVar3 = *(uint64_t *)(in_RCX + 0x4b0);
    if (((uint8_t)*(undefined4 *)(in_RCX + 0x5d0) & 7) != 1) {
        return;
    }
    cVar1 = *(char *)(in_RCX + 0x491);
    *(undefined8 *)((int64_t)&arg_78h + iVar8) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_a8h + iVar8) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_b0h + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_b8h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_80h + iVar8) = unaff_R13;
    if (cVar1 == '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e42c2;
        iVar9 = fcn.1801fca50(10);
        if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
            return;
        }
        uVar15 = 0x1805aadb1;
        uVar17 = 0x1805aadb1;
        if (iVar9 != 0) {
            uVar17 = 0x1805ab2bc;
        }
        uVar16 = 0x1805aadb1;
        iVar14 = 0x1805aadb1;
        if (iVar9 != 0) {
            uVar16 = 0x1805ab2cc;
            iVar14 = iVar9;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4306;
        iVar10 = fcn.1801fcb70(0x18);
        iVar9 = 0x1805aadb1;
        if (iVar10 != 0) {
            iVar9 = iVar10;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4318;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4330;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        uVar11 = 0x1805aadb1;
        *(undefined8 *)((int64_t)&arg_40h + iVar8) = 0x1804b72b0;
        if (iVar10 != 0) {
            uVar11 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&arg_38h + iVar8) = uVar11;
        *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar9;
        if (iVar10 != 0) {
            uVar15 = 0x1805ab2cc;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar8) = uVar15;
        *(undefined8 *)((int64_t)&var_20h + iVar8) = 0x18;
        *(undefined8 *)((int64_t)&var_18h + iVar8) = uVar17;
        *(int64_t *)((int64_t)&var_10h + iVar8) = iVar14;
        *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar16;
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e439b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e43b3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e43c4;
            iVar9 = fcn.1802542f0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8));
            *(int64_t *)(in_RCX + 0x5d8) = iVar9;
            if (iVar9 == 0) goto code_r0x0001801e47a8;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e43d8;
        fcn.180254600(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
    } else {
        uVar12 = *in_RDX;
        if (*in_RDX <= uVar2) {
            uVar12 = uVar2;
        }
        uVar13 = in_RDX[1];
        if (in_RDX[1] <= uVar3) {
            uVar13 = uVar3;
        }
        if (uVar12 - uVar13 < 2) {
            if (uVar13 - uVar3 < 0xb) {
                if (uVar12 <= uVar2) {
code_r0x0001801e4807:
                    uVar2 = *(uint64_t *)(in_RCX + 0x4b0);
                    while( true ) {
                        if (uVar13 <= uVar2) {
                            return;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e481e;
                        iVar7 = func_0x0001801de6f0(in_RCX, uVar2);
                        if (iVar7 == 0) break;
                        *(int64_t *)(in_RCX + 0x4b0) = *(int64_t *)(in_RCX + 0x4b0) + 1;
                        uVar2 = *(uint64_t *)(in_RCX + 0x4b0);
                    }
                    return;
                }
                uVar15 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4668;
                iVar7 = func_0x000180201190(uVar15, in_RCX, uVar12, (int64_t)in_RDX + 0x25);
                if (iVar7 != 0) {
                    uVar15 = *(undefined8 *)(in_RCX + 0x88);
                    *(uint64_t *)(in_RCX + 0x4a8) = uVar12;
                    uVar4 = *(undefined4 *)((int64_t)in_RDX + 0x14);
                    uVar5 = *(undefined4 *)(in_RDX + 3);
                    uVar6 = *(undefined4 *)((int64_t)in_RDX + 0x1c);
                    *(undefined4 *)(in_RCX + 0x491) = *(undefined4 *)(in_RDX + 2);
                    *(undefined4 *)(in_RCX + 0x495) = uVar4;
                    *(undefined4 *)(in_RCX + 0x499) = uVar5;
                    *(undefined4 *)(in_RCX + 0x49d) = uVar6;
                    *(undefined4 *)(in_RCX + 0x4a1) = *(undefined4 *)(in_RDX + 4);
                    *(undefined *)(in_RCX + 0x4a5) = *(undefined *)((int64_t)in_RDX + 0x24);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4807;
                    func_0x000180207ff0(uVar15, in_RCX + 0x491);
                    goto code_r0x0001801e4807;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4682;
                iVar9 = fcn.1801fca50(9);
                if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar15 = 0x1805aadb1;
                uVar17 = 0x1805aadb1;
                if (iVar9 != 0) {
                    uVar17 = 0x1805ab2bc;
                }
                uVar16 = 0x1805aadb1;
                iVar14 = 0x1805aadb1;
                if (iVar9 != 0) {
                    uVar16 = 0x1805ab2cc;
                    iVar14 = iVar9;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e46c6;
                iVar10 = fcn.1801fcb70(0x18);
                iVar9 = 0x1805aadb1;
                if (iVar10 != 0) {
                    iVar9 = iVar10;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e46d8;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e46f0;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                              *(int64_t *)((int64_t)&arg_38h + iVar8));
                uVar11 = 0x1805aadb1;
                *(undefined8 *)((int64_t)&arg_40h + iVar8) = 0x1804b7328;
                if (iVar10 != 0) {
                    uVar11 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&arg_38h + iVar8) = uVar11;
                *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar9;
                if (iVar10 != 0) {
                    uVar15 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&arg_28h + iVar8) = uVar15;
                *(undefined8 *)((int64_t)&var_20h + iVar8) = 0x18;
                *(undefined8 *)((int64_t)&var_18h + iVar8) = uVar17;
                *(int64_t *)((int64_t)&var_10h + iVar8) = iVar14;
                *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar16;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e475b;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4569;
                iVar9 = fcn.1801fca50(9);
                if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar15 = 0x1805aadb1;
                uVar17 = 0x1805aadb1;
                if (iVar9 != 0) {
                    uVar17 = 0x1805ab2bc;
                }
                uVar16 = 0x1805aadb1;
                iVar14 = 0x1805aadb1;
                if (iVar9 != 0) {
                    uVar16 = 0x1805ab2cc;
                    iVar14 = iVar9;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e45ad;
                iVar10 = fcn.1801fcb70(0x18);
                iVar9 = 0x1805aadb1;
                if (iVar10 != 0) {
                    iVar9 = iVar10;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e45bf;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e45d7;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                              *(int64_t *)((int64_t)&arg_38h + iVar8));
                uVar11 = 0x1805aadb1;
                *(undefined8 *)((int64_t)&arg_40h + iVar8) = 0x1804b7300;
                if (iVar10 != 0) {
                    uVar11 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&arg_38h + iVar8) = uVar11;
                *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar9;
                if (iVar10 != 0) {
                    uVar15 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&arg_28h + iVar8) = uVar15;
                *(undefined8 *)((int64_t)&var_20h + iVar8) = 0x18;
                *(undefined8 *)((int64_t)&var_18h + iVar8) = uVar17;
                *(int64_t *)((int64_t)&var_10h + iVar8) = iVar14;
                *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar16;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4642;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar8));
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4773;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4784;
                iVar9 = fcn.1802542f0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8));
                *(int64_t *)(in_RCX + 0x5d8) = iVar9;
                if (iVar9 == 0) goto code_r0x0001801e47a8;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4798;
            fcn.180254600(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4424;
            iVar9 = fcn.1801fca50(9);
            if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                return;
            }
            uVar15 = 0x1805aadb1;
            uVar17 = 0x1805aadb1;
            if (iVar9 != 0) {
                uVar17 = 0x1805ab2bc;
            }
            uVar16 = 0x1805aadb1;
            iVar14 = 0x1805aadb1;
            if (iVar9 != 0) {
                uVar16 = 0x1805ab2cc;
                iVar14 = iVar9;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4468;
            iVar10 = fcn.1801fcb70(0x18);
            iVar9 = 0x1805aadb1;
            if (iVar10 != 0) {
                iVar9 = iVar10;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e447a;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4492;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            uVar11 = 0x1805aadb1;
            *(undefined8 *)((int64_t)&arg_40h + iVar8) = 0x1804b72d8;
            if (iVar10 != 0) {
                uVar11 = 0x1805ab2bc;
            }
            *(undefined8 *)((int64_t)&arg_38h + iVar8) = uVar11;
            *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar9;
            if (iVar10 != 0) {
                uVar15 = 0x1805ab2cc;
            }
            *(undefined8 *)((int64_t)&arg_28h + iVar8) = uVar15;
            *(undefined8 *)((int64_t)&var_20h + iVar8) = 0x18;
            *(undefined8 *)((int64_t)&var_18h + iVar8) = uVar17;
            *(int64_t *)((int64_t)&var_10h + iVar8) = iVar14;
            *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar16;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e44fd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4515;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4526;
                iVar9 = fcn.1802542f0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8));
                *(int64_t *)(in_RCX + 0x5d8) = iVar9;
                if (iVar9 == 0) goto code_r0x0001801e47a8;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e453a;
            fcn.180254600(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
        }
    }
code_r0x0001801e47a8:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e47ca;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8), 
                  *(int64_t *)((int64_t)&arg_40h + iVar8), *(int64_t *)(&stack0x00000048 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801e485d
// Address: 0x1801e485d
// Size: 12 bytes
// ============================================================
void fcn.1801e4240(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h)
{
    char cVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    uint64_t *in_RDX;
    undefined8 unaff_RSI;
    uint64_t uVar12;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    undefined8 unaff_R12;
    int64_t iVar14;
    undefined8 unaff_R13;
    undefined8 uVar15;
    undefined8 uVar16;
    undefined8 unaff_R15;
    undefined8 uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e4254;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar2 = *(uint64_t *)(in_RCX + 0x4a8);
    uVar3 = *(uint64_t *)(in_RCX + 0x4b0);
    if (((uint8_t)*(undefined4 *)(in_RCX + 0x5d0) & 7) != 1) {
        return;
    }
    cVar1 = *(char *)(in_RCX + 0x491);
    *(undefined8 *)((int64_t)&arg_78h + iVar8) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_a8h + iVar8) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_b0h + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_b8h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_80h + iVar8) = unaff_R13;
    if (cVar1 == '\0') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e42c2;
        iVar9 = fcn.1801fca50(10);
        if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
            return;
        }
        uVar15 = 0x1805aadb1;
        uVar17 = 0x1805aadb1;
        if (iVar9 != 0) {
            uVar17 = 0x1805ab2bc;
        }
        uVar16 = 0x1805aadb1;
        iVar14 = 0x1805aadb1;
        if (iVar9 != 0) {
            uVar16 = 0x1805ab2cc;
            iVar14 = iVar9;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4306;
        iVar10 = fcn.1801fcb70(0x18);
        iVar9 = 0x1805aadb1;
        if (iVar10 != 0) {
            iVar9 = iVar10;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4318;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4330;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        uVar11 = 0x1805aadb1;
        *(undefined8 *)((int64_t)&arg_40h + iVar8) = 0x1804b72b0;
        if (iVar10 != 0) {
            uVar11 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&arg_38h + iVar8) = uVar11;
        *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar9;
        if (iVar10 != 0) {
            uVar15 = 0x1805ab2cc;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar8) = uVar15;
        *(undefined8 *)((int64_t)&var_20h + iVar8) = 0x18;
        *(undefined8 *)((int64_t)&var_18h + iVar8) = uVar17;
        *(int64_t *)((int64_t)&var_10h + iVar8) = iVar14;
        *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar16;
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e439b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e43b3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar8));
        if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e43c4;
            iVar9 = fcn.1802542f0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8));
            *(int64_t *)(in_RCX + 0x5d8) = iVar9;
            if (iVar9 == 0) goto code_r0x0001801e47a8;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e43d8;
        fcn.180254600(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
    } else {
        uVar12 = *in_RDX;
        if (*in_RDX <= uVar2) {
            uVar12 = uVar2;
        }
        uVar13 = in_RDX[1];
        if (in_RDX[1] <= uVar3) {
            uVar13 = uVar3;
        }
        if (uVar12 - uVar13 < 2) {
            if (uVar13 - uVar3 < 0xb) {
                if (uVar12 <= uVar2) {
code_r0x0001801e4807:
                    uVar2 = *(uint64_t *)(in_RCX + 0x4b0);
                    while( true ) {
                        if (uVar13 <= uVar2) {
                            return;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e481e;
                        iVar7 = func_0x0001801de6f0(in_RCX, uVar2);
                        if (iVar7 == 0) break;
                        *(int64_t *)(in_RCX + 0x4b0) = *(int64_t *)(in_RCX + 0x4b0) + 1;
                        uVar2 = *(uint64_t *)(in_RCX + 0x4b0);
                    }
                    return;
                }
                uVar15 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4668;
                iVar7 = func_0x000180201190(uVar15, in_RCX, uVar12, (int64_t)in_RDX + 0x25);
                if (iVar7 != 0) {
                    uVar15 = *(undefined8 *)(in_RCX + 0x88);
                    *(uint64_t *)(in_RCX + 0x4a8) = uVar12;
                    uVar4 = *(undefined4 *)((int64_t)in_RDX + 0x14);
                    uVar5 = *(undefined4 *)(in_RDX + 3);
                    uVar6 = *(undefined4 *)((int64_t)in_RDX + 0x1c);
                    *(undefined4 *)(in_RCX + 0x491) = *(undefined4 *)(in_RDX + 2);
                    *(undefined4 *)(in_RCX + 0x495) = uVar4;
                    *(undefined4 *)(in_RCX + 0x499) = uVar5;
                    *(undefined4 *)(in_RCX + 0x49d) = uVar6;
                    *(undefined4 *)(in_RCX + 0x4a1) = *(undefined4 *)(in_RDX + 4);
                    *(undefined *)(in_RCX + 0x4a5) = *(undefined *)((int64_t)in_RDX + 0x24);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4807;
                    func_0x000180207ff0(uVar15, in_RCX + 0x491);
                    goto code_r0x0001801e4807;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4682;
                iVar9 = fcn.1801fca50(9);
                if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar15 = 0x1805aadb1;
                uVar17 = 0x1805aadb1;
                if (iVar9 != 0) {
                    uVar17 = 0x1805ab2bc;
                }
                uVar16 = 0x1805aadb1;
                iVar14 = 0x1805aadb1;
                if (iVar9 != 0) {
                    uVar16 = 0x1805ab2cc;
                    iVar14 = iVar9;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e46c6;
                iVar10 = fcn.1801fcb70(0x18);
                iVar9 = 0x1805aadb1;
                if (iVar10 != 0) {
                    iVar9 = iVar10;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e46d8;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e46f0;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                              *(int64_t *)((int64_t)&arg_38h + iVar8));
                uVar11 = 0x1805aadb1;
                *(undefined8 *)((int64_t)&arg_40h + iVar8) = 0x1804b7328;
                if (iVar10 != 0) {
                    uVar11 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&arg_38h + iVar8) = uVar11;
                *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar9;
                if (iVar10 != 0) {
                    uVar15 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&arg_28h + iVar8) = uVar15;
                *(undefined8 *)((int64_t)&var_20h + iVar8) = 0x18;
                *(undefined8 *)((int64_t)&var_18h + iVar8) = uVar17;
                *(int64_t *)((int64_t)&var_10h + iVar8) = iVar14;
                *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar16;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e475b;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4569;
                iVar9 = fcn.1801fca50(9);
                if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar15 = 0x1805aadb1;
                uVar17 = 0x1805aadb1;
                if (iVar9 != 0) {
                    uVar17 = 0x1805ab2bc;
                }
                uVar16 = 0x1805aadb1;
                iVar14 = 0x1805aadb1;
                if (iVar9 != 0) {
                    uVar16 = 0x1805ab2cc;
                    iVar14 = iVar9;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e45ad;
                iVar10 = fcn.1801fcb70(0x18);
                iVar9 = 0x1805aadb1;
                if (iVar10 != 0) {
                    iVar9 = iVar10;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e45bf;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e45d7;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                              *(int64_t *)((int64_t)&arg_38h + iVar8));
                uVar11 = 0x1805aadb1;
                *(undefined8 *)((int64_t)&arg_40h + iVar8) = 0x1804b7300;
                if (iVar10 != 0) {
                    uVar11 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&arg_38h + iVar8) = uVar11;
                *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar9;
                if (iVar10 != 0) {
                    uVar15 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&arg_28h + iVar8) = uVar15;
                *(undefined8 *)((int64_t)&var_20h + iVar8) = 0x18;
                *(undefined8 *)((int64_t)&var_18h + iVar8) = uVar17;
                *(int64_t *)((int64_t)&var_10h + iVar8) = iVar14;
                *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar16;
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4642;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar8));
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4773;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4784;
                iVar9 = fcn.1802542f0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8));
                *(int64_t *)(in_RCX + 0x5d8) = iVar9;
                if (iVar9 == 0) goto code_r0x0001801e47a8;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4798;
            fcn.180254600(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4424;
            iVar9 = fcn.1801fca50(9);
            if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                return;
            }
            uVar15 = 0x1805aadb1;
            uVar17 = 0x1805aadb1;
            if (iVar9 != 0) {
                uVar17 = 0x1805ab2bc;
            }
            uVar16 = 0x1805aadb1;
            iVar14 = 0x1805aadb1;
            if (iVar9 != 0) {
                uVar16 = 0x1805ab2cc;
                iVar14 = iVar9;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4468;
            iVar10 = fcn.1801fcb70(0x18);
            iVar9 = 0x1805aadb1;
            if (iVar10 != 0) {
                iVar9 = iVar10;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e447a;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4492;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            uVar11 = 0x1805aadb1;
            *(undefined8 *)((int64_t)&arg_40h + iVar8) = 0x1804b72d8;
            if (iVar10 != 0) {
                uVar11 = 0x1805ab2bc;
            }
            *(undefined8 *)((int64_t)&arg_38h + iVar8) = uVar11;
            *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar9;
            if (iVar10 != 0) {
                uVar15 = 0x1805ab2cc;
            }
            *(undefined8 *)((int64_t)&arg_28h + iVar8) = uVar15;
            *(undefined8 *)((int64_t)&var_20h + iVar8) = 0x18;
            *(undefined8 *)((int64_t)&var_18h + iVar8) = uVar17;
            *(int64_t *)((int64_t)&var_10h + iVar8) = iVar14;
            *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar16;
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e44fd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4515;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar8));
            if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e4526;
                iVar9 = fcn.1802542f0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8));
                *(int64_t *)(in_RCX + 0x5d8) = iVar9;
                if (iVar9 == 0) goto code_r0x0001801e47a8;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e453a;
            fcn.180254600(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
        }
    }
code_r0x0001801e47a8:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&uStack_20 + iVar8) = 0x1801e47ca;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8), 
                  *(int64_t *)((int64_t)&arg_40h + iVar8), *(int64_t *)(&stack0x00000048 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801e4870
// Address: 0x1801e4870
// Size: 104 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_44h because it doesn't fit into ProtoModel

void fcn.1801e4870(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined4 uVar1;
    int64_t iVar2;
    uint32_t *in_RDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    if (arg1 != 0) {
        uStack_8 = 0x1801e487f;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar1 = *(undefined4 *)(arg1 + 0x5d0);
        *(undefined4 *)((int64_t)&arg_40h + iVar2 + 4) = 0;
        if (((uint8_t)uVar1 & 7) == 1) {
            *(uint32_t *)((int64_t)&arg_40h + iVar2) = *in_RDX & 1 | 2;
            *(undefined8 *)((int64_t)&var_20h + iVar2) = *(undefined8 *)(in_RDX + 2);
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = *(undefined8 *)(in_RDX + 4);
            *(undefined8 *)((int64_t)&arg_30h + iVar2) = *(undefined8 *)(in_RDX + 6);
            *(undefined8 *)((int64_t)&arg_38h + iVar2) = *(undefined8 *)(in_RDX + 8);
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801e48d3;
            fcn.1801e2d20(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                          *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                          *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2));
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e48e0
// Address: 0x1801e48e0
// Size: 74 bytes
// ============================================================
void fcn.1801e48e0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e48ea;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined (*) [16])((int64_t)&arg_38h + iVar1) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_28h + iVar1) = ZEXT816(0);
    *(undefined4 *)((int64_t)&arg_40h + iVar1) = 2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801e4925;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar1), *(int64_t *)(&stack0x00000060 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801e4930
// Address: 0x1801e4930
// Size: 95 bytes
// ============================================================
void fcn.1801e4930(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e493a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0;
    uVar1 = *(uint32_t *)(in_RCX + 0x5d4);
    if ((uVar1 & 0x20) == 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar2) = 1;
        *(uint32_t *)(in_RCX + 0x5d4) = uVar1 | 0x20;
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0x15;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = 0x1804b7350;
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801e498a;
        fcn.1801e2d20(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                      *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2));
    }
    return;
}

// ============================================================
// Function: FUN_1801e4990
// Address: 0x1801e4990
// Size: 86 bytes
// ============================================================
void fcn.1801e4990(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_a8h, int64_t arg_b0h,
                  int64_t arg_b8h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_188h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 uVar4;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 uVar5;
    int64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801e49a3;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_60h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e49d9;
    iVar2 = fcn.1801fca50(in_RDX);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_b8h + iVar1) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_70h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_68h + iVar1) = unaff_R12;
    uVar6 = 0x1805aadb1;
    uVar5 = 0x1805aadb1;
    iVar3 = 0x1805aadb1;
    if (iVar2 != 0) {
        uVar5 = 0x1805ab2bc;
        iVar3 = iVar2;
    }
    uVar4 = 0x1805aadb1;
    *(int64_t *)((int64_t)&arg_38h + iVar1) = iVar3;
    if (iVar2 != 0) {
        uVar4 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&arg_b0h + iVar1) = uVar5;
    *(undefined8 *)((int64_t)&arg_a8h + iVar1) = uVar4;
    if (*(int64_t *)((int64_t)&arg_c8h + iVar1) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4a52;
        func_0x000180254310();
    }
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b04;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1));
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b1c;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                      *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&var_10h + iVar1) = in_R9;
        *(undefined8 *)((int64_t)&var_8h + iVar1) = uVar5;
        *(int64_t *)(&stack0x00000000 + iVar1) = iVar3;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar1) = *(undefined8 *)((int64_t)&arg_a8h + iVar1);
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b4f;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar1));
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4a63;
        iVar3 = fcn.1801fcb70(in_R8);
        iVar2 = 0x1805aadb1;
        if (iVar3 != 0) {
            iVar2 = iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4a75;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1));
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4a8d;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                      *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&arg_30h + iVar1) = in_R9;
        uVar5 = 0x1805aadb1;
        if (iVar3 != 0) {
            uVar5 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = uVar5;
        if (iVar3 != 0) {
            uVar6 = 0x1805ab2cc;
        }
        *(int64_t *)((int64_t)&var_20h + iVar1) = iVar2;
        *(undefined8 *)((int64_t)&var_18h + iVar1) = uVar6;
        *(int64_t *)((int64_t)&var_10h + iVar1) = in_R8;
        *(undefined8 *)((int64_t)&var_8h + iVar1) = *(undefined8 *)((int64_t)&arg_b0h + iVar1);
        *(undefined8 *)(&stack0x00000000 + iVar1) = *(undefined8 *)((int64_t)&arg_38h + iVar1);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar1) = *(undefined8 *)((int64_t)&arg_a8h + iVar1);
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4afd;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar1));
    }
    if (*(int64_t *)((int64_t)&arg_d0h + iVar1) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b88;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                      *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
    }
    if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b99;
        iVar2 = fcn.1802542f0(*(int64_t *)(&stack0x00000000 + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
        *(int64_t *)(in_RCX + 0x5d8) = iVar2;
        if (iVar2 == 0) goto code_r0x0001801e4bad;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4bad;
    fcn.180254600(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                  *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1));
code_r0x0001801e4bad:
    *(undefined8 *)((int64_t)&arg_40h + iVar1) = in_RDX;
    *(int64_t *)((int64_t)&arg_48h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&arg_50h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4bc4;
    uVar5 = func_0x000180498cd0(in_R9);
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_58h + iVar1) = uVar5;
    *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4be3;
    fcn.1801e2d20(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                  *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801e49e6
// Address: 0x1801e49e6
// Size: 398 bytes
// ============================================================
void fcn.1801e4990(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_a8h, int64_t arg_b0h,
                  int64_t arg_b8h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_188h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 uVar4;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 uVar5;
    int64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801e49a3;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_60h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e49d9;
    iVar2 = fcn.1801fca50(in_RDX);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_b8h + iVar1) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_70h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_68h + iVar1) = unaff_R12;
    uVar6 = 0x1805aadb1;
    uVar5 = 0x1805aadb1;
    iVar3 = 0x1805aadb1;
    if (iVar2 != 0) {
        uVar5 = 0x1805ab2bc;
        iVar3 = iVar2;
    }
    uVar4 = 0x1805aadb1;
    *(int64_t *)((int64_t)&arg_38h + iVar1) = iVar3;
    if (iVar2 != 0) {
        uVar4 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&arg_b0h + iVar1) = uVar5;
    *(undefined8 *)((int64_t)&arg_a8h + iVar1) = uVar4;
    if (*(int64_t *)((int64_t)&arg_c8h + iVar1) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4a52;
        func_0x000180254310();
    }
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b04;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1));
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b1c;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                      *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&var_10h + iVar1) = in_R9;
        *(undefined8 *)((int64_t)&var_8h + iVar1) = uVar5;
        *(int64_t *)(&stack0x00000000 + iVar1) = iVar3;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar1) = *(undefined8 *)((int64_t)&arg_a8h + iVar1);
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b4f;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar1));
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4a63;
        iVar3 = fcn.1801fcb70(in_R8);
        iVar2 = 0x1805aadb1;
        if (iVar3 != 0) {
            iVar2 = iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4a75;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1));
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4a8d;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                      *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&arg_30h + iVar1) = in_R9;
        uVar5 = 0x1805aadb1;
        if (iVar3 != 0) {
            uVar5 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = uVar5;
        if (iVar3 != 0) {
            uVar6 = 0x1805ab2cc;
        }
        *(int64_t *)((int64_t)&var_20h + iVar1) = iVar2;
        *(undefined8 *)((int64_t)&var_18h + iVar1) = uVar6;
        *(int64_t *)((int64_t)&var_10h + iVar1) = in_R8;
        *(undefined8 *)((int64_t)&var_8h + iVar1) = *(undefined8 *)((int64_t)&arg_b0h + iVar1);
        *(undefined8 *)(&stack0x00000000 + iVar1) = *(undefined8 *)((int64_t)&arg_38h + iVar1);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar1) = *(undefined8 *)((int64_t)&arg_a8h + iVar1);
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4afd;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar1));
    }
    if (*(int64_t *)((int64_t)&arg_d0h + iVar1) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b88;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                      *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
    }
    if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b99;
        iVar2 = fcn.1802542f0(*(int64_t *)(&stack0x00000000 + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
        *(int64_t *)(in_RCX + 0x5d8) = iVar2;
        if (iVar2 == 0) goto code_r0x0001801e4bad;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4bad;
    fcn.180254600(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                  *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1));
code_r0x0001801e4bad:
    *(undefined8 *)((int64_t)&arg_40h + iVar1) = in_RDX;
    *(int64_t *)((int64_t)&arg_48h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&arg_50h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4bc4;
    uVar5 = func_0x000180498cd0(in_R9);
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_58h + iVar1) = uVar5;
    *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4be3;
    fcn.1801e2d20(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                  *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801e4b74
// Address: 0x1801e4b74
// Size: 127 bytes
// ============================================================
void fcn.1801e4990(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_a8h, int64_t arg_b0h,
                  int64_t arg_b8h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_188h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 uVar4;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 uVar5;
    int64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801e49a3;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_60h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e49d9;
    iVar2 = fcn.1801fca50(in_RDX);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_b8h + iVar1) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_70h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_68h + iVar1) = unaff_R12;
    uVar6 = 0x1805aadb1;
    uVar5 = 0x1805aadb1;
    iVar3 = 0x1805aadb1;
    if (iVar2 != 0) {
        uVar5 = 0x1805ab2bc;
        iVar3 = iVar2;
    }
    uVar4 = 0x1805aadb1;
    *(int64_t *)((int64_t)&arg_38h + iVar1) = iVar3;
    if (iVar2 != 0) {
        uVar4 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&arg_b0h + iVar1) = uVar5;
    *(undefined8 *)((int64_t)&arg_a8h + iVar1) = uVar4;
    if (*(int64_t *)((int64_t)&arg_c8h + iVar1) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4a52;
        func_0x000180254310();
    }
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b04;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1));
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b1c;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                      *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&var_10h + iVar1) = in_R9;
        *(undefined8 *)((int64_t)&var_8h + iVar1) = uVar5;
        *(int64_t *)(&stack0x00000000 + iVar1) = iVar3;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar1) = *(undefined8 *)((int64_t)&arg_a8h + iVar1);
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b4f;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar1));
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4a63;
        iVar3 = fcn.1801fcb70(in_R8);
        iVar2 = 0x1805aadb1;
        if (iVar3 != 0) {
            iVar2 = iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4a75;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1));
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4a8d;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                      *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&arg_30h + iVar1) = in_R9;
        uVar5 = 0x1805aadb1;
        if (iVar3 != 0) {
            uVar5 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = uVar5;
        if (iVar3 != 0) {
            uVar6 = 0x1805ab2cc;
        }
        *(int64_t *)((int64_t)&var_20h + iVar1) = iVar2;
        *(undefined8 *)((int64_t)&var_18h + iVar1) = uVar6;
        *(int64_t *)((int64_t)&var_10h + iVar1) = in_R8;
        *(undefined8 *)((int64_t)&var_8h + iVar1) = *(undefined8 *)((int64_t)&arg_b0h + iVar1);
        *(undefined8 *)(&stack0x00000000 + iVar1) = *(undefined8 *)((int64_t)&arg_38h + iVar1);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar1) = *(undefined8 *)((int64_t)&arg_a8h + iVar1);
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4afd;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar1));
    }
    if (*(int64_t *)((int64_t)&arg_d0h + iVar1) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b88;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                      *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
    }
    if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4b99;
        iVar2 = fcn.1802542f0(*(int64_t *)(&stack0x00000000 + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
        *(int64_t *)(in_RCX + 0x5d8) = iVar2;
        if (iVar2 == 0) goto code_r0x0001801e4bad;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4bad;
    fcn.180254600(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                  *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1));
code_r0x0001801e4bad:
    *(undefined8 *)((int64_t)&arg_40h + iVar1) = in_RDX;
    *(int64_t *)((int64_t)&arg_48h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&arg_50h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4bc4;
    uVar5 = func_0x000180498cd0(in_R9);
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_58h + iVar1) = uVar5;
    *(undefined8 *)((int64_t)&uStack_30 + iVar1) = 0x1801e4be3;
    fcn.1801e2d20(*(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                  *(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801e4c00
// Address: 0x1801e4c00
// Size: 65 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001801e4c36: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001801e4c3b)

void fcn.1801e4c00(int64_t arg1, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a8h, int64_t arg_c0h, int64_t arg_d8h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    char *pcVar3;
    char *pcVar4;
    undefined *puVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint32_t uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    undefined *puVar15;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar16;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar17;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    if (arg1 == 0) {
        return;
    }
    uStack_10 = 0x1801e4c10;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar13 = *(int64_t *)arg1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801e4c1e;
    iVar6 = func_0x0001801e8e90(iVar13);
    if (iVar6 == 0) {
        arg1 = *(int64_t *)arg1;
        *(undefined8 *)((int64_t)auStackX_10 + iVar8 + 8) = *(undefined8 *)((int64_t)auStackX_10 + iVar8 + 8);
        *(undefined8 *)((int64_t)auStackX_10 + iVar8) = 0x1801e902c;
        iVar9 = fcn.18045a350();
        iVar9 = -iVar9;
        *(undefined8 *)((int64_t)auStackX_10 + iVar9 + iVar8) = 0x1801e9037;
        func_0x0001802203d0();
        iVar13 = *(int64_t *)(arg1 + 0x90);
        arg1 = *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar8);
        puVar15 = &stack0x00000040 + iVar9 + iVar8;
    } else {
        iVar13 = *(int64_t *)(arg1 + 0x5d8);
        puVar15 = (undefined *)((int64_t)&uStack_10 + iVar8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801e4c3b;
    }
    if (iVar13 != 0) {
        *(undefined8 *)(puVar15 + -8) = unaff_R14;
        *(undefined8 *)(puVar15 + -0x10) = 0x180254325;
        iVar8 = fcn.18045a350();
        iVar8 = -iVar8;
        if (*(int32_t *)(iVar13 + 0x344) != *(int32_t *)(iVar13 + 0x340)) {
            *(undefined8 *)(puVar15 + iVar8 + 0x30) = unaff_RDI;
            *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x180254347;
            iVar9 = func_0x000180221280();
            if (iVar9 != 0) {
                *(int64_t *)(puVar15 + iVar8 + 0x48) = arg1;
                uVar14 = *(uint32_t *)(iVar13 + 0x344);
                if (uVar14 != *(uint32_t *)(iVar13 + 0x340)) {
                    *(undefined8 *)(puVar15 + iVar8 + 0x18) = unaff_R15;
                    *(undefined8 *)(puVar15 + iVar8 + 0x50) = unaff_RBP;
                    *(undefined8 *)(puVar15 + iVar8 + 0x58) = unaff_RSI;
                    *(undefined8 *)(puVar15 + iVar8 + 0x28) = unaff_R12;
                    *(undefined8 *)(puVar15 + iVar8 + 0x20) = unaff_R13;
                    do {
                        uVar14 = uVar14 + 1 & 0x8000000f;
                        if ((int32_t)uVar14 < 0) {
                            uVar14 = (uVar14 - 1 | 0xfffffff0) + 1;
                        }
                        iVar17 = (int64_t)(int32_t)uVar14;
                        if ((*(uint8_t *)(iVar13 + iVar17 * 4) & 2) == 0) {
                            uVar7 = *(int32_t *)(iVar9 + 0x340) + 1U & 0x8000000f;
                            if ((int32_t)uVar7 < 0) {
                                uVar7 = (uVar7 - 1 | 0xfffffff0) + 1;
                            }
                            *(uint32_t *)(iVar9 + 0x340) = uVar7;
                            if (uVar7 == *(uint32_t *)(iVar9 + 0x344)) {
                                uVar12 = *(uint32_t *)(iVar9 + 0x344) + 1 & 0x8000000f;
                                if ((int32_t)uVar12 < 0) {
                                    uVar12 = (uVar12 - 1 | 0xfffffff0) + 1;
                                }
                                *(uint32_t *)(iVar9 + 0x344) = uVar12;
                            }
                            iVar16 = (int64_t)(int32_t)uVar7;
                            *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x1802543f2;
                            func_0x000180220e60(iVar9, iVar16, 0);
                            *(undefined4 *)(iVar9 + iVar16 * 4) = *(undefined4 *)(iVar13 + iVar17 * 4);
                            *(undefined4 *)(iVar9 + 0x80 + iVar16 * 4) = *(undefined4 *)(iVar13 + 0x80 + iVar17 * 4);
                            uVar2 = *(undefined8 *)(iVar9 + 0x200 + iVar16 * 8);
                            pcVar3 = *(char **)(iVar13 + 0x2c0 + iVar17 * 8);
                            uVar1 = *(undefined4 *)(iVar13 + 0x280 + iVar17 * 4);
                            pcVar4 = *(char **)(iVar13 + 0x200 + iVar17 * 8);
                            *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x18025443a;
                            fcn.180224990(uVar2, 0x1804bf6a0, 0x39);
                            if ((pcVar4 == (char *)0x0) || (*pcVar4 == '\0')) {
                                *(undefined8 *)(iVar9 + 0x200 + iVar16 * 8) = 0;
                            } else {
                                *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x180254456;
                                func_0x000180498cd0(pcVar4);
                                *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x180254464;
                                iVar10 = fcn.1802248d0(*(int64_t *)(puVar15 + iVar8 + 0x18), 
                                                       *(int64_t *)(puVar15 + iVar8 + 0x20));
                                *(int64_t *)(iVar9 + 0x200 + iVar16 * 8) = iVar10;
                                if (iVar10 != 0) {
                                    *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x18025447c;
                                    func_0x0001804990c0(iVar10, pcVar4);
                                }
                            }
                            *(undefined4 *)(iVar9 + 0x280 + iVar16 * 4) = uVar1;
                            uVar2 = *(undefined8 *)(iVar9 + 0x2c0 + iVar16 * 8);
                            *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x1802544a1;
                            fcn.180224990(uVar2, 0x1804bf6a0);
                            if ((pcVar3 == (char *)0x0) || (*pcVar3 == '\0')) {
                                *(undefined8 *)(iVar9 + 0x2c0 + iVar16 * 8) = 0;
                            } else {
                                *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x1802544b4;
                                func_0x000180498cd0(pcVar3);
                                *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x1802544c2;
                                iVar10 = fcn.1802248d0(*(int64_t *)(puVar15 + iVar8 + 0x18), 
                                                       *(int64_t *)(puVar15 + iVar8 + 0x20));
                                *(int64_t *)(iVar9 + 0x2c0 + iVar16 * 8) = iVar10;
                                if (iVar10 != 0) {
                                    *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x1802544da;
                                    func_0x0001804990c0(iVar10, pcVar3);
                                }
                            }
                            if ((*(int64_t *)(iVar13 + 0xc0 + iVar17 * 8) == 0) ||
                               (iVar10 = *(int64_t *)(iVar13 + 0x140 + iVar17 * 8), iVar10 == 0)) {
                                iVar17 = iVar9 + iVar16 * 4;
                                iVar10 = iVar9 + iVar16 * 8;
                                if ((*(uint8_t *)(iVar17 + 0x1c0) & 1) == 0) {
                                    *(undefined8 *)(iVar10 + 0xc0) = 0;
                                    *(undefined8 *)(iVar9 + 0x140 + iVar16 * 8) = 0;
                                    *(undefined4 *)(iVar17 + 0x1c0) = 0;
                                } else {
                                    puVar5 = *(undefined **)(iVar10 + 0xc0);
                                    if (puVar5 != (undefined *)0x0) {
                                        *puVar5 = 0;
                                        *(undefined4 *)(iVar17 + 0x1c0) = 1;
                                    }
                                }
                            } else {
                                *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x18025451a;
                                iVar11 = fcn.1802248d0(*(int64_t *)(puVar15 + iVar8 + 0x18), 
                                                       *(int64_t *)(puVar15 + iVar8 + 0x20));
                                if (iVar11 != 0) {
                                    uVar2 = *(undefined8 *)(iVar13 + 0xc0 + iVar17 * 8);
                                    *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x180254539;
                                    func_0x000180498030(iVar11, uVar2);
                                    uVar7 = *(uint32_t *)(iVar13 + 0x1c0 + iVar17 * 4);
                                    if ((*(uint8_t *)(iVar9 + 0x1c0 + iVar16 * 4) & 1) != 0) {
                                        uVar2 = *(undefined8 *)(iVar9 + 0xc0 + iVar16 * 8);
                                        *(undefined8 *)(puVar15 + iVar8 + -0x10) = 0x180254569;
                                        fcn.180224990(uVar2, 0x1804bf6a0);
                                    }
                                    *(int64_t *)(iVar9 + 0xc0 + iVar16 * 8) = iVar11;
                                    *(int64_t *)(iVar9 + 0x140 + iVar16 * 8) = iVar10;
                                    *(uint32_t *)(iVar9 + 0x1c0 + iVar16 * 4) = uVar7 | 1;
                                }
                            }
                        }
                    } while (uVar14 != *(uint32_t *)(iVar13 + 0x340));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e4c80
// Address: 0x1801e4c80
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801e4c80(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e4c95;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)(in_RCX + 0x3e0) = in_RDX;
    *(undefined8 *)(in_RCX + 0x3f0) = in_R8;
    uVar1 = *(undefined8 *)(in_RCX + 0x3d0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e4cbb;
    fcn.1801fb910(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e4ccd;
    fcn.180208190(uVar1, in_RDX, in_R8);
    if ((*(uint32_t *)(in_RCX + 0x5d4) & 0x400) == 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0x3d8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e4ceb;
        fcn.180205760(uVar1, in_RDX, in_R8);
    }
    return;
}

// ============================================================
// Function: FUN_1801e4d00
// Address: 0x1801e4d00
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801e4d00(int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e4d10;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)(in_RCX + 1000) = in_RDX;
    uVar1 = *(undefined8 *)(in_RCX + 0x3d0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e4d2c;
    fcn.1801fb920(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e4d3b;
    fcn.1802081a0(uVar1, in_RDX);
    if ((*(uint32_t *)(in_RCX + 0x5d4) & 0x400) == 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0x3d8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e4d56;
        fcn.180205770(uVar1, in_RDX);
    }
    return;
}

// ============================================================
// Function: FUN_1801e4d70
// Address: 0x1801e4d70
// Size: 157 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801e4d70(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e4d80;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(uint8_t *)(in_RCX + 0x5d0) & 7) != 0) {
        return 0;
    }
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e4d9f;
        iVar1 = fcn.18026bea0(in_RDX);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e4daf;
            iVar1 = fcn.18026be40(in_RCX + 0x68, in_RDX);
            if (iVar1 == 0) {
                *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) & 0xffffff7f;
                return 0;
            }
            *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x80;
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e4df3;
    fcn.18026be30(in_RCX + 0x68);
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) & 0xffffff7f;
    return 1;
}

// ============================================================
// Function: FUN_1801e4e10
// Address: 0x1801e4e10
// Size: 194 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801e4e10(int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar3;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e4e25;
    iVar1 = fcn.18045a350();
    if (in_R8 == 0) {
        iVar2 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1801e4e41;
        iVar2 = func_0x000180498cd0(in_R8);
    }
    if (*(int64_t *)(in_RCX + 0x580) == 0) {
        *(undefined8 *)(in_RCX + 0x570) = in_RDX;
        *(undefined8 *)(in_RCX + 0x578) = 0;
        *(uint32_t *)(in_RCX + 0x590) = *(uint32_t *)(in_RCX + 0x590) & 0xfffffffd | 1;
        if ((in_R8 != 0) && (iVar2 != 0)) {
            iVar3 = iVar2 + -1;
            if (iVar2 != -1) {
                iVar3 = iVar2;
            }
            *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1801e4eab;
            iVar1 = func_0x000180223170(in_R8, iVar3 + 1, 0x1804b6360, 0xc98);
            *(int64_t *)(in_RCX + 0x580) = iVar1;
            if (iVar1 != 0) {
                *(undefined *)(iVar3 + iVar1) = 0;
                *(int64_t *)(in_RCX + 0x588) = iVar3;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e4ee0
// Address: 0x1801e4ee0
// Size: 357 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

undefined8 fcn.1801e4ee0(int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t **in_RCX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e4ef0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if ((*(uint32_t *)(in_RCX + 0xba) >> 0x19 & 1) == 0) {
        if ((*(uint32_t *)(in_RCX + 0xba) & 7) != 0) {
            return 1;
        }
        piVar2 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801e4f1e;
        iVar6 = func_0x0001802081b0(piVar2, in_RCX + 0xd);
        if (iVar6 != 0) {
            if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) {
                iVar3 = (*in_RCX)[5];
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801e4f47;
                iVar6 = func_0x0001801bf2f0(iVar3, in_RCX + 0xd, (int64_t)&arg_38h + iVar7);
                if (iVar6 != 0) {
                    iVar3 = *(int64_t *)((int64_t)&arg_38h + iVar7);
                    piVar2 = in_RCX[0x11];
                    *(int64_t *)((int64_t)&var_18h + iVar7) = iVar3;
                    uVar8 = *(undefined8 *)(iVar3 + 0x20);
                    uVar4 = *(undefined8 *)(iVar3 + 0x18);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801e4f70;
                    iVar6 = func_0x0001802080d0(piVar2, uVar4, uVar8, 0x1801e3670);
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801e4f7e;
                        func_0x0001801bf150(*(undefined8 *)((int64_t)&arg_38h + iVar7));
                    }
                }
            }
            uVar1 = *(uint32_t *)(in_RCX + 0xba);
            puVar5 = (undefined8 *)**in_RCX;
            *(int64_t **)((int64_t)&var_20h + iVar7) = in_RCX[0x7a];
            uVar8 = puVar5[1];
            uVar4 = *puVar5;
            *(int64_t **)((int64_t)&var_18h + iVar7) = in_RCX[0x7b];
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801e4fbe;
            iVar6 = func_0x0001801f9c30(uVar4, uVar8, in_RCX + 0x85, uVar1 >> 0x19 & 1);
            if (iVar6 != 0) {
                if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000100) == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801e4fd6;
                    iVar6 = func_0x0001801de9b0(in_RCX);
                    if (iVar6 == 0) {
                        return 0;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801e4fe7;
                fcn.1801e1a70(*(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                              *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) & 0xffffffbf;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801e4ff6;
                uVar8 = fcn.1801deee0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar7), *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                      *(int64_t *)(&stack0x00000048 + iVar7), *(int64_t *)(&stack0x00000058 + iVar7), 
                                      *(int64_t *)(&stack0x00000068 + iVar7));
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801e5005;
                func_0x000180204cf0(uVar8, in_RCX + 0x85);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801e5012;
                iVar6 = func_0x0001801e2eb0(in_RCX, 0, 0);
                if (iVar6 != 0) {
                    piVar2 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801e501e;
                    uVar8 = func_0x0001801e8e10(piVar2);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801e5028;
                    func_0x0001801dd2b0(uVar8, 0);
                    return 1;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e5050
// Address: 0x1801e5050
// Size: 156 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801e5050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined uVar11;
    int64_t **in_RCX;
    int64_t **in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int64_t iVar13;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801e5063;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)(in_RCX + 0xba);
    iVar14 = 0;
    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 0;
    uVar2 = uVar2 & 7;
    if ((uVar2 == 0) || (uVar2 == 4)) {
        *(undefined2 *)(in_RDX + 1) = 0;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        *(undefined *)((int64_t)in_RDX + 10) = 0;
        return;
    }
    if (uVar2 - 2 < 2) {
        piVar6 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50a6;
        piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
        if ((in_RCX[0xb3] < piVar6) || (in_RCX[0xb3] <= piVar6)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50be;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined2 *)(in_RDX + 1) = 0;
            *in_RDX = (int64_t *)0xffffffffffffffff;
            *(undefined *)((int64_t)in_RDX + 10) = 1;
            return;
        }
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    if ((*(uint8_t *)(*piVar6 + 0xa0) & 1) == 0) {
        uVar1 = *(uint8_t *)((int64_t)in_RCX + 0x5d4);
        *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
        if ((uVar1 & 2) != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5122;
            piVar6 = (int64_t *)func_0x0001801e8e50();
            if ((in_RCX[0xb7] < piVar6) || (in_RCX[0xb7] <= piVar6)) {
                piVar6 = in_RCX[0x7b];
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffd;
                in_RCX[0xb7] = (int64_t *)0xffffffffffffffff;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5150;
                iVar3 = func_0x000180205360(piVar6, 1);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R12;
                    *(undefined8 *)((int64_t)&arg_40h + iVar5) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e516c;
                    iVar7 = fcn.1801fca50(1);
                    if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                        uVar12 = 0x1805aadb1;
                        iVar13 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            iVar13 = iVar7;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5192;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51aa;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        uVar8 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            uVar8 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar8;
                        if (iVar7 != 0) {
                            uVar12 = 0x1805ab2cc;
                        }
                        *(int64_t *)(&stack0x00000000 + iVar5) = iVar13;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar12;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51fd;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5218;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        if (in_RCX[0xbb] == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5229;
                            piVar6 = (int64_t *)
                                     fcn.1802542f0(*(int64_t *)(&stack0x00000000 + iVar5), 
                                                   *(int64_t *)((int64_t)&var_20h + iVar5));
                            in_RCX[0xbb] = piVar6;
                            if (piVar6 != (int64_t *)0x0) goto code_r0x0001801e5235;
                        } else {
code_r0x0001801e5235:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e523d;
                            fcn.180254600(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5)
                                          , *(int64_t *)((int64_t)&var_10h + iVar5));
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        *(undefined8 *)((int64_t)&var_20h + iVar5) = 1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
                        *(undefined8 *)((int64_t)&arg_30h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0x1c;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5270;
                        fcn.1801e2d20(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5));
                    }
                }
            }
        }
        do {
            *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) & 0xf3ffffff;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e529d;
            func_0x0001801e1d90(in_RCX, (uint32_t)in_R8 & 1, (int64_t)&arg_98h + iVar5);
            uVar2 = *(uint32_t *)(in_RCX + 0xba);
            if (((uVar2 >> 0x1b & 1) == 0) && (*(undefined8 *)((int64_t)&arg_88h + iVar5) = 0, (in_R8 & 1) == 0)) {
                piVar6 = in_RCX[5];
                *(uint32_t *)(in_RCX + 0xba) = uVar2 | 0x8000000;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52cd;
                func_0x0001801a62c0(piVar6);
                piVar6 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52eb;
                iVar3 = func_0x0001801a60b0(piVar6, (int64_t)&var_18h + iVar5, (int64_t)&arg_a0h + iVar5, 
                                            (int64_t)&arg_88h + iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b7050;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x8b4;
                    *(undefined8 *)(&stack0x00000000 + iVar5) = 0x1804b6360;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = *(undefined8 *)((int64_t)&arg_88h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5326;
                    fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_88h + iVar5), *(int64_t *)((int64_t)&arg_98h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_a0h + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                                  *(int64_t *)(&stack0x000000b0 + iVar5), *(int64_t *)(&stack0x00000158 + iVar5));
                    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 1;
                }
            }
        } while ((*(uint32_t *)(in_RCX + 0xba) & 0x4000000) != 0);
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5351;
    piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
    if (in_RCX[0xb4] <= piVar6) {
        if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
            *(uint32_t *)(in_RCX + 0xb2) = *(uint32_t *)(in_RCX + 0xb2) & 0xfffffffe;
            in_RCX[0xae] = (int64_t *)0xffffffffffffffff;
            in_RCX[0xaf] = (int64_t *)0x0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e557e;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
        }
        *(undefined2 *)(in_RDX + 1) = 0;
        *(undefined *)((int64_t)in_RDX + 10) = 1;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        return;
    }
    if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
        piVar9 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5380;
        piVar9 = (int64_t *)func_0x000180202860(piVar9);
        if ((piVar9 != (int64_t *)0x0) && ((piVar9 < piVar6 || (piVar9 <= piVar6)))) {
            piVar9 = in_RCX[0x79];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5398;
            func_0x000180203570(piVar9);
        }
        if ((in_RCX[0xb5] < piVar6) || (in_RCX[0xb5] <= piVar6)) {
            uVar2 = *(uint32_t *)(in_RCX + 0xba) >> 0xe & 7;
            iVar3 = iVar14;
            if (uVar2 != 0) {
                if ((uVar2 == 1) || (uVar2 != 2)) {
                    iVar3 = 2;
                } else {
                    iVar3 = 1;
                }
            }
            piVar6 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53d8;
            func_0x000180207ed0(piVar6, iVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53e0;
            func_0x0001801e34d0(in_RCX);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53f0;
        func_0x0001801e3140(in_RCX, (int64_t)&arg_98h + iVar5);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53fc;
        func_0x0001801e77e0();
    }
    piVar6 = (int64_t *)0xffffffffffffffff;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        piVar6 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5418;
        piVar6 = (int64_t *)func_0x000180202860(piVar6);
        iVar3 = iVar14;
        if (piVar6 == (int64_t *)0x0) {
            piVar6 = (int64_t *)0xffffffffffffffff;
        }
        do {
            piVar9 = in_RCX[0x7a];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e543e;
            iVar4 = func_0x0001801fb7e0(piVar9, iVar3);
            piVar9 = piVar6;
            if (iVar4 != 0) {
                iVar4 = iVar14;
                if (iVar3 != 0) {
                    if ((iVar3 == 1) || (iVar3 != 2)) {
                        iVar4 = 2;
                    } else {
                        iVar4 = 1;
                    }
                }
                piVar9 = in_RCX[0x79];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e546f;
                piVar9 = (int64_t *)func_0x0001802026d0(piVar9, iVar4);
                if (piVar6 < piVar9) {
                    piVar9 = piVar6;
                }
            }
            iVar3 = iVar3 + 1;
            piVar6 = piVar9;
        } while (iVar3 < 4);
        piVar6 = in_RCX[0xb5];
        piVar10 = piVar9;
        if ((piVar6 != (int64_t *)0xffffffffffffffff) && (piVar10 = piVar6, piVar9 < piVar6)) {
            piVar10 = piVar9;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e54a3;
        piVar9 = (int64_t *)func_0x000180207b50();
        if (piVar10 < piVar9) {
            piVar9 = piVar10;
        }
        if (((*(uint32_t *)(in_RCX + 0xba) & 7) == 2) || ((*(uint32_t *)(in_RCX + 0xba) & 7) == 3)) {
            piVar10 = in_RCX[0xb3];
code_r0x0001801e54d6:
            piVar6 = piVar10;
            if (piVar9 < piVar10) {
                piVar6 = piVar9;
            }
        } else {
            piVar10 = in_RCX[0xb4];
            piVar6 = piVar9;
            if (piVar10 != (int64_t *)0xffffffffffffffff) goto code_r0x0001801e54d6;
        }
        if (((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) && (in_RCX[0xb7] <= piVar6)) {
            piVar6 = in_RCX[0xb7];
        }
    }
    *in_RDX = piVar6;
    *(bool *)(in_RDX + 1) = ((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5523;
        iVar7 = func_0x0001801fb7d0();
        if (iVar7 != 0) {
            uVar11 = 1;
            goto code_r0x0001801e552e;
        }
    }
    uVar11 = 0;
code_r0x0001801e552e:
    *(undefined *)((int64_t)in_RDX + 10) = *(undefined *)((int64_t)&arg_98h + iVar5);
    *(undefined *)((int64_t)in_RDX + 9) = uVar11;
    return;
}

// ============================================================
// Function: FUN_1801e50ec
// Address: 0x1801e50ec
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801e5050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined uVar11;
    int64_t **in_RCX;
    int64_t **in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int64_t iVar13;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801e5063;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)(in_RCX + 0xba);
    iVar14 = 0;
    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 0;
    uVar2 = uVar2 & 7;
    if ((uVar2 == 0) || (uVar2 == 4)) {
        *(undefined2 *)(in_RDX + 1) = 0;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        *(undefined *)((int64_t)in_RDX + 10) = 0;
        return;
    }
    if (uVar2 - 2 < 2) {
        piVar6 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50a6;
        piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
        if ((in_RCX[0xb3] < piVar6) || (in_RCX[0xb3] <= piVar6)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50be;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined2 *)(in_RDX + 1) = 0;
            *in_RDX = (int64_t *)0xffffffffffffffff;
            *(undefined *)((int64_t)in_RDX + 10) = 1;
            return;
        }
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    if ((*(uint8_t *)(*piVar6 + 0xa0) & 1) == 0) {
        uVar1 = *(uint8_t *)((int64_t)in_RCX + 0x5d4);
        *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
        if ((uVar1 & 2) != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5122;
            piVar6 = (int64_t *)func_0x0001801e8e50();
            if ((in_RCX[0xb7] < piVar6) || (in_RCX[0xb7] <= piVar6)) {
                piVar6 = in_RCX[0x7b];
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffd;
                in_RCX[0xb7] = (int64_t *)0xffffffffffffffff;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5150;
                iVar3 = func_0x000180205360(piVar6, 1);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R12;
                    *(undefined8 *)((int64_t)&arg_40h + iVar5) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e516c;
                    iVar7 = fcn.1801fca50(1);
                    if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                        uVar12 = 0x1805aadb1;
                        iVar13 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            iVar13 = iVar7;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5192;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51aa;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        uVar8 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            uVar8 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar8;
                        if (iVar7 != 0) {
                            uVar12 = 0x1805ab2cc;
                        }
                        *(int64_t *)(&stack0x00000000 + iVar5) = iVar13;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar12;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51fd;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5218;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        if (in_RCX[0xbb] == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5229;
                            piVar6 = (int64_t *)
                                     fcn.1802542f0(*(int64_t *)(&stack0x00000000 + iVar5), 
                                                   *(int64_t *)((int64_t)&var_20h + iVar5));
                            in_RCX[0xbb] = piVar6;
                            if (piVar6 != (int64_t *)0x0) goto code_r0x0001801e5235;
                        } else {
code_r0x0001801e5235:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e523d;
                            fcn.180254600(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5)
                                          , *(int64_t *)((int64_t)&var_10h + iVar5));
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        *(undefined8 *)((int64_t)&var_20h + iVar5) = 1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
                        *(undefined8 *)((int64_t)&arg_30h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0x1c;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5270;
                        fcn.1801e2d20(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5));
                    }
                }
            }
        }
        do {
            *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) & 0xf3ffffff;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e529d;
            func_0x0001801e1d90(in_RCX, (uint32_t)in_R8 & 1, (int64_t)&arg_98h + iVar5);
            uVar2 = *(uint32_t *)(in_RCX + 0xba);
            if (((uVar2 >> 0x1b & 1) == 0) && (*(undefined8 *)((int64_t)&arg_88h + iVar5) = 0, (in_R8 & 1) == 0)) {
                piVar6 = in_RCX[5];
                *(uint32_t *)(in_RCX + 0xba) = uVar2 | 0x8000000;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52cd;
                func_0x0001801a62c0(piVar6);
                piVar6 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52eb;
                iVar3 = func_0x0001801a60b0(piVar6, (int64_t)&var_18h + iVar5, (int64_t)&arg_a0h + iVar5, 
                                            (int64_t)&arg_88h + iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b7050;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x8b4;
                    *(undefined8 *)(&stack0x00000000 + iVar5) = 0x1804b6360;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = *(undefined8 *)((int64_t)&arg_88h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5326;
                    fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_88h + iVar5), *(int64_t *)((int64_t)&arg_98h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_a0h + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                                  *(int64_t *)(&stack0x000000b0 + iVar5), *(int64_t *)(&stack0x00000158 + iVar5));
                    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 1;
                }
            }
        } while ((*(uint32_t *)(in_RCX + 0xba) & 0x4000000) != 0);
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5351;
    piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
    if (in_RCX[0xb4] <= piVar6) {
        if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
            *(uint32_t *)(in_RCX + 0xb2) = *(uint32_t *)(in_RCX + 0xb2) & 0xfffffffe;
            in_RCX[0xae] = (int64_t *)0xffffffffffffffff;
            in_RCX[0xaf] = (int64_t *)0x0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e557e;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
        }
        *(undefined2 *)(in_RDX + 1) = 0;
        *(undefined *)((int64_t)in_RDX + 10) = 1;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        return;
    }
    if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
        piVar9 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5380;
        piVar9 = (int64_t *)func_0x000180202860(piVar9);
        if ((piVar9 != (int64_t *)0x0) && ((piVar9 < piVar6 || (piVar9 <= piVar6)))) {
            piVar9 = in_RCX[0x79];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5398;
            func_0x000180203570(piVar9);
        }
        if ((in_RCX[0xb5] < piVar6) || (in_RCX[0xb5] <= piVar6)) {
            uVar2 = *(uint32_t *)(in_RCX + 0xba) >> 0xe & 7;
            iVar3 = iVar14;
            if (uVar2 != 0) {
                if ((uVar2 == 1) || (uVar2 != 2)) {
                    iVar3 = 2;
                } else {
                    iVar3 = 1;
                }
            }
            piVar6 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53d8;
            func_0x000180207ed0(piVar6, iVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53e0;
            func_0x0001801e34d0(in_RCX);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53f0;
        func_0x0001801e3140(in_RCX, (int64_t)&arg_98h + iVar5);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53fc;
        func_0x0001801e77e0();
    }
    piVar6 = (int64_t *)0xffffffffffffffff;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        piVar6 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5418;
        piVar6 = (int64_t *)func_0x000180202860(piVar6);
        iVar3 = iVar14;
        if (piVar6 == (int64_t *)0x0) {
            piVar6 = (int64_t *)0xffffffffffffffff;
        }
        do {
            piVar9 = in_RCX[0x7a];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e543e;
            iVar4 = func_0x0001801fb7e0(piVar9, iVar3);
            piVar9 = piVar6;
            if (iVar4 != 0) {
                iVar4 = iVar14;
                if (iVar3 != 0) {
                    if ((iVar3 == 1) || (iVar3 != 2)) {
                        iVar4 = 2;
                    } else {
                        iVar4 = 1;
                    }
                }
                piVar9 = in_RCX[0x79];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e546f;
                piVar9 = (int64_t *)func_0x0001802026d0(piVar9, iVar4);
                if (piVar6 < piVar9) {
                    piVar9 = piVar6;
                }
            }
            iVar3 = iVar3 + 1;
            piVar6 = piVar9;
        } while (iVar3 < 4);
        piVar6 = in_RCX[0xb5];
        piVar10 = piVar9;
        if ((piVar6 != (int64_t *)0xffffffffffffffff) && (piVar10 = piVar6, piVar9 < piVar6)) {
            piVar10 = piVar9;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e54a3;
        piVar9 = (int64_t *)func_0x000180207b50();
        if (piVar10 < piVar9) {
            piVar9 = piVar10;
        }
        if (((*(uint32_t *)(in_RCX + 0xba) & 7) == 2) || ((*(uint32_t *)(in_RCX + 0xba) & 7) == 3)) {
            piVar10 = in_RCX[0xb3];
code_r0x0001801e54d6:
            piVar6 = piVar10;
            if (piVar9 < piVar10) {
                piVar6 = piVar9;
            }
        } else {
            piVar10 = in_RCX[0xb4];
            piVar6 = piVar9;
            if (piVar10 != (int64_t *)0xffffffffffffffff) goto code_r0x0001801e54d6;
        }
        if (((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) && (in_RCX[0xb7] <= piVar6)) {
            piVar6 = in_RCX[0xb7];
        }
    }
    *in_RDX = piVar6;
    *(bool *)(in_RDX + 1) = ((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5523;
        iVar7 = func_0x0001801fb7d0();
        if (iVar7 != 0) {
            uVar11 = 1;
            goto code_r0x0001801e552e;
        }
    }
    uVar11 = 0;
code_r0x0001801e552e:
    *(undefined *)((int64_t)in_RDX + 10) = *(undefined *)((int64_t)&arg_98h + iVar5);
    *(undefined *)((int64_t)in_RDX + 9) = uVar11;
    return;
}

// ============================================================
// Function: FUN_1801e5108
// Address: 0x1801e5108
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801e5050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined uVar11;
    int64_t **in_RCX;
    int64_t **in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int64_t iVar13;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801e5063;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)(in_RCX + 0xba);
    iVar14 = 0;
    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 0;
    uVar2 = uVar2 & 7;
    if ((uVar2 == 0) || (uVar2 == 4)) {
        *(undefined2 *)(in_RDX + 1) = 0;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        *(undefined *)((int64_t)in_RDX + 10) = 0;
        return;
    }
    if (uVar2 - 2 < 2) {
        piVar6 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50a6;
        piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
        if ((in_RCX[0xb3] < piVar6) || (in_RCX[0xb3] <= piVar6)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50be;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined2 *)(in_RDX + 1) = 0;
            *in_RDX = (int64_t *)0xffffffffffffffff;
            *(undefined *)((int64_t)in_RDX + 10) = 1;
            return;
        }
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    if ((*(uint8_t *)(*piVar6 + 0xa0) & 1) == 0) {
        uVar1 = *(uint8_t *)((int64_t)in_RCX + 0x5d4);
        *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
        if ((uVar1 & 2) != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5122;
            piVar6 = (int64_t *)func_0x0001801e8e50();
            if ((in_RCX[0xb7] < piVar6) || (in_RCX[0xb7] <= piVar6)) {
                piVar6 = in_RCX[0x7b];
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffd;
                in_RCX[0xb7] = (int64_t *)0xffffffffffffffff;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5150;
                iVar3 = func_0x000180205360(piVar6, 1);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R12;
                    *(undefined8 *)((int64_t)&arg_40h + iVar5) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e516c;
                    iVar7 = fcn.1801fca50(1);
                    if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                        uVar12 = 0x1805aadb1;
                        iVar13 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            iVar13 = iVar7;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5192;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51aa;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        uVar8 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            uVar8 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar8;
                        if (iVar7 != 0) {
                            uVar12 = 0x1805ab2cc;
                        }
                        *(int64_t *)(&stack0x00000000 + iVar5) = iVar13;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar12;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51fd;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5218;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        if (in_RCX[0xbb] == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5229;
                            piVar6 = (int64_t *)
                                     fcn.1802542f0(*(int64_t *)(&stack0x00000000 + iVar5), 
                                                   *(int64_t *)((int64_t)&var_20h + iVar5));
                            in_RCX[0xbb] = piVar6;
                            if (piVar6 != (int64_t *)0x0) goto code_r0x0001801e5235;
                        } else {
code_r0x0001801e5235:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e523d;
                            fcn.180254600(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5)
                                          , *(int64_t *)((int64_t)&var_10h + iVar5));
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        *(undefined8 *)((int64_t)&var_20h + iVar5) = 1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
                        *(undefined8 *)((int64_t)&arg_30h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0x1c;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5270;
                        fcn.1801e2d20(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5));
                    }
                }
            }
        }
        do {
            *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) & 0xf3ffffff;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e529d;
            func_0x0001801e1d90(in_RCX, (uint32_t)in_R8 & 1, (int64_t)&arg_98h + iVar5);
            uVar2 = *(uint32_t *)(in_RCX + 0xba);
            if (((uVar2 >> 0x1b & 1) == 0) && (*(undefined8 *)((int64_t)&arg_88h + iVar5) = 0, (in_R8 & 1) == 0)) {
                piVar6 = in_RCX[5];
                *(uint32_t *)(in_RCX + 0xba) = uVar2 | 0x8000000;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52cd;
                func_0x0001801a62c0(piVar6);
                piVar6 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52eb;
                iVar3 = func_0x0001801a60b0(piVar6, (int64_t)&var_18h + iVar5, (int64_t)&arg_a0h + iVar5, 
                                            (int64_t)&arg_88h + iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b7050;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x8b4;
                    *(undefined8 *)(&stack0x00000000 + iVar5) = 0x1804b6360;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = *(undefined8 *)((int64_t)&arg_88h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5326;
                    fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_88h + iVar5), *(int64_t *)((int64_t)&arg_98h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_a0h + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                                  *(int64_t *)(&stack0x000000b0 + iVar5), *(int64_t *)(&stack0x00000158 + iVar5));
                    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 1;
                }
            }
        } while ((*(uint32_t *)(in_RCX + 0xba) & 0x4000000) != 0);
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5351;
    piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
    if (in_RCX[0xb4] <= piVar6) {
        if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
            *(uint32_t *)(in_RCX + 0xb2) = *(uint32_t *)(in_RCX + 0xb2) & 0xfffffffe;
            in_RCX[0xae] = (int64_t *)0xffffffffffffffff;
            in_RCX[0xaf] = (int64_t *)0x0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e557e;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
        }
        *(undefined2 *)(in_RDX + 1) = 0;
        *(undefined *)((int64_t)in_RDX + 10) = 1;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        return;
    }
    if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
        piVar9 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5380;
        piVar9 = (int64_t *)func_0x000180202860(piVar9);
        if ((piVar9 != (int64_t *)0x0) && ((piVar9 < piVar6 || (piVar9 <= piVar6)))) {
            piVar9 = in_RCX[0x79];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5398;
            func_0x000180203570(piVar9);
        }
        if ((in_RCX[0xb5] < piVar6) || (in_RCX[0xb5] <= piVar6)) {
            uVar2 = *(uint32_t *)(in_RCX + 0xba) >> 0xe & 7;
            iVar3 = iVar14;
            if (uVar2 != 0) {
                if ((uVar2 == 1) || (uVar2 != 2)) {
                    iVar3 = 2;
                } else {
                    iVar3 = 1;
                }
            }
            piVar6 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53d8;
            func_0x000180207ed0(piVar6, iVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53e0;
            func_0x0001801e34d0(in_RCX);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53f0;
        func_0x0001801e3140(in_RCX, (int64_t)&arg_98h + iVar5);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53fc;
        func_0x0001801e77e0();
    }
    piVar6 = (int64_t *)0xffffffffffffffff;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        piVar6 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5418;
        piVar6 = (int64_t *)func_0x000180202860(piVar6);
        iVar3 = iVar14;
        if (piVar6 == (int64_t *)0x0) {
            piVar6 = (int64_t *)0xffffffffffffffff;
        }
        do {
            piVar9 = in_RCX[0x7a];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e543e;
            iVar4 = func_0x0001801fb7e0(piVar9, iVar3);
            piVar9 = piVar6;
            if (iVar4 != 0) {
                iVar4 = iVar14;
                if (iVar3 != 0) {
                    if ((iVar3 == 1) || (iVar3 != 2)) {
                        iVar4 = 2;
                    } else {
                        iVar4 = 1;
                    }
                }
                piVar9 = in_RCX[0x79];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e546f;
                piVar9 = (int64_t *)func_0x0001802026d0(piVar9, iVar4);
                if (piVar6 < piVar9) {
                    piVar9 = piVar6;
                }
            }
            iVar3 = iVar3 + 1;
            piVar6 = piVar9;
        } while (iVar3 < 4);
        piVar6 = in_RCX[0xb5];
        piVar10 = piVar9;
        if ((piVar6 != (int64_t *)0xffffffffffffffff) && (piVar10 = piVar6, piVar9 < piVar6)) {
            piVar10 = piVar9;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e54a3;
        piVar9 = (int64_t *)func_0x000180207b50();
        if (piVar10 < piVar9) {
            piVar9 = piVar10;
        }
        if (((*(uint32_t *)(in_RCX + 0xba) & 7) == 2) || ((*(uint32_t *)(in_RCX + 0xba) & 7) == 3)) {
            piVar10 = in_RCX[0xb3];
code_r0x0001801e54d6:
            piVar6 = piVar10;
            if (piVar9 < piVar10) {
                piVar6 = piVar9;
            }
        } else {
            piVar10 = in_RCX[0xb4];
            piVar6 = piVar9;
            if (piVar10 != (int64_t *)0xffffffffffffffff) goto code_r0x0001801e54d6;
        }
        if (((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) && (in_RCX[0xb7] <= piVar6)) {
            piVar6 = in_RCX[0xb7];
        }
    }
    *in_RDX = piVar6;
    *(bool *)(in_RDX + 1) = ((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5523;
        iVar7 = func_0x0001801fb7d0();
        if (iVar7 != 0) {
            uVar11 = 1;
            goto code_r0x0001801e552e;
        }
    }
    uVar11 = 0;
code_r0x0001801e552e:
    *(undefined *)((int64_t)in_RDX + 10) = *(undefined *)((int64_t)&arg_98h + iVar5);
    *(undefined *)((int64_t)in_RDX + 9) = uVar11;
    return;
}

// ============================================================
// Function: FUN_1801e515d
// Address: 0x1801e515d
// Size: 280 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801e5050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined uVar11;
    int64_t **in_RCX;
    int64_t **in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int64_t iVar13;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801e5063;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)(in_RCX + 0xba);
    iVar14 = 0;
    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 0;
    uVar2 = uVar2 & 7;
    if ((uVar2 == 0) || (uVar2 == 4)) {
        *(undefined2 *)(in_RDX + 1) = 0;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        *(undefined *)((int64_t)in_RDX + 10) = 0;
        return;
    }
    if (uVar2 - 2 < 2) {
        piVar6 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50a6;
        piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
        if ((in_RCX[0xb3] < piVar6) || (in_RCX[0xb3] <= piVar6)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50be;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined2 *)(in_RDX + 1) = 0;
            *in_RDX = (int64_t *)0xffffffffffffffff;
            *(undefined *)((int64_t)in_RDX + 10) = 1;
            return;
        }
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    if ((*(uint8_t *)(*piVar6 + 0xa0) & 1) == 0) {
        uVar1 = *(uint8_t *)((int64_t)in_RCX + 0x5d4);
        *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
        if ((uVar1 & 2) != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5122;
            piVar6 = (int64_t *)func_0x0001801e8e50();
            if ((in_RCX[0xb7] < piVar6) || (in_RCX[0xb7] <= piVar6)) {
                piVar6 = in_RCX[0x7b];
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffd;
                in_RCX[0xb7] = (int64_t *)0xffffffffffffffff;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5150;
                iVar3 = func_0x000180205360(piVar6, 1);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R12;
                    *(undefined8 *)((int64_t)&arg_40h + iVar5) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e516c;
                    iVar7 = fcn.1801fca50(1);
                    if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                        uVar12 = 0x1805aadb1;
                        iVar13 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            iVar13 = iVar7;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5192;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51aa;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        uVar8 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            uVar8 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar8;
                        if (iVar7 != 0) {
                            uVar12 = 0x1805ab2cc;
                        }
                        *(int64_t *)(&stack0x00000000 + iVar5) = iVar13;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar12;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51fd;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5218;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        if (in_RCX[0xbb] == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5229;
                            piVar6 = (int64_t *)
                                     fcn.1802542f0(*(int64_t *)(&stack0x00000000 + iVar5), 
                                                   *(int64_t *)((int64_t)&var_20h + iVar5));
                            in_RCX[0xbb] = piVar6;
                            if (piVar6 != (int64_t *)0x0) goto code_r0x0001801e5235;
                        } else {
code_r0x0001801e5235:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e523d;
                            fcn.180254600(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5)
                                          , *(int64_t *)((int64_t)&var_10h + iVar5));
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        *(undefined8 *)((int64_t)&var_20h + iVar5) = 1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
                        *(undefined8 *)((int64_t)&arg_30h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0x1c;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5270;
                        fcn.1801e2d20(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5));
                    }
                }
            }
        }
        do {
            *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) & 0xf3ffffff;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e529d;
            func_0x0001801e1d90(in_RCX, (uint32_t)in_R8 & 1, (int64_t)&arg_98h + iVar5);
            uVar2 = *(uint32_t *)(in_RCX + 0xba);
            if (((uVar2 >> 0x1b & 1) == 0) && (*(undefined8 *)((int64_t)&arg_88h + iVar5) = 0, (in_R8 & 1) == 0)) {
                piVar6 = in_RCX[5];
                *(uint32_t *)(in_RCX + 0xba) = uVar2 | 0x8000000;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52cd;
                func_0x0001801a62c0(piVar6);
                piVar6 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52eb;
                iVar3 = func_0x0001801a60b0(piVar6, (int64_t)&var_18h + iVar5, (int64_t)&arg_a0h + iVar5, 
                                            (int64_t)&arg_88h + iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b7050;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x8b4;
                    *(undefined8 *)(&stack0x00000000 + iVar5) = 0x1804b6360;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = *(undefined8 *)((int64_t)&arg_88h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5326;
                    fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_88h + iVar5), *(int64_t *)((int64_t)&arg_98h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_a0h + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                                  *(int64_t *)(&stack0x000000b0 + iVar5), *(int64_t *)(&stack0x00000158 + iVar5));
                    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 1;
                }
            }
        } while ((*(uint32_t *)(in_RCX + 0xba) & 0x4000000) != 0);
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5351;
    piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
    if (in_RCX[0xb4] <= piVar6) {
        if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
            *(uint32_t *)(in_RCX + 0xb2) = *(uint32_t *)(in_RCX + 0xb2) & 0xfffffffe;
            in_RCX[0xae] = (int64_t *)0xffffffffffffffff;
            in_RCX[0xaf] = (int64_t *)0x0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e557e;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
        }
        *(undefined2 *)(in_RDX + 1) = 0;
        *(undefined *)((int64_t)in_RDX + 10) = 1;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        return;
    }
    if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
        piVar9 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5380;
        piVar9 = (int64_t *)func_0x000180202860(piVar9);
        if ((piVar9 != (int64_t *)0x0) && ((piVar9 < piVar6 || (piVar9 <= piVar6)))) {
            piVar9 = in_RCX[0x79];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5398;
            func_0x000180203570(piVar9);
        }
        if ((in_RCX[0xb5] < piVar6) || (in_RCX[0xb5] <= piVar6)) {
            uVar2 = *(uint32_t *)(in_RCX + 0xba) >> 0xe & 7;
            iVar3 = iVar14;
            if (uVar2 != 0) {
                if ((uVar2 == 1) || (uVar2 != 2)) {
                    iVar3 = 2;
                } else {
                    iVar3 = 1;
                }
            }
            piVar6 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53d8;
            func_0x000180207ed0(piVar6, iVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53e0;
            func_0x0001801e34d0(in_RCX);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53f0;
        func_0x0001801e3140(in_RCX, (int64_t)&arg_98h + iVar5);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53fc;
        func_0x0001801e77e0();
    }
    piVar6 = (int64_t *)0xffffffffffffffff;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        piVar6 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5418;
        piVar6 = (int64_t *)func_0x000180202860(piVar6);
        iVar3 = iVar14;
        if (piVar6 == (int64_t *)0x0) {
            piVar6 = (int64_t *)0xffffffffffffffff;
        }
        do {
            piVar9 = in_RCX[0x7a];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e543e;
            iVar4 = func_0x0001801fb7e0(piVar9, iVar3);
            piVar9 = piVar6;
            if (iVar4 != 0) {
                iVar4 = iVar14;
                if (iVar3 != 0) {
                    if ((iVar3 == 1) || (iVar3 != 2)) {
                        iVar4 = 2;
                    } else {
                        iVar4 = 1;
                    }
                }
                piVar9 = in_RCX[0x79];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e546f;
                piVar9 = (int64_t *)func_0x0001802026d0(piVar9, iVar4);
                if (piVar6 < piVar9) {
                    piVar9 = piVar6;
                }
            }
            iVar3 = iVar3 + 1;
            piVar6 = piVar9;
        } while (iVar3 < 4);
        piVar6 = in_RCX[0xb5];
        piVar10 = piVar9;
        if ((piVar6 != (int64_t *)0xffffffffffffffff) && (piVar10 = piVar6, piVar9 < piVar6)) {
            piVar10 = piVar9;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e54a3;
        piVar9 = (int64_t *)func_0x000180207b50();
        if (piVar10 < piVar9) {
            piVar9 = piVar10;
        }
        if (((*(uint32_t *)(in_RCX + 0xba) & 7) == 2) || ((*(uint32_t *)(in_RCX + 0xba) & 7) == 3)) {
            piVar10 = in_RCX[0xb3];
code_r0x0001801e54d6:
            piVar6 = piVar10;
            if (piVar9 < piVar10) {
                piVar6 = piVar9;
            }
        } else {
            piVar10 = in_RCX[0xb4];
            piVar6 = piVar9;
            if (piVar10 != (int64_t *)0xffffffffffffffff) goto code_r0x0001801e54d6;
        }
        if (((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) && (in_RCX[0xb7] <= piVar6)) {
            piVar6 = in_RCX[0xb7];
        }
    }
    *in_RDX = piVar6;
    *(bool *)(in_RDX + 1) = ((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5523;
        iVar7 = func_0x0001801fb7d0();
        if (iVar7 != 0) {
            uVar11 = 1;
            goto code_r0x0001801e552e;
        }
    }
    uVar11 = 0;
code_r0x0001801e552e:
    *(undefined *)((int64_t)in_RDX + 10) = *(undefined *)((int64_t)&arg_98h + iVar5);
    *(undefined *)((int64_t)in_RDX + 9) = uVar11;
    return;
}

// ============================================================
// Function: FUN_1801e5275
// Address: 0x1801e5275
// Size: 212 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801e5050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined uVar11;
    int64_t **in_RCX;
    int64_t **in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int64_t iVar13;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801e5063;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)(in_RCX + 0xba);
    iVar14 = 0;
    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 0;
    uVar2 = uVar2 & 7;
    if ((uVar2 == 0) || (uVar2 == 4)) {
        *(undefined2 *)(in_RDX + 1) = 0;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        *(undefined *)((int64_t)in_RDX + 10) = 0;
        return;
    }
    if (uVar2 - 2 < 2) {
        piVar6 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50a6;
        piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
        if ((in_RCX[0xb3] < piVar6) || (in_RCX[0xb3] <= piVar6)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50be;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined2 *)(in_RDX + 1) = 0;
            *in_RDX = (int64_t *)0xffffffffffffffff;
            *(undefined *)((int64_t)in_RDX + 10) = 1;
            return;
        }
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    if ((*(uint8_t *)(*piVar6 + 0xa0) & 1) == 0) {
        uVar1 = *(uint8_t *)((int64_t)in_RCX + 0x5d4);
        *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
        if ((uVar1 & 2) != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5122;
            piVar6 = (int64_t *)func_0x0001801e8e50();
            if ((in_RCX[0xb7] < piVar6) || (in_RCX[0xb7] <= piVar6)) {
                piVar6 = in_RCX[0x7b];
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffd;
                in_RCX[0xb7] = (int64_t *)0xffffffffffffffff;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5150;
                iVar3 = func_0x000180205360(piVar6, 1);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R12;
                    *(undefined8 *)((int64_t)&arg_40h + iVar5) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e516c;
                    iVar7 = fcn.1801fca50(1);
                    if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                        uVar12 = 0x1805aadb1;
                        iVar13 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            iVar13 = iVar7;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5192;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51aa;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        uVar8 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            uVar8 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar8;
                        if (iVar7 != 0) {
                            uVar12 = 0x1805ab2cc;
                        }
                        *(int64_t *)(&stack0x00000000 + iVar5) = iVar13;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar12;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51fd;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5218;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        if (in_RCX[0xbb] == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5229;
                            piVar6 = (int64_t *)
                                     fcn.1802542f0(*(int64_t *)(&stack0x00000000 + iVar5), 
                                                   *(int64_t *)((int64_t)&var_20h + iVar5));
                            in_RCX[0xbb] = piVar6;
                            if (piVar6 != (int64_t *)0x0) goto code_r0x0001801e5235;
                        } else {
code_r0x0001801e5235:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e523d;
                            fcn.180254600(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5)
                                          , *(int64_t *)((int64_t)&var_10h + iVar5));
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        *(undefined8 *)((int64_t)&var_20h + iVar5) = 1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
                        *(undefined8 *)((int64_t)&arg_30h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0x1c;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5270;
                        fcn.1801e2d20(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5));
                    }
                }
            }
        }
        do {
            *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) & 0xf3ffffff;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e529d;
            func_0x0001801e1d90(in_RCX, (uint32_t)in_R8 & 1, (int64_t)&arg_98h + iVar5);
            uVar2 = *(uint32_t *)(in_RCX + 0xba);
            if (((uVar2 >> 0x1b & 1) == 0) && (*(undefined8 *)((int64_t)&arg_88h + iVar5) = 0, (in_R8 & 1) == 0)) {
                piVar6 = in_RCX[5];
                *(uint32_t *)(in_RCX + 0xba) = uVar2 | 0x8000000;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52cd;
                func_0x0001801a62c0(piVar6);
                piVar6 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52eb;
                iVar3 = func_0x0001801a60b0(piVar6, (int64_t)&var_18h + iVar5, (int64_t)&arg_a0h + iVar5, 
                                            (int64_t)&arg_88h + iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b7050;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x8b4;
                    *(undefined8 *)(&stack0x00000000 + iVar5) = 0x1804b6360;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = *(undefined8 *)((int64_t)&arg_88h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5326;
                    fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_88h + iVar5), *(int64_t *)((int64_t)&arg_98h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_a0h + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                                  *(int64_t *)(&stack0x000000b0 + iVar5), *(int64_t *)(&stack0x00000158 + iVar5));
                    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 1;
                }
            }
        } while ((*(uint32_t *)(in_RCX + 0xba) & 0x4000000) != 0);
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5351;
    piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
    if (in_RCX[0xb4] <= piVar6) {
        if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
            *(uint32_t *)(in_RCX + 0xb2) = *(uint32_t *)(in_RCX + 0xb2) & 0xfffffffe;
            in_RCX[0xae] = (int64_t *)0xffffffffffffffff;
            in_RCX[0xaf] = (int64_t *)0x0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e557e;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
        }
        *(undefined2 *)(in_RDX + 1) = 0;
        *(undefined *)((int64_t)in_RDX + 10) = 1;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        return;
    }
    if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
        piVar9 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5380;
        piVar9 = (int64_t *)func_0x000180202860(piVar9);
        if ((piVar9 != (int64_t *)0x0) && ((piVar9 < piVar6 || (piVar9 <= piVar6)))) {
            piVar9 = in_RCX[0x79];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5398;
            func_0x000180203570(piVar9);
        }
        if ((in_RCX[0xb5] < piVar6) || (in_RCX[0xb5] <= piVar6)) {
            uVar2 = *(uint32_t *)(in_RCX + 0xba) >> 0xe & 7;
            iVar3 = iVar14;
            if (uVar2 != 0) {
                if ((uVar2 == 1) || (uVar2 != 2)) {
                    iVar3 = 2;
                } else {
                    iVar3 = 1;
                }
            }
            piVar6 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53d8;
            func_0x000180207ed0(piVar6, iVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53e0;
            func_0x0001801e34d0(in_RCX);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53f0;
        func_0x0001801e3140(in_RCX, (int64_t)&arg_98h + iVar5);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53fc;
        func_0x0001801e77e0();
    }
    piVar6 = (int64_t *)0xffffffffffffffff;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        piVar6 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5418;
        piVar6 = (int64_t *)func_0x000180202860(piVar6);
        iVar3 = iVar14;
        if (piVar6 == (int64_t *)0x0) {
            piVar6 = (int64_t *)0xffffffffffffffff;
        }
        do {
            piVar9 = in_RCX[0x7a];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e543e;
            iVar4 = func_0x0001801fb7e0(piVar9, iVar3);
            piVar9 = piVar6;
            if (iVar4 != 0) {
                iVar4 = iVar14;
                if (iVar3 != 0) {
                    if ((iVar3 == 1) || (iVar3 != 2)) {
                        iVar4 = 2;
                    } else {
                        iVar4 = 1;
                    }
                }
                piVar9 = in_RCX[0x79];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e546f;
                piVar9 = (int64_t *)func_0x0001802026d0(piVar9, iVar4);
                if (piVar6 < piVar9) {
                    piVar9 = piVar6;
                }
            }
            iVar3 = iVar3 + 1;
            piVar6 = piVar9;
        } while (iVar3 < 4);
        piVar6 = in_RCX[0xb5];
        piVar10 = piVar9;
        if ((piVar6 != (int64_t *)0xffffffffffffffff) && (piVar10 = piVar6, piVar9 < piVar6)) {
            piVar10 = piVar9;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e54a3;
        piVar9 = (int64_t *)func_0x000180207b50();
        if (piVar10 < piVar9) {
            piVar9 = piVar10;
        }
        if (((*(uint32_t *)(in_RCX + 0xba) & 7) == 2) || ((*(uint32_t *)(in_RCX + 0xba) & 7) == 3)) {
            piVar10 = in_RCX[0xb3];
code_r0x0001801e54d6:
            piVar6 = piVar10;
            if (piVar9 < piVar10) {
                piVar6 = piVar9;
            }
        } else {
            piVar10 = in_RCX[0xb4];
            piVar6 = piVar9;
            if (piVar10 != (int64_t *)0xffffffffffffffff) goto code_r0x0001801e54d6;
        }
        if (((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) && (in_RCX[0xb7] <= piVar6)) {
            piVar6 = in_RCX[0xb7];
        }
    }
    *in_RDX = piVar6;
    *(bool *)(in_RDX + 1) = ((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5523;
        iVar7 = func_0x0001801fb7d0();
        if (iVar7 != 0) {
            uVar11 = 1;
            goto code_r0x0001801e552e;
        }
    }
    uVar11 = 0;
code_r0x0001801e552e:
    *(undefined *)((int64_t)in_RDX + 10) = *(undefined *)((int64_t)&arg_98h + iVar5);
    *(undefined *)((int64_t)in_RDX + 9) = uVar11;
    return;
}

// ============================================================
// Function: FUN_1801e5349
// Address: 0x1801e5349
// Size: 522 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801e5050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined uVar11;
    int64_t **in_RCX;
    int64_t **in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int64_t iVar13;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801e5063;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)(in_RCX + 0xba);
    iVar14 = 0;
    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 0;
    uVar2 = uVar2 & 7;
    if ((uVar2 == 0) || (uVar2 == 4)) {
        *(undefined2 *)(in_RDX + 1) = 0;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        *(undefined *)((int64_t)in_RDX + 10) = 0;
        return;
    }
    if (uVar2 - 2 < 2) {
        piVar6 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50a6;
        piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
        if ((in_RCX[0xb3] < piVar6) || (in_RCX[0xb3] <= piVar6)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50be;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined2 *)(in_RDX + 1) = 0;
            *in_RDX = (int64_t *)0xffffffffffffffff;
            *(undefined *)((int64_t)in_RDX + 10) = 1;
            return;
        }
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    if ((*(uint8_t *)(*piVar6 + 0xa0) & 1) == 0) {
        uVar1 = *(uint8_t *)((int64_t)in_RCX + 0x5d4);
        *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
        if ((uVar1 & 2) != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5122;
            piVar6 = (int64_t *)func_0x0001801e8e50();
            if ((in_RCX[0xb7] < piVar6) || (in_RCX[0xb7] <= piVar6)) {
                piVar6 = in_RCX[0x7b];
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffd;
                in_RCX[0xb7] = (int64_t *)0xffffffffffffffff;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5150;
                iVar3 = func_0x000180205360(piVar6, 1);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R12;
                    *(undefined8 *)((int64_t)&arg_40h + iVar5) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e516c;
                    iVar7 = fcn.1801fca50(1);
                    if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                        uVar12 = 0x1805aadb1;
                        iVar13 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            iVar13 = iVar7;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5192;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51aa;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        uVar8 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            uVar8 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar8;
                        if (iVar7 != 0) {
                            uVar12 = 0x1805ab2cc;
                        }
                        *(int64_t *)(&stack0x00000000 + iVar5) = iVar13;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar12;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51fd;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5218;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        if (in_RCX[0xbb] == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5229;
                            piVar6 = (int64_t *)
                                     fcn.1802542f0(*(int64_t *)(&stack0x00000000 + iVar5), 
                                                   *(int64_t *)((int64_t)&var_20h + iVar5));
                            in_RCX[0xbb] = piVar6;
                            if (piVar6 != (int64_t *)0x0) goto code_r0x0001801e5235;
                        } else {
code_r0x0001801e5235:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e523d;
                            fcn.180254600(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5)
                                          , *(int64_t *)((int64_t)&var_10h + iVar5));
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        *(undefined8 *)((int64_t)&var_20h + iVar5) = 1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
                        *(undefined8 *)((int64_t)&arg_30h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0x1c;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5270;
                        fcn.1801e2d20(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5));
                    }
                }
            }
        }
        do {
            *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) & 0xf3ffffff;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e529d;
            func_0x0001801e1d90(in_RCX, (uint32_t)in_R8 & 1, (int64_t)&arg_98h + iVar5);
            uVar2 = *(uint32_t *)(in_RCX + 0xba);
            if (((uVar2 >> 0x1b & 1) == 0) && (*(undefined8 *)((int64_t)&arg_88h + iVar5) = 0, (in_R8 & 1) == 0)) {
                piVar6 = in_RCX[5];
                *(uint32_t *)(in_RCX + 0xba) = uVar2 | 0x8000000;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52cd;
                func_0x0001801a62c0(piVar6);
                piVar6 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52eb;
                iVar3 = func_0x0001801a60b0(piVar6, (int64_t)&var_18h + iVar5, (int64_t)&arg_a0h + iVar5, 
                                            (int64_t)&arg_88h + iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b7050;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x8b4;
                    *(undefined8 *)(&stack0x00000000 + iVar5) = 0x1804b6360;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = *(undefined8 *)((int64_t)&arg_88h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5326;
                    fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_88h + iVar5), *(int64_t *)((int64_t)&arg_98h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_a0h + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                                  *(int64_t *)(&stack0x000000b0 + iVar5), *(int64_t *)(&stack0x00000158 + iVar5));
                    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 1;
                }
            }
        } while ((*(uint32_t *)(in_RCX + 0xba) & 0x4000000) != 0);
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5351;
    piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
    if (in_RCX[0xb4] <= piVar6) {
        if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
            *(uint32_t *)(in_RCX + 0xb2) = *(uint32_t *)(in_RCX + 0xb2) & 0xfffffffe;
            in_RCX[0xae] = (int64_t *)0xffffffffffffffff;
            in_RCX[0xaf] = (int64_t *)0x0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e557e;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
        }
        *(undefined2 *)(in_RDX + 1) = 0;
        *(undefined *)((int64_t)in_RDX + 10) = 1;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        return;
    }
    if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
        piVar9 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5380;
        piVar9 = (int64_t *)func_0x000180202860(piVar9);
        if ((piVar9 != (int64_t *)0x0) && ((piVar9 < piVar6 || (piVar9 <= piVar6)))) {
            piVar9 = in_RCX[0x79];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5398;
            func_0x000180203570(piVar9);
        }
        if ((in_RCX[0xb5] < piVar6) || (in_RCX[0xb5] <= piVar6)) {
            uVar2 = *(uint32_t *)(in_RCX + 0xba) >> 0xe & 7;
            iVar3 = iVar14;
            if (uVar2 != 0) {
                if ((uVar2 == 1) || (uVar2 != 2)) {
                    iVar3 = 2;
                } else {
                    iVar3 = 1;
                }
            }
            piVar6 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53d8;
            func_0x000180207ed0(piVar6, iVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53e0;
            func_0x0001801e34d0(in_RCX);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53f0;
        func_0x0001801e3140(in_RCX, (int64_t)&arg_98h + iVar5);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53fc;
        func_0x0001801e77e0();
    }
    piVar6 = (int64_t *)0xffffffffffffffff;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        piVar6 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5418;
        piVar6 = (int64_t *)func_0x000180202860(piVar6);
        iVar3 = iVar14;
        if (piVar6 == (int64_t *)0x0) {
            piVar6 = (int64_t *)0xffffffffffffffff;
        }
        do {
            piVar9 = in_RCX[0x7a];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e543e;
            iVar4 = func_0x0001801fb7e0(piVar9, iVar3);
            piVar9 = piVar6;
            if (iVar4 != 0) {
                iVar4 = iVar14;
                if (iVar3 != 0) {
                    if ((iVar3 == 1) || (iVar3 != 2)) {
                        iVar4 = 2;
                    } else {
                        iVar4 = 1;
                    }
                }
                piVar9 = in_RCX[0x79];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e546f;
                piVar9 = (int64_t *)func_0x0001802026d0(piVar9, iVar4);
                if (piVar6 < piVar9) {
                    piVar9 = piVar6;
                }
            }
            iVar3 = iVar3 + 1;
            piVar6 = piVar9;
        } while (iVar3 < 4);
        piVar6 = in_RCX[0xb5];
        piVar10 = piVar9;
        if ((piVar6 != (int64_t *)0xffffffffffffffff) && (piVar10 = piVar6, piVar9 < piVar6)) {
            piVar10 = piVar9;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e54a3;
        piVar9 = (int64_t *)func_0x000180207b50();
        if (piVar10 < piVar9) {
            piVar9 = piVar10;
        }
        if (((*(uint32_t *)(in_RCX + 0xba) & 7) == 2) || ((*(uint32_t *)(in_RCX + 0xba) & 7) == 3)) {
            piVar10 = in_RCX[0xb3];
code_r0x0001801e54d6:
            piVar6 = piVar10;
            if (piVar9 < piVar10) {
                piVar6 = piVar9;
            }
        } else {
            piVar10 = in_RCX[0xb4];
            piVar6 = piVar9;
            if (piVar10 != (int64_t *)0xffffffffffffffff) goto code_r0x0001801e54d6;
        }
        if (((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) && (in_RCX[0xb7] <= piVar6)) {
            piVar6 = in_RCX[0xb7];
        }
    }
    *in_RDX = piVar6;
    *(bool *)(in_RDX + 1) = ((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5523;
        iVar7 = func_0x0001801fb7d0();
        if (iVar7 != 0) {
            uVar11 = 1;
            goto code_r0x0001801e552e;
        }
    }
    uVar11 = 0;
code_r0x0001801e552e:
    *(undefined *)((int64_t)in_RDX + 10) = *(undefined *)((int64_t)&arg_98h + iVar5);
    *(undefined *)((int64_t)in_RDX + 9) = uVar11;
    return;
}

// ============================================================
// Function: FUN_1801e5553
// Address: 0x1801e5553
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801e5050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined uVar11;
    int64_t **in_RCX;
    int64_t **in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int64_t iVar13;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801e5063;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)(in_RCX + 0xba);
    iVar14 = 0;
    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 0;
    uVar2 = uVar2 & 7;
    if ((uVar2 == 0) || (uVar2 == 4)) {
        *(undefined2 *)(in_RDX + 1) = 0;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        *(undefined *)((int64_t)in_RDX + 10) = 0;
        return;
    }
    if (uVar2 - 2 < 2) {
        piVar6 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50a6;
        piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
        if ((in_RCX[0xb3] < piVar6) || (in_RCX[0xb3] <= piVar6)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50be;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined2 *)(in_RDX + 1) = 0;
            *in_RDX = (int64_t *)0xffffffffffffffff;
            *(undefined *)((int64_t)in_RDX + 10) = 1;
            return;
        }
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    if ((*(uint8_t *)(*piVar6 + 0xa0) & 1) == 0) {
        uVar1 = *(uint8_t *)((int64_t)in_RCX + 0x5d4);
        *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
        if ((uVar1 & 2) != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5122;
            piVar6 = (int64_t *)func_0x0001801e8e50();
            if ((in_RCX[0xb7] < piVar6) || (in_RCX[0xb7] <= piVar6)) {
                piVar6 = in_RCX[0x7b];
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffd;
                in_RCX[0xb7] = (int64_t *)0xffffffffffffffff;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5150;
                iVar3 = func_0x000180205360(piVar6, 1);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R12;
                    *(undefined8 *)((int64_t)&arg_40h + iVar5) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e516c;
                    iVar7 = fcn.1801fca50(1);
                    if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                        uVar12 = 0x1805aadb1;
                        iVar13 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            iVar13 = iVar7;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5192;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51aa;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        uVar8 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            uVar8 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar8;
                        if (iVar7 != 0) {
                            uVar12 = 0x1805ab2cc;
                        }
                        *(int64_t *)(&stack0x00000000 + iVar5) = iVar13;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar12;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51fd;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5218;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        if (in_RCX[0xbb] == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5229;
                            piVar6 = (int64_t *)
                                     fcn.1802542f0(*(int64_t *)(&stack0x00000000 + iVar5), 
                                                   *(int64_t *)((int64_t)&var_20h + iVar5));
                            in_RCX[0xbb] = piVar6;
                            if (piVar6 != (int64_t *)0x0) goto code_r0x0001801e5235;
                        } else {
code_r0x0001801e5235:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e523d;
                            fcn.180254600(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5)
                                          , *(int64_t *)((int64_t)&var_10h + iVar5));
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        *(undefined8 *)((int64_t)&var_20h + iVar5) = 1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
                        *(undefined8 *)((int64_t)&arg_30h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0x1c;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5270;
                        fcn.1801e2d20(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5));
                    }
                }
            }
        }
        do {
            *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) & 0xf3ffffff;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e529d;
            func_0x0001801e1d90(in_RCX, (uint32_t)in_R8 & 1, (int64_t)&arg_98h + iVar5);
            uVar2 = *(uint32_t *)(in_RCX + 0xba);
            if (((uVar2 >> 0x1b & 1) == 0) && (*(undefined8 *)((int64_t)&arg_88h + iVar5) = 0, (in_R8 & 1) == 0)) {
                piVar6 = in_RCX[5];
                *(uint32_t *)(in_RCX + 0xba) = uVar2 | 0x8000000;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52cd;
                func_0x0001801a62c0(piVar6);
                piVar6 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52eb;
                iVar3 = func_0x0001801a60b0(piVar6, (int64_t)&var_18h + iVar5, (int64_t)&arg_a0h + iVar5, 
                                            (int64_t)&arg_88h + iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b7050;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x8b4;
                    *(undefined8 *)(&stack0x00000000 + iVar5) = 0x1804b6360;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = *(undefined8 *)((int64_t)&arg_88h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5326;
                    fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_88h + iVar5), *(int64_t *)((int64_t)&arg_98h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_a0h + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                                  *(int64_t *)(&stack0x000000b0 + iVar5), *(int64_t *)(&stack0x00000158 + iVar5));
                    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 1;
                }
            }
        } while ((*(uint32_t *)(in_RCX + 0xba) & 0x4000000) != 0);
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5351;
    piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
    if (in_RCX[0xb4] <= piVar6) {
        if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
            *(uint32_t *)(in_RCX + 0xb2) = *(uint32_t *)(in_RCX + 0xb2) & 0xfffffffe;
            in_RCX[0xae] = (int64_t *)0xffffffffffffffff;
            in_RCX[0xaf] = (int64_t *)0x0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e557e;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
        }
        *(undefined2 *)(in_RDX + 1) = 0;
        *(undefined *)((int64_t)in_RDX + 10) = 1;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        return;
    }
    if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
        piVar9 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5380;
        piVar9 = (int64_t *)func_0x000180202860(piVar9);
        if ((piVar9 != (int64_t *)0x0) && ((piVar9 < piVar6 || (piVar9 <= piVar6)))) {
            piVar9 = in_RCX[0x79];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5398;
            func_0x000180203570(piVar9);
        }
        if ((in_RCX[0xb5] < piVar6) || (in_RCX[0xb5] <= piVar6)) {
            uVar2 = *(uint32_t *)(in_RCX + 0xba) >> 0xe & 7;
            iVar3 = iVar14;
            if (uVar2 != 0) {
                if ((uVar2 == 1) || (uVar2 != 2)) {
                    iVar3 = 2;
                } else {
                    iVar3 = 1;
                }
            }
            piVar6 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53d8;
            func_0x000180207ed0(piVar6, iVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53e0;
            func_0x0001801e34d0(in_RCX);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53f0;
        func_0x0001801e3140(in_RCX, (int64_t)&arg_98h + iVar5);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53fc;
        func_0x0001801e77e0();
    }
    piVar6 = (int64_t *)0xffffffffffffffff;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        piVar6 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5418;
        piVar6 = (int64_t *)func_0x000180202860(piVar6);
        iVar3 = iVar14;
        if (piVar6 == (int64_t *)0x0) {
            piVar6 = (int64_t *)0xffffffffffffffff;
        }
        do {
            piVar9 = in_RCX[0x7a];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e543e;
            iVar4 = func_0x0001801fb7e0(piVar9, iVar3);
            piVar9 = piVar6;
            if (iVar4 != 0) {
                iVar4 = iVar14;
                if (iVar3 != 0) {
                    if ((iVar3 == 1) || (iVar3 != 2)) {
                        iVar4 = 2;
                    } else {
                        iVar4 = 1;
                    }
                }
                piVar9 = in_RCX[0x79];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e546f;
                piVar9 = (int64_t *)func_0x0001802026d0(piVar9, iVar4);
                if (piVar6 < piVar9) {
                    piVar9 = piVar6;
                }
            }
            iVar3 = iVar3 + 1;
            piVar6 = piVar9;
        } while (iVar3 < 4);
        piVar6 = in_RCX[0xb5];
        piVar10 = piVar9;
        if ((piVar6 != (int64_t *)0xffffffffffffffff) && (piVar10 = piVar6, piVar9 < piVar6)) {
            piVar10 = piVar9;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e54a3;
        piVar9 = (int64_t *)func_0x000180207b50();
        if (piVar10 < piVar9) {
            piVar9 = piVar10;
        }
        if (((*(uint32_t *)(in_RCX + 0xba) & 7) == 2) || ((*(uint32_t *)(in_RCX + 0xba) & 7) == 3)) {
            piVar10 = in_RCX[0xb3];
code_r0x0001801e54d6:
            piVar6 = piVar10;
            if (piVar9 < piVar10) {
                piVar6 = piVar9;
            }
        } else {
            piVar10 = in_RCX[0xb4];
            piVar6 = piVar9;
            if (piVar10 != (int64_t *)0xffffffffffffffff) goto code_r0x0001801e54d6;
        }
        if (((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) && (in_RCX[0xb7] <= piVar6)) {
            piVar6 = in_RCX[0xb7];
        }
    }
    *in_RDX = piVar6;
    *(bool *)(in_RDX + 1) = ((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5523;
        iVar7 = func_0x0001801fb7d0();
        if (iVar7 != 0) {
            uVar11 = 1;
            goto code_r0x0001801e552e;
        }
    }
    uVar11 = 0;
code_r0x0001801e552e:
    *(undefined *)((int64_t)in_RDX + 10) = *(undefined *)((int64_t)&arg_98h + iVar5);
    *(undefined *)((int64_t)in_RDX + 9) = uVar11;
    return;
}

// ============================================================
// Function: FUN_1801e558d
// Address: 0x1801e558d
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801e5050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined uVar11;
    int64_t **in_RCX;
    int64_t **in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    int64_t iVar13;
    uint64_t in_R8;
    undefined8 unaff_R12;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801e5063;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = *(uint32_t *)(in_RCX + 0xba);
    iVar14 = 0;
    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 0;
    uVar2 = uVar2 & 7;
    if ((uVar2 == 0) || (uVar2 == 4)) {
        *(undefined2 *)(in_RDX + 1) = 0;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        *(undefined *)((int64_t)in_RDX + 10) = 0;
        return;
    }
    if (uVar2 - 2 < 2) {
        piVar6 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50a6;
        piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
        if ((in_RCX[0xb3] < piVar6) || (in_RCX[0xb3] <= piVar6)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e50be;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined2 *)(in_RDX + 1) = 0;
            *in_RDX = (int64_t *)0xffffffffffffffff;
            *(undefined *)((int64_t)in_RDX + 10) = 1;
            return;
        }
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    if ((*(uint8_t *)(*piVar6 + 0xa0) & 1) == 0) {
        uVar1 = *(uint8_t *)((int64_t)in_RCX + 0x5d4);
        *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
        if ((uVar1 & 2) != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5122;
            piVar6 = (int64_t *)func_0x0001801e8e50();
            if ((in_RCX[0xb7] < piVar6) || (in_RCX[0xb7] <= piVar6)) {
                piVar6 = in_RCX[0x7b];
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffd;
                in_RCX[0xb7] = (int64_t *)0xffffffffffffffff;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5150;
                iVar3 = func_0x000180205360(piVar6, 1);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R12;
                    *(undefined8 *)((int64_t)&arg_40h + iVar5) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e516c;
                    iVar7 = fcn.1801fca50(1);
                    if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                        uVar12 = 0x1805aadb1;
                        iVar13 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            iVar13 = iVar7;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5192;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51aa;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        uVar8 = 0x1805aadb1;
                        if (iVar7 != 0) {
                            uVar8 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar8;
                        if (iVar7 != 0) {
                            uVar12 = 0x1805ab2cc;
                        }
                        *(int64_t *)(&stack0x00000000 + iVar5) = iVar13;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar12;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e51fd;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5218;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                        if (in_RCX[0xbb] == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5229;
                            piVar6 = (int64_t *)
                                     fcn.1802542f0(*(int64_t *)(&stack0x00000000 + iVar5), 
                                                   *(int64_t *)((int64_t)&var_20h + iVar5));
                            in_RCX[0xbb] = piVar6;
                            if (piVar6 != (int64_t *)0x0) goto code_r0x0001801e5235;
                        } else {
code_r0x0001801e5235:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e523d;
                            fcn.180254600(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5)
                                          , *(int64_t *)((int64_t)&var_10h + iVar5));
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        *(undefined8 *)((int64_t)&var_20h + iVar5) = 1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
                        *(undefined8 *)((int64_t)&arg_30h + iVar5) = 0x1804b63d8;
                        *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0x1c;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5270;
                        fcn.1801e2d20(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                      *(int64_t *)(&stack0x00000000 + iVar5), *(int64_t *)((int64_t)&var_8h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar5));
                    }
                }
            }
        }
        do {
            *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) & 0xf3ffffff;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e529d;
            func_0x0001801e1d90(in_RCX, (uint32_t)in_R8 & 1, (int64_t)&arg_98h + iVar5);
            uVar2 = *(uint32_t *)(in_RCX + 0xba);
            if (((uVar2 >> 0x1b & 1) == 0) && (*(undefined8 *)((int64_t)&arg_88h + iVar5) = 0, (in_R8 & 1) == 0)) {
                piVar6 = in_RCX[5];
                *(uint32_t *)(in_RCX + 0xba) = uVar2 | 0x8000000;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52cd;
                func_0x0001801a62c0(piVar6);
                piVar6 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e52eb;
                iVar3 = func_0x0001801a60b0(piVar6, (int64_t)&var_18h + iVar5, (int64_t)&arg_a0h + iVar5, 
                                            (int64_t)&arg_88h + iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b7050;
                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x8b4;
                    *(undefined8 *)(&stack0x00000000 + iVar5) = 0x1804b6360;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = *(undefined8 *)((int64_t)&arg_88h + iVar5);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5326;
                    fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_88h + iVar5), *(int64_t *)((int64_t)&arg_98h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_a0h + iVar5), *(int64_t *)(&stack0x000000a8 + iVar5), 
                                  *(int64_t *)(&stack0x000000b0 + iVar5), *(int64_t *)(&stack0x00000158 + iVar5));
                    *(undefined4 *)((int64_t)&arg_98h + iVar5) = 1;
                }
            }
        } while ((*(uint32_t *)(in_RCX + 0xba) & 0x4000000) != 0);
    }
    piVar6 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5351;
    piVar6 = (int64_t *)func_0x0001801e8e50(piVar6);
    if (in_RCX[0xb4] <= piVar6) {
        if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
            *(uint32_t *)(in_RCX + 0xb2) = *(uint32_t *)(in_RCX + 0xb2) & 0xfffffffe;
            in_RCX[0xae] = (int64_t *)0xffffffffffffffff;
            in_RCX[0xaf] = (int64_t *)0x0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e557e;
            fcn.1801e1a70(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
        }
        *(undefined2 *)(in_RDX + 1) = 0;
        *(undefined *)((int64_t)in_RDX + 10) = 1;
        *in_RDX = (int64_t *)0xffffffffffffffff;
        return;
    }
    if ((*(uint8_t *)(**in_RCX + 0xa0) & 1) == 0) {
        piVar9 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5380;
        piVar9 = (int64_t *)func_0x000180202860(piVar9);
        if ((piVar9 != (int64_t *)0x0) && ((piVar9 < piVar6 || (piVar9 <= piVar6)))) {
            piVar9 = in_RCX[0x79];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5398;
            func_0x000180203570(piVar9);
        }
        if ((in_RCX[0xb5] < piVar6) || (in_RCX[0xb5] <= piVar6)) {
            uVar2 = *(uint32_t *)(in_RCX + 0xba) >> 0xe & 7;
            iVar3 = iVar14;
            if (uVar2 != 0) {
                if ((uVar2 == 1) || (uVar2 != 2)) {
                    iVar3 = 2;
                } else {
                    iVar3 = 1;
                }
            }
            piVar6 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53d8;
            func_0x000180207ed0(piVar6, iVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53e0;
            func_0x0001801e34d0(in_RCX);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53f0;
        func_0x0001801e3140(in_RCX, (int64_t)&arg_98h + iVar5);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e53fc;
        func_0x0001801e77e0();
    }
    piVar6 = (int64_t *)0xffffffffffffffff;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        piVar6 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5418;
        piVar6 = (int64_t *)func_0x000180202860(piVar6);
        iVar3 = iVar14;
        if (piVar6 == (int64_t *)0x0) {
            piVar6 = (int64_t *)0xffffffffffffffff;
        }
        do {
            piVar9 = in_RCX[0x7a];
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e543e;
            iVar4 = func_0x0001801fb7e0(piVar9, iVar3);
            piVar9 = piVar6;
            if (iVar4 != 0) {
                iVar4 = iVar14;
                if (iVar3 != 0) {
                    if ((iVar3 == 1) || (iVar3 != 2)) {
                        iVar4 = 2;
                    } else {
                        iVar4 = 1;
                    }
                }
                piVar9 = in_RCX[0x79];
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e546f;
                piVar9 = (int64_t *)func_0x0001802026d0(piVar9, iVar4);
                if (piVar6 < piVar9) {
                    piVar9 = piVar6;
                }
            }
            iVar3 = iVar3 + 1;
            piVar6 = piVar9;
        } while (iVar3 < 4);
        piVar6 = in_RCX[0xb5];
        piVar10 = piVar9;
        if ((piVar6 != (int64_t *)0xffffffffffffffff) && (piVar10 = piVar6, piVar9 < piVar6)) {
            piVar10 = piVar9;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e54a3;
        piVar9 = (int64_t *)func_0x000180207b50();
        if (piVar10 < piVar9) {
            piVar9 = piVar10;
        }
        if (((*(uint32_t *)(in_RCX + 0xba) & 7) == 2) || ((*(uint32_t *)(in_RCX + 0xba) & 7) == 3)) {
            piVar10 = in_RCX[0xb3];
code_r0x0001801e54d6:
            piVar6 = piVar10;
            if (piVar9 < piVar10) {
                piVar6 = piVar9;
            }
        } else {
            piVar10 = in_RCX[0xb4];
            piVar6 = piVar9;
            if (piVar10 != (int64_t *)0xffffffffffffffff) goto code_r0x0001801e54d6;
        }
        if (((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) && (in_RCX[0xb7] <= piVar6)) {
            piVar6 = in_RCX[0xb7];
        }
    }
    *in_RDX = piVar6;
    *(bool *)(in_RDX + 1) = ((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4;
    if (((uint8_t)*(undefined4 *)(in_RCX + 0xba) & 7) != 4) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e5523;
        iVar7 = func_0x0001801fb7d0();
        if (iVar7 != 0) {
            uVar11 = 1;
            goto code_r0x0001801e552e;
        }
    }
    uVar11 = 0;
code_r0x0001801e552e:
    *(undefined *)((int64_t)in_RDX + 10) = *(undefined *)((int64_t)&arg_98h + iVar5);
    *(undefined *)((int64_t)in_RDX + 9) = uVar11;
    return;
}

// ============================================================
// Function: FUN_1801e55b0
// Address: 0x1801e55b0
// Size: 59 bytes
// ============================================================
bool fcn.1801e55b0(uint8_t *param_1, uint8_t *param_2)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e55ba;
    iVar3 = fcn.18045a350();
    uVar1 = *param_1;
    if ((uVar1 == *param_2) && (uVar1 < 0x15)) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar3) = 0x1801e55d6;
        iVar2 = fcn.180497f30(param_1 + 1, param_2 + 1, uVar1);
        return iVar2 == 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1801e55f0
// Address: 0x1801e55f0
// Size: 48 bytes
// ============================================================
bool fcn.1801e55f0(undefined8 param_1, uint64_t param_2, int64_t param_3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e55fa;
    iVar3 = fcn.18045a350();
    uVar1 = *(undefined8 *)(param_3 + 0x3c8);
    *(undefined8 *)((int64_t)&uStack_8 - iVar3) = 0x1801e5612;
    iVar2 = fcn.1802029a0(uVar1, param_1, param_2 & 0xffffffff);
    return iVar2 != 0;
}

// ============================================================
// Function: FUN_1801e5620
// Address: 0x1801e5620
// Size: 172 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801e5620(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
                  int64_t arg_78h, int64_t arg_80h)
{
    uint32_t *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 in_RCX;
    int64_t iVar7;
    undefined8 *in_RDX;
    undefined8 unaff_R12;
    undefined8 uVar8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e5638;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar2 = *(uint32_t *)(in_RDX + 0xba);
    puVar1 = (uint32_t *)((int64_t)in_RDX + 0x5d4);
    if (((uVar2 >> 10 & 1) != 0) && ((*(uint8_t *)puVar1 & 4) == 0)) {
        uVar8 = in_RDX[0x79];
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e566b;
        uVar4 = func_0x000180202870(uVar8);
        uVar8 = *in_RDX;
        *(uint32_t *)(in_RDX + 0xba) = *(uint32_t *)(in_RDX + 0xba) & 0x7fffffff;
        *puVar1 = *puVar1 | 6;
        in_RDX[0xb9] = in_RCX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e568a;
        iVar5 = func_0x0001801e8e50(uVar8);
        iVar7 = -1;
        if (uVar4 <= -iVar5 - 1U) {
            iVar7 = iVar5 + uVar4;
        }
        *puVar1 = *puVar1 & 0xffffffef;
        in_RDX[0xb7] = iVar7;
        if (((int32_t)uVar2 >> 0x1f & 0xfffffffeU) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e56b6;
            func_0x0001801e2f70(in_RDX);
        }
        uVar8 = in_RDX[0x11];
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e56c7;
        func_0x000180207ea0(uVar8, 2);
        return;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e56ef;
    iVar7 = fcn.1801fca50(0xe);
    if ((*(uint8_t *)puVar1 & 0x40) != 0) {
        return;
    }
    uVar8 = 0x1805aadb1;
    iVar5 = iVar7;
    if (iVar7 == 0) {
        iVar5 = 0x1805aadb1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e571f;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e5737;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar3));
    uVar6 = 0x1805aadb1;
    if (iVar7 != 0) {
        uVar6 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b63a8;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar6;
    *(int64_t *)((int64_t)&var_10h + iVar3) = iVar5;
    if (iVar7 != 0) {
        uVar8 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e578d;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e57a5;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar3));
    if (in_RDX[0xbb] == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e57b6;
        iVar7 = fcn.1802542f0(*(int64_t *)((int64_t)&var_10h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
        in_RDX[0xbb] = iVar7;
        if (iVar7 == 0) goto code_r0x0001801e57cd;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e57cd;
    fcn.180254600(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
code_r0x0001801e57cd:
    *(uint32_t *)((int64_t)in_RDX + 0x5d4) = *(uint32_t *)((int64_t)in_RDX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0xe;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0x1804b63a8;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1c;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e5800;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801e56cc
// Address: 0x1801e56cc
// Size: 324 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801e5620(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
                  int64_t arg_78h, int64_t arg_80h)
{
    uint32_t *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 in_RCX;
    int64_t iVar7;
    undefined8 *in_RDX;
    undefined8 unaff_R12;
    undefined8 uVar8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e5638;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar2 = *(uint32_t *)(in_RDX + 0xba);
    puVar1 = (uint32_t *)((int64_t)in_RDX + 0x5d4);
    if (((uVar2 >> 10 & 1) != 0) && ((*(uint8_t *)puVar1 & 4) == 0)) {
        uVar8 = in_RDX[0x79];
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e566b;
        uVar4 = func_0x000180202870(uVar8);
        uVar8 = *in_RDX;
        *(uint32_t *)(in_RDX + 0xba) = *(uint32_t *)(in_RDX + 0xba) & 0x7fffffff;
        *puVar1 = *puVar1 | 6;
        in_RDX[0xb9] = in_RCX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e568a;
        iVar5 = func_0x0001801e8e50(uVar8);
        iVar7 = -1;
        if (uVar4 <= -iVar5 - 1U) {
            iVar7 = iVar5 + uVar4;
        }
        *puVar1 = *puVar1 & 0xffffffef;
        in_RDX[0xb7] = iVar7;
        if (((int32_t)uVar2 >> 0x1f & 0xfffffffeU) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e56b6;
            func_0x0001801e2f70(in_RDX);
        }
        uVar8 = in_RDX[0x11];
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e56c7;
        func_0x000180207ea0(uVar8, 2);
        return;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e56ef;
    iVar7 = fcn.1801fca50(0xe);
    if ((*(uint8_t *)puVar1 & 0x40) != 0) {
        return;
    }
    uVar8 = 0x1805aadb1;
    iVar5 = iVar7;
    if (iVar7 == 0) {
        iVar5 = 0x1805aadb1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e571f;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e5737;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar3));
    uVar6 = 0x1805aadb1;
    if (iVar7 != 0) {
        uVar6 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b63a8;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar6;
    *(int64_t *)((int64_t)&var_10h + iVar3) = iVar5;
    if (iVar7 != 0) {
        uVar8 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e578d;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e57a5;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar3));
    if (in_RDX[0xbb] == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e57b6;
        iVar7 = fcn.1802542f0(*(int64_t *)((int64_t)&var_10h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
        in_RDX[0xbb] = iVar7;
        if (iVar7 == 0) goto code_r0x0001801e57cd;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e57cd;
    fcn.180254600(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
code_r0x0001801e57cd:
    *(uint32_t *)((int64_t)in_RDX + 0x5d4) = *(uint32_t *)((int64_t)in_RDX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0xe;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0x1804b63a8;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1c;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e5800;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801e5810
// Address: 0x1801e5810
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801e5620(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
                  int64_t arg_78h, int64_t arg_80h)
{
    uint32_t *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 in_RCX;
    int64_t iVar7;
    undefined8 *in_RDX;
    undefined8 unaff_R12;
    undefined8 uVar8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e5638;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar2 = *(uint32_t *)(in_RDX + 0xba);
    puVar1 = (uint32_t *)((int64_t)in_RDX + 0x5d4);
    if (((uVar2 >> 10 & 1) != 0) && ((*(uint8_t *)puVar1 & 4) == 0)) {
        uVar8 = in_RDX[0x79];
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e566b;
        uVar4 = func_0x000180202870(uVar8);
        uVar8 = *in_RDX;
        *(uint32_t *)(in_RDX + 0xba) = *(uint32_t *)(in_RDX + 0xba) & 0x7fffffff;
        *puVar1 = *puVar1 | 6;
        in_RDX[0xb9] = in_RCX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e568a;
        iVar5 = func_0x0001801e8e50(uVar8);
        iVar7 = -1;
        if (uVar4 <= -iVar5 - 1U) {
            iVar7 = iVar5 + uVar4;
        }
        *puVar1 = *puVar1 & 0xffffffef;
        in_RDX[0xb7] = iVar7;
        if (((int32_t)uVar2 >> 0x1f & 0xfffffffeU) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e56b6;
            func_0x0001801e2f70(in_RDX);
        }
        uVar8 = in_RDX[0x11];
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e56c7;
        func_0x000180207ea0(uVar8, 2);
        return;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e56ef;
    iVar7 = fcn.1801fca50(0xe);
    if ((*(uint8_t *)puVar1 & 0x40) != 0) {
        return;
    }
    uVar8 = 0x1805aadb1;
    iVar5 = iVar7;
    if (iVar7 == 0) {
        iVar5 = 0x1805aadb1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e571f;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e5737;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar3));
    uVar6 = 0x1805aadb1;
    if (iVar7 != 0) {
        uVar6 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b63a8;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar6;
    *(int64_t *)((int64_t)&var_10h + iVar3) = iVar5;
    if (iVar7 != 0) {
        uVar8 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e578d;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e57a5;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar3));
    if (in_RDX[0xbb] == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e57b6;
        iVar7 = fcn.1802542f0(*(int64_t *)((int64_t)&var_10h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
        in_RDX[0xbb] = iVar7;
        if (iVar7 == 0) goto code_r0x0001801e57cd;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e57cd;
    fcn.180254600(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
code_r0x0001801e57cd:
    *(uint32_t *)((int64_t)in_RDX + 0x5d4) = *(uint32_t *)((int64_t)in_RDX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0xe;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0x1804b63a8;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1c;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e5800;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801e5830
// Address: 0x1801e5830
// Size: 43 bytes
// ============================================================
undefined8 fcn.1801e5830(int64_t param_1, uint64_t *param_2)
{
    undefined8 uVar1;
    
    uVar1 = fcn.18045a350();
    if ((*(uint8_t *)(param_1 + 0x100) & 3) != 0) {
        return uVar1;
    }
    if (*param_2 <= *(uint64_t *)(param_1 + 0x90)) {
        return 0;
    }
    *(uint64_t *)(param_1 + 0x90) = *param_2;
    return 1;
}

// ============================================================
// Function: FUN_1801e5860
// Address: 0x1801e5860
// Size: 46 bytes
// ============================================================
uint32_t fcn.1801e5860(int64_t param_1, uint64_t *param_2)
{
    uint32_t uVar1;
    
    fcn.18045a350();
    uVar1 = *(uint32_t *)(param_1 + 0x100) & 0xffffff03;
    if ((char)uVar1 != '\x02') {
        return uVar1;
    }
    if (*param_2 <= *(uint64_t *)(param_1 + 0x90)) {
        return 0;
    }
    *(uint64_t *)(param_1 + 0x90) = *param_2;
    return 1;
}

// ============================================================
// Function: FUN_1801e5890
// Address: 0x1801e5890
// Size: 77 bytes
// ============================================================
undefined8 fcn.1801e5890(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined8 *in_RCX;
    undefined8 unaff_RBX;
    int64_t iVar4;
    undefined8 unaff_RDI;
    uint64_t uVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e589c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((*(uint32_t *)(in_RCX + 0xba) & 0x1c000) != 0xc000) || ((*(uint32_t *)(in_RCX + 0xba) >> 10 & 1) == 0)) {
        return 0;
    }
    if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 1) != 0) {
        uVar1 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        uVar5 = in_RCX[0xb8];
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e58ee;
        uVar3 = func_0x000180202850(uVar1, 2);
        if (uVar5 <= uVar3) {
            uVar1 = in_RCX[0x79];
            *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e5904;
            uVar3 = func_0x000180202870(uVar1);
            *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffe;
            iVar4 = -1;
            uVar5 = 0xffffffffffffffff;
            if (uVar3 < 0x5555555555555556) {
                uVar5 = uVar3 * 3;
            }
            uVar1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e5930;
            iVar2 = func_0x0001801e8e50(uVar1);
            if (uVar5 <= -iVar2 - 1U) {
                iVar4 = uVar5 + iVar2;
            }
            in_RCX[0xb6] = iVar4;
        }
        if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 1) != 0) {
            return 0;
        }
    }
    return 1;
}

