// Chunk 53 - 50 functions

// ============================================================
// Function: FUN_1800a52b1
// Address: 0x1800a52b1
// Size: 83 bytes
// ============================================================
undefined8 fcn.1800a52b1(int64_t arg_30h, int64_t arg_50h)
{
    undefined4 *unaff_RBX;
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_20h;
    
    uVar1 = fcn.180490aa0();
    uVar2 = fcn.180490aa0(unaff_RBX[1]);
    uVar3 = fcn.180490aa0(*unaff_RBX);
    fcn.180086750(uVar3, uVar3, uVar2, uVar1);
    return 1;
}

// ============================================================
// Function: FUN_1800a5304
// Address: 0x1800a5304
// Size: 17 bytes
// ============================================================
void fcn.1800a5304(undefined8 param_1)
{
    code *pcVar1;
    
    fcn.180088470(param_1, 1, 5);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800a5320
// Address: 0x1800a5320
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a5320(int64_t arg1)
{
    code *pcVar1;
    undefined4 *puVar2;
    undefined8 uVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    
    puVar2 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar2 = *(undefined4 **)0x180782430;
    }
    puVar4 = (undefined4 *)0x0;
    if (puVar2[3] == 5) {
        puVar4 = puVar2;
    }
    if (puVar4 != (undefined4 *)0x0) {
        uVar5 = fcn.180471c90(puVar4[2]);
        uVar6 = fcn.180471c90(puVar4[1]);
        uVar7 = fcn.180471c90(*puVar4);
        fcn.180086750(arg1, uVar7, uVar6, uVar5);
        return 1;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a5351
// Address: 0x1800a5351
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a5320(int64_t arg1)
{
    code *pcVar1;
    undefined4 *puVar2;
    undefined8 uVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    
    puVar2 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar2 = *(undefined4 **)0x180782430;
    }
    puVar4 = (undefined4 *)0x0;
    if (puVar2[3] == 5) {
        puVar4 = puVar2;
    }
    if (puVar4 != (undefined4 *)0x0) {
        uVar5 = fcn.180471c90(puVar4[2]);
        uVar6 = fcn.180471c90(puVar4[1]);
        uVar7 = fcn.180471c90(*puVar4);
        fcn.180086750(arg1, uVar7, uVar6, uVar5);
        return 1;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a53a4
// Address: 0x1800a53a4
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a5320(int64_t arg1)
{
    code *pcVar1;
    undefined4 *puVar2;
    undefined8 uVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    
    puVar2 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar2 = *(undefined4 **)0x180782430;
    }
    puVar4 = (undefined4 *)0x0;
    if (puVar2[3] == 5) {
        puVar4 = puVar2;
    }
    if (puVar4 != (undefined4 *)0x0) {
        uVar5 = fcn.180471c90(puVar4[2]);
        uVar6 = fcn.180471c90(puVar4[1]);
        uVar7 = fcn.180471c90(*puVar4);
        fcn.180086750(arg1, uVar7, uVar6, uVar5);
        return 1;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a53c0
// Address: 0x1800a53c0
// Size: 98 bytes
// ============================================================
undefined8 fcn.1800a53c0(int64_t arg1)
{
    code *pcVar1;
    uint32_t *puVar2;
    undefined8 uVar3;
    uint32_t *puVar4;
    
    puVar2 = *(uint32_t **)(arg1 + 0x28);
    if (*(uint32_t **)(arg1 + 0x40) <= *(uint32_t **)(arg1 + 0x28)) {
        puVar2 = *(uint32_t **)0x180782430;
    }
    puVar4 = (uint32_t *)0x0;
    if (puVar2[3] == 5) {
        puVar4 = puVar2;
    }
    if (puVar4 != (uint32_t *)0x0) {
        fcn.180086750(0x7fffffff7fffffff, *puVar4 & 0x7fffffff, puVar4[1] & 0x7fffffff, puVar4[2] & 0x7fffffff);
        return 1;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a5430
// Address: 0x1800a5430
// Size: 187 bytes
// ============================================================
undefined8 fcn.1800a5430(int64_t arg1)
{
    code *pcVar1;
    float *pfVar2;
    undefined8 uVar3;
    float *pfVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    
    pfVar2 = *(float **)(arg1 + 0x28);
    if (*(float **)(arg1 + 0x40) <= *(float **)(arg1 + 0x28)) {
        pfVar2 = *(float **)0x180782430;
    }
    pfVar4 = (float *)0x0;
    if (pfVar2[3] == 7.006492e-45) {
        pfVar4 = pfVar2;
    }
    if (pfVar4 != (float *)0x0) {
        uVar5 = 0x3f800000;
        if (pfVar4[2] <= 0.0) {
            if (0.0 <= pfVar4[2]) {
                uVar6 = 0;
            } else {
                uVar6 = 0xbf800000;
            }
        } else {
            uVar6 = 0x3f800000;
        }
        if (pfVar4[1] <= 0.0) {
            if (0.0 <= pfVar4[1]) {
                uVar7 = 0;
            } else {
                uVar7 = 0xbf800000;
            }
        } else {
            uVar7 = 0x3f800000;
        }
        if (*pfVar4 <= 0.0) {
            if (*pfVar4 < 0.0) {
                fcn.180086750(0, 0xbf800000, uVar7, uVar6);
                return 1;
            }
            uVar5 = 0;
        }
        fcn.180086750(0, uVar5, uVar7, uVar6);
        return 1;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a54f0
// Address: 0x1800a54f0
// Size: 309 bytes
// ============================================================
undefined8 fcn.1800a54f0(int64_t arg1)
{
    float *pfVar1;
    code *pcVar2;
    float *pfVar3;
    undefined8 uVar4;
    float *pfVar5;
    float *pfVar6;
    float *pfVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    
    pfVar6 = *(float **)(arg1 + 0x28);
    pfVar1 = *(float **)(arg1 + 0x40);
    pfVar3 = pfVar6;
    if (pfVar1 <= pfVar6) {
        pfVar3 = *(float **)0x180782430;
    }
    pfVar7 = (float *)0x0;
    if (pfVar3[3] == 7.006492e-45) {
        pfVar7 = pfVar3;
    }
    if (pfVar7 == (float *)0x0) {
        fcn.180088470(arg1, 1, 5);
        pcVar2 = (code *)swi(3);
        uVar4 = (*pcVar2)();
        return uVar4;
    }
    pfVar3 = pfVar6 + 4;
    if (pfVar1 <= pfVar6 + 4) {
        pfVar3 = *(float **)0x180782430;
    }
    pfVar5 = (float *)0x0;
    if (pfVar3[3] == 7.006492e-45) {
        pfVar5 = pfVar3;
    }
    if (pfVar5 == (float *)0x0) {
        fcn.180088470(arg1, 2, 5);
        pcVar2 = (code *)swi(3);
        uVar4 = (*pcVar2)();
        return uVar4;
    }
    pfVar3 = pfVar6 + 8;
    if (pfVar1 <= pfVar6 + 8) {
        pfVar3 = *(float **)0x180782430;
    }
    pfVar6 = (float *)0x0;
    if (pfVar3[3] == 7.006492e-45) {
        pfVar6 = pfVar3;
    }
    if (pfVar6 != (float *)0x0) {
        fVar8 = *pfVar5;
        fVar9 = *pfVar6;
        if (fVar9 < fVar8) {
            fcn.180088380(fVar8, 3, 0x18063edb0);
            pcVar2 = (code *)swi(3);
            uVar4 = (*pcVar2)();
            return uVar4;
        }
        fVar12 = pfVar5[1];
        fVar10 = pfVar6[1];
        if (fVar12 <= fVar10) {
            fVar13 = pfVar5[2];
            fVar11 = pfVar6[2];
            if (fVar13 <= fVar11) {
                if (fVar13 <= pfVar7[2]) {
                    fVar13 = pfVar7[2];
                }
                if (fVar12 <= pfVar7[1]) {
                    fVar12 = pfVar7[1];
                }
                if (fVar8 <= *pfVar7) {
                    fVar8 = *pfVar7;
                }
                if (fVar13 <= fVar11) {
                    fVar11 = fVar13;
                }
                if (fVar12 <= fVar10) {
                    fVar10 = fVar12;
                }
                if (fVar8 <= fVar9) {
                    fVar9 = fVar8;
                }
                fcn.180086750(fVar8, fVar9, fVar10, fVar11);
                return 1;
            }
            fcn.180088380(fVar8, 3, 0x18063ee10);
            pcVar2 = (code *)swi(3);
            uVar4 = (*pcVar2)();
            return uVar4;
        }
        fcn.180088380(fVar8, 3, 0x18063ede0);
        pcVar2 = (code *)swi(3);
        uVar4 = (*pcVar2)();
        return uVar4;
    }
    fcn.180088470(arg1, 3, 5);
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
}

// ============================================================
// Function: FUN_1800a5630
// Address: 0x1800a5630
// Size: 201 bytes
// ============================================================
undefined8 fcn.1800a5630(int64_t arg1)
{
    code *pcVar1;
    float *pfVar2;
    float *pfVar3;
    undefined8 uVar4;
    float *pfVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    
    pfVar3 = *(float **)(arg1 + 0x28);
    pfVar2 = pfVar3;
    if (*(float **)(arg1 + 0x40) <= pfVar3) {
        pfVar2 = *(float **)0x180782430;
    }
    pfVar5 = (float *)0x0;
    if (pfVar2[3] == 7.006492e-45) {
        pfVar5 = pfVar2;
    }
    if (pfVar5 != (float *)0x0) {
        fVar9 = *pfVar5;
        fVar10 = pfVar5[1];
        uVar7 = 2;
        fVar11 = pfVar5[2];
        iVar8 = (int64_t)*(float **)(arg1 + 0x40) - (int64_t)pfVar3 >> 4;
        if (1 < (int32_t)iVar8) {
            do {
                pfVar3 = (float *)func_0x000180086200(arg1, uVar7);
                if (pfVar3 == (float *)0x0) {
                    fcn.180088470(arg1, uVar7 & 0xffffffff, 5);
                    pcVar1 = (code *)swi(3);
                    uVar4 = (*pcVar1)();
                    return uVar4;
                }
                if (*pfVar3 < fVar9) {
                    fVar9 = *pfVar3;
                }
                if (pfVar3[1] < fVar10) {
                    fVar10 = pfVar3[1];
                }
                if (pfVar3[2] < fVar11) {
                    fVar11 = pfVar3[2];
                }
                uVar6 = (int32_t)uVar7 + 1;
                uVar7 = (uint64_t)uVar6;
            } while ((int32_t)uVar6 <= (int32_t)iVar8);
        }
        fcn.180086750(arg1);
        return 1;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_1800a5700
// Address: 0x1800a5700
// Size: 201 bytes
// ============================================================
undefined8 fcn.1800a5700(int64_t arg1)
{
    code *pcVar1;
    float *pfVar2;
    float *pfVar3;
    undefined8 uVar4;
    float *pfVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    
    pfVar3 = *(float **)(arg1 + 0x28);
    pfVar2 = pfVar3;
    if (*(float **)(arg1 + 0x40) <= pfVar3) {
        pfVar2 = *(float **)0x180782430;
    }
    pfVar5 = (float *)0x0;
    if (pfVar2[3] == 7.006492e-45) {
        pfVar5 = pfVar2;
    }
    if (pfVar5 != (float *)0x0) {
        fVar9 = *pfVar5;
        fVar10 = pfVar5[1];
        uVar7 = 2;
        fVar11 = pfVar5[2];
        iVar8 = (int64_t)*(float **)(arg1 + 0x40) - (int64_t)pfVar3 >> 4;
        if (1 < (int32_t)iVar8) {
            do {
                pfVar3 = (float *)func_0x000180086200(arg1, uVar7);
                if (pfVar3 == (float *)0x0) {
                    fcn.180088470(arg1, uVar7 & 0xffffffff, 5);
                    pcVar1 = (code *)swi(3);
                    uVar4 = (*pcVar1)();
                    return uVar4;
                }
                if (fVar9 < *pfVar3) {
                    fVar9 = *pfVar3;
                }
                if (fVar10 < pfVar3[1]) {
                    fVar10 = pfVar3[1];
                }
                if (fVar11 < pfVar3[2]) {
                    fVar11 = pfVar3[2];
                }
                uVar6 = (int32_t)uVar7 + 1;
                uVar7 = (uint64_t)uVar6;
            } while ((int32_t)uVar6 <= (int32_t)iVar8);
        }
        fcn.180086750(arg1);
        return 1;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_1800a57d0
// Address: 0x1800a57d0
// Size: 292 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800a57d0(int64_t arg1)
{
    char *pcVar1;
    int64_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t var_8h;
    
    piVar2 = *(int64_t **)(arg1 + 0x28);
    piVar7 = piVar2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    piVar8 = (int64_t *)0x0;
    if (*(int32_t *)((int64_t)piVar7 + 0xc) == 5) {
        piVar8 = piVar7;
    }
    if (piVar8 == (int64_t *)0x0) {
        fcn.180088470(arg1, 1, 5);
        pcVar3 = (code *)swi(3);
        uVar5 = (*pcVar3)();
        return uVar5;
    }
    piVar7 = piVar2 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar2 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800a58e0;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    pcVar1 = (char *)(*piVar7 + 0x18);
    if (pcVar1 != (char *)0x0) {
        if ((*(int32_t *)(*piVar7 + 0x14) == 1) && (uVar6 = (int32_t)*pcVar1 | 0x20, uVar6 - 0x78 < 3)) {
            func_0x000180086570(arg1, (double)*(float *)((int64_t)piVar8 + (int64_t)(int32_t)uVar6 * 4 + -0x1e0));
            return 1;
        }
        fcn.180088560(arg1, 0x18063ee50);
        pcVar3 = (code *)swi(3);
        uVar5 = (*pcVar3)();
        return uVar5;
    }
code_r0x0001800a58e0:
    fcn.180088470(arg1, 2, 6);
    pcVar3 = (code *)swi(3);
    uVar5 = (*pcVar3)();
    return uVar5;
}

// ============================================================
// Function: FUN_1800a5900
// Address: 0x1800a5900
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a5900(int64_t arg1)
{
    code *pcVar1;
    float *pfVar2;
    undefined8 uVar3;
    float *pfVar4;
    float *pfVar5;
    double dVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    pfVar5 = *(float **)(arg1 + 0x28);
    pfVar2 = pfVar5;
    if (*(float **)(arg1 + 0x40) <= pfVar5) {
        pfVar2 = *(float **)0x180782430;
    }
    pfVar4 = (float *)0x0;
    if (pfVar2[3] == 7.006492e-45) {
        pfVar4 = pfVar2;
    }
    if (pfVar4 != (float *)0x0) {
        pfVar2 = pfVar5 + 4;
        if (*(float **)(arg1 + 0x40) <= pfVar5 + 4) {
            pfVar2 = *(float **)0x180782430;
        }
        pfVar5 = (float *)0x0;
        if (pfVar2[3] == 7.006492e-45) {
            pfVar5 = pfVar2;
        }
        if (pfVar5 != (float *)0x0) {
            dVar6 = (double)func_0x000180085ea0(arg1, 3, &var_8h);
            if ((int32_t)var_8h != 0) {
                fVar9 = pfVar5[2];
                fVar10 = (float)dVar6;
                if (fVar10 != 1.0) {
                    fVar9 = (fVar9 - pfVar4[2]) * fVar10 + pfVar4[2];
                }
                fVar8 = pfVar5[1];
                if (fVar10 != 1.0) {
                    fVar8 = (fVar8 - pfVar4[1]) * fVar10 + pfVar4[1];
                }
                fVar7 = *pfVar5;
                if (fVar10 != 1.0) {
                    fVar7 = (fVar7 - *pfVar4) * fVar10 + *pfVar4;
                }
                fcn.180086750(arg1, fVar7, fVar8, fVar9);
                return 1;
            }
            fcn.180088470(arg1, 3, 3);
            pcVar1 = (code *)swi(3);
            uVar3 = (*pcVar1)();
            return uVar3;
        }
        fcn.180088470(arg1, 2, 5);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a593d
// Address: 0x1800a593d
// Size: 179 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a5900(int64_t arg1)
{
    code *pcVar1;
    float *pfVar2;
    undefined8 uVar3;
    float *pfVar4;
    float *pfVar5;
    double dVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    pfVar5 = *(float **)(arg1 + 0x28);
    pfVar2 = pfVar5;
    if (*(float **)(arg1 + 0x40) <= pfVar5) {
        pfVar2 = *(float **)0x180782430;
    }
    pfVar4 = (float *)0x0;
    if (pfVar2[3] == 7.006492e-45) {
        pfVar4 = pfVar2;
    }
    if (pfVar4 != (float *)0x0) {
        pfVar2 = pfVar5 + 4;
        if (*(float **)(arg1 + 0x40) <= pfVar5 + 4) {
            pfVar2 = *(float **)0x180782430;
        }
        pfVar5 = (float *)0x0;
        if (pfVar2[3] == 7.006492e-45) {
            pfVar5 = pfVar2;
        }
        if (pfVar5 != (float *)0x0) {
            dVar6 = (double)func_0x000180085ea0(arg1, 3, &var_8h);
            if ((int32_t)var_8h != 0) {
                fVar9 = pfVar5[2];
                fVar10 = (float)dVar6;
                if (fVar10 != 1.0) {
                    fVar9 = (fVar9 - pfVar4[2]) * fVar10 + pfVar4[2];
                }
                fVar8 = pfVar5[1];
                if (fVar10 != 1.0) {
                    fVar8 = (fVar8 - pfVar4[1]) * fVar10 + pfVar4[1];
                }
                fVar7 = *pfVar5;
                if (fVar10 != 1.0) {
                    fVar7 = (fVar7 - *pfVar4) * fVar10 + *pfVar4;
                }
                fcn.180086750(arg1, fVar7, fVar8, fVar9);
                return 1;
            }
            fcn.180088470(arg1, 3, 3);
            pcVar1 = (code *)swi(3);
            uVar3 = (*pcVar1)();
            return uVar3;
        }
        fcn.180088470(arg1, 2, 5);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a59f0
// Address: 0x1800a59f0
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a5900(int64_t arg1)
{
    code *pcVar1;
    float *pfVar2;
    undefined8 uVar3;
    float *pfVar4;
    float *pfVar5;
    double dVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    pfVar5 = *(float **)(arg1 + 0x28);
    pfVar2 = pfVar5;
    if (*(float **)(arg1 + 0x40) <= pfVar5) {
        pfVar2 = *(float **)0x180782430;
    }
    pfVar4 = (float *)0x0;
    if (pfVar2[3] == 7.006492e-45) {
        pfVar4 = pfVar2;
    }
    if (pfVar4 != (float *)0x0) {
        pfVar2 = pfVar5 + 4;
        if (*(float **)(arg1 + 0x40) <= pfVar5 + 4) {
            pfVar2 = *(float **)0x180782430;
        }
        pfVar5 = (float *)0x0;
        if (pfVar2[3] == 7.006492e-45) {
            pfVar5 = pfVar2;
        }
        if (pfVar5 != (float *)0x0) {
            dVar6 = (double)func_0x000180085ea0(arg1, 3, &var_8h);
            if ((int32_t)var_8h != 0) {
                fVar9 = pfVar5[2];
                fVar10 = (float)dVar6;
                if (fVar10 != 1.0) {
                    fVar9 = (fVar9 - pfVar4[2]) * fVar10 + pfVar4[2];
                }
                fVar8 = pfVar5[1];
                if (fVar10 != 1.0) {
                    fVar8 = (fVar8 - pfVar4[1]) * fVar10 + pfVar4[1];
                }
                fVar7 = *pfVar5;
                if (fVar10 != 1.0) {
                    fVar7 = (fVar7 - *pfVar4) * fVar10 + *pfVar4;
                }
                fcn.180086750(arg1, fVar7, fVar8, fVar9);
                return 1;
            }
            fcn.180088470(arg1, 3, 3);
            pcVar1 = (code *)swi(3);
            uVar3 = (*pcVar1)();
            return uVar3;
        }
        fcn.180088470(arg1, 2, 5);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a5a04
// Address: 0x1800a5a04
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800a5900(int64_t arg1)
{
    code *pcVar1;
    float *pfVar2;
    undefined8 uVar3;
    float *pfVar4;
    float *pfVar5;
    double dVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    pfVar5 = *(float **)(arg1 + 0x28);
    pfVar2 = pfVar5;
    if (*(float **)(arg1 + 0x40) <= pfVar5) {
        pfVar2 = *(float **)0x180782430;
    }
    pfVar4 = (float *)0x0;
    if (pfVar2[3] == 7.006492e-45) {
        pfVar4 = pfVar2;
    }
    if (pfVar4 != (float *)0x0) {
        pfVar2 = pfVar5 + 4;
        if (*(float **)(arg1 + 0x40) <= pfVar5 + 4) {
            pfVar2 = *(float **)0x180782430;
        }
        pfVar5 = (float *)0x0;
        if (pfVar2[3] == 7.006492e-45) {
            pfVar5 = pfVar2;
        }
        if (pfVar5 != (float *)0x0) {
            dVar6 = (double)func_0x000180085ea0(arg1, 3, &var_8h);
            if ((int32_t)var_8h != 0) {
                fVar9 = pfVar5[2];
                fVar10 = (float)dVar6;
                if (fVar10 != 1.0) {
                    fVar9 = (fVar9 - pfVar4[2]) * fVar10 + pfVar4[2];
                }
                fVar8 = pfVar5[1];
                if (fVar10 != 1.0) {
                    fVar8 = (fVar8 - pfVar4[1]) * fVar10 + pfVar4[1];
                }
                fVar7 = *pfVar5;
                if (fVar10 != 1.0) {
                    fVar7 = (fVar7 - *pfVar4) * fVar10 + *pfVar4;
                }
                fcn.180086750(arg1, fVar7, fVar8, fVar9);
                return 1;
            }
            fcn.180088470(arg1, 3, 3);
            pcVar1 = (code *)swi(3);
            uVar3 = (*pcVar1)();
            return uVar3;
        }
        fcn.180088470(arg1, 2, 5);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    fcn.180088470(arg1, 1, 5);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a5a30
// Address: 0x1800a5a30
// Size: 907 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.1800a5a30(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined8 uVar5;
    undefined4 *puVar6;
    int32_t iVar7;
    int64_t unaff_RDI;
    undefined8 *puVar8;
    int64_t var_38h;
    
    puVar8 = (undefined8 *)0x180612e50;
    iVar7 = 0;
    piVar2 = (int64_t *)0x180612e50;
    do {
        iVar7 = iVar7 + 1;
        piVar2 = piVar2 + 2;
    } while (*piVar2 != 0);
    func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
    func_0x000180086cc0(arg1, 0xffffffff, 0x18063e1a8);
    iVar3 = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((iVar3 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
        *(int64_t *)(arg1 + 0x40) = iVar3;
        iVar3 = func_0x000180088ce0(arg1, 0xffffd8ee, 0x18063e1a8, iVar7);
        if (iVar3 != 0) {
            fcn.180088560(arg1, 0x18063da68, 0x18063e1a8);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar7 = fcn.180085510(unaff_RDI), iVar7 == 0)) goto code_r0x0001800a5da3;
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        *puVar4 = puVar4[-4];
        puVar4[1] = puVar4[-3];
        puVar4[2] = puVar4[-2];
        puVar4[3] = puVar4[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffd, 0x18063e1a8);
    }
    puVar6 = *(undefined4 **)(arg1 + 0x40);
    puVar4 = puVar6 + -4;
    if (puVar4 < puVar6) {
        do {
            puVar4[-4] = *puVar4;
            puVar4[-3] = puVar4[1];
            puVar4[-2] = puVar4[2];
            puVar4[-1] = puVar4[3];
            puVar6 = *(undefined4 **)(arg1 + 0x40);
            puVar4 = puVar4 + 4;
        } while (puVar4 < puVar6);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar6 + -4;
    iVar3 = 0x18063c32c;
    do {
        func_0x0001800869f0(arg1, puVar8[1], iVar3, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, *puVar8);
        iVar3 = puVar8[2];
        puVar8 = puVar8 + 2;
    } while (iVar3 != 0);
    fcn.180086750(arg1, 0, 0, 0);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063cc38);
    fcn.180086750(arg1, 0x3f800000, 0x3f800000, 0x3f800000);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063c87c);
    func_0x000180086fd0(arg1, 0, 1);
    fcn.180086750(arg1, 0, 0, 0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar7 = fcn.180085510(unaff_RDI), iVar7 != 0)) {
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        *puVar4 = puVar4[-8];
        puVar4[1] = puVar4[-7];
        puVar4[2] = puVar4[-6];
        puVar4[3] = puVar4[-5];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087650(arg1, 0xfffffffe);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar7 = fcn.180085510(unaff_RDI), iVar7 != 0)) {
            if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x78)) {
                uVar5 = *(undefined8 *)(arg1 + 0x58);
            } else {
                uVar5 = *(undefined8 *)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x10);
            }
            iVar3 = func_0x0001800942b0(arg1, 0, uVar5);
            *(code **)(iVar3 + 0x20) = fcn.1800a57d0;
            *(int64_t *)(iVar3 + 0x28) = -(iVar3 + 0x28);
            *(int64_t *)(iVar3 + 0x30) = iVar3 + 0x30;
            piVar2 = *(int64_t **)(arg1 + 0x40);
            *(int64_t **)(arg1 + 0x40) = piVar2;
            *piVar2 = iVar3;
            *(undefined4 *)((int64_t)piVar2 + 0xc) = 8;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087370(arg1, 0xfffffffe, 0x1805aae90);
            *(undefined *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 4) = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            return 1;
        }
    }
code_r0x0001800a5da3:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar1 = (code *)swi(3);
    uVar5 = (*pcVar1)();
    return uVar5;
}

// ============================================================
// Function: FUN_1800a5dc0
// Address: 0x1800a5dc0
// Size: 473 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800a5dc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    int64_t var_20h;
    undefined auStack_1b8 [32];
    int64_t var_198h;
    int64_t var_188h;
    int64_t var_164h;
    int64_t var_158h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1b8;
    iVar2 = *(int64_t *)(arg1 + 0x38);
    piVar3 = *(int64_t **)(arg1 + 0x18);
    iVar4 = *(int64_t *)(arg1 + 0x28);
    iVar5 = *(int64_t *)(arg1 + 0x40);
    cVar1 = *(char *)(arg1 + 3);
    iVar6 = *piVar3;
    if ((cVar1 == '\x01') || (cVar1 == '\x06')) {
        *(undefined *)(arg1 + 3) = 0;
        *(int64_t *)(arg1 + 0x28) = piVar3[2];
    }
    iVar7 = piVar3[3];
    iVar8 = *(int64_t *)piVar3[1];
    if ((iVar7 != 0) &&
       (iVar7 != *(int64_t *)(*(int64_t *)(iVar8 + 0x20) + 0x40) +
                 (int64_t)*(int32_t *)(*(int64_t *)(iVar8 + 0x20) + 0x9c) * 4)) {
        piVar3[3] = iVar7 + 4;
    }
    var_198h = arg3;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x141) {
        iVar10 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar11 = iVar10 * 2;
        if (iVar10 < 0x14) {
            iVar11 = iVar10 + 0x14;
        }
        func_0x000180093240(arg1, iVar11, 0);
    }
    **(int64_t **)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x40) + 0x140;
    if (*(char *)(iVar8 + 3) == '\0') {
        iVar8 = *(int64_t *)(iVar8 + 0x20);
        iVar9 = *(int64_t *)(*(int64_t *)(arg1 + 0x18) + 0x18);
        if ((iVar9 == 0) || (iVar9 == *(int64_t *)(iVar8 + 0x40))) {
            iVar11 = 0;
        } else {
            iVar11 = (int32_t)(iVar9 - *(int64_t *)(iVar8 + 0x40) >> 2) + -1;
        }
        if (*(int64_t *)(iVar8 + 0x50) == iVar8 + 0x50) {
            var_164h._0_4_ = 0;
        } else {
            var_164h._0_4_ =
                 (uint32_t)*(uint8_t *)((*(int64_t *)(iVar8 + 0x50) - iVar8) + -0x50 + (int64_t)iVar11) +
                 *(int32_t *)
                  ((((int64_t)iVar11 >> ((uint8_t)*(undefined4 *)(iVar8 + 0xa4) & 0x3f)) * 4 -
                   *(int64_t *)(iVar8 + 0x60)) + 0x60 + iVar8);
        }
    } else {
        var_164h._0_4_ = -1;
    }
    var_158h = var_198h;
    (*(code *)arg2)(arg1, &var_188h);
    *(int64_t *)(*(int64_t *)(arg1 + 0x18) + 0x18) = iVar7;
    **(int64_t **)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x38) + (iVar6 - iVar2);
    *(int64_t *)(arg1 + 0x40) = (iVar5 - iVar2) + *(int64_t *)(arg1 + 0x38);
    if (cVar1 == '\x01') {
        if (*(char *)(arg1 + 3) == '\x01') goto code_r0x0001800a5f6e;
        *(undefined *)(arg1 + 3) = 1;
    } else {
        if (cVar1 != '\x06') goto code_r0x0001800a5f6e;
        *(undefined *)(arg1 + 3) = 6;
    }
    *(int64_t *)(arg1 + 0x28) = (iVar4 - iVar2) + *(int64_t *)(arg1 + 0x38);
code_r0x0001800a5f6e:
    fcn.180459870(var_48h ^ (uint64_t)auStack_1b8);
    return;
}

// ============================================================
// Function: FUN_1800a5fa0
// Address: 0x1800a5fa0
// Size: 448 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_3h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

undefined8 fcn.1800a5fa0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    undefined4 *puVar14;
    int64_t var_5h;
    int64_t var_20h;
    
    uVar10 = arg3 & 0xffffffff;
    if (*(int32_t *)(arg2 + 0xc) != 8) {
        func_0x0001800a8df0();
    }
    iVar2 = *(int64_t *)arg2;
    if (*(int64_t *)(arg1 + 0x18) == *(int64_t *)(arg1 + 0x70)) {
        puVar9 = (uint64_t *)func_0x0001800934d0(arg1);
    } else {
        puVar9 = (uint64_t *)(*(int64_t *)(arg1 + 0x18) + 0x28);
        *(uint64_t **)(arg1 + 0x18) = puVar9;
    }
    puVar9[1] = arg2;
    puVar9[2] = arg2 + 0x10;
    *puVar9 = (uint64_t)*(uint8_t *)(iVar2 + 5) * 0x10 + *(int64_t *)(arg1 + 0x40);
    puVar9[3] = 0;
    *(undefined4 *)((int64_t)puVar9 + 0x24) = 0;
    *(int32_t *)(puVar9 + 4) = (int32_t)arg3;
    if (*(char *)0x180777df8 != '\0') {
        *(int64_t *)(iVar2 + 8) = *(int64_t *)(iVar2 + 8) + 1;
    }
    *(uint64_t *)(arg1 + 0x28) = puVar9[2];
    uVar1 = *(uint8_t *)(iVar2 + 5);
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) <= (int64_t)((uint64_t)uVar1 * 0x10)) {
        uVar11 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar8 = uVar11 * 2;
        if (uVar1 != uVar11 && (int32_t)uVar11 <= (int32_t)(uint32_t)uVar1) {
            iVar8 = uVar11 + uVar1;
        }
        func_0x000180093240(arg1, iVar8, 1);
    }
    if (*(char *)(iVar2 + 3) == '\0') {
        iVar2 = *(int64_t *)(iVar2 + 0x20);
        uVar1 = *(uint8_t *)(iVar2 + 5);
        iVar3 = *(int64_t *)(arg1 + 0x28);
        for (uVar10 = *(uint64_t *)(arg1 + 0x40); uVar10 < (uint64_t)uVar1 * 0x10 + iVar3; uVar10 = uVar10 + 0x10) {
            *(undefined4 *)(uVar10 + 0xc) = 0;
        }
        if (*(char *)(iVar2 + 4) == '\0') {
            uVar10 = *puVar9;
        }
        *(uint64_t *)(arg1 + 0x40) = uVar10;
        puVar9[3] = *(uint64_t *)(iVar2 + 0x40);
        if ((*(int64_t *)(iVar2 + 0x78) != 0) && (*(int64_t *)(iVar2 + 0x70) != 0)) {
            *(undefined4 *)((int64_t)puVar9 + 0x24) = 4;
        }
        return 0;
    }
    iVar8 = (**(code **)(iVar2 + 0x20))(arg1);
    if (iVar8 < 0) {
        return 2;
    }
    iVar3 = *(int64_t *)(arg1 + 0x18);
    if (*(char *)0x180777df8 != '\0') {
        *(int64_t *)(iVar2 + 8) = *(int64_t *)(iVar2 + 8) + -1;
    }
    puVar4 = *(undefined4 **)(arg1 + 0x40);
    puVar13 = *(undefined4 **)(iVar3 + 8);
    puVar12 = puVar13;
    puVar14 = puVar4 + (int64_t)iVar8 * -4;
    if ((int32_t)arg3 != 0) {
        do {
            puVar13 = puVar12;
            if (puVar4 <= puVar14) break;
            puVar13 = puVar12 + 4;
            uVar5 = puVar14[1];
            uVar6 = puVar14[2];
            uVar7 = puVar14[3];
            *puVar12 = *puVar14;
            puVar12[1] = uVar5;
            puVar12[2] = uVar6;
            puVar12[3] = uVar7;
            uVar11 = (int32_t)uVar10 - 1;
            uVar10 = (uint64_t)uVar11;
            puVar12 = puVar13;
            puVar14 = puVar14 + 4;
        } while (uVar11 != 0);
        uVar11 = (uint32_t)uVar10;
        while (0 < (int32_t)uVar11) {
            puVar13[3] = 0;
            uVar11 = (int32_t)uVar10 - 1;
            uVar10 = (uint64_t)uVar11;
            puVar13 = puVar13 + 4;
        }
    }
    *(int64_t *)(arg1 + 0x18) = iVar3 + -0x28;
    *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(iVar3 + -0x18);
    *(undefined4 **)(arg1 + 0x40) = puVar13;
    return 1;
}

// ============================================================
// Function: FUN_1800a6160
// Address: 0x1800a6160
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800a6160(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    undefined4 *puVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = *(int64_t *)(arg1 + 0x18);
    if (*(char *)0x180777df8 != '\0') {
        piVar1 = (int64_t *)(**(int64_t **)(iVar2 + 8) + 8);
        *piVar1 = *piVar1 + -1;
    }
    iVar9 = *(int32_t *)(iVar2 + 0x20);
    puVar8 = *(undefined4 **)(iVar2 + 8);
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    puVar7 = puVar8;
    if (iVar9 != 0) {
        do {
            puVar8 = puVar7;
            if (puVar3 <= (uint64_t)arg2) break;
            puVar8 = puVar7 + 4;
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            *puVar7 = *(undefined4 *)arg2;
            puVar7[1] = uVar4;
            puVar7[2] = uVar5;
            puVar7[3] = uVar6;
            iVar9 = iVar9 + -1;
            puVar7 = puVar8;
            arg2 = (int64_t)(arg2 + 0x10);
        } while (iVar9 != 0);
        for (; 0 < iVar9; iVar9 = iVar9 + -1) {
            puVar8[3] = 0;
            puVar8 = puVar8 + 4;
        }
    }
    *(undefined8 **)(arg1 + 0x18) = (undefined8 *)(iVar2 + -0x28);
    *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(iVar2 + -0x18);
    if (*(int32_t *)(iVar2 + 0x20) != -1) {
        puVar8 = *(undefined4 **)(undefined8 *)(iVar2 + -0x28);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar8;
    return;
}

// ============================================================
// Function: FUN_1800a6220
// Address: 0x1800a6220
// Size: 779 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

void fcn.1800a6220(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    uint8_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    int64_t *piVar8;
    double *pdVar9;
    int32_t iVar10;
    uint32_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    uint32_t uVar14;
    int64_t *piVar15;
    int64_t iVar16;
    int32_t iVar17;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    undefined4 var_44h;
    int64_t var_40h;
    int64_t var_38h;
    
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&var_98h;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar10 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar17 = iVar10 * 2;
        if (iVar10 < 1) {
            iVar17 = iVar10 + 1;
        }
        func_0x000180093240(arg1, iVar17, 0);
    }
    var_44h = 7;
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    *(undefined4 **)(arg1 + 0x40) = puVar2 + 4;
    var_68h = (int64_t)*(uint32_t *)(arg2 + 8);
    var_60h = *(int64_t *)arg2;
    var_58h = *(int64_t *)(arg1 + 0x38);
    iVar16 = (uint64_t)(*(uint32_t *)(arg2 + 8) >> 0x14 & 0x3ff) * 0x10 + var_60h;
    iVar17 = 0;
    var_50h = *(int64_t *)(arg1 + 0x58);
    piVar15 = &var_50h;
    do {
        iVar10 = *(int32_t *)((int64_t)piVar15 + 0xc);
        if (iVar10 == 7) {
            iVar13 = *piVar15;
            puVar7 = (undefined4 *)func_0x0001800a0ea0(iVar13, iVar16);
            if (puVar7 != *(undefined4 **)0x180782430) {
                *(int32_t *)(arg1 + 0x6c) = (int32_t)((int64_t)puVar7 - *(int64_t *)(iVar13 + 0x28) >> 5);
            }
            if (((puVar7[3] == 0) && (iVar13 = *(int64_t *)(iVar13 + 0x10), iVar13 != 0)) &&
               (uVar1 = *(uint8_t *)(iVar13 + 5), (uVar1 & 1) == 0)) {
                piVar8 = (int64_t *)fcn.1800a0e30(iVar13, *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x328));
                if (*(int32_t *)((int64_t)piVar8 + 0xc) == 0) {
                    *(uint8_t *)(iVar13 + 5) = uVar1 | 1;
                } else if (piVar8 != (int64_t *)0x0) goto code_r0x0001800a6381;
            }
            uVar4 = puVar7[1];
            uVar5 = puVar7[2];
            uVar6 = puVar7[3];
            *puVar2 = *puVar7;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
code_r0x0001800a645d:
            iVar13 = var_58h;
            iVar16 = var_60h;
            uVar11 = (uint32_t)var_68h;
            uVar14 = (uint32_t)((uint64_t)var_68h >> 0x1e) & 3;
            if (1 < uVar14) {
                iVar12 = (int64_t)puVar2 + (*(int64_t *)(arg1 + 0x38) - var_58h);
                if (*(int32_t *)(iVar12 + 0xc) != 0) {
                    func_0x0001800a8490(arg1, iVar12, 
                                        (uint64_t)((uint32_t)((var_68h & 0xffffffffU) >> 10) & 0x3ff) * 0x10 + var_60h, 
                                        iVar12);
                    uVar11 = (uint32_t)var_68h;
                }
                if ((2 < uVar14) &&
                   (iVar13 = (int64_t)puVar2 + (*(int64_t *)(arg1 + 0x38) - iVar13), *(int32_t *)(iVar13 + 0xc) != 0)) {
                    func_0x0001800a8490(arg1, iVar13, (uint64_t)(uVar11 & 0x3ff) * 0x10 + iVar16, iVar13);
                }
            }
            fcn.180459870(var_40h ^ (uint64_t)&var_98h);
            return;
        }
        if (*(char *)0x180777db8 != '\0') {
            if (iVar10 == 0xd) {
                iVar13 = *piVar15;
                iVar12 = *(int64_t *)(iVar13 + 0x10);
                pdVar9 = (double *)func_0x0001800a0ea0(*(undefined8 *)(iVar12 + 0x20), iVar16);
                if (*(int32_t *)((int64_t)pdVar9 + 0xc) == 0) goto code_r0x0001800a650c;
                iVar17 = (int32_t)*pdVar9;
                if (iVar17 < *(int32_t *)(iVar12 + 0x40)) {
                    puVar7 = (undefined4 *)((int64_t)iVar17 * 0x10 + *(int64_t *)(iVar13 + 0x20));
                    uVar4 = puVar7[1];
                    uVar5 = puVar7[2];
                    uVar6 = puVar7[3];
                    *puVar2 = *puVar7;
                    puVar2[1] = uVar4;
                    puVar2[2] = uVar5;
                    puVar2[3] = uVar6;
                } else {
                    puVar7 = (undefined4 *)
                             ((int64_t)(iVar17 - *(int32_t *)(iVar12 + 0x40)) * 0x10 + *(int64_t *)(iVar12 + 0x18));
                    uVar4 = puVar7[1];
                    uVar5 = puVar7[2];
                    uVar6 = puVar7[3];
                    *puVar2 = *puVar7;
                    puVar2[1] = uVar4;
                    puVar2[2] = uVar5;
                    puVar2[3] = uVar6;
                }
                goto code_r0x0001800a645d;
            }
            if (iVar10 == 0xc) {
                iVar13 = *piVar15;
                pdVar9 = (double *)func_0x0001800a0ea0(*(undefined8 *)(iVar13 + 0x20), iVar16);
                if (*(int32_t *)((int64_t)pdVar9 + 0xc) != 0) {
                    if (*(int32_t *)(iVar13 + 0x40) <= (int32_t)*pdVar9) {
                        puVar7 = (undefined4 *)
                                 (*(int64_t *)(iVar13 + 0x18) +
                                 (int64_t)((int32_t)*pdVar9 - *(int32_t *)(iVar13 + 0x40)) * 0x10);
                        uVar4 = puVar7[1];
                        uVar5 = puVar7[2];
                        uVar6 = puVar7[3];
                        *puVar2 = *puVar7;
                        puVar2[1] = uVar4;
                        puVar2[2] = uVar5;
                        puVar2[3] = uVar6;
                        goto code_r0x0001800a645d;
                    }
                }
code_r0x0001800a650c:
                func_0x000180092ea0(arg1, piVar15, iVar16);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
        }
        piVar8 = (int64_t *)func_0x0001800a3b10(arg1, piVar15, 0);
        if (*(int32_t *)((int64_t)piVar8 + 0xc) == 0) {
            func_0x000180092e30(arg1, piVar15, iVar16);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
code_r0x0001800a6381:
        if (*(int32_t *)((int64_t)piVar8 + 0xc) == 8) {
            var_78h = iVar16;
            func_0x0001800a83e0(arg1, puVar2, piVar8, piVar15);
            goto code_r0x0001800a645d;
        }
        iVar17 = iVar17 + 1;
        piVar15 = piVar8;
        if (99 < iVar17) {
            fcn.180093000(arg1, 0x18063efc0);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800a6530
// Address: 0x1800a6530
// Size: 6934 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_247h
// WARNING: [rz-ghidra] Detected overlap for variable var_248h
// WARNING: [rz-ghidra] Detected overlap for variable var_21ch
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

void fcn.1800a6530(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    undefined4 *puVar1;
    char *pcVar2;
    int32_t *piVar3;
    code *pcVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined uVar7;
    int16_t iVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    undefined *puVar11;
    uint8_t *puVar12;
    undefined (*pauVar13) [16];
    undefined *puVar14;
    uint8_t uVar15;
    uint8_t uVar16;
    uint64_t uVar17;
    uint64_t uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    undefined8 uVar21;
    uint64_t uVar22;
    int32_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    int64_t iVar26;
    uint32_t uVar27;
    uint32_t *puVar28;
    char cVar29;
    uint64_t uVar30;
    undefined8 uVar31;
    int64_t iVar32;
    uint64_t uVar33;
    uint32_t uVar34;
    int32_t iVar35;
    undefined auStack_278 [32];
    int64_t var_258h;
    int64_t var_250h;
    uint8_t var_248h;
    uint8_t var_247h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1e8h;
    int64_t var_1e0h;
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b8h;
    int64_t var_1b0h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    undefined4 var_194h;
    int64_t var_190h;
    int64_t var_184h;
    undefined8 uStack_178;
    int64_t var_170h;
    undefined8 uStack_168;
    int64_t var_158h;
    int64_t var_58h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_278;
    var_1e8h = arg_28h;
    uVar15 = *(uint8_t *)arg_28h;
    var_247h = uVar15;
    var_240h = arg1;
    var_228h = arg3;
    var_1f8h = arg2;
    if (uVar15 == 0) {
        fcn.180498cd0(arg4);
        uVar9 = func_0x000180099480(&var_158h);
        var_258h = arg_28h + 1;
        func_0x000180086980(arg1, 0x18063efb8, uVar9, (int32_t)arg_30h + -1);
        goto code_r0x0001800a7f91;
    }
    if ((uint8_t)(uVar15 - 3) < 9) {
        if (uVar15 < 4) {
            iVar24 = 1;
            var_248h = 0;
        } else {
            uVar15 = *(uint8_t *)(arg_28h + 1);
            var_248h = uVar15;
            if (2 < (uint8_t)(uVar15 - 1)) {
                fcn.180498cd0(arg4);
                uVar9 = func_0x000180099480(&var_158h);
                var_258h = CONCAT44(var_258h._4_4_, 3);
                uVar31 = 1;
                uVar21 = 0x18063ef60;
                goto code_r0x0001800a7f81;
            }
            iVar24 = 2;
        }
        if ((int32_t)arg_38h == 0) {
            piVar10 = (int64_t *)(arg1 + 0x58);
        } else {
            piVar10 = (int64_t *)fcn.180085430();
        }
        var_1e0h = *piVar10;
        uVar9 = fcn.180498cd0(arg4);
        var_1c0h = fcn.18009a8e0(arg1, arg4, uVar9);
        uVar22 = 0;
        uVar15 = 0;
        do {
            puVar12 = (uint8_t *)(arg_28h + iVar24);
            iVar24 = iVar24 + 1;
            uVar34 = (uint32_t)uVar22 | (*puVar12 & 0x7f) << (uVar15 & 0x1f);
            uVar22 = (uint64_t)uVar34;
            uVar15 = uVar15 + 7;
        } while ((char)*puVar12 < '\0');
        *(int64_t *)arg2 = arg1;
        uVar9 = func_0x000180098670(arg1, uVar22 * 8);
        *(undefined8 *)(arg2 + 8) = uVar9;
        *(uint64_t *)(arg2 + 0x10) = uVar22;
        uVar22 = 0;
        if (uVar34 != 0) {
            do {
                uVar30 = 0;
                uVar15 = 0;
                do {
                    puVar12 = (uint8_t *)(arg_28h + iVar24);
                    iVar24 = iVar24 + 1;
                    uVar30 = (uint64_t)((uint32_t)uVar30 | (*puVar12 & 0x7f) << (uVar15 & 0x1f));
                    uVar15 = uVar15 + 7;
                } while ((char)*puVar12 < '\0');
                uVar9 = fcn.18009a8e0(arg1, arg_28h + iVar24);
                *(undefined8 *)(*(int64_t *)(arg2 + 8) + uVar22 * 8) = uVar9;
                iVar24 = iVar24 + uVar30;
                uVar27 = (int32_t)uVar22 + 1;
                uVar22 = (uint64_t)uVar27;
            } while (uVar27 < uVar34);
        }
        if (var_248h == 3) {
            stack0xfffffffffffffe80 = 0x707070707070707;
            uStack_178 = 0x707070707070707;
            var_170h = 0x707070707070707;
            uStack_168 = 0x707070707070707;
            puVar12 = (uint8_t *)(arg_28h + iVar24);
            iVar24 = iVar24 + 1;
            uVar15 = *puVar12;
            while (uVar15 != 0) {
                uVar34 = 0;
                uVar16 = 0;
                do {
                    iVar26 = iVar24;
                    uVar34 = uVar34 | (*(uint8_t *)(arg_28h + iVar26) & 0x7f) << (uVar16 & 0x1f);
                    uVar16 = uVar16 + 7;
                    iVar24 = iVar26 + 1;
                } while ((char)*(uint8_t *)(arg_28h + iVar26) < '\0');
                if (uVar34 == 0) {
                    iVar24 = 0;
                } else {
                    iVar24 = *(int64_t *)(*(int64_t *)(arg2 + 8) + (uint64_t)(uVar34 - 1) * 8);
                }
                if ((uVar15 - 1 < 0x20) &&
                   (pcVar4 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x588), pcVar4 != (code *)0x0)) {
                    uVar7 = (*pcVar4)(arg1, iVar24 + 0x18);
                    *(undefined *)((int64_t)&var_184h + (uint64_t)uVar15 + 3) = uVar7;
                }
                iVar24 = iVar26 + 2;
                uVar15 = *(uint8_t *)(arg_28h + iVar26 + 1);
            }
        }
        iVar26 = var_228h;
        uVar22 = 0;
        uVar15 = 0;
        do {
            puVar12 = (uint8_t *)(arg_28h + iVar24);
            iVar24 = iVar24 + 1;
            uVar34 = (uint32_t)uVar22 | (*puVar12 & 0x7f) << (uVar15 & 0x1f);
            uVar22 = (uint64_t)uVar34;
            uVar15 = uVar15 + 7;
        } while ((char)*puVar12 < '\0');
        *(int64_t *)var_228h = arg1;
        var_1f0h._0_4_ = uVar34;
        uVar9 = func_0x000180098670(arg1, uVar22 * 8);
        *(undefined8 *)(iVar26 + 8) = uVar9;
        *(uint64_t *)(iVar26 + 0x10) = (uint64_t)uVar34;
        var_208h._0_4_ = 0;
        if (uVar34 != 0) {
            do {
                uVar34 = (uint32_t)var_208h;
                puVar11 = (undefined *)fcn.180098710(arg1, 0xc0, *(undefined *)(arg1 + 4));
                uVar15 = var_248h;
                puVar11[1] = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3;
                puVar11[2] = 0xf;
                *puVar11 = *(undefined *)(arg1 + 4);
                *(undefined4 *)(puVar11 + 3) = 0;
                puVar11[7] = 0;
                *(undefined8 *)(puVar11 + 0x38) = 0;
                *(undefined8 *)(puVar11 + 0x40) = 0;
                *(undefined8 *)(puVar11 + 0x58) = 0;
                *(undefined8 *)(puVar11 + 0x68) = 0;
                *(undefined8 *)(puVar11 + 0x70) = 0;
                *(undefined8 *)(puVar11 + 0x78) = 0;
                *(undefined **)(puVar11 + 0x50) = puVar11 + 0x50;
                *(undefined **)(puVar11 + 0x60) = puVar11 + 0x60;
                *(undefined **)(puVar11 + 0x80) = puVar11 + 0x80;
                *(undefined **)(puVar11 + 8) = puVar11 + 8;
                *(undefined **)(puVar11 + 0x20) = puVar11 + 0x20;
                *(undefined **)(puVar11 + 0x28) = puVar11 + 0x28;
                *(int64_t *)(puVar11 + 0x30) = -0x30 - (int64_t)puVar11;
                *(undefined **)(puVar11 + 0x18) = puVar11 + 0x18;
                *(undefined8 *)(puVar11 + 0x48) = 0;
                *(undefined8 *)(puVar11 + 0x9c) = 0;
                *(undefined8 *)(puVar11 + 0x90) = 0;
                *(undefined8 *)(puVar11 + 0xa4) = 0;
                iVar35 = 0;
                *(undefined4 *)(puVar11 + 0x98) = 0;
                *(undefined8 *)(puVar11 + 0x88) = 0;
                *(undefined8 *)(puVar11 + 0xb0) = 0;
                *(undefined8 *)(puVar11 + 0xb8) = 0;
                *(undefined **)(puVar11 + 0x10) = puVar11 + var_1c0h + 0x10;
                *(uint32_t *)(puVar11 + 0xac) = uVar34;
                iVar23 = *(int32_t *)(*(int64_t *)(arg1 + 0x20) + 0x44f8);
                if (iVar23 != 0) {
                    *(int32_t *)(*(int64_t *)(arg1 + 0x20) + 0x44f8) = iVar23 + 1;
                    iVar35 = iVar23;
                }
                *(int32_t *)(puVar11 + 0xbc) = iVar35;
                puVar11[3] = *(undefined *)(arg_28h + iVar24);
                puVar11[5] = *(undefined *)(arg_28h + 1 + iVar24);
                puVar11[6] = *(undefined *)(arg_28h + 2 + iVar24);
                puVar11[4] = *(undefined *)(arg_28h + 3 + iVar24);
                iVar25 = iVar24 + 4;
                var_218h = (int64_t)puVar11;
                if (3 < var_247h) {
                    iVar25 = iVar24 + 5;
                    puVar11[7] = *(undefined *)(arg_28h + iVar24 + 4);
                    if (var_248h == 1) {
                        uVar27 = 0;
                        uVar34 = uVar27;
                        do {
                            puVar12 = (uint8_t *)(arg_28h + iVar25);
                            iVar25 = iVar25 + 1;
                            uVar27 = uVar27 | (*puVar12 & 0x7f) << ((uint8_t)uVar34 & 0x1f);
                            uVar34 = uVar34 + 7;
                        } while ((char)*puVar12 < '\0');
                        iVar26 = var_228h;
                        if (uVar27 != 0) {
                            uVar34 = (0x7f < uVar27) + 3;
                            iVar23 = uVar34 + uVar27;
                            puVar12 = (uint8_t *)func_0x000180098670(var_240h, iVar23, *puVar11);
                            *(uint8_t **)(puVar11 + 0x30) = puVar12 + (-0x30 - (int64_t)puVar11);
                            *(int32_t *)(puVar11 + 0x88) = iVar23;
                            if (uVar27 < 0x80) {
                                *puVar12 = (uint8_t)uVar27;
                                puVar11[*(int64_t *)(puVar11 + 0x30) + 0x31] = 0;
                                puVar11[*(int64_t *)(puVar11 + 0x30) + 0x32] = 0;
                            } else {
                                *puVar12 = (uint8_t)uVar27 | 0x80;
                                puVar11[*(int64_t *)(puVar11 + 0x30) + 0x31] = (char)(uVar27 >> 7);
                                puVar11[*(int64_t *)(puVar11 + 0x30) + 0x32] = 0;
                                puVar11[*(int64_t *)(puVar11 + 0x30) + 0x33] = 0;
                            }
                            fcn.180498030(puVar11 + (uint64_t)uVar34 + 0x30 + *(int64_t *)(puVar11 + 0x30), 
                                          arg_28h + iVar25, uVar27);
                            iVar25 = iVar25 + (uint64_t)uVar27;
                            iVar26 = var_228h;
                            arg1 = var_240h;
                        }
                    } else if ((uint8_t)(var_248h - 2) < 2) {
                        uVar34 = 0;
                        uVar16 = 0;
                        do {
                            puVar12 = (uint8_t *)(arg_28h + iVar25);
                            iVar25 = iVar25 + 1;
                            uVar34 = uVar34 | (*puVar12 & 0x7f) << (uVar16 & 0x1f);
                            uVar16 = uVar16 + 7;
                        } while ((char)*puVar12 < '\0');
                        iVar26 = var_228h;
                        if (uVar34 != 0) {
                            iVar24 = func_0x000180098670(arg1, uVar34, *puVar11);
                            *(int64_t *)(puVar11 + 0x30) = (iVar24 - (int64_t)puVar11) + -0x30;
                            *(uint32_t *)(puVar11 + 0x88) = uVar34;
                            fcn.180498030(iVar24, arg_28h + iVar25);
                            iVar25 = iVar25 + (uint64_t)uVar34;
                            iVar26 = var_228h;
                            if (uVar15 == 3) {
                                iVar32 = *(int64_t *)(puVar11 + 0x30) + 0x30;
                                iVar24 = 0;
                                uVar34 = 0;
                                uVar15 = 0;
                                do {
                                    iVar6 = iVar24 + iVar32;
                                    iVar24 = iVar24 + 1;
                                    uVar34 = uVar34 | ((uint8_t)puVar11[iVar6] & 0x7f) << (uVar15 & 0x1f);
                                    uVar15 = uVar15 + 7;
                                } while ((char)puVar11[iVar6] < '\0');
                                uVar27 = 0;
                                uVar15 = 0;
                                do {
                                    iVar6 = iVar24 + iVar32;
                                    iVar24 = iVar24 + 1;
                                    uVar27 = uVar27 | ((uint8_t)puVar11[iVar6] & 0x7f) << (uVar15 & 0x1f);
                                    uVar15 = uVar15 + 7;
                                } while ((char)puVar11[iVar6] < '\0');
                                uVar20 = 0;
                                uVar15 = 0;
                                do {
                                    iVar6 = iVar24 + iVar32;
                                    iVar24 = iVar24 + 1;
                                    uVar20 = uVar20 | ((uint8_t)puVar11[iVar6] & 0x7f) << (uVar15 & 0x1f);
                                    uVar15 = uVar15 + 7;
                                } while ((char)puVar11[iVar6] < '\0');
                                if (uVar34 != 0) {
                                    uVar22 = 2;
                                    if (2 < uVar34) {
                                        do {
                                            if ((uint8_t)puVar11[uVar22 + iVar24 + iVar32] - 0x40 < 0x20) {
                                                puVar11[uVar22 + iVar24 + iVar32] =
                                                     *(undefined *)
                                                      ((int64_t)&var_184h +
                                                      (uint64_t)((uint8_t)puVar11[uVar22 + iVar24 + iVar32] - 0x40) + 4)
                                                ;
                                            }
                                            uVar19 = (int32_t)uVar22 + 1;
                                            uVar22 = (uint64_t)uVar19;
                                        } while (uVar19 < uVar34);
                                    }
                                    iVar24 = iVar24 + (uint64_t)uVar34;
                                }
                                if (uVar27 != 0) {
                                    uVar22 = 0;
                                    if (uVar27 != 0) {
                                        do {
                                            if ((uint8_t)puVar11[uVar22 + iVar24 + iVar32] - 0x40 < 0x20) {
                                                puVar11[uVar22 + iVar24 + iVar32] =
                                                     *(undefined *)
                                                      ((int64_t)&var_184h +
                                                      (uint64_t)((uint8_t)puVar11[uVar22 + iVar24 + iVar32] - 0x40) + 4)
                                                ;
                                            }
                                            uVar34 = (int32_t)uVar22 + 1;
                                            uVar22 = (uint64_t)uVar34;
                                        } while (uVar34 < uVar27);
                                    }
                                    iVar24 = iVar24 + (uint64_t)uVar27;
                                }
                                if ((uVar20 != 0) && (uVar34 = 0, uVar20 != 0)) {
                                    do {
                                        if ((int32_t)(char)puVar11[iVar24 + iVar32] - 0x40U < 0x20) {
                                            puVar11[iVar24 + iVar32] =
                                                 *(undefined *)
                                                  ((int64_t)&var_184h +
                                                  (uint64_t)((int32_t)(char)puVar11[iVar24 + iVar32] - 0x40U) + 4);
                                        }
                                        iVar24 = iVar24 + 2;
                                        do {
                                            iVar6 = iVar24 + iVar32;
                                            iVar24 = iVar24 + 1;
                                        } while ((char)puVar11[iVar6] < '\0');
                                        do {
                                            iVar6 = iVar24 + iVar32;
                                            iVar24 = iVar24 + 1;
                                        } while ((char)puVar11[iVar6] < '\0');
                                        uVar34 = uVar34 + 1;
                                    } while (uVar34 < uVar20);
                                }
                            }
                        }
                    }
                }
                uVar20 = 0;
                uVar34 = uVar20;
                uVar27 = uVar20;
                do {
                    puVar12 = (uint8_t *)(arg_28h + iVar25);
                    iVar25 = iVar25 + 1;
                    uVar34 = uVar34 | (*puVar12 & 0x7f) << ((uint8_t)uVar27 & 0x1f);
                    uVar27 = uVar27 + 7;
                } while ((char)*puVar12 < '\0');
                iVar32 = var_240h;
                if (0x3fffffffffffffff < (uint64_t)(int64_t)(int32_t)uVar34) {
code_r0x0001800a7fb9:
                    fcn.180098420(iVar32);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                uVar9 = func_0x000180098670(arg1, (int64_t)(int32_t)uVar34 * 4, *puVar11);
                *(undefined8 *)(puVar11 + 0x40) = uVar9;
                *(uint32_t *)(puVar11 + 0x9c) = uVar34;
                uVar27 = uVar20;
                if (0 < (int32_t)uVar34) {
                    do {
                        puVar1 = (undefined4 *)(arg_28h + iVar25);
                        iVar25 = iVar25 + 4;
                        *(undefined4 *)(*(int64_t *)(puVar11 + 0x40) + (int64_t)(int32_t)uVar27 * 4) = *puVar1;
                        uVar27 = uVar27 + 1;
                    } while ((int32_t)uVar27 < *(int32_t *)(puVar11 + 0x9c));
                }
                *(undefined8 *)(puVar11 + 0x68) = *(undefined8 *)(puVar11 + 0x40);
                uVar34 = uVar20;
                uVar27 = uVar20;
                do {
                    puVar12 = (uint8_t *)(arg_28h + iVar25);
                    iVar25 = iVar25 + 1;
                    uVar27 = uVar27 | (*puVar12 & 0x7f) << ((uint8_t)uVar34 & 0x1f);
                    uVar34 = uVar34 + 7;
                } while ((char)*puVar12 < '\0');
                iVar32 = var_240h;
                var_238h = iVar25;
                if (0xfffffffffffffff < (uint64_t)(int64_t)(int32_t)uVar27) goto code_r0x0001800a7fb9;
                uVar9 = func_0x000180098670(arg1, (int64_t)(int32_t)uVar27 << 4, *puVar11);
                *(undefined8 *)(puVar11 + 0x38) = uVar9;
                *(uint32_t *)(puVar11 + 0xa8) = uVar27;
                if (0 < (int32_t)uVar27) {
                    do {
                        *(undefined4 *)(*(int64_t *)(puVar11 + 0x38) + 0xc + (int64_t)(int32_t)uVar20 * 0x10) = 0;
                        uVar20 = uVar20 + 1;
                    } while ((int32_t)uVar20 < *(int32_t *)(puVar11 + 0xa8));
                    var_230h._0_4_ = 0;
                    iVar24 = iVar25;
                    if (0 < *(int32_t *)(puVar11 + 0xa8)) {
                        do {
                            iVar23 = (int32_t)var_230h;
                            iVar32 = var_240h;
                            uVar22 = 0;
                            iVar25 = iVar24 + 1;
                            var_230h._0_4_ = iVar23;
                            var_238h = iVar25;
    // switch table (10 cases) at 0x1800a7fc4
                            switch(*(undefined *)(arg_28h + iVar24)) {
                            case 1:
                                puVar12 = (uint8_t *)(arg_28h + iVar25);
                                iVar25 = iVar24 + 2;
                                iVar24 = *(int64_t *)(puVar11 + 0x38);
                                *(uint32_t *)(iVar24 + (int64_t)(int32_t)var_230h * 0x10) = (uint32_t)*puVar12;
                                *(undefined4 *)(iVar24 + 0xc + (int64_t)(int32_t)var_230h * 0x10) = 1;
                                var_238h = iVar25;
                                break;
                            case 2:
                                var_210h = *(int64_t *)(arg_28h + iVar25);
                                iVar25 = iVar24 + 9;
                                iVar24 = *(int64_t *)(puVar11 + 0x38);
                                *(int64_t *)(iVar24 + (int64_t)(int32_t)var_230h * 0x10) = var_210h;
                                *(undefined4 *)(iVar24 + 0xc + (int64_t)(int32_t)var_230h * 0x10) = 3;
                                var_238h = iVar25;
                                break;
                            case 3:
                                uVar30 = uVar22;
                                uVar18 = uVar22;
                                do {
                                    puVar12 = (uint8_t *)(arg_28h + iVar25);
                                    iVar25 = iVar25 + 1;
                                    uVar34 = (uint32_t)uVar18 | (*puVar12 & 0x7f) << ((uint8_t)uVar30 & 0x1f);
                                    uVar18 = (uint64_t)uVar34;
                                    uVar30 = (uint64_t)((int32_t)uVar30 + 7);
                                } while ((char)*puVar12 < '\0');
                                if (uVar34 != 0) {
                                    uVar22 = *(uint64_t *)(*(int64_t *)(var_1f8h + 8) + (uint64_t)(uVar34 - 1) * 8);
                                }
                                iVar24 = *(int64_t *)(puVar11 + 0x38);
                                *(uint64_t *)(iVar24 + (int64_t)(int32_t)var_230h * 0x10) = uVar22;
                                *(undefined4 *)(iVar24 + 0xc + (int64_t)(int32_t)var_230h * 0x10) = 6;
                                var_238h = iVar25;
                                break;
                            case 4:
                                var_1a8h._0_4_ = *(undefined4 *)(arg_28h + iVar25);
                                iVar25 = iVar24 + 5;
                                var_1b0h = *(int64_t *)(puVar11 + 0x38);
                                var_238h = iVar25;
                                if (*(char *)(*(int64_t *)(arg1 + 0x58) + 6) == '\0') {
                                    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                                } else {
                                    var_258h = 0;
                                    iVar35 = func_0x000180094080(arg1, fcn.1800a6220, &var_1b0h);
                                    if (iVar35 != 0) {
                                        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + -4) = 0;
                                    }
                                }
                                *(undefined (*) [16])(*(int64_t *)(puVar11 + 0x38) + (int64_t)iVar23 * 0x10) =
                                     *(undefined (*) [16])(*(int64_t *)(arg1 + 0x40) + -0x10);
                                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                                var_230h._0_4_ = iVar23;
                                break;
                            case 5:
                                uVar15 = 0;
                                do {
                                    puVar12 = (uint8_t *)(arg_28h + iVar25);
                                    iVar25 = iVar25 + 1;
                                    uVar34 = (uint32_t)uVar22 | (*puVar12 & 0x7f) << (uVar15 & 0x1f);
                                    uVar22 = (uint64_t)uVar34;
                                    uVar15 = uVar15 + 7;
                                } while ((char)*puVar12 < '\0');
                                var_238h = iVar25;
                                puVar14 = (undefined *)fcn.180098710(arg1, 0x30, *(undefined *)(arg1 + 4));
                                puVar14[1] = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3;
                                puVar14[2] = 7;
                                *puVar14 = *(undefined *)(arg1 + 4);
                                *(undefined8 *)(puVar14 + 0x10) = 0;
                                *(undefined4 *)(puVar14 + 4) = 0xff00;
                                *(undefined8 *)(puVar14 + 0x20) = 0;
                                *(undefined8 *)(puVar14 + 8) = 0;
                                puVar14[3] = 0;
                                *(undefined8 *)(puVar14 + 0x28) = *(undefined8 *)0x1807823c8;
                                if (0 < (int32_t)uVar34) {
                                    func_0x0001800a0320(arg1, puVar14, uVar22);
                                    iVar35 = 0;
                                    do {
                                        uVar27 = 0;
                                        uVar15 = 0;
                                        do {
                                            puVar12 = (uint8_t *)(arg_28h + iVar25);
                                            iVar25 = iVar25 + 1;
                                            uVar27 = uVar27 | (*puVar12 & 0x7f) << (uVar15 & 0x1f);
                                            uVar15 = uVar15 + 7;
                                        } while ((char)*puVar12 < '\0');
                                        var_238h = iVar25;
                                        pauVar13 = (undefined (*) [16])
                                                   func_0x0001800a0ea0(puVar14, (int64_t)(int32_t)uVar27 * 0x10 +
                                                                                *(int64_t *)(puVar11 + 0x38));
                                        puVar14[5] = 0;
                                        if (pauVar13 == *(undefined (**) [16])0x180782430) {
                                            pauVar13 = (undefined (*) [16])func_0x0001800a0f90(var_240h, puVar14);
                                        }
                                        *(undefined8 *)*pauVar13 = 0;
                                        *(undefined4 *)(*pauVar13 + 0xc) = 3;
                                        iVar35 = iVar35 + 1;
                                        arg1 = var_240h;
                                        iVar23 = (int32_t)var_230h;
                                    } while (iVar35 < (int32_t)uVar34);
                                }
                                iVar24 = *(int64_t *)(puVar11 + 0x38);
                                *(undefined **)(iVar24 + (int64_t)iVar23 * 0x10) = puVar14;
                                *(undefined4 *)(iVar24 + 0xc + (int64_t)iVar23 * 0x10) = 7;
                                var_230h._0_4_ = iVar23;
                                break;
                            case 6:
                                uVar30 = uVar22;
                                do {
                                    puVar12 = (uint8_t *)(arg_28h + iVar25);
                                    iVar25 = iVar25 + 1;
                                    uVar30 = (uint64_t)
                                             ((uint32_t)uVar30 | (*puVar12 & 0x7f) << ((uint8_t)uVar22 & 0x1f));
                                    uVar22 = (uint64_t)((int32_t)uVar22 + 7);
                                } while ((char)*puVar12 < '\0');
                                var_238h = iVar25;
                                iVar26 = func_0x000180094210(arg1, *(undefined *)
                                                                    (*(int64_t *)(*(int64_t *)(iVar26 + 8) + uVar30 * 8)
                                                                    + 6), var_1e0h);
                                *(bool *)(iVar26 + 6) = *(char *)(iVar26 + 4) != '\0';
                                iVar24 = *(int64_t *)(puVar11 + 0x38);
                                *(int64_t *)(iVar24 + (int64_t)iVar23 * 0x10) = iVar26;
                                *(undefined4 *)(iVar24 + 0xc + (int64_t)iVar23 * 0x10) = 8;
                                var_230h._0_4_ = iVar23;
                                break;
                            case 7:
                                puVar1 = (undefined4 *)(arg_28h + iVar25);
                                var_220h._0_4_ = *(uint32_t *)(iVar24 + 5 + arg_28h);
                                var_220h._4_4_ = *(uint32_t *)(iVar24 + 9 + arg_28h);
                                iVar25 = iVar24 + 0x11;
                                iVar26 = (int64_t)(int32_t)var_230h;
                                iVar24 = *(int64_t *)(puVar11 + 0x38);
                                *(undefined4 *)(iVar24 + iVar26 * 0x10) = *puVar1;
                                *(uint32_t *)(iVar24 + 4 + iVar26 * 0x10) = (uint32_t)var_220h;
                                *(uint32_t *)(iVar24 + 8 + iVar26 * 0x10) = var_220h._4_4_;
                                *(undefined4 *)(iVar24 + 0xc + iVar26 * 0x10) = 5;
                                var_238h = iVar25;
                                break;
                            case 8:
                                uVar30 = uVar22;
                                do {
                                    puVar12 = (uint8_t *)(arg_28h + iVar25);
                                    iVar25 = iVar25 + 1;
                                    uVar34 = (uint32_t)uVar30 | (*puVar12 & 0x7f) << ((uint8_t)uVar22 & 0x1f);
                                    uVar30 = (uint64_t)uVar34;
                                    uVar22 = (uint64_t)((int32_t)uVar22 + 7);
                                } while ((char)*puVar12 < '\0');
                                var_238h = iVar25;
                                puVar14 = (undefined *)fcn.180098710(var_240h, 0x30, *(undefined *)(var_240h + 4));
                                puVar14[1] = *(uint8_t *)(*(int64_t *)(iVar32 + 0x20) + 0x58) & 3;
                                puVar14[2] = 7;
                                *puVar14 = *(undefined *)(iVar32 + 4);
                                *(undefined8 *)(puVar14 + 0x10) = 0;
                                *(undefined4 *)(puVar14 + 4) = 0xff00;
                                *(undefined8 *)(puVar14 + 0x20) = 0;
                                *(undefined8 *)(puVar14 + 8) = 0;
                                puVar14[3] = 0;
                                *(undefined8 *)(puVar14 + 0x28) = *(undefined8 *)0x1807823c8;
                                if (0 < (int32_t)uVar34) {
                                    func_0x0001800a0320(iVar32, puVar14, uVar34);
                                }
                                var_1d0h = 0;
                                var_1c8h = 0;
                                var_1d8h = iVar32;
                                uVar22 = (uint64_t)uVar34;
                                var_210h = uVar22;
                                var_1d0h = func_0x000180098670(iVar32, uVar30 * 4, 0);
                                var_200h = 0;
                                uVar27 = 0;
                                iVar24 = var_238h;
                                var_1c8h = uVar22;
                                if (uVar34 != 0) {
                                    do {
                                        uVar20 = 0;
                                        uVar15 = 0;
                                        do {
                                            iVar24 = iVar25;
                                            uVar20 = uVar20 | (*(uint8_t *)(arg_28h + iVar24) & 0x7f) << (uVar15 & 0x1f)
                                            ;
                                            uVar15 = uVar15 + 7;
                                            iVar25 = iVar24 + 1;
                                        } while ((char)*(uint8_t *)(arg_28h + iVar24) < '\0');
                                        iVar25 = (int64_t)(int32_t)uVar20 * 0x10 + *(int64_t *)(var_218h + 0x38);
                                        pauVar13 = (undefined (*) [16])func_0x0001800a0ea0(puVar14, iVar25);
                                        iVar26 = var_240h;
                                        puVar14[5] = 0;
                                        if (pauVar13 == *(undefined (**) [16])0x180782430) {
                                            pauVar13 = (undefined (*) [16])
                                                       func_0x0001800a0f90(var_240h, puVar14, iVar25);
                                        }
                                        iVar23 = *(int32_t *)(arg_28h + iVar24 + 1);
                                        iVar32 = (int64_t)iVar23;
                                        iVar25 = iVar24 + 5;
                                        if (iVar23 < 0) {
code_r0x0001800a7222:
                                            *(undefined8 *)*pauVar13 = 0;
                                            *(undefined4 *)(*pauVar13 + 0xc) = 3;
                                        } else {
                                            iVar24 = *(int64_t *)(var_218h + 0x38);
                                            if (*(int32_t *)(iVar24 + 0xc + iVar32 * 0x10) == 0) {
                                                *(uint32_t *)(var_1d0h + var_200h * 4) = uVar20;
                                                var_200h = var_200h + 1;
                                                goto code_r0x0001800a7222;
                                            }
                                            *pauVar13 = *(undefined (*) [16])(iVar24 + iVar32 * 0x10);
                                            if (((5 < *(int32_t *)(iVar24 + 0xc + iVar32 * 0x10)) &&
                                                ((puVar14[1] & 4) != 0)) &&
                                               ((*(uint8_t *)(*(int64_t *)(iVar24 + iVar32 * 0x10) + 1) & 3) != 0)) {
                                                iVar24 = *(int64_t *)(iVar26 + 0x20);
                                                if (*(char *)(iVar24 + 0x59) == '\x02') {
                                                    func_0x000180094420();
                                                } else {
                                                    puVar14[1] = puVar14[1] & 0xfb;
                                                    *(undefined8 *)(puVar14 + 0x18) = *(undefined8 *)(iVar24 + 0x18);
                                                    *(undefined **)(iVar24 + 0x18) = puVar14;
                                                }
                                            }
                                        }
                                        uVar27 = uVar27 + 1;
                                        iVar24 = iVar25;
                                    } while (uVar27 < uVar34);
                                }
                                var_238h = iVar24;
                                iVar32 = var_1d0h;
                                iVar26 = var_200h;
                                puVar11 = (undefined *)var_218h;
                                iVar24 = var_240h;
                                uVar22 = 0;
                                if (var_200h != 0) {
                                    do {
                                        iVar25 = (int64_t)*(int32_t *)(iVar32 + uVar22 * 4) * 0x10 +
                                                 *(int64_t *)((int64_t)puVar11 + 0x38);
                                        pauVar13 = (undefined (*) [16])func_0x0001800a0ea0(puVar14, iVar25);
                                        puVar14[5] = 0;
                                        if (pauVar13 == *(undefined (**) [16])0x180782430) {
                                            pauVar13 = (undefined (*) [16])func_0x0001800a0f90(iVar24, puVar14, iVar25);
                                        }
                                        *(undefined4 *)(*pauVar13 + 0xc) = 0;
                                        uVar22 = uVar22 + 1;
                                        iVar25 = var_238h;
                                        arg_28h = var_1e8h;
                                    } while (uVar22 < (uint64_t)iVar26);
                                }
                                iVar26 = var_210h;
                                arg1 = var_240h;
                                iVar24 = *(int64_t *)((int64_t)puVar11 + 0x38);
                                *(undefined **)(iVar24 + (int64_t)(int32_t)var_230h * 0x10) = puVar14;
                                *(undefined4 *)(iVar24 + 0xc + (int64_t)(int32_t)var_230h * 0x10) = 7;
                                if (var_1d0h != 0) {
                                    iVar24 = var_210h * 4;
                                    iVar32 = *(int64_t *)(var_240h + 0x20);
                                    if ((iVar24 - 1U < 0x400) && (-1 < *(char *)(iVar24 + 0x180777990))) {
                                        func_0x0001800985c0(var_240h, (int32_t)*(char *)(iVar24 + 0x180777990), var_1d0h
                                                           );
                                    } else {
                                        (**(code **)(iVar32 + 0x48))
                                                  (*(undefined8 *)(iVar32 + 0x50), var_1d0h, iVar24, 0);
                                    }
                                    *(int64_t *)(iVar32 + 0x30) = *(int64_t *)(iVar32 + 0x30) + iVar26 * -4;
                                    *(int64_t *)(iVar32 + 0x2c30) = *(int64_t *)(iVar32 + 0x2c30) + iVar26 * -4;
                                }
                                break;
                            case 9:
                                pcVar2 = (char *)(arg_28h + iVar25);
                                iVar25 = iVar24 + 2;
                                uVar30 = uVar22;
                                do {
                                    puVar12 = (uint8_t *)(arg_28h + iVar25);
                                    iVar25 = iVar25 + 1;
                                    uVar30 = uVar30 | (uint64_t)(*puVar12 & 0x7f) << ((uint8_t)uVar22 & 0x3f);
                                    uVar22 = (uint64_t)((int32_t)uVar22 + 7);
                                } while ((char)*puVar12 < '\0');
                                iVar24 = *(int64_t *)(puVar11 + 0x38);
                                if (*pcVar2 != '\0') {
                                    uVar30 = -uVar30;
                                }
                                *(uint64_t *)(iVar24 + (int64_t)(int32_t)var_230h * 0x10) = uVar30;
                                *(undefined4 *)(iVar24 + 0xc + (int64_t)(int32_t)var_230h * 0x10) = 4;
                                var_238h = iVar25;
                                break;
                            case 10:
                                uVar30 = uVar22;
                                uVar18 = uVar22;
                                do {
                                    puVar12 = (uint8_t *)(arg_28h + iVar25);
                                    iVar25 = iVar25 + 1;
                                    uVar18 = (uint64_t)
                                             ((uint32_t)uVar18 | (*puVar12 & 0x7f) << ((uint8_t)uVar30 & 0x1f));
                                    uVar30 = (uint64_t)((int32_t)uVar30 + 7);
                                    uVar17 = uVar22;
                                    uVar33 = uVar22;
                                } while ((char)*puVar12 < '\0');
                                do {
                                    puVar12 = (uint8_t *)(arg_28h + iVar25);
                                    iVar25 = iVar25 + 1;
                                    var_220h._0_4_ = (uint32_t)uVar33 | (*puVar12 & 0x7f) << ((uint8_t)uVar17 & 0x1f);
                                    uVar17 = (uint64_t)((int32_t)uVar17 + 7);
                                    uVar33 = (uint64_t)(uint32_t)var_220h;
                                } while ((char)*puVar12 < '\0');
                                uVar15 = 0;
                                do {
                                    puVar12 = (uint8_t *)(arg_28h + iVar25);
                                    iVar25 = iVar25 + 1;
                                    uVar34 = (uint32_t)uVar22 | (*puVar12 & 0x7f) << (uVar15 & 0x1f);
                                    uVar22 = (uint64_t)uVar34;
                                    uVar15 = uVar15 + 7;
                                } while ((char)*puVar12 < '\0');
                                var_1b8h = uVar18 * 0x10 + *(int64_t *)(puVar11 + 0x38);
                                uVar27 = uVar34 + (uint32_t)var_220h;
                                var_200h = CONCAT44(var_200h._4_4_, uVar27);
                                var_238h = iVar25;
                                var_220h._4_4_ = uVar34;
                                var_210h = func_0x000180098670(arg1, (uint64_t)uVar27 << 3, *(undefined *)(arg1 + 4));
                                puVar11 = (undefined *)fcn.180098710(arg1, 0x30);
                                puVar11[1] = *(uint8_t *)(*(int64_t *)(var_240h + 0x20) + 0x58) & 3;
                                puVar11[2] = 7;
                                *puVar11 = *(undefined *)(var_240h + 4);
                                *(undefined8 *)(puVar11 + 0x10) = 0;
                                *(undefined4 *)(puVar11 + 4) = 0xff00;
                                *(undefined8 *)(puVar11 + 0x20) = 0;
                                *(undefined8 *)(puVar11 + 8) = 0;
                                puVar11[3] = 0;
                                *(undefined8 *)(puVar11 + 0x28) = *(undefined8 *)0x1807823c8;
                                if (0 < (int32_t)uVar27) {
                                    func_0x0001800a0320(var_240h, puVar11);
                                }
                                iVar24 = var_210h;
                                uVar22 = 0;
                                if (uVar27 != 0) {
                                    do {
                                        uVar30 = 0;
                                        uVar15 = 0;
                                        do {
                                            puVar12 = (uint8_t *)(arg_28h + iVar25);
                                            iVar25 = iVar25 + 1;
                                            uVar30 = (uint64_t)((uint32_t)uVar30 | (*puVar12 & 0x7f) << (uVar15 & 0x1f))
                                            ;
                                            uVar15 = uVar15 + 7;
                                        } while ((char)*puVar12 < '\0');
                                        iVar26 = *(int64_t *)(var_218h + 0x38);
                                        *(undefined8 *)(iVar24 + uVar22 * 8) = *(undefined8 *)(iVar26 + uVar30 * 0x10);
                                        iVar26 = *(int64_t *)(iVar26 + uVar30 * 0x10);
                                        var_238h = iVar25;
                                        pauVar13 = (undefined (*) [16])fcn.1800a0e30(puVar11, iVar26);
                                        puVar11[5] = 0;
                                        if (pauVar13 == *(undefined (**) [16])0x180782430) {
                                            var_194h = 6;
                                            var_1a0h = iVar26;
                                            pauVar13 = (undefined (*) [16])func_0x0001800a0a80(var_240h, puVar11);
                                        }
                                        *(double *)*pauVar13 = (double)uVar22;
                                        *(undefined4 *)(*pauVar13 + 0xc) = 3;
                                        uVar20 = (int32_t)uVar22 + 1;
                                        uVar22 = (uint64_t)uVar20;
                                        uVar34 = var_220h._4_4_;
                                    } while (uVar20 < uVar27);
                                }
                                iVar32 = var_240h;
                                puVar11[4] = 1;
                                uVar9 = *(undefined8 *)var_1b8h;
                                puVar14 = (undefined *)fcn.180098710(var_240h, 0x48, *(undefined *)(var_240h + 4));
                                puVar14[1] = *(uint8_t *)(*(int64_t *)(iVar32 + 0x20) + 0x58) & 3;
                                puVar14[2] = 0xc;
                                *puVar14 = *(undefined *)(iVar32 + 4);
                                *(undefined8 *)(puVar14 + 0x10) = uVar9;
                                if (0xfffffffffffffff < (uint64_t)(int64_t)(int32_t)uVar34) goto code_r0x0001800a7fb9;
                                uVar9 = func_0x000180098670(iVar32, (int64_t)(int32_t)uVar34 << 4);
                                arg1 = var_240h;
                                *(undefined8 *)(puVar14 + 0x18) = uVar9;
                                iVar23 = 0;
                                if (0 < (int32_t)uVar34) {
                                    do {
                                        *(undefined4 *)(*(int64_t *)(puVar14 + 0x18) + 0xc + (int64_t)iVar23 * 0x10) = 0
                                        ;
                                        iVar23 = iVar23 + 1;
                                    } while (iVar23 < (int32_t)uVar34);
                                }
                                *(undefined **)(puVar14 + 0x20) = puVar11;
                                *(int64_t *)(puVar14 + 0x28) = var_210h;
                                puVar11 = (undefined *)fcn.180098710(var_240h, 0x30, *(undefined *)(var_240h + 4));
                                puVar11[1] = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3;
                                puVar11[2] = 7;
                                *puVar11 = *(undefined *)(arg1 + 4);
                                *(undefined8 *)(puVar11 + 0x10) = 0;
                                *(undefined4 *)(puVar11 + 4) = 0xff00;
                                *(undefined8 *)(puVar11 + 0x20) = 0;
                                *(undefined8 *)(puVar11 + 8) = 0;
                                puVar11[3] = 0;
                                *(undefined8 *)(puVar11 + 0x28) = *(undefined8 *)0x1807823c8;
                                func_0x0001800a0320(arg1, puVar11, 1);
                                *(undefined **)(puVar14 + 0x30) = puVar11;
                                iVar32 = func_0x0001800942b0(arg1, 0, *(undefined8 *)(arg1 + 0x58));
                                *(undefined8 *)(iVar32 + 0x20) = 0x1800a8e60;
                                *(int64_t *)(iVar32 + 0x30) = iVar32 + -0x18063eff8;
                                *(int64_t *)(iVar32 + 0x28) = -0x28 - iVar32;
                                iVar24 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x348);
                                iVar26 = *(int64_t *)(puVar14 + 0x30);
                                pauVar13 = (undefined (*) [16])fcn.1800a0e30(iVar26, iVar24);
                                *(undefined *)(iVar26 + 5) = 0;
                                if (pauVar13 == *(undefined (**) [16])0x180782430) {
                                    var_184h._0_4_ = 6;
                                    var_190h = iVar24;
                                    pauVar13 = (undefined (*) [16])func_0x0001800a0a80(arg1, iVar26, &var_190h);
                                }
                                *(int64_t *)*pauVar13 = iVar32;
                                *(undefined4 *)(*pauVar13 + 0xc) = 8;
                                *(undefined *)(*(int64_t *)(puVar14 + 0x30) + 4) = 1;
                                *(undefined8 *)(puVar14 + 0x38) = 0;
                                *(uint32_t *)(puVar14 + 0x40) = (uint32_t)var_220h;
                                *(undefined4 *)(puVar14 + 0x44) = (undefined4)var_200h;
                                iVar24 = *(int64_t *)(var_218h + 0x38);
                                *(undefined **)(iVar24 + (int64_t)(int32_t)var_230h * 0x10) = puVar14;
                                *(undefined4 *)(iVar24 + 0xc + (int64_t)(int32_t)var_230h * 0x10) = 0xc;
                                puVar11 = (undefined *)var_218h;
                            }
                            var_230h._0_4_ = (int32_t)var_230h + 1;
                            iVar24 = iVar25;
                            iVar26 = var_228h;
                        } while ((int32_t)var_230h < *(int32_t *)(puVar11 + 0xa8));
                    }
                }
                if ((*(char *)0x180777e38 != '\0') &&
                   (puVar28 = *(uint32_t **)(puVar11 + 0x40), puVar28 < puVar28 + *(int32_t *)(puVar11 + 0x9c))) {
                    do {
                        uVar34 = *puVar28;
                        uVar27 = uVar34 & 0xff;
                        if (uVar27 == 0xf) {
                            uVar27 = 0x53;
code_r0x0001800a7870:
                            if (puVar28[1] < 0x10000) {
                                iVar24 = *(int64_t *)(*(int64_t *)(puVar11 + 0x38) + (uint64_t)puVar28[1] * 0x10);
                                iVar8 = *(int16_t *)(iVar24 + 6);
                                if (iVar8 == -0x8000) {
                                    pcVar4 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x530);
                                    if (pcVar4 == (code *)0x0) {
                                        iVar8 = -1;
                                    } else {
                                        iVar8 = (*pcVar4)(arg1, iVar24 + 0x18, *(undefined4 *)(iVar24 + 0x14));
                                    }
                                    *(int16_t *)(iVar24 + 6) = iVar8;
                                    uVar34 = *puVar28;
                                }
                                if (-1 < iVar8) {
                                    uVar34 = uVar34 & 0xffffff00 | uVar27;
                                    *puVar28 = uVar34;
                                }
                            }
                        } else {
                            if (uVar27 == 0x10) {
                                uVar27 = 0x54;
                                goto code_r0x0001800a7870;
                            }
                            if (uVar27 == 0x14) {
                                uVar27 = 0x55;
                                goto code_r0x0001800a7870;
                            }
                        }
    // switch table (2 cases) at 0x1800a7fec
                        switch(uVar34 & 0xff) {
                        case 7:
                        case 8:
                        case 0xc:
                        case 0xf:
                        case 0x10:
                        case 0x14:
                        case 0x1b:
                        case 0x1c:
                        case 0x1d:
                        case 0x1e:
                        case 0x1f:
                        case 0x20:
                        case 0x35:
                        case 0x37:
                        case 0x3a:
                        case 0x3c:
                        case 0x42:
                        case 0x4a:
                        case 0x4b:
                        case 0x4d:
                        case 0x4e:
                        case 0x4f:
                        case 0x50:
                        case 0x53:
                        case 0x54:
                        case 0x55:
                        case 0x56:
                        case 0x57:
                        case 0x58:
                            iVar24 = 8;
                            break;
                        default:
                            iVar24 = 4;
                        }
                        puVar28 = (uint32_t *)((int64_t)puVar28 + iVar24);
                        iVar25 = var_238h;
                        arg_28h = var_1e8h;
                    } while (puVar28 < (uint32_t *)
                                       (*(int64_t *)(puVar11 + 0x40) + (int64_t)*(int32_t *)(puVar11 + 0x9c) * 4));
                }
                uVar22 = 0;
                uVar30 = uVar22;
                uVar18 = uVar22;
                do {
                    puVar12 = (uint8_t *)(arg_28h + iVar25);
                    iVar25 = iVar25 + 1;
                    uVar34 = (uint32_t)uVar18 | (*puVar12 & 0x7f) << ((uint8_t)uVar30 & 0x1f);
                    uVar18 = (uint64_t)uVar34;
                    uVar30 = (uint64_t)((int32_t)uVar30 + 7);
                } while ((char)*puVar12 < '\0');
                iVar32 = var_240h;
                if (0x1fffffffffffffff < (uint64_t)(int64_t)(int32_t)uVar34) goto code_r0x0001800a7fb9;
                uVar9 = func_0x000180098670(arg1, (int64_t)(int32_t)uVar34 * 8, *puVar11);
                *(undefined8 *)(puVar11 + 0x58) = uVar9;
                *(uint32_t *)(puVar11 + 0xa0) = uVar34;
                uVar30 = uVar22;
                uVar18 = uVar22;
                uVar17 = uVar22;
                uVar33 = uVar22;
                if (0 < (int32_t)uVar34) {
                    do {
                        do {
                            puVar12 = (uint8_t *)(arg_28h + iVar25);
                            iVar25 = iVar25 + 1;
                            uVar17 = (uint64_t)((uint32_t)uVar17 | (*puVar12 & 0x7f) << ((uint8_t)uVar30 & 0x1f));
                            uVar30 = (uint64_t)((int32_t)uVar30 + 7);
                        } while ((char)*puVar12 < '\0');
                        *(undefined8 *)(*(int64_t *)(puVar11 + 0x58) + (int64_t)(int32_t)uVar33 * 8) =
                             *(undefined8 *)(*(int64_t *)(var_228h + 8) + uVar17 * 8);
                        uVar34 = (int32_t)uVar33 + 1;
                        uVar30 = uVar22;
                        uVar17 = uVar22;
                        uVar33 = (uint64_t)uVar34;
                    } while ((int32_t)uVar34 < *(int32_t *)(puVar11 + 0xa0));
                }
                do {
                    puVar12 = (uint8_t *)(arg_28h + iVar25);
                    iVar25 = iVar25 + 1;
                    uVar34 = (uint32_t)uVar30 | (*puVar12 & 0x7f) << ((uint8_t)uVar18 & 0x1f);
                    uVar18 = (uint64_t)((int32_t)uVar18 + 7);
                    uVar30 = (uint64_t)uVar34;
                } while ((char)*puVar12 < '\0');
                *(uint32_t *)(puVar11 + 0x8c) = uVar34;
                uVar30 = uVar22;
                uVar18 = uVar22;
                do {
                    iVar24 = iVar25;
                    uVar34 = (uint32_t)uVar18 | (*(uint8_t *)(arg_28h + iVar24) & 0x7f) << ((uint8_t)uVar30 & 0x1f);
                    uVar18 = (uint64_t)uVar34;
                    uVar30 = (uint64_t)((int32_t)uVar30 + 7);
                    iVar25 = iVar24 + 1;
                } while ((char)*(uint8_t *)(arg_28h + iVar24) < '\0');
                if (uVar34 != 0) {
                    uVar22 = *(uint64_t *)(*(int64_t *)(var_1f8h + 8) + (uint64_t)(uVar34 - 1) * 8);
                }
                *(undefined **)(puVar11 + 0x20) = puVar11 + (0x20 - uVar22);
                iVar26 = iVar24 + 2;
                if (*(char *)(arg_28h + iVar24 + 1) != '\0') {
                    uVar15 = *(uint8_t *)(arg_28h + iVar26);
                    *(uint32_t *)(puVar11 + 0xa4) = (uint32_t)uVar15;
                    iVar35 = (*(int32_t *)(puVar11 + 0x9c) + -1 >> (uVar15 & 0x1f)) + 1;
                    uVar34 = *(int32_t *)(puVar11 + 0x9c) + 3U & 0xfffffffc;
                    iVar23 = uVar34 + iVar35 * 4;
                    iVar26 = iVar24 + 3;
                    iVar24 = func_0x000180098670(arg1, (int64_t)iVar23);
                    piVar10 = (int64_t *)(puVar11 + 0x50);
                    *piVar10 = (int64_t)(puVar11 + iVar24 + 0x50);
                    *(int32_t *)(puVar11 + 0x98) = iVar23;
                    *(int64_t *)(puVar11 + 0x60) =
                         (((int64_t)puVar11 * 2 - (int64_t)(int32_t)uVar34) - (int64_t)(puVar11 + iVar24 + 0x50)) + 0xb0
                    ;
                    cVar29 = '\0';
                    iVar23 = 0;
                    if (0 < *(int32_t *)(puVar11 + 0x9c)) {
                        do {
                            pcVar2 = (char *)(arg_28h + iVar26);
                            iVar26 = iVar26 + 1;
                            cVar29 = cVar29 + *pcVar2;
                            *(char *)(((int64_t)iVar23 - (int64_t)piVar10) + *piVar10) = cVar29;
                            iVar23 = iVar23 + 1;
                        } while (iVar23 < *(int32_t *)(puVar11 + 0x9c));
                    }
                    iVar23 = 0;
                    uVar22 = 0;
                    if (0 < iVar35) {
                        do {
                            piVar3 = (int32_t *)(arg_28h + iVar26);
                            iVar26 = iVar26 + 4;
                            iVar23 = iVar23 + *piVar3;
                            *(int32_t *)(puVar11 + (uVar22 * 4 - *(int64_t *)(puVar11 + 0x60)) + 0x60) = iVar23;
                            uVar34 = (int32_t)uVar22 + 1;
                            uVar22 = (uint64_t)uVar34;
                        } while ((int32_t)uVar34 < iVar35);
                    }
                }
                uVar18 = 0;
                iVar24 = iVar26 + 1;
                uVar22 = uVar18;
                uVar30 = uVar18;
                if (*(char *)(arg_28h + iVar26) != '\0') {
                    do {
                        puVar12 = (uint8_t *)(arg_28h + iVar24);
                        iVar24 = iVar24 + 1;
                        uVar34 = (uint32_t)uVar30 | (*puVar12 & 0x7f) << ((uint8_t)uVar22 & 0x1f);
                        uVar22 = (uint64_t)((int32_t)uVar22 + 7);
                        uVar30 = (uint64_t)uVar34;
                    } while ((char)*puVar12 < '\0');
                    iVar32 = var_240h;
                    if (0xaaaaaaaaaaaaaaa < (uint64_t)(int64_t)(int32_t)uVar34) goto code_r0x0001800a7fb9;
                    iVar26 = func_0x000180098670(arg1, (int64_t)(int32_t)uVar34 * 0x18, *puVar11);
                    piVar10 = (int64_t *)(puVar11 + 0x80);
                    *piVar10 = (int64_t)(puVar11 + iVar26 + 0x80);
                    *(uint32_t *)(puVar11 + 0x90) = uVar34;
                    uVar22 = uVar18;
                    uVar30 = uVar18;
                    uVar17 = uVar18;
                    uVar33 = uVar18;
                    if (0 < (int32_t)uVar34) {
                        do {
                            do {
                                puVar12 = (uint8_t *)(arg_28h + iVar24);
                                iVar24 = iVar24 + 1;
                                uVar34 = (uint32_t)uVar17 | (*puVar12 & 0x7f) << ((uint8_t)uVar22 & 0x1f);
                                uVar22 = (uint64_t)((int32_t)uVar22 + 7);
                                uVar17 = (uint64_t)uVar34;
                            } while ((char)*puVar12 < '\0');
                            uVar22 = uVar18;
                            if (uVar34 != 0) {
                                uVar22 = *(uint64_t *)(*(int64_t *)(var_1f8h + 8) + (uint64_t)(uVar34 - 1) * 8);
                            }
                            iVar26 = (int64_t)(int32_t)uVar33 * 0x18 - (int64_t)piVar10;
                            *(uint64_t *)(iVar26 + *piVar10) = uVar22;
                            uVar22 = uVar18;
                            uVar17 = uVar18;
                            do {
                                puVar12 = (uint8_t *)(arg_28h + iVar24);
                                iVar24 = iVar24 + 1;
                                uVar34 = (uint32_t)uVar17 | (*puVar12 & 0x7f) << ((uint8_t)uVar22 & 0x1f);
                                uVar17 = (uint64_t)uVar34;
                                uVar22 = (uint64_t)((int32_t)uVar22 + 7);
                            } while ((char)*puVar12 < '\0');
                            *(uint32_t *)(iVar26 + 8 + *piVar10) = uVar34;
                            uVar22 = uVar18;
                            uVar17 = uVar18;
                            do {
                                iVar25 = iVar24;
                                uVar34 = (uint32_t)uVar17 |
                                         (*(uint8_t *)(arg_28h + iVar25) & 0x7f) << ((uint8_t)uVar22 & 0x1f);
                                uVar17 = (uint64_t)uVar34;
                                uVar22 = (uint64_t)((int32_t)uVar22 + 7);
                                iVar24 = iVar25 + 1;
                            } while ((char)*(uint8_t *)(arg_28h + iVar25) < '\0');
                            *(uint32_t *)(iVar26 + 0xc + *piVar10) = uVar34;
                            iVar24 = iVar25 + 2;
                            *(undefined *)(iVar26 + 0x10 + *piVar10) = *(undefined *)(arg_28h + iVar25 + 1);
                            uVar34 = (int32_t)uVar33 + 1;
                            uVar22 = uVar18;
                            uVar17 = uVar18;
                            uVar33 = (uint64_t)uVar34;
                            arg1 = var_240h;
                        } while ((int32_t)uVar34 < *(int32_t *)(puVar11 + 0x90));
                    }
                    do {
                        puVar12 = (uint8_t *)(arg_28h + iVar24);
                        iVar24 = iVar24 + 1;
                        uVar34 = (uint32_t)uVar22 | (*puVar12 & 0x7f) << ((uint8_t)uVar30 & 0x1f);
                        uVar30 = (uint64_t)((int32_t)uVar30 + 7);
                        uVar22 = (uint64_t)uVar34;
                    } while ((char)*puVar12 < '\0');
                    iVar32 = var_240h;
                    if (0x1fffffffffffffff < (uint64_t)(int64_t)(int32_t)uVar34) goto code_r0x0001800a7fb9;
                    iVar26 = func_0x000180098670(arg1, (int64_t)(int32_t)uVar34 * 8);
                    *(undefined **)(puVar11 + 8) = puVar11 + (8 - iVar26);
                    *(uint32_t *)(puVar11 + 0x94) = uVar34;
                    uVar22 = uVar18;
                    uVar30 = uVar18;
                    uVar17 = uVar18;
                    if (0 < (int32_t)uVar34) {
                        do {
                            do {
                                puVar12 = (uint8_t *)(arg_28h + iVar24);
                                iVar24 = iVar24 + 1;
                                uVar34 = (uint32_t)uVar30 | (*puVar12 & 0x7f) << ((uint8_t)uVar22 & 0x1f);
                                uVar22 = (uint64_t)((int32_t)uVar22 + 7);
                                uVar30 = (uint64_t)uVar34;
                            } while ((char)*puVar12 < '\0');
                            uVar22 = uVar18;
                            if (uVar34 != 0) {
                                uVar22 = *(uint64_t *)(*(int64_t *)(var_1f8h + 8) + (uint64_t)(uVar34 - 1) * 8);
                            }
                            *(uint64_t *)(puVar11 + ((int64_t)(int32_t)uVar17 * 8 - *(int64_t *)(puVar11 + 8)) + 8) =
                                 uVar22;
                            uVar34 = (int32_t)uVar17 + 1;
                            uVar22 = uVar18;
                            uVar30 = uVar18;
                            arg1 = var_240h;
                            uVar17 = (uint64_t)uVar34;
                        } while ((int32_t)uVar34 < *(int32_t *)(puVar11 + 0x94));
                    }
                }
                uVar22 = uVar18;
                uVar30 = uVar18;
                if (10 < var_247h) {
                    do {
                        puVar12 = (uint8_t *)(arg_28h + iVar24);
                        iVar24 = iVar24 + 1;
                        uVar34 = (uint32_t)uVar30 | (*puVar12 & 0x7f) << ((uint8_t)uVar22 & 0x1f);
                        uVar22 = (uint64_t)((int32_t)uVar22 + 7);
                        uVar30 = (uint64_t)uVar34;
                    } while ((char)*puVar12 < '\0');
                    *(uint32_t *)(puVar11 + 0xb8) = uVar34;
                    if (uVar34 != 0) {
                        uVar9 = func_0x000180098670(arg1, (uint64_t)uVar34 << 4);
                        *(undefined8 *)(puVar11 + 0xb0) = uVar9;
                    }
                    uVar22 = uVar18;
                    if (*(int32_t *)(puVar11 + 0xb8) != 0) {
                        do {
                            puVar12 = (uint8_t *)(arg_28h + iVar24);
                            iVar24 = iVar24 + 1;
                            iVar26 = *(int64_t *)(puVar11 + 0xb0);
                            *(uint32_t *)(iVar26 + uVar22 * 0x10) = (uint32_t)*puVar12;
                            uVar30 = uVar18;
                            uVar17 = uVar18;
                            do {
                                puVar12 = (uint8_t *)(arg_28h + iVar24);
                                iVar24 = iVar24 + 1;
                                uVar34 = (uint32_t)uVar17 | (*puVar12 & 0x7f) << ((uint8_t)uVar30 & 0x1f);
                                uVar17 = (uint64_t)uVar34;
                                uVar30 = (uint64_t)((int32_t)uVar30 + 7);
                            } while ((char)*puVar12 < '\0');
                            *(uint32_t *)(iVar26 + 4 + uVar22 * 0x10) = uVar34;
                            *(undefined8 *)(iVar26 + 8 + uVar22 * 0x10) = 0;
                            uVar34 = (int32_t)uVar22 + 1;
                            uVar22 = (uint64_t)uVar34;
                        } while (uVar34 < *(uint32_t *)(puVar11 + 0xb8));
                    }
                }
                *(undefined **)(*(int64_t *)(var_228h + 8) + (uint64_t)(uint32_t)var_208h * 8) = puVar11;
                var_208h._0_4_ = (uint32_t)var_208h + 1;
                iVar26 = var_228h;
            } while ((uint32_t)var_208h < (uint32_t)var_1f0h);
        }
        uVar22 = 0;
        uVar15 = 0;
        do {
            puVar12 = (uint8_t *)(arg_28h + iVar24);
            iVar24 = iVar24 + 1;
            uVar22 = (uint64_t)((uint32_t)uVar22 | (*puVar12 & 0x7f) << (uVar15 & 0x1f));
            uVar15 = uVar15 + 7;
        } while ((char)*puVar12 < '\0');
        iVar24 = *(int64_t *)(*(int64_t *)(iVar26 + 8) + uVar22 * 8);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        puVar11 = (undefined *)fcn.180098710(arg1, 0x28, *(undefined *)(arg1 + 4));
        puVar11[1] = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3;
        puVar11[2] = 8;
        *puVar11 = *(undefined *)(arg1 + 4);
        puVar11[3] = 0;
        *(int64_t *)(puVar11 + 0x10) = var_1e0h;
        puVar11[4] = 0;
        puVar11[5] = *(undefined *)(iVar24 + 3);
        puVar11[6] = 0;
        *(undefined8 *)(puVar11 + 8) = 0;
        *(int64_t *)(puVar11 + 0x20) = iVar24;
        *(undefined8 *)(iVar24 + 0x78) = 1;
        puVar5 = *(undefined8 **)(arg1 + 0x40);
        *puVar5 = puVar11;
        *(undefined4 *)((int64_t)puVar5 + 0xc) = 8;
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar35 = *(int32_t *)(arg1 + 0x60) - (int32_t)(int32_t *)(arg1 + 0x60);
            iVar23 = iVar35 * 2;
            if (iVar35 < 1) {
                iVar23 = iVar35 + 1;
            }
            func_0x000180093240(arg1, iVar23, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    } else {
        fcn.180498cd0(arg4);
        uVar9 = func_0x000180099480(&var_158h);
        var_258h = CONCAT44(var_258h._4_4_, 0xb);
        uVar31 = 3;
        uVar21 = 0x18063ef20;
code_r0x0001800a7f81:
        var_250h._0_4_ = (uint32_t)uVar15;
        func_0x000180086980(arg1, uVar21, uVar9, uVar31);
    }
code_r0x0001800a7f91:
    fcn.180459870(var_58h ^ (uint64_t)auStack_278);
    return;
}

// ============================================================
// Function: FUN_1800a8050
// Address: 0x1800a8050
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_247h
// WARNING: [rz-ghidra] Detected overlap for variable var_248h
// WARNING: [rz-ghidra] Detected overlap for variable var_21ch
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h

void fcn.1800a8050(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    uVar1 = fcn.1800a6530(arg1, arg2, arg2 + 0x18, *(int64_t *)(arg2 + 0x30), *(int64_t *)(arg2 + 0x38), 
                          *(int64_t *)(arg2 + 0x40), CONCAT44(var_18h._4_4_, *(undefined4 *)(arg2 + 0x48)));
    *(undefined4 *)(arg2 + 0x50) = uVar1;
    return;
}

// ============================================================
// Function: FUN_1800a8090
// Address: 0x1800a8090
// Size: 31 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001800a809d: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001800a80a2)

void fcn.1800a8090(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)(arg1 + 0x20);
    if (iVar2 != 0) {
        iVar3 = *(int64_t *)(arg1 + 0x28);
        iVar1 = iVar3 * 8;
        iVar4 = *(int64_t *)(*(int64_t *)(arg1 + 0x18) + 0x20);
        if ((iVar1 - 1U < 0x400) && (-1 < *(char *)(iVar1 + 0x180777990))) {
            func_0x0001800985c0(*(int64_t *)(arg1 + 0x18), (int32_t)*(char *)(iVar1 + 0x180777990), iVar2);
        } else {
            (**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), iVar2, iVar1, 0);
        }
        *(int64_t *)(iVar4 + 0x30) = *(int64_t *)(iVar4 + 0x30) + iVar3 * -8;
        *(int64_t *)(iVar4 + 0x2c30) = *(int64_t *)(iVar4 + 0x2c30) + iVar3 * -8;
    }
    return;
}

// ============================================================
// Function: FUN_1800a80b0
// Address: 0x1800a80b0
// Size: 464 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800a80b0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    int32_t *piVar6;
    int64_t iVar7;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar6 = (int32_t *)
             (*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8);
    if (*piVar6 < *(int32_t *)0x180782a28) {
        fcn.180459d18(0x180782a28);
        if (*(int32_t *)0x180782a28 == -1) {
            *(int64_t *)0x180782a30 = (*(code *)0x699d1e)(0);
            fcn.180459cac(0x180782a28);
        }
    }
    if (*piVar6 < *(int32_t *)0x180782a38) {
        fcn.180459d18(0x180782a38);
        if (*(int32_t *)0x180782a38 == -1) {
            *(code **)0x180782a20 = (code *)(*(int64_t *)0x180782a30 + 0x4677b00);
            fcn.180459cac(0x180782a38);
        }
    }
    if (*(int32_t *)(*(int64_t *)0x180782a30 + 0x7ce7b28) != 0) {
        iVar3 = fcn.18045838c();
        iVar7 = iVar3 + SUB168(SEXT816(-0x29406b2a1a85bd43) * SEXT816(iVar3), 8);
        iVar7 = (iVar7 >> 0x17) - (iVar7 >> 0x3f);
        if ((iVar7 * 10000000 - iVar3 != 0) && (iVar3 <= iVar7 * 10000000)) {
            iVar7 = iVar7 + -1;
        }
        piVar4 = (int64_t *)(**(code **)0x180782558)(*(undefined8 *)(*(int64_t *)0x180782a30 + 0x7ce7d00));
        pcVar1 = *(code **)0x180782a20;
        *piVar4 = iVar7;
        uVar2 = (*pcVar1)(arg1, arg2, arg2 + 0x18, *(undefined8 *)(arg2 + 0x30), *(undefined8 *)(arg2 + 0x38), 
                          *(undefined8 *)(arg2 + 0x40), *(undefined4 *)(arg2 + 0x48));
        iVar7 = *(int64_t *)0x180782a30;
        *(undefined4 *)(arg2 + 0x4c) = uVar2;
        puVar5 = (undefined8 *)(**(code **)0x180782558)(*(undefined8 *)(iVar7 + 0x7ce7d00));
        *puVar5 = 0;
        return;
    }
    uVar2 = (**(code **)0x180782a20)
                      (arg1, arg2, arg2 + 0x18, *(undefined8 *)(arg2 + 0x30), *(undefined8 *)(arg2 + 0x38), 
                       *(undefined8 *)(arg2 + 0x40), *(undefined4 *)(arg2 + 0x48));
    *(undefined4 *)(arg2 + 0x4c) = uVar2;
    return;
}

// ============================================================
// Function: FUN_1800a8280
// Address: 0x1800a8280
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800a8280(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)(arg1 + 8);
    if (iVar2 != 0) {
        iVar3 = *(int64_t *)(arg1 + 0x10);
        iVar1 = iVar3 * 4;
        iVar4 = *(int64_t *)(*(int64_t *)arg1 + 0x20);
        if ((iVar1 - 1U < 0x400) && (-1 < *(char *)(iVar1 + 0x180777990))) {
            func_0x0001800985c0(*(int64_t *)arg1, (int32_t)*(char *)(iVar1 + 0x180777990), iVar2);
        } else {
            (**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), iVar2, iVar1, 0);
        }
        *(int64_t *)(iVar4 + 0x30) = *(int64_t *)(iVar4 + 0x30) + iVar3 * -4;
        *(int64_t *)(iVar4 + 0x2c30) = *(int64_t *)(iVar4 + 0x2c30) + iVar3 * -4;
    }
    return;
}

// ============================================================
// Function: FUN_1800a82f0
// Address: 0x1800a82f0
// Size: 112 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001800a809d: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001800a80a2)

void fcn.1800a8090(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)(arg1 + 0x20);
    if (iVar2 != 0) {
        iVar3 = *(int64_t *)(arg1 + 0x28);
        iVar1 = iVar3 * 8;
        iVar4 = *(int64_t *)(*(int64_t *)(arg1 + 0x18) + 0x20);
        if ((iVar1 - 1U < 0x400) && (-1 < *(char *)(iVar1 + 0x180777990))) {
            func_0x0001800985c0(*(int64_t *)(arg1 + 0x18), (int32_t)*(char *)(iVar1 + 0x180777990), iVar2);
        } else {
            (**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), iVar2, iVar1, 0);
        }
        *(int64_t *)(iVar4 + 0x30) = *(int64_t *)(iVar4 + 0x30) + iVar3 * -8;
        *(int64_t *)(iVar4 + 0x2c30) = *(int64_t *)(iVar4 + 0x2c30) + iVar3 * -8;
    }
    return;
}

// ============================================================
// Function: FUN_1800a8360
// Address: 0x1800a8360
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800a8360(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t var_18h;
    undefined auStack_68 [32];
    int64_t var_48h;
    uint64_t uStack_18;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    if (*(int32_t *)(arg2 + 0xc) == 3) {
        iVar1 = func_0x000180098ac0(&var_48h, *(undefined8 *)arg2);
        uVar2 = fcn.18009a8e0(arg1, &var_48h, iVar1 - (int64_t)&var_48h);
        *(undefined8 *)arg2 = uVar2;
        *(undefined4 *)(arg2 + 0xc) = 6;
    }
    fcn.180459870(uStack_18 ^ (uint64_t)auStack_68);
    return;
}

// ============================================================
// Function: FUN_1800a83e0
// Address: 0x1800a83e0
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800a83e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t in_stack_00000018;
    int64_t in_stack_00000020;
    
    puVar1 = *(undefined4 **)(arg1 + 0x40);
    uVar4 = *(undefined4 *)(arg3 + 4);
    uVar5 = *(undefined4 *)(arg3 + 8);
    uVar6 = *(undefined4 *)(arg3 + 0xc);
    iVar2 = *(int64_t *)(arg1 + 0x38);
    *puVar1 = *(undefined4 *)arg3;
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    iVar3 = *(int64_t *)(arg1 + 0x40);
    uVar4 = *(undefined4 *)(arg4 + 4);
    uVar5 = *(undefined4 *)(arg4 + 8);
    uVar6 = *(undefined4 *)(arg4 + 0xc);
    *(undefined4 *)(iVar3 + 0x10) = *(undefined4 *)arg4;
    *(undefined4 *)(iVar3 + 0x14) = uVar4;
    *(undefined4 *)(iVar3 + 0x18) = uVar5;
    *(undefined4 *)(iVar3 + 0x1c) = uVar6;
    iVar3 = *(int64_t *)(arg1 + 0x40);
    uVar4 = *(undefined4 *)(arg_28h + 4);
    uVar5 = *(undefined4 *)(arg_28h + 8);
    uVar6 = *(undefined4 *)(arg_28h + 0xc);
    *(undefined4 *)(iVar3 + 0x20) = *(undefined4 *)arg_28h;
    *(undefined4 *)(iVar3 + 0x24) = uVar4;
    *(undefined4 *)(iVar3 + 0x28) = uVar5;
    *(undefined4 *)(iVar3 + 0x2c) = uVar6;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x31) {
        fcn.180093240(in_stack_00000010, in_stack_00000018, in_stack_00000020, arg_28h);
    }
    iVar3 = *(int64_t *)(arg1 + 0x40);
    *(int64_t *)(arg1 + 0x40) = iVar3 + 0x30;
    fcn.1800935b0(arg1, iVar3, 1, 0);
    puVar7 = (undefined4 *)(*(int64_t *)(arg1 + 0x38) + (arg2 - iVar2));
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    puVar1 = *(undefined4 **)(arg1 + 0x40);
    uVar4 = puVar1[1];
    uVar5 = puVar1[2];
    uVar6 = puVar1[3];
    *puVar7 = *puVar1;
    puVar7[1] = uVar4;
    puVar7[2] = uVar5;
    puVar7[3] = uVar6;
    return;
}

// ============================================================
// Function: FUN_1800a8490
// Address: 0x1800a8490
// Size: 490 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800a8490(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined auVar6 [16];
    undefined4 *puVar7;
    int64_t *arg3_00;
    double *pdVar8;
    int32_t iVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    iVar9 = 0;
    while (iVar2 = *(int32_t *)(arg2 + 0xc), iVar2 != 7) {
        if (*(char *)0x180777db8 != '\0') {
            if (iVar2 == 0xd) {
                iVar3 = *(int64_t *)arg2;
                iVar4 = *(int64_t *)(iVar3 + 0x10);
                pdVar8 = (double *)func_0x0001800a0ea0(*(undefined8 *)(iVar4 + 0x20), arg3);
                if (*(int32_t *)((int64_t)pdVar8 + 0xc) == 0) goto code_r0x0001800a865b;
                iVar9 = (int32_t)*pdVar8;
                if (iVar9 < *(int32_t *)(iVar4 + 0x40)) {
                    puVar7 = (undefined4 *)((int64_t)iVar9 * 0x10 + *(int64_t *)(iVar3 + 0x20));
                    uVar10 = *puVar7;
                    uVar11 = puVar7[1];
                    uVar12 = puVar7[2];
                    uVar13 = puVar7[3];
                } else {
                    puVar7 = (undefined4 *)
                             ((int64_t)(iVar9 - *(int32_t *)(iVar4 + 0x40)) * 0x10 + *(int64_t *)(iVar4 + 0x18));
                    uVar10 = *puVar7;
                    uVar11 = puVar7[1];
                    uVar12 = puVar7[2];
                    uVar13 = puVar7[3];
                }
                goto code_r0x0001800a858b;
            }
            if (iVar2 == 0xc) {
                iVar3 = *(int64_t *)arg2;
                pdVar8 = (double *)func_0x0001800a0ea0(*(undefined8 *)(iVar3 + 0x20), arg3);
                if (*(int32_t *)((int64_t)pdVar8 + 0xc) != 0) {
                    if (*(int32_t *)(iVar3 + 0x40) <= (int32_t)*pdVar8) {
                        puVar7 = (undefined4 *)
                                 (*(int64_t *)(iVar3 + 0x18) +
                                 (int64_t)((int32_t)*pdVar8 - *(int32_t *)(iVar3 + 0x40)) * 0x10);
                        uVar10 = *puVar7;
                        uVar11 = puVar7[1];
                        uVar12 = puVar7[2];
                        uVar13 = puVar7[3];
                        goto code_r0x0001800a858b;
                    }
                }
code_r0x0001800a865b:
                func_0x000180092ea0(arg1, arg2, arg3);
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
        }
        arg3_00 = (int64_t *)func_0x0001800a3b10(arg1, arg2, 0);
        if (*(int32_t *)((int64_t)arg3_00 + 0xc) == 0) {
            func_0x000180092e30(arg1, arg2, arg3);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
code_r0x0001800a8561:
        if (*(int32_t *)((int64_t)arg3_00 + 0xc) == 8) {
            fcn.1800a83e0(arg1, arg4, (int64_t)arg3_00, arg2, arg3);
            return;
        }
        iVar9 = iVar9 + 1;
        arg2 = (int64_t)arg3_00;
        if (99 < iVar9) {
            fcn.180093000(arg1, 0x18063efc0);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
    }
    iVar3 = *(int64_t *)arg2;
    puVar7 = (undefined4 *)func_0x0001800a0ea0(iVar3, arg3);
    if (puVar7 != *(undefined4 **)0x180782430) {
        *(int32_t *)(arg1 + 0x6c) = (int32_t)((int64_t)puVar7 - *(int64_t *)(iVar3 + 0x28) >> 5);
    }
    if (((puVar7[3] == 0) && (iVar3 = *(int64_t *)(iVar3 + 0x10), iVar3 != 0)) &&
       (uVar1 = *(uint8_t *)(iVar3 + 5), (uVar1 & 1) == 0)) {
        arg3_00 = (int64_t *)fcn.1800a0e30(iVar3, *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x328));
        if (*(int32_t *)((int64_t)arg3_00 + 0xc) == 0) {
            *(uint8_t *)(iVar3 + 5) = uVar1 | 1;
        } else if (arg3_00 != (int64_t *)0x0) goto code_r0x0001800a8561;
    }
    uVar10 = *puVar7;
    uVar11 = puVar7[1];
    uVar12 = puVar7[2];
    uVar13 = puVar7[3];
code_r0x0001800a858b:
    auVar6._4_4_ = uVar11;
    auVar6._0_4_ = uVar10;
    auVar6._8_4_ = uVar12;
    auVar6._12_4_ = uVar13;
    *(undefined (*) [16])arg4 = auVar6;
    return;
}

// ============================================================
// Function: FUN_1800a8680
// Address: 0x1800a8680
// Size: 856 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h

void fcn.1800a8680(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_40h)
{
    uint8_t uVar1;
    int32_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    undefined4 *puVar8;
    double *pdVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    int64_t unaff_R14;
    int64_t unaff_R15;
    int64_t var_5h;
    int64_t var_20h;
    undefined auStackY_88 [32];
    int64_t var_68h;
    int64_t var_60h;
    undefined4 uStackY_58;
    undefined4 uStackY_54;
    int64_t var_50h;
    int64_t in_stack_ffffffffffffffb8;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_88;
    iVar13 = 0;
    puVar12 = *(undefined4 **)0x180782430;
    var_68h = arg4;
    do {
        iVar2 = *(int32_t *)(arg2 + 0xc);
        if (iVar2 == 7) {
            iVar10 = *(int64_t *)arg2;
            puVar7 = (undefined4 *)func_0x0001800a0ea0(iVar10, arg3);
            if (((puVar7[3] == 0) &&
                (iVar11 = *(int64_t *)(iVar10 + 0x10), puVar12 = *(undefined4 **)0x180782430, iVar11 != 0)) &&
               (uVar1 = *(uint8_t *)(iVar11 + 5), (uVar1 & 2) == 0)) {
                puVar8 = (undefined4 *)fcn.1800a0e30(iVar11, *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x330));
                if (puVar8[3] == 0) {
                    *(uint8_t *)(iVar11 + 5) = uVar1 | 2;
                    puVar12 = *(undefined4 **)0x180782430;
                } else {
                    puVar12 = *(undefined4 **)0x180782430;
                    if (puVar8 != (undefined4 *)0x0) goto code_r0x0001800a87c1;
                }
            }
            if (*(char *)(iVar10 + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            *(undefined *)(iVar10 + 5) = 0;
            if (puVar7 == puVar12) {
                puVar7 = (undefined4 *)func_0x0001800a0f90(arg1, iVar10, arg3);
            }
            *(int32_t *)(arg1 + 0x6c) = (int32_t)((int64_t)puVar7 - *(int64_t *)(iVar10 + 0x28) >> 5);
            uVar4 = *(undefined4 *)(var_68h + 4);
            uVar5 = *(undefined4 *)(var_68h + 8);
            uVar6 = *(undefined4 *)(var_68h + 0xc);
            *puVar7 = *(undefined4 *)var_68h;
            puVar7[1] = uVar4;
            puVar7[2] = uVar5;
            puVar7[3] = uVar6;
            if (((*(int32_t *)(var_68h + 0xc) < 6) || ((*(uint8_t *)(iVar10 + 1) & 4) == 0)) ||
               ((*(uint8_t *)(*(int64_t *)var_68h + 1) & 3) == 0)) goto code_r0x0001800a886f;
            iVar11 = *(int64_t *)(arg1 + 0x20);
            if (*(char *)(iVar11 + 0x59) != '\x02') {
                *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar10 + 1) & 0xfb;
                *(undefined8 *)(iVar10 + 0x18) = *(undefined8 *)(iVar11 + 0x18);
                *(int64_t *)(iVar11 + 0x18) = iVar10;
                goto code_r0x0001800a886f;
            }
code_r0x0001800a891b:
            func_0x000180094420(iVar11);
code_r0x0001800a886f:
            fcn.180459870(var_50h ^ (uint64_t)auStackY_88);
            return;
        }
        if ((*(char *)0x180777db8 != '\0') && (iVar2 == 0xd)) {
            iVar10 = *(int64_t *)arg2;
            iVar11 = *(int64_t *)(iVar10 + 0x10);
            pdVar9 = (double *)func_0x0001800a0ea0(*(undefined8 *)(iVar11 + 0x20), arg3);
            if (*(int32_t *)((int64_t)pdVar9 + 0xc) == 0) {
                func_0x000180092ea0(arg1, arg2, arg3);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            if (*(int32_t *)(iVar11 + 0x40) <= (int32_t)*pdVar9) goto code_r0x0001800a89a1;
            uVar4 = *(undefined4 *)(var_68h + 4);
            uVar5 = *(undefined4 *)(var_68h + 8);
            uVar6 = *(undefined4 *)(var_68h + 0xc);
            puVar12 = (undefined4 *)(*(int64_t *)(iVar10 + 0x20) + (int64_t)(int32_t)*pdVar9 * 0x10);
            *puVar12 = *(undefined4 *)var_68h;
            puVar12[1] = uVar4;
            puVar12[2] = uVar5;
            puVar12[3] = uVar6;
            if (((*(int32_t *)(var_68h + 0xc) < 6) || ((*(uint8_t *)(iVar10 + 1) & 4) == 0)) ||
               ((*(uint8_t *)(*(int64_t *)var_68h + 1) & 3) == 0)) goto code_r0x0001800a886f;
            iVar11 = *(int64_t *)(arg1 + 0x20);
            if (2 < (uint8_t)(*(char *)(iVar11 + 0x59) - 1U)) {
                *(uint8_t *)(iVar10 + 1) = *(uint8_t *)(iVar11 + 0x58) & 3 | *(uint8_t *)(iVar10 + 1) & 0xf8;
                goto code_r0x0001800a886f;
            }
            goto code_r0x0001800a891b;
        }
        if (iVar2 == 7) {
            iVar10 = *(int64_t *)(*(int64_t *)arg2 + 0x10);
        } else if (iVar2 == 9) {
            iVar10 = *(int64_t *)arg2 + 8 + *(int64_t *)(*(int64_t *)arg2 + 8);
        } else if (iVar2 == 0xc) {
            iVar10 = *(int64_t *)(*(int64_t *)arg2 + 0x30);
        } else if (iVar2 == 0xd) {
            iVar10 = *(int64_t *)(*(int64_t *)(*(int64_t *)arg2 + 0x10) + 0x38);
        } else {
            iVar10 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x440 + (int64_t)iVar2 * 8);
        }
        puVar8 = puVar12;
        if (iVar10 != 0) {
            puVar8 = (undefined4 *)fcn.1800a0e30(iVar10, *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x330));
        }
        if (puVar8[3] == 0) {
code_r0x0001800a89a1:
            func_0x000180092e30(arg1, arg2, arg3);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
code_r0x0001800a87c1:
        uVar4 = puVar8[1];
        uVar5 = puVar8[2];
        uVar6 = puVar8[3];
        if (puVar8[3] == 8) {
            puVar12 = *(undefined4 **)(arg1 + 0x40);
            *puVar12 = *puVar8;
            puVar12[1] = uVar4;
            puVar12[2] = uVar5;
            puVar12[3] = uVar6;
            iVar10 = *(int64_t *)(arg1 + 0x40);
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            *(undefined4 *)(iVar10 + 0x10) = *(undefined4 *)arg2;
            *(undefined4 *)(iVar10 + 0x14) = uVar4;
            *(undefined4 *)(iVar10 + 0x18) = uVar5;
            *(undefined4 *)(iVar10 + 0x1c) = uVar6;
            iVar10 = *(int64_t *)(arg1 + 0x40);
            uVar4 = *(undefined4 *)(arg3 + 4);
            uVar5 = *(undefined4 *)(arg3 + 8);
            uVar6 = *(undefined4 *)(arg3 + 0xc);
            *(undefined4 *)(iVar10 + 0x20) = *(undefined4 *)arg3;
            *(undefined4 *)(iVar10 + 0x24) = uVar4;
            *(undefined4 *)(iVar10 + 0x28) = uVar5;
            *(undefined4 *)(iVar10 + 0x2c) = uVar6;
            iVar10 = *(int64_t *)(arg1 + 0x40);
            uVar4 = *(undefined4 *)(var_68h + 4);
            uVar5 = *(undefined4 *)(var_68h + 8);
            uVar6 = *(undefined4 *)(var_68h + 0xc);
            *(undefined4 *)(iVar10 + 0x30) = *(undefined4 *)var_68h;
            *(undefined4 *)(iVar10 + 0x34) = uVar4;
            *(undefined4 *)(iVar10 + 0x38) = uVar5;
            *(undefined4 *)(iVar10 + 0x3c) = uVar6;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x41) {
                fcn.180093240(var_50h, in_stack_ffffffffffffffb8, unaff_R15, unaff_R14);
            }
            iVar10 = *(int64_t *)(arg1 + 0x40);
            *(int64_t *)(arg1 + 0x40) = iVar10 + 0x40;
            fcn.1800935b0(arg1, iVar10, 0, 0);
            goto code_r0x0001800a886f;
        }
        iVar13 = iVar13 + 1;
        var_60h._0_4_ = *puVar8;
        var_60h._4_4_ = uVar4;
        uStackY_58 = uVar5;
        uStackY_54 = uVar6;
        if (99 < iVar13) {
            fcn.180093000(arg1, 0x18063eff8);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        arg2 = (int64_t)&var_60h;
    } while( true );
}

// ============================================================
// Function: FUN_1800a89e0
// Address: 0x1800a89e0
// Size: 164 bytes
// ============================================================
int64_t fcn.1800a89e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    
    if ((arg2 != 0) && (uVar1 = *(uint8_t *)(arg2 + 5), -1 < (char)uVar1)) {
        iVar3 = fcn.1800a0e30(arg2, *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x360));
        if (*(int32_t *)(iVar3 + 0xc) == 0) {
            *(uint8_t *)(arg2 + 5) = uVar1 | 0x80;
        } else if (iVar3 != 0) {
            if (arg2 == arg3) {
                return iVar3;
            }
            if (((arg3 != 0) && (-1 < *(char *)(arg3 + 5))) &&
               (iVar4 = fcn.1800a3ad0(arg3, 7, *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x360)), iVar4 != 0)) {
                iVar2 = fcn.180099140(iVar3, iVar4);
                iVar4 = 0;
                if (iVar2 != 0) {
                    iVar4 = iVar3;
                }
                return iVar4;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800a8a90
// Address: 0x1800a8a90
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.1800a8a90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t arg3_00;
    undefined8 uVar3;
    int64_t var_38h;
    
    arg3_00 = func_0x0001800a3b10(arg1, arg2, 0x10);
    if (*(int32_t *)(arg3_00 + 0xc) == 0) {
        func_0x000180092de0(arg1, arg2, arg3);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    uVar3 = func_0x0001800a3b10(arg1, arg3, 0x10);
    iVar2 = fcn.180099140(arg3_00, uVar3);
    if (iVar2 != 0) {
        fcn.1800a83e0(arg1, *(int64_t *)(arg1 + 0x40), arg3_00, arg2, arg3);
        iVar2 = (*(int32_t **)(arg1 + 0x40))[3];
        if ((iVar2 != 0) && ((iVar2 != 1 || (**(int32_t **)(arg1 + 0x40) != 0)))) {
            return 1;
        }
        return 0;
    }
    func_0x000180092de0(arg1, arg2, arg3);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800a8b40
// Address: 0x1800a8b40
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800a8b40(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    int64_t var_8h;
    
    if (arg1 == arg2) {
        return 0;
    }
    if (*(uint8_t *)(arg1 + 0x18) != *(uint8_t *)(arg2 + 0x18)) {
        return (uint64_t)((uint32_t)*(uint8_t *)(arg1 + 0x18) - (uint32_t)*(uint8_t *)(arg2 + 0x18));
    }
    uVar1 = *(uint32_t *)(arg2 + 0x14);
    uVar2 = *(uint32_t *)(arg1 + 0x14);
    uVar3 = uVar1;
    if (uVar2 < uVar1) {
        uVar3 = uVar2;
    }
    uVar4 = fcn.180497f30(arg1 + 0x18, arg2 + 0x18, uVar3);
    if ((int32_t)uVar4 == 0) {
        if (uVar2 == uVar1) {
            return uVar4;
        }
        uVar4 = 1;
        if (uVar2 < uVar1) {
            uVar4 = 0xffffffff;
        }
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1800a8b66
// Address: 0x1800a8b66
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800a8b40(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    int64_t var_8h;
    
    if (arg1 == arg2) {
        return 0;
    }
    if (*(uint8_t *)(arg1 + 0x18) != *(uint8_t *)(arg2 + 0x18)) {
        return (uint64_t)((uint32_t)*(uint8_t *)(arg1 + 0x18) - (uint32_t)*(uint8_t *)(arg2 + 0x18));
    }
    uVar1 = *(uint32_t *)(arg2 + 0x14);
    uVar2 = *(uint32_t *)(arg1 + 0x14);
    uVar3 = uVar1;
    if (uVar2 < uVar1) {
        uVar3 = uVar2;
    }
    uVar4 = fcn.180497f30(arg1 + 0x18, arg2 + 0x18, uVar3);
    if ((int32_t)uVar4 == 0) {
        if (uVar2 == uVar1) {
            return uVar4;
        }
        uVar4 = 1;
        if (uVar2 < uVar1) {
            uVar4 = 0xffffffff;
        }
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1800a8ba3
// Address: 0x1800a8ba3
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800a8b40(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    int64_t var_8h;
    
    if (arg1 == arg2) {
        return 0;
    }
    if (*(uint8_t *)(arg1 + 0x18) != *(uint8_t *)(arg2 + 0x18)) {
        return (uint64_t)((uint32_t)*(uint8_t *)(arg1 + 0x18) - (uint32_t)*(uint8_t *)(arg2 + 0x18));
    }
    uVar1 = *(uint32_t *)(arg2 + 0x14);
    uVar2 = *(uint32_t *)(arg1 + 0x14);
    uVar3 = uVar1;
    if (uVar2 < uVar1) {
        uVar3 = uVar2;
    }
    uVar4 = fcn.180497f30(arg1 + 0x18, arg2 + 0x18, uVar3);
    if ((int32_t)uVar4 == 0) {
        if (uVar2 == uVar1) {
            return uVar4;
        }
        uVar4 = 1;
        if (uVar2 < uVar1) {
            uVar4 = 0xffffffff;
        }
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1800a8bc0
// Address: 0x1800a8bc0
// Size: 80 bytes
// ============================================================
uint64_t fcn.1800a8bc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    code *pcVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    int64_t in_stack_fffffffffffffff8;
    
    iVar1 = *(int32_t *)(arg2 + 0xc);
    if (iVar1 != *(int32_t *)(arg3 + 0xc)) {
        fcn.180092de0();
        pcVar2 = (code *)swi(3);
        uVar4 = (*pcVar2)();
        return uVar4;
    }
    if (iVar1 == 3) {
        return (uint64_t)(*(double *)arg2 <= *(double *)arg3 && *(double *)arg3 != *(double *)arg2);
    }
    if (iVar1 == 6) {
        uVar3 = fcn.1800a8b40(*(int64_t *)arg2, *(int64_t *)arg3, in_stack_fffffffffffffff8);
        return (uint64_t)(uVar3 >> 0x1f);
    }
    uVar4 = fcn.1800a8a90(arg1, arg2, arg3);
    return uVar4;
}

// ============================================================
// Function: FUN_1800a8c10
// Address: 0x1800a8c10
// Size: 480 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h

bool fcn.1800a8c10(int64_t arg1, int64_t arg2, int64_t arg3)
{
    double dVar1;
    int32_t iVar2;
    int16_t iVar3;
    int64_t arg3_00;
    int64_t iVar4;
    int64_t iVar5;
    bool bVar6;
    bool bVar7;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_38h;
    
    // switch table (14 cases) at 0x1800a8db8
    switch(*(undefined4 *)(arg2 + 0xc)) {
    case 0:
        return true;
    case 1:
        return *(int32_t *)arg2 == *(int32_t *)arg3;
    case 2:
        if (*(int64_t *)arg2 != *(int64_t *)arg3) {
            return false;
        }
        bVar7 = *(int32_t *)(arg2 + 8) == *(int32_t *)(arg3 + 8);
        goto code_r0x0001800a8c72;
    case 3:
        dVar1 = *(double *)arg2;
        iVar3 = fcn.18046ea10(dVar1);
        if ((iVar3 == 2) && (iVar3 = fcn.18046ea10(*(undefined8 *)arg3), iVar3 == 2)) {
            return true;
        }
        bVar6 = NAN(dVar1) || NAN(*(double *)arg3);
        bVar7 = dVar1 == *(double *)arg3;
        break;
    default:
        return *(int64_t *)arg2 == *(int64_t *)arg3;
    case 5:
        if (*(float *)arg2 != *(float *)arg3) {
            return false;
        }
        if (*(float *)(arg2 + 4) != *(float *)(arg3 + 4)) {
            return false;
        }
        bVar6 = NAN(*(float *)(arg2 + 8)) || NAN(*(float *)(arg3 + 8));
        bVar7 = *(float *)(arg2 + 8) == *(float *)(arg3 + 8);
        break;
    case 7:
        iVar5 = *(int64_t *)(*(int64_t *)arg3 + 0x10);
        iVar4 = *(int64_t *)(*(int64_t *)arg2 + 0x10);
        goto code_r0x0001800a8cf9;
    case 9:
        iVar5 = *(int64_t *)(*(int64_t *)arg3 + 8) + *(int64_t *)arg3 + 8;
        iVar4 = *(int64_t *)arg2 + 8 + *(int64_t *)(*(int64_t *)arg2 + 8);
code_r0x0001800a8cf9:
        arg3_00 = fcn.1800a89e0(arg1, iVar4, iVar5);
        if (arg3_00 == 0) {
code_r0x0001800a8d06:
            return *(int64_t *)arg2 == *(int64_t *)arg3;
        }
code_r0x0001800a8d60:
        fcn.1800a83e0(arg1, *(int64_t *)(arg1 + 0x40), arg3_00, arg2, arg3);
        iVar2 = (*(int32_t **)(arg1 + 0x40))[3];
        if (iVar2 == 0) {
            return false;
        }
        if (iVar2 != 1) {
            return true;
        }
        if (**(int32_t **)(arg1 + 0x40) == 0) {
            return false;
        }
        return true;
    case 0xc:
        goto code_r0x0001800a8d06;
    case 0xd:
        iVar5 = *(int64_t *)arg3;
        iVar4 = *(int64_t *)arg2;
        if (*(int64_t *)(iVar4 + 0x10) != *(int64_t *)(iVar5 + 0x10)) {
            return false;
        }
        arg3_00 = fcn.1800a3b10(arg1, arg2, 7);
        if (*(int32_t *)(arg3_00 + 0xc) == 0) {
            return iVar4 == iVar5;
        }
        goto code_r0x0001800a8d60;
    }
    if (!bVar6) {
code_r0x0001800a8c72:
        if (bVar7) {
            return true;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1800a8df0
// Address: 0x1800a8df0
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800a8df0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    int64_t var_8h;
    
    puVar6 = (undefined4 *)fcn.1800a3b10(arg1, arg2, 4);
    if (puVar6[3] != 8) {
        func_0x000180092d60(arg1, arg2);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    for (puVar1 = *(undefined4 **)(arg1 + 0x40); (uint64_t)arg2 < puVar1; puVar1 = puVar1 + -4) {
        *puVar1 = puVar1[-4];
        puVar1[1] = puVar1[-3];
        puVar1[2] = puVar1[-2];
        puVar1[3] = puVar1[-1];
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    uVar3 = puVar6[1];
    uVar4 = puVar6[2];
    uVar5 = puVar6[3];
    *(undefined4 *)arg2 = *puVar6;
    *(undefined4 *)(arg2 + 4) = uVar3;
    *(undefined4 *)(arg2 + 8) = uVar4;
    *(undefined4 *)(arg2 + 0xc) = uVar5;
    return;
}

// ============================================================
// Function: FUN_1800a8e60
// Address: 0x1800a8e60
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800a8e60(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    undefined4 *puVar1;
    uint8_t uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined *puVar11;
    undefined8 uVar12;
    int64_t *piVar13;
    int64_t iVar14;
    int32_t iVar15;
    int64_t iVar16;
    int32_t iVar17;
    int64_t var_10h;
    undefined auStack_58 [32];
    int64_t var_38h;
    undefined4 var_2ch;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    piVar3 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar3;
    if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar13 + 0xc) == 0xc)) {
        iVar4 = *piVar3;
        puVar11 = (undefined *)fcn.180098710(arg1, 0x28, *(undefined *)(arg1 + 4));
        uVar2 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
        puVar11[2] = 0xd;
        puVar11[1] = uVar2 & 3;
        *puVar11 = *(undefined *)(arg1 + 4);
        *(int64_t *)(puVar11 + 0x10) = iVar4;
        iVar15 = *(int32_t *)(iVar4 + 0x40);
        *(int32_t *)(puVar11 + 0x18) = iVar15;
        if (0xfffffffffffffff < (uint64_t)(int64_t)iVar15) {
            fcn.180098420(arg1);
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        uVar12 = func_0x000180098670(arg1, (int64_t)iVar15 << 4, *(undefined *)(arg1 + 4));
        *(undefined8 *)(puVar11 + 0x20) = uVar12;
        iVar17 = 0;
        iVar5 = *(int64_t *)(arg1 + 0x40);
        iVar15 = 0;
        iVar16 = *(int64_t *)(arg1 + 0x28);
        if (0 < *(int32_t *)(iVar4 + 0x40)) {
            do {
                iVar14 = (int64_t)iVar15;
                iVar15 = iVar15 + 1;
                *(undefined4 *)(*(int64_t *)(puVar11 + 0x20) + 0xc + iVar14 * 0x10) = 0;
            } while (iVar15 < *(int32_t *)(iVar4 + 0x40));
        }
        puVar6 = *(undefined8 **)(arg1 + 0x40);
        *puVar6 = puVar11;
        *(undefined4 *)((int64_t)puVar6 + 0xc) = 0xd;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        iVar15 = (int32_t)(iVar5 - iVar16 >> 4);
        if (iVar15 != 1) {
            if (iVar15 != 2) {
                fcn.180088560(arg1, 0x18063f040, *(int64_t *)(iVar4 + 0x10) + 0x18);
                pcVar7 = (code *)swi(3);
                (*pcVar7)();
                return;
            }
            if (0 < *(int32_t *)(iVar4 + 0x40)) {
                do {
                    iVar16 = (int64_t)iVar17;
                    var_2ch = 6;
                    var_38h = *(int64_t *)(*(int64_t *)(iVar4 + 0x28) + iVar16 * 8);
                    fcn.1800a8490(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, (int64_t)&var_38h, 
                                  *(int64_t *)(arg1 + 0x40) + -0x10);
                    iVar5 = *(int64_t *)(arg1 + 0x40);
                    iVar17 = iVar17 + 1;
                    uVar8 = *(undefined4 *)(iVar5 + -0xc);
                    uVar9 = *(undefined4 *)(iVar5 + -8);
                    uVar10 = *(undefined4 *)(iVar5 + -4);
                    puVar1 = (undefined4 *)(*(int64_t *)(puVar11 + 0x20) + iVar16 * 0x10);
                    *puVar1 = *(undefined4 *)(iVar5 + -0x10);
                    puVar1[1] = uVar8;
                    puVar1[2] = uVar9;
                    puVar1[3] = uVar10;
                } while (iVar17 < *(int32_t *)(iVar4 + 0x40));
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        if ((puVar11[1] & 4) != 0) {
            iVar4 = *(int64_t *)(arg1 + 0x20);
            puVar11[1] = puVar11[1] & 0xfb;
            *(undefined8 *)(puVar11 + 8) = *(undefined8 *)(iVar4 + 0x18);
            *(undefined **)(iVar4 + 0x18) = puVar11;
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_58);
        return;
    }
    fcn.180088470(arg1, 1, 0xc);
    pcVar7 = (code *)swi(3);
    (*pcVar7)();
    return;
}

// ============================================================
// Function: FUN_1800a8eb4
// Address: 0x1800a8eb4
// Size: 200 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800a8e60(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    undefined4 *puVar1;
    uint8_t uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined *puVar11;
    undefined8 uVar12;
    int64_t *piVar13;
    int64_t iVar14;
    int32_t iVar15;
    int64_t iVar16;
    int32_t iVar17;
    int64_t var_10h;
    undefined auStack_58 [32];
    int64_t var_38h;
    undefined4 var_2ch;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    piVar3 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar3;
    if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar13 + 0xc) == 0xc)) {
        iVar4 = *piVar3;
        puVar11 = (undefined *)fcn.180098710(arg1, 0x28, *(undefined *)(arg1 + 4));
        uVar2 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
        puVar11[2] = 0xd;
        puVar11[1] = uVar2 & 3;
        *puVar11 = *(undefined *)(arg1 + 4);
        *(int64_t *)(puVar11 + 0x10) = iVar4;
        iVar15 = *(int32_t *)(iVar4 + 0x40);
        *(int32_t *)(puVar11 + 0x18) = iVar15;
        if (0xfffffffffffffff < (uint64_t)(int64_t)iVar15) {
            fcn.180098420(arg1);
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        uVar12 = func_0x000180098670(arg1, (int64_t)iVar15 << 4, *(undefined *)(arg1 + 4));
        *(undefined8 *)(puVar11 + 0x20) = uVar12;
        iVar17 = 0;
        iVar5 = *(int64_t *)(arg1 + 0x40);
        iVar15 = 0;
        iVar16 = *(int64_t *)(arg1 + 0x28);
        if (0 < *(int32_t *)(iVar4 + 0x40)) {
            do {
                iVar14 = (int64_t)iVar15;
                iVar15 = iVar15 + 1;
                *(undefined4 *)(*(int64_t *)(puVar11 + 0x20) + 0xc + iVar14 * 0x10) = 0;
            } while (iVar15 < *(int32_t *)(iVar4 + 0x40));
        }
        puVar6 = *(undefined8 **)(arg1 + 0x40);
        *puVar6 = puVar11;
        *(undefined4 *)((int64_t)puVar6 + 0xc) = 0xd;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        iVar15 = (int32_t)(iVar5 - iVar16 >> 4);
        if (iVar15 != 1) {
            if (iVar15 != 2) {
                fcn.180088560(arg1, 0x18063f040, *(int64_t *)(iVar4 + 0x10) + 0x18);
                pcVar7 = (code *)swi(3);
                (*pcVar7)();
                return;
            }
            if (0 < *(int32_t *)(iVar4 + 0x40)) {
                do {
                    iVar16 = (int64_t)iVar17;
                    var_2ch = 6;
                    var_38h = *(int64_t *)(*(int64_t *)(iVar4 + 0x28) + iVar16 * 8);
                    fcn.1800a8490(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, (int64_t)&var_38h, 
                                  *(int64_t *)(arg1 + 0x40) + -0x10);
                    iVar5 = *(int64_t *)(arg1 + 0x40);
                    iVar17 = iVar17 + 1;
                    uVar8 = *(undefined4 *)(iVar5 + -0xc);
                    uVar9 = *(undefined4 *)(iVar5 + -8);
                    uVar10 = *(undefined4 *)(iVar5 + -4);
                    puVar1 = (undefined4 *)(*(int64_t *)(puVar11 + 0x20) + iVar16 * 0x10);
                    *puVar1 = *(undefined4 *)(iVar5 + -0x10);
                    puVar1[1] = uVar8;
                    puVar1[2] = uVar9;
                    puVar1[3] = uVar10;
                } while (iVar17 < *(int32_t *)(iVar4 + 0x40));
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        if ((puVar11[1] & 4) != 0) {
            iVar4 = *(int64_t *)(arg1 + 0x20);
            puVar11[1] = puVar11[1] & 0xfb;
            *(undefined8 *)(puVar11 + 8) = *(undefined8 *)(iVar4 + 0x18);
            *(undefined **)(iVar4 + 0x18) = puVar11;
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_58);
        return;
    }
    fcn.180088470(arg1, 1, 0xc);
    pcVar7 = (code *)swi(3);
    (*pcVar7)();
    return;
}

// ============================================================
// Function: FUN_1800a8f7c
// Address: 0x1800a8f7c
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800a8e60(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    undefined4 *puVar1;
    uint8_t uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined *puVar11;
    undefined8 uVar12;
    int64_t *piVar13;
    int64_t iVar14;
    int32_t iVar15;
    int64_t iVar16;
    int32_t iVar17;
    int64_t var_10h;
    undefined auStack_58 [32];
    int64_t var_38h;
    undefined4 var_2ch;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    piVar3 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar3;
    if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar13 + 0xc) == 0xc)) {
        iVar4 = *piVar3;
        puVar11 = (undefined *)fcn.180098710(arg1, 0x28, *(undefined *)(arg1 + 4));
        uVar2 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
        puVar11[2] = 0xd;
        puVar11[1] = uVar2 & 3;
        *puVar11 = *(undefined *)(arg1 + 4);
        *(int64_t *)(puVar11 + 0x10) = iVar4;
        iVar15 = *(int32_t *)(iVar4 + 0x40);
        *(int32_t *)(puVar11 + 0x18) = iVar15;
        if (0xfffffffffffffff < (uint64_t)(int64_t)iVar15) {
            fcn.180098420(arg1);
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        uVar12 = func_0x000180098670(arg1, (int64_t)iVar15 << 4, *(undefined *)(arg1 + 4));
        *(undefined8 *)(puVar11 + 0x20) = uVar12;
        iVar17 = 0;
        iVar5 = *(int64_t *)(arg1 + 0x40);
        iVar15 = 0;
        iVar16 = *(int64_t *)(arg1 + 0x28);
        if (0 < *(int32_t *)(iVar4 + 0x40)) {
            do {
                iVar14 = (int64_t)iVar15;
                iVar15 = iVar15 + 1;
                *(undefined4 *)(*(int64_t *)(puVar11 + 0x20) + 0xc + iVar14 * 0x10) = 0;
            } while (iVar15 < *(int32_t *)(iVar4 + 0x40));
        }
        puVar6 = *(undefined8 **)(arg1 + 0x40);
        *puVar6 = puVar11;
        *(undefined4 *)((int64_t)puVar6 + 0xc) = 0xd;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        iVar15 = (int32_t)(iVar5 - iVar16 >> 4);
        if (iVar15 != 1) {
            if (iVar15 != 2) {
                fcn.180088560(arg1, 0x18063f040, *(int64_t *)(iVar4 + 0x10) + 0x18);
                pcVar7 = (code *)swi(3);
                (*pcVar7)();
                return;
            }
            if (0 < *(int32_t *)(iVar4 + 0x40)) {
                do {
                    iVar16 = (int64_t)iVar17;
                    var_2ch = 6;
                    var_38h = *(int64_t *)(*(int64_t *)(iVar4 + 0x28) + iVar16 * 8);
                    fcn.1800a8490(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, (int64_t)&var_38h, 
                                  *(int64_t *)(arg1 + 0x40) + -0x10);
                    iVar5 = *(int64_t *)(arg1 + 0x40);
                    iVar17 = iVar17 + 1;
                    uVar8 = *(undefined4 *)(iVar5 + -0xc);
                    uVar9 = *(undefined4 *)(iVar5 + -8);
                    uVar10 = *(undefined4 *)(iVar5 + -4);
                    puVar1 = (undefined4 *)(*(int64_t *)(puVar11 + 0x20) + iVar16 * 0x10);
                    *puVar1 = *(undefined4 *)(iVar5 + -0x10);
                    puVar1[1] = uVar8;
                    puVar1[2] = uVar9;
                    puVar1[3] = uVar10;
                } while (iVar17 < *(int32_t *)(iVar4 + 0x40));
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        if ((puVar11[1] & 4) != 0) {
            iVar4 = *(int64_t *)(arg1 + 0x20);
            puVar11[1] = puVar11[1] & 0xfb;
            *(undefined8 *)(puVar11 + 8) = *(undefined8 *)(iVar4 + 0x18);
            *(undefined **)(iVar4 + 0x18) = puVar11;
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_58);
        return;
    }
    fcn.180088470(arg1, 1, 0xc);
    pcVar7 = (code *)swi(3);
    (*pcVar7)();
    return;
}

// ============================================================
// Function: FUN_1800a8fd7
// Address: 0x1800a8fd7
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800a8e60(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    undefined4 *puVar1;
    uint8_t uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined *puVar11;
    undefined8 uVar12;
    int64_t *piVar13;
    int64_t iVar14;
    int32_t iVar15;
    int64_t iVar16;
    int32_t iVar17;
    int64_t var_10h;
    undefined auStack_58 [32];
    int64_t var_38h;
    undefined4 var_2ch;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    piVar3 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar3;
    if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar13 + 0xc) == 0xc)) {
        iVar4 = *piVar3;
        puVar11 = (undefined *)fcn.180098710(arg1, 0x28, *(undefined *)(arg1 + 4));
        uVar2 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
        puVar11[2] = 0xd;
        puVar11[1] = uVar2 & 3;
        *puVar11 = *(undefined *)(arg1 + 4);
        *(int64_t *)(puVar11 + 0x10) = iVar4;
        iVar15 = *(int32_t *)(iVar4 + 0x40);
        *(int32_t *)(puVar11 + 0x18) = iVar15;
        if (0xfffffffffffffff < (uint64_t)(int64_t)iVar15) {
            fcn.180098420(arg1);
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        uVar12 = func_0x000180098670(arg1, (int64_t)iVar15 << 4, *(undefined *)(arg1 + 4));
        *(undefined8 *)(puVar11 + 0x20) = uVar12;
        iVar17 = 0;
        iVar5 = *(int64_t *)(arg1 + 0x40);
        iVar15 = 0;
        iVar16 = *(int64_t *)(arg1 + 0x28);
        if (0 < *(int32_t *)(iVar4 + 0x40)) {
            do {
                iVar14 = (int64_t)iVar15;
                iVar15 = iVar15 + 1;
                *(undefined4 *)(*(int64_t *)(puVar11 + 0x20) + 0xc + iVar14 * 0x10) = 0;
            } while (iVar15 < *(int32_t *)(iVar4 + 0x40));
        }
        puVar6 = *(undefined8 **)(arg1 + 0x40);
        *puVar6 = puVar11;
        *(undefined4 *)((int64_t)puVar6 + 0xc) = 0xd;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        iVar15 = (int32_t)(iVar5 - iVar16 >> 4);
        if (iVar15 != 1) {
            if (iVar15 != 2) {
                fcn.180088560(arg1, 0x18063f040, *(int64_t *)(iVar4 + 0x10) + 0x18);
                pcVar7 = (code *)swi(3);
                (*pcVar7)();
                return;
            }
            if (0 < *(int32_t *)(iVar4 + 0x40)) {
                do {
                    iVar16 = (int64_t)iVar17;
                    var_2ch = 6;
                    var_38h = *(int64_t *)(*(int64_t *)(iVar4 + 0x28) + iVar16 * 8);
                    fcn.1800a8490(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, (int64_t)&var_38h, 
                                  *(int64_t *)(arg1 + 0x40) + -0x10);
                    iVar5 = *(int64_t *)(arg1 + 0x40);
                    iVar17 = iVar17 + 1;
                    uVar8 = *(undefined4 *)(iVar5 + -0xc);
                    uVar9 = *(undefined4 *)(iVar5 + -8);
                    uVar10 = *(undefined4 *)(iVar5 + -4);
                    puVar1 = (undefined4 *)(*(int64_t *)(puVar11 + 0x20) + iVar16 * 0x10);
                    *puVar1 = *(undefined4 *)(iVar5 + -0x10);
                    puVar1[1] = uVar8;
                    puVar1[2] = uVar9;
                    puVar1[3] = uVar10;
                } while (iVar17 < *(int32_t *)(iVar4 + 0x40));
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        if ((puVar11[1] & 4) != 0) {
            iVar4 = *(int64_t *)(arg1 + 0x20);
            puVar11[1] = puVar11[1] & 0xfb;
            *(undefined8 *)(puVar11 + 8) = *(undefined8 *)(iVar4 + 0x18);
            *(undefined **)(iVar4 + 0x18) = puVar11;
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_58);
        return;
    }
    fcn.180088470(arg1, 1, 0xc);
    pcVar7 = (code *)swi(3);
    (*pcVar7)();
    return;
}

// ============================================================
// Function: FUN_1800a901c
// Address: 0x1800a901c
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800a8e60(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    undefined4 *puVar1;
    uint8_t uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined *puVar11;
    undefined8 uVar12;
    int64_t *piVar13;
    int64_t iVar14;
    int32_t iVar15;
    int64_t iVar16;
    int32_t iVar17;
    int64_t var_10h;
    undefined auStack_58 [32];
    int64_t var_38h;
    undefined4 var_2ch;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    piVar3 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar3;
    if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar13 + 0xc) == 0xc)) {
        iVar4 = *piVar3;
        puVar11 = (undefined *)fcn.180098710(arg1, 0x28, *(undefined *)(arg1 + 4));
        uVar2 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
        puVar11[2] = 0xd;
        puVar11[1] = uVar2 & 3;
        *puVar11 = *(undefined *)(arg1 + 4);
        *(int64_t *)(puVar11 + 0x10) = iVar4;
        iVar15 = *(int32_t *)(iVar4 + 0x40);
        *(int32_t *)(puVar11 + 0x18) = iVar15;
        if (0xfffffffffffffff < (uint64_t)(int64_t)iVar15) {
            fcn.180098420(arg1);
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        uVar12 = func_0x000180098670(arg1, (int64_t)iVar15 << 4, *(undefined *)(arg1 + 4));
        *(undefined8 *)(puVar11 + 0x20) = uVar12;
        iVar17 = 0;
        iVar5 = *(int64_t *)(arg1 + 0x40);
        iVar15 = 0;
        iVar16 = *(int64_t *)(arg1 + 0x28);
        if (0 < *(int32_t *)(iVar4 + 0x40)) {
            do {
                iVar14 = (int64_t)iVar15;
                iVar15 = iVar15 + 1;
                *(undefined4 *)(*(int64_t *)(puVar11 + 0x20) + 0xc + iVar14 * 0x10) = 0;
            } while (iVar15 < *(int32_t *)(iVar4 + 0x40));
        }
        puVar6 = *(undefined8 **)(arg1 + 0x40);
        *puVar6 = puVar11;
        *(undefined4 *)((int64_t)puVar6 + 0xc) = 0xd;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        iVar15 = (int32_t)(iVar5 - iVar16 >> 4);
        if (iVar15 != 1) {
            if (iVar15 != 2) {
                fcn.180088560(arg1, 0x18063f040, *(int64_t *)(iVar4 + 0x10) + 0x18);
                pcVar7 = (code *)swi(3);
                (*pcVar7)();
                return;
            }
            if (0 < *(int32_t *)(iVar4 + 0x40)) {
                do {
                    iVar16 = (int64_t)iVar17;
                    var_2ch = 6;
                    var_38h = *(int64_t *)(*(int64_t *)(iVar4 + 0x28) + iVar16 * 8);
                    fcn.1800a8490(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, (int64_t)&var_38h, 
                                  *(int64_t *)(arg1 + 0x40) + -0x10);
                    iVar5 = *(int64_t *)(arg1 + 0x40);
                    iVar17 = iVar17 + 1;
                    uVar8 = *(undefined4 *)(iVar5 + -0xc);
                    uVar9 = *(undefined4 *)(iVar5 + -8);
                    uVar10 = *(undefined4 *)(iVar5 + -4);
                    puVar1 = (undefined4 *)(*(int64_t *)(puVar11 + 0x20) + iVar16 * 0x10);
                    *puVar1 = *(undefined4 *)(iVar5 + -0x10);
                    puVar1[1] = uVar8;
                    puVar1[2] = uVar9;
                    puVar1[3] = uVar10;
                } while (iVar17 < *(int32_t *)(iVar4 + 0x40));
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        if ((puVar11[1] & 4) != 0) {
            iVar4 = *(int64_t *)(arg1 + 0x20);
            puVar11[1] = puVar11[1] & 0xfb;
            *(undefined8 *)(puVar11 + 8) = *(undefined8 *)(iVar4 + 0x18);
            *(undefined **)(iVar4 + 0x18) = puVar11;
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_58);
        return;
    }
    fcn.180088470(arg1, 1, 0xc);
    pcVar7 = (code *)swi(3);
    (*pcVar7)();
    return;
}

// ============================================================
// Function: FUN_1800a9030
// Address: 0x1800a9030
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800a8e60(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    undefined4 *puVar1;
    uint8_t uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined *puVar11;
    undefined8 uVar12;
    int64_t *piVar13;
    int64_t iVar14;
    int32_t iVar15;
    int64_t iVar16;
    int32_t iVar17;
    int64_t var_10h;
    undefined auStack_58 [32];
    int64_t var_38h;
    undefined4 var_2ch;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    piVar3 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar3;
    if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar13 + 0xc) == 0xc)) {
        iVar4 = *piVar3;
        puVar11 = (undefined *)fcn.180098710(arg1, 0x28, *(undefined *)(arg1 + 4));
        uVar2 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
        puVar11[2] = 0xd;
        puVar11[1] = uVar2 & 3;
        *puVar11 = *(undefined *)(arg1 + 4);
        *(int64_t *)(puVar11 + 0x10) = iVar4;
        iVar15 = *(int32_t *)(iVar4 + 0x40);
        *(int32_t *)(puVar11 + 0x18) = iVar15;
        if (0xfffffffffffffff < (uint64_t)(int64_t)iVar15) {
            fcn.180098420(arg1);
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        uVar12 = func_0x000180098670(arg1, (int64_t)iVar15 << 4, *(undefined *)(arg1 + 4));
        *(undefined8 *)(puVar11 + 0x20) = uVar12;
        iVar17 = 0;
        iVar5 = *(int64_t *)(arg1 + 0x40);
        iVar15 = 0;
        iVar16 = *(int64_t *)(arg1 + 0x28);
        if (0 < *(int32_t *)(iVar4 + 0x40)) {
            do {
                iVar14 = (int64_t)iVar15;
                iVar15 = iVar15 + 1;
                *(undefined4 *)(*(int64_t *)(puVar11 + 0x20) + 0xc + iVar14 * 0x10) = 0;
            } while (iVar15 < *(int32_t *)(iVar4 + 0x40));
        }
        puVar6 = *(undefined8 **)(arg1 + 0x40);
        *puVar6 = puVar11;
        *(undefined4 *)((int64_t)puVar6 + 0xc) = 0xd;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        iVar15 = (int32_t)(iVar5 - iVar16 >> 4);
        if (iVar15 != 1) {
            if (iVar15 != 2) {
                fcn.180088560(arg1, 0x18063f040, *(int64_t *)(iVar4 + 0x10) + 0x18);
                pcVar7 = (code *)swi(3);
                (*pcVar7)();
                return;
            }
            if (0 < *(int32_t *)(iVar4 + 0x40)) {
                do {
                    iVar16 = (int64_t)iVar17;
                    var_2ch = 6;
                    var_38h = *(int64_t *)(*(int64_t *)(iVar4 + 0x28) + iVar16 * 8);
                    fcn.1800a8490(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, (int64_t)&var_38h, 
                                  *(int64_t *)(arg1 + 0x40) + -0x10);
                    iVar5 = *(int64_t *)(arg1 + 0x40);
                    iVar17 = iVar17 + 1;
                    uVar8 = *(undefined4 *)(iVar5 + -0xc);
                    uVar9 = *(undefined4 *)(iVar5 + -8);
                    uVar10 = *(undefined4 *)(iVar5 + -4);
                    puVar1 = (undefined4 *)(*(int64_t *)(puVar11 + 0x20) + iVar16 * 0x10);
                    *puVar1 = *(undefined4 *)(iVar5 + -0x10);
                    puVar1[1] = uVar8;
                    puVar1[2] = uVar9;
                    puVar1[3] = uVar10;
                } while (iVar17 < *(int32_t *)(iVar4 + 0x40));
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        if ((puVar11[1] & 4) != 0) {
            iVar4 = *(int64_t *)(arg1 + 0x20);
            puVar11[1] = puVar11[1] & 0xfb;
            *(undefined8 *)(puVar11 + 8) = *(undefined8 *)(iVar4 + 0x18);
            *(undefined **)(iVar4 + 0x18) = puVar11;
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_58);
        return;
    }
    fcn.180088470(arg1, 1, 0xc);
    pcVar7 = (code *)swi(3);
    (*pcVar7)();
    return;
}

// ============================================================
// Function: FUN_1800a9048
// Address: 0x1800a9048
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800a8e60(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    undefined4 *puVar1;
    uint8_t uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined *puVar11;
    undefined8 uVar12;
    int64_t *piVar13;
    int64_t iVar14;
    int32_t iVar15;
    int64_t iVar16;
    int32_t iVar17;
    int64_t var_10h;
    undefined auStack_58 [32];
    int64_t var_38h;
    undefined4 var_2ch;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    piVar3 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar3;
    if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar13 + 0xc) == 0xc)) {
        iVar4 = *piVar3;
        puVar11 = (undefined *)fcn.180098710(arg1, 0x28, *(undefined *)(arg1 + 4));
        uVar2 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
        puVar11[2] = 0xd;
        puVar11[1] = uVar2 & 3;
        *puVar11 = *(undefined *)(arg1 + 4);
        *(int64_t *)(puVar11 + 0x10) = iVar4;
        iVar15 = *(int32_t *)(iVar4 + 0x40);
        *(int32_t *)(puVar11 + 0x18) = iVar15;
        if (0xfffffffffffffff < (uint64_t)(int64_t)iVar15) {
            fcn.180098420(arg1);
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        uVar12 = func_0x000180098670(arg1, (int64_t)iVar15 << 4, *(undefined *)(arg1 + 4));
        *(undefined8 *)(puVar11 + 0x20) = uVar12;
        iVar17 = 0;
        iVar5 = *(int64_t *)(arg1 + 0x40);
        iVar15 = 0;
        iVar16 = *(int64_t *)(arg1 + 0x28);
        if (0 < *(int32_t *)(iVar4 + 0x40)) {
            do {
                iVar14 = (int64_t)iVar15;
                iVar15 = iVar15 + 1;
                *(undefined4 *)(*(int64_t *)(puVar11 + 0x20) + 0xc + iVar14 * 0x10) = 0;
            } while (iVar15 < *(int32_t *)(iVar4 + 0x40));
        }
        puVar6 = *(undefined8 **)(arg1 + 0x40);
        *puVar6 = puVar11;
        *(undefined4 *)((int64_t)puVar6 + 0xc) = 0xd;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        iVar15 = (int32_t)(iVar5 - iVar16 >> 4);
        if (iVar15 != 1) {
            if (iVar15 != 2) {
                fcn.180088560(arg1, 0x18063f040, *(int64_t *)(iVar4 + 0x10) + 0x18);
                pcVar7 = (code *)swi(3);
                (*pcVar7)();
                return;
            }
            if (0 < *(int32_t *)(iVar4 + 0x40)) {
                do {
                    iVar16 = (int64_t)iVar17;
                    var_2ch = 6;
                    var_38h = *(int64_t *)(*(int64_t *)(iVar4 + 0x28) + iVar16 * 8);
                    fcn.1800a8490(arg1, *(int64_t *)(arg1 + 0x28) + 0x10, (int64_t)&var_38h, 
                                  *(int64_t *)(arg1 + 0x40) + -0x10);
                    iVar5 = *(int64_t *)(arg1 + 0x40);
                    iVar17 = iVar17 + 1;
                    uVar8 = *(undefined4 *)(iVar5 + -0xc);
                    uVar9 = *(undefined4 *)(iVar5 + -8);
                    uVar10 = *(undefined4 *)(iVar5 + -4);
                    puVar1 = (undefined4 *)(*(int64_t *)(puVar11 + 0x20) + iVar16 * 0x10);
                    *puVar1 = *(undefined4 *)(iVar5 + -0x10);
                    puVar1[1] = uVar8;
                    puVar1[2] = uVar9;
                    puVar1[3] = uVar10;
                } while (iVar17 < *(int32_t *)(iVar4 + 0x40));
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        if ((puVar11[1] & 4) != 0) {
            iVar4 = *(int64_t *)(arg1 + 0x20);
            puVar11[1] = puVar11[1] & 0xfb;
            *(undefined8 *)(puVar11 + 8) = *(undefined8 *)(iVar4 + 0x18);
            *(undefined **)(iVar4 + 0x18) = puVar11;
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_58);
        return;
    }
    fcn.180088470(arg1, 1, 0xc);
    pcVar7 = (code *)swi(3);
    (*pcVar7)();
    return;
}

// ============================================================
// Function: FUN_1800a9050
// Address: 0x1800a9050
// Size: 753 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800a9050(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    double dVar1;
    double dVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int32_t iVar11;
    bool bVar12;
    undefined8 uVar13;
    double dVar14;
    double dVar15;
    undefined auVar16 [16];
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar11 = (int32_t)arg_28h;
    // switch table (92 cases) at 0x1800aa0d0
    switch((int32_t)arg3) {
    case 2:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            uVar5 = *(uint64_t *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(uint64_t *)(arg1 + 8) = uVar5 & 0x7fffffffffffffff;
            goto code_r0x0001800a937e;
        }
        break;
    case 3:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048e730(*(undefined8 *)(arg4 + 8));
code_r0x0001800a9105:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = dVar15;
            goto code_r0x0001800a937e;
        }
        break;
    case 4:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048ec30(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 5:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x00018048f110(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 6:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048eec0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 7:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048d6f0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 8:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804901d0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 9:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048f790(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 10:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8) / 0.0174532925199433;
            goto code_r0x0001800a9105;
        }
        break;
    case 0xb:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804905c0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xc:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804909e0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xd:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x000180490b30(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xf:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x00018046d9a0(*(undefined8 *)(arg4 + 8), 
                                                 CONCAT44(1, (int32_t)*(double *)(arg4 + 0x20)));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x10:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048d7c0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x11:
        if (arg_28h == 1) {
            if (*(int32_t *)arg4 == 3) {
                dVar15 = (double)func_0x000180491150(*(undefined8 *)(arg4 + 8));
                goto code_r0x0001800a9105;
            }
        } else if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            uVar13 = *(undefined8 *)(arg4 + 8);
            dVar15 = *(double *)(arg4 + 0x20);
            *(undefined4 *)arg1 = 3;
            if (dVar15 == 2.0) {
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                uVar13 = func_0x000180491680(uVar13);
            } else {
                if (dVar15 != 10.0) {
                    *(undefined4 *)(arg1 + 4) = 0;
                    *(undefined8 *)(arg1 + 0x10) = 0;
                    dVar15 = (double)func_0x000180491150();
                    dVar14 = (double)func_0x000180491150();
                    *(double *)(arg1 + 8) = dVar15 / dVar14;
                    goto code_r0x0001800a937e;
                }
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                uVar13 = func_0x00018048d7c0();
            }
            *(undefined8 *)(arg1 + 8) = uVar13;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x12:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8);
            uVar5 = 1;
            dVar14 = dVar15;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar5 * 0x18) != 3) goto code_r0x0001800a9448;
                    dVar15 = *(double *)(arg4 + 8 + uVar5 * 0x18);
                    uVar5 = uVar5 + 1;
                    if (dVar15 <= dVar14) {
                        dVar15 = dVar14;
                    }
                    dVar14 = dVar15;
                } while (uVar5 < (uint64_t)arg_28h);
            }
code_r0x0001800a9e57:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = dVar15;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x13:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8);
            uVar5 = 1;
            dVar14 = dVar15;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar5 * 0x18) != 3) goto code_r0x0001800a9448;
                    dVar15 = *(double *)(arg4 + 8 + uVar5 * 0x18);
                    uVar5 = uVar5 + 1;
                    if (dVar14 <= dVar15) {
                        dVar15 = dVar14;
                    }
                    dVar14 = dVar15;
                } while (uVar5 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9e57;
        }
        break;
    case 0x15:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x000180491d70(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x16:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8) * 0.0174532925199433;
            goto code_r0x0001800a9105;
        }
        break;
    case 0x17:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494070(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x18:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180493440(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x19:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            if (*(double *)(arg4 + 8) < 0.0) {
                dVar15 = (double)func_0x0001804944a0(*(undefined8 *)(arg4 + 8));
            } else {
                auVar16._8_8_ = 0;
                auVar16._0_8_ = *(double *)(arg4 + 8);
                auVar16 = sqrtpd(ZEXT816(0), auVar16);
                dVar15 = auVar16._0_8_;
            }
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1a:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494da0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494600(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1c:
        if ((((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20)) {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) =
                 (double)(uint64_t)(uint32_t)((int32_t)(int64_t)dVar14 >> ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x1d:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 & (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
code_r0x0001800a9661:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = (double)(uVar5 & 0xffffffff);
            goto code_r0x0001800a937e;
        }
        break;
    case 0x1e:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)(uint64_t)~(uint32_t)(int64_t)*(double *)(arg4 + 8);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1f:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 | (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9661;
        }
        break;
    case 0x20:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 ^ (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9661;
        }
        break;
    case 0x21:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar7 = (uint32_t)uVar5;
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar7 = (uint32_t)uVar5 & (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10);
                    uVar5 = (uint64_t)uVar7;
                } while (uVar9 < (uint64_t)arg_28h);
            }
            *(undefined8 *)arg1 = 2;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(bool *)(arg1 + 8) = uVar7 != 0;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x22:
        if ((((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           ((arg_28h == 2 || (*(int32_t *)(arg4 + 0x30) == 3)))) {
            iVar11 = (int32_t)*(double *)(arg4 + 0x20);
            if (arg_28h == 2) {
                iVar4 = 1;
            } else {
                iVar4 = (int32_t)*(double *)(arg4 + 0x38);
            }
            if (((-1 < iVar11) && (0 < iVar4)) && (iVar4 + iVar11 < 0x21)) {
                dVar15 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 3;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(double *)(arg1 + 8) =
                     (double)(uint64_t)
                             ((uint32_t)(int64_t)dVar15 >> ((uint8_t)iVar11 & 0x1f) & ~(-2 << ((char)iVar4 - 1U & 0x1f))
                             );
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x23:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = *(double *)(arg4 + 0x20);
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            uVar3 = (uint8_t)(int32_t)dVar15;
            uVar7 = (uint32_t)(int64_t)dVar14;
            *(double *)(arg1 + 8) = (double)(uint64_t)(uVar7 >> (-uVar3 & 0x1f) | uVar7 << (uVar3 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x24:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) &&
           ((*(int32_t *)(arg4 + 0x18) == 3 && (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20))))
        {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) =
                 (double)(uint64_t)(uint32_t)((int32_t)(int64_t)dVar14 << ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x25:
        if (((2 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) &&
           (((*(int32_t *)(arg4 + 0x18) == 3 && (*(int32_t *)(arg4 + 0x30) == 3)) &&
            ((arg_28h == 3 || (*(int32_t *)(arg4 + 0x48) == 3)))))) {
            iVar11 = (int32_t)*(double *)(arg4 + 0x38);
            if (arg_28h == 3) {
                iVar4 = 1;
            } else {
                iVar4 = (int32_t)*(double *)(arg4 + 0x50);
            }
            if (((-1 < iVar11) && (0 < iVar4)) && (iVar4 + iVar11 < 0x21)) {
                dVar15 = *(double *)(arg4 + 0x20);
                uVar7 = ~(-2 << ((char)iVar4 - 1U & 0x1f));
                dVar14 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 3;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(double *)(arg1 + 8) =
                     (double)(uint64_t)
                             (~(uVar7 << ((uint8_t)iVar11 & 0x1f)) & (uint32_t)(int64_t)dVar14 |
                             ((uint32_t)(int64_t)dVar15 & uVar7) << ((uint8_t)iVar11 & 0x1f));
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x26:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = *(double *)(arg4 + 0x20);
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            uVar3 = (uint8_t)(int32_t)dVar15;
            uVar7 = (uint32_t)(int64_t)dVar14;
            *(double *)(arg1 + 8) = (double)(uint64_t)(uVar7 << (-uVar3 & 0x1f) | uVar7 >> (uVar3 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x27:
        if ((((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20)) {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = (double)(uint64_t)((uint32_t)(int64_t)dVar14 >> ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x28:
        if ((arg_28h == 1) && (*(int32_t *)arg4 != 0)) {
    // switch table (6 cases) at 0x1800aa1f8
            switch(*(int32_t *)arg4) {
            case 1:
code_r0x0001800a9ccf:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063da4c;
                *(undefined4 *)(arg1 + 4) = 3;
                break;
            case 2:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063ec88;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 3:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e2d0;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 4:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a0;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 5:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a8;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 6:
code_r0x0001800a9d5b:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x180625fe4;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            default:
                goto code_r0x0001800a9448;
            }
            goto code_r0x0001800a937e;
        }
        break;
    case 0x29:
        if (arg_28h == 1) {
            if ((*(int32_t *)arg4 == 6) && (*(int32_t *)(arg4 + 4) != 0)) {
                dVar15 = (double)(uint32_t)**(uint8_t **)(arg4 + 8);
                goto code_r0x0001800a9105;
            }
        } else if ((((arg_28h == 2) && (*(int32_t *)arg4 == 6)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
                  ((uVar7 = (uint32_t)*(double *)(arg4 + 0x20), 0 < (int32_t)uVar7 && (uVar7 <= *(uint32_t *)(arg4 + 4))
                   ))) {
            dVar15 = (double)(uint32_t)*(uint8_t *)(*(int64_t *)(arg4 + 8) + -1 + (int64_t)(int32_t)uVar7);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x2a:
        if ((uint64_t)arg_28h < 0x80) {
            _var_b8h = ZEXT816(0);
            uVar5 = 0;
            _var_a8h = _var_b8h;
            _var_98h = _var_b8h;
            _var_88h = _var_b8h;
            _var_78h = _var_b8h;
            _var_68h = _var_b8h;
            _var_58h = _var_b8h;
            _var_48h = _var_b8h;
            if (arg_28h != 0) {
                do {
                    if ((*(int32_t *)(arg4 + uVar5 * 0x18) != 3) ||
                       (uVar7 = (uint32_t)*(double *)(arg4 + 8 + uVar5 * 0x18), (uVar7 & 0xff) != uVar7))
                    goto code_r0x0001800a9448;
                    *(char *)((int64_t)&var_b8h + uVar5) = (char)uVar7;
                    uVar5 = uVar5 + 1;
                } while (uVar5 < (uint64_t)arg_28h);
                piVar8 = &var_b8h;
                iVar10 = arg_28h;
code_r0x0001800a9c37:
                func_0x0001800d6f20(arg2, &var_c0h, piVar8, iVar10);
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(int64_t *)(arg1 + 8) = var_c0h;
                *(int32_t *)(arg1 + 4) = (int32_t)arg_28h;
                goto code_r0x0001800a937e;
            }
code_r0x0001800a9c5f:
            *(undefined8 *)arg1 = 6;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(undefined8 *)(arg1 + 8) = 0x1805aadb1;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x2b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 6)) {
            dVar15 = (double)(uint64_t)*(uint32_t *)(arg4 + 4);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x2c:
        if ((arg_28h == 1) && (*(int32_t *)arg4 != 0)) {
    // switch table (6 cases) at 0x1800aa210
            switch(*(int32_t *)arg4) {
            case 1:
                goto code_r0x0001800a9ccf;
            case 2:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063ec88;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 3:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e2d0;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 4:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a0;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            default:
                goto code_r0x0001800a9448;
            case 6:
                goto code_r0x0001800a9d5b;
            }
            goto code_r0x0001800a937e;
        }
        break;
    case 0x2d:
        if (((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 6)) &&
           ((*(int32_t *)(arg4 + 0x18) == 3 && (((uint64_t)arg_28h < 3 || (*(int32_t *)(arg4 + 0x30) == 3)))))) {
            iVar11 = *(int32_t *)(arg4 + 4);
            iVar4 = (int32_t)*(double *)(arg4 + 0x20);
            iVar6 = iVar11;
            if (2 < (uint64_t)arg_28h) {
                iVar6 = (int32_t)*(double *)(arg4 + 0x38);
            }
            if (iVar4 < 0) {
                iVar4 = iVar4 + 1 + iVar11;
            }
            if (iVar6 < 0) {
                iVar6 = iVar6 + 1 + iVar11;
            }
            if (0 < iVar6) {
                if (iVar4 < 1) {
                    iVar4 = 1;
                }
                if (iVar11 < iVar6) {
                    iVar6 = iVar11;
                }
                if (iVar4 <= iVar6) {
                    uVar7 = (iVar6 - iVar4) + 1;
                    arg_28h = (int64_t)uVar7;
                    piVar8 = (int64_t *)((int64_t)(iVar4 + -1) + *(int64_t *)(arg4 + 8));
                    iVar10 = (int64_t)(int32_t)uVar7;
                    goto code_r0x0001800a9c37;
                }
            }
            goto code_r0x0001800a9c5f;
        }
        break;
    case 0x2e:
        if ((((arg_28h == 3) && (*(int32_t *)arg4 == iVar11)) && (*(int32_t *)(arg4 + 0x18) == iVar11)) &&
           (*(int32_t *)(arg4 + 0x30) == iVar11)) {
            dVar14 = *(double *)(arg4 + 0x20);
            dVar15 = *(double *)(arg4 + 0x38);
            if (dVar14 <= dVar15) {
                if (dVar14 <= *(double *)(arg4 + 8)) {
                    dVar14 = *(double *)(arg4 + 8);
                }
                if (dVar14 <= dVar15) {
                    dVar15 = dVar14;
                }
                goto code_r0x0001800a9e57;
            }
        }
        break;
    case 0x2f:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = 0.0;
            if (*(double *)(arg4 + 8) <= 0.0) {
                if (*(double *)(arg4 + 8) < 0.0) {
                    dVar15 = -1.0;
                }
            } else {
                dVar15 = 1.0;
            }
            goto code_r0x0001800a9105;
        }
        break;
    case 0x30:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018046e0b0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x36:
        if (((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            if (arg_28h == 2) {
                dVar15 = *(double *)(arg4 + 0x20);
                dVar14 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 5;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(float *)(arg1 + 8) = (float)dVar14;
                *(float *)(arg1 + 0xc) = (float)dVar15;
                goto code_r0x0001800a937e;
            }
            if (arg_28h == 3) {
                if (*(int32_t *)(arg4 + 0x30) == iVar11) {
                    dVar15 = *(double *)(arg4 + 8);
                    dVar14 = *(double *)(arg4 + 0x38);
                    dVar1 = *(double *)(arg4 + 0x20);
                    *(undefined8 *)arg1 = 5;
                    *(undefined4 *)(arg1 + 0x14) = 0;
                    *(float *)(arg1 + 8) = (float)dVar15;
                    *(float *)(arg1 + 0xc) = (float)dVar1;
                    *(float *)(arg1 + 0x10) = (float)dVar14;
                    goto code_r0x0001800a937e;
                }
            } else if (((arg_28h == 4) && (*(int32_t *)(arg4 + 0x30) == 3)) && (*(int32_t *)(arg4 + 0x48) == 3)) {
                dVar15 = *(double *)(arg4 + 0x20);
                dVar14 = *(double *)(arg4 + 8);
                dVar1 = *(double *)(arg4 + 0x50);
                dVar2 = *(double *)(arg4 + 0x38);
                *(undefined8 *)arg1 = 5;
                *(float *)(arg1 + 8) = (float)dVar14;
                *(float *)(arg1 + 0xc) = (float)dVar15;
                *(float *)(arg1 + 0x10) = (float)dVar2;
                *(float *)(arg1 + 0x14) = (float)dVar1;
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x59:
        if ((((arg_28h == 3) && (*(int32_t *)arg4 == iVar11)) && (*(int32_t *)(arg4 + 0x18) == iVar11)) &&
           (*(int32_t *)(arg4 + 0x30) == iVar11)) {
            dVar15 = *(double *)(arg4 + 0x20);
            if (*(double *)(arg4 + 0x38) != 1.0) {
                dVar15 = (*(double *)(arg4 + 0x20) - *(double *)(arg4 + 8)) * *(double *)(arg4 + 0x38) +
                         *(double *)(arg4 + 8);
            }
            goto code_r0x0001800a9e57;
        }
        break;
    case 0x5b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = NAN(*(double *)(arg4 + 8));
code_r0x0001800aa05d:
            *(undefined8 *)arg1 = 2;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(bool *)(arg1 + 8) = bVar12;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x5c:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = INFINITY <= (double)(*(uint64_t *)(arg4 + 8) & 0x7fffffffffffffff);
            goto code_r0x0001800aa05d;
        }
        break;
    case 0x5d:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = ((uint32_t)((uint64_t)*(undefined8 *)(arg4 + 8) >> 0x34) & 0x7ff) != 0x7ff;
            goto code_r0x0001800aa05d;
        }
    }
code_r0x0001800a9448:
    var_d8h = 0;
    var_d0h = 0;
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 0;
    *(undefined4 *)(arg1 + 8) = 0;
    *(undefined4 *)(arg1 + 0xc) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
code_r0x0001800a937e:
    fcn.180459870(var_38h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_1800a9341
// Address: 0x1800a9341
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800a9050(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    double dVar1;
    double dVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int32_t iVar11;
    bool bVar12;
    undefined8 uVar13;
    double dVar14;
    double dVar15;
    undefined auVar16 [16];
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar11 = (int32_t)arg_28h;
    // switch table (92 cases) at 0x1800aa0d0
    switch((int32_t)arg3) {
    case 2:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            uVar5 = *(uint64_t *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(uint64_t *)(arg1 + 8) = uVar5 & 0x7fffffffffffffff;
            goto code_r0x0001800a937e;
        }
        break;
    case 3:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048e730(*(undefined8 *)(arg4 + 8));
code_r0x0001800a9105:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = dVar15;
            goto code_r0x0001800a937e;
        }
        break;
    case 4:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048ec30(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 5:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x00018048f110(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 6:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048eec0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 7:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048d6f0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 8:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804901d0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 9:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048f790(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 10:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8) / 0.0174532925199433;
            goto code_r0x0001800a9105;
        }
        break;
    case 0xb:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804905c0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xc:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804909e0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xd:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x000180490b30(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xf:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x00018046d9a0(*(undefined8 *)(arg4 + 8), 
                                                 CONCAT44(1, (int32_t)*(double *)(arg4 + 0x20)));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x10:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048d7c0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x11:
        if (arg_28h == 1) {
            if (*(int32_t *)arg4 == 3) {
                dVar15 = (double)func_0x000180491150(*(undefined8 *)(arg4 + 8));
                goto code_r0x0001800a9105;
            }
        } else if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            uVar13 = *(undefined8 *)(arg4 + 8);
            dVar15 = *(double *)(arg4 + 0x20);
            *(undefined4 *)arg1 = 3;
            if (dVar15 == 2.0) {
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                uVar13 = func_0x000180491680(uVar13);
            } else {
                if (dVar15 != 10.0) {
                    *(undefined4 *)(arg1 + 4) = 0;
                    *(undefined8 *)(arg1 + 0x10) = 0;
                    dVar15 = (double)func_0x000180491150();
                    dVar14 = (double)func_0x000180491150();
                    *(double *)(arg1 + 8) = dVar15 / dVar14;
                    goto code_r0x0001800a937e;
                }
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                uVar13 = func_0x00018048d7c0();
            }
            *(undefined8 *)(arg1 + 8) = uVar13;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x12:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8);
            uVar5 = 1;
            dVar14 = dVar15;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar5 * 0x18) != 3) goto code_r0x0001800a9448;
                    dVar15 = *(double *)(arg4 + 8 + uVar5 * 0x18);
                    uVar5 = uVar5 + 1;
                    if (dVar15 <= dVar14) {
                        dVar15 = dVar14;
                    }
                    dVar14 = dVar15;
                } while (uVar5 < (uint64_t)arg_28h);
            }
code_r0x0001800a9e57:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = dVar15;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x13:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8);
            uVar5 = 1;
            dVar14 = dVar15;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar5 * 0x18) != 3) goto code_r0x0001800a9448;
                    dVar15 = *(double *)(arg4 + 8 + uVar5 * 0x18);
                    uVar5 = uVar5 + 1;
                    if (dVar14 <= dVar15) {
                        dVar15 = dVar14;
                    }
                    dVar14 = dVar15;
                } while (uVar5 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9e57;
        }
        break;
    case 0x15:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x000180491d70(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x16:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8) * 0.0174532925199433;
            goto code_r0x0001800a9105;
        }
        break;
    case 0x17:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494070(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x18:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180493440(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x19:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            if (*(double *)(arg4 + 8) < 0.0) {
                dVar15 = (double)func_0x0001804944a0(*(undefined8 *)(arg4 + 8));
            } else {
                auVar16._8_8_ = 0;
                auVar16._0_8_ = *(double *)(arg4 + 8);
                auVar16 = sqrtpd(ZEXT816(0), auVar16);
                dVar15 = auVar16._0_8_;
            }
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1a:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494da0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494600(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1c:
        if ((((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20)) {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) =
                 (double)(uint64_t)(uint32_t)((int32_t)(int64_t)dVar14 >> ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x1d:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 & (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
code_r0x0001800a9661:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = (double)(uVar5 & 0xffffffff);
            goto code_r0x0001800a937e;
        }
        break;
    case 0x1e:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)(uint64_t)~(uint32_t)(int64_t)*(double *)(arg4 + 8);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1f:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 | (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9661;
        }
        break;
    case 0x20:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 ^ (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9661;
        }
        break;
    case 0x21:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar7 = (uint32_t)uVar5;
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar7 = (uint32_t)uVar5 & (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10);
                    uVar5 = (uint64_t)uVar7;
                } while (uVar9 < (uint64_t)arg_28h);
            }
            *(undefined8 *)arg1 = 2;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(bool *)(arg1 + 8) = uVar7 != 0;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x22:
        if ((((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           ((arg_28h == 2 || (*(int32_t *)(arg4 + 0x30) == 3)))) {
            iVar11 = (int32_t)*(double *)(arg4 + 0x20);
            if (arg_28h == 2) {
                iVar4 = 1;
            } else {
                iVar4 = (int32_t)*(double *)(arg4 + 0x38);
            }
            if (((-1 < iVar11) && (0 < iVar4)) && (iVar4 + iVar11 < 0x21)) {
                dVar15 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 3;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(double *)(arg1 + 8) =
                     (double)(uint64_t)
                             ((uint32_t)(int64_t)dVar15 >> ((uint8_t)iVar11 & 0x1f) & ~(-2 << ((char)iVar4 - 1U & 0x1f))
                             );
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x23:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = *(double *)(arg4 + 0x20);
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            uVar3 = (uint8_t)(int32_t)dVar15;
            uVar7 = (uint32_t)(int64_t)dVar14;
            *(double *)(arg1 + 8) = (double)(uint64_t)(uVar7 >> (-uVar3 & 0x1f) | uVar7 << (uVar3 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x24:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) &&
           ((*(int32_t *)(arg4 + 0x18) == 3 && (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20))))
        {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) =
                 (double)(uint64_t)(uint32_t)((int32_t)(int64_t)dVar14 << ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x25:
        if (((2 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) &&
           (((*(int32_t *)(arg4 + 0x18) == 3 && (*(int32_t *)(arg4 + 0x30) == 3)) &&
            ((arg_28h == 3 || (*(int32_t *)(arg4 + 0x48) == 3)))))) {
            iVar11 = (int32_t)*(double *)(arg4 + 0x38);
            if (arg_28h == 3) {
                iVar4 = 1;
            } else {
                iVar4 = (int32_t)*(double *)(arg4 + 0x50);
            }
            if (((-1 < iVar11) && (0 < iVar4)) && (iVar4 + iVar11 < 0x21)) {
                dVar15 = *(double *)(arg4 + 0x20);
                uVar7 = ~(-2 << ((char)iVar4 - 1U & 0x1f));
                dVar14 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 3;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(double *)(arg1 + 8) =
                     (double)(uint64_t)
                             (~(uVar7 << ((uint8_t)iVar11 & 0x1f)) & (uint32_t)(int64_t)dVar14 |
                             ((uint32_t)(int64_t)dVar15 & uVar7) << ((uint8_t)iVar11 & 0x1f));
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x26:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = *(double *)(arg4 + 0x20);
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            uVar3 = (uint8_t)(int32_t)dVar15;
            uVar7 = (uint32_t)(int64_t)dVar14;
            *(double *)(arg1 + 8) = (double)(uint64_t)(uVar7 << (-uVar3 & 0x1f) | uVar7 >> (uVar3 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x27:
        if ((((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20)) {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = (double)(uint64_t)((uint32_t)(int64_t)dVar14 >> ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x28:
        if ((arg_28h == 1) && (*(int32_t *)arg4 != 0)) {
    // switch table (6 cases) at 0x1800aa1f8
            switch(*(int32_t *)arg4) {
            case 1:
code_r0x0001800a9ccf:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063da4c;
                *(undefined4 *)(arg1 + 4) = 3;
                break;
            case 2:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063ec88;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 3:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e2d0;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 4:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a0;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 5:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a8;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 6:
code_r0x0001800a9d5b:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x180625fe4;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            default:
                goto code_r0x0001800a9448;
            }
            goto code_r0x0001800a937e;
        }
        break;
    case 0x29:
        if (arg_28h == 1) {
            if ((*(int32_t *)arg4 == 6) && (*(int32_t *)(arg4 + 4) != 0)) {
                dVar15 = (double)(uint32_t)**(uint8_t **)(arg4 + 8);
                goto code_r0x0001800a9105;
            }
        } else if ((((arg_28h == 2) && (*(int32_t *)arg4 == 6)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
                  ((uVar7 = (uint32_t)*(double *)(arg4 + 0x20), 0 < (int32_t)uVar7 && (uVar7 <= *(uint32_t *)(arg4 + 4))
                   ))) {
            dVar15 = (double)(uint32_t)*(uint8_t *)(*(int64_t *)(arg4 + 8) + -1 + (int64_t)(int32_t)uVar7);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x2a:
        if ((uint64_t)arg_28h < 0x80) {
            _var_b8h = ZEXT816(0);
            uVar5 = 0;
            _var_a8h = _var_b8h;
            _var_98h = _var_b8h;
            _var_88h = _var_b8h;
            _var_78h = _var_b8h;
            _var_68h = _var_b8h;
            _var_58h = _var_b8h;
            _var_48h = _var_b8h;
            if (arg_28h != 0) {
                do {
                    if ((*(int32_t *)(arg4 + uVar5 * 0x18) != 3) ||
                       (uVar7 = (uint32_t)*(double *)(arg4 + 8 + uVar5 * 0x18), (uVar7 & 0xff) != uVar7))
                    goto code_r0x0001800a9448;
                    *(char *)((int64_t)&var_b8h + uVar5) = (char)uVar7;
                    uVar5 = uVar5 + 1;
                } while (uVar5 < (uint64_t)arg_28h);
                piVar8 = &var_b8h;
                iVar10 = arg_28h;
code_r0x0001800a9c37:
                func_0x0001800d6f20(arg2, &var_c0h, piVar8, iVar10);
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(int64_t *)(arg1 + 8) = var_c0h;
                *(int32_t *)(arg1 + 4) = (int32_t)arg_28h;
                goto code_r0x0001800a937e;
            }
code_r0x0001800a9c5f:
            *(undefined8 *)arg1 = 6;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(undefined8 *)(arg1 + 8) = 0x1805aadb1;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x2b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 6)) {
            dVar15 = (double)(uint64_t)*(uint32_t *)(arg4 + 4);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x2c:
        if ((arg_28h == 1) && (*(int32_t *)arg4 != 0)) {
    // switch table (6 cases) at 0x1800aa210
            switch(*(int32_t *)arg4) {
            case 1:
                goto code_r0x0001800a9ccf;
            case 2:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063ec88;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 3:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e2d0;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 4:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a0;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            default:
                goto code_r0x0001800a9448;
            case 6:
                goto code_r0x0001800a9d5b;
            }
            goto code_r0x0001800a937e;
        }
        break;
    case 0x2d:
        if (((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 6)) &&
           ((*(int32_t *)(arg4 + 0x18) == 3 && (((uint64_t)arg_28h < 3 || (*(int32_t *)(arg4 + 0x30) == 3)))))) {
            iVar11 = *(int32_t *)(arg4 + 4);
            iVar4 = (int32_t)*(double *)(arg4 + 0x20);
            iVar6 = iVar11;
            if (2 < (uint64_t)arg_28h) {
                iVar6 = (int32_t)*(double *)(arg4 + 0x38);
            }
            if (iVar4 < 0) {
                iVar4 = iVar4 + 1 + iVar11;
            }
            if (iVar6 < 0) {
                iVar6 = iVar6 + 1 + iVar11;
            }
            if (0 < iVar6) {
                if (iVar4 < 1) {
                    iVar4 = 1;
                }
                if (iVar11 < iVar6) {
                    iVar6 = iVar11;
                }
                if (iVar4 <= iVar6) {
                    uVar7 = (iVar6 - iVar4) + 1;
                    arg_28h = (int64_t)uVar7;
                    piVar8 = (int64_t *)((int64_t)(iVar4 + -1) + *(int64_t *)(arg4 + 8));
                    iVar10 = (int64_t)(int32_t)uVar7;
                    goto code_r0x0001800a9c37;
                }
            }
            goto code_r0x0001800a9c5f;
        }
        break;
    case 0x2e:
        if ((((arg_28h == 3) && (*(int32_t *)arg4 == iVar11)) && (*(int32_t *)(arg4 + 0x18) == iVar11)) &&
           (*(int32_t *)(arg4 + 0x30) == iVar11)) {
            dVar14 = *(double *)(arg4 + 0x20);
            dVar15 = *(double *)(arg4 + 0x38);
            if (dVar14 <= dVar15) {
                if (dVar14 <= *(double *)(arg4 + 8)) {
                    dVar14 = *(double *)(arg4 + 8);
                }
                if (dVar14 <= dVar15) {
                    dVar15 = dVar14;
                }
                goto code_r0x0001800a9e57;
            }
        }
        break;
    case 0x2f:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = 0.0;
            if (*(double *)(arg4 + 8) <= 0.0) {
                if (*(double *)(arg4 + 8) < 0.0) {
                    dVar15 = -1.0;
                }
            } else {
                dVar15 = 1.0;
            }
            goto code_r0x0001800a9105;
        }
        break;
    case 0x30:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018046e0b0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x36:
        if (((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            if (arg_28h == 2) {
                dVar15 = *(double *)(arg4 + 0x20);
                dVar14 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 5;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(float *)(arg1 + 8) = (float)dVar14;
                *(float *)(arg1 + 0xc) = (float)dVar15;
                goto code_r0x0001800a937e;
            }
            if (arg_28h == 3) {
                if (*(int32_t *)(arg4 + 0x30) == iVar11) {
                    dVar15 = *(double *)(arg4 + 8);
                    dVar14 = *(double *)(arg4 + 0x38);
                    dVar1 = *(double *)(arg4 + 0x20);
                    *(undefined8 *)arg1 = 5;
                    *(undefined4 *)(arg1 + 0x14) = 0;
                    *(float *)(arg1 + 8) = (float)dVar15;
                    *(float *)(arg1 + 0xc) = (float)dVar1;
                    *(float *)(arg1 + 0x10) = (float)dVar14;
                    goto code_r0x0001800a937e;
                }
            } else if (((arg_28h == 4) && (*(int32_t *)(arg4 + 0x30) == 3)) && (*(int32_t *)(arg4 + 0x48) == 3)) {
                dVar15 = *(double *)(arg4 + 0x20);
                dVar14 = *(double *)(arg4 + 8);
                dVar1 = *(double *)(arg4 + 0x50);
                dVar2 = *(double *)(arg4 + 0x38);
                *(undefined8 *)arg1 = 5;
                *(float *)(arg1 + 8) = (float)dVar14;
                *(float *)(arg1 + 0xc) = (float)dVar15;
                *(float *)(arg1 + 0x10) = (float)dVar2;
                *(float *)(arg1 + 0x14) = (float)dVar1;
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x59:
        if ((((arg_28h == 3) && (*(int32_t *)arg4 == iVar11)) && (*(int32_t *)(arg4 + 0x18) == iVar11)) &&
           (*(int32_t *)(arg4 + 0x30) == iVar11)) {
            dVar15 = *(double *)(arg4 + 0x20);
            if (*(double *)(arg4 + 0x38) != 1.0) {
                dVar15 = (*(double *)(arg4 + 0x20) - *(double *)(arg4 + 8)) * *(double *)(arg4 + 0x38) +
                         *(double *)(arg4 + 8);
            }
            goto code_r0x0001800a9e57;
        }
        break;
    case 0x5b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = NAN(*(double *)(arg4 + 8));
code_r0x0001800aa05d:
            *(undefined8 *)arg1 = 2;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(bool *)(arg1 + 8) = bVar12;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x5c:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = INFINITY <= (double)(*(uint64_t *)(arg4 + 8) & 0x7fffffffffffffff);
            goto code_r0x0001800aa05d;
        }
        break;
    case 0x5d:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = ((uint32_t)((uint64_t)*(undefined8 *)(arg4 + 8) >> 0x34) & 0x7ff) != 0x7ff;
            goto code_r0x0001800aa05d;
        }
    }
code_r0x0001800a9448:
    var_d8h = 0;
    var_d0h = 0;
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 0;
    *(undefined4 *)(arg1 + 8) = 0;
    *(undefined4 *)(arg1 + 0xc) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
code_r0x0001800a937e:
    fcn.180459870(var_38h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_1800a937e
// Address: 0x1800a937e
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800a9050(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    double dVar1;
    double dVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int32_t iVar11;
    bool bVar12;
    undefined8 uVar13;
    double dVar14;
    double dVar15;
    undefined auVar16 [16];
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar11 = (int32_t)arg_28h;
    // switch table (92 cases) at 0x1800aa0d0
    switch((int32_t)arg3) {
    case 2:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            uVar5 = *(uint64_t *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(uint64_t *)(arg1 + 8) = uVar5 & 0x7fffffffffffffff;
            goto code_r0x0001800a937e;
        }
        break;
    case 3:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048e730(*(undefined8 *)(arg4 + 8));
code_r0x0001800a9105:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = dVar15;
            goto code_r0x0001800a937e;
        }
        break;
    case 4:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048ec30(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 5:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x00018048f110(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 6:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048eec0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 7:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048d6f0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 8:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804901d0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 9:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048f790(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 10:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8) / 0.0174532925199433;
            goto code_r0x0001800a9105;
        }
        break;
    case 0xb:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804905c0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xc:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804909e0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xd:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x000180490b30(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xf:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x00018046d9a0(*(undefined8 *)(arg4 + 8), 
                                                 CONCAT44(1, (int32_t)*(double *)(arg4 + 0x20)));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x10:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048d7c0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x11:
        if (arg_28h == 1) {
            if (*(int32_t *)arg4 == 3) {
                dVar15 = (double)func_0x000180491150(*(undefined8 *)(arg4 + 8));
                goto code_r0x0001800a9105;
            }
        } else if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            uVar13 = *(undefined8 *)(arg4 + 8);
            dVar15 = *(double *)(arg4 + 0x20);
            *(undefined4 *)arg1 = 3;
            if (dVar15 == 2.0) {
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                uVar13 = func_0x000180491680(uVar13);
            } else {
                if (dVar15 != 10.0) {
                    *(undefined4 *)(arg1 + 4) = 0;
                    *(undefined8 *)(arg1 + 0x10) = 0;
                    dVar15 = (double)func_0x000180491150();
                    dVar14 = (double)func_0x000180491150();
                    *(double *)(arg1 + 8) = dVar15 / dVar14;
                    goto code_r0x0001800a937e;
                }
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                uVar13 = func_0x00018048d7c0();
            }
            *(undefined8 *)(arg1 + 8) = uVar13;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x12:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8);
            uVar5 = 1;
            dVar14 = dVar15;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar5 * 0x18) != 3) goto code_r0x0001800a9448;
                    dVar15 = *(double *)(arg4 + 8 + uVar5 * 0x18);
                    uVar5 = uVar5 + 1;
                    if (dVar15 <= dVar14) {
                        dVar15 = dVar14;
                    }
                    dVar14 = dVar15;
                } while (uVar5 < (uint64_t)arg_28h);
            }
code_r0x0001800a9e57:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = dVar15;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x13:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8);
            uVar5 = 1;
            dVar14 = dVar15;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar5 * 0x18) != 3) goto code_r0x0001800a9448;
                    dVar15 = *(double *)(arg4 + 8 + uVar5 * 0x18);
                    uVar5 = uVar5 + 1;
                    if (dVar14 <= dVar15) {
                        dVar15 = dVar14;
                    }
                    dVar14 = dVar15;
                } while (uVar5 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9e57;
        }
        break;
    case 0x15:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x000180491d70(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x16:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8) * 0.0174532925199433;
            goto code_r0x0001800a9105;
        }
        break;
    case 0x17:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494070(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x18:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180493440(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x19:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            if (*(double *)(arg4 + 8) < 0.0) {
                dVar15 = (double)func_0x0001804944a0(*(undefined8 *)(arg4 + 8));
            } else {
                auVar16._8_8_ = 0;
                auVar16._0_8_ = *(double *)(arg4 + 8);
                auVar16 = sqrtpd(ZEXT816(0), auVar16);
                dVar15 = auVar16._0_8_;
            }
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1a:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494da0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494600(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1c:
        if ((((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20)) {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) =
                 (double)(uint64_t)(uint32_t)((int32_t)(int64_t)dVar14 >> ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x1d:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 & (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
code_r0x0001800a9661:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = (double)(uVar5 & 0xffffffff);
            goto code_r0x0001800a937e;
        }
        break;
    case 0x1e:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)(uint64_t)~(uint32_t)(int64_t)*(double *)(arg4 + 8);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1f:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 | (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9661;
        }
        break;
    case 0x20:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 ^ (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9661;
        }
        break;
    case 0x21:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar7 = (uint32_t)uVar5;
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar7 = (uint32_t)uVar5 & (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10);
                    uVar5 = (uint64_t)uVar7;
                } while (uVar9 < (uint64_t)arg_28h);
            }
            *(undefined8 *)arg1 = 2;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(bool *)(arg1 + 8) = uVar7 != 0;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x22:
        if ((((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           ((arg_28h == 2 || (*(int32_t *)(arg4 + 0x30) == 3)))) {
            iVar11 = (int32_t)*(double *)(arg4 + 0x20);
            if (arg_28h == 2) {
                iVar4 = 1;
            } else {
                iVar4 = (int32_t)*(double *)(arg4 + 0x38);
            }
            if (((-1 < iVar11) && (0 < iVar4)) && (iVar4 + iVar11 < 0x21)) {
                dVar15 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 3;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(double *)(arg1 + 8) =
                     (double)(uint64_t)
                             ((uint32_t)(int64_t)dVar15 >> ((uint8_t)iVar11 & 0x1f) & ~(-2 << ((char)iVar4 - 1U & 0x1f))
                             );
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x23:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = *(double *)(arg4 + 0x20);
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            uVar3 = (uint8_t)(int32_t)dVar15;
            uVar7 = (uint32_t)(int64_t)dVar14;
            *(double *)(arg1 + 8) = (double)(uint64_t)(uVar7 >> (-uVar3 & 0x1f) | uVar7 << (uVar3 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x24:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) &&
           ((*(int32_t *)(arg4 + 0x18) == 3 && (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20))))
        {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) =
                 (double)(uint64_t)(uint32_t)((int32_t)(int64_t)dVar14 << ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x25:
        if (((2 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) &&
           (((*(int32_t *)(arg4 + 0x18) == 3 && (*(int32_t *)(arg4 + 0x30) == 3)) &&
            ((arg_28h == 3 || (*(int32_t *)(arg4 + 0x48) == 3)))))) {
            iVar11 = (int32_t)*(double *)(arg4 + 0x38);
            if (arg_28h == 3) {
                iVar4 = 1;
            } else {
                iVar4 = (int32_t)*(double *)(arg4 + 0x50);
            }
            if (((-1 < iVar11) && (0 < iVar4)) && (iVar4 + iVar11 < 0x21)) {
                dVar15 = *(double *)(arg4 + 0x20);
                uVar7 = ~(-2 << ((char)iVar4 - 1U & 0x1f));
                dVar14 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 3;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(double *)(arg1 + 8) =
                     (double)(uint64_t)
                             (~(uVar7 << ((uint8_t)iVar11 & 0x1f)) & (uint32_t)(int64_t)dVar14 |
                             ((uint32_t)(int64_t)dVar15 & uVar7) << ((uint8_t)iVar11 & 0x1f));
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x26:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = *(double *)(arg4 + 0x20);
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            uVar3 = (uint8_t)(int32_t)dVar15;
            uVar7 = (uint32_t)(int64_t)dVar14;
            *(double *)(arg1 + 8) = (double)(uint64_t)(uVar7 << (-uVar3 & 0x1f) | uVar7 >> (uVar3 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x27:
        if ((((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20)) {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = (double)(uint64_t)((uint32_t)(int64_t)dVar14 >> ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x28:
        if ((arg_28h == 1) && (*(int32_t *)arg4 != 0)) {
    // switch table (6 cases) at 0x1800aa1f8
            switch(*(int32_t *)arg4) {
            case 1:
code_r0x0001800a9ccf:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063da4c;
                *(undefined4 *)(arg1 + 4) = 3;
                break;
            case 2:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063ec88;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 3:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e2d0;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 4:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a0;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 5:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a8;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 6:
code_r0x0001800a9d5b:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x180625fe4;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            default:
                goto code_r0x0001800a9448;
            }
            goto code_r0x0001800a937e;
        }
        break;
    case 0x29:
        if (arg_28h == 1) {
            if ((*(int32_t *)arg4 == 6) && (*(int32_t *)(arg4 + 4) != 0)) {
                dVar15 = (double)(uint32_t)**(uint8_t **)(arg4 + 8);
                goto code_r0x0001800a9105;
            }
        } else if ((((arg_28h == 2) && (*(int32_t *)arg4 == 6)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
                  ((uVar7 = (uint32_t)*(double *)(arg4 + 0x20), 0 < (int32_t)uVar7 && (uVar7 <= *(uint32_t *)(arg4 + 4))
                   ))) {
            dVar15 = (double)(uint32_t)*(uint8_t *)(*(int64_t *)(arg4 + 8) + -1 + (int64_t)(int32_t)uVar7);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x2a:
        if ((uint64_t)arg_28h < 0x80) {
            _var_b8h = ZEXT816(0);
            uVar5 = 0;
            _var_a8h = _var_b8h;
            _var_98h = _var_b8h;
            _var_88h = _var_b8h;
            _var_78h = _var_b8h;
            _var_68h = _var_b8h;
            _var_58h = _var_b8h;
            _var_48h = _var_b8h;
            if (arg_28h != 0) {
                do {
                    if ((*(int32_t *)(arg4 + uVar5 * 0x18) != 3) ||
                       (uVar7 = (uint32_t)*(double *)(arg4 + 8 + uVar5 * 0x18), (uVar7 & 0xff) != uVar7))
                    goto code_r0x0001800a9448;
                    *(char *)((int64_t)&var_b8h + uVar5) = (char)uVar7;
                    uVar5 = uVar5 + 1;
                } while (uVar5 < (uint64_t)arg_28h);
                piVar8 = &var_b8h;
                iVar10 = arg_28h;
code_r0x0001800a9c37:
                func_0x0001800d6f20(arg2, &var_c0h, piVar8, iVar10);
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(int64_t *)(arg1 + 8) = var_c0h;
                *(int32_t *)(arg1 + 4) = (int32_t)arg_28h;
                goto code_r0x0001800a937e;
            }
code_r0x0001800a9c5f:
            *(undefined8 *)arg1 = 6;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(undefined8 *)(arg1 + 8) = 0x1805aadb1;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x2b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 6)) {
            dVar15 = (double)(uint64_t)*(uint32_t *)(arg4 + 4);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x2c:
        if ((arg_28h == 1) && (*(int32_t *)arg4 != 0)) {
    // switch table (6 cases) at 0x1800aa210
            switch(*(int32_t *)arg4) {
            case 1:
                goto code_r0x0001800a9ccf;
            case 2:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063ec88;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 3:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e2d0;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 4:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a0;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            default:
                goto code_r0x0001800a9448;
            case 6:
                goto code_r0x0001800a9d5b;
            }
            goto code_r0x0001800a937e;
        }
        break;
    case 0x2d:
        if (((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 6)) &&
           ((*(int32_t *)(arg4 + 0x18) == 3 && (((uint64_t)arg_28h < 3 || (*(int32_t *)(arg4 + 0x30) == 3)))))) {
            iVar11 = *(int32_t *)(arg4 + 4);
            iVar4 = (int32_t)*(double *)(arg4 + 0x20);
            iVar6 = iVar11;
            if (2 < (uint64_t)arg_28h) {
                iVar6 = (int32_t)*(double *)(arg4 + 0x38);
            }
            if (iVar4 < 0) {
                iVar4 = iVar4 + 1 + iVar11;
            }
            if (iVar6 < 0) {
                iVar6 = iVar6 + 1 + iVar11;
            }
            if (0 < iVar6) {
                if (iVar4 < 1) {
                    iVar4 = 1;
                }
                if (iVar11 < iVar6) {
                    iVar6 = iVar11;
                }
                if (iVar4 <= iVar6) {
                    uVar7 = (iVar6 - iVar4) + 1;
                    arg_28h = (int64_t)uVar7;
                    piVar8 = (int64_t *)((int64_t)(iVar4 + -1) + *(int64_t *)(arg4 + 8));
                    iVar10 = (int64_t)(int32_t)uVar7;
                    goto code_r0x0001800a9c37;
                }
            }
            goto code_r0x0001800a9c5f;
        }
        break;
    case 0x2e:
        if ((((arg_28h == 3) && (*(int32_t *)arg4 == iVar11)) && (*(int32_t *)(arg4 + 0x18) == iVar11)) &&
           (*(int32_t *)(arg4 + 0x30) == iVar11)) {
            dVar14 = *(double *)(arg4 + 0x20);
            dVar15 = *(double *)(arg4 + 0x38);
            if (dVar14 <= dVar15) {
                if (dVar14 <= *(double *)(arg4 + 8)) {
                    dVar14 = *(double *)(arg4 + 8);
                }
                if (dVar14 <= dVar15) {
                    dVar15 = dVar14;
                }
                goto code_r0x0001800a9e57;
            }
        }
        break;
    case 0x2f:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = 0.0;
            if (*(double *)(arg4 + 8) <= 0.0) {
                if (*(double *)(arg4 + 8) < 0.0) {
                    dVar15 = -1.0;
                }
            } else {
                dVar15 = 1.0;
            }
            goto code_r0x0001800a9105;
        }
        break;
    case 0x30:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018046e0b0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x36:
        if (((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            if (arg_28h == 2) {
                dVar15 = *(double *)(arg4 + 0x20);
                dVar14 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 5;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(float *)(arg1 + 8) = (float)dVar14;
                *(float *)(arg1 + 0xc) = (float)dVar15;
                goto code_r0x0001800a937e;
            }
            if (arg_28h == 3) {
                if (*(int32_t *)(arg4 + 0x30) == iVar11) {
                    dVar15 = *(double *)(arg4 + 8);
                    dVar14 = *(double *)(arg4 + 0x38);
                    dVar1 = *(double *)(arg4 + 0x20);
                    *(undefined8 *)arg1 = 5;
                    *(undefined4 *)(arg1 + 0x14) = 0;
                    *(float *)(arg1 + 8) = (float)dVar15;
                    *(float *)(arg1 + 0xc) = (float)dVar1;
                    *(float *)(arg1 + 0x10) = (float)dVar14;
                    goto code_r0x0001800a937e;
                }
            } else if (((arg_28h == 4) && (*(int32_t *)(arg4 + 0x30) == 3)) && (*(int32_t *)(arg4 + 0x48) == 3)) {
                dVar15 = *(double *)(arg4 + 0x20);
                dVar14 = *(double *)(arg4 + 8);
                dVar1 = *(double *)(arg4 + 0x50);
                dVar2 = *(double *)(arg4 + 0x38);
                *(undefined8 *)arg1 = 5;
                *(float *)(arg1 + 8) = (float)dVar14;
                *(float *)(arg1 + 0xc) = (float)dVar15;
                *(float *)(arg1 + 0x10) = (float)dVar2;
                *(float *)(arg1 + 0x14) = (float)dVar1;
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x59:
        if ((((arg_28h == 3) && (*(int32_t *)arg4 == iVar11)) && (*(int32_t *)(arg4 + 0x18) == iVar11)) &&
           (*(int32_t *)(arg4 + 0x30) == iVar11)) {
            dVar15 = *(double *)(arg4 + 0x20);
            if (*(double *)(arg4 + 0x38) != 1.0) {
                dVar15 = (*(double *)(arg4 + 0x20) - *(double *)(arg4 + 8)) * *(double *)(arg4 + 0x38) +
                         *(double *)(arg4 + 8);
            }
            goto code_r0x0001800a9e57;
        }
        break;
    case 0x5b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = NAN(*(double *)(arg4 + 8));
code_r0x0001800aa05d:
            *(undefined8 *)arg1 = 2;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(bool *)(arg1 + 8) = bVar12;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x5c:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = INFINITY <= (double)(*(uint64_t *)(arg4 + 8) & 0x7fffffffffffffff);
            goto code_r0x0001800aa05d;
        }
        break;
    case 0x5d:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = ((uint32_t)((uint64_t)*(undefined8 *)(arg4 + 8) >> 0x34) & 0x7ff) != 0x7ff;
            goto code_r0x0001800aa05d;
        }
    }
code_r0x0001800a9448:
    var_d8h = 0;
    var_d0h = 0;
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 0;
    *(undefined4 *)(arg1 + 8) = 0;
    *(undefined4 *)(arg1 + 0xc) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
code_r0x0001800a937e:
    fcn.180459870(var_38h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_1800a93a2
// Address: 0x1800a93a2
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800a9050(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    double dVar1;
    double dVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int32_t iVar11;
    bool bVar12;
    undefined8 uVar13;
    double dVar14;
    double dVar15;
    undefined auVar16 [16];
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar11 = (int32_t)arg_28h;
    // switch table (92 cases) at 0x1800aa0d0
    switch((int32_t)arg3) {
    case 2:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            uVar5 = *(uint64_t *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(uint64_t *)(arg1 + 8) = uVar5 & 0x7fffffffffffffff;
            goto code_r0x0001800a937e;
        }
        break;
    case 3:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048e730(*(undefined8 *)(arg4 + 8));
code_r0x0001800a9105:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = dVar15;
            goto code_r0x0001800a937e;
        }
        break;
    case 4:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048ec30(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 5:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x00018048f110(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 6:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048eec0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 7:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048d6f0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 8:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804901d0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 9:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048f790(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 10:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8) / 0.0174532925199433;
            goto code_r0x0001800a9105;
        }
        break;
    case 0xb:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804905c0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xc:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804909e0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xd:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x000180490b30(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xf:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x00018046d9a0(*(undefined8 *)(arg4 + 8), 
                                                 CONCAT44(1, (int32_t)*(double *)(arg4 + 0x20)));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x10:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048d7c0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x11:
        if (arg_28h == 1) {
            if (*(int32_t *)arg4 == 3) {
                dVar15 = (double)func_0x000180491150(*(undefined8 *)(arg4 + 8));
                goto code_r0x0001800a9105;
            }
        } else if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            uVar13 = *(undefined8 *)(arg4 + 8);
            dVar15 = *(double *)(arg4 + 0x20);
            *(undefined4 *)arg1 = 3;
            if (dVar15 == 2.0) {
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                uVar13 = func_0x000180491680(uVar13);
            } else {
                if (dVar15 != 10.0) {
                    *(undefined4 *)(arg1 + 4) = 0;
                    *(undefined8 *)(arg1 + 0x10) = 0;
                    dVar15 = (double)func_0x000180491150();
                    dVar14 = (double)func_0x000180491150();
                    *(double *)(arg1 + 8) = dVar15 / dVar14;
                    goto code_r0x0001800a937e;
                }
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                uVar13 = func_0x00018048d7c0();
            }
            *(undefined8 *)(arg1 + 8) = uVar13;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x12:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8);
            uVar5 = 1;
            dVar14 = dVar15;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar5 * 0x18) != 3) goto code_r0x0001800a9448;
                    dVar15 = *(double *)(arg4 + 8 + uVar5 * 0x18);
                    uVar5 = uVar5 + 1;
                    if (dVar15 <= dVar14) {
                        dVar15 = dVar14;
                    }
                    dVar14 = dVar15;
                } while (uVar5 < (uint64_t)arg_28h);
            }
code_r0x0001800a9e57:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = dVar15;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x13:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8);
            uVar5 = 1;
            dVar14 = dVar15;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar5 * 0x18) != 3) goto code_r0x0001800a9448;
                    dVar15 = *(double *)(arg4 + 8 + uVar5 * 0x18);
                    uVar5 = uVar5 + 1;
                    if (dVar14 <= dVar15) {
                        dVar15 = dVar14;
                    }
                    dVar14 = dVar15;
                } while (uVar5 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9e57;
        }
        break;
    case 0x15:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x000180491d70(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x16:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8) * 0.0174532925199433;
            goto code_r0x0001800a9105;
        }
        break;
    case 0x17:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494070(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x18:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180493440(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x19:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            if (*(double *)(arg4 + 8) < 0.0) {
                dVar15 = (double)func_0x0001804944a0(*(undefined8 *)(arg4 + 8));
            } else {
                auVar16._8_8_ = 0;
                auVar16._0_8_ = *(double *)(arg4 + 8);
                auVar16 = sqrtpd(ZEXT816(0), auVar16);
                dVar15 = auVar16._0_8_;
            }
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1a:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494da0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494600(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1c:
        if ((((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20)) {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) =
                 (double)(uint64_t)(uint32_t)((int32_t)(int64_t)dVar14 >> ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x1d:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 & (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
code_r0x0001800a9661:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = (double)(uVar5 & 0xffffffff);
            goto code_r0x0001800a937e;
        }
        break;
    case 0x1e:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)(uint64_t)~(uint32_t)(int64_t)*(double *)(arg4 + 8);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1f:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 | (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9661;
        }
        break;
    case 0x20:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 ^ (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9661;
        }
        break;
    case 0x21:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar7 = (uint32_t)uVar5;
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar7 = (uint32_t)uVar5 & (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10);
                    uVar5 = (uint64_t)uVar7;
                } while (uVar9 < (uint64_t)arg_28h);
            }
            *(undefined8 *)arg1 = 2;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(bool *)(arg1 + 8) = uVar7 != 0;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x22:
        if ((((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           ((arg_28h == 2 || (*(int32_t *)(arg4 + 0x30) == 3)))) {
            iVar11 = (int32_t)*(double *)(arg4 + 0x20);
            if (arg_28h == 2) {
                iVar4 = 1;
            } else {
                iVar4 = (int32_t)*(double *)(arg4 + 0x38);
            }
            if (((-1 < iVar11) && (0 < iVar4)) && (iVar4 + iVar11 < 0x21)) {
                dVar15 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 3;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(double *)(arg1 + 8) =
                     (double)(uint64_t)
                             ((uint32_t)(int64_t)dVar15 >> ((uint8_t)iVar11 & 0x1f) & ~(-2 << ((char)iVar4 - 1U & 0x1f))
                             );
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x23:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = *(double *)(arg4 + 0x20);
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            uVar3 = (uint8_t)(int32_t)dVar15;
            uVar7 = (uint32_t)(int64_t)dVar14;
            *(double *)(arg1 + 8) = (double)(uint64_t)(uVar7 >> (-uVar3 & 0x1f) | uVar7 << (uVar3 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x24:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) &&
           ((*(int32_t *)(arg4 + 0x18) == 3 && (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20))))
        {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) =
                 (double)(uint64_t)(uint32_t)((int32_t)(int64_t)dVar14 << ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x25:
        if (((2 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) &&
           (((*(int32_t *)(arg4 + 0x18) == 3 && (*(int32_t *)(arg4 + 0x30) == 3)) &&
            ((arg_28h == 3 || (*(int32_t *)(arg4 + 0x48) == 3)))))) {
            iVar11 = (int32_t)*(double *)(arg4 + 0x38);
            if (arg_28h == 3) {
                iVar4 = 1;
            } else {
                iVar4 = (int32_t)*(double *)(arg4 + 0x50);
            }
            if (((-1 < iVar11) && (0 < iVar4)) && (iVar4 + iVar11 < 0x21)) {
                dVar15 = *(double *)(arg4 + 0x20);
                uVar7 = ~(-2 << ((char)iVar4 - 1U & 0x1f));
                dVar14 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 3;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(double *)(arg1 + 8) =
                     (double)(uint64_t)
                             (~(uVar7 << ((uint8_t)iVar11 & 0x1f)) & (uint32_t)(int64_t)dVar14 |
                             ((uint32_t)(int64_t)dVar15 & uVar7) << ((uint8_t)iVar11 & 0x1f));
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x26:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = *(double *)(arg4 + 0x20);
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            uVar3 = (uint8_t)(int32_t)dVar15;
            uVar7 = (uint32_t)(int64_t)dVar14;
            *(double *)(arg1 + 8) = (double)(uint64_t)(uVar7 << (-uVar3 & 0x1f) | uVar7 >> (uVar3 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x27:
        if ((((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20)) {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = (double)(uint64_t)((uint32_t)(int64_t)dVar14 >> ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x28:
        if ((arg_28h == 1) && (*(int32_t *)arg4 != 0)) {
    // switch table (6 cases) at 0x1800aa1f8
            switch(*(int32_t *)arg4) {
            case 1:
code_r0x0001800a9ccf:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063da4c;
                *(undefined4 *)(arg1 + 4) = 3;
                break;
            case 2:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063ec88;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 3:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e2d0;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 4:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a0;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 5:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a8;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 6:
code_r0x0001800a9d5b:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x180625fe4;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            default:
                goto code_r0x0001800a9448;
            }
            goto code_r0x0001800a937e;
        }
        break;
    case 0x29:
        if (arg_28h == 1) {
            if ((*(int32_t *)arg4 == 6) && (*(int32_t *)(arg4 + 4) != 0)) {
                dVar15 = (double)(uint32_t)**(uint8_t **)(arg4 + 8);
                goto code_r0x0001800a9105;
            }
        } else if ((((arg_28h == 2) && (*(int32_t *)arg4 == 6)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
                  ((uVar7 = (uint32_t)*(double *)(arg4 + 0x20), 0 < (int32_t)uVar7 && (uVar7 <= *(uint32_t *)(arg4 + 4))
                   ))) {
            dVar15 = (double)(uint32_t)*(uint8_t *)(*(int64_t *)(arg4 + 8) + -1 + (int64_t)(int32_t)uVar7);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x2a:
        if ((uint64_t)arg_28h < 0x80) {
            _var_b8h = ZEXT816(0);
            uVar5 = 0;
            _var_a8h = _var_b8h;
            _var_98h = _var_b8h;
            _var_88h = _var_b8h;
            _var_78h = _var_b8h;
            _var_68h = _var_b8h;
            _var_58h = _var_b8h;
            _var_48h = _var_b8h;
            if (arg_28h != 0) {
                do {
                    if ((*(int32_t *)(arg4 + uVar5 * 0x18) != 3) ||
                       (uVar7 = (uint32_t)*(double *)(arg4 + 8 + uVar5 * 0x18), (uVar7 & 0xff) != uVar7))
                    goto code_r0x0001800a9448;
                    *(char *)((int64_t)&var_b8h + uVar5) = (char)uVar7;
                    uVar5 = uVar5 + 1;
                } while (uVar5 < (uint64_t)arg_28h);
                piVar8 = &var_b8h;
                iVar10 = arg_28h;
code_r0x0001800a9c37:
                func_0x0001800d6f20(arg2, &var_c0h, piVar8, iVar10);
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(int64_t *)(arg1 + 8) = var_c0h;
                *(int32_t *)(arg1 + 4) = (int32_t)arg_28h;
                goto code_r0x0001800a937e;
            }
code_r0x0001800a9c5f:
            *(undefined8 *)arg1 = 6;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(undefined8 *)(arg1 + 8) = 0x1805aadb1;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x2b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 6)) {
            dVar15 = (double)(uint64_t)*(uint32_t *)(arg4 + 4);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x2c:
        if ((arg_28h == 1) && (*(int32_t *)arg4 != 0)) {
    // switch table (6 cases) at 0x1800aa210
            switch(*(int32_t *)arg4) {
            case 1:
                goto code_r0x0001800a9ccf;
            case 2:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063ec88;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 3:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e2d0;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 4:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a0;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            default:
                goto code_r0x0001800a9448;
            case 6:
                goto code_r0x0001800a9d5b;
            }
            goto code_r0x0001800a937e;
        }
        break;
    case 0x2d:
        if (((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 6)) &&
           ((*(int32_t *)(arg4 + 0x18) == 3 && (((uint64_t)arg_28h < 3 || (*(int32_t *)(arg4 + 0x30) == 3)))))) {
            iVar11 = *(int32_t *)(arg4 + 4);
            iVar4 = (int32_t)*(double *)(arg4 + 0x20);
            iVar6 = iVar11;
            if (2 < (uint64_t)arg_28h) {
                iVar6 = (int32_t)*(double *)(arg4 + 0x38);
            }
            if (iVar4 < 0) {
                iVar4 = iVar4 + 1 + iVar11;
            }
            if (iVar6 < 0) {
                iVar6 = iVar6 + 1 + iVar11;
            }
            if (0 < iVar6) {
                if (iVar4 < 1) {
                    iVar4 = 1;
                }
                if (iVar11 < iVar6) {
                    iVar6 = iVar11;
                }
                if (iVar4 <= iVar6) {
                    uVar7 = (iVar6 - iVar4) + 1;
                    arg_28h = (int64_t)uVar7;
                    piVar8 = (int64_t *)((int64_t)(iVar4 + -1) + *(int64_t *)(arg4 + 8));
                    iVar10 = (int64_t)(int32_t)uVar7;
                    goto code_r0x0001800a9c37;
                }
            }
            goto code_r0x0001800a9c5f;
        }
        break;
    case 0x2e:
        if ((((arg_28h == 3) && (*(int32_t *)arg4 == iVar11)) && (*(int32_t *)(arg4 + 0x18) == iVar11)) &&
           (*(int32_t *)(arg4 + 0x30) == iVar11)) {
            dVar14 = *(double *)(arg4 + 0x20);
            dVar15 = *(double *)(arg4 + 0x38);
            if (dVar14 <= dVar15) {
                if (dVar14 <= *(double *)(arg4 + 8)) {
                    dVar14 = *(double *)(arg4 + 8);
                }
                if (dVar14 <= dVar15) {
                    dVar15 = dVar14;
                }
                goto code_r0x0001800a9e57;
            }
        }
        break;
    case 0x2f:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = 0.0;
            if (*(double *)(arg4 + 8) <= 0.0) {
                if (*(double *)(arg4 + 8) < 0.0) {
                    dVar15 = -1.0;
                }
            } else {
                dVar15 = 1.0;
            }
            goto code_r0x0001800a9105;
        }
        break;
    case 0x30:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018046e0b0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x36:
        if (((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            if (arg_28h == 2) {
                dVar15 = *(double *)(arg4 + 0x20);
                dVar14 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 5;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(float *)(arg1 + 8) = (float)dVar14;
                *(float *)(arg1 + 0xc) = (float)dVar15;
                goto code_r0x0001800a937e;
            }
            if (arg_28h == 3) {
                if (*(int32_t *)(arg4 + 0x30) == iVar11) {
                    dVar15 = *(double *)(arg4 + 8);
                    dVar14 = *(double *)(arg4 + 0x38);
                    dVar1 = *(double *)(arg4 + 0x20);
                    *(undefined8 *)arg1 = 5;
                    *(undefined4 *)(arg1 + 0x14) = 0;
                    *(float *)(arg1 + 8) = (float)dVar15;
                    *(float *)(arg1 + 0xc) = (float)dVar1;
                    *(float *)(arg1 + 0x10) = (float)dVar14;
                    goto code_r0x0001800a937e;
                }
            } else if (((arg_28h == 4) && (*(int32_t *)(arg4 + 0x30) == 3)) && (*(int32_t *)(arg4 + 0x48) == 3)) {
                dVar15 = *(double *)(arg4 + 0x20);
                dVar14 = *(double *)(arg4 + 8);
                dVar1 = *(double *)(arg4 + 0x50);
                dVar2 = *(double *)(arg4 + 0x38);
                *(undefined8 *)arg1 = 5;
                *(float *)(arg1 + 8) = (float)dVar14;
                *(float *)(arg1 + 0xc) = (float)dVar15;
                *(float *)(arg1 + 0x10) = (float)dVar2;
                *(float *)(arg1 + 0x14) = (float)dVar1;
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x59:
        if ((((arg_28h == 3) && (*(int32_t *)arg4 == iVar11)) && (*(int32_t *)(arg4 + 0x18) == iVar11)) &&
           (*(int32_t *)(arg4 + 0x30) == iVar11)) {
            dVar15 = *(double *)(arg4 + 0x20);
            if (*(double *)(arg4 + 0x38) != 1.0) {
                dVar15 = (*(double *)(arg4 + 0x20) - *(double *)(arg4 + 8)) * *(double *)(arg4 + 0x38) +
                         *(double *)(arg4 + 8);
            }
            goto code_r0x0001800a9e57;
        }
        break;
    case 0x5b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = NAN(*(double *)(arg4 + 8));
code_r0x0001800aa05d:
            *(undefined8 *)arg1 = 2;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(bool *)(arg1 + 8) = bVar12;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x5c:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = INFINITY <= (double)(*(uint64_t *)(arg4 + 8) & 0x7fffffffffffffff);
            goto code_r0x0001800aa05d;
        }
        break;
    case 0x5d:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = ((uint32_t)((uint64_t)*(undefined8 *)(arg4 + 8) >> 0x34) & 0x7ff) != 0x7ff;
            goto code_r0x0001800aa05d;
        }
    }
code_r0x0001800a9448:
    var_d8h = 0;
    var_d0h = 0;
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 0;
    *(undefined4 *)(arg1 + 8) = 0;
    *(undefined4 *)(arg1 + 0xc) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
code_r0x0001800a937e:
    fcn.180459870(var_38h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_1800a93c2
// Address: 0x1800a93c2
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800a9050(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    double dVar1;
    double dVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int32_t iVar11;
    bool bVar12;
    undefined8 uVar13;
    double dVar14;
    double dVar15;
    undefined auVar16 [16];
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar11 = (int32_t)arg_28h;
    // switch table (92 cases) at 0x1800aa0d0
    switch((int32_t)arg3) {
    case 2:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            uVar5 = *(uint64_t *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(uint64_t *)(arg1 + 8) = uVar5 & 0x7fffffffffffffff;
            goto code_r0x0001800a937e;
        }
        break;
    case 3:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048e730(*(undefined8 *)(arg4 + 8));
code_r0x0001800a9105:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = dVar15;
            goto code_r0x0001800a937e;
        }
        break;
    case 4:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048ec30(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 5:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x00018048f110(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 6:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048eec0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 7:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048d6f0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 8:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804901d0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 9:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048f790(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 10:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8) / 0.0174532925199433;
            goto code_r0x0001800a9105;
        }
        break;
    case 0xb:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804905c0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xc:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x0001804909e0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xd:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x000180490b30(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 0xf:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x00018046d9a0(*(undefined8 *)(arg4 + 8), 
                                                 CONCAT44(1, (int32_t)*(double *)(arg4 + 0x20)));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x10:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018048d7c0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x11:
        if (arg_28h == 1) {
            if (*(int32_t *)arg4 == 3) {
                dVar15 = (double)func_0x000180491150(*(undefined8 *)(arg4 + 8));
                goto code_r0x0001800a9105;
            }
        } else if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            uVar13 = *(undefined8 *)(arg4 + 8);
            dVar15 = *(double *)(arg4 + 0x20);
            *(undefined4 *)arg1 = 3;
            if (dVar15 == 2.0) {
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                uVar13 = func_0x000180491680(uVar13);
            } else {
                if (dVar15 != 10.0) {
                    *(undefined4 *)(arg1 + 4) = 0;
                    *(undefined8 *)(arg1 + 0x10) = 0;
                    dVar15 = (double)func_0x000180491150();
                    dVar14 = (double)func_0x000180491150();
                    *(double *)(arg1 + 8) = dVar15 / dVar14;
                    goto code_r0x0001800a937e;
                }
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                uVar13 = func_0x00018048d7c0();
            }
            *(undefined8 *)(arg1 + 8) = uVar13;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x12:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8);
            uVar5 = 1;
            dVar14 = dVar15;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar5 * 0x18) != 3) goto code_r0x0001800a9448;
                    dVar15 = *(double *)(arg4 + 8 + uVar5 * 0x18);
                    uVar5 = uVar5 + 1;
                    if (dVar15 <= dVar14) {
                        dVar15 = dVar14;
                    }
                    dVar14 = dVar15;
                } while (uVar5 < (uint64_t)arg_28h);
            }
code_r0x0001800a9e57:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = dVar15;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x13:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8);
            uVar5 = 1;
            dVar14 = dVar15;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar5 * 0x18) != 3) goto code_r0x0001800a9448;
                    dVar15 = *(double *)(arg4 + 8 + uVar5 * 0x18);
                    uVar5 = uVar5 + 1;
                    if (dVar14 <= dVar15) {
                        dVar15 = dVar14;
                    }
                    dVar14 = dVar15;
                } while (uVar5 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9e57;
        }
        break;
    case 0x15:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = (double)func_0x000180491d70(*(undefined8 *)(arg4 + 8), (int32_t)*(undefined8 *)(arg4 + 0x20));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x16:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = *(double *)(arg4 + 8) * 0.0174532925199433;
            goto code_r0x0001800a9105;
        }
        break;
    case 0x17:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494070(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x18:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180493440(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x19:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            if (*(double *)(arg4 + 8) < 0.0) {
                dVar15 = (double)func_0x0001804944a0(*(undefined8 *)(arg4 + 8));
            } else {
                auVar16._8_8_ = 0;
                auVar16._0_8_ = *(double *)(arg4 + 8);
                auVar16 = sqrtpd(ZEXT816(0), auVar16);
                dVar15 = auVar16._0_8_;
            }
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1a:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494da0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x000180494600(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1c:
        if ((((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20)) {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) =
                 (double)(uint64_t)(uint32_t)((int32_t)(int64_t)dVar14 >> ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x1d:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 & (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
code_r0x0001800a9661:
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = (double)(uVar5 & 0xffffffff);
            goto code_r0x0001800a937e;
        }
        break;
    case 0x1e:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)(uint64_t)~(uint32_t)(int64_t)*(double *)(arg4 + 8);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x1f:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 | (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9661;
        }
        break;
    case 0x20:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar5 = (uint64_t)((uint32_t)uVar5 ^ (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10));
                } while (uVar9 < (uint64_t)arg_28h);
            }
            goto code_r0x0001800a9661;
        }
        break;
    case 0x21:
        if ((arg_28h != 0) && (*(int32_t *)arg4 == 3)) {
            uVar5 = (uint64_t)*(double *)(arg4 + 8);
            uVar7 = (uint32_t)uVar5;
            uVar9 = 1;
            if (1 < (uint64_t)arg_28h) {
                do {
                    if (*(int32_t *)(arg4 + uVar9 * 0x18) != 3) goto code_r0x0001800a9448;
                    iVar10 = uVar9 * 0x18;
                    uVar9 = uVar9 + 1;
                    uVar7 = (uint32_t)uVar5 & (uint32_t)(int64_t)*(double *)(arg4 + 8 + iVar10);
                    uVar5 = (uint64_t)uVar7;
                } while (uVar9 < (uint64_t)arg_28h);
            }
            *(undefined8 *)arg1 = 2;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(bool *)(arg1 + 8) = uVar7 != 0;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x22:
        if ((((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           ((arg_28h == 2 || (*(int32_t *)(arg4 + 0x30) == 3)))) {
            iVar11 = (int32_t)*(double *)(arg4 + 0x20);
            if (arg_28h == 2) {
                iVar4 = 1;
            } else {
                iVar4 = (int32_t)*(double *)(arg4 + 0x38);
            }
            if (((-1 < iVar11) && (0 < iVar4)) && (iVar4 + iVar11 < 0x21)) {
                dVar15 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 3;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(double *)(arg1 + 8) =
                     (double)(uint64_t)
                             ((uint32_t)(int64_t)dVar15 >> ((uint8_t)iVar11 & 0x1f) & ~(-2 << ((char)iVar4 - 1U & 0x1f))
                             );
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x23:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = *(double *)(arg4 + 0x20);
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            uVar3 = (uint8_t)(int32_t)dVar15;
            uVar7 = (uint32_t)(int64_t)dVar14;
            *(double *)(arg1 + 8) = (double)(uint64_t)(uVar7 >> (-uVar3 & 0x1f) | uVar7 << (uVar3 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x24:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) &&
           ((*(int32_t *)(arg4 + 0x18) == 3 && (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20))))
        {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) =
                 (double)(uint64_t)(uint32_t)((int32_t)(int64_t)dVar14 << ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x25:
        if (((2 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) &&
           (((*(int32_t *)(arg4 + 0x18) == 3 && (*(int32_t *)(arg4 + 0x30) == 3)) &&
            ((arg_28h == 3 || (*(int32_t *)(arg4 + 0x48) == 3)))))) {
            iVar11 = (int32_t)*(double *)(arg4 + 0x38);
            if (arg_28h == 3) {
                iVar4 = 1;
            } else {
                iVar4 = (int32_t)*(double *)(arg4 + 0x50);
            }
            if (((-1 < iVar11) && (0 < iVar4)) && (iVar4 + iVar11 < 0x21)) {
                dVar15 = *(double *)(arg4 + 0x20);
                uVar7 = ~(-2 << ((char)iVar4 - 1U & 0x1f));
                dVar14 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 3;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(double *)(arg1 + 8) =
                     (double)(uint64_t)
                             (~(uVar7 << ((uint8_t)iVar11 & 0x1f)) & (uint32_t)(int64_t)dVar14 |
                             ((uint32_t)(int64_t)dVar15 & uVar7) << ((uint8_t)iVar11 & 0x1f));
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x26:
        if (((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            dVar15 = *(double *)(arg4 + 0x20);
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            uVar3 = (uint8_t)(int32_t)dVar15;
            uVar7 = (uint32_t)(int64_t)dVar14;
            *(double *)(arg1 + 8) = (double)(uint64_t)(uVar7 << (-uVar3 & 0x1f) | uVar7 >> (uVar3 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x27:
        if ((((arg_28h == 2) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
           (dVar15 = *(double *)(arg4 + 0x20), (uint32_t)(int32_t)dVar15 < 0x20)) {
            dVar14 = *(double *)(arg4 + 8);
            *(undefined8 *)arg1 = 3;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(double *)(arg1 + 8) = (double)(uint64_t)((uint32_t)(int64_t)dVar14 >> ((uint8_t)(int32_t)dVar15 & 0x1f));
            goto code_r0x0001800a937e;
        }
        break;
    case 0x28:
        if ((arg_28h == 1) && (*(int32_t *)arg4 != 0)) {
    // switch table (6 cases) at 0x1800aa1f8
            switch(*(int32_t *)arg4) {
            case 1:
code_r0x0001800a9ccf:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063da4c;
                *(undefined4 *)(arg1 + 4) = 3;
                break;
            case 2:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063ec88;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 3:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e2d0;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 4:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a0;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 5:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a8;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 6:
code_r0x0001800a9d5b:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x180625fe4;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            default:
                goto code_r0x0001800a9448;
            }
            goto code_r0x0001800a937e;
        }
        break;
    case 0x29:
        if (arg_28h == 1) {
            if ((*(int32_t *)arg4 == 6) && (*(int32_t *)(arg4 + 4) != 0)) {
                dVar15 = (double)(uint32_t)**(uint8_t **)(arg4 + 8);
                goto code_r0x0001800a9105;
            }
        } else if ((((arg_28h == 2) && (*(int32_t *)arg4 == 6)) && (*(int32_t *)(arg4 + 0x18) == 3)) &&
                  ((uVar7 = (uint32_t)*(double *)(arg4 + 0x20), 0 < (int32_t)uVar7 && (uVar7 <= *(uint32_t *)(arg4 + 4))
                   ))) {
            dVar15 = (double)(uint32_t)*(uint8_t *)(*(int64_t *)(arg4 + 8) + -1 + (int64_t)(int32_t)uVar7);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x2a:
        if ((uint64_t)arg_28h < 0x80) {
            _var_b8h = ZEXT816(0);
            uVar5 = 0;
            _var_a8h = _var_b8h;
            _var_98h = _var_b8h;
            _var_88h = _var_b8h;
            _var_78h = _var_b8h;
            _var_68h = _var_b8h;
            _var_58h = _var_b8h;
            _var_48h = _var_b8h;
            if (arg_28h != 0) {
                do {
                    if ((*(int32_t *)(arg4 + uVar5 * 0x18) != 3) ||
                       (uVar7 = (uint32_t)*(double *)(arg4 + 8 + uVar5 * 0x18), (uVar7 & 0xff) != uVar7))
                    goto code_r0x0001800a9448;
                    *(char *)((int64_t)&var_b8h + uVar5) = (char)uVar7;
                    uVar5 = uVar5 + 1;
                } while (uVar5 < (uint64_t)arg_28h);
                piVar8 = &var_b8h;
                iVar10 = arg_28h;
code_r0x0001800a9c37:
                func_0x0001800d6f20(arg2, &var_c0h, piVar8, iVar10);
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(int64_t *)(arg1 + 8) = var_c0h;
                *(int32_t *)(arg1 + 4) = (int32_t)arg_28h;
                goto code_r0x0001800a937e;
            }
code_r0x0001800a9c5f:
            *(undefined8 *)arg1 = 6;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(undefined8 *)(arg1 + 8) = 0x1805aadb1;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x2b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 6)) {
            dVar15 = (double)(uint64_t)*(uint32_t *)(arg4 + 4);
            goto code_r0x0001800a9105;
        }
        break;
    case 0x2c:
        if ((arg_28h == 1) && (*(int32_t *)arg4 != 0)) {
    // switch table (6 cases) at 0x1800aa210
            switch(*(int32_t *)arg4) {
            case 1:
                goto code_r0x0001800a9ccf;
            case 2:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063ec88;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            case 3:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e2d0;
                *(undefined4 *)(arg1 + 4) = 6;
                break;
            case 4:
                *(undefined4 *)arg1 = 6;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 8) = 0x18063e1a0;
                *(undefined4 *)(arg1 + 4) = 7;
                break;
            default:
                goto code_r0x0001800a9448;
            case 6:
                goto code_r0x0001800a9d5b;
            }
            goto code_r0x0001800a937e;
        }
        break;
    case 0x2d:
        if (((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 6)) &&
           ((*(int32_t *)(arg4 + 0x18) == 3 && (((uint64_t)arg_28h < 3 || (*(int32_t *)(arg4 + 0x30) == 3)))))) {
            iVar11 = *(int32_t *)(arg4 + 4);
            iVar4 = (int32_t)*(double *)(arg4 + 0x20);
            iVar6 = iVar11;
            if (2 < (uint64_t)arg_28h) {
                iVar6 = (int32_t)*(double *)(arg4 + 0x38);
            }
            if (iVar4 < 0) {
                iVar4 = iVar4 + 1 + iVar11;
            }
            if (iVar6 < 0) {
                iVar6 = iVar6 + 1 + iVar11;
            }
            if (0 < iVar6) {
                if (iVar4 < 1) {
                    iVar4 = 1;
                }
                if (iVar11 < iVar6) {
                    iVar6 = iVar11;
                }
                if (iVar4 <= iVar6) {
                    uVar7 = (iVar6 - iVar4) + 1;
                    arg_28h = (int64_t)uVar7;
                    piVar8 = (int64_t *)((int64_t)(iVar4 + -1) + *(int64_t *)(arg4 + 8));
                    iVar10 = (int64_t)(int32_t)uVar7;
                    goto code_r0x0001800a9c37;
                }
            }
            goto code_r0x0001800a9c5f;
        }
        break;
    case 0x2e:
        if ((((arg_28h == 3) && (*(int32_t *)arg4 == iVar11)) && (*(int32_t *)(arg4 + 0x18) == iVar11)) &&
           (*(int32_t *)(arg4 + 0x30) == iVar11)) {
            dVar14 = *(double *)(arg4 + 0x20);
            dVar15 = *(double *)(arg4 + 0x38);
            if (dVar14 <= dVar15) {
                if (dVar14 <= *(double *)(arg4 + 8)) {
                    dVar14 = *(double *)(arg4 + 8);
                }
                if (dVar14 <= dVar15) {
                    dVar15 = dVar14;
                }
                goto code_r0x0001800a9e57;
            }
        }
        break;
    case 0x2f:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = 0.0;
            if (*(double *)(arg4 + 8) <= 0.0) {
                if (*(double *)(arg4 + 8) < 0.0) {
                    dVar15 = -1.0;
                }
            } else {
                dVar15 = 1.0;
            }
            goto code_r0x0001800a9105;
        }
        break;
    case 0x30:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            dVar15 = (double)func_0x00018046e0b0(*(undefined8 *)(arg4 + 8));
            goto code_r0x0001800a9105;
        }
        break;
    case 0x36:
        if (((1 < (uint64_t)arg_28h) && (*(int32_t *)arg4 == 3)) && (*(int32_t *)(arg4 + 0x18) == 3)) {
            if (arg_28h == 2) {
                dVar15 = *(double *)(arg4 + 0x20);
                dVar14 = *(double *)(arg4 + 8);
                *(undefined8 *)arg1 = 5;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(float *)(arg1 + 8) = (float)dVar14;
                *(float *)(arg1 + 0xc) = (float)dVar15;
                goto code_r0x0001800a937e;
            }
            if (arg_28h == 3) {
                if (*(int32_t *)(arg4 + 0x30) == iVar11) {
                    dVar15 = *(double *)(arg4 + 8);
                    dVar14 = *(double *)(arg4 + 0x38);
                    dVar1 = *(double *)(arg4 + 0x20);
                    *(undefined8 *)arg1 = 5;
                    *(undefined4 *)(arg1 + 0x14) = 0;
                    *(float *)(arg1 + 8) = (float)dVar15;
                    *(float *)(arg1 + 0xc) = (float)dVar1;
                    *(float *)(arg1 + 0x10) = (float)dVar14;
                    goto code_r0x0001800a937e;
                }
            } else if (((arg_28h == 4) && (*(int32_t *)(arg4 + 0x30) == 3)) && (*(int32_t *)(arg4 + 0x48) == 3)) {
                dVar15 = *(double *)(arg4 + 0x20);
                dVar14 = *(double *)(arg4 + 8);
                dVar1 = *(double *)(arg4 + 0x50);
                dVar2 = *(double *)(arg4 + 0x38);
                *(undefined8 *)arg1 = 5;
                *(float *)(arg1 + 8) = (float)dVar14;
                *(float *)(arg1 + 0xc) = (float)dVar15;
                *(float *)(arg1 + 0x10) = (float)dVar2;
                *(float *)(arg1 + 0x14) = (float)dVar1;
                goto code_r0x0001800a937e;
            }
        }
        break;
    case 0x59:
        if ((((arg_28h == 3) && (*(int32_t *)arg4 == iVar11)) && (*(int32_t *)(arg4 + 0x18) == iVar11)) &&
           (*(int32_t *)(arg4 + 0x30) == iVar11)) {
            dVar15 = *(double *)(arg4 + 0x20);
            if (*(double *)(arg4 + 0x38) != 1.0) {
                dVar15 = (*(double *)(arg4 + 0x20) - *(double *)(arg4 + 8)) * *(double *)(arg4 + 0x38) +
                         *(double *)(arg4 + 8);
            }
            goto code_r0x0001800a9e57;
        }
        break;
    case 0x5b:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = NAN(*(double *)(arg4 + 8));
code_r0x0001800aa05d:
            *(undefined8 *)arg1 = 2;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            *(bool *)(arg1 + 8) = bVar12;
            goto code_r0x0001800a937e;
        }
        break;
    case 0x5c:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = INFINITY <= (double)(*(uint64_t *)(arg4 + 8) & 0x7fffffffffffffff);
            goto code_r0x0001800aa05d;
        }
        break;
    case 0x5d:
        if ((arg_28h == 1) && (*(int32_t *)arg4 == 3)) {
            bVar12 = ((uint32_t)((uint64_t)*(undefined8 *)(arg4 + 8) >> 0x34) & 0x7ff) != 0x7ff;
            goto code_r0x0001800aa05d;
        }
    }
code_r0x0001800a9448:
    var_d8h = 0;
    var_d0h = 0;
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 0;
    *(undefined4 *)(arg1 + 8) = 0;
    *(undefined4 *)(arg1 + 0xc) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
code_r0x0001800a937e:
    fcn.180459870(var_38h ^ (uint64_t)auStack_f8);
    return;
}

