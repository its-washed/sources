// Chunk 82 - 50 functions

// ============================================================
// Function: FUN_180113160
// Address: 0x180113160
// Size: 403 bytes
// ============================================================
void fcn.180113160(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t *piVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t *piVar11;
    int32_t iVar12;
    undefined4 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar11 = *(int64_t **)(arg1 + 0x1588);
    piVar1 = piVar11 + *(int32_t *)(arg1 + 0x1580);
    for (; piVar11 != piVar1; piVar11 = piVar11 + 1) {
        iVar5 = *piVar11;
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x100) == 0) {
            if (*(int32_t *)(iVar5 + 0x31c) == -1) {
                iVar8 = func_0x000180112cf0(*(undefined4 *)(iVar5 + 0x10));
            } else {
                iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x31c) + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2958);
            }
            if (iVar8 == 0) {
                iVar8 = func_0x000180112c00(*(undefined8 *)(iVar5 + 8));
                *(int32_t *)(iVar5 + 0x31c) = (int32_t)iVar8 - *(int32_t *)(arg1 + 0x2958);
            }
            fVar2 = *(float *)(iVar5 + 0x60);
            fVar3 = *(float *)(iVar5 + 0x54);
            *(int16_t *)(iVar8 + 6) = (int16_t)(int32_t)(*(float *)(iVar5 + 100) - *(float *)(iVar5 + 0x58));
            *(int16_t *)(iVar8 + 4) = (int16_t)(int32_t)(fVar2 - fVar3);
            fVar2 = *(float *)(iVar5 + 0x70);
            *(int16_t *)(iVar8 + 10) = (int16_t)(int32_t)*(float *)(iVar5 + 0x74);
            *(int16_t *)(iVar8 + 8) = (int16_t)(int32_t)fVar2;
            *(undefined4 *)(iVar8 + 0x10) = *(undefined4 *)(iVar5 + 0x50);
            fVar2 = *(float *)(iVar5 + 0x58);
            *(int16_t *)(iVar8 + 0xc) = (int16_t)(int32_t)*(float *)(iVar5 + 0x54);
            *(int16_t *)(iVar8 + 0xe) = (int16_t)(int32_t)fVar2;
            *(undefined4 *)(iVar8 + 0x14) = *(undefined4 *)(iVar5 + 0x4d0);
            *(undefined4 *)(iVar8 + 0x18) = *(undefined4 *)(iVar5 + 0x20);
            *(undefined2 *)(iVar8 + 0x1c) = *(undefined2 *)(iVar5 + 0x496);
            *(undefined *)(iVar8 + 0x1e) = *(undefined *)(iVar5 + 0x10c);
            iVar6 = *(int64_t *)(iVar5 + 0x418);
            *(undefined *)(iVar8 + 0x21) = 0;
            *(bool *)(iVar8 + 0x1f) = iVar6 != iVar5;
        }
    }
    iVar12 = *(int32_t *)(arg1 + 0x2950) * 6;
    iVar9 = *(int32_t *)arg3 + -1 + iVar12;
    if (*(int32_t *)arg3 == 0) {
        iVar9 = iVar12;
    }
    if (*(int32_t *)(arg3 + 4) < iVar9) {
        uVar7 = func_0x00018046d050((int64_t)iVar9);
        if (*(int64_t *)(arg3 + 8) != 0) {
            func_0x000180498030(uVar7, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
            func_0x000180460d90(*(undefined8 *)(arg3 + 8));
        }
        *(undefined8 *)(arg3 + 8) = uVar7;
        *(int32_t *)(arg3 + 4) = iVar9;
    }
    iVar5 = 0;
    if (*(int64_t *)(arg1 + 0x2958) != 0) {
        iVar5 = *(int64_t *)(arg1 + 0x2958) + 4;
    }
    while (iVar5 != 0) {
        if (*(char *)(iVar5 + 0x21) == '\0') {
            uVar13 = func_0x0001800f65a0(arg3, 0x180644fe0, *(undefined8 *)arg2, iVar5 + 0x24);
            if (*(char *)(iVar5 + 0x1f) == '\0') {
                if ((*(int32_t *)(iVar5 + 0x10) != 0) && (*(int32_t *)(iVar5 + 0x10) != 0x11111111)) {
                    uVar13 = func_0x0001800f65a0(uVar13, 0x180645010, (int32_t)*(int16_t *)(iVar5 + 0xc), 
                                                 (int32_t)*(int16_t *)(iVar5 + 0xe));
                    func_0x0001800f65a0(uVar13, 0x180645090, *(undefined4 *)(iVar5 + 0x10));
                }
                if (((*(int16_t *)(iVar5 + 4) != 0) || (*(int16_t *)(iVar5 + 6) != 0)) ||
                   (*(int32_t *)(iVar5 + 0x10) == 0x11111111)) {
                    func_0x0001800f65a0(arg3, 0x1806450a8, (int32_t)*(int16_t *)(iVar5 + 4), 
                                        (int32_t)*(int16_t *)(iVar5 + 6));
                }
                if ((*(int16_t *)(iVar5 + 8) != 0) || (*(int16_t *)(iVar5 + 10) != 0)) {
                    func_0x0001800f65a0(arg3, 0x180645000, (int32_t)*(int16_t *)(iVar5 + 8), 
                                        (int32_t)*(int16_t *)(iVar5 + 10));
                }
                uVar13 = func_0x0001800f65a0(arg3, 0x1806450b8, *(undefined *)(iVar5 + 0x1e));
                if (*(int32_t *)(iVar5 + 0x14) != 0) {
                    if (*(int16_t *)(iVar5 + 0x1c) == -1) {
                        func_0x0001800f65a0(uVar13, 0x1806450c8);
                    } else {
                        func_0x0001800f65a0(uVar13, 0x180645068, *(int32_t *)(iVar5 + 0x14), 
                                            (int32_t)*(int16_t *)(iVar5 + 0x1c));
                    }
                    if (*(int32_t *)(iVar5 + 0x18) != 0) {
                        func_0x0001800f65a0(arg3, 0x180645080);
                    }
                }
            } else {
                uVar13 = func_0x0001800f65a0(uVar13, 0x180644ff0);
                func_0x0001800f65a0(uVar13, 0x180645000, (int32_t)*(int16_t *)(iVar5 + 8), 
                                    (int32_t)*(int16_t *)(iVar5 + 10));
            }
            iVar12 = 1;
            if (*(int32_t *)arg3 != 0) {
                iVar12 = *(int32_t *)arg3;
            }
            iVar4 = *(int32_t *)(arg3 + 4);
            iVar9 = iVar12 + 1;
            if (iVar4 <= iVar9) {
                iVar10 = iVar4 * 2;
                if (iVar4 * 2 < iVar9) {
                    iVar10 = iVar9;
                }
                if (iVar4 < iVar10) {
                    uVar7 = func_0x00018046d050((int64_t)iVar10);
                    if (*(int64_t *)(arg3 + 8) != 0) {
                        func_0x000180498030(uVar7, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
                        func_0x000180460d90(*(undefined8 *)(arg3 + 8));
                    }
                    *(undefined8 *)(arg3 + 8) = uVar7;
                    *(int32_t *)(arg3 + 4) = iVar10;
                }
            }
            func_0x00018011f640(arg3, iVar9);
            *(undefined *)((int64_t)iVar12 + -1 + *(int64_t *)(arg3 + 8)) = 10;
            *(undefined *)((int64_t)iVar12 + *(int64_t *)(arg3 + 8)) = 0;
        }
        iVar8 = *(int32_t *)(iVar5 + -4) + iVar5;
        iVar5 = 0;
        if (iVar8 != *(int64_t *)(arg1 + 0x2958) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2950)) {
            iVar5 = iVar8;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801132f3
// Address: 0x1801132f3
// Size: 490 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180113160(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t *piVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t *piVar11;
    int32_t iVar12;
    undefined4 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar11 = *(int64_t **)(arg1 + 0x1588);
    piVar1 = piVar11 + *(int32_t *)(arg1 + 0x1580);
    for (; piVar11 != piVar1; piVar11 = piVar11 + 1) {
        iVar5 = *piVar11;
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x100) == 0) {
            if (*(int32_t *)(iVar5 + 0x31c) == -1) {
                iVar8 = func_0x000180112cf0(*(undefined4 *)(iVar5 + 0x10));
            } else {
                iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x31c) + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2958);
            }
            if (iVar8 == 0) {
                iVar8 = func_0x000180112c00(*(undefined8 *)(iVar5 + 8));
                *(int32_t *)(iVar5 + 0x31c) = (int32_t)iVar8 - *(int32_t *)(arg1 + 0x2958);
            }
            fVar2 = *(float *)(iVar5 + 0x60);
            fVar3 = *(float *)(iVar5 + 0x54);
            *(int16_t *)(iVar8 + 6) = (int16_t)(int32_t)(*(float *)(iVar5 + 100) - *(float *)(iVar5 + 0x58));
            *(int16_t *)(iVar8 + 4) = (int16_t)(int32_t)(fVar2 - fVar3);
            fVar2 = *(float *)(iVar5 + 0x70);
            *(int16_t *)(iVar8 + 10) = (int16_t)(int32_t)*(float *)(iVar5 + 0x74);
            *(int16_t *)(iVar8 + 8) = (int16_t)(int32_t)fVar2;
            *(undefined4 *)(iVar8 + 0x10) = *(undefined4 *)(iVar5 + 0x50);
            fVar2 = *(float *)(iVar5 + 0x58);
            *(int16_t *)(iVar8 + 0xc) = (int16_t)(int32_t)*(float *)(iVar5 + 0x54);
            *(int16_t *)(iVar8 + 0xe) = (int16_t)(int32_t)fVar2;
            *(undefined4 *)(iVar8 + 0x14) = *(undefined4 *)(iVar5 + 0x4d0);
            *(undefined4 *)(iVar8 + 0x18) = *(undefined4 *)(iVar5 + 0x20);
            *(undefined2 *)(iVar8 + 0x1c) = *(undefined2 *)(iVar5 + 0x496);
            *(undefined *)(iVar8 + 0x1e) = *(undefined *)(iVar5 + 0x10c);
            iVar6 = *(int64_t *)(iVar5 + 0x418);
            *(undefined *)(iVar8 + 0x21) = 0;
            *(bool *)(iVar8 + 0x1f) = iVar6 != iVar5;
        }
    }
    iVar12 = *(int32_t *)(arg1 + 0x2950) * 6;
    iVar9 = *(int32_t *)arg3 + -1 + iVar12;
    if (*(int32_t *)arg3 == 0) {
        iVar9 = iVar12;
    }
    if (*(int32_t *)(arg3 + 4) < iVar9) {
        uVar7 = func_0x00018046d050((int64_t)iVar9);
        if (*(int64_t *)(arg3 + 8) != 0) {
            func_0x000180498030(uVar7, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
            func_0x000180460d90(*(undefined8 *)(arg3 + 8));
        }
        *(undefined8 *)(arg3 + 8) = uVar7;
        *(int32_t *)(arg3 + 4) = iVar9;
    }
    iVar5 = 0;
    if (*(int64_t *)(arg1 + 0x2958) != 0) {
        iVar5 = *(int64_t *)(arg1 + 0x2958) + 4;
    }
    while (iVar5 != 0) {
        if (*(char *)(iVar5 + 0x21) == '\0') {
            uVar13 = func_0x0001800f65a0(arg3, 0x180644fe0, *(undefined8 *)arg2, iVar5 + 0x24);
            if (*(char *)(iVar5 + 0x1f) == '\0') {
                if ((*(int32_t *)(iVar5 + 0x10) != 0) && (*(int32_t *)(iVar5 + 0x10) != 0x11111111)) {
                    uVar13 = func_0x0001800f65a0(uVar13, 0x180645010, (int32_t)*(int16_t *)(iVar5 + 0xc), 
                                                 (int32_t)*(int16_t *)(iVar5 + 0xe));
                    func_0x0001800f65a0(uVar13, 0x180645090, *(undefined4 *)(iVar5 + 0x10));
                }
                if (((*(int16_t *)(iVar5 + 4) != 0) || (*(int16_t *)(iVar5 + 6) != 0)) ||
                   (*(int32_t *)(iVar5 + 0x10) == 0x11111111)) {
                    func_0x0001800f65a0(arg3, 0x1806450a8, (int32_t)*(int16_t *)(iVar5 + 4), 
                                        (int32_t)*(int16_t *)(iVar5 + 6));
                }
                if ((*(int16_t *)(iVar5 + 8) != 0) || (*(int16_t *)(iVar5 + 10) != 0)) {
                    func_0x0001800f65a0(arg3, 0x180645000, (int32_t)*(int16_t *)(iVar5 + 8), 
                                        (int32_t)*(int16_t *)(iVar5 + 10));
                }
                uVar13 = func_0x0001800f65a0(arg3, 0x1806450b8, *(undefined *)(iVar5 + 0x1e));
                if (*(int32_t *)(iVar5 + 0x14) != 0) {
                    if (*(int16_t *)(iVar5 + 0x1c) == -1) {
                        func_0x0001800f65a0(uVar13, 0x1806450c8);
                    } else {
                        func_0x0001800f65a0(uVar13, 0x180645068, *(int32_t *)(iVar5 + 0x14), 
                                            (int32_t)*(int16_t *)(iVar5 + 0x1c));
                    }
                    if (*(int32_t *)(iVar5 + 0x18) != 0) {
                        func_0x0001800f65a0(arg3, 0x180645080);
                    }
                }
            } else {
                uVar13 = func_0x0001800f65a0(uVar13, 0x180644ff0);
                func_0x0001800f65a0(uVar13, 0x180645000, (int32_t)*(int16_t *)(iVar5 + 8), 
                                    (int32_t)*(int16_t *)(iVar5 + 10));
            }
            iVar12 = 1;
            if (*(int32_t *)arg3 != 0) {
                iVar12 = *(int32_t *)arg3;
            }
            iVar4 = *(int32_t *)(arg3 + 4);
            iVar9 = iVar12 + 1;
            if (iVar4 <= iVar9) {
                iVar10 = iVar4 * 2;
                if (iVar4 * 2 < iVar9) {
                    iVar10 = iVar9;
                }
                if (iVar4 < iVar10) {
                    uVar7 = func_0x00018046d050((int64_t)iVar10);
                    if (*(int64_t *)(arg3 + 8) != 0) {
                        func_0x000180498030(uVar7, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
                        func_0x000180460d90(*(undefined8 *)(arg3 + 8));
                    }
                    *(undefined8 *)(arg3 + 8) = uVar7;
                    *(int32_t *)(arg3 + 4) = iVar10;
                }
            }
            func_0x00018011f640(arg3, iVar9);
            *(undefined *)((int64_t)iVar12 + -1 + *(int64_t *)(arg3 + 8)) = 10;
            *(undefined *)((int64_t)iVar12 + *(int64_t *)(arg3 + 8)) = 0;
        }
        iVar8 = *(int32_t *)(iVar5 + -4) + iVar5;
        iVar5 = 0;
        if (iVar8 != *(int64_t *)(arg1 + 0x2958) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2950)) {
            iVar5 = iVar8;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801134dd
// Address: 0x1801134dd
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180113160(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t *piVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t *piVar11;
    int32_t iVar12;
    undefined4 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar11 = *(int64_t **)(arg1 + 0x1588);
    piVar1 = piVar11 + *(int32_t *)(arg1 + 0x1580);
    for (; piVar11 != piVar1; piVar11 = piVar11 + 1) {
        iVar5 = *piVar11;
        if ((*(uint32_t *)(iVar5 + 0x14) & 0x100) == 0) {
            if (*(int32_t *)(iVar5 + 0x31c) == -1) {
                iVar8 = func_0x000180112cf0(*(undefined4 *)(iVar5 + 0x10));
            } else {
                iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x31c) + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2958);
            }
            if (iVar8 == 0) {
                iVar8 = func_0x000180112c00(*(undefined8 *)(iVar5 + 8));
                *(int32_t *)(iVar5 + 0x31c) = (int32_t)iVar8 - *(int32_t *)(arg1 + 0x2958);
            }
            fVar2 = *(float *)(iVar5 + 0x60);
            fVar3 = *(float *)(iVar5 + 0x54);
            *(int16_t *)(iVar8 + 6) = (int16_t)(int32_t)(*(float *)(iVar5 + 100) - *(float *)(iVar5 + 0x58));
            *(int16_t *)(iVar8 + 4) = (int16_t)(int32_t)(fVar2 - fVar3);
            fVar2 = *(float *)(iVar5 + 0x70);
            *(int16_t *)(iVar8 + 10) = (int16_t)(int32_t)*(float *)(iVar5 + 0x74);
            *(int16_t *)(iVar8 + 8) = (int16_t)(int32_t)fVar2;
            *(undefined4 *)(iVar8 + 0x10) = *(undefined4 *)(iVar5 + 0x50);
            fVar2 = *(float *)(iVar5 + 0x58);
            *(int16_t *)(iVar8 + 0xc) = (int16_t)(int32_t)*(float *)(iVar5 + 0x54);
            *(int16_t *)(iVar8 + 0xe) = (int16_t)(int32_t)fVar2;
            *(undefined4 *)(iVar8 + 0x14) = *(undefined4 *)(iVar5 + 0x4d0);
            *(undefined4 *)(iVar8 + 0x18) = *(undefined4 *)(iVar5 + 0x20);
            *(undefined2 *)(iVar8 + 0x1c) = *(undefined2 *)(iVar5 + 0x496);
            *(undefined *)(iVar8 + 0x1e) = *(undefined *)(iVar5 + 0x10c);
            iVar6 = *(int64_t *)(iVar5 + 0x418);
            *(undefined *)(iVar8 + 0x21) = 0;
            *(bool *)(iVar8 + 0x1f) = iVar6 != iVar5;
        }
    }
    iVar12 = *(int32_t *)(arg1 + 0x2950) * 6;
    iVar9 = *(int32_t *)arg3 + -1 + iVar12;
    if (*(int32_t *)arg3 == 0) {
        iVar9 = iVar12;
    }
    if (*(int32_t *)(arg3 + 4) < iVar9) {
        uVar7 = func_0x00018046d050((int64_t)iVar9);
        if (*(int64_t *)(arg3 + 8) != 0) {
            func_0x000180498030(uVar7, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
            func_0x000180460d90(*(undefined8 *)(arg3 + 8));
        }
        *(undefined8 *)(arg3 + 8) = uVar7;
        *(int32_t *)(arg3 + 4) = iVar9;
    }
    iVar5 = 0;
    if (*(int64_t *)(arg1 + 0x2958) != 0) {
        iVar5 = *(int64_t *)(arg1 + 0x2958) + 4;
    }
    while (iVar5 != 0) {
        if (*(char *)(iVar5 + 0x21) == '\0') {
            uVar13 = func_0x0001800f65a0(arg3, 0x180644fe0, *(undefined8 *)arg2, iVar5 + 0x24);
            if (*(char *)(iVar5 + 0x1f) == '\0') {
                if ((*(int32_t *)(iVar5 + 0x10) != 0) && (*(int32_t *)(iVar5 + 0x10) != 0x11111111)) {
                    uVar13 = func_0x0001800f65a0(uVar13, 0x180645010, (int32_t)*(int16_t *)(iVar5 + 0xc), 
                                                 (int32_t)*(int16_t *)(iVar5 + 0xe));
                    func_0x0001800f65a0(uVar13, 0x180645090, *(undefined4 *)(iVar5 + 0x10));
                }
                if (((*(int16_t *)(iVar5 + 4) != 0) || (*(int16_t *)(iVar5 + 6) != 0)) ||
                   (*(int32_t *)(iVar5 + 0x10) == 0x11111111)) {
                    func_0x0001800f65a0(arg3, 0x1806450a8, (int32_t)*(int16_t *)(iVar5 + 4), 
                                        (int32_t)*(int16_t *)(iVar5 + 6));
                }
                if ((*(int16_t *)(iVar5 + 8) != 0) || (*(int16_t *)(iVar5 + 10) != 0)) {
                    func_0x0001800f65a0(arg3, 0x180645000, (int32_t)*(int16_t *)(iVar5 + 8), 
                                        (int32_t)*(int16_t *)(iVar5 + 10));
                }
                uVar13 = func_0x0001800f65a0(arg3, 0x1806450b8, *(undefined *)(iVar5 + 0x1e));
                if (*(int32_t *)(iVar5 + 0x14) != 0) {
                    if (*(int16_t *)(iVar5 + 0x1c) == -1) {
                        func_0x0001800f65a0(uVar13, 0x1806450c8);
                    } else {
                        func_0x0001800f65a0(uVar13, 0x180645068, *(int32_t *)(iVar5 + 0x14), 
                                            (int32_t)*(int16_t *)(iVar5 + 0x1c));
                    }
                    if (*(int32_t *)(iVar5 + 0x18) != 0) {
                        func_0x0001800f65a0(arg3, 0x180645080);
                    }
                }
            } else {
                uVar13 = func_0x0001800f65a0(uVar13, 0x180644ff0);
                func_0x0001800f65a0(uVar13, 0x180645000, (int32_t)*(int16_t *)(iVar5 + 8), 
                                    (int32_t)*(int16_t *)(iVar5 + 10));
            }
            iVar12 = 1;
            if (*(int32_t *)arg3 != 0) {
                iVar12 = *(int32_t *)arg3;
            }
            iVar4 = *(int32_t *)(arg3 + 4);
            iVar9 = iVar12 + 1;
            if (iVar4 <= iVar9) {
                iVar10 = iVar4 * 2;
                if (iVar4 * 2 < iVar9) {
                    iVar10 = iVar9;
                }
                if (iVar4 < iVar10) {
                    uVar7 = func_0x00018046d050((int64_t)iVar10);
                    if (*(int64_t *)(arg3 + 8) != 0) {
                        func_0x000180498030(uVar7, *(int64_t *)(arg3 + 8), (int64_t)*(int32_t *)arg3);
                        func_0x000180460d90(*(undefined8 *)(arg3 + 8));
                    }
                    *(undefined8 *)(arg3 + 8) = uVar7;
                    *(int32_t *)(arg3 + 4) = iVar10;
                }
            }
            func_0x00018011f640(arg3, iVar9);
            *(undefined *)((int64_t)iVar12 + -1 + *(int64_t *)(arg3 + 8)) = 10;
            *(undefined *)((int64_t)iVar12 + *(int64_t *)(arg3 + 8)) = 0;
        }
        iVar8 = *(int32_t *)(iVar5 + -4) + iVar5;
        iVar5 = 0;
        if (iVar8 != *(int64_t *)(arg1 + 0x2958) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2950)) {
            iVar5 = iVar8;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180113580
// Address: 0x180113580
// Size: 397 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180113580(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    char cVar6;
    undefined4 *puVar7;
    uint32_t uVar8;
    int32_t iVar9;
    undefined8 *puVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar2 = *(undefined4 **)(arg1 + 0x48);
    if (((puVar2 != (undefined4 *)arg2) && ((*(uint32_t *)(arg2 + 4) >> 0xb & 1) != 0)) &&
       ((*(uint32_t *)(arg2 + 4) >> 0xc & 1) == 0)) {
        fVar13 = *(float *)(arg1 + 0x60);
        if (*(float *)(arg2 + 8) <= fVar13) {
            fVar14 = *(float *)(arg1 + 100);
            if (((*(float *)(arg2 + 0xc) <= fVar14) &&
                (fVar12 = fVar13 + *(float *)(arg1 + 0x68), fVar12 <= *(float *)(arg2 + 8) + *(float *)(arg2 + 0x10)))
               && ((fVar11 = fVar14 + *(float *)(arg1 + 0x6c),
                   fVar11 <= *(float *)(arg2 + 0xc) + *(float *)(arg2 + 0x14) &&
                   (cVar6 = func_0x000180113530(), iVar5 = *(int64_t *)0x180781f28, cVar6 == '\0')))) {
                puVar10 = *(undefined8 **)(*(int64_t *)0x180781f28 + 0x2158);
                puVar1 = puVar10 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
                do {
                    if (puVar10 == puVar1) {
                        iVar9 = 0;
                        if ((*(char *)(arg1 + 0x108) != '\0') && (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580))) {
                            do {
                                iVar4 = *(int64_t *)(*(int64_t *)(iVar5 + 0x1588) + (int64_t)iVar9 * 8);
                                puVar3 = *(undefined4 **)(iVar4 + 0x48);
                                if (puVar3 == puVar2) {
                                    if ((*(char *)(iVar4 + 0x108) != '\0') && (*(int64_t *)(puVar3 + 0x1e) == iVar4)) {
                                        *(undefined8 *)(puVar3 + 4) = 0;
                                    }
                                    *(int64_t *)(iVar4 + 0x48) = arg2;
                                    *(undefined4 *)(iVar4 + 0x50) = *(undefined4 *)arg2;
                                    *(bool *)(iVar4 + 0x108) = *(int64_t *)(arg2 + 0x78) == iVar4;
                                }
                                iVar9 = iVar9 + 1;
                            } while (iVar9 < *(int32_t *)(iVar5 + 0x1580));
                        }
                        if ((*(char *)(arg1 + 0x108) != '\0') &&
                           (*(int64_t *)(*(int64_t *)(arg1 + 0x48) + 0x78) == arg1)) {
                            *(undefined8 *)(*(int64_t *)(arg1 + 0x48) + 0x10) = 0;
                        }
                        *(int64_t *)(arg1 + 0x48) = arg2;
                        *(undefined4 *)(arg1 + 0x50) = *(undefined4 *)arg2;
                        *(bool *)(arg1 + 0x108) = *(int64_t *)(arg2 + 0x78) == arg1;
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x2000) == 0) {
                            func_0x00018010dfb0(arg1);
                        }
                        return 1;
                    }
                    puVar3 = (undefined4 *)*puVar10;
                    if (((((puVar3 != puVar2) && (puVar3 != (undefined4 *)arg2)) &&
                         (fVar14 < (float)puVar3[3] + (float)puVar3[5])) &&
                        (((float)puVar3[3] < fVar11 && (fVar13 < (float)puVar3[2] + (float)puVar3[4])))) &&
                       ((float)puVar3[2] < fVar12)) {
                        uVar8 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x34) & 0x2000;
                        puVar7 = puVar3;
                        if (uVar8 == 0) {
                            if (*(undefined4 **)(puVar3 + 0xe) != (undefined4 *)arg2) {
code_r0x0001801136b6:
                                if ((int32_t)puVar3[0x22] <= *(int32_t *)(arg2 + 0x88)) goto code_r0x000180113700;
                            }
                        } else {
                            do {
                                puVar7 = *(undefined4 **)(puVar7 + 0xe);
                                if (puVar7 == (undefined4 *)0x0) goto code_r0x0001801136b6;
                            } while (puVar7 != (undefined4 *)arg2);
                        }
                        if (puVar2 == (undefined4 *)0x0) {
                            return 0;
                        }
                        puVar7 = puVar2;
                        if (uVar8 == 0) {
                            if (*(undefined4 **)(puVar2 + 0xe) == puVar3) {
                                return 0;
                            }
                        } else {
                            while (puVar7 = *(undefined4 **)(puVar7 + 0xe), puVar7 != (undefined4 *)0x0) {
                                if (puVar7 == puVar3) {
                                    return 0;
                                }
                            }
                        }
                        if ((int32_t)puVar3[0x22] < (int32_t)puVar2[0x22]) {
                            return 0;
                        }
                    }
code_r0x000180113700:
                    puVar10 = puVar10 + 1;
                } while( true );
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18011370d
// Address: 0x18011370d
// Size: 177 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180113580(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    char cVar6;
    undefined4 *puVar7;
    uint32_t uVar8;
    int32_t iVar9;
    undefined8 *puVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar2 = *(undefined4 **)(arg1 + 0x48);
    if (((puVar2 != (undefined4 *)arg2) && ((*(uint32_t *)(arg2 + 4) >> 0xb & 1) != 0)) &&
       ((*(uint32_t *)(arg2 + 4) >> 0xc & 1) == 0)) {
        fVar13 = *(float *)(arg1 + 0x60);
        if (*(float *)(arg2 + 8) <= fVar13) {
            fVar14 = *(float *)(arg1 + 100);
            if (((*(float *)(arg2 + 0xc) <= fVar14) &&
                (fVar12 = fVar13 + *(float *)(arg1 + 0x68), fVar12 <= *(float *)(arg2 + 8) + *(float *)(arg2 + 0x10)))
               && ((fVar11 = fVar14 + *(float *)(arg1 + 0x6c),
                   fVar11 <= *(float *)(arg2 + 0xc) + *(float *)(arg2 + 0x14) &&
                   (cVar6 = func_0x000180113530(), iVar5 = *(int64_t *)0x180781f28, cVar6 == '\0')))) {
                puVar10 = *(undefined8 **)(*(int64_t *)0x180781f28 + 0x2158);
                puVar1 = puVar10 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
                do {
                    if (puVar10 == puVar1) {
                        iVar9 = 0;
                        if ((*(char *)(arg1 + 0x108) != '\0') && (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580))) {
                            do {
                                iVar4 = *(int64_t *)(*(int64_t *)(iVar5 + 0x1588) + (int64_t)iVar9 * 8);
                                puVar3 = *(undefined4 **)(iVar4 + 0x48);
                                if (puVar3 == puVar2) {
                                    if ((*(char *)(iVar4 + 0x108) != '\0') && (*(int64_t *)(puVar3 + 0x1e) == iVar4)) {
                                        *(undefined8 *)(puVar3 + 4) = 0;
                                    }
                                    *(int64_t *)(iVar4 + 0x48) = arg2;
                                    *(undefined4 *)(iVar4 + 0x50) = *(undefined4 *)arg2;
                                    *(bool *)(iVar4 + 0x108) = *(int64_t *)(arg2 + 0x78) == iVar4;
                                }
                                iVar9 = iVar9 + 1;
                            } while (iVar9 < *(int32_t *)(iVar5 + 0x1580));
                        }
                        if ((*(char *)(arg1 + 0x108) != '\0') &&
                           (*(int64_t *)(*(int64_t *)(arg1 + 0x48) + 0x78) == arg1)) {
                            *(undefined8 *)(*(int64_t *)(arg1 + 0x48) + 0x10) = 0;
                        }
                        *(int64_t *)(arg1 + 0x48) = arg2;
                        *(undefined4 *)(arg1 + 0x50) = *(undefined4 *)arg2;
                        *(bool *)(arg1 + 0x108) = *(int64_t *)(arg2 + 0x78) == arg1;
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x2000) == 0) {
                            func_0x00018010dfb0(arg1);
                        }
                        return 1;
                    }
                    puVar3 = (undefined4 *)*puVar10;
                    if (((((puVar3 != puVar2) && (puVar3 != (undefined4 *)arg2)) &&
                         (fVar14 < (float)puVar3[3] + (float)puVar3[5])) &&
                        (((float)puVar3[3] < fVar11 && (fVar13 < (float)puVar3[2] + (float)puVar3[4])))) &&
                       ((float)puVar3[2] < fVar12)) {
                        uVar8 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x34) & 0x2000;
                        puVar7 = puVar3;
                        if (uVar8 == 0) {
                            if (*(undefined4 **)(puVar3 + 0xe) != (undefined4 *)arg2) {
code_r0x0001801136b6:
                                if ((int32_t)puVar3[0x22] <= *(int32_t *)(arg2 + 0x88)) goto code_r0x000180113700;
                            }
                        } else {
                            do {
                                puVar7 = *(undefined4 **)(puVar7 + 0xe);
                                if (puVar7 == (undefined4 *)0x0) goto code_r0x0001801136b6;
                            } while (puVar7 != (undefined4 *)arg2);
                        }
                        if (puVar2 == (undefined4 *)0x0) {
                            return 0;
                        }
                        puVar7 = puVar2;
                        if (uVar8 == 0) {
                            if (*(undefined4 **)(puVar2 + 0xe) == puVar3) {
                                return 0;
                            }
                        } else {
                            while (puVar7 = *(undefined4 **)(puVar7 + 0xe), puVar7 != (undefined4 *)0x0) {
                                if (puVar7 == puVar3) {
                                    return 0;
                                }
                            }
                        }
                        if ((int32_t)puVar3[0x22] < (int32_t)puVar2[0x22]) {
                            return 0;
                        }
                    }
code_r0x000180113700:
                    puVar10 = puVar10 + 1;
                } while( true );
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801137be
// Address: 0x1801137be
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180113580(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    char cVar6;
    undefined4 *puVar7;
    uint32_t uVar8;
    int32_t iVar9;
    undefined8 *puVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar2 = *(undefined4 **)(arg1 + 0x48);
    if (((puVar2 != (undefined4 *)arg2) && ((*(uint32_t *)(arg2 + 4) >> 0xb & 1) != 0)) &&
       ((*(uint32_t *)(arg2 + 4) >> 0xc & 1) == 0)) {
        fVar13 = *(float *)(arg1 + 0x60);
        if (*(float *)(arg2 + 8) <= fVar13) {
            fVar14 = *(float *)(arg1 + 100);
            if (((*(float *)(arg2 + 0xc) <= fVar14) &&
                (fVar12 = fVar13 + *(float *)(arg1 + 0x68), fVar12 <= *(float *)(arg2 + 8) + *(float *)(arg2 + 0x10)))
               && ((fVar11 = fVar14 + *(float *)(arg1 + 0x6c),
                   fVar11 <= *(float *)(arg2 + 0xc) + *(float *)(arg2 + 0x14) &&
                   (cVar6 = func_0x000180113530(), iVar5 = *(int64_t *)0x180781f28, cVar6 == '\0')))) {
                puVar10 = *(undefined8 **)(*(int64_t *)0x180781f28 + 0x2158);
                puVar1 = puVar10 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
                do {
                    if (puVar10 == puVar1) {
                        iVar9 = 0;
                        if ((*(char *)(arg1 + 0x108) != '\0') && (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580))) {
                            do {
                                iVar4 = *(int64_t *)(*(int64_t *)(iVar5 + 0x1588) + (int64_t)iVar9 * 8);
                                puVar3 = *(undefined4 **)(iVar4 + 0x48);
                                if (puVar3 == puVar2) {
                                    if ((*(char *)(iVar4 + 0x108) != '\0') && (*(int64_t *)(puVar3 + 0x1e) == iVar4)) {
                                        *(undefined8 *)(puVar3 + 4) = 0;
                                    }
                                    *(int64_t *)(iVar4 + 0x48) = arg2;
                                    *(undefined4 *)(iVar4 + 0x50) = *(undefined4 *)arg2;
                                    *(bool *)(iVar4 + 0x108) = *(int64_t *)(arg2 + 0x78) == iVar4;
                                }
                                iVar9 = iVar9 + 1;
                            } while (iVar9 < *(int32_t *)(iVar5 + 0x1580));
                        }
                        if ((*(char *)(arg1 + 0x108) != '\0') &&
                           (*(int64_t *)(*(int64_t *)(arg1 + 0x48) + 0x78) == arg1)) {
                            *(undefined8 *)(*(int64_t *)(arg1 + 0x48) + 0x10) = 0;
                        }
                        *(int64_t *)(arg1 + 0x48) = arg2;
                        *(undefined4 *)(arg1 + 0x50) = *(undefined4 *)arg2;
                        *(bool *)(arg1 + 0x108) = *(int64_t *)(arg2 + 0x78) == arg1;
                        if ((*(uint32_t *)(arg1 + 0x14) & 0x2000) == 0) {
                            func_0x00018010dfb0(arg1);
                        }
                        return 1;
                    }
                    puVar3 = (undefined4 *)*puVar10;
                    if (((((puVar3 != puVar2) && (puVar3 != (undefined4 *)arg2)) &&
                         (fVar14 < (float)puVar3[3] + (float)puVar3[5])) &&
                        (((float)puVar3[3] < fVar11 && (fVar13 < (float)puVar3[2] + (float)puVar3[4])))) &&
                       ((float)puVar3[2] < fVar12)) {
                        uVar8 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x34) & 0x2000;
                        puVar7 = puVar3;
                        if (uVar8 == 0) {
                            if (*(undefined4 **)(puVar3 + 0xe) != (undefined4 *)arg2) {
code_r0x0001801136b6:
                                if ((int32_t)puVar3[0x22] <= *(int32_t *)(arg2 + 0x88)) goto code_r0x000180113700;
                            }
                        } else {
                            do {
                                puVar7 = *(undefined4 **)(puVar7 + 0xe);
                                if (puVar7 == (undefined4 *)0x0) goto code_r0x0001801136b6;
                            } while (puVar7 != (undefined4 *)arg2);
                        }
                        if (puVar2 == (undefined4 *)0x0) {
                            return 0;
                        }
                        puVar7 = puVar2;
                        if (uVar8 == 0) {
                            if (*(undefined4 **)(puVar2 + 0xe) == puVar3) {
                                return 0;
                            }
                        } else {
                            while (puVar7 = *(undefined4 **)(puVar7 + 0xe), puVar7 != (undefined4 *)0x0) {
                                if (puVar7 == puVar3) {
                                    return 0;
                                }
                            }
                        }
                        if ((int32_t)puVar3[0x22] < (int32_t)puVar2[0x22]) {
                            return 0;
                        }
                    }
code_r0x000180113700:
                    puVar10 = puVar10 + 1;
                } while( true );
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801137e0
// Address: 0x1801137e0
// Size: 664 bytes
// ============================================================
void fcn.1801137e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_58h)
{
    int64_t *piVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t *piVar9;
    float fVar10;
    float fVar11;
    float *in_stack_00000028;
    int64_t var_28h;
    int64_t var_18h;
    
    fVar2 = *(float *)arg2;
    fVar10 = *(float *)arg3 - fVar2;
    piVar9 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x1588);
    uVar6 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x12cc);
    uVar7 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x12d0);
    fVar3 = *(float *)(arg2 + 4);
    fVar11 = *(float *)(arg3 + 4) - fVar3;
    piVar1 = piVar9 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580);
    fVar4 = *(float *)arg4;
    fVar5 = *(float *)(arg4 + 4);
    for (; piVar9 != piVar1; piVar9 = piVar9 + 1) {
        iVar8 = *piVar9;
        if (((uVar6 & 0x400) != (uVar7 & 0x400)) ||
           ((*(int64_t *)(iVar8 + 0x48) == arg1 &&
            (((*(float *)arg4 == *in_stack_00000028 && (*(float *)(arg4 + 4) == in_stack_00000028[1])) ||
             ((fVar2 <= *(float *)(iVar8 + 0x60) &&
              (((fVar3 <= *(float *)(iVar8 + 100) &&
                (*(float *)(iVar8 + 0x60) + *(float *)(iVar8 + 0x68) <= fVar2 + fVar4)) &&
               (*(float *)(iVar8 + 100) + *(float *)(iVar8 + 0x6c) <= fVar3 + fVar5)))))))))) {
            *(float *)(iVar8 + 0x60) = fVar10 + *(float *)(iVar8 + 0x60);
            *(float *)(iVar8 + 100) = fVar11 + *(float *)(iVar8 + 100);
            *(float *)(iVar8 + 0x2b8) = fVar10 + *(float *)(iVar8 + 0x2b8);
            *(float *)(iVar8 + 700) = fVar11 + *(float *)(iVar8 + 700);
            *(float *)(iVar8 + 0x2c0) = fVar10 + *(float *)(iVar8 + 0x2c0);
            *(float *)(iVar8 + 0x2c4) = fVar11 + *(float *)(iVar8 + 0x2c4);
            *(float *)(iVar8 + 0x268) = fVar10 + *(float *)(iVar8 + 0x268);
            *(float *)(iVar8 + 0x26c) = fVar11 + *(float *)(iVar8 + 0x26c);
            *(float *)(iVar8 + 0x270) = fVar10 + *(float *)(iVar8 + 0x270);
            *(float *)(iVar8 + 0x274) = fVar11 + *(float *)(iVar8 + 0x274);
            *(float *)(iVar8 + 0x278) = fVar10 + *(float *)(iVar8 + 0x278);
            *(float *)(iVar8 + 0x27c) = fVar11 + *(float *)(iVar8 + 0x27c);
            *(float *)(iVar8 + 0x280) = fVar10 + *(float *)(iVar8 + 0x280);
            *(float *)(iVar8 + 0x284) = fVar11 + *(float *)(iVar8 + 0x284);
            *(float *)(iVar8 + 0x158) = fVar10 + *(float *)(iVar8 + 0x158);
            *(float *)(iVar8 + 0x15c) = fVar11 + *(float *)(iVar8 + 0x15c);
            *(float *)(iVar8 + 0x168) = fVar10 + *(float *)(iVar8 + 0x168);
            *(float *)(iVar8 + 0x16c) = fVar11 + *(float *)(iVar8 + 0x16c);
            *(float *)(iVar8 + 0x170) = fVar10 + *(float *)(iVar8 + 0x170);
            *(float *)(iVar8 + 0x174) = fVar11 + *(float *)(iVar8 + 0x174);
            *(float *)(iVar8 + 0x178) = fVar10 + *(float *)(iVar8 + 0x178);
            *(float *)(iVar8 + 0x17c) = fVar11 + *(float *)(iVar8 + 0x17c);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180113b10
// Address: 0x180113b10
// Size: 3095 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: [rz-ghidra] Removing arg arg_d40h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ca0h because it doesn't fit into ProtoModel

void fcn.180113b10(void)
{
    int32_t **ppiVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint8_t uVar4;
    undefined4 *puVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    char cVar9;
    undefined uVar10;
    int32_t iVar11;
    int64_t *piVar12;
    undefined8 *puVar13;
    int32_t *piVar14;
    uint8_t uVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int32_t *piVar18;
    int64_t iVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    int32_t **ppiVar22;
    int64_t *piVar23;
    undefined4 uVar24;
    float fVar25;
    float fVar26;
    undefined4 uVar27;
    undefined4 uVar28;
    undefined4 uVar29;
    float fVar30;
    float fVar31;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    undefined4 unaff_XMM9_Dc;
    undefined4 unaff_XMM9_Dd;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int32_t iStack_98;
    int32_t iStack_94;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    
    iVar7 = *(int64_t *)0x180781f28;
    var_88h._4_4_ = unaff_XMM9_Db;
    var_88h._0_4_ = unaff_XMM9_Da;
    unique0x1000034c = unaff_XMM9_Dc;
    unique0x10000350 = unaff_XMM9_Dd;
    uVar21 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x12cc) & 0x400;
    if (uVar21 == 0) {
code_r0x000180113d89:
        var_10h = **(int64_t **)(iVar7 + 0x2158);
        if (uVar21 != 0) goto code_r0x000180113da6;
        uVar24 = 0;
        uVar27 = 0;
        uVar28 = (undefined4)*(undefined8 *)(iVar7 + 0x38);
        uVar29 = (undefined4)((uint64_t)*(undefined8 *)(iVar7 + 0x38) >> 0x20);
code_r0x000180113e16:
        var_18h = CONCAT44(uVar29, uVar28);
        var_20h = CONCAT44(uVar27, uVar24);
    } else {
        piVar18 = (int32_t *)0x0;
        ppiVar22 = *(int32_t ***)(*(int64_t *)0x180781f28 + 0x2158);
        ppiVar1 = ppiVar22 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
        if (ppiVar22 == ppiVar1) goto code_r0x000180113d89;
        do {
            piVar14 = *ppiVar22;
            cVar9 = *(char *)(piVar14 + 0x1c);
            if ((*(code **)(iVar7 + 0xce8) != (code *)0x0) && (cVar9 != '\0')) {
                cVar8 = (**(code **)(iVar7 + 0xce8))(piVar14);
                if (cVar8 == '\0') {
                    uVar16 = piVar14[1] & 0xffffefff;
                } else {
                    uVar16 = piVar14[1] | 0x1000;
                }
                piVar14[1] = uVar16;
            }
            if ((*(code **)(iVar7 + 0xce0) != (code *)0x0) && (cVar9 != '\0')) {
                cVar9 = (**(code **)(iVar7 + 0xce0))(piVar14);
                if (cVar9 == '\0') {
                    uVar16 = piVar14[1] & 0xffffdfff;
                } else {
                    uVar16 = piVar14[1] | 0x2000;
                    piVar18 = piVar14;
                }
                piVar14[1] = uVar16;
            }
            iVar17 = *(int64_t *)0x180781f28;
            ppiVar22 = ppiVar22 + 1;
        } while (ppiVar22 != ppiVar1);
        if (piVar18 == (int32_t *)0x0) goto code_r0x000180113d89;
        if (*(int32_t *)(iVar7 + 0x2178) != *piVar18) {
            ppiVar22 = *(int32_t ***)(*(int64_t *)0x180781f28 + 0x2158);
            ppiVar1 = ppiVar22 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
            for (; ppiVar22 != ppiVar1; ppiVar22 = ppiVar22 + 1) {
                if (**ppiVar22 == *(int32_t *)(iVar7 + 0x2178)) {
                    if (*(char *)(*ppiVar22 + 0x1c) != '\0') {
                        bVar6 = false;
                        goto code_r0x000180113c36;
                    }
                    break;
                }
            }
            bVar6 = true;
code_r0x000180113c36:
            if (piVar18[0x22] != *(int32_t *)(iVar7 + 0x21c8)) {
                iVar11 = *(int32_t *)(iVar7 + 0x21c8) + 1;
                *(int32_t *)(iVar7 + 0x21c8) = iVar11;
                piVar18[0x22] = iVar11;
            }
            *(int32_t *)(iVar7 + 0x2178) = *piVar18;
            if ((((((*(char *)(iVar17 + 0x120) == '\0') && (*(char *)(iVar17 + 0x121) == '\0')) &&
                  (*(char *)(iVar17 + 0x122) == '\0')) &&
                 ((*(char *)(iVar17 + 0x123) == '\0' && (*(char *)(iVar17 + 0x124) == '\0')))) && (!bVar6)) &&
               (*(char *)(iVar7 + 0x89) != '\0')) {
                uVar4 = *(uint8_t *)(piVar18 + 0x2a);
                if ((*(int64_t *)(iVar7 + 0x21d8) == 0) ||
                   (*(int32_t **)(*(int64_t *)(iVar7 + 0x21d8) + 0x48) != piVar18)) {
                    uVar15 = 0;
                } else {
                    uVar15 = 1;
                }
                *(uint8_t *)(piVar18 + 0x2a) = uVar4 | uVar15;
                iVar19 = *(int64_t *)(piVar18 + 0x1e);
                if (iVar19 == 0) {
                    if (((uVar4 | uVar15) != 0) && (uVar16 = *(int32_t *)(iVar17 + 0x1590) - 1, -1 < (int32_t)uVar16)) {
                        do {
                            iVar19 = *(int64_t *)(*(int64_t *)(iVar17 + 0x1598) + (uint64_t)uVar16 * 8);
                            if ((((iVar19 != 0) && (*(char *)(iVar19 + 0x10a) != '\0')) &&
                                (*(int32_t **)(iVar19 + 0x48) == piVar18)) &&
                               ((*(uint32_t *)(iVar19 + 0x14) & 0x10200) != 0x10200)) goto code_r0x000180113d3f;
                            uVar16 = uVar16 - 1;
                        } while (-1 < (int32_t)uVar16);
                    }
                    iVar19 = 0;
                }
code_r0x000180113d3f:
                func_0x00018010e050(iVar19, 3);
            }
        }
        if ((*(int64_t *)(iVar7 + 0x21d8) == 0) || (*(int32_t **)(*(int64_t *)(iVar7 + 0x21d8) + 0x48) != piVar18)) {
            uVar10 = 0;
        } else {
            uVar10 = 1;
        }
        *(undefined *)(piVar18 + 0x2a) = uVar10;
        var_10h = **(int64_t **)(iVar7 + 0x2158);
code_r0x000180113da6:
        piVar12 = (int64_t *)(**(code **)(iVar7 + 0xcb8))(&var_18h, var_10h);
        var_20h = *piVar12;
        var_18h = *(int64_t *)(iVar7 + 0x38);
        if ((*(uint32_t *)(var_10h + 4) & 0x1000) != 0) {
            uVar24 = (undefined4)*(undefined8 *)(var_10h + 8);
            uVar27 = (undefined4)((uint64_t)*(undefined8 *)(var_10h + 8) >> 0x20);
            uVar28 = (undefined4)*(undefined8 *)(var_10h + 0x10);
            uVar29 = (undefined4)((uint64_t)*(undefined8 *)(var_10h + 0x10) >> 0x20);
            goto code_r0x000180113e16;
        }
    }
    func_0x000180114730(0, 0x11111111, &var_20h, &var_18h, 0x804);
    if ((*(char *)(iVar7 + 0x20b9) != '\0') || (*(float *)(iVar7 + 0x98) < 0.0)) {
        fVar31 = 3.402823e+38;
    } else {
        fVar31 = (float)*(double *)(iVar7 + 0x18) - *(float *)(iVar7 + 0x98);
    }
    iVar11 = 0;
    *(undefined4 *)(iVar7 + 0x1308) = 0;
    *(undefined8 *)(iVar7 + 0x2160) = 0;
    *(undefined8 *)(iVar7 + 0x2168) = 0;
    if (0 < *(int32_t *)(iVar7 + 0x2150)) {
        do {
            piVar18 = *(int32_t **)(*(int64_t *)(iVar7 + 0x2158) + (int64_t)iVar11 * 8);
            piVar18[0x20] = iVar11;
            iVar17 = *(int64_t *)0x180781f28;
            if ((iVar11 < 1) || (*(int32_t *)(iVar7 + 4) + -2 <= piVar18[0x21])) {
                cVar9 = *(char *)(piVar18 + 0x1c);
                if ((uVar21 != 0) && (((piVar18[1] & 0x1000U) == 0 && (cVar9 != '\0')))) {
                    if (*(char *)((int64_t)piVar18 + 0x71) != '\0') {
                        piVar14 = (int32_t *)(**(code **)(iVar7 + 0xcb8))(&var_18h, piVar18);
                        iVar2 = *piVar14;
                        iVar3 = piVar14[1];
                        piVar18[0x4c] = iVar2;
                        piVar18[0x4d] = iVar3;
                        piVar18[2] = iVar2;
                        piVar18[3] = iVar3;
                    }
                    if (*(char *)((int64_t)piVar18 + 0x72) != '\0') {
                        piVar14 = (int32_t *)(**(code **)(iVar7 + 0xcc8))(&var_20h, piVar18);
                        iVar2 = *piVar14;
                        iVar3 = piVar14[1];
                        piVar18[0x4e] = iVar2;
                        piVar18[0x4f] = iVar3;
                        piVar18[4] = iVar2;
                        piVar18[5] = iVar3;
                    }
                    if (*(code **)(iVar7 + 0xcd0) != (code *)0x0) {
                        puVar13 = (undefined8 *)(**(code **)(iVar7 + 0xcd0))(&var_a8h, piVar18);
                        *(undefined8 *)(piVar18 + 6) = *puVar13;
                    }
                }
                func_0x000180114a60(piVar18);
                piVar18[0x52] = piVar18[0x56];
                piVar18[0x53] = piVar18[0x57];
                piVar18[0x54] = piVar18[0x58];
                piVar18[0x55] = piVar18[0x59];
                *(undefined8 *)(piVar18 + 0x58) = 0;
                *(undefined8 *)(piVar18 + 0x56) = 0;
                if ((*(code **)(iVar7 + 0xd28) != (code *)0x0) && (cVar9 != '\0')) {
                    (**(code **)(iVar7 + 0xd28))(&var_a0h, piVar18);
                    piVar18[0x56] = (int32_t)var_a0h;
                    piVar18[0x57] = var_a0h._4_4_;
                    piVar18[0x58] = iStack_98;
                    piVar18[0x59] = iStack_94;
                }
                piVar18[8] = (int32_t)((float)piVar18[0x52] + (float)piVar18[2]);
                piVar18[9] = (int32_t)((float)piVar18[0x53] + (float)piVar18[3]);
                fVar25 = ((float)piVar18[5] - (float)piVar18[0x53]) - (float)piVar18[0x55];
                fVar26 = 0.0;
                if (0.0 <= fVar25) {
                    fVar26 = fVar25;
                }
                fVar30 = ((float)piVar18[4] - (float)piVar18[0x52]) - (float)piVar18[0x54];
                fVar25 = 0.0;
                if (0.0 <= fVar30) {
                    fVar25 = fVar30;
                }
                piVar18[10] = (int32_t)fVar25;
                piVar18[0xb] = (int32_t)fVar26;
                if (((float)piVar18[0x2b] <= fVar31 && fVar31 != (float)piVar18[0x2b]) &&
                   (iVar17 = *(int64_t *)(piVar18 + 0x2e), iVar17 != 0)) {
                    func_0x000180123dd0(iVar17);
                    func_0x000180460d90(iVar17);
                    *(undefined8 *)(piVar18 + 0x2e) = 0;
                }
                if (((float)piVar18[0x2c] <= fVar31 && fVar31 != (float)piVar18[0x2c]) &&
                   (iVar17 = *(int64_t *)(piVar18 + 0x30), iVar17 != 0)) {
                    func_0x000180123dd0(iVar17);
                    func_0x000180460d90(iVar17);
                    *(undefined8 *)(piVar18 + 0x30) = 0;
                }
                piVar18[0x28] = 0x3f800000;
                if (((piVar18[1] & 0x800U) != 0) &&
                   (((float)piVar18[2] - (float)piVar18[0x24] != 0.0 ||
                    ((float)piVar18[3] - (float)piVar18[0x25] != 0.0)))) {
                    fcn.1801137e0((int64_t)piVar18, (int64_t)(piVar18 + 0x24), (int64_t)(piVar18 + 2), 
                                  (int64_t)(piVar18 + 0x26), var_88h);
                }
                if ((*(code **)(iVar7 + 0xd18) == (code *)0x0) || (cVar9 == '\0')) {
                    if (*(int16_t *)((int64_t)piVar18 + 0xaa) == -1) {
                        fVar26 = (float)piVar18[0xc];
                        if (fVar26 == 0.0) {
                            fVar26 = 1.0;
                        }
                    } else {
                        fVar26 = *(float *)(*(int64_t *)(iVar7 + 0xd68) + 0x20 +
                                           (int64_t)*(int16_t *)((int64_t)piVar18 + 0xaa) * 0x30);
                    }
                } else {
                    fVar26 = (float)(**(code **)(iVar7 + 0xd18))(piVar18);
                }
                fVar25 = (float)piVar18[0xc];
                if (((fVar25 != 0.0) && (fVar26 != fVar25)) && (*(char *)(iVar7 + 0x8b) != '\0')) {
                    fVar25 = fVar26 / fVar25;
                    if (*(int64_t *)(piVar18 + 0x1e) == 0) {
                        piVar23 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x1588);
                        piVar12 = piVar23 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580);
                        if (piVar23 != piVar12) {
                            do {
                                if (*(int32_t **)(*piVar23 + 0x48) == piVar18) {
                                    func_0x0001800fad40(*piVar23, fVar25);
                                }
                                piVar23 = piVar23 + 1;
                            } while (piVar23 != piVar12);
                        }
                    } else {
                        func_0x0001800fad40(*(int64_t *)(piVar18 + 0x1e), fVar25);
                    }
                }
                piVar18[0xc] = (int32_t)fVar26;
            } else {
                piVar23 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x1588);
                piVar12 = piVar23 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580);
                for (; piVar23 != piVar12; piVar23 = piVar23 + 1) {
                    iVar19 = *piVar23;
                    if (*(int32_t **)(iVar19 + 0x48) == piVar18) {
                        *(undefined8 *)(iVar19 + 0x48) = 0;
                        *(undefined *)(iVar19 + 0x108) = 0;
                    }
                }
                if (piVar18 == *(int32_t **)(iVar17 + 0x2170)) {
                    *(undefined8 *)(iVar17 + 0x2170) = 0;
                }
                iVar19 = *(int64_t *)0x180781f28;
                if (*(char *)(piVar18 + 0x1c) != '\0') {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0xd40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0xd40))(piVar18);
                    }
                    if (*(code **)(iVar19 + 0xca0) != (code *)0x0) {
                        (**(code **)(iVar19 + 0xca0))(piVar18);
                    }
                    if (*piVar18 != 0x11111111) {
                        *(undefined *)(piVar18 + 0x1c) = 0;
                    }
                }
                *(undefined8 *)(piVar18 + 0x18) = 0;
                *(undefined8 *)(piVar18 + 0x14) = 0;
                *(undefined8 *)(piVar18 + 0x12) = 0;
                *(undefined2 *)((int64_t)piVar18 + 0x71) = 0;
                *(undefined *)((int64_t)piVar18 + 0x73) = 0;
                iVar19 = *(int64_t *)(iVar17 + 0x2158) + (int64_t)piVar18[0x20] * 8;
                func_0x000180498030(iVar19, iVar19 + 8, 
                                    ((int64_t)*(int32_t *)(iVar17 + 0x2150) - (int64_t)piVar18[0x20]) * 8 + -8);
                *(int32_t *)(iVar17 + 0x2150) = *(int32_t *)(iVar17 + 0x2150) + -1;
                iVar17 = *(int64_t *)(piVar18 + 0x2e);
                if (iVar17 != 0) {
                    func_0x000180123dd0(iVar17);
                    func_0x000180460d90(iVar17);
                }
                iVar17 = *(int64_t *)(piVar18 + 0x30);
                if (iVar17 != 0) {
                    func_0x000180123dd0(iVar17);
                    func_0x000180460d90(iVar17);
                }
                if (*(int64_t *)(piVar18 + 0x4a) != 0) {
                    func_0x000180460d90();
                }
                if (*(int64_t *)(piVar18 + 0x38) != 0) {
                    func_0x000180460d90();
                }
                func_0x000180460d90(piVar18);
                iVar11 = iVar11 + -1;
            }
            iVar11 = iVar11 + 1;
        } while (iVar11 < *(int32_t *)(iVar7 + 0x2150));
    }
    piVar18 = (int32_t *)0x0;
    *(undefined4 *)(iVar7 + 0x21b0) = 0x7f7fffff;
    *(undefined4 *)(iVar7 + 0x21b4) = 0x7f7fffff;
    *(undefined4 *)(iVar7 + 0x21b8) = 0xff7fffff;
    *(undefined4 *)(iVar7 + 0x21bc) = 0xff7fffff;
    if (*(int32_t *)(iVar7 + 0xd60) == 0) {
        *(undefined8 *)(iVar7 + 0x2180) = *(undefined8 *)(var_10h + 8);
        *(undefined8 *)(iVar7 + 0x2188) = *(undefined8 *)(var_10h + 0x10);
        *(undefined8 *)(iVar7 + 0x2190) = *(undefined8 *)(var_10h + 0x20);
        *(undefined8 *)(iVar7 + 0x2198) = *(undefined8 *)(var_10h + 0x28);
        *(undefined4 *)(iVar7 + 0x21a0) = *(undefined4 *)(var_10h + 0x30);
        if (*(float *)(iVar7 + 0x2190) < *(float *)(iVar7 + 0x21b0)) {
            *(float *)(iVar7 + 0x21b0) = *(float *)(iVar7 + 0x2190);
        }
        if (*(float *)(iVar7 + 0x2194) < *(float *)(iVar7 + 0x21b4)) {
            *(float *)(iVar7 + 0x21b4) = *(float *)(iVar7 + 0x2194);
        }
        fVar31 = *(float *)(iVar7 + 0x2190);
        fVar26 = *(float *)(iVar7 + 0x21b8);
        if (fVar26 < fVar31) {
            *(float *)(iVar7 + 0x21b8) = fVar31;
            fVar26 = fVar31;
        }
        fVar31 = *(float *)(iVar7 + 0x2194);
        fVar25 = *(float *)(iVar7 + 0x21bc);
        if (fVar25 < fVar31) {
            *(float *)(iVar7 + 0x21bc) = fVar31;
            fVar25 = fVar31;
        }
        fVar30 = *(float *)(iVar7 + 0x2198) + *(float *)(iVar7 + 0x2190);
        fVar31 = *(float *)(iVar7 + 0x219c) + *(float *)(iVar7 + 0x2194);
        if (fVar30 < *(float *)(iVar7 + 0x21b0)) {
            *(float *)(iVar7 + 0x21b0) = fVar30;
            fVar26 = *(float *)(iVar7 + 0x21b8);
            fVar25 = *(float *)(iVar7 + 0x21bc);
        }
        if (fVar31 < *(float *)(iVar7 + 0x21b4)) {
            *(float *)(iVar7 + 0x21b4) = fVar31;
        }
        if (fVar26 < fVar30) {
            *(float *)(iVar7 + 0x21b8) = fVar30;
        }
        if (fVar25 < fVar31) {
            *(float *)(iVar7 + 0x21bc) = fVar31;
        }
    } else {
        puVar5 = *(undefined4 **)(iVar7 + 0xd68);
        uVar24 = puVar5[1];
        uVar27 = puVar5[2];
        uVar28 = puVar5[3];
        *(undefined4 *)(iVar7 + 0x2180) = *puVar5;
        *(undefined4 *)(iVar7 + 0x2184) = uVar24;
        *(undefined4 *)(iVar7 + 0x2188) = uVar27;
        *(undefined4 *)(iVar7 + 0x218c) = uVar28;
        uVar24 = puVar5[5];
        uVar27 = puVar5[6];
        uVar28 = puVar5[7];
        *(undefined4 *)(iVar7 + 0x2190) = puVar5[4];
        *(undefined4 *)(iVar7 + 0x2194) = uVar24;
        *(undefined4 *)(iVar7 + 0x2198) = uVar27;
        *(undefined4 *)(iVar7 + 0x219c) = uVar28;
        uVar24 = puVar5[9];
        uVar27 = puVar5[10];
        uVar28 = puVar5[0xb];
        *(undefined4 *)(iVar7 + 0x21a0) = puVar5[8];
        *(undefined4 *)(iVar7 + 0x21a4) = uVar24;
        *(undefined4 *)(iVar7 + 0x21a8) = uVar27;
        *(undefined4 *)(iVar7 + 0x21ac) = uVar28;
    }
    iVar17 = *(int64_t *)(iVar7 + 0xd68);
    iVar19 = (int64_t)*(int32_t *)(iVar7 + 0xd60) * 0x30 + iVar17;
    for (; iVar17 != iVar19; iVar17 = iVar17 + 0x30) {
        fVar31 = *(float *)(iVar17 + 0x10);
        fVar26 = *(float *)(iVar7 + 0x21b0);
        if (fVar31 < fVar26) {
            *(float *)(iVar7 + 0x21b0) = fVar31;
            fVar26 = fVar31;
        }
        if (*(float *)(iVar17 + 0x14) < *(float *)(iVar7 + 0x21b4)) {
            *(float *)(iVar7 + 0x21b4) = *(float *)(iVar17 + 0x14);
            fVar26 = *(float *)(iVar7 + 0x21b0);
        }
        fVar31 = *(float *)(iVar17 + 0x10);
        if (*(float *)(iVar7 + 0x21b8) <= fVar31 && fVar31 != *(float *)(iVar7 + 0x21b8)) {
            *(float *)(iVar7 + 0x21b8) = fVar31;
        }
        fVar31 = *(float *)(iVar17 + 0x14);
        fVar25 = *(float *)(iVar7 + 0x21bc);
        if (fVar25 < fVar31) {
            *(float *)(iVar7 + 0x21bc) = fVar31;
            fVar25 = fVar31;
        }
        fVar30 = *(float *)(iVar17 + 0x18) + *(float *)(iVar17 + 0x10);
        fVar31 = *(float *)(iVar17 + 0x1c) + *(float *)(iVar17 + 0x14);
        if (fVar30 < fVar26) {
            *(float *)(iVar7 + 0x21b0) = fVar30;
        }
        if (fVar31 < *(float *)(iVar7 + 0x21b4)) {
            *(float *)(iVar7 + 0x21b4) = fVar31;
            fVar25 = *(float *)(iVar7 + 0x21bc);
        }
        if (*(float *)(iVar7 + 0x21b8) <= fVar30 && fVar30 != *(float *)(iVar7 + 0x21b8)) {
            *(float *)(iVar7 + 0x21b8) = fVar30;
        }
        if (fVar25 < fVar31) {
            *(float *)(iVar7 + 0x21bc) = fVar31;
        }
    }
    if (uVar21 == 0) {
        *(int64_t *)(iVar7 + 0x2168) = var_10h;
        return;
    }
    if ((*(uint32_t *)(iVar7 + 0x34) & 0x1000) == 0) {
code_r0x000180114637:
        piVar14 = (int32_t *)func_0x000180113a80(iVar7 + 0x118);
code_r0x000180114646:
        piVar18 = piVar14;
        if (piVar14 == (int32_t *)0x0) goto code_r0x00018011465a;
        *(int32_t **)(iVar7 + 0x2170) = piVar14;
    } else {
        if (*(int32_t *)(iVar7 + 0x134) != 0) {
            ppiVar22 = *(int32_t ***)(*(int64_t *)0x180781f28 + 0x2158);
            ppiVar1 = ppiVar22 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
            for (; (piVar14 = piVar18, ppiVar22 != ppiVar1 &&
                   (piVar14 = *ppiVar22, **ppiVar22 != *(int32_t *)(iVar7 + 0x134))); ppiVar22 = ppiVar22 + 1) {
            }
            piVar18 = piVar14;
            if (piVar14 != (int32_t *)0x0) {
                if ((*(uint8_t *)(piVar14 + 1) & 0x80) != 0) goto code_r0x000180114637;
                goto code_r0x000180114646;
            }
        }
code_r0x00018011465a:
        piVar14 = *(int32_t **)(iVar7 + 0x2170);
        if (piVar14 == (int32_t *)0x0) {
            piVar14 = **(int32_t ***)(int64_t *)(iVar7 + 0x2158);
            *(int32_t **)(iVar7 + 0x2170) = piVar14;
        }
    }
    if ((*(int64_t *)(iVar7 + 0x1600) == 0) ||
       (piVar20 = *(int32_t **)(*(int64_t *)(iVar7 + 0x1600) + 0x48), piVar20 == (int32_t *)0x0)) {
        piVar20 = piVar14;
    }
    *(int32_t **)(iVar7 + 0x2168) = piVar20;
    if (*(char *)(iVar7 + 0x2400) == '\0') {
        piVar14 = piVar18;
        if (*(int32_t *)(iVar7 + 0x1654) != 0) {
            if (*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') {
                return;
            }
            if (*(char *)(*(int64_t *)0x180781f28 + 0x121) != '\0') {
                return;
            }
            if (*(char *)(*(int64_t *)0x180781f28 + 0x122) != '\0') {
                return;
            }
            if (*(char *)(*(int64_t *)0x180781f28 + 0x123) != '\0') {
                return;
            }
            if (*(char *)(*(int64_t *)0x180781f28 + 0x124) != '\0') {
                return;
            }
        }
    } else if (piVar18 != (int32_t *)0x0) goto code_r0x0001801146e8;
    piVar18 = piVar14;
    if (piVar14 == (int32_t *)0x0) {
        return;
    }
code_r0x0001801146e8:
    if ((piVar18 != piVar20) && ((*(uint8_t *)(piVar18 + 1) & 0x80) == 0)) {
        *(int32_t **)(iVar7 + 0x2168) = piVar18;
    }
    return;
}

// ============================================================
// Function: FUN_180114730
// Address: 0x180114730
// Size: 811 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1348h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_134ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1350h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1354h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Removing arg arg_15a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2100h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20f8h because it doesn't fit into ProtoModel

int32_t * fcn.180114730(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int32_t **ppiVar1;
    int32_t iVar2;
    int32_t iVar3;
    int16_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int32_t *piVar7;
    int64_t iVar8;
    int32_t **ppiVar9;
    uint32_t uVar10;
    float fVar11;
    float fVar12;
    uint64_t uVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar5 = *(int64_t *)0x180781f28;
    uVar10 = (uint32_t)arg_28h | 1;
    if (arg1 != 0) {
        if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) != 0) &&
           (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) + 0x428) == arg1)) {
            uVar10 = (uint32_t)arg_28h | 0xa1;
        }
        uVar6 = uVar10 | 0x80;
        if ((*(uint32_t *)(arg1 + 0x14) & 0x10200) != 0x10200) {
            uVar6 = uVar10;
        }
        uVar10 = uVar6 | 0x20;
        if ((*(uint32_t *)(arg1 + 0x14) & 0x1000) == 0) {
            uVar10 = uVar6;
        }
    }
    ppiVar9 = *(int32_t ***)(*(int64_t *)0x180781f28 + 0x2158);
    ppiVar1 = ppiVar9 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
    do {
        if (ppiVar9 == ppiVar1) {
            var_8h = func_0x00018046d050(0x168);
            if (var_8h == 0) {
                piVar7 = (int32_t *)0x0;
            } else {
                piVar7 = (int32_t *)func_0x0001800f42c0(var_8h);
            }
            *piVar7 = (int32_t)arg2;
            piVar7[0x20] = *(int32_t *)(iVar5 + 0x2150);
            iVar2 = *(int32_t *)arg3;
            iVar3 = *(int32_t *)(arg3 + 4);
            piVar7[0x24] = iVar2;
            piVar7[0x25] = iVar3;
            piVar7[2] = iVar2;
            piVar7[3] = iVar3;
            iVar2 = *(int32_t *)arg4;
            iVar3 = *(int32_t *)(arg4 + 4);
            piVar7[0x26] = iVar2;
            piVar7[0x27] = iVar3;
            piVar7[4] = iVar2;
            piVar7[5] = iVar3;
            piVar7[1] = uVar10;
            var_8h = (int64_t)piVar7;
            func_0x000180114a60(piVar7);
            func_0x00018011ec70(iVar5 + 0x2150, &var_8h);
            *(int32_t *)(iVar5 + 0x21c0) = *(int32_t *)(iVar5 + 0x21c0) + 1;
            *(int32_t *)(iVar5 + 0x21c8) = *(int32_t *)(iVar5 + 0x21c8) + 1;
            piVar7[0x22] = *(int32_t *)(iVar5 + 0x21c8);
            fVar14 = *(float *)(iVar5 + 0x1348);
            if ((float)piVar7[2] <= *(float *)(iVar5 + 0x1348)) {
                fVar14 = (float)piVar7[2];
            }
            *(float *)(iVar5 + 0x1348) = fVar14;
            fVar14 = *(float *)(iVar5 + 0x134c);
            if ((float)piVar7[3] <= *(float *)(iVar5 + 0x134c)) {
                fVar14 = (float)piVar7[3];
            }
            *(float *)(iVar5 + 0x134c) = fVar14;
            fVar14 = *(float *)(iVar5 + 0x1350);
            if (*(float *)(iVar5 + 0x1350) <= (float)piVar7[4] + (float)piVar7[2]) {
                fVar14 = (float)piVar7[4] + (float)piVar7[2];
            }
            *(float *)(iVar5 + 0x1350) = fVar14;
            fVar14 = *(float *)(iVar5 + 0x1354);
            if (*(float *)(iVar5 + 0x1354) <= (float)piVar7[5] + (float)piVar7[3]) {
                fVar14 = (float)piVar7[5] + (float)piVar7[3];
            }
            *(float *)(iVar5 + 0x1354) = fVar14;
            iVar4 = *(int16_t *)((int64_t)piVar7 + 0xaa);
            if ((iVar4 < 0) || (*(int32_t *)(*(int64_t *)0x180781f28 + 0xd60) <= (int32_t)iVar4)) {
                iVar8 = *(int64_t *)0x180781f28 + 0x2180;
            } else {
                iVar8 = (int64_t)iVar4 * 0x30 + *(int64_t *)(*(int64_t *)0x180781f28 + 0xd68);
            }
            piVar7[0xc] = *(int32_t *)(iVar8 + 0x20);
code_r0x0001801149c2:
            *(int64_t *)(piVar7 + 0x1e) = arg1;
            piVar7[0x21] = *(int32_t *)(iVar5 + 4);
            piVar7[8] = (int32_t)((float)piVar7[0x52] + (float)piVar7[2]);
            piVar7[9] = (int32_t)((float)piVar7[0x53] + (float)piVar7[3]);
            fVar11 = ((float)piVar7[5] - (float)piVar7[0x53]) - (float)piVar7[0x55];
            fVar14 = 0.0;
            if (0.0 <= fVar11) {
                fVar14 = fVar11;
            }
            fVar12 = ((float)piVar7[4] - (float)piVar7[0x52]) - (float)piVar7[0x54];
            fVar11 = 0.0;
            if (0.0 <= fVar12) {
                fVar11 = fVar12;
            }
            piVar7[10] = (int32_t)fVar11;
            piVar7[0xb] = (int32_t)fVar14;
            if (arg1 != 0) {
                *(undefined *)(arg1 + 0x108) = 1;
            }
            return piVar7;
        }
        piVar7 = *ppiVar9;
        if (*piVar7 == (int32_t)arg2) {
            fVar14 = (float)piVar7[2];
            fVar11 = (float)piVar7[4];
            if ((*(char *)((int64_t)piVar7 + 0x71) == '\0') || (*piVar7 == 0x11111111)) {
                uVar13 = *(uint64_t *)arg3;
                *(uint64_t *)(piVar7 + 2) = uVar13;
            } else {
                uVar13 = (uint64_t)(uint32_t)fVar14;
            }
            if ((*(char *)((int64_t)piVar7 + 0x72) == '\0') || (*piVar7 == 0x11111111)) {
                *(undefined8 *)(piVar7 + 4) = *(undefined8 *)arg4;
            }
            piVar7[1] = piVar7[1] & 0x3000;
            piVar7[1] = piVar7[1] | uVar10;
            if ((((fVar14 != (float)uVar13) || ((float)piVar7[3] != (float)piVar7[3])) || (fVar11 != (float)piVar7[4]))
               || ((float)piVar7[5] != (float)piVar7[5])) {
                func_0x000180114a60(piVar7);
            }
            goto code_r0x0001801149c2;
        }
        ppiVar9 = ppiVar9 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_180114a60
// Address: 0x180114a60
// Size: 43 bytes
// ============================================================
void fcn.180114a60(int64_t arg1)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    undefined2 uVar8;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int32_t iVar9;
    
    iVar3 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd60);
    if (iVar3 < 2) {
        *(int16_t *)(arg1 + 0xaa) = (int16_t)iVar3 + -1;
        return;
    }
    fVar16 = 0.001;
    fVar1 = *(float *)(arg1 + 0xc);
    fVar18 = fVar1 + *(float *)(arg1 + 0x14);
    fVar2 = *(float *)(arg1 + 8);
    fVar17 = fVar2 + *(float *)(arg1 + 0x10);
    fVar19 = (fVar18 - fVar1) * (fVar17 - fVar2) * 0.5;
    iVar7 = 0;
    iVar9 = 0;
    if (fVar19 <= 1.0) {
        fVar19 = 1.0;
        iVar7 = 0;
    }
    do {
        uVar8 = (undefined2)iVar9;
        if (fVar19 <= fVar16) break;
        iVar6 = (int64_t)iVar7;
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd68);
        fVar10 = *(float *)(iVar4 + iVar6 * 0x30);
        fVar11 = *(float *)(iVar4 + 4 + iVar6 * 0x30);
        fVar13 = fVar10 + *(float *)(iVar4 + 8 + iVar6 * 0x30);
        fVar12 = fVar11 + *(float *)(iVar4 + 0xc + iVar6 * 0x30);
        if ((((fVar10 <= fVar2) && (fVar11 <= fVar1)) && (fVar17 <= fVar13)) && (fVar18 <= fVar12)) {
            *(int16_t *)(arg1 + 0xaa) = (int16_t)iVar7;
            return;
        }
        fVar15 = fVar11;
        if ((fVar11 <= fVar1) && (fVar15 = fVar12, fVar1 <= fVar12)) {
            fVar15 = fVar1;
        }
        fVar14 = fVar10;
        if ((fVar10 <= fVar2) && (fVar14 = fVar13, fVar2 <= fVar13)) {
            fVar14 = fVar2;
        }
        if ((fVar11 <= fVar18) && (fVar11 = fVar12, fVar18 <= fVar12)) {
            fVar11 = fVar18;
        }
        if ((fVar10 <= fVar17) && (fVar10 = fVar13, fVar17 <= fVar13)) {
            fVar10 = fVar17;
        }
        fVar10 = (fVar10 - fVar14) * (fVar11 - fVar15);
        iVar5 = iVar7;
        if (fVar10 < fVar16) {
            iVar5 = iVar9;
            fVar10 = fVar16;
        }
        fVar16 = fVar10;
        iVar7 = iVar7 + 1;
        uVar8 = (undefined2)iVar5;
        iVar9 = iVar5;
    } while (iVar7 < iVar3);
    *(undefined2 *)(arg1 + 0xaa) = uVar8;
    return;
}

// ============================================================
// Function: FUN_180114a8b
// Address: 0x180114a8b
// Size: 370 bytes
// ============================================================
void fcn.180114a60(int64_t arg1)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    undefined2 uVar8;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int32_t iVar9;
    
    iVar3 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd60);
    if (iVar3 < 2) {
        *(int16_t *)(arg1 + 0xaa) = (int16_t)iVar3 + -1;
        return;
    }
    fVar16 = 0.001;
    fVar1 = *(float *)(arg1 + 0xc);
    fVar18 = fVar1 + *(float *)(arg1 + 0x14);
    fVar2 = *(float *)(arg1 + 8);
    fVar17 = fVar2 + *(float *)(arg1 + 0x10);
    fVar19 = (fVar18 - fVar1) * (fVar17 - fVar2) * 0.5;
    iVar7 = 0;
    iVar9 = 0;
    if (fVar19 <= 1.0) {
        fVar19 = 1.0;
        iVar7 = 0;
    }
    do {
        uVar8 = (undefined2)iVar9;
        if (fVar19 <= fVar16) break;
        iVar6 = (int64_t)iVar7;
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd68);
        fVar10 = *(float *)(iVar4 + iVar6 * 0x30);
        fVar11 = *(float *)(iVar4 + 4 + iVar6 * 0x30);
        fVar13 = fVar10 + *(float *)(iVar4 + 8 + iVar6 * 0x30);
        fVar12 = fVar11 + *(float *)(iVar4 + 0xc + iVar6 * 0x30);
        if ((((fVar10 <= fVar2) && (fVar11 <= fVar1)) && (fVar17 <= fVar13)) && (fVar18 <= fVar12)) {
            *(int16_t *)(arg1 + 0xaa) = (int16_t)iVar7;
            return;
        }
        fVar15 = fVar11;
        if ((fVar11 <= fVar1) && (fVar15 = fVar12, fVar1 <= fVar12)) {
            fVar15 = fVar1;
        }
        fVar14 = fVar10;
        if ((fVar10 <= fVar2) && (fVar14 = fVar13, fVar2 <= fVar13)) {
            fVar14 = fVar2;
        }
        if ((fVar11 <= fVar18) && (fVar11 = fVar12, fVar18 <= fVar12)) {
            fVar11 = fVar18;
        }
        if ((fVar10 <= fVar17) && (fVar10 = fVar13, fVar17 <= fVar13)) {
            fVar10 = fVar17;
        }
        fVar10 = (fVar10 - fVar14) * (fVar11 - fVar15);
        iVar5 = iVar7;
        if (fVar10 < fVar16) {
            iVar5 = iVar9;
            fVar10 = fVar16;
        }
        fVar16 = fVar10;
        iVar7 = iVar7 + 1;
        uVar8 = (undefined2)iVar5;
        iVar9 = iVar5;
    } while (iVar7 < iVar3);
    *(undefined2 *)(arg1 + 0xaa) = uVar8;
    return;
}

// ============================================================
// Function: FUN_180114bfd
// Address: 0x180114bfd
// Size: 10 bytes
// ============================================================
void fcn.180114a60(int64_t arg1)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    undefined2 uVar8;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int32_t iVar9;
    
    iVar3 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd60);
    if (iVar3 < 2) {
        *(int16_t *)(arg1 + 0xaa) = (int16_t)iVar3 + -1;
        return;
    }
    fVar16 = 0.001;
    fVar1 = *(float *)(arg1 + 0xc);
    fVar18 = fVar1 + *(float *)(arg1 + 0x14);
    fVar2 = *(float *)(arg1 + 8);
    fVar17 = fVar2 + *(float *)(arg1 + 0x10);
    fVar19 = (fVar18 - fVar1) * (fVar17 - fVar2) * 0.5;
    iVar7 = 0;
    iVar9 = 0;
    if (fVar19 <= 1.0) {
        fVar19 = 1.0;
        iVar7 = 0;
    }
    do {
        uVar8 = (undefined2)iVar9;
        if (fVar19 <= fVar16) break;
        iVar6 = (int64_t)iVar7;
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd68);
        fVar10 = *(float *)(iVar4 + iVar6 * 0x30);
        fVar11 = *(float *)(iVar4 + 4 + iVar6 * 0x30);
        fVar13 = fVar10 + *(float *)(iVar4 + 8 + iVar6 * 0x30);
        fVar12 = fVar11 + *(float *)(iVar4 + 0xc + iVar6 * 0x30);
        if ((((fVar10 <= fVar2) && (fVar11 <= fVar1)) && (fVar17 <= fVar13)) && (fVar18 <= fVar12)) {
            *(int16_t *)(arg1 + 0xaa) = (int16_t)iVar7;
            return;
        }
        fVar15 = fVar11;
        if ((fVar11 <= fVar1) && (fVar15 = fVar12, fVar1 <= fVar12)) {
            fVar15 = fVar1;
        }
        fVar14 = fVar10;
        if ((fVar10 <= fVar2) && (fVar14 = fVar13, fVar2 <= fVar13)) {
            fVar14 = fVar2;
        }
        if ((fVar11 <= fVar18) && (fVar11 = fVar12, fVar18 <= fVar12)) {
            fVar11 = fVar18;
        }
        if ((fVar10 <= fVar17) && (fVar10 = fVar13, fVar17 <= fVar13)) {
            fVar10 = fVar17;
        }
        fVar10 = (fVar10 - fVar14) * (fVar11 - fVar15);
        iVar5 = iVar7;
        if (fVar10 < fVar16) {
            iVar5 = iVar9;
            fVar10 = fVar16;
        }
        fVar16 = fVar10;
        iVar7 = iVar7 + 1;
        uVar8 = (undefined2)iVar5;
        iVar9 = iVar5;
    } while (iVar7 < iVar3);
    *(undefined2 *)(arg1 + 0xaa) = uVar8;
    return;
}

// ============================================================
// Function: FUN_180114c50
// Address: 0x180114c50
// Size: 321 bytes
// ============================================================
int64_t fcn.180114c50(int64_t param_1)
{
    fcn.1801161f0(param_1, 0);
    *(undefined8 *)(param_1 + 0xf8) = 0;
    *(undefined8 *)(param_1 + 0x100) = 0;
    *(undefined8 *)(param_1 + 0x108) = 0;
    *(undefined8 *)(param_1 + 0x110) = 0;
    *(undefined8 *)(param_1 + 0x118) = 0;
    *(undefined8 *)(param_1 + 0x120) = 0;
    *(undefined8 *)(param_1 + 0x128) = 0;
    *(undefined8 *)(param_1 + 0x130) = 0;
    *(undefined8 *)(param_1 + 0x138) = 0;
    *(undefined8 *)(param_1 + 0x140) = 0;
    *(undefined4 *)(param_1 + 0xe0) = 0;
    *(undefined8 *)(param_1 + 0xe8) = 0;
    *(undefined4 *)(param_1 + 0xf0) = 0xffffffff;
    *(undefined4 *)(param_1 + 0xf4) = 0;
    *(undefined4 *)(param_1 + 0xf8) = 0x7f7fffff;
    *(undefined4 *)(param_1 + 0xfc) = 0x7f7fffff;
    *(undefined4 *)(param_1 + 0x100) = 0xff7fffff;
    *(undefined4 *)(param_1 + 0x104) = 0xff7fffff;
    *(undefined4 *)(param_1 + 0x108) = 0x7f7fffff;
    *(undefined4 *)(param_1 + 0x10c) = 0x7f7fffff;
    *(undefined4 *)(param_1 + 0x110) = 0xff7fffff;
    *(undefined4 *)(param_1 + 0x114) = 0xff7fffff;
    *(undefined4 *)(param_1 + 0x118) = 0x7f7fffff;
    *(undefined4 *)(param_1 + 0x11c) = 0x7f7fffff;
    *(undefined4 *)(param_1 + 0x120) = 0xff7fffff;
    *(undefined4 *)(param_1 + 0x124) = 0xff7fffff;
    *(undefined4 *)(param_1 + 0x128) = 0x7f7fffff;
    *(undefined4 *)(param_1 + 300) = 0x7f7fffff;
    *(undefined4 *)(param_1 + 0x130) = 0xff7fffff;
    *(undefined4 *)(param_1 + 0x134) = 0xff7fffff;
    *(undefined4 *)(param_1 + 0x138) = 0x7f7fffff;
    *(undefined4 *)(param_1 + 0x13c) = 0x7f7fffff;
    *(undefined4 *)(param_1 + 0x140) = 0xff7fffff;
    *(undefined4 *)(param_1 + 0x144) = 0xff7fffff;
    return param_1;
}

// ============================================================
// Function: FUN_180114da0
// Address: 0x180114da0
// Size: 264 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180114e92: Changing call to branch
// WARNING: Possible PIC construction at 0x000180114ee3: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180114ee8)
// WARNING: Removing unreachable block (ram,0x000180114f15)
// WARNING: Removing unreachable block (ram,0x000180114f20)
// WARNING: Removing unreachable block (ram,0x000180114f2d)
// WARNING: Removing unreachable block (ram,0x000180114f3a)
// WARNING: Removing unreachable block (ram,0x000180114f44)
// WARNING: Removing unreachable block (ram,0x000180114f5a)
// WARNING: Removing unreachable block (ram,0x000180114f63)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_2908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1588h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1580h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.180114da0(int64_t arg1, int64_t arg_30h)
{
    int64_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int32_t *piVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    int32_t iVar11;
    undefined4 *puVar12;
    uint32_t *puVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint64_t unaff_RBX;
    int32_t iVar16;
    int64_t unaff_RBP;
    int32_t *unaff_RSI;
    int32_t *piVar17;
    uint64_t unaff_RDI;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    uint64_t in_R9;
    uint64_t uVar21;
    int64_t iVar22;
    uint64_t uVar23;
    undefined8 unaff_R12;
    uint32_t uVar24;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint64_t uVar25;
    undefined8 unaff_R15;
    uint64_t uVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 auStack_50 [2];
    char acStack_40 [32];
    
    uVar23 = *(uint64_t *)0x180781f28;
    piVar17 = (int32_t *)(arg1 + 0x28e8);
    if ((*(uint8_t *)(arg1 + 0x30) & 0x80) == 0) {
        if ((*piVar17 < 1) && (*(int32_t *)(arg1 + 0x28f8) < 1)) {
            return;
        }
        uVar10 = 0;
        uVar20 = uVar10;
        if (*(int64_t *)(*(uint64_t *)0x180781f28 + 0x2958) != 0) {
            uVar20 = *(int64_t *)(*(uint64_t *)0x180781f28 + 0x2958) + 4;
        }
        while (uVar20 != 0) {
            iVar11 = *(int32_t *)(uVar20 - 4);
            *(undefined4 *)(uVar20 + 0x14) = 0;
            uVar19 = (int64_t)iVar11 + uVar20;
            uVar20 = uVar10;
            if (uVar19 != *(int64_t *)(uVar23 + 0x2958) + 4 + (int64_t)*(int32_t *)(uVar23 + 0x2950)) {
                uVar20 = uVar19;
            }
        }
        in_R9 = 0;
        piVar17 = unaff_RSI;
        arg1 = unaff_RBP;
        if (0 < *(int32_t *)(uVar23 + 0x1580)) {
            do {
                auStack_50[0] = 0x180114e46;
                func_0x000180115d50();
                uVar14 = (int32_t)uVar10 + 1;
                uVar10 = (uint64_t)uVar14;
            } while ((int32_t)uVar14 < *(int32_t *)(uVar23 + 0x1580));
        }
        iVar11 = 0;
    } else {
        unaff_RBX = 0;
        if ((*(char *)(arg1 + 0x80) != '\0') && (unaff_RDI = unaff_RBX, 0 < *piVar17)) {
            do {
                piVar8 = *(int32_t **)(*(int64_t *)(arg1 + 0x28f0) + 8 + (int64_t)(int32_t)unaff_RDI * 0x10);
                if ((piVar8 != (int32_t *)0x0) && ((*(int64_t *)(piVar8 + 6) == 0 && (*(int64_t *)(piVar8 + 8) != 0))))
                {
                    iVar11 = *piVar8;
                    *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
                    auStack_50[0] = 0x180114e97;
                    goto code_r0x00018011c860;
                }
                uVar14 = (int32_t)unaff_RDI + 1;
                unaff_RDI = (uint64_t)uVar14;
            } while ((int32_t)uVar14 < *piVar17);
        }
        if (*(char *)(arg1 + 0x2918) == '\0') {
            piVar17 = *(int32_t **)(arg1 + 0x2900);
            piVar8 = piVar17 + (int64_t)*(int32_t *)(arg1 + 0x28f8) * 0x10;
            for (; piVar17 != piVar8; piVar17 = piVar17 + 0x10) {
                if (*piVar17 == 2) {
                    if (*(int64_t *)(piVar17 + 0xc) == 0) {
                        if (*(int64_t *)(piVar17 + 0xe) != 0) {
                            auStack_50[0] = 0x180114fa9;
                            func_0x000180115ea0(arg1);
                        }
                    } else {
                        auStack_50[0] = 0x180114f96;
                        func_0x000180115d50();
                    }
                }
            }
            return;
        }
        auStack_50[0] = 0x180114eb2;
        func_0x000180112af0();
        unaff_RDI = *(uint64_t *)0x180781f28;
        if (0 < *(int32_t *)(*(uint64_t *)0x180781f28 + 0x1580)) {
            do {
                auStack_50[0] = 0x180114ed7;
                func_0x000180115d50();
                uVar14 = (int32_t)unaff_RBX + 1;
                unaff_RBX = (uint64_t)uVar14;
            } while ((int32_t)uVar14 < *(int32_t *)(unaff_RDI + 0x1580));
        }
        iVar11 = 0;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
        auStack_50[0] = 0x180114ee8;
    }
code_r0x00018011c860:
    uVar23 = *(uint64_t *)0x180781f28;
    *(int32_t *)((int64_t)*(undefined **)0x20 + 8) = iVar11;
    *(uint64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
    *(int64_t *)((int64_t)*(undefined **)0x20 + -0x10) = arg1;
    *(int32_t **)((int64_t)*(undefined **)0x20 + -0x18) = piVar17;
    *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x20) = unaff_RDI;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x28) = unaff_R12;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = unaff_R13;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x38) = unaff_R14;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = unaff_R15;
    *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x88) = *(uint64_t *)0x180781f28;
    piVar17 = (int32_t *)(*(uint64_t *)0x180781f28 + 0x28e8);
    *(int32_t **)((int64_t)*(undefined **)0x20 + -0x68) = piVar17;
    puVar7 = (undefined4 *)0x0;
    if (iVar11 == 0) {
        uVar14 = 0;
        *(undefined4 *)((int64_t)*(undefined **)0x20 + 0x18) = 0;
        puVar13 = (uint32_t *)0xd8;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x80) = 0;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x70) = 0;
        uVar20 = *(uint64_t *)0x180781f28;
        uVar24 = uVar14;
    } else {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011c89f;
        puVar7 = (undefined4 *)func_0x0001800f60f0(piVar17, iVar11);
        *(undefined4 **)((int64_t)*(undefined **)0x20 + -0x80) = puVar7;
        if (puVar7 == (undefined4 *)0x0) {
            return;
        }
        *(undefined4 **)((int64_t)*(undefined **)0x20 + -0x70) = puVar7;
        puVar13 = puVar7 + 0x36;
        uVar24 = *puVar13;
        uVar14 = (int32_t)(uVar24 << 0x1d) >> 0x1d;
        *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x18) = uVar14;
        uVar20 = *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x88);
        uVar24 = (int32_t)(uVar24 << 0x1a) >> 0x1d;
    }
    uVar19 = 0;
    uVar21 = in_R9 & 0xffffffffffffff00;
    *(int32_t *)((int64_t)*(undefined **)0x20 + 0x10) = (int32_t)uVar21;
    *(int32_t **)((int64_t)*(undefined **)0x20 + -0x78) = piVar17;
    *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x20) = uVar24;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x60) = 0;
    iVar16 = 0;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x58) = 0;
    uVar10 = uVar19;
    if (0 < *piVar17) {
        iVar11 = *(int32_t *)((int64_t)*(undefined **)0x20 + 8);
        uVar18 = uVar19;
        uVar25 = uVar19;
        uVar26 = uVar19;
        do {
            piVar17 = *(int32_t **)(*(int64_t *)(uVar23 + 0x28f0) + 8 + (int64_t)(int32_t)uVar26 * 0x10);
            uVar10 = uVar25;
            if (piVar17 != (int32_t *)0x0) {
                if (iVar11 == 0) {
code_r0x00018011c9a9:
                    uVar14 = (uint32_t)uVar21 & 0xff;
                    if ((piVar17[4] & 0x800U) != 0) {
                        uVar14 = 1;
                    }
                    *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x10) = uVar14;
                    if (iVar11 != 0) {
                        puVar9 = *(undefined4 **)(uVar20 + 0x2900);
                        puVar12 = puVar9 + (int64_t)*(int32_t *)(uVar20 + 0x28f8) * 0x10;
                        for (; puVar9 != puVar12; puVar9 = puVar9 + 0x10) {
                            if (*(int32_t **)(puVar9 + 4) == piVar17) {
                                *puVar9 = 0;
                            }
                        }
                    }
                    if (puVar7 != (undefined4 *)0x0) {
                        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca02;
                        func_0x0001801167e0(puVar7, piVar17);
                        uVar2 = *puVar7;
                        iVar16 = *piVar17;
                        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca0b;
                        func_0x00018011d570(iVar16, uVar2);
                    }
                    iVar15 = (int32_t)uVar18;
                    iVar16 = (int32_t)uVar19;
                    if (iVar16 == iVar15) {
                        if (iVar15 == 0) {
                            uVar14 = 8;
                        } else {
                            uVar14 = iVar15 / 2 + iVar15;
                        }
                        uVar24 = iVar16 + 1U;
                        if ((int32_t)(iVar16 + 1U) < (int32_t)uVar14) {
                            uVar24 = uVar14;
                        }
                        if (iVar15 < (int32_t)uVar24) {
                            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca3b;
                            uVar10 = func_0x00018046d050((int64_t)(int32_t)uVar24 << 3);
                            if (uVar25 != 0) {
                                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca55;
                                func_0x000180498030(uVar10, uVar25, (int64_t)iVar16 << 3);
                                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca5d;
                                func_0x000180460d90(uVar25);
                            }
                            *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x58) = uVar10;
                            uVar18 = (uint64_t)uVar24;
                            *(uint32_t *)((int64_t)*(undefined **)0x20 + -0x5c) = uVar24;
                        }
                        puVar7 = *(undefined4 **)((int64_t)*(undefined **)0x20 + -0x80);
                    }
                    *(int32_t **)(uVar10 + (int64_t)iVar16 * 8) = piVar17;
                    uVar19 = (uint64_t)(iVar16 + 1U);
                    *(uint32_t *)((int64_t)*(undefined **)0x20 + -0x60) = iVar16 + 1U;
                } else if ((*piVar17 != iVar11) && (piVar8 = piVar17, *(int64_t *)(piVar17 + 6) != 0)) {
                    do {
                        piVar8 = *(int32_t **)(piVar8 + 6);
                    } while (*(int64_t *)(piVar8 + 6) != 0);
                    if (*piVar8 == iVar11) goto code_r0x00018011c9a9;
                }
            }
            iVar16 = (int32_t)uVar19;
            uVar14 = (int32_t)uVar26 + 1;
            uVar26 = (uint64_t)uVar14;
            uVar20 = *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x88);
            uVar21 = (uint64_t)*(uint32_t *)((int64_t)*(undefined **)0x20 + 0x10);
            uVar25 = uVar10;
        } while ((int32_t)uVar14 < **(int32_t **)((int64_t)*(undefined **)0x20 + -0x68));
        puVar13 = (uint32_t *)(*(int64_t *)((int64_t)*(undefined **)0x20 + -0x70) + 0xd8);
        uVar14 = *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x18);
        uVar24 = *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x20);
        iVar11 = *(int32_t *)((int64_t)*(undefined **)0x20 + 8);
    }
    uVar23 = 0;
    if (puVar7 != (undefined4 *)0x0) {
        *puVar13 = (uVar24 * 8 ^ uVar14) & 0xffffffc7 ^ (uVar14 ^ *puVar13) & 0xffffffc0 ^ uVar24 * 8;
    }
    iVar22 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x88);
    uVar20 = uVar23;
    if (*(int64_t *)(iVar22 + 0x2958) != 0) {
        uVar20 = *(int64_t *)(iVar22 + 0x2958) + 4;
    }
    do {
        if (uVar20 == 0) {
            if ((1 < iVar16) && (1 < (uint64_t)(int64_t)iVar16)) {
                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cb86;
                func_0x00018046f0d0(uVar10, (int64_t)iVar16, 8, 0x180115340);
                iVar22 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x88);
            }
            iVar15 = 0;
            if (0 < iVar16) {
                do {
                    iVar6 = 0;
                    iVar3 = *(int64_t *)(uVar10 + (int64_t)iVar15 * 8);
                    if (*(int64_t *)(iVar3 + 0x98) != 0) {
                        *(undefined8 *)(*(int64_t *)(iVar3 + 0x98) + 0x4c8) = 0;
                    }
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    if (iVar4 != 0) {
                        for (; iVar6 < 2; iVar6 = iVar6 + 1) {
                            iVar1 = (int64_t)iVar6 * 8 + 0x20;
                            if (*(int64_t *)(iVar4 + iVar1) == iVar3) {
                                *(undefined8 *)(iVar1 + *(int64_t *)(iVar3 + 0x18)) = 0;
                            }
                        }
                    }
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cbf3;
                    func_0x0001801152b0(iVar22, iVar3);
                    iVar15 = iVar15 + 1;
                    iVar22 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x88);
                } while (iVar15 < iVar16);
            }
            if (iVar11 == 0) {
                puVar5 = *(undefined8 **)((int64_t)*(undefined **)0x20 + -0x68);
                if (puVar5[1] != 0) {
                    *puVar5 = 0;
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cc25;
                    func_0x000180460d90();
                    puVar5[1] = 0;
                }
                if (puVar5[3] != 0) {
                    puVar5[2] = 0;
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cc42;
                    func_0x000180460d90();
                    puVar5[3] = 0;
                }
            } else if (*(char *)((int64_t)*(undefined **)0x20 + 0x10) != '\0') {
                iVar22 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x80);
                *(int64_t *)(iVar22 + 0xa8) = iVar22;
                *(uint32_t *)(iVar22 + 8) = *(uint32_t *)(iVar22 + 8) | 0x800;
                *(uint32_t *)(iVar22 + 0x10) =
                     *(uint32_t *)(iVar22 + 0xc) | *(uint32_t *)(iVar22 + 4) | *(uint32_t *)(iVar22 + 8);
            }
            if (uVar10 != 0) {
                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cc82;
                func_0x000180460d90(uVar10);
            }
            return;
        }
        if ((*(int32_t *)(uVar20 + 0x14) != 0) && (uVar19 = uVar23, 0 < iVar16)) {
            do {
                if (**(int32_t **)(uVar10 + (int64_t)(int32_t)uVar19 * 8) == *(int32_t *)(uVar20 + 0x14)) {
                    *(int32_t *)(uVar20 + 0x14) = iVar11;
                    break;
                }
                uVar14 = (int32_t)uVar19 + 1;
                uVar19 = (uint64_t)uVar14;
            } while ((int32_t)uVar14 < iVar16);
        }
        uVar19 = (int64_t)*(int32_t *)(uVar20 - 4) + uVar20;
        uVar20 = uVar23;
        if (uVar19 != *(int64_t *)(iVar22 + 0x2958) + 4 + (int64_t)*(int32_t *)(iVar22 + 0x2950)) {
            uVar20 = uVar19;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180114ea8
// Address: 0x180114ea8
// Size: 196 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180114e92: Changing call to branch
// WARNING: Possible PIC construction at 0x000180114ee3: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180114ee8)
// WARNING: Removing unreachable block (ram,0x000180114f15)
// WARNING: Removing unreachable block (ram,0x000180114f20)
// WARNING: Removing unreachable block (ram,0x000180114f2d)
// WARNING: Removing unreachable block (ram,0x000180114f3a)
// WARNING: Removing unreachable block (ram,0x000180114f44)
// WARNING: Removing unreachable block (ram,0x000180114f5a)
// WARNING: Removing unreachable block (ram,0x000180114f63)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_2908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1588h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1580h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.180114da0(int64_t arg1, int64_t arg_30h)
{
    int64_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int32_t *piVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    int32_t iVar11;
    undefined4 *puVar12;
    uint32_t *puVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint64_t unaff_RBX;
    int32_t iVar16;
    int64_t unaff_RBP;
    int32_t *unaff_RSI;
    int32_t *piVar17;
    uint64_t unaff_RDI;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    uint64_t in_R9;
    uint64_t uVar21;
    int64_t iVar22;
    uint64_t uVar23;
    undefined8 unaff_R12;
    uint32_t uVar24;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint64_t uVar25;
    undefined8 unaff_R15;
    uint64_t uVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 auStack_50 [2];
    char acStack_40 [32];
    
    uVar23 = *(uint64_t *)0x180781f28;
    piVar17 = (int32_t *)(arg1 + 0x28e8);
    if ((*(uint8_t *)(arg1 + 0x30) & 0x80) == 0) {
        if ((*piVar17 < 1) && (*(int32_t *)(arg1 + 0x28f8) < 1)) {
            return;
        }
        uVar10 = 0;
        uVar20 = uVar10;
        if (*(int64_t *)(*(uint64_t *)0x180781f28 + 0x2958) != 0) {
            uVar20 = *(int64_t *)(*(uint64_t *)0x180781f28 + 0x2958) + 4;
        }
        while (uVar20 != 0) {
            iVar11 = *(int32_t *)(uVar20 - 4);
            *(undefined4 *)(uVar20 + 0x14) = 0;
            uVar19 = (int64_t)iVar11 + uVar20;
            uVar20 = uVar10;
            if (uVar19 != *(int64_t *)(uVar23 + 0x2958) + 4 + (int64_t)*(int32_t *)(uVar23 + 0x2950)) {
                uVar20 = uVar19;
            }
        }
        in_R9 = 0;
        piVar17 = unaff_RSI;
        arg1 = unaff_RBP;
        if (0 < *(int32_t *)(uVar23 + 0x1580)) {
            do {
                auStack_50[0] = 0x180114e46;
                func_0x000180115d50();
                uVar14 = (int32_t)uVar10 + 1;
                uVar10 = (uint64_t)uVar14;
            } while ((int32_t)uVar14 < *(int32_t *)(uVar23 + 0x1580));
        }
        iVar11 = 0;
    } else {
        unaff_RBX = 0;
        if ((*(char *)(arg1 + 0x80) != '\0') && (unaff_RDI = unaff_RBX, 0 < *piVar17)) {
            do {
                piVar8 = *(int32_t **)(*(int64_t *)(arg1 + 0x28f0) + 8 + (int64_t)(int32_t)unaff_RDI * 0x10);
                if ((piVar8 != (int32_t *)0x0) && ((*(int64_t *)(piVar8 + 6) == 0 && (*(int64_t *)(piVar8 + 8) != 0))))
                {
                    iVar11 = *piVar8;
                    *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
                    auStack_50[0] = 0x180114e97;
                    goto code_r0x00018011c860;
                }
                uVar14 = (int32_t)unaff_RDI + 1;
                unaff_RDI = (uint64_t)uVar14;
            } while ((int32_t)uVar14 < *piVar17);
        }
        if (*(char *)(arg1 + 0x2918) == '\0') {
            piVar17 = *(int32_t **)(arg1 + 0x2900);
            piVar8 = piVar17 + (int64_t)*(int32_t *)(arg1 + 0x28f8) * 0x10;
            for (; piVar17 != piVar8; piVar17 = piVar17 + 0x10) {
                if (*piVar17 == 2) {
                    if (*(int64_t *)(piVar17 + 0xc) == 0) {
                        if (*(int64_t *)(piVar17 + 0xe) != 0) {
                            auStack_50[0] = 0x180114fa9;
                            func_0x000180115ea0(arg1);
                        }
                    } else {
                        auStack_50[0] = 0x180114f96;
                        func_0x000180115d50();
                    }
                }
            }
            return;
        }
        auStack_50[0] = 0x180114eb2;
        func_0x000180112af0();
        unaff_RDI = *(uint64_t *)0x180781f28;
        if (0 < *(int32_t *)(*(uint64_t *)0x180781f28 + 0x1580)) {
            do {
                auStack_50[0] = 0x180114ed7;
                func_0x000180115d50();
                uVar14 = (int32_t)unaff_RBX + 1;
                unaff_RBX = (uint64_t)uVar14;
            } while ((int32_t)uVar14 < *(int32_t *)(unaff_RDI + 0x1580));
        }
        iVar11 = 0;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
        auStack_50[0] = 0x180114ee8;
    }
code_r0x00018011c860:
    uVar23 = *(uint64_t *)0x180781f28;
    *(int32_t *)((int64_t)*(undefined **)0x20 + 8) = iVar11;
    *(uint64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
    *(int64_t *)((int64_t)*(undefined **)0x20 + -0x10) = arg1;
    *(int32_t **)((int64_t)*(undefined **)0x20 + -0x18) = piVar17;
    *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x20) = unaff_RDI;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x28) = unaff_R12;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = unaff_R13;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x38) = unaff_R14;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = unaff_R15;
    *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x88) = *(uint64_t *)0x180781f28;
    piVar17 = (int32_t *)(*(uint64_t *)0x180781f28 + 0x28e8);
    *(int32_t **)((int64_t)*(undefined **)0x20 + -0x68) = piVar17;
    puVar7 = (undefined4 *)0x0;
    if (iVar11 == 0) {
        uVar14 = 0;
        *(undefined4 *)((int64_t)*(undefined **)0x20 + 0x18) = 0;
        puVar13 = (uint32_t *)0xd8;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x80) = 0;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x70) = 0;
        uVar20 = *(uint64_t *)0x180781f28;
        uVar24 = uVar14;
    } else {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011c89f;
        puVar7 = (undefined4 *)func_0x0001800f60f0(piVar17, iVar11);
        *(undefined4 **)((int64_t)*(undefined **)0x20 + -0x80) = puVar7;
        if (puVar7 == (undefined4 *)0x0) {
            return;
        }
        *(undefined4 **)((int64_t)*(undefined **)0x20 + -0x70) = puVar7;
        puVar13 = puVar7 + 0x36;
        uVar24 = *puVar13;
        uVar14 = (int32_t)(uVar24 << 0x1d) >> 0x1d;
        *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x18) = uVar14;
        uVar20 = *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x88);
        uVar24 = (int32_t)(uVar24 << 0x1a) >> 0x1d;
    }
    uVar19 = 0;
    uVar21 = in_R9 & 0xffffffffffffff00;
    *(int32_t *)((int64_t)*(undefined **)0x20 + 0x10) = (int32_t)uVar21;
    *(int32_t **)((int64_t)*(undefined **)0x20 + -0x78) = piVar17;
    *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x20) = uVar24;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x60) = 0;
    iVar16 = 0;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x58) = 0;
    uVar10 = uVar19;
    if (0 < *piVar17) {
        iVar11 = *(int32_t *)((int64_t)*(undefined **)0x20 + 8);
        uVar18 = uVar19;
        uVar25 = uVar19;
        uVar26 = uVar19;
        do {
            piVar17 = *(int32_t **)(*(int64_t *)(uVar23 + 0x28f0) + 8 + (int64_t)(int32_t)uVar26 * 0x10);
            uVar10 = uVar25;
            if (piVar17 != (int32_t *)0x0) {
                if (iVar11 == 0) {
code_r0x00018011c9a9:
                    uVar14 = (uint32_t)uVar21 & 0xff;
                    if ((piVar17[4] & 0x800U) != 0) {
                        uVar14 = 1;
                    }
                    *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x10) = uVar14;
                    if (iVar11 != 0) {
                        puVar9 = *(undefined4 **)(uVar20 + 0x2900);
                        puVar12 = puVar9 + (int64_t)*(int32_t *)(uVar20 + 0x28f8) * 0x10;
                        for (; puVar9 != puVar12; puVar9 = puVar9 + 0x10) {
                            if (*(int32_t **)(puVar9 + 4) == piVar17) {
                                *puVar9 = 0;
                            }
                        }
                    }
                    if (puVar7 != (undefined4 *)0x0) {
                        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca02;
                        func_0x0001801167e0(puVar7, piVar17);
                        uVar2 = *puVar7;
                        iVar16 = *piVar17;
                        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca0b;
                        func_0x00018011d570(iVar16, uVar2);
                    }
                    iVar15 = (int32_t)uVar18;
                    iVar16 = (int32_t)uVar19;
                    if (iVar16 == iVar15) {
                        if (iVar15 == 0) {
                            uVar14 = 8;
                        } else {
                            uVar14 = iVar15 / 2 + iVar15;
                        }
                        uVar24 = iVar16 + 1U;
                        if ((int32_t)(iVar16 + 1U) < (int32_t)uVar14) {
                            uVar24 = uVar14;
                        }
                        if (iVar15 < (int32_t)uVar24) {
                            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca3b;
                            uVar10 = func_0x00018046d050((int64_t)(int32_t)uVar24 << 3);
                            if (uVar25 != 0) {
                                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca55;
                                func_0x000180498030(uVar10, uVar25, (int64_t)iVar16 << 3);
                                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca5d;
                                func_0x000180460d90(uVar25);
                            }
                            *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x58) = uVar10;
                            uVar18 = (uint64_t)uVar24;
                            *(uint32_t *)((int64_t)*(undefined **)0x20 + -0x5c) = uVar24;
                        }
                        puVar7 = *(undefined4 **)((int64_t)*(undefined **)0x20 + -0x80);
                    }
                    *(int32_t **)(uVar10 + (int64_t)iVar16 * 8) = piVar17;
                    uVar19 = (uint64_t)(iVar16 + 1U);
                    *(uint32_t *)((int64_t)*(undefined **)0x20 + -0x60) = iVar16 + 1U;
                } else if ((*piVar17 != iVar11) && (piVar8 = piVar17, *(int64_t *)(piVar17 + 6) != 0)) {
                    do {
                        piVar8 = *(int32_t **)(piVar8 + 6);
                    } while (*(int64_t *)(piVar8 + 6) != 0);
                    if (*piVar8 == iVar11) goto code_r0x00018011c9a9;
                }
            }
            iVar16 = (int32_t)uVar19;
            uVar14 = (int32_t)uVar26 + 1;
            uVar26 = (uint64_t)uVar14;
            uVar20 = *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x88);
            uVar21 = (uint64_t)*(uint32_t *)((int64_t)*(undefined **)0x20 + 0x10);
            uVar25 = uVar10;
        } while ((int32_t)uVar14 < **(int32_t **)((int64_t)*(undefined **)0x20 + -0x68));
        puVar13 = (uint32_t *)(*(int64_t *)((int64_t)*(undefined **)0x20 + -0x70) + 0xd8);
        uVar14 = *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x18);
        uVar24 = *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x20);
        iVar11 = *(int32_t *)((int64_t)*(undefined **)0x20 + 8);
    }
    uVar23 = 0;
    if (puVar7 != (undefined4 *)0x0) {
        *puVar13 = (uVar24 * 8 ^ uVar14) & 0xffffffc7 ^ (uVar14 ^ *puVar13) & 0xffffffc0 ^ uVar24 * 8;
    }
    iVar22 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x88);
    uVar20 = uVar23;
    if (*(int64_t *)(iVar22 + 0x2958) != 0) {
        uVar20 = *(int64_t *)(iVar22 + 0x2958) + 4;
    }
    do {
        if (uVar20 == 0) {
            if ((1 < iVar16) && (1 < (uint64_t)(int64_t)iVar16)) {
                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cb86;
                func_0x00018046f0d0(uVar10, (int64_t)iVar16, 8, 0x180115340);
                iVar22 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x88);
            }
            iVar15 = 0;
            if (0 < iVar16) {
                do {
                    iVar6 = 0;
                    iVar3 = *(int64_t *)(uVar10 + (int64_t)iVar15 * 8);
                    if (*(int64_t *)(iVar3 + 0x98) != 0) {
                        *(undefined8 *)(*(int64_t *)(iVar3 + 0x98) + 0x4c8) = 0;
                    }
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    if (iVar4 != 0) {
                        for (; iVar6 < 2; iVar6 = iVar6 + 1) {
                            iVar1 = (int64_t)iVar6 * 8 + 0x20;
                            if (*(int64_t *)(iVar4 + iVar1) == iVar3) {
                                *(undefined8 *)(iVar1 + *(int64_t *)(iVar3 + 0x18)) = 0;
                            }
                        }
                    }
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cbf3;
                    func_0x0001801152b0(iVar22, iVar3);
                    iVar15 = iVar15 + 1;
                    iVar22 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x88);
                } while (iVar15 < iVar16);
            }
            if (iVar11 == 0) {
                puVar5 = *(undefined8 **)((int64_t)*(undefined **)0x20 + -0x68);
                if (puVar5[1] != 0) {
                    *puVar5 = 0;
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cc25;
                    func_0x000180460d90();
                    puVar5[1] = 0;
                }
                if (puVar5[3] != 0) {
                    puVar5[2] = 0;
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cc42;
                    func_0x000180460d90();
                    puVar5[3] = 0;
                }
            } else if (*(char *)((int64_t)*(undefined **)0x20 + 0x10) != '\0') {
                iVar22 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x80);
                *(int64_t *)(iVar22 + 0xa8) = iVar22;
                *(uint32_t *)(iVar22 + 8) = *(uint32_t *)(iVar22 + 8) | 0x800;
                *(uint32_t *)(iVar22 + 0x10) =
                     *(uint32_t *)(iVar22 + 0xc) | *(uint32_t *)(iVar22 + 4) | *(uint32_t *)(iVar22 + 8);
            }
            if (uVar10 != 0) {
                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cc82;
                func_0x000180460d90(uVar10);
            }
            return;
        }
        if ((*(int32_t *)(uVar20 + 0x14) != 0) && (uVar19 = uVar23, 0 < iVar16)) {
            do {
                if (**(int32_t **)(uVar10 + (int64_t)(int32_t)uVar19 * 8) == *(int32_t *)(uVar20 + 0x14)) {
                    *(int32_t *)(uVar20 + 0x14) = iVar11;
                    break;
                }
                uVar14 = (int32_t)uVar19 + 1;
                uVar19 = (uint64_t)uVar14;
            } while ((int32_t)uVar14 < iVar16);
        }
        uVar19 = (int64_t)*(int32_t *)(uVar20 - 4) + uVar20;
        uVar20 = uVar23;
        if (uVar19 != *(int64_t *)(iVar22 + 0x2958) + 4 + (int64_t)*(int32_t *)(iVar22 + 0x2950)) {
            uVar20 = uVar19;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180114f6c
// Address: 0x180114f6c
// Size: 79 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180114e92: Changing call to branch
// WARNING: Possible PIC construction at 0x000180114ee3: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180114ee8)
// WARNING: Removing unreachable block (ram,0x000180114f15)
// WARNING: Removing unreachable block (ram,0x000180114f20)
// WARNING: Removing unreachable block (ram,0x000180114f2d)
// WARNING: Removing unreachable block (ram,0x000180114f3a)
// WARNING: Removing unreachable block (ram,0x000180114f44)
// WARNING: Removing unreachable block (ram,0x000180114f5a)
// WARNING: Removing unreachable block (ram,0x000180114f63)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_2908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2910h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1588h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1580h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.180114da0(int64_t arg1, int64_t arg_30h)
{
    int64_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int32_t *piVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    int32_t iVar11;
    undefined4 *puVar12;
    uint32_t *puVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint64_t unaff_RBX;
    int32_t iVar16;
    int64_t unaff_RBP;
    int32_t *unaff_RSI;
    int32_t *piVar17;
    uint64_t unaff_RDI;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    uint64_t in_R9;
    uint64_t uVar21;
    int64_t iVar22;
    uint64_t uVar23;
    undefined8 unaff_R12;
    uint32_t uVar24;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint64_t uVar25;
    undefined8 unaff_R15;
    uint64_t uVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 auStack_50 [2];
    char acStack_40 [32];
    
    uVar23 = *(uint64_t *)0x180781f28;
    piVar17 = (int32_t *)(arg1 + 0x28e8);
    if ((*(uint8_t *)(arg1 + 0x30) & 0x80) == 0) {
        if ((*piVar17 < 1) && (*(int32_t *)(arg1 + 0x28f8) < 1)) {
            return;
        }
        uVar10 = 0;
        uVar20 = uVar10;
        if (*(int64_t *)(*(uint64_t *)0x180781f28 + 0x2958) != 0) {
            uVar20 = *(int64_t *)(*(uint64_t *)0x180781f28 + 0x2958) + 4;
        }
        while (uVar20 != 0) {
            iVar11 = *(int32_t *)(uVar20 - 4);
            *(undefined4 *)(uVar20 + 0x14) = 0;
            uVar19 = (int64_t)iVar11 + uVar20;
            uVar20 = uVar10;
            if (uVar19 != *(int64_t *)(uVar23 + 0x2958) + 4 + (int64_t)*(int32_t *)(uVar23 + 0x2950)) {
                uVar20 = uVar19;
            }
        }
        in_R9 = 0;
        piVar17 = unaff_RSI;
        arg1 = unaff_RBP;
        if (0 < *(int32_t *)(uVar23 + 0x1580)) {
            do {
                auStack_50[0] = 0x180114e46;
                func_0x000180115d50();
                uVar14 = (int32_t)uVar10 + 1;
                uVar10 = (uint64_t)uVar14;
            } while ((int32_t)uVar14 < *(int32_t *)(uVar23 + 0x1580));
        }
        iVar11 = 0;
    } else {
        unaff_RBX = 0;
        if ((*(char *)(arg1 + 0x80) != '\0') && (unaff_RDI = unaff_RBX, 0 < *piVar17)) {
            do {
                piVar8 = *(int32_t **)(*(int64_t *)(arg1 + 0x28f0) + 8 + (int64_t)(int32_t)unaff_RDI * 0x10);
                if ((piVar8 != (int32_t *)0x0) && ((*(int64_t *)(piVar8 + 6) == 0 && (*(int64_t *)(piVar8 + 8) != 0))))
                {
                    iVar11 = *piVar8;
                    *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
                    auStack_50[0] = 0x180114e97;
                    goto code_r0x00018011c860;
                }
                uVar14 = (int32_t)unaff_RDI + 1;
                unaff_RDI = (uint64_t)uVar14;
            } while ((int32_t)uVar14 < *piVar17);
        }
        if (*(char *)(arg1 + 0x2918) == '\0') {
            piVar17 = *(int32_t **)(arg1 + 0x2900);
            piVar8 = piVar17 + (int64_t)*(int32_t *)(arg1 + 0x28f8) * 0x10;
            for (; piVar17 != piVar8; piVar17 = piVar17 + 0x10) {
                if (*piVar17 == 2) {
                    if (*(int64_t *)(piVar17 + 0xc) == 0) {
                        if (*(int64_t *)(piVar17 + 0xe) != 0) {
                            auStack_50[0] = 0x180114fa9;
                            func_0x000180115ea0(arg1);
                        }
                    } else {
                        auStack_50[0] = 0x180114f96;
                        func_0x000180115d50();
                    }
                }
            }
            return;
        }
        auStack_50[0] = 0x180114eb2;
        func_0x000180112af0();
        unaff_RDI = *(uint64_t *)0x180781f28;
        if (0 < *(int32_t *)(*(uint64_t *)0x180781f28 + 0x1580)) {
            do {
                auStack_50[0] = 0x180114ed7;
                func_0x000180115d50();
                uVar14 = (int32_t)unaff_RBX + 1;
                unaff_RBX = (uint64_t)uVar14;
            } while ((int32_t)uVar14 < *(int32_t *)(unaff_RDI + 0x1580));
        }
        iVar11 = 0;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
        auStack_50[0] = 0x180114ee8;
    }
code_r0x00018011c860:
    uVar23 = *(uint64_t *)0x180781f28;
    *(int32_t *)((int64_t)*(undefined **)0x20 + 8) = iVar11;
    *(uint64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
    *(int64_t *)((int64_t)*(undefined **)0x20 + -0x10) = arg1;
    *(int32_t **)((int64_t)*(undefined **)0x20 + -0x18) = piVar17;
    *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x20) = unaff_RDI;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x28) = unaff_R12;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = unaff_R13;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x38) = unaff_R14;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = unaff_R15;
    *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x88) = *(uint64_t *)0x180781f28;
    piVar17 = (int32_t *)(*(uint64_t *)0x180781f28 + 0x28e8);
    *(int32_t **)((int64_t)*(undefined **)0x20 + -0x68) = piVar17;
    puVar7 = (undefined4 *)0x0;
    if (iVar11 == 0) {
        uVar14 = 0;
        *(undefined4 *)((int64_t)*(undefined **)0x20 + 0x18) = 0;
        puVar13 = (uint32_t *)0xd8;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x80) = 0;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x70) = 0;
        uVar20 = *(uint64_t *)0x180781f28;
        uVar24 = uVar14;
    } else {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011c89f;
        puVar7 = (undefined4 *)func_0x0001800f60f0(piVar17, iVar11);
        *(undefined4 **)((int64_t)*(undefined **)0x20 + -0x80) = puVar7;
        if (puVar7 == (undefined4 *)0x0) {
            return;
        }
        *(undefined4 **)((int64_t)*(undefined **)0x20 + -0x70) = puVar7;
        puVar13 = puVar7 + 0x36;
        uVar24 = *puVar13;
        uVar14 = (int32_t)(uVar24 << 0x1d) >> 0x1d;
        *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x18) = uVar14;
        uVar20 = *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x88);
        uVar24 = (int32_t)(uVar24 << 0x1a) >> 0x1d;
    }
    uVar19 = 0;
    uVar21 = in_R9 & 0xffffffffffffff00;
    *(int32_t *)((int64_t)*(undefined **)0x20 + 0x10) = (int32_t)uVar21;
    *(int32_t **)((int64_t)*(undefined **)0x20 + -0x78) = piVar17;
    *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x20) = uVar24;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x60) = 0;
    iVar16 = 0;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x58) = 0;
    uVar10 = uVar19;
    if (0 < *piVar17) {
        iVar11 = *(int32_t *)((int64_t)*(undefined **)0x20 + 8);
        uVar18 = uVar19;
        uVar25 = uVar19;
        uVar26 = uVar19;
        do {
            piVar17 = *(int32_t **)(*(int64_t *)(uVar23 + 0x28f0) + 8 + (int64_t)(int32_t)uVar26 * 0x10);
            uVar10 = uVar25;
            if (piVar17 != (int32_t *)0x0) {
                if (iVar11 == 0) {
code_r0x00018011c9a9:
                    uVar14 = (uint32_t)uVar21 & 0xff;
                    if ((piVar17[4] & 0x800U) != 0) {
                        uVar14 = 1;
                    }
                    *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x10) = uVar14;
                    if (iVar11 != 0) {
                        puVar9 = *(undefined4 **)(uVar20 + 0x2900);
                        puVar12 = puVar9 + (int64_t)*(int32_t *)(uVar20 + 0x28f8) * 0x10;
                        for (; puVar9 != puVar12; puVar9 = puVar9 + 0x10) {
                            if (*(int32_t **)(puVar9 + 4) == piVar17) {
                                *puVar9 = 0;
                            }
                        }
                    }
                    if (puVar7 != (undefined4 *)0x0) {
                        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca02;
                        func_0x0001801167e0(puVar7, piVar17);
                        uVar2 = *puVar7;
                        iVar16 = *piVar17;
                        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca0b;
                        func_0x00018011d570(iVar16, uVar2);
                    }
                    iVar15 = (int32_t)uVar18;
                    iVar16 = (int32_t)uVar19;
                    if (iVar16 == iVar15) {
                        if (iVar15 == 0) {
                            uVar14 = 8;
                        } else {
                            uVar14 = iVar15 / 2 + iVar15;
                        }
                        uVar24 = iVar16 + 1U;
                        if ((int32_t)(iVar16 + 1U) < (int32_t)uVar14) {
                            uVar24 = uVar14;
                        }
                        if (iVar15 < (int32_t)uVar24) {
                            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca3b;
                            uVar10 = func_0x00018046d050((int64_t)(int32_t)uVar24 << 3);
                            if (uVar25 != 0) {
                                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca55;
                                func_0x000180498030(uVar10, uVar25, (int64_t)iVar16 << 3);
                                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011ca5d;
                                func_0x000180460d90(uVar25);
                            }
                            *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x58) = uVar10;
                            uVar18 = (uint64_t)uVar24;
                            *(uint32_t *)((int64_t)*(undefined **)0x20 + -0x5c) = uVar24;
                        }
                        puVar7 = *(undefined4 **)((int64_t)*(undefined **)0x20 + -0x80);
                    }
                    *(int32_t **)(uVar10 + (int64_t)iVar16 * 8) = piVar17;
                    uVar19 = (uint64_t)(iVar16 + 1U);
                    *(uint32_t *)((int64_t)*(undefined **)0x20 + -0x60) = iVar16 + 1U;
                } else if ((*piVar17 != iVar11) && (piVar8 = piVar17, *(int64_t *)(piVar17 + 6) != 0)) {
                    do {
                        piVar8 = *(int32_t **)(piVar8 + 6);
                    } while (*(int64_t *)(piVar8 + 6) != 0);
                    if (*piVar8 == iVar11) goto code_r0x00018011c9a9;
                }
            }
            iVar16 = (int32_t)uVar19;
            uVar14 = (int32_t)uVar26 + 1;
            uVar26 = (uint64_t)uVar14;
            uVar20 = *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x88);
            uVar21 = (uint64_t)*(uint32_t *)((int64_t)*(undefined **)0x20 + 0x10);
            uVar25 = uVar10;
        } while ((int32_t)uVar14 < **(int32_t **)((int64_t)*(undefined **)0x20 + -0x68));
        puVar13 = (uint32_t *)(*(int64_t *)((int64_t)*(undefined **)0x20 + -0x70) + 0xd8);
        uVar14 = *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x18);
        uVar24 = *(uint32_t *)((int64_t)*(undefined **)0x20 + 0x20);
        iVar11 = *(int32_t *)((int64_t)*(undefined **)0x20 + 8);
    }
    uVar23 = 0;
    if (puVar7 != (undefined4 *)0x0) {
        *puVar13 = (uVar24 * 8 ^ uVar14) & 0xffffffc7 ^ (uVar14 ^ *puVar13) & 0xffffffc0 ^ uVar24 * 8;
    }
    iVar22 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x88);
    uVar20 = uVar23;
    if (*(int64_t *)(iVar22 + 0x2958) != 0) {
        uVar20 = *(int64_t *)(iVar22 + 0x2958) + 4;
    }
    do {
        if (uVar20 == 0) {
            if ((1 < iVar16) && (1 < (uint64_t)(int64_t)iVar16)) {
                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cb86;
                func_0x00018046f0d0(uVar10, (int64_t)iVar16, 8, 0x180115340);
                iVar22 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x88);
            }
            iVar15 = 0;
            if (0 < iVar16) {
                do {
                    iVar6 = 0;
                    iVar3 = *(int64_t *)(uVar10 + (int64_t)iVar15 * 8);
                    if (*(int64_t *)(iVar3 + 0x98) != 0) {
                        *(undefined8 *)(*(int64_t *)(iVar3 + 0x98) + 0x4c8) = 0;
                    }
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    if (iVar4 != 0) {
                        for (; iVar6 < 2; iVar6 = iVar6 + 1) {
                            iVar1 = (int64_t)iVar6 * 8 + 0x20;
                            if (*(int64_t *)(iVar4 + iVar1) == iVar3) {
                                *(undefined8 *)(iVar1 + *(int64_t *)(iVar3 + 0x18)) = 0;
                            }
                        }
                    }
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cbf3;
                    func_0x0001801152b0(iVar22, iVar3);
                    iVar15 = iVar15 + 1;
                    iVar22 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x88);
                } while (iVar15 < iVar16);
            }
            if (iVar11 == 0) {
                puVar5 = *(undefined8 **)((int64_t)*(undefined **)0x20 + -0x68);
                if (puVar5[1] != 0) {
                    *puVar5 = 0;
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cc25;
                    func_0x000180460d90();
                    puVar5[1] = 0;
                }
                if (puVar5[3] != 0) {
                    puVar5[2] = 0;
                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cc42;
                    func_0x000180460d90();
                    puVar5[3] = 0;
                }
            } else if (*(char *)((int64_t)*(undefined **)0x20 + 0x10) != '\0') {
                iVar22 = *(int64_t *)((int64_t)*(undefined **)0x20 + -0x80);
                *(int64_t *)(iVar22 + 0xa8) = iVar22;
                *(uint32_t *)(iVar22 + 8) = *(uint32_t *)(iVar22 + 8) | 0x800;
                *(uint32_t *)(iVar22 + 0x10) =
                     *(uint32_t *)(iVar22 + 0xc) | *(uint32_t *)(iVar22 + 4) | *(uint32_t *)(iVar22 + 8);
            }
            if (uVar10 != 0) {
                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0xb0) = 0x18011cc82;
                func_0x000180460d90(uVar10);
            }
            return;
        }
        if ((*(int32_t *)(uVar20 + 0x14) != 0) && (uVar19 = uVar23, 0 < iVar16)) {
            do {
                if (**(int32_t **)(uVar10 + (int64_t)(int32_t)uVar19 * 8) == *(int32_t *)(uVar20 + 0x14)) {
                    *(int32_t *)(uVar20 + 0x14) = iVar11;
                    break;
                }
                uVar14 = (int32_t)uVar19 + 1;
                uVar19 = (uint64_t)uVar14;
            } while ((int32_t)uVar14 < iVar16);
        }
        uVar19 = (int64_t)*(int32_t *)(uVar20 - 4) + uVar20;
        uVar20 = uVar23;
        if (uVar19 != *(int64_t *)(iVar22 + 0x2958) + 4 + (int64_t)*(int32_t *)(iVar22 + 0x2950)) {
            uVar20 = uVar19;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180114fc0
// Address: 0x180114fc0
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_2878h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2870h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

void fcn.180114fc0(int64_t arg1)
{
    float fVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_74h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar10 = 0;
    if (0 < *(int32_t *)(arg1 + 0x28e8)) {
        do {
            iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x28f0) + 8 + (int64_t)iVar10 * 0x10);
            if (((((iVar2 != 0) && (*(int32_t *)(iVar2 + 0xc0) == *(int32_t *)(arg1 + 4))) &&
                 ((*(uint8_t *)(iVar2 + 0xdc) & 1) != 0)) &&
                ((iVar3 = *(int64_t *)(iVar2 + 0x98), iVar3 != 0 && (*(int64_t *)(iVar2 + 0x20) == 0)))) &&
               ((*(uint8_t *)(iVar2 + 0xdc) & 4) == 0)) {
                fVar1 = *(float *)(arg1 + 0xebc);
                var_40h._0_4_ = *(float *)(iVar2 + 0x48) + *(float *)(iVar2 + 0x50);
                var_48h._0_4_ = *(float *)(iVar2 + 0x48) + 0.0;
                var_40h._4_4_ = *(float *)(iVar2 + 0x4c) + *(float *)(iVar2 + 0x54);
                var_48h._4_4_ =
                     *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
                     *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)(iVar2 + 0x4c);
                bVar4 = fVar1 + *(float *)(iVar3 + 0x60) < (float)var_48h;
                bVar5 = (float)var_40h < (*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - fVar1;
                bVar6 = fVar1 + *(float *)(iVar3 + 100) < var_48h._4_4_;
                bVar7 = var_40h._4_4_ < (*(float *)(iVar3 + 100) + *(float *)(iVar3 + 0x6c)) - fVar1;
                if ((bVar6) || (bVar4)) {
                    uVar8 = 0;
                    if (!bVar6) goto code_r0x000180115116;
code_r0x000180115122:
                    uVar9 = 0;
                } else {
                    uVar8 = 0x10;
code_r0x000180115116:
                    if (bVar5) goto code_r0x000180115122;
                    uVar9 = 0x20;
                }
                uVar9 = uVar9 | uVar8;
                if (bVar7) {
code_r0x000180115144:
                    uVar8 = 0x100;
                } else {
                    if (bVar4) {
                        if (bVar7) goto code_r0x000180115144;
                    } else {
                        uVar9 = uVar9 | 0x40;
                    }
                    uVar8 = 0x180;
                    if (bVar5) goto code_r0x000180115144;
                }
                func_0x000180127010(*(int64_t *)(iVar3 + 800) + 0x88, *(int64_t *)(iVar3 + 800), 0);
                func_0x000180126550(*(undefined8 *)(*(int64_t *)(iVar2 + 0x98) + 800), &var_48h, &var_40h, 
                                    *(undefined4 *)(iVar2 + 0x90), *(undefined4 *)(*(int64_t *)(iVar2 + 0x98) + 0x98), 
                                    uVar9 | uVar8);
            }
            iVar10 = iVar10 + 1;
        } while (iVar10 < *(int32_t *)(arg1 + 0x28e8));
    }
    return;
}

// ============================================================
// Function: FUN_180114fdd
// Address: 0x180114fdd
// Size: 498 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_2878h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2870h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

void fcn.180114fc0(int64_t arg1)
{
    float fVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_74h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar10 = 0;
    if (0 < *(int32_t *)(arg1 + 0x28e8)) {
        do {
            iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x28f0) + 8 + (int64_t)iVar10 * 0x10);
            if (((((iVar2 != 0) && (*(int32_t *)(iVar2 + 0xc0) == *(int32_t *)(arg1 + 4))) &&
                 ((*(uint8_t *)(iVar2 + 0xdc) & 1) != 0)) &&
                ((iVar3 = *(int64_t *)(iVar2 + 0x98), iVar3 != 0 && (*(int64_t *)(iVar2 + 0x20) == 0)))) &&
               ((*(uint8_t *)(iVar2 + 0xdc) & 4) == 0)) {
                fVar1 = *(float *)(arg1 + 0xebc);
                var_40h._0_4_ = *(float *)(iVar2 + 0x48) + *(float *)(iVar2 + 0x50);
                var_48h._0_4_ = *(float *)(iVar2 + 0x48) + 0.0;
                var_40h._4_4_ = *(float *)(iVar2 + 0x4c) + *(float *)(iVar2 + 0x54);
                var_48h._4_4_ =
                     *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
                     *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)(iVar2 + 0x4c);
                bVar4 = fVar1 + *(float *)(iVar3 + 0x60) < (float)var_48h;
                bVar5 = (float)var_40h < (*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - fVar1;
                bVar6 = fVar1 + *(float *)(iVar3 + 100) < var_48h._4_4_;
                bVar7 = var_40h._4_4_ < (*(float *)(iVar3 + 100) + *(float *)(iVar3 + 0x6c)) - fVar1;
                if ((bVar6) || (bVar4)) {
                    uVar8 = 0;
                    if (!bVar6) goto code_r0x000180115116;
code_r0x000180115122:
                    uVar9 = 0;
                } else {
                    uVar8 = 0x10;
code_r0x000180115116:
                    if (bVar5) goto code_r0x000180115122;
                    uVar9 = 0x20;
                }
                uVar9 = uVar9 | uVar8;
                if (bVar7) {
code_r0x000180115144:
                    uVar8 = 0x100;
                } else {
                    if (bVar4) {
                        if (bVar7) goto code_r0x000180115144;
                    } else {
                        uVar9 = uVar9 | 0x40;
                    }
                    uVar8 = 0x180;
                    if (bVar5) goto code_r0x000180115144;
                }
                func_0x000180127010(*(int64_t *)(iVar3 + 800) + 0x88, *(int64_t *)(iVar3 + 800), 0);
                func_0x000180126550(*(undefined8 *)(*(int64_t *)(iVar2 + 0x98) + 800), &var_48h, &var_40h, 
                                    *(undefined4 *)(iVar2 + 0x90), *(undefined4 *)(*(int64_t *)(iVar2 + 0x98) + 0x98), 
                                    uVar9 | uVar8);
            }
            iVar10 = iVar10 + 1;
        } while (iVar10 < *(int32_t *)(arg1 + 0x28e8));
    }
    return;
}

// ============================================================
// Function: FUN_1801151cf
// Address: 0x1801151cf
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_2878h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2870h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

void fcn.180114fc0(int64_t arg1)
{
    float fVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_74h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar10 = 0;
    if (0 < *(int32_t *)(arg1 + 0x28e8)) {
        do {
            iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x28f0) + 8 + (int64_t)iVar10 * 0x10);
            if (((((iVar2 != 0) && (*(int32_t *)(iVar2 + 0xc0) == *(int32_t *)(arg1 + 4))) &&
                 ((*(uint8_t *)(iVar2 + 0xdc) & 1) != 0)) &&
                ((iVar3 = *(int64_t *)(iVar2 + 0x98), iVar3 != 0 && (*(int64_t *)(iVar2 + 0x20) == 0)))) &&
               ((*(uint8_t *)(iVar2 + 0xdc) & 4) == 0)) {
                fVar1 = *(float *)(arg1 + 0xebc);
                var_40h._0_4_ = *(float *)(iVar2 + 0x48) + *(float *)(iVar2 + 0x50);
                var_48h._0_4_ = *(float *)(iVar2 + 0x48) + 0.0;
                var_40h._4_4_ = *(float *)(iVar2 + 0x4c) + *(float *)(iVar2 + 0x54);
                var_48h._4_4_ =
                     *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
                     *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)(iVar2 + 0x4c);
                bVar4 = fVar1 + *(float *)(iVar3 + 0x60) < (float)var_48h;
                bVar5 = (float)var_40h < (*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - fVar1;
                bVar6 = fVar1 + *(float *)(iVar3 + 100) < var_48h._4_4_;
                bVar7 = var_40h._4_4_ < (*(float *)(iVar3 + 100) + *(float *)(iVar3 + 0x6c)) - fVar1;
                if ((bVar6) || (bVar4)) {
                    uVar8 = 0;
                    if (!bVar6) goto code_r0x000180115116;
code_r0x000180115122:
                    uVar9 = 0;
                } else {
                    uVar8 = 0x10;
code_r0x000180115116:
                    if (bVar5) goto code_r0x000180115122;
                    uVar9 = 0x20;
                }
                uVar9 = uVar9 | uVar8;
                if (bVar7) {
code_r0x000180115144:
                    uVar8 = 0x100;
                } else {
                    if (bVar4) {
                        if (bVar7) goto code_r0x000180115144;
                    } else {
                        uVar9 = uVar9 | 0x40;
                    }
                    uVar8 = 0x180;
                    if (bVar5) goto code_r0x000180115144;
                }
                func_0x000180127010(*(int64_t *)(iVar3 + 800) + 0x88, *(int64_t *)(iVar3 + 800), 0);
                func_0x000180126550(*(undefined8 *)(*(int64_t *)(iVar2 + 0x98) + 800), &var_48h, &var_40h, 
                                    *(undefined4 *)(iVar2 + 0x90), *(undefined4 *)(*(int64_t *)(iVar2 + 0x98) + 0x98), 
                                    uVar9 | uVar8);
            }
            iVar10 = iVar10 + 1;
        } while (iVar10 < *(int32_t *)(arg1 + 0x28e8));
    }
    return;
}

// ============================================================
// Function: FUN_1801151e0
// Address: 0x1801151e0
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.1801151e0(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t var_8h;
    
    iVar2 = 1;
    iVar1 = func_0x0001800f60f0(arg1 + 0x28e8, 1);
    while (iVar1 != 0) {
        iVar2 = iVar2 + 1;
        iVar1 = func_0x0001800f60f0(arg1 + 0x28e8, iVar2);
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180115230
// Address: 0x180115230
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 * fcn.180115230(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    int64_t var_18h;
    
    arg1 = arg1 + 0x28e8;
    uVar3 = arg2 & 0xffffffff;
    if ((int32_t)arg2 == 0) {
        uVar3 = 1;
        iVar1 = func_0x0001800f60f0(arg1, 1);
        while (iVar1 != 0) {
            uVar3 = (uint64_t)((int32_t)uVar3 + 1);
            iVar1 = func_0x0001800f60f0(arg1, uVar3);
        }
    }
    iVar1 = func_0x00018046d050(0xe0);
    if (iVar1 == 0) {
        puVar2 = (undefined4 *)0x0;
    } else {
        puVar2 = (undefined4 *)fcn.1801161f0(iVar1, uVar3);
    }
    func_0x0001800f6220(arg1, *puVar2, puVar2);
    return puVar2;
}

// ============================================================
// Function: FUN_1801152b0
// Address: 0x1801152b0
// Size: 140 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001801152da: Changing call to branch
// WARNING: Possible PIC construction at 0x0001801152f2: Changing call to branch
// WARNING: Possible PIC construction at 0x00018011531f: Changing call to branch
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801152b0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStack_30 [5];
    
    iVar4 = *(int64_t *)(arg2 + 0x40);
    if (iVar4 == 0) {
        *(undefined8 *)(arg2 + 0x40) = 0;
        auStack_30[0] = 0x18011530e;
        func_0x0001800f6220(arg1 + 0x28e8, *(undefined4 *)arg2, 0);
        *(undefined8 *)(arg2 + 0x28) = 0;
        *(undefined8 *)(arg2 + 0x20) = 0;
        iVar4 = arg2;
        if (*(int64_t *)(arg2 + 0x38) != 0) {
            *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
            auStack_30[0] = 0x180115324;
            iVar4 = *(int64_t *)(arg2 + 0x38);
            unaff_RBX = arg2;
        }
    } else if (*(int64_t *)(iVar4 + 0xa8) == 0) {
        if (*(int64_t *)(iVar4 + 0x10) != 0) {
            auStack_30[0] = 0x1801152ee;
            func_0x000180460d90();
        }
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x1801152f7;
        unaff_RBX = arg2;
    } else {
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x1801152df;
        iVar4 = *(int64_t *)(iVar4 + 0xa8);
        unaff_RBX = arg2;
    }
    if (iVar4 != 0) {
        *(int64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar4);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = func_0x00018046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar1 = (undefined4 *)func_0x00018046b77c();
            *puVar1 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180115390
// Address: 0x180115390
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.180115390(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    int16_t iVar2;
    int16_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    int32_t iVar9;
    uint32_t uVar10;
    int64_t iVar12;
    int64_t var_18h;
    int64_t var_58h;
    uint8_t var_50h;
    int64_t var_4fh;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar11;
    
    if (0 < (int32_t)arg3) {
        iVar9 = 0;
        iVar12 = 0;
        do {
            uVar7 = *(uint32_t *)(arg2 + iVar12 * 0x24);
            if ((uVar7 != 0) && (iVar4 = func_0x0001800f60f0(arg1 + 0x28e8, uVar7), iVar4 == 0)) {
                iVar4 = fcn.180115230(arg1, (uint64_t)uVar7);
                if (*(int32_t *)(arg2 + 4 + iVar12 * 0x24) == 0) {
                    iVar5 = 0;
                } else {
                    iVar5 = func_0x0001800f60f0(arg1 + 0x28e8);
                }
                *(int64_t *)(iVar4 + 0x18) = iVar5;
                iVar2 = *(int16_t *)(arg2 + 0x18 + iVar12 * 0x24);
                *(float *)(iVar4 + 0x4c) = (float)(int32_t)*(int16_t *)(arg2 + 0x1a + iVar12 * 0x24);
                *(float *)(iVar4 + 0x48) = (float)(int32_t)iVar2;
                iVar2 = *(int16_t *)(arg2 + 0x1c + iVar12 * 0x24);
                *(float *)(iVar4 + 0x54) = (float)(int32_t)*(int16_t *)(arg2 + 0x1e + iVar12 * 0x24);
                *(float *)(iVar4 + 0x50) = (float)(int32_t)iVar2;
                iVar2 = *(int16_t *)(arg2 + 0x22 + iVar12 * 0x24);
                iVar3 = *(int16_t *)(arg2 + 0x20 + iVar12 * 0x24);
                *(uint32_t *)(iVar4 + 0xd8) = *(uint32_t *)(iVar4 + 0xd8) & 0xfffffe49;
                *(uint32_t *)(iVar4 + 0xd8) = *(uint32_t *)(iVar4 + 0xd8) | 0x49;
                *(float *)(iVar4 + 0x5c) = (float)(int32_t)iVar2;
                *(float *)(iVar4 + 0x58) = (float)(int32_t)iVar3;
                if (iVar5 != 0) {
                    if (*(int64_t *)(iVar5 + 0x20) == 0) {
                        *(int64_t *)(iVar5 + 0x20) = iVar4;
                    } else if (*(int64_t *)(iVar5 + 0x28) == 0) {
                        *(int64_t *)(iVar5 + 0x28) = iVar4;
                    }
                }
                piVar8 = &var_4fh;
                uVar11 = 0xffffffff;
                uVar10 = 0xffffffff;
                *(undefined4 *)(iVar4 + 0xcc) = *(undefined4 *)(arg2 + 0xc + iVar12 * 0x24);
                *(int32_t *)(iVar4 + 0x60) = (int32_t)*(char *)(arg2 + 0x10 + iVar12 * 0x24);
                uVar7 = *(uint32_t *)(arg2 + 0x14 + iVar12 * 0x24) & 0x3fc20;
                *(uint32_t *)(iVar4 + 8) = uVar7;
                *(uint32_t *)(iVar4 + 0x10) = *(uint32_t *)(iVar4 + 0xc) | *(uint32_t *)(iVar4 + 4) | uVar7;
                uVar1 = var_50h;
                if (var_50h != 0) {
                    do {
                        if (((uVar1 == 0x23) && (*(uint8_t *)piVar8 == 0x23)) &&
                           (*(uint8_t *)((int64_t)piVar8 + 1) == 0x23)) {
                            uVar11 = 0xffffffff;
                            piVar8 = (int64_t *)((int64_t)piVar8 + 2);
                        } else {
                            uVar11 = (uint64_t)
                                     ((uint32_t)(uVar11 >> 8) ^
                                     *(uint32_t *)((uVar11 & 0xff ^ (uint64_t)uVar1) * 4 + 0x180618620));
                        }
                        uVar10 = (uint32_t)uVar11;
                        uVar1 = *(uint8_t *)piVar8;
                        piVar8 = (int64_t *)((int64_t)piVar8 + 1);
                    } while (uVar1 != 0);
                }
                uVar6 = func_0x0001800f60f0(*(int64_t *)0x180781f28 + 0x15c0, ~uVar10);
                *(undefined8 *)(iVar4 + 0x98) = uVar6;
            }
            iVar9 = iVar9 + 1;
            iVar12 = iVar12 + 1;
        } while (iVar9 < (int32_t)arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1801153a7
// Address: 0x1801153a7
// Size: 498 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.180115390(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    int16_t iVar2;
    int16_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    int32_t iVar9;
    uint32_t uVar10;
    int64_t iVar12;
    int64_t var_18h;
    int64_t var_58h;
    uint8_t var_50h;
    int64_t var_4fh;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar11;
    
    if (0 < (int32_t)arg3) {
        iVar9 = 0;
        iVar12 = 0;
        do {
            uVar7 = *(uint32_t *)(arg2 + iVar12 * 0x24);
            if ((uVar7 != 0) && (iVar4 = func_0x0001800f60f0(arg1 + 0x28e8, uVar7), iVar4 == 0)) {
                iVar4 = fcn.180115230(arg1, (uint64_t)uVar7);
                if (*(int32_t *)(arg2 + 4 + iVar12 * 0x24) == 0) {
                    iVar5 = 0;
                } else {
                    iVar5 = func_0x0001800f60f0(arg1 + 0x28e8);
                }
                *(int64_t *)(iVar4 + 0x18) = iVar5;
                iVar2 = *(int16_t *)(arg2 + 0x18 + iVar12 * 0x24);
                *(float *)(iVar4 + 0x4c) = (float)(int32_t)*(int16_t *)(arg2 + 0x1a + iVar12 * 0x24);
                *(float *)(iVar4 + 0x48) = (float)(int32_t)iVar2;
                iVar2 = *(int16_t *)(arg2 + 0x1c + iVar12 * 0x24);
                *(float *)(iVar4 + 0x54) = (float)(int32_t)*(int16_t *)(arg2 + 0x1e + iVar12 * 0x24);
                *(float *)(iVar4 + 0x50) = (float)(int32_t)iVar2;
                iVar2 = *(int16_t *)(arg2 + 0x22 + iVar12 * 0x24);
                iVar3 = *(int16_t *)(arg2 + 0x20 + iVar12 * 0x24);
                *(uint32_t *)(iVar4 + 0xd8) = *(uint32_t *)(iVar4 + 0xd8) & 0xfffffe49;
                *(uint32_t *)(iVar4 + 0xd8) = *(uint32_t *)(iVar4 + 0xd8) | 0x49;
                *(float *)(iVar4 + 0x5c) = (float)(int32_t)iVar2;
                *(float *)(iVar4 + 0x58) = (float)(int32_t)iVar3;
                if (iVar5 != 0) {
                    if (*(int64_t *)(iVar5 + 0x20) == 0) {
                        *(int64_t *)(iVar5 + 0x20) = iVar4;
                    } else if (*(int64_t *)(iVar5 + 0x28) == 0) {
                        *(int64_t *)(iVar5 + 0x28) = iVar4;
                    }
                }
                piVar8 = &var_4fh;
                uVar11 = 0xffffffff;
                uVar10 = 0xffffffff;
                *(undefined4 *)(iVar4 + 0xcc) = *(undefined4 *)(arg2 + 0xc + iVar12 * 0x24);
                *(int32_t *)(iVar4 + 0x60) = (int32_t)*(char *)(arg2 + 0x10 + iVar12 * 0x24);
                uVar7 = *(uint32_t *)(arg2 + 0x14 + iVar12 * 0x24) & 0x3fc20;
                *(uint32_t *)(iVar4 + 8) = uVar7;
                *(uint32_t *)(iVar4 + 0x10) = *(uint32_t *)(iVar4 + 0xc) | *(uint32_t *)(iVar4 + 4) | uVar7;
                uVar1 = var_50h;
                if (var_50h != 0) {
                    do {
                        if (((uVar1 == 0x23) && (*(uint8_t *)piVar8 == 0x23)) &&
                           (*(uint8_t *)((int64_t)piVar8 + 1) == 0x23)) {
                            uVar11 = 0xffffffff;
                            piVar8 = (int64_t *)((int64_t)piVar8 + 2);
                        } else {
                            uVar11 = (uint64_t)
                                     ((uint32_t)(uVar11 >> 8) ^
                                     *(uint32_t *)((uVar11 & 0xff ^ (uint64_t)uVar1) * 4 + 0x180618620));
                        }
                        uVar10 = (uint32_t)uVar11;
                        uVar1 = *(uint8_t *)piVar8;
                        piVar8 = (int64_t *)((int64_t)piVar8 + 1);
                    } while (uVar1 != 0);
                }
                uVar6 = func_0x0001800f60f0(*(int64_t *)0x180781f28 + 0x15c0, ~uVar10);
                *(undefined8 *)(iVar4 + 0x98) = uVar6;
            }
            iVar9 = iVar9 + 1;
            iVar12 = iVar12 + 1;
        } while (iVar9 < (int32_t)arg3);
    }
    return;
}

// ============================================================
// Function: FUN_180115599
// Address: 0x180115599
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.180115390(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    int16_t iVar2;
    int16_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    int32_t iVar9;
    uint32_t uVar10;
    int64_t iVar12;
    int64_t var_18h;
    int64_t var_58h;
    uint8_t var_50h;
    int64_t var_4fh;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar11;
    
    if (0 < (int32_t)arg3) {
        iVar9 = 0;
        iVar12 = 0;
        do {
            uVar7 = *(uint32_t *)(arg2 + iVar12 * 0x24);
            if ((uVar7 != 0) && (iVar4 = func_0x0001800f60f0(arg1 + 0x28e8, uVar7), iVar4 == 0)) {
                iVar4 = fcn.180115230(arg1, (uint64_t)uVar7);
                if (*(int32_t *)(arg2 + 4 + iVar12 * 0x24) == 0) {
                    iVar5 = 0;
                } else {
                    iVar5 = func_0x0001800f60f0(arg1 + 0x28e8);
                }
                *(int64_t *)(iVar4 + 0x18) = iVar5;
                iVar2 = *(int16_t *)(arg2 + 0x18 + iVar12 * 0x24);
                *(float *)(iVar4 + 0x4c) = (float)(int32_t)*(int16_t *)(arg2 + 0x1a + iVar12 * 0x24);
                *(float *)(iVar4 + 0x48) = (float)(int32_t)iVar2;
                iVar2 = *(int16_t *)(arg2 + 0x1c + iVar12 * 0x24);
                *(float *)(iVar4 + 0x54) = (float)(int32_t)*(int16_t *)(arg2 + 0x1e + iVar12 * 0x24);
                *(float *)(iVar4 + 0x50) = (float)(int32_t)iVar2;
                iVar2 = *(int16_t *)(arg2 + 0x22 + iVar12 * 0x24);
                iVar3 = *(int16_t *)(arg2 + 0x20 + iVar12 * 0x24);
                *(uint32_t *)(iVar4 + 0xd8) = *(uint32_t *)(iVar4 + 0xd8) & 0xfffffe49;
                *(uint32_t *)(iVar4 + 0xd8) = *(uint32_t *)(iVar4 + 0xd8) | 0x49;
                *(float *)(iVar4 + 0x5c) = (float)(int32_t)iVar2;
                *(float *)(iVar4 + 0x58) = (float)(int32_t)iVar3;
                if (iVar5 != 0) {
                    if (*(int64_t *)(iVar5 + 0x20) == 0) {
                        *(int64_t *)(iVar5 + 0x20) = iVar4;
                    } else if (*(int64_t *)(iVar5 + 0x28) == 0) {
                        *(int64_t *)(iVar5 + 0x28) = iVar4;
                    }
                }
                piVar8 = &var_4fh;
                uVar11 = 0xffffffff;
                uVar10 = 0xffffffff;
                *(undefined4 *)(iVar4 + 0xcc) = *(undefined4 *)(arg2 + 0xc + iVar12 * 0x24);
                *(int32_t *)(iVar4 + 0x60) = (int32_t)*(char *)(arg2 + 0x10 + iVar12 * 0x24);
                uVar7 = *(uint32_t *)(arg2 + 0x14 + iVar12 * 0x24) & 0x3fc20;
                *(uint32_t *)(iVar4 + 8) = uVar7;
                *(uint32_t *)(iVar4 + 0x10) = *(uint32_t *)(iVar4 + 0xc) | *(uint32_t *)(iVar4 + 4) | uVar7;
                uVar1 = var_50h;
                if (var_50h != 0) {
                    do {
                        if (((uVar1 == 0x23) && (*(uint8_t *)piVar8 == 0x23)) &&
                           (*(uint8_t *)((int64_t)piVar8 + 1) == 0x23)) {
                            uVar11 = 0xffffffff;
                            piVar8 = (int64_t *)((int64_t)piVar8 + 2);
                        } else {
                            uVar11 = (uint64_t)
                                     ((uint32_t)(uVar11 >> 8) ^
                                     *(uint32_t *)((uVar11 & 0xff ^ (uint64_t)uVar1) * 4 + 0x180618620));
                        }
                        uVar10 = (uint32_t)uVar11;
                        uVar1 = *(uint8_t *)piVar8;
                        piVar8 = (int64_t *)((int64_t)piVar8 + 1);
                    } while (uVar1 != 0);
                }
                uVar6 = func_0x0001800f60f0(*(int64_t *)0x180781f28 + 0x15c0, ~uVar10);
                *(undefined8 *)(iVar4 + 0x98) = uVar6;
            }
            iVar9 = iVar9 + 1;
            iVar12 = iVar12 + 1;
        } while (iVar9 < (int32_t)arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1801155a0
// Address: 0x1801155a0
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801155a0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int64_t *piVar6;
    int64_t var_8h;
    
    piVar6 = *(int64_t **)(arg1 + 0x1588);
    piVar1 = piVar6 + *(int32_t *)(arg1 + 0x1580);
    do {
        if (piVar6 == piVar1) {
            return;
        }
        iVar2 = *piVar6;
        if (((*(int32_t *)(iVar2 + 0x4d0) != 0) && (*(int32_t *)(arg1 + 4) + -1 <= *(int32_t *)(iVar2 + 0x2e0))) &&
           (*(int64_t *)(iVar2 + 0x4c0) == 0)) {
            piVar5 = (int32_t *)func_0x0001800f60f0(arg1 + 0x28e8);
            if ((int32_t)arg2 != 0) {
                iVar4 = *(int64_t *)(piVar5 + 6);
                piVar3 = piVar5;
                while (iVar4 != 0) {
                    piVar3 = *(int32_t **)(piVar3 + 6);
                    iVar4 = *(int64_t *)(piVar3 + 6);
                }
                if (*piVar3 != (int32_t)arg2) goto code_r0x00018011562d;
            }
            func_0x0001801162d0(piVar5, iVar2, 1);
        }
code_r0x00018011562d:
        piVar6 = piVar6 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1801155c6
// Address: 0x1801155c6
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801155a0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int64_t *piVar6;
    int64_t var_8h;
    
    piVar6 = *(int64_t **)(arg1 + 0x1588);
    piVar1 = piVar6 + *(int32_t *)(arg1 + 0x1580);
    do {
        if (piVar6 == piVar1) {
            return;
        }
        iVar2 = *piVar6;
        if (((*(int32_t *)(iVar2 + 0x4d0) != 0) && (*(int32_t *)(arg1 + 4) + -1 <= *(int32_t *)(iVar2 + 0x2e0))) &&
           (*(int64_t *)(iVar2 + 0x4c0) == 0)) {
            piVar5 = (int32_t *)func_0x0001800f60f0(arg1 + 0x28e8);
            if ((int32_t)arg2 != 0) {
                iVar4 = *(int64_t *)(piVar5 + 6);
                piVar3 = piVar5;
                while (iVar4 != 0) {
                    piVar3 = *(int32_t **)(piVar3 + 6);
                    iVar4 = *(int64_t *)(piVar3 + 6);
                }
                if (*piVar3 != (int32_t)arg2) goto code_r0x00018011562d;
            }
            func_0x0001801162d0(piVar5, iVar2, 1);
        }
code_r0x00018011562d:
        piVar6 = piVar6 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_18011563b
// Address: 0x18011563b
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801155a0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int64_t *piVar6;
    int64_t var_8h;
    
    piVar6 = *(int64_t **)(arg1 + 0x1588);
    piVar1 = piVar6 + *(int32_t *)(arg1 + 0x1580);
    do {
        if (piVar6 == piVar1) {
            return;
        }
        iVar2 = *piVar6;
        if (((*(int32_t *)(iVar2 + 0x4d0) != 0) && (*(int32_t *)(arg1 + 4) + -1 <= *(int32_t *)(iVar2 + 0x2e0))) &&
           (*(int64_t *)(iVar2 + 0x4c0) == 0)) {
            piVar5 = (int32_t *)func_0x0001800f60f0(arg1 + 0x28e8);
            if ((int32_t)arg2 != 0) {
                iVar4 = *(int64_t *)(piVar5 + 6);
                piVar3 = piVar5;
                while (iVar4 != 0) {
                    piVar3 = *(int32_t **)(piVar3 + 6);
                    iVar4 = *(int64_t *)(piVar3 + 6);
                }
                if (*piVar3 != (int32_t)arg2) goto code_r0x00018011562d;
            }
            func_0x0001801162d0(piVar5, iVar2, 1);
        }
code_r0x00018011562d:
        piVar6 = piVar6 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_180115650
// Address: 0x180115650
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180115650(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    uint32_t *puVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    undefined4 *puVar14;
    undefined4 *arg2_00;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    uint64_t uVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    int64_t var_18h;
    uint32_t uStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    puVar8 = *(undefined4 **)(arg2 + 0x10);
    iVar5 = *(int64_t *)(arg2 + 0x18);
    iVar6 = *(int64_t *)(arg2 + 8);
    var_18h._0_4_ = 0;
    if (iVar5 == 0) {
        arg2_00 = (undefined4 *)0x0;
    } else {
        arg2_00 = *(undefined4 **)(iVar5 + 0x4c8);
        *(undefined8 *)(iVar5 + 0x4c8) = 0;
        if (arg2_00 == (undefined4 *)0x0) {
            var_18h._0_4_ = *(int32_t *)(iVar5 + 200);
        } else if (*(int64_t *)(arg2_00 + 8) == 0) {
            var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x24);
            if ((int32_t)var_18h == 0) {
                var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x20);
            }
        }
    }
    iVar13 = 1;
    if (puVar8 == (undefined4 *)0x0) {
        iVar15 = 1;
        iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar8 = (undefined4 *)0x0;
        } else {
            puVar8 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(arg1 + 0x28e8, *puVar8, puVar8);
        *(undefined8 *)(puVar8 + 0x12) = *(undefined8 *)(iVar6 + 0x60);
        *(undefined8 *)(puVar8 + 0x14) = *(undefined8 *)(iVar6 + 0x68);
        if (*(int64_t *)(iVar6 + 0x4c8) == 0) {
            func_0x0001801162d0(puVar8, iVar6, 1);
            puVar1 = (uint32_t *)(*(int64_t *)(*(int64_t *)(puVar8 + 0x10) + 0x10) + 4);
            *puVar1 = *puVar1 & 0xff7fffff;
            *(uint8_t *)(iVar6 + 0x495) = *(uint8_t *)(iVar6 + 0x495) | 1;
        }
    }
    iVar6 = *(int64_t *)0x180781f28;
    uVar16 = *(uint32_t *)(arg2 + 0x20);
    if (uVar16 == 0xffffffff) goto code_r0x000180115b04;
    iVar15 = 1;
    if (uVar16 < 2) {
        uStackX_20 = 0;
        if (uVar16 != 0) goto code_r0x0001801157ce;
code_r0x0001801157d8:
        uVar16 = 1;
    } else {
        uStackX_20 = 1;
code_r0x0001801157ce:
        if (uVar16 == 2) goto code_r0x0001801157d8;
        uVar16 = 0;
    }
    fVar20 = *(float *)(arg2 + 0x24);
    if ((arg2_00 == (undefined4 *)0x0) || (uVar16 == 0)) {
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar9 = (undefined4 *)0x0;
        } else {
            puVar9 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(iVar17, *puVar9, puVar9);
        *(undefined4 **)(puVar9 + 6) = puVar8;
        if (arg2_00 != (undefined4 *)0x0) goto code_r0x00018011587e;
code_r0x000180115888:
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar13 = iVar13 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar13);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar10 = (undefined4 *)0x0;
        } else {
            puVar10 = (undefined4 *)fcn.1801161f0(iVar7, iVar13);
        }
        func_0x0001800f6220(iVar17, *puVar10, puVar10);
    } else {
        *(undefined4 **)(arg2_00 + 6) = puVar8;
        puVar9 = arg2_00;
code_r0x00018011587e:
        puVar10 = arg2_00;
        if (uVar16 == 1) goto code_r0x000180115888;
    }
    *(undefined4 **)(puVar10 + 6) = puVar8;
    iVar7 = *(int64_t *)(puVar8 + 8);
    puVar14 = puVar10;
    if (uVar16 == 0) {
        puVar14 = puVar9;
    }
    *(int64_t *)(puVar14 + 8) = iVar7;
    *(undefined8 *)(puVar14 + 10) = *(undefined8 *)(puVar8 + 10);
    if (iVar7 != 0) {
        *(undefined4 **)(iVar7 + 0x18) = puVar14;
    }
    if (*(int64_t *)(puVar14 + 10) != 0) {
        *(undefined4 **)(*(int64_t *)(puVar14 + 10) + 0x18) = puVar14;
    }
    puVar14[0x18] = puVar8[0x18];
    *(undefined8 *)(puVar14 + 0x16) = *(undefined8 *)(puVar8 + 0x16);
    *(undefined4 **)(puVar8 + 8) = puVar9;
    *(undefined4 **)(puVar8 + 10) = puVar10;
    uVar18 = (uint64_t)uVar16;
    *(undefined8 *)(*(int64_t *)(puVar8 + uVar18 * 2 + 8) + 0xa0) = *(undefined8 *)(puVar8 + 0x28);
    puVar8[0x36] = puVar8[0x36] & 0xffffffc9;
    puVar8[0x36] = puVar8[0x36] | 9;
    uVar3 = puVar8[0x15];
    puVar8[0x18] = uStackX_20;
    uVar11 = (uint64_t)uStackX_20;
    *(undefined8 *)(puVar8 + 0x28) = 0;
    fVar19 = *(float *)(iVar6 + 0xdb8 + uVar11 * 4);
    fVar21 = (float)puVar8[uVar11 + 0x14] - *(float *)(iVar6 + 0xebc);
    fVar19 = fVar19 + fVar19;
    if (fVar21 <= fVar19) {
        fVar21 = fVar19;
    }
    uVar4 = puVar8[0x14];
    puVar10[0x16] = uVar4;
    puVar10[0x17] = uVar3;
    puVar9[0x16] = uVar4;
    puVar9[0x17] = uVar3;
    fVar20 = (float)(int32_t)(fVar21 * fVar20);
    puVar9[uVar11 + 0x16] = fVar20;
    puVar10[uVar11 + 0x16] = (float)(int32_t)(fVar21 - fVar20);
    func_0x0001801167e0(*(undefined8 *)(puVar8 + uVar18 * 2 + 8), puVar8);
    func_0x00018011d570(*puVar8, **(undefined4 **)(puVar8 + uVar18 * 2 + 8));
    iVar6 = *(int64_t *)(puVar8 + 6);
    puVar12 = puVar8;
    while (iVar6 != 0) {
        puVar12 = *(undefined4 **)(puVar12 + 6);
        iVar6 = *(int64_t *)(puVar12 + 6);
    }
    *(uint8_t *)(puVar12 + 0x37) = *(uint8_t *)(puVar12 + 0x37) & 0xdf;
    if (*(int64_t *)(puVar12 + 8) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 10) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 6) == 0) {
        for (iVar6 = *(int64_t *)(puVar12 + 0x2a); iVar6 != 0; iVar6 = *(int64_t *)(iVar6 + 0x18)) {
            *(uint8_t *)(iVar6 + 0xdc) = *(uint8_t *)(iVar6 + 0xdc) | 0x20;
        }
    }
    func_0x00018011b1e0(puVar8, *(undefined8 *)(puVar8 + 0x12), *(undefined8 *)(puVar8 + 0x14), 0);
    puVar9[1] = puVar8[1];
    puVar10[1] = puVar8[1];
    puVar14[2] = puVar8[2] & 0x3f870;
    puVar8[2] = puVar8[2] & 0xfffc078f;
    puVar9[4] = puVar9[3] | puVar9[2] | puVar9[1];
    puVar10[4] = puVar10[3] | puVar10[2] | puVar10[1];
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if ((puVar14[4] & 0x800) != 0) {
        iVar6 = *(int64_t *)(puVar8 + 6);
        puVar9 = puVar8;
        while (iVar6 != 0) {
            puVar9 = *(undefined4 **)(puVar9 + 6);
            iVar6 = *(int64_t *)(puVar9 + 6);
        }
        *(undefined4 **)(puVar9 + 0x2a) = puVar14;
    }
    puVar2 = (undefined8 *)(puVar8 + 0x26);
    puVar8 = *(undefined4 **)(puVar8 + (uVar18 ^ 1) * 2 + 8);
    *(undefined8 *)(puVar8 + 0x26) = *puVar2;
code_r0x000180115b04:
    puVar8[2] = puVar8[2] & 0xffffdfff;
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if (puVar8 == arg2_00) {
        *(uint8_t *)((int64_t)puVar8 + 0xdd) = *(uint8_t *)((int64_t)puVar8 + 0xdd) | 2;
    } else {
        iVar13 = puVar8[0xc];
        if ((0 < iVar13) && (*(int64_t *)(puVar8 + 0x10) == 0)) {
            func_0x000180119020(puVar8);
            iVar13 = puVar8[0xc];
            iVar15 = 0;
            if (0 < iVar13) {
                do {
                    func_0x00018014ab80(*(undefined8 *)(puVar8 + 0x10), 0, 
                                        *(undefined8 *)(*(int64_t *)(puVar8 + 0xe) + (int64_t)iVar15 * 8));
                    iVar13 = puVar8[0xc];
                    iVar15 = iVar15 + 1;
                } while (iVar15 < iVar13);
            }
        }
        if (arg2_00 == (undefined4 *)0x0) {
            if (iVar5 != 0) {
                iVar13 = *(int32_t *)(iVar5 + 0x4d0);
                *(int64_t *)(puVar8 + 0x28) = iVar5;
                func_0x0001801162d0(puVar8, iVar5, 1);
                if (iVar13 != 0) {
                    func_0x00018011d570(iVar13, *puVar8);
                }
            }
        } else {
            if (*(int64_t *)(arg2_00 + 8) == 0) {
                uVar3 = *arg2_00;
                func_0x0001801167e0(puVar8, arg2_00);
                func_0x00018011d570(uVar3, *puVar8);
            } else {
                if (0 < iVar13) {
                    puVar9 = *(undefined4 **)(arg2_00 + 0x2c);
                    func_0x0001801167e0(puVar8, puVar9);
                    func_0x0001801167e0(puVar9, puVar8);
                    func_0x00018011d570(*puVar8, *puVar9);
                }
                if ((puVar8[4] & 0x800) != 0) {
                    iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, arg2_00[0x32]);
                    iVar6 = *(int64_t *)(iVar7 + 0x18);
                    iVar5 = iVar7;
                    while (iVar6 != 0) {
                        iVar5 = *(int64_t *)(iVar5 + 0x18);
                        iVar6 = *(int64_t *)(iVar5 + 0x18);
                    }
                    *(uint32_t *)(iVar7 + 8) = *(uint32_t *)(iVar7 + 8) | 0x800;
                    *(uint32_t *)(iVar7 + 0x10) =
                         *(uint32_t *)(iVar7 + 0xc) | *(uint32_t *)(iVar7 + 4) | *(uint32_t *)(iVar7 + 8);
                    puVar8[2] = puVar8[2] & 0xfffff7ff;
                    puVar8[4] = puVar8[2] | puVar8[3] | puVar8[1];
                    *(int64_t *)(iVar5 + 0xa8) = iVar7;
                }
                iVar5 = *(int64_t *)(arg2_00 + 8);
                *(int64_t *)(puVar8 + 8) = iVar5;
                *(undefined8 *)(puVar8 + 10) = *(undefined8 *)(arg2_00 + 10);
                if (iVar5 != 0) {
                    *(undefined4 **)(iVar5 + 0x18) = puVar8;
                }
                if (*(int64_t *)(puVar8 + 10) != 0) {
                    *(undefined4 **)(*(int64_t *)(puVar8 + 10) + 0x18) = puVar8;
                }
                puVar8[0x18] = arg2_00[0x18];
                *(undefined8 *)(puVar8 + 0x16) = *(undefined8 *)(arg2_00 + 0x16);
                *(undefined8 *)(arg2_00 + 10) = 0;
                *(undefined8 *)(arg2_00 + 8) = 0;
            }
            if (*(int64_t *)(arg2_00 + 0x26) != 0) {
                *(undefined8 *)(*(int64_t *)(arg2_00 + 0x26) + 0x4c8) = 0;
            }
            iVar5 = *(int64_t *)(arg2_00 + 6);
            if (iVar5 == 0) {
                fcn.1801152b0(arg1, (int64_t)arg2_00);
            } else {
                puVar9 = *(undefined4 **)(iVar5 + 0x20);
                if (puVar9 == arg2_00) {
                    puVar9 = *(undefined4 **)(iVar5 + 0x28);
                }
                func_0x00018011af70(arg1, iVar5, puVar9);
            }
        }
    }
    if (*(int64_t *)(puVar8 + 0x10) != 0) {
        *(int32_t *)(*(int64_t *)(puVar8 + 0x10) + 0x24) = (int32_t)var_18h;
    }
    if (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    return;
}

// ============================================================
// Function: FUN_18011565e
// Address: 0x18011565e
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180115650(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    uint32_t *puVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    undefined4 *puVar14;
    undefined4 *arg2_00;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    uint64_t uVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    int64_t var_18h;
    uint32_t uStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    puVar8 = *(undefined4 **)(arg2 + 0x10);
    iVar5 = *(int64_t *)(arg2 + 0x18);
    iVar6 = *(int64_t *)(arg2 + 8);
    var_18h._0_4_ = 0;
    if (iVar5 == 0) {
        arg2_00 = (undefined4 *)0x0;
    } else {
        arg2_00 = *(undefined4 **)(iVar5 + 0x4c8);
        *(undefined8 *)(iVar5 + 0x4c8) = 0;
        if (arg2_00 == (undefined4 *)0x0) {
            var_18h._0_4_ = *(int32_t *)(iVar5 + 200);
        } else if (*(int64_t *)(arg2_00 + 8) == 0) {
            var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x24);
            if ((int32_t)var_18h == 0) {
                var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x20);
            }
        }
    }
    iVar13 = 1;
    if (puVar8 == (undefined4 *)0x0) {
        iVar15 = 1;
        iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar8 = (undefined4 *)0x0;
        } else {
            puVar8 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(arg1 + 0x28e8, *puVar8, puVar8);
        *(undefined8 *)(puVar8 + 0x12) = *(undefined8 *)(iVar6 + 0x60);
        *(undefined8 *)(puVar8 + 0x14) = *(undefined8 *)(iVar6 + 0x68);
        if (*(int64_t *)(iVar6 + 0x4c8) == 0) {
            func_0x0001801162d0(puVar8, iVar6, 1);
            puVar1 = (uint32_t *)(*(int64_t *)(*(int64_t *)(puVar8 + 0x10) + 0x10) + 4);
            *puVar1 = *puVar1 & 0xff7fffff;
            *(uint8_t *)(iVar6 + 0x495) = *(uint8_t *)(iVar6 + 0x495) | 1;
        }
    }
    iVar6 = *(int64_t *)0x180781f28;
    uVar16 = *(uint32_t *)(arg2 + 0x20);
    if (uVar16 == 0xffffffff) goto code_r0x000180115b04;
    iVar15 = 1;
    if (uVar16 < 2) {
        uStackX_20 = 0;
        if (uVar16 != 0) goto code_r0x0001801157ce;
code_r0x0001801157d8:
        uVar16 = 1;
    } else {
        uStackX_20 = 1;
code_r0x0001801157ce:
        if (uVar16 == 2) goto code_r0x0001801157d8;
        uVar16 = 0;
    }
    fVar20 = *(float *)(arg2 + 0x24);
    if ((arg2_00 == (undefined4 *)0x0) || (uVar16 == 0)) {
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar9 = (undefined4 *)0x0;
        } else {
            puVar9 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(iVar17, *puVar9, puVar9);
        *(undefined4 **)(puVar9 + 6) = puVar8;
        if (arg2_00 != (undefined4 *)0x0) goto code_r0x00018011587e;
code_r0x000180115888:
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar13 = iVar13 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar13);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar10 = (undefined4 *)0x0;
        } else {
            puVar10 = (undefined4 *)fcn.1801161f0(iVar7, iVar13);
        }
        func_0x0001800f6220(iVar17, *puVar10, puVar10);
    } else {
        *(undefined4 **)(arg2_00 + 6) = puVar8;
        puVar9 = arg2_00;
code_r0x00018011587e:
        puVar10 = arg2_00;
        if (uVar16 == 1) goto code_r0x000180115888;
    }
    *(undefined4 **)(puVar10 + 6) = puVar8;
    iVar7 = *(int64_t *)(puVar8 + 8);
    puVar14 = puVar10;
    if (uVar16 == 0) {
        puVar14 = puVar9;
    }
    *(int64_t *)(puVar14 + 8) = iVar7;
    *(undefined8 *)(puVar14 + 10) = *(undefined8 *)(puVar8 + 10);
    if (iVar7 != 0) {
        *(undefined4 **)(iVar7 + 0x18) = puVar14;
    }
    if (*(int64_t *)(puVar14 + 10) != 0) {
        *(undefined4 **)(*(int64_t *)(puVar14 + 10) + 0x18) = puVar14;
    }
    puVar14[0x18] = puVar8[0x18];
    *(undefined8 *)(puVar14 + 0x16) = *(undefined8 *)(puVar8 + 0x16);
    *(undefined4 **)(puVar8 + 8) = puVar9;
    *(undefined4 **)(puVar8 + 10) = puVar10;
    uVar18 = (uint64_t)uVar16;
    *(undefined8 *)(*(int64_t *)(puVar8 + uVar18 * 2 + 8) + 0xa0) = *(undefined8 *)(puVar8 + 0x28);
    puVar8[0x36] = puVar8[0x36] & 0xffffffc9;
    puVar8[0x36] = puVar8[0x36] | 9;
    uVar3 = puVar8[0x15];
    puVar8[0x18] = uStackX_20;
    uVar11 = (uint64_t)uStackX_20;
    *(undefined8 *)(puVar8 + 0x28) = 0;
    fVar19 = *(float *)(iVar6 + 0xdb8 + uVar11 * 4);
    fVar21 = (float)puVar8[uVar11 + 0x14] - *(float *)(iVar6 + 0xebc);
    fVar19 = fVar19 + fVar19;
    if (fVar21 <= fVar19) {
        fVar21 = fVar19;
    }
    uVar4 = puVar8[0x14];
    puVar10[0x16] = uVar4;
    puVar10[0x17] = uVar3;
    puVar9[0x16] = uVar4;
    puVar9[0x17] = uVar3;
    fVar20 = (float)(int32_t)(fVar21 * fVar20);
    puVar9[uVar11 + 0x16] = fVar20;
    puVar10[uVar11 + 0x16] = (float)(int32_t)(fVar21 - fVar20);
    func_0x0001801167e0(*(undefined8 *)(puVar8 + uVar18 * 2 + 8), puVar8);
    func_0x00018011d570(*puVar8, **(undefined4 **)(puVar8 + uVar18 * 2 + 8));
    iVar6 = *(int64_t *)(puVar8 + 6);
    puVar12 = puVar8;
    while (iVar6 != 0) {
        puVar12 = *(undefined4 **)(puVar12 + 6);
        iVar6 = *(int64_t *)(puVar12 + 6);
    }
    *(uint8_t *)(puVar12 + 0x37) = *(uint8_t *)(puVar12 + 0x37) & 0xdf;
    if (*(int64_t *)(puVar12 + 8) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 10) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 6) == 0) {
        for (iVar6 = *(int64_t *)(puVar12 + 0x2a); iVar6 != 0; iVar6 = *(int64_t *)(iVar6 + 0x18)) {
            *(uint8_t *)(iVar6 + 0xdc) = *(uint8_t *)(iVar6 + 0xdc) | 0x20;
        }
    }
    func_0x00018011b1e0(puVar8, *(undefined8 *)(puVar8 + 0x12), *(undefined8 *)(puVar8 + 0x14), 0);
    puVar9[1] = puVar8[1];
    puVar10[1] = puVar8[1];
    puVar14[2] = puVar8[2] & 0x3f870;
    puVar8[2] = puVar8[2] & 0xfffc078f;
    puVar9[4] = puVar9[3] | puVar9[2] | puVar9[1];
    puVar10[4] = puVar10[3] | puVar10[2] | puVar10[1];
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if ((puVar14[4] & 0x800) != 0) {
        iVar6 = *(int64_t *)(puVar8 + 6);
        puVar9 = puVar8;
        while (iVar6 != 0) {
            puVar9 = *(undefined4 **)(puVar9 + 6);
            iVar6 = *(int64_t *)(puVar9 + 6);
        }
        *(undefined4 **)(puVar9 + 0x2a) = puVar14;
    }
    puVar2 = (undefined8 *)(puVar8 + 0x26);
    puVar8 = *(undefined4 **)(puVar8 + (uVar18 ^ 1) * 2 + 8);
    *(undefined8 *)(puVar8 + 0x26) = *puVar2;
code_r0x000180115b04:
    puVar8[2] = puVar8[2] & 0xffffdfff;
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if (puVar8 == arg2_00) {
        *(uint8_t *)((int64_t)puVar8 + 0xdd) = *(uint8_t *)((int64_t)puVar8 + 0xdd) | 2;
    } else {
        iVar13 = puVar8[0xc];
        if ((0 < iVar13) && (*(int64_t *)(puVar8 + 0x10) == 0)) {
            func_0x000180119020(puVar8);
            iVar13 = puVar8[0xc];
            iVar15 = 0;
            if (0 < iVar13) {
                do {
                    func_0x00018014ab80(*(undefined8 *)(puVar8 + 0x10), 0, 
                                        *(undefined8 *)(*(int64_t *)(puVar8 + 0xe) + (int64_t)iVar15 * 8));
                    iVar13 = puVar8[0xc];
                    iVar15 = iVar15 + 1;
                } while (iVar15 < iVar13);
            }
        }
        if (arg2_00 == (undefined4 *)0x0) {
            if (iVar5 != 0) {
                iVar13 = *(int32_t *)(iVar5 + 0x4d0);
                *(int64_t *)(puVar8 + 0x28) = iVar5;
                func_0x0001801162d0(puVar8, iVar5, 1);
                if (iVar13 != 0) {
                    func_0x00018011d570(iVar13, *puVar8);
                }
            }
        } else {
            if (*(int64_t *)(arg2_00 + 8) == 0) {
                uVar3 = *arg2_00;
                func_0x0001801167e0(puVar8, arg2_00);
                func_0x00018011d570(uVar3, *puVar8);
            } else {
                if (0 < iVar13) {
                    puVar9 = *(undefined4 **)(arg2_00 + 0x2c);
                    func_0x0001801167e0(puVar8, puVar9);
                    func_0x0001801167e0(puVar9, puVar8);
                    func_0x00018011d570(*puVar8, *puVar9);
                }
                if ((puVar8[4] & 0x800) != 0) {
                    iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, arg2_00[0x32]);
                    iVar6 = *(int64_t *)(iVar7 + 0x18);
                    iVar5 = iVar7;
                    while (iVar6 != 0) {
                        iVar5 = *(int64_t *)(iVar5 + 0x18);
                        iVar6 = *(int64_t *)(iVar5 + 0x18);
                    }
                    *(uint32_t *)(iVar7 + 8) = *(uint32_t *)(iVar7 + 8) | 0x800;
                    *(uint32_t *)(iVar7 + 0x10) =
                         *(uint32_t *)(iVar7 + 0xc) | *(uint32_t *)(iVar7 + 4) | *(uint32_t *)(iVar7 + 8);
                    puVar8[2] = puVar8[2] & 0xfffff7ff;
                    puVar8[4] = puVar8[2] | puVar8[3] | puVar8[1];
                    *(int64_t *)(iVar5 + 0xa8) = iVar7;
                }
                iVar5 = *(int64_t *)(arg2_00 + 8);
                *(int64_t *)(puVar8 + 8) = iVar5;
                *(undefined8 *)(puVar8 + 10) = *(undefined8 *)(arg2_00 + 10);
                if (iVar5 != 0) {
                    *(undefined4 **)(iVar5 + 0x18) = puVar8;
                }
                if (*(int64_t *)(puVar8 + 10) != 0) {
                    *(undefined4 **)(*(int64_t *)(puVar8 + 10) + 0x18) = puVar8;
                }
                puVar8[0x18] = arg2_00[0x18];
                *(undefined8 *)(puVar8 + 0x16) = *(undefined8 *)(arg2_00 + 0x16);
                *(undefined8 *)(arg2_00 + 10) = 0;
                *(undefined8 *)(arg2_00 + 8) = 0;
            }
            if (*(int64_t *)(arg2_00 + 0x26) != 0) {
                *(undefined8 *)(*(int64_t *)(arg2_00 + 0x26) + 0x4c8) = 0;
            }
            iVar5 = *(int64_t *)(arg2_00 + 6);
            if (iVar5 == 0) {
                fcn.1801152b0(arg1, (int64_t)arg2_00);
            } else {
                puVar9 = *(undefined4 **)(iVar5 + 0x20);
                if (puVar9 == arg2_00) {
                    puVar9 = *(undefined4 **)(iVar5 + 0x28);
                }
                func_0x00018011af70(arg1, iVar5, puVar9);
            }
        }
    }
    if (*(int64_t *)(puVar8 + 0x10) != 0) {
        *(int32_t *)(*(int64_t *)(puVar8 + 0x10) + 0x24) = (int32_t)var_18h;
    }
    if (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    return;
}

// ============================================================
// Function: FUN_180115685
// Address: 0x180115685
// Size: 296 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180115650(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    uint32_t *puVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    undefined4 *puVar14;
    undefined4 *arg2_00;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    uint64_t uVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    int64_t var_18h;
    uint32_t uStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    puVar8 = *(undefined4 **)(arg2 + 0x10);
    iVar5 = *(int64_t *)(arg2 + 0x18);
    iVar6 = *(int64_t *)(arg2 + 8);
    var_18h._0_4_ = 0;
    if (iVar5 == 0) {
        arg2_00 = (undefined4 *)0x0;
    } else {
        arg2_00 = *(undefined4 **)(iVar5 + 0x4c8);
        *(undefined8 *)(iVar5 + 0x4c8) = 0;
        if (arg2_00 == (undefined4 *)0x0) {
            var_18h._0_4_ = *(int32_t *)(iVar5 + 200);
        } else if (*(int64_t *)(arg2_00 + 8) == 0) {
            var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x24);
            if ((int32_t)var_18h == 0) {
                var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x20);
            }
        }
    }
    iVar13 = 1;
    if (puVar8 == (undefined4 *)0x0) {
        iVar15 = 1;
        iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar8 = (undefined4 *)0x0;
        } else {
            puVar8 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(arg1 + 0x28e8, *puVar8, puVar8);
        *(undefined8 *)(puVar8 + 0x12) = *(undefined8 *)(iVar6 + 0x60);
        *(undefined8 *)(puVar8 + 0x14) = *(undefined8 *)(iVar6 + 0x68);
        if (*(int64_t *)(iVar6 + 0x4c8) == 0) {
            func_0x0001801162d0(puVar8, iVar6, 1);
            puVar1 = (uint32_t *)(*(int64_t *)(*(int64_t *)(puVar8 + 0x10) + 0x10) + 4);
            *puVar1 = *puVar1 & 0xff7fffff;
            *(uint8_t *)(iVar6 + 0x495) = *(uint8_t *)(iVar6 + 0x495) | 1;
        }
    }
    iVar6 = *(int64_t *)0x180781f28;
    uVar16 = *(uint32_t *)(arg2 + 0x20);
    if (uVar16 == 0xffffffff) goto code_r0x000180115b04;
    iVar15 = 1;
    if (uVar16 < 2) {
        uStackX_20 = 0;
        if (uVar16 != 0) goto code_r0x0001801157ce;
code_r0x0001801157d8:
        uVar16 = 1;
    } else {
        uStackX_20 = 1;
code_r0x0001801157ce:
        if (uVar16 == 2) goto code_r0x0001801157d8;
        uVar16 = 0;
    }
    fVar20 = *(float *)(arg2 + 0x24);
    if ((arg2_00 == (undefined4 *)0x0) || (uVar16 == 0)) {
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar9 = (undefined4 *)0x0;
        } else {
            puVar9 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(iVar17, *puVar9, puVar9);
        *(undefined4 **)(puVar9 + 6) = puVar8;
        if (arg2_00 != (undefined4 *)0x0) goto code_r0x00018011587e;
code_r0x000180115888:
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar13 = iVar13 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar13);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar10 = (undefined4 *)0x0;
        } else {
            puVar10 = (undefined4 *)fcn.1801161f0(iVar7, iVar13);
        }
        func_0x0001800f6220(iVar17, *puVar10, puVar10);
    } else {
        *(undefined4 **)(arg2_00 + 6) = puVar8;
        puVar9 = arg2_00;
code_r0x00018011587e:
        puVar10 = arg2_00;
        if (uVar16 == 1) goto code_r0x000180115888;
    }
    *(undefined4 **)(puVar10 + 6) = puVar8;
    iVar7 = *(int64_t *)(puVar8 + 8);
    puVar14 = puVar10;
    if (uVar16 == 0) {
        puVar14 = puVar9;
    }
    *(int64_t *)(puVar14 + 8) = iVar7;
    *(undefined8 *)(puVar14 + 10) = *(undefined8 *)(puVar8 + 10);
    if (iVar7 != 0) {
        *(undefined4 **)(iVar7 + 0x18) = puVar14;
    }
    if (*(int64_t *)(puVar14 + 10) != 0) {
        *(undefined4 **)(*(int64_t *)(puVar14 + 10) + 0x18) = puVar14;
    }
    puVar14[0x18] = puVar8[0x18];
    *(undefined8 *)(puVar14 + 0x16) = *(undefined8 *)(puVar8 + 0x16);
    *(undefined4 **)(puVar8 + 8) = puVar9;
    *(undefined4 **)(puVar8 + 10) = puVar10;
    uVar18 = (uint64_t)uVar16;
    *(undefined8 *)(*(int64_t *)(puVar8 + uVar18 * 2 + 8) + 0xa0) = *(undefined8 *)(puVar8 + 0x28);
    puVar8[0x36] = puVar8[0x36] & 0xffffffc9;
    puVar8[0x36] = puVar8[0x36] | 9;
    uVar3 = puVar8[0x15];
    puVar8[0x18] = uStackX_20;
    uVar11 = (uint64_t)uStackX_20;
    *(undefined8 *)(puVar8 + 0x28) = 0;
    fVar19 = *(float *)(iVar6 + 0xdb8 + uVar11 * 4);
    fVar21 = (float)puVar8[uVar11 + 0x14] - *(float *)(iVar6 + 0xebc);
    fVar19 = fVar19 + fVar19;
    if (fVar21 <= fVar19) {
        fVar21 = fVar19;
    }
    uVar4 = puVar8[0x14];
    puVar10[0x16] = uVar4;
    puVar10[0x17] = uVar3;
    puVar9[0x16] = uVar4;
    puVar9[0x17] = uVar3;
    fVar20 = (float)(int32_t)(fVar21 * fVar20);
    puVar9[uVar11 + 0x16] = fVar20;
    puVar10[uVar11 + 0x16] = (float)(int32_t)(fVar21 - fVar20);
    func_0x0001801167e0(*(undefined8 *)(puVar8 + uVar18 * 2 + 8), puVar8);
    func_0x00018011d570(*puVar8, **(undefined4 **)(puVar8 + uVar18 * 2 + 8));
    iVar6 = *(int64_t *)(puVar8 + 6);
    puVar12 = puVar8;
    while (iVar6 != 0) {
        puVar12 = *(undefined4 **)(puVar12 + 6);
        iVar6 = *(int64_t *)(puVar12 + 6);
    }
    *(uint8_t *)(puVar12 + 0x37) = *(uint8_t *)(puVar12 + 0x37) & 0xdf;
    if (*(int64_t *)(puVar12 + 8) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 10) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 6) == 0) {
        for (iVar6 = *(int64_t *)(puVar12 + 0x2a); iVar6 != 0; iVar6 = *(int64_t *)(iVar6 + 0x18)) {
            *(uint8_t *)(iVar6 + 0xdc) = *(uint8_t *)(iVar6 + 0xdc) | 0x20;
        }
    }
    func_0x00018011b1e0(puVar8, *(undefined8 *)(puVar8 + 0x12), *(undefined8 *)(puVar8 + 0x14), 0);
    puVar9[1] = puVar8[1];
    puVar10[1] = puVar8[1];
    puVar14[2] = puVar8[2] & 0x3f870;
    puVar8[2] = puVar8[2] & 0xfffc078f;
    puVar9[4] = puVar9[3] | puVar9[2] | puVar9[1];
    puVar10[4] = puVar10[3] | puVar10[2] | puVar10[1];
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if ((puVar14[4] & 0x800) != 0) {
        iVar6 = *(int64_t *)(puVar8 + 6);
        puVar9 = puVar8;
        while (iVar6 != 0) {
            puVar9 = *(undefined4 **)(puVar9 + 6);
            iVar6 = *(int64_t *)(puVar9 + 6);
        }
        *(undefined4 **)(puVar9 + 0x2a) = puVar14;
    }
    puVar2 = (undefined8 *)(puVar8 + 0x26);
    puVar8 = *(undefined4 **)(puVar8 + (uVar18 ^ 1) * 2 + 8);
    *(undefined8 *)(puVar8 + 0x26) = *puVar2;
code_r0x000180115b04:
    puVar8[2] = puVar8[2] & 0xffffdfff;
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if (puVar8 == arg2_00) {
        *(uint8_t *)((int64_t)puVar8 + 0xdd) = *(uint8_t *)((int64_t)puVar8 + 0xdd) | 2;
    } else {
        iVar13 = puVar8[0xc];
        if ((0 < iVar13) && (*(int64_t *)(puVar8 + 0x10) == 0)) {
            func_0x000180119020(puVar8);
            iVar13 = puVar8[0xc];
            iVar15 = 0;
            if (0 < iVar13) {
                do {
                    func_0x00018014ab80(*(undefined8 *)(puVar8 + 0x10), 0, 
                                        *(undefined8 *)(*(int64_t *)(puVar8 + 0xe) + (int64_t)iVar15 * 8));
                    iVar13 = puVar8[0xc];
                    iVar15 = iVar15 + 1;
                } while (iVar15 < iVar13);
            }
        }
        if (arg2_00 == (undefined4 *)0x0) {
            if (iVar5 != 0) {
                iVar13 = *(int32_t *)(iVar5 + 0x4d0);
                *(int64_t *)(puVar8 + 0x28) = iVar5;
                func_0x0001801162d0(puVar8, iVar5, 1);
                if (iVar13 != 0) {
                    func_0x00018011d570(iVar13, *puVar8);
                }
            }
        } else {
            if (*(int64_t *)(arg2_00 + 8) == 0) {
                uVar3 = *arg2_00;
                func_0x0001801167e0(puVar8, arg2_00);
                func_0x00018011d570(uVar3, *puVar8);
            } else {
                if (0 < iVar13) {
                    puVar9 = *(undefined4 **)(arg2_00 + 0x2c);
                    func_0x0001801167e0(puVar8, puVar9);
                    func_0x0001801167e0(puVar9, puVar8);
                    func_0x00018011d570(*puVar8, *puVar9);
                }
                if ((puVar8[4] & 0x800) != 0) {
                    iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, arg2_00[0x32]);
                    iVar6 = *(int64_t *)(iVar7 + 0x18);
                    iVar5 = iVar7;
                    while (iVar6 != 0) {
                        iVar5 = *(int64_t *)(iVar5 + 0x18);
                        iVar6 = *(int64_t *)(iVar5 + 0x18);
                    }
                    *(uint32_t *)(iVar7 + 8) = *(uint32_t *)(iVar7 + 8) | 0x800;
                    *(uint32_t *)(iVar7 + 0x10) =
                         *(uint32_t *)(iVar7 + 0xc) | *(uint32_t *)(iVar7 + 4) | *(uint32_t *)(iVar7 + 8);
                    puVar8[2] = puVar8[2] & 0xfffff7ff;
                    puVar8[4] = puVar8[2] | puVar8[3] | puVar8[1];
                    *(int64_t *)(iVar5 + 0xa8) = iVar7;
                }
                iVar5 = *(int64_t *)(arg2_00 + 8);
                *(int64_t *)(puVar8 + 8) = iVar5;
                *(undefined8 *)(puVar8 + 10) = *(undefined8 *)(arg2_00 + 10);
                if (iVar5 != 0) {
                    *(undefined4 **)(iVar5 + 0x18) = puVar8;
                }
                if (*(int64_t *)(puVar8 + 10) != 0) {
                    *(undefined4 **)(*(int64_t *)(puVar8 + 10) + 0x18) = puVar8;
                }
                puVar8[0x18] = arg2_00[0x18];
                *(undefined8 *)(puVar8 + 0x16) = *(undefined8 *)(arg2_00 + 0x16);
                *(undefined8 *)(arg2_00 + 10) = 0;
                *(undefined8 *)(arg2_00 + 8) = 0;
            }
            if (*(int64_t *)(arg2_00 + 0x26) != 0) {
                *(undefined8 *)(*(int64_t *)(arg2_00 + 0x26) + 0x4c8) = 0;
            }
            iVar5 = *(int64_t *)(arg2_00 + 6);
            if (iVar5 == 0) {
                fcn.1801152b0(arg1, (int64_t)arg2_00);
            } else {
                puVar9 = *(undefined4 **)(iVar5 + 0x20);
                if (puVar9 == arg2_00) {
                    puVar9 = *(undefined4 **)(iVar5 + 0x28);
                }
                func_0x00018011af70(arg1, iVar5, puVar9);
            }
        }
    }
    if (*(int64_t *)(puVar8 + 0x10) != 0) {
        *(int32_t *)(*(int64_t *)(puVar8 + 0x10) + 0x24) = (int32_t)var_18h;
    }
    if (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    return;
}

// ============================================================
// Function: FUN_1801157ad
// Address: 0x1801157ad
// Size: 596 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180115650(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    uint32_t *puVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    undefined4 *puVar14;
    undefined4 *arg2_00;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    uint64_t uVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    int64_t var_18h;
    uint32_t uStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    puVar8 = *(undefined4 **)(arg2 + 0x10);
    iVar5 = *(int64_t *)(arg2 + 0x18);
    iVar6 = *(int64_t *)(arg2 + 8);
    var_18h._0_4_ = 0;
    if (iVar5 == 0) {
        arg2_00 = (undefined4 *)0x0;
    } else {
        arg2_00 = *(undefined4 **)(iVar5 + 0x4c8);
        *(undefined8 *)(iVar5 + 0x4c8) = 0;
        if (arg2_00 == (undefined4 *)0x0) {
            var_18h._0_4_ = *(int32_t *)(iVar5 + 200);
        } else if (*(int64_t *)(arg2_00 + 8) == 0) {
            var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x24);
            if ((int32_t)var_18h == 0) {
                var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x20);
            }
        }
    }
    iVar13 = 1;
    if (puVar8 == (undefined4 *)0x0) {
        iVar15 = 1;
        iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar8 = (undefined4 *)0x0;
        } else {
            puVar8 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(arg1 + 0x28e8, *puVar8, puVar8);
        *(undefined8 *)(puVar8 + 0x12) = *(undefined8 *)(iVar6 + 0x60);
        *(undefined8 *)(puVar8 + 0x14) = *(undefined8 *)(iVar6 + 0x68);
        if (*(int64_t *)(iVar6 + 0x4c8) == 0) {
            func_0x0001801162d0(puVar8, iVar6, 1);
            puVar1 = (uint32_t *)(*(int64_t *)(*(int64_t *)(puVar8 + 0x10) + 0x10) + 4);
            *puVar1 = *puVar1 & 0xff7fffff;
            *(uint8_t *)(iVar6 + 0x495) = *(uint8_t *)(iVar6 + 0x495) | 1;
        }
    }
    iVar6 = *(int64_t *)0x180781f28;
    uVar16 = *(uint32_t *)(arg2 + 0x20);
    if (uVar16 == 0xffffffff) goto code_r0x000180115b04;
    iVar15 = 1;
    if (uVar16 < 2) {
        uStackX_20 = 0;
        if (uVar16 != 0) goto code_r0x0001801157ce;
code_r0x0001801157d8:
        uVar16 = 1;
    } else {
        uStackX_20 = 1;
code_r0x0001801157ce:
        if (uVar16 == 2) goto code_r0x0001801157d8;
        uVar16 = 0;
    }
    fVar20 = *(float *)(arg2 + 0x24);
    if ((arg2_00 == (undefined4 *)0x0) || (uVar16 == 0)) {
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar9 = (undefined4 *)0x0;
        } else {
            puVar9 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(iVar17, *puVar9, puVar9);
        *(undefined4 **)(puVar9 + 6) = puVar8;
        if (arg2_00 != (undefined4 *)0x0) goto code_r0x00018011587e;
code_r0x000180115888:
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar13 = iVar13 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar13);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar10 = (undefined4 *)0x0;
        } else {
            puVar10 = (undefined4 *)fcn.1801161f0(iVar7, iVar13);
        }
        func_0x0001800f6220(iVar17, *puVar10, puVar10);
    } else {
        *(undefined4 **)(arg2_00 + 6) = puVar8;
        puVar9 = arg2_00;
code_r0x00018011587e:
        puVar10 = arg2_00;
        if (uVar16 == 1) goto code_r0x000180115888;
    }
    *(undefined4 **)(puVar10 + 6) = puVar8;
    iVar7 = *(int64_t *)(puVar8 + 8);
    puVar14 = puVar10;
    if (uVar16 == 0) {
        puVar14 = puVar9;
    }
    *(int64_t *)(puVar14 + 8) = iVar7;
    *(undefined8 *)(puVar14 + 10) = *(undefined8 *)(puVar8 + 10);
    if (iVar7 != 0) {
        *(undefined4 **)(iVar7 + 0x18) = puVar14;
    }
    if (*(int64_t *)(puVar14 + 10) != 0) {
        *(undefined4 **)(*(int64_t *)(puVar14 + 10) + 0x18) = puVar14;
    }
    puVar14[0x18] = puVar8[0x18];
    *(undefined8 *)(puVar14 + 0x16) = *(undefined8 *)(puVar8 + 0x16);
    *(undefined4 **)(puVar8 + 8) = puVar9;
    *(undefined4 **)(puVar8 + 10) = puVar10;
    uVar18 = (uint64_t)uVar16;
    *(undefined8 *)(*(int64_t *)(puVar8 + uVar18 * 2 + 8) + 0xa0) = *(undefined8 *)(puVar8 + 0x28);
    puVar8[0x36] = puVar8[0x36] & 0xffffffc9;
    puVar8[0x36] = puVar8[0x36] | 9;
    uVar3 = puVar8[0x15];
    puVar8[0x18] = uStackX_20;
    uVar11 = (uint64_t)uStackX_20;
    *(undefined8 *)(puVar8 + 0x28) = 0;
    fVar19 = *(float *)(iVar6 + 0xdb8 + uVar11 * 4);
    fVar21 = (float)puVar8[uVar11 + 0x14] - *(float *)(iVar6 + 0xebc);
    fVar19 = fVar19 + fVar19;
    if (fVar21 <= fVar19) {
        fVar21 = fVar19;
    }
    uVar4 = puVar8[0x14];
    puVar10[0x16] = uVar4;
    puVar10[0x17] = uVar3;
    puVar9[0x16] = uVar4;
    puVar9[0x17] = uVar3;
    fVar20 = (float)(int32_t)(fVar21 * fVar20);
    puVar9[uVar11 + 0x16] = fVar20;
    puVar10[uVar11 + 0x16] = (float)(int32_t)(fVar21 - fVar20);
    func_0x0001801167e0(*(undefined8 *)(puVar8 + uVar18 * 2 + 8), puVar8);
    func_0x00018011d570(*puVar8, **(undefined4 **)(puVar8 + uVar18 * 2 + 8));
    iVar6 = *(int64_t *)(puVar8 + 6);
    puVar12 = puVar8;
    while (iVar6 != 0) {
        puVar12 = *(undefined4 **)(puVar12 + 6);
        iVar6 = *(int64_t *)(puVar12 + 6);
    }
    *(uint8_t *)(puVar12 + 0x37) = *(uint8_t *)(puVar12 + 0x37) & 0xdf;
    if (*(int64_t *)(puVar12 + 8) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 10) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 6) == 0) {
        for (iVar6 = *(int64_t *)(puVar12 + 0x2a); iVar6 != 0; iVar6 = *(int64_t *)(iVar6 + 0x18)) {
            *(uint8_t *)(iVar6 + 0xdc) = *(uint8_t *)(iVar6 + 0xdc) | 0x20;
        }
    }
    func_0x00018011b1e0(puVar8, *(undefined8 *)(puVar8 + 0x12), *(undefined8 *)(puVar8 + 0x14), 0);
    puVar9[1] = puVar8[1];
    puVar10[1] = puVar8[1];
    puVar14[2] = puVar8[2] & 0x3f870;
    puVar8[2] = puVar8[2] & 0xfffc078f;
    puVar9[4] = puVar9[3] | puVar9[2] | puVar9[1];
    puVar10[4] = puVar10[3] | puVar10[2] | puVar10[1];
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if ((puVar14[4] & 0x800) != 0) {
        iVar6 = *(int64_t *)(puVar8 + 6);
        puVar9 = puVar8;
        while (iVar6 != 0) {
            puVar9 = *(undefined4 **)(puVar9 + 6);
            iVar6 = *(int64_t *)(puVar9 + 6);
        }
        *(undefined4 **)(puVar9 + 0x2a) = puVar14;
    }
    puVar2 = (undefined8 *)(puVar8 + 0x26);
    puVar8 = *(undefined4 **)(puVar8 + (uVar18 ^ 1) * 2 + 8);
    *(undefined8 *)(puVar8 + 0x26) = *puVar2;
code_r0x000180115b04:
    puVar8[2] = puVar8[2] & 0xffffdfff;
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if (puVar8 == arg2_00) {
        *(uint8_t *)((int64_t)puVar8 + 0xdd) = *(uint8_t *)((int64_t)puVar8 + 0xdd) | 2;
    } else {
        iVar13 = puVar8[0xc];
        if ((0 < iVar13) && (*(int64_t *)(puVar8 + 0x10) == 0)) {
            func_0x000180119020(puVar8);
            iVar13 = puVar8[0xc];
            iVar15 = 0;
            if (0 < iVar13) {
                do {
                    func_0x00018014ab80(*(undefined8 *)(puVar8 + 0x10), 0, 
                                        *(undefined8 *)(*(int64_t *)(puVar8 + 0xe) + (int64_t)iVar15 * 8));
                    iVar13 = puVar8[0xc];
                    iVar15 = iVar15 + 1;
                } while (iVar15 < iVar13);
            }
        }
        if (arg2_00 == (undefined4 *)0x0) {
            if (iVar5 != 0) {
                iVar13 = *(int32_t *)(iVar5 + 0x4d0);
                *(int64_t *)(puVar8 + 0x28) = iVar5;
                func_0x0001801162d0(puVar8, iVar5, 1);
                if (iVar13 != 0) {
                    func_0x00018011d570(iVar13, *puVar8);
                }
            }
        } else {
            if (*(int64_t *)(arg2_00 + 8) == 0) {
                uVar3 = *arg2_00;
                func_0x0001801167e0(puVar8, arg2_00);
                func_0x00018011d570(uVar3, *puVar8);
            } else {
                if (0 < iVar13) {
                    puVar9 = *(undefined4 **)(arg2_00 + 0x2c);
                    func_0x0001801167e0(puVar8, puVar9);
                    func_0x0001801167e0(puVar9, puVar8);
                    func_0x00018011d570(*puVar8, *puVar9);
                }
                if ((puVar8[4] & 0x800) != 0) {
                    iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, arg2_00[0x32]);
                    iVar6 = *(int64_t *)(iVar7 + 0x18);
                    iVar5 = iVar7;
                    while (iVar6 != 0) {
                        iVar5 = *(int64_t *)(iVar5 + 0x18);
                        iVar6 = *(int64_t *)(iVar5 + 0x18);
                    }
                    *(uint32_t *)(iVar7 + 8) = *(uint32_t *)(iVar7 + 8) | 0x800;
                    *(uint32_t *)(iVar7 + 0x10) =
                         *(uint32_t *)(iVar7 + 0xc) | *(uint32_t *)(iVar7 + 4) | *(uint32_t *)(iVar7 + 8);
                    puVar8[2] = puVar8[2] & 0xfffff7ff;
                    puVar8[4] = puVar8[2] | puVar8[3] | puVar8[1];
                    *(int64_t *)(iVar5 + 0xa8) = iVar7;
                }
                iVar5 = *(int64_t *)(arg2_00 + 8);
                *(int64_t *)(puVar8 + 8) = iVar5;
                *(undefined8 *)(puVar8 + 10) = *(undefined8 *)(arg2_00 + 10);
                if (iVar5 != 0) {
                    *(undefined4 **)(iVar5 + 0x18) = puVar8;
                }
                if (*(int64_t *)(puVar8 + 10) != 0) {
                    *(undefined4 **)(*(int64_t *)(puVar8 + 10) + 0x18) = puVar8;
                }
                puVar8[0x18] = arg2_00[0x18];
                *(undefined8 *)(puVar8 + 0x16) = *(undefined8 *)(arg2_00 + 0x16);
                *(undefined8 *)(arg2_00 + 10) = 0;
                *(undefined8 *)(arg2_00 + 8) = 0;
            }
            if (*(int64_t *)(arg2_00 + 0x26) != 0) {
                *(undefined8 *)(*(int64_t *)(arg2_00 + 0x26) + 0x4c8) = 0;
            }
            iVar5 = *(int64_t *)(arg2_00 + 6);
            if (iVar5 == 0) {
                fcn.1801152b0(arg1, (int64_t)arg2_00);
            } else {
                puVar9 = *(undefined4 **)(iVar5 + 0x20);
                if (puVar9 == arg2_00) {
                    puVar9 = *(undefined4 **)(iVar5 + 0x28);
                }
                func_0x00018011af70(arg1, iVar5, puVar9);
            }
        }
    }
    if (*(int64_t *)(puVar8 + 0x10) != 0) {
        *(int32_t *)(*(int64_t *)(puVar8 + 0x10) + 0x24) = (int32_t)var_18h;
    }
    if (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    return;
}

// ============================================================
// Function: FUN_180115a01
// Address: 0x180115a01
// Size: 297 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180115650(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    uint32_t *puVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    undefined4 *puVar14;
    undefined4 *arg2_00;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    uint64_t uVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    int64_t var_18h;
    uint32_t uStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    puVar8 = *(undefined4 **)(arg2 + 0x10);
    iVar5 = *(int64_t *)(arg2 + 0x18);
    iVar6 = *(int64_t *)(arg2 + 8);
    var_18h._0_4_ = 0;
    if (iVar5 == 0) {
        arg2_00 = (undefined4 *)0x0;
    } else {
        arg2_00 = *(undefined4 **)(iVar5 + 0x4c8);
        *(undefined8 *)(iVar5 + 0x4c8) = 0;
        if (arg2_00 == (undefined4 *)0x0) {
            var_18h._0_4_ = *(int32_t *)(iVar5 + 200);
        } else if (*(int64_t *)(arg2_00 + 8) == 0) {
            var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x24);
            if ((int32_t)var_18h == 0) {
                var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x20);
            }
        }
    }
    iVar13 = 1;
    if (puVar8 == (undefined4 *)0x0) {
        iVar15 = 1;
        iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar8 = (undefined4 *)0x0;
        } else {
            puVar8 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(arg1 + 0x28e8, *puVar8, puVar8);
        *(undefined8 *)(puVar8 + 0x12) = *(undefined8 *)(iVar6 + 0x60);
        *(undefined8 *)(puVar8 + 0x14) = *(undefined8 *)(iVar6 + 0x68);
        if (*(int64_t *)(iVar6 + 0x4c8) == 0) {
            func_0x0001801162d0(puVar8, iVar6, 1);
            puVar1 = (uint32_t *)(*(int64_t *)(*(int64_t *)(puVar8 + 0x10) + 0x10) + 4);
            *puVar1 = *puVar1 & 0xff7fffff;
            *(uint8_t *)(iVar6 + 0x495) = *(uint8_t *)(iVar6 + 0x495) | 1;
        }
    }
    iVar6 = *(int64_t *)0x180781f28;
    uVar16 = *(uint32_t *)(arg2 + 0x20);
    if (uVar16 == 0xffffffff) goto code_r0x000180115b04;
    iVar15 = 1;
    if (uVar16 < 2) {
        uStackX_20 = 0;
        if (uVar16 != 0) goto code_r0x0001801157ce;
code_r0x0001801157d8:
        uVar16 = 1;
    } else {
        uStackX_20 = 1;
code_r0x0001801157ce:
        if (uVar16 == 2) goto code_r0x0001801157d8;
        uVar16 = 0;
    }
    fVar20 = *(float *)(arg2 + 0x24);
    if ((arg2_00 == (undefined4 *)0x0) || (uVar16 == 0)) {
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar9 = (undefined4 *)0x0;
        } else {
            puVar9 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(iVar17, *puVar9, puVar9);
        *(undefined4 **)(puVar9 + 6) = puVar8;
        if (arg2_00 != (undefined4 *)0x0) goto code_r0x00018011587e;
code_r0x000180115888:
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar13 = iVar13 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar13);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar10 = (undefined4 *)0x0;
        } else {
            puVar10 = (undefined4 *)fcn.1801161f0(iVar7, iVar13);
        }
        func_0x0001800f6220(iVar17, *puVar10, puVar10);
    } else {
        *(undefined4 **)(arg2_00 + 6) = puVar8;
        puVar9 = arg2_00;
code_r0x00018011587e:
        puVar10 = arg2_00;
        if (uVar16 == 1) goto code_r0x000180115888;
    }
    *(undefined4 **)(puVar10 + 6) = puVar8;
    iVar7 = *(int64_t *)(puVar8 + 8);
    puVar14 = puVar10;
    if (uVar16 == 0) {
        puVar14 = puVar9;
    }
    *(int64_t *)(puVar14 + 8) = iVar7;
    *(undefined8 *)(puVar14 + 10) = *(undefined8 *)(puVar8 + 10);
    if (iVar7 != 0) {
        *(undefined4 **)(iVar7 + 0x18) = puVar14;
    }
    if (*(int64_t *)(puVar14 + 10) != 0) {
        *(undefined4 **)(*(int64_t *)(puVar14 + 10) + 0x18) = puVar14;
    }
    puVar14[0x18] = puVar8[0x18];
    *(undefined8 *)(puVar14 + 0x16) = *(undefined8 *)(puVar8 + 0x16);
    *(undefined4 **)(puVar8 + 8) = puVar9;
    *(undefined4 **)(puVar8 + 10) = puVar10;
    uVar18 = (uint64_t)uVar16;
    *(undefined8 *)(*(int64_t *)(puVar8 + uVar18 * 2 + 8) + 0xa0) = *(undefined8 *)(puVar8 + 0x28);
    puVar8[0x36] = puVar8[0x36] & 0xffffffc9;
    puVar8[0x36] = puVar8[0x36] | 9;
    uVar3 = puVar8[0x15];
    puVar8[0x18] = uStackX_20;
    uVar11 = (uint64_t)uStackX_20;
    *(undefined8 *)(puVar8 + 0x28) = 0;
    fVar19 = *(float *)(iVar6 + 0xdb8 + uVar11 * 4);
    fVar21 = (float)puVar8[uVar11 + 0x14] - *(float *)(iVar6 + 0xebc);
    fVar19 = fVar19 + fVar19;
    if (fVar21 <= fVar19) {
        fVar21 = fVar19;
    }
    uVar4 = puVar8[0x14];
    puVar10[0x16] = uVar4;
    puVar10[0x17] = uVar3;
    puVar9[0x16] = uVar4;
    puVar9[0x17] = uVar3;
    fVar20 = (float)(int32_t)(fVar21 * fVar20);
    puVar9[uVar11 + 0x16] = fVar20;
    puVar10[uVar11 + 0x16] = (float)(int32_t)(fVar21 - fVar20);
    func_0x0001801167e0(*(undefined8 *)(puVar8 + uVar18 * 2 + 8), puVar8);
    func_0x00018011d570(*puVar8, **(undefined4 **)(puVar8 + uVar18 * 2 + 8));
    iVar6 = *(int64_t *)(puVar8 + 6);
    puVar12 = puVar8;
    while (iVar6 != 0) {
        puVar12 = *(undefined4 **)(puVar12 + 6);
        iVar6 = *(int64_t *)(puVar12 + 6);
    }
    *(uint8_t *)(puVar12 + 0x37) = *(uint8_t *)(puVar12 + 0x37) & 0xdf;
    if (*(int64_t *)(puVar12 + 8) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 10) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 6) == 0) {
        for (iVar6 = *(int64_t *)(puVar12 + 0x2a); iVar6 != 0; iVar6 = *(int64_t *)(iVar6 + 0x18)) {
            *(uint8_t *)(iVar6 + 0xdc) = *(uint8_t *)(iVar6 + 0xdc) | 0x20;
        }
    }
    func_0x00018011b1e0(puVar8, *(undefined8 *)(puVar8 + 0x12), *(undefined8 *)(puVar8 + 0x14), 0);
    puVar9[1] = puVar8[1];
    puVar10[1] = puVar8[1];
    puVar14[2] = puVar8[2] & 0x3f870;
    puVar8[2] = puVar8[2] & 0xfffc078f;
    puVar9[4] = puVar9[3] | puVar9[2] | puVar9[1];
    puVar10[4] = puVar10[3] | puVar10[2] | puVar10[1];
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if ((puVar14[4] & 0x800) != 0) {
        iVar6 = *(int64_t *)(puVar8 + 6);
        puVar9 = puVar8;
        while (iVar6 != 0) {
            puVar9 = *(undefined4 **)(puVar9 + 6);
            iVar6 = *(int64_t *)(puVar9 + 6);
        }
        *(undefined4 **)(puVar9 + 0x2a) = puVar14;
    }
    puVar2 = (undefined8 *)(puVar8 + 0x26);
    puVar8 = *(undefined4 **)(puVar8 + (uVar18 ^ 1) * 2 + 8);
    *(undefined8 *)(puVar8 + 0x26) = *puVar2;
code_r0x000180115b04:
    puVar8[2] = puVar8[2] & 0xffffdfff;
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if (puVar8 == arg2_00) {
        *(uint8_t *)((int64_t)puVar8 + 0xdd) = *(uint8_t *)((int64_t)puVar8 + 0xdd) | 2;
    } else {
        iVar13 = puVar8[0xc];
        if ((0 < iVar13) && (*(int64_t *)(puVar8 + 0x10) == 0)) {
            func_0x000180119020(puVar8);
            iVar13 = puVar8[0xc];
            iVar15 = 0;
            if (0 < iVar13) {
                do {
                    func_0x00018014ab80(*(undefined8 *)(puVar8 + 0x10), 0, 
                                        *(undefined8 *)(*(int64_t *)(puVar8 + 0xe) + (int64_t)iVar15 * 8));
                    iVar13 = puVar8[0xc];
                    iVar15 = iVar15 + 1;
                } while (iVar15 < iVar13);
            }
        }
        if (arg2_00 == (undefined4 *)0x0) {
            if (iVar5 != 0) {
                iVar13 = *(int32_t *)(iVar5 + 0x4d0);
                *(int64_t *)(puVar8 + 0x28) = iVar5;
                func_0x0001801162d0(puVar8, iVar5, 1);
                if (iVar13 != 0) {
                    func_0x00018011d570(iVar13, *puVar8);
                }
            }
        } else {
            if (*(int64_t *)(arg2_00 + 8) == 0) {
                uVar3 = *arg2_00;
                func_0x0001801167e0(puVar8, arg2_00);
                func_0x00018011d570(uVar3, *puVar8);
            } else {
                if (0 < iVar13) {
                    puVar9 = *(undefined4 **)(arg2_00 + 0x2c);
                    func_0x0001801167e0(puVar8, puVar9);
                    func_0x0001801167e0(puVar9, puVar8);
                    func_0x00018011d570(*puVar8, *puVar9);
                }
                if ((puVar8[4] & 0x800) != 0) {
                    iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, arg2_00[0x32]);
                    iVar6 = *(int64_t *)(iVar7 + 0x18);
                    iVar5 = iVar7;
                    while (iVar6 != 0) {
                        iVar5 = *(int64_t *)(iVar5 + 0x18);
                        iVar6 = *(int64_t *)(iVar5 + 0x18);
                    }
                    *(uint32_t *)(iVar7 + 8) = *(uint32_t *)(iVar7 + 8) | 0x800;
                    *(uint32_t *)(iVar7 + 0x10) =
                         *(uint32_t *)(iVar7 + 0xc) | *(uint32_t *)(iVar7 + 4) | *(uint32_t *)(iVar7 + 8);
                    puVar8[2] = puVar8[2] & 0xfffff7ff;
                    puVar8[4] = puVar8[2] | puVar8[3] | puVar8[1];
                    *(int64_t *)(iVar5 + 0xa8) = iVar7;
                }
                iVar5 = *(int64_t *)(arg2_00 + 8);
                *(int64_t *)(puVar8 + 8) = iVar5;
                *(undefined8 *)(puVar8 + 10) = *(undefined8 *)(arg2_00 + 10);
                if (iVar5 != 0) {
                    *(undefined4 **)(iVar5 + 0x18) = puVar8;
                }
                if (*(int64_t *)(puVar8 + 10) != 0) {
                    *(undefined4 **)(*(int64_t *)(puVar8 + 10) + 0x18) = puVar8;
                }
                puVar8[0x18] = arg2_00[0x18];
                *(undefined8 *)(puVar8 + 0x16) = *(undefined8 *)(arg2_00 + 0x16);
                *(undefined8 *)(arg2_00 + 10) = 0;
                *(undefined8 *)(arg2_00 + 8) = 0;
            }
            if (*(int64_t *)(arg2_00 + 0x26) != 0) {
                *(undefined8 *)(*(int64_t *)(arg2_00 + 0x26) + 0x4c8) = 0;
            }
            iVar5 = *(int64_t *)(arg2_00 + 6);
            if (iVar5 == 0) {
                fcn.1801152b0(arg1, (int64_t)arg2_00);
            } else {
                puVar9 = *(undefined4 **)(iVar5 + 0x20);
                if (puVar9 == arg2_00) {
                    puVar9 = *(undefined4 **)(iVar5 + 0x28);
                }
                func_0x00018011af70(arg1, iVar5, puVar9);
            }
        }
    }
    if (*(int64_t *)(puVar8 + 0x10) != 0) {
        *(int32_t *)(*(int64_t *)(puVar8 + 0x10) + 0x24) = (int32_t)var_18h;
    }
    if (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    return;
}

// ============================================================
// Function: FUN_180115b2a
// Address: 0x180115b2a
// Size: 497 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180115650(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    uint32_t *puVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    undefined4 *puVar14;
    undefined4 *arg2_00;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    uint64_t uVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    int64_t var_18h;
    uint32_t uStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    puVar8 = *(undefined4 **)(arg2 + 0x10);
    iVar5 = *(int64_t *)(arg2 + 0x18);
    iVar6 = *(int64_t *)(arg2 + 8);
    var_18h._0_4_ = 0;
    if (iVar5 == 0) {
        arg2_00 = (undefined4 *)0x0;
    } else {
        arg2_00 = *(undefined4 **)(iVar5 + 0x4c8);
        *(undefined8 *)(iVar5 + 0x4c8) = 0;
        if (arg2_00 == (undefined4 *)0x0) {
            var_18h._0_4_ = *(int32_t *)(iVar5 + 200);
        } else if (*(int64_t *)(arg2_00 + 8) == 0) {
            var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x24);
            if ((int32_t)var_18h == 0) {
                var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x20);
            }
        }
    }
    iVar13 = 1;
    if (puVar8 == (undefined4 *)0x0) {
        iVar15 = 1;
        iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar8 = (undefined4 *)0x0;
        } else {
            puVar8 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(arg1 + 0x28e8, *puVar8, puVar8);
        *(undefined8 *)(puVar8 + 0x12) = *(undefined8 *)(iVar6 + 0x60);
        *(undefined8 *)(puVar8 + 0x14) = *(undefined8 *)(iVar6 + 0x68);
        if (*(int64_t *)(iVar6 + 0x4c8) == 0) {
            func_0x0001801162d0(puVar8, iVar6, 1);
            puVar1 = (uint32_t *)(*(int64_t *)(*(int64_t *)(puVar8 + 0x10) + 0x10) + 4);
            *puVar1 = *puVar1 & 0xff7fffff;
            *(uint8_t *)(iVar6 + 0x495) = *(uint8_t *)(iVar6 + 0x495) | 1;
        }
    }
    iVar6 = *(int64_t *)0x180781f28;
    uVar16 = *(uint32_t *)(arg2 + 0x20);
    if (uVar16 == 0xffffffff) goto code_r0x000180115b04;
    iVar15 = 1;
    if (uVar16 < 2) {
        uStackX_20 = 0;
        if (uVar16 != 0) goto code_r0x0001801157ce;
code_r0x0001801157d8:
        uVar16 = 1;
    } else {
        uStackX_20 = 1;
code_r0x0001801157ce:
        if (uVar16 == 2) goto code_r0x0001801157d8;
        uVar16 = 0;
    }
    fVar20 = *(float *)(arg2 + 0x24);
    if ((arg2_00 == (undefined4 *)0x0) || (uVar16 == 0)) {
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar9 = (undefined4 *)0x0;
        } else {
            puVar9 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(iVar17, *puVar9, puVar9);
        *(undefined4 **)(puVar9 + 6) = puVar8;
        if (arg2_00 != (undefined4 *)0x0) goto code_r0x00018011587e;
code_r0x000180115888:
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar13 = iVar13 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar13);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar10 = (undefined4 *)0x0;
        } else {
            puVar10 = (undefined4 *)fcn.1801161f0(iVar7, iVar13);
        }
        func_0x0001800f6220(iVar17, *puVar10, puVar10);
    } else {
        *(undefined4 **)(arg2_00 + 6) = puVar8;
        puVar9 = arg2_00;
code_r0x00018011587e:
        puVar10 = arg2_00;
        if (uVar16 == 1) goto code_r0x000180115888;
    }
    *(undefined4 **)(puVar10 + 6) = puVar8;
    iVar7 = *(int64_t *)(puVar8 + 8);
    puVar14 = puVar10;
    if (uVar16 == 0) {
        puVar14 = puVar9;
    }
    *(int64_t *)(puVar14 + 8) = iVar7;
    *(undefined8 *)(puVar14 + 10) = *(undefined8 *)(puVar8 + 10);
    if (iVar7 != 0) {
        *(undefined4 **)(iVar7 + 0x18) = puVar14;
    }
    if (*(int64_t *)(puVar14 + 10) != 0) {
        *(undefined4 **)(*(int64_t *)(puVar14 + 10) + 0x18) = puVar14;
    }
    puVar14[0x18] = puVar8[0x18];
    *(undefined8 *)(puVar14 + 0x16) = *(undefined8 *)(puVar8 + 0x16);
    *(undefined4 **)(puVar8 + 8) = puVar9;
    *(undefined4 **)(puVar8 + 10) = puVar10;
    uVar18 = (uint64_t)uVar16;
    *(undefined8 *)(*(int64_t *)(puVar8 + uVar18 * 2 + 8) + 0xa0) = *(undefined8 *)(puVar8 + 0x28);
    puVar8[0x36] = puVar8[0x36] & 0xffffffc9;
    puVar8[0x36] = puVar8[0x36] | 9;
    uVar3 = puVar8[0x15];
    puVar8[0x18] = uStackX_20;
    uVar11 = (uint64_t)uStackX_20;
    *(undefined8 *)(puVar8 + 0x28) = 0;
    fVar19 = *(float *)(iVar6 + 0xdb8 + uVar11 * 4);
    fVar21 = (float)puVar8[uVar11 + 0x14] - *(float *)(iVar6 + 0xebc);
    fVar19 = fVar19 + fVar19;
    if (fVar21 <= fVar19) {
        fVar21 = fVar19;
    }
    uVar4 = puVar8[0x14];
    puVar10[0x16] = uVar4;
    puVar10[0x17] = uVar3;
    puVar9[0x16] = uVar4;
    puVar9[0x17] = uVar3;
    fVar20 = (float)(int32_t)(fVar21 * fVar20);
    puVar9[uVar11 + 0x16] = fVar20;
    puVar10[uVar11 + 0x16] = (float)(int32_t)(fVar21 - fVar20);
    func_0x0001801167e0(*(undefined8 *)(puVar8 + uVar18 * 2 + 8), puVar8);
    func_0x00018011d570(*puVar8, **(undefined4 **)(puVar8 + uVar18 * 2 + 8));
    iVar6 = *(int64_t *)(puVar8 + 6);
    puVar12 = puVar8;
    while (iVar6 != 0) {
        puVar12 = *(undefined4 **)(puVar12 + 6);
        iVar6 = *(int64_t *)(puVar12 + 6);
    }
    *(uint8_t *)(puVar12 + 0x37) = *(uint8_t *)(puVar12 + 0x37) & 0xdf;
    if (*(int64_t *)(puVar12 + 8) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 10) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 6) == 0) {
        for (iVar6 = *(int64_t *)(puVar12 + 0x2a); iVar6 != 0; iVar6 = *(int64_t *)(iVar6 + 0x18)) {
            *(uint8_t *)(iVar6 + 0xdc) = *(uint8_t *)(iVar6 + 0xdc) | 0x20;
        }
    }
    func_0x00018011b1e0(puVar8, *(undefined8 *)(puVar8 + 0x12), *(undefined8 *)(puVar8 + 0x14), 0);
    puVar9[1] = puVar8[1];
    puVar10[1] = puVar8[1];
    puVar14[2] = puVar8[2] & 0x3f870;
    puVar8[2] = puVar8[2] & 0xfffc078f;
    puVar9[4] = puVar9[3] | puVar9[2] | puVar9[1];
    puVar10[4] = puVar10[3] | puVar10[2] | puVar10[1];
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if ((puVar14[4] & 0x800) != 0) {
        iVar6 = *(int64_t *)(puVar8 + 6);
        puVar9 = puVar8;
        while (iVar6 != 0) {
            puVar9 = *(undefined4 **)(puVar9 + 6);
            iVar6 = *(int64_t *)(puVar9 + 6);
        }
        *(undefined4 **)(puVar9 + 0x2a) = puVar14;
    }
    puVar2 = (undefined8 *)(puVar8 + 0x26);
    puVar8 = *(undefined4 **)(puVar8 + (uVar18 ^ 1) * 2 + 8);
    *(undefined8 *)(puVar8 + 0x26) = *puVar2;
code_r0x000180115b04:
    puVar8[2] = puVar8[2] & 0xffffdfff;
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if (puVar8 == arg2_00) {
        *(uint8_t *)((int64_t)puVar8 + 0xdd) = *(uint8_t *)((int64_t)puVar8 + 0xdd) | 2;
    } else {
        iVar13 = puVar8[0xc];
        if ((0 < iVar13) && (*(int64_t *)(puVar8 + 0x10) == 0)) {
            func_0x000180119020(puVar8);
            iVar13 = puVar8[0xc];
            iVar15 = 0;
            if (0 < iVar13) {
                do {
                    func_0x00018014ab80(*(undefined8 *)(puVar8 + 0x10), 0, 
                                        *(undefined8 *)(*(int64_t *)(puVar8 + 0xe) + (int64_t)iVar15 * 8));
                    iVar13 = puVar8[0xc];
                    iVar15 = iVar15 + 1;
                } while (iVar15 < iVar13);
            }
        }
        if (arg2_00 == (undefined4 *)0x0) {
            if (iVar5 != 0) {
                iVar13 = *(int32_t *)(iVar5 + 0x4d0);
                *(int64_t *)(puVar8 + 0x28) = iVar5;
                func_0x0001801162d0(puVar8, iVar5, 1);
                if (iVar13 != 0) {
                    func_0x00018011d570(iVar13, *puVar8);
                }
            }
        } else {
            if (*(int64_t *)(arg2_00 + 8) == 0) {
                uVar3 = *arg2_00;
                func_0x0001801167e0(puVar8, arg2_00);
                func_0x00018011d570(uVar3, *puVar8);
            } else {
                if (0 < iVar13) {
                    puVar9 = *(undefined4 **)(arg2_00 + 0x2c);
                    func_0x0001801167e0(puVar8, puVar9);
                    func_0x0001801167e0(puVar9, puVar8);
                    func_0x00018011d570(*puVar8, *puVar9);
                }
                if ((puVar8[4] & 0x800) != 0) {
                    iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, arg2_00[0x32]);
                    iVar6 = *(int64_t *)(iVar7 + 0x18);
                    iVar5 = iVar7;
                    while (iVar6 != 0) {
                        iVar5 = *(int64_t *)(iVar5 + 0x18);
                        iVar6 = *(int64_t *)(iVar5 + 0x18);
                    }
                    *(uint32_t *)(iVar7 + 8) = *(uint32_t *)(iVar7 + 8) | 0x800;
                    *(uint32_t *)(iVar7 + 0x10) =
                         *(uint32_t *)(iVar7 + 0xc) | *(uint32_t *)(iVar7 + 4) | *(uint32_t *)(iVar7 + 8);
                    puVar8[2] = puVar8[2] & 0xfffff7ff;
                    puVar8[4] = puVar8[2] | puVar8[3] | puVar8[1];
                    *(int64_t *)(iVar5 + 0xa8) = iVar7;
                }
                iVar5 = *(int64_t *)(arg2_00 + 8);
                *(int64_t *)(puVar8 + 8) = iVar5;
                *(undefined8 *)(puVar8 + 10) = *(undefined8 *)(arg2_00 + 10);
                if (iVar5 != 0) {
                    *(undefined4 **)(iVar5 + 0x18) = puVar8;
                }
                if (*(int64_t *)(puVar8 + 10) != 0) {
                    *(undefined4 **)(*(int64_t *)(puVar8 + 10) + 0x18) = puVar8;
                }
                puVar8[0x18] = arg2_00[0x18];
                *(undefined8 *)(puVar8 + 0x16) = *(undefined8 *)(arg2_00 + 0x16);
                *(undefined8 *)(arg2_00 + 10) = 0;
                *(undefined8 *)(arg2_00 + 8) = 0;
            }
            if (*(int64_t *)(arg2_00 + 0x26) != 0) {
                *(undefined8 *)(*(int64_t *)(arg2_00 + 0x26) + 0x4c8) = 0;
            }
            iVar5 = *(int64_t *)(arg2_00 + 6);
            if (iVar5 == 0) {
                fcn.1801152b0(arg1, (int64_t)arg2_00);
            } else {
                puVar9 = *(undefined4 **)(iVar5 + 0x20);
                if (puVar9 == arg2_00) {
                    puVar9 = *(undefined4 **)(iVar5 + 0x28);
                }
                func_0x00018011af70(arg1, iVar5, puVar9);
            }
        }
    }
    if (*(int64_t *)(puVar8 + 0x10) != 0) {
        *(int32_t *)(*(int64_t *)(puVar8 + 0x10) + 0x24) = (int32_t)var_18h;
    }
    if (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    return;
}

// ============================================================
// Function: FUN_180115d1b
// Address: 0x180115d1b
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180115650(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    uint32_t *puVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int32_t iVar13;
    undefined4 *puVar14;
    undefined4 *arg2_00;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    uint64_t uVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    int64_t var_18h;
    uint32_t uStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    puVar8 = *(undefined4 **)(arg2 + 0x10);
    iVar5 = *(int64_t *)(arg2 + 0x18);
    iVar6 = *(int64_t *)(arg2 + 8);
    var_18h._0_4_ = 0;
    if (iVar5 == 0) {
        arg2_00 = (undefined4 *)0x0;
    } else {
        arg2_00 = *(undefined4 **)(iVar5 + 0x4c8);
        *(undefined8 *)(iVar5 + 0x4c8) = 0;
        if (arg2_00 == (undefined4 *)0x0) {
            var_18h._0_4_ = *(int32_t *)(iVar5 + 200);
        } else if (*(int64_t *)(arg2_00 + 8) == 0) {
            var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x24);
            if ((int32_t)var_18h == 0) {
                var_18h._0_4_ = *(int32_t *)(*(int64_t *)(arg2_00 + 0x10) + 0x20);
            }
        }
    }
    iVar13 = 1;
    if (puVar8 == (undefined4 *)0x0) {
        iVar15 = 1;
        iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar8 = (undefined4 *)0x0;
        } else {
            puVar8 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(arg1 + 0x28e8, *puVar8, puVar8);
        *(undefined8 *)(puVar8 + 0x12) = *(undefined8 *)(iVar6 + 0x60);
        *(undefined8 *)(puVar8 + 0x14) = *(undefined8 *)(iVar6 + 0x68);
        if (*(int64_t *)(iVar6 + 0x4c8) == 0) {
            func_0x0001801162d0(puVar8, iVar6, 1);
            puVar1 = (uint32_t *)(*(int64_t *)(*(int64_t *)(puVar8 + 0x10) + 0x10) + 4);
            *puVar1 = *puVar1 & 0xff7fffff;
            *(uint8_t *)(iVar6 + 0x495) = *(uint8_t *)(iVar6 + 0x495) | 1;
        }
    }
    iVar6 = *(int64_t *)0x180781f28;
    uVar16 = *(uint32_t *)(arg2 + 0x20);
    if (uVar16 == 0xffffffff) goto code_r0x000180115b04;
    iVar15 = 1;
    if (uVar16 < 2) {
        uStackX_20 = 0;
        if (uVar16 != 0) goto code_r0x0001801157ce;
code_r0x0001801157d8:
        uVar16 = 1;
    } else {
        uStackX_20 = 1;
code_r0x0001801157ce:
        if (uVar16 == 2) goto code_r0x0001801157d8;
        uVar16 = 0;
    }
    fVar20 = *(float *)(arg2 + 0x24);
    if ((arg2_00 == (undefined4 *)0x0) || (uVar16 == 0)) {
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar15 = iVar15 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar15);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar9 = (undefined4 *)0x0;
        } else {
            puVar9 = (undefined4 *)fcn.1801161f0(iVar7, iVar15);
        }
        func_0x0001800f6220(iVar17, *puVar9, puVar9);
        *(undefined4 **)(puVar9 + 6) = puVar8;
        if (arg2_00 != (undefined4 *)0x0) goto code_r0x00018011587e;
code_r0x000180115888:
        iVar17 = arg1 + 0x28e8;
        iVar7 = func_0x0001800f60f0(iVar17, 1);
        while (iVar7 != 0) {
            iVar13 = iVar13 + 1;
            iVar7 = func_0x0001800f60f0(iVar17, iVar13);
        }
        iVar7 = func_0x00018046d050(0xe0);
        if (iVar7 == 0) {
            puVar10 = (undefined4 *)0x0;
        } else {
            puVar10 = (undefined4 *)fcn.1801161f0(iVar7, iVar13);
        }
        func_0x0001800f6220(iVar17, *puVar10, puVar10);
    } else {
        *(undefined4 **)(arg2_00 + 6) = puVar8;
        puVar9 = arg2_00;
code_r0x00018011587e:
        puVar10 = arg2_00;
        if (uVar16 == 1) goto code_r0x000180115888;
    }
    *(undefined4 **)(puVar10 + 6) = puVar8;
    iVar7 = *(int64_t *)(puVar8 + 8);
    puVar14 = puVar10;
    if (uVar16 == 0) {
        puVar14 = puVar9;
    }
    *(int64_t *)(puVar14 + 8) = iVar7;
    *(undefined8 *)(puVar14 + 10) = *(undefined8 *)(puVar8 + 10);
    if (iVar7 != 0) {
        *(undefined4 **)(iVar7 + 0x18) = puVar14;
    }
    if (*(int64_t *)(puVar14 + 10) != 0) {
        *(undefined4 **)(*(int64_t *)(puVar14 + 10) + 0x18) = puVar14;
    }
    puVar14[0x18] = puVar8[0x18];
    *(undefined8 *)(puVar14 + 0x16) = *(undefined8 *)(puVar8 + 0x16);
    *(undefined4 **)(puVar8 + 8) = puVar9;
    *(undefined4 **)(puVar8 + 10) = puVar10;
    uVar18 = (uint64_t)uVar16;
    *(undefined8 *)(*(int64_t *)(puVar8 + uVar18 * 2 + 8) + 0xa0) = *(undefined8 *)(puVar8 + 0x28);
    puVar8[0x36] = puVar8[0x36] & 0xffffffc9;
    puVar8[0x36] = puVar8[0x36] | 9;
    uVar3 = puVar8[0x15];
    puVar8[0x18] = uStackX_20;
    uVar11 = (uint64_t)uStackX_20;
    *(undefined8 *)(puVar8 + 0x28) = 0;
    fVar19 = *(float *)(iVar6 + 0xdb8 + uVar11 * 4);
    fVar21 = (float)puVar8[uVar11 + 0x14] - *(float *)(iVar6 + 0xebc);
    fVar19 = fVar19 + fVar19;
    if (fVar21 <= fVar19) {
        fVar21 = fVar19;
    }
    uVar4 = puVar8[0x14];
    puVar10[0x16] = uVar4;
    puVar10[0x17] = uVar3;
    puVar9[0x16] = uVar4;
    puVar9[0x17] = uVar3;
    fVar20 = (float)(int32_t)(fVar21 * fVar20);
    puVar9[uVar11 + 0x16] = fVar20;
    puVar10[uVar11 + 0x16] = (float)(int32_t)(fVar21 - fVar20);
    func_0x0001801167e0(*(undefined8 *)(puVar8 + uVar18 * 2 + 8), puVar8);
    func_0x00018011d570(*puVar8, **(undefined4 **)(puVar8 + uVar18 * 2 + 8));
    iVar6 = *(int64_t *)(puVar8 + 6);
    puVar12 = puVar8;
    while (iVar6 != 0) {
        puVar12 = *(undefined4 **)(puVar12 + 6);
        iVar6 = *(int64_t *)(puVar12 + 6);
    }
    *(uint8_t *)(puVar12 + 0x37) = *(uint8_t *)(puVar12 + 0x37) & 0xdf;
    if (*(int64_t *)(puVar12 + 8) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 10) != 0) {
        func_0x000180116c40();
    }
    if (*(int64_t *)(puVar12 + 6) == 0) {
        for (iVar6 = *(int64_t *)(puVar12 + 0x2a); iVar6 != 0; iVar6 = *(int64_t *)(iVar6 + 0x18)) {
            *(uint8_t *)(iVar6 + 0xdc) = *(uint8_t *)(iVar6 + 0xdc) | 0x20;
        }
    }
    func_0x00018011b1e0(puVar8, *(undefined8 *)(puVar8 + 0x12), *(undefined8 *)(puVar8 + 0x14), 0);
    puVar9[1] = puVar8[1];
    puVar10[1] = puVar8[1];
    puVar14[2] = puVar8[2] & 0x3f870;
    puVar8[2] = puVar8[2] & 0xfffc078f;
    puVar9[4] = puVar9[3] | puVar9[2] | puVar9[1];
    puVar10[4] = puVar10[3] | puVar10[2] | puVar10[1];
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if ((puVar14[4] & 0x800) != 0) {
        iVar6 = *(int64_t *)(puVar8 + 6);
        puVar9 = puVar8;
        while (iVar6 != 0) {
            puVar9 = *(undefined4 **)(puVar9 + 6);
            iVar6 = *(int64_t *)(puVar9 + 6);
        }
        *(undefined4 **)(puVar9 + 0x2a) = puVar14;
    }
    puVar2 = (undefined8 *)(puVar8 + 0x26);
    puVar8 = *(undefined4 **)(puVar8 + (uVar18 ^ 1) * 2 + 8);
    *(undefined8 *)(puVar8 + 0x26) = *puVar2;
code_r0x000180115b04:
    puVar8[2] = puVar8[2] & 0xffffdfff;
    puVar8[4] = puVar8[3] | puVar8[1] | puVar8[2];
    if (puVar8 == arg2_00) {
        *(uint8_t *)((int64_t)puVar8 + 0xdd) = *(uint8_t *)((int64_t)puVar8 + 0xdd) | 2;
    } else {
        iVar13 = puVar8[0xc];
        if ((0 < iVar13) && (*(int64_t *)(puVar8 + 0x10) == 0)) {
            func_0x000180119020(puVar8);
            iVar13 = puVar8[0xc];
            iVar15 = 0;
            if (0 < iVar13) {
                do {
                    func_0x00018014ab80(*(undefined8 *)(puVar8 + 0x10), 0, 
                                        *(undefined8 *)(*(int64_t *)(puVar8 + 0xe) + (int64_t)iVar15 * 8));
                    iVar13 = puVar8[0xc];
                    iVar15 = iVar15 + 1;
                } while (iVar15 < iVar13);
            }
        }
        if (arg2_00 == (undefined4 *)0x0) {
            if (iVar5 != 0) {
                iVar13 = *(int32_t *)(iVar5 + 0x4d0);
                *(int64_t *)(puVar8 + 0x28) = iVar5;
                func_0x0001801162d0(puVar8, iVar5, 1);
                if (iVar13 != 0) {
                    func_0x00018011d570(iVar13, *puVar8);
                }
            }
        } else {
            if (*(int64_t *)(arg2_00 + 8) == 0) {
                uVar3 = *arg2_00;
                func_0x0001801167e0(puVar8, arg2_00);
                func_0x00018011d570(uVar3, *puVar8);
            } else {
                if (0 < iVar13) {
                    puVar9 = *(undefined4 **)(arg2_00 + 0x2c);
                    func_0x0001801167e0(puVar8, puVar9);
                    func_0x0001801167e0(puVar9, puVar8);
                    func_0x00018011d570(*puVar8, *puVar9);
                }
                if ((puVar8[4] & 0x800) != 0) {
                    iVar7 = func_0x0001800f60f0(arg1 + 0x28e8, arg2_00[0x32]);
                    iVar6 = *(int64_t *)(iVar7 + 0x18);
                    iVar5 = iVar7;
                    while (iVar6 != 0) {
                        iVar5 = *(int64_t *)(iVar5 + 0x18);
                        iVar6 = *(int64_t *)(iVar5 + 0x18);
                    }
                    *(uint32_t *)(iVar7 + 8) = *(uint32_t *)(iVar7 + 8) | 0x800;
                    *(uint32_t *)(iVar7 + 0x10) =
                         *(uint32_t *)(iVar7 + 0xc) | *(uint32_t *)(iVar7 + 4) | *(uint32_t *)(iVar7 + 8);
                    puVar8[2] = puVar8[2] & 0xfffff7ff;
                    puVar8[4] = puVar8[2] | puVar8[3] | puVar8[1];
                    *(int64_t *)(iVar5 + 0xa8) = iVar7;
                }
                iVar5 = *(int64_t *)(arg2_00 + 8);
                *(int64_t *)(puVar8 + 8) = iVar5;
                *(undefined8 *)(puVar8 + 10) = *(undefined8 *)(arg2_00 + 10);
                if (iVar5 != 0) {
                    *(undefined4 **)(iVar5 + 0x18) = puVar8;
                }
                if (*(int64_t *)(puVar8 + 10) != 0) {
                    *(undefined4 **)(*(int64_t *)(puVar8 + 10) + 0x18) = puVar8;
                }
                puVar8[0x18] = arg2_00[0x18];
                *(undefined8 *)(puVar8 + 0x16) = *(undefined8 *)(arg2_00 + 0x16);
                *(undefined8 *)(arg2_00 + 10) = 0;
                *(undefined8 *)(arg2_00 + 8) = 0;
            }
            if (*(int64_t *)(arg2_00 + 0x26) != 0) {
                *(undefined8 *)(*(int64_t *)(arg2_00 + 0x26) + 0x4c8) = 0;
            }
            iVar5 = *(int64_t *)(arg2_00 + 6);
            if (iVar5 == 0) {
                fcn.1801152b0(arg1, (int64_t)arg2_00);
            } else {
                puVar9 = *(undefined4 **)(iVar5 + 0x20);
                if (puVar9 == arg2_00) {
                    puVar9 = *(undefined4 **)(iVar5 + 0x28);
                }
                func_0x00018011af70(arg1, iVar5, puVar9);
            }
        }
    }
    if (*(int64_t *)(puVar8 + 0x10) != 0) {
        *(int32_t *)(*(int64_t *)(puVar8 + 0x10) + 0x24) = (int32_t)var_18h;
    }
    if (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    return;
}

// ============================================================
// Function: FUN_180115d50
// Address: 0x180115d50
// Size: 323 bytes
// ============================================================
void fcn.180115d50(undefined8 placeholder_0, int64_t arg2)
{
    float fVar1;
    int16_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char in_R8B;
    float fVar5;
    float fVar6;
    
    iVar4 = *(int64_t *)(arg2 + 0x4c0);
    if (iVar4 == 0) {
        *(undefined4 *)(arg2 + 0x4d0) = 0;
    } else if (in_R8B == '\0') {
        func_0x000180116490(iVar4, arg2, *(undefined4 *)(arg2 + 0x4d0));
    } else {
        func_0x000180116490(iVar4, arg2, 0);
    }
    *(uint8_t *)(arg2 + 0x495) = *(uint8_t *)(arg2 + 0x495) & 0xf8;
    iVar3 = *(int64_t *)0x180781f28;
    iVar4 = *(int64_t *)(arg2 + 0x48);
    *(undefined *)(arg2 + 0x10c) = 0;
    if (iVar4 == 0) {
        fVar5 = *(float *)(arg2 + 0x70);
        fVar6 = *(float *)(arg2 + 0x74);
    } else {
        if ((*(uint32_t *)(iVar3 + 0x12cc) & 0x400) == 0) {
            fVar1 = *(float *)(iVar4 + 0x2c);
            fVar6 = *(float *)(iVar4 + 0x28);
        } else {
            iVar2 = *(int16_t *)(iVar4 + 0xaa);
            if ((iVar2 < 0) || (*(int32_t *)(iVar3 + 0xd60) <= (int32_t)iVar2)) {
                iVar4 = iVar3 + 0x2180;
            } else {
                iVar4 = (int64_t)iVar2 * 0x30 + *(int64_t *)(iVar3 + 0xd68);
            }
            fVar6 = *(float *)(iVar4 + 0x18);
            fVar1 = *(float *)(iVar4 + 0x1c);
        }
        fVar5 = *(float *)(arg2 + 0x70);
        if ((float)(int32_t)(fVar6 * 0.9) <= *(float *)(arg2 + 0x70)) {
            fVar5 = (float)(int32_t)(fVar6 * 0.9);
        }
        fVar6 = *(float *)(arg2 + 0x74);
        if ((float)(int32_t)(fVar1 * 0.9) <= *(float *)(arg2 + 0x74)) {
            fVar6 = (float)(int32_t)(fVar1 * 0.9);
        }
    }
    *(float *)(arg2 + 0x70) = fVar5;
    *(float *)(arg2 + 0x68) = fVar5;
    *(float *)(arg2 + 0x74) = fVar6;
    *(float *)(arg2 + 0x6c) = fVar6;
    if (*(float *)(iVar3 + 0x292c) <= 0.0) {
        *(undefined4 *)(iVar3 + 0x292c) = *(undefined4 *)(iVar3 + 0x4c);
    }
    return;
}

// ============================================================
// Function: FUN_180115ea0
// Address: 0x180115ea0
// Size: 4 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180115ea0(int64_t arg1, int64_t arg2, int64_t arg_1b8h, int64_t arg_1c0h)
{
    int64_t *piVar1;
    float fVar2;
    int16_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    float fVar13;
    float fVar14;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar9 = *(int64_t *)(arg2 + 0x18);
    if ((iVar9 == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) != 0)) {
        arg1 = arg1 + 0x28e8;
        iVar10 = 1;
        iVar9 = func_0x0001800f60f0(arg1, 1);
        while (iVar9 != 0) {
            iVar10 = iVar10 + 1;
            iVar9 = func_0x0001800f60f0(arg1, iVar10);
        }
        iVar9 = func_0x00018046d050(0xe0);
        puVar6 = (undefined4 *)0x0;
        if (iVar9 != 0) {
            puVar6 = (undefined4 *)fcn.1801161f0(iVar9, iVar10);
        }
        func_0x0001800f6220(arg1, *puVar6, puVar6);
        *(undefined8 *)(puVar6 + 0x12) = *(undefined8 *)(arg2 + 0x48);
        *(undefined8 *)(puVar6 + 0x14) = *(undefined8 *)(arg2 + 0x50);
        *(undefined8 *)(puVar6 + 0x16) = *(undefined8 *)(arg2 + 0x58);
        func_0x0001801167e0(puVar6, arg2);
        func_0x00018011d570(*(undefined4 *)arg2, *puVar6);
    } else {
        iVar5 = 0x20;
        uVar12 = 0x28;
        if (*(int64_t *)(iVar9 + 0x20) != arg2) {
            iVar5 = 0x28;
            uVar12 = 0x20;
        }
        *(undefined8 *)(iVar5 + iVar9) = 0;
        func_0x00018011af70(arg1, *(int64_t *)(arg2 + 0x18), 
                            *(undefined8 *)((uint64_t)uVar12 + *(int64_t *)(arg2 + 0x18)));
        *(uint32_t *)(*(int64_t *)(arg2 + 0x18) + 0xd8) =
             *(uint32_t *)(*(int64_t *)(arg2 + 0x18) + 0xd8) & 0xfffffebf | 0x80;
        *(undefined8 *)(arg2 + 0x18) = 0;
        puVar6 = (undefined4 *)arg2;
    }
    piVar11 = *(int64_t **)(puVar6 + 0xe);
    piVar1 = piVar11 + (int32_t)puVar6[0xc];
    do {
        if (piVar11 == piVar1) {
            puVar6[0x36] = puVar6[0x36] & 0xffffffc9;
            puVar6[0x36] = puVar6[0x36] | 9;
            iVar5 = *(int64_t *)0x180781f28;
            iVar9 = *(int64_t *)(**(int64_t **)(puVar6 + 0xe) + 0x48);
            if (iVar9 == 0) {
                fVar13 = (float)puVar6[0x14];
                fVar14 = (float)puVar6[0x15];
            } else {
                if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x12cc) & 0x400) == 0) {
                    fVar2 = *(float *)(iVar9 + 0x2c);
                    fVar14 = *(float *)(iVar9 + 0x28);
                } else {
                    iVar3 = *(int16_t *)(iVar9 + 0xaa);
                    if ((iVar3 < 0) || (*(int32_t *)(*(int64_t *)0x180781f28 + 0xd60) <= (int32_t)iVar3)) {
                        iVar9 = *(int64_t *)0x180781f28 + 0x2180;
                    } else {
                        iVar9 = (int64_t)iVar3 * 0x30 + *(int64_t *)(*(int64_t *)0x180781f28 + 0xd68);
                    }
                    fVar14 = *(float *)(iVar9 + 0x18);
                    fVar2 = *(float *)(iVar9 + 0x1c);
                }
                fVar13 = (float)puVar6[0x14];
                if ((float)(int32_t)(fVar14 * 0.9) <= (float)puVar6[0x14]) {
                    fVar13 = (float)(int32_t)(fVar14 * 0.9);
                }
                fVar14 = (float)puVar6[0x15];
                if ((float)(int32_t)(fVar2 * 0.9) <= (float)puVar6[0x15]) {
                    fVar14 = (float)(int32_t)(fVar2 * 0.9);
                }
            }
            *(uint8_t *)((int64_t)puVar6 + 0xdd) = *(uint8_t *)((int64_t)puVar6 + 0xdd) | 1;
            puVar6[0x14] = fVar13;
            puVar6[0x15] = fVar14;
            if (*(float *)(iVar5 + 0x292c) <= 0.0) {
                *(undefined4 *)(iVar5 + 0x292c) = *(undefined4 *)(iVar5 + 0x4c);
            }
            return;
        }
        iVar9 = *piVar11;
        *(uint32_t *)(iVar9 + 0x14) = *(uint32_t *)(iVar9 + 0x14) & 0xfeffffff;
        iVar5 = *(int64_t *)(iVar9 + 0x408);
        if (iVar5 != 0) {
            piVar4 = *(int64_t **)(iVar5 + 0x1f8);
            for (piVar7 = piVar4; piVar7 < piVar4 + *(int32_t *)(iVar5 + 0x1f0); piVar7 = piVar7 + 1) {
                if (*piVar7 == iVar9) {
                    iVar8 = (int64_t)piVar7 - (int64_t)piVar4 >> 3;
                    func_0x000180498030(piVar4 + iVar8, piVar4 + iVar8 + 1, 
                                        (*(int32_t *)(iVar5 + 0x1f0) - iVar8) * 8 + -8);
                    *(int32_t *)(iVar5 + 0x1f0) = *(int32_t *)(iVar5 + 0x1f0) + -1;
                    break;
                }
            }
        }
        piVar4 = (int64_t *)(iVar9 + 0x438);
        *(undefined8 *)(iVar9 + 0x408) = 0;
        *piVar4 = iVar9;
        *(int64_t *)(iVar9 + 0x430) = iVar9;
        *(int64_t *)(iVar9 + 0x428) = iVar9;
        *(int64_t *)(iVar9 + 0x420) = iVar9;
        *(int64_t *)(iVar9 + 0x418) = iVar9;
        uVar12 = *(uint32_t *)(iVar9 + 0x1c);
        while ((uVar12 & 0x100) != 0) {
            iVar9 = *(int64_t *)(iVar9 + 0x408);
            *piVar4 = iVar9;
            uVar12 = *(uint32_t *)(iVar9 + 0x1c);
        }
        piVar11 = piVar11 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_180115ea4
// Address: 0x180115ea4
// Size: 300 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180115ea0(int64_t arg1, int64_t arg2, int64_t arg_1b8h, int64_t arg_1c0h)
{
    int64_t *piVar1;
    float fVar2;
    int16_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    float fVar13;
    float fVar14;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar9 = *(int64_t *)(arg2 + 0x18);
    if ((iVar9 == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) != 0)) {
        arg1 = arg1 + 0x28e8;
        iVar10 = 1;
        iVar9 = func_0x0001800f60f0(arg1, 1);
        while (iVar9 != 0) {
            iVar10 = iVar10 + 1;
            iVar9 = func_0x0001800f60f0(arg1, iVar10);
        }
        iVar9 = func_0x00018046d050(0xe0);
        puVar6 = (undefined4 *)0x0;
        if (iVar9 != 0) {
            puVar6 = (undefined4 *)fcn.1801161f0(iVar9, iVar10);
        }
        func_0x0001800f6220(arg1, *puVar6, puVar6);
        *(undefined8 *)(puVar6 + 0x12) = *(undefined8 *)(arg2 + 0x48);
        *(undefined8 *)(puVar6 + 0x14) = *(undefined8 *)(arg2 + 0x50);
        *(undefined8 *)(puVar6 + 0x16) = *(undefined8 *)(arg2 + 0x58);
        func_0x0001801167e0(puVar6, arg2);
        func_0x00018011d570(*(undefined4 *)arg2, *puVar6);
    } else {
        iVar5 = 0x20;
        uVar12 = 0x28;
        if (*(int64_t *)(iVar9 + 0x20) != arg2) {
            iVar5 = 0x28;
            uVar12 = 0x20;
        }
        *(undefined8 *)(iVar5 + iVar9) = 0;
        func_0x00018011af70(arg1, *(int64_t *)(arg2 + 0x18), 
                            *(undefined8 *)((uint64_t)uVar12 + *(int64_t *)(arg2 + 0x18)));
        *(uint32_t *)(*(int64_t *)(arg2 + 0x18) + 0xd8) =
             *(uint32_t *)(*(int64_t *)(arg2 + 0x18) + 0xd8) & 0xfffffebf | 0x80;
        *(undefined8 *)(arg2 + 0x18) = 0;
        puVar6 = (undefined4 *)arg2;
    }
    piVar11 = *(int64_t **)(puVar6 + 0xe);
    piVar1 = piVar11 + (int32_t)puVar6[0xc];
    do {
        if (piVar11 == piVar1) {
            puVar6[0x36] = puVar6[0x36] & 0xffffffc9;
            puVar6[0x36] = puVar6[0x36] | 9;
            iVar5 = *(int64_t *)0x180781f28;
            iVar9 = *(int64_t *)(**(int64_t **)(puVar6 + 0xe) + 0x48);
            if (iVar9 == 0) {
                fVar13 = (float)puVar6[0x14];
                fVar14 = (float)puVar6[0x15];
            } else {
                if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x12cc) & 0x400) == 0) {
                    fVar2 = *(float *)(iVar9 + 0x2c);
                    fVar14 = *(float *)(iVar9 + 0x28);
                } else {
                    iVar3 = *(int16_t *)(iVar9 + 0xaa);
                    if ((iVar3 < 0) || (*(int32_t *)(*(int64_t *)0x180781f28 + 0xd60) <= (int32_t)iVar3)) {
                        iVar9 = *(int64_t *)0x180781f28 + 0x2180;
                    } else {
                        iVar9 = (int64_t)iVar3 * 0x30 + *(int64_t *)(*(int64_t *)0x180781f28 + 0xd68);
                    }
                    fVar14 = *(float *)(iVar9 + 0x18);
                    fVar2 = *(float *)(iVar9 + 0x1c);
                }
                fVar13 = (float)puVar6[0x14];
                if ((float)(int32_t)(fVar14 * 0.9) <= (float)puVar6[0x14]) {
                    fVar13 = (float)(int32_t)(fVar14 * 0.9);
                }
                fVar14 = (float)puVar6[0x15];
                if ((float)(int32_t)(fVar2 * 0.9) <= (float)puVar6[0x15]) {
                    fVar14 = (float)(int32_t)(fVar2 * 0.9);
                }
            }
            *(uint8_t *)((int64_t)puVar6 + 0xdd) = *(uint8_t *)((int64_t)puVar6 + 0xdd) | 1;
            puVar6[0x14] = fVar13;
            puVar6[0x15] = fVar14;
            if (*(float *)(iVar5 + 0x292c) <= 0.0) {
                *(undefined4 *)(iVar5 + 0x292c) = *(undefined4 *)(iVar5 + 0x4c);
            }
            return;
        }
        iVar9 = *piVar11;
        *(uint32_t *)(iVar9 + 0x14) = *(uint32_t *)(iVar9 + 0x14) & 0xfeffffff;
        iVar5 = *(int64_t *)(iVar9 + 0x408);
        if (iVar5 != 0) {
            piVar4 = *(int64_t **)(iVar5 + 0x1f8);
            for (piVar7 = piVar4; piVar7 < piVar4 + *(int32_t *)(iVar5 + 0x1f0); piVar7 = piVar7 + 1) {
                if (*piVar7 == iVar9) {
                    iVar8 = (int64_t)piVar7 - (int64_t)piVar4 >> 3;
                    func_0x000180498030(piVar4 + iVar8, piVar4 + iVar8 + 1, 
                                        (*(int32_t *)(iVar5 + 0x1f0) - iVar8) * 8 + -8);
                    *(int32_t *)(iVar5 + 0x1f0) = *(int32_t *)(iVar5 + 0x1f0) + -1;
                    break;
                }
            }
        }
        piVar4 = (int64_t *)(iVar9 + 0x438);
        *(undefined8 *)(iVar9 + 0x408) = 0;
        *piVar4 = iVar9;
        *(int64_t *)(iVar9 + 0x430) = iVar9;
        *(int64_t *)(iVar9 + 0x428) = iVar9;
        *(int64_t *)(iVar9 + 0x420) = iVar9;
        *(int64_t *)(iVar9 + 0x418) = iVar9;
        uVar12 = *(uint32_t *)(iVar9 + 0x1c);
        while ((uVar12 & 0x100) != 0) {
            iVar9 = *(int64_t *)(iVar9 + 0x408);
            *piVar4 = iVar9;
            uVar12 = *(uint32_t *)(iVar9 + 0x1c);
        }
        piVar11 = piVar11 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_180115fd0
// Address: 0x180115fd0
// Size: 197 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180115ea0(int64_t arg1, int64_t arg2, int64_t arg_1b8h, int64_t arg_1c0h)
{
    int64_t *piVar1;
    float fVar2;
    int16_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    float fVar13;
    float fVar14;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar9 = *(int64_t *)(arg2 + 0x18);
    if ((iVar9 == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) != 0)) {
        arg1 = arg1 + 0x28e8;
        iVar10 = 1;
        iVar9 = func_0x0001800f60f0(arg1, 1);
        while (iVar9 != 0) {
            iVar10 = iVar10 + 1;
            iVar9 = func_0x0001800f60f0(arg1, iVar10);
        }
        iVar9 = func_0x00018046d050(0xe0);
        puVar6 = (undefined4 *)0x0;
        if (iVar9 != 0) {
            puVar6 = (undefined4 *)fcn.1801161f0(iVar9, iVar10);
        }
        func_0x0001800f6220(arg1, *puVar6, puVar6);
        *(undefined8 *)(puVar6 + 0x12) = *(undefined8 *)(arg2 + 0x48);
        *(undefined8 *)(puVar6 + 0x14) = *(undefined8 *)(arg2 + 0x50);
        *(undefined8 *)(puVar6 + 0x16) = *(undefined8 *)(arg2 + 0x58);
        func_0x0001801167e0(puVar6, arg2);
        func_0x00018011d570(*(undefined4 *)arg2, *puVar6);
    } else {
        iVar5 = 0x20;
        uVar12 = 0x28;
        if (*(int64_t *)(iVar9 + 0x20) != arg2) {
            iVar5 = 0x28;
            uVar12 = 0x20;
        }
        *(undefined8 *)(iVar5 + iVar9) = 0;
        func_0x00018011af70(arg1, *(int64_t *)(arg2 + 0x18), 
                            *(undefined8 *)((uint64_t)uVar12 + *(int64_t *)(arg2 + 0x18)));
        *(uint32_t *)(*(int64_t *)(arg2 + 0x18) + 0xd8) =
             *(uint32_t *)(*(int64_t *)(arg2 + 0x18) + 0xd8) & 0xfffffebf | 0x80;
        *(undefined8 *)(arg2 + 0x18) = 0;
        puVar6 = (undefined4 *)arg2;
    }
    piVar11 = *(int64_t **)(puVar6 + 0xe);
    piVar1 = piVar11 + (int32_t)puVar6[0xc];
    do {
        if (piVar11 == piVar1) {
            puVar6[0x36] = puVar6[0x36] & 0xffffffc9;
            puVar6[0x36] = puVar6[0x36] | 9;
            iVar5 = *(int64_t *)0x180781f28;
            iVar9 = *(int64_t *)(**(int64_t **)(puVar6 + 0xe) + 0x48);
            if (iVar9 == 0) {
                fVar13 = (float)puVar6[0x14];
                fVar14 = (float)puVar6[0x15];
            } else {
                if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x12cc) & 0x400) == 0) {
                    fVar2 = *(float *)(iVar9 + 0x2c);
                    fVar14 = *(float *)(iVar9 + 0x28);
                } else {
                    iVar3 = *(int16_t *)(iVar9 + 0xaa);
                    if ((iVar3 < 0) || (*(int32_t *)(*(int64_t *)0x180781f28 + 0xd60) <= (int32_t)iVar3)) {
                        iVar9 = *(int64_t *)0x180781f28 + 0x2180;
                    } else {
                        iVar9 = (int64_t)iVar3 * 0x30 + *(int64_t *)(*(int64_t *)0x180781f28 + 0xd68);
                    }
                    fVar14 = *(float *)(iVar9 + 0x18);
                    fVar2 = *(float *)(iVar9 + 0x1c);
                }
                fVar13 = (float)puVar6[0x14];
                if ((float)(int32_t)(fVar14 * 0.9) <= (float)puVar6[0x14]) {
                    fVar13 = (float)(int32_t)(fVar14 * 0.9);
                }
                fVar14 = (float)puVar6[0x15];
                if ((float)(int32_t)(fVar2 * 0.9) <= (float)puVar6[0x15]) {
                    fVar14 = (float)(int32_t)(fVar2 * 0.9);
                }
            }
            *(uint8_t *)((int64_t)puVar6 + 0xdd) = *(uint8_t *)((int64_t)puVar6 + 0xdd) | 1;
            puVar6[0x14] = fVar13;
            puVar6[0x15] = fVar14;
            if (*(float *)(iVar5 + 0x292c) <= 0.0) {
                *(undefined4 *)(iVar5 + 0x292c) = *(undefined4 *)(iVar5 + 0x4c);
            }
            return;
        }
        iVar9 = *piVar11;
        *(uint32_t *)(iVar9 + 0x14) = *(uint32_t *)(iVar9 + 0x14) & 0xfeffffff;
        iVar5 = *(int64_t *)(iVar9 + 0x408);
        if (iVar5 != 0) {
            piVar4 = *(int64_t **)(iVar5 + 0x1f8);
            for (piVar7 = piVar4; piVar7 < piVar4 + *(int32_t *)(iVar5 + 0x1f0); piVar7 = piVar7 + 1) {
                if (*piVar7 == iVar9) {
                    iVar8 = (int64_t)piVar7 - (int64_t)piVar4 >> 3;
                    func_0x000180498030(piVar4 + iVar8, piVar4 + iVar8 + 1, 
                                        (*(int32_t *)(iVar5 + 0x1f0) - iVar8) * 8 + -8);
                    *(int32_t *)(iVar5 + 0x1f0) = *(int32_t *)(iVar5 + 0x1f0) + -1;
                    break;
                }
            }
        }
        piVar4 = (int64_t *)(iVar9 + 0x438);
        *(undefined8 *)(iVar9 + 0x408) = 0;
        *piVar4 = iVar9;
        *(int64_t *)(iVar9 + 0x430) = iVar9;
        *(int64_t *)(iVar9 + 0x428) = iVar9;
        *(int64_t *)(iVar9 + 0x420) = iVar9;
        *(int64_t *)(iVar9 + 0x418) = iVar9;
        uVar12 = *(uint32_t *)(iVar9 + 0x1c);
        while ((uVar12 & 0x100) != 0) {
            iVar9 = *(int64_t *)(iVar9 + 0x408);
            *piVar4 = iVar9;
            uVar12 = *(uint32_t *)(iVar9 + 0x1c);
        }
        piVar11 = piVar11 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_180116095
// Address: 0x180116095
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180115ea0(int64_t arg1, int64_t arg2, int64_t arg_1b8h, int64_t arg_1c0h)
{
    int64_t *piVar1;
    float fVar2;
    int16_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    float fVar13;
    float fVar14;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar9 = *(int64_t *)(arg2 + 0x18);
    if ((iVar9 == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) != 0)) {
        arg1 = arg1 + 0x28e8;
        iVar10 = 1;
        iVar9 = func_0x0001800f60f0(arg1, 1);
        while (iVar9 != 0) {
            iVar10 = iVar10 + 1;
            iVar9 = func_0x0001800f60f0(arg1, iVar10);
        }
        iVar9 = func_0x00018046d050(0xe0);
        puVar6 = (undefined4 *)0x0;
        if (iVar9 != 0) {
            puVar6 = (undefined4 *)fcn.1801161f0(iVar9, iVar10);
        }
        func_0x0001800f6220(arg1, *puVar6, puVar6);
        *(undefined8 *)(puVar6 + 0x12) = *(undefined8 *)(arg2 + 0x48);
        *(undefined8 *)(puVar6 + 0x14) = *(undefined8 *)(arg2 + 0x50);
        *(undefined8 *)(puVar6 + 0x16) = *(undefined8 *)(arg2 + 0x58);
        func_0x0001801167e0(puVar6, arg2);
        func_0x00018011d570(*(undefined4 *)arg2, *puVar6);
    } else {
        iVar5 = 0x20;
        uVar12 = 0x28;
        if (*(int64_t *)(iVar9 + 0x20) != arg2) {
            iVar5 = 0x28;
            uVar12 = 0x20;
        }
        *(undefined8 *)(iVar5 + iVar9) = 0;
        func_0x00018011af70(arg1, *(int64_t *)(arg2 + 0x18), 
                            *(undefined8 *)((uint64_t)uVar12 + *(int64_t *)(arg2 + 0x18)));
        *(uint32_t *)(*(int64_t *)(arg2 + 0x18) + 0xd8) =
             *(uint32_t *)(*(int64_t *)(arg2 + 0x18) + 0xd8) & 0xfffffebf | 0x80;
        *(undefined8 *)(arg2 + 0x18) = 0;
        puVar6 = (undefined4 *)arg2;
    }
    piVar11 = *(int64_t **)(puVar6 + 0xe);
    piVar1 = piVar11 + (int32_t)puVar6[0xc];
    do {
        if (piVar11 == piVar1) {
            puVar6[0x36] = puVar6[0x36] & 0xffffffc9;
            puVar6[0x36] = puVar6[0x36] | 9;
            iVar5 = *(int64_t *)0x180781f28;
            iVar9 = *(int64_t *)(**(int64_t **)(puVar6 + 0xe) + 0x48);
            if (iVar9 == 0) {
                fVar13 = (float)puVar6[0x14];
                fVar14 = (float)puVar6[0x15];
            } else {
                if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x12cc) & 0x400) == 0) {
                    fVar2 = *(float *)(iVar9 + 0x2c);
                    fVar14 = *(float *)(iVar9 + 0x28);
                } else {
                    iVar3 = *(int16_t *)(iVar9 + 0xaa);
                    if ((iVar3 < 0) || (*(int32_t *)(*(int64_t *)0x180781f28 + 0xd60) <= (int32_t)iVar3)) {
                        iVar9 = *(int64_t *)0x180781f28 + 0x2180;
                    } else {
                        iVar9 = (int64_t)iVar3 * 0x30 + *(int64_t *)(*(int64_t *)0x180781f28 + 0xd68);
                    }
                    fVar14 = *(float *)(iVar9 + 0x18);
                    fVar2 = *(float *)(iVar9 + 0x1c);
                }
                fVar13 = (float)puVar6[0x14];
                if ((float)(int32_t)(fVar14 * 0.9) <= (float)puVar6[0x14]) {
                    fVar13 = (float)(int32_t)(fVar14 * 0.9);
                }
                fVar14 = (float)puVar6[0x15];
                if ((float)(int32_t)(fVar2 * 0.9) <= (float)puVar6[0x15]) {
                    fVar14 = (float)(int32_t)(fVar2 * 0.9);
                }
            }
            *(uint8_t *)((int64_t)puVar6 + 0xdd) = *(uint8_t *)((int64_t)puVar6 + 0xdd) | 1;
            puVar6[0x14] = fVar13;
            puVar6[0x15] = fVar14;
            if (*(float *)(iVar5 + 0x292c) <= 0.0) {
                *(undefined4 *)(iVar5 + 0x292c) = *(undefined4 *)(iVar5 + 0x4c);
            }
            return;
        }
        iVar9 = *piVar11;
        *(uint32_t *)(iVar9 + 0x14) = *(uint32_t *)(iVar9 + 0x14) & 0xfeffffff;
        iVar5 = *(int64_t *)(iVar9 + 0x408);
        if (iVar5 != 0) {
            piVar4 = *(int64_t **)(iVar5 + 0x1f8);
            for (piVar7 = piVar4; piVar7 < piVar4 + *(int32_t *)(iVar5 + 0x1f0); piVar7 = piVar7 + 1) {
                if (*piVar7 == iVar9) {
                    iVar8 = (int64_t)piVar7 - (int64_t)piVar4 >> 3;
                    func_0x000180498030(piVar4 + iVar8, piVar4 + iVar8 + 1, 
                                        (*(int32_t *)(iVar5 + 0x1f0) - iVar8) * 8 + -8);
                    *(int32_t *)(iVar5 + 0x1f0) = *(int32_t *)(iVar5 + 0x1f0) + -1;
                    break;
                }
            }
        }
        piVar4 = (int64_t *)(iVar9 + 0x438);
        *(undefined8 *)(iVar9 + 0x408) = 0;
        *piVar4 = iVar9;
        *(int64_t *)(iVar9 + 0x430) = iVar9;
        *(int64_t *)(iVar9 + 0x428) = iVar9;
        *(int64_t *)(iVar9 + 0x420) = iVar9;
        *(int64_t *)(iVar9 + 0x418) = iVar9;
        uVar12 = *(uint32_t *)(iVar9 + 0x1c);
        while ((uVar12 & 0x100) != 0) {
            iVar9 = *(int64_t *)(iVar9 + 0x408);
            *piVar4 = iVar9;
            uVar12 = *(uint32_t *)(iVar9 + 0x1c);
        }
        piVar11 = piVar11 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1801160ce
// Address: 0x1801160ce
// Size: 218 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180115ea0(int64_t arg1, int64_t arg2, int64_t arg_1b8h, int64_t arg_1c0h)
{
    int64_t *piVar1;
    float fVar2;
    int16_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    float fVar13;
    float fVar14;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar9 = *(int64_t *)(arg2 + 0x18);
    if ((iVar9 == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) != 0)) {
        arg1 = arg1 + 0x28e8;
        iVar10 = 1;
        iVar9 = func_0x0001800f60f0(arg1, 1);
        while (iVar9 != 0) {
            iVar10 = iVar10 + 1;
            iVar9 = func_0x0001800f60f0(arg1, iVar10);
        }
        iVar9 = func_0x00018046d050(0xe0);
        puVar6 = (undefined4 *)0x0;
        if (iVar9 != 0) {
            puVar6 = (undefined4 *)fcn.1801161f0(iVar9, iVar10);
        }
        func_0x0001800f6220(arg1, *puVar6, puVar6);
        *(undefined8 *)(puVar6 + 0x12) = *(undefined8 *)(arg2 + 0x48);
        *(undefined8 *)(puVar6 + 0x14) = *(undefined8 *)(arg2 + 0x50);
        *(undefined8 *)(puVar6 + 0x16) = *(undefined8 *)(arg2 + 0x58);
        func_0x0001801167e0(puVar6, arg2);
        func_0x00018011d570(*(undefined4 *)arg2, *puVar6);
    } else {
        iVar5 = 0x20;
        uVar12 = 0x28;
        if (*(int64_t *)(iVar9 + 0x20) != arg2) {
            iVar5 = 0x28;
            uVar12 = 0x20;
        }
        *(undefined8 *)(iVar5 + iVar9) = 0;
        func_0x00018011af70(arg1, *(int64_t *)(arg2 + 0x18), 
                            *(undefined8 *)((uint64_t)uVar12 + *(int64_t *)(arg2 + 0x18)));
        *(uint32_t *)(*(int64_t *)(arg2 + 0x18) + 0xd8) =
             *(uint32_t *)(*(int64_t *)(arg2 + 0x18) + 0xd8) & 0xfffffebf | 0x80;
        *(undefined8 *)(arg2 + 0x18) = 0;
        puVar6 = (undefined4 *)arg2;
    }
    piVar11 = *(int64_t **)(puVar6 + 0xe);
    piVar1 = piVar11 + (int32_t)puVar6[0xc];
    do {
        if (piVar11 == piVar1) {
            puVar6[0x36] = puVar6[0x36] & 0xffffffc9;
            puVar6[0x36] = puVar6[0x36] | 9;
            iVar5 = *(int64_t *)0x180781f28;
            iVar9 = *(int64_t *)(**(int64_t **)(puVar6 + 0xe) + 0x48);
            if (iVar9 == 0) {
                fVar13 = (float)puVar6[0x14];
                fVar14 = (float)puVar6[0x15];
            } else {
                if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x12cc) & 0x400) == 0) {
                    fVar2 = *(float *)(iVar9 + 0x2c);
                    fVar14 = *(float *)(iVar9 + 0x28);
                } else {
                    iVar3 = *(int16_t *)(iVar9 + 0xaa);
                    if ((iVar3 < 0) || (*(int32_t *)(*(int64_t *)0x180781f28 + 0xd60) <= (int32_t)iVar3)) {
                        iVar9 = *(int64_t *)0x180781f28 + 0x2180;
                    } else {
                        iVar9 = (int64_t)iVar3 * 0x30 + *(int64_t *)(*(int64_t *)0x180781f28 + 0xd68);
                    }
                    fVar14 = *(float *)(iVar9 + 0x18);
                    fVar2 = *(float *)(iVar9 + 0x1c);
                }
                fVar13 = (float)puVar6[0x14];
                if ((float)(int32_t)(fVar14 * 0.9) <= (float)puVar6[0x14]) {
                    fVar13 = (float)(int32_t)(fVar14 * 0.9);
                }
                fVar14 = (float)puVar6[0x15];
                if ((float)(int32_t)(fVar2 * 0.9) <= (float)puVar6[0x15]) {
                    fVar14 = (float)(int32_t)(fVar2 * 0.9);
                }
            }
            *(uint8_t *)((int64_t)puVar6 + 0xdd) = *(uint8_t *)((int64_t)puVar6 + 0xdd) | 1;
            puVar6[0x14] = fVar13;
            puVar6[0x15] = fVar14;
            if (*(float *)(iVar5 + 0x292c) <= 0.0) {
                *(undefined4 *)(iVar5 + 0x292c) = *(undefined4 *)(iVar5 + 0x4c);
            }
            return;
        }
        iVar9 = *piVar11;
        *(uint32_t *)(iVar9 + 0x14) = *(uint32_t *)(iVar9 + 0x14) & 0xfeffffff;
        iVar5 = *(int64_t *)(iVar9 + 0x408);
        if (iVar5 != 0) {
            piVar4 = *(int64_t **)(iVar5 + 0x1f8);
            for (piVar7 = piVar4; piVar7 < piVar4 + *(int32_t *)(iVar5 + 0x1f0); piVar7 = piVar7 + 1) {
                if (*piVar7 == iVar9) {
                    iVar8 = (int64_t)piVar7 - (int64_t)piVar4 >> 3;
                    func_0x000180498030(piVar4 + iVar8, piVar4 + iVar8 + 1, 
                                        (*(int32_t *)(iVar5 + 0x1f0) - iVar8) * 8 + -8);
                    *(int32_t *)(iVar5 + 0x1f0) = *(int32_t *)(iVar5 + 0x1f0) + -1;
                    break;
                }
            }
        }
        piVar4 = (int64_t *)(iVar9 + 0x438);
        *(undefined8 *)(iVar9 + 0x408) = 0;
        *piVar4 = iVar9;
        *(int64_t *)(iVar9 + 0x430) = iVar9;
        *(int64_t *)(iVar9 + 0x428) = iVar9;
        *(int64_t *)(iVar9 + 0x420) = iVar9;
        *(int64_t *)(iVar9 + 0x418) = iVar9;
        uVar12 = *(uint32_t *)(iVar9 + 0x1c);
        while ((uVar12 & 0x100) != 0) {
            iVar9 = *(int64_t *)(iVar9 + 0x408);
            *piVar4 = iVar9;
            uVar12 = *(uint32_t *)(iVar9 + 0x1c);
        }
        piVar11 = piVar11 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1801161a8
// Address: 0x1801161a8
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180115ea0(int64_t arg1, int64_t arg2, int64_t arg_1b8h, int64_t arg_1c0h)
{
    int64_t *piVar1;
    float fVar2;
    int16_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    float fVar13;
    float fVar14;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_8h;
    
    iVar9 = *(int64_t *)(arg2 + 0x18);
    if ((iVar9 == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) != 0)) {
        arg1 = arg1 + 0x28e8;
        iVar10 = 1;
        iVar9 = func_0x0001800f60f0(arg1, 1);
        while (iVar9 != 0) {
            iVar10 = iVar10 + 1;
            iVar9 = func_0x0001800f60f0(arg1, iVar10);
        }
        iVar9 = func_0x00018046d050(0xe0);
        puVar6 = (undefined4 *)0x0;
        if (iVar9 != 0) {
            puVar6 = (undefined4 *)fcn.1801161f0(iVar9, iVar10);
        }
        func_0x0001800f6220(arg1, *puVar6, puVar6);
        *(undefined8 *)(puVar6 + 0x12) = *(undefined8 *)(arg2 + 0x48);
        *(undefined8 *)(puVar6 + 0x14) = *(undefined8 *)(arg2 + 0x50);
        *(undefined8 *)(puVar6 + 0x16) = *(undefined8 *)(arg2 + 0x58);
        func_0x0001801167e0(puVar6, arg2);
        func_0x00018011d570(*(undefined4 *)arg2, *puVar6);
    } else {
        iVar5 = 0x20;
        uVar12 = 0x28;
        if (*(int64_t *)(iVar9 + 0x20) != arg2) {
            iVar5 = 0x28;
            uVar12 = 0x20;
        }
        *(undefined8 *)(iVar5 + iVar9) = 0;
        func_0x00018011af70(arg1, *(int64_t *)(arg2 + 0x18), 
                            *(undefined8 *)((uint64_t)uVar12 + *(int64_t *)(arg2 + 0x18)));
        *(uint32_t *)(*(int64_t *)(arg2 + 0x18) + 0xd8) =
             *(uint32_t *)(*(int64_t *)(arg2 + 0x18) + 0xd8) & 0xfffffebf | 0x80;
        *(undefined8 *)(arg2 + 0x18) = 0;
        puVar6 = (undefined4 *)arg2;
    }
    piVar11 = *(int64_t **)(puVar6 + 0xe);
    piVar1 = piVar11 + (int32_t)puVar6[0xc];
    do {
        if (piVar11 == piVar1) {
            puVar6[0x36] = puVar6[0x36] & 0xffffffc9;
            puVar6[0x36] = puVar6[0x36] | 9;
            iVar5 = *(int64_t *)0x180781f28;
            iVar9 = *(int64_t *)(**(int64_t **)(puVar6 + 0xe) + 0x48);
            if (iVar9 == 0) {
                fVar13 = (float)puVar6[0x14];
                fVar14 = (float)puVar6[0x15];
            } else {
                if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x12cc) & 0x400) == 0) {
                    fVar2 = *(float *)(iVar9 + 0x2c);
                    fVar14 = *(float *)(iVar9 + 0x28);
                } else {
                    iVar3 = *(int16_t *)(iVar9 + 0xaa);
                    if ((iVar3 < 0) || (*(int32_t *)(*(int64_t *)0x180781f28 + 0xd60) <= (int32_t)iVar3)) {
                        iVar9 = *(int64_t *)0x180781f28 + 0x2180;
                    } else {
                        iVar9 = (int64_t)iVar3 * 0x30 + *(int64_t *)(*(int64_t *)0x180781f28 + 0xd68);
                    }
                    fVar14 = *(float *)(iVar9 + 0x18);
                    fVar2 = *(float *)(iVar9 + 0x1c);
                }
                fVar13 = (float)puVar6[0x14];
                if ((float)(int32_t)(fVar14 * 0.9) <= (float)puVar6[0x14]) {
                    fVar13 = (float)(int32_t)(fVar14 * 0.9);
                }
                fVar14 = (float)puVar6[0x15];
                if ((float)(int32_t)(fVar2 * 0.9) <= (float)puVar6[0x15]) {
                    fVar14 = (float)(int32_t)(fVar2 * 0.9);
                }
            }
            *(uint8_t *)((int64_t)puVar6 + 0xdd) = *(uint8_t *)((int64_t)puVar6 + 0xdd) | 1;
            puVar6[0x14] = fVar13;
            puVar6[0x15] = fVar14;
            if (*(float *)(iVar5 + 0x292c) <= 0.0) {
                *(undefined4 *)(iVar5 + 0x292c) = *(undefined4 *)(iVar5 + 0x4c);
            }
            return;
        }
        iVar9 = *piVar11;
        *(uint32_t *)(iVar9 + 0x14) = *(uint32_t *)(iVar9 + 0x14) & 0xfeffffff;
        iVar5 = *(int64_t *)(iVar9 + 0x408);
        if (iVar5 != 0) {
            piVar4 = *(int64_t **)(iVar5 + 0x1f8);
            for (piVar7 = piVar4; piVar7 < piVar4 + *(int32_t *)(iVar5 + 0x1f0); piVar7 = piVar7 + 1) {
                if (*piVar7 == iVar9) {
                    iVar8 = (int64_t)piVar7 - (int64_t)piVar4 >> 3;
                    func_0x000180498030(piVar4 + iVar8, piVar4 + iVar8 + 1, 
                                        (*(int32_t *)(iVar5 + 0x1f0) - iVar8) * 8 + -8);
                    *(int32_t *)(iVar5 + 0x1f0) = *(int32_t *)(iVar5 + 0x1f0) + -1;
                    break;
                }
            }
        }
        piVar4 = (int64_t *)(iVar9 + 0x438);
        *(undefined8 *)(iVar9 + 0x408) = 0;
        *piVar4 = iVar9;
        *(int64_t *)(iVar9 + 0x430) = iVar9;
        *(int64_t *)(iVar9 + 0x428) = iVar9;
        *(int64_t *)(iVar9 + 0x420) = iVar9;
        *(int64_t *)(iVar9 + 0x418) = iVar9;
        uVar12 = *(uint32_t *)(iVar9 + 0x1c);
        while ((uVar12 & 0x100) != 0) {
            iVar9 = *(int64_t *)(iVar9 + 0x408);
            *piVar4 = iVar9;
            uVar12 = *(uint32_t *)(iVar9 + 0x1c);
        }
        piVar11 = piVar11 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1801161c0
// Address: 0x1801161c0
// Size: 34 bytes
// ============================================================
void fcn.1801161c0(int64_t arg1)
{
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    if (*(int64_t *)(arg1 + 0x38) != 0) {
        fcn.180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_1801162d0
// Address: 0x1801162d0
// Size: 448 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_4c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_495h because it doesn't fit into ProtoModel

void fcn.1801162d0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    char in_R8B;
    int32_t iVar4;
    int64_t var_14h;
    
    if (*(int64_t *)(arg2 + 0x4c0) != 0) {
        func_0x000180116490(*(int64_t *)(arg2 + 0x4c0), arg2, 0);
    }
    if (((*(int64_t *)(arg1 + 0x98) == 0) && (*(int32_t *)(arg1 + 0x30) == 1)) &&
       (iVar1 = **(int64_t **)(arg1 + 0x38), *(char *)(iVar1 + 0x10a) == '\0')) {
        *(undefined *)(iVar1 + 0x111) = 1;
        *(char *)(iVar1 + 299) = (*(char *)(iVar1 + 0x109) == '\0') + '\x01';
    }
    iVar2 = *(int32_t *)(arg1 + 0x34);
    if (*(int32_t *)(arg1 + 0x30) == iVar2) {
        iVar4 = *(int32_t *)(arg1 + 0x30) + 1;
        if (iVar2 == 0) {
            iVar2 = 8;
        } else {
            iVar2 = iVar2 / 2 + iVar2;
        }
        if (iVar4 < iVar2) {
            iVar4 = iVar2;
        }
        func_0x00018011f4f0(arg1 + 0x30, iVar4);
    }
    *(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)*(int32_t *)(arg1 + 0x30) * 8) = arg2;
    *(int32_t *)(arg1 + 0x30) = *(int32_t *)(arg1 + 0x30) + 1;
    *(uint8_t *)(arg1 + 0xdd) = *(uint8_t *)(arg1 + 0xdd) | 2;
    *(int64_t *)(arg2 + 0x4c0) = arg1;
    *(undefined4 *)(arg2 + 0x4d0) = *(undefined4 *)arg1;
    *(uint8_t *)(arg2 + 0x495) = 1 < *(int32_t *)(arg1 + 0x30) | *(uint8_t *)(arg2 + 0x495) & 0xf6;
    if (((*(int64_t *)(arg1 + 0x98) == 0) && (*(int64_t *)(arg1 + 0x18) == 0)) &&
       ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0)) {
        uVar3 = *(uint32_t *)(arg1 + 0xd8);
        if ((uVar3 & 7) == 0) {
            uVar3 = uVar3 & 0xfffffffa | 2;
            *(uint32_t *)(arg1 + 0xd8) = uVar3;
        }
        if ((uVar3 & 0x38) == 0) {
            uVar3 = uVar3 & 0xffffffd7 | 0x10;
            *(uint32_t *)(arg1 + 0xd8) = uVar3;
        }
        if ((uVar3 & 0x1c0) == 0) {
            *(uint32_t *)(arg1 + 0xd8) = uVar3 & 0xfffffebf | 0x80;
        }
    }
    if (in_R8B != '\0') {
        if (*(int64_t *)(arg1 + 0x40) == 0) {
            func_0x000180119020(arg1);
            iVar2 = 0;
            *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x24) = *(undefined4 *)(arg1 + 0xcc);
            *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x20) = *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x24);
            if (0 < *(int32_t *)(arg1 + 0x30) + -1) {
                do {
                    func_0x00018014ab80(*(undefined8 *)(arg1 + 0x40), 0, 
                                        *(undefined8 *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar2 * 8));
                    iVar2 = iVar2 + 1;
                } while (iVar2 < *(int32_t *)(arg1 + 0x30) + -1);
            }
        }
        func_0x00018014ab80(*(undefined8 *)(arg1 + 0x40), 0x800000, arg2);
    }
    func_0x000180116ca0(arg1);
    if (*(int64_t *)(arg1 + 0x98) != 0) {
        func_0x0001801018b0(arg2, *(uint32_t *)(arg2 + 0x14) | 0x1000000);
    }
    return;
}

// ============================================================
// Function: FUN_180116490
// Address: 0x180116490
// Size: 843 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_28e8h because it doesn't fit into ProtoModel

void fcn.180116490(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_a0h)
{
    int64_t iVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    undefined4 *puVar6;
    uint8_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    undefined4 uVar10;
    int64_t *piVar11;
    int64_t iVar12;
    undefined4 *puVar14;
    uint32_t uVar15;
    uint8_t uVar16;
    int64_t iVar17;
    undefined8 *puVar18;
    uint32_t uVar19;
    undefined8 uVar20;
    int64_t var_68h;
    int64_t var_58h;
    uint64_t uVar13;
    
    iVar1 = *(int64_t *)0x180781f28;
    uVar13 = 0;
    *(undefined8 *)(arg2 + 0x4c0) = 0;
    *(uint8_t *)(arg2 + 0x495) = *(uint8_t *)(arg2 + 0x495) & 0xf6;
    *(int32_t *)(arg2 + 0x4d0) = (int32_t)arg3;
    *(uint32_t *)(arg2 + 0x14) = *(uint32_t *)(arg2 + 0x14) & 0xfeffffff;
    iVar17 = *(int64_t *)(arg2 + 0x408);
    if (iVar17 != 0) {
        piVar4 = *(int64_t **)(iVar17 + 0x1f8);
        for (piVar11 = piVar4; piVar11 < piVar4 + *(int32_t *)(iVar17 + 0x1f0); piVar11 = piVar11 + 1) {
            if (*piVar11 == arg2) {
                iVar12 = (int64_t)piVar11 - (int64_t)piVar4 >> 3;
                func_0x000180498030(piVar4 + iVar12, piVar4 + iVar12 + 1, 
                                    (*(int32_t *)(iVar17 + 0x1f0) - iVar12) * 8 + -8);
                *(int32_t *)(iVar17 + 0x1f0) = *(int32_t *)(iVar17 + 0x1f0) + -1;
                break;
            }
        }
    }
    *(undefined8 *)(arg2 + 0x408) = 0;
    *(int64_t *)(arg2 + 0x438) = arg2;
    *(int64_t *)(arg2 + 0x430) = arg2;
    *(int64_t *)(arg2 + 0x428) = arg2;
    *(int64_t *)(arg2 + 0x420) = arg2;
    *(int64_t *)(arg2 + 0x418) = arg2;
    uVar8 = *(uint32_t *)(arg2 + 0x1c);
    iVar17 = arg2;
    while ((uVar8 & 0x100) != 0) {
        iVar17 = *(int64_t *)(iVar17 + 0x408);
        *(int64_t *)(arg2 + 0x438) = iVar17;
        uVar8 = *(uint32_t *)(iVar17 + 0x1c);
    }
    if ((*(int64_t *)(arg1 + 0x98) != 0) && (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x108) != '\0')) {
        *(undefined8 *)(arg2 + 0x48) = 0;
        *(undefined4 *)(arg2 + 0x50) = 0;
        *(undefined *)(arg2 + 0x108) = 0;
        *(undefined *)(arg2 + 0x111) = 1;
    }
    iVar9 = *(int32_t *)(arg1 + 0x30);
    if (0 < iVar9) {
        do {
            piVar4 = (int64_t *)(*(int64_t *)(arg1 + 0x38) + uVar13 * 8);
            if (*piVar4 == arg2) {
                func_0x000180498030(piVar4, piVar4 + 1, ((int64_t)iVar9 - uVar13) * 8 + -8);
                *(int32_t *)(arg1 + 0x30) = *(int32_t *)(arg1 + 0x30) + -1;
                break;
            }
            uVar8 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar8;
        } while ((int32_t)uVar8 < iVar9);
    }
    if (*(int64_t *)(arg1 + 0xa0) == arg2) {
        *(undefined8 *)(arg1 + 0xa0) = 0;
    }
    *(uint8_t *)(arg1 + 0xdd) = *(uint8_t *)(arg1 + 0xdd) | 2;
    if (((*(int64_t *)(arg1 + 0x40) != 0) &&
        (func_0x00018014ac70(*(int64_t *)(arg1 + 0x40), *(undefined4 *)(arg2 + 200)),
        *(int32_t *)(arg1 + 0x30) < (int32_t)(2 - (uint32_t)((*(uint32_t *)(arg1 + 0x10) & 0x800) != 0)))) &&
       (iVar17 = *(int64_t *)(arg1 + 0x40), iVar17 != 0)) {
        if (*(int64_t *)(iVar17 + 0xa8) != 0) {
            fcn.180460d90();
        }
        if (*(int64_t *)(iVar17 + 0x10) != 0) {
            fcn.180460d90();
        }
        fcn.180460d90(iVar17);
        *(undefined8 *)(arg1 + 0x40) = 0;
    }
    iVar9 = *(int32_t *)(arg1 + 0x30);
    if (iVar9 == 0) {
        if ((((*(uint32_t *)(arg1 + 0x10) >> 0xb & 1) == 0) && ((*(uint32_t *)(arg1 + 0x10) >> 10 & 1) == 0)) &&
           (*(int32_t *)(arg2 + 0x4d0) != *(int32_t *)arg1)) {
            if (*(int64_t *)(arg1 + 0x98) != 0) {
                *(undefined8 *)(*(int64_t *)(arg1 + 0x98) + 0x4c8) = 0;
            }
            puVar14 = *(undefined4 **)(arg1 + 0x18);
            if (puVar14 == (undefined4 *)0x0) {
                iVar17 = *(int64_t *)(arg1 + 0x40);
                if (iVar17 != 0) {
                    if (*(int64_t *)(iVar17 + 0xa8) != 0) {
                        fcn.180460d90();
                    }
                    if (*(int64_t *)(iVar17 + 0x10) != 0) {
                        fcn.180460d90();
                    }
                    fcn.180460d90(iVar17);
                }
                *(undefined8 *)(arg1 + 0x40) = 0;
                func_0x0001800f6220(iVar1 + 0x28e8, *(undefined4 *)arg1, 0);
                *(undefined8 *)(arg1 + 0x28) = 0;
                *(undefined8 *)(arg1 + 0x20) = 0;
                if (*(int64_t *)(arg1 + 0x38) != 0) {
                    fcn.180460d90();
                }
                if ((arg1 != 0) && (iVar9 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1), iVar9 == 0)) {
                    uVar10 = (*(code *)0x699ff6)();
                    uVar10 = func_0x00018046b63c(uVar10);
                    puVar14 = (undefined4 *)func_0x00018046b77c();
                    *puVar14 = uVar10;
                }
                return;
            }
            iVar17 = *(int64_t *)(puVar14 + 8);
            if (iVar17 == arg1) {
                iVar17 = *(int64_t *)(puVar14 + 10);
            }
            puVar5 = *(undefined4 **)(puVar14 + 8);
            puVar6 = *(undefined4 **)(puVar14 + 10);
            uVar10 = puVar14[0x16];
            uVar3 = puVar14[0x17];
            iVar12 = *(int64_t *)(iVar17 + 0x20);
            *(int64_t *)(puVar14 + 8) = iVar12;
            *(undefined8 *)(puVar14 + 10) = *(undefined8 *)(iVar17 + 0x28);
            if (iVar12 != 0) {
                *(undefined4 **)(iVar12 + 0x18) = puVar14;
            }
            if (*(int64_t *)(puVar14 + 10) != 0) {
                *(undefined4 **)(*(int64_t *)(puVar14 + 10) + 0x18) = puVar14;
            }
            puVar14[0x18] = *(undefined4 *)(iVar17 + 0x60);
            *(undefined8 *)(puVar14 + 0x16) = *(undefined8 *)(iVar17 + 0x58);
            *(undefined8 *)(iVar17 + 0x28) = 0;
            *(undefined8 *)(iVar17 + 0x20) = 0;
            if (puVar5 != (undefined4 *)0x0) {
                func_0x0001801167e0(puVar14, puVar5);
                func_0x00018011d570(*puVar5, *puVar14);
            }
            if (puVar6 != (undefined4 *)0x0) {
                func_0x0001801167e0(puVar14, puVar6);
                func_0x00018011d570(*puVar6, *puVar14);
            }
            puVar18 = *(undefined8 **)(puVar14 + 0xe);
            puVar2 = puVar18 + (int32_t)puVar14[0xc];
            for (; puVar18 != puVar2; puVar18 = puVar18 + 1) {
                uVar20 = func_0x000180106470(*puVar18, puVar14 + 0x12, 1);
                func_0x0001801065c0(uVar20, puVar14 + 0x14, 1);
            }
            puVar14[0x36] = puVar14[0x36] & 0xfffffe00;
            *(undefined8 *)(puVar14 + 0x28) = *(undefined8 *)(iVar17 + 0xa0);
            puVar14[0x16] = uVar10;
            puVar14[0x17] = uVar3;
            uVar8 = puVar14[2];
            puVar14[2] = uVar8 & 0xfffc078f;
            uVar19 = 0;
            uVar15 = uVar19;
            if (puVar5 != (undefined4 *)0x0) {
                uVar15 = puVar5[2];
            }
            uVar15 = (uVar8 ^ uVar15) & 0xfffc078f ^ uVar15;
            puVar14[2] = uVar15;
            uVar8 = uVar19;
            if (puVar6 != (undefined4 *)0x0) {
                uVar8 = puVar6[2];
            }
            uVar15 = uVar8 & 0x3f870 | uVar15;
            puVar14[2] = uVar15;
            uVar8 = uVar19;
            if (puVar5 != (undefined4 *)0x0) {
                uVar8 = puVar5[3];
            }
            if (puVar6 != (undefined4 *)0x0) {
                uVar19 = puVar6[3];
            }
            puVar14[3] = uVar19 | uVar8;
            puVar14[4] = uVar19 | uVar8 | puVar14[1] | uVar15;
            iVar1 = iVar1 + 0x28e8;
            if (puVar5 != (undefined4 *)0x0) {
                iVar17 = *(int64_t *)(puVar5 + 0x10);
                if (iVar17 != 0) {
                    if (*(int64_t *)(iVar17 + 0xa8) != 0) {
                        fcn.180460d90();
                    }
                    if (*(int64_t *)(iVar17 + 0x10) != 0) {
                        fcn.180460d90();
                    }
                    fcn.180460d90(iVar17);
                }
                *(undefined8 *)(puVar5 + 0x10) = 0;
                func_0x0001800f6220(iVar1, *puVar5, 0);
                *(undefined8 *)(puVar5 + 10) = 0;
                *(undefined8 *)(puVar5 + 8) = 0;
                if (*(int64_t *)(puVar5 + 0xe) != 0) {
                    fcn.180460d90();
                }
                fcn.180460d90(puVar5);
            }
            if (puVar6 != (undefined4 *)0x0) {
                iVar17 = *(int64_t *)(puVar6 + 0x10);
                if (iVar17 != 0) {
                    if (*(int64_t *)(iVar17 + 0xa8) != 0) {
                        fcn.180460d90();
                    }
                    if (*(int64_t *)(iVar17 + 0x10) != 0) {
                        fcn.180460d90();
                    }
                    fcn.180460d90(iVar17);
                }
                *(undefined8 *)(puVar6 + 0x10) = 0;
                func_0x0001800f6220(iVar1, *puVar6, 0);
                *(undefined8 *)(puVar6 + 10) = 0;
                *(undefined8 *)(puVar6 + 8) = 0;
                if (*(int64_t *)(puVar6 + 0xe) != 0) {
                    fcn.180460d90();
                }
                fcn.180460d90(puVar6);
            }
            return;
        }
    } else if (((iVar9 == 1) && ((*(uint32_t *)(arg1 + 0x10) & 0x800) == 0)) && (*(int64_t *)(arg1 + 0x98) != 0)) {
        *(undefined *)(**(int64_t **)(arg1 + 0x38) + 0x10c) = *(undefined *)(*(int64_t *)(arg1 + 0x98) + 0x10c);
        iVar9 = *(int32_t *)(arg1 + 0x30);
    }
    uVar7 = (uint8_t)((*(uint32_t *)(arg1 + 0x10) & 0x800) >> 0xb);
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        uVar7 = (uint8_t)((*(uint32_t *)(arg1 + 0x10) & 0x400) >> 10);
    }
    if (0 < iVar9) {
        uVar7 = 1;
    }
    if ((*(int64_t *)(arg1 + 0x20) == 0) || (uVar16 = 1, (*(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0xdc) & 1) == 0)) {
        uVar16 = uVar7;
    }
    if ((*(int64_t *)(arg1 + 0x28) == 0) || ((*(uint8_t *)(*(int64_t *)(arg1 + 0x28) + 0xdc) & 1) == 0)) {
        uVar7 = 0;
    } else {
        uVar7 = 1;
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfe;
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | uVar7 | uVar16;
    return;
}

// ============================================================
// Function: FUN_1801167e0
// Address: 0x1801167e0
// Size: 269 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_4c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_495h because it doesn't fit into ProtoModel

void fcn.1801167e0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    bool bVar3;
    int64_t *piVar4;
    
    if ((*(int64_t *)(arg2 + 0x40) == 0) || (*(int64_t *)(arg1 + 0x40) != 0)) {
        bVar3 = false;
    } else {
        bVar3 = true;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg2 + 0x40);
        *(undefined8 *)(arg2 + 0x40) = 0;
    }
    piVar4 = *(int64_t **)(arg2 + 0x38);
    piVar1 = piVar4 + *(int32_t *)(arg2 + 0x30);
    for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
        iVar2 = *piVar4;
        *(undefined8 *)(iVar2 + 0x4c0) = 0;
        *(uint8_t *)(iVar2 + 0x495) = *(uint8_t *)(iVar2 + 0x495) & 0xfe;
        fcn.1801162d0(arg1, iVar2);
    }
    if (*(int64_t *)(arg2 + 0x38) != 0) {
        *(undefined8 *)(arg2 + 0x30) = 0;
        fcn.180460d90();
        *(undefined8 *)(arg2 + 0x38) = 0;
    }
    if ((!bVar3) && (*(int64_t *)(arg2 + 0x40) != 0)) {
        if (*(int64_t *)(arg1 + 0x40) != 0) {
            *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x20) = *(undefined4 *)(*(int64_t *)(arg2 + 0x40) + 0x20);
        }
        iVar2 = *(int64_t *)(arg2 + 0x40);
        if (iVar2 != 0) {
            if (*(int64_t *)(iVar2 + 0xa8) != 0) {
                fcn.180460d90();
            }
            if (*(int64_t *)(iVar2 + 0x10) != 0) {
                fcn.180460d90();
            }
            fcn.180460d90(iVar2);
            *(undefined8 *)(arg2 + 0x40) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801168f0
// Address: 0x1801168f0
// Size: 155 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801168f0(int64_t arg1)
{
    uint8_t *puVar1;
    int64_t iVar2;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)(arg1 + 0x98);
    if (iVar2 != 0) {
        if (*(int64_t *)(iVar2 + 0x4c8) == arg1) {
            *(undefined8 *)(iVar2 + 0x4c8) = 0;
        }
        *(undefined8 *)(arg1 + 0x98) = 0;
    }
    if (*(int32_t *)(arg1 + 0x30) == 1) {
        *(int64_t *)(arg1 + 0xa0) = **(int64_t **)(arg1 + 0x38);
        puVar1 = (uint8_t *)(**(int64_t **)(arg1 + 0x38) + 0x495);
        *puVar1 = *puVar1 & 0xfe;
    }
    iVar2 = *(int64_t *)(arg1 + 0x40);
    if (iVar2 != 0) {
        if (*(int64_t *)(iVar2 + 0xa8) != 0) {
            fcn.180460d90();
        }
        if (*(int64_t *)(iVar2 + 0x10) != 0) {
            fcn.180460d90();
        }
        fcn.180460d90(iVar2);
        *(undefined8 *)(arg1 + 0x40) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180116990
// Address: 0x180116990
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180116990(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    while( true ) {
        if (0 < *(int32_t *)(arg1 + 0x30)) {
            if (*(int64_t *)(arg2 + 8) == 0) {
                *(int64_t *)(arg2 + 8) = arg1;
            }
            *(int32_t *)(arg2 + 0x10) = *(int32_t *)(arg2 + 0x10) + 1;
        }
        if ((*(uint32_t *)(arg1 + 0x10) & 0x800) != 0) {
            *(int64_t *)arg2 = arg1;
        }
        if ((1 < *(int32_t *)(arg2 + 0x10)) && (*(int64_t *)arg2 != 0)) break;
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            fcn.180116990(*(int64_t *)(arg1 + 0x20), arg2);
        }
        arg1 = *(int64_t *)(arg1 + 0x28);
        if (arg1 == 0) {
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180116a00
// Address: 0x180116a00
// Size: 565 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_28e8h because it doesn't fit into ProtoModel

void fcn.180116a00(int64_t arg1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined4 *arg2;
    undefined4 *arg2_00;
    uint8_t uVar6;
    uint8_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    undefined4 uVar10;
    int64_t *piVar11;
    int64_t iVar12;
    undefined4 *puVar14;
    uint32_t uVar15;
    uint8_t uVar16;
    int32_t iVar17;
    uint32_t uVar18;
    int64_t iVar19;
    undefined8 *puVar20;
    uint32_t uVar21;
    undefined8 uVar22;
    int64_t var_4h;
    int64_t in_stack_00000050;
    uint64_t uVar13;
    
    iVar1 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        *(undefined4 *)(arg1 + 4) = *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 4);
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xdf;
    if (*(int64_t *)(arg1 + 0x20) != 0) {
        fcn.180116a00(*(int64_t *)(arg1 + 0x20));
    }
    if (*(int64_t *)(arg1 + 0x28) != 0) {
        fcn.180116a00(*(int64_t *)(arg1 + 0x28));
    }
    iVar9 = *(int32_t *)(arg1 + 0x30);
    iVar17 = 0;
    *(undefined4 *)(arg1 + 0xc) = 0;
    if (0 < iVar9) {
        do {
            iVar19 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar17 * 8);
            iVar9 = *(int32_t *)(arg1 + 0xc0) + 1;
            if ((iVar9 == *(int32_t *)(iVar1 + 4)) && (*(char *)(iVar19 + 0x10a) == '\0')) {
                uVar6 = 1;
code_r0x000180116a8d:
                uVar7 = uVar6;
                if (((((*(uint8_t *)(arg1 + 0xdc) & 0x40) != 0) ||
                     (*(int32_t *)(arg1 + 0xd0) == *(int32_t *)(iVar19 + 200))) && (*(char *)(iVar19 + 0x114) != '\0'))
                   && ((*(uint32_t *)(iVar19 + 0x14) & 0x40000) == 0)) {
                    uVar7 = 1;
                }
            } else {
                uVar7 = 0;
                uVar6 = 0;
                if (iVar9 == *(int32_t *)(iVar1 + 4)) goto code_r0x000180116a8d;
            }
            if ((*(uint8_t *)(iVar19 + 0x495) >> 3 & 1 | uVar7) == 0) {
                *(uint32_t *)(arg1 + 0xc) = *(uint32_t *)(arg1 + 0xc) | *(uint32_t *)(iVar19 + 0x38);
            } else {
                *(uint8_t *)(iVar19 + 0x495) = *(uint8_t *)(iVar19 + 0x495) & 0xf7;
                if ((*(int32_t *)(arg1 + 0x30) == 1) && ((*(uint32_t *)(arg1 + 0x10) & 0x800) == 0)) {
                    fcn.1801168f0(arg1);
                    uVar10 = *(undefined4 *)arg1;
                    *(undefined4 *)(arg1 + 0x14) = 1;
                    iVar1 = *(int64_t *)0x180781f28;
                    uVar13 = 0;
                    *(undefined8 *)(iVar19 + 0x4c0) = 0;
                    *(uint8_t *)(iVar19 + 0x495) = *(uint8_t *)(iVar19 + 0x495) & 0xf6;
                    *(undefined4 *)(iVar19 + 0x4d0) = uVar10;
                    *(uint32_t *)(iVar19 + 0x14) = *(uint32_t *)(iVar19 + 0x14) & 0xfeffffff;
                    iVar4 = *(int64_t *)(iVar19 + 0x408);
                    if (iVar4 == 0) goto code_r0x000180116525;
                    piVar5 = *(int64_t **)(iVar4 + 0x1f8);
                    piVar11 = piVar5;
                    if (piVar5 + *(int32_t *)(iVar4 + 0x1f0) <= piVar5) goto code_r0x000180116525;
                    goto code_r0x0001801164f0;
                }
                fcn.180116490(arg1, iVar19, (uint64_t)*(uint32_t *)arg1, in_stack_00000050);
                iVar17 = iVar17 + -1;
            }
            iVar9 = *(int32_t *)(arg1 + 0x30);
            iVar17 = iVar17 + 1;
        } while (iVar17 < iVar9);
    }
    uVar8 = *(uint32_t *)(arg1 + 8);
    uVar21 = *(uint32_t *)(arg1 + 4);
    uVar15 = *(uint32_t *)(arg1 + 0xc);
    uVar18 = uVar8 | uVar21 | uVar15;
    uVar6 = *(uint8_t *)(arg1 + 0xdd);
    *(uint32_t *)(arg1 + 0x10) = uVar18;
    if (((((uVar6 & 2) != 0) && (iVar9 == 1)) && ((uVar18 & 0x40) != 0)) && ((uVar18 >> 0xd & 1) == 0)) {
        uVar6 = uVar6 | 4;
    }
    uVar7 = uVar6 & 0xfd;
    *(uint8_t *)(arg1 + 0xdd) = uVar7;
    if ((((uVar6 & 4) != 0) && (*(int64_t *)(arg1 + 0xa0) != 0)) &&
       ((*(uint32_t *)(*(int64_t *)(arg1 + 0xa0) + 0x38) & 0x2000) != 0)) {
        uVar7 = uVar6 & 0xf9;
    }
    if (iVar9 < 2) {
        if ((uVar7 & 4) != 0) {
            *(uint32_t *)(arg1 + 8) = uVar8 ^ 0x2000;
            uVar18 = uVar8 ^ 0x2000 | uVar21 | uVar15;
            *(uint32_t *)(arg1 + 0x10) = uVar18;
        }
    } else {
        *(uint32_t *)(arg1 + 8) = uVar8 & 0xffffdfff;
        uVar18 = uVar8 & 0xffffdfff | uVar21 | uVar15;
        *(uint32_t *)(arg1 + 0x10) = uVar18;
    }
    *(uint8_t *)(arg1 + 0xdd) = uVar7 & 0xfb;
    uVar6 = (uint8_t)((uVar18 & 0x800) >> 0xb);
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        uVar6 = (uint8_t)((uVar18 & 0x400) >> 10);
    }
    uVar7 = 1;
    if (0 < iVar9) {
        uVar6 = 1;
    }
    if ((*(int64_t *)(arg1 + 0x20) == 0) || ((*(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0xdc) & 1) == 0)) {
        uVar7 = 0;
    }
    if ((*(int64_t *)(arg1 + 0x28) == 0) || ((*(uint8_t *)(*(int64_t *)(arg1 + 0x28) + 0xdc) & 1) == 0)) {
        uVar16 = 0;
    } else {
        uVar16 = 1;
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfe | uVar6 | uVar7 | uVar16;
    return;
    while (piVar11 = piVar11 + 1, piVar11 < piVar5 + *(int32_t *)(iVar4 + 0x1f0)) {
code_r0x0001801164f0:
        if (*piVar11 == iVar19) {
            iVar12 = (int64_t)piVar11 - (int64_t)piVar5 >> 3;
            func_0x000180498030(piVar5 + iVar12, piVar5 + iVar12 + 1, (*(int32_t *)(iVar4 + 0x1f0) - iVar12) * 8 + -8);
            *(int32_t *)(iVar4 + 0x1f0) = *(int32_t *)(iVar4 + 0x1f0) + -1;
            break;
        }
    }
code_r0x000180116525:
    *(undefined8 *)(iVar19 + 0x408) = 0;
    *(int64_t *)(iVar19 + 0x438) = iVar19;
    *(int64_t *)(iVar19 + 0x430) = iVar19;
    *(int64_t *)(iVar19 + 0x428) = iVar19;
    *(int64_t *)(iVar19 + 0x420) = iVar19;
    *(int64_t *)(iVar19 + 0x418) = iVar19;
    uVar8 = *(uint32_t *)(iVar19 + 0x1c);
    iVar4 = iVar19;
    while ((uVar8 & 0x100) != 0) {
        iVar4 = *(int64_t *)(iVar4 + 0x408);
        *(int64_t *)(iVar19 + 0x438) = iVar4;
        uVar8 = *(uint32_t *)(iVar4 + 0x1c);
    }
    if ((*(int64_t *)(arg1 + 0x98) != 0) && (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x108) != '\0')) {
        *(undefined8 *)(iVar19 + 0x48) = 0;
        *(undefined4 *)(iVar19 + 0x50) = 0;
        *(undefined *)(iVar19 + 0x108) = 0;
        *(undefined *)(iVar19 + 0x111) = 1;
    }
    iVar9 = *(int32_t *)(arg1 + 0x30);
    if (0 < iVar9) {
        do {
            piVar5 = (int64_t *)(*(int64_t *)(arg1 + 0x38) + uVar13 * 8);
            if (*piVar5 == iVar19) {
                func_0x000180498030(piVar5, piVar5 + 1, ((int64_t)iVar9 - uVar13) * 8 + -8);
                *(int32_t *)(arg1 + 0x30) = *(int32_t *)(arg1 + 0x30) + -1;
                break;
            }
            uVar8 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar8;
        } while ((int32_t)uVar8 < iVar9);
    }
    if (*(int64_t *)(arg1 + 0xa0) == iVar19) {
        *(undefined8 *)(arg1 + 0xa0) = 0;
    }
    *(uint8_t *)(arg1 + 0xdd) = *(uint8_t *)(arg1 + 0xdd) | 2;
    if (((*(int64_t *)(arg1 + 0x40) != 0) &&
        (func_0x00018014ac70(*(int64_t *)(arg1 + 0x40), *(undefined4 *)(iVar19 + 200)),
        *(int32_t *)(arg1 + 0x30) < (int32_t)(2 - (uint32_t)((*(uint32_t *)(arg1 + 0x10) & 0x800) != 0)))) &&
       (iVar4 = *(int64_t *)(arg1 + 0x40), iVar4 != 0)) {
        if (*(int64_t *)(iVar4 + 0xa8) != 0) {
            fcn.180460d90();
        }
        if (*(int64_t *)(iVar4 + 0x10) != 0) {
            fcn.180460d90();
        }
        fcn.180460d90(iVar4);
        *(undefined8 *)(arg1 + 0x40) = 0;
    }
    iVar9 = *(int32_t *)(arg1 + 0x30);
    if (iVar9 == 0) {
        if ((((*(uint32_t *)(arg1 + 0x10) >> 0xb & 1) == 0) && ((*(uint32_t *)(arg1 + 0x10) >> 10 & 1) == 0)) &&
           (*(int32_t *)(iVar19 + 0x4d0) != *(int32_t *)arg1)) {
            if (*(int64_t *)(arg1 + 0x98) != 0) {
                *(undefined8 *)(*(int64_t *)(arg1 + 0x98) + 0x4c8) = 0;
            }
            puVar14 = *(undefined4 **)(arg1 + 0x18);
            if (puVar14 == (undefined4 *)0x0) {
                iVar19 = *(int64_t *)(arg1 + 0x40);
                if (iVar19 != 0) {
                    if (*(int64_t *)(iVar19 + 0xa8) != 0) {
                        fcn.180460d90();
                    }
                    if (*(int64_t *)(iVar19 + 0x10) != 0) {
                        fcn.180460d90();
                    }
                    fcn.180460d90(iVar19);
                }
                *(undefined8 *)(arg1 + 0x40) = 0;
                func_0x0001800f6220(iVar1 + 0x28e8, *(undefined4 *)arg1, 0);
                *(undefined8 *)(arg1 + 0x28) = 0;
                *(undefined8 *)(arg1 + 0x20) = 0;
                if (*(int64_t *)(arg1 + 0x38) != 0) {
                    fcn.180460d90();
                }
                if ((arg1 != 0) && (iVar9 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1), iVar9 == 0)) {
                    uVar10 = (*(code *)0x699ff6)();
                    uVar10 = func_0x00018046b63c(uVar10);
                    puVar14 = (undefined4 *)func_0x00018046b77c();
                    *puVar14 = uVar10;
                }
                return;
            }
            iVar19 = *(int64_t *)(puVar14 + 8);
            if (iVar19 == arg1) {
                iVar19 = *(int64_t *)(puVar14 + 10);
            }
            arg2 = *(undefined4 **)(puVar14 + 8);
            arg2_00 = *(undefined4 **)(puVar14 + 10);
            uVar10 = puVar14[0x16];
            uVar3 = puVar14[0x17];
            iVar4 = *(int64_t *)(iVar19 + 0x20);
            *(int64_t *)(puVar14 + 8) = iVar4;
            *(undefined8 *)(puVar14 + 10) = *(undefined8 *)(iVar19 + 0x28);
            if (iVar4 != 0) {
                *(undefined4 **)(iVar4 + 0x18) = puVar14;
            }
            if (*(int64_t *)(puVar14 + 10) != 0) {
                *(undefined4 **)(*(int64_t *)(puVar14 + 10) + 0x18) = puVar14;
            }
            puVar14[0x18] = *(undefined4 *)(iVar19 + 0x60);
            *(undefined8 *)(puVar14 + 0x16) = *(undefined8 *)(iVar19 + 0x58);
            *(undefined8 *)(iVar19 + 0x28) = 0;
            *(undefined8 *)(iVar19 + 0x20) = 0;
            if (arg2 != (undefined4 *)0x0) {
                fcn.1801167e0((int64_t)puVar14, (int64_t)arg2);
                func_0x00018011d570(*arg2, *puVar14);
            }
            if (arg2_00 != (undefined4 *)0x0) {
                fcn.1801167e0((int64_t)puVar14, (int64_t)arg2_00);
                func_0x00018011d570(*arg2_00, *puVar14);
            }
            puVar20 = *(undefined8 **)(puVar14 + 0xe);
            puVar2 = puVar20 + (int32_t)puVar14[0xc];
            for (; puVar20 != puVar2; puVar20 = puVar20 + 1) {
                uVar22 = func_0x000180106470(*puVar20, puVar14 + 0x12, 1);
                func_0x0001801065c0(uVar22, puVar14 + 0x14, 1);
            }
            puVar14[0x36] = puVar14[0x36] & 0xfffffe00;
            *(undefined8 *)(puVar14 + 0x28) = *(undefined8 *)(iVar19 + 0xa0);
            puVar14[0x16] = uVar10;
            puVar14[0x17] = uVar3;
            uVar8 = puVar14[2];
            puVar14[2] = uVar8 & 0xfffc078f;
            uVar21 = 0;
            uVar15 = uVar21;
            if (arg2 != (undefined4 *)0x0) {
                uVar15 = arg2[2];
            }
            uVar15 = (uVar8 ^ uVar15) & 0xfffc078f ^ uVar15;
            puVar14[2] = uVar15;
            uVar8 = uVar21;
            if (arg2_00 != (undefined4 *)0x0) {
                uVar8 = arg2_00[2];
            }
            uVar15 = uVar8 & 0x3f870 | uVar15;
            puVar14[2] = uVar15;
            uVar8 = uVar21;
            if (arg2 != (undefined4 *)0x0) {
                uVar8 = arg2[3];
            }
            if (arg2_00 != (undefined4 *)0x0) {
                uVar21 = arg2_00[3];
            }
            puVar14[3] = uVar21 | uVar8;
            puVar14[4] = uVar21 | uVar8 | puVar14[1] | uVar15;
            iVar1 = iVar1 + 0x28e8;
            if (arg2 != (undefined4 *)0x0) {
                iVar19 = *(int64_t *)(arg2 + 0x10);
                if (iVar19 != 0) {
                    if (*(int64_t *)(iVar19 + 0xa8) != 0) {
                        fcn.180460d90();
                    }
                    if (*(int64_t *)(iVar19 + 0x10) != 0) {
                        fcn.180460d90();
                    }
                    fcn.180460d90(iVar19);
                }
                *(undefined8 *)(arg2 + 0x10) = 0;
                func_0x0001800f6220(iVar1, *arg2, 0);
                *(undefined8 *)(arg2 + 10) = 0;
                *(undefined8 *)(arg2 + 8) = 0;
                if (*(int64_t *)(arg2 + 0xe) != 0) {
                    fcn.180460d90();
                }
                fcn.180460d90(arg2);
            }
            if (arg2_00 != (undefined4 *)0x0) {
                iVar19 = *(int64_t *)(arg2_00 + 0x10);
                if (iVar19 != 0) {
                    if (*(int64_t *)(iVar19 + 0xa8) != 0) {
                        fcn.180460d90();
                    }
                    if (*(int64_t *)(iVar19 + 0x10) != 0) {
                        fcn.180460d90();
                    }
                    fcn.180460d90(iVar19);
                }
                *(undefined8 *)(arg2_00 + 0x10) = 0;
                func_0x0001800f6220(iVar1, *arg2_00, 0);
                *(undefined8 *)(arg2_00 + 10) = 0;
                *(undefined8 *)(arg2_00 + 8) = 0;
                if (*(int64_t *)(arg2_00 + 0xe) != 0) {
                    fcn.180460d90();
                }
                fcn.180460d90(arg2_00);
            }
            return;
        }
    } else if (((iVar9 == 1) && ((*(uint32_t *)(arg1 + 0x10) & 0x800) == 0)) && (*(int64_t *)(arg1 + 0x98) != 0)) {
        *(undefined *)(**(int64_t **)(arg1 + 0x38) + 0x10c) = *(undefined *)(*(int64_t *)(arg1 + 0x98) + 0x10c);
        iVar9 = *(int32_t *)(arg1 + 0x30);
    }
    uVar6 = (uint8_t)((*(uint32_t *)(arg1 + 0x10) & 0x800) >> 0xb);
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        uVar6 = (uint8_t)((*(uint32_t *)(arg1 + 0x10) & 0x400) >> 10);
    }
    if (0 < iVar9) {
        uVar6 = 1;
    }
    if ((*(int64_t *)(arg1 + 0x20) == 0) || (uVar7 = 1, (*(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0xdc) & 1) == 0)) {
        uVar7 = uVar6;
    }
    if ((*(int64_t *)(arg1 + 0x28) == 0) || ((*(uint8_t *)(*(int64_t *)(arg1 + 0x28) + 0xdc) & 1) == 0)) {
        uVar6 = 0;
    } else {
        uVar6 = 1;
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfe;
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | uVar6 | uVar7;
    return;
}

// ============================================================
// Function: FUN_180116c40
// Address: 0x180116c40
// Size: 86 bytes
// ============================================================
void fcn.180116c40(int64_t arg1)
{
    int64_t iVar1;
    
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xdf;
    if (*(int64_t *)(arg1 + 0x20) != 0) {
        fcn.180116c40(*(int64_t *)(arg1 + 0x20));
    }
    if (*(int64_t *)(arg1 + 0x28) != 0) {
        fcn.180116c40(*(int64_t *)(arg1 + 0x28));
    }
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        for (iVar1 = *(int64_t *)(arg1 + 0xa8); iVar1 != 0; iVar1 = *(int64_t *)(iVar1 + 0x18)) {
            *(uint8_t *)(iVar1 + 0xdc) = *(uint8_t *)(iVar1 + 0xdc) | 0x20;
        }
    }
    return;
}

