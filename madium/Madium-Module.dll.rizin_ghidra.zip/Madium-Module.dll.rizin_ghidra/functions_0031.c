// Chunk 31 - 50 functions

// ============================================================
// Function: FUN_180064500
// Address: 0x180064500
// Size: 43 bytes
// ============================================================
int64_t fcn.180064500(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1804a6e50;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x90);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180064530
// Address: 0x180064530
// Size: 43 bytes
// ============================================================
int64_t fcn.180064530(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1804a6e78;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0xb8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180064560
// Address: 0x180064560
// Size: 43 bytes
// ============================================================
int64_t fcn.180064560(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1804a6ea0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x20);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180064590
// Address: 0x180064590
// Size: 43 bytes
// ============================================================
int64_t fcn.180064590(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x180624d38;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x38);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800645c0
// Address: 0x1800645c0
// Size: 43 bytes
// ============================================================
int64_t fcn.1800645c0(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x180624fe8;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800645f0
// Address: 0x1800645f0
// Size: 43 bytes
// ============================================================
int64_t fcn.1800645f0(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x180624d18;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x18);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180064620
// Address: 0x180064620
// Size: 43 bytes
// ============================================================
int64_t fcn.180064620(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x180624bf0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x58);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180064650
// Address: 0x180064650
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180064650(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x180624ba8;
    if ((*(char *)(arg1 + 0xc1) != '\0') && (*(int32_t *)(arg1 + 0xbc) == 0)) {
        func_0x000180454960(arg1 + 0x20);
    }
    func_0x000180458fd4(arg1 + 0x10);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0xd0);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800646d0
// Address: 0x1800646d0
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800646d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    char cVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar4 = *(char *)(arg3 + 0x19);
    while (cVar4 == '\0') {
        fcn.1800646d0(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RBX);
        piVar5 = *(int64_t **)(arg3 + 0x30);
        piVar6 = *(int64_t **)arg3;
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar5 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        fcn.180459c3c(arg3, 0x38);
        arg3 = (int64_t)piVar6;
        cVar4 = *(char *)((int64_t)piVar6 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_1800646f0
// Address: 0x1800646f0
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800646d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    char cVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar4 = *(char *)(arg3 + 0x19);
    while (cVar4 == '\0') {
        fcn.1800646d0(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RBX);
        piVar5 = *(int64_t **)(arg3 + 0x30);
        piVar6 = *(int64_t **)arg3;
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar5 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        fcn.180459c3c(arg3, 0x38);
        arg3 = (int64_t)piVar6;
        cVar4 = *(char *)((int64_t)piVar6 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_18006476a
// Address: 0x18006476a
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800646d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    char cVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar4 = *(char *)(arg3 + 0x19);
    while (cVar4 == '\0') {
        fcn.1800646d0(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RBX);
        piVar5 = *(int64_t **)(arg3 + 0x30);
        piVar6 = *(int64_t **)arg3;
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar5 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        fcn.180459c3c(arg3, 0x38);
        arg3 = (int64_t)piVar6;
        cVar4 = *(char *)((int64_t)piVar6 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_180064780
// Address: 0x180064780
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180064780(int64_t arg1)
{
    int64_t *piVar1;
    char in_DL;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(arg1 + 0x48);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg1 + 0x10));
        *(undefined8 *)(arg1 + 0x48) = 0;
    }
    if (in_DL != '\0') {
        fcn.180459c3c(arg1, 0x50);
    }
    return;
}

// ============================================================
// Function: FUN_1800647f0
// Address: 0x1800647f0
// Size: 116 bytes
// ============================================================
void fcn.1800647f0(int64_t arg1)
{
    undefined8 *puVar1;
    int32_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    
    if (*(int64_t **)(arg1 + 0x48) == (int64_t *)0x0) {
        fcn.180454690();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    iVar4 = (**(code **)(**(int64_t **)(arg1 + 0x48) + 0x10))();
    if (iVar4 != 0) {
        piVar2 = *(int32_t **)(*(int64_t *)(arg1 + 8) + 8);
        puVar1 = (undefined8 *)(piVar2 + 2);
        if (*(int64_t *)(piVar2 + 2) != 0) {
            if (*piVar2 < 5) {
                if (*(char *)(piVar2 + 4) != '\0') {
                    fcn.1801821b0(puVar1);
                    *puVar1 = 0;
                    return;
                }
            } else {
                LOCK();
                *piVar2 = 7;
                UNLOCK();
                fcn.180182a20(*puVar1);
            }
            *puVar1 = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180064870
// Address: 0x180064870
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 * fcn.180064870(int64_t arg1)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    puVar2 = (undefined8 *)fcn.180459890(0x50);
    *puVar2 = 0x180624c70;
    puVar2[1] = *(undefined8 *)(arg1 + 8);
    puVar2[9] = 0;
    puVar1 = *(undefined8 **)(arg1 + 0x48);
    if (puVar1 != (undefined8 *)0x0) {
        uVar3 = (**(code **)*puVar1)(puVar1, puVar2 + 2);
        puVar2[9] = uVar3;
    }
    return puVar2;
}

// ============================================================
// Function: FUN_1800648e0
// Address: 0x1800648e0
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800648e0(int64_t arg1)
{
    int64_t *piVar1;
    char in_DL;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(arg1 + 0x40);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg1 + 8));
        *(undefined8 *)(arg1 + 0x40) = 0;
    }
    if (in_DL != '\0') {
        fcn.180459c3c(arg1, 0x48);
    }
    return;
}

// ============================================================
// Function: FUN_180064970
// Address: 0x180064970
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 * fcn.180064970(int64_t arg1)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    puVar2 = (undefined8 *)fcn.180459890(0x48);
    *puVar2 = 0x180624ca0;
    puVar2[8] = 0;
    puVar1 = *(undefined8 **)(arg1 + 0x40);
    if (puVar1 != (undefined8 *)0x0) {
        uVar3 = (**(code **)*puVar1)(puVar1, puVar2 + 1);
        puVar2[8] = uVar3;
    }
    return puVar2;
}

// ============================================================
// Function: FUN_1800649e0
// Address: 0x1800649e0
// Size: 1407 bytes
// ============================================================
void fcn.1800649e0(int64_t arg1)
{
    int64_t **ppiVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    code *pcVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    char *pcVar10;
    int64_t *piVar11;
    undefined8 *puVar12;
    undefined8 uVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    char cVar16;
    undefined auStack_198 [32];
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_a0h;
    undefined8 uStack_98;
    int64_t var_90h;
    int64_t var_60h;
    int64_t var_58h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_198;
    var_170h = *(int64_t *)(arg1 + 0x48);
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar15 = (int64_t *)piVar11[1];
    if (piVar15 == (int64_t *)0x0) {
        var_178h = 0;
        piVar15 = (int64_t *)0x0;
    } else {
        var_178h = *piVar11;
        LOCK();
        *(int32_t *)((int64_t)piVar15 + 0xc) = *(int32_t *)((int64_t)piVar15 + 0xc) + 1;
        UNLOCK();
    }
    piVar8 = (int64_t *)fcn.180459890(0x28);
    *(undefined4 *)(piVar8 + 1) = 1;
    *(undefined4 *)((int64_t)piVar8 + 0xc) = 1;
    *piVar8 = 0x180624fe8;
    ppiVar1 = (int64_t **)(piVar8 + 2);
    func_0x000180065a60(ppiVar1);
    piVar3 = *ppiVar1;
    if ((piVar3 != (int64_t *)0x0) && ((*(char *)(piVar8 + 3) == '\0' || (*(char *)(piVar3 + 0x17) == '\0')))) {
        if (*(char *)(piVar8 + 4) != '\0') {
            func_0x0001800621d0(2);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        *(undefined *)(piVar8 + 4) = 1;
        if (piVar3 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar3 + 1) = *(int32_t *)(piVar3 + 1) + 1;
            UNLOCK();
        }
        piVar9 = (int64_t *)fcn.180459890();
        *(undefined4 *)(piVar9 + 1) = 1;
        *(undefined4 *)((int64_t)piVar9 + 0xc) = 1;
        *piVar9 = 0x180624d18;
        var_130h = (int64_t)(piVar9 + 2);
        *(undefined *)var_130h = 0;
        var_150h = 0;
        var_148h = (int64_t)(int64_t *)0x0;
        if (piVar15 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)((int64_t)piVar15 + 0xc) = *(int32_t *)((int64_t)piVar15 + 0xc) + 1;
            UNLOCK();
            var_150h = var_178h;
            var_148h = (int64_t)piVar15;
        }
        LOCK();
        *(int32_t *)(piVar8 + 1) = *(int32_t *)(piVar8 + 1) + 1;
        UNLOCK();
        LOCK();
        *(int32_t *)(piVar9 + 1) = *(int32_t *)(piVar9 + 1) + 1;
        UNLOCK();
        var_158h = 0x180624cd0;
        var_120h = (int64_t)&var_158h;
        var_140h = (int64_t)ppiVar1;
        var_138h = (int64_t)piVar8;
        var_128h = (int64_t)piVar9;
        func_0x000180014e50(&var_158h, piVar11[5] + 0x198);
        if (var_120h != 0) {
            (**(code **)(*(int64_t *)var_120h + 0x20))
                      (var_120h, CONCAT71((unkint7)((uint64_t)&var_158h >> 8), (int64_t *)var_120h != &var_158h));
        }
        var_110h = 0;
        var_108h = (int64_t)(int64_t *)0x0;
        if (piVar15 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)((int64_t)piVar15 + 0xc) = *(int32_t *)((int64_t)piVar15 + 0xc) + 1;
            UNLOCK();
            var_110h = var_178h;
            var_108h = (int64_t)piVar15;
        }
        LOCK();
        *(int32_t *)(piVar8 + 1) = *(int32_t *)(piVar8 + 1) + 1;
        UNLOCK();
        LOCK();
        *(int32_t *)(piVar9 + 1) = *(int32_t *)(piVar9 + 1) + 1;
        UNLOCK();
        var_118h = 0x180624c40;
        var_f0h = (int64_t)(piVar9 + 2);
        var_e0h = (int64_t)&var_118h;
        var_100h = (int64_t)ppiVar1;
        var_f8h = (int64_t)piVar8;
        var_e8h = (int64_t)piVar9;
        func_0x000180014e50(&var_118h, piVar11[5] + 0x1d8);
        if (var_e0h != 0) {
            (**(code **)(*(int64_t *)var_e0h + 0x20))
                      (var_e0h, CONCAT71((unkint7)((uint64_t)&var_118h >> 8), (int64_t *)var_e0h != &var_118h));
        }
        if (piVar15 == (int64_t *)0x0) {
            var_d0h = 0;
            var_c8h = 0;
        } else {
            LOCK();
            *(int32_t *)((int64_t)piVar15 + 0xc) = *(int32_t *)((int64_t)piVar15 + 0xc) + 1;
            UNLOCK();
            var_d0h = var_178h;
            var_c8h = (int64_t)piVar15;
        }
        var_d8h = 0x180624c10;
        var_a0h = (int64_t)&var_d8h;
        func_0x000180014e50(&var_d8h, piVar11[5] + 0x218);
        if (var_a0h != 0) {
            (**(code **)(*(int64_t *)var_a0h + 0x20))
                      (var_a0h, CONCAT71((unkint7)((uint64_t)&var_d8h >> 8), (int64_t *)var_a0h != &var_d8h));
        }
        *(undefined4 *)(piVar11[5] + 0x58) = 5000;
        piVar14 = (int64_t *)(arg1 + 8);
        if (0xf < *(uint64_t *)(arg1 + 0x20)) {
            piVar14 = (int64_t *)*piVar14;
        }
        iVar7 = func_0x00018017fc00(piVar11[5], piVar14, 0x18077e0e0);
        if (iVar7 == 0) {
            if ((piVar3 == (int64_t *)0x0) || (*(char *)(piVar3 + 0x17) != '\0')) goto code_r0x000180064f54;
            pcVar10 = (char *)(**(code **)(*piVar3 + 0x10))(piVar3, 1);
            cVar16 = *pcVar10;
            LOCK();
            piVar11 = piVar3 + 1;
            iVar7 = *(int32_t *)piVar11;
            *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                puVar12 = (undefined8 *)piVar3[0x19];
                if (puVar12 == (undefined8 *)0x0) {
                    (**(code **)*piVar3)(piVar3, 1);
                } else {
                    (**(code **)*puVar12)(puVar12, piVar3);
                }
            }
            LOCK();
            piVar11 = piVar9 + 1;
            iVar7 = *(int32_t *)piVar11;
            *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)*piVar9)(piVar9);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar9 + 0xc);
                iVar7 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)(*piVar9 + 8))(piVar9);
                }
            }
            LOCK();
            piVar11 = piVar8 + 1;
            iVar7 = *(int32_t *)piVar11;
            *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)*piVar8)(piVar8);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar8 + 0xc);
                iVar7 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)(*piVar8 + 8))(piVar8);
                }
            }
            if (piVar15 != (int64_t *)0x0) {
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar15 + 0xc);
                iVar7 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)(*piVar15 + 8))(piVar15);
                }
            }
        } else {
            LOCK();
            piVar11 = piVar9 + 1;
            iVar7 = *(int32_t *)piVar11;
            *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)*piVar9)(piVar9);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar9 + 0xc);
                iVar7 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)(*piVar9 + 8))(piVar9);
                }
            }
            if (piVar3 != (int64_t *)0x0) {
                LOCK();
                piVar11 = piVar3 + 1;
                iVar7 = *(int32_t *)piVar11;
                *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    puVar12 = (undefined8 *)piVar3[0x19];
                    if (puVar12 == (undefined8 *)0x0) {
                        (**(code **)*piVar3)(piVar3, 1);
                    } else {
                        (**(code **)*puVar12)(puVar12, piVar3);
                    }
                }
            }
            LOCK();
            piVar11 = piVar8 + 1;
            iVar7 = *(int32_t *)piVar11;
            *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)*piVar8)(piVar8);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar8 + 0xc);
                iVar7 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)(*piVar8 + 8))(piVar8);
                }
            }
            if (piVar15 != (int64_t *)0x0) {
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar15 + 0xc);
                iVar7 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)(*piVar15 + 8))(piVar15);
                }
            }
            cVar16 = '\0';
        }
        piVar11 = (int64_t *)func_0x0001800137d0();
        var_178h = *piVar11;
        puVar12 = (undefined8 *)fcn.180459890(0x88);
        *(undefined4 *)(puVar12 + 1) = 1;
        *(undefined4 *)((int64_t)puVar12 + 0xc) = 1;
        *puVar12 = 0x180623990;
        uVar4 = *(undefined8 *)arg1;
        uStack_98 = 0x180624d58;
        *(undefined4 *)(puVar12 + 3) = 2;
        puVar12[2] = 0x180623918;
        puVar12[0xb] = 0;
        var_90h._0_1_ = cVar16 == '\0';
        var_60h = (int64_t)&uStack_98;
        uVar13 = func_0x000180065e00(&uStack_98, puVar12 + 4);
        puVar12[0xb] = uVar13;
        puVar12[0xc] = uVar4;
        puVar12[0xd] = var_170h;
        puVar12[0xe] = 0;
        puVar12[0xf] = 0;
        if (*(int64_t *)(arg1 + 0x40) != 0) {
            LOCK();
            piVar2 = (int32_t *)(*(int64_t *)(arg1 + 0x40) + 8);
            *piVar2 = *piVar2 + 1;
            UNLOCK();
        }
        puVar12[0xe] = *(undefined8 *)(arg1 + 0x38);
        puVar12[0xf] = *(undefined8 *)(arg1 + 0x40);
        *(bool *)(puVar12 + 0x10) = cVar16 == '\0';
        *(undefined4 *)(puVar12 + 3) = 1;
        if (var_60h != 0) {
            (**(code **)(*(int64_t *)var_60h + 0x20))
                      (var_60h, CONCAT71((unkint7)((uint64_t)&uStack_98 >> 8), (undefined8 *)var_60h != &uStack_98));
        }
        var_170h = (int64_t)(puVar12 + 2);
        var_168h = (int64_t)puVar12;
        func_0x00018000a9d0(var_178h, &var_170h);
        iVar6 = var_168h;
        if (var_168h != 0) {
            LOCK();
            piVar2 = (int32_t *)(var_168h + 8);
            iVar7 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (***(code ***)var_168h)(var_168h);
                LOCK();
                piVar2 = (int32_t *)(iVar6 + 0xc);
                iVar7 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)(*(int64_t *)iVar6 + 8))(iVar6);
                }
            }
        }
        func_0x00018045476c();
        func_0x000180063610(arg1);
        fcn.180459c3c(arg1, 0x50);
        func_0x000180459870(var_58h ^ (uint64_t)auStack_198);
        return;
    }
code_r0x000180064f54:
    func_0x0001800621d0(4);
    pcVar5 = (code *)swi(3);
    (*pcVar5)();
    return;
}

// ============================================================
// Function: FUN_180064f80
// Address: 0x180064f80
// Size: 46 bytes
// ============================================================
void fcn.180064f80(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 == 0) {
        return;
    }
    func_0x000180063610(arg1);
    if ((arg1 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar2 == 0))
    {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_180064fb0
// Address: 0x180064fb0
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180064fb0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    char in_DL;
    int64_t var_8h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3 != (int64_t *)0x0) {
        LOCK();
        piVar1 = (int32_t *)((int64_t)piVar3 + 0xc);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
            (**(code **)(*piVar3 + 8))();
        }
    }
    if (in_DL != '\0') {
        fcn.180459c3c(arg1, 0x18);
    }
    return;
}

// ============================================================
// Function: FUN_180065010
// Address: 0x180065010
// Size: 573 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180065010(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    bool bVar10;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    uint64_t uStack_20;
    
    uStack_20 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar5 = *(int64_t *)(arg1 + 0x10);
    var_78h = 0;
    if (iVar5 == 0) {
code_r0x000180065072:
        var_80h = 0;
        iVar5 = var_80h;
        piVar9 = (int64_t *)var_78h;
        _var_80h = ZEXT816(0);
    } else {
        iVar2 = *(int32_t *)(iVar5 + 8);
        do {
            if (iVar2 == 0) goto code_r0x000180065072;
            LOCK();
            iVar4 = *(int32_t *)(iVar5 + 8);
            bVar10 = iVar2 == iVar4;
            if (bVar10) {
                *(int32_t *)(iVar5 + 8) = iVar2 + 1;
                iVar4 = iVar2;
            }
            UNLOCK();
            iVar2 = iVar4;
        } while (!bVar10);
        iVar5 = *(int64_t *)*(undefined (*) [16])(arg1 + 8);
        piVar9 = *(int64_t **)(arg1 + 0x10);
        _var_80h = *(undefined (*) [16])(arg1 + 8);
    }
    if ((iVar5 != 0) && (*(int32_t *)(iVar5 + 0x10) != -1)) {
        puVar6 = (undefined8 *)func_0x0001800137d0();
        uVar3 = *puVar6;
        var_50h = 0;
        iVar5 = *(int64_t *)(arg1 + 0x10);
        var_48h = 0;
        if (iVar5 != 0) {
            var_50h = *(int64_t *)(arg1 + 8);
            LOCK();
            *(int32_t *)(iVar5 + 0xc) = *(int32_t *)(iVar5 + 0xc) + 1;
            UNLOCK();
            var_48h = iVar5;
        }
        func_0x00018000b4d0(&var_40h, arg2);
        uVar7 = func_0x00018045838c();
        piVar8 = (int64_t *)fcn.180459890(0x30);
        *piVar8 = var_50h;
        piVar8[1] = var_48h;
        _var_50h = ZEXT816(0);
        var_88h = (int64_t)piVar8;
        var_70h = (int64_t)piVar8;
        func_0x00018000b4d0(piVar8 + 2, &var_40h);
        var_88h = (int64_t)piVar8;
        var_68h = fcn.180459890(0x38);
        *(undefined (*) [16])var_68h = ZEXT816(0);
        *(undefined4 *)((undefined *)var_68h + 8) = 1;
        *(undefined4 *)((undefined *)var_68h + 0xc) = 1;
        *(undefined8 *)(undefined *)var_68h = 0x180622900;
        var_70h = var_68h + 0x10;
        *(undefined4 *)(*(undefined (*) [16])(var_68h + 0x10) + 8) = 2;
        *(undefined8 *)(undefined *)var_70h = 0x180624d00;
        var_88h = 0;
        *(int64_t **)*(undefined (*) [16])(var_68h + 0x20) = piVar8;
        *(undefined8 *)(*(undefined (*) [16])(var_68h + 0x20) + 8) = 0x180063e30;
        *(undefined8 *)*(undefined (*) [16])(var_68h + 0x30) = uVar7;
        _var_60h = ZEXT816(0);
        func_0x00018000a9d0(uVar3, &var_70h);
        iVar5 = var_68h;
        if (var_68h != 0) {
            LOCK();
            piVar1 = (int32_t *)(var_68h + 8);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (***(code ***)var_68h)(var_68h);
                LOCK();
                piVar1 = (int32_t *)(iVar5 + 0xc);
                iVar2 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar2 == 1) {
                    (**(code **)(*(int64_t *)iVar5 + 8))(iVar5);
                }
            }
        }
        func_0x000180004e40(&var_40h);
        if (var_48h != 0) {
            LOCK();
            piVar1 = (int32_t *)(var_48h + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*(int64_t *)var_48h + 8))();
            }
        }
    }
    if (piVar9 != (int64_t *)0x0) {
        LOCK();
        piVar8 = piVar9 + 1;
        iVar2 = *(int32_t *)piVar8;
        *(int32_t *)piVar8 = *(int32_t *)piVar8 + -1;
        UNLOCK();
        if (iVar2 == 1) {
            (**(code **)*piVar9)(piVar9);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar9 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar9 + 8))(piVar9);
            }
        }
    }
    func_0x000180459870(uStack_20 ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_1800652d0
// Address: 0x1800652d0
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800652d0(int64_t arg1)
{
    char in_DL;
    int64_t var_8h;
    
    fcn.180062600(arg1 + 8);
    if (in_DL != '\0') {
        fcn.180459c3c(arg1, 0x38);
    }
    return;
}

// ============================================================
// Function: FUN_180065320
// Address: 0x180065320
// Size: 530 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h

void fcn.180065320(int64_t arg1)
{
    int32_t *piVar1;
    char cVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    undefined8 *puVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t *piVar10;
    undefined8 in_R8;
    undefined8 in_R9;
    bool bVar11;
    int64_t var_8h;
    int64_t var_98h;
    int64_t var_8ch;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    iVar9 = *(int64_t *)(arg1 + 0x10);
    var_70h = 0;
    if (iVar9 == 0) {
code_r0x00018006535e:
        var_78h = 0;
        iVar9 = var_78h;
        piVar10 = (int64_t *)var_70h;
        _var_78h = ZEXT816(0);
    } else {
        iVar3 = *(int32_t *)(iVar9 + 8);
        do {
            if (iVar3 == 0) goto code_r0x00018006535e;
            LOCK();
            iVar5 = *(int32_t *)(iVar9 + 8);
            bVar11 = iVar3 == iVar5;
            if (bVar11) {
                *(int32_t *)(iVar9 + 8) = iVar3 + 1;
                iVar5 = iVar3;
            }
            UNLOCK();
            iVar3 = iVar5;
        } while (!bVar11);
        iVar9 = *(int64_t *)*(undefined (*) [16])(arg1 + 8);
        piVar10 = *(int64_t **)(arg1 + 0x10);
        _var_78h = *(undefined (*) [16])(arg1 + 8);
    }
    if (iVar9 != 0) {
        LOCK();
        *(undefined *)(iVar9 + 0x40) = 0;
        UNLOCK();
        LOCK();
        cVar2 = **(char **)(arg1 + 0x28);
        **(char **)(arg1 + 0x28) = '\x01';
        UNLOCK();
        if (cVar2 == '\0') {
            var_8h = var_8h & 0xffffffffffffff00;
            func_0x0001800638b0(*(undefined8 *)(arg1 + 0x18), &var_8h, in_R8, in_R9, _var_78h);
        }
        if (*(int32_t *)(iVar9 + 0x14) != -1) {
            puVar6 = (undefined8 *)func_0x0001800137d0();
            uVar4 = *puVar6;
            iVar9 = *(int64_t *)(arg1 + 0x10);
            var_60h = 0;
            if (iVar9 == 0) {
                var_68h = 0;
            } else {
                var_68h = *(int64_t *)(arg1 + 8);
                LOCK();
                *(int32_t *)(iVar9 + 0xc) = *(int32_t *)(iVar9 + 0xc) + 1;
                UNLOCK();
                var_60h = iVar9;
            }
            uVar7 = func_0x00018045838c();
            piVar8 = (int64_t *)fcn.180459890(0x10);
            *piVar8 = var_68h;
            piVar8[1] = var_60h;
            var_8h = (int64_t)piVar8;
            var_50h = fcn.180459890(0x38);
            *(undefined (*) [16])var_50h = ZEXT816(0);
            *(undefined4 *)((undefined *)var_50h + 8) = 1;
            *(undefined4 *)((undefined *)var_50h + 0xc) = 1;
            *(undefined8 *)(undefined *)var_50h = 0x180622900;
            var_58h = var_50h + 0x10;
            *(undefined4 *)(*(undefined (*) [16])(var_50h + 0x10) + 8) = 2;
            *(undefined8 *)(undefined *)var_58h = 0x180624bd8;
            var_8h = 0;
            *(int64_t **)*(undefined (*) [16])(var_50h + 0x20) = piVar8;
            *(undefined8 *)(*(undefined (*) [16])(var_50h + 0x20) + 8) = 0x180063c50;
            *(undefined8 *)*(undefined (*) [16])(var_50h + 0x30) = uVar7;
            _var_48h = ZEXT816(0);
            func_0x00018000a9d0(uVar4, &var_58h);
            iVar9 = var_50h;
            if (var_50h != 0) {
                LOCK();
                piVar1 = (int32_t *)(var_50h + 8);
                iVar3 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (***(code ***)var_50h)(var_50h);
                    LOCK();
                    piVar1 = (int32_t *)(iVar9 + 0xc);
                    iVar3 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)(*(int64_t *)iVar9 + 8))(iVar9);
                    }
                }
            }
        }
    }
    if (piVar10 != (int64_t *)0x0) {
        LOCK();
        piVar8 = piVar10 + 1;
        iVar3 = *(int32_t *)piVar8;
        *(int32_t *)piVar8 = *(int32_t *)piVar8 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar10)(piVar10);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar10 + 8))(piVar10);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180065650
// Address: 0x180065650
// Size: 187 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180065650(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    char cVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    undefined8 in_R9;
    bool bVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t *piStack_10;
    
    iVar6 = *(int64_t *)(arg1 + 0x10);
    piStack_10 = (int64_t *)0x0;
    if (iVar6 == 0) {
code_r0x000180065684:
        var_18h = 0;
        iVar6 = var_18h;
        piVar7 = piStack_10;
        _var_18h = ZEXT816(0);
    } else {
        iVar4 = *(int32_t *)(iVar6 + 8);
        do {
            if (iVar4 == 0) goto code_r0x000180065684;
            LOCK();
            iVar5 = *(int32_t *)(iVar6 + 8);
            bVar8 = iVar4 == iVar5;
            if (bVar8) {
                *(int32_t *)(iVar6 + 8) = iVar4 + 1;
                iVar5 = iVar4;
            }
            UNLOCK();
            iVar4 = iVar5;
        } while (!bVar8);
        iVar6 = *(int64_t *)*(undefined (*) [16])(arg1 + 8);
        piVar7 = *(int64_t **)(arg1 + 0x10);
        _var_18h = *(undefined (*) [16])(arg1 + 8);
    }
    if (iVar6 != 0) {
        LOCK();
        *(undefined *)(iVar6 + 0x40) = 1;
        UNLOCK();
        LOCK();
        cVar3 = **(char **)(arg1 + 0x28);
        **(char **)(arg1 + 0x28) = '\x01';
        UNLOCK();
        if (cVar3 == '\0') {
            var_8h._0_1_ = 1;
            func_0x0001800638b0(*(undefined8 *)(arg1 + 0x18), &var_8h, arg1, in_R9, _var_18h);
        }
    }
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar7 + 1;
        iVar4 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar4 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180065810
// Address: 0x180065810
// Size: 589 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h

void fcn.180065810(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    undefined8 var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    
    iVar1 = *(int64_t *)arg1;
    if ((iVar1 != 0) &&
       (((*(char *)(arg1 + 8) == '\0' || (*(char *)(iVar1 + 0xb8) == '\0')) && (*(int32_t *)(iVar1 + 0xbc) == 0)))) {
        var_78h = 0x1804a5358;
        _var_70h = ZEXT816(0);
        var_a0h._0_1_ = 1;
        var_a8h = 0x1805aadb1;
        func_0x00018045b4e4(&var_a8h, &var_70h);
        var_78h = 0x1804a5690;
        var_60h._0_4_ = 1;
        var_60h._4_4_ = var_a8h._4_4_;
        var_58h = 0x1806a45f0;
        var_40h = 0x1804a5358;
        _var_38h = ZEXT816(0);
        func_0x00018045b4e4(&var_70h, &var_38h);
        var_40h = 0x1804a5690;
        var_28h._0_4_ = (undefined4)var_60h;
        var_28h._4_4_ = var_60h._4_4_;
        uStack_20 = (undefined4)var_58h;
        uStack_1c = var_58h._4_4_;
        _var_88h = ZEXT816(0);
        func_0x000180458fc4(&var_88h);
        func_0x000180458f98(&var_88h, &var_40h, 0x180698e18);
        var_40h = 0x1804a5358;
        func_0x00018045b56c(&var_38h);
        piVar2 = *(int64_t **)arg1;
        if ((piVar2 == (int64_t *)0x0) || ((*(char *)(arg1 + 8) != '\0' && (*(char *)(piVar2 + 0x17) != '\0')))) {
            func_0x0001800621d0(4);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        _var_a8h = ZEXT816(0);
        func_0x000180458f6c(&var_a8h, &var_88h);
        var_98h = (int64_t)(piVar2 + 4);
        var_90h._0_1_ = 0;
        iVar6 = func_0x000180456008(var_98h);
        if (iVar6 != 0) {
            func_0x0001804542e8(5);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        if (*(int32_t *)((int64_t)piVar2 + 0x6c) == 0x7fffffff) {
            *(undefined4 *)((int64_t)piVar2 + 0x6c) = 0x7ffffffe;
            func_0x0001804542e8(6);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        var_90h._0_1_ = '\x01';
        _var_50h = ZEXT816(0);
        func_0x000180458f6c(&var_50h, &var_a8h);
        if (*(char *)((int64_t)piVar2 + 0xc1) != '\0') {
            func_0x0001800621d0(3);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        func_0x000180458f64(piVar2 + 2, &var_50h);
        (**(code **)(*piVar2 + 0x28))(piVar2, &var_98h, 0);
        func_0x000180458fd4(&var_50h);
        if ((char)var_90h != '\0') {
            func_0x000180456010(var_98h);
        }
        func_0x000180458fd4(&var_a8h);
        func_0x000180458fd4(&var_88h);
        var_78h = 0x1804a5358;
        func_0x00018045b56c(&var_70h);
    }
    puVar3 = *(undefined8 **)arg1;
    if (puVar3 != (undefined8 *)0x0) {
        LOCK();
        puVar4 = puVar3 + 1;
        iVar6 = *(int32_t *)puVar4;
        *(int32_t *)puVar4 = *(int32_t *)puVar4 + -1;
        UNLOCK();
        if (iVar6 == 1) {
            puVar4 = (undefined8 *)puVar3[0x19];
            if (puVar4 == (undefined8 *)0x0) {
                (**(code **)*puVar3)(puVar3, 1);
            } else {
                (**(code **)*puVar4)(puVar4, puVar3);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180065a60
// Address: 0x180065a60
// Size: 213 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180065a60(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    puVar1 = (undefined8 *)fcn.180459890(0xd0);
    *puVar1 = 0x180624ba8;
    *(undefined4 *)(puVar1 + 1) = 1;
    *(undefined *)((int64_t)puVar1 + 0xc) = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    fcn.180458fc4();
    *(undefined (*) [16])(puVar1 + 7) = ZEXT816(0);
    *(undefined (*) [16])(puVar1 + 9) = ZEXT816(0);
    *(undefined (*) [16])(puVar1 + 0xb) = ZEXT816(0);
    puVar1[5] = 0;
    puVar1[6] = 0;
    *(undefined4 *)((int64_t)puVar1 + 0x6c) = 0;
    *(undefined4 *)(puVar1 + 0xd) = 0xffffffff;
    *(undefined4 *)(puVar1 + 4) = 2;
    puVar1[0xe] = 0;
    puVar1[0xf] = 0;
    *(undefined (*) [16])(puVar1 + 0x10) = ZEXT816(0);
    *(undefined (*) [16])(puVar1 + 0x12) = ZEXT816(0);
    *(undefined (*) [16])(puVar1 + 0x14) = ZEXT816(0);
    puVar1[0x16] = 0;
    *(undefined *)(puVar1 + 0x17) = 0;
    *(undefined4 *)((int64_t)puVar1 + 0xbc) = 0;
    *(undefined2 *)(puVar1 + 0x18) = 0;
    *(undefined *)((int64_t)puVar1 + 0xc2) = 0;
    puVar1[0x19] = 0;
    *(undefined8 **)arg1 = puVar1;
    *(undefined *)(arg1 + 8) = 0;
    *(undefined *)(arg1 + 0x10) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_180065b40
// Address: 0x180065b40
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180065b40(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    uVar4 = *(uint64_t *)(arg1 + 0x10);
    uVar6 = 1;
    if (uVar4 != 0) {
        uVar6 = uVar4;
    }
    for (; (uVar6 - uVar4 < (uint64_t)arg2 || (uVar6 < 8)); uVar6 = uVar6 * 2) {
        if (0xfffffffffffffff - uVar6 < uVar6) {
            func_0x000180010270();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    if (0x1fffffffffffffff < uVar6) {
code_r0x000180065d2b:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar3 = uVar6 * 8;
    if (uVar3 == 0) {
        unaff_R14 = 0;
code_r0x000180065bf9:
        iVar2 = uVar4 * 8;
        uVar3 = uVar6 >> 1;
        for (; uVar6 <= uVar3; uVar6 = uVar6 * 2) {
        }
        uVar6 = uVar6 - *(int64_t *)(arg1 + 0x10);
        iVar5 = *(int64_t *)(arg1 + 8) + iVar2;
        iVar8 = (*(int64_t *)(arg1 + 0x10) * 8 - iVar5) + *(int64_t *)(arg1 + 8);
        func_0x000180498030(iVar2 + unaff_R14, iVar5, iVar8);
        iVar8 = iVar8 + iVar2 + unaff_R14;
        if (uVar6 < uVar4) {
            iVar9 = uVar6 * 8;
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar9);
            iVar5 = iVar9 + *(int64_t *)(arg1 + 8);
            iVar2 = (*(int64_t *)(arg1 + 8) - iVar5) + iVar2;
            func_0x000180498030(unaff_R14, iVar5, iVar2);
            uVar4 = iVar2 + unaff_R14;
        } else {
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar2);
            func_0x0001804986e0(iVar8 + iVar2, 0, (uVar6 - uVar4) * 8);
            uVar4 = unaff_R14;
            iVar9 = iVar2;
        }
        func_0x0001804986e0(uVar4, 0, iVar9);
        iVar2 = *(int64_t *)(arg1 + 8);
        if (iVar2 == 0) goto code_r0x000180065d12;
        iVar5 = iVar2;
        puVar7 = auStack_38;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar5 = *(int64_t *)(iVar2 + -8), puVar7 = auStack_38, 0x1f < (iVar2 - iVar5) - 8U))
        goto code_r0x000180065d00;
    } else {
        if (uVar3 < 0x1000) {
            unaff_R14 = fcn.180459890();
            goto code_r0x000180065bf9;
        }
        if (uVar3 + 0x27 <= uVar3) goto code_r0x000180065d2b;
        iVar2 = fcn.180459890(uVar3 + 0x27);
        if (iVar2 != 0) {
            unaff_R14 = iVar2 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_R14 - 8) = iVar2;
            goto code_r0x000180065bf9;
        }
code_r0x000180065d00:
        iVar5 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar7 = auStack_30;
    }
    *(undefined8 *)(puVar7 + -8) = 0x180065d12;
    fcn.180459c3c(iVar5);
code_r0x000180065d12:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + uVar6;
    *(uint64_t *)(arg1 + 8) = unaff_R14;
    return;
}

// ============================================================
// Function: FUN_180065b89
// Address: 0x180065b89
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180065b40(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    uVar4 = *(uint64_t *)(arg1 + 0x10);
    uVar6 = 1;
    if (uVar4 != 0) {
        uVar6 = uVar4;
    }
    for (; (uVar6 - uVar4 < (uint64_t)arg2 || (uVar6 < 8)); uVar6 = uVar6 * 2) {
        if (0xfffffffffffffff - uVar6 < uVar6) {
            func_0x000180010270();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    if (0x1fffffffffffffff < uVar6) {
code_r0x000180065d2b:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar3 = uVar6 * 8;
    if (uVar3 == 0) {
        unaff_R14 = 0;
code_r0x000180065bf9:
        iVar2 = uVar4 * 8;
        uVar3 = uVar6 >> 1;
        for (; uVar6 <= uVar3; uVar6 = uVar6 * 2) {
        }
        uVar6 = uVar6 - *(int64_t *)(arg1 + 0x10);
        iVar5 = *(int64_t *)(arg1 + 8) + iVar2;
        iVar8 = (*(int64_t *)(arg1 + 0x10) * 8 - iVar5) + *(int64_t *)(arg1 + 8);
        func_0x000180498030(iVar2 + unaff_R14, iVar5, iVar8);
        iVar8 = iVar8 + iVar2 + unaff_R14;
        if (uVar6 < uVar4) {
            iVar9 = uVar6 * 8;
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar9);
            iVar5 = iVar9 + *(int64_t *)(arg1 + 8);
            iVar2 = (*(int64_t *)(arg1 + 8) - iVar5) + iVar2;
            func_0x000180498030(unaff_R14, iVar5, iVar2);
            uVar4 = iVar2 + unaff_R14;
        } else {
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar2);
            func_0x0001804986e0(iVar8 + iVar2, 0, (uVar6 - uVar4) * 8);
            uVar4 = unaff_R14;
            iVar9 = iVar2;
        }
        func_0x0001804986e0(uVar4, 0, iVar9);
        iVar2 = *(int64_t *)(arg1 + 8);
        if (iVar2 == 0) goto code_r0x000180065d12;
        iVar5 = iVar2;
        puVar7 = auStack_38;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar5 = *(int64_t *)(iVar2 + -8), puVar7 = auStack_38, 0x1f < (iVar2 - iVar5) - 8U))
        goto code_r0x000180065d00;
    } else {
        if (uVar3 < 0x1000) {
            unaff_R14 = fcn.180459890();
            goto code_r0x000180065bf9;
        }
        if (uVar3 + 0x27 <= uVar3) goto code_r0x000180065d2b;
        iVar2 = fcn.180459890(uVar3 + 0x27);
        if (iVar2 != 0) {
            unaff_R14 = iVar2 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_R14 - 8) = iVar2;
            goto code_r0x000180065bf9;
        }
code_r0x000180065d00:
        iVar5 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar7 = auStack_30;
    }
    *(undefined8 *)(puVar7 + -8) = 0x180065d12;
    fcn.180459c3c(iVar5);
code_r0x000180065d12:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + uVar6;
    *(uint64_t *)(arg1 + 8) = unaff_R14;
    return;
}

// ============================================================
// Function: FUN_180065bf9
// Address: 0x180065bf9
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180065b40(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    uVar4 = *(uint64_t *)(arg1 + 0x10);
    uVar6 = 1;
    if (uVar4 != 0) {
        uVar6 = uVar4;
    }
    for (; (uVar6 - uVar4 < (uint64_t)arg2 || (uVar6 < 8)); uVar6 = uVar6 * 2) {
        if (0xfffffffffffffff - uVar6 < uVar6) {
            func_0x000180010270();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    if (0x1fffffffffffffff < uVar6) {
code_r0x000180065d2b:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar3 = uVar6 * 8;
    if (uVar3 == 0) {
        unaff_R14 = 0;
code_r0x000180065bf9:
        iVar2 = uVar4 * 8;
        uVar3 = uVar6 >> 1;
        for (; uVar6 <= uVar3; uVar6 = uVar6 * 2) {
        }
        uVar6 = uVar6 - *(int64_t *)(arg1 + 0x10);
        iVar5 = *(int64_t *)(arg1 + 8) + iVar2;
        iVar8 = (*(int64_t *)(arg1 + 0x10) * 8 - iVar5) + *(int64_t *)(arg1 + 8);
        func_0x000180498030(iVar2 + unaff_R14, iVar5, iVar8);
        iVar8 = iVar8 + iVar2 + unaff_R14;
        if (uVar6 < uVar4) {
            iVar9 = uVar6 * 8;
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar9);
            iVar5 = iVar9 + *(int64_t *)(arg1 + 8);
            iVar2 = (*(int64_t *)(arg1 + 8) - iVar5) + iVar2;
            func_0x000180498030(unaff_R14, iVar5, iVar2);
            uVar4 = iVar2 + unaff_R14;
        } else {
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar2);
            func_0x0001804986e0(iVar8 + iVar2, 0, (uVar6 - uVar4) * 8);
            uVar4 = unaff_R14;
            iVar9 = iVar2;
        }
        func_0x0001804986e0(uVar4, 0, iVar9);
        iVar2 = *(int64_t *)(arg1 + 8);
        if (iVar2 == 0) goto code_r0x000180065d12;
        iVar5 = iVar2;
        puVar7 = auStack_38;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar5 = *(int64_t *)(iVar2 + -8), puVar7 = auStack_38, 0x1f < (iVar2 - iVar5) - 8U))
        goto code_r0x000180065d00;
    } else {
        if (uVar3 < 0x1000) {
            unaff_R14 = fcn.180459890();
            goto code_r0x000180065bf9;
        }
        if (uVar3 + 0x27 <= uVar3) goto code_r0x000180065d2b;
        iVar2 = fcn.180459890(uVar3 + 0x27);
        if (iVar2 != 0) {
            unaff_R14 = iVar2 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_R14 - 8) = iVar2;
            goto code_r0x000180065bf9;
        }
code_r0x000180065d00:
        iVar5 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar7 = auStack_30;
    }
    *(undefined8 *)(puVar7 + -8) = 0x180065d12;
    fcn.180459c3c(iVar5);
code_r0x000180065d12:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + uVar6;
    *(uint64_t *)(arg1 + 8) = unaff_R14;
    return;
}

// ============================================================
// Function: FUN_180065c01
// Address: 0x180065c01
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180065b40(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    uVar4 = *(uint64_t *)(arg1 + 0x10);
    uVar6 = 1;
    if (uVar4 != 0) {
        uVar6 = uVar4;
    }
    for (; (uVar6 - uVar4 < (uint64_t)arg2 || (uVar6 < 8)); uVar6 = uVar6 * 2) {
        if (0xfffffffffffffff - uVar6 < uVar6) {
            func_0x000180010270();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    if (0x1fffffffffffffff < uVar6) {
code_r0x000180065d2b:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar3 = uVar6 * 8;
    if (uVar3 == 0) {
        unaff_R14 = 0;
code_r0x000180065bf9:
        iVar2 = uVar4 * 8;
        uVar3 = uVar6 >> 1;
        for (; uVar6 <= uVar3; uVar6 = uVar6 * 2) {
        }
        uVar6 = uVar6 - *(int64_t *)(arg1 + 0x10);
        iVar5 = *(int64_t *)(arg1 + 8) + iVar2;
        iVar8 = (*(int64_t *)(arg1 + 0x10) * 8 - iVar5) + *(int64_t *)(arg1 + 8);
        func_0x000180498030(iVar2 + unaff_R14, iVar5, iVar8);
        iVar8 = iVar8 + iVar2 + unaff_R14;
        if (uVar6 < uVar4) {
            iVar9 = uVar6 * 8;
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar9);
            iVar5 = iVar9 + *(int64_t *)(arg1 + 8);
            iVar2 = (*(int64_t *)(arg1 + 8) - iVar5) + iVar2;
            func_0x000180498030(unaff_R14, iVar5, iVar2);
            uVar4 = iVar2 + unaff_R14;
        } else {
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar2);
            func_0x0001804986e0(iVar8 + iVar2, 0, (uVar6 - uVar4) * 8);
            uVar4 = unaff_R14;
            iVar9 = iVar2;
        }
        func_0x0001804986e0(uVar4, 0, iVar9);
        iVar2 = *(int64_t *)(arg1 + 8);
        if (iVar2 == 0) goto code_r0x000180065d12;
        iVar5 = iVar2;
        puVar7 = auStack_38;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar5 = *(int64_t *)(iVar2 + -8), puVar7 = auStack_38, 0x1f < (iVar2 - iVar5) - 8U))
        goto code_r0x000180065d00;
    } else {
        if (uVar3 < 0x1000) {
            unaff_R14 = fcn.180459890();
            goto code_r0x000180065bf9;
        }
        if (uVar3 + 0x27 <= uVar3) goto code_r0x000180065d2b;
        iVar2 = fcn.180459890(uVar3 + 0x27);
        if (iVar2 != 0) {
            unaff_R14 = iVar2 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_R14 - 8) = iVar2;
            goto code_r0x000180065bf9;
        }
code_r0x000180065d00:
        iVar5 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar7 = auStack_30;
    }
    *(undefined8 *)(puVar7 + -8) = 0x180065d12;
    fcn.180459c3c(iVar5);
code_r0x000180065d12:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + uVar6;
    *(uint64_t *)(arg1 + 8) = unaff_R14;
    return;
}

// ============================================================
// Function: FUN_180065c64
// Address: 0x180065c64
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180065b40(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    uVar4 = *(uint64_t *)(arg1 + 0x10);
    uVar6 = 1;
    if (uVar4 != 0) {
        uVar6 = uVar4;
    }
    for (; (uVar6 - uVar4 < (uint64_t)arg2 || (uVar6 < 8)); uVar6 = uVar6 * 2) {
        if (0xfffffffffffffff - uVar6 < uVar6) {
            func_0x000180010270();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    if (0x1fffffffffffffff < uVar6) {
code_r0x000180065d2b:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar3 = uVar6 * 8;
    if (uVar3 == 0) {
        unaff_R14 = 0;
code_r0x000180065bf9:
        iVar2 = uVar4 * 8;
        uVar3 = uVar6 >> 1;
        for (; uVar6 <= uVar3; uVar6 = uVar6 * 2) {
        }
        uVar6 = uVar6 - *(int64_t *)(arg1 + 0x10);
        iVar5 = *(int64_t *)(arg1 + 8) + iVar2;
        iVar8 = (*(int64_t *)(arg1 + 0x10) * 8 - iVar5) + *(int64_t *)(arg1 + 8);
        func_0x000180498030(iVar2 + unaff_R14, iVar5, iVar8);
        iVar8 = iVar8 + iVar2 + unaff_R14;
        if (uVar6 < uVar4) {
            iVar9 = uVar6 * 8;
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar9);
            iVar5 = iVar9 + *(int64_t *)(arg1 + 8);
            iVar2 = (*(int64_t *)(arg1 + 8) - iVar5) + iVar2;
            func_0x000180498030(unaff_R14, iVar5, iVar2);
            uVar4 = iVar2 + unaff_R14;
        } else {
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar2);
            func_0x0001804986e0(iVar8 + iVar2, 0, (uVar6 - uVar4) * 8);
            uVar4 = unaff_R14;
            iVar9 = iVar2;
        }
        func_0x0001804986e0(uVar4, 0, iVar9);
        iVar2 = *(int64_t *)(arg1 + 8);
        if (iVar2 == 0) goto code_r0x000180065d12;
        iVar5 = iVar2;
        puVar7 = auStack_38;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar5 = *(int64_t *)(iVar2 + -8), puVar7 = auStack_38, 0x1f < (iVar2 - iVar5) - 8U))
        goto code_r0x000180065d00;
    } else {
        if (uVar3 < 0x1000) {
            unaff_R14 = fcn.180459890();
            goto code_r0x000180065bf9;
        }
        if (uVar3 + 0x27 <= uVar3) goto code_r0x000180065d2b;
        iVar2 = fcn.180459890(uVar3 + 0x27);
        if (iVar2 != 0) {
            unaff_R14 = iVar2 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_R14 - 8) = iVar2;
            goto code_r0x000180065bf9;
        }
code_r0x000180065d00:
        iVar5 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar7 = auStack_30;
    }
    *(undefined8 *)(puVar7 + -8) = 0x180065d12;
    fcn.180459c3c(iVar5);
code_r0x000180065d12:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + uVar6;
    *(uint64_t *)(arg1 + 8) = unaff_R14;
    return;
}

// ============================================================
// Function: FUN_180065cd4
// Address: 0x180065cd4
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180065b40(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    uVar4 = *(uint64_t *)(arg1 + 0x10);
    uVar6 = 1;
    if (uVar4 != 0) {
        uVar6 = uVar4;
    }
    for (; (uVar6 - uVar4 < (uint64_t)arg2 || (uVar6 < 8)); uVar6 = uVar6 * 2) {
        if (0xfffffffffffffff - uVar6 < uVar6) {
            func_0x000180010270();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    if (0x1fffffffffffffff < uVar6) {
code_r0x000180065d2b:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar3 = uVar6 * 8;
    if (uVar3 == 0) {
        unaff_R14 = 0;
code_r0x000180065bf9:
        iVar2 = uVar4 * 8;
        uVar3 = uVar6 >> 1;
        for (; uVar6 <= uVar3; uVar6 = uVar6 * 2) {
        }
        uVar6 = uVar6 - *(int64_t *)(arg1 + 0x10);
        iVar5 = *(int64_t *)(arg1 + 8) + iVar2;
        iVar8 = (*(int64_t *)(arg1 + 0x10) * 8 - iVar5) + *(int64_t *)(arg1 + 8);
        func_0x000180498030(iVar2 + unaff_R14, iVar5, iVar8);
        iVar8 = iVar8 + iVar2 + unaff_R14;
        if (uVar6 < uVar4) {
            iVar9 = uVar6 * 8;
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar9);
            iVar5 = iVar9 + *(int64_t *)(arg1 + 8);
            iVar2 = (*(int64_t *)(arg1 + 8) - iVar5) + iVar2;
            func_0x000180498030(unaff_R14, iVar5, iVar2);
            uVar4 = iVar2 + unaff_R14;
        } else {
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar2);
            func_0x0001804986e0(iVar8 + iVar2, 0, (uVar6 - uVar4) * 8);
            uVar4 = unaff_R14;
            iVar9 = iVar2;
        }
        func_0x0001804986e0(uVar4, 0, iVar9);
        iVar2 = *(int64_t *)(arg1 + 8);
        if (iVar2 == 0) goto code_r0x000180065d12;
        iVar5 = iVar2;
        puVar7 = auStack_38;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar5 = *(int64_t *)(iVar2 + -8), puVar7 = auStack_38, 0x1f < (iVar2 - iVar5) - 8U))
        goto code_r0x000180065d00;
    } else {
        if (uVar3 < 0x1000) {
            unaff_R14 = fcn.180459890();
            goto code_r0x000180065bf9;
        }
        if (uVar3 + 0x27 <= uVar3) goto code_r0x000180065d2b;
        iVar2 = fcn.180459890(uVar3 + 0x27);
        if (iVar2 != 0) {
            unaff_R14 = iVar2 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_R14 - 8) = iVar2;
            goto code_r0x000180065bf9;
        }
code_r0x000180065d00:
        iVar5 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar7 = auStack_30;
    }
    *(undefined8 *)(puVar7 + -8) = 0x180065d12;
    fcn.180459c3c(iVar5);
code_r0x000180065d12:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + uVar6;
    *(uint64_t *)(arg1 + 8) = unaff_R14;
    return;
}

// ============================================================
// Function: FUN_180065d2b
// Address: 0x180065d2b
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180065b40(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    uVar4 = *(uint64_t *)(arg1 + 0x10);
    uVar6 = 1;
    if (uVar4 != 0) {
        uVar6 = uVar4;
    }
    for (; (uVar6 - uVar4 < (uint64_t)arg2 || (uVar6 < 8)); uVar6 = uVar6 * 2) {
        if (0xfffffffffffffff - uVar6 < uVar6) {
            func_0x000180010270();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    if (0x1fffffffffffffff < uVar6) {
code_r0x000180065d2b:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar3 = uVar6 * 8;
    if (uVar3 == 0) {
        unaff_R14 = 0;
code_r0x000180065bf9:
        iVar2 = uVar4 * 8;
        uVar3 = uVar6 >> 1;
        for (; uVar6 <= uVar3; uVar6 = uVar6 * 2) {
        }
        uVar6 = uVar6 - *(int64_t *)(arg1 + 0x10);
        iVar5 = *(int64_t *)(arg1 + 8) + iVar2;
        iVar8 = (*(int64_t *)(arg1 + 0x10) * 8 - iVar5) + *(int64_t *)(arg1 + 8);
        func_0x000180498030(iVar2 + unaff_R14, iVar5, iVar8);
        iVar8 = iVar8 + iVar2 + unaff_R14;
        if (uVar6 < uVar4) {
            iVar9 = uVar6 * 8;
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar9);
            iVar5 = iVar9 + *(int64_t *)(arg1 + 8);
            iVar2 = (*(int64_t *)(arg1 + 8) - iVar5) + iVar2;
            func_0x000180498030(unaff_R14, iVar5, iVar2);
            uVar4 = iVar2 + unaff_R14;
        } else {
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar2);
            func_0x0001804986e0(iVar8 + iVar2, 0, (uVar6 - uVar4) * 8);
            uVar4 = unaff_R14;
            iVar9 = iVar2;
        }
        func_0x0001804986e0(uVar4, 0, iVar9);
        iVar2 = *(int64_t *)(arg1 + 8);
        if (iVar2 == 0) goto code_r0x000180065d12;
        iVar5 = iVar2;
        puVar7 = auStack_38;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar5 = *(int64_t *)(iVar2 + -8), puVar7 = auStack_38, 0x1f < (iVar2 - iVar5) - 8U))
        goto code_r0x000180065d00;
    } else {
        if (uVar3 < 0x1000) {
            unaff_R14 = fcn.180459890();
            goto code_r0x000180065bf9;
        }
        if (uVar3 + 0x27 <= uVar3) goto code_r0x000180065d2b;
        iVar2 = fcn.180459890(uVar3 + 0x27);
        if (iVar2 != 0) {
            unaff_R14 = iVar2 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_R14 - 8) = iVar2;
            goto code_r0x000180065bf9;
        }
code_r0x000180065d00:
        iVar5 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar7 = auStack_30;
    }
    *(undefined8 *)(puVar7 + -8) = 0x180065d12;
    fcn.180459c3c(iVar5);
code_r0x000180065d12:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + uVar6;
    *(uint64_t *)(arg1 + 8) = unaff_R14;
    return;
}

// ============================================================
// Function: FUN_180065d31
// Address: 0x180065d31
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180065b40(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    uVar4 = *(uint64_t *)(arg1 + 0x10);
    uVar6 = 1;
    if (uVar4 != 0) {
        uVar6 = uVar4;
    }
    for (; (uVar6 - uVar4 < (uint64_t)arg2 || (uVar6 < 8)); uVar6 = uVar6 * 2) {
        if (0xfffffffffffffff - uVar6 < uVar6) {
            func_0x000180010270();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    if (0x1fffffffffffffff < uVar6) {
code_r0x000180065d2b:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar3 = uVar6 * 8;
    if (uVar3 == 0) {
        unaff_R14 = 0;
code_r0x000180065bf9:
        iVar2 = uVar4 * 8;
        uVar3 = uVar6 >> 1;
        for (; uVar6 <= uVar3; uVar6 = uVar6 * 2) {
        }
        uVar6 = uVar6 - *(int64_t *)(arg1 + 0x10);
        iVar5 = *(int64_t *)(arg1 + 8) + iVar2;
        iVar8 = (*(int64_t *)(arg1 + 0x10) * 8 - iVar5) + *(int64_t *)(arg1 + 8);
        func_0x000180498030(iVar2 + unaff_R14, iVar5, iVar8);
        iVar8 = iVar8 + iVar2 + unaff_R14;
        if (uVar6 < uVar4) {
            iVar9 = uVar6 * 8;
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar9);
            iVar5 = iVar9 + *(int64_t *)(arg1 + 8);
            iVar2 = (*(int64_t *)(arg1 + 8) - iVar5) + iVar2;
            func_0x000180498030(unaff_R14, iVar5, iVar2);
            uVar4 = iVar2 + unaff_R14;
        } else {
            func_0x000180498030(iVar8, *(undefined8 *)(arg1 + 8), iVar2);
            func_0x0001804986e0(iVar8 + iVar2, 0, (uVar6 - uVar4) * 8);
            uVar4 = unaff_R14;
            iVar9 = iVar2;
        }
        func_0x0001804986e0(uVar4, 0, iVar9);
        iVar2 = *(int64_t *)(arg1 + 8);
        if (iVar2 == 0) goto code_r0x000180065d12;
        iVar5 = iVar2;
        puVar7 = auStack_38;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
           (iVar5 = *(int64_t *)(iVar2 + -8), puVar7 = auStack_38, 0x1f < (iVar2 - iVar5) - 8U))
        goto code_r0x000180065d00;
    } else {
        if (uVar3 < 0x1000) {
            unaff_R14 = fcn.180459890();
            goto code_r0x000180065bf9;
        }
        if (uVar3 + 0x27 <= uVar3) goto code_r0x000180065d2b;
        iVar2 = fcn.180459890(uVar3 + 0x27);
        if (iVar2 != 0) {
            unaff_R14 = iVar2 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_R14 - 8) = iVar2;
            goto code_r0x000180065bf9;
        }
code_r0x000180065d00:
        iVar5 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar7 = auStack_30;
    }
    *(undefined8 *)(puVar7 + -8) = 0x180065d12;
    fcn.180459c3c(iVar5);
code_r0x000180065d12:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + uVar6;
    *(uint64_t *)(arg1 + 8) = unaff_R14;
    return;
}

// ============================================================
// Function: FUN_180065d40
// Address: 0x180065d40
// Size: 125 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180065d40(int64_t arg1)
{
    int64_t *piVar1;
    int64_t var_8h;
    
    (**(code **)(arg1 + 0x88))(*(undefined8 *)(arg1 + 0x80), (int64_t *)(arg1 + 0x40), arg1);
    func_0x00018045476c();
    piVar1 = *(int64_t **)(arg1 + 0x78);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg1 + 0x40));
        *(undefined8 *)(arg1 + 0x78) = 0;
    }
    piVar1 = *(int64_t **)(arg1 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg1);
        *(undefined8 *)(arg1 + 0x38) = 0;
    }
    fcn.180459c3c(arg1, 0x90);
    return 0;
}

// ============================================================
// Function: FUN_180065dd0
// Address: 0x180065dd0
// Size: 46 bytes
// ============================================================
undefined8 fcn.180065dd0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    
    if (*(char *)(arg1 + 8) != '\0') {
        arg2 = *(int64_t *)arg2;
        piVar1 = (int64_t *)(arg2 + 0x40);
        *piVar1 = *piVar1 + -0x10;
        fcn.1800867f0(arg2, 0x180624fc0, 0x1e);
    }
    return 1;
}

// ============================================================
// Function: FUN_180065e20
// Address: 0x180065e20
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180065e20(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)arg1;
    if (piVar1 == (int64_t *)0x0) {
        return;
    }
    piVar2 = (int64_t *)piVar1[0xf];
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != piVar1 + 8);
        piVar1[0xf] = 0;
    }
    piVar2 = (int64_t *)piVar1[7];
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != piVar1);
        piVar1[7] = 0;
    }
    if ((piVar1 != (int64_t *)0x0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, piVar1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_180065e32
// Address: 0x180065e32
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180065e20(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)arg1;
    if (piVar1 == (int64_t *)0x0) {
        return;
    }
    piVar2 = (int64_t *)piVar1[0xf];
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != piVar1 + 8);
        piVar1[0xf] = 0;
    }
    piVar2 = (int64_t *)piVar1[7];
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != piVar1);
        piVar1[7] = 0;
    }
    if ((piVar1 != (int64_t *)0x0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, piVar1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_180065e62
// Address: 0x180065e62
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180065e20(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)arg1;
    if (piVar1 == (int64_t *)0x0) {
        return;
    }
    piVar2 = (int64_t *)piVar1[0xf];
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != piVar1 + 8);
        piVar1[0xf] = 0;
    }
    piVar2 = (int64_t *)piVar1[7];
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != piVar1);
        piVar1[7] = 0;
    }
    if ((piVar1 != (int64_t *)0x0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, piVar1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_180065ea0
// Address: 0x180065ea0
// Size: 106 bytes
// ============================================================
void fcn.180065ea0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    if (*(int64_t *)arg1 != 0) {
        func_0x00018000d5d0(*(int64_t *)arg1, *(undefined8 *)(arg1 + 8));
        iVar1 = *(int64_t *)arg1;
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar1 & 0xfffffffffffffff0U)) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180065ef7;
        fcn.180459c3c(iVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180065f10
// Address: 0x180065f10
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ffh
// WARNING: [rz-ghidra] Detected overlap for variable var_4fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_4f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_500h
// WARNING: [rz-ghidra] Detected overlap for variable var_494h
// WARNING: [rz-ghidra] Detected overlap for variable var_490h
// WARNING: [rz-ghidra] Detected overlap for variable var_46ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4c4h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4cch

int32_t fcn.180065f10(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int64_t var_38h;
    int64_t var_30h;
    
    fcn.1800102c0();
    iVar1 = fcn.180467554(0, arg4);
    if (iVar1 < 0) {
        iVar1 = -1;
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180065f60
// Address: 0x180065f60
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ffh
// WARNING: [rz-ghidra] Detected overlap for variable var_4fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_4f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_500h
// WARNING: [rz-ghidra] Detected overlap for variable var_494h
// WARNING: [rz-ghidra] Detected overlap for variable var_490h
// WARNING: [rz-ghidra] Detected overlap for variable var_46ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4c4h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4cch

int32_t fcn.180065f60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_20h = arg4;
    fcn.1800102c0();
    iVar1 = fcn.180467554(0, (int64_t)&var_20h);
    if (iVar1 < 0) {
        iVar1 = -1;
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180065fc0
// Address: 0x180065fc0
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180065fc0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    int64_t iVar15;
    int32_t iVar16;
    undefined8 unaff_RDI;
    float fVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar7 = *(int64_t *)0x180781f28;
    if (arg1 == 0) {
        arg1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x12e8);
        fVar17 = 0.0;
    } else {
        fVar17 = *(float *)(arg1 + 0x1c);
    }
    iVar4 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20e4);
    uVar5 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x12e8);
    uVar2 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x12fc);
    uVar3 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x12f8);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) == iVar4) {
        iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) + 1;
        if (iVar4 == 0) {
            iVar11 = 8;
        } else {
            arg2 = (int64_t)(uint32_t)(iVar4 >> 0x1f);
            iVar11 = iVar4 / 2 + iVar4;
        }
        if (iVar16 < iVar11) {
            iVar16 = iVar11;
        }
        if (iVar4 < iVar16) {
            uVar12 = fcn.18046d050((int64_t)iVar16 << 4, arg2);
            if (*(int64_t *)(iVar7 + 0x20e8) != 0) {
                func_0x000180498030(uVar12, *(int64_t *)(iVar7 + 0x20e8), (int64_t)*(int32_t *)(iVar7 + 0x20e0) << 4);
                fcn.180460d90(*(undefined8 *)(iVar7 + 0x20e8));
            }
            *(undefined8 *)(iVar7 + 0x20e8) = uVar12;
            *(int32_t *)(iVar7 + 0x20e4) = iVar16;
        }
    }
    iVar14 = (int64_t)*(int32_t *)(iVar7 + 0x20e0);
    iVar6 = *(int64_t *)(iVar7 + 0x20e8);
    *(undefined8 *)(iVar6 + iVar14 * 0x10) = uVar5;
    *(undefined4 *)(iVar6 + 8 + iVar14 * 0x10) = uVar2;
    *(undefined4 *)(iVar6 + 0xc + iVar14 * 0x10) = uVar3;
    *(int32_t *)(iVar7 + 0x20e0) = *(int32_t *)(iVar7 + 0x20e0) + 1;
    iVar6 = *(int64_t *)0x180781f28;
    if (fVar17 == 0.0) {
        fVar17 = *(float *)(iVar7 + 0x12fc);
    }
    *(float *)(*(int64_t *)0x180781f28 + 0x12fc) = fVar17;
    *(int64_t *)(iVar6 + 0x12e8) = arg1;
    func_0x0001801073c0(0);
    if (arg1 != 0) {
        iVar7 = *(int64_t *)(arg1 + 8);
        *(int64_t *)(iVar6 + 0x1320) = iVar7;
        *(int64_t *)(iVar6 + 0x1328) = arg1;
        puVar13 = *(undefined8 **)(iVar7 + 0x2a8);
        puVar1 = puVar13 + *(int32_t *)(iVar7 + 0x2a0);
        for (; puVar13 != puVar1; puVar13 = puVar13 + 1) {
            puVar8 = (undefined8 *)*puVar13;
            if (puVar8[2] == iVar7) {
                *puVar8 = *(undefined8 *)(iVar7 + 0x5c);
                puVar8[1] = iVar7 + 0x88;
            }
        }
        if (*(int64_t *)(iVar6 + 0x15e0) != 0) {
            iVar6 = *(int64_t *)(*(int64_t *)(iVar6 + 0x15e0) + 800);
            iVar14 = *(int64_t *)(iVar7 + 0x30);
            iVar9 = *(int64_t *)(iVar7 + 0x28);
            if ((*(int64_t *)(iVar6 + 0x78) != iVar14) || (*(int64_t *)(iVar6 + 0x70) != iVar9)) {
                *(int64_t *)(iVar6 + 0x70) = iVar9;
                *(int64_t *)(iVar6 + 0x78) = iVar14;
                iVar15 = (int64_t)*(int32_t *)(iVar6 + 0xb0);
                iVar10 = *(int64_t *)(iVar6 + 0xb8);
                *(int64_t *)(iVar10 + -0x10 + iVar15 * 0x10) = iVar9;
                *(int64_t *)(iVar10 + -8 + iVar15 * 0x10) = iVar14;
                func_0x000180124360(iVar6, iVar15 * 2, iVar7, iVar9, unaff_RDI);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180065fe1
// Address: 0x180065fe1
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180065fc0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int32_t iVar9;
    undefined8 uVar10;
    undefined8 *puVar11;
    int64_t iVar12;
    int32_t iVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar7 = *(int64_t *)0x180781f28;
    if (arg1 == 0) {
        arg1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x12e8);
        fVar14 = 0.0;
    } else {
        fVar14 = *(float *)(arg1 + 0x1c);
    }
    iVar4 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20e4);
    uVar5 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x12e8);
    uVar2 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x12fc);
    uVar3 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x12f8);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) == iVar4) {
        iVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) + 1;
        if (iVar4 == 0) {
            iVar9 = 8;
        } else {
            arg2 = (int64_t)(uint32_t)(iVar4 >> 0x1f);
            iVar9 = iVar4 / 2 + iVar4;
        }
        if (iVar13 < iVar9) {
            iVar13 = iVar9;
        }
        if (iVar4 < iVar13) {
            uVar10 = fcn.18046d050((int64_t)iVar13 << 4, arg2);
            if (*(int64_t *)(iVar7 + 0x20e8) != 0) {
                func_0x000180498030(uVar10, *(int64_t *)(iVar7 + 0x20e8), (int64_t)*(int32_t *)(iVar7 + 0x20e0) << 4);
                fcn.180460d90(*(undefined8 *)(iVar7 + 0x20e8));
            }
            *(undefined8 *)(iVar7 + 0x20e8) = uVar10;
            *(int32_t *)(iVar7 + 0x20e4) = iVar13;
        }
    }
    iVar12 = (int64_t)*(int32_t *)(iVar7 + 0x20e0);
    iVar6 = *(int64_t *)(iVar7 + 0x20e8);
    *(undefined8 *)(iVar6 + iVar12 * 0x10) = uVar5;
    *(undefined4 *)(iVar6 + 8 + iVar12 * 0x10) = uVar2;
    *(undefined4 *)(iVar6 + 0xc + iVar12 * 0x10) = uVar3;
    *(int32_t *)(iVar7 + 0x20e0) = *(int32_t *)(iVar7 + 0x20e0) + 1;
    iVar6 = *(int64_t *)0x180781f28;
    if (fVar14 == 0.0) {
        fVar14 = *(float *)(iVar7 + 0x12fc);
    }
    *(float *)(*(int64_t *)0x180781f28 + 0x12fc) = fVar14;
    *(int64_t *)(iVar6 + 0x12e8) = arg1;
    func_0x0001801073c0(0);
    if (arg1 != 0) {
        iVar7 = *(int64_t *)(arg1 + 8);
        *(int64_t *)(iVar6 + 0x1320) = iVar7;
        *(int64_t *)(iVar6 + 0x1328) = arg1;
        puVar11 = *(undefined8 **)(iVar7 + 0x2a8);
        puVar1 = puVar11 + *(int32_t *)(iVar7 + 0x2a0);
        for (; puVar11 != puVar1; puVar11 = puVar11 + 1) {
            puVar8 = (undefined8 *)*puVar11;
            if (puVar8[2] == iVar7) {
                *puVar8 = *(undefined8 *)(iVar7 + 0x5c);
                puVar8[1] = iVar7 + 0x88;
            }
        }
        if (*(int64_t *)(iVar6 + 0x15e0) != 0) {
            iVar6 = *(int64_t *)(*(int64_t *)(iVar6 + 0x15e0) + 800);
            iVar12 = *(int64_t *)(iVar7 + 0x30);
            iVar7 = *(int64_t *)(iVar7 + 0x28);
            if ((*(int64_t *)(iVar6 + 0x78) != iVar12) || (*(int64_t *)(iVar6 + 0x70) != iVar7)) {
                *(int64_t *)(iVar6 + 0x70) = iVar7;
                *(int64_t *)(iVar6 + 0x78) = iVar12;
                iVar4 = *(int32_t *)(iVar6 + 0xb0);
                iVar6 = *(int64_t *)(iVar6 + 0xb8);
                *(int64_t *)(iVar6 + -0x10 + (int64_t)iVar4 * 0x10) = iVar7;
                *(int64_t *)(iVar6 + -8 + (int64_t)iVar4 * 0x10) = iVar12;
                func_0x000180124360();
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180066058
// Address: 0x180066058
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180065fc0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int32_t iVar9;
    undefined8 uVar10;
    undefined8 *puVar11;
    int64_t iVar12;
    int32_t iVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar7 = *(int64_t *)0x180781f28;
    if (arg1 == 0) {
        arg1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x12e8);
        fVar14 = 0.0;
    } else {
        fVar14 = *(float *)(arg1 + 0x1c);
    }
    iVar4 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20e4);
    uVar5 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x12e8);
    uVar2 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x12fc);
    uVar3 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x12f8);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) == iVar4) {
        iVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) + 1;
        if (iVar4 == 0) {
            iVar9 = 8;
        } else {
            arg2 = (int64_t)(uint32_t)(iVar4 >> 0x1f);
            iVar9 = iVar4 / 2 + iVar4;
        }
        if (iVar13 < iVar9) {
            iVar13 = iVar9;
        }
        if (iVar4 < iVar13) {
            uVar10 = fcn.18046d050((int64_t)iVar13 << 4, arg2);
            if (*(int64_t *)(iVar7 + 0x20e8) != 0) {
                func_0x000180498030(uVar10, *(int64_t *)(iVar7 + 0x20e8), (int64_t)*(int32_t *)(iVar7 + 0x20e0) << 4);
                fcn.180460d90(*(undefined8 *)(iVar7 + 0x20e8));
            }
            *(undefined8 *)(iVar7 + 0x20e8) = uVar10;
            *(int32_t *)(iVar7 + 0x20e4) = iVar13;
        }
    }
    iVar12 = (int64_t)*(int32_t *)(iVar7 + 0x20e0);
    iVar6 = *(int64_t *)(iVar7 + 0x20e8);
    *(undefined8 *)(iVar6 + iVar12 * 0x10) = uVar5;
    *(undefined4 *)(iVar6 + 8 + iVar12 * 0x10) = uVar2;
    *(undefined4 *)(iVar6 + 0xc + iVar12 * 0x10) = uVar3;
    *(int32_t *)(iVar7 + 0x20e0) = *(int32_t *)(iVar7 + 0x20e0) + 1;
    iVar6 = *(int64_t *)0x180781f28;
    if (fVar14 == 0.0) {
        fVar14 = *(float *)(iVar7 + 0x12fc);
    }
    *(float *)(*(int64_t *)0x180781f28 + 0x12fc) = fVar14;
    *(int64_t *)(iVar6 + 0x12e8) = arg1;
    func_0x0001801073c0(0);
    if (arg1 != 0) {
        iVar7 = *(int64_t *)(arg1 + 8);
        *(int64_t *)(iVar6 + 0x1320) = iVar7;
        *(int64_t *)(iVar6 + 0x1328) = arg1;
        puVar11 = *(undefined8 **)(iVar7 + 0x2a8);
        puVar1 = puVar11 + *(int32_t *)(iVar7 + 0x2a0);
        for (; puVar11 != puVar1; puVar11 = puVar11 + 1) {
            puVar8 = (undefined8 *)*puVar11;
            if (puVar8[2] == iVar7) {
                *puVar8 = *(undefined8 *)(iVar7 + 0x5c);
                puVar8[1] = iVar7 + 0x88;
            }
        }
        if (*(int64_t *)(iVar6 + 0x15e0) != 0) {
            iVar6 = *(int64_t *)(*(int64_t *)(iVar6 + 0x15e0) + 800);
            iVar12 = *(int64_t *)(iVar7 + 0x30);
            iVar7 = *(int64_t *)(iVar7 + 0x28);
            if ((*(int64_t *)(iVar6 + 0x78) != iVar12) || (*(int64_t *)(iVar6 + 0x70) != iVar7)) {
                *(int64_t *)(iVar6 + 0x70) = iVar7;
                *(int64_t *)(iVar6 + 0x78) = iVar12;
                iVar4 = *(int32_t *)(iVar6 + 0xb0);
                iVar6 = *(int64_t *)(iVar6 + 0xb8);
                *(int64_t *)(iVar6 + -0x10 + (int64_t)iVar4 * 0x10) = iVar7;
                *(int64_t *)(iVar6 + -8 + (int64_t)iVar4 * 0x10) = iVar12;
                func_0x000180124360();
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800660a2
// Address: 0x1800660a2
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180065fc0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    int64_t iVar15;
    int32_t iVar16;
    undefined8 unaff_RDI;
    float fVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar7 = *(int64_t *)0x180781f28;
    if (arg1 == 0) {
        arg1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x12e8);
        fVar17 = 0.0;
    } else {
        fVar17 = *(float *)(arg1 + 0x1c);
    }
    iVar4 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20e4);
    uVar5 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x12e8);
    uVar2 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x12fc);
    uVar3 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x12f8);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) == iVar4) {
        iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) + 1;
        if (iVar4 == 0) {
            iVar11 = 8;
        } else {
            arg2 = (int64_t)(uint32_t)(iVar4 >> 0x1f);
            iVar11 = iVar4 / 2 + iVar4;
        }
        if (iVar16 < iVar11) {
            iVar16 = iVar11;
        }
        if (iVar4 < iVar16) {
            uVar12 = fcn.18046d050((int64_t)iVar16 << 4, arg2);
            if (*(int64_t *)(iVar7 + 0x20e8) != 0) {
                func_0x000180498030(uVar12, *(int64_t *)(iVar7 + 0x20e8), (int64_t)*(int32_t *)(iVar7 + 0x20e0) << 4);
                fcn.180460d90(*(undefined8 *)(iVar7 + 0x20e8));
            }
            *(undefined8 *)(iVar7 + 0x20e8) = uVar12;
            *(int32_t *)(iVar7 + 0x20e4) = iVar16;
        }
    }
    iVar14 = (int64_t)*(int32_t *)(iVar7 + 0x20e0);
    iVar6 = *(int64_t *)(iVar7 + 0x20e8);
    *(undefined8 *)(iVar6 + iVar14 * 0x10) = uVar5;
    *(undefined4 *)(iVar6 + 8 + iVar14 * 0x10) = uVar2;
    *(undefined4 *)(iVar6 + 0xc + iVar14 * 0x10) = uVar3;
    *(int32_t *)(iVar7 + 0x20e0) = *(int32_t *)(iVar7 + 0x20e0) + 1;
    iVar6 = *(int64_t *)0x180781f28;
    if (fVar17 == 0.0) {
        fVar17 = *(float *)(iVar7 + 0x12fc);
    }
    *(float *)(*(int64_t *)0x180781f28 + 0x12fc) = fVar17;
    *(int64_t *)(iVar6 + 0x12e8) = arg1;
    func_0x0001801073c0(0);
    if (arg1 != 0) {
        iVar7 = *(int64_t *)(arg1 + 8);
        *(int64_t *)(iVar6 + 0x1320) = iVar7;
        *(int64_t *)(iVar6 + 0x1328) = arg1;
        puVar13 = *(undefined8 **)(iVar7 + 0x2a8);
        puVar1 = puVar13 + *(int32_t *)(iVar7 + 0x2a0);
        for (; puVar13 != puVar1; puVar13 = puVar13 + 1) {
            puVar8 = (undefined8 *)*puVar13;
            if (puVar8[2] == iVar7) {
                *puVar8 = *(undefined8 *)(iVar7 + 0x5c);
                puVar8[1] = iVar7 + 0x88;
            }
        }
        if (*(int64_t *)(iVar6 + 0x15e0) != 0) {
            iVar6 = *(int64_t *)(*(int64_t *)(iVar6 + 0x15e0) + 800);
            iVar14 = *(int64_t *)(iVar7 + 0x30);
            iVar9 = *(int64_t *)(iVar7 + 0x28);
            if ((*(int64_t *)(iVar6 + 0x78) != iVar14) || (*(int64_t *)(iVar6 + 0x70) != iVar9)) {
                *(int64_t *)(iVar6 + 0x70) = iVar9;
                *(int64_t *)(iVar6 + 0x78) = iVar14;
                iVar15 = (int64_t)*(int32_t *)(iVar6 + 0xb0);
                iVar10 = *(int64_t *)(iVar6 + 0xb8);
                *(int64_t *)(iVar10 + -0x10 + iVar15 * 0x10) = iVar9;
                *(int64_t *)(iVar10 + -8 + iVar15 * 0x10) = iVar14;
                func_0x000180124360(iVar6, iVar15 * 2, iVar7, iVar9, unaff_RDI);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800660e9
// Address: 0x1800660e9
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180065fc0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    undefined8 *puVar13;
    int64_t iVar14;
    int64_t iVar15;
    int32_t iVar16;
    undefined8 unaff_RDI;
    float fVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar7 = *(int64_t *)0x180781f28;
    if (arg1 == 0) {
        arg1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x12e8);
        fVar17 = 0.0;
    } else {
        fVar17 = *(float *)(arg1 + 0x1c);
    }
    iVar4 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20e4);
    uVar5 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x12e8);
    uVar2 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x12fc);
    uVar3 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x12f8);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) == iVar4) {
        iVar16 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x20e0) + 1;
        if (iVar4 == 0) {
            iVar11 = 8;
        } else {
            arg2 = (int64_t)(uint32_t)(iVar4 >> 0x1f);
            iVar11 = iVar4 / 2 + iVar4;
        }
        if (iVar16 < iVar11) {
            iVar16 = iVar11;
        }
        if (iVar4 < iVar16) {
            uVar12 = fcn.18046d050((int64_t)iVar16 << 4, arg2);
            if (*(int64_t *)(iVar7 + 0x20e8) != 0) {
                func_0x000180498030(uVar12, *(int64_t *)(iVar7 + 0x20e8), (int64_t)*(int32_t *)(iVar7 + 0x20e0) << 4);
                fcn.180460d90(*(undefined8 *)(iVar7 + 0x20e8));
            }
            *(undefined8 *)(iVar7 + 0x20e8) = uVar12;
            *(int32_t *)(iVar7 + 0x20e4) = iVar16;
        }
    }
    iVar14 = (int64_t)*(int32_t *)(iVar7 + 0x20e0);
    iVar6 = *(int64_t *)(iVar7 + 0x20e8);
    *(undefined8 *)(iVar6 + iVar14 * 0x10) = uVar5;
    *(undefined4 *)(iVar6 + 8 + iVar14 * 0x10) = uVar2;
    *(undefined4 *)(iVar6 + 0xc + iVar14 * 0x10) = uVar3;
    *(int32_t *)(iVar7 + 0x20e0) = *(int32_t *)(iVar7 + 0x20e0) + 1;
    iVar6 = *(int64_t *)0x180781f28;
    if (fVar17 == 0.0) {
        fVar17 = *(float *)(iVar7 + 0x12fc);
    }
    *(float *)(*(int64_t *)0x180781f28 + 0x12fc) = fVar17;
    *(int64_t *)(iVar6 + 0x12e8) = arg1;
    func_0x0001801073c0(0);
    if (arg1 != 0) {
        iVar7 = *(int64_t *)(arg1 + 8);
        *(int64_t *)(iVar6 + 0x1320) = iVar7;
        *(int64_t *)(iVar6 + 0x1328) = arg1;
        puVar13 = *(undefined8 **)(iVar7 + 0x2a8);
        puVar1 = puVar13 + *(int32_t *)(iVar7 + 0x2a0);
        for (; puVar13 != puVar1; puVar13 = puVar13 + 1) {
            puVar8 = (undefined8 *)*puVar13;
            if (puVar8[2] == iVar7) {
                *puVar8 = *(undefined8 *)(iVar7 + 0x5c);
                puVar8[1] = iVar7 + 0x88;
            }
        }
        if (*(int64_t *)(iVar6 + 0x15e0) != 0) {
            iVar6 = *(int64_t *)(*(int64_t *)(iVar6 + 0x15e0) + 800);
            iVar14 = *(int64_t *)(iVar7 + 0x30);
            iVar9 = *(int64_t *)(iVar7 + 0x28);
            if ((*(int64_t *)(iVar6 + 0x78) != iVar14) || (*(int64_t *)(iVar6 + 0x70) != iVar9)) {
                *(int64_t *)(iVar6 + 0x70) = iVar9;
                *(int64_t *)(iVar6 + 0x78) = iVar14;
                iVar15 = (int64_t)*(int32_t *)(iVar6 + 0xb0);
                iVar10 = *(int64_t *)(iVar6 + 0xb8);
                *(int64_t *)(iVar10 + -0x10 + iVar15 * 0x10) = iVar9;
                *(int64_t *)(iVar10 + -8 + iVar15 * 0x10) = iVar14;
                func_0x000180124360(iVar6, iVar15 * 2, iVar7, iVar9, unaff_RDI);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180066120
// Address: 0x180066120
// Size: 881 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Detected overlap for variable var_ah
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.180066120(int64_t arg1, int64_t arg2)
{
    uint8_t *puVar1;
    int64_t *piVar2;
    int32_t *piVar3;
    undefined4 *puVar4;
    undefined uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint16_t uVar8;
    uint8_t *puVar9;
    uint8_t *puVar10;
    uint64_t *puVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int32_t var_20h;
    
    func_0x00018015e8e0(arg1 + 0x40);
    iVar6 = func_0x00018014fb40(arg1 + 0x40);
    piVar2 = *(int64_t **)(arg1 + 0xa0);
    if (piVar2 != (int64_t *)0x0) {
        var_8h._0_4_ = (int32_t)(*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) * -0x49249249 + -1;
        uVar7 = (**(code **)(*piVar2 + 0x10))(piVar2, &var_8h);
        *(undefined8 *)(iVar6 + 0x30) = uVar7;
    }
    *(undefined *)(arg1 + 100) = 1;
    puVar9 = *(uint8_t **)arg2;
    puVar1 = puVar9 + *(int64_t *)(arg2 + 8);
    if ((((2 < *(int64_t *)(arg2 + 8)) && (*puVar9 == 0xef)) && (puVar9[1] == 0xbb)) && (puVar9[2] == 0xbf)) {
        puVar9 = puVar9 + 3;
    }
    while (puVar9 < puVar1) {
        uVar8 = (uint16_t)(char)*puVar9;
        if ((char)*puVar9 < '\0') {
            puVar10 = puVar9 + 1;
            if ((puVar10 < puVar1) && ((*puVar9 & 0xe0) == 0xc0)) {
                uVar8 = (uint16_t)(*puVar9 & 0x1f) << 6 | (uint16_t)(*puVar10 & 0x3f);
                puVar10 = puVar9 + 2;
                goto code_r0x000180066242;
            }
            if ((puVar9 + 2 < puVar1) && ((*puVar9 & 0xf0) == 0xe0)) {
                uVar8 = ((uint16_t)(*puVar10 & 0x3f) | (int16_t)(char)*puVar9 << 6) << 6 | (uint16_t)(puVar9[2] & 0x3f);
                puVar10 = puVar9 + 3;
                goto code_r0x000180066242;
            }
            if ((puVar9 + 3 < puVar1) && ((*puVar9 & 0xf8) == 0xf0)) {
                uVar8 = 0xfffd;
                puVar10 = puVar9 + 4;
            } else {
                uVar8 = 0xfffd;
            }
code_r0x0001800662b0:
            puVar9 = puVar10;
            if ((*(char *)(arg1 + 0x5c) == '\0') || (uVar8 != 9)) {
                if (uVar8 != 0xd) {
                    iVar6 = *(int64_t *)(arg1 + 0x48);
                    puVar4 = *(undefined4 **)(iVar6 + -0x30);
                    if (puVar4 == *(undefined4 **)(iVar6 + -0x28)) {
                        func_0x000180164e00(iVar6 + -0x38, puVar4, &var_18h);
                    } else {
                        *puVar4 = (undefined4)var_18h;
                        *(int64_t *)(iVar6 + -0x30) = *(int64_t *)(iVar6 + -0x30) + 4;
                    }
                }
            } else {
                uVar12 = 0;
                uVar13 = *(int64_t *)(*(int64_t *)(arg1 + 0x48) + -0x30) -
                         *(int64_t *)(*(int64_t *)(arg1 + 0x48) + -0x38) >> 2;
                uVar13 = (uVar13 / (uint64_t)(int64_t)*(int32_t *)(arg1 + 0x58) + 1) *
                         (int64_t)*(int32_t *)(arg1 + 0x58) - uVar13;
                if (uVar13 != 0) {
                    do {
                        iVar6 = *(int64_t *)(arg1 + 0x48);
                        var_8h._0_4_ = CONCAT13(var_8h._3_1_, 0x20);
                        piVar3 = *(int32_t **)(iVar6 + -0x30);
                        if (piVar3 == *(int32_t **)(iVar6 + -0x28)) {
                            func_0x000180164e00(iVar6 + -0x38, piVar3, &var_8h);
                        } else {
                            *piVar3 = (int32_t)var_8h;
                            *(int64_t *)(iVar6 + -0x30) = *(int64_t *)(iVar6 + -0x30) + 4;
                        }
                        uVar12 = uVar12 + 1;
                    } while (uVar12 < uVar13);
                }
            }
        } else {
            puVar10 = puVar9 + 1;
code_r0x000180066242:
            if (uVar8 != 10) goto code_r0x0001800662b0;
            iVar6 = func_0x00018014fb40(arg1 + 0x40);
            puVar9 = puVar10;
            if (*(int64_t **)(arg1 + 0xa0) != (int64_t *)0x0) {
                var_20h = (int32_t)(*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) * -0x49249249 + -1;
                uVar7 = (**(code **)(**(int64_t **)(arg1 + 0xa0) + 0x10))();
                *(undefined8 *)(iVar6 + 0x30) = uVar7;
            }
        }
    }
    func_0x00018015d710(arg1 + 0x40, 0, 
                        (int32_t)(*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) * -0x49249249 + -1);
    if (*(int64_t *)(arg1 + 0xe8) != *(int64_t *)(arg1 + 0xf0)) {
        func_0x00018000d5d0();
        *(undefined8 *)(arg1 + 0xf0) = *(undefined8 *)(arg1 + 0xe8);
    }
    *(undefined8 *)(arg1 + 0x100) = 0;
    *(undefined8 *)(arg1 + 0x108) = 0;
    if (*(int64_t *)(arg1 + 0x118) != *(int64_t *)(arg1 + 0x120)) {
        *(int64_t *)(arg1 + 0x120) = *(int64_t *)(arg1 + 0x118);
    }
    iVar6 = *(int64_t *)(arg1 + 0x5e8);
    puVar11 = *(uint64_t **)(arg1 + 0x40);
    if (iVar6 == 0) {
        for (; puVar11 < *(uint64_t **)(arg1 + 0x48); puVar11 = puVar11 + 7) {
            for (uVar12 = *puVar11; uVar12 < puVar11[1]; uVar12 = uVar12 + 4) {
                *(undefined *)(uVar12 + 2) = 0;
            }
            *(undefined *)(puVar11 + 3) = 0;
            *(undefined *)((int64_t)puVar11 + 0x2c) = 0;
        }
    } else {
        while (puVar11 < *(uint64_t **)(arg1 + 0x48)) {
            uVar5 = func_0x00018015e9e0(arg1 + 0x110, puVar11, iVar6);
            if (*(uint64_t **)(arg1 + 0x48) <= puVar11 + 7) break;
            *(undefined *)(puVar11 + 10) = uVar5;
            puVar11 = puVar11 + 7;
        }
    }
    func_0x00018015c180(arg1);
    func_0x0001801571c0(arg1);
    *(undefined *)(arg1 + 0x2c8) = 1;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    *(undefined2 *)(arg1 + 0x2d4) = 0;
    return;
}

// ============================================================
// Function: FUN_1800664a0
// Address: 0x1800664a0
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1800664a0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined *puVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x38) = 0;
    puVar5 = (undefined8 *)func_0x00018007c3d0(&var_10h);
    uVar1 = *puVar5;
    *puVar5 = 0;
    iVar2 = *(int64_t *)arg1;
    *(undefined8 *)arg1 = uVar1;
    puVar8 = auStack_28;
    if (iVar2 != 0) {
        if (0xf < *(uint64_t *)(iVar2 + 0x58)) {
            iVar3 = *(int64_t *)(iVar2 + 0x40);
            iVar6 = iVar3;
            puVar7 = auStack_28;
            if ((0xfff < *(uint64_t *)(iVar2 + 0x58) + 1) &&
               (iVar6 = *(int64_t *)(iVar3 + -8), puVar7 = auStack_28, 0x1f < (iVar3 - iVar6) - 8U)) {
                pcVar4 = (code *)swi(0x29);
                iVar6 = (*pcVar4)(5);
                puVar7 = auStack_20;
            }
            *(undefined8 *)(puVar7 + -8) = 0x18006652f;
            fcn.180459c3c(iVar6);
        }
        *(undefined8 *)(iVar2 + 0x50) = 0;
        *(undefined8 *)(iVar2 + 0x58) = 0xf;
        *(undefined *)(iVar2 + 0x40) = 0;
        *(undefined8 *)(puVar7 + -8) = 0x180066548;
        func_0x00018000ace0(iVar2 + 0x18);
        *(undefined8 *)(puVar7 + -8) = 0x180066551;
        func_0x00018007d750(iVar2 + 8);
        *(undefined8 *)(puVar7 + -8) = 0x18006655e;
        fcn.180459c3c(iVar2, 0x60);
        puVar8 = puVar7;
    }
    iVar2 = *(int64_t *)(puVar8 + 0x38);
    if (iVar2 != 0) {
        *(undefined8 *)(puVar8 + -8) = 0x180066571;
        func_0x000180004e40(iVar2 + 0x40);
        *(undefined8 *)(puVar8 + -8) = 0x18006657a;
        func_0x00018000ace0(iVar2 + 0x18);
        *(undefined8 *)(puVar8 + -8) = 0x180066583;
        func_0x00018007d750(iVar2 + 8);
        *(undefined8 *)(puVar8 + -8) = 0x180066590;
        fcn.180459c3c(iVar2, 0x60);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800665b0
// Address: 0x1800665b0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ffh
// WARNING: [rz-ghidra] Detected overlap for variable var_4fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_4f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_500h
// WARNING: [rz-ghidra] Detected overlap for variable var_494h
// WARNING: [rz-ghidra] Detected overlap for variable var_490h
// WARNING: [rz-ghidra] Detected overlap for variable var_46ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4c4h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4cch

void fcn.1800665b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_10h;
    
    if (arg2 != 0) {
        var_18h = arg3;
        var_20h = arg4;
        fcn.1800102c0();
        fcn.180467554(0, (int64_t)&var_18h);
    }
    return;
}

// ============================================================
// Function: FUN_1800665c9
// Address: 0x1800665c9
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ffh
// WARNING: [rz-ghidra] Detected overlap for variable var_4fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_4f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_500h
// WARNING: [rz-ghidra] Detected overlap for variable var_494h
// WARNING: [rz-ghidra] Detected overlap for variable var_490h
// WARNING: [rz-ghidra] Detected overlap for variable var_46ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4c4h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4cch

void fcn.1800665b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_10h;
    
    if (arg2 != 0) {
        var_18h = arg3;
        var_20h = arg4;
        fcn.1800102c0();
        fcn.180467554(0, (int64_t)&var_18h);
    }
    return;
}

