// Chunk 57 - 50 functions

// ============================================================
// Function: FUN_1800bc7b0
// Address: 0x1800bc7b0
// Size: 6837 bytes
// ============================================================
void fcn.1800bc7b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t **ppiVar1;
    undefined4 *puVar2;
    undefined uVar3;
    char *pcVar4;
    undefined (*pauVar5) [16];
    undefined8 uVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined auVar10 [16];
    undefined auVar11 [16];
    undefined auVar12 [16];
    char cVar13;
    int32_t iVar14;
    uint32_t uVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t *piVar18;
    int64_t *piVar19;
    undefined8 uVar20;
    int64_t iVar21;
    uint64_t uVar22;
    int64_t iVar23;
    undefined8 *puVar24;
    undefined (*pauVar25) [16];
    int64_t **ppiVar26;
    undefined (*pauVar27) [16];
    uint64_t uVar28;
    uint64_t uVar29;
    undefined8 *puVar30;
    char *pcVar31;
    undefined *puVar32;
    undefined *puVar33;
    undefined *puVar34;
    undefined *puVar35;
    undefined *puVar36;
    undefined8 *puVar37;
    uint64_t *puVar38;
    undefined (*pauVar39) [16];
    undefined8 *puVar40;
    undefined8 *puVar41;
    bool bVar42;
    undefined4 uVar43;
    undefined8 uStack_ab0;
    undefined auStack_aa8 [8];
    undefined auStack_aa0 [24];
    int64_t var_a88h;
    int64_t var_a80h;
    int64_t var_a78h;
    int64_t var_a70h;
    int64_t var_a68h;
    int64_t var_a60h;
    int64_t var_a58h;
    int64_t var_a48h;
    int64_t var_a38h;
    int64_t var_a30h;
    int64_t var_a28h;
    int64_t var_a18h;
    undefined4 var_a0fh;
    undefined2 var_a0bh;
    undefined var_a09h;
    int64_t var_a08h;
    int64_t var_a00h;
    int64_t var_9f8h;
    int64_t var_9f0h;
    int64_t var_9e8h;
    int64_t var_9e0h;
    int64_t var_9d8h;
    int64_t var_9d0h;
    int64_t var_9c8h;
    undefined4 uStack_9c0;
    undefined4 uStack_9bc;
    int64_t var_9b8h;
    int64_t var_9b0h;
    int64_t var_9a8h;
    int64_t var_9a0h;
    int64_t var_998h;
    int64_t var_990h;
    int64_t var_988h;
    int64_t var_978h;
    int64_t var_970h;
    int64_t var_968h;
    int64_t var_958h;
    int64_t var_950h;
    int64_t var_948h;
    int64_t var_940h;
    int64_t var_938h;
    int64_t var_930h;
    int64_t var_928h;
    int64_t var_920h;
    int64_t var_918h;
    int64_t var_910h;
    int64_t var_908h;
    int64_t var_900h;
    int64_t var_8f8h;
    int64_t var_8f0h;
    int64_t var_8e8h;
    int64_t var_8d8h;
    int64_t var_8c8h;
    int64_t var_8c0h;
    int64_t var_8b8h;
    int64_t var_8b0h;
    int64_t var_8a8h;
    int64_t var_898h;
    int64_t var_890h;
    int64_t var_888h;
    int64_t var_880h;
    int64_t var_870h;
    int64_t var_868h;
    int64_t var_860h;
    int64_t var_858h;
    int64_t var_848h;
    int64_t var_840h;
    int32_t iStack_838;
    undefined4 uStack_834;
    int64_t var_830h;
    undefined4 uStack_828;
    undefined4 uStack_824;
    int64_t var_820h;
    undefined4 uStack_818;
    undefined4 uStack_814;
    int64_t var_810h;
    undefined4 uStack_808;
    undefined4 uStack_804;
    int64_t var_800h;
    undefined4 uStack_7f8;
    undefined4 uStack_7f4;
    int64_t var_7f0h;
    int64_t var_7e8h;
    int64_t var_7e0h;
    int64_t var_7d8h;
    int64_t var_7d0h;
    int64_t var_7c0h;
    int64_t var_7b8h;
    int64_t var_7b0h;
    int64_t var_7a8h;
    int64_t var_798h;
    int64_t var_790h;
    int64_t var_788h;
    int64_t var_780h;
    int64_t var_770h;
    int64_t var_768h;
    int64_t var_760h;
    int64_t var_758h;
    int64_t var_748h;
    int64_t var_740h;
    int64_t var_738h;
    int64_t var_730h;
    int64_t var_720h;
    int64_t var_718h;
    int64_t var_710h;
    int64_t var_708h;
    int64_t var_6f8h;
    int64_t var_6f0h;
    int64_t var_6e8h;
    int64_t var_6e0h;
    int64_t var_6d0h;
    int64_t var_6c8h;
    int64_t var_6c0h;
    int64_t var_6b8h;
    int64_t var_6a8h;
    int64_t var_6a0h;
    int64_t var_698h;
    int64_t var_690h;
    int64_t var_680h;
    int64_t var_678h;
    int64_t var_670h;
    int64_t var_668h;
    int64_t var_658h;
    int64_t var_650h;
    int64_t var_648h;
    int64_t var_640h;
    int64_t var_630h;
    int64_t var_628h;
    int64_t var_620h;
    int64_t var_618h;
    int64_t var_608h;
    int64_t var_600h;
    int64_t var_5f8h;
    int64_t var_5f0h;
    int64_t var_5e0h;
    int64_t var_5d8h;
    int64_t var_5d0h;
    int64_t var_5c8h;
    int64_t var_5b8h;
    int64_t var_5b0h;
    int64_t var_5a8h;
    int64_t var_5a0h;
    int64_t var_590h;
    int64_t var_588h;
    int64_t var_578h;
    int64_t var_568h;
    int64_t var_560h;
    int64_t var_558h;
    int64_t var_54ch;
    int64_t var_540h;
    int64_t var_538h;
    int64_t var_530h;
    undefined4 var_528h;
    undefined4 uStack_524;
    undefined4 uStack_520;
    undefined4 uStack_51c;
    int64_t var_518h;
    int64_t var_510h;
    int64_t var_508h;
    int64_t var_500h;
    int64_t var_4f8h;
    int64_t var_4f0h;
    int64_t var_4e8h;
    int64_t var_4e0h;
    int64_t var_4d4h;
    int64_t var_4c8h;
    int64_t var_4c0h;
    int64_t var_4b8h;
    undefined4 var_4b0h;
    undefined4 uStack_4ac;
    undefined4 uStack_4a8;
    undefined4 uStack_4a4;
    int64_t var_4a0h;
    int64_t var_498h;
    int64_t var_490h;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_478h;
    int64_t var_470h;
    int64_t var_468h;
    int64_t var_45ch;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_440h;
    undefined4 var_438h;
    undefined4 uStack_434;
    undefined4 uStack_430;
    undefined4 uStack_42c;
    int64_t var_428h;
    int64_t var_420h;
    int64_t var_418h;
    int64_t var_410h;
    int64_t var_408h;
    int64_t var_400h;
    int64_t var_3f8h;
    int64_t var_3f0h;
    int64_t var_3e4h;
    int64_t var_3d8h;
    int64_t var_3d0h;
    int64_t var_3c8h;
    undefined4 var_3c0h;
    undefined4 uStack_3bc;
    undefined4 uStack_3b8;
    undefined4 uStack_3b4;
    int64_t var_3b0h;
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_390h;
    int64_t var_388h;
    int64_t var_380h;
    int64_t var_378h;
    int64_t var_36ch;
    int64_t var_360h;
    int64_t var_358h;
    int64_t var_350h;
    undefined4 var_348h;
    undefined4 uStack_344;
    undefined4 uStack_340;
    undefined4 uStack_33c;
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_310h;
    int64_t var_308h;
    int64_t var_300h;
    int64_t var_2f4h;
    int64_t var_2e8h;
    int64_t var_2e0h;
    int64_t var_2d8h;
    undefined4 var_2d0h;
    undefined4 uStack_2cc;
    undefined4 uStack_2c8;
    undefined4 uStack_2c4;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1e8h;
    int64_t var_1d8h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b8h;
    int64_t var_1a8h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_138h;
    int64_t var_130h;
    undefined4 uStack_128;
    undefined4 uStack_124;
    undefined4 uStack_120;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_bch;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    undefined4 uStack_88;
    undefined4 uStack_84;
    int64_t var_80h;
    undefined var_78h [8];
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar35 = auStack_aa8;
    puVar32 = auStack_aa8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_aa8;
    var_9d8h._0_4_ = *(uint32_t *)arg4;
    var_9d8h._4_4_ = *(undefined4 *)(arg4 + 4);
    var_9d0h._0_4_ = *(int32_t *)(arg4 + 8);
    var_9d0h._4_4_ = *(undefined4 *)(arg4 + 0xc);
    var_9c8h._0_4_ = *(undefined4 *)(arg4 + 0x10);
    var_9c8h._4_4_ = *(undefined4 *)(arg4 + 0x14);
    uStack_9c0 = *(undefined4 *)(arg4 + 0x18);
    uStack_9bc = *(undefined4 *)(arg4 + 0x1c);
    var_9b8h._0_4_ = *(undefined4 *)(arg4 + 0x20);
    var_9b8h._4_4_ = *(undefined4 *)(arg4 + 0x24);
    var_9b0h._0_4_ = *(undefined4 *)(arg4 + 0x28);
    var_9b0h._4_4_ = *(undefined4 *)(arg4 + 0x2c);
    var_9a8h._0_4_ = *(undefined4 *)(arg4 + 0x30);
    var_9a8h._4_4_ = *(undefined4 *)(arg4 + 0x34);
    var_9a0h._0_4_ = *(undefined4 *)(arg4 + 0x38);
    var_9a0h._4_4_ = *(undefined4 *)(arg4 + 0x3c);
    var_998h._0_4_ = *(undefined4 *)(arg4 + 0x40);
    var_998h._4_4_ = *(undefined4 *)(arg4 + 0x44);
    var_990h._0_4_ = *(undefined4 *)(arg4 + 0x48);
    var_990h._4_4_ = *(undefined4 *)(arg4 + 0x4c);
    var_988h = *(int64_t *)(arg4 + 0x50);
    puVar36 = (undefined *)0x0;
    var_a48h._0_1_ = 0;
    pcVar4 = *(char **)(arg2 + 0x18);
    pcVar31 = *(char **)(arg2 + 0x10);
    var_9e0h = arg3;
    if (pcVar31 != pcVar4) {
        do {
            if (*pcVar31 != '\0') {
                iVar14 = func_0x00018004a3c0(pcVar31 + 0x18);
                if (iVar14 == 0) {
                    iVar17 = func_0x00018000b450(pcVar31 + 0x18);
                    uVar15 = func_0x00018046eadc(iVar17 + 9);
                    uVar16 = 2;
                    if ((int32_t)uVar15 < 2) {
                        uVar16 = uVar15;
                    }
                    var_9d8h._0_4_ = 0;
                    if (0 < (int32_t)uVar16) {
                        var_9d8h._0_4_ = uVar16;
                    }
                }
                if ((*pcVar31 != '\0') && (cVar13 = func_0x00018000a630(pcVar31 + 0x18, 0x18063fcfc), cVar13 != '\0')) {
                    puVar36 = (undefined *)0x1;
                    var_9d8h._0_4_ = 2;
                    var_9d0h._0_4_ = 1;
                }
            }
            pcVar31 = pcVar31 + 0x38;
        } while (pcVar31 != pcVar4);
        var_a48h._0_1_ = (uint8_t)puVar36;
    }
    puVar40 = *(undefined8 **)arg2;
    _var_a08h = ZEXT816(0);
    var_9f8h = 0;
    var_978h = 0x1806407c8;
    var_970h = (int64_t)&var_a08h;
    var_968h._0_2_ = 0;
    var_a18h = 0x10;
    var_9f0h = (int64_t)puVar40;
    iVar17 = func_0x00018001ba60(0, &var_a18h);
    uVar43 = func_0x000180498030(iVar17, var_a08h, var_a00h - var_a08h);
    if (var_a08h != 0) {
        func_0x0001800c21a0(uVar43, var_a08h, var_9f8h - var_a08h >> 3);
    }
    var_a00h = iVar17;
    var_a08h = iVar17;
    var_9f8h = iVar17 + 0x80;
    (**(code **)*puVar40)(puVar40, &var_978h);
    iVar23 = var_9e0h;
    iVar17 = var_a28h;
    if (var_968h._1_1_ != '\0') {
        var_9d8h._0_4_ = 2;
        var_9d0h._0_4_ = 1;
    }
    var_840h._0_4_ = (uint32_t)var_9d8h;
    var_840h._4_4_ = var_9d8h._4_4_;
    iStack_838 = (int32_t)var_9d0h;
    uStack_834 = var_9d0h._4_4_;
    var_830h._0_4_ = (undefined4)var_9c8h;
    var_830h._4_4_ = var_9c8h._4_4_;
    uStack_828 = uStack_9c0;
    uStack_824 = uStack_9bc;
    var_820h._0_4_ = (undefined4)var_9b8h;
    var_820h._4_4_ = var_9b8h._4_4_;
    uStack_818 = (undefined4)var_9b0h;
    uStack_814 = var_9b0h._4_4_;
    var_810h._0_4_ = (undefined4)var_9a8h;
    var_810h._4_4_ = var_9a8h._4_4_;
    uStack_808 = (undefined4)var_9a0h;
    uStack_804 = var_9a0h._4_4_;
    var_800h._0_4_ = (undefined4)var_998h;
    var_800h._4_4_ = var_998h._4_4_;
    uStack_7f8 = (undefined4)var_990h;
    uStack_7f4 = var_990h._4_4_;
    var_7f0h = var_988h;
    var_7e8h = 0;
    var_7e0h = 0;
    var_7d8h = 0;
    var_7d0h = 0;
    var_7c0h = 0;
    var_7b8h = 0;
    var_7b0h = 0;
    var_7a8h = 0;
    var_798h = 0;
    var_790h = 0;
    var_788h = 0;
    var_780h = 0;
    var_770h = 0;
    var_768h = 0;
    var_760h = 0;
    var_758h = 0;
    var_748h = 0;
    var_740h = 0;
    var_738h = 0;
    var_730h = 0;
    var_720h = 0;
    var_718h = 0;
    var_710h = 0;
    var_708h = 0;
    var_6f8h = 0;
    var_6f0h = 0;
    var_6e8h = 0;
    var_6e0h = 0;
    var_6d0h = 0;
    var_6c8h = 0;
    var_6c0h = 0;
    var_6b8h = 0;
    var_6a8h = 0;
    var_6a0h = 0;
    var_698h = 0;
    var_690h = 0;
    var_680h = 0;
    var_678h = 0;
    var_670h = 0;
    var_668h = 0;
    var_658h = 0;
    var_650h = 0;
    var_648h = 0;
    var_640h = 0;
    var_630h = 0;
    var_628h = 0;
    var_620h = 0;
    var_618h = 0;
    var_608h = 0;
    var_600h = 0;
    var_5f8h = 0;
    var_5f0h = 0;
    var_5e0h = 0;
    var_5d8h = 0;
    var_5d0h = 0;
    var_5c8h = 0;
    var_5b8h = 0;
    var_5b0h = 0;
    var_5a8h = 0;
    var_5a0h = 0;
    var_590h = 0;
    _var_588h = ZEXT816(0);
    _var_578h = ZEXT816(0);
    var_568h = 0;
    uVar16 = (uint32_t)(unkuint3)((uint64_t)var_a28h >> 8);
    var_a28h._0_4_ = uVar16 << 8;
    var_558h._0_4_ = *(undefined4 *)0x1807826bc;
    stack0xfffffffffffffaac = 0;
    var_54ch = 0;
    var_560h = 0x1806419a0;
    var_540h._0_1_ = 0;
    var_538h = var_a18h;
    var_530h._0_1_ = 0;
    var_530h._1_4_ = var_a0fh;
    var_530h._5_2_ = var_a0bh;
    var_530h._7_1_ = var_a09h;
    var_528h = (undefined4)var_a38h;
    uStack_524 = var_a38h._4_4_;
    uStack_520 = (undefined4)var_a30h;
    uStack_51c = var_a30h._4_4_;
    var_518h._0_4_ = (int32_t)var_a28h;
    var_510h = 0x18063ec88;
    var_508h = 0;
    var_500h = 0;
    var_4f8h = 0;
    var_4f0h = 0;
    var_a28h._0_4_ = uVar16 << 8;
    var_4e0h._0_4_ = *(undefined4 *)0x1807826bc;
    stack0xfffffffffffffb24 = 0;
    var_4d4h = 0;
    var_4e8h = 0x1806419a0;
    var_4c8h._0_1_ = 0;
    var_4c0h = var_a18h;
    var_4b8h._0_1_ = 0;
    var_4b8h._1_4_ = var_a0fh;
    var_4b8h._5_2_ = var_a0bh;
    var_4b8h._7_1_ = var_a09h;
    var_4b0h = (undefined4)var_a38h;
    uStack_4ac = var_a38h._4_4_;
    uStack_4a8 = (undefined4)var_a30h;
    uStack_4a4 = var_a30h._4_4_;
    var_4a0h._0_4_ = (int32_t)var_a28h;
    var_498h = 0x18063e2d0;
    var_490h = 0;
    var_488h = 0;
    var_480h = 0;
    var_478h = 0;
    var_a28h._0_4_ = uVar16 << 8;
    var_468h._0_4_ = *(undefined4 *)0x1807826bc;
    stack0xfffffffffffffb9c = 0;
    var_45ch = 0;
    var_470h = 0x1806419a0;
    var_450h._0_1_ = 0;
    var_448h = var_a18h;
    var_440h._0_1_ = 0;
    var_440h._1_4_ = var_a0fh;
    var_440h._5_2_ = var_a0bh;
    var_440h._7_1_ = var_a09h;
    var_438h = (undefined4)var_a38h;
    uStack_434 = var_a38h._4_4_;
    uStack_430 = (undefined4)var_a30h;
    uStack_42c = var_a30h._4_4_;
    var_428h._0_4_ = (int32_t)var_a28h;
    var_420h = 0x18063e1a0;
    var_418h = 0;
    var_410h = 0;
    var_408h = 0;
    var_400h = 0;
    var_a28h._0_4_ = uVar16 << 8;
    var_3f0h._0_4_ = *(undefined4 *)0x1807826bc;
    stack0xfffffffffffffc14 = 0;
    var_3e4h = 0;
    var_3f8h = 0x1806419a0;
    var_3d8h._0_1_ = 0;
    var_3d0h = var_a18h;
    var_3c8h._0_1_ = 0;
    var_3c8h._1_4_ = var_a0fh;
    var_3c8h._5_2_ = var_a0bh;
    var_3c8h._7_1_ = var_a09h;
    var_3c0h = (undefined4)var_a38h;
    uStack_3bc = var_a38h._4_4_;
    uStack_3b8 = (undefined4)var_a30h;
    uStack_3b4 = var_a30h._4_4_;
    var_3b0h._0_4_ = (int32_t)var_a28h;
    var_3a8h = 0x180625fe4;
    var_3a0h = 0;
    var_398h = 0;
    var_390h = 0;
    var_388h = 0;
    var_a28h._0_4_ = uVar16 << 8;
    var_378h._0_4_ = *(undefined4 *)0x1807826bc;
    stack0xfffffffffffffc8c = 0;
    var_36ch = 0;
    var_380h = 0x1806419a0;
    var_360h._0_1_ = 0;
    var_358h = var_a18h;
    var_350h._0_1_ = 0;
    var_350h._1_4_ = var_a0fh;
    var_350h._5_2_ = var_a0bh;
    var_350h._7_1_ = var_a09h;
    var_348h = (undefined4)var_a38h;
    uStack_344 = var_a38h._4_4_;
    uStack_340 = (undefined4)var_a30h;
    uStack_33c = var_a30h._4_4_;
    var_338h._0_4_ = (int32_t)var_a28h;
    var_330h = 0x18063e1a8;
    var_328h = 0;
    var_320h = 0;
    var_318h = 0;
    var_310h = 0;
    var_a28h._0_4_ = uVar16 << 8;
    var_2c0h._0_4_ = (int32_t)var_a28h;
    var_a28h = iVar17 & 0xffffffffffffff00;
    var_300h._0_4_ = *(undefined4 *)0x1807826bc;
    stack0xfffffffffffffd04 = 0;
    var_2f4h = 0;
    var_308h = 0x1806419a0;
    var_2e8h._0_1_ = 0;
    var_2e0h = var_a18h;
    var_2d8h._0_1_ = 0;
    var_2d8h._1_4_ = var_a0fh;
    var_2d8h._5_2_ = var_a0bh;
    var_2d8h._7_1_ = var_a09h;
    var_2d0h = (undefined4)var_a38h;
    uStack_2cc = var_a38h._4_4_;
    uStack_2c8 = (undefined4)var_a30h;
    uStack_2c4 = var_a30h._4_4_;
    var_2b8h._0_4_ = (undefined4)var_9b8h;
    var_2b8h._4_4_ = var_9b8h._4_4_;
    var_2b0h = 0;
    var_2a8h = 0;
    var_2a0h = 0;
    var_298h = 0;
    var_290h = var_9e0h;
    var_848h = arg1;
    piVar18 = (int64_t *)func_0x0001800d6e80(var_9e0h, &var_a38h, 0x18063f598, 5);
    var_288h = *piVar18;
    var_280h = 0;
    var_278h = 0;
    var_270h = 0;
    var_268h = 0;
    var_260h = 0;
    var_258h._0_2_ = 1;
    var_250h = 0;
    var_248h = 0;
    var_240h._0_1_ = 0;
    stack0xfffffffffffffdc4 = 0;
    var_230h = 0;
    var_228h._0_1_ = 0;
    var_220h = 0;
    var_218h = 0;
    var_210h._0_2_ = 0;
    _var_208h = ZEXT816(0);
    var_1f8h = 0;
    var_1f0h = 0;
    _var_1e8h = ZEXT816(0);
    _var_1d8h = ZEXT816(0);
    var_1c8h = 0;
    var_1c0h = 0;
    _var_1b8h = ZEXT816(0);
    _var_1a8h = ZEXT816(0);
    var_198h = 0;
    var_190h = 0;
    _var_188h = ZEXT816(0);
    _var_178h = ZEXT816(0);
    var_168h = 0;
    var_160h = 0;
    var_158h = 0;
    var_150h = 0;
    var_148h = 0;
    func_0x0001800c0de0(&var_208h);
    func_0x0001800c0de0(&var_1f0h);
    func_0x0001800cd5c0(&var_798h, iVar23, CONCAT44(var_9b0h._4_4_, (undefined4)var_9b0h));
    func_0x0001800cd770(&var_798h, &var_770h, puVar40);
    puVar37 = (undefined8 *)(uint64_t)(uint32_t)var_9d8h;
    if ((0 < (int32_t)(uint32_t)var_9d8h) &&
       ((piVar18 = (int64_t *)func_0x0001800d6fc0(iVar23, &var_a18h, 0x1806228a0), *piVar18 != 0 ||
        (piVar18 = (int64_t *)func_0x0001800d6fc0(iVar23, &var_a18h, 0x1806228c0), *piVar18 != 0)))) {
        var_a38h = 0x18063ff58;
        var_a30h = (int64_t)&var_210h;
        var_a28h = (int64_t)&var_210h + 1;
        (**(code **)*puVar40)(puVar40, &var_a38h);
        puVar37 = (undefined8 *)(uint64_t)(uint32_t)var_9d8h;
    }
    if (((1 < (int32_t)puVar37) && ((char)var_210h == '\0')) && (var_210h._1_1_ == '\0')) {
        var_248h = (int64_t)&var_6a8h;
        func_0x0001800d6fc0(iVar23, &var_a18h, 0x180625d34);
        if ((var_a18h == 0) || (iVar14 = func_0x0001800aa2c0(&var_798h), iVar14 != 0)) {
            piVar18 = (int64_t *)CONCAT44(var_9a0h._4_4_, (undefined4)var_9a0h);
            if (piVar18 != (int64_t *)0x0) {
                iVar17 = *piVar18;
                while (iVar17 != 0) {
                    func_0x0001800d6fc0(iVar23, &var_a18h, iVar17);
                    if ((var_a18h != 0) && (iVar14 = func_0x0001800aa2c0(&var_798h), iVar14 == 0))
                    goto code_r0x0001800bd246;
                    piVar18 = piVar18 + 1;
                    iVar17 = *piVar18;
                }
            }
        } else {
code_r0x0001800bd246:
            var_240h._0_1_ = 1;
        }
    }
    if (0 < (int32_t)puVar37) {
        var_a80h = iVar23;
        var_a88h = (int64_t)puVar40;
        func_0x0001800ac190(&var_6a8h, &var_798h, &var_770h, &var_9d8h);
        if ((*(char *)0x180778018 != '\0') && (*(char *)0x180777ff8 != '\0')) {
            func_0x0001800c7410(&var_6f8h, &var_770h, puVar40);
        }
        var_a58h = 0;
        var_a60h = 0;
        var_a68h = (int64_t)&var_6f8h;
        var_a70h = iVar23;
        var_a80h = CONCAT44(var_990h._4_4_, (undefined4)var_990h);
        var_a88h = CONCAT71(var_a88h._1_7_, (undefined)var_240h);
        var_a78h = (int64_t)puVar40;
        func_0x0001800c7640(&var_748h, &var_770h, &var_720h, var_248h);
        func_0x0001800ca0a0(&var_6d0h, puVar40);
        puVar37 = (undefined8 *)(uint64_t)(uint32_t)var_9d8h;
    }
    piVar18 = (int64_t *)CONCAT44(var_9a8h._4_4_, (undefined4)var_9a8h);
    var_a18h = (int64_t)piVar18;
    if (piVar18 != (int64_t *)0x0) {
        iVar17 = *piVar18;
        if (iVar17 != 0) {
            do {
                iVar21 = 0;
                puVar36 = (undefined *)0x666666666666666;
                var_a18h = (int64_t)piVar18;
                uVar16 = func_0x000180498cd0(iVar17);
                var_a30h = (int64_t)uVar16;
                var_a38h = iVar17;
                piVar19 = (int64_t *)func_0x0001800d8ef0(iVar23, &var_a38h);
                if (piVar19 != (int64_t *)0x0) {
                    iVar21 = *piVar19;
                }
                var_9e8h = iVar21;
                if (iVar21 != 0) {
                    var_68h = 0;
                    var_60h = 0xf;
                    stack0xffffffffffffff89 = SUB1615(ZEXT816(0), 1);
                    auVar10[15] = 0;
                    auVar10._0_15_ = stack0xffffffffffffff89;
                    _var_78h = auVar10 << 8;
                    var_58h._0_4_ = 0;
                    var_58h._4_1_ = 0;
                    uVar20 = func_0x000180498cd0(iVar21);
                    func_0x00018000f180(var_78h, iVar21, uVar20);
                    pauVar5 = *(undefined (**) [16])(arg1 + 0x2e0);
                    if (pauVar5 == *(undefined (**) [16])(arg1 + 0x2e8)) {
                        iVar17 = ((int64_t)pauVar5 - *(int64_t *)(arg1 + 0x2d8)) / 0x28;
                        if (iVar17 == 0x666666666666666) {
                            func_0x000180010010();
                            goto code_r0x0001800be25f;
                        }
                        uVar28 = ((int64_t)*(undefined (**) [16])(arg1 + 0x2e8) - *(int64_t *)(arg1 + 0x2d8) >> 3) *
                                 -0x3333333333333333;
                        uVar22 = 0x666666666666666 - (uVar28 >> 1);
                        puVar34 = auStack_aa8;
                        if (uVar22 <= uVar28 && uVar28 - uVar22 != 0) goto code_r0x0001800be253;
                        uVar22 = iVar17 + 1;
                        uVar28 = uVar28 + (uVar28 >> 1);
                        uVar29 = uVar22;
                        if (uVar22 <= uVar28) {
                            uVar29 = uVar28;
                        }
                        puVar34 = auStack_aa8;
                        if (0x666666666666666 < uVar29) goto code_r0x0001800be253;
                        puVar40 = (undefined8 *)(uVar29 * 0x28);
                        if (puVar40 != (undefined8 *)0x0) {
                            if (puVar40 < (undefined8 *)0x1000) {
                                puVar36 = (undefined *)func_0x000180459890(puVar40);
                                goto code_r0x0001800bd51f;
                            }
                            puVar34 = auStack_aa8;
                            if ((undefined8 *)((int64_t)puVar40 + 0x27) <= puVar40) goto code_r0x0001800be253;
                            iVar23 = func_0x000180459890();
                            if (iVar23 != 0) {
                                puVar36 = (undefined *)(iVar23 + 0x27U & 0xffffffffffffffe0);
                                *(int64_t *)*(undefined (*) [16])(puVar36 + -8) = iVar23;
                                goto code_r0x0001800bd51f;
                            }
code_r0x0001800bda3b:
                            pcVar7 = (code *)swi(0x29);
                            iVar17 = (*pcVar7)(5);
                            puVar32 = auStack_aa0;
                            goto code_r0x0001800bda45;
                        }
                        puVar36 = (undefined *)0x0;
code_r0x0001800bd51f:
                        pauVar39 = (undefined (*) [16])(puVar36 + iVar17 * 0x28);
                        *pauVar39 = ZEXT816(0);
                        *(undefined8 *)pauVar39[1] = 0;
                        *(undefined8 *)(pauVar39[1] + 8) = 0;
                        *(undefined (*) [8])*pauVar39 = var_78h;
                        *(int64_t *)(*pauVar39 + 8) = var_70h;
                        *(int64_t *)pauVar39[1] = var_68h;
                        *(int64_t *)(pauVar39[1] + 8) = var_60h;
                        var_68h = 0;
                        var_60h = 0xf;
                        auVar12[15] = 0;
                        auVar12._0_15_ = stack0xffffffffffffff89;
                        _var_78h = auVar12 << 8;
                        *(undefined4 *)pauVar39[2] = (undefined4)var_58h;
                        pauVar39[2][4] = var_58h._4_1_;
                        pauVar27 = *(undefined (**) [16])(arg1 + 0x2e0);
                        pauVar25 = *(undefined (**) [16])(arg1 + 0x2d8);
                        puVar34 = puVar36;
                        if (pauVar5 != pauVar27) {
                            func_0x0001800d46c0(*(undefined (**) [16])(arg1 + 0x2d8), pauVar5, puVar36);
                            puVar34 = pauVar39[2] + 8;
                            pauVar27 = *(undefined (**) [16])(arg1 + 0x2e0);
                            pauVar25 = pauVar5;
                        }
                        func_0x0001800d46c0(pauVar25, pauVar27, puVar34);
                        iVar17 = *(int64_t *)(arg1 + 0x2d8);
                        if (iVar17 != 0) {
                            iVar23 = *(int64_t *)(arg1 + 0x2e0);
                            for (; iVar17 != iVar23; iVar17 = iVar17 + 0x28) {
                                func_0x000180004e40(iVar17);
                            }
                            iVar17 = *(int64_t *)(arg1 + 0x2d8);
                            uVar28 = (*(int64_t *)(arg1 + 0x2e8) - iVar17 >> 3) * 8;
                            if (0xfff < uVar28) {
                                if (0x1f < (iVar17 - *(int64_t *)(iVar17 + -8)) - 8U) goto code_r0x0001800bda3b;
                                uVar28 = uVar28 + 0x27;
                                iVar17 = *(int64_t *)(iVar17 + -8);
                            }
                            func_0x000180459c3c(iVar17, uVar28);
                        }
                        *(undefined **)(arg1 + 0x2d8) = puVar36;
                        puVar34 = puVar36 + uVar22 * 0x28;
                        *(undefined **)(arg1 + 0x2e0) = puVar34;
                        *(undefined **)(arg1 + 0x2e8) = puVar36 + (int64_t)puVar40;
                    } else {
                        *pauVar5 = ZEXT816(0);
                        *(undefined8 *)pauVar5[1] = 0;
                        *(undefined8 *)(pauVar5[1] + 8) = 0;
                        *(undefined (*) [8])*pauVar5 = var_78h;
                        *(int64_t *)(*pauVar5 + 8) = var_70h;
                        *(int64_t *)pauVar5[1] = var_68h;
                        *(int64_t *)(pauVar5[1] + 8) = var_60h;
                        var_68h = 0;
                        var_60h = 0xf;
                        auVar11[15] = 0;
                        auVar11._0_15_ = stack0xffffffffffffff89;
                        _var_78h = auVar11 << 8;
                        *(undefined4 *)pauVar5[2] = (undefined4)var_58h;
                        pauVar5[2][4] = var_58h._4_1_;
                        *(int64_t *)(arg1 + 0x2e0) = *(int64_t *)(arg1 + 0x2e0) + 0x28;
                        puVar34 = *(undefined **)(arg1 + 0x2e0);
                    }
                    puVar37 = (undefined8 *)0x0;
                    puVar40 = (undefined8 *)0x10;
                    iVar17 = *(int64_t *)(arg1 + 0x2d8);
                    if (0xf < (uint64_t)var_60h) {
                        uVar28 = var_60h + 1;
                        iVar23 = (int64_t)var_78h;
                        if (0xfff < uVar28) {
                            iVar23 = *(int64_t *)((int64_t)var_78h + -8);
                            puVar33 = auStack_aa8;
                            if (0x1f < ((int64_t)var_78h - iVar23) - 8U) goto code_r0x0001800bdff7;
                            uVar28 = var_60h + 0x28;
                        }
                        func_0x000180459c3c(iVar23, uVar28);
                    }
                    iVar23 = var_678h;
                    if (((uint64_t)(var_678h * 3) >> 2 <= (uint64_t)var_670h) &&
                       (iVar21 = func_0x0001800ac7f0(&var_680h, &var_9e8h), iVar21 == 0)) {
                        iVar21 = 0x10;
                        if (iVar23 != 0) {
                            iVar21 = iVar23 * 2;
                        }
                        func_0x0001800c12b0(var_78h, &var_668h, iVar21);
                        iVar23 = var_680h;
                        if (var_678h != 0) {
                            do {
                                uVar28 = *(uint64_t *)(var_680h + (int64_t)puVar37 * 0x10);
                                if (uVar28 != var_668h) {
                                    uVar22 = (uVar28 >> 5 ^ uVar28) >> 4;
                                    uVar29 = 0;
                                    do {
                                        uVar22 = uVar22 & var_70h - 1U;
                                        puVar38 = (uint64_t *)(uVar22 * 0x10 + (int64_t)var_78h);
                                        if (*puVar38 == var_60h) {
                                            *puVar38 = uVar28;
                                            goto code_r0x0001800bd7d3;
                                        }
                                        if (*puVar38 == uVar28) goto code_r0x0001800bd7d3;
                                        uVar22 = uVar22 + 1 + uVar29;
                                        uVar29 = uVar29 + 1;
                                    } while (uVar29 <= var_70h - 1U);
                                    puVar38 = (uint64_t *)0x0;
code_r0x0001800bd7d3:
                                    *puVar38 = *(uint64_t *)(var_680h + (int64_t)puVar37 * 0x10);
                                    *(undefined *)(puVar38 + 1) = *(undefined *)(var_680h + 8 + (int64_t)puVar37 * 0x10)
                                    ;
                                }
                                puVar37 = (undefined8 *)((int64_t)puVar37 + 1);
                                piVar18 = (int64_t *)var_a18h;
                            } while (puVar37 < (uint64_t)var_678h);
                        }
                        var_680h = (int64_t)var_78h;
                        var_678h = var_70h;
                        if (iVar23 != 0) {
                            func_0x0001800f4640();
                        }
                    }
                    iVar23 = func_0x0001800c1340(&var_680h, &var_9e8h);
                    *(char *)(iVar23 + 8) = (char)((int64_t)puVar34 - iVar17 >> 3) * -0x33 + -1;
                    iVar23 = var_9e0h;
                }
                var_a18h = (int64_t)(piVar18 + 1);
                iVar17 = *(int64_t *)var_a18h;
                piVar18 = (int64_t *)var_a18h;
            } while (iVar17 != 0);
            piVar18 = (int64_t *)CONCAT44(var_9a8h._4_4_, (undefined4)var_9a8h);
            puVar37 = (undefined8 *)(uint64_t)(uint32_t)var_9d8h;
            puVar36 = (undefined *)(uint64_t)(uint8_t)var_a48h;
        }
        puVar33 = auStack_aa8;
        if (0x20 < (uint64_t)(var_a18h - (int64_t)piVar18 >> 3)) goto code_r0x0001800be23e;
    }
    uVar22 = var_9f0h;
    puVar40 = (undefined8 *)0x10;
    if (((int32_t)var_9d0h < 1) && ((int32_t)puVar37 < 2)) {
        piVar18 = (int64_t *)0x0;
        puVar33 = auStack_aa8;
        var_a8h = var_9f0h;
code_r0x0001800bda76:
        puVar37 = (undefined8 *)var_a00h;
        puVar30 = (undefined8 *)var_a08h;
        if (var_a08h != var_a00h) {
            do {
                puVar33[0x60] = 0;
                uVar20 = *puVar30;
                *(undefined8 *)(puVar33 + -8) = 0x1800bda9c;
                func_0x0001800ad7a0(&var_848h, uVar20, puVar33 + 0x60);
                if (((puVar33[0x60] & 4) != 0) && (((uint64_t)puVar36 & 1) == 0)) {
                    puVar36 = (undefined *)(uint64_t)(uint8_t)((uint8_t)puVar36 | 4);
                }
                puVar30 = puVar30 + 1;
            } while (puVar30 != puVar37);
            puVar33[0x60] = (char)puVar36;
        }
        var_130h._0_4_ = *(undefined4 *)0x1807826a0;
        var_130h._4_4_ = *(undefined4 *)(var_a8h + 0xc);
        uStack_128 = *(undefined4 *)(var_a8h + 0x10);
        uStack_124 = *(undefined4 *)(var_a8h + 0x14);
        uStack_120 = *(undefined4 *)(var_a8h + 0x18);
        var_138h = 0x180641ed8;
        _var_e8h = ZEXT816(0);
        var_c8h._0_1_ = 1;
        stack0xffffffffffffff3c = 0;
        var_bch = 0;
        var_90h._0_4_ = *(undefined4 *)(puVar33 + 0x70);
        var_90h._4_4_ = *(undefined4 *)(puVar33 + 0x74);
        uStack_88 = *(undefined4 *)(puVar33 + 0x78);
        uStack_84 = *(undefined4 *)(puVar33 + 0x7c);
        var_80h._0_1_ = 0;
        var_80h._1_2_ = var_a28h._1_2_;
        var_80h._3_1_ = var_a28h._3_1_;
        *(undefined8 *)(puVar33 + -8) = 0x1800bdbab;
        var_118h = (int64_t)piVar18;
        var_110h = (int64_t)piVar18;
        var_108h = (int64_t)piVar18;
        var_100h = (int64_t)piVar18;
        var_f8h = (int64_t)piVar18;
        var_f0h = (int64_t)piVar18;
        var_d8h = (int64_t)piVar18;
        var_d0h = (int64_t)piVar18;
        var_b0h = (int64_t)piVar18;
        var_a0h = (int64_t)piVar18;
        var_98h = (int64_t)piVar18;
        uVar43 = func_0x0001800ad7a0(&var_848h, &var_138h, puVar33 + 0x60);
        *(undefined4 *)(arg1 + 0x1c) = uVar43;
        puVar30 = *(undefined8 **)(arg1 + 0x2e0);
        for (puVar41 = *(undefined8 **)(arg1 + 0x2d8); puVar41 != puVar30; puVar41 = puVar41 + 5) {
            if (*(char *)((int64_t)puVar41 + 0x24) != '\0') {
                puVar24 = puVar41;
                if (0xf < (uint64_t)puVar41[3]) {
                    puVar24 = (undefined8 *)*puVar41;
                }
                *(undefined8 **)(puVar33 + 0x70) = puVar24;
                *(undefined8 *)(puVar33 + 0x78) = puVar41[2];
                *(undefined8 *)(puVar33 + -8) = 0x1800bdbf1;
                uVar43 = func_0x0001800cf010(arg1, puVar33 + 0x70);
                *(undefined4 *)(puVar41 + 4) = uVar43;
            }
        }
        piVar19 = *(int64_t **)(arg1 + 0x2f8);
        if (piVar19 != (int64_t *)0x0) {
            puVar37 = *(undefined8 **)(arg1 + 0x2f0);
            do {
                iVar17 = puVar37[(int64_t)piVar18 * 3];
                if ((iVar17 == 0) || (*(int64_t *)(arg1 + 0x308) == 0)) {
                    bVar42 = iVar17 == *(int64_t *)(arg1 + 0x308);
                } else {
                    if ((puVar37 + (int64_t)piVar18 * 3)[1] != *(int64_t *)(arg1 + 0x310)) break;
                    *(undefined8 *)(puVar33 + -8) = 0x1800bdc51;
                    iVar14 = func_0x000180497f30(iVar17);
                    bVar42 = iVar14 == 0;
                }
                if ((!bVar42) || (piVar18 = (int64_t *)((int64_t)piVar18 + 1), piVar19 <= piVar18)) break;
            } while( true );
        }
code_r0x0001800bdc69:
        if (piVar18 != piVar19) {
            puVar37 = *(undefined8 **)(arg1 + 0x2f0);
            puVar40 = (undefined8 *)((int64_t)puVar40 + puVar37[(int64_t)piVar18 * 3 + 1] + 2);
            do {
                while( true ) {
                    piVar18 = (int64_t *)((int64_t)piVar18 + 1);
                    if (piVar19 <= piVar18) goto code_r0x0001800bdc69;
                    iVar17 = puVar37[(int64_t)piVar18 * 3];
                    if ((iVar17 == 0) || (*(int64_t *)(arg1 + 0x308) == 0)) break;
                    if ((puVar37 + (int64_t)piVar18 * 3)[1] != *(int64_t *)(arg1 + 0x310)) goto code_r0x0001800bdc69;
                    *(undefined8 *)(puVar33 + -8) = 0x1800bdcb9;
                    iVar14 = func_0x000180497f30(iVar17);
                    if (iVar14 != 0) goto code_r0x0001800bdc69;
                }
            } while (iVar17 == *(int64_t *)(arg1 + 0x308));
            goto code_r0x0001800bdc69;
        }
        for (iVar17 = *(int64_t *)arg1; iVar17 != *(int64_t *)(arg1 + 8); iVar17 = iVar17 + 0xa8) {
            puVar40 = (undefined8 *)((int64_t)puVar40 + *(int64_t *)(iVar17 + 0x10));
        }
        ppiVar1 = (int64_t **)(arg1 + 0x378);
        *(undefined8 *)(puVar33 + -8) = 0x1800bdd01;
        func_0x00018000b240(ppiVar1, puVar40);
        if (*(char *)0x180777e98 == '\0') {
            if (*(char *)0x180778560 == '\0') {
                if (*(char *)0x180778078 == '\0') {
                    if (*(char *)0x180778580 == '\0') {
                        cVar13 = (*(char *)0x180777fb8 != '\0') + '\x06';
                    } else {
                        cVar13 = '\b';
                    }
                } else {
                    cVar13 = '\t';
                }
            } else {
                cVar13 = '\n';
            }
        } else {
            cVar13 = '\v';
        }
        *(undefined8 *)(arg1 + 0x388) = 1;
        ppiVar26 = ppiVar1;
        if (0xf < *(uint64_t *)(arg1 + 0x390)) {
            ppiVar26 = (int64_t **)*ppiVar1;
        }
        *(char *)ppiVar26 = cVar13;
        *(undefined *)((int64_t)ppiVar26 + 1) = 0;
        puVar33[0x60] = 3;
        uVar28 = *(uint64_t *)(arg1 + 0x388);
        if (*(uint64_t *)(arg1 + 0x390) == uVar28) {
            *(undefined8 *)(puVar33 + 0x20) = 1;
            *(undefined8 *)(puVar33 + -8) = 0x1800bddc1;
            func_0x00018000ee80(ppiVar1, 1, puVar33[0x60], puVar33 + 0x60);
        } else {
            *(uint64_t *)(arg1 + 0x388) = uVar28 + 1;
            if (*(uint64_t *)(arg1 + 0x390) < 0x10) {
                *(undefined2 *)(uVar28 + (int64_t)ppiVar1) = 3;
            } else {
                *(undefined2 *)(uVar28 + (int64_t)*ppiVar1) = 3;
            }
        }
        uVar28 = *(uint64_t *)(arg1 + 0x300);
        *(undefined (*) [16])(puVar33 + 0x70) = ZEXT816(0);
        puVar40 = (undefined8 *)0x0;
        var_a28h = 0;
        if (uVar28 == 0) {
            puVar30 = *(undefined8 **)(puVar33 + 0x78);
            puVar37 = *(undefined8 **)(puVar33 + 0x70);
        } else {
            puVar35 = puVar33;
            if (0xfffffffffffffff < uVar28) {
code_r0x0001800be25f:
                *(undefined8 *)(puVar35 + -8) = 0x1800be264;
                func_0x000180010010();
                pcVar7 = (code *)swi(3);
                (*pcVar7)();
                return;
            }
            uVar22 = uVar28 * 0x10;
            puVar41 = puVar40;
            if (uVar22 != 0) {
                if (uVar22 < 0x1000) {
                    *(undefined8 *)(puVar33 + -8) = 0x1800bde41;
                    puVar41 = (undefined8 *)func_0x000180459890();
                } else {
                    if (uVar22 + 0x27 <= uVar22) {
                        *(undefined8 *)(puVar33 + -8) = 0x1800be23d;
                        func_0x000180004720();
code_r0x0001800be23e:
                        *(undefined8 *)(puVar33 + -8) = 0x1800be252;
                        func_0x0001800acea0(var_9f0h + 0xc, 0x18063fd08);
                        puVar34 = puVar33;
code_r0x0001800be253:
                        *(undefined8 *)(puVar34 + -8) = 0x1800be258;
                        func_0x000180004720();
                        pcVar7 = (code *)swi(3);
                        (*pcVar7)();
                        return;
                    }
                    *(undefined8 *)(puVar33 + -8) = 0x1800bde22;
                    iVar17 = func_0x000180459890();
                    if (iVar17 == 0) goto code_r0x0001800bdff7;
                    puVar41 = (undefined8 *)(iVar17 + 0x27U & 0xffffffffffffffe0);
                    puVar41[-1] = iVar17;
                }
            }
            *(undefined8 **)(puVar33 + 0x70) = puVar41;
            puVar40 = puVar41 + uVar28 * 2;
            puVar30 = puVar41;
            do {
                *puVar30 = 0;
                puVar30[1] = 0;
                puVar30 = puVar30 + 2;
                uVar28 = uVar28 - 1;
            } while (uVar28 != 0);
            var_a28h = (int64_t)puVar40;
            *(undefined8 **)(puVar33 + 0x78) = puVar30;
            puVar37 = puVar41;
        }
        uVar22 = 0;
        uVar28 = *(uint64_t *)(arg1 + 0x2f8);
        if (uVar28 != 0) {
            iVar17 = *(int64_t *)(arg1 + 0x2f0);
            do {
                piVar18 = (int64_t *)(iVar17 + uVar22 * 0x18);
                iVar23 = *piVar18;
                if ((iVar23 == 0) || (*(int64_t *)(arg1 + 0x308) == 0)) {
                    bVar42 = iVar23 == *(int64_t *)(arg1 + 0x308);
                } else {
                    if (piVar18[1] != *(int64_t *)(arg1 + 0x310)) break;
                    *(undefined8 *)(puVar33 + -8) = 0x1800bded1;
                    iVar14 = func_0x000180497f30(iVar23);
                    bVar42 = iVar14 == 0;
                }
                if ((!bVar42) || (uVar22 = uVar22 + 1, uVar28 <= uVar22)) break;
            } while( true );
        }
        uVar28 = *(uint64_t *)(arg1 + 0x2f8);
code_r0x0001800bdef0:
        if (uVar22 != uVar28) {
            puVar2 = (undefined4 *)(*(int64_t *)(arg1 + 0x2f0) + uVar22 * 0x18);
            uVar43 = puVar2[1];
            uVar8 = puVar2[2];
            uVar9 = puVar2[3];
            puVar41 = puVar37 + (uint64_t)(*(int32_t *)(*(int64_t *)(arg1 + 0x2f0) + 0x10 + uVar22 * 0x18) - 1) * 2;
            *(undefined4 *)puVar41 = *puVar2;
            *(undefined4 *)((int64_t)puVar41 + 4) = uVar43;
            *(undefined4 *)(puVar41 + 1) = uVar8;
            *(undefined4 *)((int64_t)puVar41 + 0xc) = uVar9;
            uVar29 = *(uint64_t *)(arg1 + 0x2f8);
            do {
                while( true ) {
                    uVar22 = uVar22 + 1;
                    if (uVar29 <= uVar22) goto code_r0x0001800bdef0;
                    piVar18 = (int64_t *)(*(int64_t *)(arg1 + 0x2f0) + uVar22 * 0x18);
                    iVar17 = *piVar18;
                    if ((iVar17 == 0) || (*(int64_t *)(arg1 + 0x308) == 0)) break;
                    if (piVar18[1] != *(int64_t *)(arg1 + 0x310)) goto code_r0x0001800bdef0;
                    *(undefined8 *)(puVar33 + -8) = 0x1800bdf60;
                    iVar14 = func_0x000180497f30(iVar17);
                    if (iVar14 != 0) goto code_r0x0001800bdef0;
                }
            } while (iVar17 == *(int64_t *)(arg1 + 0x308));
            goto code_r0x0001800bdef0;
        }
        *(undefined8 *)(puVar33 + -8) = 0x1800bdf8c;
        func_0x0001800cdce0(arg1 + 0x378, (int64_t)puVar30 - (int64_t)puVar37 >> 4 & 0xffffffff);
        for (puVar41 = puVar37; puVar41 != puVar30; puVar41 = puVar41 + 2) {
            uVar43 = *(undefined4 *)(puVar41 + 1);
            *(undefined8 *)(puVar33 + -8) = 0x1800bdfaf;
            func_0x0001800cdce0(arg1 + 0x378, uVar43);
            uVar20 = puVar41[1];
            uVar6 = *puVar41;
            *(undefined8 *)(puVar33 + -8) = 0x1800bdfc2;
            func_0x00018000d970(arg1 + 0x378, uVar6, uVar20);
        }
        if (puVar37 == (undefined8 *)0x0) goto code_r0x0001800be009;
        puVar40 = (undefined8 *)((int64_t)puVar40 - (int64_t)puVar37 & 0xfffffffffffffff0);
        if ((undefined8 *)0xfff < puVar40) {
            puVar30 = puVar37 + -1;
            puVar37 = (undefined8 *)((int64_t)puVar37 + (-8 - (int64_t)(undefined8 *)*puVar30));
            if ((undefined8 *)0x1f < puVar37) goto code_r0x0001800bdff7;
            puVar40 = (undefined8 *)((int64_t)puVar40 + 0x27);
            puVar37 = (undefined8 *)*puVar30;
        }
    } else {
        var_910h = CONCAT44(var_998h._4_4_, (undefined4)var_998h);
        var_938h = CONCAT44(var_9b8h._4_4_, (undefined4)var_9b8h);
        var_958h = 0x1806414d8;
        var_950h = (int64_t)&var_658h;
        var_948h = (int64_t)&var_630h;
        var_940h = (int64_t)&var_608h;
        var_930h = (int64_t)&var_680h;
        var_928h = (int64_t)&var_560h;
        var_920h = (int64_t)&var_6a8h;
        var_918h = (int64_t)&var_798h;
        piVar18 = (int64_t *)0x0;
        var_900h = 0;
        var_8f8h = 0;
        var_8f0h = 0;
        var_8e8h = 0;
        _var_8d8h = ZEXT816(0);
        var_8c8h = 0;
        var_8c0h = 0;
        var_8b8h = 0;
        var_8b0h = 0;
        var_8a8h = 0;
        var_898h = 0;
        var_890h = 0;
        var_888h = 0;
        var_880h = 0;
        var_870h = 0;
        var_868h = 0;
        var_860h = 0;
        var_858h = 0;
        var_908h = arg1;
        (***(code ***)var_9f0h)(var_9f0h, &var_958h);
        if (var_870h != 0) {
            func_0x0001800f4640();
            var_870h = 0;
            var_868h = 0;
        }
        if (var_898h != 0) {
            func_0x0001800f4640();
            var_898h = 0;
            var_890h = 0;
        }
        if (var_8c0h != 0) {
            func_0x0001800f4640();
            var_8c0h = 0;
            var_8b8h = 0;
        }
        if (var_8d8h == 0) {
code_r0x0001800bda5c:
            puVar33 = puVar32;
            var_a8h = uVar22;
            if (var_900h != 0) {
                *(undefined8 *)(puVar32 + -8) = 0x1800bda6d;
                func_0x0001800f4640();
            }
            goto code_r0x0001800bda76;
        }
        iVar17 = var_8d8h;
        puVar32 = auStack_aa8;
        if (((var_8c8h - var_8d8h & 0xfffffffffffffff0U) < 0x1000) ||
           (iVar17 = *(int64_t *)(var_8d8h + -8), puVar33 = auStack_aa8, puVar32 = auStack_aa8,
           (var_8d8h - iVar17) - 8U < 0x20)) {
code_r0x0001800bda45:
            *(undefined8 *)(puVar32 + -8) = 0x1800bda4a;
            func_0x000180459c3c(iVar17);
            _var_8d8h = ZEXT816(0);
            var_8c8h = (int64_t)piVar18;
            goto code_r0x0001800bda5c;
        }
code_r0x0001800bdff7:
        pcVar7 = (code *)swi(0x29);
        (*pcVar7)(5);
        puVar33 = puVar33 + 8;
    }
    *(undefined8 *)(puVar33 + -8) = 0x1800be009;
    func_0x000180459c3c(puVar37, puVar40);
code_r0x0001800be009:
    uVar28 = 0;
    iVar17 = *(int64_t *)(arg1 + 0x2d8);
    if ((int32_t)(*(int64_t *)(arg1 + 0x2e0) - iVar17 >> 3) * -0x33333333 != 0) {
        uVar3 = puVar33[0x60];
        do {
            if (*(char *)(iVar17 + 0x24 + uVar28 * 0x28) != '\0') {
                cVar13 = (char)uVar28 + '\x01';
                puVar33[0x60] = cVar13;
                puVar40 = (undefined8 *)(arg1 + 0x378);
                uVar22 = *(uint64_t *)(arg1 + 0x388);
                if (*(uint64_t *)(arg1 + 0x390) == uVar22) {
                    *(undefined8 *)(puVar33 + 0x20) = 1;
                    *(undefined8 *)(puVar33 + -8) = 0x1800be0af;
                    func_0x00018000ee80(puVar40, 1, uVar3, puVar33 + 0x60);
                } else {
                    *(uint64_t *)(arg1 + 0x388) = uVar22 + 1;
                    if (0xf < *(uint64_t *)(arg1 + 0x390)) {
                        puVar40 = (undefined8 *)*puVar40;
                    }
                    *(char *)((int64_t)puVar40 + uVar22) = cVar13;
                    *(undefined *)((int64_t)puVar40 + uVar22 + 1) = 0;
                }
                uVar43 = *(undefined4 *)(*(int64_t *)(arg1 + 0x2d8) + 0x20 + uVar28 * 0x28);
                *(undefined8 *)(puVar33 + -8) = 0x1800be0c7;
                func_0x0001800cdce0(arg1 + 0x378, uVar43);
            }
            uVar16 = (int32_t)uVar28 + 1;
            uVar28 = (uint64_t)uVar16;
            iVar17 = *(int64_t *)(arg1 + 0x2d8);
        } while (uVar16 < (uint32_t)((int32_t)(*(int64_t *)(arg1 + 0x2e0) - iVar17 >> 3) * -0x33333333));
    }
    puVar33[0x60] = 0;
    puVar40 = (undefined8 *)(arg1 + 0x378);
    uVar28 = *(uint64_t *)(arg1 + 0x388);
    if (*(uint64_t *)(arg1 + 0x390) == uVar28) {
        *(undefined8 *)(puVar33 + 0x20) = 1;
        *(undefined8 *)(puVar33 + -8) = 0x1800be141;
        func_0x00018000ee80(puVar40, 1, puVar33[0x60], puVar33 + 0x60);
    } else {
        *(uint64_t *)(arg1 + 0x388) = uVar28 + 1;
        if (0xf < *(uint64_t *)(arg1 + 0x390)) {
            puVar40 = (undefined8 *)*puVar40;
        }
        *(undefined2 *)((int64_t)puVar40 + uVar28) = 0;
    }
    iVar17 = *(int64_t *)(arg1 + 8);
    iVar23 = *(int64_t *)arg1;
    *(undefined8 *)(puVar33 + -8) = 0x1800be168;
    func_0x0001800cdce0(arg1 + 0x378, (int32_t)(iVar17 - iVar23 >> 3) * 0x3cf3cf3d);
    puVar40 = *(undefined8 **)(arg1 + 8);
    for (puVar37 = *(undefined8 **)arg1; puVar37 != puVar40; puVar37 = puVar37 + 0x15) {
        puVar30 = puVar37;
        if (0xf < (uint64_t)puVar37[3]) {
            puVar30 = (undefined8 *)*puVar37;
        }
        uVar20 = puVar37[2];
        *(undefined8 *)(puVar33 + -8) = 0x1800be193;
        func_0x00018000d970(arg1 + 0x378, puVar30, uVar20);
    }
    uVar43 = *(undefined4 *)(arg1 + 0x1c);
    *(undefined8 *)(puVar33 + -8) = 0x1800be1ae;
    func_0x0001800cdce0(arg1 + 0x378, uVar43);
    *(undefined8 *)(puVar33 + -8) = 0x1800be1bb;
    func_0x0001800be270(&var_848h);
    var_978h = 0x18063f2c0;
    if (var_a08h != 0) {
        iVar17 = var_a08h;
        if ((0xfff < (uint64_t)((var_9f8h - var_a08h >> 3) * 8)) &&
           (iVar17 = *(int64_t *)(var_a08h + -8), 0x1f < (var_a08h - iVar17) - 8U)) {
            iVar17 = 5;
            pcVar7 = (code *)swi(0x29);
            (*pcVar7)(5);
            puVar33 = puVar33 + 8;
        }
        *(undefined8 *)(puVar33 + -8) = 0x1800be215;
        func_0x000180459c3c(iVar17);
    }
    *(undefined8 *)(puVar33 + -8) = 0x1800be224;
    func_0x000180459870(var_50h ^ (uint64_t)puVar33);
    return;
}

// ============================================================
// Function: FUN_1800be270
// Address: 0x1800be270
// Size: 588 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800be270(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg1 + 0x6e8) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x6e8) = 0;
        *(undefined8 *)(arg1 + 0x6f0) = 0;
    }
    func_0x00018000ace0(arg1 + 0x6d0);
    func_0x00018000ace0(arg1 + 0x6b8);
    func_0x0001800bfa00(arg1 + 0x6a0);
    func_0x000180028940(arg1 + 0x688);
    func_0x00018002a260(arg1 + 0x670);
    func_0x00018000ace0(arg1 + 0x658);
    func_0x00018000ace0(arg1 + 0x640);
    func_0x0001800c07c0(arg1 + 0x2d0);
    func_0x0001800c07c0(arg1 + 0x2b8);
    if (*(int64_t *)(arg1 + 0x290) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x290) = 0;
        *(undefined8 *)(arg1 + 0x298) = 0;
    }
    if (*(int64_t *)(arg1 + 0x268) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x268) = 0;
        *(undefined8 *)(arg1 + 0x270) = 0;
    }
    if (*(int64_t *)(arg1 + 0x240) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x240) = 0;
        *(undefined8 *)(arg1 + 0x248) = 0;
    }
    if (*(int64_t *)(arg1 + 0x218) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x218) = 0;
        *(undefined8 *)(arg1 + 0x220) = 0;
    }
    func_0x0001800bffd0(arg1 + 0x1f0);
    if (*(int64_t *)(arg1 + 0x1c8) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x1c8) = 0;
        *(undefined8 *)(arg1 + 0x1d0) = 0;
    }
    if (*(int64_t *)(arg1 + 0x1a0) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x1a0) = 0;
        *(undefined8 *)(arg1 + 0x1a8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x178) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x178) = 0;
        *(undefined8 *)(arg1 + 0x180) = 0;
    }
    if (*(int64_t *)(arg1 + 0x150) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x150) = 0;
        *(undefined8 *)(arg1 + 0x158) = 0;
    }
    if (*(int64_t *)(arg1 + 0x128) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x128) = 0;
        *(undefined8 *)(arg1 + 0x130) = 0;
    }
    if (*(int64_t *)(arg1 + 0x100) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x100) = 0;
        *(undefined8 *)(arg1 + 0x108) = 0;
    }
    if (*(int64_t *)(arg1 + 0xd8) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0xd8) = 0;
        *(undefined8 *)(arg1 + 0xe0) = 0;
    }
    if (*(int64_t *)(arg1 + 0xb0) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xb8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x88) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x88) = 0;
        *(undefined8 *)(arg1 + 0x90) = 0;
    }
    piVar1 = (int64_t *)(arg1 + 0x60);
    iVar2 = *piVar1;
    if (iVar2 != 0) {
        uVar4 = 0;
        uVar3 = *(uint64_t *)(arg1 + 0x68);
        if (uVar3 != 0) {
            do {
                func_0x00018000ace0(uVar4 * 0x38 + iVar2 + 0x10);
                uVar4 = uVar4 + 1;
            } while (uVar4 < uVar3);
        }
        func_0x0001800f4640(*piVar1);
        *piVar1 = 0;
        *(undefined8 *)(arg1 + 0x68) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800be4c0
// Address: 0x1800be4c0
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800be4c0(int64_t arg1, int64_t arg2)
{
    int64_t unaff_RBX;
    int64_t unaff_RDI;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined *)arg1 = *(undefined *)arg2;
    *(undefined *)(arg1 + 1) = *(undefined *)(arg2 + 1);
    *(undefined *)(arg1 + 0x50) = 0;
    if (*(char *)(arg2 + 0x50) != '\0') {
        fcn.1800c24e0(unaff_RDI, unaff_retaddr, unaff_RBX);
        *(undefined *)(arg1 + 0x50) = 1;
    }
    *(undefined *)(arg1 + 0x58) = *(undefined *)(arg2 + 0x58);
    *(undefined *)(arg1 + 0x59) = *(undefined *)(arg2 + 0x59);
    return arg1;
}

// ============================================================
// Function: FUN_1800be530
// Address: 0x1800be530
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800be530(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    if (*(int64_t *)(arg1 + 0x58) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x58) = 0;
        *(undefined8 *)(arg1 + 0x60) = 0;
    }
    func_0x00018007c820(arg1 + 0x40);
    func_0x0001800c17d0(arg1 + 0x28);
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar4 = *piVar1;
    if (iVar4 != 0) {
        iVar3 = *(int64_t *)(arg1 + 0x18);
        for (; iVar4 != iVar3; iVar4 = iVar4 + 0x38) {
            func_0x000180004e40(iVar4 + 0x18);
        }
        iVar4 = *piVar1;
        iVar3 = iVar4;
        puVar5 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x20) - iVar4 >> 3) * 8)) &&
           (iVar3 = *(int64_t *)(iVar4 + -8), puVar5 = auStack_28, 0x1f < (iVar4 - iVar3) - 8U)) {
            iVar3 = 5;
            pcVar2 = (code *)swi(0x29);
            (*pcVar2)(5);
            puVar5 = auStack_20;
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800c0a20;
        func_0x000180459c3c(iVar3);
        *piVar1 = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
        *(undefined8 *)(arg1 + 0x20) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800be580
// Address: 0x1800be580
// Size: 1099 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_464h
// WARNING: [rz-ghidra] Detected overlap for variable var_460h
// WARNING: [rz-ghidra] Detected overlap for variable var_967h
// WARNING: [rz-ghidra] Detected overlap for variable var_a27h
// WARNING: [rz-ghidra] Detected overlap for variable var_a25h
// WARNING: [rz-ghidra] Detected overlap for variable var_554h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0fh
// WARNING: [rz-ghidra] Detected overlap for variable var_52fh
// WARNING: [rz-ghidra] Detected overlap for variable var_a0bh
// WARNING: [rz-ghidra] Detected overlap for variable var_52bh
// WARNING: [rz-ghidra] Detected overlap for variable var_a09h
// WARNING: [rz-ghidra] Detected overlap for variable var_529h
// WARNING: [rz-ghidra] Detected overlap for variable var_528h
// WARNING: [rz-ghidra] Detected overlap for variable var_4dch
// WARNING: [rz-ghidra] Detected overlap for variable var_4b7h
// WARNING: [rz-ghidra] Detected overlap for variable var_4b3h
// WARNING: [rz-ghidra] Detected overlap for variable var_4b1h
// WARNING: [rz-ghidra] Detected overlap for variable var_4b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_43fh
// WARNING: [rz-ghidra] Detected overlap for variable var_43bh
// WARNING: [rz-ghidra] Detected overlap for variable var_439h
// WARNING: [rz-ghidra] Detected overlap for variable var_438h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ech
// WARNING: [rz-ghidra] Detected overlap for variable var_3c7h
// WARNING: [rz-ghidra] Detected overlap for variable var_3c3h
// WARNING: [rz-ghidra] Detected overlap for variable var_3c1h
// WARNING: [rz-ghidra] Detected overlap for variable var_3c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_374h
// WARNING: [rz-ghidra] Detected overlap for variable var_34fh
// WARNING: [rz-ghidra] Detected overlap for variable var_34bh
// WARNING: [rz-ghidra] Detected overlap for variable var_349h
// WARNING: [rz-ghidra] Detected overlap for variable var_348h
// WARNING: [rz-ghidra] Detected overlap for variable var_2fch
// WARNING: [rz-ghidra] Detected overlap for variable var_2d7h
// WARNING: [rz-ghidra] Detected overlap for variable var_2d3h
// WARNING: [rz-ghidra] Detected overlap for variable var_2d1h
// WARNING: [rz-ghidra] Detected overlap for variable var_2d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_23ch
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_7fh
// WARNING: [rz-ghidra] Detected overlap for variable var_7dh
// WARNING: [rz-ghidra] Detected overlap for variable var_a2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_20fh

void fcn.1800be580(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    undefined *puVar7;
    uint32_t uVar8;
    undefined auStack_5e8 [8];
    undefined auStack_5e0 [24];
    int64_t var_5c8h;
    int64_t var_5c0h;
    int64_t var_5b8h;
    int64_t var_5b0h;
    int64_t var_5a8h;
    int64_t var_5a0h;
    int64_t var_598h;
    int64_t var_590h;
    int64_t var_588h;
    int64_t var_580h;
    int64_t var_578h;
    int64_t var_568h;
    int64_t var_558h;
    int64_t var_548h;
    int64_t var_530h;
    int64_t var_528h;
    int64_t var_518h;
    int64_t var_500h;
    int64_t var_4f8h;
    int64_t var_4d0h;
    int64_t var_470h;
    int64_t var_468h;
    undefined8 var_460h;
    int64_t var_458h;
    int64_t var_448h;
    int64_t var_d0h;
    int64_t var_48h;
    
    puVar7 = auStack_5e8;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_5e8;
    uVar5 = 0;
    var_5b8h._0_4_ = 0;
    var_5b0h = arg1;
    var_5a8h = func_0x000180459890(0x2008);
    var_5a0h = 0;
    *(undefined8 *)var_5a8h = 0;
    var_598h = 0;
    var_590h = 0;
    var_588h = 0;
    var_580h = 0x1805aadb1;
    var_578h = 0;
    var_598h = func_0x000180459890(0x800);
    var_590h = 0x80;
    do {
        *(undefined8 *)(var_598h + uVar5 * 0x10) = 0x1805aadb1;
        *(undefined8 *)(var_598h + 8 + uVar5 * 0x10) = 0;
        uVar5 = uVar5 + 1;
    } while (uVar5 < 0x80);
    var_568h = (int64_t)&var_5a8h;
    uVar5 = 0x123;
    do {
        var_470h = *(int64_t *)(uVar5 * 8 + 0x1806179e8);
        var_468h._0_4_ = func_0x000180498cd0();
        var_468h._4_4_ = (int32_t)uVar5;
        func_0x0001800d8c20(&var_598h, &var_470h);
        uVar8 = (int32_t)uVar5 + 1;
        uVar5 = (uint64_t)uVar8;
    } while ((int32_t)uVar8 < 0x138);
    var_5c0h = fcn.1800be4c0((int64_t)&var_4d0h, arg4);
    puVar1 = (undefined8 *)(arg2 + 0x10);
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    var_5c8h = (int64_t)&var_5a8h;
    func_0x0001800d99a0(&var_558h, arg2, *puVar1, &var_598h);
    if (var_530h == var_528h) {
        func_0x0001800cde40(&var_448h);
        fcn.1800bc7b0((int64_t)&var_448h, (int64_t)&var_558h, (int64_t)&var_598h, arg3);
        func_0x00018000b4d0(arg1, &var_d0h);
        var_5b8h._0_4_ = 1;
        func_0x0001800be9d0(&var_448h);
        if (var_500h != 0) {
            func_0x0001800f4640();
            var_500h = 0;
            var_4f8h = 0;
        }
        func_0x00018007c820(&var_518h);
        func_0x0001800c17d0(&var_530h);
        func_0x0001800c0990(&var_548h);
        puVar1 = (undefined8 *)var_5a8h;
        if (var_598h != 0) {
            func_0x0001800f4640();
            var_598h = 0;
            var_590h = 0;
            puVar1 = (undefined8 *)var_5a8h;
        }
        while (puVar1 != (undefined8 *)0x0) {
            puVar1 = (undefined8 *)*puVar1;
            func_0x0001800f4640();
        }
    } else {
        uVar3 = (**(code **)(*(int64_t *)var_530h + 8))(var_530h);
        func_0x0001800d4c50(&var_470h, 0x18063fd40, *(int32_t *)(var_530h + 0x18) + 1, uVar3);
        *(undefined (*) [16])arg1 = ZEXT816(0);
        *(undefined8 *)(arg1 + 0x18) = 0xf;
        *(undefined *)arg1 = 0;
        var_5b8h._0_4_ = 2;
        *(undefined8 *)(arg1 + 0x10) = 1;
        *(undefined2 *)arg1 = 0;
        piVar6 = &var_470h;
        if (0xf < (uint64_t)var_458h) {
            piVar6 = (int64_t *)var_470h;
        }
        func_0x00018000d970(arg1, piVar6, var_460h);
        puVar7 = auStack_5e8;
        if (0xf < (uint64_t)var_458h) {
            iVar4 = var_470h;
            puVar7 = auStack_5e8;
            if ((0xfff < var_458h + 1U) &&
               (iVar4 = *(int64_t *)(var_470h + -8), puVar7 = auStack_5e8, 0x1f < (var_470h - iVar4) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar4 = (*pcVar2)(5);
                puVar7 = auStack_5e0;
            }
            *(undefined8 *)(puVar7 + -8) = 0x1800be79f;
            func_0x000180459c3c(iVar4);
        }
        *(undefined8 *)(puVar7 + 0x188) = 0;
        *(undefined8 *)(puVar7 + 400) = 0xf;
        puVar7[0x178] = 0;
        if (*(int64_t *)(puVar7 + 0xe8) != 0) {
            *(undefined8 *)(puVar7 + -8) = 0x1800be7cd;
            func_0x0001800f4640();
            *(undefined8 *)(puVar7 + 0xe8) = 0;
            *(undefined8 *)(puVar7 + 0xf0) = 0;
        }
        *(undefined8 *)(puVar7 + -8) = 0x1800be7ea;
        func_0x00018007c820(puVar7 + 0xd0);
        *(undefined8 *)(puVar7 + -8) = 0x1800be7f7;
        func_0x0001800c17d0(puVar7 + 0xb8);
        *(undefined8 *)(puVar7 + -8) = 0x1800be804;
        func_0x0001800c0990(puVar7 + 0xa0);
        if (*(int64_t *)(puVar7 + 0x50) != 0) {
            *(undefined8 *)(puVar7 + -8) = 0x1800be814;
            func_0x0001800f4640();
            *(undefined8 *)(puVar7 + 0x50) = 0;
            *(undefined8 *)(puVar7 + 0x58) = 0;
        }
        puVar1 = *(undefined8 **)(puVar7 + 0x40);
        while (puVar1 != (undefined8 *)0x0) {
            puVar1 = (undefined8 *)*puVar1;
            *(undefined8 *)(puVar7 + -8) = 0x1800be838;
            func_0x0001800f4640();
        }
    }
    *(undefined8 *)(puVar7 + -8) = 0x1800be9b8;
    func_0x000180459870(*(uint64_t *)(puVar7 + 0x5a0) ^ (uint64_t)puVar7);
    return;
}

// ============================================================
// Function: FUN_1800be9d0
// Address: 0x1800be9d0
// Size: 385 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800be9d0(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    func_0x000180004e40(arg1 + 0x3d0);
    func_0x0001800c1890(arg1 + 0x3b8);
    func_0x00018007c960(arg1 + 0x3a0);
    func_0x000180004e40(arg1 + 0x378);
    func_0x000180004e40(arg1 + 0x350);
    func_0x00018000ace0(arg1 + 0x338);
    func_0x00018002a260(arg1 + 800);
    if (*(int64_t *)(arg1 + 0x2f0) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x2f0) = 0;
        *(undefined8 *)(arg1 + 0x2f8) = 0;
    }
    func_0x0001800c0bd0(arg1 + 0x2d8);
    func_0x00018002ee50(arg1 + 0x2c0);
    func_0x00018002a260(arg1 + 0x2a8);
    func_0x00018002ee50(arg1 + 0x290);
    func_0x00018002a260(arg1 + 0x278);
    if (*(int64_t *)(arg1 + 0x250) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x250) = 0;
        *(undefined8 *)(arg1 + 600) = 0;
    }
    if (*(int64_t *)(arg1 + 0x128) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x128) = 0;
        *(undefined8 *)(arg1 + 0x130) = 0;
    }
    if (*(int64_t *)(arg1 + 0xf0) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0xf0) = 0;
        *(undefined8 *)(arg1 + 0xf8) = 0;
    }
    func_0x00018002ee50(arg1 + 0xd0);
    func_0x0001800c0c80(arg1 + 0xb8);
    func_0x0001800c1950(arg1 + 0xa0);
    func_0x00018000ace0(arg1 + 0x88);
    func_0x00018002ee50(arg1 + 0x70);
    func_0x000180028940(arg1 + 0x58);
    func_0x00018002ee50(arg1 + 0x40);
    func_0x00018002ee50(arg1 + 0x28);
    if (*(int64_t *)arg1 != 0) {
        func_0x0001800c1e20(*(int64_t *)arg1, *(undefined8 *)(arg1 + 8));
        uVar4 = *(uint64_t *)arg1;
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 3) * 8;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                uVar3 = 5;
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800c0dc2;
        func_0x000180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800bec40
// Address: 0x1800bec40
// Size: 330 bytes
// ============================================================
undefined4 * fcn.1800bec40(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    uint64_t uVar7;
    undefined4 *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    
    puVar9 = auStack_58;
    puVar10 = auStack_58;
    puVar6 = *(undefined4 **)(arg1 + 8);
    if (puVar6 != *(undefined4 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined4 *)arg2;
        puVar6 = *(undefined4 **)(arg1 + 8);
        *(undefined4 **)(arg1 + 8) = puVar6 + 1;
        return puVar6;
    }
    iVar12 = (int64_t)puVar6 - *(int64_t *)arg1 >> 2;
    if (iVar12 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined4 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 2;
    if (uVar7 <= 0x3fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar12 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar11 = uVar1;
        if (uVar1 <= uVar7) {
            uVar11 = uVar7;
        }
        if (uVar11 < 0x4000000000000000) {
            uVar7 = uVar11 * 4;
            if (uVar7 == 0) {
                puVar13 = (undefined4 *)0x0;
                puVar10 = auStack_58;
            } else if (uVar7 < 0x1000) {
                puVar13 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800bed84;
                iVar5 = func_0x000180459890(uVar7 + 0x27);
                if (iVar5 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar5 = (*pcVar4)(5);
                    puVar9 = auStack_50;
                }
                puVar13 = (undefined4 *)(iVar5 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar13 + -2) = iVar5;
                puVar10 = puVar9;
            }
            puVar2 = puVar13 + iVar12;
            *puVar2 = *(undefined4 *)arg2;
            puVar3 = *(undefined4 **)arg1;
            if (puVar6 == *(undefined4 **)(arg1 + 8)) {
                iVar12 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar3;
                puVar8 = puVar13;
                puVar6 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800bed48;
                fcn.180498030(puVar13, puVar3, (int64_t)puVar6 - (int64_t)puVar3);
                puVar8 = puVar2 + 1;
                iVar12 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800bed5b;
            fcn.180498030(puVar8, puVar6, iVar12);
            *(undefined8 *)(puVar10 + -8) = 0x1800bed6c;
            func_0x000180030d40(arg1, puVar13, uVar1, uVar11);
            return puVar2;
        }
    }
code_r0x0001800bed84:
    func_0x000180004720();
    pcVar4 = (code *)swi(3);
    puVar6 = (undefined4 *)(*pcVar4)();
    return puVar6;
}

// ============================================================
// Function: FUN_1800bed90
// Address: 0x1800bed90
// Size: 178 bytes
// ============================================================
void fcn.1800bed90(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 uVar2;
    code *pcVar3;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t iStack_58;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    iStack_58 = var_60h;
    iVar1 = *(int64_t *)(arg2 + 0x10);
    uVar2 = **(undefined8 **)arg1;
    var_60h = fcn.180498cd0(iVar1);
    var_68h = iVar1;
    var_60h._0_4_ = fcn.1800cf010(uVar2, &var_68h);
    var_68h = CONCAT44(var_68h._4_4_, 5);
    stack0xffffffffffffffa4 = SUB1612(ZEXT816(0), 4);
    var_40h = (int64_t)(uint32_t)var_60h;
    var_48h._0_4_ = 5;
    var_38h = 0;
    var_8h._0_4_ = fcn.1800ced20(unaff_retaddr);
    if (-1 < (int32_t)var_8h) {
        fcn.1800bec40(*(int64_t *)(arg1 + 8) + 8, (int64_t)&var_8h);
        return;
    }
    fcn.1800acea0(arg2 + 0x18, 0x18063f5a0);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800bee50
// Address: 0x1800bee50
// Size: 341 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001800bef36: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800bef6c: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001800bef3b)
// WARNING: Removing unreachable block (ram,0x0001800bef71)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_fh
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_dh

void fcn.1800bee50(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  undefined8 placeholder_5, undefined8 placeholder_6, int64_t arg_40h)
{
    uint32_t **ppuVar1;
    uint64_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t *puVar5;
    uint64_t uVar6;
    uint32_t *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    uint32_t *puVar13;
    int64_t iVar14;
    uint32_t *puVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_d0 [3];
    undefined auStack_b8 [8];
    undefined auStack_b0 [24];
    int64_t var_58h;
    int64_t var_50h;
    int64_t iStack_48;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iStack_48 = var_50h;
    fcn.1800b2270(*(undefined8 *)(arg1 + 0x10), *(undefined8 *)(arg2 + 0x40), **(undefined **)(arg1 + 0x18));
    iVar3 = *(int64_t *)(arg2 + 0x28);
    uVar12 = **(undefined8 **)(arg1 + 0x10);
    var_50h = fcn.180498cd0(iVar3);
    var_58h = iVar3;
    var_50h._0_4_ = fcn.1800cf010(uVar12, &var_58h);
    var_58h = CONCAT44(var_58h._4_4_, 5);
    stack0xffffffffffffffb4 = SUB1612(ZEXT816(0), 4);
    var_30h = (int64_t)(uint32_t)var_50h;
    var_38h._0_4_ = 5;
    var_28h = 0;
    var_8h._0_4_ = fcn.1800ced20(CONCAT44(var_10h._4_4_, (uint32_t)var_10h));
    if ((int32_t)var_8h < 0) {
        fcn.1800acea0(*(int64_t *)(arg2 + 0x40) + 0xc, 0x18063f5a0);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    fcn.1800bec40(*(int64_t *)(arg1 + 0x20) + 0x20, (int64_t)&var_8h);
    iVar3 = **(int64_t **)(arg1 + 0x10);
    ppuVar1 = (uint32_t **)(iVar3 + 0x28);
    var_10h._0_4_ = ((uint32_t)**(uint8_t **)(arg1 + 0x28) | (uint32_t)**(uint8_t **)(arg1 + 0x18) << 0x10) << 8 | 0x56;
    puVar9 = auStack_b8;
    puVar10 = auStack_b8;
    puVar15 = *(uint32_t **)(iVar3 + 0x30);
    if (puVar15 != *(uint32_t **)(iVar3 + 0x38)) {
        *puVar15 = (uint32_t)var_10h;
        *(int64_t *)(iVar3 + 0x30) = *(int64_t *)(iVar3 + 0x30) + 4;
        return;
    }
    iVar16 = (int64_t)puVar15 - (int64_t)*ppuVar1 >> 2;
    if (iVar16 == 0x3fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar6 = (int64_t)*(uint32_t **)(iVar3 + 0x38) - (int64_t)*ppuVar1 >> 2;
    if (uVar6 <= 0x3fffffffffffffff - (uVar6 >> 1)) {
        uVar2 = iVar16 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar11 = uVar2;
        if (uVar2 <= uVar6) {
            uVar11 = uVar6;
        }
        if (uVar11 < 0x4000000000000000) {
            uVar6 = uVar11 * 4;
            if (uVar6 == 0) {
                puVar13 = (uint32_t *)0x0;
                puVar10 = auStack_b8;
            } else if (uVar6 < 0x1000) {
                puVar13 = (uint32_t *)fcn.180459890();
            } else {
                if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800d32fa;
                iVar14 = fcn.180459890(uVar6 + 0x27);
                if (iVar14 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar14 = (*pcVar4)(5);
                    puVar9 = auStack_b0;
                }
                puVar13 = (uint32_t *)(iVar14 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar13 + -2) = iVar14;
                puVar10 = puVar9;
            }
            puVar13[iVar16] = (uint32_t)var_10h;
            puVar5 = *ppuVar1;
            if (puVar15 == *(uint32_t **)(iVar3 + 0x30)) {
                iVar14 = (int64_t)*(uint32_t **)(iVar3 + 0x30) - (int64_t)puVar5;
                puVar7 = puVar13;
                puVar15 = puVar5;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800d32b0;
                fcn.180498030(puVar13, puVar5, (int64_t)puVar15 - (int64_t)puVar5);
                iVar14 = *(int64_t *)(iVar3 + 0x30) - (int64_t)puVar15;
                puVar7 = puVar13 + iVar16 + 1;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800d32c7;
            fcn.180498030(puVar7, puVar15, iVar14);
            uVar12 = *(undefined8 *)(puVar10 + 0x28);
            *(undefined8 *)(puVar10 + 0x30) = *(undefined8 *)(puVar10 + 0x30);
            *(undefined8 *)(puVar10 + 0x28) = *(undefined8 *)(puVar10 + 0x40);
            *(undefined8 *)(puVar10 + 0x20) = uVar12;
            *(undefined8 *)(puVar10 + 0x18) = *(undefined8 *)(puVar10 + 0x48);
            puVar15 = *ppuVar1;
            if (puVar15 != (uint32_t *)0x0) {
                puVar5 = puVar15;
                puVar8 = puVar10 + -0x10;
                if (0xfff < (uint64_t)((*(int64_t *)(iVar3 + 0x38) - (int64_t)puVar15 >> 2) * 4)) {
                    puVar5 = *(uint32_t **)(puVar15 + -2);
                    puVar15 = (uint32_t *)((int64_t)puVar15 + (-8 - (int64_t)puVar5));
                    puVar8 = puVar10 + -0x10;
                    if ((uint32_t *)0x1f < puVar15) {
                        pcVar4 = (code *)swi(0x29);
                        puVar5 = puVar15;
                        (*pcVar4)(5);
                        puVar8 = puVar10 + -8;
                    }
                }
                *(undefined8 *)(puVar8 + -8) = 0x180030d9f;
                fcn.180459c3c(puVar5);
            }
            *ppuVar1 = puVar13;
            *(uint32_t **)(iVar3 + 0x30) = puVar13 + uVar2;
            *(uint32_t **)(iVar3 + 0x38) = puVar13 + uVar11;
            return;
        }
    }
code_r0x0001800d32fa:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_1800befb0
// Address: 0x1800befb0
// Size: 1677 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

int64_t fcn.1800befb0(int64_t arg1, int64_t arg2)
{
    uint64_t **ppuVar1;
    int64_t *piVar2;
    int32_t iVar3;
    float fVar4;
    uint32_t uVar5;
    uint64_t *puVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    code *pcVar13;
    int64_t **ppiVar14;
    int64_t iVar15;
    uint64_t uVar16;
    uint64_t *puVar17;
    uint64_t uVar18;
    undefined *puVar19;
    undefined *puVar20;
    int64_t **ppiVar21;
    int64_t **ppiVar22;
    uint64_t unaff_RDI;
    uint64_t uVar23;
    int64_t iVar24;
    uint64_t uVar25;
    float fVar26;
    float fVar27;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_27h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    
    puVar19 = auStack_68;
    uVar23 = (((((uint64_t)*(uint8_t *)arg2 ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 1)) *
               0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 2)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 3)) *
             0x100000001b3 & *(uint64_t *)(arg1 + 0x48);
    iVar15 = *(int64_t *)(*(int64_t *)(arg1 + 0x30) + 8 + uVar23 * 0x10);
    if (iVar15 == *(int64_t *)(arg1 + 0x20)) {
code_r0x0001800bf050:
        iVar15 = 0;
    } else {
        iVar3 = *(int32_t *)(iVar15 + 0x10);
        while (*(int32_t *)arg2 != iVar3) {
            if (iVar15 == *(int64_t *)(*(int64_t *)(arg1 + 0x30) + uVar23 * 0x10)) goto code_r0x0001800bf050;
            iVar15 = *(int64_t *)(iVar15 + 8);
            iVar3 = *(int32_t *)(iVar15 + 0x10);
        }
    }
    ppuVar1 = (uint64_t **)(arg1 + 8);
    if ((iVar15 != 0) && (iVar15 != *(int64_t *)(arg1 + 0x20))) {
        if (*(uint64_t *)(iVar15 + 0x18) < (uint64_t)((int64_t)*ppuVar1 - *(int64_t *)arg1 >> 3)) {
            return *(int64_t *)arg1 + 4 + *(uint64_t *)(iVar15 + 0x18) * 8;
        }
        func_0x000180060370();
        pcVar13 = (code *)swi(3);
        iVar15 = (*pcVar13)();
        return iVar15;
    }
    uVar5 = *(uint32_t *)arg2;
    puVar17 = *ppuVar1;
    if (puVar17 == *(uint64_t **)(arg1 + 0x10)) {
        iVar15 = (int64_t)puVar17 - *(int64_t *)arg1 >> 3;
        if (iVar15 == 0x1fffffffffffffff) {
            fcn.180010010();
            pcVar13 = (code *)swi(3);
            iVar15 = (*pcVar13)();
            return iVar15;
        }
        uVar23 = (int64_t)*(uint64_t **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
        puVar20 = auStack_68;
        if (0x1fffffffffffffff - (uVar23 >> 1) < uVar23) goto code_r0x0001800bf61e;
        uVar25 = iVar15 + 1;
        uVar23 = uVar23 + (uVar23 >> 1);
        uVar16 = uVar25;
        if (uVar25 <= uVar23) {
            uVar16 = uVar23;
        }
        puVar20 = auStack_68;
        if (0x1fffffffffffffff < uVar16) goto code_r0x0001800bf61e;
        uVar16 = uVar16 * 8;
        if (uVar16 == 0) {
            unaff_RDI = 0;
code_r0x0001800bf174:
            *(uint64_t *)(unaff_RDI + iVar15 * 8) = (uint64_t)uVar5;
            puVar6 = *(uint64_t **)arg1;
            if (puVar17 == *ppuVar1) {
                iVar24 = (int64_t)*ppuVar1 - (int64_t)puVar6;
                uVar23 = unaff_RDI;
                puVar17 = puVar6;
            } else {
                fcn.180498030(unaff_RDI, puVar6, (int64_t)puVar17 - (int64_t)puVar6);
                iVar24 = (int64_t)*ppuVar1 - (int64_t)puVar17;
                uVar23 = unaff_RDI + (iVar15 + 1) * 8;
            }
            fcn.180498030(uVar23, puVar17, iVar24);
            iVar15 = *(int64_t *)arg1;
            if (iVar15 != 0) {
                iVar24 = iVar15;
                puVar19 = auStack_68;
                if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar15 >> 3) * 8)) &&
                   (iVar24 = *(int64_t *)(iVar15 + -8), puVar19 = auStack_68, 0x1f < (iVar15 - iVar24) - 8U))
                goto code_r0x0001800bf1ec;
                goto code_r0x0001800bf1f6;
            }
        } else {
            if (uVar16 < 0x1000) {
                unaff_RDI = fcn.180459890(uVar16);
                goto code_r0x0001800bf174;
            }
            puVar20 = auStack_68;
            if (uVar16 + 0x27 <= uVar16) goto code_r0x0001800bf61e;
            iVar24 = fcn.180459890();
            if (iVar24 != 0) {
                unaff_RDI = iVar24 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(unaff_RDI - 8) = iVar24;
                goto code_r0x0001800bf174;
            }
code_r0x0001800bf1ec:
            iVar24 = 5;
            pcVar13 = (code *)swi(0x29);
            (*pcVar13)(5);
            puVar19 = auStack_60;
code_r0x0001800bf1f6:
            *(undefined8 *)(puVar19 + -8) = 0x1800bf1fe;
            fcn.180459c3c(iVar24);
        }
        *(uint64_t *)arg1 = unaff_RDI;
        puVar17 = (uint64_t *)(unaff_RDI + uVar25 * 8);
        *ppuVar1 = puVar17;
        *(uint64_t *)(arg1 + 0x10) = unaff_RDI + uVar16;
    } else {
        *puVar17 = (uint64_t)uVar5;
        *ppuVar1 = *ppuVar1 + 1;
        puVar17 = *ppuVar1;
        puVar19 = auStack_68;
    }
    ppiVar21 = (int64_t **)(arg1 + 0x20);
    *(undefined8 *)(puVar19 + 0x70) = *(undefined8 *)arg1;
    uVar25 = (((((uint64_t)*(uint8_t *)arg2 ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 1)) *
               0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 2)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 3)) *
             0x100000001b3;
    uVar23 = uVar25 & *(uint64_t *)(arg1 + 0x48);
    ppiVar14 = *(int64_t ***)(*(int64_t *)(arg1 + 0x30) + 8 + uVar23 * 0x10);
    ppiVar22 = (int64_t **)*ppiVar21;
    if (ppiVar14 != ppiVar22) {
        iVar3 = *(int32_t *)(ppiVar14 + 2);
        ppiVar22 = ppiVar14;
        while (ppiVar14 = ppiVar22, *(int32_t *)arg2 != iVar3) {
            if (ppiVar22 == *(int64_t ***)(*(int64_t *)(arg1 + 0x30) + uVar23 * 0x10)) goto code_r0x0001800bf2ac;
            ppiVar22 = (int64_t **)ppiVar22[1];
            iVar3 = *(int32_t *)(ppiVar22 + 2);
        }
        goto code_r0x0001800bf5ed;
    }
code_r0x0001800bf2ac:
    if (*(int64_t *)(arg1 + 0x28) == 0x7ffffffffffffff) {
        *(undefined8 *)(puVar19 + -8) = 0x1800bf63c;
        fcn.1804546d4(0x180620428);
        pcVar13 = (code *)swi(3);
        iVar15 = (*pcVar13)();
        return iVar15;
    }
    *(int64_t ***)(puVar19 + 0x20) = ppiVar21;
    *(undefined8 *)(puVar19 + 0x28) = 0;
    *(undefined8 *)(puVar19 + -8) = 0x1800bf2d8;
    ppiVar14 = (int64_t **)fcn.180459890(0x20);
    *(int64_t ***)(puVar19 + 0x28) = ppiVar14;
    *(undefined4 *)(ppiVar14 + 2) = *(undefined4 *)arg2;
    ppiVar14[3] = (int64_t *)0x0;
    uVar23 = *(int64_t *)(arg1 + 0x28) + 1;
    if ((int64_t)uVar23 < 0) {
        fVar26 = (float)(uVar23 >> 1 | (uint64_t)((uint32_t)uVar23 & 1));
        fVar26 = fVar26 + fVar26;
    } else {
        fVar26 = (float)uVar23;
    }
    uVar23 = *(uint64_t *)(arg1 + 0x50);
    fVar4 = *(float *)(arg1 + 0x18);
    if ((int64_t)uVar23 < 0) {
        fVar27 = (float)(uVar23 >> 1 | (uint64_t)((uint32_t)uVar23 & 1));
        fVar27 = fVar27 + fVar27;
    } else {
        fVar27 = (float)uVar23;
    }
    if (fVar4 < fVar26 / fVar27) {
        *(undefined8 *)(puVar19 + -8) = 0x1800bf362;
        fVar26 = (float)func_0x000180471c90(fVar26 / fVar4);
        iVar15 = 0;
        if ((9.223372e+18 <= fVar26) && (fVar26 = fVar26 - 9.223372e+18, fVar26 < 9.223372e+18)) {
            iVar15 = -0x8000000000000000;
        }
        uVar16 = 8;
        if (8 < (uint64_t)((int64_t)fVar26 + iVar15)) {
            uVar16 = (int64_t)fVar26 + iVar15;
        }
        uVar18 = uVar23;
        if ((uVar23 < uVar16) && ((0x1ff < uVar23 || (uVar18 = uVar23 * 8, uVar23 * 8 < uVar16)))) {
            uVar18 = uVar16;
        }
        for (iVar15 = 0x3f; 0xfffffffffffffffU >> iVar15 == 0; iVar15 = iVar15 + -1) {
        }
        if ((uint64_t)(1LL << ((uint8_t)iVar15 & 0x3f)) < uVar18) {
            *(undefined8 *)(puVar19 + -8) = 0x1800bf61d;
            fcn.1804546d4(0x180620448);
            puVar20 = puVar19;
code_r0x0001800bf61e:
            *(undefined8 *)(puVar20 + -8) = 0x1800bf623;
            fcn.180004720();
            pcVar13 = (code *)swi(3);
            iVar15 = (*pcVar13)();
            return iVar15;
        }
        uVar23 = uVar18 - 1 | 1;
        iVar15 = 0x3f;
        if (uVar23 != 0) {
            for (; uVar23 >> iVar15 == 0; iVar15 = iVar15 + -1) {
            }
        }
        iVar15 = 1LL << ((char)iVar15 + 1U & 0x3f);
        ppiVar22 = (int64_t **)*ppiVar21;
        piVar2 = (int64_t *)(arg1 + 0x30);
        *(undefined8 *)(puVar19 + -8) = 0x1800bf401;
        func_0x00018000f7e0(piVar2, iVar15 * 2, ppiVar22);
        *(int64_t *)(arg1 + 0x48) = iVar15 + -1;
        *(int64_t *)(arg1 + 0x50) = iVar15;
        ppiVar21 = (int64_t **)**ppiVar21;
joined_r0x0001800bf41a:
        if (ppiVar21 != ppiVar22) {
            ppiVar7 = (int64_t **)*ppiVar21;
            uVar23 = (((((uint64_t)*(uint8_t *)(ppiVar21 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                       (uint64_t)*(uint8_t *)((int64_t)ppiVar21 + 0x11)) * 0x100000001b3 ^
                      (uint64_t)*(uint8_t *)((int64_t)ppiVar21 + 0x12)) * 0x100000001b3 ^
                     (uint64_t)*(uint8_t *)((int64_t)ppiVar21 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x48);
            iVar15 = *piVar2;
            ppiVar8 = *(int64_t ***)(iVar15 + uVar23 * 0x10);
            if (ppiVar8 == ppiVar22) {
                *(int64_t ***)(iVar15 + uVar23 * 0x10) = ppiVar21;
                *(int64_t ***)(iVar15 + 8 + uVar23 * 0x10) = ppiVar21;
                ppiVar21 = ppiVar7;
            } else {
                ppiVar9 = *(int64_t ***)(iVar15 + 8 + uVar23 * 0x10);
                if (*(int32_t *)(ppiVar21 + 2) == *(int32_t *)(ppiVar9 + 2)) {
                    ppiVar9 = (int64_t **)*ppiVar9;
                    if (ppiVar9 != ppiVar21) {
                        piVar10 = ppiVar21[1];
                        *piVar10 = (int64_t)ppiVar7;
                        ppiVar8 = (int64_t **)ppiVar7[1];
                        *ppiVar8 = (int64_t *)ppiVar9;
                        piVar11 = ppiVar9[1];
                        *piVar11 = (int64_t)ppiVar21;
                        ppiVar9[1] = (int64_t *)ppiVar8;
                        ppiVar7[1] = piVar10;
                        ppiVar21[1] = piVar11;
                    }
                    *(int64_t ***)(iVar15 + 8 + uVar23 * 0x10) = ppiVar21;
                    ppiVar21 = ppiVar7;
                } else {
                    do {
                        if (ppiVar8 == ppiVar9) {
                            piVar10 = ppiVar21[1];
                            *piVar10 = (int64_t)ppiVar7;
                            ppiVar8 = (int64_t **)ppiVar7[1];
                            *ppiVar8 = (int64_t *)ppiVar9;
                            piVar11 = ppiVar9[1];
                            *piVar11 = (int64_t)ppiVar21;
                            ppiVar9[1] = (int64_t *)ppiVar8;
                            ppiVar7[1] = piVar10;
                            ppiVar21[1] = piVar11;
                            *(int64_t ***)(iVar15 + uVar23 * 0x10) = ppiVar21;
                            ppiVar21 = ppiVar7;
                            goto joined_r0x0001800bf41a;
                        }
                        ppiVar9 = (int64_t **)ppiVar9[1];
                    } while (*(int32_t *)(ppiVar21 + 2) != *(int32_t *)(ppiVar9 + 2));
                    piVar10 = *ppiVar9;
                    piVar11 = ppiVar21[1];
                    *piVar11 = (int64_t)ppiVar7;
                    ppiVar8 = (int64_t **)ppiVar7[1];
                    *ppiVar8 = piVar10;
                    piVar12 = (int64_t *)piVar10[1];
                    *piVar12 = (int64_t)ppiVar21;
                    piVar10[1] = (int64_t)ppiVar8;
                    ppiVar7[1] = piVar11;
                    ppiVar21[1] = piVar12;
                    ppiVar21 = ppiVar7;
                }
            }
            goto joined_r0x0001800bf41a;
        }
        uVar23 = uVar25 & *(uint64_t *)(arg1 + 0x48);
        ppiVar21 = *(int64_t ***)(*piVar2 + 8 + uVar23 * 0x10);
        ppiVar22 = *(int64_t ***)(arg1 + 0x20);
        if (ppiVar21 != ppiVar22) {
            iVar3 = *(int32_t *)(ppiVar21 + 2);
            ppiVar22 = ppiVar21;
            while (*(int32_t *)(ppiVar14 + 2) != iVar3) {
                if (ppiVar22 == *(int64_t ***)(*piVar2 + uVar23 * 0x10)) goto code_r0x0001800bf5a5;
                ppiVar22 = (int64_t **)ppiVar22[1];
                iVar3 = *(int32_t *)(ppiVar22 + 2);
            }
            ppiVar22 = (int64_t **)*ppiVar22;
        }
    }
code_r0x0001800bf5a5:
    ppiVar21 = (int64_t **)ppiVar22[1];
    *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg1 + 0x28) + 1;
    *ppiVar14 = (int64_t *)ppiVar22;
    ppiVar14[1] = (int64_t *)ppiVar21;
    *ppiVar21 = (int64_t *)ppiVar14;
    ppiVar22[1] = (int64_t *)ppiVar14;
    iVar15 = *(int64_t *)(arg1 + 0x30);
    uVar25 = uVar25 & *(uint64_t *)(arg1 + 0x48);
    ppiVar7 = *(int64_t ***)(iVar15 + uVar25 * 0x10);
    if (ppiVar7 == *(int64_t ***)(arg1 + 0x20)) {
        *(int64_t ***)(iVar15 + uVar25 * 0x10) = ppiVar14;
    } else {
        if (ppiVar7 == ppiVar22) {
            *(int64_t ***)(iVar15 + uVar25 * 0x10) = ppiVar14;
            goto code_r0x0001800bf5ed;
        }
        if (*(int64_t ***)(iVar15 + 8 + uVar25 * 0x10) != ppiVar21) goto code_r0x0001800bf5ed;
    }
    *(int64_t ***)(iVar15 + 8 + uVar25 * 0x10) = ppiVar14;
code_r0x0001800bf5ed:
    ppiVar14[3] = (int64_t *)(((int64_t)puVar17 - *(int64_t *)(puVar19 + 0x70) >> 3) + -1);
    return **(int64_t **)(puVar19 + 0x80) + -4;
}

// ============================================================
// Function: FUN_1800bf640
// Address: 0x1800bf640
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800bf640(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    uint64_t uVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    undefined *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    uint64_t uVar15;
    undefined8 uVar16;
    undefined8 uVar17;
    uint64_t uVar18;
    int64_t iVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar12 = auStack_38;
    puVar13 = auStack_38;
    puVar10 = *(undefined4 **)(arg1 + 8);
    if (puVar10 != *(undefined4 **)(arg1 + 0x10)) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *puVar10 = *(undefined4 *)arg2;
        puVar10[1] = uVar3;
        puVar10[2] = uVar4;
        puVar10[3] = uVar5;
        uVar3 = *(undefined4 *)(arg2 + 0x14);
        uVar4 = *(undefined4 *)(arg2 + 0x18);
        uVar5 = *(undefined4 *)(arg2 + 0x1c);
        puVar10[4] = *(undefined4 *)(arg2 + 0x10);
        puVar10[5] = uVar3;
        puVar10[6] = uVar4;
        puVar10[7] = uVar5;
        uVar3 = *(undefined4 *)(arg2 + 0x24);
        uVar4 = *(undefined4 *)(arg2 + 0x28);
        uVar5 = *(undefined4 *)(arg2 + 0x2c);
        puVar10[8] = *(undefined4 *)(arg2 + 0x20);
        puVar10[9] = uVar3;
        puVar10[10] = uVar4;
        puVar10[0xb] = uVar5;
        *(undefined8 *)(puVar10 + 0xc) = *(undefined8 *)(arg2 + 0x30);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x38;
        return;
    }
    iVar19 = ((int64_t)puVar10 - *(int64_t *)arg1) / 0x38;
    if (iVar19 == 0x492492492492492) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar18 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar6 = 0x492492492492492 - (uVar18 >> 1);
    if (uVar18 < uVar6 || uVar18 - uVar6 == 0) {
        uVar6 = iVar19 + 1;
        uVar18 = uVar18 + (uVar18 >> 1);
        uVar15 = uVar6;
        if (uVar6 <= uVar18) {
            uVar15 = uVar18;
        }
        if (uVar15 < 0x492492492492493) {
            uVar18 = uVar15 * 0x38;
            if (uVar18 == 0) {
                puVar11 = (undefined4 *)0x0;
                puVar13 = auStack_38;
            } else if (uVar18 < 0x1000) {
                puVar11 = (undefined4 *)fcn.180459890();
            } else {
                if (uVar18 + 0x27 <= uVar18) goto code_r0x0001800bf7fe;
                iVar7 = fcn.180459890(uVar18 + 0x27);
                if (iVar7 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar7 = (*pcVar2)(5);
                    puVar12 = auStack_30;
                }
                puVar11 = (undefined4 *)(iVar7 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar11 + -2) = iVar7;
                puVar13 = puVar12;
            }
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar8 = puVar11 + iVar19 * 0xe;
            *puVar8 = *(undefined4 *)arg2;
            puVar8[1] = uVar3;
            puVar8[2] = uVar4;
            puVar8[3] = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x14);
            uVar4 = *(undefined4 *)(arg2 + 0x18);
            uVar5 = *(undefined4 *)(arg2 + 0x1c);
            puVar8[4] = *(undefined4 *)(arg2 + 0x10);
            puVar8[5] = uVar3;
            puVar8[6] = uVar4;
            puVar8[7] = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x24);
            uVar4 = *(undefined4 *)(arg2 + 0x28);
            uVar5 = *(undefined4 *)(arg2 + 0x2c);
            puVar8[8] = *(undefined4 *)(arg2 + 0x20);
            puVar8[9] = uVar3;
            puVar8[10] = uVar4;
            puVar8[0xb] = uVar5;
            *(undefined8 *)(puVar8 + 0xc) = *(undefined8 *)(arg2 + 0x30);
            puVar1 = *(undefined4 **)arg1;
            if (puVar10 == *(undefined4 **)(arg1 + 8)) {
                iVar19 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar1;
                puVar8 = puVar11;
                puVar10 = puVar1;
            } else {
                *(undefined8 *)(puVar13 + -8) = 0x1800bf7b8;
                fcn.180498030(puVar11, puVar1, (int64_t)puVar10 - (int64_t)puVar1);
                puVar8 = puVar8 + 0xe;
                iVar19 = *(int64_t *)(arg1 + 8) - (int64_t)puVar10;
            }
            *(undefined8 *)(puVar13 + -8) = 0x1800bf7cb;
            fcn.180498030(puVar8, puVar10, iVar19);
            uVar17 = *(undefined8 *)(puVar13 + 0x28);
            uVar16 = *(undefined8 *)(puVar13 + 0x30);
            *(undefined8 *)(puVar13 + 0x30) = *(undefined8 *)(puVar13 + 0x40);
            *(undefined8 *)(puVar13 + 0x28) = *(undefined8 *)(puVar13 + 0x48);
            *(undefined8 *)(puVar13 + 0x20) = uVar16;
            *(undefined8 *)(puVar13 + 0x18) = uVar17;
            uVar18 = *(uint64_t *)arg1;
            if (uVar18 != 0) {
                uVar9 = uVar18;
                puVar14 = puVar13 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar18) >> 3) * 8)) {
                    uVar9 = *(uint64_t *)(uVar18 - 8);
                    uVar18 = (uVar18 - uVar9) - 8;
                    puVar14 = puVar13 + -0x10;
                    if (0x1f < uVar18) {
                        pcVar2 = (code *)swi(0x29);
                        uVar9 = uVar18;
                        (*pcVar2)(5);
                        puVar14 = puVar13 + -8;
                    }
                }
                *(undefined8 *)(puVar14 + -8) = 0x1800c20f9;
                fcn.180459c3c(uVar9);
            }
            *(undefined4 **)arg1 = puVar11;
            *(undefined4 **)(arg1 + 8) = puVar11 + uVar6 * 0xe;
            *(undefined4 **)(arg1 + 0x10) = puVar11 + uVar15 * 0xe;
            return;
        }
    }
code_r0x0001800bf7fe:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800bf697
// Address: 0x1800bf697
// Size: 353 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800bf640(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    uint64_t uVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    undefined *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    uint64_t uVar15;
    undefined8 uVar16;
    undefined8 uVar17;
    uint64_t uVar18;
    int64_t iVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar12 = auStack_38;
    puVar13 = auStack_38;
    puVar10 = *(undefined4 **)(arg1 + 8);
    if (puVar10 != *(undefined4 **)(arg1 + 0x10)) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *puVar10 = *(undefined4 *)arg2;
        puVar10[1] = uVar3;
        puVar10[2] = uVar4;
        puVar10[3] = uVar5;
        uVar3 = *(undefined4 *)(arg2 + 0x14);
        uVar4 = *(undefined4 *)(arg2 + 0x18);
        uVar5 = *(undefined4 *)(arg2 + 0x1c);
        puVar10[4] = *(undefined4 *)(arg2 + 0x10);
        puVar10[5] = uVar3;
        puVar10[6] = uVar4;
        puVar10[7] = uVar5;
        uVar3 = *(undefined4 *)(arg2 + 0x24);
        uVar4 = *(undefined4 *)(arg2 + 0x28);
        uVar5 = *(undefined4 *)(arg2 + 0x2c);
        puVar10[8] = *(undefined4 *)(arg2 + 0x20);
        puVar10[9] = uVar3;
        puVar10[10] = uVar4;
        puVar10[0xb] = uVar5;
        *(undefined8 *)(puVar10 + 0xc) = *(undefined8 *)(arg2 + 0x30);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x38;
        return;
    }
    iVar19 = ((int64_t)puVar10 - *(int64_t *)arg1) / 0x38;
    if (iVar19 == 0x492492492492492) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar18 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar6 = 0x492492492492492 - (uVar18 >> 1);
    if (uVar18 < uVar6 || uVar18 - uVar6 == 0) {
        uVar6 = iVar19 + 1;
        uVar18 = uVar18 + (uVar18 >> 1);
        uVar15 = uVar6;
        if (uVar6 <= uVar18) {
            uVar15 = uVar18;
        }
        if (uVar15 < 0x492492492492493) {
            uVar18 = uVar15 * 0x38;
            if (uVar18 == 0) {
                puVar11 = (undefined4 *)0x0;
                puVar13 = auStack_38;
            } else if (uVar18 < 0x1000) {
                puVar11 = (undefined4 *)fcn.180459890();
            } else {
                if (uVar18 + 0x27 <= uVar18) goto code_r0x0001800bf7fe;
                iVar7 = fcn.180459890(uVar18 + 0x27);
                if (iVar7 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar7 = (*pcVar2)(5);
                    puVar12 = auStack_30;
                }
                puVar11 = (undefined4 *)(iVar7 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar11 + -2) = iVar7;
                puVar13 = puVar12;
            }
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar8 = puVar11 + iVar19 * 0xe;
            *puVar8 = *(undefined4 *)arg2;
            puVar8[1] = uVar3;
            puVar8[2] = uVar4;
            puVar8[3] = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x14);
            uVar4 = *(undefined4 *)(arg2 + 0x18);
            uVar5 = *(undefined4 *)(arg2 + 0x1c);
            puVar8[4] = *(undefined4 *)(arg2 + 0x10);
            puVar8[5] = uVar3;
            puVar8[6] = uVar4;
            puVar8[7] = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x24);
            uVar4 = *(undefined4 *)(arg2 + 0x28);
            uVar5 = *(undefined4 *)(arg2 + 0x2c);
            puVar8[8] = *(undefined4 *)(arg2 + 0x20);
            puVar8[9] = uVar3;
            puVar8[10] = uVar4;
            puVar8[0xb] = uVar5;
            *(undefined8 *)(puVar8 + 0xc) = *(undefined8 *)(arg2 + 0x30);
            puVar1 = *(undefined4 **)arg1;
            if (puVar10 == *(undefined4 **)(arg1 + 8)) {
                iVar19 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar1;
                puVar8 = puVar11;
                puVar10 = puVar1;
            } else {
                *(undefined8 *)(puVar13 + -8) = 0x1800bf7b8;
                fcn.180498030(puVar11, puVar1, (int64_t)puVar10 - (int64_t)puVar1);
                puVar8 = puVar8 + 0xe;
                iVar19 = *(int64_t *)(arg1 + 8) - (int64_t)puVar10;
            }
            *(undefined8 *)(puVar13 + -8) = 0x1800bf7cb;
            fcn.180498030(puVar8, puVar10, iVar19);
            uVar17 = *(undefined8 *)(puVar13 + 0x28);
            uVar16 = *(undefined8 *)(puVar13 + 0x30);
            *(undefined8 *)(puVar13 + 0x30) = *(undefined8 *)(puVar13 + 0x40);
            *(undefined8 *)(puVar13 + 0x28) = *(undefined8 *)(puVar13 + 0x48);
            *(undefined8 *)(puVar13 + 0x20) = uVar16;
            *(undefined8 *)(puVar13 + 0x18) = uVar17;
            uVar18 = *(uint64_t *)arg1;
            if (uVar18 != 0) {
                uVar9 = uVar18;
                puVar14 = puVar13 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar18) >> 3) * 8)) {
                    uVar9 = *(uint64_t *)(uVar18 - 8);
                    uVar18 = (uVar18 - uVar9) - 8;
                    puVar14 = puVar13 + -0x10;
                    if (0x1f < uVar18) {
                        pcVar2 = (code *)swi(0x29);
                        uVar9 = uVar18;
                        (*pcVar2)(5);
                        puVar14 = puVar13 + -8;
                    }
                }
                *(undefined8 *)(puVar14 + -8) = 0x1800c20f9;
                fcn.180459c3c(uVar9);
            }
            *(undefined4 **)arg1 = puVar11;
            *(undefined4 **)(arg1 + 8) = puVar11 + uVar6 * 0xe;
            *(undefined4 **)(arg1 + 0x10) = puVar11 + uVar15 * 0xe;
            return;
        }
    }
code_r0x0001800bf7fe:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800bf7f8
// Address: 0x1800bf7f8
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800bf640(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    uint64_t uVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    undefined *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    uint64_t uVar15;
    undefined8 uVar16;
    undefined8 uVar17;
    uint64_t uVar18;
    int64_t iVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar12 = auStack_38;
    puVar13 = auStack_38;
    puVar10 = *(undefined4 **)(arg1 + 8);
    if (puVar10 != *(undefined4 **)(arg1 + 0x10)) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *puVar10 = *(undefined4 *)arg2;
        puVar10[1] = uVar3;
        puVar10[2] = uVar4;
        puVar10[3] = uVar5;
        uVar3 = *(undefined4 *)(arg2 + 0x14);
        uVar4 = *(undefined4 *)(arg2 + 0x18);
        uVar5 = *(undefined4 *)(arg2 + 0x1c);
        puVar10[4] = *(undefined4 *)(arg2 + 0x10);
        puVar10[5] = uVar3;
        puVar10[6] = uVar4;
        puVar10[7] = uVar5;
        uVar3 = *(undefined4 *)(arg2 + 0x24);
        uVar4 = *(undefined4 *)(arg2 + 0x28);
        uVar5 = *(undefined4 *)(arg2 + 0x2c);
        puVar10[8] = *(undefined4 *)(arg2 + 0x20);
        puVar10[9] = uVar3;
        puVar10[10] = uVar4;
        puVar10[0xb] = uVar5;
        *(undefined8 *)(puVar10 + 0xc) = *(undefined8 *)(arg2 + 0x30);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x38;
        return;
    }
    iVar19 = ((int64_t)puVar10 - *(int64_t *)arg1) / 0x38;
    if (iVar19 == 0x492492492492492) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar18 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar6 = 0x492492492492492 - (uVar18 >> 1);
    if (uVar18 < uVar6 || uVar18 - uVar6 == 0) {
        uVar6 = iVar19 + 1;
        uVar18 = uVar18 + (uVar18 >> 1);
        uVar15 = uVar6;
        if (uVar6 <= uVar18) {
            uVar15 = uVar18;
        }
        if (uVar15 < 0x492492492492493) {
            uVar18 = uVar15 * 0x38;
            if (uVar18 == 0) {
                puVar11 = (undefined4 *)0x0;
                puVar13 = auStack_38;
            } else if (uVar18 < 0x1000) {
                puVar11 = (undefined4 *)fcn.180459890();
            } else {
                if (uVar18 + 0x27 <= uVar18) goto code_r0x0001800bf7fe;
                iVar7 = fcn.180459890(uVar18 + 0x27);
                if (iVar7 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar7 = (*pcVar2)(5);
                    puVar12 = auStack_30;
                }
                puVar11 = (undefined4 *)(iVar7 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar11 + -2) = iVar7;
                puVar13 = puVar12;
            }
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar8 = puVar11 + iVar19 * 0xe;
            *puVar8 = *(undefined4 *)arg2;
            puVar8[1] = uVar3;
            puVar8[2] = uVar4;
            puVar8[3] = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x14);
            uVar4 = *(undefined4 *)(arg2 + 0x18);
            uVar5 = *(undefined4 *)(arg2 + 0x1c);
            puVar8[4] = *(undefined4 *)(arg2 + 0x10);
            puVar8[5] = uVar3;
            puVar8[6] = uVar4;
            puVar8[7] = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x24);
            uVar4 = *(undefined4 *)(arg2 + 0x28);
            uVar5 = *(undefined4 *)(arg2 + 0x2c);
            puVar8[8] = *(undefined4 *)(arg2 + 0x20);
            puVar8[9] = uVar3;
            puVar8[10] = uVar4;
            puVar8[0xb] = uVar5;
            *(undefined8 *)(puVar8 + 0xc) = *(undefined8 *)(arg2 + 0x30);
            puVar1 = *(undefined4 **)arg1;
            if (puVar10 == *(undefined4 **)(arg1 + 8)) {
                iVar19 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar1;
                puVar8 = puVar11;
                puVar10 = puVar1;
            } else {
                *(undefined8 *)(puVar13 + -8) = 0x1800bf7b8;
                fcn.180498030(puVar11, puVar1, (int64_t)puVar10 - (int64_t)puVar1);
                puVar8 = puVar8 + 0xe;
                iVar19 = *(int64_t *)(arg1 + 8) - (int64_t)puVar10;
            }
            *(undefined8 *)(puVar13 + -8) = 0x1800bf7cb;
            fcn.180498030(puVar8, puVar10, iVar19);
            uVar17 = *(undefined8 *)(puVar13 + 0x28);
            uVar16 = *(undefined8 *)(puVar13 + 0x30);
            *(undefined8 *)(puVar13 + 0x30) = *(undefined8 *)(puVar13 + 0x40);
            *(undefined8 *)(puVar13 + 0x28) = *(undefined8 *)(puVar13 + 0x48);
            *(undefined8 *)(puVar13 + 0x20) = uVar16;
            *(undefined8 *)(puVar13 + 0x18) = uVar17;
            uVar18 = *(uint64_t *)arg1;
            if (uVar18 != 0) {
                uVar9 = uVar18;
                puVar14 = puVar13 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar18) >> 3) * 8)) {
                    uVar9 = *(uint64_t *)(uVar18 - 8);
                    uVar18 = (uVar18 - uVar9) - 8;
                    puVar14 = puVar13 + -0x10;
                    if (0x1f < uVar18) {
                        pcVar2 = (code *)swi(0x29);
                        uVar9 = uVar18;
                        (*pcVar2)(5);
                        puVar14 = puVar13 + -8;
                    }
                }
                *(undefined8 *)(puVar14 + -8) = 0x1800c20f9;
                fcn.180459c3c(uVar9);
            }
            *(undefined4 **)arg1 = puVar11;
            *(undefined4 **)(arg1 + 8) = puVar11 + uVar6 * 0xe;
            *(undefined4 **)(arg1 + 0x10) = puVar11 + uVar15 * 0xe;
            return;
        }
    }
code_r0x0001800bf7fe:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800bf7fe
// Address: 0x1800bf7fe
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800bf640(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    uint64_t uVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    undefined *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    uint64_t uVar15;
    undefined8 uVar16;
    undefined8 uVar17;
    uint64_t uVar18;
    int64_t iVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar12 = auStack_38;
    puVar13 = auStack_38;
    puVar10 = *(undefined4 **)(arg1 + 8);
    if (puVar10 != *(undefined4 **)(arg1 + 0x10)) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *puVar10 = *(undefined4 *)arg2;
        puVar10[1] = uVar3;
        puVar10[2] = uVar4;
        puVar10[3] = uVar5;
        uVar3 = *(undefined4 *)(arg2 + 0x14);
        uVar4 = *(undefined4 *)(arg2 + 0x18);
        uVar5 = *(undefined4 *)(arg2 + 0x1c);
        puVar10[4] = *(undefined4 *)(arg2 + 0x10);
        puVar10[5] = uVar3;
        puVar10[6] = uVar4;
        puVar10[7] = uVar5;
        uVar3 = *(undefined4 *)(arg2 + 0x24);
        uVar4 = *(undefined4 *)(arg2 + 0x28);
        uVar5 = *(undefined4 *)(arg2 + 0x2c);
        puVar10[8] = *(undefined4 *)(arg2 + 0x20);
        puVar10[9] = uVar3;
        puVar10[10] = uVar4;
        puVar10[0xb] = uVar5;
        *(undefined8 *)(puVar10 + 0xc) = *(undefined8 *)(arg2 + 0x30);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x38;
        return;
    }
    iVar19 = ((int64_t)puVar10 - *(int64_t *)arg1) / 0x38;
    if (iVar19 == 0x492492492492492) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar18 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar6 = 0x492492492492492 - (uVar18 >> 1);
    if (uVar18 < uVar6 || uVar18 - uVar6 == 0) {
        uVar6 = iVar19 + 1;
        uVar18 = uVar18 + (uVar18 >> 1);
        uVar15 = uVar6;
        if (uVar6 <= uVar18) {
            uVar15 = uVar18;
        }
        if (uVar15 < 0x492492492492493) {
            uVar18 = uVar15 * 0x38;
            if (uVar18 == 0) {
                puVar11 = (undefined4 *)0x0;
                puVar13 = auStack_38;
            } else if (uVar18 < 0x1000) {
                puVar11 = (undefined4 *)fcn.180459890();
            } else {
                if (uVar18 + 0x27 <= uVar18) goto code_r0x0001800bf7fe;
                iVar7 = fcn.180459890(uVar18 + 0x27);
                if (iVar7 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar7 = (*pcVar2)(5);
                    puVar12 = auStack_30;
                }
                puVar11 = (undefined4 *)(iVar7 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar11 + -2) = iVar7;
                puVar13 = puVar12;
            }
            uVar3 = *(undefined4 *)(arg2 + 4);
            uVar4 = *(undefined4 *)(arg2 + 8);
            uVar5 = *(undefined4 *)(arg2 + 0xc);
            puVar8 = puVar11 + iVar19 * 0xe;
            *puVar8 = *(undefined4 *)arg2;
            puVar8[1] = uVar3;
            puVar8[2] = uVar4;
            puVar8[3] = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x14);
            uVar4 = *(undefined4 *)(arg2 + 0x18);
            uVar5 = *(undefined4 *)(arg2 + 0x1c);
            puVar8[4] = *(undefined4 *)(arg2 + 0x10);
            puVar8[5] = uVar3;
            puVar8[6] = uVar4;
            puVar8[7] = uVar5;
            uVar3 = *(undefined4 *)(arg2 + 0x24);
            uVar4 = *(undefined4 *)(arg2 + 0x28);
            uVar5 = *(undefined4 *)(arg2 + 0x2c);
            puVar8[8] = *(undefined4 *)(arg2 + 0x20);
            puVar8[9] = uVar3;
            puVar8[10] = uVar4;
            puVar8[0xb] = uVar5;
            *(undefined8 *)(puVar8 + 0xc) = *(undefined8 *)(arg2 + 0x30);
            puVar1 = *(undefined4 **)arg1;
            if (puVar10 == *(undefined4 **)(arg1 + 8)) {
                iVar19 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar1;
                puVar8 = puVar11;
                puVar10 = puVar1;
            } else {
                *(undefined8 *)(puVar13 + -8) = 0x1800bf7b8;
                fcn.180498030(puVar11, puVar1, (int64_t)puVar10 - (int64_t)puVar1);
                puVar8 = puVar8 + 0xe;
                iVar19 = *(int64_t *)(arg1 + 8) - (int64_t)puVar10;
            }
            *(undefined8 *)(puVar13 + -8) = 0x1800bf7cb;
            fcn.180498030(puVar8, puVar10, iVar19);
            uVar17 = *(undefined8 *)(puVar13 + 0x28);
            uVar16 = *(undefined8 *)(puVar13 + 0x30);
            *(undefined8 *)(puVar13 + 0x30) = *(undefined8 *)(puVar13 + 0x40);
            *(undefined8 *)(puVar13 + 0x28) = *(undefined8 *)(puVar13 + 0x48);
            *(undefined8 *)(puVar13 + 0x20) = uVar16;
            *(undefined8 *)(puVar13 + 0x18) = uVar17;
            uVar18 = *(uint64_t *)arg1;
            if (uVar18 != 0) {
                uVar9 = uVar18;
                puVar14 = puVar13 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar18) >> 3) * 8)) {
                    uVar9 = *(uint64_t *)(uVar18 - 8);
                    uVar18 = (uVar18 - uVar9) - 8;
                    puVar14 = puVar13 + -0x10;
                    if (0x1f < uVar18) {
                        pcVar2 = (code *)swi(0x29);
                        uVar9 = uVar18;
                        (*pcVar2)(5);
                        puVar14 = puVar13 + -8;
                    }
                }
                *(undefined8 *)(puVar14 + -8) = 0x1800c20f9;
                fcn.180459c3c(uVar9);
            }
            *(undefined4 **)arg1 = puVar11;
            *(undefined4 **)(arg1 + 8) = puVar11 + uVar6 * 0xe;
            *(undefined4 **)(arg1 + 0x10) = puVar11 + uVar15 * 0xe;
            return;
        }
    }
code_r0x0001800bf7fe:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800bf810
// Address: 0x1800bf810
// Size: 118 bytes
// ============================================================
void fcn.1800bf810(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 3) * 8;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                uVar3 = 5;
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800bf873;
        fcn.180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800bf890
// Address: 0x1800bf890
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800bf890(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined8 *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar7 = auStack_38;
    puVar8 = auStack_38;
    puVar6 = *(undefined8 **)(arg1 + 8);
    if (puVar6 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined8 *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
        return;
    }
    iVar14 = (int64_t)puVar6 - *(int64_t *)arg1 >> 3;
    if (iVar14 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (uVar4 <= 0x1fffffffffffffff - (uVar4 >> 1)) {
        uVar1 = iVar14 + 1;
        uVar4 = uVar4 + (uVar4 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar4) {
            uVar10 = uVar4;
        }
        if (uVar10 < 0x2000000000000000) {
            uVar4 = uVar10 * 8;
            if (uVar4 == 0) {
                uVar4 = 0;
                puVar8 = auStack_38;
            } else if (uVar4 < 0x1000) {
                uVar4 = fcn.180459890();
            } else {
                if (uVar4 + 0x27 <= uVar4) goto code_r0x0001800bf9ec;
                iVar12 = fcn.180459890(uVar4 + 0x27);
                if (iVar12 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar12 = (*pcVar3)(5);
                    puVar7 = auStack_30;
                }
                uVar4 = iVar12 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar4 - 8) = iVar12;
                puVar8 = puVar7;
            }
            *(undefined8 *)(uVar4 + iVar14 * 8) = *(undefined8 *)arg2;
            puVar2 = *(undefined8 **)arg1;
            if (puVar6 == *(undefined8 **)(arg1 + 8)) {
                iVar12 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
                uVar13 = uVar4;
                puVar6 = puVar2;
            } else {
                *(undefined8 *)(puVar8 + -8) = 0x1800bf9a2;
                fcn.180498030(uVar4, puVar2, (int64_t)puVar6 - (int64_t)puVar2);
                iVar12 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
                uVar13 = uVar4 + (iVar14 + 1) * 8;
            }
            *(undefined8 *)(puVar8 + -8) = 0x1800bf9b9;
            fcn.180498030(uVar13, puVar6, iVar12);
            uVar11 = *(undefined8 *)(puVar8 + 0x28);
            *(undefined8 *)(puVar8 + 0x30) = *(undefined8 *)(puVar8 + 0x30);
            *(undefined8 *)(puVar8 + 0x28) = *(undefined8 *)(puVar8 + 0x40);
            *(undefined8 *)(puVar8 + 0x20) = uVar11;
            *(undefined8 *)(puVar8 + 0x18) = *(undefined8 *)(puVar8 + 0x48);
            uVar13 = *(uint64_t *)arg1;
            if (uVar13 != 0) {
                uVar5 = uVar13;
                puVar9 = puVar8 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar13) >> 3) * 8)) {
                    uVar5 = *(uint64_t *)(uVar13 - 8);
                    uVar13 = (uVar13 - uVar5) - 8;
                    puVar9 = puVar8 + -0x10;
                    if (0x1f < uVar13) {
                        pcVar3 = (code *)swi(0x29);
                        uVar5 = uVar13;
                        (*pcVar3)(5);
                        puVar9 = puVar8 + -8;
                    }
                }
                *(undefined8 *)(puVar9 + -8) = 0x1800c217f;
                fcn.180459c3c(uVar5);
            }
            *(uint64_t *)arg1 = uVar4;
            *(uint64_t *)(arg1 + 8) = uVar4 + uVar1 * 8;
            *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar10 * 8;
            return;
        }
    }
code_r0x0001800bf9ec:
    fcn.180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800bf8cd
// Address: 0x1800bf8cd
// Size: 281 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800bf890(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined8 *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar7 = auStack_38;
    puVar8 = auStack_38;
    puVar6 = *(undefined8 **)(arg1 + 8);
    if (puVar6 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined8 *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
        return;
    }
    iVar14 = (int64_t)puVar6 - *(int64_t *)arg1 >> 3;
    if (iVar14 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (uVar4 <= 0x1fffffffffffffff - (uVar4 >> 1)) {
        uVar1 = iVar14 + 1;
        uVar4 = uVar4 + (uVar4 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar4) {
            uVar10 = uVar4;
        }
        if (uVar10 < 0x2000000000000000) {
            uVar4 = uVar10 * 8;
            if (uVar4 == 0) {
                uVar4 = 0;
                puVar8 = auStack_38;
            } else if (uVar4 < 0x1000) {
                uVar4 = fcn.180459890();
            } else {
                if (uVar4 + 0x27 <= uVar4) goto code_r0x0001800bf9ec;
                iVar12 = fcn.180459890(uVar4 + 0x27);
                if (iVar12 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar12 = (*pcVar3)(5);
                    puVar7 = auStack_30;
                }
                uVar4 = iVar12 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar4 - 8) = iVar12;
                puVar8 = puVar7;
            }
            *(undefined8 *)(uVar4 + iVar14 * 8) = *(undefined8 *)arg2;
            puVar2 = *(undefined8 **)arg1;
            if (puVar6 == *(undefined8 **)(arg1 + 8)) {
                iVar12 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
                uVar13 = uVar4;
                puVar6 = puVar2;
            } else {
                *(undefined8 *)(puVar8 + -8) = 0x1800bf9a2;
                fcn.180498030(uVar4, puVar2, (int64_t)puVar6 - (int64_t)puVar2);
                iVar12 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
                uVar13 = uVar4 + (iVar14 + 1) * 8;
            }
            *(undefined8 *)(puVar8 + -8) = 0x1800bf9b9;
            fcn.180498030(uVar13, puVar6, iVar12);
            uVar11 = *(undefined8 *)(puVar8 + 0x28);
            *(undefined8 *)(puVar8 + 0x30) = *(undefined8 *)(puVar8 + 0x30);
            *(undefined8 *)(puVar8 + 0x28) = *(undefined8 *)(puVar8 + 0x40);
            *(undefined8 *)(puVar8 + 0x20) = uVar11;
            *(undefined8 *)(puVar8 + 0x18) = *(undefined8 *)(puVar8 + 0x48);
            uVar13 = *(uint64_t *)arg1;
            if (uVar13 != 0) {
                uVar5 = uVar13;
                puVar9 = puVar8 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar13) >> 3) * 8)) {
                    uVar5 = *(uint64_t *)(uVar13 - 8);
                    uVar13 = (uVar13 - uVar5) - 8;
                    puVar9 = puVar8 + -0x10;
                    if (0x1f < uVar13) {
                        pcVar3 = (code *)swi(0x29);
                        uVar5 = uVar13;
                        (*pcVar3)(5);
                        puVar9 = puVar8 + -8;
                    }
                }
                *(undefined8 *)(puVar9 + -8) = 0x1800c217f;
                fcn.180459c3c(uVar5);
            }
            *(uint64_t *)arg1 = uVar4;
            *(uint64_t *)(arg1 + 8) = uVar4 + uVar1 * 8;
            *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar10 * 8;
            return;
        }
    }
code_r0x0001800bf9ec:
    fcn.180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800bf9e6
// Address: 0x1800bf9e6
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800bf890(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined8 *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar7 = auStack_38;
    puVar8 = auStack_38;
    puVar6 = *(undefined8 **)(arg1 + 8);
    if (puVar6 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined8 *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
        return;
    }
    iVar14 = (int64_t)puVar6 - *(int64_t *)arg1 >> 3;
    if (iVar14 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (uVar4 <= 0x1fffffffffffffff - (uVar4 >> 1)) {
        uVar1 = iVar14 + 1;
        uVar4 = uVar4 + (uVar4 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar4) {
            uVar10 = uVar4;
        }
        if (uVar10 < 0x2000000000000000) {
            uVar4 = uVar10 * 8;
            if (uVar4 == 0) {
                uVar4 = 0;
                puVar8 = auStack_38;
            } else if (uVar4 < 0x1000) {
                uVar4 = fcn.180459890();
            } else {
                if (uVar4 + 0x27 <= uVar4) goto code_r0x0001800bf9ec;
                iVar12 = fcn.180459890(uVar4 + 0x27);
                if (iVar12 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar12 = (*pcVar3)(5);
                    puVar7 = auStack_30;
                }
                uVar4 = iVar12 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar4 - 8) = iVar12;
                puVar8 = puVar7;
            }
            *(undefined8 *)(uVar4 + iVar14 * 8) = *(undefined8 *)arg2;
            puVar2 = *(undefined8 **)arg1;
            if (puVar6 == *(undefined8 **)(arg1 + 8)) {
                iVar12 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
                uVar13 = uVar4;
                puVar6 = puVar2;
            } else {
                *(undefined8 *)(puVar8 + -8) = 0x1800bf9a2;
                fcn.180498030(uVar4, puVar2, (int64_t)puVar6 - (int64_t)puVar2);
                iVar12 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
                uVar13 = uVar4 + (iVar14 + 1) * 8;
            }
            *(undefined8 *)(puVar8 + -8) = 0x1800bf9b9;
            fcn.180498030(uVar13, puVar6, iVar12);
            uVar11 = *(undefined8 *)(puVar8 + 0x28);
            *(undefined8 *)(puVar8 + 0x30) = *(undefined8 *)(puVar8 + 0x30);
            *(undefined8 *)(puVar8 + 0x28) = *(undefined8 *)(puVar8 + 0x40);
            *(undefined8 *)(puVar8 + 0x20) = uVar11;
            *(undefined8 *)(puVar8 + 0x18) = *(undefined8 *)(puVar8 + 0x48);
            uVar13 = *(uint64_t *)arg1;
            if (uVar13 != 0) {
                uVar5 = uVar13;
                puVar9 = puVar8 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar13) >> 3) * 8)) {
                    uVar5 = *(uint64_t *)(uVar13 - 8);
                    uVar13 = (uVar13 - uVar5) - 8;
                    puVar9 = puVar8 + -0x10;
                    if (0x1f < uVar13) {
                        pcVar3 = (code *)swi(0x29);
                        uVar5 = uVar13;
                        (*pcVar3)(5);
                        puVar9 = puVar8 + -8;
                    }
                }
                *(undefined8 *)(puVar9 + -8) = 0x1800c217f;
                fcn.180459c3c(uVar5);
            }
            *(uint64_t *)arg1 = uVar4;
            *(uint64_t *)(arg1 + 8) = uVar4 + uVar1 * 8;
            *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar10 * 8;
            return;
        }
    }
code_r0x0001800bf9ec:
    fcn.180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800bf9ec
// Address: 0x1800bf9ec
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800bf890(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined8 *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar7 = auStack_38;
    puVar8 = auStack_38;
    puVar6 = *(undefined8 **)(arg1 + 8);
    if (puVar6 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined8 *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
        return;
    }
    iVar14 = (int64_t)puVar6 - *(int64_t *)arg1 >> 3;
    if (iVar14 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (uVar4 <= 0x1fffffffffffffff - (uVar4 >> 1)) {
        uVar1 = iVar14 + 1;
        uVar4 = uVar4 + (uVar4 >> 1);
        uVar10 = uVar1;
        if (uVar1 <= uVar4) {
            uVar10 = uVar4;
        }
        if (uVar10 < 0x2000000000000000) {
            uVar4 = uVar10 * 8;
            if (uVar4 == 0) {
                uVar4 = 0;
                puVar8 = auStack_38;
            } else if (uVar4 < 0x1000) {
                uVar4 = fcn.180459890();
            } else {
                if (uVar4 + 0x27 <= uVar4) goto code_r0x0001800bf9ec;
                iVar12 = fcn.180459890(uVar4 + 0x27);
                if (iVar12 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar12 = (*pcVar3)(5);
                    puVar7 = auStack_30;
                }
                uVar4 = iVar12 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar4 - 8) = iVar12;
                puVar8 = puVar7;
            }
            *(undefined8 *)(uVar4 + iVar14 * 8) = *(undefined8 *)arg2;
            puVar2 = *(undefined8 **)arg1;
            if (puVar6 == *(undefined8 **)(arg1 + 8)) {
                iVar12 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
                uVar13 = uVar4;
                puVar6 = puVar2;
            } else {
                *(undefined8 *)(puVar8 + -8) = 0x1800bf9a2;
                fcn.180498030(uVar4, puVar2, (int64_t)puVar6 - (int64_t)puVar2);
                iVar12 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
                uVar13 = uVar4 + (iVar14 + 1) * 8;
            }
            *(undefined8 *)(puVar8 + -8) = 0x1800bf9b9;
            fcn.180498030(uVar13, puVar6, iVar12);
            uVar11 = *(undefined8 *)(puVar8 + 0x28);
            *(undefined8 *)(puVar8 + 0x30) = *(undefined8 *)(puVar8 + 0x30);
            *(undefined8 *)(puVar8 + 0x28) = *(undefined8 *)(puVar8 + 0x40);
            *(undefined8 *)(puVar8 + 0x20) = uVar11;
            *(undefined8 *)(puVar8 + 0x18) = *(undefined8 *)(puVar8 + 0x48);
            uVar13 = *(uint64_t *)arg1;
            if (uVar13 != 0) {
                uVar5 = uVar13;
                puVar9 = puVar8 + -0x10;
                if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar13) >> 3) * 8)) {
                    uVar5 = *(uint64_t *)(uVar13 - 8);
                    uVar13 = (uVar13 - uVar5) - 8;
                    puVar9 = puVar8 + -0x10;
                    if (0x1f < uVar13) {
                        pcVar3 = (code *)swi(0x29);
                        uVar5 = uVar13;
                        (*pcVar3)(5);
                        puVar9 = puVar8 + -8;
                    }
                }
                *(undefined8 *)(puVar9 + -8) = 0x1800c217f;
                fcn.180459c3c(uVar5);
            }
            *(uint64_t *)arg1 = uVar4;
            *(uint64_t *)(arg1 + 8) = uVar4 + uVar1 * 8;
            *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar10 * 8;
            return;
        }
    }
code_r0x0001800bf9ec:
    fcn.180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800bfa00
// Address: 0x1800bfa00
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800bfa00(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x30) {
            func_0x00018000ace0(iVar3 + 0x18);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 4) << 4)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800bfa94;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800bfa19
// Address: 0x1800bfa19
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800bfa00(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x30) {
            func_0x00018000ace0(iVar3 + 0x18);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 4) << 4)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800bfa94;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800bfa6b
// Address: 0x1800bfa6b
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800bfa00(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x30) {
            func_0x00018000ace0(iVar3 + 0x18);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 4) << 4)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800bfa94;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800bfab0
// Address: 0x1800bfab0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800bfab0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    undefined *puVar12;
    undefined4 *unaff_RDI;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    int64_t var_20h;
    
    puVar11 = *(undefined4 **)(arg1 + 8);
    if (puVar11 != *(undefined4 **)(arg1 + 0x10)) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *puVar11 = *(undefined4 *)arg2;
        puVar11[1] = uVar3;
        puVar11[2] = uVar4;
        puVar11[3] = uVar5;
        *(undefined8 *)(puVar11 + 4) = *(undefined8 *)(arg2 + 0x10);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x18;
        return;
    }
    iVar7 = (int64_t)puVar11 - *(int64_t *)arg1;
    iVar7 = iVar7 / 6 + (iVar7 >> 0x3f);
    iVar7 = (iVar7 >> 2) - (iVar7 >> 0x3f);
    if (iVar7 == 0xaaaaaaaaaaaaaaa) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar13 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * -0x5555555555555555;
    uVar6 = 0xaaaaaaaaaaaaaaa - (uVar13 >> 1);
    if (uVar6 <= uVar13 && uVar13 - uVar6 != 0) {
code_r0x0001800bfcb2:
        fcn.180004720();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar13 = uVar13 + (uVar13 >> 1);
    uVar6 = iVar7 + 1;
    uVar8 = uVar6;
    if (uVar6 <= uVar13) {
        uVar8 = uVar13;
    }
    if (0xaaaaaaaaaaaaaaa < uVar8) goto code_r0x0001800bfcb2;
    uVar13 = uVar8 * 0x18;
    if (uVar13 == 0) {
        unaff_RDI = (undefined4 *)0x0;
code_r0x0001800bfbd2:
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        puVar9 = unaff_RDI + iVar7 * 6;
        *puVar9 = *(undefined4 *)arg2;
        puVar9[1] = uVar3;
        puVar9[2] = uVar4;
        puVar9[3] = uVar5;
        *(undefined8 *)(puVar9 + 4) = *(undefined8 *)(arg2 + 0x10);
        puVar1 = *(undefined4 **)arg1;
        if (puVar11 == *(undefined4 **)(arg1 + 8)) {
            iVar7 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar1;
            puVar9 = unaff_RDI;
            puVar11 = puVar1;
        } else {
            fcn.180498030(unaff_RDI, puVar1, (int64_t)puVar11 - (int64_t)puVar1);
            puVar9 = puVar9 + 6;
            iVar7 = *(int64_t *)(arg1 + 8) - (int64_t)puVar11;
        }
        fcn.180498030(puVar9, puVar11, iVar7);
        iVar7 = *(int64_t *)arg1;
        if (iVar7 == 0) goto code_r0x0001800bfc74;
        iVar10 = iVar7;
        puVar12 = auStack_48;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 3) * 8)) &&
           (iVar10 = *(int64_t *)(iVar7 + -8), puVar12 = auStack_48, 0x1f < (iVar7 - iVar10) - 8U))
        goto code_r0x0001800bfc62;
    } else {
        if (uVar13 < 0x1000) {
            unaff_RDI = (undefined4 *)fcn.180459890(uVar13);
            goto code_r0x0001800bfbd2;
        }
        if (uVar13 + 0x27 <= uVar13) goto code_r0x0001800bfcb2;
        iVar10 = fcn.180459890();
        if (iVar10 != 0) {
            unaff_RDI = (undefined4 *)(iVar10 + 0x27U & 0xffffffffffffffe0);
            *(int64_t *)(unaff_RDI + -2) = iVar10;
            goto code_r0x0001800bfbd2;
        }
code_r0x0001800bfc62:
        iVar10 = 5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar12 = auStack_40;
    }
    *(undefined8 *)(puVar12 + -8) = 0x1800bfc74;
    fcn.180459c3c(iVar10);
code_r0x0001800bfc74:
    *(undefined4 **)arg1 = unaff_RDI;
    *(undefined4 **)(arg1 + 8) = unaff_RDI + uVar6 * 6;
    *(undefined4 **)(arg1 + 0x10) = unaff_RDI + uVar8 * 6;
    return;
}

// ============================================================
// Function: FUN_1800bfaf5
// Address: 0x1800bfaf5
// Size: 439 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800bfab0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    undefined *puVar12;
    undefined4 *unaff_RDI;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    int64_t var_20h;
    
    puVar11 = *(undefined4 **)(arg1 + 8);
    if (puVar11 != *(undefined4 **)(arg1 + 0x10)) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *puVar11 = *(undefined4 *)arg2;
        puVar11[1] = uVar3;
        puVar11[2] = uVar4;
        puVar11[3] = uVar5;
        *(undefined8 *)(puVar11 + 4) = *(undefined8 *)(arg2 + 0x10);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x18;
        return;
    }
    iVar7 = (int64_t)puVar11 - *(int64_t *)arg1;
    iVar7 = iVar7 / 6 + (iVar7 >> 0x3f);
    iVar7 = (iVar7 >> 2) - (iVar7 >> 0x3f);
    if (iVar7 == 0xaaaaaaaaaaaaaaa) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar13 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * -0x5555555555555555;
    uVar6 = 0xaaaaaaaaaaaaaaa - (uVar13 >> 1);
    if (uVar6 <= uVar13 && uVar13 - uVar6 != 0) {
code_r0x0001800bfcb2:
        fcn.180004720();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar13 = uVar13 + (uVar13 >> 1);
    uVar6 = iVar7 + 1;
    uVar8 = uVar6;
    if (uVar6 <= uVar13) {
        uVar8 = uVar13;
    }
    if (0xaaaaaaaaaaaaaaa < uVar8) goto code_r0x0001800bfcb2;
    uVar13 = uVar8 * 0x18;
    if (uVar13 == 0) {
        unaff_RDI = (undefined4 *)0x0;
code_r0x0001800bfbd2:
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        puVar9 = unaff_RDI + iVar7 * 6;
        *puVar9 = *(undefined4 *)arg2;
        puVar9[1] = uVar3;
        puVar9[2] = uVar4;
        puVar9[3] = uVar5;
        *(undefined8 *)(puVar9 + 4) = *(undefined8 *)(arg2 + 0x10);
        puVar1 = *(undefined4 **)arg1;
        if (puVar11 == *(undefined4 **)(arg1 + 8)) {
            iVar7 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar1;
            puVar9 = unaff_RDI;
            puVar11 = puVar1;
        } else {
            fcn.180498030(unaff_RDI, puVar1, (int64_t)puVar11 - (int64_t)puVar1);
            puVar9 = puVar9 + 6;
            iVar7 = *(int64_t *)(arg1 + 8) - (int64_t)puVar11;
        }
        fcn.180498030(puVar9, puVar11, iVar7);
        iVar7 = *(int64_t *)arg1;
        if (iVar7 == 0) goto code_r0x0001800bfc74;
        iVar10 = iVar7;
        puVar12 = auStack_48;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 3) * 8)) &&
           (iVar10 = *(int64_t *)(iVar7 + -8), puVar12 = auStack_48, 0x1f < (iVar7 - iVar10) - 8U))
        goto code_r0x0001800bfc62;
    } else {
        if (uVar13 < 0x1000) {
            unaff_RDI = (undefined4 *)fcn.180459890(uVar13);
            goto code_r0x0001800bfbd2;
        }
        if (uVar13 + 0x27 <= uVar13) goto code_r0x0001800bfcb2;
        iVar10 = fcn.180459890();
        if (iVar10 != 0) {
            unaff_RDI = (undefined4 *)(iVar10 + 0x27U & 0xffffffffffffffe0);
            *(int64_t *)(unaff_RDI + -2) = iVar10;
            goto code_r0x0001800bfbd2;
        }
code_r0x0001800bfc62:
        iVar10 = 5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar12 = auStack_40;
    }
    *(undefined8 *)(puVar12 + -8) = 0x1800bfc74;
    fcn.180459c3c(iVar10);
code_r0x0001800bfc74:
    *(undefined4 **)arg1 = unaff_RDI;
    *(undefined4 **)(arg1 + 8) = unaff_RDI + uVar6 * 6;
    *(undefined4 **)(arg1 + 0x10) = unaff_RDI + uVar8 * 6;
    return;
}

// ============================================================
// Function: FUN_1800bfcac
// Address: 0x1800bfcac
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800bfab0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    undefined *puVar12;
    undefined4 *unaff_RDI;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    int64_t var_20h;
    
    puVar11 = *(undefined4 **)(arg1 + 8);
    if (puVar11 != *(undefined4 **)(arg1 + 0x10)) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *puVar11 = *(undefined4 *)arg2;
        puVar11[1] = uVar3;
        puVar11[2] = uVar4;
        puVar11[3] = uVar5;
        *(undefined8 *)(puVar11 + 4) = *(undefined8 *)(arg2 + 0x10);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x18;
        return;
    }
    iVar7 = (int64_t)puVar11 - *(int64_t *)arg1;
    iVar7 = iVar7 / 6 + (iVar7 >> 0x3f);
    iVar7 = (iVar7 >> 2) - (iVar7 >> 0x3f);
    if (iVar7 == 0xaaaaaaaaaaaaaaa) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar13 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * -0x5555555555555555;
    uVar6 = 0xaaaaaaaaaaaaaaa - (uVar13 >> 1);
    if (uVar6 <= uVar13 && uVar13 - uVar6 != 0) {
code_r0x0001800bfcb2:
        fcn.180004720();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar13 = uVar13 + (uVar13 >> 1);
    uVar6 = iVar7 + 1;
    uVar8 = uVar6;
    if (uVar6 <= uVar13) {
        uVar8 = uVar13;
    }
    if (0xaaaaaaaaaaaaaaa < uVar8) goto code_r0x0001800bfcb2;
    uVar13 = uVar8 * 0x18;
    if (uVar13 == 0) {
        unaff_RDI = (undefined4 *)0x0;
code_r0x0001800bfbd2:
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        puVar9 = unaff_RDI + iVar7 * 6;
        *puVar9 = *(undefined4 *)arg2;
        puVar9[1] = uVar3;
        puVar9[2] = uVar4;
        puVar9[3] = uVar5;
        *(undefined8 *)(puVar9 + 4) = *(undefined8 *)(arg2 + 0x10);
        puVar1 = *(undefined4 **)arg1;
        if (puVar11 == *(undefined4 **)(arg1 + 8)) {
            iVar7 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar1;
            puVar9 = unaff_RDI;
            puVar11 = puVar1;
        } else {
            fcn.180498030(unaff_RDI, puVar1, (int64_t)puVar11 - (int64_t)puVar1);
            puVar9 = puVar9 + 6;
            iVar7 = *(int64_t *)(arg1 + 8) - (int64_t)puVar11;
        }
        fcn.180498030(puVar9, puVar11, iVar7);
        iVar7 = *(int64_t *)arg1;
        if (iVar7 == 0) goto code_r0x0001800bfc74;
        iVar10 = iVar7;
        puVar12 = auStack_48;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 3) * 8)) &&
           (iVar10 = *(int64_t *)(iVar7 + -8), puVar12 = auStack_48, 0x1f < (iVar7 - iVar10) - 8U))
        goto code_r0x0001800bfc62;
    } else {
        if (uVar13 < 0x1000) {
            unaff_RDI = (undefined4 *)fcn.180459890(uVar13);
            goto code_r0x0001800bfbd2;
        }
        if (uVar13 + 0x27 <= uVar13) goto code_r0x0001800bfcb2;
        iVar10 = fcn.180459890();
        if (iVar10 != 0) {
            unaff_RDI = (undefined4 *)(iVar10 + 0x27U & 0xffffffffffffffe0);
            *(int64_t *)(unaff_RDI + -2) = iVar10;
            goto code_r0x0001800bfbd2;
        }
code_r0x0001800bfc62:
        iVar10 = 5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar12 = auStack_40;
    }
    *(undefined8 *)(puVar12 + -8) = 0x1800bfc74;
    fcn.180459c3c(iVar10);
code_r0x0001800bfc74:
    *(undefined4 **)arg1 = unaff_RDI;
    *(undefined4 **)(arg1 + 8) = unaff_RDI + uVar6 * 6;
    *(undefined4 **)(arg1 + 0x10) = unaff_RDI + uVar8 * 6;
    return;
}

// ============================================================
// Function: FUN_1800bfcb2
// Address: 0x1800bfcb2
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800bfab0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    undefined *puVar12;
    undefined4 *unaff_RDI;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    int64_t var_20h;
    
    puVar11 = *(undefined4 **)(arg1 + 8);
    if (puVar11 != *(undefined4 **)(arg1 + 0x10)) {
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *puVar11 = *(undefined4 *)arg2;
        puVar11[1] = uVar3;
        puVar11[2] = uVar4;
        puVar11[3] = uVar5;
        *(undefined8 *)(puVar11 + 4) = *(undefined8 *)(arg2 + 0x10);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x18;
        return;
    }
    iVar7 = (int64_t)puVar11 - *(int64_t *)arg1;
    iVar7 = iVar7 / 6 + (iVar7 >> 0x3f);
    iVar7 = (iVar7 >> 2) - (iVar7 >> 0x3f);
    if (iVar7 == 0xaaaaaaaaaaaaaaa) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar13 = ((int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * -0x5555555555555555;
    uVar6 = 0xaaaaaaaaaaaaaaa - (uVar13 >> 1);
    if (uVar6 <= uVar13 && uVar13 - uVar6 != 0) {
code_r0x0001800bfcb2:
        fcn.180004720();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar13 = uVar13 + (uVar13 >> 1);
    uVar6 = iVar7 + 1;
    uVar8 = uVar6;
    if (uVar6 <= uVar13) {
        uVar8 = uVar13;
    }
    if (0xaaaaaaaaaaaaaaa < uVar8) goto code_r0x0001800bfcb2;
    uVar13 = uVar8 * 0x18;
    if (uVar13 == 0) {
        unaff_RDI = (undefined4 *)0x0;
code_r0x0001800bfbd2:
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        puVar9 = unaff_RDI + iVar7 * 6;
        *puVar9 = *(undefined4 *)arg2;
        puVar9[1] = uVar3;
        puVar9[2] = uVar4;
        puVar9[3] = uVar5;
        *(undefined8 *)(puVar9 + 4) = *(undefined8 *)(arg2 + 0x10);
        puVar1 = *(undefined4 **)arg1;
        if (puVar11 == *(undefined4 **)(arg1 + 8)) {
            iVar7 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar1;
            puVar9 = unaff_RDI;
            puVar11 = puVar1;
        } else {
            fcn.180498030(unaff_RDI, puVar1, (int64_t)puVar11 - (int64_t)puVar1);
            puVar9 = puVar9 + 6;
            iVar7 = *(int64_t *)(arg1 + 8) - (int64_t)puVar11;
        }
        fcn.180498030(puVar9, puVar11, iVar7);
        iVar7 = *(int64_t *)arg1;
        if (iVar7 == 0) goto code_r0x0001800bfc74;
        iVar10 = iVar7;
        puVar12 = auStack_48;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 3) * 8)) &&
           (iVar10 = *(int64_t *)(iVar7 + -8), puVar12 = auStack_48, 0x1f < (iVar7 - iVar10) - 8U))
        goto code_r0x0001800bfc62;
    } else {
        if (uVar13 < 0x1000) {
            unaff_RDI = (undefined4 *)fcn.180459890(uVar13);
            goto code_r0x0001800bfbd2;
        }
        if (uVar13 + 0x27 <= uVar13) goto code_r0x0001800bfcb2;
        iVar10 = fcn.180459890();
        if (iVar10 != 0) {
            unaff_RDI = (undefined4 *)(iVar10 + 0x27U & 0xffffffffffffffe0);
            *(int64_t *)(unaff_RDI + -2) = iVar10;
            goto code_r0x0001800bfbd2;
        }
code_r0x0001800bfc62:
        iVar10 = 5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar12 = auStack_40;
    }
    *(undefined8 *)(puVar12 + -8) = 0x1800bfc74;
    fcn.180459c3c(iVar10);
code_r0x0001800bfc74:
    *(undefined4 **)arg1 = unaff_RDI;
    *(undefined4 **)(arg1 + 8) = unaff_RDI + uVar6 * 6;
    *(undefined4 **)(arg1 + 0x10) = unaff_RDI + uVar8 * 6;
    return;
}

// ============================================================
// Function: FUN_1800bfcc0
// Address: 0x1800bfcc0
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800bfcc0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    undefined *puVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_40h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = auStack_38;
    puVar6 = auStack_38;
    iVar8 = *(int64_t *)(arg1 + 8);
    iVar4 = *(int64_t *)arg1;
    uVar7 = iVar8 - iVar4 >> 4;
    if ((uint64_t)arg2 < uVar7) {
        *(int64_t *)(arg1 + 8) = arg2 * 0x10 + iVar4;
        return;
    }
    if (uVar7 < (uint64_t)arg2) {
        uVar2 = *(int64_t *)(arg1 + 0x10) - iVar4 >> 4;
        if ((uint64_t)arg2 <= uVar2) {
            iVar4 = arg2 - uVar7;
            if (iVar4 != 0) {
                fcn.1804986e0(iVar8, arg2 & 0xffffffffffffff00, iVar4 * 0x10);
                do {
                    iVar8 = iVar8 + 0x10;
                    iVar4 = iVar4 + -1;
                } while (iVar4 != 0);
            }
            *(int64_t *)(arg1 + 8) = iVar8;
            return;
        }
        if (0xfffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar3 = uVar2 >> 1;
        if ((0xfffffffffffffff - uVar3 < uVar2) ||
           ((uVar2 = uVar2 + uVar3, uVar9 = arg2, (uint64_t)arg2 <= uVar2 && (uVar9 = uVar2, 0xfffffffffffffff < uVar2))
           )) {
code_r0x0001800bfe4c:
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar2 = uVar9 * 0x10;
        if (uVar2 == 0) {
            uVar2 = 0;
            puVar6 = auStack_38;
        } else if (uVar2 < 0x1000) {
            uVar2 = fcn.180459890();
        } else {
            if (uVar2 + 0x27 <= uVar2) goto code_r0x0001800bfe4c;
            iVar8 = fcn.180459890(uVar2 + 0x27);
            if (iVar8 == 0) {
                pcVar1 = (code *)swi(0x29);
                iVar8 = (*pcVar1)(5);
                puVar5 = auStack_30;
            }
            uVar2 = iVar8 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar2 - 8) = iVar8;
            puVar6 = puVar5;
        }
        iVar8 = arg2 - uVar7;
        if (iVar8 != 0) {
            *(undefined8 *)(puVar6 + -8) = 0x1800bfdd8;
            fcn.1804986e0(uVar7 * 0x10 + uVar2, uVar3 & 0xffffffffffffff00, iVar8 * 0x10);
            do {
                iVar8 = iVar8 + -1;
            } while (iVar8 != 0);
        }
        iVar8 = *(int64_t *)arg1;
        iVar4 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar6 + -8) = 0x1800bfdf0;
        fcn.180498030(uVar2, iVar8, iVar4 - iVar8);
        *(undefined8 *)(puVar6 + -8) = 0x1800bfe01;
        fcn.1800c23d0(arg1, uVar2, arg2, uVar9);
    }
    return;
}

// ============================================================
// Function: FUN_1800bfd32
// Address: 0x1800bfd32
// Size: 217 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800bfcc0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    undefined *puVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_40h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = auStack_38;
    puVar6 = auStack_38;
    iVar8 = *(int64_t *)(arg1 + 8);
    iVar4 = *(int64_t *)arg1;
    uVar7 = iVar8 - iVar4 >> 4;
    if ((uint64_t)arg2 < uVar7) {
        *(int64_t *)(arg1 + 8) = arg2 * 0x10 + iVar4;
        return;
    }
    if (uVar7 < (uint64_t)arg2) {
        uVar2 = *(int64_t *)(arg1 + 0x10) - iVar4 >> 4;
        if ((uint64_t)arg2 <= uVar2) {
            iVar4 = arg2 - uVar7;
            if (iVar4 != 0) {
                fcn.1804986e0(iVar8, arg2 & 0xffffffffffffff00, iVar4 * 0x10);
                do {
                    iVar8 = iVar8 + 0x10;
                    iVar4 = iVar4 + -1;
                } while (iVar4 != 0);
            }
            *(int64_t *)(arg1 + 8) = iVar8;
            return;
        }
        if (0xfffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar3 = uVar2 >> 1;
        if ((0xfffffffffffffff - uVar3 < uVar2) ||
           ((uVar2 = uVar2 + uVar3, uVar9 = arg2, (uint64_t)arg2 <= uVar2 && (uVar9 = uVar2, 0xfffffffffffffff < uVar2))
           )) {
code_r0x0001800bfe4c:
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar2 = uVar9 * 0x10;
        if (uVar2 == 0) {
            uVar2 = 0;
            puVar6 = auStack_38;
        } else if (uVar2 < 0x1000) {
            uVar2 = fcn.180459890();
        } else {
            if (uVar2 + 0x27 <= uVar2) goto code_r0x0001800bfe4c;
            iVar8 = fcn.180459890(uVar2 + 0x27);
            if (iVar8 == 0) {
                pcVar1 = (code *)swi(0x29);
                iVar8 = (*pcVar1)(5);
                puVar5 = auStack_30;
            }
            uVar2 = iVar8 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar2 - 8) = iVar8;
            puVar6 = puVar5;
        }
        iVar8 = arg2 - uVar7;
        if (iVar8 != 0) {
            *(undefined8 *)(puVar6 + -8) = 0x1800bfdd8;
            fcn.1804986e0(uVar7 * 0x10 + uVar2, uVar3 & 0xffffffffffffff00, iVar8 * 0x10);
            do {
                iVar8 = iVar8 + -1;
            } while (iVar8 != 0);
        }
        iVar8 = *(int64_t *)arg1;
        iVar4 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar6 + -8) = 0x1800bfdf0;
        fcn.180498030(uVar2, iVar8, iVar4 - iVar8);
        *(undefined8 *)(puVar6 + -8) = 0x1800bfe01;
        fcn.1800c23d0(arg1, uVar2, arg2, uVar9);
    }
    return;
}

// ============================================================
// Function: FUN_1800bfe0b
// Address: 0x1800bfe0b
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800bfcc0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    undefined *puVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_40h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = auStack_38;
    puVar6 = auStack_38;
    iVar8 = *(int64_t *)(arg1 + 8);
    iVar4 = *(int64_t *)arg1;
    uVar7 = iVar8 - iVar4 >> 4;
    if ((uint64_t)arg2 < uVar7) {
        *(int64_t *)(arg1 + 8) = arg2 * 0x10 + iVar4;
        return;
    }
    if (uVar7 < (uint64_t)arg2) {
        uVar2 = *(int64_t *)(arg1 + 0x10) - iVar4 >> 4;
        if ((uint64_t)arg2 <= uVar2) {
            iVar4 = arg2 - uVar7;
            if (iVar4 != 0) {
                fcn.1804986e0(iVar8, arg2 & 0xffffffffffffff00, iVar4 * 0x10);
                do {
                    iVar8 = iVar8 + 0x10;
                    iVar4 = iVar4 + -1;
                } while (iVar4 != 0);
            }
            *(int64_t *)(arg1 + 8) = iVar8;
            return;
        }
        if (0xfffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar3 = uVar2 >> 1;
        if ((0xfffffffffffffff - uVar3 < uVar2) ||
           ((uVar2 = uVar2 + uVar3, uVar9 = arg2, (uint64_t)arg2 <= uVar2 && (uVar9 = uVar2, 0xfffffffffffffff < uVar2))
           )) {
code_r0x0001800bfe4c:
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar2 = uVar9 * 0x10;
        if (uVar2 == 0) {
            uVar2 = 0;
            puVar6 = auStack_38;
        } else if (uVar2 < 0x1000) {
            uVar2 = fcn.180459890();
        } else {
            if (uVar2 + 0x27 <= uVar2) goto code_r0x0001800bfe4c;
            iVar8 = fcn.180459890(uVar2 + 0x27);
            if (iVar8 == 0) {
                pcVar1 = (code *)swi(0x29);
                iVar8 = (*pcVar1)(5);
                puVar5 = auStack_30;
            }
            uVar2 = iVar8 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar2 - 8) = iVar8;
            puVar6 = puVar5;
        }
        iVar8 = arg2 - uVar7;
        if (iVar8 != 0) {
            *(undefined8 *)(puVar6 + -8) = 0x1800bfdd8;
            fcn.1804986e0(uVar7 * 0x10 + uVar2, uVar3 & 0xffffffffffffff00, iVar8 * 0x10);
            do {
                iVar8 = iVar8 + -1;
            } while (iVar8 != 0);
        }
        iVar8 = *(int64_t *)arg1;
        iVar4 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar6 + -8) = 0x1800bfdf0;
        fcn.180498030(uVar2, iVar8, iVar4 - iVar8);
        *(undefined8 *)(puVar6 + -8) = 0x1800bfe01;
        fcn.1800c23d0(arg1, uVar2, arg2, uVar9);
    }
    return;
}

// ============================================================
// Function: FUN_1800bfe4c
// Address: 0x1800bfe4c
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800bfcc0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    undefined *puVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_40h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = auStack_38;
    puVar6 = auStack_38;
    iVar8 = *(int64_t *)(arg1 + 8);
    iVar4 = *(int64_t *)arg1;
    uVar7 = iVar8 - iVar4 >> 4;
    if ((uint64_t)arg2 < uVar7) {
        *(int64_t *)(arg1 + 8) = arg2 * 0x10 + iVar4;
        return;
    }
    if (uVar7 < (uint64_t)arg2) {
        uVar2 = *(int64_t *)(arg1 + 0x10) - iVar4 >> 4;
        if ((uint64_t)arg2 <= uVar2) {
            iVar4 = arg2 - uVar7;
            if (iVar4 != 0) {
                fcn.1804986e0(iVar8, arg2 & 0xffffffffffffff00, iVar4 * 0x10);
                do {
                    iVar8 = iVar8 + 0x10;
                    iVar4 = iVar4 + -1;
                } while (iVar4 != 0);
            }
            *(int64_t *)(arg1 + 8) = iVar8;
            return;
        }
        if (0xfffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar3 = uVar2 >> 1;
        if ((0xfffffffffffffff - uVar3 < uVar2) ||
           ((uVar2 = uVar2 + uVar3, uVar9 = arg2, (uint64_t)arg2 <= uVar2 && (uVar9 = uVar2, 0xfffffffffffffff < uVar2))
           )) {
code_r0x0001800bfe4c:
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar2 = uVar9 * 0x10;
        if (uVar2 == 0) {
            uVar2 = 0;
            puVar6 = auStack_38;
        } else if (uVar2 < 0x1000) {
            uVar2 = fcn.180459890();
        } else {
            if (uVar2 + 0x27 <= uVar2) goto code_r0x0001800bfe4c;
            iVar8 = fcn.180459890(uVar2 + 0x27);
            if (iVar8 == 0) {
                pcVar1 = (code *)swi(0x29);
                iVar8 = (*pcVar1)(5);
                puVar5 = auStack_30;
            }
            uVar2 = iVar8 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar2 - 8) = iVar8;
            puVar6 = puVar5;
        }
        iVar8 = arg2 - uVar7;
        if (iVar8 != 0) {
            *(undefined8 *)(puVar6 + -8) = 0x1800bfdd8;
            fcn.1804986e0(uVar7 * 0x10 + uVar2, uVar3 & 0xffffffffffffff00, iVar8 * 0x10);
            do {
                iVar8 = iVar8 + -1;
            } while (iVar8 != 0);
        }
        iVar8 = *(int64_t *)arg1;
        iVar4 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar6 + -8) = 0x1800bfdf0;
        fcn.180498030(uVar2, iVar8, iVar4 - iVar8);
        *(undefined8 *)(puVar6 + -8) = 0x1800bfe01;
        fcn.1800c23d0(arg1, uVar2, arg2, uVar9);
    }
    return;
}

// ============================================================
// Function: FUN_1800bfe52
// Address: 0x1800bfe52
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800bfcc0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    undefined *puVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_40h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = auStack_38;
    puVar6 = auStack_38;
    iVar8 = *(int64_t *)(arg1 + 8);
    iVar4 = *(int64_t *)arg1;
    uVar7 = iVar8 - iVar4 >> 4;
    if ((uint64_t)arg2 < uVar7) {
        *(int64_t *)(arg1 + 8) = arg2 * 0x10 + iVar4;
        return;
    }
    if (uVar7 < (uint64_t)arg2) {
        uVar2 = *(int64_t *)(arg1 + 0x10) - iVar4 >> 4;
        if ((uint64_t)arg2 <= uVar2) {
            iVar4 = arg2 - uVar7;
            if (iVar4 != 0) {
                fcn.1804986e0(iVar8, arg2 & 0xffffffffffffff00, iVar4 * 0x10);
                do {
                    iVar8 = iVar8 + 0x10;
                    iVar4 = iVar4 + -1;
                } while (iVar4 != 0);
            }
            *(int64_t *)(arg1 + 8) = iVar8;
            return;
        }
        if (0xfffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar3 = uVar2 >> 1;
        if ((0xfffffffffffffff - uVar3 < uVar2) ||
           ((uVar2 = uVar2 + uVar3, uVar9 = arg2, (uint64_t)arg2 <= uVar2 && (uVar9 = uVar2, 0xfffffffffffffff < uVar2))
           )) {
code_r0x0001800bfe4c:
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar2 = uVar9 * 0x10;
        if (uVar2 == 0) {
            uVar2 = 0;
            puVar6 = auStack_38;
        } else if (uVar2 < 0x1000) {
            uVar2 = fcn.180459890();
        } else {
            if (uVar2 + 0x27 <= uVar2) goto code_r0x0001800bfe4c;
            iVar8 = fcn.180459890(uVar2 + 0x27);
            if (iVar8 == 0) {
                pcVar1 = (code *)swi(0x29);
                iVar8 = (*pcVar1)(5);
                puVar5 = auStack_30;
            }
            uVar2 = iVar8 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar2 - 8) = iVar8;
            puVar6 = puVar5;
        }
        iVar8 = arg2 - uVar7;
        if (iVar8 != 0) {
            *(undefined8 *)(puVar6 + -8) = 0x1800bfdd8;
            fcn.1804986e0(uVar7 * 0x10 + uVar2, uVar3 & 0xffffffffffffff00, iVar8 * 0x10);
            do {
                iVar8 = iVar8 + -1;
            } while (iVar8 != 0);
        }
        iVar8 = *(int64_t *)arg1;
        iVar4 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar6 + -8) = 0x1800bfdf0;
        fcn.180498030(uVar2, iVar8, iVar4 - iVar8);
        *(undefined8 *)(puVar6 + -8) = 0x1800bfe01;
        fcn.1800c23d0(arg1, uVar2, arg2, uVar9);
    }
    return;
}

// ============================================================
// Function: FUN_1800bfe60
// Address: 0x1800bfe60
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800bfe60(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    undefined *puVar10;
    undefined *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar10 = auStack_38;
    puVar11 = auStack_38;
    puVar9 = *(undefined4 **)(arg1 + 8);
    if (puVar9 != *(undefined4 **)(arg1 + 0x10)) {
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        *puVar9 = *(undefined4 *)arg2;
        puVar9[1] = uVar4;
        puVar9[2] = uVar5;
        puVar9[3] = uVar6;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x10;
        return;
    }
    iVar14 = (int64_t)puVar9 - *(int64_t *)arg1 >> 4;
    if (iVar14 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar7 = (int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 4;
    if (uVar7 <= 0xfffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar14 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x1000000000000000) {
            uVar7 = uVar13 * 0x10;
            if (uVar7 == 0) {
                uVar7 = 0;
                puVar11 = auStack_38;
            } else if (uVar7 < 0x1000) {
                uVar7 = fcn.180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800bffc3;
                iVar16 = fcn.180459890(uVar7 + 0x27);
                if (iVar16 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar16 = (*pcVar3)(5);
                    puVar10 = auStack_30;
                }
                uVar7 = iVar16 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar7 - 8) = iVar16;
                puVar11 = puVar10;
            }
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            puVar2 = (undefined4 *)(iVar14 * 0x10 + uVar7);
            *puVar2 = *(undefined4 *)arg2;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
            puVar2 = *(undefined4 **)arg1;
            if (puVar9 == *(undefined4 **)(arg1 + 8)) {
                iVar16 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar2;
                uVar8 = uVar7;
                puVar9 = puVar2;
            } else {
                *(undefined8 *)(puVar11 + -8) = 0x1800bff79;
                fcn.180498030(uVar7, puVar2, (int64_t)puVar9 - (int64_t)puVar2);
                iVar16 = *(int64_t *)(arg1 + 8) - (int64_t)puVar9;
                uVar8 = iVar14 * 0x10 + 0x10 + uVar7;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800bff8f;
            fcn.180498030(uVar8, puVar9, iVar16);
            uVar15 = *(undefined8 *)(puVar11 + 0x30);
            *(undefined8 *)(puVar11 + 0x30) = *(undefined8 *)(puVar11 + 0x40);
            *(undefined8 *)(puVar11 + 0x28) = *(undefined8 *)(puVar11 + 0x48);
            *(undefined8 *)(puVar11 + 0x20) = *(undefined8 *)(puVar11 + 0x50);
            *(undefined8 *)(puVar11 + 0x18) = uVar15;
            iVar14 = *(int64_t *)arg1;
            if (iVar14 != 0) {
                iVar16 = iVar14;
                puVar12 = puVar11 + -0x10;
                if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar14 & 0xfffffffffffffff0U)) &&
                   (iVar16 = *(int64_t *)(iVar14 + -8), puVar12 = puVar11 + -0x10, 0x1f < (iVar14 - iVar16) - 8U)) {
                    pcVar3 = (code *)swi(0x29);
                    iVar16 = (*pcVar3)(5);
                    puVar12 = puVar11 + -8;
                }
                *(undefined8 *)(puVar12 + -8) = 0x1800c2427;
                fcn.180459c3c(iVar16);
            }
            *(uint64_t *)arg1 = uVar7;
            *(uint64_t *)(arg1 + 8) = uVar1 * 0x10 + uVar7;
            *(uint64_t *)(arg1 + 0x10) = uVar13 * 0x10 + uVar7;
            return;
        }
    }
code_r0x0001800bffc3:
    fcn.180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800bfea0
// Address: 0x1800bfea0
// Size: 285 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800bfe60(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    undefined *puVar10;
    undefined *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar10 = auStack_38;
    puVar11 = auStack_38;
    puVar9 = *(undefined4 **)(arg1 + 8);
    if (puVar9 != *(undefined4 **)(arg1 + 0x10)) {
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        *puVar9 = *(undefined4 *)arg2;
        puVar9[1] = uVar4;
        puVar9[2] = uVar5;
        puVar9[3] = uVar6;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x10;
        return;
    }
    iVar14 = (int64_t)puVar9 - *(int64_t *)arg1 >> 4;
    if (iVar14 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar7 = (int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 4;
    if (uVar7 <= 0xfffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar14 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x1000000000000000) {
            uVar7 = uVar13 * 0x10;
            if (uVar7 == 0) {
                uVar7 = 0;
                puVar11 = auStack_38;
            } else if (uVar7 < 0x1000) {
                uVar7 = fcn.180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800bffc3;
                iVar16 = fcn.180459890(uVar7 + 0x27);
                if (iVar16 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar16 = (*pcVar3)(5);
                    puVar10 = auStack_30;
                }
                uVar7 = iVar16 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar7 - 8) = iVar16;
                puVar11 = puVar10;
            }
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            puVar2 = (undefined4 *)(iVar14 * 0x10 + uVar7);
            *puVar2 = *(undefined4 *)arg2;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
            puVar2 = *(undefined4 **)arg1;
            if (puVar9 == *(undefined4 **)(arg1 + 8)) {
                iVar16 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar2;
                uVar8 = uVar7;
                puVar9 = puVar2;
            } else {
                *(undefined8 *)(puVar11 + -8) = 0x1800bff79;
                fcn.180498030(uVar7, puVar2, (int64_t)puVar9 - (int64_t)puVar2);
                iVar16 = *(int64_t *)(arg1 + 8) - (int64_t)puVar9;
                uVar8 = iVar14 * 0x10 + 0x10 + uVar7;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800bff8f;
            fcn.180498030(uVar8, puVar9, iVar16);
            uVar15 = *(undefined8 *)(puVar11 + 0x30);
            *(undefined8 *)(puVar11 + 0x30) = *(undefined8 *)(puVar11 + 0x40);
            *(undefined8 *)(puVar11 + 0x28) = *(undefined8 *)(puVar11 + 0x48);
            *(undefined8 *)(puVar11 + 0x20) = *(undefined8 *)(puVar11 + 0x50);
            *(undefined8 *)(puVar11 + 0x18) = uVar15;
            iVar14 = *(int64_t *)arg1;
            if (iVar14 != 0) {
                iVar16 = iVar14;
                puVar12 = puVar11 + -0x10;
                if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar14 & 0xfffffffffffffff0U)) &&
                   (iVar16 = *(int64_t *)(iVar14 + -8), puVar12 = puVar11 + -0x10, 0x1f < (iVar14 - iVar16) - 8U)) {
                    pcVar3 = (code *)swi(0x29);
                    iVar16 = (*pcVar3)(5);
                    puVar12 = puVar11 + -8;
                }
                *(undefined8 *)(puVar12 + -8) = 0x1800c2427;
                fcn.180459c3c(iVar16);
            }
            *(uint64_t *)arg1 = uVar7;
            *(uint64_t *)(arg1 + 8) = uVar1 * 0x10 + uVar7;
            *(uint64_t *)(arg1 + 0x10) = uVar13 * 0x10 + uVar7;
            return;
        }
    }
code_r0x0001800bffc3:
    fcn.180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800bffbd
// Address: 0x1800bffbd
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800bfe60(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    undefined *puVar10;
    undefined *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar10 = auStack_38;
    puVar11 = auStack_38;
    puVar9 = *(undefined4 **)(arg1 + 8);
    if (puVar9 != *(undefined4 **)(arg1 + 0x10)) {
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        *puVar9 = *(undefined4 *)arg2;
        puVar9[1] = uVar4;
        puVar9[2] = uVar5;
        puVar9[3] = uVar6;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x10;
        return;
    }
    iVar14 = (int64_t)puVar9 - *(int64_t *)arg1 >> 4;
    if (iVar14 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar7 = (int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 4;
    if (uVar7 <= 0xfffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar14 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x1000000000000000) {
            uVar7 = uVar13 * 0x10;
            if (uVar7 == 0) {
                uVar7 = 0;
                puVar11 = auStack_38;
            } else if (uVar7 < 0x1000) {
                uVar7 = fcn.180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800bffc3;
                iVar16 = fcn.180459890(uVar7 + 0x27);
                if (iVar16 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar16 = (*pcVar3)(5);
                    puVar10 = auStack_30;
                }
                uVar7 = iVar16 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar7 - 8) = iVar16;
                puVar11 = puVar10;
            }
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            puVar2 = (undefined4 *)(iVar14 * 0x10 + uVar7);
            *puVar2 = *(undefined4 *)arg2;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
            puVar2 = *(undefined4 **)arg1;
            if (puVar9 == *(undefined4 **)(arg1 + 8)) {
                iVar16 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar2;
                uVar8 = uVar7;
                puVar9 = puVar2;
            } else {
                *(undefined8 *)(puVar11 + -8) = 0x1800bff79;
                fcn.180498030(uVar7, puVar2, (int64_t)puVar9 - (int64_t)puVar2);
                iVar16 = *(int64_t *)(arg1 + 8) - (int64_t)puVar9;
                uVar8 = iVar14 * 0x10 + 0x10 + uVar7;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800bff8f;
            fcn.180498030(uVar8, puVar9, iVar16);
            uVar15 = *(undefined8 *)(puVar11 + 0x30);
            *(undefined8 *)(puVar11 + 0x30) = *(undefined8 *)(puVar11 + 0x40);
            *(undefined8 *)(puVar11 + 0x28) = *(undefined8 *)(puVar11 + 0x48);
            *(undefined8 *)(puVar11 + 0x20) = *(undefined8 *)(puVar11 + 0x50);
            *(undefined8 *)(puVar11 + 0x18) = uVar15;
            iVar14 = *(int64_t *)arg1;
            if (iVar14 != 0) {
                iVar16 = iVar14;
                puVar12 = puVar11 + -0x10;
                if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar14 & 0xfffffffffffffff0U)) &&
                   (iVar16 = *(int64_t *)(iVar14 + -8), puVar12 = puVar11 + -0x10, 0x1f < (iVar14 - iVar16) - 8U)) {
                    pcVar3 = (code *)swi(0x29);
                    iVar16 = (*pcVar3)(5);
                    puVar12 = puVar11 + -8;
                }
                *(undefined8 *)(puVar12 + -8) = 0x1800c2427;
                fcn.180459c3c(iVar16);
            }
            *(uint64_t *)arg1 = uVar7;
            *(uint64_t *)(arg1 + 8) = uVar1 * 0x10 + uVar7;
            *(uint64_t *)(arg1 + 0x10) = uVar13 * 0x10 + uVar7;
            return;
        }
    }
code_r0x0001800bffc3:
    fcn.180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800bffc3
// Address: 0x1800bffc3
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800bfe60(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    undefined *puVar10;
    undefined *puVar11;
    undefined *puVar12;
    uint64_t uVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_50 [3];
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar10 = auStack_38;
    puVar11 = auStack_38;
    puVar9 = *(undefined4 **)(arg1 + 8);
    if (puVar9 != *(undefined4 **)(arg1 + 0x10)) {
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        *puVar9 = *(undefined4 *)arg2;
        puVar9[1] = uVar4;
        puVar9[2] = uVar5;
        puVar9[3] = uVar6;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x10;
        return;
    }
    iVar14 = (int64_t)puVar9 - *(int64_t *)arg1 >> 4;
    if (iVar14 == 0xfffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar7 = (int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 4;
    if (uVar7 <= 0xfffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar14 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x1000000000000000) {
            uVar7 = uVar13 * 0x10;
            if (uVar7 == 0) {
                uVar7 = 0;
                puVar11 = auStack_38;
            } else if (uVar7 < 0x1000) {
                uVar7 = fcn.180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800bffc3;
                iVar16 = fcn.180459890(uVar7 + 0x27);
                if (iVar16 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar16 = (*pcVar3)(5);
                    puVar10 = auStack_30;
                }
                uVar7 = iVar16 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar7 - 8) = iVar16;
                puVar11 = puVar10;
            }
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            puVar2 = (undefined4 *)(iVar14 * 0x10 + uVar7);
            *puVar2 = *(undefined4 *)arg2;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
            puVar2 = *(undefined4 **)arg1;
            if (puVar9 == *(undefined4 **)(arg1 + 8)) {
                iVar16 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar2;
                uVar8 = uVar7;
                puVar9 = puVar2;
            } else {
                *(undefined8 *)(puVar11 + -8) = 0x1800bff79;
                fcn.180498030(uVar7, puVar2, (int64_t)puVar9 - (int64_t)puVar2);
                iVar16 = *(int64_t *)(arg1 + 8) - (int64_t)puVar9;
                uVar8 = iVar14 * 0x10 + 0x10 + uVar7;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800bff8f;
            fcn.180498030(uVar8, puVar9, iVar16);
            uVar15 = *(undefined8 *)(puVar11 + 0x30);
            *(undefined8 *)(puVar11 + 0x30) = *(undefined8 *)(puVar11 + 0x40);
            *(undefined8 *)(puVar11 + 0x28) = *(undefined8 *)(puVar11 + 0x48);
            *(undefined8 *)(puVar11 + 0x20) = *(undefined8 *)(puVar11 + 0x50);
            *(undefined8 *)(puVar11 + 0x18) = uVar15;
            iVar14 = *(int64_t *)arg1;
            if (iVar14 != 0) {
                iVar16 = iVar14;
                puVar12 = puVar11 + -0x10;
                if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar14 & 0xfffffffffffffff0U)) &&
                   (iVar16 = *(int64_t *)(iVar14 + -8), puVar12 = puVar11 + -0x10, 0x1f < (iVar14 - iVar16) - 8U)) {
                    pcVar3 = (code *)swi(0x29);
                    iVar16 = (*pcVar3)(5);
                    puVar12 = puVar11 + -8;
                }
                *(undefined8 *)(puVar12 + -8) = 0x1800c2427;
                fcn.180459c3c(iVar16);
            }
            *(uint64_t *)arg1 = uVar7;
            *(uint64_t *)(arg1 + 8) = uVar1 * 0x10 + uVar7;
            *(uint64_t *)(arg1 + 0x10) = uVar13 * 0x10 + uVar7;
            return;
        }
    }
code_r0x0001800bffc3:
    fcn.180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800bffd0
// Address: 0x1800bffd0
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800bffd0(int64_t arg1, int64_t arg_38h, int64_t arg_48h)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)arg1;
    if (iVar1 != 0) {
        uVar3 = 0;
        uVar2 = *(uint64_t *)(arg1 + 8);
        if (uVar2 != 0) {
            do {
                fcn.180004e40(iVar1 + 8 + uVar3 * 0x28);
                uVar3 = uVar3 + 1;
            } while (uVar3 < uVar2);
        }
        fcn.1800f4640(*(undefined8 *)arg1);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800bffe1
// Address: 0x1800bffe1
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800bffd0(int64_t arg1, int64_t arg_38h, int64_t arg_48h)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)arg1;
    if (iVar1 != 0) {
        uVar3 = 0;
        uVar2 = *(uint64_t *)(arg1 + 8);
        if (uVar2 != 0) {
            do {
                fcn.180004e40(iVar1 + 8 + uVar3 * 0x28);
                uVar3 = uVar3 + 1;
            } while (uVar3 < uVar2);
        }
        fcn.1800f4640(*(undefined8 *)arg1);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800bfff6
// Address: 0x1800bfff6
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800bffd0(int64_t arg1, int64_t arg_38h, int64_t arg_48h)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)arg1;
    if (iVar1 != 0) {
        uVar3 = 0;
        uVar2 = *(uint64_t *)(arg1 + 8);
        if (uVar2 != 0) {
            do {
                fcn.180004e40(iVar1 + 8 + uVar3 * 0x28);
                uVar3 = uVar3 + 1;
            } while (uVar3 < uVar2);
        }
        fcn.1800f4640(*(undefined8 *)arg1);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c001a
// Address: 0x1800c001a
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800bffd0(int64_t arg1, int64_t arg_38h, int64_t arg_48h)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)arg1;
    if (iVar1 != 0) {
        uVar3 = 0;
        uVar2 = *(uint64_t *)(arg1 + 8);
        if (uVar2 != 0) {
            do {
                fcn.180004e40(iVar1 + 8 + uVar3 * 0x28);
                uVar3 = uVar3 + 1;
            } while (uVar3 < uVar2);
        }
        fcn.1800f4640(*(undefined8 *)arg1);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c003b
// Address: 0x1800c003b
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800bffd0(int64_t arg1, int64_t arg_38h, int64_t arg_48h)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)arg1;
    if (iVar1 != 0) {
        uVar3 = 0;
        uVar2 = *(uint64_t *)(arg1 + 8);
        if (uVar2 != 0) {
            do {
                fcn.180004e40(iVar1 + 8 + uVar3 * 0x28);
                uVar3 = uVar3 + 1;
            } while (uVar3 < uVar2);
        }
        fcn.1800f4640(*(undefined8 *)arg1);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0050
// Address: 0x1800c0050
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c0050(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    uint64_t *puVar11;
    uint64_t *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar6 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar6 * 3) >> 2) || (iVar3 = func_0x0001800ac770(), iVar3 != 0))
    goto code_r0x0001800c0212;
    puVar1 = (uint64_t *)(arg1 + 0x18);
    uVar2 = *puVar1;
    if (iVar6 == 0) {
        uVar10 = 0x10;
        uVar4 = fcn.180459890(0x180);
        uVar5 = 0;
        uVar13 = 0x10;
        uVar14 = uVar4;
code_r0x0001800c0100:
        do {
            uVar7 = uVar5 + 1;
            iVar6 = uVar5 * 0x18;
            *(uint64_t *)(iVar6 + uVar4) = *puVar1;
            *(undefined8 *)(iVar6 + 8 + uVar4) = 0;
            *(undefined8 *)(iVar6 + 0xc + uVar4) = 0;
            *(undefined4 *)(iVar6 + 0x10 + uVar4) = 0;
            *(undefined2 *)(iVar6 + 8 + uVar4) = 0;
            *(undefined *)(iVar6 + 10 + uVar4) = 0;
            uVar5 = uVar7;
        } while (uVar7 < uVar10);
    } else {
        uVar10 = iVar6 * 2;
        if (uVar10 == 0) {
            uVar13 = 0;
            uVar14 = 0;
        } else {
            uVar4 = fcn.180459890(iVar6 * 0x30);
            uVar5 = 0;
            uVar13 = uVar10;
            uVar14 = uVar4;
            if (uVar10 != 0) goto code_r0x0001800c0100;
        }
    }
    puVar9 = (uint64_t *)0x0;
    puVar12 = puVar9;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            iVar6 = (int64_t)puVar12 * 0x18;
            uVar10 = *(uint64_t *)(iVar6 + *(int64_t *)arg1);
            if (uVar10 != *puVar1) {
                uVar5 = (uVar10 >> 5 ^ uVar10) >> 4;
                puVar8 = puVar9;
                do {
                    uVar5 = uVar5 & (uint64_t)(uint64_t *)(uVar13 - 1);
                    puVar11 = (uint64_t *)(uVar14 + uVar5 * 0x18);
                    uVar4 = *(uint64_t *)(uVar14 + uVar5 * 0x18);
                    if (uVar4 == uVar2) {
                        *puVar11 = uVar10;
                        break;
                    }
                    if (uVar4 == uVar10) break;
                    uVar5 = uVar5 + 1 + (int64_t)puVar8;
                    puVar8 = (uint64_t *)((int64_t)puVar8 + 1);
                    puVar11 = puVar9;
                } while (puVar8 <= (uint64_t *)(uVar13 - 1));
                iVar3 = *(int64_t *)arg1;
                *puVar11 = *(uint64_t *)(iVar3 + iVar6);
                puVar11[1] = *(uint64_t *)(iVar3 + 8 + iVar6);
                *(undefined4 *)(puVar11 + 2) = *(undefined4 *)(iVar3 + 0x10 + iVar6);
            }
            puVar12 = (uint64_t *)((int64_t)puVar12 + 1);
        } while (puVar12 < *(uint64_t **)(arg1 + 8));
    }
    iVar6 = *(int64_t *)arg1;
    *(uint64_t *)arg1 = uVar14;
    *(uint64_t *)(arg1 + 8) = uVar13;
    if (iVar6 != 0) {
        fcn.1800f4640();
    }
code_r0x0001800c0212:
    iVar6 = func_0x0001800c14e0(arg1, arg2);
    return iVar6 + 8;
}

// ============================================================
// Function: FUN_1800c0086
// Address: 0x1800c0086
// Size: 391 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c0050(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    uint64_t *puVar11;
    uint64_t *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar6 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar6 * 3) >> 2) || (iVar3 = func_0x0001800ac770(), iVar3 != 0))
    goto code_r0x0001800c0212;
    puVar1 = (uint64_t *)(arg1 + 0x18);
    uVar2 = *puVar1;
    if (iVar6 == 0) {
        uVar10 = 0x10;
        uVar4 = fcn.180459890(0x180);
        uVar5 = 0;
        uVar13 = 0x10;
        uVar14 = uVar4;
code_r0x0001800c0100:
        do {
            uVar7 = uVar5 + 1;
            iVar6 = uVar5 * 0x18;
            *(uint64_t *)(iVar6 + uVar4) = *puVar1;
            *(undefined8 *)(iVar6 + 8 + uVar4) = 0;
            *(undefined8 *)(iVar6 + 0xc + uVar4) = 0;
            *(undefined4 *)(iVar6 + 0x10 + uVar4) = 0;
            *(undefined2 *)(iVar6 + 8 + uVar4) = 0;
            *(undefined *)(iVar6 + 10 + uVar4) = 0;
            uVar5 = uVar7;
        } while (uVar7 < uVar10);
    } else {
        uVar10 = iVar6 * 2;
        if (uVar10 == 0) {
            uVar13 = 0;
            uVar14 = 0;
        } else {
            uVar4 = fcn.180459890(iVar6 * 0x30);
            uVar5 = 0;
            uVar13 = uVar10;
            uVar14 = uVar4;
            if (uVar10 != 0) goto code_r0x0001800c0100;
        }
    }
    puVar9 = (uint64_t *)0x0;
    puVar12 = puVar9;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            iVar6 = (int64_t)puVar12 * 0x18;
            uVar10 = *(uint64_t *)(iVar6 + *(int64_t *)arg1);
            if (uVar10 != *puVar1) {
                uVar5 = (uVar10 >> 5 ^ uVar10) >> 4;
                puVar8 = puVar9;
                do {
                    uVar5 = uVar5 & (uint64_t)(uint64_t *)(uVar13 - 1);
                    puVar11 = (uint64_t *)(uVar14 + uVar5 * 0x18);
                    uVar4 = *(uint64_t *)(uVar14 + uVar5 * 0x18);
                    if (uVar4 == uVar2) {
                        *puVar11 = uVar10;
                        break;
                    }
                    if (uVar4 == uVar10) break;
                    uVar5 = uVar5 + 1 + (int64_t)puVar8;
                    puVar8 = (uint64_t *)((int64_t)puVar8 + 1);
                    puVar11 = puVar9;
                } while (puVar8 <= (uint64_t *)(uVar13 - 1));
                iVar3 = *(int64_t *)arg1;
                *puVar11 = *(uint64_t *)(iVar3 + iVar6);
                puVar11[1] = *(uint64_t *)(iVar3 + 8 + iVar6);
                *(undefined4 *)(puVar11 + 2) = *(undefined4 *)(iVar3 + 0x10 + iVar6);
            }
            puVar12 = (uint64_t *)((int64_t)puVar12 + 1);
        } while (puVar12 < *(uint64_t **)(arg1 + 8));
    }
    iVar6 = *(int64_t *)arg1;
    *(uint64_t *)arg1 = uVar14;
    *(uint64_t *)(arg1 + 8) = uVar13;
    if (iVar6 != 0) {
        fcn.1800f4640();
    }
code_r0x0001800c0212:
    iVar6 = func_0x0001800c14e0(arg1, arg2);
    return iVar6 + 8;
}

// ============================================================
// Function: FUN_1800c020d
// Address: 0x1800c020d
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c0050(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    uint64_t *puVar11;
    uint64_t *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar6 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar6 * 3) >> 2) || (iVar3 = func_0x0001800ac770(), iVar3 != 0))
    goto code_r0x0001800c0212;
    puVar1 = (uint64_t *)(arg1 + 0x18);
    uVar2 = *puVar1;
    if (iVar6 == 0) {
        uVar10 = 0x10;
        uVar4 = fcn.180459890(0x180);
        uVar5 = 0;
        uVar13 = 0x10;
        uVar14 = uVar4;
code_r0x0001800c0100:
        do {
            uVar7 = uVar5 + 1;
            iVar6 = uVar5 * 0x18;
            *(uint64_t *)(iVar6 + uVar4) = *puVar1;
            *(undefined8 *)(iVar6 + 8 + uVar4) = 0;
            *(undefined8 *)(iVar6 + 0xc + uVar4) = 0;
            *(undefined4 *)(iVar6 + 0x10 + uVar4) = 0;
            *(undefined2 *)(iVar6 + 8 + uVar4) = 0;
            *(undefined *)(iVar6 + 10 + uVar4) = 0;
            uVar5 = uVar7;
        } while (uVar7 < uVar10);
    } else {
        uVar10 = iVar6 * 2;
        if (uVar10 == 0) {
            uVar13 = 0;
            uVar14 = 0;
        } else {
            uVar4 = fcn.180459890(iVar6 * 0x30);
            uVar5 = 0;
            uVar13 = uVar10;
            uVar14 = uVar4;
            if (uVar10 != 0) goto code_r0x0001800c0100;
        }
    }
    puVar9 = (uint64_t *)0x0;
    puVar12 = puVar9;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            iVar6 = (int64_t)puVar12 * 0x18;
            uVar10 = *(uint64_t *)(iVar6 + *(int64_t *)arg1);
            if (uVar10 != *puVar1) {
                uVar5 = (uVar10 >> 5 ^ uVar10) >> 4;
                puVar8 = puVar9;
                do {
                    uVar5 = uVar5 & (uint64_t)(uint64_t *)(uVar13 - 1);
                    puVar11 = (uint64_t *)(uVar14 + uVar5 * 0x18);
                    uVar4 = *(uint64_t *)(uVar14 + uVar5 * 0x18);
                    if (uVar4 == uVar2) {
                        *puVar11 = uVar10;
                        break;
                    }
                    if (uVar4 == uVar10) break;
                    uVar5 = uVar5 + 1 + (int64_t)puVar8;
                    puVar8 = (uint64_t *)((int64_t)puVar8 + 1);
                    puVar11 = puVar9;
                } while (puVar8 <= (uint64_t *)(uVar13 - 1));
                iVar3 = *(int64_t *)arg1;
                *puVar11 = *(uint64_t *)(iVar3 + iVar6);
                puVar11[1] = *(uint64_t *)(iVar3 + 8 + iVar6);
                *(undefined4 *)(puVar11 + 2) = *(undefined4 *)(iVar3 + 0x10 + iVar6);
            }
            puVar12 = (uint64_t *)((int64_t)puVar12 + 1);
        } while (puVar12 < *(uint64_t **)(arg1 + 8));
    }
    iVar6 = *(int64_t *)arg1;
    *(uint64_t *)arg1 = uVar14;
    *(uint64_t *)(arg1 + 8) = uVar13;
    if (iVar6 != 0) {
        fcn.1800f4640();
    }
code_r0x0001800c0212:
    iVar6 = func_0x0001800c14e0(arg1, arg2);
    return iVar6 + 8;
}

// ============================================================
// Function: FUN_1800c0230
// Address: 0x1800c0230
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800be270(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t unaff_RBX;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg1 + 0x6e8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x6e8) = 0;
        *(undefined8 *)(arg1 + 0x6f0) = 0;
    }
    func_0x00018000ace0(arg1 + 0x6d0);
    func_0x00018000ace0(arg1 + 0x6b8);
    fcn.1800bfa00(arg1 + 0x6a0, unaff_RBX);
    func_0x000180028940(arg1 + 0x688);
    func_0x00018002a260(arg1 + 0x670);
    func_0x00018000ace0(arg1 + 0x658);
    func_0x00018000ace0(arg1 + 0x640);
    func_0x0001800c07c0(arg1 + 0x2d0);
    func_0x0001800c07c0(arg1 + 0x2b8);
    if (*(int64_t *)(arg1 + 0x290) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x290) = 0;
        *(undefined8 *)(arg1 + 0x298) = 0;
    }
    if (*(int64_t *)(arg1 + 0x268) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x268) = 0;
        *(undefined8 *)(arg1 + 0x270) = 0;
    }
    if (*(int64_t *)(arg1 + 0x240) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x240) = 0;
        *(undefined8 *)(arg1 + 0x248) = 0;
    }
    if (*(int64_t *)(arg1 + 0x218) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x218) = 0;
        *(undefined8 *)(arg1 + 0x220) = 0;
    }
    fcn.1800bffd0(arg1 + 0x1f0, unaff_RBX, var_18h);
    if (*(int64_t *)(arg1 + 0x1c8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x1c8) = 0;
        *(undefined8 *)(arg1 + 0x1d0) = 0;
    }
    if (*(int64_t *)(arg1 + 0x1a0) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x1a0) = 0;
        *(undefined8 *)(arg1 + 0x1a8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x178) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x178) = 0;
        *(undefined8 *)(arg1 + 0x180) = 0;
    }
    if (*(int64_t *)(arg1 + 0x150) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x150) = 0;
        *(undefined8 *)(arg1 + 0x158) = 0;
    }
    if (*(int64_t *)(arg1 + 0x128) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x128) = 0;
        *(undefined8 *)(arg1 + 0x130) = 0;
    }
    if (*(int64_t *)(arg1 + 0x100) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x100) = 0;
        *(undefined8 *)(arg1 + 0x108) = 0;
    }
    if (*(int64_t *)(arg1 + 0xd8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0xd8) = 0;
        *(undefined8 *)(arg1 + 0xe0) = 0;
    }
    if (*(int64_t *)(arg1 + 0xb0) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xb8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x88) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x88) = 0;
        *(undefined8 *)(arg1 + 0x90) = 0;
    }
    piVar1 = (int64_t *)(arg1 + 0x60);
    iVar2 = *piVar1;
    if (iVar2 != 0) {
        uVar4 = 0;
        uVar3 = *(uint64_t *)(arg1 + 0x68);
        if (uVar3 != 0) {
            do {
                func_0x00018000ace0(uVar4 * 0x38 + iVar2 + 0x10);
                uVar4 = uVar4 + 1;
            } while (uVar4 < uVar3);
        }
        fcn.1800f4640(*piVar1);
        *piVar1 = 0;
        *(undefined8 *)(arg1 + 0x68) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0241
// Address: 0x1800c0241
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800be270(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t unaff_RBX;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg1 + 0x6e8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x6e8) = 0;
        *(undefined8 *)(arg1 + 0x6f0) = 0;
    }
    func_0x00018000ace0(arg1 + 0x6d0);
    func_0x00018000ace0(arg1 + 0x6b8);
    fcn.1800bfa00(arg1 + 0x6a0, unaff_RBX);
    func_0x000180028940(arg1 + 0x688);
    func_0x00018002a260(arg1 + 0x670);
    func_0x00018000ace0(arg1 + 0x658);
    func_0x00018000ace0(arg1 + 0x640);
    func_0x0001800c07c0(arg1 + 0x2d0);
    func_0x0001800c07c0(arg1 + 0x2b8);
    if (*(int64_t *)(arg1 + 0x290) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x290) = 0;
        *(undefined8 *)(arg1 + 0x298) = 0;
    }
    if (*(int64_t *)(arg1 + 0x268) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x268) = 0;
        *(undefined8 *)(arg1 + 0x270) = 0;
    }
    if (*(int64_t *)(arg1 + 0x240) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x240) = 0;
        *(undefined8 *)(arg1 + 0x248) = 0;
    }
    if (*(int64_t *)(arg1 + 0x218) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x218) = 0;
        *(undefined8 *)(arg1 + 0x220) = 0;
    }
    fcn.1800bffd0(arg1 + 0x1f0, unaff_RBX, var_18h);
    if (*(int64_t *)(arg1 + 0x1c8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x1c8) = 0;
        *(undefined8 *)(arg1 + 0x1d0) = 0;
    }
    if (*(int64_t *)(arg1 + 0x1a0) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x1a0) = 0;
        *(undefined8 *)(arg1 + 0x1a8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x178) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x178) = 0;
        *(undefined8 *)(arg1 + 0x180) = 0;
    }
    if (*(int64_t *)(arg1 + 0x150) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x150) = 0;
        *(undefined8 *)(arg1 + 0x158) = 0;
    }
    if (*(int64_t *)(arg1 + 0x128) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x128) = 0;
        *(undefined8 *)(arg1 + 0x130) = 0;
    }
    if (*(int64_t *)(arg1 + 0x100) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x100) = 0;
        *(undefined8 *)(arg1 + 0x108) = 0;
    }
    if (*(int64_t *)(arg1 + 0xd8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0xd8) = 0;
        *(undefined8 *)(arg1 + 0xe0) = 0;
    }
    if (*(int64_t *)(arg1 + 0xb0) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xb8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x88) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x88) = 0;
        *(undefined8 *)(arg1 + 0x90) = 0;
    }
    piVar1 = (int64_t *)(arg1 + 0x60);
    iVar2 = *piVar1;
    if (iVar2 != 0) {
        uVar4 = 0;
        uVar3 = *(uint64_t *)(arg1 + 0x68);
        if (uVar3 != 0) {
            do {
                func_0x00018000ace0(uVar4 * 0x38 + iVar2 + 0x10);
                uVar4 = uVar4 + 1;
            } while (uVar4 < uVar3);
        }
        fcn.1800f4640(*piVar1);
        *piVar1 = 0;
        *(undefined8 *)(arg1 + 0x68) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0256
// Address: 0x1800c0256
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800be270(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t unaff_RBX;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg1 + 0x6e8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x6e8) = 0;
        *(undefined8 *)(arg1 + 0x6f0) = 0;
    }
    func_0x00018000ace0(arg1 + 0x6d0);
    func_0x00018000ace0(arg1 + 0x6b8);
    fcn.1800bfa00(arg1 + 0x6a0, unaff_RBX);
    func_0x000180028940(arg1 + 0x688);
    func_0x00018002a260(arg1 + 0x670);
    func_0x00018000ace0(arg1 + 0x658);
    func_0x00018000ace0(arg1 + 0x640);
    func_0x0001800c07c0(arg1 + 0x2d0);
    func_0x0001800c07c0(arg1 + 0x2b8);
    if (*(int64_t *)(arg1 + 0x290) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x290) = 0;
        *(undefined8 *)(arg1 + 0x298) = 0;
    }
    if (*(int64_t *)(arg1 + 0x268) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x268) = 0;
        *(undefined8 *)(arg1 + 0x270) = 0;
    }
    if (*(int64_t *)(arg1 + 0x240) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x240) = 0;
        *(undefined8 *)(arg1 + 0x248) = 0;
    }
    if (*(int64_t *)(arg1 + 0x218) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x218) = 0;
        *(undefined8 *)(arg1 + 0x220) = 0;
    }
    fcn.1800bffd0(arg1 + 0x1f0, unaff_RBX, var_18h);
    if (*(int64_t *)(arg1 + 0x1c8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x1c8) = 0;
        *(undefined8 *)(arg1 + 0x1d0) = 0;
    }
    if (*(int64_t *)(arg1 + 0x1a0) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x1a0) = 0;
        *(undefined8 *)(arg1 + 0x1a8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x178) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x178) = 0;
        *(undefined8 *)(arg1 + 0x180) = 0;
    }
    if (*(int64_t *)(arg1 + 0x150) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x150) = 0;
        *(undefined8 *)(arg1 + 0x158) = 0;
    }
    if (*(int64_t *)(arg1 + 0x128) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x128) = 0;
        *(undefined8 *)(arg1 + 0x130) = 0;
    }
    if (*(int64_t *)(arg1 + 0x100) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x100) = 0;
        *(undefined8 *)(arg1 + 0x108) = 0;
    }
    if (*(int64_t *)(arg1 + 0xd8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0xd8) = 0;
        *(undefined8 *)(arg1 + 0xe0) = 0;
    }
    if (*(int64_t *)(arg1 + 0xb0) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xb8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x88) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x88) = 0;
        *(undefined8 *)(arg1 + 0x90) = 0;
    }
    piVar1 = (int64_t *)(arg1 + 0x60);
    iVar2 = *piVar1;
    if (iVar2 != 0) {
        uVar4 = 0;
        uVar3 = *(uint64_t *)(arg1 + 0x68);
        if (uVar3 != 0) {
            do {
                func_0x00018000ace0(uVar4 * 0x38 + iVar2 + 0x10);
                uVar4 = uVar4 + 1;
            } while (uVar4 < uVar3);
        }
        fcn.1800f4640(*piVar1);
        *piVar1 = 0;
        *(undefined8 *)(arg1 + 0x68) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c0279
// Address: 0x1800c0279
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800be270(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t unaff_RBX;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg1 + 0x6e8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x6e8) = 0;
        *(undefined8 *)(arg1 + 0x6f0) = 0;
    }
    func_0x00018000ace0(arg1 + 0x6d0);
    func_0x00018000ace0(arg1 + 0x6b8);
    fcn.1800bfa00(arg1 + 0x6a0, unaff_RBX);
    func_0x000180028940(arg1 + 0x688);
    func_0x00018002a260(arg1 + 0x670);
    func_0x00018000ace0(arg1 + 0x658);
    func_0x00018000ace0(arg1 + 0x640);
    func_0x0001800c07c0(arg1 + 0x2d0);
    func_0x0001800c07c0(arg1 + 0x2b8);
    if (*(int64_t *)(arg1 + 0x290) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x290) = 0;
        *(undefined8 *)(arg1 + 0x298) = 0;
    }
    if (*(int64_t *)(arg1 + 0x268) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x268) = 0;
        *(undefined8 *)(arg1 + 0x270) = 0;
    }
    if (*(int64_t *)(arg1 + 0x240) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x240) = 0;
        *(undefined8 *)(arg1 + 0x248) = 0;
    }
    if (*(int64_t *)(arg1 + 0x218) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x218) = 0;
        *(undefined8 *)(arg1 + 0x220) = 0;
    }
    fcn.1800bffd0(arg1 + 0x1f0, unaff_RBX, var_18h);
    if (*(int64_t *)(arg1 + 0x1c8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x1c8) = 0;
        *(undefined8 *)(arg1 + 0x1d0) = 0;
    }
    if (*(int64_t *)(arg1 + 0x1a0) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x1a0) = 0;
        *(undefined8 *)(arg1 + 0x1a8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x178) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x178) = 0;
        *(undefined8 *)(arg1 + 0x180) = 0;
    }
    if (*(int64_t *)(arg1 + 0x150) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x150) = 0;
        *(undefined8 *)(arg1 + 0x158) = 0;
    }
    if (*(int64_t *)(arg1 + 0x128) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x128) = 0;
        *(undefined8 *)(arg1 + 0x130) = 0;
    }
    if (*(int64_t *)(arg1 + 0x100) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x100) = 0;
        *(undefined8 *)(arg1 + 0x108) = 0;
    }
    if (*(int64_t *)(arg1 + 0xd8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0xd8) = 0;
        *(undefined8 *)(arg1 + 0xe0) = 0;
    }
    if (*(int64_t *)(arg1 + 0xb0) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xb8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x88) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x88) = 0;
        *(undefined8 *)(arg1 + 0x90) = 0;
    }
    piVar1 = (int64_t *)(arg1 + 0x60);
    iVar2 = *piVar1;
    if (iVar2 != 0) {
        uVar4 = 0;
        uVar3 = *(uint64_t *)(arg1 + 0x68);
        if (uVar3 != 0) {
            do {
                func_0x00018000ace0(uVar4 * 0x38 + iVar2 + 0x10);
                uVar4 = uVar4 + 1;
            } while (uVar4 < uVar3);
        }
        fcn.1800f4640(*piVar1);
        *piVar1 = 0;
        *(undefined8 *)(arg1 + 0x68) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c029a
// Address: 0x1800c029a
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800be270(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t unaff_RBX;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int64_t *)(arg1 + 0x6e8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x6e8) = 0;
        *(undefined8 *)(arg1 + 0x6f0) = 0;
    }
    func_0x00018000ace0(arg1 + 0x6d0);
    func_0x00018000ace0(arg1 + 0x6b8);
    fcn.1800bfa00(arg1 + 0x6a0, unaff_RBX);
    func_0x000180028940(arg1 + 0x688);
    func_0x00018002a260(arg1 + 0x670);
    func_0x00018000ace0(arg1 + 0x658);
    func_0x00018000ace0(arg1 + 0x640);
    func_0x0001800c07c0(arg1 + 0x2d0);
    func_0x0001800c07c0(arg1 + 0x2b8);
    if (*(int64_t *)(arg1 + 0x290) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x290) = 0;
        *(undefined8 *)(arg1 + 0x298) = 0;
    }
    if (*(int64_t *)(arg1 + 0x268) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x268) = 0;
        *(undefined8 *)(arg1 + 0x270) = 0;
    }
    if (*(int64_t *)(arg1 + 0x240) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x240) = 0;
        *(undefined8 *)(arg1 + 0x248) = 0;
    }
    if (*(int64_t *)(arg1 + 0x218) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x218) = 0;
        *(undefined8 *)(arg1 + 0x220) = 0;
    }
    fcn.1800bffd0(arg1 + 0x1f0, unaff_RBX, var_18h);
    if (*(int64_t *)(arg1 + 0x1c8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x1c8) = 0;
        *(undefined8 *)(arg1 + 0x1d0) = 0;
    }
    if (*(int64_t *)(arg1 + 0x1a0) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x1a0) = 0;
        *(undefined8 *)(arg1 + 0x1a8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x178) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x178) = 0;
        *(undefined8 *)(arg1 + 0x180) = 0;
    }
    if (*(int64_t *)(arg1 + 0x150) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x150) = 0;
        *(undefined8 *)(arg1 + 0x158) = 0;
    }
    if (*(int64_t *)(arg1 + 0x128) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x128) = 0;
        *(undefined8 *)(arg1 + 0x130) = 0;
    }
    if (*(int64_t *)(arg1 + 0x100) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x100) = 0;
        *(undefined8 *)(arg1 + 0x108) = 0;
    }
    if (*(int64_t *)(arg1 + 0xd8) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0xd8) = 0;
        *(undefined8 *)(arg1 + 0xe0) = 0;
    }
    if (*(int64_t *)(arg1 + 0xb0) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xb8) = 0;
    }
    if (*(int64_t *)(arg1 + 0x88) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x88) = 0;
        *(undefined8 *)(arg1 + 0x90) = 0;
    }
    piVar1 = (int64_t *)(arg1 + 0x60);
    iVar2 = *piVar1;
    if (iVar2 != 0) {
        uVar4 = 0;
        uVar3 = *(uint64_t *)(arg1 + 0x68);
        if (uVar3 != 0) {
            do {
                func_0x00018000ace0(uVar4 * 0x38 + iVar2 + 0x10);
                uVar4 = uVar4 + 1;
            } while (uVar4 < uVar3);
        }
        fcn.1800f4640(*piVar1);
        *piVar1 = 0;
        *(undefined8 *)(arg1 + 0x68) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c02a0
// Address: 0x1800c02a0
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t * fcn.1800c02a0(int64_t arg1, int64_t arg2, int64_t arg_78h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    if (((uint64_t)(iVar1 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x10)) && (iVar3 = func_0x0001800c1560(), iVar3 == 0)) {
        iVar3 = 0x10;
        if (iVar1 != 0) {
            iVar3 = iVar1 * 2;
        }
        func_0x0001800c1660(&var_48h, arg1 + 0x18, iVar3);
        uVar8 = 0;
        if (*(int64_t *)(arg1 + 8) != 0) {
            do {
                uVar5 = *(uint64_t *)(*(int64_t *)arg1 + uVar8 * 8);
                if (uVar5 != *(uint64_t *)(arg1 + 0x18)) {
                    uVar4 = (uVar5 >> 5 ^ uVar5) >> 4;
                    uVar6 = 0;
                    do {
                        uVar4 = uVar4 & var_40h - 1U;
                        uVar2 = *(uint64_t *)(var_48h + uVar4 * 8);
                        puVar7 = (uint64_t *)(var_48h + uVar4 * 8);
                        if (uVar2 == var_30h) {
                            *puVar7 = uVar5;
                            goto code_r0x0001800c037a;
                        }
                        if (uVar2 == uVar5) goto code_r0x0001800c037a;
                        uVar4 = uVar4 + 1 + uVar6;
                        uVar6 = uVar6 + 1;
                    } while (uVar6 <= var_40h - 1U);
                    puVar7 = (uint64_t *)0x0;
code_r0x0001800c037a:
                    *puVar7 = *(uint64_t *)(*(int64_t *)arg1 + uVar8 * 8);
                }
                uVar8 = uVar8 + 1;
            } while (uVar8 < *(uint64_t *)(arg1 + 8));
        }
        iVar1 = *(int64_t *)arg1;
        *(int64_t *)(arg1 + 8) = var_40h;
        *(int64_t *)arg1 = var_48h;
        if (iVar1 != 0) {
            fcn.1800f4640();
        }
    }
    uVar8 = *(uint64_t *)arg2;
    uVar6 = *(int64_t *)(arg1 + 8) - 1;
    uVar5 = (uVar8 >> 5 ^ uVar8) >> 4;
    uVar4 = 0;
    while( true ) {
        uVar5 = uVar5 & uVar6;
        uVar2 = *(uint64_t *)(*(int64_t *)arg1 + uVar5 * 8);
        puVar7 = (uint64_t *)(*(int64_t *)arg1 + uVar5 * 8);
        if (uVar2 == *(uint64_t *)(arg1 + 0x18)) {
            *puVar7 = uVar8;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar7;
        }
        if (uVar2 == uVar8) break;
        uVar5 = uVar5 + 1 + uVar4;
        uVar4 = uVar4 + 1;
        if (uVar6 < uVar4) {
            return (uint64_t *)0x0;
        }
    }
    return puVar7;
}

// ============================================================
// Function: FUN_1800c02d3
// Address: 0x1800c02d3
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t * fcn.1800c02a0(int64_t arg1, int64_t arg2, int64_t arg_78h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    if (((uint64_t)(iVar1 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x10)) && (iVar3 = func_0x0001800c1560(), iVar3 == 0)) {
        iVar3 = 0x10;
        if (iVar1 != 0) {
            iVar3 = iVar1 * 2;
        }
        func_0x0001800c1660(&var_48h, arg1 + 0x18, iVar3);
        uVar8 = 0;
        if (*(int64_t *)(arg1 + 8) != 0) {
            do {
                uVar5 = *(uint64_t *)(*(int64_t *)arg1 + uVar8 * 8);
                if (uVar5 != *(uint64_t *)(arg1 + 0x18)) {
                    uVar4 = (uVar5 >> 5 ^ uVar5) >> 4;
                    uVar6 = 0;
                    do {
                        uVar4 = uVar4 & var_40h - 1U;
                        uVar2 = *(uint64_t *)(var_48h + uVar4 * 8);
                        puVar7 = (uint64_t *)(var_48h + uVar4 * 8);
                        if (uVar2 == var_30h) {
                            *puVar7 = uVar5;
                            goto code_r0x0001800c037a;
                        }
                        if (uVar2 == uVar5) goto code_r0x0001800c037a;
                        uVar4 = uVar4 + 1 + uVar6;
                        uVar6 = uVar6 + 1;
                    } while (uVar6 <= var_40h - 1U);
                    puVar7 = (uint64_t *)0x0;
code_r0x0001800c037a:
                    *puVar7 = *(uint64_t *)(*(int64_t *)arg1 + uVar8 * 8);
                }
                uVar8 = uVar8 + 1;
            } while (uVar8 < *(uint64_t *)(arg1 + 8));
        }
        iVar1 = *(int64_t *)arg1;
        *(int64_t *)(arg1 + 8) = var_40h;
        *(int64_t *)arg1 = var_48h;
        if (iVar1 != 0) {
            fcn.1800f4640();
        }
    }
    uVar8 = *(uint64_t *)arg2;
    uVar6 = *(int64_t *)(arg1 + 8) - 1;
    uVar5 = (uVar8 >> 5 ^ uVar8) >> 4;
    uVar4 = 0;
    while( true ) {
        uVar5 = uVar5 & uVar6;
        uVar2 = *(uint64_t *)(*(int64_t *)arg1 + uVar5 * 8);
        puVar7 = (uint64_t *)(*(int64_t *)arg1 + uVar5 * 8);
        if (uVar2 == *(uint64_t *)(arg1 + 0x18)) {
            *puVar7 = uVar8;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar7;
        }
        if (uVar2 == uVar8) break;
        uVar5 = uVar5 + 1 + uVar4;
        uVar4 = uVar4 + 1;
        if (uVar6 < uVar4) {
            return (uint64_t *)0x0;
        }
    }
    return puVar7;
}

