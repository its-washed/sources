// Chunk 97 - 50 functions

// ============================================================
// Function: FUN_18014c270
// Address: 0x18014c270
// Size: 216 bytes
// ============================================================
void fcn.18014c270(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_f8h, int64_t arg_170h)
{
    char *pcVar1;
    float *pfVar2;
    float fVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    bool bVar23;
    bool bVar24;
    bool bVar25;
    int64_t iVar26;
    int64_t iVar27;
    int64_t iVar28;
    undefined uVar29;
    char cVar30;
    undefined4 uVar31;
    char *pcVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    undefined4 var_d0h;
    undefined4 uStack_cc;
    undefined4 uStack_c8;
    int64_t var_c4h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    
    iVar27 = arg_28h;
    iVar26 = *(int64_t *)0x180781f28;
    var_18h._0_4_ = (uint32_t)arg3;
    pcVar32 = (char *)arg_28h;
    if (arg_28h != -1) {
        while (*pcVar32 != '\0') {
            pcVar1 = pcVar32 + 1;
            if (((*pcVar32 == '#') && (*pcVar1 == '#')) || (pcVar32 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    func_0x0001800fe0a0(&var_10h, arg_28h, pcVar32, 0, 0xbf800000);
    iVar28 = arg_48h;
    if (arg_48h != 0) {
        *(undefined *)arg_48h = 0;
    }
    if (arg_50h != 0) {
        *(undefined *)arg_50h = 0;
    }
    if (*(float *)(arg2 + 8) - *(float *)arg2 <= 1.0) {
        return;
    }
    fVar33 = (float)arg4;
    var_e0h = *(float *)arg2 + fVar33;
    var_d8h._0_4_ = *(float *)(arg2 + 8) - fVar33;
    var_e8h._4_4_ = (float)((uint64_t)arg4 >> 0x20);
    var_dch = var_e8h._4_4_ + *(float *)(arg2 + 4);
    var_d8h._4_4_ = *(undefined4 *)(arg2 + 0xc);
    if (arg_50h != 0) {
        *(bool *)arg_50h = (float)var_d8h < var_e0h + (float)var_10h;
    }
    fVar35 = *(float *)(arg2 + 8);
    uVar29 = 0;
    fVar3 = *(float *)arg2;
    arg_28h._4_4_ = var_e8h._4_4_ + *(float *)(arg2 + 4);
    fVar36 = *(float *)(iVar26 + 0x12f8);
    bVar24 = false;
    fVar33 = (fVar35 - fVar33) - fVar36;
    arg_28h._0_4_ = fVar3;
    if (fVar3 <= fVar33) {
        arg_28h._0_4_ = fVar33;
    }
    if (((*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_30h) || (*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_38h)) ||
       ((*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_30h || (*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_38h)))) {
        bVar23 = true;
    } else {
        bVar23 = false;
    }
    if ((int32_t)arg_38h != 0) {
        if ((uint8_t)arg_40h == 0) {
            fVar33 = *(float *)(iVar26 + 0xe48);
        } else {
            fVar33 = *(float *)(iVar26 + 0xe44);
        }
        if (fVar33 < 0.0) {
code_r0x00018014c473:
            bVar24 = true;
        } else if (bVar23) {
            fVar34 = fVar36;
            if (fVar36 <= fVar33) {
                fVar34 = fVar33;
            }
            if (fVar34 <= fVar35 - fVar3) goto code_r0x00018014c473;
        }
    }
    if ((((arg3 & 1U) == 0) || (fVar35 < fVar36 + (float)arg_28h)) || ((bVar24 && (bVar23)))) {
        bVar25 = false;
        if (!bVar24) goto code_r0x00018014c5e1;
        uVar31 = *(undefined4 *)(iVar26 + 0x1fb8);
        uVar4 = *(undefined4 *)(iVar26 + 0x1fbc);
        uVar5 = *(undefined4 *)(iVar26 + 0x1fc0);
        uVar6 = *(undefined4 *)(iVar26 + 0x1fc4);
        uVar7 = *(undefined4 *)(iVar26 + 0x1fc8);
        uVar8 = *(undefined4 *)(iVar26 + 0x1fcc);
        uVar9 = *(undefined4 *)(iVar26 + 0x1fd0);
        uVar10 = *(undefined4 *)(iVar26 + 0x1fd4);
        uVar11 = *(undefined4 *)(iVar26 + 0x1fd8);
        uVar12 = *(undefined4 *)(iVar26 + 0x1fdc);
        uVar13 = *(undefined4 *)(iVar26 + 0x1fe0);
        uVar14 = *(undefined4 *)(iVar26 + 0x1fe4);
        uVar15 = *(undefined4 *)(iVar26 + 0x1fe8);
        uVar16 = *(undefined4 *)(iVar26 + 0x1fec);
        uVar17 = *(undefined4 *)(iVar26 + 0x1ff0);
        uVar18 = *(undefined4 *)(iVar26 + 0x1ff4);
        uVar19 = *(undefined4 *)(iVar26 + 0x1ff8);
        uVar20 = *(undefined4 *)(iVar26 + 0x1ffc);
        uVar21 = *(undefined4 *)(iVar26 + 0x2000);
        uVar22 = *(undefined4 *)(iVar26 + 0x2004);
        uVar29 = func_0x00018013ac70(arg_38h & 0xffffffff, &arg_28h);
        *(undefined4 *)(iVar26 + 0x1fb8) = uVar31;
        *(undefined4 *)(iVar26 + 0x1fbc) = uVar4;
        *(undefined4 *)(iVar26 + 0x1fc0) = uVar5;
        *(undefined4 *)(iVar26 + 0x1fc4) = uVar6;
        *(undefined4 *)(iVar26 + 0x1fc8) = uVar7;
        *(undefined4 *)(iVar26 + 0x1fcc) = uVar8;
        *(undefined4 *)(iVar26 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar26 + 0x1fd4) = uVar10;
        *(undefined4 *)(iVar26 + 0x1fd8) = uVar11;
        *(undefined4 *)(iVar26 + 0x1fdc) = uVar12;
        *(undefined4 *)(iVar26 + 0x1fe0) = uVar13;
        *(undefined4 *)(iVar26 + 0x1fe4) = uVar14;
        *(undefined4 *)(iVar26 + 0x1fe8) = uVar15;
        *(undefined4 *)(iVar26 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar26 + 0x1ff0) = uVar17;
        *(undefined4 *)(iVar26 + 0x1ff4) = uVar18;
        *(undefined4 *)(iVar26 + 0x1ff8) = uVar19;
        *(undefined4 *)(iVar26 + 0x1ffc) = uVar20;
        *(undefined4 *)(iVar26 + 0x2000) = uVar21;
        *(undefined4 *)(iVar26 + 0x2004) = uVar22;
        if ((!bVar23) || (((uint32_t)var_18h & 4) != 0)) goto code_r0x00018014c5e1;
        cVar30 = func_0x000180107ff0(2, 0, 0);
        bVar25 = false;
        if (cVar30 == '\0') goto code_r0x00018014c5e1;
        uVar29 = 1;
code_r0x00018014c6af:
        pfVar2 = (float *)(iVar26 + 0xe44 + ((uint64_t)(uint8_t)arg_40h ^ 1) * 4);
        fVar33 = (float)var_d8h;
        if (*pfVar2 <= 0.0 && *pfVar2 != 0.0) goto code_r0x00018014c5f5;
    } else {
        var_d0h = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1260);
        uStack_cc = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1264);
        uStack_c8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1268);
        fVar35 = arg_28h._4_4_ + fVar36 * 0.5;
        fVar33 = fVar36 * 0.5 + (float)arg_28h;
        var_c4h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x126c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar31 = func_0x0001800f5fa0(&var_d0h);
        func_0x000180130370(arg1, CONCAT44(fVar35, fVar33), uVar31);
        bVar25 = true;
code_r0x00018014c5e1:
        if (bVar24) {
            if (!bVar25) goto code_r0x00018014c6af;
        } else {
            fVar33 = (float)var_d8h;
            if (!bVar25) goto code_r0x00018014c611;
        }
code_r0x00018014c5f5:
        fVar36 = fVar36 * 0.9;
        fVar33 = (float)var_d8h - fVar36;
    }
    var_d8h._0_4_ = (float)var_d8h - fVar36;
code_r0x00018014c611:
    iVar26 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x1806238f0;
    *(undefined8 *)(iVar26 + 0x2a28) = 0x18063d7d8;
    func_0x0001800f7480(arg1, &var_e0h, &var_d8h, fVar33, iVar27, pcVar32, &var_10h);
    if (iVar28 != 0) {
        *(undefined *)iVar28 = uVar29;
    }
    return;
}

// ============================================================
// Function: FUN_18014c348
// Address: 0x18014c348
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_163ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_e44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1654h because it doesn't fit into ProtoModel

void fcn.18014c270(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_f8h, int64_t arg_170h)
{
    char *pcVar1;
    float *pfVar2;
    float fVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    bool bVar23;
    bool bVar24;
    bool bVar25;
    int64_t iVar26;
    int64_t iVar27;
    int64_t iVar28;
    undefined uVar29;
    char cVar30;
    undefined4 uVar31;
    char *pcVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    undefined4 var_d0h;
    undefined4 uStack_cc;
    undefined4 uStack_c8;
    int64_t var_c4h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    
    iVar27 = arg_28h;
    iVar26 = *(int64_t *)0x180781f28;
    var_18h._0_4_ = (uint32_t)arg3;
    pcVar32 = (char *)arg_28h;
    if (arg_28h != -1) {
        while (*pcVar32 != '\0') {
            pcVar1 = pcVar32 + 1;
            if (((*pcVar32 == '#') && (*pcVar1 == '#')) || (pcVar32 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    func_0x0001800fe0a0(&var_10h, arg_28h, pcVar32, 0, 0xbf800000);
    iVar28 = arg_48h;
    if (arg_48h != 0) {
        *(undefined *)arg_48h = 0;
    }
    if (arg_50h != 0) {
        *(undefined *)arg_50h = 0;
    }
    if (*(float *)(arg2 + 8) - *(float *)arg2 <= 1.0) {
        return;
    }
    fVar33 = (float)arg4;
    var_e0h = *(float *)arg2 + fVar33;
    var_d8h._0_4_ = *(float *)(arg2 + 8) - fVar33;
    var_e8h._4_4_ = (float)((uint64_t)arg4 >> 0x20);
    var_dch = var_e8h._4_4_ + *(float *)(arg2 + 4);
    var_d8h._4_4_ = *(undefined4 *)(arg2 + 0xc);
    if (arg_50h != 0) {
        *(bool *)arg_50h = (float)var_d8h < var_e0h + (float)var_10h;
    }
    fVar35 = *(float *)(arg2 + 8);
    uVar29 = 0;
    fVar3 = *(float *)arg2;
    arg_28h._4_4_ = var_e8h._4_4_ + *(float *)(arg2 + 4);
    fVar36 = *(float *)(iVar26 + 0x12f8);
    bVar24 = false;
    fVar33 = (fVar35 - fVar33) - fVar36;
    arg_28h._0_4_ = fVar3;
    if (fVar3 <= fVar33) {
        arg_28h._0_4_ = fVar33;
    }
    if (((*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_30h) || (*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_38h)) ||
       ((*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_30h || (*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_38h)))) {
        bVar23 = true;
    } else {
        bVar23 = false;
    }
    if ((int32_t)arg_38h != 0) {
        if ((uint8_t)arg_40h == 0) {
            fVar33 = *(float *)(iVar26 + 0xe48);
        } else {
            fVar33 = *(float *)(iVar26 + 0xe44);
        }
        if (fVar33 < 0.0) {
code_r0x00018014c473:
            bVar24 = true;
        } else if (bVar23) {
            fVar34 = fVar36;
            if (fVar36 <= fVar33) {
                fVar34 = fVar33;
            }
            if (fVar34 <= fVar35 - fVar3) goto code_r0x00018014c473;
        }
    }
    if ((((arg3 & 1U) == 0) || (fVar35 < fVar36 + (float)arg_28h)) || ((bVar24 && (bVar23)))) {
        bVar25 = false;
        if (!bVar24) goto code_r0x00018014c5e1;
        uVar31 = *(undefined4 *)(iVar26 + 0x1fb8);
        uVar4 = *(undefined4 *)(iVar26 + 0x1fbc);
        uVar5 = *(undefined4 *)(iVar26 + 0x1fc0);
        uVar6 = *(undefined4 *)(iVar26 + 0x1fc4);
        uVar7 = *(undefined4 *)(iVar26 + 0x1fc8);
        uVar8 = *(undefined4 *)(iVar26 + 0x1fcc);
        uVar9 = *(undefined4 *)(iVar26 + 0x1fd0);
        uVar10 = *(undefined4 *)(iVar26 + 0x1fd4);
        uVar11 = *(undefined4 *)(iVar26 + 0x1fd8);
        uVar12 = *(undefined4 *)(iVar26 + 0x1fdc);
        uVar13 = *(undefined4 *)(iVar26 + 0x1fe0);
        uVar14 = *(undefined4 *)(iVar26 + 0x1fe4);
        uVar15 = *(undefined4 *)(iVar26 + 0x1fe8);
        uVar16 = *(undefined4 *)(iVar26 + 0x1fec);
        uVar17 = *(undefined4 *)(iVar26 + 0x1ff0);
        uVar18 = *(undefined4 *)(iVar26 + 0x1ff4);
        uVar19 = *(undefined4 *)(iVar26 + 0x1ff8);
        uVar20 = *(undefined4 *)(iVar26 + 0x1ffc);
        uVar21 = *(undefined4 *)(iVar26 + 0x2000);
        uVar22 = *(undefined4 *)(iVar26 + 0x2004);
        uVar29 = func_0x00018013ac70(arg_38h & 0xffffffff, &arg_28h);
        *(undefined4 *)(iVar26 + 0x1fb8) = uVar31;
        *(undefined4 *)(iVar26 + 0x1fbc) = uVar4;
        *(undefined4 *)(iVar26 + 0x1fc0) = uVar5;
        *(undefined4 *)(iVar26 + 0x1fc4) = uVar6;
        *(undefined4 *)(iVar26 + 0x1fc8) = uVar7;
        *(undefined4 *)(iVar26 + 0x1fcc) = uVar8;
        *(undefined4 *)(iVar26 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar26 + 0x1fd4) = uVar10;
        *(undefined4 *)(iVar26 + 0x1fd8) = uVar11;
        *(undefined4 *)(iVar26 + 0x1fdc) = uVar12;
        *(undefined4 *)(iVar26 + 0x1fe0) = uVar13;
        *(undefined4 *)(iVar26 + 0x1fe4) = uVar14;
        *(undefined4 *)(iVar26 + 0x1fe8) = uVar15;
        *(undefined4 *)(iVar26 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar26 + 0x1ff0) = uVar17;
        *(undefined4 *)(iVar26 + 0x1ff4) = uVar18;
        *(undefined4 *)(iVar26 + 0x1ff8) = uVar19;
        *(undefined4 *)(iVar26 + 0x1ffc) = uVar20;
        *(undefined4 *)(iVar26 + 0x2000) = uVar21;
        *(undefined4 *)(iVar26 + 0x2004) = uVar22;
        if ((!bVar23) || (((uint32_t)var_18h & 4) != 0)) goto code_r0x00018014c5e1;
        cVar30 = func_0x000180107ff0(2, 0, 0);
        bVar25 = false;
        if (cVar30 == '\0') goto code_r0x00018014c5e1;
        uVar29 = 1;
code_r0x00018014c6af:
        pfVar2 = (float *)(iVar26 + 0xe44 + ((uint64_t)(uint8_t)arg_40h ^ 1) * 4);
        fVar33 = (float)var_d8h;
        if (*pfVar2 <= 0.0 && *pfVar2 != 0.0) goto code_r0x00018014c5f5;
    } else {
        var_d0h = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1260);
        uStack_cc = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1264);
        uStack_c8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1268);
        fVar35 = arg_28h._4_4_ + fVar36 * 0.5;
        fVar33 = fVar36 * 0.5 + (float)arg_28h;
        var_c4h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x126c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar31 = func_0x0001800f5fa0(&var_d0h);
        func_0x000180130370(arg1, CONCAT44(fVar35, fVar33), uVar31);
        bVar25 = true;
code_r0x00018014c5e1:
        if (bVar24) {
            if (!bVar25) goto code_r0x00018014c6af;
        } else {
            fVar33 = (float)var_d8h;
            if (!bVar25) goto code_r0x00018014c611;
        }
code_r0x00018014c5f5:
        fVar36 = fVar36 * 0.9;
        fVar33 = (float)var_d8h - fVar36;
    }
    var_d8h._0_4_ = (float)var_d8h - fVar36;
code_r0x00018014c611:
    iVar26 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x1806238f0;
    *(undefined8 *)(iVar26 + 0x2a28) = 0x18063d7d8;
    func_0x0001800f7480(arg1, &var_e0h, &var_d8h, fVar33, iVar27, pcVar32, &var_10h);
    if (iVar28 != 0) {
        *(undefined *)iVar28 = uVar29;
    }
    return;
}

// ============================================================
// Function: FUN_18014c354
// Address: 0x18014c354
// Size: 465 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_163ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_e44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1654h because it doesn't fit into ProtoModel

void fcn.18014c270(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_f8h, int64_t arg_170h)
{
    char *pcVar1;
    float *pfVar2;
    float fVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    bool bVar23;
    bool bVar24;
    bool bVar25;
    int64_t iVar26;
    int64_t iVar27;
    int64_t iVar28;
    undefined uVar29;
    char cVar30;
    undefined4 uVar31;
    char *pcVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    undefined4 var_d0h;
    undefined4 uStack_cc;
    undefined4 uStack_c8;
    int64_t var_c4h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    
    iVar27 = arg_28h;
    iVar26 = *(int64_t *)0x180781f28;
    var_18h._0_4_ = (uint32_t)arg3;
    pcVar32 = (char *)arg_28h;
    if (arg_28h != -1) {
        while (*pcVar32 != '\0') {
            pcVar1 = pcVar32 + 1;
            if (((*pcVar32 == '#') && (*pcVar1 == '#')) || (pcVar32 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    func_0x0001800fe0a0(&var_10h, arg_28h, pcVar32, 0, 0xbf800000);
    iVar28 = arg_48h;
    if (arg_48h != 0) {
        *(undefined *)arg_48h = 0;
    }
    if (arg_50h != 0) {
        *(undefined *)arg_50h = 0;
    }
    if (*(float *)(arg2 + 8) - *(float *)arg2 <= 1.0) {
        return;
    }
    fVar33 = (float)arg4;
    var_e0h = *(float *)arg2 + fVar33;
    var_d8h._0_4_ = *(float *)(arg2 + 8) - fVar33;
    var_e8h._4_4_ = (float)((uint64_t)arg4 >> 0x20);
    var_dch = var_e8h._4_4_ + *(float *)(arg2 + 4);
    var_d8h._4_4_ = *(undefined4 *)(arg2 + 0xc);
    if (arg_50h != 0) {
        *(bool *)arg_50h = (float)var_d8h < var_e0h + (float)var_10h;
    }
    fVar35 = *(float *)(arg2 + 8);
    uVar29 = 0;
    fVar3 = *(float *)arg2;
    arg_28h._4_4_ = var_e8h._4_4_ + *(float *)(arg2 + 4);
    fVar36 = *(float *)(iVar26 + 0x12f8);
    bVar24 = false;
    fVar33 = (fVar35 - fVar33) - fVar36;
    arg_28h._0_4_ = fVar3;
    if (fVar3 <= fVar33) {
        arg_28h._0_4_ = fVar33;
    }
    if (((*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_30h) || (*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_38h)) ||
       ((*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_30h || (*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_38h)))) {
        bVar23 = true;
    } else {
        bVar23 = false;
    }
    if ((int32_t)arg_38h != 0) {
        if ((uint8_t)arg_40h == 0) {
            fVar33 = *(float *)(iVar26 + 0xe48);
        } else {
            fVar33 = *(float *)(iVar26 + 0xe44);
        }
        if (fVar33 < 0.0) {
code_r0x00018014c473:
            bVar24 = true;
        } else if (bVar23) {
            fVar34 = fVar36;
            if (fVar36 <= fVar33) {
                fVar34 = fVar33;
            }
            if (fVar34 <= fVar35 - fVar3) goto code_r0x00018014c473;
        }
    }
    if ((((arg3 & 1U) == 0) || (fVar35 < fVar36 + (float)arg_28h)) || ((bVar24 && (bVar23)))) {
        bVar25 = false;
        if (!bVar24) goto code_r0x00018014c5e1;
        uVar31 = *(undefined4 *)(iVar26 + 0x1fb8);
        uVar4 = *(undefined4 *)(iVar26 + 0x1fbc);
        uVar5 = *(undefined4 *)(iVar26 + 0x1fc0);
        uVar6 = *(undefined4 *)(iVar26 + 0x1fc4);
        uVar7 = *(undefined4 *)(iVar26 + 0x1fc8);
        uVar8 = *(undefined4 *)(iVar26 + 0x1fcc);
        uVar9 = *(undefined4 *)(iVar26 + 0x1fd0);
        uVar10 = *(undefined4 *)(iVar26 + 0x1fd4);
        uVar11 = *(undefined4 *)(iVar26 + 0x1fd8);
        uVar12 = *(undefined4 *)(iVar26 + 0x1fdc);
        uVar13 = *(undefined4 *)(iVar26 + 0x1fe0);
        uVar14 = *(undefined4 *)(iVar26 + 0x1fe4);
        uVar15 = *(undefined4 *)(iVar26 + 0x1fe8);
        uVar16 = *(undefined4 *)(iVar26 + 0x1fec);
        uVar17 = *(undefined4 *)(iVar26 + 0x1ff0);
        uVar18 = *(undefined4 *)(iVar26 + 0x1ff4);
        uVar19 = *(undefined4 *)(iVar26 + 0x1ff8);
        uVar20 = *(undefined4 *)(iVar26 + 0x1ffc);
        uVar21 = *(undefined4 *)(iVar26 + 0x2000);
        uVar22 = *(undefined4 *)(iVar26 + 0x2004);
        uVar29 = func_0x00018013ac70(arg_38h & 0xffffffff, &arg_28h);
        *(undefined4 *)(iVar26 + 0x1fb8) = uVar31;
        *(undefined4 *)(iVar26 + 0x1fbc) = uVar4;
        *(undefined4 *)(iVar26 + 0x1fc0) = uVar5;
        *(undefined4 *)(iVar26 + 0x1fc4) = uVar6;
        *(undefined4 *)(iVar26 + 0x1fc8) = uVar7;
        *(undefined4 *)(iVar26 + 0x1fcc) = uVar8;
        *(undefined4 *)(iVar26 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar26 + 0x1fd4) = uVar10;
        *(undefined4 *)(iVar26 + 0x1fd8) = uVar11;
        *(undefined4 *)(iVar26 + 0x1fdc) = uVar12;
        *(undefined4 *)(iVar26 + 0x1fe0) = uVar13;
        *(undefined4 *)(iVar26 + 0x1fe4) = uVar14;
        *(undefined4 *)(iVar26 + 0x1fe8) = uVar15;
        *(undefined4 *)(iVar26 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar26 + 0x1ff0) = uVar17;
        *(undefined4 *)(iVar26 + 0x1ff4) = uVar18;
        *(undefined4 *)(iVar26 + 0x1ff8) = uVar19;
        *(undefined4 *)(iVar26 + 0x1ffc) = uVar20;
        *(undefined4 *)(iVar26 + 0x2000) = uVar21;
        *(undefined4 *)(iVar26 + 0x2004) = uVar22;
        if ((!bVar23) || (((uint32_t)var_18h & 4) != 0)) goto code_r0x00018014c5e1;
        cVar30 = func_0x000180107ff0(2, 0, 0);
        bVar25 = false;
        if (cVar30 == '\0') goto code_r0x00018014c5e1;
        uVar29 = 1;
code_r0x00018014c6af:
        pfVar2 = (float *)(iVar26 + 0xe44 + ((uint64_t)(uint8_t)arg_40h ^ 1) * 4);
        fVar33 = (float)var_d8h;
        if (*pfVar2 <= 0.0 && *pfVar2 != 0.0) goto code_r0x00018014c5f5;
    } else {
        var_d0h = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1260);
        uStack_cc = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1264);
        uStack_c8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1268);
        fVar35 = arg_28h._4_4_ + fVar36 * 0.5;
        fVar33 = fVar36 * 0.5 + (float)arg_28h;
        var_c4h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x126c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar31 = func_0x0001800f5fa0(&var_d0h);
        func_0x000180130370(arg1, CONCAT44(fVar35, fVar33), uVar31);
        bVar25 = true;
code_r0x00018014c5e1:
        if (bVar24) {
            if (!bVar25) goto code_r0x00018014c6af;
        } else {
            fVar33 = (float)var_d8h;
            if (!bVar25) goto code_r0x00018014c611;
        }
code_r0x00018014c5f5:
        fVar36 = fVar36 * 0.9;
        fVar33 = (float)var_d8h - fVar36;
    }
    var_d8h._0_4_ = (float)var_d8h - fVar36;
code_r0x00018014c611:
    iVar26 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x1806238f0;
    *(undefined8 *)(iVar26 + 0x2a28) = 0x18063d7d8;
    func_0x0001800f7480(arg1, &var_e0h, &var_d8h, fVar33, iVar27, pcVar32, &var_10h);
    if (iVar28 != 0) {
        *(undefined *)iVar28 = uVar29;
    }
    return;
}

// ============================================================
// Function: FUN_18014c525
// Address: 0x18014c525
// Size: 129 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_163ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_e44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1654h because it doesn't fit into ProtoModel

void fcn.18014c270(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_f8h, int64_t arg_170h)
{
    char *pcVar1;
    float *pfVar2;
    float fVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    bool bVar23;
    bool bVar24;
    bool bVar25;
    int64_t iVar26;
    int64_t iVar27;
    int64_t iVar28;
    undefined uVar29;
    char cVar30;
    undefined4 uVar31;
    char *pcVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    undefined4 var_d0h;
    undefined4 uStack_cc;
    undefined4 uStack_c8;
    int64_t var_c4h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    
    iVar27 = arg_28h;
    iVar26 = *(int64_t *)0x180781f28;
    var_18h._0_4_ = (uint32_t)arg3;
    pcVar32 = (char *)arg_28h;
    if (arg_28h != -1) {
        while (*pcVar32 != '\0') {
            pcVar1 = pcVar32 + 1;
            if (((*pcVar32 == '#') && (*pcVar1 == '#')) || (pcVar32 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    func_0x0001800fe0a0(&var_10h, arg_28h, pcVar32, 0, 0xbf800000);
    iVar28 = arg_48h;
    if (arg_48h != 0) {
        *(undefined *)arg_48h = 0;
    }
    if (arg_50h != 0) {
        *(undefined *)arg_50h = 0;
    }
    if (*(float *)(arg2 + 8) - *(float *)arg2 <= 1.0) {
        return;
    }
    fVar33 = (float)arg4;
    var_e0h = *(float *)arg2 + fVar33;
    var_d8h._0_4_ = *(float *)(arg2 + 8) - fVar33;
    var_e8h._4_4_ = (float)((uint64_t)arg4 >> 0x20);
    var_dch = var_e8h._4_4_ + *(float *)(arg2 + 4);
    var_d8h._4_4_ = *(undefined4 *)(arg2 + 0xc);
    if (arg_50h != 0) {
        *(bool *)arg_50h = (float)var_d8h < var_e0h + (float)var_10h;
    }
    fVar35 = *(float *)(arg2 + 8);
    uVar29 = 0;
    fVar3 = *(float *)arg2;
    arg_28h._4_4_ = var_e8h._4_4_ + *(float *)(arg2 + 4);
    fVar36 = *(float *)(iVar26 + 0x12f8);
    bVar24 = false;
    fVar33 = (fVar35 - fVar33) - fVar36;
    arg_28h._0_4_ = fVar3;
    if (fVar3 <= fVar33) {
        arg_28h._0_4_ = fVar33;
    }
    if (((*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_30h) || (*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_38h)) ||
       ((*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_30h || (*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_38h)))) {
        bVar23 = true;
    } else {
        bVar23 = false;
    }
    if ((int32_t)arg_38h != 0) {
        if ((uint8_t)arg_40h == 0) {
            fVar33 = *(float *)(iVar26 + 0xe48);
        } else {
            fVar33 = *(float *)(iVar26 + 0xe44);
        }
        if (fVar33 < 0.0) {
code_r0x00018014c473:
            bVar24 = true;
        } else if (bVar23) {
            fVar34 = fVar36;
            if (fVar36 <= fVar33) {
                fVar34 = fVar33;
            }
            if (fVar34 <= fVar35 - fVar3) goto code_r0x00018014c473;
        }
    }
    if ((((arg3 & 1U) == 0) || (fVar35 < fVar36 + (float)arg_28h)) || ((bVar24 && (bVar23)))) {
        bVar25 = false;
        if (!bVar24) goto code_r0x00018014c5e1;
        uVar31 = *(undefined4 *)(iVar26 + 0x1fb8);
        uVar4 = *(undefined4 *)(iVar26 + 0x1fbc);
        uVar5 = *(undefined4 *)(iVar26 + 0x1fc0);
        uVar6 = *(undefined4 *)(iVar26 + 0x1fc4);
        uVar7 = *(undefined4 *)(iVar26 + 0x1fc8);
        uVar8 = *(undefined4 *)(iVar26 + 0x1fcc);
        uVar9 = *(undefined4 *)(iVar26 + 0x1fd0);
        uVar10 = *(undefined4 *)(iVar26 + 0x1fd4);
        uVar11 = *(undefined4 *)(iVar26 + 0x1fd8);
        uVar12 = *(undefined4 *)(iVar26 + 0x1fdc);
        uVar13 = *(undefined4 *)(iVar26 + 0x1fe0);
        uVar14 = *(undefined4 *)(iVar26 + 0x1fe4);
        uVar15 = *(undefined4 *)(iVar26 + 0x1fe8);
        uVar16 = *(undefined4 *)(iVar26 + 0x1fec);
        uVar17 = *(undefined4 *)(iVar26 + 0x1ff0);
        uVar18 = *(undefined4 *)(iVar26 + 0x1ff4);
        uVar19 = *(undefined4 *)(iVar26 + 0x1ff8);
        uVar20 = *(undefined4 *)(iVar26 + 0x1ffc);
        uVar21 = *(undefined4 *)(iVar26 + 0x2000);
        uVar22 = *(undefined4 *)(iVar26 + 0x2004);
        uVar29 = func_0x00018013ac70(arg_38h & 0xffffffff, &arg_28h);
        *(undefined4 *)(iVar26 + 0x1fb8) = uVar31;
        *(undefined4 *)(iVar26 + 0x1fbc) = uVar4;
        *(undefined4 *)(iVar26 + 0x1fc0) = uVar5;
        *(undefined4 *)(iVar26 + 0x1fc4) = uVar6;
        *(undefined4 *)(iVar26 + 0x1fc8) = uVar7;
        *(undefined4 *)(iVar26 + 0x1fcc) = uVar8;
        *(undefined4 *)(iVar26 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar26 + 0x1fd4) = uVar10;
        *(undefined4 *)(iVar26 + 0x1fd8) = uVar11;
        *(undefined4 *)(iVar26 + 0x1fdc) = uVar12;
        *(undefined4 *)(iVar26 + 0x1fe0) = uVar13;
        *(undefined4 *)(iVar26 + 0x1fe4) = uVar14;
        *(undefined4 *)(iVar26 + 0x1fe8) = uVar15;
        *(undefined4 *)(iVar26 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar26 + 0x1ff0) = uVar17;
        *(undefined4 *)(iVar26 + 0x1ff4) = uVar18;
        *(undefined4 *)(iVar26 + 0x1ff8) = uVar19;
        *(undefined4 *)(iVar26 + 0x1ffc) = uVar20;
        *(undefined4 *)(iVar26 + 0x2000) = uVar21;
        *(undefined4 *)(iVar26 + 0x2004) = uVar22;
        if ((!bVar23) || (((uint32_t)var_18h & 4) != 0)) goto code_r0x00018014c5e1;
        cVar30 = func_0x000180107ff0(2, 0, 0);
        bVar25 = false;
        if (cVar30 == '\0') goto code_r0x00018014c5e1;
        uVar29 = 1;
code_r0x00018014c6af:
        pfVar2 = (float *)(iVar26 + 0xe44 + ((uint64_t)(uint8_t)arg_40h ^ 1) * 4);
        fVar33 = (float)var_d8h;
        if (*pfVar2 <= 0.0 && *pfVar2 != 0.0) goto code_r0x00018014c5f5;
    } else {
        var_d0h = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1260);
        uStack_cc = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1264);
        uStack_c8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1268);
        fVar35 = arg_28h._4_4_ + fVar36 * 0.5;
        fVar33 = fVar36 * 0.5 + (float)arg_28h;
        var_c4h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x126c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar31 = func_0x0001800f5fa0(&var_d0h);
        func_0x000180130370(arg1, CONCAT44(fVar35, fVar33), uVar31);
        bVar25 = true;
code_r0x00018014c5e1:
        if (bVar24) {
            if (!bVar25) goto code_r0x00018014c6af;
        } else {
            fVar33 = (float)var_d8h;
            if (!bVar25) goto code_r0x00018014c611;
        }
code_r0x00018014c5f5:
        fVar36 = fVar36 * 0.9;
        fVar33 = (float)var_d8h - fVar36;
    }
    var_d8h._0_4_ = (float)var_d8h - fVar36;
code_r0x00018014c611:
    iVar26 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x1806238f0;
    *(undefined8 *)(iVar26 + 0x2a28) = 0x18063d7d8;
    func_0x0001800f7480(arg1, &var_e0h, &var_d8h, fVar33, iVar27, pcVar32, &var_10h);
    if (iVar28 != 0) {
        *(undefined *)iVar28 = uVar29;
    }
    return;
}

// ============================================================
// Function: FUN_18014c5a6
// Address: 0x18014c5a6
// Size: 219 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_163ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_e44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1654h because it doesn't fit into ProtoModel

void fcn.18014c270(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_f8h, int64_t arg_170h)
{
    char *pcVar1;
    float *pfVar2;
    float fVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    bool bVar23;
    bool bVar24;
    bool bVar25;
    int64_t iVar26;
    int64_t iVar27;
    int64_t iVar28;
    undefined uVar29;
    char cVar30;
    undefined4 uVar31;
    char *pcVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    undefined4 var_d0h;
    undefined4 uStack_cc;
    undefined4 uStack_c8;
    int64_t var_c4h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    
    iVar27 = arg_28h;
    iVar26 = *(int64_t *)0x180781f28;
    var_18h._0_4_ = (uint32_t)arg3;
    pcVar32 = (char *)arg_28h;
    if (arg_28h != -1) {
        while (*pcVar32 != '\0') {
            pcVar1 = pcVar32 + 1;
            if (((*pcVar32 == '#') && (*pcVar1 == '#')) || (pcVar32 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    func_0x0001800fe0a0(&var_10h, arg_28h, pcVar32, 0, 0xbf800000);
    iVar28 = arg_48h;
    if (arg_48h != 0) {
        *(undefined *)arg_48h = 0;
    }
    if (arg_50h != 0) {
        *(undefined *)arg_50h = 0;
    }
    if (*(float *)(arg2 + 8) - *(float *)arg2 <= 1.0) {
        return;
    }
    fVar33 = (float)arg4;
    var_e0h = *(float *)arg2 + fVar33;
    var_d8h._0_4_ = *(float *)(arg2 + 8) - fVar33;
    var_e8h._4_4_ = (float)((uint64_t)arg4 >> 0x20);
    var_dch = var_e8h._4_4_ + *(float *)(arg2 + 4);
    var_d8h._4_4_ = *(undefined4 *)(arg2 + 0xc);
    if (arg_50h != 0) {
        *(bool *)arg_50h = (float)var_d8h < var_e0h + (float)var_10h;
    }
    fVar35 = *(float *)(arg2 + 8);
    uVar29 = 0;
    fVar3 = *(float *)arg2;
    arg_28h._4_4_ = var_e8h._4_4_ + *(float *)(arg2 + 4);
    fVar36 = *(float *)(iVar26 + 0x12f8);
    bVar24 = false;
    fVar33 = (fVar35 - fVar33) - fVar36;
    arg_28h._0_4_ = fVar3;
    if (fVar3 <= fVar33) {
        arg_28h._0_4_ = fVar33;
    }
    if (((*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_30h) || (*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_38h)) ||
       ((*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_30h || (*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_38h)))) {
        bVar23 = true;
    } else {
        bVar23 = false;
    }
    if ((int32_t)arg_38h != 0) {
        if ((uint8_t)arg_40h == 0) {
            fVar33 = *(float *)(iVar26 + 0xe48);
        } else {
            fVar33 = *(float *)(iVar26 + 0xe44);
        }
        if (fVar33 < 0.0) {
code_r0x00018014c473:
            bVar24 = true;
        } else if (bVar23) {
            fVar34 = fVar36;
            if (fVar36 <= fVar33) {
                fVar34 = fVar33;
            }
            if (fVar34 <= fVar35 - fVar3) goto code_r0x00018014c473;
        }
    }
    if ((((arg3 & 1U) == 0) || (fVar35 < fVar36 + (float)arg_28h)) || ((bVar24 && (bVar23)))) {
        bVar25 = false;
        if (!bVar24) goto code_r0x00018014c5e1;
        uVar31 = *(undefined4 *)(iVar26 + 0x1fb8);
        uVar4 = *(undefined4 *)(iVar26 + 0x1fbc);
        uVar5 = *(undefined4 *)(iVar26 + 0x1fc0);
        uVar6 = *(undefined4 *)(iVar26 + 0x1fc4);
        uVar7 = *(undefined4 *)(iVar26 + 0x1fc8);
        uVar8 = *(undefined4 *)(iVar26 + 0x1fcc);
        uVar9 = *(undefined4 *)(iVar26 + 0x1fd0);
        uVar10 = *(undefined4 *)(iVar26 + 0x1fd4);
        uVar11 = *(undefined4 *)(iVar26 + 0x1fd8);
        uVar12 = *(undefined4 *)(iVar26 + 0x1fdc);
        uVar13 = *(undefined4 *)(iVar26 + 0x1fe0);
        uVar14 = *(undefined4 *)(iVar26 + 0x1fe4);
        uVar15 = *(undefined4 *)(iVar26 + 0x1fe8);
        uVar16 = *(undefined4 *)(iVar26 + 0x1fec);
        uVar17 = *(undefined4 *)(iVar26 + 0x1ff0);
        uVar18 = *(undefined4 *)(iVar26 + 0x1ff4);
        uVar19 = *(undefined4 *)(iVar26 + 0x1ff8);
        uVar20 = *(undefined4 *)(iVar26 + 0x1ffc);
        uVar21 = *(undefined4 *)(iVar26 + 0x2000);
        uVar22 = *(undefined4 *)(iVar26 + 0x2004);
        uVar29 = func_0x00018013ac70(arg_38h & 0xffffffff, &arg_28h);
        *(undefined4 *)(iVar26 + 0x1fb8) = uVar31;
        *(undefined4 *)(iVar26 + 0x1fbc) = uVar4;
        *(undefined4 *)(iVar26 + 0x1fc0) = uVar5;
        *(undefined4 *)(iVar26 + 0x1fc4) = uVar6;
        *(undefined4 *)(iVar26 + 0x1fc8) = uVar7;
        *(undefined4 *)(iVar26 + 0x1fcc) = uVar8;
        *(undefined4 *)(iVar26 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar26 + 0x1fd4) = uVar10;
        *(undefined4 *)(iVar26 + 0x1fd8) = uVar11;
        *(undefined4 *)(iVar26 + 0x1fdc) = uVar12;
        *(undefined4 *)(iVar26 + 0x1fe0) = uVar13;
        *(undefined4 *)(iVar26 + 0x1fe4) = uVar14;
        *(undefined4 *)(iVar26 + 0x1fe8) = uVar15;
        *(undefined4 *)(iVar26 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar26 + 0x1ff0) = uVar17;
        *(undefined4 *)(iVar26 + 0x1ff4) = uVar18;
        *(undefined4 *)(iVar26 + 0x1ff8) = uVar19;
        *(undefined4 *)(iVar26 + 0x1ffc) = uVar20;
        *(undefined4 *)(iVar26 + 0x2000) = uVar21;
        *(undefined4 *)(iVar26 + 0x2004) = uVar22;
        if ((!bVar23) || (((uint32_t)var_18h & 4) != 0)) goto code_r0x00018014c5e1;
        cVar30 = func_0x000180107ff0(2, 0, 0);
        bVar25 = false;
        if (cVar30 == '\0') goto code_r0x00018014c5e1;
        uVar29 = 1;
code_r0x00018014c6af:
        pfVar2 = (float *)(iVar26 + 0xe44 + ((uint64_t)(uint8_t)arg_40h ^ 1) * 4);
        fVar33 = (float)var_d8h;
        if (*pfVar2 <= 0.0 && *pfVar2 != 0.0) goto code_r0x00018014c5f5;
    } else {
        var_d0h = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1260);
        uStack_cc = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1264);
        uStack_c8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1268);
        fVar35 = arg_28h._4_4_ + fVar36 * 0.5;
        fVar33 = fVar36 * 0.5 + (float)arg_28h;
        var_c4h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x126c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar31 = func_0x0001800f5fa0(&var_d0h);
        func_0x000180130370(arg1, CONCAT44(fVar35, fVar33), uVar31);
        bVar25 = true;
code_r0x00018014c5e1:
        if (bVar24) {
            if (!bVar25) goto code_r0x00018014c6af;
        } else {
            fVar33 = (float)var_d8h;
            if (!bVar25) goto code_r0x00018014c611;
        }
code_r0x00018014c5f5:
        fVar36 = fVar36 * 0.9;
        fVar33 = (float)var_d8h - fVar36;
    }
    var_d8h._0_4_ = (float)var_d8h - fVar36;
code_r0x00018014c611:
    iVar26 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x1806238f0;
    *(undefined8 *)(iVar26 + 0x2a28) = 0x18063d7d8;
    func_0x0001800f7480(arg1, &var_e0h, &var_d8h, fVar33, iVar27, pcVar32, &var_10h);
    if (iVar28 != 0) {
        *(undefined *)iVar28 = uVar29;
    }
    return;
}

// ============================================================
// Function: FUN_18014c681
// Address: 0x18014c681
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_163ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_e44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1654h because it doesn't fit into ProtoModel

void fcn.18014c270(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_f8h, int64_t arg_170h)
{
    char *pcVar1;
    float *pfVar2;
    float fVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    bool bVar23;
    bool bVar24;
    bool bVar25;
    int64_t iVar26;
    int64_t iVar27;
    int64_t iVar28;
    undefined uVar29;
    char cVar30;
    undefined4 uVar31;
    char *pcVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    undefined4 var_d0h;
    undefined4 uStack_cc;
    undefined4 uStack_c8;
    int64_t var_c4h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    
    iVar27 = arg_28h;
    iVar26 = *(int64_t *)0x180781f28;
    var_18h._0_4_ = (uint32_t)arg3;
    pcVar32 = (char *)arg_28h;
    if (arg_28h != -1) {
        while (*pcVar32 != '\0') {
            pcVar1 = pcVar32 + 1;
            if (((*pcVar32 == '#') && (*pcVar1 == '#')) || (pcVar32 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    func_0x0001800fe0a0(&var_10h, arg_28h, pcVar32, 0, 0xbf800000);
    iVar28 = arg_48h;
    if (arg_48h != 0) {
        *(undefined *)arg_48h = 0;
    }
    if (arg_50h != 0) {
        *(undefined *)arg_50h = 0;
    }
    if (*(float *)(arg2 + 8) - *(float *)arg2 <= 1.0) {
        return;
    }
    fVar33 = (float)arg4;
    var_e0h = *(float *)arg2 + fVar33;
    var_d8h._0_4_ = *(float *)(arg2 + 8) - fVar33;
    var_e8h._4_4_ = (float)((uint64_t)arg4 >> 0x20);
    var_dch = var_e8h._4_4_ + *(float *)(arg2 + 4);
    var_d8h._4_4_ = *(undefined4 *)(arg2 + 0xc);
    if (arg_50h != 0) {
        *(bool *)arg_50h = (float)var_d8h < var_e0h + (float)var_10h;
    }
    fVar35 = *(float *)(arg2 + 8);
    uVar29 = 0;
    fVar3 = *(float *)arg2;
    arg_28h._4_4_ = var_e8h._4_4_ + *(float *)(arg2 + 4);
    fVar36 = *(float *)(iVar26 + 0x12f8);
    bVar24 = false;
    fVar33 = (fVar35 - fVar33) - fVar36;
    arg_28h._0_4_ = fVar3;
    if (fVar3 <= fVar33) {
        arg_28h._0_4_ = fVar33;
    }
    if (((*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_30h) || (*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_38h)) ||
       ((*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_30h || (*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_38h)))) {
        bVar23 = true;
    } else {
        bVar23 = false;
    }
    if ((int32_t)arg_38h != 0) {
        if ((uint8_t)arg_40h == 0) {
            fVar33 = *(float *)(iVar26 + 0xe48);
        } else {
            fVar33 = *(float *)(iVar26 + 0xe44);
        }
        if (fVar33 < 0.0) {
code_r0x00018014c473:
            bVar24 = true;
        } else if (bVar23) {
            fVar34 = fVar36;
            if (fVar36 <= fVar33) {
                fVar34 = fVar33;
            }
            if (fVar34 <= fVar35 - fVar3) goto code_r0x00018014c473;
        }
    }
    if ((((arg3 & 1U) == 0) || (fVar35 < fVar36 + (float)arg_28h)) || ((bVar24 && (bVar23)))) {
        bVar25 = false;
        if (!bVar24) goto code_r0x00018014c5e1;
        uVar31 = *(undefined4 *)(iVar26 + 0x1fb8);
        uVar4 = *(undefined4 *)(iVar26 + 0x1fbc);
        uVar5 = *(undefined4 *)(iVar26 + 0x1fc0);
        uVar6 = *(undefined4 *)(iVar26 + 0x1fc4);
        uVar7 = *(undefined4 *)(iVar26 + 0x1fc8);
        uVar8 = *(undefined4 *)(iVar26 + 0x1fcc);
        uVar9 = *(undefined4 *)(iVar26 + 0x1fd0);
        uVar10 = *(undefined4 *)(iVar26 + 0x1fd4);
        uVar11 = *(undefined4 *)(iVar26 + 0x1fd8);
        uVar12 = *(undefined4 *)(iVar26 + 0x1fdc);
        uVar13 = *(undefined4 *)(iVar26 + 0x1fe0);
        uVar14 = *(undefined4 *)(iVar26 + 0x1fe4);
        uVar15 = *(undefined4 *)(iVar26 + 0x1fe8);
        uVar16 = *(undefined4 *)(iVar26 + 0x1fec);
        uVar17 = *(undefined4 *)(iVar26 + 0x1ff0);
        uVar18 = *(undefined4 *)(iVar26 + 0x1ff4);
        uVar19 = *(undefined4 *)(iVar26 + 0x1ff8);
        uVar20 = *(undefined4 *)(iVar26 + 0x1ffc);
        uVar21 = *(undefined4 *)(iVar26 + 0x2000);
        uVar22 = *(undefined4 *)(iVar26 + 0x2004);
        uVar29 = func_0x00018013ac70(arg_38h & 0xffffffff, &arg_28h);
        *(undefined4 *)(iVar26 + 0x1fb8) = uVar31;
        *(undefined4 *)(iVar26 + 0x1fbc) = uVar4;
        *(undefined4 *)(iVar26 + 0x1fc0) = uVar5;
        *(undefined4 *)(iVar26 + 0x1fc4) = uVar6;
        *(undefined4 *)(iVar26 + 0x1fc8) = uVar7;
        *(undefined4 *)(iVar26 + 0x1fcc) = uVar8;
        *(undefined4 *)(iVar26 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar26 + 0x1fd4) = uVar10;
        *(undefined4 *)(iVar26 + 0x1fd8) = uVar11;
        *(undefined4 *)(iVar26 + 0x1fdc) = uVar12;
        *(undefined4 *)(iVar26 + 0x1fe0) = uVar13;
        *(undefined4 *)(iVar26 + 0x1fe4) = uVar14;
        *(undefined4 *)(iVar26 + 0x1fe8) = uVar15;
        *(undefined4 *)(iVar26 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar26 + 0x1ff0) = uVar17;
        *(undefined4 *)(iVar26 + 0x1ff4) = uVar18;
        *(undefined4 *)(iVar26 + 0x1ff8) = uVar19;
        *(undefined4 *)(iVar26 + 0x1ffc) = uVar20;
        *(undefined4 *)(iVar26 + 0x2000) = uVar21;
        *(undefined4 *)(iVar26 + 0x2004) = uVar22;
        if ((!bVar23) || (((uint32_t)var_18h & 4) != 0)) goto code_r0x00018014c5e1;
        cVar30 = func_0x000180107ff0(2, 0, 0);
        bVar25 = false;
        if (cVar30 == '\0') goto code_r0x00018014c5e1;
        uVar29 = 1;
code_r0x00018014c6af:
        pfVar2 = (float *)(iVar26 + 0xe44 + ((uint64_t)(uint8_t)arg_40h ^ 1) * 4);
        fVar33 = (float)var_d8h;
        if (*pfVar2 <= 0.0 && *pfVar2 != 0.0) goto code_r0x00018014c5f5;
    } else {
        var_d0h = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1260);
        uStack_cc = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1264);
        uStack_c8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1268);
        fVar35 = arg_28h._4_4_ + fVar36 * 0.5;
        fVar33 = fVar36 * 0.5 + (float)arg_28h;
        var_c4h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x126c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar31 = func_0x0001800f5fa0(&var_d0h);
        func_0x000180130370(arg1, CONCAT44(fVar35, fVar33), uVar31);
        bVar25 = true;
code_r0x00018014c5e1:
        if (bVar24) {
            if (!bVar25) goto code_r0x00018014c6af;
        } else {
            fVar33 = (float)var_d8h;
            if (!bVar25) goto code_r0x00018014c611;
        }
code_r0x00018014c5f5:
        fVar36 = fVar36 * 0.9;
        fVar33 = (float)var_d8h - fVar36;
    }
    var_d8h._0_4_ = (float)var_d8h - fVar36;
code_r0x00018014c611:
    iVar26 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x1806238f0;
    *(undefined8 *)(iVar26 + 0x2a28) = 0x18063d7d8;
    func_0x0001800f7480(arg1, &var_e0h, &var_d8h, fVar33, iVar27, pcVar32, &var_10h);
    if (iVar28 != 0) {
        *(undefined *)iVar28 = uVar29;
    }
    return;
}

// ============================================================
// Function: FUN_18014c68d
// Address: 0x18014c68d
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_163ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_e44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1654h because it doesn't fit into ProtoModel

void fcn.18014c270(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_f8h, int64_t arg_170h)
{
    char *pcVar1;
    float *pfVar2;
    float fVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    bool bVar23;
    bool bVar24;
    bool bVar25;
    int64_t iVar26;
    int64_t iVar27;
    int64_t iVar28;
    undefined uVar29;
    char cVar30;
    undefined4 uVar31;
    char *pcVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    undefined4 var_d0h;
    undefined4 uStack_cc;
    undefined4 uStack_c8;
    int64_t var_c4h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    
    iVar27 = arg_28h;
    iVar26 = *(int64_t *)0x180781f28;
    var_18h._0_4_ = (uint32_t)arg3;
    pcVar32 = (char *)arg_28h;
    if (arg_28h != -1) {
        while (*pcVar32 != '\0') {
            pcVar1 = pcVar32 + 1;
            if (((*pcVar32 == '#') && (*pcVar1 == '#')) || (pcVar32 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    func_0x0001800fe0a0(&var_10h, arg_28h, pcVar32, 0, 0xbf800000);
    iVar28 = arg_48h;
    if (arg_48h != 0) {
        *(undefined *)arg_48h = 0;
    }
    if (arg_50h != 0) {
        *(undefined *)arg_50h = 0;
    }
    if (*(float *)(arg2 + 8) - *(float *)arg2 <= 1.0) {
        return;
    }
    fVar33 = (float)arg4;
    var_e0h = *(float *)arg2 + fVar33;
    var_d8h._0_4_ = *(float *)(arg2 + 8) - fVar33;
    var_e8h._4_4_ = (float)((uint64_t)arg4 >> 0x20);
    var_dch = var_e8h._4_4_ + *(float *)(arg2 + 4);
    var_d8h._4_4_ = *(undefined4 *)(arg2 + 0xc);
    if (arg_50h != 0) {
        *(bool *)arg_50h = (float)var_d8h < var_e0h + (float)var_10h;
    }
    fVar35 = *(float *)(arg2 + 8);
    uVar29 = 0;
    fVar3 = *(float *)arg2;
    arg_28h._4_4_ = var_e8h._4_4_ + *(float *)(arg2 + 4);
    fVar36 = *(float *)(iVar26 + 0x12f8);
    bVar24 = false;
    fVar33 = (fVar35 - fVar33) - fVar36;
    arg_28h._0_4_ = fVar3;
    if (fVar3 <= fVar33) {
        arg_28h._0_4_ = fVar33;
    }
    if (((*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_30h) || (*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_38h)) ||
       ((*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_30h || (*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_38h)))) {
        bVar23 = true;
    } else {
        bVar23 = false;
    }
    if ((int32_t)arg_38h != 0) {
        if ((uint8_t)arg_40h == 0) {
            fVar33 = *(float *)(iVar26 + 0xe48);
        } else {
            fVar33 = *(float *)(iVar26 + 0xe44);
        }
        if (fVar33 < 0.0) {
code_r0x00018014c473:
            bVar24 = true;
        } else if (bVar23) {
            fVar34 = fVar36;
            if (fVar36 <= fVar33) {
                fVar34 = fVar33;
            }
            if (fVar34 <= fVar35 - fVar3) goto code_r0x00018014c473;
        }
    }
    if ((((arg3 & 1U) == 0) || (fVar35 < fVar36 + (float)arg_28h)) || ((bVar24 && (bVar23)))) {
        bVar25 = false;
        if (!bVar24) goto code_r0x00018014c5e1;
        uVar31 = *(undefined4 *)(iVar26 + 0x1fb8);
        uVar4 = *(undefined4 *)(iVar26 + 0x1fbc);
        uVar5 = *(undefined4 *)(iVar26 + 0x1fc0);
        uVar6 = *(undefined4 *)(iVar26 + 0x1fc4);
        uVar7 = *(undefined4 *)(iVar26 + 0x1fc8);
        uVar8 = *(undefined4 *)(iVar26 + 0x1fcc);
        uVar9 = *(undefined4 *)(iVar26 + 0x1fd0);
        uVar10 = *(undefined4 *)(iVar26 + 0x1fd4);
        uVar11 = *(undefined4 *)(iVar26 + 0x1fd8);
        uVar12 = *(undefined4 *)(iVar26 + 0x1fdc);
        uVar13 = *(undefined4 *)(iVar26 + 0x1fe0);
        uVar14 = *(undefined4 *)(iVar26 + 0x1fe4);
        uVar15 = *(undefined4 *)(iVar26 + 0x1fe8);
        uVar16 = *(undefined4 *)(iVar26 + 0x1fec);
        uVar17 = *(undefined4 *)(iVar26 + 0x1ff0);
        uVar18 = *(undefined4 *)(iVar26 + 0x1ff4);
        uVar19 = *(undefined4 *)(iVar26 + 0x1ff8);
        uVar20 = *(undefined4 *)(iVar26 + 0x1ffc);
        uVar21 = *(undefined4 *)(iVar26 + 0x2000);
        uVar22 = *(undefined4 *)(iVar26 + 0x2004);
        uVar29 = func_0x00018013ac70(arg_38h & 0xffffffff, &arg_28h);
        *(undefined4 *)(iVar26 + 0x1fb8) = uVar31;
        *(undefined4 *)(iVar26 + 0x1fbc) = uVar4;
        *(undefined4 *)(iVar26 + 0x1fc0) = uVar5;
        *(undefined4 *)(iVar26 + 0x1fc4) = uVar6;
        *(undefined4 *)(iVar26 + 0x1fc8) = uVar7;
        *(undefined4 *)(iVar26 + 0x1fcc) = uVar8;
        *(undefined4 *)(iVar26 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar26 + 0x1fd4) = uVar10;
        *(undefined4 *)(iVar26 + 0x1fd8) = uVar11;
        *(undefined4 *)(iVar26 + 0x1fdc) = uVar12;
        *(undefined4 *)(iVar26 + 0x1fe0) = uVar13;
        *(undefined4 *)(iVar26 + 0x1fe4) = uVar14;
        *(undefined4 *)(iVar26 + 0x1fe8) = uVar15;
        *(undefined4 *)(iVar26 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar26 + 0x1ff0) = uVar17;
        *(undefined4 *)(iVar26 + 0x1ff4) = uVar18;
        *(undefined4 *)(iVar26 + 0x1ff8) = uVar19;
        *(undefined4 *)(iVar26 + 0x1ffc) = uVar20;
        *(undefined4 *)(iVar26 + 0x2000) = uVar21;
        *(undefined4 *)(iVar26 + 0x2004) = uVar22;
        if ((!bVar23) || (((uint32_t)var_18h & 4) != 0)) goto code_r0x00018014c5e1;
        cVar30 = func_0x000180107ff0(2, 0, 0);
        bVar25 = false;
        if (cVar30 == '\0') goto code_r0x00018014c5e1;
        uVar29 = 1;
code_r0x00018014c6af:
        pfVar2 = (float *)(iVar26 + 0xe44 + ((uint64_t)(uint8_t)arg_40h ^ 1) * 4);
        fVar33 = (float)var_d8h;
        if (*pfVar2 <= 0.0 && *pfVar2 != 0.0) goto code_r0x00018014c5f5;
    } else {
        var_d0h = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1260);
        uStack_cc = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1264);
        uStack_c8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1268);
        fVar35 = arg_28h._4_4_ + fVar36 * 0.5;
        fVar33 = fVar36 * 0.5 + (float)arg_28h;
        var_c4h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x126c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar31 = func_0x0001800f5fa0(&var_d0h);
        func_0x000180130370(arg1, CONCAT44(fVar35, fVar33), uVar31);
        bVar25 = true;
code_r0x00018014c5e1:
        if (bVar24) {
            if (!bVar25) goto code_r0x00018014c6af;
        } else {
            fVar33 = (float)var_d8h;
            if (!bVar25) goto code_r0x00018014c611;
        }
code_r0x00018014c5f5:
        fVar36 = fVar36 * 0.9;
        fVar33 = (float)var_d8h - fVar36;
    }
    var_d8h._0_4_ = (float)var_d8h - fVar36;
code_r0x00018014c611:
    iVar26 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x1806238f0;
    *(undefined8 *)(iVar26 + 0x2a28) = 0x18063d7d8;
    func_0x0001800f7480(arg1, &var_e0h, &var_d8h, fVar33, iVar27, pcVar32, &var_10h);
    if (iVar28 != 0) {
        *(undefined *)iVar28 = uVar29;
    }
    return;
}

// ============================================================
// Function: FUN_18014c6a6
// Address: 0x18014c6a6
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_163ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Removing arg arg_e44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fb8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fc8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fd8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1fe8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ff8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Removing arg arg_e48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1654h because it doesn't fit into ProtoModel

void fcn.18014c270(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_f8h, int64_t arg_170h)
{
    char *pcVar1;
    float *pfVar2;
    float fVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    bool bVar23;
    bool bVar24;
    bool bVar25;
    int64_t iVar26;
    int64_t iVar27;
    int64_t iVar28;
    undefined uVar29;
    char cVar30;
    undefined4 uVar31;
    char *pcVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    undefined4 var_d0h;
    undefined4 uStack_cc;
    undefined4 uStack_c8;
    int64_t var_c4h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    
    iVar27 = arg_28h;
    iVar26 = *(int64_t *)0x180781f28;
    var_18h._0_4_ = (uint32_t)arg3;
    pcVar32 = (char *)arg_28h;
    if (arg_28h != -1) {
        while (*pcVar32 != '\0') {
            pcVar1 = pcVar32 + 1;
            if (((*pcVar32 == '#') && (*pcVar1 == '#')) || (pcVar32 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    func_0x0001800fe0a0(&var_10h, arg_28h, pcVar32, 0, 0xbf800000);
    iVar28 = arg_48h;
    if (arg_48h != 0) {
        *(undefined *)arg_48h = 0;
    }
    if (arg_50h != 0) {
        *(undefined *)arg_50h = 0;
    }
    if (*(float *)(arg2 + 8) - *(float *)arg2 <= 1.0) {
        return;
    }
    fVar33 = (float)arg4;
    var_e0h = *(float *)arg2 + fVar33;
    var_d8h._0_4_ = *(float *)(arg2 + 8) - fVar33;
    var_e8h._4_4_ = (float)((uint64_t)arg4 >> 0x20);
    var_dch = var_e8h._4_4_ + *(float *)(arg2 + 4);
    var_d8h._4_4_ = *(undefined4 *)(arg2 + 0xc);
    if (arg_50h != 0) {
        *(bool *)arg_50h = (float)var_d8h < var_e0h + (float)var_10h;
    }
    fVar35 = *(float *)(arg2 + 8);
    uVar29 = 0;
    fVar3 = *(float *)arg2;
    arg_28h._4_4_ = var_e8h._4_4_ + *(float *)(arg2 + 4);
    fVar36 = *(float *)(iVar26 + 0x12f8);
    bVar24 = false;
    fVar33 = (fVar35 - fVar33) - fVar36;
    arg_28h._0_4_ = fVar3;
    if (fVar3 <= fVar33) {
        arg_28h._0_4_ = fVar33;
    }
    if (((*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_30h) || (*(int32_t *)(iVar26 + 0x163c) == (int32_t)arg_38h)) ||
       ((*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_30h || (*(int32_t *)(iVar26 + 0x1654) == (int32_t)arg_38h)))) {
        bVar23 = true;
    } else {
        bVar23 = false;
    }
    if ((int32_t)arg_38h != 0) {
        if ((uint8_t)arg_40h == 0) {
            fVar33 = *(float *)(iVar26 + 0xe48);
        } else {
            fVar33 = *(float *)(iVar26 + 0xe44);
        }
        if (fVar33 < 0.0) {
code_r0x00018014c473:
            bVar24 = true;
        } else if (bVar23) {
            fVar34 = fVar36;
            if (fVar36 <= fVar33) {
                fVar34 = fVar33;
            }
            if (fVar34 <= fVar35 - fVar3) goto code_r0x00018014c473;
        }
    }
    if ((((arg3 & 1U) == 0) || (fVar35 < fVar36 + (float)arg_28h)) || ((bVar24 && (bVar23)))) {
        bVar25 = false;
        if (!bVar24) goto code_r0x00018014c5e1;
        uVar31 = *(undefined4 *)(iVar26 + 0x1fb8);
        uVar4 = *(undefined4 *)(iVar26 + 0x1fbc);
        uVar5 = *(undefined4 *)(iVar26 + 0x1fc0);
        uVar6 = *(undefined4 *)(iVar26 + 0x1fc4);
        uVar7 = *(undefined4 *)(iVar26 + 0x1fc8);
        uVar8 = *(undefined4 *)(iVar26 + 0x1fcc);
        uVar9 = *(undefined4 *)(iVar26 + 0x1fd0);
        uVar10 = *(undefined4 *)(iVar26 + 0x1fd4);
        uVar11 = *(undefined4 *)(iVar26 + 0x1fd8);
        uVar12 = *(undefined4 *)(iVar26 + 0x1fdc);
        uVar13 = *(undefined4 *)(iVar26 + 0x1fe0);
        uVar14 = *(undefined4 *)(iVar26 + 0x1fe4);
        uVar15 = *(undefined4 *)(iVar26 + 0x1fe8);
        uVar16 = *(undefined4 *)(iVar26 + 0x1fec);
        uVar17 = *(undefined4 *)(iVar26 + 0x1ff0);
        uVar18 = *(undefined4 *)(iVar26 + 0x1ff4);
        uVar19 = *(undefined4 *)(iVar26 + 0x1ff8);
        uVar20 = *(undefined4 *)(iVar26 + 0x1ffc);
        uVar21 = *(undefined4 *)(iVar26 + 0x2000);
        uVar22 = *(undefined4 *)(iVar26 + 0x2004);
        uVar29 = func_0x00018013ac70(arg_38h & 0xffffffff, &arg_28h);
        *(undefined4 *)(iVar26 + 0x1fb8) = uVar31;
        *(undefined4 *)(iVar26 + 0x1fbc) = uVar4;
        *(undefined4 *)(iVar26 + 0x1fc0) = uVar5;
        *(undefined4 *)(iVar26 + 0x1fc4) = uVar6;
        *(undefined4 *)(iVar26 + 0x1fc8) = uVar7;
        *(undefined4 *)(iVar26 + 0x1fcc) = uVar8;
        *(undefined4 *)(iVar26 + 0x1fd0) = uVar9;
        *(undefined4 *)(iVar26 + 0x1fd4) = uVar10;
        *(undefined4 *)(iVar26 + 0x1fd8) = uVar11;
        *(undefined4 *)(iVar26 + 0x1fdc) = uVar12;
        *(undefined4 *)(iVar26 + 0x1fe0) = uVar13;
        *(undefined4 *)(iVar26 + 0x1fe4) = uVar14;
        *(undefined4 *)(iVar26 + 0x1fe8) = uVar15;
        *(undefined4 *)(iVar26 + 0x1fec) = uVar16;
        *(undefined4 *)(iVar26 + 0x1ff0) = uVar17;
        *(undefined4 *)(iVar26 + 0x1ff4) = uVar18;
        *(undefined4 *)(iVar26 + 0x1ff8) = uVar19;
        *(undefined4 *)(iVar26 + 0x1ffc) = uVar20;
        *(undefined4 *)(iVar26 + 0x2000) = uVar21;
        *(undefined4 *)(iVar26 + 0x2004) = uVar22;
        if ((!bVar23) || (((uint32_t)var_18h & 4) != 0)) goto code_r0x00018014c5e1;
        cVar30 = func_0x000180107ff0(2, 0, 0);
        bVar25 = false;
        if (cVar30 == '\0') goto code_r0x00018014c5e1;
        uVar29 = 1;
code_r0x00018014c6af:
        pfVar2 = (float *)(iVar26 + 0xe44 + ((uint64_t)(uint8_t)arg_40h ^ 1) * 4);
        fVar33 = (float)var_d8h;
        if (*pfVar2 <= 0.0 && *pfVar2 != 0.0) goto code_r0x00018014c5f5;
    } else {
        var_d0h = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1260);
        uStack_cc = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1264);
        uStack_c8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1268);
        fVar35 = arg_28h._4_4_ + fVar36 * 0.5;
        fVar33 = fVar36 * 0.5 + (float)arg_28h;
        var_c4h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x126c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar31 = func_0x0001800f5fa0(&var_d0h);
        func_0x000180130370(arg1, CONCAT44(fVar35, fVar33), uVar31);
        bVar25 = true;
code_r0x00018014c5e1:
        if (bVar24) {
            if (!bVar25) goto code_r0x00018014c6af;
        } else {
            fVar33 = (float)var_d8h;
            if (!bVar25) goto code_r0x00018014c611;
        }
code_r0x00018014c5f5:
        fVar36 = fVar36 * 0.9;
        fVar33 = (float)var_d8h - fVar36;
    }
    var_d8h._0_4_ = (float)var_d8h - fVar36;
code_r0x00018014c611:
    iVar26 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x1806238f0;
    *(undefined8 *)(iVar26 + 0x2a28) = 0x18063d7d8;
    func_0x0001800f7480(arg1, &var_e0h, &var_d8h, fVar33, iVar27, pcVar32, &var_10h);
    if (iVar28 != 0) {
        *(undefined *)iVar28 = uVar29;
    }
    return;
}

// ============================================================
// Function: FUN_18014c6e0
// Address: 0x18014c6e0
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8
fcn.18014c6e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h,
             undefined8 placeholder_7, int64_t arg_48h)
{
    undefined *puVar1;
    bool bVar2;
    int64_t iVar3;
    char cVar4;
    char cVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    char *pcVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    undefined8 extraout_XMM0_Qa;
    undefined8 extraout_XMM0_Qa_00;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)0x180781f28;
    fVar16 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    bVar2 = (int32_t)arg3 - 8U < 2;
    iVar8 = (int32_t)arg_30h - (int32_t)arg_28h;
    if ((int32_t)arg_30h <= (int32_t)arg_28h) {
        iVar8 = (int32_t)arg_28h - (int32_t)arg_30h;
    }
    fVar15 = (*(float *)(arg1 + 8) - *(float *)arg1) - 4.0;
    fVar11 = fVar16;
    if (((!bVar2) && (0.0 <= (float)iVar8)) && (fVar11 = fVar15 / ((float)iVar8 + 1.0), fVar11 <= fVar16)) {
        fVar11 = fVar16;
    }
    if (fVar15 <= fVar11) {
        fVar11 = fVar15;
    }
    fVar17 = fVar11 * 0.5;
    fVar16 = *(float *)arg1 + 2.0 + fVar17;
    fVar18 = (*(float *)(arg1 + 8) - 2.0) - fVar17;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == (int32_t)arg2) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
            if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
code_r0x00018014c844:
                func_0x0001800f9f30(0, 0);
            } else {
                fVar13 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                    fVar12 = (float)func_0x00018014d300(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                        arg_30h & 0xffffffff, 0, 0);
                    fVar12 = fVar12 * (fVar18 - fVar16) + fVar16;
                    if (((fVar13 < (fVar12 - fVar17) - 1.0) || (fVar12 + fVar17 + 1.0 < fVar13)) || (!bVar2)) {
                        fVar12 = 0.0;
                    } else {
                        fVar12 = fVar13 - fVar12;
                    }
                    *(float *)(iVar3 + 0x2804) = fVar12;
                }
                fVar14 = 0.0;
                if (((0.0 < fVar15 - fVar11) &&
                    (fVar11 = ((fVar13 - *(float *)(iVar3 + 0x2804)) - fVar16) / (fVar15 - fVar11), 0.0 <= fVar11)) &&
                   (fVar14 = 1.0, fVar11 <= 1.0)) {
                    fVar14 = fVar11;
                }
code_r0x00018014cbcb:
                if ((*(uint32_t *)(iVar3 + 0x1fbc) & 0x800) == 0) {
                    iVar8 = func_0x00018014d600(arg3 & 0xffffffff, fVar14, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    if (bVar2) {
                        iVar8 = func_0x00018014d8a0(arg_38h);
                    }
                    if (*(int32_t *)arg4 != iVar8) {
                        *(int32_t *)arg4 = iVar8;
                        uVar9 = 1;
                        goto code_r0x00018014c85f;
                    }
                }
            }
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
            puVar1 = (undefined *)(*(int64_t *)0x180781f28 + 0x280c);
            if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) == '\0') {
                fVar11 = *(float *)(*(int64_t *)0x180781f28 + 0x2808);
            } else {
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                fVar11 = 0.0;
                *puVar1 = 0;
            }
            fVar13 = (float)func_0x00018010f200(0);
            if (fVar13 != 0.0) {
                iVar6 = *(int32_t *)(iVar3 + 0x2228);
                uVar9 = 0x1000;
                if (iVar6 == 3) {
                    uVar9 = 0x282;
                }
                cVar4 = func_0x000180107d30(uVar9, 0);
                uVar9 = 0x2000;
                if (iVar6 == 3) {
                    uVar9 = 0x283;
                }
                cVar5 = func_0x000180107d30(uVar9, 0);
                fVar11 = 10.0;
                if ((bVar2) && (iVar6 = func_0x00018013f990(arg_38h), 0 < iVar6)) {
                    fVar13 = fVar13 / 100.0;
                    if (cVar4 != '\0') {
                        fVar13 = fVar13 / fVar11;
                    }
                } else {
                    fVar12 = (float)iVar8;
                    if (((-100.0 <= fVar12) && ((fVar12 <= 100.0 && (fVar12 != 0.0)))) || (cVar4 != '\0')) {
                        if (0.0 <= fVar13) {
                            fVar13 = 1.0 / fVar12;
                        } else {
                            fVar13 = -1.0 / fVar12;
                        }
                    } else {
                        fVar13 = fVar13 / 100.0;
                    }
                }
                if (cVar5 != '\0') {
                    fVar13 = fVar13 * fVar11;
                }
                fVar11 = fVar13 + *(float *)(iVar3 + 0x2808);
                *(undefined *)(iVar3 + 0x280c) = 1;
                *(float *)(iVar3 + 0x2808) = fVar11;
            }
            if ((*(int32_t *)(iVar3 + 0x21f4) == (int32_t)arg2) && (*(char *)(iVar3 + 0x1660) == '\0'))
            goto code_r0x00018014c844;
            pcVar10 = (char *)(iVar3 + 0x280c);
            if (*pcVar10 != '\0') {
                fVar13 = (float)func_0x00018014d300();
                if (((fVar13 < 1.0) || (fVar11 <= 0.0)) && ((0.0 < fVar13 || (0.0 <= fVar11)))) {
                    fVar12 = fVar11 + fVar13;
                    if (0.0 <= fVar12) {
                        fVar14 = 1.0;
                        if (fVar12 <= 1.0) {
                            fVar14 = fVar12;
                        }
                    } else {
                        fVar14 = 0.0;
                    }
                    uVar7 = func_0x00018014d600(arg3 & 0xffffffff, fVar14, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    uVar9 = extraout_XMM0_Qa;
                    if (bVar2) {
                        uVar7 = func_0x00018014d8a0(arg_38h);
                        uVar9 = extraout_XMM0_Qa_00;
                    }
                    fVar12 = (float)func_0x00018014d300(uVar9, uVar7, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0);
                    fVar12 = fVar12 - fVar13;
                    if (fVar11 <= 0.0) {
                        if (fVar12 <= fVar11) {
                            fVar12 = fVar11;
                        }
                    } else if (fVar11 <= fVar12) {
                        fVar12 = fVar11;
                    }
                    *(float *)(iVar3 + 0x2808) = *(float *)(iVar3 + 0x2808) - fVar12;
                    *pcVar10 = '\0';
                    goto code_r0x00018014cbcb;
                }
                *(undefined4 *)(iVar3 + 0x2808) = 0;
                *pcVar10 = '\0';
            }
        }
    }
    uVar9 = 0;
code_r0x00018014c85f:
    if (1.0 <= fVar15) {
        fVar13 = (float)func_0x00018014d300(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
        ;
        fVar15 = *(float *)(arg1 + 0xc) - 2.0;
        fVar11 = *(float *)(arg1 + 4) + 2.0;
        fVar16 = fVar13 * (fVar18 - fVar16) + fVar16;
        fVar18 = fVar16 - fVar17;
        fVar16 = fVar16 + fVar17;
    } else {
        fVar16 = *(float *)arg1;
        fVar11 = *(float *)(arg1 + 4);
        fVar18 = fVar16;
        fVar15 = fVar11;
    }
    *(float *)arg_48h = fVar18;
    *(float *)(arg_48h + 4) = fVar11;
    *(float *)(arg_48h + 8) = fVar16;
    *(float *)(arg_48h + 0xc) = fVar15;
    return uVar9;
}

// ============================================================
// Function: FUN_18014c74a
// Address: 0x18014c74a
// Size: 360 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8
fcn.18014c6e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h,
             undefined8 placeholder_7, int64_t arg_48h)
{
    undefined *puVar1;
    bool bVar2;
    int64_t iVar3;
    char cVar4;
    char cVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    char *pcVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    undefined8 extraout_XMM0_Qa;
    undefined8 extraout_XMM0_Qa_00;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)0x180781f28;
    fVar16 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    bVar2 = (int32_t)arg3 - 8U < 2;
    iVar8 = (int32_t)arg_30h - (int32_t)arg_28h;
    if ((int32_t)arg_30h <= (int32_t)arg_28h) {
        iVar8 = (int32_t)arg_28h - (int32_t)arg_30h;
    }
    fVar15 = (*(float *)(arg1 + 8) - *(float *)arg1) - 4.0;
    fVar11 = fVar16;
    if (((!bVar2) && (0.0 <= (float)iVar8)) && (fVar11 = fVar15 / ((float)iVar8 + 1.0), fVar11 <= fVar16)) {
        fVar11 = fVar16;
    }
    if (fVar15 <= fVar11) {
        fVar11 = fVar15;
    }
    fVar17 = fVar11 * 0.5;
    fVar16 = *(float *)arg1 + 2.0 + fVar17;
    fVar18 = (*(float *)(arg1 + 8) - 2.0) - fVar17;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == (int32_t)arg2) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
            if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
code_r0x00018014c844:
                func_0x0001800f9f30(0, 0);
            } else {
                fVar13 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                    fVar12 = (float)func_0x00018014d300(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                        arg_30h & 0xffffffff, 0, 0);
                    fVar12 = fVar12 * (fVar18 - fVar16) + fVar16;
                    if (((fVar13 < (fVar12 - fVar17) - 1.0) || (fVar12 + fVar17 + 1.0 < fVar13)) || (!bVar2)) {
                        fVar12 = 0.0;
                    } else {
                        fVar12 = fVar13 - fVar12;
                    }
                    *(float *)(iVar3 + 0x2804) = fVar12;
                }
                fVar14 = 0.0;
                if (((0.0 < fVar15 - fVar11) &&
                    (fVar11 = ((fVar13 - *(float *)(iVar3 + 0x2804)) - fVar16) / (fVar15 - fVar11), 0.0 <= fVar11)) &&
                   (fVar14 = 1.0, fVar11 <= 1.0)) {
                    fVar14 = fVar11;
                }
code_r0x00018014cbcb:
                if ((*(uint32_t *)(iVar3 + 0x1fbc) & 0x800) == 0) {
                    iVar8 = func_0x00018014d600(arg3 & 0xffffffff, fVar14, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    if (bVar2) {
                        iVar8 = func_0x00018014d8a0(arg_38h);
                    }
                    if (*(int32_t *)arg4 != iVar8) {
                        *(int32_t *)arg4 = iVar8;
                        uVar9 = 1;
                        goto code_r0x00018014c85f;
                    }
                }
            }
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
            puVar1 = (undefined *)(*(int64_t *)0x180781f28 + 0x280c);
            if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) == '\0') {
                fVar11 = *(float *)(*(int64_t *)0x180781f28 + 0x2808);
            } else {
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                fVar11 = 0.0;
                *puVar1 = 0;
            }
            fVar13 = (float)func_0x00018010f200(0);
            if (fVar13 != 0.0) {
                iVar6 = *(int32_t *)(iVar3 + 0x2228);
                uVar9 = 0x1000;
                if (iVar6 == 3) {
                    uVar9 = 0x282;
                }
                cVar4 = func_0x000180107d30(uVar9, 0);
                uVar9 = 0x2000;
                if (iVar6 == 3) {
                    uVar9 = 0x283;
                }
                cVar5 = func_0x000180107d30(uVar9, 0);
                fVar11 = 10.0;
                if ((bVar2) && (iVar6 = func_0x00018013f990(arg_38h), 0 < iVar6)) {
                    fVar13 = fVar13 / 100.0;
                    if (cVar4 != '\0') {
                        fVar13 = fVar13 / fVar11;
                    }
                } else {
                    fVar12 = (float)iVar8;
                    if (((-100.0 <= fVar12) && ((fVar12 <= 100.0 && (fVar12 != 0.0)))) || (cVar4 != '\0')) {
                        if (0.0 <= fVar13) {
                            fVar13 = 1.0 / fVar12;
                        } else {
                            fVar13 = -1.0 / fVar12;
                        }
                    } else {
                        fVar13 = fVar13 / 100.0;
                    }
                }
                if (cVar5 != '\0') {
                    fVar13 = fVar13 * fVar11;
                }
                fVar11 = fVar13 + *(float *)(iVar3 + 0x2808);
                *(undefined *)(iVar3 + 0x280c) = 1;
                *(float *)(iVar3 + 0x2808) = fVar11;
            }
            if ((*(int32_t *)(iVar3 + 0x21f4) == (int32_t)arg2) && (*(char *)(iVar3 + 0x1660) == '\0'))
            goto code_r0x00018014c844;
            pcVar10 = (char *)(iVar3 + 0x280c);
            if (*pcVar10 != '\0') {
                fVar13 = (float)func_0x00018014d300();
                if (((fVar13 < 1.0) || (fVar11 <= 0.0)) && ((0.0 < fVar13 || (0.0 <= fVar11)))) {
                    fVar12 = fVar11 + fVar13;
                    if (0.0 <= fVar12) {
                        fVar14 = 1.0;
                        if (fVar12 <= 1.0) {
                            fVar14 = fVar12;
                        }
                    } else {
                        fVar14 = 0.0;
                    }
                    uVar7 = func_0x00018014d600(arg3 & 0xffffffff, fVar14, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    uVar9 = extraout_XMM0_Qa;
                    if (bVar2) {
                        uVar7 = func_0x00018014d8a0(arg_38h);
                        uVar9 = extraout_XMM0_Qa_00;
                    }
                    fVar12 = (float)func_0x00018014d300(uVar9, uVar7, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0);
                    fVar12 = fVar12 - fVar13;
                    if (fVar11 <= 0.0) {
                        if (fVar12 <= fVar11) {
                            fVar12 = fVar11;
                        }
                    } else if (fVar11 <= fVar12) {
                        fVar12 = fVar11;
                    }
                    *(float *)(iVar3 + 0x2808) = *(float *)(iVar3 + 0x2808) - fVar12;
                    *pcVar10 = '\0';
                    goto code_r0x00018014cbcb;
                }
                *(undefined4 *)(iVar3 + 0x2808) = 0;
                *pcVar10 = '\0';
            }
        }
    }
    uVar9 = 0;
code_r0x00018014c85f:
    if (1.0 <= fVar15) {
        fVar13 = (float)func_0x00018014d300(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
        ;
        fVar15 = *(float *)(arg1 + 0xc) - 2.0;
        fVar11 = *(float *)(arg1 + 4) + 2.0;
        fVar16 = fVar13 * (fVar18 - fVar16) + fVar16;
        fVar18 = fVar16 - fVar17;
        fVar16 = fVar16 + fVar17;
    } else {
        fVar16 = *(float *)arg1;
        fVar11 = *(float *)(arg1 + 4);
        fVar18 = fVar16;
        fVar15 = fVar11;
    }
    *(float *)arg_48h = fVar18;
    *(float *)(arg_48h + 4) = fVar11;
    *(float *)(arg_48h + 8) = fVar16;
    *(float *)(arg_48h + 0xc) = fVar15;
    return uVar9;
}

// ============================================================
// Function: FUN_18014c8b2
// Address: 0x18014c8b2
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8
fcn.18014c6e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h,
             undefined8 placeholder_7, int64_t arg_48h)
{
    undefined *puVar1;
    bool bVar2;
    int64_t iVar3;
    char cVar4;
    char cVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    char *pcVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    undefined8 extraout_XMM0_Qa;
    undefined8 extraout_XMM0_Qa_00;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)0x180781f28;
    fVar16 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    bVar2 = (int32_t)arg3 - 8U < 2;
    iVar8 = (int32_t)arg_30h - (int32_t)arg_28h;
    if ((int32_t)arg_30h <= (int32_t)arg_28h) {
        iVar8 = (int32_t)arg_28h - (int32_t)arg_30h;
    }
    fVar15 = (*(float *)(arg1 + 8) - *(float *)arg1) - 4.0;
    fVar11 = fVar16;
    if (((!bVar2) && (0.0 <= (float)iVar8)) && (fVar11 = fVar15 / ((float)iVar8 + 1.0), fVar11 <= fVar16)) {
        fVar11 = fVar16;
    }
    if (fVar15 <= fVar11) {
        fVar11 = fVar15;
    }
    fVar17 = fVar11 * 0.5;
    fVar16 = *(float *)arg1 + 2.0 + fVar17;
    fVar18 = (*(float *)(arg1 + 8) - 2.0) - fVar17;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == (int32_t)arg2) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
            if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
code_r0x00018014c844:
                func_0x0001800f9f30(0, 0);
            } else {
                fVar13 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                    fVar12 = (float)func_0x00018014d300(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                        arg_30h & 0xffffffff, 0, 0);
                    fVar12 = fVar12 * (fVar18 - fVar16) + fVar16;
                    if (((fVar13 < (fVar12 - fVar17) - 1.0) || (fVar12 + fVar17 + 1.0 < fVar13)) || (!bVar2)) {
                        fVar12 = 0.0;
                    } else {
                        fVar12 = fVar13 - fVar12;
                    }
                    *(float *)(iVar3 + 0x2804) = fVar12;
                }
                fVar14 = 0.0;
                if (((0.0 < fVar15 - fVar11) &&
                    (fVar11 = ((fVar13 - *(float *)(iVar3 + 0x2804)) - fVar16) / (fVar15 - fVar11), 0.0 <= fVar11)) &&
                   (fVar14 = 1.0, fVar11 <= 1.0)) {
                    fVar14 = fVar11;
                }
code_r0x00018014cbcb:
                if ((*(uint32_t *)(iVar3 + 0x1fbc) & 0x800) == 0) {
                    iVar8 = func_0x00018014d600(arg3 & 0xffffffff, fVar14, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    if (bVar2) {
                        iVar8 = func_0x00018014d8a0(arg_38h);
                    }
                    if (*(int32_t *)arg4 != iVar8) {
                        *(int32_t *)arg4 = iVar8;
                        uVar9 = 1;
                        goto code_r0x00018014c85f;
                    }
                }
            }
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
            puVar1 = (undefined *)(*(int64_t *)0x180781f28 + 0x280c);
            if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) == '\0') {
                fVar11 = *(float *)(*(int64_t *)0x180781f28 + 0x2808);
            } else {
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                fVar11 = 0.0;
                *puVar1 = 0;
            }
            fVar13 = (float)func_0x00018010f200(0);
            if (fVar13 != 0.0) {
                iVar6 = *(int32_t *)(iVar3 + 0x2228);
                uVar9 = 0x1000;
                if (iVar6 == 3) {
                    uVar9 = 0x282;
                }
                cVar4 = func_0x000180107d30(uVar9, 0);
                uVar9 = 0x2000;
                if (iVar6 == 3) {
                    uVar9 = 0x283;
                }
                cVar5 = func_0x000180107d30(uVar9, 0);
                fVar11 = 10.0;
                if ((bVar2) && (iVar6 = func_0x00018013f990(arg_38h), 0 < iVar6)) {
                    fVar13 = fVar13 / 100.0;
                    if (cVar4 != '\0') {
                        fVar13 = fVar13 / fVar11;
                    }
                } else {
                    fVar12 = (float)iVar8;
                    if (((-100.0 <= fVar12) && ((fVar12 <= 100.0 && (fVar12 != 0.0)))) || (cVar4 != '\0')) {
                        if (0.0 <= fVar13) {
                            fVar13 = 1.0 / fVar12;
                        } else {
                            fVar13 = -1.0 / fVar12;
                        }
                    } else {
                        fVar13 = fVar13 / 100.0;
                    }
                }
                if (cVar5 != '\0') {
                    fVar13 = fVar13 * fVar11;
                }
                fVar11 = fVar13 + *(float *)(iVar3 + 0x2808);
                *(undefined *)(iVar3 + 0x280c) = 1;
                *(float *)(iVar3 + 0x2808) = fVar11;
            }
            if ((*(int32_t *)(iVar3 + 0x21f4) == (int32_t)arg2) && (*(char *)(iVar3 + 0x1660) == '\0'))
            goto code_r0x00018014c844;
            pcVar10 = (char *)(iVar3 + 0x280c);
            if (*pcVar10 != '\0') {
                fVar13 = (float)func_0x00018014d300();
                if (((fVar13 < 1.0) || (fVar11 <= 0.0)) && ((0.0 < fVar13 || (0.0 <= fVar11)))) {
                    fVar12 = fVar11 + fVar13;
                    if (0.0 <= fVar12) {
                        fVar14 = 1.0;
                        if (fVar12 <= 1.0) {
                            fVar14 = fVar12;
                        }
                    } else {
                        fVar14 = 0.0;
                    }
                    uVar7 = func_0x00018014d600(arg3 & 0xffffffff, fVar14, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    uVar9 = extraout_XMM0_Qa;
                    if (bVar2) {
                        uVar7 = func_0x00018014d8a0(arg_38h);
                        uVar9 = extraout_XMM0_Qa_00;
                    }
                    fVar12 = (float)func_0x00018014d300(uVar9, uVar7, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0);
                    fVar12 = fVar12 - fVar13;
                    if (fVar11 <= 0.0) {
                        if (fVar12 <= fVar11) {
                            fVar12 = fVar11;
                        }
                    } else if (fVar11 <= fVar12) {
                        fVar12 = fVar11;
                    }
                    *(float *)(iVar3 + 0x2808) = *(float *)(iVar3 + 0x2808) - fVar12;
                    *pcVar10 = '\0';
                    goto code_r0x00018014cbcb;
                }
                *(undefined4 *)(iVar3 + 0x2808) = 0;
                *pcVar10 = '\0';
            }
        }
    }
    uVar9 = 0;
code_r0x00018014c85f:
    if (1.0 <= fVar15) {
        fVar13 = (float)func_0x00018014d300(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
        ;
        fVar15 = *(float *)(arg1 + 0xc) - 2.0;
        fVar11 = *(float *)(arg1 + 4) + 2.0;
        fVar16 = fVar13 * (fVar18 - fVar16) + fVar16;
        fVar18 = fVar16 - fVar17;
        fVar16 = fVar16 + fVar17;
    } else {
        fVar16 = *(float *)arg1;
        fVar11 = *(float *)(arg1 + 4);
        fVar18 = fVar16;
        fVar15 = fVar11;
    }
    *(float *)arg_48h = fVar18;
    *(float *)(arg_48h + 4) = fVar11;
    *(float *)(arg_48h + 8) = fVar16;
    *(float *)(arg_48h + 0xc) = fVar15;
    return uVar9;
}

// ============================================================
// Function: FUN_18014c8c6
// Address: 0x18014c8c6
// Size: 874 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8
fcn.18014c6e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h,
             undefined8 placeholder_7, int64_t arg_48h)
{
    undefined *puVar1;
    bool bVar2;
    int64_t iVar3;
    char cVar4;
    char cVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    char *pcVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    undefined8 extraout_XMM0_Qa;
    undefined8 extraout_XMM0_Qa_00;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)0x180781f28;
    fVar16 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    bVar2 = (int32_t)arg3 - 8U < 2;
    iVar8 = (int32_t)arg_30h - (int32_t)arg_28h;
    if ((int32_t)arg_30h <= (int32_t)arg_28h) {
        iVar8 = (int32_t)arg_28h - (int32_t)arg_30h;
    }
    fVar15 = (*(float *)(arg1 + 8) - *(float *)arg1) - 4.0;
    fVar11 = fVar16;
    if (((!bVar2) && (0.0 <= (float)iVar8)) && (fVar11 = fVar15 / ((float)iVar8 + 1.0), fVar11 <= fVar16)) {
        fVar11 = fVar16;
    }
    if (fVar15 <= fVar11) {
        fVar11 = fVar15;
    }
    fVar17 = fVar11 * 0.5;
    fVar16 = *(float *)arg1 + 2.0 + fVar17;
    fVar18 = (*(float *)(arg1 + 8) - 2.0) - fVar17;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == (int32_t)arg2) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
            if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
code_r0x00018014c844:
                func_0x0001800f9f30(0, 0);
            } else {
                fVar13 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                    fVar12 = (float)func_0x00018014d300(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                        arg_30h & 0xffffffff, 0, 0);
                    fVar12 = fVar12 * (fVar18 - fVar16) + fVar16;
                    if (((fVar13 < (fVar12 - fVar17) - 1.0) || (fVar12 + fVar17 + 1.0 < fVar13)) || (!bVar2)) {
                        fVar12 = 0.0;
                    } else {
                        fVar12 = fVar13 - fVar12;
                    }
                    *(float *)(iVar3 + 0x2804) = fVar12;
                }
                fVar14 = 0.0;
                if (((0.0 < fVar15 - fVar11) &&
                    (fVar11 = ((fVar13 - *(float *)(iVar3 + 0x2804)) - fVar16) / (fVar15 - fVar11), 0.0 <= fVar11)) &&
                   (fVar14 = 1.0, fVar11 <= 1.0)) {
                    fVar14 = fVar11;
                }
code_r0x00018014cbcb:
                if ((*(uint32_t *)(iVar3 + 0x1fbc) & 0x800) == 0) {
                    iVar8 = func_0x00018014d600(arg3 & 0xffffffff, fVar14, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    if (bVar2) {
                        iVar8 = func_0x00018014d8a0(arg_38h);
                    }
                    if (*(int32_t *)arg4 != iVar8) {
                        *(int32_t *)arg4 = iVar8;
                        uVar9 = 1;
                        goto code_r0x00018014c85f;
                    }
                }
            }
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
            puVar1 = (undefined *)(*(int64_t *)0x180781f28 + 0x280c);
            if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) == '\0') {
                fVar11 = *(float *)(*(int64_t *)0x180781f28 + 0x2808);
            } else {
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                fVar11 = 0.0;
                *puVar1 = 0;
            }
            fVar13 = (float)func_0x00018010f200(0);
            if (fVar13 != 0.0) {
                iVar6 = *(int32_t *)(iVar3 + 0x2228);
                uVar9 = 0x1000;
                if (iVar6 == 3) {
                    uVar9 = 0x282;
                }
                cVar4 = func_0x000180107d30(uVar9, 0);
                uVar9 = 0x2000;
                if (iVar6 == 3) {
                    uVar9 = 0x283;
                }
                cVar5 = func_0x000180107d30(uVar9, 0);
                fVar11 = 10.0;
                if ((bVar2) && (iVar6 = func_0x00018013f990(arg_38h), 0 < iVar6)) {
                    fVar13 = fVar13 / 100.0;
                    if (cVar4 != '\0') {
                        fVar13 = fVar13 / fVar11;
                    }
                } else {
                    fVar12 = (float)iVar8;
                    if (((-100.0 <= fVar12) && ((fVar12 <= 100.0 && (fVar12 != 0.0)))) || (cVar4 != '\0')) {
                        if (0.0 <= fVar13) {
                            fVar13 = 1.0 / fVar12;
                        } else {
                            fVar13 = -1.0 / fVar12;
                        }
                    } else {
                        fVar13 = fVar13 / 100.0;
                    }
                }
                if (cVar5 != '\0') {
                    fVar13 = fVar13 * fVar11;
                }
                fVar11 = fVar13 + *(float *)(iVar3 + 0x2808);
                *(undefined *)(iVar3 + 0x280c) = 1;
                *(float *)(iVar3 + 0x2808) = fVar11;
            }
            if ((*(int32_t *)(iVar3 + 0x21f4) == (int32_t)arg2) && (*(char *)(iVar3 + 0x1660) == '\0'))
            goto code_r0x00018014c844;
            pcVar10 = (char *)(iVar3 + 0x280c);
            if (*pcVar10 != '\0') {
                fVar13 = (float)func_0x00018014d300();
                if (((fVar13 < 1.0) || (fVar11 <= 0.0)) && ((0.0 < fVar13 || (0.0 <= fVar11)))) {
                    fVar12 = fVar11 + fVar13;
                    if (0.0 <= fVar12) {
                        fVar14 = 1.0;
                        if (fVar12 <= 1.0) {
                            fVar14 = fVar12;
                        }
                    } else {
                        fVar14 = 0.0;
                    }
                    uVar7 = func_0x00018014d600(arg3 & 0xffffffff, fVar14, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    uVar9 = extraout_XMM0_Qa;
                    if (bVar2) {
                        uVar7 = func_0x00018014d8a0(arg_38h);
                        uVar9 = extraout_XMM0_Qa_00;
                    }
                    fVar12 = (float)func_0x00018014d300(uVar9, uVar7, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0);
                    fVar12 = fVar12 - fVar13;
                    if (fVar11 <= 0.0) {
                        if (fVar12 <= fVar11) {
                            fVar12 = fVar11;
                        }
                    } else if (fVar11 <= fVar12) {
                        fVar12 = fVar11;
                    }
                    *(float *)(iVar3 + 0x2808) = *(float *)(iVar3 + 0x2808) - fVar12;
                    *pcVar10 = '\0';
                    goto code_r0x00018014cbcb;
                }
                *(undefined4 *)(iVar3 + 0x2808) = 0;
                *pcVar10 = '\0';
            }
        }
    }
    uVar9 = 0;
code_r0x00018014c85f:
    if (1.0 <= fVar15) {
        fVar13 = (float)func_0x00018014d300(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
        ;
        fVar15 = *(float *)(arg1 + 0xc) - 2.0;
        fVar11 = *(float *)(arg1 + 4) + 2.0;
        fVar16 = fVar13 * (fVar18 - fVar16) + fVar16;
        fVar18 = fVar16 - fVar17;
        fVar16 = fVar16 + fVar17;
    } else {
        fVar16 = *(float *)arg1;
        fVar11 = *(float *)(arg1 + 4);
        fVar18 = fVar16;
        fVar15 = fVar11;
    }
    *(float *)arg_48h = fVar18;
    *(float *)(arg_48h + 4) = fVar11;
    *(float *)(arg_48h + 8) = fVar16;
    *(float *)(arg_48h + 0xc) = fVar15;
    return uVar9;
}

// ============================================================
// Function: FUN_18014cc30
// Address: 0x18014cc30
// Size: 177 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8
fcn.18014c6e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h,
             undefined8 placeholder_7, int64_t arg_48h)
{
    undefined *puVar1;
    bool bVar2;
    int64_t iVar3;
    char cVar4;
    char cVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    char *pcVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    undefined8 extraout_XMM0_Qa;
    undefined8 extraout_XMM0_Qa_00;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)0x180781f28;
    fVar16 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    bVar2 = (int32_t)arg3 - 8U < 2;
    iVar8 = (int32_t)arg_30h - (int32_t)arg_28h;
    if ((int32_t)arg_30h <= (int32_t)arg_28h) {
        iVar8 = (int32_t)arg_28h - (int32_t)arg_30h;
    }
    fVar15 = (*(float *)(arg1 + 8) - *(float *)arg1) - 4.0;
    fVar11 = fVar16;
    if (((!bVar2) && (0.0 <= (float)iVar8)) && (fVar11 = fVar15 / ((float)iVar8 + 1.0), fVar11 <= fVar16)) {
        fVar11 = fVar16;
    }
    if (fVar15 <= fVar11) {
        fVar11 = fVar15;
    }
    fVar17 = fVar11 * 0.5;
    fVar16 = *(float *)arg1 + 2.0 + fVar17;
    fVar18 = (*(float *)(arg1 + 8) - 2.0) - fVar17;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == (int32_t)arg2) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
            if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
code_r0x00018014c844:
                func_0x0001800f9f30(0, 0);
            } else {
                fVar13 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                    fVar12 = (float)func_0x00018014d300(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                        arg_30h & 0xffffffff, 0, 0);
                    fVar12 = fVar12 * (fVar18 - fVar16) + fVar16;
                    if (((fVar13 < (fVar12 - fVar17) - 1.0) || (fVar12 + fVar17 + 1.0 < fVar13)) || (!bVar2)) {
                        fVar12 = 0.0;
                    } else {
                        fVar12 = fVar13 - fVar12;
                    }
                    *(float *)(iVar3 + 0x2804) = fVar12;
                }
                fVar14 = 0.0;
                if (((0.0 < fVar15 - fVar11) &&
                    (fVar11 = ((fVar13 - *(float *)(iVar3 + 0x2804)) - fVar16) / (fVar15 - fVar11), 0.0 <= fVar11)) &&
                   (fVar14 = 1.0, fVar11 <= 1.0)) {
                    fVar14 = fVar11;
                }
code_r0x00018014cbcb:
                if ((*(uint32_t *)(iVar3 + 0x1fbc) & 0x800) == 0) {
                    iVar8 = func_0x00018014d600(arg3 & 0xffffffff, fVar14, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    if (bVar2) {
                        iVar8 = func_0x00018014d8a0(arg_38h);
                    }
                    if (*(int32_t *)arg4 != iVar8) {
                        *(int32_t *)arg4 = iVar8;
                        uVar9 = 1;
                        goto code_r0x00018014c85f;
                    }
                }
            }
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
            puVar1 = (undefined *)(*(int64_t *)0x180781f28 + 0x280c);
            if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) == '\0') {
                fVar11 = *(float *)(*(int64_t *)0x180781f28 + 0x2808);
            } else {
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                fVar11 = 0.0;
                *puVar1 = 0;
            }
            fVar13 = (float)func_0x00018010f200(0);
            if (fVar13 != 0.0) {
                iVar6 = *(int32_t *)(iVar3 + 0x2228);
                uVar9 = 0x1000;
                if (iVar6 == 3) {
                    uVar9 = 0x282;
                }
                cVar4 = func_0x000180107d30(uVar9, 0);
                uVar9 = 0x2000;
                if (iVar6 == 3) {
                    uVar9 = 0x283;
                }
                cVar5 = func_0x000180107d30(uVar9, 0);
                fVar11 = 10.0;
                if ((bVar2) && (iVar6 = func_0x00018013f990(arg_38h), 0 < iVar6)) {
                    fVar13 = fVar13 / 100.0;
                    if (cVar4 != '\0') {
                        fVar13 = fVar13 / fVar11;
                    }
                } else {
                    fVar12 = (float)iVar8;
                    if (((-100.0 <= fVar12) && ((fVar12 <= 100.0 && (fVar12 != 0.0)))) || (cVar4 != '\0')) {
                        if (0.0 <= fVar13) {
                            fVar13 = 1.0 / fVar12;
                        } else {
                            fVar13 = -1.0 / fVar12;
                        }
                    } else {
                        fVar13 = fVar13 / 100.0;
                    }
                }
                if (cVar5 != '\0') {
                    fVar13 = fVar13 * fVar11;
                }
                fVar11 = fVar13 + *(float *)(iVar3 + 0x2808);
                *(undefined *)(iVar3 + 0x280c) = 1;
                *(float *)(iVar3 + 0x2808) = fVar11;
            }
            if ((*(int32_t *)(iVar3 + 0x21f4) == (int32_t)arg2) && (*(char *)(iVar3 + 0x1660) == '\0'))
            goto code_r0x00018014c844;
            pcVar10 = (char *)(iVar3 + 0x280c);
            if (*pcVar10 != '\0') {
                fVar13 = (float)func_0x00018014d300();
                if (((fVar13 < 1.0) || (fVar11 <= 0.0)) && ((0.0 < fVar13 || (0.0 <= fVar11)))) {
                    fVar12 = fVar11 + fVar13;
                    if (0.0 <= fVar12) {
                        fVar14 = 1.0;
                        if (fVar12 <= 1.0) {
                            fVar14 = fVar12;
                        }
                    } else {
                        fVar14 = 0.0;
                    }
                    uVar7 = func_0x00018014d600(arg3 & 0xffffffff, fVar14, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    uVar9 = extraout_XMM0_Qa;
                    if (bVar2) {
                        uVar7 = func_0x00018014d8a0(arg_38h);
                        uVar9 = extraout_XMM0_Qa_00;
                    }
                    fVar12 = (float)func_0x00018014d300(uVar9, uVar7, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0);
                    fVar12 = fVar12 - fVar13;
                    if (fVar11 <= 0.0) {
                        if (fVar12 <= fVar11) {
                            fVar12 = fVar11;
                        }
                    } else if (fVar11 <= fVar12) {
                        fVar12 = fVar11;
                    }
                    *(float *)(iVar3 + 0x2808) = *(float *)(iVar3 + 0x2808) - fVar12;
                    *pcVar10 = '\0';
                    goto code_r0x00018014cbcb;
                }
                *(undefined4 *)(iVar3 + 0x2808) = 0;
                *pcVar10 = '\0';
            }
        }
    }
    uVar9 = 0;
code_r0x00018014c85f:
    if (1.0 <= fVar15) {
        fVar13 = (float)func_0x00018014d300(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
        ;
        fVar15 = *(float *)(arg1 + 0xc) - 2.0;
        fVar11 = *(float *)(arg1 + 4) + 2.0;
        fVar16 = fVar13 * (fVar18 - fVar16) + fVar16;
        fVar18 = fVar16 - fVar17;
        fVar16 = fVar16 + fVar17;
    } else {
        fVar16 = *(float *)arg1;
        fVar11 = *(float *)(arg1 + 4);
        fVar18 = fVar16;
        fVar15 = fVar11;
    }
    *(float *)arg_48h = fVar18;
    *(float *)(arg_48h + 4) = fVar11;
    *(float *)(arg_48h + 8) = fVar16;
    *(float *)(arg_48h + 0xc) = fVar15;
    return uVar9;
}

// ============================================================
// Function: FUN_18014ccf0
// Address: 0x18014ccf0
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8
fcn.18014ccf0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h,
             undefined8 placeholder_7, int64_t arg_48h)
{
    undefined *puVar1;
    bool bVar2;
    uint32_t uVar3;
    int64_t iVar4;
    char cVar5;
    char cVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    char *pcVar10;
    uint64_t uVar11;
    float fVar12;
    float fVar13;
    float extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    fVar18 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    bVar2 = (int32_t)arg3 - 8U < 2;
    uVar3 = (uint32_t)arg_30h - (uint32_t)arg_28h;
    if ((uint32_t)arg_30h <= (uint32_t)arg_28h) {
        uVar3 = (uint32_t)arg_28h - (uint32_t)arg_30h;
    }
    uVar11 = (uint64_t)uVar3;
    fVar17 = (*(float *)(arg1 + 8) - *(float *)arg1) - 4.0;
    fVar12 = fVar18;
    if (((!bVar2) && (0.0 <= (float)uVar11)) && (fVar12 = fVar17 / ((float)uVar11 + 1.0), fVar12 <= fVar18)) {
        fVar12 = fVar18;
    }
    if (fVar17 <= fVar12) {
        fVar12 = fVar17;
    }
    fVar19 = fVar12 * 0.5;
    fVar18 = *(float *)arg1 + 2.0 + fVar19;
    fVar20 = (*(float *)(arg1 + 8) - 2.0) - fVar19;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == (int32_t)arg2) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
            if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
code_r0x00018014ce57:
                func_0x0001800f9f30(0, 0);
            } else {
                fVar15 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                    fVar13 = (float)func_0x00018014d930(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                        arg_30h & 0xffffffff, 0, 0);
                    fVar13 = fVar13 * (fVar20 - fVar18) + fVar18;
                    if (((fVar15 < (fVar13 - fVar19) - 1.0) || (fVar13 + fVar19 + 1.0 < fVar15)) || (!bVar2)) {
                        fVar13 = 0.0;
                    } else {
                        fVar13 = fVar15 - fVar13;
                    }
                    *(float *)(iVar4 + 0x2804) = fVar13;
                }
                fVar16 = 0.0;
                if (((0.0 < fVar17 - fVar12) &&
                    (fVar12 = ((fVar15 - *(float *)(iVar4 + 0x2804)) - fVar18) / (fVar17 - fVar12), 0.0 <= fVar12)) &&
                   (fVar16 = 1.0, fVar12 <= 1.0)) {
                    fVar16 = fVar12;
                }
code_r0x00018014d1e1:
                if ((*(uint32_t *)(iVar4 + 0x1fbc) & 0x800) == 0) {
                    iVar8 = func_0x00018014dc40(arg3 & 0xffffffff, fVar16, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    if (bVar2) {
                        iVar8 = func_0x00018014def0(arg_38h);
                    }
                    if (*(int32_t *)arg4 != iVar8) {
                        *(int32_t *)arg4 = iVar8;
                        uVar9 = 1;
                        goto code_r0x00018014ce72;
                    }
                }
            }
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
            puVar1 = (undefined *)(*(int64_t *)0x180781f28 + 0x280c);
            if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) == '\0') {
                fVar12 = *(float *)(*(int64_t *)0x180781f28 + 0x2808);
            } else {
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                fVar12 = 0.0;
                *puVar1 = 0;
            }
            fVar15 = (float)func_0x00018010f200(0);
            if (fVar15 != 0.0) {
                iVar8 = *(int32_t *)(iVar4 + 0x2228);
                uVar9 = 0x1000;
                if (iVar8 == 3) {
                    uVar9 = 0x282;
                }
                cVar5 = func_0x000180107d30(uVar9, 0);
                uVar9 = 0x2000;
                if (iVar8 == 3) {
                    uVar9 = 0x283;
                }
                cVar6 = func_0x000180107d30(uVar9, 0);
                fVar13 = 10.0;
                fVar12 = fVar15;
                if ((bVar2) && (iVar8 = func_0x00018013f990(arg_38h), fVar12 = fVar15, 0 < iVar8)) {
                    fVar12 = fVar15 / 100.0;
                    fVar15 = extraout_XMM0_Da;
                    if (cVar5 != '\0') {
                        fVar12 = fVar12 / fVar13;
                    }
                } else {
                    fVar15 = (float)(uVar11 & 0xffffffff);
                    if (((-100.0 <= fVar15) && ((fVar15 <= 100.0 && (fVar15 != 0.0)))) || (cVar5 != '\0')) {
                        if (0.0 <= fVar12) {
                            fVar12 = 1.0 / fVar15;
                        } else {
                            fVar12 = -1.0 / fVar15;
                        }
                    } else {
                        fVar12 = fVar12 / 100.0;
                    }
                }
                if (cVar6 != '\0') {
                    fVar12 = fVar12 * fVar13;
                }
                fVar12 = fVar12 + *(float *)(iVar4 + 0x2808);
                *(undefined *)(iVar4 + 0x280c) = 1;
                *(float *)(iVar4 + 0x2808) = fVar12;
            }
            if ((*(int32_t *)(iVar4 + 0x21f4) == (int32_t)arg2) && (*(char *)(iVar4 + 0x1660) == '\0'))
            goto code_r0x00018014ce57;
            pcVar10 = (char *)(iVar4 + 0x280c);
            if (*pcVar10 != '\0') {
                fVar15 = (float)func_0x00018014d930(fVar15, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                    arg_30h & 0xffffffff, 0, 0);
                if (((fVar15 < 1.0) || (fVar12 <= 0.0)) && ((0.0 < fVar15 || (0.0 <= fVar12)))) {
                    fVar13 = fVar12 + fVar15;
                    if (0.0 <= fVar13) {
                        fVar16 = 1.0;
                        if (fVar13 <= 1.0) {
                            fVar16 = fVar13;
                        }
                    } else {
                        fVar16 = 0.0;
                    }
                    uVar7 = func_0x00018014dc40(arg3 & 0xffffffff, fVar16, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    uVar14 = extraout_XMM0_Da_00;
                    if (bVar2) {
                        uVar7 = func_0x00018014def0(arg_38h);
                        uVar14 = extraout_XMM0_Da_01;
                    }
                    fVar13 = (float)func_0x00018014d930(uVar14, uVar7, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
                    ;
                    fVar13 = fVar13 - fVar15;
                    if (fVar12 <= 0.0) {
                        if (fVar13 <= fVar12) {
                            fVar13 = fVar12;
                        }
                    } else if (fVar12 <= fVar13) {
                        fVar13 = fVar12;
                    }
                    *(float *)(iVar4 + 0x2808) = *(float *)(iVar4 + 0x2808) - fVar13;
                    *pcVar10 = '\0';
                    goto code_r0x00018014d1e1;
                }
                *(undefined4 *)(iVar4 + 0x2808) = 0;
                *pcVar10 = '\0';
            }
        }
    }
    uVar9 = 0;
code_r0x00018014ce72:
    if (1.0 <= fVar17) {
        fVar17 = (float)func_0x00018014d930(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
        ;
        fVar12 = *(float *)(arg1 + 0xc) - 2.0;
        fVar15 = *(float *)(arg1 + 4) + 2.0;
        fVar18 = fVar17 * (fVar20 - fVar18) + fVar18;
        fVar17 = fVar18 - fVar19;
        fVar18 = fVar18 + fVar19;
    } else {
        fVar18 = *(float *)arg1;
        fVar12 = *(float *)(arg1 + 4);
        fVar17 = fVar18;
        fVar15 = fVar12;
    }
    *(float *)arg_48h = fVar17;
    *(float *)(arg_48h + 4) = fVar15;
    *(float *)(arg_48h + 8) = fVar18;
    *(float *)(arg_48h + 0xc) = fVar12;
    return uVar9;
}

// ============================================================
// Function: FUN_18014cd5a
// Address: 0x18014cd5a
// Size: 363 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8
fcn.18014ccf0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h,
             undefined8 placeholder_7, int64_t arg_48h)
{
    undefined *puVar1;
    bool bVar2;
    uint32_t uVar3;
    int64_t iVar4;
    char cVar5;
    char cVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    char *pcVar10;
    uint64_t uVar11;
    float fVar12;
    float fVar13;
    float extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    fVar18 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    bVar2 = (int32_t)arg3 - 8U < 2;
    uVar3 = (uint32_t)arg_30h - (uint32_t)arg_28h;
    if ((uint32_t)arg_30h <= (uint32_t)arg_28h) {
        uVar3 = (uint32_t)arg_28h - (uint32_t)arg_30h;
    }
    uVar11 = (uint64_t)uVar3;
    fVar17 = (*(float *)(arg1 + 8) - *(float *)arg1) - 4.0;
    fVar12 = fVar18;
    if (((!bVar2) && (0.0 <= (float)uVar11)) && (fVar12 = fVar17 / ((float)uVar11 + 1.0), fVar12 <= fVar18)) {
        fVar12 = fVar18;
    }
    if (fVar17 <= fVar12) {
        fVar12 = fVar17;
    }
    fVar19 = fVar12 * 0.5;
    fVar18 = *(float *)arg1 + 2.0 + fVar19;
    fVar20 = (*(float *)(arg1 + 8) - 2.0) - fVar19;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == (int32_t)arg2) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
            if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
code_r0x00018014ce57:
                func_0x0001800f9f30(0, 0);
            } else {
                fVar15 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                    fVar13 = (float)func_0x00018014d930(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                        arg_30h & 0xffffffff, 0, 0);
                    fVar13 = fVar13 * (fVar20 - fVar18) + fVar18;
                    if (((fVar15 < (fVar13 - fVar19) - 1.0) || (fVar13 + fVar19 + 1.0 < fVar15)) || (!bVar2)) {
                        fVar13 = 0.0;
                    } else {
                        fVar13 = fVar15 - fVar13;
                    }
                    *(float *)(iVar4 + 0x2804) = fVar13;
                }
                fVar16 = 0.0;
                if (((0.0 < fVar17 - fVar12) &&
                    (fVar12 = ((fVar15 - *(float *)(iVar4 + 0x2804)) - fVar18) / (fVar17 - fVar12), 0.0 <= fVar12)) &&
                   (fVar16 = 1.0, fVar12 <= 1.0)) {
                    fVar16 = fVar12;
                }
code_r0x00018014d1e1:
                if ((*(uint32_t *)(iVar4 + 0x1fbc) & 0x800) == 0) {
                    iVar8 = func_0x00018014dc40(arg3 & 0xffffffff, fVar16, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    if (bVar2) {
                        iVar8 = func_0x00018014def0(arg_38h);
                    }
                    if (*(int32_t *)arg4 != iVar8) {
                        *(int32_t *)arg4 = iVar8;
                        uVar9 = 1;
                        goto code_r0x00018014ce72;
                    }
                }
            }
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
            puVar1 = (undefined *)(*(int64_t *)0x180781f28 + 0x280c);
            if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) == '\0') {
                fVar12 = *(float *)(*(int64_t *)0x180781f28 + 0x2808);
            } else {
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                fVar12 = 0.0;
                *puVar1 = 0;
            }
            fVar15 = (float)func_0x00018010f200(0);
            if (fVar15 != 0.0) {
                iVar8 = *(int32_t *)(iVar4 + 0x2228);
                uVar9 = 0x1000;
                if (iVar8 == 3) {
                    uVar9 = 0x282;
                }
                cVar5 = func_0x000180107d30(uVar9, 0);
                uVar9 = 0x2000;
                if (iVar8 == 3) {
                    uVar9 = 0x283;
                }
                cVar6 = func_0x000180107d30(uVar9, 0);
                fVar13 = 10.0;
                fVar12 = fVar15;
                if ((bVar2) && (iVar8 = func_0x00018013f990(arg_38h), fVar12 = fVar15, 0 < iVar8)) {
                    fVar12 = fVar15 / 100.0;
                    fVar15 = extraout_XMM0_Da;
                    if (cVar5 != '\0') {
                        fVar12 = fVar12 / fVar13;
                    }
                } else {
                    fVar15 = (float)(uVar11 & 0xffffffff);
                    if (((-100.0 <= fVar15) && ((fVar15 <= 100.0 && (fVar15 != 0.0)))) || (cVar5 != '\0')) {
                        if (0.0 <= fVar12) {
                            fVar12 = 1.0 / fVar15;
                        } else {
                            fVar12 = -1.0 / fVar15;
                        }
                    } else {
                        fVar12 = fVar12 / 100.0;
                    }
                }
                if (cVar6 != '\0') {
                    fVar12 = fVar12 * fVar13;
                }
                fVar12 = fVar12 + *(float *)(iVar4 + 0x2808);
                *(undefined *)(iVar4 + 0x280c) = 1;
                *(float *)(iVar4 + 0x2808) = fVar12;
            }
            if ((*(int32_t *)(iVar4 + 0x21f4) == (int32_t)arg2) && (*(char *)(iVar4 + 0x1660) == '\0'))
            goto code_r0x00018014ce57;
            pcVar10 = (char *)(iVar4 + 0x280c);
            if (*pcVar10 != '\0') {
                fVar15 = (float)func_0x00018014d930(fVar15, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                    arg_30h & 0xffffffff, 0, 0);
                if (((fVar15 < 1.0) || (fVar12 <= 0.0)) && ((0.0 < fVar15 || (0.0 <= fVar12)))) {
                    fVar13 = fVar12 + fVar15;
                    if (0.0 <= fVar13) {
                        fVar16 = 1.0;
                        if (fVar13 <= 1.0) {
                            fVar16 = fVar13;
                        }
                    } else {
                        fVar16 = 0.0;
                    }
                    uVar7 = func_0x00018014dc40(arg3 & 0xffffffff, fVar16, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    uVar14 = extraout_XMM0_Da_00;
                    if (bVar2) {
                        uVar7 = func_0x00018014def0(arg_38h);
                        uVar14 = extraout_XMM0_Da_01;
                    }
                    fVar13 = (float)func_0x00018014d930(uVar14, uVar7, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
                    ;
                    fVar13 = fVar13 - fVar15;
                    if (fVar12 <= 0.0) {
                        if (fVar13 <= fVar12) {
                            fVar13 = fVar12;
                        }
                    } else if (fVar12 <= fVar13) {
                        fVar13 = fVar12;
                    }
                    *(float *)(iVar4 + 0x2808) = *(float *)(iVar4 + 0x2808) - fVar13;
                    *pcVar10 = '\0';
                    goto code_r0x00018014d1e1;
                }
                *(undefined4 *)(iVar4 + 0x2808) = 0;
                *pcVar10 = '\0';
            }
        }
    }
    uVar9 = 0;
code_r0x00018014ce72:
    if (1.0 <= fVar17) {
        fVar17 = (float)func_0x00018014d930(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
        ;
        fVar12 = *(float *)(arg1 + 0xc) - 2.0;
        fVar15 = *(float *)(arg1 + 4) + 2.0;
        fVar18 = fVar17 * (fVar20 - fVar18) + fVar18;
        fVar17 = fVar18 - fVar19;
        fVar18 = fVar18 + fVar19;
    } else {
        fVar18 = *(float *)arg1;
        fVar12 = *(float *)(arg1 + 4);
        fVar17 = fVar18;
        fVar15 = fVar12;
    }
    *(float *)arg_48h = fVar17;
    *(float *)(arg_48h + 4) = fVar15;
    *(float *)(arg_48h + 8) = fVar18;
    *(float *)(arg_48h + 0xc) = fVar12;
    return uVar9;
}

// ============================================================
// Function: FUN_18014cec5
// Address: 0x18014cec5
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8
fcn.18014ccf0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h,
             undefined8 placeholder_7, int64_t arg_48h)
{
    undefined *puVar1;
    bool bVar2;
    uint32_t uVar3;
    int64_t iVar4;
    char cVar5;
    char cVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    char *pcVar10;
    uint64_t uVar11;
    float fVar12;
    float fVar13;
    float extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    fVar18 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    bVar2 = (int32_t)arg3 - 8U < 2;
    uVar3 = (uint32_t)arg_30h - (uint32_t)arg_28h;
    if ((uint32_t)arg_30h <= (uint32_t)arg_28h) {
        uVar3 = (uint32_t)arg_28h - (uint32_t)arg_30h;
    }
    uVar11 = (uint64_t)uVar3;
    fVar17 = (*(float *)(arg1 + 8) - *(float *)arg1) - 4.0;
    fVar12 = fVar18;
    if (((!bVar2) && (0.0 <= (float)uVar11)) && (fVar12 = fVar17 / ((float)uVar11 + 1.0), fVar12 <= fVar18)) {
        fVar12 = fVar18;
    }
    if (fVar17 <= fVar12) {
        fVar12 = fVar17;
    }
    fVar19 = fVar12 * 0.5;
    fVar18 = *(float *)arg1 + 2.0 + fVar19;
    fVar20 = (*(float *)(arg1 + 8) - 2.0) - fVar19;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == (int32_t)arg2) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
            if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
code_r0x00018014ce57:
                func_0x0001800f9f30(0, 0);
            } else {
                fVar15 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                    fVar13 = (float)func_0x00018014d930(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                        arg_30h & 0xffffffff, 0, 0);
                    fVar13 = fVar13 * (fVar20 - fVar18) + fVar18;
                    if (((fVar15 < (fVar13 - fVar19) - 1.0) || (fVar13 + fVar19 + 1.0 < fVar15)) || (!bVar2)) {
                        fVar13 = 0.0;
                    } else {
                        fVar13 = fVar15 - fVar13;
                    }
                    *(float *)(iVar4 + 0x2804) = fVar13;
                }
                fVar16 = 0.0;
                if (((0.0 < fVar17 - fVar12) &&
                    (fVar12 = ((fVar15 - *(float *)(iVar4 + 0x2804)) - fVar18) / (fVar17 - fVar12), 0.0 <= fVar12)) &&
                   (fVar16 = 1.0, fVar12 <= 1.0)) {
                    fVar16 = fVar12;
                }
code_r0x00018014d1e1:
                if ((*(uint32_t *)(iVar4 + 0x1fbc) & 0x800) == 0) {
                    iVar8 = func_0x00018014dc40(arg3 & 0xffffffff, fVar16, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    if (bVar2) {
                        iVar8 = func_0x00018014def0(arg_38h);
                    }
                    if (*(int32_t *)arg4 != iVar8) {
                        *(int32_t *)arg4 = iVar8;
                        uVar9 = 1;
                        goto code_r0x00018014ce72;
                    }
                }
            }
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
            puVar1 = (undefined *)(*(int64_t *)0x180781f28 + 0x280c);
            if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) == '\0') {
                fVar12 = *(float *)(*(int64_t *)0x180781f28 + 0x2808);
            } else {
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                fVar12 = 0.0;
                *puVar1 = 0;
            }
            fVar15 = (float)func_0x00018010f200(0);
            if (fVar15 != 0.0) {
                iVar8 = *(int32_t *)(iVar4 + 0x2228);
                uVar9 = 0x1000;
                if (iVar8 == 3) {
                    uVar9 = 0x282;
                }
                cVar5 = func_0x000180107d30(uVar9, 0);
                uVar9 = 0x2000;
                if (iVar8 == 3) {
                    uVar9 = 0x283;
                }
                cVar6 = func_0x000180107d30(uVar9, 0);
                fVar13 = 10.0;
                fVar12 = fVar15;
                if ((bVar2) && (iVar8 = func_0x00018013f990(arg_38h), fVar12 = fVar15, 0 < iVar8)) {
                    fVar12 = fVar15 / 100.0;
                    fVar15 = extraout_XMM0_Da;
                    if (cVar5 != '\0') {
                        fVar12 = fVar12 / fVar13;
                    }
                } else {
                    fVar15 = (float)(uVar11 & 0xffffffff);
                    if (((-100.0 <= fVar15) && ((fVar15 <= 100.0 && (fVar15 != 0.0)))) || (cVar5 != '\0')) {
                        if (0.0 <= fVar12) {
                            fVar12 = 1.0 / fVar15;
                        } else {
                            fVar12 = -1.0 / fVar15;
                        }
                    } else {
                        fVar12 = fVar12 / 100.0;
                    }
                }
                if (cVar6 != '\0') {
                    fVar12 = fVar12 * fVar13;
                }
                fVar12 = fVar12 + *(float *)(iVar4 + 0x2808);
                *(undefined *)(iVar4 + 0x280c) = 1;
                *(float *)(iVar4 + 0x2808) = fVar12;
            }
            if ((*(int32_t *)(iVar4 + 0x21f4) == (int32_t)arg2) && (*(char *)(iVar4 + 0x1660) == '\0'))
            goto code_r0x00018014ce57;
            pcVar10 = (char *)(iVar4 + 0x280c);
            if (*pcVar10 != '\0') {
                fVar15 = (float)func_0x00018014d930(fVar15, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                    arg_30h & 0xffffffff, 0, 0);
                if (((fVar15 < 1.0) || (fVar12 <= 0.0)) && ((0.0 < fVar15 || (0.0 <= fVar12)))) {
                    fVar13 = fVar12 + fVar15;
                    if (0.0 <= fVar13) {
                        fVar16 = 1.0;
                        if (fVar13 <= 1.0) {
                            fVar16 = fVar13;
                        }
                    } else {
                        fVar16 = 0.0;
                    }
                    uVar7 = func_0x00018014dc40(arg3 & 0xffffffff, fVar16, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    uVar14 = extraout_XMM0_Da_00;
                    if (bVar2) {
                        uVar7 = func_0x00018014def0(arg_38h);
                        uVar14 = extraout_XMM0_Da_01;
                    }
                    fVar13 = (float)func_0x00018014d930(uVar14, uVar7, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
                    ;
                    fVar13 = fVar13 - fVar15;
                    if (fVar12 <= 0.0) {
                        if (fVar13 <= fVar12) {
                            fVar13 = fVar12;
                        }
                    } else if (fVar12 <= fVar13) {
                        fVar13 = fVar12;
                    }
                    *(float *)(iVar4 + 0x2808) = *(float *)(iVar4 + 0x2808) - fVar13;
                    *pcVar10 = '\0';
                    goto code_r0x00018014d1e1;
                }
                *(undefined4 *)(iVar4 + 0x2808) = 0;
                *pcVar10 = '\0';
            }
        }
    }
    uVar9 = 0;
code_r0x00018014ce72:
    if (1.0 <= fVar17) {
        fVar17 = (float)func_0x00018014d930(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
        ;
        fVar12 = *(float *)(arg1 + 0xc) - 2.0;
        fVar15 = *(float *)(arg1 + 4) + 2.0;
        fVar18 = fVar17 * (fVar20 - fVar18) + fVar18;
        fVar17 = fVar18 - fVar19;
        fVar18 = fVar18 + fVar19;
    } else {
        fVar18 = *(float *)arg1;
        fVar12 = *(float *)(arg1 + 4);
        fVar17 = fVar18;
        fVar15 = fVar12;
    }
    *(float *)arg_48h = fVar17;
    *(float *)(arg_48h + 4) = fVar15;
    *(float *)(arg_48h + 8) = fVar18;
    *(float *)(arg_48h + 0xc) = fVar12;
    return uVar9;
}

// ============================================================
// Function: FUN_18014ced9
// Address: 0x18014ced9
// Size: 877 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8
fcn.18014ccf0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h,
             undefined8 placeholder_7, int64_t arg_48h)
{
    undefined *puVar1;
    bool bVar2;
    uint32_t uVar3;
    int64_t iVar4;
    char cVar5;
    char cVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    char *pcVar10;
    uint64_t uVar11;
    float fVar12;
    float fVar13;
    float extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    fVar18 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    bVar2 = (int32_t)arg3 - 8U < 2;
    uVar3 = (uint32_t)arg_30h - (uint32_t)arg_28h;
    if ((uint32_t)arg_30h <= (uint32_t)arg_28h) {
        uVar3 = (uint32_t)arg_28h - (uint32_t)arg_30h;
    }
    uVar11 = (uint64_t)uVar3;
    fVar17 = (*(float *)(arg1 + 8) - *(float *)arg1) - 4.0;
    fVar12 = fVar18;
    if (((!bVar2) && (0.0 <= (float)uVar11)) && (fVar12 = fVar17 / ((float)uVar11 + 1.0), fVar12 <= fVar18)) {
        fVar12 = fVar18;
    }
    if (fVar17 <= fVar12) {
        fVar12 = fVar17;
    }
    fVar19 = fVar12 * 0.5;
    fVar18 = *(float *)arg1 + 2.0 + fVar19;
    fVar20 = (*(float *)(arg1 + 8) - 2.0) - fVar19;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == (int32_t)arg2) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
            if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
code_r0x00018014ce57:
                func_0x0001800f9f30(0, 0);
            } else {
                fVar15 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                    fVar13 = (float)func_0x00018014d930(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                        arg_30h & 0xffffffff, 0, 0);
                    fVar13 = fVar13 * (fVar20 - fVar18) + fVar18;
                    if (((fVar15 < (fVar13 - fVar19) - 1.0) || (fVar13 + fVar19 + 1.0 < fVar15)) || (!bVar2)) {
                        fVar13 = 0.0;
                    } else {
                        fVar13 = fVar15 - fVar13;
                    }
                    *(float *)(iVar4 + 0x2804) = fVar13;
                }
                fVar16 = 0.0;
                if (((0.0 < fVar17 - fVar12) &&
                    (fVar12 = ((fVar15 - *(float *)(iVar4 + 0x2804)) - fVar18) / (fVar17 - fVar12), 0.0 <= fVar12)) &&
                   (fVar16 = 1.0, fVar12 <= 1.0)) {
                    fVar16 = fVar12;
                }
code_r0x00018014d1e1:
                if ((*(uint32_t *)(iVar4 + 0x1fbc) & 0x800) == 0) {
                    iVar8 = func_0x00018014dc40(arg3 & 0xffffffff, fVar16, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    if (bVar2) {
                        iVar8 = func_0x00018014def0(arg_38h);
                    }
                    if (*(int32_t *)arg4 != iVar8) {
                        *(int32_t *)arg4 = iVar8;
                        uVar9 = 1;
                        goto code_r0x00018014ce72;
                    }
                }
            }
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
            puVar1 = (undefined *)(*(int64_t *)0x180781f28 + 0x280c);
            if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) == '\0') {
                fVar12 = *(float *)(*(int64_t *)0x180781f28 + 0x2808);
            } else {
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                fVar12 = 0.0;
                *puVar1 = 0;
            }
            fVar15 = (float)func_0x00018010f200(0);
            if (fVar15 != 0.0) {
                iVar8 = *(int32_t *)(iVar4 + 0x2228);
                uVar9 = 0x1000;
                if (iVar8 == 3) {
                    uVar9 = 0x282;
                }
                cVar5 = func_0x000180107d30(uVar9, 0);
                uVar9 = 0x2000;
                if (iVar8 == 3) {
                    uVar9 = 0x283;
                }
                cVar6 = func_0x000180107d30(uVar9, 0);
                fVar13 = 10.0;
                fVar12 = fVar15;
                if ((bVar2) && (iVar8 = func_0x00018013f990(arg_38h), fVar12 = fVar15, 0 < iVar8)) {
                    fVar12 = fVar15 / 100.0;
                    fVar15 = extraout_XMM0_Da;
                    if (cVar5 != '\0') {
                        fVar12 = fVar12 / fVar13;
                    }
                } else {
                    fVar15 = (float)(uVar11 & 0xffffffff);
                    if (((-100.0 <= fVar15) && ((fVar15 <= 100.0 && (fVar15 != 0.0)))) || (cVar5 != '\0')) {
                        if (0.0 <= fVar12) {
                            fVar12 = 1.0 / fVar15;
                        } else {
                            fVar12 = -1.0 / fVar15;
                        }
                    } else {
                        fVar12 = fVar12 / 100.0;
                    }
                }
                if (cVar6 != '\0') {
                    fVar12 = fVar12 * fVar13;
                }
                fVar12 = fVar12 + *(float *)(iVar4 + 0x2808);
                *(undefined *)(iVar4 + 0x280c) = 1;
                *(float *)(iVar4 + 0x2808) = fVar12;
            }
            if ((*(int32_t *)(iVar4 + 0x21f4) == (int32_t)arg2) && (*(char *)(iVar4 + 0x1660) == '\0'))
            goto code_r0x00018014ce57;
            pcVar10 = (char *)(iVar4 + 0x280c);
            if (*pcVar10 != '\0') {
                fVar15 = (float)func_0x00018014d930(fVar15, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                    arg_30h & 0xffffffff, 0, 0);
                if (((fVar15 < 1.0) || (fVar12 <= 0.0)) && ((0.0 < fVar15 || (0.0 <= fVar12)))) {
                    fVar13 = fVar12 + fVar15;
                    if (0.0 <= fVar13) {
                        fVar16 = 1.0;
                        if (fVar13 <= 1.0) {
                            fVar16 = fVar13;
                        }
                    } else {
                        fVar16 = 0.0;
                    }
                    uVar7 = func_0x00018014dc40(arg3 & 0xffffffff, fVar16, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    uVar14 = extraout_XMM0_Da_00;
                    if (bVar2) {
                        uVar7 = func_0x00018014def0(arg_38h);
                        uVar14 = extraout_XMM0_Da_01;
                    }
                    fVar13 = (float)func_0x00018014d930(uVar14, uVar7, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
                    ;
                    fVar13 = fVar13 - fVar15;
                    if (fVar12 <= 0.0) {
                        if (fVar13 <= fVar12) {
                            fVar13 = fVar12;
                        }
                    } else if (fVar12 <= fVar13) {
                        fVar13 = fVar12;
                    }
                    *(float *)(iVar4 + 0x2808) = *(float *)(iVar4 + 0x2808) - fVar13;
                    *pcVar10 = '\0';
                    goto code_r0x00018014d1e1;
                }
                *(undefined4 *)(iVar4 + 0x2808) = 0;
                *pcVar10 = '\0';
            }
        }
    }
    uVar9 = 0;
code_r0x00018014ce72:
    if (1.0 <= fVar17) {
        fVar17 = (float)func_0x00018014d930(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
        ;
        fVar12 = *(float *)(arg1 + 0xc) - 2.0;
        fVar15 = *(float *)(arg1 + 4) + 2.0;
        fVar18 = fVar17 * (fVar20 - fVar18) + fVar18;
        fVar17 = fVar18 - fVar19;
        fVar18 = fVar18 + fVar19;
    } else {
        fVar18 = *(float *)arg1;
        fVar12 = *(float *)(arg1 + 4);
        fVar17 = fVar18;
        fVar15 = fVar12;
    }
    *(float *)arg_48h = fVar17;
    *(float *)(arg_48h + 4) = fVar15;
    *(float *)(arg_48h + 8) = fVar18;
    *(float *)(arg_48h + 0xc) = fVar12;
    return uVar9;
}

// ============================================================
// Function: FUN_18014d246
// Address: 0x18014d246
// Size: 177 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8
fcn.18014ccf0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h,
             undefined8 placeholder_7, int64_t arg_48h)
{
    undefined *puVar1;
    bool bVar2;
    uint32_t uVar3;
    int64_t iVar4;
    char cVar5;
    char cVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    char *pcVar10;
    uint64_t uVar11;
    float fVar12;
    float fVar13;
    float extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    fVar18 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    bVar2 = (int32_t)arg3 - 8U < 2;
    uVar3 = (uint32_t)arg_30h - (uint32_t)arg_28h;
    if ((uint32_t)arg_30h <= (uint32_t)arg_28h) {
        uVar3 = (uint32_t)arg_28h - (uint32_t)arg_30h;
    }
    uVar11 = (uint64_t)uVar3;
    fVar17 = (*(float *)(arg1 + 8) - *(float *)arg1) - 4.0;
    fVar12 = fVar18;
    if (((!bVar2) && (0.0 <= (float)uVar11)) && (fVar12 = fVar17 / ((float)uVar11 + 1.0), fVar12 <= fVar18)) {
        fVar12 = fVar18;
    }
    if (fVar17 <= fVar12) {
        fVar12 = fVar17;
    }
    fVar19 = fVar12 * 0.5;
    fVar18 = *(float *)arg1 + 2.0 + fVar19;
    fVar20 = (*(float *)(arg1 + 8) - 2.0) - fVar19;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == (int32_t)arg2) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
            if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
code_r0x00018014ce57:
                func_0x0001800f9f30(0, 0);
            } else {
                fVar15 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                    fVar13 = (float)func_0x00018014d930(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                        arg_30h & 0xffffffff, 0, 0);
                    fVar13 = fVar13 * (fVar20 - fVar18) + fVar18;
                    if (((fVar15 < (fVar13 - fVar19) - 1.0) || (fVar13 + fVar19 + 1.0 < fVar15)) || (!bVar2)) {
                        fVar13 = 0.0;
                    } else {
                        fVar13 = fVar15 - fVar13;
                    }
                    *(float *)(iVar4 + 0x2804) = fVar13;
                }
                fVar16 = 0.0;
                if (((0.0 < fVar17 - fVar12) &&
                    (fVar12 = ((fVar15 - *(float *)(iVar4 + 0x2804)) - fVar18) / (fVar17 - fVar12), 0.0 <= fVar12)) &&
                   (fVar16 = 1.0, fVar12 <= 1.0)) {
                    fVar16 = fVar12;
                }
code_r0x00018014d1e1:
                if ((*(uint32_t *)(iVar4 + 0x1fbc) & 0x800) == 0) {
                    iVar8 = func_0x00018014dc40(arg3 & 0xffffffff, fVar16, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    if (bVar2) {
                        iVar8 = func_0x00018014def0(arg_38h);
                    }
                    if (*(int32_t *)arg4 != iVar8) {
                        *(int32_t *)arg4 = iVar8;
                        uVar9 = 1;
                        goto code_r0x00018014ce72;
                    }
                }
            }
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
            puVar1 = (undefined *)(*(int64_t *)0x180781f28 + 0x280c);
            if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) == '\0') {
                fVar12 = *(float *)(*(int64_t *)0x180781f28 + 0x2808);
            } else {
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                fVar12 = 0.0;
                *puVar1 = 0;
            }
            fVar15 = (float)func_0x00018010f200(0);
            if (fVar15 != 0.0) {
                iVar8 = *(int32_t *)(iVar4 + 0x2228);
                uVar9 = 0x1000;
                if (iVar8 == 3) {
                    uVar9 = 0x282;
                }
                cVar5 = func_0x000180107d30(uVar9, 0);
                uVar9 = 0x2000;
                if (iVar8 == 3) {
                    uVar9 = 0x283;
                }
                cVar6 = func_0x000180107d30(uVar9, 0);
                fVar13 = 10.0;
                fVar12 = fVar15;
                if ((bVar2) && (iVar8 = func_0x00018013f990(arg_38h), fVar12 = fVar15, 0 < iVar8)) {
                    fVar12 = fVar15 / 100.0;
                    fVar15 = extraout_XMM0_Da;
                    if (cVar5 != '\0') {
                        fVar12 = fVar12 / fVar13;
                    }
                } else {
                    fVar15 = (float)(uVar11 & 0xffffffff);
                    if (((-100.0 <= fVar15) && ((fVar15 <= 100.0 && (fVar15 != 0.0)))) || (cVar5 != '\0')) {
                        if (0.0 <= fVar12) {
                            fVar12 = 1.0 / fVar15;
                        } else {
                            fVar12 = -1.0 / fVar15;
                        }
                    } else {
                        fVar12 = fVar12 / 100.0;
                    }
                }
                if (cVar6 != '\0') {
                    fVar12 = fVar12 * fVar13;
                }
                fVar12 = fVar12 + *(float *)(iVar4 + 0x2808);
                *(undefined *)(iVar4 + 0x280c) = 1;
                *(float *)(iVar4 + 0x2808) = fVar12;
            }
            if ((*(int32_t *)(iVar4 + 0x21f4) == (int32_t)arg2) && (*(char *)(iVar4 + 0x1660) == '\0'))
            goto code_r0x00018014ce57;
            pcVar10 = (char *)(iVar4 + 0x280c);
            if (*pcVar10 != '\0') {
                fVar15 = (float)func_0x00018014d930(fVar15, *(undefined4 *)arg4, arg_28h & 0xffffffff, 
                                                    arg_30h & 0xffffffff, 0, 0);
                if (((fVar15 < 1.0) || (fVar12 <= 0.0)) && ((0.0 < fVar15 || (0.0 <= fVar12)))) {
                    fVar13 = fVar12 + fVar15;
                    if (0.0 <= fVar13) {
                        fVar16 = 1.0;
                        if (fVar13 <= 1.0) {
                            fVar16 = fVar13;
                        }
                    } else {
                        fVar16 = 0.0;
                    }
                    uVar7 = func_0x00018014dc40(arg3 & 0xffffffff, fVar16, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0
                                                , 0);
                    uVar14 = extraout_XMM0_Da_00;
                    if (bVar2) {
                        uVar7 = func_0x00018014def0(arg_38h);
                        uVar14 = extraout_XMM0_Da_01;
                    }
                    fVar13 = (float)func_0x00018014d930(uVar14, uVar7, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
                    ;
                    fVar13 = fVar13 - fVar15;
                    if (fVar12 <= 0.0) {
                        if (fVar13 <= fVar12) {
                            fVar13 = fVar12;
                        }
                    } else if (fVar12 <= fVar13) {
                        fVar13 = fVar12;
                    }
                    *(float *)(iVar4 + 0x2808) = *(float *)(iVar4 + 0x2808) - fVar13;
                    *pcVar10 = '\0';
                    goto code_r0x00018014d1e1;
                }
                *(undefined4 *)(iVar4 + 0x2808) = 0;
                *pcVar10 = '\0';
            }
        }
    }
    uVar9 = 0;
code_r0x00018014ce72:
    if (1.0 <= fVar17) {
        fVar17 = (float)func_0x00018014d930(arg1, *(undefined4 *)arg4, arg_28h & 0xffffffff, arg_30h & 0xffffffff, 0, 0)
        ;
        fVar12 = *(float *)(arg1 + 0xc) - 2.0;
        fVar15 = *(float *)(arg1 + 4) + 2.0;
        fVar18 = fVar17 * (fVar20 - fVar18) + fVar18;
        fVar17 = fVar18 - fVar19;
        fVar18 = fVar18 + fVar19;
    } else {
        fVar18 = *(float *)arg1;
        fVar12 = *(float *)(arg1 + 4);
        fVar17 = fVar18;
        fVar15 = fVar12;
    }
    *(float *)arg_48h = fVar17;
    *(float *)(arg_48h + 4) = fVar15;
    *(float *)(arg_48h + 8) = fVar18;
    *(float *)(arg_48h + 0xc) = fVar12;
    return uVar9;
}

// ============================================================
// Function: FUN_18014d300
// Address: 0x18014d300
// Size: 125 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d300(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar5 = (int32_t)arg4;
    iVar3 = (int32_t)arg2;
    iVar4 = (int32_t)arg3;
    if (iVar4 == iVar5) {
        return;
    }
    if (iVar4 < iVar5) {
        iVar1 = iVar4;
        if ((iVar4 <= iVar3) && (iVar1 = iVar3, iVar5 < iVar3)) {
            iVar1 = iVar5;
        }
    } else {
        iVar1 = iVar5;
        if ((iVar5 <= iVar3) && (iVar1 = iVar3, iVar4 < iVar3)) {
            iVar1 = iVar4;
        }
    }
    if (0.0 < (float)arg_28h) {
        iVar2 = iVar4;
        if (iVar4 <= iVar5) {
            iVar2 = iVar5;
            iVar5 = iVar4;
        }
        fVar6 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar9 = (float)iVar5;
        fVar7 = fVar9;
        if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar9 < 0.0)) {
            fVar7 = fVar6;
        }
        fVar8 = (float)iVar2;
        fVar10 = fVar8;
        if (((float)((uint32_t)fVar8 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar8 < 0.0)) {
            fVar10 = fVar6;
        }
        if ((((fVar9 != 0.0) || (fVar11 = fVar6, 0.0 <= fVar8)) && (fVar11 = fVar7, fVar8 == 0.0)) && (fVar9 < 0.0)) {
            fVar10 = fVar6;
        }
        fVar7 = (float)iVar1;
        if ((fVar11 < fVar7) && (fVar7 < fVar10)) {
            iVar2 = iVar2 * iVar5;
            if (0.0 <= (float)iVar2) {
                if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)((uint32_t)fVar10 ^ 0x80000000))
                    ;
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, fVar7 / fVar11);
                    fcn.180491ba0();
                }
            } else if ((float)iVar3 != 0.0) {
                if (0.0 <= (float)iVar3) {
                    fcn.180491ba0(iVar2, fVar7 / (float)arg_28h);
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)arg_28h);
                    fcn.180491ba0();
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014d37d
// Address: 0x18014d37d
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d300(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar5 = (int32_t)arg4;
    iVar3 = (int32_t)arg2;
    iVar4 = (int32_t)arg3;
    if (iVar4 == iVar5) {
        return;
    }
    if (iVar4 < iVar5) {
        iVar1 = iVar4;
        if ((iVar4 <= iVar3) && (iVar1 = iVar3, iVar5 < iVar3)) {
            iVar1 = iVar5;
        }
    } else {
        iVar1 = iVar5;
        if ((iVar5 <= iVar3) && (iVar1 = iVar3, iVar4 < iVar3)) {
            iVar1 = iVar4;
        }
    }
    if (0.0 < (float)arg_28h) {
        iVar2 = iVar4;
        if (iVar4 <= iVar5) {
            iVar2 = iVar5;
            iVar5 = iVar4;
        }
        fVar6 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar9 = (float)iVar5;
        fVar7 = fVar9;
        if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar9 < 0.0)) {
            fVar7 = fVar6;
        }
        fVar8 = (float)iVar2;
        fVar10 = fVar8;
        if (((float)((uint32_t)fVar8 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar8 < 0.0)) {
            fVar10 = fVar6;
        }
        if ((((fVar9 != 0.0) || (fVar11 = fVar6, 0.0 <= fVar8)) && (fVar11 = fVar7, fVar8 == 0.0)) && (fVar9 < 0.0)) {
            fVar10 = fVar6;
        }
        fVar7 = (float)iVar1;
        if ((fVar11 < fVar7) && (fVar7 < fVar10)) {
            iVar2 = iVar2 * iVar5;
            if (0.0 <= (float)iVar2) {
                if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)((uint32_t)fVar10 ^ 0x80000000))
                    ;
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, fVar7 / fVar11);
                    fcn.180491ba0();
                }
            } else if ((float)iVar3 != 0.0) {
                if (0.0 <= (float)iVar3) {
                    fcn.180491ba0(iVar2, fVar7 / (float)arg_28h);
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)arg_28h);
                    fcn.180491ba0();
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014d38a
// Address: 0x18014d38a
// Size: 206 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d300(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar5 = (int32_t)arg4;
    iVar3 = (int32_t)arg2;
    iVar4 = (int32_t)arg3;
    if (iVar4 == iVar5) {
        return;
    }
    if (iVar4 < iVar5) {
        iVar1 = iVar4;
        if ((iVar4 <= iVar3) && (iVar1 = iVar3, iVar5 < iVar3)) {
            iVar1 = iVar5;
        }
    } else {
        iVar1 = iVar5;
        if ((iVar5 <= iVar3) && (iVar1 = iVar3, iVar4 < iVar3)) {
            iVar1 = iVar4;
        }
    }
    if (0.0 < (float)arg_28h) {
        iVar2 = iVar4;
        if (iVar4 <= iVar5) {
            iVar2 = iVar5;
            iVar5 = iVar4;
        }
        fVar6 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar9 = (float)iVar5;
        fVar7 = fVar9;
        if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar9 < 0.0)) {
            fVar7 = fVar6;
        }
        fVar8 = (float)iVar2;
        fVar10 = fVar8;
        if (((float)((uint32_t)fVar8 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar8 < 0.0)) {
            fVar10 = fVar6;
        }
        if ((((fVar9 != 0.0) || (fVar11 = fVar6, 0.0 <= fVar8)) && (fVar11 = fVar7, fVar8 == 0.0)) && (fVar9 < 0.0)) {
            fVar10 = fVar6;
        }
        fVar7 = (float)iVar1;
        if ((fVar11 < fVar7) && (fVar7 < fVar10)) {
            iVar2 = iVar2 * iVar5;
            if (0.0 <= (float)iVar2) {
                if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)((uint32_t)fVar10 ^ 0x80000000))
                    ;
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, fVar7 / fVar11);
                    fcn.180491ba0();
                }
            } else if ((float)iVar3 != 0.0) {
                if (0.0 <= (float)iVar3) {
                    fcn.180491ba0(iVar2, fVar7 / (float)arg_28h);
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)arg_28h);
                    fcn.180491ba0();
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014d458
// Address: 0x18014d458
// Size: 311 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d300(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar5 = (int32_t)arg4;
    iVar3 = (int32_t)arg2;
    iVar4 = (int32_t)arg3;
    if (iVar4 == iVar5) {
        return;
    }
    if (iVar4 < iVar5) {
        iVar1 = iVar4;
        if ((iVar4 <= iVar3) && (iVar1 = iVar3, iVar5 < iVar3)) {
            iVar1 = iVar5;
        }
    } else {
        iVar1 = iVar5;
        if ((iVar5 <= iVar3) && (iVar1 = iVar3, iVar4 < iVar3)) {
            iVar1 = iVar4;
        }
    }
    if (0.0 < (float)arg_28h) {
        iVar2 = iVar4;
        if (iVar4 <= iVar5) {
            iVar2 = iVar5;
            iVar5 = iVar4;
        }
        fVar6 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar9 = (float)iVar5;
        fVar7 = fVar9;
        if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar9 < 0.0)) {
            fVar7 = fVar6;
        }
        fVar8 = (float)iVar2;
        fVar10 = fVar8;
        if (((float)((uint32_t)fVar8 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar8 < 0.0)) {
            fVar10 = fVar6;
        }
        if ((((fVar9 != 0.0) || (fVar11 = fVar6, 0.0 <= fVar8)) && (fVar11 = fVar7, fVar8 == 0.0)) && (fVar9 < 0.0)) {
            fVar10 = fVar6;
        }
        fVar7 = (float)iVar1;
        if ((fVar11 < fVar7) && (fVar7 < fVar10)) {
            iVar2 = iVar2 * iVar5;
            if (0.0 <= (float)iVar2) {
                if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)((uint32_t)fVar10 ^ 0x80000000))
                    ;
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, fVar7 / fVar11);
                    fcn.180491ba0();
                }
            } else if ((float)iVar3 != 0.0) {
                if (0.0 <= (float)iVar3) {
                    fcn.180491ba0(iVar2, fVar7 / (float)arg_28h);
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)arg_28h);
                    fcn.180491ba0();
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014d58f
// Address: 0x18014d58f
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d300(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar5 = (int32_t)arg4;
    iVar3 = (int32_t)arg2;
    iVar4 = (int32_t)arg3;
    if (iVar4 == iVar5) {
        return;
    }
    if (iVar4 < iVar5) {
        iVar1 = iVar4;
        if ((iVar4 <= iVar3) && (iVar1 = iVar3, iVar5 < iVar3)) {
            iVar1 = iVar5;
        }
    } else {
        iVar1 = iVar5;
        if ((iVar5 <= iVar3) && (iVar1 = iVar3, iVar4 < iVar3)) {
            iVar1 = iVar4;
        }
    }
    if (0.0 < (float)arg_28h) {
        iVar2 = iVar4;
        if (iVar4 <= iVar5) {
            iVar2 = iVar5;
            iVar5 = iVar4;
        }
        fVar6 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar9 = (float)iVar5;
        fVar7 = fVar9;
        if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar9 < 0.0)) {
            fVar7 = fVar6;
        }
        fVar8 = (float)iVar2;
        fVar10 = fVar8;
        if (((float)((uint32_t)fVar8 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar8 < 0.0)) {
            fVar10 = fVar6;
        }
        if ((((fVar9 != 0.0) || (fVar11 = fVar6, 0.0 <= fVar8)) && (fVar11 = fVar7, fVar8 == 0.0)) && (fVar9 < 0.0)) {
            fVar10 = fVar6;
        }
        fVar7 = (float)iVar1;
        if ((fVar11 < fVar7) && (fVar7 < fVar10)) {
            iVar2 = iVar2 * iVar5;
            if (0.0 <= (float)iVar2) {
                if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)((uint32_t)fVar10 ^ 0x80000000))
                    ;
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, fVar7 / fVar11);
                    fcn.180491ba0();
                }
            } else if ((float)iVar3 != 0.0) {
                if (0.0 <= (float)iVar3) {
                    fcn.180491ba0(iVar2, fVar7 / (float)arg_28h);
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)arg_28h);
                    fcn.180491ba0();
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014d5ab
// Address: 0x18014d5ab
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d300(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar5 = (int32_t)arg4;
    iVar3 = (int32_t)arg2;
    iVar4 = (int32_t)arg3;
    if (iVar4 == iVar5) {
        return;
    }
    if (iVar4 < iVar5) {
        iVar1 = iVar4;
        if ((iVar4 <= iVar3) && (iVar1 = iVar3, iVar5 < iVar3)) {
            iVar1 = iVar5;
        }
    } else {
        iVar1 = iVar5;
        if ((iVar5 <= iVar3) && (iVar1 = iVar3, iVar4 < iVar3)) {
            iVar1 = iVar4;
        }
    }
    if (0.0 < (float)arg_28h) {
        iVar2 = iVar4;
        if (iVar4 <= iVar5) {
            iVar2 = iVar5;
            iVar5 = iVar4;
        }
        fVar6 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar9 = (float)iVar5;
        fVar7 = fVar9;
        if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar9 < 0.0)) {
            fVar7 = fVar6;
        }
        fVar8 = (float)iVar2;
        fVar10 = fVar8;
        if (((float)((uint32_t)fVar8 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar8 < 0.0)) {
            fVar10 = fVar6;
        }
        if ((((fVar9 != 0.0) || (fVar11 = fVar6, 0.0 <= fVar8)) && (fVar11 = fVar7, fVar8 == 0.0)) && (fVar9 < 0.0)) {
            fVar10 = fVar6;
        }
        fVar7 = (float)iVar1;
        if ((fVar11 < fVar7) && (fVar7 < fVar10)) {
            iVar2 = iVar2 * iVar5;
            if (0.0 <= (float)iVar2) {
                if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)((uint32_t)fVar10 ^ 0x80000000))
                    ;
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, fVar7 / fVar11);
                    fcn.180491ba0();
                }
            } else if ((float)iVar3 != 0.0) {
                if (0.0 <= (float)iVar3) {
                    fcn.180491ba0(iVar2, fVar7 / (float)arg_28h);
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)arg_28h);
                    fcn.180491ba0();
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014d5bc
// Address: 0x18014d5bc
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d300(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar5 = (int32_t)arg4;
    iVar3 = (int32_t)arg2;
    iVar4 = (int32_t)arg3;
    if (iVar4 == iVar5) {
        return;
    }
    if (iVar4 < iVar5) {
        iVar1 = iVar4;
        if ((iVar4 <= iVar3) && (iVar1 = iVar3, iVar5 < iVar3)) {
            iVar1 = iVar5;
        }
    } else {
        iVar1 = iVar5;
        if ((iVar5 <= iVar3) && (iVar1 = iVar3, iVar4 < iVar3)) {
            iVar1 = iVar4;
        }
    }
    if (0.0 < (float)arg_28h) {
        iVar2 = iVar4;
        if (iVar4 <= iVar5) {
            iVar2 = iVar5;
            iVar5 = iVar4;
        }
        fVar6 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar9 = (float)iVar5;
        fVar7 = fVar9;
        if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar9 < 0.0)) {
            fVar7 = fVar6;
        }
        fVar8 = (float)iVar2;
        fVar10 = fVar8;
        if (((float)((uint32_t)fVar8 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar8 < 0.0)) {
            fVar10 = fVar6;
        }
        if ((((fVar9 != 0.0) || (fVar11 = fVar6, 0.0 <= fVar8)) && (fVar11 = fVar7, fVar8 == 0.0)) && (fVar9 < 0.0)) {
            fVar10 = fVar6;
        }
        fVar7 = (float)iVar1;
        if ((fVar11 < fVar7) && (fVar7 < fVar10)) {
            iVar2 = iVar2 * iVar5;
            if (0.0 <= (float)iVar2) {
                if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)((uint32_t)fVar10 ^ 0x80000000))
                    ;
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, fVar7 / fVar11);
                    fcn.180491ba0();
                }
            } else if ((float)iVar3 != 0.0) {
                if (0.0 <= (float)iVar3) {
                    fcn.180491ba0(iVar2, fVar7 / (float)arg_28h);
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)arg_28h);
                    fcn.180491ba0();
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014d5cb
// Address: 0x18014d5cb
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d300(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar5 = (int32_t)arg4;
    iVar3 = (int32_t)arg2;
    iVar4 = (int32_t)arg3;
    if (iVar4 == iVar5) {
        return;
    }
    if (iVar4 < iVar5) {
        iVar1 = iVar4;
        if ((iVar4 <= iVar3) && (iVar1 = iVar3, iVar5 < iVar3)) {
            iVar1 = iVar5;
        }
    } else {
        iVar1 = iVar5;
        if ((iVar5 <= iVar3) && (iVar1 = iVar3, iVar4 < iVar3)) {
            iVar1 = iVar4;
        }
    }
    if (0.0 < (float)arg_28h) {
        iVar2 = iVar4;
        if (iVar4 <= iVar5) {
            iVar2 = iVar5;
            iVar5 = iVar4;
        }
        fVar6 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar9 = (float)iVar5;
        fVar7 = fVar9;
        if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar9 < 0.0)) {
            fVar7 = fVar6;
        }
        fVar8 = (float)iVar2;
        fVar10 = fVar8;
        if (((float)((uint32_t)fVar8 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar8 < 0.0)) {
            fVar10 = fVar6;
        }
        if ((((fVar9 != 0.0) || (fVar11 = fVar6, 0.0 <= fVar8)) && (fVar11 = fVar7, fVar8 == 0.0)) && (fVar9 < 0.0)) {
            fVar10 = fVar6;
        }
        fVar7 = (float)iVar1;
        if ((fVar11 < fVar7) && (fVar7 < fVar10)) {
            iVar2 = iVar2 * iVar5;
            if (0.0 <= (float)iVar2) {
                if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)((uint32_t)fVar10 ^ 0x80000000))
                    ;
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, fVar7 / fVar11);
                    fcn.180491ba0();
                }
            } else if ((float)iVar3 != 0.0) {
                if (0.0 <= (float)iVar3) {
                    fcn.180491ba0(iVar2, fVar7 / (float)arg_28h);
                    fcn.180491ba0();
                } else {
                    fcn.180491ba0(iVar2, (float)((uint32_t)fVar7 ^ 0x80000000) / (float)arg_28h);
                    fcn.180491ba0();
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014d600
// Address: 0x18014d600
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h

uint64_t fcn.18014d600(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                      int64_t arg_30h)
{
    uint64_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    float fVar4;
    float in_XMM1_Da;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    undefined4 unaff_XMM9_Da;
    float fVar9;
    undefined4 unaff_XMM9_Db;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = (int32_t)arg3;
    if ((0.0 < in_XMM1_Da) && (iVar3 = (int32_t)arg4, iVar2 != iVar3)) {
        if (1.0 <= in_XMM1_Da) {
            return arg4 & 0xffffffff;
        }
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                uVar1 = (uint64_t)(uint32_t)(int32_t)((float)(iVar3 - iVar2) * in_XMM1_Da + (float)iVar2);
            } else {
                uVar1 = 0;
                if (in_XMM1_Da < 1.0) {
                    if (iVar3 < iVar2) {
                        fVar5 = -0.5;
                    } else {
                        fVar5 = 0.5;
                    }
                    uVar1 = (uint64_t)(uint32_t)((int32_t)((float)(iVar3 - iVar2) * in_XMM1_Da + fVar5) + iVar2);
                }
            }
        } else {
            fVar4 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar9 = (float)iVar2;
            fVar5 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar5 = (float)arg_28h, fVar9 < 0.0)) {
                fVar5 = fVar4;
            }
            fVar6 = (float)iVar3;
            fVar7 = fVar6;
            if (((float)((uint32_t)fVar6 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar6 < 0.0)) {
                fVar7 = fVar4;
            }
            fVar8 = fVar7;
            if (iVar3 < iVar2) {
                fVar8 = fVar5;
                fVar5 = fVar7;
            }
            if ((fVar6 == 0.0) && (fVar9 < 0.0)) {
                fVar8 = fVar4;
            }
            if (iVar3 < iVar2) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= (float)(iVar2 * iVar3)) {
                if ((fVar9 < 0.0) || (fVar6 < 0.0)) {
                    fVar5 = (float)fcn.180492580(CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da));
                    uVar1 = (uint64_t)
                            (uint32_t)
                            (int32_t)(float)((uint32_t)(fVar5 * (float)((uint32_t)fVar8 ^ 0x80000000)) ^ 0x80000000);
                } else {
                    fVar4 = (float)fcn.180492580(CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da));
                    uVar1 = (uint64_t)(uint32_t)(int32_t)(fVar4 * fVar5);
                }
            } else {
                if (iVar2 < iVar3) {
                    iVar3 = iVar2;
                }
                fVar5 = (float)((uint32_t)(float)iVar3 ^ 0x80000000) / (float)((uint32_t)(fVar6 - fVar9) & 0x7fffffff);
                if (fVar5 + (float)arg_30h < in_XMM1_Da) {
                    if (fVar5 <= in_XMM1_Da) {
                        fVar5 = (float)fcn.180492580(CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da));
                        uVar1 = (uint64_t)(uint32_t)(int32_t)(fVar5 * (float)arg_28h);
                    } else {
                        fVar5 = (float)fcn.180492580(CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da));
                        uVar1 = (uint64_t)(uint32_t)(int32_t)(float)((uint32_t)(fVar5 * (float)arg_28h) ^ 0x80000000);
                    }
                } else {
                    uVar1 = 0;
                }
            }
        }
        return uVar1;
    }
    return arg3 & 0xffffffff;
}

// ============================================================
// Function: FUN_18014d631
// Address: 0x18014d631
// Size: 602 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h

uint64_t fcn.18014d600(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                      int64_t arg_30h)
{
    uint64_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    float fVar4;
    float in_XMM1_Da;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    undefined4 unaff_XMM9_Da;
    float fVar9;
    undefined4 unaff_XMM9_Db;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = (int32_t)arg3;
    if ((0.0 < in_XMM1_Da) && (iVar3 = (int32_t)arg4, iVar2 != iVar3)) {
        if (1.0 <= in_XMM1_Da) {
            return arg4 & 0xffffffff;
        }
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                uVar1 = (uint64_t)(uint32_t)(int32_t)((float)(iVar3 - iVar2) * in_XMM1_Da + (float)iVar2);
            } else {
                uVar1 = 0;
                if (in_XMM1_Da < 1.0) {
                    if (iVar3 < iVar2) {
                        fVar5 = -0.5;
                    } else {
                        fVar5 = 0.5;
                    }
                    uVar1 = (uint64_t)(uint32_t)((int32_t)((float)(iVar3 - iVar2) * in_XMM1_Da + fVar5) + iVar2);
                }
            }
        } else {
            fVar4 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar9 = (float)iVar2;
            fVar5 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar5 = (float)arg_28h, fVar9 < 0.0)) {
                fVar5 = fVar4;
            }
            fVar6 = (float)iVar3;
            fVar7 = fVar6;
            if (((float)((uint32_t)fVar6 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar6 < 0.0)) {
                fVar7 = fVar4;
            }
            fVar8 = fVar7;
            if (iVar3 < iVar2) {
                fVar8 = fVar5;
                fVar5 = fVar7;
            }
            if ((fVar6 == 0.0) && (fVar9 < 0.0)) {
                fVar8 = fVar4;
            }
            if (iVar3 < iVar2) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= (float)(iVar2 * iVar3)) {
                if ((fVar9 < 0.0) || (fVar6 < 0.0)) {
                    fVar5 = (float)fcn.180492580(CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da));
                    uVar1 = (uint64_t)
                            (uint32_t)
                            (int32_t)(float)((uint32_t)(fVar5 * (float)((uint32_t)fVar8 ^ 0x80000000)) ^ 0x80000000);
                } else {
                    fVar4 = (float)fcn.180492580(CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da));
                    uVar1 = (uint64_t)(uint32_t)(int32_t)(fVar4 * fVar5);
                }
            } else {
                if (iVar2 < iVar3) {
                    iVar3 = iVar2;
                }
                fVar5 = (float)((uint32_t)(float)iVar3 ^ 0x80000000) / (float)((uint32_t)(fVar6 - fVar9) & 0x7fffffff);
                if (fVar5 + (float)arg_30h < in_XMM1_Da) {
                    if (fVar5 <= in_XMM1_Da) {
                        fVar5 = (float)fcn.180492580(CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da));
                        uVar1 = (uint64_t)(uint32_t)(int32_t)(fVar5 * (float)arg_28h);
                    } else {
                        fVar5 = (float)fcn.180492580(CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da));
                        uVar1 = (uint64_t)(uint32_t)(int32_t)(float)((uint32_t)(fVar5 * (float)arg_28h) ^ 0x80000000);
                    }
                } else {
                    uVar1 = 0;
                }
            }
        }
        return uVar1;
    }
    return arg3 & 0xffffffff;
}

// ============================================================
// Function: FUN_18014d88b
// Address: 0x18014d88b
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h

uint64_t fcn.18014d600(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                      int64_t arg_30h)
{
    uint64_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    float fVar4;
    float in_XMM1_Da;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    undefined4 unaff_XMM9_Da;
    float fVar9;
    undefined4 unaff_XMM9_Db;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = (int32_t)arg3;
    if ((0.0 < in_XMM1_Da) && (iVar3 = (int32_t)arg4, iVar2 != iVar3)) {
        if (1.0 <= in_XMM1_Da) {
            return arg4 & 0xffffffff;
        }
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                uVar1 = (uint64_t)(uint32_t)(int32_t)((float)(iVar3 - iVar2) * in_XMM1_Da + (float)iVar2);
            } else {
                uVar1 = 0;
                if (in_XMM1_Da < 1.0) {
                    if (iVar3 < iVar2) {
                        fVar5 = -0.5;
                    } else {
                        fVar5 = 0.5;
                    }
                    uVar1 = (uint64_t)(uint32_t)((int32_t)((float)(iVar3 - iVar2) * in_XMM1_Da + fVar5) + iVar2);
                }
            }
        } else {
            fVar4 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar9 = (float)iVar2;
            fVar5 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar5 = (float)arg_28h, fVar9 < 0.0)) {
                fVar5 = fVar4;
            }
            fVar6 = (float)iVar3;
            fVar7 = fVar6;
            if (((float)((uint32_t)fVar6 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar6 < 0.0)) {
                fVar7 = fVar4;
            }
            fVar8 = fVar7;
            if (iVar3 < iVar2) {
                fVar8 = fVar5;
                fVar5 = fVar7;
            }
            if ((fVar6 == 0.0) && (fVar9 < 0.0)) {
                fVar8 = fVar4;
            }
            if (iVar3 < iVar2) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= (float)(iVar2 * iVar3)) {
                if ((fVar9 < 0.0) || (fVar6 < 0.0)) {
                    fVar5 = (float)fcn.180492580(CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da));
                    uVar1 = (uint64_t)
                            (uint32_t)
                            (int32_t)(float)((uint32_t)(fVar5 * (float)((uint32_t)fVar8 ^ 0x80000000)) ^ 0x80000000);
                } else {
                    fVar4 = (float)fcn.180492580(CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da));
                    uVar1 = (uint64_t)(uint32_t)(int32_t)(fVar4 * fVar5);
                }
            } else {
                if (iVar2 < iVar3) {
                    iVar3 = iVar2;
                }
                fVar5 = (float)((uint32_t)(float)iVar3 ^ 0x80000000) / (float)((uint32_t)(fVar6 - fVar9) & 0x7fffffff);
                if (fVar5 + (float)arg_30h < in_XMM1_Da) {
                    if (fVar5 <= in_XMM1_Da) {
                        fVar5 = (float)fcn.180492580(CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da));
                        uVar1 = (uint64_t)(uint32_t)(int32_t)(fVar5 * (float)arg_28h);
                    } else {
                        fVar5 = (float)fcn.180492580(CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da));
                        uVar1 = (uint64_t)(uint32_t)(int32_t)(float)((uint32_t)(fVar5 * (float)arg_28h) ^ 0x80000000);
                    }
                } else {
                    uVar1 = 0;
                }
            }
        }
        return uVar1;
    }
    return arg3 & 0xffffffff;
}

// ============================================================
// Function: FUN_18014d8a0
// Address: 0x18014d8a0
// Size: 142 bytes
// ============================================================
void fcn.18014d8a0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    char *pcVar1;
    char cVar2;
    int64_t *piVar3;
    undefined auStack_88 [48];
    int64_t var_58h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    cVar2 = *(char *)arg1;
    while (cVar2 != '\0') {
        if (cVar2 == '%') {
            if (*(char *)(arg1 + 1) != '%') break;
            arg1 = arg1 + 1;
        }
        pcVar1 = (char *)(arg1 + 1);
        arg1 = arg1 + 1;
        cVar2 = *pcVar1;
    }
    if ((*(char *)arg1 == '%') && (*(char *)(arg1 + 1) != '%')) {
        piVar3 = &var_58h;
        if ((char)var_58h == ' ') {
            do {
                piVar3 = (int64_t *)((int64_t)piVar3 + 1);
            } while (*(char *)piVar3 == ' ');
        }
        func_0x000180471c88();
        func_0x000180459870(var_18h ^ (uint64_t)auStack_88);
        return;
    }
    func_0x000180459870(*(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88 ^ (uint64_t)auStack_88, placeholder_1, 
                        (int32_t)arg3);
    return;
}

// ============================================================
// Function: FUN_18014d930
// Address: 0x18014d930
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d930(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar2 = (uint32_t)arg2;
    uVar5 = (uint32_t)arg4;
    uVar3 = (uint32_t)arg3;
    if (uVar3 != uVar5) {
        if (uVar3 < uVar5) {
            if (uVar2 < uVar3) {
                uVar1 = arg3 & 0xffffffff;
            } else {
                uVar1 = arg2 & 0xffffffff;
                if (uVar5 < uVar2) {
                    uVar1 = arg4 & 0xffffffff;
                }
            }
        } else {
            uVar1 = arg4 & 0xffffffffU;
            if ((uVar5 <= uVar2) && (uVar1 = arg2 & 0xffffffff, uVar3 < uVar2)) {
                uVar1 = arg3 & 0xffffffff;
            }
        }
        if (0.0 < (float)arg_28h) {
            uVar6 = arg4 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar6 = arg3 & 0xffffffff;
            }
            uVar4 = arg3 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar4 = arg4 & 0xffffffffU;
            }
            fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar10 = (float)uVar6;
            fVar8 = fVar10;
            if (((float)((uint32_t)fVar10 & 0x7fffffff) < (float)arg_28h) && (fVar8 = (float)arg_28h, fVar10 < 0.0)) {
                fVar8 = fVar7;
            }
            fVar9 = (float)uVar4;
            fVar11 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar11 = (float)arg_28h, fVar9 < 0.0)) {
                fVar11 = fVar7;
            }
            if ((((fVar10 != 0.0) || (fVar12 = fVar7, 0.0 <= fVar9)) && (fVar12 = fVar8, fVar9 == 0.0)) &&
               (fVar10 < 0.0)) {
                fVar11 = fVar7;
            }
            fVar8 = (float)uVar1;
            if ((fVar12 < fVar8) && (fVar8 < fVar11)) {
                if (0.0 <= (float)(uint64_t)(uint32_t)((int32_t)uVar4 * (int32_t)uVar6)) {
                    if ((fVar10 < 0.0) || (fVar9 < 0.0)) {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) /
                                             (float)((uint32_t)fVar11 ^ 0x80000000));
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, fVar8 / fVar12);
                        fcn.180491ba0();
                    }
                } else if ((float)(arg2 & 0xffffffff) != 0.0) {
                    if (0.0 <= (float)(arg2 & 0xffffffff)) {
                        fcn.180491ba0(uVar1, fVar8 / (float)arg_28h);
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) / (float)arg_28h);
                        fcn.180491ba0();
                    }
                }
            }
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18014d9b0
// Address: 0x18014d9b0
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d930(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar2 = (uint32_t)arg2;
    uVar5 = (uint32_t)arg4;
    uVar3 = (uint32_t)arg3;
    if (uVar3 != uVar5) {
        if (uVar3 < uVar5) {
            if (uVar2 < uVar3) {
                uVar1 = arg3 & 0xffffffff;
            } else {
                uVar1 = arg2 & 0xffffffff;
                if (uVar5 < uVar2) {
                    uVar1 = arg4 & 0xffffffff;
                }
            }
        } else {
            uVar1 = arg4 & 0xffffffffU;
            if ((uVar5 <= uVar2) && (uVar1 = arg2 & 0xffffffff, uVar3 < uVar2)) {
                uVar1 = arg3 & 0xffffffff;
            }
        }
        if (0.0 < (float)arg_28h) {
            uVar6 = arg4 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar6 = arg3 & 0xffffffff;
            }
            uVar4 = arg3 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar4 = arg4 & 0xffffffffU;
            }
            fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar10 = (float)uVar6;
            fVar8 = fVar10;
            if (((float)((uint32_t)fVar10 & 0x7fffffff) < (float)arg_28h) && (fVar8 = (float)arg_28h, fVar10 < 0.0)) {
                fVar8 = fVar7;
            }
            fVar9 = (float)uVar4;
            fVar11 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar11 = (float)arg_28h, fVar9 < 0.0)) {
                fVar11 = fVar7;
            }
            if ((((fVar10 != 0.0) || (fVar12 = fVar7, 0.0 <= fVar9)) && (fVar12 = fVar8, fVar9 == 0.0)) &&
               (fVar10 < 0.0)) {
                fVar11 = fVar7;
            }
            fVar8 = (float)uVar1;
            if ((fVar12 < fVar8) && (fVar8 < fVar11)) {
                if (0.0 <= (float)(uint64_t)(uint32_t)((int32_t)uVar4 * (int32_t)uVar6)) {
                    if ((fVar10 < 0.0) || (fVar9 < 0.0)) {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) /
                                             (float)((uint32_t)fVar11 ^ 0x80000000));
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, fVar8 / fVar12);
                        fcn.180491ba0();
                    }
                } else if ((float)(arg2 & 0xffffffff) != 0.0) {
                    if (0.0 <= (float)(arg2 & 0xffffffff)) {
                        fcn.180491ba0(uVar1, fVar8 / (float)arg_28h);
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) / (float)arg_28h);
                        fcn.180491ba0();
                    }
                }
            }
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18014d9ba
// Address: 0x18014d9ba
// Size: 212 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d930(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar2 = (uint32_t)arg2;
    uVar5 = (uint32_t)arg4;
    uVar3 = (uint32_t)arg3;
    if (uVar3 != uVar5) {
        if (uVar3 < uVar5) {
            if (uVar2 < uVar3) {
                uVar1 = arg3 & 0xffffffff;
            } else {
                uVar1 = arg2 & 0xffffffff;
                if (uVar5 < uVar2) {
                    uVar1 = arg4 & 0xffffffff;
                }
            }
        } else {
            uVar1 = arg4 & 0xffffffffU;
            if ((uVar5 <= uVar2) && (uVar1 = arg2 & 0xffffffff, uVar3 < uVar2)) {
                uVar1 = arg3 & 0xffffffff;
            }
        }
        if (0.0 < (float)arg_28h) {
            uVar6 = arg4 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar6 = arg3 & 0xffffffff;
            }
            uVar4 = arg3 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar4 = arg4 & 0xffffffffU;
            }
            fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar10 = (float)uVar6;
            fVar8 = fVar10;
            if (((float)((uint32_t)fVar10 & 0x7fffffff) < (float)arg_28h) && (fVar8 = (float)arg_28h, fVar10 < 0.0)) {
                fVar8 = fVar7;
            }
            fVar9 = (float)uVar4;
            fVar11 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar11 = (float)arg_28h, fVar9 < 0.0)) {
                fVar11 = fVar7;
            }
            if ((((fVar10 != 0.0) || (fVar12 = fVar7, 0.0 <= fVar9)) && (fVar12 = fVar8, fVar9 == 0.0)) &&
               (fVar10 < 0.0)) {
                fVar11 = fVar7;
            }
            fVar8 = (float)uVar1;
            if ((fVar12 < fVar8) && (fVar8 < fVar11)) {
                if (0.0 <= (float)(uint64_t)(uint32_t)((int32_t)uVar4 * (int32_t)uVar6)) {
                    if ((fVar10 < 0.0) || (fVar9 < 0.0)) {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) /
                                             (float)((uint32_t)fVar11 ^ 0x80000000));
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, fVar8 / fVar12);
                        fcn.180491ba0();
                    }
                } else if ((float)(arg2 & 0xffffffff) != 0.0) {
                    if (0.0 <= (float)(arg2 & 0xffffffff)) {
                        fcn.180491ba0(uVar1, fVar8 / (float)arg_28h);
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) / (float)arg_28h);
                        fcn.180491ba0();
                    }
                }
            }
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18014da8e
// Address: 0x18014da8e
// Size: 315 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d930(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar2 = (uint32_t)arg2;
    uVar5 = (uint32_t)arg4;
    uVar3 = (uint32_t)arg3;
    if (uVar3 != uVar5) {
        if (uVar3 < uVar5) {
            if (uVar2 < uVar3) {
                uVar1 = arg3 & 0xffffffff;
            } else {
                uVar1 = arg2 & 0xffffffff;
                if (uVar5 < uVar2) {
                    uVar1 = arg4 & 0xffffffff;
                }
            }
        } else {
            uVar1 = arg4 & 0xffffffffU;
            if ((uVar5 <= uVar2) && (uVar1 = arg2 & 0xffffffff, uVar3 < uVar2)) {
                uVar1 = arg3 & 0xffffffff;
            }
        }
        if (0.0 < (float)arg_28h) {
            uVar6 = arg4 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar6 = arg3 & 0xffffffff;
            }
            uVar4 = arg3 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar4 = arg4 & 0xffffffffU;
            }
            fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar10 = (float)uVar6;
            fVar8 = fVar10;
            if (((float)((uint32_t)fVar10 & 0x7fffffff) < (float)arg_28h) && (fVar8 = (float)arg_28h, fVar10 < 0.0)) {
                fVar8 = fVar7;
            }
            fVar9 = (float)uVar4;
            fVar11 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar11 = (float)arg_28h, fVar9 < 0.0)) {
                fVar11 = fVar7;
            }
            if ((((fVar10 != 0.0) || (fVar12 = fVar7, 0.0 <= fVar9)) && (fVar12 = fVar8, fVar9 == 0.0)) &&
               (fVar10 < 0.0)) {
                fVar11 = fVar7;
            }
            fVar8 = (float)uVar1;
            if ((fVar12 < fVar8) && (fVar8 < fVar11)) {
                if (0.0 <= (float)(uint64_t)(uint32_t)((int32_t)uVar4 * (int32_t)uVar6)) {
                    if ((fVar10 < 0.0) || (fVar9 < 0.0)) {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) /
                                             (float)((uint32_t)fVar11 ^ 0x80000000));
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, fVar8 / fVar12);
                        fcn.180491ba0();
                    }
                } else if ((float)(arg2 & 0xffffffff) != 0.0) {
                    if (0.0 <= (float)(arg2 & 0xffffffff)) {
                        fcn.180491ba0(uVar1, fVar8 / (float)arg_28h);
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) / (float)arg_28h);
                        fcn.180491ba0();
                    }
                }
            }
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18014dbc9
// Address: 0x18014dbc9
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d930(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar2 = (uint32_t)arg2;
    uVar5 = (uint32_t)arg4;
    uVar3 = (uint32_t)arg3;
    if (uVar3 != uVar5) {
        if (uVar3 < uVar5) {
            if (uVar2 < uVar3) {
                uVar1 = arg3 & 0xffffffff;
            } else {
                uVar1 = arg2 & 0xffffffff;
                if (uVar5 < uVar2) {
                    uVar1 = arg4 & 0xffffffff;
                }
            }
        } else {
            uVar1 = arg4 & 0xffffffffU;
            if ((uVar5 <= uVar2) && (uVar1 = arg2 & 0xffffffff, uVar3 < uVar2)) {
                uVar1 = arg3 & 0xffffffff;
            }
        }
        if (0.0 < (float)arg_28h) {
            uVar6 = arg4 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar6 = arg3 & 0xffffffff;
            }
            uVar4 = arg3 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar4 = arg4 & 0xffffffffU;
            }
            fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar10 = (float)uVar6;
            fVar8 = fVar10;
            if (((float)((uint32_t)fVar10 & 0x7fffffff) < (float)arg_28h) && (fVar8 = (float)arg_28h, fVar10 < 0.0)) {
                fVar8 = fVar7;
            }
            fVar9 = (float)uVar4;
            fVar11 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar11 = (float)arg_28h, fVar9 < 0.0)) {
                fVar11 = fVar7;
            }
            if ((((fVar10 != 0.0) || (fVar12 = fVar7, 0.0 <= fVar9)) && (fVar12 = fVar8, fVar9 == 0.0)) &&
               (fVar10 < 0.0)) {
                fVar11 = fVar7;
            }
            fVar8 = (float)uVar1;
            if ((fVar12 < fVar8) && (fVar8 < fVar11)) {
                if (0.0 <= (float)(uint64_t)(uint32_t)((int32_t)uVar4 * (int32_t)uVar6)) {
                    if ((fVar10 < 0.0) || (fVar9 < 0.0)) {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) /
                                             (float)((uint32_t)fVar11 ^ 0x80000000));
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, fVar8 / fVar12);
                        fcn.180491ba0();
                    }
                } else if ((float)(arg2 & 0xffffffff) != 0.0) {
                    if (0.0 <= (float)(arg2 & 0xffffffff)) {
                        fcn.180491ba0(uVar1, fVar8 / (float)arg_28h);
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) / (float)arg_28h);
                        fcn.180491ba0();
                    }
                }
            }
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18014dbe5
// Address: 0x18014dbe5
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d930(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar2 = (uint32_t)arg2;
    uVar5 = (uint32_t)arg4;
    uVar3 = (uint32_t)arg3;
    if (uVar3 != uVar5) {
        if (uVar3 < uVar5) {
            if (uVar2 < uVar3) {
                uVar1 = arg3 & 0xffffffff;
            } else {
                uVar1 = arg2 & 0xffffffff;
                if (uVar5 < uVar2) {
                    uVar1 = arg4 & 0xffffffff;
                }
            }
        } else {
            uVar1 = arg4 & 0xffffffffU;
            if ((uVar5 <= uVar2) && (uVar1 = arg2 & 0xffffffff, uVar3 < uVar2)) {
                uVar1 = arg3 & 0xffffffff;
            }
        }
        if (0.0 < (float)arg_28h) {
            uVar6 = arg4 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar6 = arg3 & 0xffffffff;
            }
            uVar4 = arg3 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar4 = arg4 & 0xffffffffU;
            }
            fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar10 = (float)uVar6;
            fVar8 = fVar10;
            if (((float)((uint32_t)fVar10 & 0x7fffffff) < (float)arg_28h) && (fVar8 = (float)arg_28h, fVar10 < 0.0)) {
                fVar8 = fVar7;
            }
            fVar9 = (float)uVar4;
            fVar11 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar11 = (float)arg_28h, fVar9 < 0.0)) {
                fVar11 = fVar7;
            }
            if ((((fVar10 != 0.0) || (fVar12 = fVar7, 0.0 <= fVar9)) && (fVar12 = fVar8, fVar9 == 0.0)) &&
               (fVar10 < 0.0)) {
                fVar11 = fVar7;
            }
            fVar8 = (float)uVar1;
            if ((fVar12 < fVar8) && (fVar8 < fVar11)) {
                if (0.0 <= (float)(uint64_t)(uint32_t)((int32_t)uVar4 * (int32_t)uVar6)) {
                    if ((fVar10 < 0.0) || (fVar9 < 0.0)) {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) /
                                             (float)((uint32_t)fVar11 ^ 0x80000000));
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, fVar8 / fVar12);
                        fcn.180491ba0();
                    }
                } else if ((float)(arg2 & 0xffffffff) != 0.0) {
                    if (0.0 <= (float)(arg2 & 0xffffffff)) {
                        fcn.180491ba0(uVar1, fVar8 / (float)arg_28h);
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) / (float)arg_28h);
                        fcn.180491ba0();
                    }
                }
            }
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18014dbf6
// Address: 0x18014dbf6
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d930(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar2 = (uint32_t)arg2;
    uVar5 = (uint32_t)arg4;
    uVar3 = (uint32_t)arg3;
    if (uVar3 != uVar5) {
        if (uVar3 < uVar5) {
            if (uVar2 < uVar3) {
                uVar1 = arg3 & 0xffffffff;
            } else {
                uVar1 = arg2 & 0xffffffff;
                if (uVar5 < uVar2) {
                    uVar1 = arg4 & 0xffffffff;
                }
            }
        } else {
            uVar1 = arg4 & 0xffffffffU;
            if ((uVar5 <= uVar2) && (uVar1 = arg2 & 0xffffffff, uVar3 < uVar2)) {
                uVar1 = arg3 & 0xffffffff;
            }
        }
        if (0.0 < (float)arg_28h) {
            uVar6 = arg4 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar6 = arg3 & 0xffffffff;
            }
            uVar4 = arg3 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar4 = arg4 & 0xffffffffU;
            }
            fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar10 = (float)uVar6;
            fVar8 = fVar10;
            if (((float)((uint32_t)fVar10 & 0x7fffffff) < (float)arg_28h) && (fVar8 = (float)arg_28h, fVar10 < 0.0)) {
                fVar8 = fVar7;
            }
            fVar9 = (float)uVar4;
            fVar11 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar11 = (float)arg_28h, fVar9 < 0.0)) {
                fVar11 = fVar7;
            }
            if ((((fVar10 != 0.0) || (fVar12 = fVar7, 0.0 <= fVar9)) && (fVar12 = fVar8, fVar9 == 0.0)) &&
               (fVar10 < 0.0)) {
                fVar11 = fVar7;
            }
            fVar8 = (float)uVar1;
            if ((fVar12 < fVar8) && (fVar8 < fVar11)) {
                if (0.0 <= (float)(uint64_t)(uint32_t)((int32_t)uVar4 * (int32_t)uVar6)) {
                    if ((fVar10 < 0.0) || (fVar9 < 0.0)) {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) /
                                             (float)((uint32_t)fVar11 ^ 0x80000000));
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, fVar8 / fVar12);
                        fcn.180491ba0();
                    }
                } else if ((float)(arg2 & 0xffffffff) != 0.0) {
                    if (0.0 <= (float)(arg2 & 0xffffffff)) {
                        fcn.180491ba0(uVar1, fVar8 / (float)arg_28h);
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) / (float)arg_28h);
                        fcn.180491ba0();
                    }
                }
            }
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18014dc05
// Address: 0x18014dc05
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014d930(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar2 = (uint32_t)arg2;
    uVar5 = (uint32_t)arg4;
    uVar3 = (uint32_t)arg3;
    if (uVar3 != uVar5) {
        if (uVar3 < uVar5) {
            if (uVar2 < uVar3) {
                uVar1 = arg3 & 0xffffffff;
            } else {
                uVar1 = arg2 & 0xffffffff;
                if (uVar5 < uVar2) {
                    uVar1 = arg4 & 0xffffffff;
                }
            }
        } else {
            uVar1 = arg4 & 0xffffffffU;
            if ((uVar5 <= uVar2) && (uVar1 = arg2 & 0xffffffff, uVar3 < uVar2)) {
                uVar1 = arg3 & 0xffffffff;
            }
        }
        if (0.0 < (float)arg_28h) {
            uVar6 = arg4 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar6 = arg3 & 0xffffffff;
            }
            uVar4 = arg3 & 0xffffffff;
            if (uVar3 <= uVar5) {
                uVar4 = arg4 & 0xffffffffU;
            }
            fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar10 = (float)uVar6;
            fVar8 = fVar10;
            if (((float)((uint32_t)fVar10 & 0x7fffffff) < (float)arg_28h) && (fVar8 = (float)arg_28h, fVar10 < 0.0)) {
                fVar8 = fVar7;
            }
            fVar9 = (float)uVar4;
            fVar11 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar11 = (float)arg_28h, fVar9 < 0.0)) {
                fVar11 = fVar7;
            }
            if ((((fVar10 != 0.0) || (fVar12 = fVar7, 0.0 <= fVar9)) && (fVar12 = fVar8, fVar9 == 0.0)) &&
               (fVar10 < 0.0)) {
                fVar11 = fVar7;
            }
            fVar8 = (float)uVar1;
            if ((fVar12 < fVar8) && (fVar8 < fVar11)) {
                if (0.0 <= (float)(uint64_t)(uint32_t)((int32_t)uVar4 * (int32_t)uVar6)) {
                    if ((fVar10 < 0.0) || (fVar9 < 0.0)) {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) /
                                             (float)((uint32_t)fVar11 ^ 0x80000000));
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, fVar8 / fVar12);
                        fcn.180491ba0();
                    }
                } else if ((float)(arg2 & 0xffffffff) != 0.0) {
                    if (0.0 <= (float)(arg2 & 0xffffffff)) {
                        fcn.180491ba0(uVar1, fVar8 / (float)arg_28h);
                        fcn.180491ba0();
                    } else {
                        fcn.180491ba0(uVar1, (float)((uint32_t)fVar8 ^ 0x80000000) / (float)arg_28h);
                        fcn.180491ba0();
                    }
                }
            }
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18014dc40
// Address: 0x18014dc40
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h

uint64_t fcn.18014dc40(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                      int64_t arg_30h)
{
    int64_t arg_38h;
    uint32_t uVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    float fVar4;
    float in_XMM1_Da;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    undefined4 unaff_XMM9_Da;
    float fVar9;
    undefined4 unaff_XMM9_Db;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar1 = (uint32_t)arg3;
    if ((0.0 < in_XMM1_Da) && (uVar2 = (uint32_t)arg4, uVar1 != uVar2)) {
        if (1.0 <= in_XMM1_Da) {
            return arg4 & 0xffffffff;
        }
        arg_38h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                uVar3 = (uint64_t)((float)(uint64_t)(uVar2 - uVar1) * in_XMM1_Da + (float)(arg3 & 0xffffffff));
            } else {
                uVar3 = 0;
                if (in_XMM1_Da < 1.0) {
                    if (uVar2 < uVar1) {
                        fVar5 = -0.5;
                    } else {
                        fVar5 = 0.5;
                    }
                    uVar3 = (uint64_t)((int32_t)((float)(uVar2 - uVar1) * in_XMM1_Da + fVar5) + uVar1);
                }
            }
        } else {
            fVar4 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar9 = (float)(arg3 & 0xffffffff);
            fVar5 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar5 = (float)arg_28h, fVar9 < 0.0)) {
                fVar5 = fVar4;
            }
            fVar6 = (float)(arg4 & 0xffffffff);
            fVar7 = fVar6;
            if (((float)((uint32_t)fVar6 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar6 < 0.0)) {
                fVar7 = fVar4;
            }
            fVar8 = fVar7;
            if (uVar2 < uVar1) {
                fVar8 = fVar5;
                fVar5 = fVar7;
            }
            if ((fVar6 == 0.0) && (fVar9 < 0.0)) {
                fVar8 = fVar4;
            }
            if (uVar2 < uVar1) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= (float)(uint64_t)(uVar1 * uVar2)) {
                if ((fVar9 < 0.0) || (fVar6 < 0.0)) {
                    fVar5 = (float)fcn.180492580(arg_38h);
                    uVar3 = (uint64_t)(float)((uint32_t)(fVar5 * (float)((uint32_t)fVar8 ^ 0x80000000)) ^ 0x80000000);
                } else {
                    fVar4 = (float)fcn.180492580(arg_38h);
                    uVar3 = (uint64_t)(fVar4 * fVar5);
                }
            } else {
                uVar3 = arg4 & 0xffffffff;
                if (uVar1 < uVar2) {
                    uVar3 = arg3 & 0xffffffff;
                }
                fVar5 = (float)((uint32_t)(float)uVar3 ^ 0x80000000) / (float)((uint32_t)(fVar6 - fVar9) & 0x7fffffff);
                if ((in_XMM1_Da < fVar5 - (float)arg_30h) || (fVar5 + (float)arg_30h < in_XMM1_Da)) {
                    if (fVar5 <= in_XMM1_Da) {
                        fVar5 = (float)fcn.180492580(arg_38h);
                        uVar3 = (uint64_t)(fVar5 * (float)arg_28h);
                    } else {
                        fVar5 = (float)fcn.180492580(arg_38h);
                        uVar3 = (uint64_t)(float)((uint32_t)(fVar5 * (float)arg_28h) ^ 0x80000000);
                    }
                } else {
                    uVar3 = 0;
                }
            }
        }
        return uVar3;
    }
    return arg3 & 0xffffffff;
}

// ============================================================
// Function: FUN_18014dc71
// Address: 0x18014dc71
// Size: 623 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h

uint64_t fcn.18014dc40(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                      int64_t arg_30h)
{
    int64_t arg_38h;
    uint32_t uVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    float fVar4;
    float in_XMM1_Da;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    undefined4 unaff_XMM9_Da;
    float fVar9;
    undefined4 unaff_XMM9_Db;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar1 = (uint32_t)arg3;
    if ((0.0 < in_XMM1_Da) && (uVar2 = (uint32_t)arg4, uVar1 != uVar2)) {
        if (1.0 <= in_XMM1_Da) {
            return arg4 & 0xffffffff;
        }
        arg_38h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                uVar3 = (uint64_t)((float)(uint64_t)(uVar2 - uVar1) * in_XMM1_Da + (float)(arg3 & 0xffffffff));
            } else {
                uVar3 = 0;
                if (in_XMM1_Da < 1.0) {
                    if (uVar2 < uVar1) {
                        fVar5 = -0.5;
                    } else {
                        fVar5 = 0.5;
                    }
                    uVar3 = (uint64_t)((int32_t)((float)(uVar2 - uVar1) * in_XMM1_Da + fVar5) + uVar1);
                }
            }
        } else {
            fVar4 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar9 = (float)(arg3 & 0xffffffff);
            fVar5 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar5 = (float)arg_28h, fVar9 < 0.0)) {
                fVar5 = fVar4;
            }
            fVar6 = (float)(arg4 & 0xffffffff);
            fVar7 = fVar6;
            if (((float)((uint32_t)fVar6 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar6 < 0.0)) {
                fVar7 = fVar4;
            }
            fVar8 = fVar7;
            if (uVar2 < uVar1) {
                fVar8 = fVar5;
                fVar5 = fVar7;
            }
            if ((fVar6 == 0.0) && (fVar9 < 0.0)) {
                fVar8 = fVar4;
            }
            if (uVar2 < uVar1) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= (float)(uint64_t)(uVar1 * uVar2)) {
                if ((fVar9 < 0.0) || (fVar6 < 0.0)) {
                    fVar5 = (float)fcn.180492580(arg_38h);
                    uVar3 = (uint64_t)(float)((uint32_t)(fVar5 * (float)((uint32_t)fVar8 ^ 0x80000000)) ^ 0x80000000);
                } else {
                    fVar4 = (float)fcn.180492580(arg_38h);
                    uVar3 = (uint64_t)(fVar4 * fVar5);
                }
            } else {
                uVar3 = arg4 & 0xffffffff;
                if (uVar1 < uVar2) {
                    uVar3 = arg3 & 0xffffffff;
                }
                fVar5 = (float)((uint32_t)(float)uVar3 ^ 0x80000000) / (float)((uint32_t)(fVar6 - fVar9) & 0x7fffffff);
                if ((in_XMM1_Da < fVar5 - (float)arg_30h) || (fVar5 + (float)arg_30h < in_XMM1_Da)) {
                    if (fVar5 <= in_XMM1_Da) {
                        fVar5 = (float)fcn.180492580(arg_38h);
                        uVar3 = (uint64_t)(fVar5 * (float)arg_28h);
                    } else {
                        fVar5 = (float)fcn.180492580(arg_38h);
                        uVar3 = (uint64_t)(float)((uint32_t)(fVar5 * (float)arg_28h) ^ 0x80000000);
                    }
                } else {
                    uVar3 = 0;
                }
            }
        }
        return uVar3;
    }
    return arg3 & 0xffffffff;
}

// ============================================================
// Function: FUN_18014dee0
// Address: 0x18014dee0
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h

uint64_t fcn.18014dc40(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                      int64_t arg_30h)
{
    int64_t arg_38h;
    uint32_t uVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    float fVar4;
    float in_XMM1_Da;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    undefined4 unaff_XMM9_Da;
    float fVar9;
    undefined4 unaff_XMM9_Db;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar1 = (uint32_t)arg3;
    if ((0.0 < in_XMM1_Da) && (uVar2 = (uint32_t)arg4, uVar1 != uVar2)) {
        if (1.0 <= in_XMM1_Da) {
            return arg4 & 0xffffffff;
        }
        arg_38h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                uVar3 = (uint64_t)((float)(uint64_t)(uVar2 - uVar1) * in_XMM1_Da + (float)(arg3 & 0xffffffff));
            } else {
                uVar3 = 0;
                if (in_XMM1_Da < 1.0) {
                    if (uVar2 < uVar1) {
                        fVar5 = -0.5;
                    } else {
                        fVar5 = 0.5;
                    }
                    uVar3 = (uint64_t)((int32_t)((float)(uVar2 - uVar1) * in_XMM1_Da + fVar5) + uVar1);
                }
            }
        } else {
            fVar4 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            fVar9 = (float)(arg3 & 0xffffffff);
            fVar5 = fVar9;
            if (((float)((uint32_t)fVar9 & 0x7fffffff) < (float)arg_28h) && (fVar5 = (float)arg_28h, fVar9 < 0.0)) {
                fVar5 = fVar4;
            }
            fVar6 = (float)(arg4 & 0xffffffff);
            fVar7 = fVar6;
            if (((float)((uint32_t)fVar6 & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, fVar6 < 0.0)) {
                fVar7 = fVar4;
            }
            fVar8 = fVar7;
            if (uVar2 < uVar1) {
                fVar8 = fVar5;
                fVar5 = fVar7;
            }
            if ((fVar6 == 0.0) && (fVar9 < 0.0)) {
                fVar8 = fVar4;
            }
            if (uVar2 < uVar1) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= (float)(uint64_t)(uVar1 * uVar2)) {
                if ((fVar9 < 0.0) || (fVar6 < 0.0)) {
                    fVar5 = (float)fcn.180492580(arg_38h);
                    uVar3 = (uint64_t)(float)((uint32_t)(fVar5 * (float)((uint32_t)fVar8 ^ 0x80000000)) ^ 0x80000000);
                } else {
                    fVar4 = (float)fcn.180492580(arg_38h);
                    uVar3 = (uint64_t)(fVar4 * fVar5);
                }
            } else {
                uVar3 = arg4 & 0xffffffff;
                if (uVar1 < uVar2) {
                    uVar3 = arg3 & 0xffffffff;
                }
                fVar5 = (float)((uint32_t)(float)uVar3 ^ 0x80000000) / (float)((uint32_t)(fVar6 - fVar9) & 0x7fffffff);
                if ((in_XMM1_Da < fVar5 - (float)arg_30h) || (fVar5 + (float)arg_30h < in_XMM1_Da)) {
                    if (fVar5 <= in_XMM1_Da) {
                        fVar5 = (float)fcn.180492580(arg_38h);
                        uVar3 = (uint64_t)(fVar5 * (float)arg_28h);
                    } else {
                        fVar5 = (float)fcn.180492580(arg_38h);
                        uVar3 = (uint64_t)(float)((uint32_t)(fVar5 * (float)arg_28h) ^ 0x80000000);
                    }
                } else {
                    uVar3 = 0;
                }
            }
        }
        return uVar3;
    }
    return arg3 & 0xffffffff;
}

// ============================================================
// Function: FUN_18014def0
// Address: 0x18014def0
// Size: 143 bytes
// ============================================================
void fcn.18014def0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    char *pcVar1;
    char cVar2;
    int64_t *piVar3;
    undefined auStack_88 [48];
    int64_t var_58h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    cVar2 = *(char *)arg1;
    while (cVar2 != '\0') {
        if (cVar2 == '%') {
            if (*(char *)(arg1 + 1) != '%') break;
            arg1 = arg1 + 1;
        }
        pcVar1 = (char *)(arg1 + 1);
        arg1 = arg1 + 1;
        cVar2 = *pcVar1;
    }
    if ((*(char *)arg1 == '%') && (*(char *)(arg1 + 1) != '%')) {
        piVar3 = &var_58h;
        if ((char)var_58h == ' ') {
            do {
                piVar3 = (int64_t *)((int64_t)piVar3 + 1);
            } while (*(char *)piVar3 == ' ');
        }
        func_0x000180471c88();
        func_0x000180459870(var_18h ^ (uint64_t)auStack_88);
        return;
    }
    func_0x000180459870(*(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88 ^ (uint64_t)auStack_88, placeholder_1, 
                        (int32_t)arg3);
    return;
}

// ============================================================
// Function: FUN_18014df80
// Address: 0x18014df80
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

float fcn.18014df80(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h
                   , int64_t arg_88h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg3 == arg4) {
        return 0.0;
    }
    if (arg3 < arg4) {
        iVar2 = arg3;
        if ((arg3 <= arg2) && (iVar2 = arg2, arg4 < arg2)) {
            iVar2 = arg4;
        }
    } else {
        iVar2 = arg4;
        if ((arg4 <= arg2) && (iVar2 = arg2, arg3 < arg2)) {
            iVar2 = arg3;
        }
    }
    fVar8 = 0.0;
    if ((float)arg_28h <= 0.0) {
        return (float)(iVar2 - arg3) / (float)(arg4 - arg3);
    }
    iVar3 = arg3;
    iVar1 = arg4;
    if (arg3 <= arg4) {
        iVar3 = arg4;
        iVar1 = arg3;
    }
    dVar5 = (double)iVar1;
    dVar6 = (double)(float)arg_28h;
    fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
    fVar11 = (float)iVar1;
    if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar6) {
        fVar9 = (float)arg_28h;
        if (fVar11 < 0.0) {
            fVar9 = fVar10;
        }
        dVar5 = (double)fVar9;
    }
    dVar4 = (double)iVar3;
    fVar9 = (float)iVar3;
    if ((double)((uint64_t)dVar4 & 0x7fffffffffffffff) < dVar6) {
        if (fVar9 < 0.0) {
            arg_28h._0_4_ = fVar10;
        }
        dVar4 = (double)(float)arg_28h;
    }
    if ((fVar11 != 0.0) || (0.0 <= fVar9)) {
        if ((fVar9 == 0.0) && (fVar11 < 0.0)) {
            dVar4 = (double)fVar10;
        }
    } else {
        dVar5 = (double)fVar10;
    }
    dVar7 = (double)iVar2;
    if (dVar5 < dVar7) {
        if (dVar7 < dVar4) {
            if (0.0 <= (float)(iVar3 * iVar1)) {
                if ((fVar11 < 0.0) || (fVar9 < 0.0)) {
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar4 ^ 0x8000000000000000));
                    dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar4 ^ 0x8000000000000000));
                    fVar8 = 1.0 - (float)(dVar6 / dVar5);
                } else {
                    dVar6 = (double)fcn.180491150(dVar7 / dVar5);
                    dVar5 = (double)fcn.180491150(dVar4 / dVar5);
                    fVar8 = (float)(dVar6 / dVar5);
                }
            } else {
                fVar8 = (float)((uint32_t)fVar11 ^ 0x80000000) / (fVar9 - fVar11);
                if ((float)arg2 != 0.0) {
                    if (0.0 <= (float)arg2) {
                        dVar5 = (double)fcn.180491150(dVar7 / dVar6);
                        dVar6 = (double)fcn.180491150(dVar4 / dVar6);
                        fVar8 = (float)(dVar5 / dVar6) * (1.0 - (fVar8 + (float)arg_30h)) + fVar8 + (float)arg_30h;
                    } else {
                        dVar4 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) / dVar6);
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) / dVar6);
                        fVar8 = (1.0 - (float)(dVar4 / dVar5)) * (fVar8 - (float)arg_30h);
                    }
                }
            }
        } else {
            fVar8 = 1.0;
        }
    }
    if (arg3 <= arg4) {
        return fVar8;
    }
    return 1.0 - fVar8;
}

// ============================================================
// Function: FUN_18014dfed
// Address: 0x18014dfed
// Size: 660 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

float fcn.18014df80(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h
                   , int64_t arg_88h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg3 == arg4) {
        return 0.0;
    }
    if (arg3 < arg4) {
        iVar2 = arg3;
        if ((arg3 <= arg2) && (iVar2 = arg2, arg4 < arg2)) {
            iVar2 = arg4;
        }
    } else {
        iVar2 = arg4;
        if ((arg4 <= arg2) && (iVar2 = arg2, arg3 < arg2)) {
            iVar2 = arg3;
        }
    }
    fVar8 = 0.0;
    if ((float)arg_28h <= 0.0) {
        return (float)(iVar2 - arg3) / (float)(arg4 - arg3);
    }
    iVar3 = arg3;
    iVar1 = arg4;
    if (arg3 <= arg4) {
        iVar3 = arg4;
        iVar1 = arg3;
    }
    dVar5 = (double)iVar1;
    dVar6 = (double)(float)arg_28h;
    fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
    fVar11 = (float)iVar1;
    if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar6) {
        fVar9 = (float)arg_28h;
        if (fVar11 < 0.0) {
            fVar9 = fVar10;
        }
        dVar5 = (double)fVar9;
    }
    dVar4 = (double)iVar3;
    fVar9 = (float)iVar3;
    if ((double)((uint64_t)dVar4 & 0x7fffffffffffffff) < dVar6) {
        if (fVar9 < 0.0) {
            arg_28h._0_4_ = fVar10;
        }
        dVar4 = (double)(float)arg_28h;
    }
    if ((fVar11 != 0.0) || (0.0 <= fVar9)) {
        if ((fVar9 == 0.0) && (fVar11 < 0.0)) {
            dVar4 = (double)fVar10;
        }
    } else {
        dVar5 = (double)fVar10;
    }
    dVar7 = (double)iVar2;
    if (dVar5 < dVar7) {
        if (dVar7 < dVar4) {
            if (0.0 <= (float)(iVar3 * iVar1)) {
                if ((fVar11 < 0.0) || (fVar9 < 0.0)) {
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar4 ^ 0x8000000000000000));
                    dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar4 ^ 0x8000000000000000));
                    fVar8 = 1.0 - (float)(dVar6 / dVar5);
                } else {
                    dVar6 = (double)fcn.180491150(dVar7 / dVar5);
                    dVar5 = (double)fcn.180491150(dVar4 / dVar5);
                    fVar8 = (float)(dVar6 / dVar5);
                }
            } else {
                fVar8 = (float)((uint32_t)fVar11 ^ 0x80000000) / (fVar9 - fVar11);
                if ((float)arg2 != 0.0) {
                    if (0.0 <= (float)arg2) {
                        dVar5 = (double)fcn.180491150(dVar7 / dVar6);
                        dVar6 = (double)fcn.180491150(dVar4 / dVar6);
                        fVar8 = (float)(dVar5 / dVar6) * (1.0 - (fVar8 + (float)arg_30h)) + fVar8 + (float)arg_30h;
                    } else {
                        dVar4 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) / dVar6);
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) / dVar6);
                        fVar8 = (1.0 - (float)(dVar4 / dVar5)) * (fVar8 - (float)arg_30h);
                    }
                }
            }
        } else {
            fVar8 = 1.0;
        }
    }
    if (arg3 <= arg4) {
        return fVar8;
    }
    return 1.0 - fVar8;
}

// ============================================================
// Function: FUN_18014e281
// Address: 0x18014e281
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

float fcn.18014df80(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h
                   , int64_t arg_88h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg3 == arg4) {
        return 0.0;
    }
    if (arg3 < arg4) {
        iVar2 = arg3;
        if ((arg3 <= arg2) && (iVar2 = arg2, arg4 < arg2)) {
            iVar2 = arg4;
        }
    } else {
        iVar2 = arg4;
        if ((arg4 <= arg2) && (iVar2 = arg2, arg3 < arg2)) {
            iVar2 = arg3;
        }
    }
    fVar8 = 0.0;
    if ((float)arg_28h <= 0.0) {
        return (float)(iVar2 - arg3) / (float)(arg4 - arg3);
    }
    iVar3 = arg3;
    iVar1 = arg4;
    if (arg3 <= arg4) {
        iVar3 = arg4;
        iVar1 = arg3;
    }
    dVar5 = (double)iVar1;
    dVar6 = (double)(float)arg_28h;
    fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
    fVar11 = (float)iVar1;
    if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar6) {
        fVar9 = (float)arg_28h;
        if (fVar11 < 0.0) {
            fVar9 = fVar10;
        }
        dVar5 = (double)fVar9;
    }
    dVar4 = (double)iVar3;
    fVar9 = (float)iVar3;
    if ((double)((uint64_t)dVar4 & 0x7fffffffffffffff) < dVar6) {
        if (fVar9 < 0.0) {
            arg_28h._0_4_ = fVar10;
        }
        dVar4 = (double)(float)arg_28h;
    }
    if ((fVar11 != 0.0) || (0.0 <= fVar9)) {
        if ((fVar9 == 0.0) && (fVar11 < 0.0)) {
            dVar4 = (double)fVar10;
        }
    } else {
        dVar5 = (double)fVar10;
    }
    dVar7 = (double)iVar2;
    if (dVar5 < dVar7) {
        if (dVar7 < dVar4) {
            if (0.0 <= (float)(iVar3 * iVar1)) {
                if ((fVar11 < 0.0) || (fVar9 < 0.0)) {
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar4 ^ 0x8000000000000000));
                    dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar4 ^ 0x8000000000000000));
                    fVar8 = 1.0 - (float)(dVar6 / dVar5);
                } else {
                    dVar6 = (double)fcn.180491150(dVar7 / dVar5);
                    dVar5 = (double)fcn.180491150(dVar4 / dVar5);
                    fVar8 = (float)(dVar6 / dVar5);
                }
            } else {
                fVar8 = (float)((uint32_t)fVar11 ^ 0x80000000) / (fVar9 - fVar11);
                if ((float)arg2 != 0.0) {
                    if (0.0 <= (float)arg2) {
                        dVar5 = (double)fcn.180491150(dVar7 / dVar6);
                        dVar6 = (double)fcn.180491150(dVar4 / dVar6);
                        fVar8 = (float)(dVar5 / dVar6) * (1.0 - (fVar8 + (float)arg_30h)) + fVar8 + (float)arg_30h;
                    } else {
                        dVar4 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) / dVar6);
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) / dVar6);
                        fVar8 = (1.0 - (float)(dVar4 / dVar5)) * (fVar8 - (float)arg_30h);
                    }
                }
            }
        } else {
            fVar8 = 1.0;
        }
    }
    if (arg3 <= arg4) {
        return fVar8;
    }
    return 1.0 - fVar8;
}

// ============================================================
// Function: FUN_18014e2a1
// Address: 0x18014e2a1
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

float fcn.18014df80(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h
                   , int64_t arg_88h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg3 == arg4) {
        return 0.0;
    }
    if (arg3 < arg4) {
        iVar2 = arg3;
        if ((arg3 <= arg2) && (iVar2 = arg2, arg4 < arg2)) {
            iVar2 = arg4;
        }
    } else {
        iVar2 = arg4;
        if ((arg4 <= arg2) && (iVar2 = arg2, arg3 < arg2)) {
            iVar2 = arg3;
        }
    }
    fVar8 = 0.0;
    if ((float)arg_28h <= 0.0) {
        return (float)(iVar2 - arg3) / (float)(arg4 - arg3);
    }
    iVar3 = arg3;
    iVar1 = arg4;
    if (arg3 <= arg4) {
        iVar3 = arg4;
        iVar1 = arg3;
    }
    dVar5 = (double)iVar1;
    dVar6 = (double)(float)arg_28h;
    fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
    fVar11 = (float)iVar1;
    if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar6) {
        fVar9 = (float)arg_28h;
        if (fVar11 < 0.0) {
            fVar9 = fVar10;
        }
        dVar5 = (double)fVar9;
    }
    dVar4 = (double)iVar3;
    fVar9 = (float)iVar3;
    if ((double)((uint64_t)dVar4 & 0x7fffffffffffffff) < dVar6) {
        if (fVar9 < 0.0) {
            arg_28h._0_4_ = fVar10;
        }
        dVar4 = (double)(float)arg_28h;
    }
    if ((fVar11 != 0.0) || (0.0 <= fVar9)) {
        if ((fVar9 == 0.0) && (fVar11 < 0.0)) {
            dVar4 = (double)fVar10;
        }
    } else {
        dVar5 = (double)fVar10;
    }
    dVar7 = (double)iVar2;
    if (dVar5 < dVar7) {
        if (dVar7 < dVar4) {
            if (0.0 <= (float)(iVar3 * iVar1)) {
                if ((fVar11 < 0.0) || (fVar9 < 0.0)) {
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar4 ^ 0x8000000000000000));
                    dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar4 ^ 0x8000000000000000));
                    fVar8 = 1.0 - (float)(dVar6 / dVar5);
                } else {
                    dVar6 = (double)fcn.180491150(dVar7 / dVar5);
                    dVar5 = (double)fcn.180491150(dVar4 / dVar5);
                    fVar8 = (float)(dVar6 / dVar5);
                }
            } else {
                fVar8 = (float)((uint32_t)fVar11 ^ 0x80000000) / (fVar9 - fVar11);
                if ((float)arg2 != 0.0) {
                    if (0.0 <= (float)arg2) {
                        dVar5 = (double)fcn.180491150(dVar7 / dVar6);
                        dVar6 = (double)fcn.180491150(dVar4 / dVar6);
                        fVar8 = (float)(dVar5 / dVar6) * (1.0 - (fVar8 + (float)arg_30h)) + fVar8 + (float)arg_30h;
                    } else {
                        dVar4 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) / dVar6);
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) / dVar6);
                        fVar8 = (1.0 - (float)(dVar4 / dVar5)) * (fVar8 - (float)arg_30h);
                    }
                }
            }
        } else {
            fVar8 = 1.0;
        }
    }
    if (arg3 <= arg4) {
        return fVar8;
    }
    return 1.0 - fVar8;
}

// ============================================================
// Function: FUN_18014e2bb
// Address: 0x18014e2bb
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

float fcn.18014df80(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h
                   , int64_t arg_88h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg3 == arg4) {
        return 0.0;
    }
    if (arg3 < arg4) {
        iVar2 = arg3;
        if ((arg3 <= arg2) && (iVar2 = arg2, arg4 < arg2)) {
            iVar2 = arg4;
        }
    } else {
        iVar2 = arg4;
        if ((arg4 <= arg2) && (iVar2 = arg2, arg3 < arg2)) {
            iVar2 = arg3;
        }
    }
    fVar8 = 0.0;
    if ((float)arg_28h <= 0.0) {
        return (float)(iVar2 - arg3) / (float)(arg4 - arg3);
    }
    iVar3 = arg3;
    iVar1 = arg4;
    if (arg3 <= arg4) {
        iVar3 = arg4;
        iVar1 = arg3;
    }
    dVar5 = (double)iVar1;
    dVar6 = (double)(float)arg_28h;
    fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
    fVar11 = (float)iVar1;
    if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar6) {
        fVar9 = (float)arg_28h;
        if (fVar11 < 0.0) {
            fVar9 = fVar10;
        }
        dVar5 = (double)fVar9;
    }
    dVar4 = (double)iVar3;
    fVar9 = (float)iVar3;
    if ((double)((uint64_t)dVar4 & 0x7fffffffffffffff) < dVar6) {
        if (fVar9 < 0.0) {
            arg_28h._0_4_ = fVar10;
        }
        dVar4 = (double)(float)arg_28h;
    }
    if ((fVar11 != 0.0) || (0.0 <= fVar9)) {
        if ((fVar9 == 0.0) && (fVar11 < 0.0)) {
            dVar4 = (double)fVar10;
        }
    } else {
        dVar5 = (double)fVar10;
    }
    dVar7 = (double)iVar2;
    if (dVar5 < dVar7) {
        if (dVar7 < dVar4) {
            if (0.0 <= (float)(iVar3 * iVar1)) {
                if ((fVar11 < 0.0) || (fVar9 < 0.0)) {
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar4 ^ 0x8000000000000000));
                    dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar4 ^ 0x8000000000000000));
                    fVar8 = 1.0 - (float)(dVar6 / dVar5);
                } else {
                    dVar6 = (double)fcn.180491150(dVar7 / dVar5);
                    dVar5 = (double)fcn.180491150(dVar4 / dVar5);
                    fVar8 = (float)(dVar6 / dVar5);
                }
            } else {
                fVar8 = (float)((uint32_t)fVar11 ^ 0x80000000) / (fVar9 - fVar11);
                if ((float)arg2 != 0.0) {
                    if (0.0 <= (float)arg2) {
                        dVar5 = (double)fcn.180491150(dVar7 / dVar6);
                        dVar6 = (double)fcn.180491150(dVar4 / dVar6);
                        fVar8 = (float)(dVar5 / dVar6) * (1.0 - (fVar8 + (float)arg_30h)) + fVar8 + (float)arg_30h;
                    } else {
                        dVar4 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) / dVar6);
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) / dVar6);
                        fVar8 = (1.0 - (float)(dVar4 / dVar5)) * (fVar8 - (float)arg_30h);
                    }
                }
            }
        } else {
            fVar8 = 1.0;
        }
    }
    if (arg3 <= arg4) {
        return fVar8;
    }
    return 1.0 - fVar8;
}

// ============================================================
// Function: FUN_18014e2f0
// Address: 0x18014e2f0
// Size: 61 bytes
// ============================================================
int64_t fcn.18014e2f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     int64_t arg_30h)
{
    double dVar1;
    double dVar2;
    double dVar3;
    int64_t iVar4;
    double dVar5;
    float in_XMM1_Da;
    float fVar6;
    float fVar7;
    float fVar8;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((0.0 < in_XMM1_Da) && (arg3 != arg4)) {
        if (1.0 <= in_XMM1_Da) {
            return arg4;
        }
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                iVar4 = (int64_t)((float)(arg4 - arg3) * in_XMM1_Da + (float)arg3);
            } else {
                iVar4 = 0;
                if (in_XMM1_Da < 1.0) {
                    if (arg4 < arg3) {
                        fVar6 = -0.5;
                    } else {
                        fVar6 = 0.5;
                    }
                    iVar4 = (int64_t)((float)(arg4 - arg3) * in_XMM1_Da + fVar6) + arg3;
                }
            }
        } else {
            fVar6 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            dVar5 = (double)arg3;
            dVar2 = (double)(float)arg_28h;
            fVar8 = (float)arg3;
            if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar2) {
                fVar7 = (float)arg_28h;
                if (fVar8 < 0.0) {
                    fVar7 = fVar6;
                }
                dVar5 = (double)fVar7;
            }
            dVar1 = (double)arg4;
            fVar7 = (float)arg4;
            if ((double)((uint64_t)dVar1 & 0x7fffffffffffffff) < dVar2) {
                if (fVar7 < 0.0) {
                    arg_28h._0_4_ = fVar6;
                }
                dVar1 = (double)(float)arg_28h;
            }
            dVar3 = dVar5;
            if (arg4 < arg3) {
                dVar3 = dVar1;
                dVar1 = dVar5;
            }
            if ((fVar7 == 0.0) && (fVar8 < 0.0)) {
                dVar1 = (double)fVar6;
            }
            if (arg4 < arg3) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= (float)(arg3 * arg4)) {
                if ((fVar8 < 0.0) || (fVar7 < 0.0)) {
                    dVar5 = (double)fcn.180491d70((double)((uint64_t)dVar3 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000), 
                                                  (double)(1.0 - in_XMM1_Da));
                    iVar4 = (int64_t)(double)((uint64_t)(dVar5 * (double)((uint64_t)dVar1 ^ 0x8000000000000000)) ^
                                             0x8000000000000000);
                } else {
                    dVar5 = (double)fcn.180491d70(dVar1 / dVar3, (double)in_XMM1_Da);
                    iVar4 = (int64_t)(dVar5 * dVar3);
                }
            } else {
                if (arg3 < arg4) {
                    arg4 = arg3;
                }
                fVar8 = (float)((uint32_t)(float)arg4 ^ 0x80000000) / (float)((uint32_t)(fVar7 - fVar8) & 0x7fffffff);
                fVar6 = fVar8 + (float)arg_30h;
                if ((in_XMM1_Da < fVar8 - (float)arg_30h) || (fVar6 < in_XMM1_Da)) {
                    if (fVar8 <= in_XMM1_Da) {
                        dVar5 = (double)fcn.180491d70(dVar1 / dVar2, (double)((in_XMM1_Da - fVar6) / (1.0 - fVar6)));
                        iVar4 = (int64_t)(dVar5 * dVar2);
                    } else {
                        dVar5 = (double)fcn.180491d70((double)((uint64_t)dVar3 ^ 0x8000000000000000) / dVar2, 
                                                      (double)(1.0 - in_XMM1_Da / (fVar8 - (float)arg_30h)));
                        iVar4 = (int64_t)(double)((uint64_t)(dVar5 * dVar2) ^ 0x8000000000000000);
                    }
                } else {
                    iVar4 = 0;
                }
            }
        }
        return iVar4;
    }
    return arg3;
}

// ============================================================
// Function: FUN_18014e32d
// Address: 0x18014e32d
// Size: 643 bytes
// ============================================================
int64_t fcn.18014e2f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     int64_t arg_30h)
{
    double dVar1;
    double dVar2;
    double dVar3;
    int64_t iVar4;
    double dVar5;
    float in_XMM1_Da;
    float fVar6;
    float fVar7;
    float fVar8;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((0.0 < in_XMM1_Da) && (arg3 != arg4)) {
        if (1.0 <= in_XMM1_Da) {
            return arg4;
        }
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                iVar4 = (int64_t)((float)(arg4 - arg3) * in_XMM1_Da + (float)arg3);
            } else {
                iVar4 = 0;
                if (in_XMM1_Da < 1.0) {
                    if (arg4 < arg3) {
                        fVar6 = -0.5;
                    } else {
                        fVar6 = 0.5;
                    }
                    iVar4 = (int64_t)((float)(arg4 - arg3) * in_XMM1_Da + fVar6) + arg3;
                }
            }
        } else {
            fVar6 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            dVar5 = (double)arg3;
            dVar2 = (double)(float)arg_28h;
            fVar8 = (float)arg3;
            if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar2) {
                fVar7 = (float)arg_28h;
                if (fVar8 < 0.0) {
                    fVar7 = fVar6;
                }
                dVar5 = (double)fVar7;
            }
            dVar1 = (double)arg4;
            fVar7 = (float)arg4;
            if ((double)((uint64_t)dVar1 & 0x7fffffffffffffff) < dVar2) {
                if (fVar7 < 0.0) {
                    arg_28h._0_4_ = fVar6;
                }
                dVar1 = (double)(float)arg_28h;
            }
            dVar3 = dVar5;
            if (arg4 < arg3) {
                dVar3 = dVar1;
                dVar1 = dVar5;
            }
            if ((fVar7 == 0.0) && (fVar8 < 0.0)) {
                dVar1 = (double)fVar6;
            }
            if (arg4 < arg3) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= (float)(arg3 * arg4)) {
                if ((fVar8 < 0.0) || (fVar7 < 0.0)) {
                    dVar5 = (double)fcn.180491d70((double)((uint64_t)dVar3 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000), 
                                                  (double)(1.0 - in_XMM1_Da));
                    iVar4 = (int64_t)(double)((uint64_t)(dVar5 * (double)((uint64_t)dVar1 ^ 0x8000000000000000)) ^
                                             0x8000000000000000);
                } else {
                    dVar5 = (double)fcn.180491d70(dVar1 / dVar3, (double)in_XMM1_Da);
                    iVar4 = (int64_t)(dVar5 * dVar3);
                }
            } else {
                if (arg3 < arg4) {
                    arg4 = arg3;
                }
                fVar8 = (float)((uint32_t)(float)arg4 ^ 0x80000000) / (float)((uint32_t)(fVar7 - fVar8) & 0x7fffffff);
                fVar6 = fVar8 + (float)arg_30h;
                if ((in_XMM1_Da < fVar8 - (float)arg_30h) || (fVar6 < in_XMM1_Da)) {
                    if (fVar8 <= in_XMM1_Da) {
                        dVar5 = (double)fcn.180491d70(dVar1 / dVar2, (double)((in_XMM1_Da - fVar6) / (1.0 - fVar6)));
                        iVar4 = (int64_t)(dVar5 * dVar2);
                    } else {
                        dVar5 = (double)fcn.180491d70((double)((uint64_t)dVar3 ^ 0x8000000000000000) / dVar2, 
                                                      (double)(1.0 - in_XMM1_Da / (fVar8 - (float)arg_30h)));
                        iVar4 = (int64_t)(double)((uint64_t)(dVar5 * dVar2) ^ 0x8000000000000000);
                    }
                } else {
                    iVar4 = 0;
                }
            }
        }
        return iVar4;
    }
    return arg3;
}

// ============================================================
// Function: FUN_18014e5b0
// Address: 0x18014e5b0
// Size: 8 bytes
// ============================================================
int64_t fcn.18014e2f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     int64_t arg_30h)
{
    double dVar1;
    double dVar2;
    double dVar3;
    int64_t iVar4;
    double dVar5;
    float in_XMM1_Da;
    float fVar6;
    float fVar7;
    float fVar8;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((0.0 < in_XMM1_Da) && (arg3 != arg4)) {
        if (1.0 <= in_XMM1_Da) {
            return arg4;
        }
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                iVar4 = (int64_t)((float)(arg4 - arg3) * in_XMM1_Da + (float)arg3);
            } else {
                iVar4 = 0;
                if (in_XMM1_Da < 1.0) {
                    if (arg4 < arg3) {
                        fVar6 = -0.5;
                    } else {
                        fVar6 = 0.5;
                    }
                    iVar4 = (int64_t)((float)(arg4 - arg3) * in_XMM1_Da + fVar6) + arg3;
                }
            }
        } else {
            fVar6 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            dVar5 = (double)arg3;
            dVar2 = (double)(float)arg_28h;
            fVar8 = (float)arg3;
            if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar2) {
                fVar7 = (float)arg_28h;
                if (fVar8 < 0.0) {
                    fVar7 = fVar6;
                }
                dVar5 = (double)fVar7;
            }
            dVar1 = (double)arg4;
            fVar7 = (float)arg4;
            if ((double)((uint64_t)dVar1 & 0x7fffffffffffffff) < dVar2) {
                if (fVar7 < 0.0) {
                    arg_28h._0_4_ = fVar6;
                }
                dVar1 = (double)(float)arg_28h;
            }
            dVar3 = dVar5;
            if (arg4 < arg3) {
                dVar3 = dVar1;
                dVar1 = dVar5;
            }
            if ((fVar7 == 0.0) && (fVar8 < 0.0)) {
                dVar1 = (double)fVar6;
            }
            if (arg4 < arg3) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= (float)(arg3 * arg4)) {
                if ((fVar8 < 0.0) || (fVar7 < 0.0)) {
                    dVar5 = (double)fcn.180491d70((double)((uint64_t)dVar3 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000), 
                                                  (double)(1.0 - in_XMM1_Da));
                    iVar4 = (int64_t)(double)((uint64_t)(dVar5 * (double)((uint64_t)dVar1 ^ 0x8000000000000000)) ^
                                             0x8000000000000000);
                } else {
                    dVar5 = (double)fcn.180491d70(dVar1 / dVar3, (double)in_XMM1_Da);
                    iVar4 = (int64_t)(dVar5 * dVar3);
                }
            } else {
                if (arg3 < arg4) {
                    arg4 = arg3;
                }
                fVar8 = (float)((uint32_t)(float)arg4 ^ 0x80000000) / (float)((uint32_t)(fVar7 - fVar8) & 0x7fffffff);
                fVar6 = fVar8 + (float)arg_30h;
                if ((in_XMM1_Da < fVar8 - (float)arg_30h) || (fVar6 < in_XMM1_Da)) {
                    if (fVar8 <= in_XMM1_Da) {
                        dVar5 = (double)fcn.180491d70(dVar1 / dVar2, (double)((in_XMM1_Da - fVar6) / (1.0 - fVar6)));
                        iVar4 = (int64_t)(dVar5 * dVar2);
                    } else {
                        dVar5 = (double)fcn.180491d70((double)((uint64_t)dVar3 ^ 0x8000000000000000) / dVar2, 
                                                      (double)(1.0 - in_XMM1_Da / (fVar8 - (float)arg_30h)));
                        iVar4 = (int64_t)(double)((uint64_t)(dVar5 * dVar2) ^ 0x8000000000000000);
                    }
                } else {
                    iVar4 = 0;
                }
            }
        }
        return iVar4;
    }
    return arg3;
}

